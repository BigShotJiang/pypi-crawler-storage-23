"""Storage and migration logic for Remote LLM config."""

import base64
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import structlog
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .remote_llm_config_models import RemoteLLMConfig

logger = structlog.get_logger(__name__)


class RemoteLLMConfigStorageMixin:
    """Persistence, migration, and key-recovery logic for remote LLM config."""

    def _decrypt_api_key_fields(
        self, api_key_enc: object, api_key_nonce: object
    ) -> Optional[str]:
        """Decrypt encrypted API key fields from config payload."""
        try:
            if not (isinstance(api_key_enc, str) and isinstance(api_key_nonce, str)):
                return None
            if not api_key_enc or not api_key_nonce:
                return None
            key = self._get_encryption_key_bytes()
            aesgcm = AESGCM(key)
            nonce = base64.b64decode(api_key_nonce)
            ct = base64.b64decode(api_key_enc)
            decrypted = aesgcm.decrypt(nonce, ct, None).decode()
            return decrypted if decrypted else None
        except Exception:
            return None

    def _extract_api_key_from_provider_payload(self, payload: object) -> Optional[str]:
        """Extract plaintext API key from a provider payload (encrypted or legacy plaintext)."""
        if not isinstance(payload, dict):
            return None
        decrypted = self._decrypt_api_key_fields(
            payload.get("api_key_enc"), payload.get("api_key_nonce")
        )
        if decrypted:
            return decrypted
        plain = payload.get("api_key")
        if isinstance(plain, str) and plain.strip():
            return plain.strip()
        return None

    def _extract_provider_keys_from_config_data(
        self, data: object
    ) -> Dict[str, str]:
        """Extract provider_id -> api_key from config JSON payload."""
        extracted: Dict[str, str] = {}
        if not isinstance(data, dict):
            return extracted

        providers_obj = data.get("providers")
        if isinstance(providers_obj, dict):
            for provider_id, payload in providers_obj.items():
                if not isinstance(provider_id, str) or not provider_id.strip():
                    continue
                key = self._extract_api_key_from_provider_payload(payload)
                if key:
                    extracted[provider_id.strip()] = key

        # Legacy flat structure fallback (single provider config).
        if not extracted:
            provider_id_obj = data.get("provider")
            provider_id = (
                provider_id_obj.strip()
                if isinstance(provider_id_obj, str) and provider_id_obj.strip()
                else "openai"
            )
            key = self._extract_api_key_from_provider_payload(data)
            if key:
                extracted[provider_id] = key

        return extracted

    def _candidate_key_recovery_paths(self) -> list[Path]:
        """Return candidate config files for one-time API key recovery."""
        candidates: list[Path] = []
        seen: set[Path] = set()

        def _append(path: Optional[Path]) -> None:
            if path is None:
                return
            if path in seen:
                return
            seen.add(path)
            candidates.append(path)

        # Primary legacy/canonical candidates from path helpers.
        _append(self._get_app_config_dir() / "remote_llm.json")
        _append(self._get_legacy_app_data_dir() / "remote_llm.json")

        # Historical roots used by older desktop builds.
        home = self._get_real_home()
        _append(home / "Library" / "Application Support" / "nowledge-mem" / "remote_llm.json")
        _append(home / ".config" / "co.nowledge.mem.desktop" / "remote_llm.json")
        _append(home / ".local" / "share" / "co.nowledge.mem.desktop" / "remote_llm.json")
        _append(home / "AppData" / "Roaming" / "co.nowledge.mem.desktop" / "remote_llm.json")

        # Common backup naming patterns.
        _append(self.config_path.with_suffix(self.config_path.suffix + ".backup"))
        _append(self.config_path.with_suffix(self.config_path.suffix + ".bak"))

        # Never "recover" from the same file we just loaded.
        return [p for p in candidates if p != self.config_path]

    def _recover_missing_provider_keys_locked(self) -> bool:
        """Recover missing provider API keys from legacy config files.

        Must be called while self._data_lock is held.
        """
        missing_provider_ids = [
            provider_id
            for provider_id, cfg in self._providers.items()
            if isinstance(provider_id, str)
            and provider_id.strip()
            and not ((cfg.api_key or "").strip())
        ]
        if not missing_provider_ids:
            return False

        recovered = False
        missing_set = set(missing_provider_ids)

        for candidate in self._candidate_key_recovery_paths():
            try:
                if not candidate.exists():
                    continue
                with open(candidate, "r", encoding="utf-8") as f:
                    payload = json.load(f)
                provider_keys = self._extract_provider_keys_from_config_data(payload)
                if not provider_keys:
                    continue

                recovered_from_candidate = 0
                for provider_id in list(missing_set):
                    key = provider_keys.get(provider_id)
                    if not key:
                        continue
                    cfg = self._providers.get(provider_id)
                    if not cfg:
                        continue
                    cfg.api_key = key
                    self._providers[provider_id] = cfg
                    missing_set.remove(provider_id)
                    recovered_from_candidate += 1
                    recovered = True

                if recovered_from_candidate > 0:
                    logger.warning(
                        "Recovered missing provider API keys from fallback config",
                        recovered_count=recovered_from_candidate,
                        source_path=str(candidate),
                    )

                if not missing_set:
                    break
            except Exception as e:
                logger.debug(
                    "Skipped API key recovery candidate",
                    path=str(candidate),
                    error=str(e),
                )

        if recovered:
            active_provider_id = (
                (self._purposes.get("default", {}) or {}).get("provider")
                or self._active_provider
                or self._config.provider
            )
            active_cfg = self._providers.get(active_provider_id or "")
            if active_cfg:
                self._config.api_key = active_cfg.api_key

        return recovered

    def _load_config(self) -> None:
        """Load configuration from file (thread-safe)."""
        import time

        # Check debounce BEFORE acquiring lock to avoid waiting if we should skip
        # (But always allow initial load when _last_save_time == -1)
        if self._last_save_time >= 0 and (
            self._saving or (time.time() - self._last_save_time) < 0.5
        ):
            logger.info(
                "Skipping _load_config - we just saved",
                saving=self._saving,
                time_since_save=time.time() - self._last_save_time,
            )
            return

        with self._data_lock:
            try:
                logger.warning(
                    "[CONFIG] Loading config from disk",
                    path=str(self.config_path),
                    file_exists=self.config_path.exists(),
                )
                if self.config_path.exists():
                    with open(self.config_path, "r") as f:
                        data = json.load(f)

                        # Multi-provider structure detection
                        if isinstance(data, dict) and "providers" in data:
                            enabled = bool(data.get("enabled", False))
                            active_provider = data.get("active_provider") or data.get(
                                "provider"
                            )
                            providers_obj = data.get("providers") or {}

                            self._providers = {}

                            # Load purpose selections (backward compatible)
                            purposes_obj = None
                            if isinstance(data.get("purposes"), dict):
                                purposes_obj = data.get("purposes")
                            # Older variants could use active_providers, accept but normalize
                            if purposes_obj is None and isinstance(
                                data.get("active_providers"), dict
                            ):
                                purposes_obj = data.get("active_providers")

                            def _read_purpose(p: object) -> Dict[str, Optional[str]]:
                                if isinstance(p, dict):
                                    prov = (
                                        p.get("provider")
                                        or p.get("provider_id")
                                        or p.get("active_provider")
                                    )
                                    model = p.get("model")
                                    return {
                                        "provider": str(prov)
                                        if isinstance(prov, str) and prov.strip()
                                        else None,
                                        "model": str(model)
                                        if isinstance(model, str) and model.strip()
                                        else None,
                                    }
                                if isinstance(p, str) and p.strip():
                                    return {"provider": p.strip(), "model": None}
                                return {"provider": None, "model": None}

                            if purposes_obj is not None and isinstance(
                                purposes_obj, dict
                            ):
                                self._purposes["default"] = _read_purpose(
                                    purposes_obj.get("default")
                                )
                                self._purposes["ai_now"] = _read_purpose(
                                    purposes_obj.get("ai_now")
                                )
                            else:
                                # Derive default purpose from active_provider + provider model
                                self._purposes["default"] = {
                                    "provider": str(active_provider).strip()
                                    if isinstance(active_provider, str)
                                    and str(active_provider).strip()
                                    else None,
                                    "model": None,
                                }
                                self._purposes["ai_now"] = {
                                    "provider": None,
                                    "model": None,
                                }

                            for provider_name, p_data in providers_obj.items():
                                # Decrypt nested api_key if present
                                api_key_plain: Optional[str] = None  # type: ignore
                                try:
                                    api_key_enc = p_data.get("api_key_enc")
                                    api_key_nonce = p_data.get("api_key_nonce")
                                    if api_key_enc and api_key_nonce:
                                        key = self._get_encryption_key_bytes()
                                        aesgcm = AESGCM(key)
                                        nonce = base64.b64decode(api_key_nonce)
                                        ct = base64.b64decode(api_key_enc)
                                        api_key_plain = aesgcm.decrypt(
                                            nonce, ct, None
                                        ).decode()
                                except Exception as e:
                                    logger.warning(
                                        "Failed to decrypt stored API key for provider",
                                        provider=provider_name,
                                        error=str(e),
                                    )

                                # Backward-compat: accept plaintext api_key inside provider
                                if not api_key_plain and p_data.get("api_key"):
                                    api_key_plain = p_data.get("api_key")

                                init_dict = {
                                    k: v
                                    for k, v in p_data.items()
                                    if k
                                    not in (
                                        "api_key",
                                        "api_key_enc",
                                        "api_key_nonce",
                                        "type",
                                    )
                                }
                                # provider_name is our provider_id (dict key).
                                # provider_type may differ for multi-instance providers.
                                provider_type = None
                                try:
                                    t = p_data.get("type")
                                    if isinstance(t, str) and t.strip():
                                        provider_type = t.strip()
                                except Exception:
                                    provider_type = None

                                init_dict["provider"] = provider_name
                                init_dict["provider_type"] = (
                                    provider_type or provider_name
                                )
                                # Optional display name
                                try:
                                    dn = p_data.get("display_name")
                                    if isinstance(dn, str) and dn.strip():
                                        init_dict["display_name"] = dn.strip()
                                except Exception:
                                    pass
                                if api_key_plain:
                                    init_dict["api_key"] = api_key_plain

                                try:
                                    prov_cfg = RemoteLLMConfig(**init_dict)
                                except Exception:
                                    # Ensure provider is set even if p_data incomplete
                                    prov_cfg = RemoteLLMConfig(
                                        provider=provider_name,
                                        provider_type=provider_type or provider_name,
                                    )

                                self._providers[provider_name] = prov_cfg

                            # Select active config
                            default_provider_id = (
                                self._purposes.get("default", {}).get("provider")
                                or active_provider
                            )
                            if (
                                default_provider_id
                                and default_provider_id in self._providers
                            ):
                                self._config = self._providers[
                                    default_provider_id
                                ].model_copy()
                            else:
                                # Pick any configured provider or default
                                self._config = (
                                    next(iter(self._providers.values())).model_copy()
                                    if self._providers
                                    else RemoteLLMConfig()
                                )
                                default_provider_id = (
                                    self._config.provider or default_provider_id
                                )

                            # Apply global enabled flag
                            self._config.enabled = enabled
                            # Ensure default purpose is always populated
                            if not self._purposes.get("default", {}).get("provider"):
                                self._purposes["default"]["provider"] = (
                                    default_provider_id
                                )
                            if not self._purposes.get("default", {}).get("model"):
                                # Store explicit default model selection if we have one
                                dm = (self._config.model or "").strip()
                                self._purposes["default"]["model"] = dm if dm else None

                            self._active_provider = self._purposes["default"][
                                "provider"
                            ]
                            # If default selection is invalid (common when only a Custom instance is configured),
                            # auto-select the only configured provider deterministically.
                            self._ensure_valid_default_selection_locked()
                            recovered_keys = self._recover_missing_provider_keys_locked()
                            if recovered_keys:
                                # Persist recovered keys immediately so downstream consumers
                                # read a single canonical config source.
                                self._save_config()

                            logger.info(
                                "Loaded remote LLM config (multi-provider)",
                                enabled=enabled,
                                active_provider=self._active_provider,
                                providers=list(self._providers.keys()),
                            )
                        else:
                            # Legacy flat structure
                            # Decrypt api_key if stored encrypted
                            api_key_plain: Optional[str] = None
                            try:
                                api_key_enc = data.get("api_key_enc")
                                api_key_nonce = data.get("api_key_nonce")
                                if api_key_enc and api_key_nonce:
                                    key = self._get_encryption_key_bytes()
                                    aesgcm = AESGCM(key)
                                    nonce = base64.b64decode(api_key_nonce)
                                    ct = base64.b64decode(api_key_enc)
                                    api_key_plain = aesgcm.decrypt(
                                        nonce, ct, None
                                    ).decode()
                            except Exception as e:
                                logger.warning(
                                    "Failed to decrypt stored API key", error=str(e)
                                )

                            # Backward-compat: accept plaintext api_key for first version (no migration yet)
                            if not api_key_plain and data.get("api_key"):
                                api_key_plain = data.get("api_key")

                            # Build model, injecting decrypted api_key
                            model_init = {
                                k: v
                                for k, v in data.items()
                                if k not in ("api_key", "api_key_enc", "api_key_nonce")
                            }
                            if api_key_plain:
                                model_init["api_key"] = api_key_plain

                            self._config = RemoteLLMConfig(**model_init)
                            self._active_provider = self._config.provider
                            # Initialize providers map with the active one for migration
                            self._providers = {
                                self._config.provider: self._config.model_copy()
                            }
                            # Initialize purposes (legacy)
                            self._purposes["default"] = {
                                "provider": self._config.provider,
                                "model": (self._config.model or "").strip() or None,
                            }
                            self._purposes["ai_now"] = {"provider": None, "model": None}
                            self._ensure_valid_default_selection_locked()
                            recovered_keys = self._recover_missing_provider_keys_locked()
                            if recovered_keys:
                                self._save_config()
                            logger.info(
                                "Loaded remote LLM config (legacy)",
                                enabled=self._config.enabled,
                                provider=self._config.provider,
                                model=self._config.model,
                            )
                else:
                    # Create default config file
                    self._save_config()
                    logger.info(
                        "Created default remote LLM config", path=str(self.config_path)
                    )
            except Exception as e:
                logger.error("Failed to load remote LLM config", error=str(e))
                self._config = RemoteLLMConfig()

        # Notify change callbacks (outside the lock to avoid deadlocks)
        # This enables reactive startup (e.g., Knowledge Agent starting when config becomes available)
        self._notify_change_callbacks()

    def _save_config(self) -> None:
        """Save configuration to file (thread-safe)."""
        import time

        with self._data_lock:
            try:
                # Mark that we're saving to prevent file watcher from reloading
                self._saving = True
                self._last_save_time = time.time()

                self.config_path.parent.mkdir(parents=True, exist_ok=True)
                # Load previous file to preserve encrypted keys when not updating them
                prev_providers: Dict[str, Dict[str, Any]] = {}
                try:
                    if self.config_path.exists():
                        with open(self.config_path, "r") as _pf:
                            _pdata = json.load(_pf) or {}
                            if isinstance(_pdata, dict):
                                prev_providers = _pdata.get("providers", {}) or {}
                except Exception:
                    prev_providers = {}

                # Build multi-provider structure
                active_provider = (
                    (self._purposes.get("default", {}) or {}).get("provider")
                    or self._active_provider
                    or self._config.provider
                )
                enabled = bool(self._config.enabled)
                providers_out: Dict[str, Any] = {}

                # DO NOT overwrite providers[active_provider] with self._config here!
                # update_config already maintains _providers correctly; copying _config back would overwrite
                # the provider's real credentials with stale or wrong ones from the flattened _config.

                os_module = self._os_module()

                for provider_name, prov_cfg in self._providers.items():
                    p_dict = prov_cfg.model_dump()
                    # Encrypt api_key per provider; never write plaintext
                    api_key_plain = (prov_cfg.api_key or "").strip()
                    prev = prev_providers.get(provider_name) or {}

                    def _restore_prev_key_fields() -> bool:
                        if not isinstance(prev, dict):
                            return False
                        if prev.get("api_key_enc") and prev.get("api_key_nonce"):
                            p_dict["api_key_enc"] = prev.get("api_key_enc")
                            p_dict["api_key_nonce"] = prev.get("api_key_nonce")
                            return True
                        legacy_plain = str(prev.get("api_key") or "").strip()
                        if legacy_plain:
                            p_dict["api_key"] = legacy_plain
                            return True
                        return False

                    if api_key_plain:
                        try:
                            key = self._get_encryption_key_bytes()
                            aesgcm = AESGCM(key)
                            nonce = os_module.urandom(12)
                            ct = aesgcm.encrypt(nonce, api_key_plain.encode(), None)
                            p_dict.pop("api_key", None)
                            p_dict["api_key_enc"] = base64.b64encode(ct).decode()
                            p_dict["api_key_nonce"] = base64.b64encode(nonce).decode()
                        except Exception as e:
                            logger.warning(
                                "Failed to encrypt API key for provider; preserving key data to avoid loss",
                                provider=provider_name,
                                error=str(e),
                            )
                            p_dict.pop("api_key_enc", None)
                            p_dict.pop("api_key_nonce", None)
                            if not _restore_prev_key_fields():
                                # Last resort: keep plaintext key rather than silently dropping it.
                                p_dict["api_key"] = api_key_plain
                    else:
                        # Keep previously persisted encrypted fields if present
                        p_dict.pop("api_key", None)
                        if isinstance(prev, dict):
                            if prev.get("api_key_enc") and prev.get("api_key_nonce"):
                                p_dict["api_key_enc"] = prev.get("api_key_enc")
                                p_dict["api_key_nonce"] = prev.get("api_key_nonce")
                            # Legacy plaintext migration: if previous file still had plaintext key,
                            # encrypt it now so updates never drop credentials silently.
                            elif prev.get("api_key"):
                                legacy_plain = str(prev.get("api_key") or "").strip()
                                if legacy_plain:
                                    try:
                                        key = self._get_encryption_key_bytes()
                                        aesgcm = AESGCM(key)
                                        nonce = os_module.urandom(12)
                                        ct = aesgcm.encrypt(
                                            nonce, legacy_plain.encode(), None
                                        )
                                        p_dict["api_key_enc"] = (
                                            base64.b64encode(ct).decode()
                                        )
                                        p_dict["api_key_nonce"] = (
                                            base64.b64encode(nonce).decode()
                                        )
                                    except Exception as e:
                                        # Last-resort safety: keep plaintext instead of losing key.
                                        logger.warning(
                                            "Failed to migrate legacy plaintext API key; preserving plaintext to avoid key loss",
                                            provider=provider_name,
                                            error=str(e),
                                        )
                                        p_dict["api_key"] = legacy_plain

                    # Provider field is implicit in key
                    p_dict.pop("provider", None)
                    # Enabled is global, not per-provider
                    p_dict.pop("enabled", None)
                    # Persist provider type separately for multi-instance providers.
                    provider_type = (
                        prov_cfg.provider_type or ""
                    ).strip() or provider_name
                    p_dict.pop("provider_type", None)
                    p_dict["type"] = provider_type
                    # Optional display name
                    dn = (prov_cfg.display_name or "").strip()
                    p_dict.pop("display_name", None)
                    if dn:
                        p_dict["display_name"] = dn
                    providers_out[provider_name] = p_dict

                file_data = {
                    "enabled": enabled,
                    # Backward compatible: active_provider == default purpose provider
                    "active_provider": active_provider,
                    "purposes": {
                        "default": {
                            "provider": (self._purposes.get("default", {}) or {}).get(
                                "provider"
                            ),
                            "model": (self._purposes.get("default", {}) or {}).get(
                                "model"
                            ),
                        },
                        "ai_now": {
                            "provider": (self._purposes.get("ai_now", {}) or {}).get(
                                "provider"
                            ),
                            "model": (self._purposes.get("ai_now", {}) or {}).get(
                                "model"
                            ),
                        },
                    },
                    "providers": providers_out,
                    "last_updated": datetime.utcnow().isoformat(),
                }
                backup_path = self.config_path.with_suffix(
                    self.config_path.suffix + ".backup"
                )
                tmp_path = self.config_path.with_suffix(
                    self.config_path.suffix + ".tmp"
                )

                # Best-effort backup of previous config for operator recovery.
                if self.config_path.exists():
                    try:
                        shutil.copy2(self.config_path, backup_path)
                    except Exception as e:
                        logger.warning(
                            "Failed to create remote LLM config backup before save",
                            path=str(self.config_path),
                            backup_path=str(backup_path),
                            error=str(e),
                        )

                # Atomic write: write to temp file first, then replace.
                try:
                    with open(tmp_path, "w", encoding="utf-8") as f:
                        json.dump(file_data, f, indent=2)
                    os_module.replace(tmp_path, self.config_path)
                finally:
                    if tmp_path.exists():
                        try:
                            tmp_path.unlink()
                        except Exception:
                            pass
                logger.info("Saved remote LLM config", path=str(self.config_path))
            except Exception as e:
                logger.error("Failed to save remote LLM config", error=str(e))
            finally:
                # Clear the saving flag after a short delay to allow file watcher to see it
                # (file watcher will check this flag and skip reload if still saving)
                import time

                time.sleep(0.1)  # 100ms grace period
                self._saving = False
