"""Central place to define the (temporary) hardcoded encryption key.

WARNING: Hardcoding secrets in a repository is not secure and should only be
used for development/testing. Prefer an OS keychain or environment secret.

Key format: 32 random bytes, Base64-encoded (URL-safe not required).

How to generate a key (choose ONE):
  - OpenSSL (most systems):
      openssl rand -base64 32
  - Python (no external deps):
      python3 - <<'PY'
      import os, base64
      print(base64.b64encode(os.urandom(32)).decode())
      PY

After generating, replace the placeholder string below with your key.
"""

from __future__ import annotations

# Replace the placeholder with your Base64-encoded 32-byte key string.
ENCRYPTION_KEY_B64: str = "J6NlDKLIwsEMfJxmS0rh8kj8S1a+N4bnvj7VV7NFpkM="


def get_encryption_key_bytes() -> bytes:
    """Return the raw 32-byte key from ENCRYPTION_KEY_B64.

    Raises:
        ValueError: if the value is unset or invalid.
    """
    import base64

    key_b64 = (ENCRYPTION_KEY_B64 or "").strip()
    if not key_b64 or key_b64 == "REPLACE_WITH_BASE64_32_BYTE_KEY":
        raise ValueError(
            "Encryption key not set. Please set ENCRYPTION_KEY_B64 in secure_keys.py"
        )

    try:
        key = base64.b64decode(key_b64)
    except Exception as e:
        raise ValueError(f"Invalid Base64 encryption key: {e}") from e

    if len(key) != 32:
        raise ValueError(f"Encryption key must be 32 bytes, got {len(key)} bytes")
    return key
