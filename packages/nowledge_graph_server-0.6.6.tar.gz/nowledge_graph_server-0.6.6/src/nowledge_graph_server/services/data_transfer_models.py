"""Shared models/constants for data transfer."""

from __future__ import annotations

from dataclasses import dataclass

EXPORT_FORMAT = "nowledge-mem-export"
EXPORT_VERSION = 1


@dataclass
class ExportOptions:
    include_memories: bool = True
    include_threads: bool = True
    include_messages: bool = True
    include_entities: bool = True
    include_labels: bool = True
    include_sources: bool = True
    include_communities: bool = True
    include_edges: bool = True
    include_working_memory: bool = True
    include_working_memory_archive: bool = True
    include_source_files: bool = True
    compress: bool = True
    overwrite: bool = False


@dataclass
class ImportOptions:
    include_memories: bool = True
    include_threads: bool = True
    include_messages: bool = True
    include_entities: bool = True
    include_labels: bool = True
    include_sources: bool = True
    include_communities: bool = True
    include_edges: bool = True
    include_working_memory: bool = True
    include_working_memory_archive: bool = True
    include_source_files: bool = True
    mode: str = "merge"  # merge | skip | overwrite
