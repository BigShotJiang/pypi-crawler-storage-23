"""
JSON parsing and cleaning utilities for LLM responses.

Provides robust JSON extraction from LLM outputs with multiple fallback strategies.
"""

import json
import re
from typing import Any, Dict, List, Optional

import structlog
from json_repair import repair_json

logger = structlog.get_logger()


def clean_and_parse_json(response: str) -> Optional[Dict[str, Any]]:
    """Clean LLM response and parse JSON with multiple fallback strategies.

    Strategy order:
    1) Prefer the last fenced ```json block
    2) Otherwise, the last fenced ``` block
    3) Otherwise, try balanced-brace extraction of the largest JSON object/array
    4) Parse with json_repair first; if it returns a string, parse again
    5) Standard json.loads fallback and light repairs

    Args:
        response: Raw LLM response text

    Returns:
        Parsed JSON dict or None if parsing fails
    """
    try:
        logger.debug("Starting JSON cleaning and parsing", response_length=len(response))

        json_content = (
            _pick_fenced_json(response.strip())
            or _extract_largest_balanced(response.strip())
            or response.strip()
        )

        source = _determine_source(json_content, response.strip())
        logger.debug(
            "Selected JSON candidate",
            source=source,
            candidate_length=len(json_content or ""),
            candidate_preview=(json_content or "")[:200],
        )

        # Step B: Try parsing with json_repair
        result = _try_json_repair(json_content)
        if result is not None:
            return result

        # Step C: Standard parse (accept only dicts with expected keys)
        result = _try_standard_parse(json_content)
        if result is not None:
            return result

        # Step D: Light repairs then parse again
        result = _try_light_repairs(json_content)
        if result is not None:
            return result

        # Step E: Regex-based object/array extraction as last resort
        result = _try_regex_extraction(response.strip())
        if result is not None:
            return result

        logger.debug(
            "All JSON parsing strategies failed",
            response_preview=response[:300],
        )
        return None

    except Exception as e:
        logger.error(
            "JSON cleaning and parsing failed",
            error=str(e),
            response_preview=response[:200],
        )
        return None


def _pick_fenced_json(text: str) -> Optional[str]:
    """Extract JSON from fenced code blocks, preferring ```json blocks."""
    # Prefer explicit ```json blocks (case-insensitive)
    json_fences = re.findall(r"```json\s*([\s\S]*?)```", text, flags=re.IGNORECASE)
    if json_fences:
        best = max(json_fences, key=_score_json_block)
        return best.strip()

    # Fallback: any fenced block, choose the best with relevant keys
    any_fences = re.findall(r"```\s*([\s\S]*?)```", text)
    if any_fences:
        best = max(any_fences, key=_score_json_block)
        return best.strip()

    return None


def _score_json_block(block: str) -> int:
    """Score a JSON block by relevance (entities/relationships/memories)."""
    score = 0
    if "entities" in block:
        score += 2
    if "relationships" in block:
        score += 2
    if "memories" in block:
        score += 3
    return score + len(block) // 100  # bias to longer blocks


def _extract_largest_balanced(text: str) -> Optional[str]:
    """Extract the largest balanced JSON object/array in the text."""
    best_candidate = None
    best_score = -1
    start_positions = [i for i, ch in enumerate(text) if ch in "{["]

    for start in start_positions:
        stack: List[str] = []
        for i in range(start, len(text)):
            ch = text[i]
            if ch in "{[":
                stack.append(ch)
            elif ch in "}]":
                if not stack:
                    break
                top = stack[-1]
                if (top == "{" and ch == "}") or (top == "[" and ch == "]"):
                    stack.pop()
                    if not stack:
                        candidate = text[start : i + 1]
                        score = len(candidate)
                        if "entities" in candidate:
                            score += 500
                        if "relationships" in candidate:
                            score += 500
                        if "memories" in candidate:
                            score += 800
                        if score > best_score:
                            best_candidate = candidate
                            best_score = score
                        break

    return best_candidate


def _determine_source(json_content: Optional[str], cleaned_response: str) -> str:
    """Determine the source of extracted JSON for logging."""
    if json_content and json_content in cleaned_response and "```" in cleaned_response:
        return "fenced-json"
    elif json_content and json_content != cleaned_response:
        return "balanced-scan"
    return "raw"


def _try_json_repair(json_content: Optional[str]) -> Optional[Dict[str, Any]]:
    """Try parsing with json_repair library."""
    try:
        logger.debug("Attempting json_repair parsing")
        repaired = repair_json(json_content or "")
        parsed = json.loads(repaired)

        # If the parser returns a JSON string, attempt to parse once more
        if isinstance(parsed, str):
            logger.debug("json_repair produced string, attempting second parse")
            parsed = json.loads(parsed)

        if isinstance(parsed, list):
            return _extract_relevant_from_list(parsed)

        if isinstance(parsed, dict):
            return parsed

        logger.debug(
            "json_repair produced unexpected type",
            parsed_type=type(parsed).__name__,
            parsed_preview=str(parsed)[:200],
        )

    except Exception as repair_error:
        logger.debug("json_repair failed or incomplete", error=str(repair_error))

    return None


def _try_standard_parse(json_content: Optional[str]) -> Optional[Dict[str, Any]]:
    """Standard JSON parse accepting only dicts with expected keys."""
    try:
        parsed = json.loads(json_content or "")
        if isinstance(parsed, str):
            parsed = json.loads(parsed)

        if isinstance(parsed, dict):
            if any(k in parsed for k in ("entities", "relationships", "memories")):
                return parsed
            raise ValueError("Parsed dict missing expected keys")

        if isinstance(parsed, list):
            for item in parsed:
                if isinstance(item, dict) and any(
                    k in item for k in ("entities", "relationships", "memories")
                ):
                    return item

    except Exception as json_error:
        logger.debug("Standard parse failed", error=str(json_error))

    return None


def _try_light_repairs(json_content: Optional[str]) -> Optional[Dict[str, Any]]:
    """Apply light repairs and try parsing again."""
    fixed = json_content or ""
    fixed = re.sub(r"(\w+):", r'"\1":', fixed)
    fixed = fixed.replace("'", '"')

    # Try to complete truncated braces/brackets
    open_braces = fixed.count("{") - fixed.count("}")
    open_brackets = fixed.count("[") - fixed.count("]")
    if open_brackets > 0:
        fixed += "]" * open_brackets
    if open_braces > 0:
        fixed += "}" * open_braces

    try:
        parsed = json.loads(fixed)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)

        if isinstance(parsed, dict):
            if any(k in parsed for k in ("entities", "relationships", "memories")):
                return parsed

        if isinstance(parsed, list):
            for item in parsed:
                if isinstance(item, dict) and any(
                    k in item for k in ("entities", "relationships", "memories")
                ):
                    return item

    except Exception:
        pass

    return None


def _try_regex_extraction(cleaned_response: str) -> Optional[Dict[str, Any]]:
    """Regex-based object/array extraction as last resort."""
    candidates = re.findall(r"(\{[\s\S]*\}|\[[\s\S]*\])", cleaned_response)
    candidates.sort(key=lambda s: len(s), reverse=True)

    for cand in candidates:
        try:
            parsed = json.loads(repair_json(cand))
            if isinstance(parsed, dict):
                if any(k in parsed for k in ("entities", "relationships", "memories")):
                    return parsed
            elif isinstance(parsed, list):
                for item in parsed:
                    if isinstance(item, dict) and any(
                        k in item for k in ("entities", "relationships", "memories")
                    ):
                        return item
        except Exception:
            continue

    return None


def _extract_relevant_from_list(parsed: list) -> Optional[Dict[str, Any]]:
    """Extract relevant dict from a parsed list."""
    # Prefer dict item containing 'memories'
    for item in reversed(parsed):
        if isinstance(item, dict) and ("memories" in item or "entities" in item):
            return item
    # Otherwise first dict
    for item in parsed:
        if isinstance(item, dict):
            return item
    return None
