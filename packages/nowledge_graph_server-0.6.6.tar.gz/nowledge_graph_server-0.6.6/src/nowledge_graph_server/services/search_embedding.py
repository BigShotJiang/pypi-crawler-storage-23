"""Search embedding service for LanceDB hybrid search.

This module provides platform-specific 1024-dimensional embeddings for the search index:
- macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings (fast, native Metal)
- non-Apple-Silicon: BGE-M3 via FastEmbed/ONNX (cross-platform)

This is optimized for LanceDB's hybrid search (vector + BM25 FTS with RRF fusion).
"""

import asyncio
import gc
import os
import time
from pathlib import Path
from typing import Any, List, Optional, Tuple, Callable
import platform

import structlog

logger = structlog.get_logger(__name__)

# Platform detection (same as embedding.py)
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"
IS_INTEL_MAC = platform.system() == "Darwin" and platform.machine() == "x86_64"
SHOULD_USE_ONNX = IS_WINDOWS or IS_LINUX or IS_INTEL_MAC

# Model configuration
SEARCH_EMBEDDING_DIMENSION = 1024

# Platform-specific models
MLX_MODEL = "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"  # ~400MB, 4-bit quantized
# BAAI/bge-m3 has ONNX files in repo on both HuggingFace and ModelScope
ONNX_MODEL = "BAAI/bge-m3"  # ~1.4GB ONNX, onnx/model.onnx in repo

# Qwen3-Embedding requires instruction prefix for queries (not for documents)
# See: https://huggingface.co/Qwen/Qwen3-Embedding-0.6B
QWEN3_QUERY_INSTRUCTION = "Given a web search query, retrieve relevant passages that answer the query"

# Enhanced instruction for short queries
# Short queries lack context, so we use a more descriptive instruction
# This guides the embedding model without modifying the query text itself
QWEN3_SHORT_QUERY_INSTRUCTION = (
    "Given a short keyword or phrase, retrieve comprehensive passages that explain, "
    "describe, or contain detailed information about this topic"
)

# Threshold for short query detection
SHORT_QUERY_CHAR_THRESHOLD = 15
SHORT_QUERY_WORD_THRESHOLD = 3

# Chunk size for FastEmbed batch indexing to cap peak host RAM during large reindex jobs.
FASTEMBED_BATCH_CHUNK_SIZE = 128


def _is_short_query(text: str) -> bool:
    """Detect if a query is short and needs enhanced instruction.

    Short queries have less semantic information, causing embeddings to cluster.
    We use enhanced instruction prefix (not query modification) to help.
    """
    text = text.strip()
    if not text:
        return True

    # Character-based check (good for CJK)
    if len(text) < SHORT_QUERY_CHAR_THRESHOLD:
        return True

    # Word-based check (for space-separated languages)
    words = text.split()
    if len(words) < SHORT_QUERY_WORD_THRESHOLD:
        return True

    return False

# Global locks
_GLOBAL_DOWNLOAD_LOCK: asyncio.Lock = asyncio.Lock()

# Import shared MLX lock (shared across embeddings + LLM to prevent Metal conflicts)
from .mlx_locks import get_mlx_inference_lock


def _import_mlx_embeddings() -> Tuple[Optional[Callable[[str], Tuple[Any, Any]]], Optional[Any]]:
    """Lazy import for MLX embeddings (Apple Silicon optimized)."""
    try:
        from mlx_embeddings.utils import load
        import mlx.core as mx

        return load, mx
    except ImportError as e:
        logger.error("Failed to import mlx_embeddings", error=str(e))
        return None, None


def _import_fastembed():
    """Lazy import for FastEmbed (ONNX runtime)."""
    try:
        from fastembed import TextEmbedding # type: ignore

        return TextEmbedding
    except ImportError as e:
        logger.error("Failed to import fastembed", error=str(e))
        raise ImportError(
            "fastembed is required for search embeddings on non-Apple-Silicon platforms. "
            "Install with: pip install fastembed"
        )


def _try_linux_malloc_trim() -> Optional[bool]:
    """Best-effort glibc heap trim on Linux to return freed memory to OS."""
    if not IS_LINUX:
        return None
    try:
        import ctypes

        libc = ctypes.CDLL("libc.so.6")
        malloc_trim = getattr(libc, "malloc_trim", None)
        if malloc_trim is None:
            return None
        malloc_trim.argtypes = [ctypes.c_size_t]
        malloc_trim.restype = ctypes.c_int
        return bool(malloc_trim(0))
    except Exception:
        return None


class SearchEmbeddingService:
    """Platform-specific search embedding service for LanceDB hybrid search.

    Provides 1024-dimensional embeddings using:
    - MLX + Qwen3-Embedding on macOS Apple Silicon
    - FastEmbed + BGE-M3 on non-Apple-Silicon
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        cache_only: bool = True,
        download_source: str = "auto",  # "huggingface", "modelscope", or "auto"
    ):
        """Initialize search embedding service.

        Args:
            cache_dir: Local cache directory for models
            cache_only: Use only cached models (don't download)
            download_source: Download source - "huggingface", "modelscope", or "auto" (detect based on region)
        """
        self.cache_dir = cache_dir
        self.cache_only = cache_only
        self.download_source = download_source
        self.dimension = SEARCH_EMBEDDING_DIMENSION
        self._initialized = False

        # Platform-specific model selection
        if IS_APPLE_SILICON:
            self.model_name = MLX_MODEL
            self._backend = "mlx"
        else:
            # BAAI/bge-m3 has onnx/model.onnx in both HuggingFace and ModelScope repos
            self.model_name = ONNX_MODEL
            self._backend = "fastembed"

        # Model instances (initialized lazily)
        self._mlx_model: Optional[Any] = None
        self._mlx_tokenizer: Optional[Any] = None
        self._mlx_mx: Optional[Any] = None
        self._fastembed_model: Optional[Any] = None

        # Idle tracking for memory management
        self._last_used_at: float = 0.0

    async def release_runtime_cache(self, reason: str = "manual") -> None:
        """Release runtime memory/caches to reduce long-lived residency after heavy batches."""
        loop = asyncio.get_event_loop()

        if not IS_APPLE_SILICON:
            def _clear_host() -> Optional[bool]:
                try:
                    gc.collect()
                except Exception:
                    pass
                return _try_linux_malloc_trim()

            malloc_trimmed = await loop.run_in_executor(None, _clear_host)
            logger.debug(
                "Released FastEmbed host runtime cache",
                reason=reason,
                malloc_trimmed=malloc_trimmed,
            )
            return

        if self._mlx_mx is None:
            return

        def _clear() -> tuple[Optional[int], Optional[int]]:
            active_before = None
            active_after = None
            try:
                if hasattr(self._mlx_mx, "get_active_memory"):
                    active_before = int(self._mlx_mx.get_active_memory())  # type: ignore[arg-type]
            except Exception:
                active_before = None

            try:
                if hasattr(self._mlx_mx, "clear_cache"):
                    self._mlx_mx.clear_cache()
                metal = getattr(self._mlx_mx, "metal", None)
                if metal is not None and hasattr(metal, "clear_cache"):
                    metal.clear_cache()
            except Exception as e:
                logger.debug("Failed to clear MLX cache", reason=reason, error=str(e))

            try:
                gc.collect()
            except Exception:
                pass

            try:
                if hasattr(self._mlx_mx, "get_active_memory"):
                    active_after = int(self._mlx_mx.get_active_memory())  # type: ignore[arg-type]
            except Exception:
                active_after = None

            return active_before, active_after

        mlx_lock = get_mlx_inference_lock()
        if mlx_lock is not None:
            async with mlx_lock:
                active_before, active_after = await loop.run_in_executor(None, _clear)
        else:
            active_before, active_after = await loop.run_in_executor(None, _clear)

        logger.debug(
            "Released MLX runtime cache",
            reason=reason,
            active_memory_before=active_before,
            active_memory_after=active_after,
        )

    async def initialize(self) -> None:
        """Initialize the embedding model."""
        if self._initialized:
            return

        logger.info(
            "Initializing search embedding model",
            model=self.model_name,
            backend=self._backend,
            cache_only=self.cache_only,
        )

        try:
            if IS_APPLE_SILICON:
                await self._initialize_mlx()
            else:
                await self._initialize_fastembed()

            self._initialized = True
            self._last_used_at = time.monotonic()  # start idle timer from load time
            logger.info(
                "Search embedding model initialized",
                model=self.model_name,
                dimension=self.dimension,
            )
        except Exception as e:
            logger.error(
                "Failed to initialize search embedding model",
                model=self.model_name,
                error=str(e),
            )
            raise

    async def _initialize_mlx(self) -> None:
        """Initialize MLX model for macOS Apple Silicon."""
        load_fn, mx = _import_mlx_embeddings()
        if load_fn is None or mx is None:
            raise RuntimeError("MLX embeddings not available on this platform")

        self._mlx_mx = mx

        # Check if model is cached
        from ..config import get_settings
        settings = get_settings()

        # Get HuggingFace cache directory
        hf_cache_root = Path.home() / ".cache" / "huggingface" / "hub"
        if settings.embedding_cache_dir:
            hf_cache_root = Path(settings.embedding_cache_dir)

        # Check for cached model
        model_cache_path = self._find_mlx_model_cache(hf_cache_root)

        if model_cache_path is None:
            if self.cache_only:
                logger.error(
                    "Search model not found in cache",
                    model=self.model_name,
                    checked_paths=[
                        str(hf_cache_root / f"models--{self.model_name.replace('/', '--')}"),
                        str(hf_cache_root / self.model_name),
                    ],
                )
                raise RuntimeError(
                    f"Search model {self.model_name} not cached and cache_only mode enabled. "
                    "Please download the model first."
                )

            # Download model using region-aware source
            async with _GLOBAL_DOWNLOAD_LOCK:
                await self._download_mlx_model(hf_cache_root, self.download_source)
                model_cache_path = self._find_mlx_model_cache(hf_cache_root)

        if model_cache_path is None:
            raise RuntimeError(f"Failed to load MLX model from {hf_cache_root}")

        # IMPORTANT: Always set offline mode when loading from cache to prevent network calls
        # This prevents mlx_embeddings from trying to validate/update the model via HuggingFace
        original_hf_offline = os.environ.get("HF_HUB_OFFLINE")
        original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")

        # Always set offline mode when we have a cached model
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

        try:
            # Load model from LOCAL PATH, not model name
            # This avoids HuggingFace API calls entirely since we pass the resolved path
            loop = asyncio.get_event_loop()
            local_path = str(model_cache_path)

            logger.debug(
                "Loading MLX model from local cache",
                model=self.model_name,
                local_path=local_path,
            )

            def _load():
                return load_fn(local_path)

            model, tokenizer = await loop.run_in_executor(None, _load)
            self._mlx_model = model
            self._mlx_tokenizer = tokenizer
        finally:
            # Restore original env vars (or remove if they weren't set)
            if original_hf_offline is not None:
                os.environ["HF_HUB_OFFLINE"] = original_hf_offline
            else:
                os.environ.pop("HF_HUB_OFFLINE", None)

            if original_transformers_offline is not None:
                os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
            else:
                os.environ.pop("TRANSFORMERS_OFFLINE", None)

    def _find_mlx_model_cache(self, hf_cache_root: Path) -> Optional[Path]:
        """Find cached MLX model.

        Args:
            hf_cache_root: HuggingFace cache root directory

        Returns:
            Path to model directory or None if not found
        """
        # Check HuggingFace-style cache structure
        hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
        model_cache_dir = hf_cache_root / hf_cache_name

        if model_cache_dir.exists():
            snapshots_dir = model_cache_dir / "snapshots"
            if snapshots_dir.exists():
                for snapshot_dir in snapshots_dir.iterdir():
                    if snapshot_dir.is_dir():
                        # Check for model files
                        if (snapshot_dir / "config.json").exists():
                            return snapshot_dir

        # Check direct path (ModelScope-style)
        direct_path = hf_cache_root / self.model_name
        if direct_path.exists() and (direct_path / "config.json").exists():
            return direct_path

        return None

    async def _download_mlx_model(
        self, hf_cache_root: Path, download_source: str = "auto"
    ) -> None:
        """Download MLX model using region-aware source (HuggingFace/ModelScope).

        Uses the same pattern as the main embedding service - auto-detects
        China region and uses ModelScope if available.

        Args:
            hf_cache_root: HuggingFace cache root directory
            download_source: "huggingface", "modelscope", or "auto" (detect based on region)
        """
        from ..utils.model_cache import HuggingFaceMirrorManager
        from ..utils.progress_tqdm import make_progress_tqdm
        from ..utils.progress_logger import log_stage
        from functools import partial

        # Detect region for download source if auto
        if download_source == "auto":
            region = HuggingFaceMirrorManager.detect_region()
            use_modelscope = region == "china"
        else:
            use_modelscope = download_source == "modelscope"

        source = "modelscope" if use_modelscope else "huggingface"

        logger.info(
            "Downloading MLX search embedding model",
            model=self.model_name,
            source=source,
        )

        # Log download start
        log_stage(
            operation="search_embedding_download",
            stage="initializing",
            message=f"Preparing to download {self.model_name}",
            details={"model_name": self.model_name, "source": source},
        )

        try:
            loop = asyncio.get_event_loop()

            # CRITICAL: Set HF_HUB_OFFLINE=0 BEFORE importing huggingface_hub
            # config.py sets HF_HUB_OFFLINE=1 globally, and huggingface_hub checks
            # this at import time. We must set it before importing snapshot_download.
            original_offline = os.environ.get("HF_HUB_OFFLINE")
            original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")
            os.environ["HF_HUB_OFFLINE"] = "0"
            os.environ["TRANSFORMERS_OFFLINE"] = "0"

            try:
                if use_modelscope:
                    # ModelScope has mlx-community models at same path
                    # https://modelscope.cn/models/mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ
                    try:
                        from modelscope.hub.snapshot_download import (
                            snapshot_download as ms_download,
                        )
                        from ..utils.progress_tqdm import (
                            make_modelscope_callback,
                            ModelScopeProgressCallback,
                        )

                        logger.info(
                            "Downloading MLX model from ModelScope",
                            model=self.model_name,
                        )

                        # Reset file counters for new download
                        ModelScopeProgressCallback.reset()
                        search_callback_class = make_modelscope_callback(
                            "search_embedding_download"
                        )

                        download_callable = partial(
                            ms_download,
                            self.model_name,  # Same path works on ModelScope
                            cache_dir=str(hf_cache_root),
                            progress_callbacks=[search_callback_class], # type: ignore
                        )
                        await loop.run_in_executor(None, download_callable)

                    except Exception as ms_error:
                        logger.warning(
                            "ModelScope download failed, using HuggingFace mirror",
                            error=str(ms_error),
                        )
                        # Fallback to HuggingFace mirror for China
                        original_endpoint = os.environ.get("HF_ENDPOINT")
                        os.environ["HF_ENDPOINT"] = HuggingFaceMirrorManager.MIRRORS["china"]

                        try:
                            from huggingface_hub import snapshot_download
                            import huggingface_hub.constants
                            huggingface_hub.constants.HF_HUB_OFFLINE = False

                            search_tqdm_class = make_progress_tqdm("search_embedding_download")
                            download_kwargs = {
                                "repo_id": self.model_name,
                                "cache_dir": str(hf_cache_root),
                                "local_files_only": False,
                                "tqdm_class": search_tqdm_class,
                            }
                            # Windows requires admin privileges for symlinks
                            if platform.system() == "Windows":
                                download_kwargs["local_dir_use_symlinks"] = False
                            download_callable = partial(snapshot_download, **download_kwargs)
                            await loop.run_in_executor(None, download_callable)
                        finally:
                            if original_endpoint is not None:
                                os.environ["HF_ENDPOINT"] = original_endpoint
                            else:
                                os.environ.pop("HF_ENDPOINT", None)
                else:
                    # Use HuggingFace directly
                    from huggingface_hub import snapshot_download
                    import huggingface_hub.constants
                    huggingface_hub.constants.HF_HUB_OFFLINE = False

                    search_tqdm_class = make_progress_tqdm("search_embedding_download")
                    download_kwargs = {
                        "repo_id": self.model_name,
                        "cache_dir": str(hf_cache_root),
                        "local_files_only": False,
                        "tqdm_class": search_tqdm_class,
                    }
                    # Windows requires admin privileges for symlinks
                    if platform.system() == "Windows":
                        download_kwargs["local_dir_use_symlinks"] = False
                    download_callable = partial(snapshot_download, **download_kwargs)
                    await loop.run_in_executor(None, download_callable)

                logger.info("MLX model downloaded successfully", model=self.model_name)

                # Log download complete
                log_stage(
                    operation="search_embedding_download",
                    stage="completed",
                    message="Search embedding model download completed",
                    details={"model_name": self.model_name, "source": source},
                )

            finally:
                # Restore original offline settings
                if original_offline is not None:
                    os.environ["HF_HUB_OFFLINE"] = original_offline
                else:
                    os.environ.pop("HF_HUB_OFFLINE", None)
                if original_transformers_offline is not None:
                    os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
                else:
                    os.environ.pop("TRANSFORMERS_OFFLINE", None)

        except Exception as e:
            logger.error(
                "Failed to download MLX model", model=self.model_name, error=str(e)
            )
            # Log error stage
            log_stage(
                operation="search_embedding_download",
                stage="error",
                message=f"Search embedding download failed: {str(e)}",
                details={"model_name": self.model_name, "error": str(e)},
            )
            raise

    async def _initialize_fastembed(self) -> None:
        """Initialize FastEmbed model for non-Apple-Silicon."""
        # Check if model is cached BEFORE importing fastembed
        # fastembed imports huggingface_hub which caches HF_HUB_OFFLINE at import time
        from ..config import get_default_huggingface_cache, get_settings

        settings = get_settings()
        hf_cache_root = get_default_huggingface_cache()

        # Find or download model BEFORE importing fastembed
        # Check embedding_cache_dir first (where ModelCacheManager downloads to),
        # then fall back to default HF cache — same pattern as _initialize_mlx
        local_model_path = None
        if settings.embedding_cache_dir:
            embedding_cache = Path(settings.embedding_cache_dir)
            if embedding_cache != hf_cache_root:
                local_model_path = self._find_fastembed_model_cache(embedding_cache)
        if local_model_path is None:
            local_model_path = self._find_fastembed_model_cache(hf_cache_root)

        if local_model_path is None:
            if self.cache_only:
                raise RuntimeError(
                    f"Search model {self.model_name} not cached and cache_only mode enabled. "
                    "Please download the model first."
                )

            # Download using the BGE-M3 embedding service pattern
            # CRITICAL: This sets HF_HUB_OFFLINE=0 before importing huggingface_hub
            async with _GLOBAL_DOWNLOAD_LOCK:
                local_model_path = await self._download_fastembed_model(
                    hf_cache_root, self.download_source
                )

        # Now safe to import fastembed (model is already downloaded or cached)
        TextEmbedding = _import_fastembed()

        if local_model_path is None:
            raise RuntimeError(f"Failed to find FastEmbed model at {hf_cache_root}")

        # Always set offline mode when loading from cache to prevent network calls
        # This prevents fastembed/huggingface_hub from trying to validate/update the model
        original_hf_offline = os.environ.get("HF_HUB_OFFLINE")
        original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

        try:
            # BGE-M3 support in fastembed is inconsistent across versions
            # We need to register it if not already supported
            # See: https://github.com/qdrant/fastembed/issues/348
            from fastembed.common.model_description import DenseModelDescription, ModelSource # type: ignore
            from fastembed.text.onnx_embedding import supported_onnx_models # type: ignore

            # Check if model is already in supported models
            supported_model_names = [m.model for m in supported_onnx_models]
            if self.model_name not in supported_model_names:
                # Register BGE-M3 with local path
                bge_m3_desc = DenseModelDescription(
                    model=self.model_name,
                    dim=SEARCH_EMBEDDING_DIMENSION,
                    description="BGE-M3 multilingual embedding model",
                    license="mit",
                    size_in_GB=2.3,
                    sources=ModelSource(
                        hf=self.model_name,
                        url=None,
                        _deprecated_tar_struct=False,
                    ),
                    model_file="onnx/model.onnx",
                )
                supported_onnx_models.insert(0, bge_m3_desc)
                logger.info(
                    "Registered BGE-M3 in supported_onnx_models",
                    model=self.model_name,
                )
            else:
                logger.info(
                    "BGE-M3 already in supported_onnx_models",
                    model=self.model_name,
                )

            logger.info(
                "Initializing FastEmbed with specific_model_path",
                model=self.model_name,
                path=str(local_model_path),
            )

            loop = asyncio.get_event_loop()

            def _init():
                # Use specific_model_path to point directly to the snapshot directory
                # This bypasses FastEmbed's download/retrieval mechanism entirely
                # cache_dir should be parent of hub directory (e.g., ~/.cache/huggingface)
                return TextEmbedding(
                    model_name=self.model_name,
                    specific_model_path=str(local_model_path),  # Direct path to model directory
                    cache_dir=str(hf_cache_root.parent),  # Parent of hub dir for tokenizer lookup
                    local_files_only=True,  # Always use local files only
                )

            self._fastembed_model = await loop.run_in_executor(None, _init)
        finally:
            # Restore original env vars (or remove if they weren't set)
            if original_hf_offline is not None:
                os.environ["HF_HUB_OFFLINE"] = original_hf_offline
            else:
                os.environ.pop("HF_HUB_OFFLINE", None)

            if original_transformers_offline is not None:
                os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
            else:
                os.environ.pop("TRANSFORMERS_OFFLINE", None)

    def _find_fastembed_model_cache(self, hf_cache_root: Path) -> Optional[Path]:
        """Find cached FastEmbed model.

        Checks multiple cache locations (same pattern as fastembed_onnx_service.py):
        - HuggingFace: {cache_root}/models--BAAI--bge-m3/snapshots/{hash}/
        - ModelScope standard: ~/.cache/modelscope/hub/models/BAAI/bge-m3/
        - ModelScope in HF cache: {cache_root}/BAAI/bge-m3/

        Args:
            hf_cache_root: HuggingFace cache root directory

        Returns:
            Path to model directory or None if not found
        """
        hf_cache_name = f"models--{self.model_name.replace('/', '--')}"

        # Extract org and model name for ModelScope structure
        org_name, model_name_part = self.model_name.split("/", 1) if "/" in self.model_name else ("", self.model_name)

        # Candidate cache locations to check (same as fastembed_onnx_service.py)
        candidate_cache_dirs = []

        # 1. HuggingFace standard cache
        hf_cache_dir = hf_cache_root / hf_cache_name
        candidate_cache_dirs.append(("HuggingFace cache", hf_cache_dir, "hf"))

        # 2. ModelScope standard cache (~/.cache/modelscope/hub/models/org/model-name)
        modelscope_cache_root = Path.home() / ".cache" / "modelscope" / "hub" / "models"
        if org_name and model_name_part:
            modelscope_model_dir = modelscope_cache_root / org_name / model_name_part
            candidate_cache_dirs.append(("ModelScope cache", modelscope_model_dir, "modelscope"))

        # 3. ModelScope format in HF cache root ({hf_cache_root}/org/model-name)
        if org_name and model_name_part:
            modelscope_in_hf = hf_cache_root / org_name / model_name_part
            candidate_cache_dirs.append(("ModelScope in HF cache", modelscope_in_hf, "modelscope"))

        searched_locations = []

        for location_name, model_cache_dir, cache_type in candidate_cache_dirs:
            searched_locations.append(str(model_cache_dir))
            if model_cache_dir.exists():
                if cache_type == "hf":
                    # HuggingFace structure: models--org--model/snapshots/<hash>/
                    snapshots_dir = model_cache_dir / "snapshots"
                    if snapshots_dir.exists():
                        for snapshot_dir in snapshots_dir.iterdir():
                            if snapshot_dir.is_dir() and (snapshot_dir / "onnx" / "model.onnx").exists():
                                logger.info(
                                    "Found local ONNX model (HuggingFace structure)",
                                    location=location_name,
                                    path=str(snapshot_dir),
                                )
                                return snapshot_dir
                else:  # modelscope
                    # ModelScope structure: org/model-name/ (direct, no snapshots/)
                    if (model_cache_dir / "onnx" / "model.onnx").exists():
                        logger.info(
                            "Found local ONNX model (ModelScope structure)",
                            location=location_name,
                            path=str(model_cache_dir),
                        )
                        return model_cache_dir
                    else:
                        # ModelScope might also have subdirectories - check recursively
                        for subdir in model_cache_dir.iterdir():
                            if subdir.is_dir() and (subdir / "onnx" / "model.onnx").exists():
                                logger.info(
                                    "Found local ONNX model (ModelScope structure, subdir)",
                                    location=location_name,
                                    path=str(subdir),
                                )
                                return subdir

        logger.debug(
            "ONNX model not found in any cache location",
            searched_locations=searched_locations,
        )
        return None

    async def _download_fastembed_model(
        self, hf_cache_root: Path, download_source: str = "auto"
    ) -> Optional[Path]:
        """Download FastEmbed/ONNX model.

        Args:
            hf_cache_root: HuggingFace cache root
            download_source: "huggingface", "modelscope", or "auto" (detect based on region)

        Returns:
            Path to downloaded model or None
        """
        from ..utils.model_cache import HuggingFaceMirrorManager
        from ..utils.progress_tqdm import make_progress_tqdm
        from ..utils.progress_logger import log_stage
        from functools import partial

        # Detect region for download source if auto
        if download_source == "auto":
            region = HuggingFaceMirrorManager.detect_region()
            use_modelscope = region == "china"
        else:
            use_modelscope = download_source == "modelscope"

        source = "modelscope" if use_modelscope else "huggingface"

        logger.info(
            "Downloading FastEmbed search model",
            model=self.model_name,
            source=source,
        )

        # Log download start
        log_stage(
            operation="search_embedding_download",
            stage="initializing",
            message=f"Preparing to download {self.model_name}",
            details={"model_name": self.model_name, "source": source},
        )

        try:
            loop = asyncio.get_event_loop()

            # Patterns for ONNX files (model.onnx + model.onnx_data for external weights)
            allow_patterns = [
                "onnx/model.onnx",
                "onnx/config.json",
                "tokenizer.json",
                "tokenizer_config.json",
                "special_tokens_map.json",
                "sentencepiece.bpe.model",
                "onnx/model.onnx_data",  # External weight storage (~2.27GB)
                "config.json",
            ]

            # CRITICAL: Set HF_HUB_OFFLINE=0 BEFORE importing huggingface_hub
            # config.py sets HF_HUB_OFFLINE=1 globally, and huggingface_hub checks
            # this at import time. We must set it before importing snapshot_download.
            original_offline = os.environ.get("HF_HUB_OFFLINE")
            original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")
            os.environ["HF_HUB_OFFLINE"] = "0"
            os.environ["TRANSFORMERS_OFFLINE"] = "0"

            try:
                if use_modelscope:
                    # Try ModelScope first for China region - download ONLY ONNX files
                    try:
                        from modelscope.hub.file_download import model_file_download

                        # ModelScope model path for BGE-M3
                        modelscope_model_name = "BAAI/bge-m3"

                        # Files to download (ONNX + tokenizer, NO transformer files)
                        # model.onnx_data contains the actual weights (~2.27GB)
                        files_to_download = [
                            "onnx/model.onnx",  # ONNX model structure (725KB)
                            "onnx/config.json",
                            "tokenizer.json",
                            "tokenizer_config.json",
                            "special_tokens_map.json",
                            "sentencepiece.bpe.model",  # BGE-M3 uses sentencepiece
                            "onnx/model.onnx_data",  # ONNX weights (2.27GB)
                            "config.json",
                        ]

                        logger.info(
                            "Downloading BGE-M3 ONNX files from ModelScope (not full model)",
                            modelscope_model=modelscope_model_name,
                            files=files_to_download,
                        )

                        downloaded_files = []
                        for file_path in files_to_download:
                            try:
                                logger.info(f"📥 Downloading {file_path} from ModelScope")
                                download_callable = partial(
                                    model_file_download,
                                    model_id=modelscope_model_name,
                                    file_path=file_path,
                                    cache_dir=str(hf_cache_root),
                                )
                                local_path = await loop.run_in_executor(None, download_callable)
                                downloaded_files.append(local_path)
                                logger.info(f"✅ Downloaded {file_path}", path=local_path)
                            except Exception as e:
                                logger.warning(f"Could not download {file_path}", error=str(e))

                        # Verify ONNX file exists
                        org_name, model_name_part = modelscope_model_name.split("/", 1)
                        expected_onnx_path = hf_cache_root / org_name / model_name_part / "onnx" / "model.onnx"
                        if not expected_onnx_path.exists():
                            raise RuntimeError(f"ONNX file not found at {expected_onnx_path}")

                        model_dir = str(hf_cache_root / org_name / model_name_part)
                        logger.info(
                            "✅ BGE-M3 ONNX files downloaded from ModelScope (avoided ~2GB transformer files)",
                            model_dir=model_dir,
                        )

                    except Exception as ms_error:
                        logger.warning(
                            "ModelScope download failed, using HuggingFace mirror",
                            error=str(ms_error),
                        )
                        # Set HuggingFace mirror for China
                        original_endpoint = os.environ.get("HF_ENDPOINT")
                        os.environ["HF_ENDPOINT"] = HuggingFaceMirrorManager.MIRRORS[
                            "china"
                        ]

                        try:
                            from huggingface_hub import snapshot_download
                            import huggingface_hub.constants
                            huggingface_hub.constants.HF_HUB_OFFLINE = False

                            search_tqdm_class = make_progress_tqdm(
                                "search_embedding_download"
                            )
                            download_kwargs = {
                                "repo_id": self.model_name,
                                "allow_patterns": allow_patterns,
                                "cache_dir": str(hf_cache_root),
                                "local_files_only": False,
                                "tqdm_class": search_tqdm_class,
                            }
                            # Windows requires admin privileges for symlinks
                            if platform.system() == "Windows":
                                download_kwargs["local_dir_use_symlinks"] = False
                            download_callable = partial(snapshot_download, **download_kwargs)
                            model_dir = await loop.run_in_executor(
                                None, download_callable
                            )
                        finally:
                            if original_endpoint is not None:
                                os.environ["HF_ENDPOINT"] = original_endpoint
                            else:
                                os.environ.pop("HF_ENDPOINT", None)
                else:
                    # Use HuggingFace directly with progress tracking
                    from huggingface_hub import snapshot_download
                    import huggingface_hub.constants
                    huggingface_hub.constants.HF_HUB_OFFLINE = False

                    search_tqdm_class = make_progress_tqdm("search_embedding_download")
                    download_kwargs = {
                        "repo_id": self.model_name,
                        "allow_patterns": allow_patterns,
                        "cache_dir": str(hf_cache_root),
                        "local_files_only": False,
                        "tqdm_class": search_tqdm_class,
                    }
                    # Windows requires admin privileges for symlinks
                    if platform.system() == "Windows":
                        download_kwargs["local_dir_use_symlinks"] = False
                    download_callable = partial(snapshot_download, **download_kwargs)
                    model_dir = await loop.run_in_executor(None, download_callable)

                logger.info("FastEmbed model downloaded", model=self.model_name)

                # Log download complete
                log_stage(
                    operation="search_embedding_download",
                    stage="completed",
                    message="Search embedding model download completed",
                    details={"model_name": self.model_name, "source": source},
                )

                return Path(model_dir)

            finally:
                # Restore original offline settings
                if original_offline is not None:
                    os.environ["HF_HUB_OFFLINE"] = original_offline
                else:
                    os.environ.pop("HF_HUB_OFFLINE", None)
                if original_transformers_offline is not None:
                    os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
                else:
                    os.environ.pop("TRANSFORMERS_OFFLINE", None)

        except Exception as e:
            logger.error("Failed to download FastEmbed model", error=str(e))
            # Log error stage
            log_stage(
                operation="search_embedding_download",
                stage="error",
                message=f"Search embedding download failed: {str(e)}",
                details={"model_name": self.model_name, "error": str(e)},
            )
            return None

    async def embed_text(self, text: str, is_query: bool = True) -> List[float]:
        """Generate embedding for a single text.

        Args:
            text: Input text
            is_query: True for search queries, False for documents/passages to be indexed.
                      Qwen3-Embedding requires instruction prefix for queries but not documents.
                      BGE-M3 does not require any prefix.

        Returns:
            1024-dimensional embedding vector
        """
        if not self._initialized:
            raise RuntimeError("Search embedding service not initialized")

        self._last_used_at = time.monotonic()

        if not text or not text.strip():
            return [0.0] * self.dimension

        text = text.strip()

        # Apply Qwen3 instruction prefix for queries on macOS (MLX)
        # See: https://huggingface.co/Qwen/Qwen3-Embedding-0.6B
        # Format: "Instruct: {instruction}\nQuery:{query}"
        # Documents do NOT get the instruction prefix
        #
        # For short queries, we use an enhanced instruction that guides the model
        # to look for comprehensive content. This is done via instruction only,
        # NOT by modifying the query text (which could hurt precision).
        if IS_APPLE_SILICON and is_query:
            is_short = _is_short_query(text)
            instruction = QWEN3_SHORT_QUERY_INSTRUCTION if is_short else QWEN3_QUERY_INSTRUCTION
            text = f"Instruct: {instruction}\nQuery:{text}"
            logger.debug(
                "Applied Qwen3 instruction prefix",
                is_short=is_short,
            )

        try:
            if IS_APPLE_SILICON:
                embedding = await self._embed_mlx(text)
                logger.debug(
                    "Generated MLX embedding",
                    is_query=is_query,
                    text_len=len(text),
                    embedding_dim=len(embedding),
                    embedding_norm=sum(x*x for x in embedding[:10])**0.5,  # Partial norm for sanity check
                )
                return embedding
            else:
                embedding = await self._embed_fastembed(text)
                logger.debug(
                    "Generated FastEmbed embedding",
                    is_query=is_query,
                    text_len=len(text),
                    embedding_dim=len(embedding),
                )
                return embedding
        except Exception as e:
            logger.error("Failed to generate search embedding", error=str(e))
            raise

    async def _embed_mlx(self, text: str) -> List[float]:
        """Generate embedding using MLX (macOS).

        Uses the mlx-embeddings pattern:
        1. tokenizer.encode(text, return_tensors="mlx")
        2. model(input_ids)
        3. outputs.text_embeds (mean pooled and normalized)
        """
        if self._mlx_model is None or self._mlx_tokenizer is None:
            raise RuntimeError("MLX model not loaded")

        loop = asyncio.get_event_loop()

        def _generate():
            try:
                # Step 1: Tokenize using mlx-embeddings pattern
                input_ids = self._mlx_tokenizer.encode(text, return_tensors="mlx") # type: ignore

                # Step 2: Get model outputs
                outputs = self._mlx_model(input_ids) # type: ignore

                # Step 3: Extract embeddings
                if hasattr(outputs, "text_embeds"):
                    # text_embeds is already mean pooled and normalized
                    embedding = outputs.text_embeds
                elif hasattr(outputs, "last_hidden_state"):
                    # Fallback: use CLS token from last_hidden_state
                    embedding = outputs.last_hidden_state[:, 0, :]
                else:
                    raise RuntimeError(
                        "Model outputs don't have text_embeds or last_hidden_state"
                    )

                # Convert to list of floats
                if hasattr(embedding, "tolist"):
                    embedding_list = embedding.tolist()
                    # Handle 2D array (batch, features) - squeeze to 1D
                    if isinstance(embedding_list, list) and len(embedding_list) > 0:
                        if isinstance(embedding_list[0], list):
                            return embedding_list[0]
                        return embedding_list
                    return embedding_list
                elif hasattr(embedding, "__iter__"):
                    return [float(x) for x in embedding]
                else:
                    return [float(embedding)]

            except Exception as e:
                logger.error(
                    "MLX embedding generation failed",
                    error=str(e),
                    text_preview=text[:50] if text else "",
                )
                raise RuntimeError(f"MLX embedding failed: {e}")

        # Use shared MLX inference lock to prevent Metal conflicts with LLM
        mlx_lock = get_mlx_inference_lock()
        if mlx_lock is not None:
            async with mlx_lock:
                embedding = await loop.run_in_executor(None, _generate)
        else:
            embedding = await loop.run_in_executor(None, _generate)

        return [float(x) for x in embedding]

    async def _embed_fastembed(self, text: str) -> List[float]:
        """Generate embedding using FastEmbed (non-Apple-Silicon)."""
        if self._fastembed_model is None:
            raise RuntimeError("FastEmbed model not loaded")

        loop = asyncio.get_event_loop()

        def _generate():
            embeddings = list(self._fastembed_model.embed([text])) # type: ignore
            if embeddings:
                return embeddings[0].tolist()
            return [0.0] * self.dimension

        embedding = await loop.run_in_executor(None, _generate)
        return [float(x) for x in embedding]

    async def embed_batch(self, texts: List[str], is_query: bool = False) -> List[List[float]]:
        """Generate embeddings for a batch of texts.

        Args:
            texts: List of input texts
            is_query: True for search queries, False for documents/passages to be indexed.
                      Defaults to False since batch embedding is typically used for indexing documents.
                      Qwen3-Embedding requires instruction prefix for queries but not documents.
                      BGE-M3 does not require any prefix.

        Returns:
            List of 1024-dimensional embedding vectors
        """
        if not self._initialized:
            raise RuntimeError("Search embedding service not initialized")

        self._last_used_at = time.monotonic()

        if not texts:
            return []

        # Filter empty texts
        valid_texts = [(i, t.strip()) for i, t in enumerate(texts) if t and t.strip()]

        if not valid_texts:
            return [[0.0] * self.dimension for _ in texts]

        # Apply Qwen3 instruction prefix for queries on macOS (MLX)
        # See: https://huggingface.co/Qwen/Qwen3-Embedding-0.6B
        # Documents do NOT get the instruction prefix
        if IS_APPLE_SILICON and is_query:
            valid_texts = [
                (i, f"Instruct: {QWEN3_QUERY_INSTRUCTION}\nQuery:{t}")
                for i, t in valid_texts
            ]
            logger.debug("Applied Qwen3 instruction prefix for batch queries", count=len(valid_texts))

        try:
            backend = "MLX" if IS_APPLE_SILICON else "FastEmbed"
            logger.info(
                f"Generating batch embeddings ({backend})",
                count=len(valid_texts),
                is_query=is_query,
            )

            if IS_APPLE_SILICON:
                embeddings = await self._embed_batch_mlx([t for _, t in valid_texts])
            else:
                embeddings = await self._embed_batch_fastembed([t for _, t in valid_texts])

            logger.info(
                f"Generated batch embeddings ({backend})",
                count=len(embeddings),
                dim=len(embeddings[0]) if embeddings else 0,
            )

            # Map back to original positions
            result: List[List[float]] = [[0.0] * self.dimension for _ in texts]
            for idx, (orig_idx, _) in enumerate(valid_texts):
                result[orig_idx] = embeddings[idx]

            # Batch indexing can leave runtime allocations resident (MLX/Metal or host RAM).
            # Release caches after non-query batches to reduce steady-state memory after indexing.
            if not is_query and len(valid_texts) >= 16:
                await self.release_runtime_cache(reason="embed_batch_complete")

            return result

        except Exception as e:
            logger.error("Failed to generate batch embeddings", error=str(e))
            raise

    async def _embed_batch_mlx(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings using MLX."""
        # Process sequentially and periodically trim cache to avoid large transient
        # Metal residency during long indexing batches.
        results = []
        for idx, text in enumerate(texts, start=1):
            embedding = await self._embed_mlx(text)
            results.append(embedding)
            if idx % 64 == 0:
                await self.release_runtime_cache(reason="embed_batch_periodic")
        return results

    async def _embed_batch_fastembed(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings using FastEmbed."""
        if self._fastembed_model is None:
            raise RuntimeError("FastEmbed model not loaded")

        loop = asyncio.get_event_loop()

        def _generate_chunk(chunk: List[str]) -> List[List[float]]:
            embeddings = list(self._fastembed_model.embed(chunk)) # type: ignore
            return [emb.tolist() for emb in embeddings]

        results: List[List[float]] = []
        for idx in range(0, len(texts), FASTEMBED_BATCH_CHUNK_SIZE):
            chunk = texts[idx : idx + FASTEMBED_BATCH_CHUNK_SIZE]
            chunk_embeddings = await loop.run_in_executor(
                None,
                lambda c=chunk: _generate_chunk(c),
            )
            results.extend([[float(x) for x in emb] for emb in chunk_embeddings])

            if idx > 0:
                await self.release_runtime_cache(reason="embed_batch_fastembed_chunk")

        return results

    # ------------------------------------------------------------------
    # Idle memory management
    # ------------------------------------------------------------------

    def is_idle(self, threshold_seconds: int = 300) -> bool:
        """Return True if the model has not been used for *threshold_seconds*."""
        if not self._initialized:
            return False
        return (time.monotonic() - self._last_used_at) > threshold_seconds

    async def unload(self) -> None:
        """Release model weights to reclaim memory.

        The service can be seamlessly reloaded via ``initialize()`` on next use
        because the service factory re-initializes when ``_initialized`` is False.
        """
        if not self._initialized:
            return

        logger.info(
            "Unloading search embedding model to reclaim memory",
            model=self.model_name,
            backend=self._backend,
            idle_seconds=int(time.monotonic() - self._last_used_at) if self._last_used_at else 0,
        )

        if self._mlx_model is not None:
            del self._mlx_model
            self._mlx_model = None
        if self._mlx_tokenizer is not None:
            del self._mlx_tokenizer
            self._mlx_tokenizer = None
        if self._fastembed_model is not None:
            del self._fastembed_model
            self._fastembed_model = None

        self._initialized = False
        await self.release_runtime_cache(reason="idle_unload")
        gc.collect()

    async def cleanup(self) -> None:
        """Cleanup resources."""
        if self._mlx_model is not None:
            del self._mlx_model
            self._mlx_model = None
        if self._mlx_tokenizer is not None:
            del self._mlx_tokenizer
            self._mlx_tokenizer = None
        if self._fastembed_model is not None:
            del self._fastembed_model
            self._fastembed_model = None

        await self.release_runtime_cache(reason="service_cleanup")

        self._initialized = False
        logger.info("Search embedding service cleaned up")


def check_search_model_exists() -> bool:
    """Check if the search embedding model is cached.

    Returns:
        True if model is cached
    """
    from ..config import get_settings, get_default_huggingface_cache

    settings = get_settings()

    if IS_APPLE_SILICON:
        # Check for MLX model
        model_name = MLX_MODEL
        hf_cache_root = Path.home() / ".cache" / "huggingface" / "hub"
        if settings.embedding_cache_dir:
            hf_cache_root = Path(settings.embedding_cache_dir)

        hf_cache_name = f"models--{model_name.replace('/', '--')}"
        model_cache_dir = hf_cache_root / hf_cache_name

        if model_cache_dir.exists():
            snapshots_dir = model_cache_dir / "snapshots"
            if snapshots_dir.exists():
                for snapshot_dir in snapshots_dir.iterdir():
                    if snapshot_dir.is_dir() and (snapshot_dir / "config.json").exists():
                        return True

        # Check direct path
        direct_path = hf_cache_root / model_name
        if direct_path.exists() and (direct_path / "config.json").exists():
            return True

        return False

    else:
        # Check for FastEmbed/ONNX model (BAAI/bge-m3)
        # Check multiple cache locations (same pattern as _find_fastembed_model_cache)
        model_name = ONNX_MODEL
        hf_cache_root = get_default_huggingface_cache()

        hf_cache_name = f"models--{model_name.replace('/', '--')}"

        # Extract org and model name for ModelScope structure
        org_name, model_name_part = model_name.split("/", 1) if "/" in model_name else ("", model_name)

        # Candidate cache locations to check
        candidate_cache_dirs = []

        # 1. HuggingFace standard cache
        hf_cache_dir = hf_cache_root / hf_cache_name
        candidate_cache_dirs.append(("HuggingFace cache", hf_cache_dir, "hf"))

        # 2. ModelScope standard cache (~/.cache/modelscope/hub/models/org/model-name)
        modelscope_cache_root = Path.home() / ".cache" / "modelscope" / "hub" / "models"
        if org_name and model_name_part:
            modelscope_model_dir = modelscope_cache_root / org_name / model_name_part
            candidate_cache_dirs.append(("ModelScope cache", modelscope_model_dir, "modelscope"))

        # 3. ModelScope format in HF cache root ({hf_cache_root}/org/model-name)
        if org_name and model_name_part:
            modelscope_in_hf = hf_cache_root / org_name / model_name_part
            candidate_cache_dirs.append(("ModelScope in HF cache", modelscope_in_hf, "modelscope"))

        # 4. App embedding cache (where ModelCacheManager downloads to, may differ from HF cache)
        if settings.embedding_cache_dir:
            embedding_cache = Path(settings.embedding_cache_dir)
            if embedding_cache != hf_cache_root:
                hf_in_embed = embedding_cache / hf_cache_name
                candidate_cache_dirs.append(("Embedding cache (HF)", hf_in_embed, "hf"))
                if org_name and model_name_part:
                    ms_in_embed = embedding_cache / org_name / model_name_part
                    candidate_cache_dirs.append(("Embedding cache (ModelScope)", ms_in_embed, "modelscope"))

        for location_name, model_cache_dir, cache_type in candidate_cache_dirs:
            if model_cache_dir.exists():
                if cache_type == "hf":
                    # HuggingFace structure: models--org--model/snapshots/<hash>/
                    snapshots_dir = model_cache_dir / "snapshots"
                    if snapshots_dir.exists():
                        for snapshot_dir in snapshots_dir.iterdir():
                            if snapshot_dir.is_dir() and (snapshot_dir / "onnx" / "model.onnx").exists():
                                return True
                else:  # modelscope
                    # ModelScope structure: org/model-name/ (direct, no snapshots/)
                    if (model_cache_dir / "onnx" / "model.onnx").exists():
                        return True

        return False


def get_search_model_info() -> dict:
    """Get information about the search embedding model for the current platform.

    Returns:
        Dict with model_name, backend, dimension, and estimated_size_mb
    """
    if IS_APPLE_SILICON:
        return {
            "model_name": MLX_MODEL,
            "backend": "mlx",
            "dimension": SEARCH_EMBEDDING_DIMENSION,
            "estimated_size_mb": 400,  # 4-bit quantized
            "platform": "macOS Apple Silicon",
        }
    else:
        return {
            "model_name": ONNX_MODEL,
            "backend": "fastembed",
            "dimension": SEARCH_EMBEDDING_DIMENSION,
            "estimated_size_mb": 2300,  # BAAI/bge-m3 ONNX (model.onnx_data ~2.27GB)
            "platform": "Windows/Linux/macOS Intel",
        }
