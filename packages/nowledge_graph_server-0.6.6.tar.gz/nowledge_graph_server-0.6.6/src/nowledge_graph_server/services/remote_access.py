"""Secure remote API exposure via Cloudflare Tunnel.

This service provides:
- Strong API-key authentication for remote access
- Cloudflare tunnel lifecycle management (quick + account modes)
- Request auth throttling to reduce brute-force risk
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, UTC
from pathlib import Path
from typing import Any, Deque, Optional
from urllib.parse import urlparse

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import psutil
import structlog
from fastapi import HTTPException, Request

from nowledge_graph_server.utils.app_paths import resolve_config_file_path
from nowledge_graph_server.services.remote_access_process import (
    cleanup_orphaned_managed_cloudflared_processes,
    iter_managed_cloudflared_processes,
)
from nowledge_graph_server.services.remote_access_utils import (
    IP_ALLOWLIST_ENV,  # noqa: F401 - re-exported compatibility symbol
    REMOTE_ALLOWED_PREFIXES,  # noqa: F401 - re-exported compatibility symbol
    is_ip_allowlist_match,  # noqa: F401 - re-exported compatibility symbol
    is_local_request,  # noqa: F401 - re-exported compatibility symbol
    is_remote_target_path_allowed,  # noqa: F401 - re-exported compatibility symbol
    load_ip_allowlist_from_env,
    parse_ip_allowlist,  # noqa: F401 - re-exported compatibility symbol
)
from nowledge_graph_server.services.secure_keys import get_encryption_key_bytes

logger = structlog.get_logger(__name__)

REMOTE_GATEWAY_PREFIX = "/remote-api"
LOCAL_GATEWAY_URL = f"http://127.0.0.1:14242{REMOTE_GATEWAY_PREFIX}"
CLOUDFLARED_URL_PATTERN = re.compile(
    r"https://[a-z0-9-]+\.trycloudflare\.com",
    re.IGNORECASE,
)
CLOUDFLARED_ENV_PATH = "NOWLEDGE_CLOUDFLARED_PATH"
_TUNNEL_START_TIMEOUT_ENV = "NOWLEDGE_CLOUDFLARE_START_TIMEOUT_SECONDS"
CLOUDFLARED_MANAGED_ENV = "NOWLEDGE_CLOUDFLARED_MANAGED"
CLOUDFLARED_OWNER_ENV = "NOWLEDGE_CLOUDFLARED_OWNER"


def _resolve_tunnel_start_timeout_seconds() -> int:
    raw_value = os.getenv(_TUNNEL_START_TIMEOUT_ENV, "150").strip()
    try:
        timeout = int(raw_value)
    except ValueError:
        timeout = 150
    return max(30, min(timeout, 600))


TUNNEL_START_TIMEOUT_SECONDS = _resolve_tunnel_start_timeout_seconds()
CLOUDFLARED_ACCOUNT_READY_PATTERN = re.compile(
    r"Registered tunnel connection",
    re.IGNORECASE,
)

TUNNEL_MODE_QUICK = "quick"
TUNNEL_MODE_ACCOUNT = "account"
TUNNEL_MODE_VALUES = {TUNNEL_MODE_QUICK, TUNNEL_MODE_ACCOUNT}

AUTH_WINDOW_SECONDS = 5 * 60
AUTH_MAX_FAILURES = 8
AUTH_BLOCK_SECONDS = 10 * 60

HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}

QUICK_TUNNEL_LIMITATIONS = [
    "Quick Tunnel has no uptime SLA and is not recommended for production-critical traffic.",
    "Quick Tunnel does not support SSE.",
]

ACCOUNT_TUNNEL_LIMITATIONS = [
    "Account tunnel requires Cloudflare dashboard setup before first start.",
]

@dataclass
class AuthResult:
    ok: bool
    status_code: int = 200
    detail: str = "ok"
    retry_after_seconds: Optional[int] = None
    client_ip: str = "unknown"


class RemoteAccessManager:
    """Manages secure remote access + Cloudflare tunnel process."""

    def __init__(self) -> None:
        # Canonical: app config root; legacy fallback/migration handled by resolver.
        self._state_path = resolve_config_file_path("remote-access.json")

        self._api_key_hash: Optional[str] = None
        self._api_key_salt: Optional[str] = None
        self._api_key_enc: Optional[str] = None
        self._api_key_nonce: Optional[str] = None
        self._key_id: Optional[str] = None
        self._key_created_at: Optional[str] = None
        self._key_rotated_at: Optional[str] = None
        self._configured_mode = TUNNEL_MODE_QUICK
        self._active_mode = TUNNEL_MODE_QUICK
        self._account_tunnel_url: Optional[str] = None
        self._account_tunnel_token_enc: Optional[str] = None
        self._account_tunnel_token_nonce: Optional[str] = None
        self._auto_start_enabled = False
        self._cloudflared_owner = secrets.token_hex(16)

        self._process: Optional[asyncio.subprocess.Process] = None
        self._managed_cloudflared_pid: Optional[int] = None
        self._log_task: Optional[asyncio.Task[None]] = None
        self._startup_restore_task: Optional[asyncio.Task[None]] = None
        self._public_url: Optional[str] = None
        self._url_ready: asyncio.Event = asyncio.Event()
        self._tunnel_connected = False
        self._log_tail: Deque[str] = deque(maxlen=200)

        self._lock = asyncio.Lock()
        self._auth_failures: dict[str, dict[str, float]] = {}
        self._invalid_cloudflared_env_logged = False

        self._load_state()
        self._cleanup_orphaned_managed_cloudflared_processes()

    def _iter_managed_cloudflared_processes(self) -> list[psutil.Process]:
        return iter_managed_cloudflared_processes(
            owner=self._cloudflared_owner,
            managed_env_key=CLOUDFLARED_MANAGED_ENV,
            owner_env_key=CLOUDFLARED_OWNER_ENV,
            logger=logger,
        )

    def _cleanup_orphaned_managed_cloudflared_processes(self) -> None:
        current_pid = self._process.pid if self._process is not None else None
        cleaned = cleanup_orphaned_managed_cloudflared_processes(
            owner=self._cloudflared_owner,
            managed_env_key=CLOUDFLARED_MANAGED_ENV,
            owner_env_key=CLOUDFLARED_OWNER_ENV,
            logger=logger,
            current_pid=current_pid,
        )
        if cleaned > 0:
            logger.info(
                "Cleaned orphaned managed cloudflared processes",
                cleaned_count=cleaned,
            )

    @staticmethod
    def _is_executable_binary(path: Path) -> bool:
        if not path.exists() or path.is_dir():
            return False
        return os.access(path, os.X_OK) or path.suffix.lower() == ".exe"

    def _bundled_cloudflared_candidates(self) -> list[Path]:
        """Return likely bundled cloudflared locations across dev/prod layouts."""
        candidates: list[Path] = []
        module_path = Path(__file__).resolve()
        for parent in module_path.parents:
            candidates.extend(
                [
                    parent / "cloudflared",
                    parent / "cloudflared.exe",
                    parent / "bin" / "cloudflared",
                    parent / "bin" / "cloudflared.exe",
                ]
            )
        return candidates

    def resolve_cloudflared(self) -> tuple[Optional[str], str]:
        """Resolve cloudflared binary path and source.

        Source values:
        - env: explicit NOWLEDGE_CLOUDFLARED_PATH
        - bundled: binary shipped with desktop bundle
        - system: binary discovered on PATH
        - none: not found
        """
        env_path = os.environ.get(CLOUDFLARED_ENV_PATH, "").strip()
        if env_path:
            candidate = Path(env_path).expanduser()
            if self._is_executable_binary(candidate):
                return str(candidate), "env"
            if not self._invalid_cloudflared_env_logged:
                logger.warning(
                    "Configured cloudflared path is not executable",
                    path=str(candidate),
                    env_var=CLOUDFLARED_ENV_PATH,
                )
                self._invalid_cloudflared_env_logged = True

        seen: set[str] = set()
        for candidate in self._bundled_cloudflared_candidates():
            normalized = str(candidate)
            if normalized in seen:
                continue
            seen.add(normalized)
            if self._is_executable_binary(candidate):
                return normalized, "bundled"

        system_path = shutil.which("cloudflared")
        if system_path:
            return system_path, "system"

        return None, "none"

    @property
    def cloudflared_available(self) -> bool:
        cloudflared_path, _ = self.resolve_cloudflared()
        return cloudflared_path is not None

    @property
    def api_key_configured(self) -> bool:
        return bool(self._api_key_hash and self._api_key_salt)

    @property
    def configured_mode(self) -> str:
        return self._configured_mode

    @property
    def active_mode(self) -> Optional[str]:
        if self._is_process_running():
            return self._active_mode
        return None

    @property
    def auto_start_enabled(self) -> bool:
        return self._auto_start_enabled

    @staticmethod
    def _normalize_tunnel_mode(mode: Optional[str]) -> str:
        normalized = (mode or "").strip().lower()
        if not normalized:
            return TUNNEL_MODE_QUICK
        if normalized not in TUNNEL_MODE_VALUES:
            raise ValueError(f"Unsupported tunnel mode: {mode}")
        return normalized

    @staticmethod
    def _normalize_account_tunnel_url(value: Optional[str]) -> Optional[str]:
        if value is None:
            return None

        normalized = value.strip()
        if not normalized:
            return None

        parsed = urlparse(normalized)
        if parsed.scheme.lower() != "https" or not parsed.netloc:
            raise ValueError(
                "Account tunnel URL must be an HTTPS URL, for example "
                "https://mem.example.com"
            )

        if parsed.path not in {"", "/"}:
            raise ValueError(
                "Account tunnel URL must be your domain root only "
                "(for example https://mem.example.com). "
                "Do not add /remote-api."
            )

        if parsed.query or parsed.fragment:
            raise ValueError(
                "Account tunnel URL cannot include query strings or fragments. "
                "Use only the domain root, for example https://mem.example.com."
            )

        return f"https://{parsed.netloc}".rstrip("/")

    @staticmethod
    def _encrypt_secret(value: str) -> tuple[str, str]:
        key = get_encryption_key_bytes()
        aesgcm = AESGCM(key)
        nonce = os.urandom(12)
        ciphertext = aesgcm.encrypt(nonce, value.encode("utf-8"), None)
        return (
            base64.b64encode(ciphertext).decode("utf-8"),
            base64.b64encode(nonce).decode("utf-8"),
        )

    @staticmethod
    def _decrypt_secret(
        ciphertext_b64: Optional[str], nonce_b64: Optional[str]
    ) -> Optional[str]:
        if not ciphertext_b64 or not nonce_b64:
            return None
        try:
            key = get_encryption_key_bytes()
            aesgcm = AESGCM(key)
            nonce = base64.b64decode(nonce_b64)
            ciphertext = base64.b64decode(ciphertext_b64)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
            return plaintext.decode("utf-8")
        except Exception as exc:
            logger.warning(
                "Failed to decrypt account tunnel token",
                error=str(exc),
            )
            return None

    def _get_account_tunnel_token(self) -> Optional[str]:
        return self._decrypt_secret(
            self._account_tunnel_token_enc,
            self._account_tunnel_token_nonce,
        )

    def _get_api_key_plaintext(self) -> Optional[str]:
        return self._decrypt_secret(
            self._api_key_enc,
            self._api_key_nonce,
        )

    def _load_state(self) -> None:
        if not self._state_path.exists():
            return
        try:
            data = json.loads(self._state_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return

            self._api_key_hash = data.get("api_key_hash")
            self._api_key_salt = data.get("api_key_salt")
            self._api_key_enc = data.get("api_key_enc")
            self._api_key_nonce = data.get("api_key_nonce")
            self._key_id = data.get("key_id")
            self._key_created_at = data.get("key_created_at")
            self._key_rotated_at = data.get("key_rotated_at")
            self._configured_mode = self._normalize_tunnel_mode(data.get("mode"))
            self._active_mode = self._configured_mode
            self._account_tunnel_url = self._normalize_account_tunnel_url(
                data.get("account_tunnel_url")
            )
            self._account_tunnel_token_enc = data.get("account_tunnel_token_enc")
            self._account_tunnel_token_nonce = data.get("account_tunnel_token_nonce")
            self._auto_start_enabled = bool(data.get("auto_start_enabled", False))
            owner = data.get("cloudflared_owner")
            if isinstance(owner, str) and owner.strip():
                self._cloudflared_owner = owner.strip()
            managed_pid = data.get("managed_cloudflared_pid")
            if isinstance(managed_pid, int) and managed_pid > 0:
                self._managed_cloudflared_pid = managed_pid
            else:
                self._managed_cloudflared_pid = None
        except Exception as exc:
            logger.warning("Failed to read remote-access state", error=str(exc))

    def _save_state(self) -> None:
        payload = {
            "api_key_hash": self._api_key_hash,
            "api_key_salt": self._api_key_salt,
            "api_key_enc": self._api_key_enc,
            "api_key_nonce": self._api_key_nonce,
            "key_id": self._key_id,
            "key_created_at": self._key_created_at,
            "key_rotated_at": self._key_rotated_at,
            "mode": self._configured_mode,
            "account_tunnel_url": self._account_tunnel_url,
            "account_tunnel_token_enc": self._account_tunnel_token_enc,
            "account_tunnel_token_nonce": self._account_tunnel_token_nonce,
            "auto_start_enabled": self._auto_start_enabled,
            "cloudflared_owner": self._cloudflared_owner,
            "managed_cloudflared_pid": self._managed_cloudflared_pid,
        }

        self._state_path.parent.mkdir(parents=True, exist_ok=True)

        # Keep file private to current user where supported.
        fd = os.open(self._state_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)

    @staticmethod
    def _compute_key_hash(api_key: str, salt_hex: str) -> str:
        salt = bytes.fromhex(salt_hex)
        return hmac.new(salt, api_key.encode("utf-8"), hashlib.sha256).hexdigest()

    @staticmethod
    def _generate_api_key() -> str:
        return f"nmem_{secrets.token_urlsafe(48)}"

    def _set_new_api_key(self) -> str:
        api_key = self._generate_api_key()
        salt_hex = secrets.token_hex(32)
        self._api_key_salt = salt_hex
        self._api_key_hash = self._compute_key_hash(api_key, salt_hex)
        api_key_enc, api_key_nonce = self._encrypt_secret(api_key)
        self._api_key_enc = api_key_enc
        self._api_key_nonce = api_key_nonce

        now_iso = datetime.now(UTC).isoformat()
        if not self._key_created_at:
            self._key_created_at = now_iso
        self._key_rotated_at = now_iso
        self._key_id = secrets.token_hex(6)

        self._save_state()
        return api_key

    async def ensure_api_key(self) -> Optional[str]:
        """Ensure an API key exists. Returns plaintext key only if newly generated."""
        async with self._lock:
            if self.api_key_configured:
                return None
            return self._set_new_api_key()

    async def rotate_api_key(self) -> str:
        """Rotate API key and return new plaintext key."""
        async with self._lock:
            return self._set_new_api_key()

    async def reveal_api_key(self) -> str:
        """Return current plaintext API key for local management actions only."""
        async with self._lock:
            if not self.api_key_configured:
                raise RuntimeError(
                    "Remote API key is not configured yet. Start tunnel or click Rotate first."
                )
            plaintext = self._get_api_key_plaintext()
            if plaintext:
                return plaintext
            raise RuntimeError(
                "This API key was created before secure key recovery was available. "
                "Click Rotate once to issue a recoverable key."
            )

    def _extract_api_key(
        self, request: Request, *, allow_proxy_fallback: bool = False
    ) -> Optional[str]:
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            token = auth_header[7:].strip()
            if token:
                return token

        fallback = request.headers.get("x-nmem-api-key", "").strip()
        if fallback:
            return fallback

        if not allow_proxy_fallback:
            return None

        # Proxy compatibility fallback:
        # Some restrictive proxies strip Authorization/custom headers.
        cookie_token = request.cookies.get("nmem_api_key", "").strip()
        if cookie_token:
            return cookie_token

        query_token = request.query_params.get("nmem_api_key", "").strip()
        return query_token or None

    @staticmethod
    def is_tunnel_request(request: Request) -> bool:
        # Cloudflare edge sets this header for origin requests.
        if request.headers.get("cf-connecting-ip"):
            return True
        if request.headers.get("cf-ray"):
            return True
        return False

    @staticmethod
    def _extract_client_ip(request: Request) -> str:
        forwarded = request.headers.get("cf-connecting-ip", "").strip()
        if forwarded:
            return forwarded

        if request.client and request.client.host:
            return request.client.host

        return "unknown"

    def _check_rate_limit(self, client_ip: str) -> Optional[AuthResult]:
        now = time.time()
        record = self._auth_failures.get(client_ip)
        if not record:
            return None

        blocked_until = record.get("blocked_until", 0.0)
        if blocked_until > now:
            retry_after = int(blocked_until - now)
            return AuthResult(
                ok=False,
                status_code=429,
                detail=(
                    "Too many invalid auth attempts. "
                    "Retry later or provide the correct API key."
                ),
                retry_after_seconds=max(retry_after, 1),
                client_ip=client_ip,
            )

        # Expire old failure windows.
        window_started = record.get("window_started", 0.0)
        if now - window_started > AUTH_WINDOW_SECONDS:
            self._auth_failures.pop(client_ip, None)

        return None

    def _record_auth_failure(self, client_ip: str) -> None:
        now = time.time()
        record = self._auth_failures.get(client_ip)

        if not record or now - record.get("window_started", 0.0) > AUTH_WINDOW_SECONDS:
            record = {
                "count": 1.0,
                "window_started": now,
                "blocked_until": 0.0,
            }
            self._auth_failures[client_ip] = record
            return

        record["count"] = record.get("count", 0.0) + 1.0
        if record["count"] >= AUTH_MAX_FAILURES:
            record["blocked_until"] = now + AUTH_BLOCK_SECONDS

    def _clear_auth_failure(self, client_ip: str) -> None:
        self._auth_failures.pop(client_ip, None)

    def _is_valid_api_key(self, provided: str) -> bool:
        if not provided or not self._api_key_salt or not self._api_key_hash:
            return False
        actual = self._compute_key_hash(provided, self._api_key_salt)
        return hmac.compare_digest(self._api_key_hash, actual)

    def authenticate_request(self, request: Request) -> AuthResult:
        """Validate API key with brute-force throttling."""
        client_ip = self._extract_client_ip(request)
        allow_proxy_fallback = self.is_tunnel_request(request)

        if not self.api_key_configured:
            return AuthResult(
                ok=False,
                status_code=503,
                detail="Remote API key is not configured",
                client_ip=client_ip,
            )

        provided = self._extract_api_key(
            request, allow_proxy_fallback=allow_proxy_fallback
        )
        limited = self._check_rate_limit(client_ip)
        if limited:
            # If a blocked client finally provides the valid key, allow recovery
            # immediately without waiting for Retry-After to elapse.
            if provided and self._is_valid_api_key(provided):
                self._clear_auth_failure(client_ip)
                return AuthResult(ok=True, client_ip=client_ip)
            return limited

        if not provided:
            self._record_auth_failure(client_ip)
            return AuthResult(
                ok=False,
                status_code=401,
                detail=(
                    "Missing API key "
                    + (
                        "(use Authorization: Bearer <key>, X-NMEM-API-Key, "
                        "or nmem_api_key cookie/query)"
                        if allow_proxy_fallback
                        else "(use Authorization: Bearer <key> or X-NMEM-API-Key)"
                    )
                ),
                client_ip=client_ip,
            )

        if not self._is_valid_api_key(provided):
            self._record_auth_failure(client_ip)
            return AuthResult(
                ok=False,
                status_code=401,
                detail="Invalid API key",
                client_ip=client_ip,
            )

        self._clear_auth_failure(client_ip)
        return AuthResult(ok=True, client_ip=client_ip)

    def assert_authenticated(self, request: Request) -> str:
        result = self.authenticate_request(request)
        if result.ok:
            return result.client_ip

        headers: dict[str, str] = {}
        if result.retry_after_seconds is not None:
            headers["Retry-After"] = str(result.retry_after_seconds)

        raise HTTPException(
            status_code=result.status_code,
            detail=result.detail,
            headers=headers,
        )

    def _is_process_running(self) -> bool:
        return self._process is not None and self._process.returncode is None

    async def _consume_tunnel_output(self) -> None:
        process = self._process
        if process is None or process.stdout is None:
            self._url_ready.set()
            return

        try:
            while True:
                line = await process.stdout.readline()
                if not line:
                    break

                text = line.decode("utf-8", errors="replace").strip()
                if not text:
                    continue

                self._log_tail.append(text)
                logger.debug("cloudflared", line=text)

                if self._public_url is None:
                    match = CLOUDFLARED_URL_PATTERN.search(text)
                    if match:
                        self._public_url = match.group(0).rstrip(" .|")
                        self._tunnel_connected = True
                        self._url_ready.set()
                        logger.info("Cloudflare quick tunnel ready", url=self._public_url)

                if (
                    self._active_mode == TUNNEL_MODE_ACCOUNT
                    and CLOUDFLARED_ACCOUNT_READY_PATTERN.search(text)
                ):
                    self._tunnel_connected = True
                    self._url_ready.set()
                    logger.info(
                        "Cloudflare account tunnel connected",
                        configured_url=self._account_tunnel_url,
                    )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("Error reading cloudflared logs", error=str(exc))
        finally:
            # Always unblock startup waiters.
            self._url_ready.set()

    async def _stop_process_locked(self) -> None:
        if self._process is not None:
            try:
                if self._process.returncode is None:
                    self._process.terminate()
                    try:
                        await asyncio.wait_for(self._process.wait(), timeout=8)
                    except asyncio.TimeoutError:
                        self._process.kill()
                        await asyncio.wait_for(self._process.wait(), timeout=3)
            except ProcessLookupError:
                pass
            except Exception as exc:
                logger.warning("Failed to stop cloudflared cleanly", error=str(exc))

        # Best-effort cleanup for stale managed processes from previous backend instances.
        self._cleanup_orphaned_managed_cloudflared_processes()

        if self._log_task is not None:
            self._log_task.cancel()
            try:
                await self._log_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self._process = None
        self._log_task = None
        self._public_url = None
        self._tunnel_connected = False
        self._active_mode = self._configured_mode
        self._url_ready = asyncio.Event()
        if self._managed_cloudflared_pid is not None:
            self._managed_cloudflared_pid = None
            self._save_state()

    def schedule_auto_start(self) -> None:
        """Restore previously running tunnel in background on backend startup."""
        if not self._auto_start_enabled:
            return
        if self._is_process_running():
            return
        if self._startup_restore_task and not self._startup_restore_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            logger.warning("Cannot auto-restore tunnel: no active event loop")
            return
        self._startup_restore_task = loop.create_task(self._auto_start_on_launch())

    async def _auto_start_on_launch(self) -> None:
        try:
            if not self._auto_start_enabled:
                return
            logger.info("Auto-restoring remote access tunnel", mode=self._configured_mode)
            await self.start_tunnel(rotate_api_key=False, mode=self._configured_mode)
        except Exception as exc:
            logger.warning("Auto-restore tunnel failed", error=str(exc))
        finally:
            self._startup_restore_task = None

    async def _cancel_startup_restore_task(self) -> None:
        task = self._startup_restore_task
        if task is None:
            return
        if task.done():
            self._startup_restore_task = None
            return
        if task is asyncio.current_task():
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
        self._startup_restore_task = None

    async def configure_tunnel(
        self,
        *,
        mode: Optional[str] = None,
        account_tunnel_url: Optional[str] = None,
        account_tunnel_token: Optional[str] = None,
    ) -> dict[str, Any]:
        async with self._lock:
            changed = False

            if mode is not None:
                normalized_mode = self._normalize_tunnel_mode(mode)
                if normalized_mode != self._configured_mode:
                    self._configured_mode = normalized_mode
                    changed = True

            if account_tunnel_url is not None:
                normalized_url = self._normalize_account_tunnel_url(account_tunnel_url)
                if normalized_url != self._account_tunnel_url:
                    self._account_tunnel_url = normalized_url
                    changed = True

            if account_tunnel_token is not None:
                token = account_tunnel_token.strip()
                if token:
                    token_enc, token_nonce = self._encrypt_secret(token)
                    self._account_tunnel_token_enc = token_enc
                    self._account_tunnel_token_nonce = token_nonce
                else:
                    self._account_tunnel_token_enc = None
                    self._account_tunnel_token_nonce = None
                changed = True

            if changed:
                self._save_state()

            return self.get_status()

    async def start_tunnel(
        self, rotate_api_key: bool = False, mode: Optional[str] = None
    ) -> dict[str, Any]:
        """Start quick tunnel and return status plus optional plaintext API key."""
        async with self._lock:
            self._cleanup_orphaned_managed_cloudflared_processes()
            selected_mode = self._configured_mode
            if mode is not None:
                selected_mode = self._normalize_tunnel_mode(mode)
                if selected_mode != self._configured_mode:
                    self._configured_mode = selected_mode
                    self._save_state()

            new_api_key: Optional[str] = None
            if rotate_api_key or not self.api_key_configured:
                new_api_key = self._set_new_api_key()

            if self._is_process_running():
                if self._active_mode == selected_mode:
                    if not self._auto_start_enabled:
                        self._auto_start_enabled = True
                        self._save_state()
                    status = self.get_status()
                    status["api_key"] = new_api_key
                    return status
                await self._stop_process_locked()

            if selected_mode == TUNNEL_MODE_ACCOUNT:
                if not self._account_tunnel_url:
                    raise RuntimeError(
                        "Account tunnel mode requires a configured public API URL "
                        "(for example https://mem.example.com). "
                        "Create a Public Hostname in Cloudflare (Route tunnel step), "
                        "then paste that URL in Settings."
                    )
                account_token = self._get_account_tunnel_token()
                if not account_token:
                    raise RuntimeError(
                        "Account tunnel mode requires a tunnel token. "
                        "Open Cloudflare Zero Trust, create a tunnel token, and save it in Settings."
                    )

            self._active_mode = selected_mode
            tunnel_token: Optional[str] = None
            if self._active_mode == TUNNEL_MODE_ACCOUNT:
                tunnel_token = self._get_account_tunnel_token()
                assert tunnel_token is not None

            cloudflared_path, cloudflared_source = self.resolve_cloudflared()
            if not cloudflared_path:
                raise RuntimeError(
                    "cloudflared was not found (bundled runtime or PATH). "
                    "Install it first: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
                )

            command = [cloudflared_path, "tunnel", "--no-autoupdate"]
            if self._active_mode == TUNNEL_MODE_ACCOUNT:
                command.extend(["run"])
            else:
                command.extend(["--url", LOCAL_GATEWAY_URL])

            env = os.environ.copy()
            if self._active_mode == TUNNEL_MODE_ACCOUNT:
                assert tunnel_token is not None
                # Prefer env var over argv to avoid leaking token via process list.
                env["TUNNEL_TOKEN"] = tunnel_token
                self._public_url = self._account_tunnel_url
            else:
                env.pop("TUNNEL_TOKEN", None)
                self._public_url = None
            env[CLOUDFLARED_MANAGED_ENV] = "1"
            env[CLOUDFLARED_OWNER_ENV] = self._cloudflared_owner

            self._url_ready = asyncio.Event()
            self._tunnel_connected = False
            self._log_tail.clear()

            logger.info(
                "Starting cloudflared tunnel",
                cloudflared_path=cloudflared_path,
                cloudflared_source=cloudflared_source,
                mode=self._active_mode,
            )

            self._process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env=env,
            )
            self._managed_cloudflared_pid = self._process.pid
            self._save_state()
            self._log_task = asyncio.create_task(self._consume_tunnel_output())

            try:
                await asyncio.wait_for(
                    self._url_ready.wait(),
                    timeout=TUNNEL_START_TIMEOUT_SECONDS,
                )
            except asyncio.TimeoutError as exc:
                last_logs = "\n".join(list(self._log_tail)[-20:])
                await self._stop_process_locked()
                raise RuntimeError(
                    "Timed out waiting for Cloudflare tunnel readiness. "
                    "Check network/proxy connectivity and try again. "
                    "If your network is unstable, retry or use Cloudflare account mode. "
                    f"Recent logs:\n{last_logs}"
                ) from exc

            if not self._tunnel_connected:
                last_logs = "\n".join(list(self._log_tail)[-20:])
                await self._stop_process_locked()
                raise RuntimeError(
                    "Cloudflare tunnel did not finish connecting. "
                    f"Recent logs:\n{last_logs}"
                )

            if not self._is_process_running():
                last_logs = "\n".join(list(self._log_tail)[-20:])
                await self._stop_process_locked()
                raise RuntimeError(
                    "Cloudflare tunnel exited during startup. "
                    f"Recent logs:\n{last_logs}"
                )

            if not self._public_url:
                last_logs = "\n".join(list(self._log_tail)[-10:])
                await self._stop_process_locked()
                raise RuntimeError(
                    "Cloudflare tunnel started but no public URL was detected. "
                    f"Recent logs:\n{last_logs}"
                )

            if not self._auto_start_enabled:
                self._auto_start_enabled = True
                self._save_state()

            status = self.get_status()
            status["api_key"] = new_api_key
            return status

    async def stop_tunnel(self, disable_auto_start: bool = True) -> dict[str, Any]:
        await self._cancel_startup_restore_task()
        async with self._lock:
            await self._stop_process_locked()
            if disable_auto_start and self._auto_start_enabled:
                self._auto_start_enabled = False
                self._save_state()
            return self.get_status()

    async def shutdown(self) -> None:
        await self._cancel_startup_restore_task()
        async with self._lock:
            await self._stop_process_locked()

    def get_status(self) -> dict[str, Any]:
        running = self._is_process_running()
        public_base_url: Optional[str] = None
        if running and self._public_url:
            # Cloudflare quick tunnels already expose root paths directly.
            # Returning a "/remote-api" suffix causes client-side path duplication
            # and auth failures (for example ".../remote-api/health").
            public_base_url = self._public_url
        cloudflared_path, cloudflared_source = self.resolve_cloudflared()
        account_token_configured = bool(self._get_account_tunnel_token())
        api_key_recoverable = bool(self._get_api_key_plaintext())
        active_mode = self._active_mode if running else None
        limitations = (
            QUICK_TUNNEL_LIMITATIONS
            if (active_mode or self._configured_mode) == TUNNEL_MODE_QUICK
            else ACCOUNT_TUNNEL_LIMITATIONS
        )
        parsed_allowlist, invalid_allowlist = load_ip_allowlist_from_env()

        return {
            "running": running,
            "auto_start_enabled": self._auto_start_enabled,
            "cloudflared_installed": cloudflared_path is not None,
            "cloudflared_path": cloudflared_path,
            "cloudflared_source": cloudflared_source,
            "tunnel_url": public_base_url,
            "gateway_path": REMOTE_GATEWAY_PREFIX,
            "local_gateway_url": LOCAL_GATEWAY_URL,
            "mode": self._configured_mode,
            "active_mode": active_mode,
            "account_tunnel_url": self._account_tunnel_url,
            "account_tunnel_token_configured": account_token_configured,
            "account_tunnel_configured": bool(
                self._account_tunnel_url and account_token_configured
            ),
            "api_key_configured": self.api_key_configured,
            "api_key_recoverable": api_key_recoverable,
            "key_id": self._key_id,
            "key_created_at": self._key_created_at,
            "key_rotated_at": self._key_rotated_at,
            "quick_tunnel": (active_mode or self._configured_mode)
            == TUNNEL_MODE_QUICK,
            "limitations": limitations,
            "backend_ip_allowlist": [str(network) for network in parsed_allowlist],
            "backend_ip_allowlist_invalid": invalid_allowlist,
        }

_remote_access_manager: Optional[RemoteAccessManager] = None


def get_remote_access_manager() -> RemoteAccessManager:
    global _remote_access_manager
    if _remote_access_manager is None:
        _remote_access_manager = RemoteAccessManager()
    return _remote_access_manager
