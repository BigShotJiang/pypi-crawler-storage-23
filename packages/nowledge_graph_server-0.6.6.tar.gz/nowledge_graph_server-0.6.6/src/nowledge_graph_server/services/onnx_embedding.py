"""ONNX-based embedding service for non-Apple-Silicon platforms.

This service uses ONNX Runtime directly (no PyTorch fallback) for efficient
CPU-based embeddings, replacing MLX which is macOS Apple Silicon only.

Uses minimal dependencies:
- onnxruntime (REQUIRED - no fallback)
- tokenizers (lightweight, not full transformers)
- numpy (for tensor operations)

Models must be available on both HuggingFace and ModelScope and support ONNX.
Default model: BAAI/bge-m3 (1024 dim)
"""

import asyncio
import platform
from pathlib import Path
from typing import List, Optional, Any, Dict
import numpy as np
import structlog

logger = structlog.get_logger(__name__)

# Type definitions
ONNXSessionType = Any
TokenizerType = Any


def _import_onnx_runtime():
    """Lazy import for ONNX Runtime - REQUIRED, no fallback."""
    try:
        import onnxruntime as ort  # type: ignore
        return ort
    except ImportError as e:
        logger.error("Failed to import onnxruntime", error=str(e))
        raise ImportError(
            "ONNX Runtime is REQUIRED for non-Apple-Silicon platforms. Install with: pip install onnxruntime"
        )


# def _import_tokenizers():
#     """Lazy import for tokenizers (lightweight, not full transformers)."""
#     try:
#         from tokenizers import Tokenizer
#         from tokenizers.pre_tokenizers import WhitespaceSplit
#         from transformers import AutoTokenizer  # Only for model loading
#         return AutoTokenizer
#     except ImportError as e:
#         logger.error("Failed to import tokenizers", error=str(e))
#         raise ImportError(
#             "tokenizers/transformers.tokenization_auto required. Install with: pip install tokenizers transformers"
#         )


class ONNXEmbeddingService:
    """ONNX-based embedding service for non-Apple-Silicon platforms.

    Uses ONNX Runtime directly (REQUIRED - no PyTorch fallback).
    Uses sentence-transformers for model loading/export but enforces ONNX-only execution.
    Works with models from both HuggingFace and ModelScope.

    Default model: BAAI/bge-m3 (1024 dim, multilingual)
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-m3",
        cache_dir: Optional[str] = None,
        cache_only: bool = True,
        download_source: str = "huggingface",
    ):
        """Initialize ONNX embedding service.

        Args:
            model_name: HuggingFace/ModelScope model name (must exist on both platforms)
            cache_dir: Local cache directory for models
            cache_only: Use only cached models (don't download)
            download_source: Download source (huggingface/modelscope)
        """
        self.model_name = model_name
        self.cache_dir = cache_dir
        self.cache_only = cache_only
        self.download_source = download_source
        self._initialized: bool = False

        # ONNX Runtime session (REQUIRED - no fallback)
        self.session: Optional[ONNXSessionType] = None
        self.tokenizer: Optional[TokenizerType] = None

        # Model dimension mappings
        self.model_dimensions = {
            "BAAI/bge-m3": 1024,  # Default for non-Apple-Silicon
            "sentence-transformers/all-MiniLM-L6-v2": 384,
            "sentence-transformers/all-mpnet-base-v2": 768,
            "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2": 384,
            "BAAI/bge-small-en-v1.5": 384,
        }

        # Determine dimension
        self.dimension = self.model_dimensions.get(model_name, 1024)

    async def initialize(self) -> None:
        """Initialize the ONNX model - REQUIRES ONNX Runtime (no fallback)."""
        if self._initialized:
            return

        # CRITICAL: Verify ONNX Runtime is available BEFORE proceeding
        ort = _import_onnx_runtime()
        if ort is None:
            raise RuntimeError(
                "ONNX Runtime is REQUIRED for non-Apple-Silicon embeddings. "
                "Install with: pip install onnxruntime"
            )

        try:
            logger.info(
                "Initializing ONNX embedding model (ONNX Runtime REQUIRED)",
                model=self.model_name,
                cache_only=self.cache_only,
                cache_dir=self.cache_dir,
                download_source=self.download_source,
            )

            # Configure download source environment
            self._setup_download_source()

            loop = asyncio.get_event_loop()
            cache_folder = self.cache_dir if self.cache_dir else None
            
            # Try to find existing ONNX model first (both HuggingFace and ModelScope provide ONNX files)
            onnx_path = await self._find_or_download_onnx_model(cache_folder)
            
            # Load tokenizer (need transformers for this)
            from transformers import AutoTokenizer
            AutoTokenizerClass = AutoTokenizer
            
            # Find tokenizer path (same as model path)
            tokenizer_path = await self._get_model_path(cache_folder)
            
            self.tokenizer = await loop.run_in_executor(
                None,
                lambda: AutoTokenizerClass.from_pretrained(
                    tokenizer_path,
                    local_files_only=self.cache_only,
                ),
            )
            
            # Load ONNX session (REQUIRED - no fallback)
            sess_options = ort.SessionOptions()
            sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            
            self.session = await loop.run_in_executor(
                None,
                lambda: ort.InferenceSession(
                    str(onnx_path),
                    sess_options,
                    providers=["CPUExecutionProvider"],  # CPU only
                ),
            )
            
            # Log model input/output info for debugging
            if self.session is not None:
                input_names = [inp.name for inp in self.session.get_inputs()]
                output_names = [out.name for out in self.session.get_outputs()]
                logger.info(
                    "ONNX session loaded",
                    onnx_path=str(onnx_path),
                    input_names=input_names,
                    output_names=output_names,
                    num_inputs=len(input_names),
                    num_outputs=len(output_names),
                )

            # Get model dimension from ONNX model metadata or use default
            self._initialized = True
            logger.info(
                "ONNX embedding model initialized successfully (ONNX Runtime ONLY)",
                model=self.model_name,
                dimension=self.dimension,
                onnx_path=str(onnx_path),
                backend="onnxruntime (required)",
            )

        except Exception as e:
            logger.error(
                "Failed to initialize ONNX embedding model",
                model=self.model_name,
                error=str(e),
            )
            raise

    async def _get_model_path(self, cache_folder: Optional[str]) -> str:
        """Get model path (for tokenizer loading) - downloads if needed."""
        import os
        
        # Use huggingface_hub or modelscope to download model
        if self.download_source == "modelscope":
            from modelscope.hub.snapshot_download import snapshot_download
        else:
            # Ensure offline mode is disabled before importing huggingface_hub
            os.environ["HF_HUB_OFFLINE"] = "0"
            os.environ["TRANSFORMERS_OFFLINE"] = "0"
            from huggingface_hub import snapshot_download
            import huggingface_hub.constants
            huggingface_hub.constants.HF_HUB_OFFLINE = False
        
        cache_path = cache_folder or str(Path.home() / ".cache" / "huggingface" / "hub")
        
        loop = asyncio.get_event_loop()
        model_path = await loop.run_in_executor(
            None,
            lambda: snapshot_download(
                self.model_name,
                cache_dir=cache_path,
                local_files_only=self.cache_only,
            ),
        )
        
        return model_path

    async def _find_or_download_onnx_model(self, cache_folder: Optional[str]) -> Path:
        """Find or download ONNX model from HuggingFace/ModelScope (they provide ONNX files).

        NOTE: Many HuggingFace models don't include ONNX files by default. For models that
        don't include ONNX, you may need to:
        1. Use sentence-transformers models (they often have ONNX exports)
        2. Convert the model to ONNX using: https://github.com/chroma-core/onnx-embedding
        3. Or use models that explicitly provide ONNX files (like BGE-M3)
        """
        import os
        
        # Determine cache path based on download source
        # Extract org and model_name for ModelScope compatibility
        org, model_name = self.model_name.split("/", 1)
        
        if self.download_source == "modelscope":
            cache_path = Path(cache_folder) if cache_folder else Path.home() / ".cache" / "modelscope" / "hub"
            # ModelScope uses: ~/.cache/modelscope/hub/models/org/model-name
            model_cache_dir = cache_path / "models" / org / model_name
        else:
            cache_path = Path(cache_folder) if cache_folder else Path.home() / ".cache" / "huggingface" / "hub"
            # HuggingFace cache format
            hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
            model_cache_dir = cache_path / hf_cache_name
        
        logger.debug("Searching for ONNX model", model_cache_dir=str(model_cache_dir), exists=model_cache_dir.exists())
        
        # Check for existing ONNX file in cache
        if model_cache_dir.exists():
            # Try HuggingFace cache structure (snapshots/<hash>/onnx/model.onnx)
            snapshots_dir = model_cache_dir / "snapshots"
            if snapshots_dir.exists():
                for snapshot_dir in snapshots_dir.iterdir():
                    if snapshot_dir.is_dir():
                        # HuggingFace stores ONNX files in onnx/ subdirectory (e.g., BAAI/bge-m3/onnx/)
                        # Check onnx/ subdirectory first (this is where HuggingFace stores them)
                        onnx_dir = snapshot_dir / "onnx"
                        if onnx_dir.exists():
                            # Look for model.onnx (standard name)
                            onnx_files = list(onnx_dir.glob("model.onnx"))
                            if onnx_files:
                                logger.info("Found ONNX model in cache (onnx/ subdirectory)", path=str(onnx_files[0]), source=self.download_source)
                                return onnx_files[0]
                            # Also check for other ONNX variants
                            all_onnx = list(onnx_dir.glob("*.onnx"))
                            if all_onnx:
                                # Prefer model.onnx, otherwise use first found
                                preferred = next((f for f in all_onnx if f.name == "model.onnx"), all_onnx[0])
                                logger.info("Found ONNX model variant in cache", path=str(preferred), source=self.download_source)
                                return preferred
                        
                        # Also check for model.onnx directly in snapshot (older structure)
                        direct_onnx = snapshot_dir / "model.onnx"
                        if direct_onnx.exists():
                            logger.info("Found ONNX model directly in snapshot", path=str(direct_onnx), source=self.download_source)
                            return direct_onnx
            
            # Try ModelScope structure (direct model directory)
            onnx_dir = model_cache_dir / "onnx"
            if onnx_dir.exists():
                onnx_files = list(onnx_dir.glob("model.onnx"))
                if onnx_files:
                    logger.info("Found ONNX model in ModelScope cache", path=str(onnx_files[0]))
                    return onnx_files[0]
            
            # Check directly in model directory
            direct_onnx = model_cache_dir / "model.onnx"
            if direct_onnx.exists():
                logger.info("Found ONNX model directly in model directory", path=str(direct_onnx))
                return direct_onnx
        
        # If ONNX not found but PyTorch model exists, try to convert it
        # we should not try to convert it, because it's not supported by the model
        # Most models like BGE-M3 come with .onnx files
        # if model_cache_dir.exists():
        #     # Check if we have PyTorch model files (but no ONNX)
        #     has_pytorch_model = False
        #     snapshot_with_model = None
            
        #     snapshots_dir = model_cache_dir / "snapshots"
        #     if snapshots_dir.exists():
        #         for snapshot_dir in snapshots_dir.iterdir():
        #             if snapshot_dir.is_dir():
        #                 # Check for PyTorch model files
        #                 if any(f.endswith(('.safetensors', '.bin')) for f in os.listdir(snapshot_dir) if os.path.isfile(snapshot_dir / f)):
        #                     has_pytorch_model = True
        #                     snapshot_with_model = snapshot_dir
        #                     break
            
        #     if has_pytorch_model and snapshot_with_model:
        #         logger.info(
        #             "PyTorch model found but ONNX missing, attempting conversion",
        #             model=self.model_name,
        #             snapshot_dir=str(snapshot_with_model),
        #         )
        #         try:
        #             onnx_path = await self._convert_pytorch_to_onnx(snapshot_with_model, cache_folder)
        #             logger.info("Successfully converted PyTorch model to ONNX", onnx_path=str(onnx_path))
        #             return onnx_path
        #         except Exception as e:
        #             logger.warning(
        #                 "Failed to convert PyTorch model to ONNX, will fall back to sentence-transformers",
        #                 error=str(e),
        #             )
        #             # Fall through to error or fallback
        
        # If not found and cache_only, fail with helpful error
        if self.cache_only:
            # List what files ARE in the cache to help debug
            found_files = []
            if model_cache_dir.exists():
                for root, dirs, files in os.walk(model_cache_dir):
                    for file in files:
                        if file.endswith(('.onnx', '.bin', '.safetensors')):
                            found_files.append(str(Path(root) / file))
            
            error_msg = (
                f"ONNX model file not found in cache for {self.model_name}. "
                f"Searched in: {model_cache_dir}\n"
            )
            if found_files:
                error_msg += f"Found model files (but not ONNX): {found_files[:5]}\n"
            error_msg += (
                f"\nNOTE: Many HuggingFace models don't include ONNX files. Options:\n"
                f"1. Use a sentence-transformers model (e.g., sentence-transformers/all-MiniLM-L6-v2)\n"
                f"2. Convert your model to ONNX using: https://github.com/chroma-core/onnx-embedding\n"
                f"3. Disable cache_only mode to allow downloading"
            )
            raise RuntimeError(error_msg)
        
        # Download model - need to explicitly download ONNX files from onnx/ subdirectory
        logger.info("Downloading model with ONNX files from repository", model=self.model_name, source=self.download_source)
        
        if self.download_source == "modelscope":
            from modelscope.hub.snapshot_download import snapshot_download
            loop = asyncio.get_event_loop()
            model_path = await loop.run_in_executor(
                None,
                lambda: snapshot_download(
                    self.model_name,
                    cache_dir=str(cache_path),
                ),
            )
        else:
            # HuggingFace: explicitly download ONNX files from onnx/ subdirectory
            import os
            os.environ["HF_HUB_OFFLINE"] = "0"
            os.environ["TRANSFORMERS_OFFLINE"] = "0"
            from huggingface_hub import snapshot_download, hf_hub_download
            import huggingface_hub.constants
            huggingface_hub.constants.HF_HUB_OFFLINE = False
            loop = asyncio.get_event_loop()
            
            # First download the main model
            model_path = await loop.run_in_executor(
                None,
                lambda: snapshot_download(
                    self.model_name,
                    cache_dir=str(cache_path),
                ),
            )
            
            # Then explicitly download ONNX files from the onnx/ subdirectory
            # HuggingFace stores them at: model_name/onnx/model.onnx
            try:
                logger.info("Downloading ONNX files from onnx/ subdirectory", model=self.model_name)
                onnx_files = ["model.onnx", "model_O4.onnx"]  # Try common ONNX variants
                for onnx_file in onnx_files:
                    try:
                        onnx_path = await loop.run_in_executor(
                            None,
                            lambda f=onnx_file: hf_hub_download(
                                repo_id=self.model_name,
                                filename=f"onnx/{f}",
                                cache_dir=str(cache_path),
                            ),
                        )
                        logger.info("Downloaded ONNX file", file=onnx_file, path=onnx_path)
                        # Use the first successfully downloaded ONNX file
                        return Path(onnx_path)
                    except Exception as e:
                        logger.debug("Failed to download ONNX variant", file=onnx_file, error=str(e))
                        continue
                
                logger.warning("Could not download any ONNX files from onnx/ subdirectory")
            except Exception as e:
                logger.warning("Failed to download ONNX files separately", error=str(e))
                # Continue to check if they were downloaded with the main model
        
        # Now look for ONNX file in downloaded location
        model_path_obj = Path(model_path)
        
        # Check onnx/ subdirectory
        onnx_dir = model_path_obj / "onnx"
        if onnx_dir.exists():
            onnx_files = list(onnx_dir.glob("model.onnx"))
            if onnx_files:
                logger.info("Found ONNX model after download", path=str(onnx_files[0]))
                return onnx_files[0]
        
        # Check directly in model directory
        direct_onnx = model_path_obj / "model.onnx"
        if direct_onnx.exists():
            logger.info("Found ONNX model directly after download", path=str(direct_onnx))
            return direct_onnx
        
        # Check in cache structure (after download) - try both HuggingFace and ModelScope formats
        if self.download_source == "modelscope":
            # ModelScope: check in downloaded location and cache
            model_cache_dir = cache_path / "models" / org / model_name
            if model_cache_dir.exists():
                onnx_dir = model_cache_dir / "onnx"
                if onnx_dir.exists():
                    onnx_files = list(onnx_dir.glob("model.onnx"))
                    if onnx_files:
                        logger.info("Found ONNX model in ModelScope cache after download", path=str(onnx_files[0]))
                        return onnx_files[0]
        else:
            # HuggingFace: check in cache structure
            hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
            hf_cache_dir = cache_path / hf_cache_name
            if hf_cache_dir.exists():
                snapshots_dir = hf_cache_dir / "snapshots"
                if snapshots_dir.exists():
                    for snapshot_dir in snapshots_dir.iterdir():
                        if snapshot_dir.is_dir():
                            onnx_dir = snapshot_dir / "onnx"
                            if onnx_dir.exists():
                                onnx_files = list(onnx_dir.glob("model.onnx"))
                                if onnx_files:
                                    logger.info("Found ONNX model in HF cache after download", path=str(onnx_files[0]))
                                    return onnx_files[0]
        
        raise RuntimeError(
            f"ONNX model file not found after downloading {self.model_name}. "
            f"Expected ONNX file at: {model_path}/onnx/model.onnx or {model_path}/model.onnx. "
            f"Please verify the model repository contains ONNX files."
        )

    def _setup_download_source(self) -> None:
        """Configure environment for ModelScope or HuggingFace downloads."""
        import os
        
        if self.download_source == "modelscope":
            os.environ["HF_ENDPOINT"] = "https://modelscope.cn"
            logger.debug("Configured for ModelScope downloads")
        else:
            if "HF_ENDPOINT" in os.environ:
                del os.environ["HF_ENDPOINT"]
            logger.debug("Configured for HuggingFace downloads")

    # async def _convert_pytorch_to_onnx(self, model_path: Path, cache_folder: Optional[str]) -> Path:
    #     """Convert PyTorch model to ONNX format using sentence-transformers.
        
    #     This uses sentence-transformers' built-in ONNX export functionality.
    #     """
    #     try:
    #         from sentence_transformers import SentenceTransformer
    #     except ImportError:
    #         raise RuntimeError(
    #             "sentence-transformers required for ONNX conversion. "
    #             "Install with: pip install sentence-transformers"
    #         )
        
    #     logger.info("Converting PyTorch model to ONNX", model_path=str(model_path), model=self.model_name)
        
    #     loop = asyncio.get_event_loop()
        
    #     # Load the model using sentence-transformers (can load from HF format)
    #     def _convert():
    #         # Try to load model from the path
    #         # sentence-transformers can load from HuggingFace cache format
    #         try:
    #             # Load model - sentence-transformers will handle the conversion
    #             model = SentenceTransformer(self.model_name, cache_folder=cache_folder)
                
    #             # Export to ONNX - sentence-transformers v2+ has save_as_onnx method
    #             # Create output directory for ONNX file
    #             output_dir = model_path / "onnx"
    #             output_dir.mkdir(exist_ok=True)
    #             onnx_path = output_dir / "model.onnx"
                
    #             # Use sentence-transformers' ONNX export
    #             # Note: sentence-transformers v2.2+ has save_as_onnx method
    #             # Check if method exists and is callable
    #             if hasattr(model, 'save_as_onnx') and callable(getattr(model, 'save_as_onnx', None)):
    #                 getattr(model, 'save_as_onnx')(str(onnx_path))
    #             else:
    #                 # Fallback: sentence-transformers models can be saved and converted
    #                 # For non-sentence-transformers models, we'd need manual conversion
    #                 raise RuntimeError(
    #                     "sentence-transformers version too old for ONNX export or model not compatible. "
    #                     "Need sentence-transformers >= 2.2.0 with ONNX support. "
    #                     "This model may need manual ONNX conversion."
    #                 )
                
    #             if not onnx_path.exists():
    #                 raise RuntimeError(f"ONNX conversion failed - file not created at {onnx_path}")
                
    #             logger.info("ONNX conversion successful", onnx_path=str(onnx_path))
    #             return onnx_path
                
    #         except Exception as e:
    #             logger.error("Failed to convert model to ONNX", error=str(e))
    #             raise RuntimeError(f"ONNX conversion failed: {e}")
        
    #     onnx_path = await loop.run_in_executor(None, _convert)
    #     return onnx_path

    def _prepare_text(self, text: str, prefix: str = "query") -> str:
        """Prepare text for embedding.

        Args:
            text: Input text
            prefix: Either "query" or "passage" (not used by BGE-M3)
        """
        # BGE-M3 and most modern models don't require prefix tokens
        # They handle query/passage distinction internally
        return text

    async def embed_text(self, text: str, prefix: str = "query") -> List[float]:
        """Generate embedding using ONNX Runtime (REQUIRED - no fallback).

        Args:
            text: Input text
            prefix: Either "query" (for search queries) or "passage" (for documents/memories to index)

        Returns:
            Embedding vector as a list of floats
        """
        if not self._initialized:
            raise RuntimeError("ONNX embedding service not initialized")

        if self.session is None or self.tokenizer is None:
            raise RuntimeError("ONNX session or tokenizer not initialized")

        if not text or not text.strip():
            return [0.0] * self.dimension

        try:
            # Prepare text for embedding
            prepared_text = self._prepare_text(text.strip(), prefix=prefix)
            logger.debug("Embedding text with ONNX", text=prepared_text[:100])
            
            return await self._embed_text_onnx(prepared_text)

        except Exception as e:
            logger.error(
                "Failed to generate embedding with ONNX",
                text=text[:100],
                error=str(e),
            )
            raise

    async def _embed_text_onnx(self, text: str) -> List[float]:
        """Generate embedding using ONNX Runtime directly."""
        if self.session is None or self.tokenizer is None:
            raise RuntimeError("ONNX session or tokenizer not initialized")

        loop = asyncio.get_event_loop()

        def _encode_onnx() -> List[float]:
            assert self.tokenizer is not None, "Tokenizer not initialized"
            assert self.session is not None, "ONNX session not initialized"
            
            # Tokenize
            inputs = self.tokenizer(
                text,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="np",
            )

            # Prepare ONNX inputs - use actual input names from the model
            # Some models use different input names (e.g., "input_ids" vs "input")
            session_inputs = {inp.name: None for inp in self.session.get_inputs()}
            
            # Map standard names to model input names
            # Most models use "input_ids" and "attention_mask", but check actual names
            input_ids_name = "input_ids" if "input_ids" in session_inputs else list(session_inputs.keys())[0]
            attention_mask_name = "attention_mask" if "attention_mask" in session_inputs else (list(session_inputs.keys())[1] if len(session_inputs) > 1 else None)
            
            onnx_inputs = {
                input_ids_name: inputs["input_ids"].astype(np.int64),
            }
            
            if attention_mask_name:
                onnx_inputs[attention_mask_name] = inputs["attention_mask"].astype(np.int64)
            
            # Add token_type_ids if model expects it and we have it
            token_type_ids_name = "token_type_ids" if "token_type_ids" in session_inputs else None
            if token_type_ids_name and "token_type_ids" in inputs:
                onnx_inputs[token_type_ids_name] = inputs["token_type_ids"].astype(np.int64)

            # Run ONNX inference
            try:
                outputs = self.session.run(None, onnx_inputs)
                embeddings = outputs[0]  # Shape: [batch, seq_len, hidden_dim]
            except Exception as e:
                logger.error(
                    "ONNX inference failed",
                    error=str(e),
                    input_names=list(onnx_inputs.keys()),
                    input_shapes={k: v.shape for k, v in onnx_inputs.items()},
                    expected_inputs=[inp.name for inp in self.session.get_inputs()],
                )
                raise

            # Mean pooling with attention mask
            attention_mask = inputs["attention_mask"]
            mask_expanded = np.expand_dims(attention_mask, -1)
            sum_embeddings = np.sum(embeddings * mask_expanded, axis=1)
            sum_mask = np.clip(np.sum(attention_mask, axis=1, keepdims=True), a_min=1e-9, a_max=None)
            mean_pooled = sum_embeddings / sum_mask

            # Normalize
            norms = np.linalg.norm(mean_pooled, axis=1, keepdims=True)
            normalized = mean_pooled / np.clip(norms, a_min=1e-9, a_max=None)

            return normalized[0].tolist()

        embedding = await loop.run_in_executor(None, _encode_onnx)
        return [float(x) for x in embedding]

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using ONNX Runtime (REQUIRED - no fallback).

        Args:
            texts: List of input texts

        Returns:
            List of embedding vectors
        """
        if not self._initialized:
            raise RuntimeError("ONNX embedding service not initialized")

        if self.session is None or self.tokenizer is None:
            raise RuntimeError("ONNX session or tokenizer not initialized")

        if not texts:
            return []

        # Preallocate results list to preserve original length and ordering
        result = [None] * len(texts)
        
        # Record indices and values of non-empty inputs
        valid_indices = []
        valid_texts = []
        for idx, text in enumerate(texts):
            stripped = text.strip() if text else ""
            if stripped:
                valid_indices.append(idx)
                # Prepare text for embedding
                valid_texts.append(self._prepare_text(stripped))
            else:
                # Pre-fill empty entries with None (will be replaced with zero vector)
                result[idx] = None

        if not valid_texts:
            logger.warning("No valid texts to embed", texts=texts)
            # All inputs were empty - return zero vectors for all
            return [[0.0] * self.dimension for _ in texts]

        try:
            embeddings = await self._embed_batch_onnx(valid_texts)

            # Map embeddings back to original indices
            for idx, embedding in zip(valid_indices, embeddings):
                result[idx] = embedding  # type: ignore

            # Fill empty entries with zero vectors
            zero_vector = [0.0] * self.dimension
            for idx in range(len(result)):
                if result[idx] is None:
                    result[idx] = zero_vector  # type: ignore

            # Verify output length matches input length
            assert len(result) == len(texts), f"Output length {len(result)} != input length {len(texts)}"
            
            return result # type: ignore

        except Exception as e:
            logger.error(
                "Failed to generate batch embeddings with ONNX",
                count=len(texts),
                error=str(e),
            )
            raise

    async def _embed_batch_onnx(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings using ONNX Runtime directly."""
        if self.session is None or self.tokenizer is None:
            raise RuntimeError("ONNX session or tokenizer not initialized")

        loop = asyncio.get_event_loop()

        def _encode_batch_onnx() -> List[List[float]]:
            assert self.tokenizer is not None, "Tokenizer not initialized"
            assert self.session is not None, "ONNX session not initialized"
            
            # Tokenize all texts
            inputs = self.tokenizer(
                texts,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="np",
            )

            # Prepare ONNX inputs - use actual input names from the model (same as single text)
            session_inputs = {inp.name: None for inp in self.session.get_inputs()}
            input_ids_name = "input_ids" if "input_ids" in session_inputs else list(session_inputs.keys())[0]
            attention_mask_name = "attention_mask" if "attention_mask" in session_inputs else (list(session_inputs.keys())[1] if len(session_inputs) > 1 else None)
            
            onnx_inputs = {
                input_ids_name: inputs["input_ids"].astype(np.int64),
            }
            
            if attention_mask_name:
                onnx_inputs[attention_mask_name] = inputs["attention_mask"].astype(np.int64)
            
            token_type_ids_name = "token_type_ids" if "token_type_ids" in session_inputs else None
            if token_type_ids_name and "token_type_ids" in inputs:
                onnx_inputs[token_type_ids_name] = inputs["token_type_ids"].astype(np.int64)

            # Run ONNX inference
            try:
                outputs = self.session.run(None, onnx_inputs)
                embeddings = outputs[0]  # Shape: [batch, seq_len, hidden_dim]
            except Exception as e:
                logger.error(
                    "ONNX batch inference failed",
                    error=str(e),
                    batch_size=len(texts),
                    input_names=list(onnx_inputs.keys()),
                    input_shapes={k: v.shape for k, v in onnx_inputs.items()},
                    expected_inputs=[inp.name for inp in self.session.get_inputs()],
                )
                raise

            # Mean pooling with attention mask
            attention_mask = inputs["attention_mask"]
            mask_expanded = np.expand_dims(attention_mask, -1)
            sum_embeddings = np.sum(embeddings * mask_expanded, axis=1)
            sum_mask = np.clip(np.sum(attention_mask, axis=1, keepdims=True), a_min=1e-9, a_max=None)
            mean_pooled = sum_embeddings / sum_mask

            # Normalize
            norms = np.linalg.norm(mean_pooled, axis=1, keepdims=True)
            normalized = mean_pooled / np.clip(norms, a_min=1e-9, a_max=None)

            return [[float(x) for x in emb] for emb in normalized]

        embeddings = await loop.run_in_executor(None, _encode_batch_onnx)
        return embeddings

    async def cleanup(self) -> None:
        """Cleanup resources."""
        if hasattr(self, "session") and self.session is not None:
            del self.session
        if hasattr(self, "tokenizer") and self.tokenizer is not None:
            del self.tokenizer
        self._initialized = False
        logger.info("ONNX embedding service cleaned up")
