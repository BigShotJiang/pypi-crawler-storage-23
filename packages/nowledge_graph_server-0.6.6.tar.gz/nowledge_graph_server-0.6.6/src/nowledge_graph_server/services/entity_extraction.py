"""Entity extraction service for NLP processing."""

import asyncio
import re
from typing import Any, Dict, List, Optional, Set
import structlog

from ..models import EntityNode

try:
    import spacy  # type: ignore[import-not-found]

    SPACY_AVAILABLE = True
except ImportError:
    spacy = None  # type: ignore[assignment]
    SPACY_AVAILABLE = False

logger = structlog.get_logger(__name__)


class EntityExtractionService:
    """Service for extracting entities from text using spaCy and pattern matching."""

    def __init__(self, model_name: str = "en_core_web_sm"):
        """Initialize entity extraction service.

        Args:
            model_name: spaCy model name
        """
        self.model_name = model_name
        self.nlp: Optional[Any] = None
        self._initialized = False
