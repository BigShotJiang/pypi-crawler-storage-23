"""
Remote LLM Configuration Manager.

Handles configuration file for remote LLM providers with file watching.
"""

import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Literal, Optional

import structlog
from watchdog.observers import Observer

from nowledge_graph_server.utils.app_paths import (
    get_app_config_dir,
    get_legacy_app_data_dir,
    get_real_home,
    resolve_config_file_path,
)

from .remote_llm_config_models import RemoteLLMConfig
from .remote_llm_config_storage import RemoteLLMConfigStorageMixin
from .remote_llm_config_watcher import ConfigFileWatcher
from .secure_keys import get_encryption_key_bytes

logger = structlog.get_logger(__name__)


class RemoteLLMConfigManager(RemoteLLMConfigStorageMixin):
    """Singleton manager for remote LLM configuration."""

    _instance: Optional["RemoteLLMConfigManager"] = None
    _init_lock = threading.Lock()  # For singleton initialization only

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize the config manager.

        Args:
            config_path: Path to the config file. If None, uses default location.
        """
        if config_path is None:
            self.config_path = resolve_config_file_path("remote_llm.json")
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            self.config_path = config_path

        # Active/selected provider config (flattened for compatibility)
        self._config: RemoteLLMConfig = RemoteLLMConfig()
        # All configured providers by provider name
        self._providers: Dict[str, RemoteLLMConfig] = {}
        # Purpose selections (default + ai_now). ai_now may be unset (inherit default).
        # Stored as provider_id + optional model override.
        self._purposes: Dict[str, Dict[str, Optional[str]]] = {
            "default": {"provider": None, "model": None},
            "ai_now": {"provider": None, "model": None},
        }
        # Currently active provider id (legacy field, maps to purposes.default.provider)
        self._active_provider: Optional[str] = None
        self._observer: Optional[Observer] = None  # type: ignore
        self._watcher_started = False
        # Track when we're saving to avoid reloading our own changes
        self._saving = False
        self._last_save_time = -1.0  # -1 means "never saved yet"

        # Lock for thread-safe access to _providers, _config, _active_provider
        # Use RLock (reentrant) so same thread can acquire multiple times (e.g., update_config calls _save_config)
        self._data_lock = threading.RLock()

        # Callbacks to notify when config changes (for reactive agent startup)
        self._change_callbacks: list = []
        self._change_callbacks_lock = threading.Lock()

        # Load initial config
        self._load_config()

    @classmethod
    def get_instance(
        cls, config_path: Optional[Path] = None
    ) -> "RemoteLLMConfigManager":
        """Get or create the singleton instance."""
        if cls._instance is None:
            with cls._init_lock:
                if cls._instance is None:
                    cls._instance = cls(config_path)
        return cls._instance

    # Dependency hooks for storage mixin. Keep these wrappers so existing tests
    # can monkeypatch symbols on this module (`remote_llm_config.py`).
    def _get_encryption_key_bytes(self) -> bytes:
        return get_encryption_key_bytes()

    def _get_app_config_dir(self) -> Path:
        return get_app_config_dir()

    def _get_legacy_app_data_dir(self) -> Path:
        return get_legacy_app_data_dir()

    def _get_real_home(self) -> Path:
        return get_real_home()

    def _os_module(self):
        return os

    def start_watching(self) -> None:
        """Start watching the config file for changes (creation AND modification).

        This enables reactive startup: when Tauri writes the config file
        after Python has already started, the file watcher will detect it
        and trigger a config reload, which notifies callbacks (like the
        Knowledge Agent) to start.
        """
        if self._watcher_started:
            logger.info("[CONFIG WATCHER] Already started")
            return

        try:
            event_handler = ConfigFileWatcher(self.config_path, self._load_config)
            self._observer = Observer()
            self._observer.schedule(  # type: ignore
                event_handler, str(self.config_path.parent), recursive=False
            )
            self._observer.start()  # type: ignore
            self._watcher_started = True
            logger.warning(
                "[CONFIG WATCHER] Started watching remote LLM config file",
                path=str(self.config_path),
                watch_dir=str(self.config_path.parent),
                file_exists=self.config_path.exists(),
            )
        except Exception as e:
            logger.error("[CONFIG WATCHER] Failed to start file watcher", error=str(e))

    def stop_watching(self) -> None:
        """Stop watching the config file."""
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._watcher_started = False
            logger.info("Stopped watching remote LLM config file")

    def register_change_callback(self, callback) -> None:
        """Register a callback to be called when config changes.

        Callbacks are called after config is reloaded from disk.
        Use this for reactive startup (e.g., Knowledge Agent starting
        when LLM becomes available after Tauri app writes config).

        The callback receives no arguments and should be quick/non-blocking.
        For async work, schedule it on an event loop.
        """
        with self._change_callbacks_lock:
            if callback not in self._change_callbacks:
                self._change_callbacks.append(callback)

    def unregister_change_callback(self, callback) -> None:
        """Unregister a previously registered change callback."""
        with self._change_callbacks_lock:
            if callback in self._change_callbacks:
                self._change_callbacks.remove(callback)

    def _notify_change_callbacks(self) -> None:
        """Call all registered change callbacks (non-blocking).

        This is the key mechanism for reactive startup: when the config file
        changes (created or modified), we notify all registered callbacks
        (like the Knowledge Agent) so they can start if LLM is now available.
        """
        with self._change_callbacks_lock:
            callbacks = list(self._change_callbacks)

        if callbacks:
            logger.warning(
                "[CONFIG WATCHER] Notifying change callbacks",
                callback_count=len(callbacks),
            )
        else:
            logger.info("[CONFIG WATCHER] No callbacks registered to notify")

        for cb in callbacks:
            try:
                logger.warning(f"[CONFIG WATCHER] Calling callback: {cb}")
                cb()
            except Exception as e:
                logger.error("[CONFIG WATCHER] Callback failed", error=str(e), callback=str(cb))

    def get_config(self) -> RemoteLLMConfig:
        """Get the current configuration (thread-safe)."""
        with self._data_lock:
            return self._config.model_copy()

    def update_config(self, config: RemoteLLMConfig) -> None:
        """Update configuration for the specified provider and set it active (thread-safe).
        Merges with existing provider config and preserves sensitive fields if omitted.
        """
        with self._data_lock:
            # Resolve provider name
            provider_name = (config.provider or self._config.provider or "").strip()
            if not provider_name:
                # Nothing to do without a provider name
                provider_name = "openai"
                config.provider = provider_name

            # Get existing provider config
            existing = self._providers.get(
                provider_name, RemoteLLMConfig(provider=provider_name)
            )

            # Merge logic: preserve sensitive fields if not provided
            merged = existing.model_copy()
            # Simple fields
            merged.enabled = bool(config.enabled)
            merged.provider = provider_name
            merged.provider_type = (
                (config.provider_type or "").strip()
                or (existing.provider_type or "").strip()
                or provider_name
            )
            if config.display_name is not None:
                dn = (config.display_name or "").strip()
                merged.display_name = dn or None
            if config.model:
                merged.model = config.model
            # GitHub Copilot / OpenAI Codex: api_base is derived from token cache; never persist user/base here.
            if (merged.provider_type or provider_name) in ("github_copilot", "openai_codex"):
                merged.api_base = None
            elif config.api_base is not None and config.api_base != "":
                merged.api_base = config.api_base
            if config.api_version is not None and config.api_version != "":
                merged.api_version = config.api_version
            # Sensitive key: only replace if provided non-empty
            if config.api_key is not None and config.api_key != "":
                merged.api_key = config.api_key
            # Performance/timeouts
            if getattr(config, "max_tokens", None):
                merged.max_tokens = config.max_tokens
            if getattr(config, "timeout", None):
                merged.timeout = config.timeout
            if getattr(config, "temperature", None) is not None:
                merged.temperature = config.temperature
            # Extra params: merge dictionaries
            if config.extra_params:
                merged.extra_params.update(config.extra_params)
            # Never persist one-shot flags
            merged.extra_params.pop("no_activate", None)

            merged.last_updated = datetime.utcnow().isoformat()

            # Save back
            self._providers[provider_name] = merged
            # Allow callers to update provider config without changing active selection.
            # (Used for multi-instance providers, where creating/editing an instance should not implicitly select it.)
            no_activate = False
            try:
                no_activate = bool((config.extra_params or {}).get("no_activate"))
            except Exception:
                no_activate = False

            if not no_activate:
                # Default purpose selection follows update_config (legacy behavior)
                self._active_provider = provider_name
                self._purposes["default"]["provider"] = provider_name
                self._purposes["default"]["model"] = (
                    merged.model or ""
                ).strip() or None
                # Active flattened view mirrors merged, including enabled flag
                self._config = merged.model_copy()
            else:
                # IMPORTANT: Always update the global enabled flag, even when no_activate is True.
                # The no_activate flag only prevents changing the active provider selection,
                # not the global enabled/disabled state.
                self._config.enabled = merged.enabled
                # Even when not activating, keep default purpose's model in sync with its provider.
                # This ensures that when a user changes the model in the provider card (without
                # clicking "Use as Default"), the default purpose's model is updated too.
                current_default_provider = (
                    self._purposes.get("default", {}) or {}
                ).get("provider")
                if current_default_provider == provider_name:
                    self._purposes["default"]["model"] = (
                        merged.model or ""
                    ).strip() or None
                    # Also update the flattened config to stay consistent
                    if self._config.provider == provider_name:
                        self._config.model = merged.model

                # Similarly, keep ai_now purpose's model in sync if it explicitly references this provider
                ai_now_provider = (self._purposes.get("ai_now", {}) or {}).get(
                    "provider"
                )
                if ai_now_provider == provider_name:
                    # Only update if ai_now has an explicit model set (not inheriting)
                    # If ai_now.model is None, it inherits from the provider anyway
                    current_ai_now_model = (self._purposes.get("ai_now", {}) or {}).get(
                        "model"
                    )
                    if current_ai_now_model:
                        # ai_now had an explicit model; update it to the new model
                        self._purposes["ai_now"]["model"] = (
                            merged.model or ""
                        ).strip() or None

                # Ensure default selection remains usable if this was the first/only configured provider.
                self._ensure_valid_default_selection_locked()
            self._save_config()

        # Notify change callbacks (outside the lock to avoid deadlocks).
        # The file watcher's debounce correctly skips reload for our own writes,
        # but that means callbacks would never fire — so we notify directly.
        self._notify_change_callbacks()

    def is_enabled(self) -> bool:
        """Check if remote LLM is enabled."""
        return self._config.enabled

    def get_litellm_params(self) -> Dict[str, Any]:
        """Get parameters formatted for litellm.completion()."""
        if not self._config.enabled:
            raise ValueError("Remote LLM is not enabled")

        # Normalize model id: ensure proper provider prefix for LiteLLM
        provider_id = (self._config.provider or "").strip()
        provider_type = (self._config.provider_type or "").strip() or provider_id
        model = (self._config.model or "").strip()
        api_base = self._config.api_base

        from nowledge_graph_server.services.litellm.utils import (
            is_kimi_coding_base,
            resolve_provider_for_api_base,
        )

        effective_provider_type = resolve_provider_for_api_base(provider_type, api_base)
        model_for_routing = model
        if effective_provider_type == "anthropic" and is_kimi_coding_base(api_base):
            # Kimi coding-plan models are stored as moonshot/<id> in UI, but the
            # Anthropic transport expects raw model ids (we add anthropic/ below).
            if model_for_routing.startswith("moonshot/"):
                model_for_routing = model_for_routing[len("moonshot/") :]
        if effective_provider_type == "anthropic":
            # Anthropic-compatible endpoints for non-Anthropic providers should
            # strip provider prefix before anthropic/<model> routing.
            for pref in ("minimax/",):
                if model_for_routing.startswith(pref):
                    model_for_routing = model_for_routing[len(pref) :]
                    break

        if effective_provider_type and model_for_routing.startswith(effective_provider_type + "/"):
            # Already correctly prefixed (e.g., 'openrouter/google/palm-2-chat-bison')
            normalized_model = model_for_routing
        elif effective_provider_type in (
            "openrouter",
            "anthropic",
            "openai",
            "xai",
            "deepseek",
            "gemini",
            "minimax",
            "zai",
            "moonshot",
            "github_copilot",
            "openai_codex",
        ) and not model_for_routing.startswith(effective_provider_type + "/"):
            # These providers MUST have prefix, even if model contains slashes
            # E.g., 'z-ai/glm-4.6' -> 'openrouter/z-ai/glm-4.6'
            normalized_model = (
                f"{effective_provider_type}/{model_for_routing}"
                if model_for_routing
                else model_for_routing
            )
        elif effective_provider_type == "openai_compatible" or effective_provider_type.startswith("openai_compatible:"):
            # OpenAI-compatible endpoints use OpenAI client directly (not litellm)
            # The model name is passed as-is to the custom endpoint - no prefix needed
            normalized_model = model_for_routing
        elif effective_provider_type == "ollama":
            # Ollama has its own prefix
            normalized_model = (
                f"ollama/{model_for_routing}" if model_for_routing else model_for_routing
            )
        else:
            # For other providers or no provider, use model as-is
            normalized_model = model_for_routing

        # Only include routing and auth params. Do NOT pass generation knobs here.
        params = {
            "model": normalized_model,
            # Include max_tokens so callers can set sensible limits for remote providers
            "max_tokens": self._config.max_tokens,
        }

        # Do not include api_key here; provider-scoped env is set at call time to avoid cross-provider leakage

        # Add API base if provided (with provider-specific normalization)
        # GitHub Copilot / OpenAI Codex: do NOT pass api_base (resolved from token cache).
        if api_base and effective_provider_type not in ("github_copilot", "openai_codex"):
            api_base_val = api_base

            # Provider-specific normalization
            if effective_provider_type == "ollama" and isinstance(api_base_val, str):
                # Ollama: strip /api suffix if present (LiteLLM adds it automatically)
                if api_base_val.rstrip("/").endswith("/api"):
                    api_base_val = api_base_val.rstrip("/")[:-4]
            elif effective_provider_type == "anthropic" and isinstance(api_base_val, str):
                # Anthropic: strip /v1 suffix if present (LiteLLM adds /v1/messages automatically)
                if api_base_val.rstrip("/").endswith("/v1"):
                    api_base_val = api_base_val.rstrip("/")[:-3]
            elif effective_provider_type == "gemini" and isinstance(api_base_val, str):
                # Gemini: normalize base (strip /v1beta) and drop default host.
                from nowledge_graph_server.services.litellm.utils import normalize_api_base

                api_base_val = normalize_api_base("gemini", api_base_val)

            if api_base_val:
                params["api_base"] = api_base_val

        # Add API version if provided (for Azure)
        if self._config.api_version:
            params["api_version"] = self._config.api_version

        # Add any extra parameters
        params.update(self._config.extra_params)

        return params

    # --- New helper APIs for multi-provider management ---

    def get_active_provider(self) -> Optional[str]:
        # Legacy: default purpose provider id
        return (self._purposes.get("default", {}) or {}).get(
            "provider"
        ) or self._active_provider

    def set_active_provider(self, provider_name: str) -> None:
        with self._data_lock:
            if provider_name in self._providers:
                self._active_provider = provider_name
                self._purposes["default"]["provider"] = provider_name
                self._purposes["default"]["model"] = (
                    self._providers[provider_name].model or ""
                ).strip() or None
                # Mirror selected provider into flattened config (preserving enabled flag)
                enabled = self._config.enabled
                self._config = self._providers[provider_name].model_copy()
                self._config.enabled = enabled
                self._save_config()
                # DO NOT reload after save; _providers is already correct in memory and reloading can perpetuate disk corruption
            else:
                raise ValueError(f"Unknown provider: {provider_name}")

    def get_all_provider_configs(self) -> Dict[str, RemoteLLMConfig]:
        with self._data_lock:
            return {k: v.model_copy() for k, v in self._providers.items()}

    def get_purpose_selection(
        self, purpose: Literal["default", "ai_now"]
    ) -> Dict[str, Optional[str]]:
        """Return raw purpose selection. ai_now may be empty (inherit default)."""
        with self._data_lock:
            return dict(self._purposes.get(purpose, {"provider": None, "model": None}))

    def set_purpose_selection(
        self,
        purpose: Literal["default", "ai_now"],
        provider: Optional[str],
        model: Optional[str],
    ) -> None:
        """Set purpose selection. For ai_now, provider/model can be None to inherit default."""
        with self._data_lock:
            if purpose == "default":
                if not provider:
                    raise ValueError("default purpose requires provider")
                if provider not in self._providers:
                    raise ValueError(f"Unknown provider: {provider}")
                self._purposes["default"]["provider"] = provider
                self._purposes["default"]["model"] = (model or "").strip() or None
                self._active_provider = provider
                enabled = self._config.enabled
                self._config = self._providers[provider].model_copy()
                self._config.enabled = enabled
                if self._purposes["default"]["model"]:
                    self._config.model = (
                        self._purposes["default"]["model"] or self._config.model
                    )
            else:
                # ai_now: allow clearing (inherit)
                if provider and provider not in self._providers:
                    raise ValueError(f"Unknown provider: {provider}")
                self._purposes["ai_now"]["provider"] = (provider or "").strip() or None
                self._purposes["ai_now"]["model"] = (model or "").strip() or None
                # If ai_now is cleared and default is invalid, try to repair default (single-provider case).
                self._ensure_valid_default_selection_locked()
            self._save_config()

    def get_effective_purpose(
        self, purpose: Literal["default", "ai_now"]
    ) -> Dict[str, Optional[str]]:
        """Return effective provider+model for a purpose (ai_now inherits default if unset)."""
        with self._data_lock:
            dprov = (self._purposes.get("default", {}) or {}).get(
                "provider"
            ) or self._active_provider
            dmodel = (self._purposes.get("default", {}) or {}).get("model")
            if dprov and not dmodel:
                dprov_config = self._providers.get(dprov)
                dmodel = (dprov_config.model if dprov_config else "") or None

            if purpose == "default":
                return {"provider": dprov, "model": dmodel}

            aprov = (self._purposes.get("ai_now", {}) or {}).get("provider") or None
            amodel = (self._purposes.get("ai_now", {}) or {}).get("model") or None
            if not aprov:
                return {"provider": dprov, "model": dmodel}
            if not amodel:
                aprov_config = self._providers.get(aprov)
                amodel = (aprov_config.model if aprov_config else "") or None
            return {"provider": aprov, "model": amodel}

    def remove_provider(self, provider_id: str) -> None:
        """Remove a provider config by provider_id, updating purposes if needed."""
        with self._data_lock:
            pid = (provider_id or "").strip()
            if not pid or pid not in self._providers:
                raise ValueError(f"Unknown provider: {provider_id}")

            del self._providers[pid]

            # Clear ai_now override if it referenced this provider
            if (self._purposes.get("ai_now", {}) or {}).get("provider") == pid:
                self._purposes["ai_now"]["provider"] = None
                self._purposes["ai_now"]["model"] = None

            # If default referenced it, pick a new default provider
            if (self._purposes.get("default", {}) or {}).get("provider") == pid:
                fallback = None
                if "openai" in self._providers:
                    fallback = "openai"
                elif self._providers:
                    fallback = next(iter(self._providers.keys()))
                else:
                    fallback = "openai"
                    self._providers[fallback] = RemoteLLMConfig(
                        provider=fallback, provider_type="openai"
                    )

                self._purposes["default"]["provider"] = fallback
                self._purposes["default"]["model"] = (
                    self._providers[fallback].model or ""
                ).strip() or None
                self._active_provider = fallback
                enabled = self._config.enabled
                self._config = self._providers[fallback].model_copy()
                self._config.enabled = enabled

            # If we removed the default provider and now only one provider remains configured,
            # auto-select it deterministically.
            self._ensure_valid_default_selection_locked()
            self._save_config()

    def clone_provider(
        self,
        source_provider_id: str,
        new_provider_id: str,
        *,
        model: Optional[str],
        display_name: Optional[str],
    ) -> None:
        """Clone an existing provider config to a new provider id.

        Intended for multi-instance providers like openai_compatible, allowing users to
        create multiple model variants without re-entering API keys.
        """
        with self._data_lock:
            src = (source_provider_id or "").strip()
            dst = (new_provider_id or "").strip()
            if not src or src not in self._providers:
                raise ValueError(f"Unknown source provider: {source_provider_id}")
            if not dst:
                raise ValueError("New provider id is required")
            if dst in self._providers:
                raise ValueError(f"Provider already exists: {dst}")

            src_cfg = self._providers[src].model_copy()
            new_cfg = src_cfg.model_copy()
            new_cfg.provider = dst
            # Ensure type remains the same; for built-ins provider_type==provider_id.
            new_cfg.provider_type = (src_cfg.provider_type or "").strip() or (
                src_cfg.provider or ""
            ).strip()
            if model is not None and str(model).strip():
                new_cfg.model = str(model).strip()
            if display_name is not None and str(display_name).strip():
                new_cfg.display_name = str(display_name).strip()
            new_cfg.last_updated = datetime.utcnow().isoformat()

            # Never clone global enabled flag into provider entry (enabled is global),
            # but keep the provider record consistent.
            new_cfg.enabled = bool(self._config.enabled)

            self._providers[dst] = new_cfg
            self._ensure_valid_default_selection_locked()
            self._save_config()

    def _ensure_valid_default_selection_locked(self) -> None:
        """Ensure the default purpose selection points to a usable configured provider.

        This is the long-term fix for corner cases where users configure only a Custom provider instance
        (or save without activation), leaving `purposes.default` pointing at an unconfigured built-in provider.

        Rule: If `default` is invalid AND there is exactly one provider with a non-empty model configured,
        auto-select it as the default (and let ai_now inherit unless explicitly set).

        Must be called with `self._data_lock` already held.
        """
        try:
            dprov = (self._purposes.get("default", {}) or {}).get(
                "provider"
            ) or self._active_provider
            dprov = (dprov or "").strip() if isinstance(dprov, str) else None
            dcfg = self._providers.get(dprov) if dprov else None
            dmodel = ((dcfg.model if dcfg else "") or "").strip()

            # Default is valid if it exists and has a model configured.
            default_valid = bool(dprov and dcfg and dmodel)

            if default_valid:
                return

            # Consider providers with an explicit model configured.
            candidates = [
                pid
                for pid, cfg in self._providers.items()
                if isinstance(pid, str)
                and pid.strip()
                and isinstance(cfg, RemoteLLMConfig)
                and ((cfg.model or "").strip() != "")
            ]

            if len(candidates) != 1:
                # If ambiguous (0 or >1), don't guess. UI should prompt user to select.
                return

            pid = candidates[0]
            cfg = self._providers.get(pid)
            if not cfg:
                return

            self._purposes["default"]["provider"] = pid
            self._purposes["default"]["model"] = (cfg.model or "").strip() or None
            self._active_provider = pid
            enabled = self._config.enabled
            self._config = cfg.model_copy()
            self._config.enabled = enabled
        except Exception:
            # Never let auto-repair break config loading/saving
            return


# Global instance
_config_manager: Optional[RemoteLLMConfigManager] = None


def get_config_manager() -> RemoteLLMConfigManager:
    """Get the global config manager instance.

    This is the main entry point for accessing LLM configuration.
    On first call, it creates the singleton instance and starts
    the file watcher for reactive startup support.
    """
    global _config_manager
    if _config_manager is None:
        logger.warning("[CONFIG] Creating RemoteLLMConfigManager singleton")
        _config_manager = RemoteLLMConfigManager.get_instance()
        # Start file watching for reactive startup
        logger.warning("[CONFIG] Starting file watcher for reactive startup")
        _config_manager.start_watching()
    return _config_manager
