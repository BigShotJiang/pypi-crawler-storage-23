"""Source synchronization to LanceDB search index.

Syncs source nodes and their chunks to the sources_index and
source_chunks_index tables for BM25 + vector search.
"""

from typing import List, TYPE_CHECKING

import structlog

from .tokenizers import detect_language, tokenize_for_fts
from .service_factory import get_search_index_service, get_bge_m3_service

if TYPE_CHECKING:
    from ...models.graph import SourceNode
    from ...services.source_chunker import SourceChunk

logger = structlog.get_logger(__name__)

# Max content length to store in source-level index (for large files,
# only store the summary + headings for BM25, not the full content)
MAX_SOURCE_CONTENT_LEN = 10000


async def sync_source_to_index(source: "SourceNode") -> bool:
    """Sync a source node to the sources_index table.

    Generates embedding from summary/title and upserts to LanceDB.
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.debug("Search services not available", source_id=source.id)
            return False

        # Semantic field for embedding: summary or title + first 500 chars
        summary = source.summary or ""
        semantic_field = f"{source.original_name}\n{summary}".strip()

        embedding = await bge_service.embed_text(semantic_field, is_query=False)

        # For BM25, index more content but truncate very large files
        content_for_fts = summary[:MAX_SOURCE_CONTENT_LEN] if summary else ""
        language_probe = f"{source.original_name or ''}\n{content_for_fts}".strip()
        detected_lang = detect_language(language_probe)

        record = {
            "id": source.id,
            "file_name": tokenize_for_fts(source.original_name or "", lang=detected_lang),
            "content": tokenize_for_fts(content_for_fts, lang=detected_lang),
            "summary": tokenize_for_fts(summary[:2000] if summary else "", lang=detected_lang),
            "file_type": _file_type_from_mime(source.mime_type),
            "mime_type": source.mime_type or "",
            "embedding": embedding,
            "size_bytes": source.size_bytes,
            "version": source.version,
            "source_type": source.source_type,
            "source_url": source.source_url or "",
            "memory_count": source.memory_count,
            "chunk_count": source.chunk_count,
            "lifecycle_state": source.lifecycle_state,
            "created_at": source.created_at,
            "updated_at": source.updated_at,
        }

        await search_service.upsert_source(source.id, record)
        logger.debug("Source synced to index", source_id=source.id)
        return True

    except Exception as e:
        logger.warning("Failed to sync source to index", source_id=source.id, error=str(e))
        return False


async def sync_source_chunks_to_index(
    source_id: str,
    chunks: List["SourceChunk"],
) -> int:
    """Sync source chunks to the source_chunks_index table.

    Each chunk gets its own embedding for fine-grained retrieval.

    Returns number of chunks synced.
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.debug("Search services not available", source_id=source_id)
            return 0

        from datetime import datetime, timezone

        # Detect source language once and reuse for all chunk FTS fields.
        # This avoids per-chunk fast-langdetect calls during large file indexing.
        sample_parts: List[str] = []
        for chunk in chunks[:8]:
            if chunk.heading_context:
                sample_parts.append(chunk.heading_context)
            if chunk.text:
                sample_parts.append(chunk.text[:200])
        source_lang = detect_language("\n".join(sample_parts))

        synced = 0
        for chunk in chunks:
            try:
                # Embed each chunk individually
                embed_text = f"{chunk.heading_context}\n{chunk.text}".strip() if chunk.heading_context else chunk.text
                embedding = await bge_service.embed_text(embed_text, is_query=False)

                chunk_id = f"{source_id}_chunk_{chunk.chunk_index}"
                record = {
                    "id": chunk_id,
                    "source_id": source_id,
                    "content": tokenize_for_fts(chunk.text, lang=source_lang),
                    "heading_context": tokenize_for_fts(chunk.heading_context, lang=source_lang),
                    "embedding": embedding,
                    "chunk_index": chunk.chunk_index,
                    "token_count": chunk.token_count,
                    "created_at": datetime.now(timezone.utc),
                }

                await search_service.upsert_source_chunk(chunk_id, record)
                synced += 1

            except Exception as e:
                logger.warning(
                    "Failed to sync chunk",
                    source_id=source_id,
                    chunk_index=chunk.chunk_index,
                    error=str(e),
                )

        logger.info("Synced source chunks", source_id=source_id, count=synced)
        return synced

    except Exception as e:
        logger.warning("Failed to sync source chunks", source_id=source_id, error=str(e))
        return 0


async def delete_source_from_index(source_id: str) -> bool:
    """Delete a source and its chunks from the search index."""
    try:
        search_service = await get_search_index_service()
        if not search_service:
            return False

        # Delete source-level record
        await search_service.delete_source(source_id)

        # Delete all chunks for this source
        await search_service.delete_source_chunks(source_id)

        logger.info("Deleted source from index", source_id=source_id)
        return True

    except Exception as e:
        logger.warning("Failed to delete source from index", source_id=source_id, error=str(e))
        return False


def _file_type_from_mime(mime_type: str | None) -> str:
    """Extract simple file type from MIME type."""
    if not mime_type:
        return "unknown"
    mime_map = {
        "application/pdf": "pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
        "text/html": "html",
        "text/markdown": "markdown",
        "text/plain": "text",
        "text/csv": "csv",
    }
    return mime_map.get(mime_type, mime_type.split("/")[-1])
