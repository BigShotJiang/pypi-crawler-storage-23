"""CRUD operations for search index tables."""

import asyncio
from typing import List

import structlog

logger = structlog.get_logger(__name__)


class CRUDOperations:
    """Handles CRUD operations for search index tables."""

    def __init__(self, db, index_manager):
        """Initialize CRUD operations."""
        self.db = db
        self.index_manager = index_manager

    async def upsert(self, table_name: str, record_id: str, data: dict) -> None:
        """Generic upsert: delete existing + insert new."""
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        try:
            await loop.run_in_executor(
                None, lambda: table.delete(f"id = '{record_id}'")
            )
        except Exception:
            pass
        await loop.run_in_executor(None, lambda: table.add([data]))
        self.index_manager.mark_index_dirty(table_name)

    async def delete(self, table_name: str, record_id: str) -> None:
        """Generic delete by id."""
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        try:
            await loop.run_in_executor(
                None, lambda: table.delete(f"id = '{record_id}'")
            )
            self.index_manager.mark_index_dirty(table_name)
        except Exception as e:
            logger.warning(f"Delete failed on {table_name}", id=record_id, error=str(e))

    async def batch_upsert(self, table_name: str, records: List[dict]) -> int:
        """Generic batch upsert."""
        if not records:
            return 0

        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        ids_str = ", ".join(f"'{r['id']}'" for r in records)
        try:
            await loop.run_in_executor(
                None, lambda: table.delete(f"id IN ({ids_str})")
            )
        except Exception:
            pass
        await loop.run_in_executor(None, lambda: table.add(records))
        self.index_manager.mark_index_dirty(table_name)
        return len(records)

    async def delete_messages_by_thread(self, thread_id: str) -> int:
        """Delete all messages for a thread."""
        table = self.db.open_table(self.index_manager.TABLE_MESSAGES)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        try:
            count = await loop.run_in_executor(
                None,
                lambda: len(
                    table.search()
                    .where(f"thread_id = '{thread_id}'")
                    .limit(10000)
                    .to_list()
                ),
            )
            await loop.run_in_executor(
                None, lambda: table.delete(f"thread_id = '{thread_id}'")
            )
            if count > 0:
                self.index_manager.mark_index_dirty(self.index_manager.TABLE_MESSAGES)
            return count
        except Exception as e:
            logger.warning(
                "Failed to delete thread messages", thread_id=thread_id, error=str(e)
            )
            return 0

    async def delete_by_filter(self, table_name: str, where: str) -> int:
        """Delete records matching a SQL filter expression."""
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()
        try:
            count = await loop.run_in_executor(
                None,
                lambda: len(
                    table.search()
                    .where(where)
                    .limit(10000)
                    .to_list()
                ),
            )
            await loop.run_in_executor(None, lambda: table.delete(where))
            if count > 0:
                self.index_manager.mark_index_dirty(table_name)
            return count
        except Exception as e:
            logger.warning(f"Delete by filter failed on {table_name}", where=where, error=str(e))
            return 0

    async def clear_communities(self) -> None:
        """Clear all communities from the search index."""
        table = self.db.open_table(
            self.index_manager.TABLE_COMMUNITIES
        )  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, lambda: table.delete("id IS NOT NULL"))
            self.index_manager.mark_index_dirty(self.index_manager.TABLE_COMMUNITIES)
            logger.info("Cleared all communities from search index")
        except Exception as e:
            logger.warning("Failed to clear communities", error=str(e))

    async def clear_table(self, table_name: str) -> None:
        """Clear all records from a table by deleting rows with non-null IDs."""
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, lambda: table.delete("id IS NOT NULL"))
            self.index_manager.mark_index_dirty(table_name)
            logger.info("Cleared search index table", table=table_name)
        except Exception as e:
            logger.warning("Failed to clear search index table", table=table_name, error=str(e))
