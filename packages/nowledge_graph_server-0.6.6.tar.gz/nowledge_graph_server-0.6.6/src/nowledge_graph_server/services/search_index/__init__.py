"""Search index service using LanceDB for vector + FTS hybrid search.

This module provides a secondary search index that complements the primary
Kuzu graph database. It handles:
- Vector search with BGE-M3 embeddings (1024-dim)
- BM25 full-text search via Tantivy
- Hybrid search with RRF (Reciprocal Rank Fusion)

The Kuzu graph database remains the source of truth for:
- Relationships (MENTIONS, RELATES_TO, etc.)
- Graph algorithms (Louvain, PageRank)
- Entity and community structure
"""

from .service import SearchIndexService
from .models import (
    MemoryIndexRecord,
    MessageIndexRecord,
    CommunityIndexRecord,
    EntityIndexRecord,
    SearchResult,
)
from .sync import (
    # Service getters
    get_search_index_service,
    get_search_embedding_service,
    get_bge_m3_service,  # Backward compatibility alias
    is_search_index_available,
    get_search_index_status_info,
    # Memory sync
    sync_memory_to_index,
    sync_memories_batch,
    delete_memory_from_index,
    # Message sync
    sync_message_to_index,
    sync_messages_batch,
    delete_message_from_index,
    delete_thread_messages_from_index,
    # Community sync
    sync_community_to_index,
    delete_community_from_index,
    clear_communities_from_index,
    # Entity sync
    sync_entity_to_index,
    sync_entities_batch,
    delete_entity_from_index,
    # Full reindex
    full_reindex_from_kuzu,
    cleanup_services,
)

__all__ = [
    # Core service
    "SearchIndexService",
    # Models
    "MemoryIndexRecord",
    "MessageIndexRecord",
    "CommunityIndexRecord",
    "EntityIndexRecord",
    "SearchResult",
    # Service getters
    "get_search_index_service",
    "get_search_embedding_service",
    "get_bge_m3_service",  # Backward compatibility alias
    "is_search_index_available",
    "get_search_index_status_info",
    # Memory sync
    "sync_memory_to_index",
    "sync_memories_batch",
    "delete_memory_from_index",
    # Message sync
    "sync_message_to_index",
    "sync_messages_batch",
    "delete_message_from_index",
    "delete_thread_messages_from_index",
    # Community sync
    "sync_community_to_index",
    "delete_community_from_index",
    "clear_communities_from_index",
    # Entity sync
    "sync_entity_to_index",
    "sync_entities_batch",
    "delete_entity_from_index",
    # Full reindex
    "full_reindex_from_kuzu",
    "cleanup_services",
]
