"""Message synchronization to search index."""

from datetime import datetime, timezone
from typing import Any, Dict, List

import structlog

from .models import MessageIndexRecord
from .tokenizers import tokenize_for_fts
from .service_factory import get_search_index_service
from .schemas import EMBEDDING_DIMENSION

logger = structlog.get_logger(__name__)


async def sync_message_to_index(
    message_id: str,
    thread_id: str,
    content: str,
    role: str,
    order_index: int = 0,
    created_at: datetime = None,
) -> bool:
    """Sync a thread message to the search index.

    Note: Thread/message search uses FTS-only (not hybrid), so we don't generate
    embeddings for messages. The embedding field is left empty for future use.

    Args:
        message_id: Message ID
        thread_id: Parent thread ID
        content: Message content
        role: Message role (user, assistant, system)
        order_index: Position in thread
        created_at: Creation timestamp

    Returns:
        True if synced successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        # Thread search is FTS-only, so we use empty embedding
        # (embedding field kept for future hybrid search support)
        empty_embedding = [0.0] * EMBEDDING_DIMENSION

        # Create index record with tokenized content for FTS
        record = MessageIndexRecord(
            id=message_id,
            thread_id=thread_id,
            content=tokenize_for_fts(content),
            role=role,
            embedding=empty_embedding,
            order_index=order_index,
            created_at=created_at or datetime.now(timezone.utc),
        )

        await search_service.upsert_message(record)

        logger.debug(
            "Message synced to search index (FTS-only)",
            message_id=message_id,
            thread_id=thread_id,
        )
        return True

    except Exception as e:
        logger.warning(
            "Failed to sync message to search index",
            message_id=message_id,
            error=str(e),
        )
        return False


async def sync_messages_batch(messages: List[Dict[str, Any]]) -> int:
    """Batch sync messages to the search index.

    Note: Thread/message search uses FTS-only (not hybrid), so we don't generate
    embeddings for messages. The embedding field is left empty for future use.

    Args:
        messages: List of message dicts with id, thread_id, content, role, order_index, created_at

    Returns:
        Number of successfully synced messages
    """
    if not messages:
        return 0

    try:
        search_service = await get_search_index_service()

        if not search_service:
            return 0

        # Thread search is FTS-only, so we use empty embeddings
        # (embedding field kept for future hybrid search support)
        empty_embedding = [0.0] * EMBEDDING_DIMENSION

        # Create records with empty embeddings and tokenized content
        records = []
        for msg in messages:
            records.append(
                MessageIndexRecord(
                    id=msg["id"],
                    thread_id=msg["thread_id"],
                    content=tokenize_for_fts(msg.get("content", "")),
                    role=msg.get("role", "user"),
                    embedding=empty_embedding,
                    order_index=msg.get("order_index", 0),
                    created_at=msg.get("created_at"),
                )
            )

        count = await search_service.batch_upsert_messages(records)

        logger.info(
            "Batch synced messages to search index (FTS-only)",
            count=count,
            total=len(messages),
        )
        return count

    except Exception as e:
        logger.warning(
            "Failed to batch sync messages to search index",
            count=len(messages),
            error=str(e),
        )
        return 0


async def delete_message_from_index(message_id: str) -> bool:
    """Delete a message from the search index.

    Args:
        message_id: ID of message to delete

    Returns:
        True if deleted successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        await search_service.delete_message(message_id)
        return True

    except Exception as e:
        logger.warning(
            "Failed to delete message from search index",
            message_id=message_id,
            error=str(e),
        )
        return False


async def delete_thread_messages_from_index(thread_id: str) -> int:
    """Delete all messages for a thread from the search index.

    Args:
        thread_id: Thread ID

    Returns:
        Number of messages deleted
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return 0

        count = await search_service.delete_messages_by_thread(thread_id)
        return count

    except Exception as e:
        logger.warning(
            "Failed to delete thread messages from search index",
            thread_id=thread_id,
            error=str(e),
        )
        return 0
