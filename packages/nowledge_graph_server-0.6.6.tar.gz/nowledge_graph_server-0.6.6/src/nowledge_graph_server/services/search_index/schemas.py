"""Schema definitions for LanceDB search index tables."""

import pyarrow as pa

# Embedding dimension for Qwen3-Embedding (MLX) / BGE-M3 (ONNX)
EMBEDDING_DIMENSION = 1024


def memories_schema() -> pa.Schema:
    """Schema for memories_index table."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("title", pa.string()),
        pa.field("content", pa.string()),
        pa.field("semantic_field", pa.string()),
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("importance", pa.float64()),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
        pa.field("updated_at", pa.timestamp("us", tz="UTC")),
        # v0.6 Knowledge Agent fields — used for search scoring boosts
        pa.field("is_latest", pa.bool_()),
        pa.field("is_crystal", pa.bool_()),
        pa.field("unit_type", pa.string()),
    ])


def messages_schema() -> pa.Schema:
    """Schema for messages_index table."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("thread_id", pa.string()),
        pa.field("content", pa.string()),
        pa.field("role", pa.string()),
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("order_index", pa.int32()),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
    ])


def communities_schema() -> pa.Schema:
    """Schema for communities_index table."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("community_id", pa.int64()),  # Louvain algorithm ID
        pa.field("name", pa.string()),
        pa.field("description", pa.string()),
        pa.field("ai_summary", pa.string()),
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("member_count", pa.int32()),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
    ])


def entities_schema() -> pa.Schema:
    """Schema for entities_index table."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("name", pa.string()),
        pa.field("description", pa.string()),
        pa.field("entity_type", pa.string()),
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
    ])


def sources_schema() -> pa.Schema:
    """Schema for sources_index table (source-level search)."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("file_name", pa.string()),
        pa.field("content", pa.string()),  # Full parsed markdown or summary for large files
        pa.field("summary", pa.string()),
        pa.field("file_type", pa.string()),  # "pdf", "docx", "url"
        pa.field("mime_type", pa.string()),
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("size_bytes", pa.int64()),
        pa.field("version", pa.int32()),
        pa.field("source_type", pa.string()),  # "file", "url", "obsidian_note"
        pa.field("source_url", pa.string()),
        pa.field("memory_count", pa.int64()),
        pa.field("chunk_count", pa.int64()),
        pa.field("lifecycle_state", pa.string()),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
        pa.field("updated_at", pa.timestamp("us", tz="UTC")),
    ])


def source_chunks_schema() -> pa.Schema:
    """Schema for source_chunks_index table (chunk-level search)."""
    return pa.schema([
        pa.field("id", pa.string()),
        pa.field("source_id", pa.string()),
        pa.field("content", pa.string()),
        pa.field("heading_context", pa.string()),  # "§3.2 Authentication"
        pa.field("embedding", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
        pa.field("chunk_index", pa.int32()),
        pa.field("token_count", pa.int32()),
        pa.field("created_at", pa.timestamp("us", tz="UTC")),
    ])
