"""Search index synchronization utilities.

This module provides functions to sync data between Kuzu (source of truth)
and the LanceDB search index. It handles:
- Memory CRUD sync
- Thread/Message CRUD sync
- Community sync
- Entity sync
- Platform-specific search embedding generation (MLX on macOS Apple Silicon, ONNX on non-Apple-Silicon)
"""

# Re-export all sync functions for backward compatibility
from .service_factory import (
    get_search_index_service,
    get_search_embedding_service,
    get_bge_m3_service,
    is_search_index_available,
    get_search_index_status_info,
    cleanup_services,
)
from .memory_sync import (
    sync_memory_to_index,
    sync_memories_batch,
    delete_memory_from_index,
)
from .message_sync import (
    sync_message_to_index,
    sync_messages_batch,
    delete_message_from_index,
    delete_thread_messages_from_index,
)
from .community_sync import (
    sync_community_to_index,
    delete_community_from_index,
    clear_communities_from_index,
)
from .entity_sync import (
    sync_entity_to_index,
    sync_entities_batch,
    delete_entity_from_index,
)
from .reindex import full_reindex_from_kuzu

__all__ = [
    # Service factory
    "get_search_index_service",
    "get_search_embedding_service",
    "get_bge_m3_service",
    "is_search_index_available",
    "get_search_index_status_info",
    "cleanup_services",
    # Memory sync
    "sync_memory_to_index",
    "sync_memories_batch",
    "delete_memory_from_index",
    # Message sync
    "sync_message_to_index",
    "sync_messages_batch",
    "delete_message_from_index",
    "delete_thread_messages_from_index",
    # Community sync
    "sync_community_to_index",
    "delete_community_from_index",
    "clear_communities_from_index",
    # Entity sync
    "sync_entity_to_index",
    "sync_entities_batch",
    "delete_entity_from_index",
    # Reindex
    "full_reindex_from_kuzu",
]
