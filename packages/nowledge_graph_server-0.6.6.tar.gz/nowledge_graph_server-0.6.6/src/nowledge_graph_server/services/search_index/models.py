"""Data models for the search index."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any


@dataclass
class MemoryIndexRecord:
    """Record for memory in the search index."""

    id: str  # Primary key, matches Kuzu Memory.id
    title: str
    content: str
    semantic_field: str  # title + "\n" + content (for FTS)
    embedding: List[float]  # BGE-M3 1024-dim embedding
    importance: float = 0.5
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    # Knowledge Agent fields (v0.6) — used for search scoring boosts
    is_latest: bool = True
    is_crystal: bool = False
    unit_type: str = "fact"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LanceDB insertion."""
        return {
            "id": self.id,
            "title": self.title or "",
            "content": self.content or "",
            "semantic_field": self.semantic_field or "",
            "embedding": self.embedding,
            "importance": self.importance,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "is_latest": self.is_latest,
            "is_crystal": self.is_crystal,
            "unit_type": self.unit_type,
        }


@dataclass
class MessageIndexRecord:
    """Record for thread message in the search index."""

    id: str  # Primary key, matches Kuzu Message.id
    thread_id: str  # Foreign key to Thread
    content: str
    role: str  # user, assistant, system
    embedding: List[float]  # BGE-M3 1024-dim embedding
    order_index: int = 0
    created_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LanceDB insertion."""
        return {
            "id": self.id,
            "thread_id": self.thread_id,
            "content": self.content or "",
            "role": self.role or "user",
            "embedding": self.embedding,
            "order_index": self.order_index,
            "created_at": self.created_at,
        }


@dataclass
class CommunityIndexRecord:
    """Record for community in the search index."""

    id: str  # Primary key, matches Kuzu Community.id (UUID string)
    community_id: int  # Louvain algorithm community ID (INT64) - used for graph traversal
    name: str
    description: str
    ai_summary: str
    embedding: List[float]  # BGE-M3 1024-dim embedding (of ai_summary)
    member_count: int = 0
    created_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LanceDB insertion."""
        return {
            "id": self.id,
            "community_id": self.community_id,
            "name": self.name or "",
            "description": self.description or "",
            "ai_summary": self.ai_summary or "",
            "embedding": self.embedding,
            "member_count": self.member_count,
            "created_at": self.created_at,
        }


@dataclass
class EntityIndexRecord:
    """Record for entity in the search index."""

    id: str  # Primary key, matches Kuzu Entity.id
    name: str
    description: str
    entity_type: str
    embedding: List[float]  # BGE-M3 1024-dim embedding
    created_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LanceDB insertion."""
        return {
            "id": self.id,
            "name": self.name or "",
            "description": self.description or "",
            "entity_type": self.entity_type or "",
            "embedding": self.embedding,
            "created_at": self.created_at,
        }


@dataclass
class SearchResult:
    """Result from a search operation."""

    id: str
    score: float  # Combined score from hybrid search
    vector_score: Optional[float] = None  # Raw vector similarity
    fts_score: Optional[float] = None  # Raw FTS/BM25 score
    data: Dict[str, Any] = field(default_factory=dict)  # Full record data

    def __repr__(self) -> str:
        return f"SearchResult(id={self.id}, score={self.score:.4f})"
