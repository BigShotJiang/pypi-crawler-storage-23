"""Community synchronization to search index."""

from datetime import datetime, timezone
from typing import Optional

import structlog

from .models import CommunityIndexRecord
from .tokenizers import detect_language, tokenize_for_fts
from .service_factory import get_search_index_service, get_bge_m3_service

logger = structlog.get_logger(__name__)


async def sync_community_to_index(
    id: str,
    community_id: int,
    name: str,
    description: str,
    ai_summary: str,
    member_count: int = 0,
    created_at: Optional[datetime] = None,
) -> bool:
    """Sync a community to the search index.

    Uses the AI summary for embedding generation.

    Args:
        id: Community UUID (primary key)
        community_id: Louvain algorithm community ID (INT64) - used for graph traversal
        name: Community name
        description: Community description
        ai_summary: AI-generated summary (used for embedding)
        member_count: Number of members
        created_at: Creation timestamp

    Returns:
        True if synced successfully
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return False

        # Generate embedding from AI summary (most semantically rich)
        # is_query=False since this is a document to be indexed
        embedding_text = ai_summary or f"{name}: {description}"
        logger.debug("Generating embedding for community", id=id, name=name)
        embedding = await bge_service.embed_text(embedding_text, is_query=False)
        detected_lang = detect_language(embedding_text)

        # Create record with tokenized text for FTS
        record = CommunityIndexRecord(
            id=id,
            community_id=community_id,
            name=tokenize_for_fts(name, lang=detected_lang),
            description=tokenize_for_fts(description, lang=detected_lang),
            ai_summary=tokenize_for_fts(ai_summary, lang=detected_lang),
            embedding=embedding,
            member_count=member_count,
            created_at=created_at or datetime.now(timezone.utc),
        )

        await search_service.upsert_community(record)

        logger.debug(
            "Community synced to search index",
            id=id,
            community_id=community_id,
            name=name,
        )
        return True

    except Exception as e:
        logger.warning(
            "Failed to sync community to search index",
            id=id,
            community_id=community_id,
            error=str(e),
        )
        return False


async def delete_community_from_index(community_id: str) -> bool:
    """Delete a community from the search index.

    Args:
        community_id: ID of community to delete

    Returns:
        True if deleted successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        await search_service.delete_community(community_id)
        return True

    except Exception as e:
        logger.warning(
            "Failed to delete community from search index",
            community_id=community_id,
            error=str(e),
        )
        return False


async def clear_communities_from_index() -> bool:
    """Clear all communities from the search index.

    Used before re-running community detection.

    Returns:
        True if cleared successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        await search_service.clear_communities()
        return True

    except Exception as e:
        logger.warning(
            "Failed to clear communities from search index",
            error=str(e),
        )
        return False
