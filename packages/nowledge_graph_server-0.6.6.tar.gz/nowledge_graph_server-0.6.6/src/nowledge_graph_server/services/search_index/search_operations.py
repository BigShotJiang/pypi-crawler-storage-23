"""Search operations: hybrid, FTS, and vector search."""

import asyncio
from typing import Dict, List, Optional

import structlog

from .models import SearchResult
from .tokenizers import tokenize_for_fts, sanitize_fts_query

logger = structlog.get_logger(__name__)


class SearchOperations:
    """Handles search operations: hybrid, FTS, and vector search."""

    def __init__(self, db, index_manager, fts_manager):
        """Initialize search operations."""
        self.db = db
        self.index_manager = index_manager
        self.fts_manager = fts_manager

    async def search_hybrid(
        self,
        table_name: str,
        query_text: str,
        query_embedding: List[float],
        limit: int,
        where_clause: Optional[str] = None,
    ) -> List[SearchResult]:
        """Hybrid search with objective scoring.

        Key design decisions:
        1. Objective L2 distance scores: Preserves true semantic similarity
        2. FTS-aware fusion: No penalty when FTS can't work (non-Latin scripts)
        3. Short query handling: Done at embedding layer (HyDE-lite), not here

        This gives us actual separate scores for vector and FTS, unlike LanceDB's
        built-in hybrid which only returns a combined RRF score.
        """
        # Ensure FTS index is fresh before searching
        await self.index_manager.ensure_index_fresh()
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        try:
            # Run vector search
            vector_search = table.search(query_embedding)
            if where_clause:
                vector_search = vector_search.where(where_clause)
            vector_results = await loop.run_in_executor(
                None, lambda: vector_search.limit(limit * 2).to_list()
            )

            # Run FTS search (sanitize special chars + tokenize for CJK support)
            tokenized_query = sanitize_fts_query(tokenize_for_fts(query_text))
            try:
                fts_search = table.search(tokenized_query, query_type="fts")
                if where_clause:
                    fts_search = fts_search.where(where_clause)
                fts_results = await loop.run_in_executor(
                    None, lambda: fts_search.limit(limit * 2).to_list()
                )
            except Exception as fts_error:
                logger.warning(
                    f"FTS search failed on {table_name}, falling back to vector-only",
                    error=str(fts_error),
                    query=tokenized_query[:50],
                )
                fts_results = []

            # Build vector score map with OBJECTIVE L2 distance scoring
            vector_scores: Dict[str, float] = {}
            vector_data: Dict[str, dict] = {}

            for r in vector_results:
                rid = r["id"]
                # Convert L2 distance to similarity (objective score)
                # L2 distance for normalized vectors: 0 (identical) to 2 (opposite)
                # Similarity = 1 - (distance / 2), clamped to [0, 1]
                distance = r.get("_distance", 0.0)
                similarity = max(0.0, 1.0 - (distance / 2.0))
                vector_scores[rid] = similarity
                vector_data[rid] = dict(r)

            # Build FTS score map (normalized to max for comparability)
            fts_scores: Dict[str, float] = {}
            fts_data: Dict[str, dict] = {}

            if fts_results:
                max_fts = max(r.get("_score", 0.0) for r in fts_results) or 1.0
                for r in fts_results:
                    rid = r["id"]
                    fts_scores[rid] = r.get("_score", 0.0) / max_fts
                    fts_data[rid] = dict(r)

            # Determine if FTS is functional for this query
            # If FTS returns 0, don't penalize vector-only results (non-Latin scripts)
            fts_functional = len(fts_scores) > 0

            # Combine results
            all_ids = set(vector_scores.keys()) | set(fts_scores.keys())
            results = []

            for rid in all_ids:
                v_score = vector_scores.get(rid, 0.0)
                f_score = fts_scores.get(rid, 0.0)

                if v_score > 0 and f_score > 0:
                    # Both matched - weighted sum with boost
                    combined = v_score * 0.6 + f_score * 0.4
                    combined *= 1.1  # 10% boost for dual-match
                elif v_score > 0:
                    # Vector only
                    if fts_functional:
                        # FTS worked but didn't match - slight concern
                        combined = v_score * 0.95
                    else:
                        # FTS couldn't work (non-Latin) - full vector score
                        combined = v_score
                else:
                    # FTS only - vector didn't find it similar
                    combined = f_score * 0.7

                data = vector_data.get(rid) or fts_data.get(rid, {})
                results.append(
                    SearchResult(
                        id=rid,
                        score=min(combined, 0.99),
                        vector_score=v_score,
                        fts_score=f_score,
                        data=data,
                    )
                )

            # Sort by combined score
            results.sort(key=lambda x: x.score, reverse=True)

            # Log score distribution
            logger.debug(
                f"Hybrid search on {table_name}",
                query_len=len(query_text),
                vector_count=len(vector_scores),
                fts_count=len(fts_scores),
                fts_functional=fts_functional,
                top_scores=[
                    (r.score, r.vector_score, r.fts_score) for r in results[:3]
                ]
                if results
                else [],
            )

            return results[:limit]

        except Exception as e:
            logger.error(f"Hybrid search failed on {table_name}", error=str(e))
            return []

    async def search_fts(
        self,
        table_name: str,
        query_text: str,
        limit: int,
        where_clause: Optional[str] = None,
    ) -> List[SearchResult]:
        """Generic FTS-only search."""
        # Ensure FTS index is fresh before searching
        await self.index_manager.ensure_index_fresh()
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        # Sanitize special chars + tokenize for CJK support
        tokenized_query = sanitize_fts_query(tokenize_for_fts(query_text))

        async def run_search() -> List[dict]:
            current_table = self.db.open_table(table_name)  # type: ignore[union-attr]
            search = current_table.search(tokenized_query, query_type="fts")
            if where_clause:
                search = search.where(where_clause)
            return await loop.run_in_executor(
                None, lambda: search.limit(limit).to_list()
            )

        try:
            results = await run_search()
        except Exception as e:
            error_message = str(e)
            logger.error(f"FTS search failed on {table_name}", error=error_message)
            if "Added column's length must match table's length" in error_message:
                logger.warning(
                    "FTS index out of sync; rebuilding and retrying",
                    table=table_name,
                )
                try:
                    await self.fts_manager.rebuild_fts_index(table_name)
                    results = await run_search()
                except Exception as rebuild_error:
                    logger.warning(
                        "FTS rebuild retry failed",
                        table=table_name,
                        error=str(rebuild_error),
                    )
                    return []
            else:
                return []

        if not results:
            return []

        max_score = max(r.get("_score", 0.0) for r in results) or 1.0
        return [
            SearchResult(
                id=r["id"],
                score=r.get("_score", 0.0) / max_score if max_score > 0 else 0.0,
                fts_score=r.get("_score", 0.0),
                data={**dict(r), "_rank": i + 1},
            )
            for i, r in enumerate(results)
        ]

    async def search_vector(
        self,
        table_name: str,
        query_embedding: List[float],
        limit: int,
    ) -> List[SearchResult]:
        """Generic vector-only search."""
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        loop = asyncio.get_event_loop()

        results = await loop.run_in_executor(
            None, lambda: table.search(query_embedding).limit(limit).to_list()
        )

        return [
            SearchResult(
                id=r["id"],
                # Convert L2 distance to similarity: 0 (identical) to 2 (opposite)
                score=max(0.0, 1.0 - (r.get("_distance", 0.0) / 2.0)),
                vector_score=max(0.0, 1.0 - (r.get("_distance", 0.0) / 2.0)),
                data=dict(r),
            )
            for r in results
        ]
