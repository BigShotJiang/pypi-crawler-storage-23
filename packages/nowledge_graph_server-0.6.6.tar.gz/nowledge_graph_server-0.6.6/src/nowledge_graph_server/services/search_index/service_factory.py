"""Singleton factory for search index and embedding services."""

import asyncio
from typing import Optional, TYPE_CHECKING

import structlog

from .service import SearchIndexService

if TYPE_CHECKING:
    from ..search_embedding import SearchEmbeddingService

logger = structlog.get_logger(__name__)

# Singleton instances for the services
_search_index_service: Optional[SearchIndexService] = None
_search_embedding_service: Optional["SearchEmbeddingService"] = None
_initialization_lock = asyncio.Lock()


async def get_search_index_service() -> Optional[SearchIndexService]:
    """Get or create the singleton SearchIndexService.

    Returns:
        SearchIndexService instance or None if not available
    """
    global _search_index_service

    if _search_index_service is not None and _search_index_service._initialized:
        return _search_index_service

    async with _initialization_lock:
        if _search_index_service is not None and _search_index_service._initialized:
            return _search_index_service

        try:
            from ...config import get_settings

            settings = get_settings()
            # Place search index next to the database file
            index_path = settings.database_path.parent / "search_index"

            logger.info(
                "Initializing search index service",
                database_path=str(settings.database_path),
                index_path=str(index_path),
            )

            _search_index_service = SearchIndexService(index_path)
            await _search_index_service.initialize()

            logger.info(
                "Search index service initialized",
                path=str(index_path),
            )
            return _search_index_service

        except Exception as e:
            import traceback
            logger.warning(
                "Failed to initialize search index service",
                error=str(e),
                traceback=traceback.format_exc(),
            )
            return None


async def get_search_embedding_service() -> Optional["SearchEmbeddingService"]:
    """Get or create the singleton SearchEmbeddingService.

    Uses platform-specific models:
    - macOS Apple Silicon: Qwen3-Embedding via mlx-embeddings
    - non-Apple-Silicon (Windows/Linux/macOS Intel): BGE-M3 via FastEmbed/ONNX

    Returns:
        SearchEmbeddingService instance or None if not available
    """
    global _search_embedding_service

    if _search_embedding_service is not None and _search_embedding_service._initialized:
        return _search_embedding_service

    async with _initialization_lock:
        if _search_embedding_service is not None and _search_embedding_service._initialized:
            return _search_embedding_service

        try:
            from ..search_embedding import SearchEmbeddingService, check_search_model_exists

            # Check if model is cached
            if not check_search_model_exists():
                logger.info(
                    "Search embedding model not cached, search index sync disabled. "
                    "User should download the model to enable hybrid search."
                )
                return None

            _search_embedding_service = SearchEmbeddingService(cache_only=True)
            await _search_embedding_service.initialize()

            logger.info(
                "Search embedding service initialized for search index",
                model=_search_embedding_service.model_name,
                backend=_search_embedding_service._backend,
            )
            return _search_embedding_service

        except Exception as e:
            logger.warning(
                "Failed to initialize search embedding service",
                error=str(e),
            )
            return None


# Backward compatibility alias
async def get_bge_m3_service() -> Optional["SearchEmbeddingService"]:
    """Alias for get_search_embedding_service() for backward compatibility."""
    return await get_search_embedding_service()


def is_search_index_available() -> bool:
    """Check if search index is available and initialized."""
    return (
        _search_index_service is not None
        and _search_index_service._initialized
        and _search_embedding_service is not None
        and _search_embedding_service._initialized
    )


def get_search_index_status_info() -> dict:
    """Get detailed status information about the search index.

    Returns:
        Dict with status information:
        - available: bool - whether hybrid search is fully available
        - model_cached: bool - whether search model is cached locally
        - embedding_service_initialized: bool - whether embedding service is initialized
        - search_index_initialized: bool - whether LanceDB index is initialized
        - model_info: dict - model name, backend, and size info
        - message: str - user-friendly status message
    """
    from ..search_embedding import check_search_model_exists, get_search_model_info

    model_cached = check_search_model_exists()
    embedding_initialized = (
        _search_embedding_service is not None
        and _search_embedding_service._initialized
    )
    index_initialized = (
        _search_index_service is not None and _search_index_service._initialized
    )
    model_info = get_search_model_info()

    # Determine overall status
    if model_cached and embedding_initialized and index_initialized:
        message = "Hybrid search is available and ready."
        available = True
    elif model_cached and not embedding_initialized:
        message = (
            f"{model_info['model_name']} is cached but not loaded. "
            "The service will initialize on first search request."
        )
        available = False
    elif model_cached and embedding_initialized and not index_initialized:
        message = (
            f"{model_info['model_name']} is loaded but search index not initialized. "
            "The index will be created on first use."
        )
        available = False
    elif not model_cached:
        message = (
            f"Search embedding model not installed. "
            f"Download it from Settings > Search Index to enable hybrid search (~{model_info['estimated_size_mb']}MB)."
        )
        available = False
    else:
        message = "Search index status unknown."
        available = False

    return {
        "available": available,
        "model_cached": model_cached,
        "embedding_service_initialized": embedding_initialized,
        "search_index_initialized": index_initialized,
        "model_info": model_info,
        "message": message,
        # Backward compatibility aliases
        "bge_m3_model_cached": model_cached,
        "bge_m3_service_initialized": embedding_initialized,
    }


async def cleanup_services() -> None:
    """Cleanup search index services."""
    global _search_index_service, _search_embedding_service

    if _search_index_service:
        await _search_index_service.cleanup()
        _search_index_service = None

    if _search_embedding_service:
        await _search_embedding_service.cleanup()
        _search_embedding_service = None

    logger.info("Search index sync services cleaned up")
