"""Entity synchronization to search index."""

from typing import List, TYPE_CHECKING

import structlog

from .models import EntityIndexRecord
from .tokenizers import detect_language, tokenize_for_fts
from .service_factory import get_search_index_service, get_bge_m3_service

if TYPE_CHECKING:
    from ...models.graph import EntityNode

logger = structlog.get_logger(__name__)


async def sync_entity_to_index(entity: "EntityNode") -> bool:
    """Sync an entity to the search index.

    Args:
        entity: EntityNode to sync

    Returns:
        True if synced successfully
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return False

        # Generate embedding from name + description (is_query=False for indexing)
        embedding_text = f"{entity.name}: {entity.description or ''}"
        embedding = await bge_service.embed_text(embedding_text, is_query=False)
        detected_lang = detect_language(embedding_text)

        # Create record with tokenized text for FTS
        record = EntityIndexRecord(
            id=entity.id,
            name=tokenize_for_fts(entity.name, lang=detected_lang),
            description=tokenize_for_fts(entity.description or "", lang=detected_lang),
            entity_type=entity.entity_type or "",
            embedding=embedding,
            created_at=entity.created_at,
        )

        await search_service.upsert_entity(record)

        logger.debug(
            "Entity synced to search index",
            entity_id=entity.id,
            name=entity.name,
        )
        return True

    except Exception as e:
        logger.warning(
            "Failed to sync entity to search index",
            entity_id=entity.id,
            error=str(e),
        )
        return False


async def sync_entities_batch(entities: List["EntityNode"]) -> int:
    """Batch sync entities to the search index.

    Args:
        entities: List of EntityNode objects

    Returns:
        Number of successfully synced entities
    """
    if not entities:
        return 0

    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            return 0

        # Generate embeddings (is_query=False for indexing)
        texts = [f"{e.name}: {e.description or ''}" for e in entities]
        logger.info("Generating embeddings for entities", count=len(texts))
        embeddings = await bge_service.embed_batch(texts, is_query=False)
        logger.info(
            "Generated embeddings for entities",
            count=len(embeddings),
            dim=len(embeddings[0]) if embeddings else 0,
        )

        # Create records with tokenized text for FTS
        records = []
        for entity, embedding in zip(entities, embeddings):
            embedding_text = f"{entity.name}: {entity.description or ''}"
            detected_lang = detect_language(embedding_text)
            records.append(
                EntityIndexRecord(
                    id=entity.id,
                    name=tokenize_for_fts(entity.name, lang=detected_lang),
                    description=tokenize_for_fts(entity.description or "", lang=detected_lang),
                    entity_type=entity.entity_type or "",
                    embedding=embedding,
                    created_at=entity.created_at,
                )
            )

        count = await search_service.batch_upsert_entities(records)

        logger.info(
            "Batch synced entities to search index",
            count=count,
            total=len(entities),
        )
        return count

    except Exception as e:
        logger.warning(
            "Failed to batch sync entities to search index",
            count=len(entities),
            error=str(e),
        )
        return 0


async def delete_entity_from_index(entity_id: str) -> bool:
    """Delete an entity from the search index.

    Args:
        entity_id: ID of entity to delete

    Returns:
        True if deleted successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        await search_service.delete_entity(entity_id)
        return True

    except Exception as e:
        logger.warning(
            "Failed to delete entity from search index",
            entity_id=entity_id,
            error=str(e),
        )
        return False
