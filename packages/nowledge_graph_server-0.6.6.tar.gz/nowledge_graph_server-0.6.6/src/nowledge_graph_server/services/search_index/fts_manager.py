"""FTS (Full-Text Search) index management for LanceDB tables."""

import asyncio
import platform
from typing import Dict, List

import structlog

logger = structlog.get_logger(__name__)


class FTSManager:
    """Manages FTS indices for search index tables."""

    # FTS column configuration for each table
    FTS_COLUMNS = {
        "memories_index": ["title", "content", "semantic_field"],
        "messages_index": ["content"],
        "communities_index": ["name", "description", "ai_summary"],
        "entities_index": ["name", "description"],
        "sources_index": ["file_name", "content", "summary"],
        "source_chunks_index": ["content", "heading_context"],
    }

    def __init__(self, db):
        """Initialize FTS manager with LanceDB connection."""
        self.db = db

    def get_fts_columns(self, table_name: str) -> List[str]:
        """Get FTS columns for a table."""
        if table_name not in self.FTS_COLUMNS:
            raise ValueError(f"No FTS configuration for table: {table_name}")
        return self.FTS_COLUMNS[table_name]

    async def create_fts_index(
        self, table_name: str, fts_columns: List[str]
    ) -> None:
        """Create a Tantivy FTS index on a table."""
        loop = asyncio.get_event_loop()
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        try:
            await loop.run_in_executor(
                None,
                lambda: table.create_fts_index(
                    fts_columns, use_tantivy=True, replace=True
                ),
            )
            logger.info(f"Created FTS index on {table_name}")
        except Exception as e:
            logger.warning(f"Failed to create FTS index on {table_name}", error=str(e))

    async def rebuild_fts_index(self, table_name: str) -> None:
        """Rebuild FTS index for a table."""
        loop = asyncio.get_event_loop()
        table = self.db.open_table(table_name)  # type: ignore[union-attr]
        fts_cols = self.get_fts_columns(table_name)
        row_count = await loop.run_in_executor(None, table.count_rows)
        await loop.run_in_executor(
            None,
            lambda: table.create_fts_index(fts_cols, use_tantivy=True, replace=True),
        )
        logger.info("Rebuilt FTS index for table", table=table_name, row_count=row_count)

    async def validate_fts_indices(self, table_names: List[str]) -> None:
        """Lightweight startup check to keep FTS indices in sync."""
        if self.db is None:
            raise RuntimeError("Database not connected")
        loop = asyncio.get_event_loop()
        for table_name in table_names:
            try:
                table = self.db.open_table(table_name)  # type: ignore[union-attr]

                def probe_fts(tbl):
                    return tbl.search("test", query_type="fts").limit(1).to_list()

                await loop.run_in_executor(None, probe_fts, table)
            except Exception as e:
                error_message = str(e)
                if "Added column's length must match table's length" in error_message:
                    logger.warning(
                        "FTS index out of sync at startup; rebuilding",
                        table=table_name,
                    )
                    try:
                        await self.rebuild_fts_index(table_name)
                    except Exception as rebuild_error:
                        logger.warning(
                            "FTS rebuild failed at startup",
                            table=table_name,
                            error=str(rebuild_error),
                        )

    async def rebuild_all_fts_indices(self, table_names: List[str]) -> None:
        """Rebuild all FTS indices (useful after bulk operations).

        Note: On Windows, we need to be careful about file locking.
        Re-opening tables after FTS index creation can help ensure the index is readable.
        """
        loop = asyncio.get_event_loop()
        is_windows = platform.system() == "Windows"

        for table_name in table_names:
            try:
                table = self.db.open_table(table_name)  # type: ignore[union-attr]
                columns = self.get_fts_columns(table_name)

                def count_rows(tbl):
                    return tbl.count_rows()

                def create_fts(tbl, cols):
                    return tbl.create_fts_index(cols, use_tantivy=True, replace=True)

                def test_fts(tbl):
                    return tbl.search("test", query_type="fts").limit(1).to_list()

                row_count = await loop.run_in_executor(None, count_rows, table)

                # Create FTS index
                await loop.run_in_executor(None, create_fts, table, columns)

                # On Windows, give the filesystem time to flush and release locks
                if is_windows:
                    await asyncio.sleep(0.5)

                # Re-open the table to ensure we have fresh handles (helps with Windows file locking)
                table = self.db.open_table(table_name)  # type: ignore[union-attr]

                # Verify FTS works with a simple test query
                try:
                    test_results = await loop.run_in_executor(None, test_fts, table)
                    fts_works = True
                except Exception as fts_test_err:
                    fts_works = False
                    logger.warning(
                        f"FTS verification failed for {table_name}",
                        error=str(fts_test_err),
                    )

                logger.info(
                    f"Rebuilt FTS index for {table_name}",
                    row_count=row_count,
                    fts_functional=fts_works,
                )
            except Exception as e:
                logger.warning(
                    f"Failed to rebuild FTS index for {table_name}", error=str(e)
                )
