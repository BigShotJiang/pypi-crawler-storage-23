"""Index lifecycle management: initialization, optimization, and dirty tracking."""

import asyncio
import time
from pathlib import Path
from typing import Optional, Set, Union

import lancedb
import structlog

from .schemas import (
    memories_schema,
    messages_schema,
    communities_schema,
    entities_schema,
    sources_schema,
    source_chunks_schema,
)
from .fts_manager import FTSManager

logger = structlog.get_logger(__name__)


class IndexManager:
    """Manages index lifecycle: initialization, optimization, and dirty tracking.

    Dirty tracking is per-table: only tables that received writes get their
    FTS indices rebuilt. A debounce window prevents FTS rebuilds from blocking
    search during bursts of writes (e.g., Knowledge Agent creating multiple
    memories). Vector search is always up to date — LanceDB appends are
    immediately searchable without optimization. Only FTS (Tantivy) needs
    explicit index rebuilds, and a brief staleness window is acceptable since
    vector search carries the primary signal (60% weight in hybrid scoring).
    """

    TABLE_MEMORIES = "memories_index"
    TABLE_MESSAGES = "messages_index"
    TABLE_COMMUNITIES = "communities_index"
    TABLE_ENTITIES = "entities_index"
    TABLE_SOURCES = "sources_index"
    TABLE_SOURCE_CHUNKS = "source_chunks_index"

    ALL_TABLES = [
        TABLE_MEMORIES,
        TABLE_MESSAGES,
        TABLE_COMMUNITIES,
        TABLE_ENTITIES,
        TABLE_SOURCES,
        TABLE_SOURCE_CHUNKS,
    ]

    # Don't rebuild FTS if the last write was less than this many seconds ago.
    # Vector search still works — only FTS results may be slightly stale.
    # 5s accommodates typical agent write intervals (memories every 2-5s).
    _FTS_REBUILD_DELAY: float = 5.0

    # Force FTS rebuild after this many seconds even during active writes,
    # so FTS doesn't get indefinitely stale during long agent runs.
    # 60s is fine — agent tasks rarely exceed this, and vector search
    # carries the primary signal throughout.
    _FTS_MAX_STALENESS: float = 60.0

    def __init__(self, db_path: Union[str, Path]):
        """Initialize index manager."""
        self.db_path = Path(db_path)
        self.db = None
        self._initialized = False
        self._dirty_tables: Set[str] = set()
        self._last_write_time: float = 0.0
        self._last_rebuild_time: float = 0.0
        self._index_optimize_lock = asyncio.Lock()
        self.fts_manager: Optional[FTSManager] = None

    async def initialize(self) -> None:
        """Initialize LanceDB connection and create tables if needed."""
        if self._initialized:
            return

        self.db_path.mkdir(parents=True, exist_ok=True)
        loop = asyncio.get_event_loop()

        try:
            self.db = await loop.run_in_executor(
                None, lambda: lancedb.connect(str(self.db_path))
            )
        except Exception as e:
            logger.error("Failed to connect to LanceDB", error=str(e))
            raise RuntimeError(f"Failed to connect to LanceDB: {e}")

        if self.db is None:
            raise RuntimeError(
                f"LanceDB connect returned None for path: {self.db_path}"
            )

        self.fts_manager = FTSManager(self.db)
        await self._ensure_tables()
        self._initialized = True
        await self._validate_fts_indices()
        logger.info("Search index initialized", db_path=str(self.db_path))

    async def _ensure_tables(self) -> None:
        """Create index tables if they don't exist."""
        if self.db is None:
            raise RuntimeError("Database not connected")

        loop = asyncio.get_event_loop()
        existing = await loop.run_in_executor(None, self.db.table_names)

        if self.TABLE_MEMORIES not in existing:
            await self._create_table_with_fts(
                self.TABLE_MEMORIES,
                memories_schema(),
                ["title", "content", "semantic_field"],
            )
        else:
            await self._migrate_memories_if_needed(loop)
        if self.TABLE_MESSAGES not in existing:
            await self._create_table_with_fts(
                self.TABLE_MESSAGES,
                messages_schema(),
                ["content"],
            )
        if self.TABLE_COMMUNITIES not in existing:
            await self._create_table_with_fts(
                self.TABLE_COMMUNITIES,
                communities_schema(),
                ["name", "description", "ai_summary"],
            )
        else:
            await self._migrate_communities_if_needed(loop)
        if self.TABLE_ENTITIES not in existing:
            await self._create_table_with_fts(
                self.TABLE_ENTITIES,
                entities_schema(),
                ["name", "description"],
            )
        if self.TABLE_SOURCES not in existing:
            await self._create_table_with_fts(
                self.TABLE_SOURCES,
                sources_schema(),
                ["file_name", "content", "summary"],
            )
        if self.TABLE_SOURCE_CHUNKS not in existing:
            await self._create_table_with_fts(
                self.TABLE_SOURCE_CHUNKS,
                source_chunks_schema(),
                ["content", "heading_context"],
            )

    async def _create_table_with_fts(
        self, table_name: str, schema, fts_columns: list
    ) -> None:
        """Create a table with Tantivy FTS index."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None, lambda: self.db.create_table(table_name, schema=schema)  # type: ignore[union-attr]
        )
        await self.fts_manager.create_fts_index(table_name, fts_columns)

    async def _migrate_communities_if_needed(self, loop) -> None:
        """Recreate communities table if schema is outdated."""
        try:
            table = self.db.open_table(self.TABLE_COMMUNITIES)  # type: ignore[union-attr]
            schema = await loop.run_in_executor(None, lambda: table.schema)
            field_names = [f.name for f in schema]

            if "community_id" not in field_names:
                logger.warning("Migrating communities table (adding community_id)")
                await loop.run_in_executor(
                    None,
                    lambda: self.db.drop_table(self.TABLE_COMMUNITIES),  # type: ignore[union-attr]
                )
                await self._create_table_with_fts(
                    self.TABLE_COMMUNITIES,
                    communities_schema(),
                    ["name", "description", "ai_summary"],
                )
        except Exception as e:
            logger.warning("Failed to migrate communities table", error=str(e))

    async def _migrate_memories_if_needed(self, loop) -> None:
        """Recreate memories table if schema is missing v0.6 fields."""
        try:
            table = self.db.open_table(self.TABLE_MEMORIES)  # type: ignore[union-attr]
            schema = await loop.run_in_executor(None, lambda: table.schema)
            field_names = [f.name for f in schema]

            if "is_latest" not in field_names:
                logger.warning(
                    "Migrating memories table (adding v0.6 fields: is_latest, is_crystal, unit_type)"
                )
                await loop.run_in_executor(
                    None,
                    lambda: self.db.drop_table(self.TABLE_MEMORIES),  # type: ignore[union-attr]
                )
                await self._create_table_with_fts(
                    self.TABLE_MEMORIES,
                    memories_schema(),
                    ["title", "content", "semantic_field"],
                )
                logger.info(
                    "Memories table recreated with v0.6 schema. "
                    "All memories will be re-synced on next reindex cycle."
                )
        except Exception as e:
            logger.warning("Failed to migrate memories table", error=str(e))

    async def _validate_fts_indices(self) -> None:
        """Validate FTS indices at startup."""
        await self.fts_manager.validate_fts_indices(self.ALL_TABLES)

    def mark_index_dirty(self, table_name: Optional[str] = None) -> None:
        """Mark a specific table (or all tables) as needing FTS rebuild.

        Args:
            table_name: The table that was modified. If None, marks all tables
                        dirty (for backward compatibility / bulk operations).
        """
        now = time.time()
        if table_name:
            self._dirty_tables.add(table_name)
        else:
            self._dirty_tables.update(self.ALL_TABLES)
        self._last_write_time = now
        logger.debug(
            "Index marked dirty",
            table=table_name or "ALL",
            dirty_count=len(self._dirty_tables),
        )

    async def ensure_index_fresh(self) -> None:
        """Rebuild FTS indices for dirty tables if writes have settled.

        Debounce logic:
        - If no tables are dirty, return immediately.
        - If the last write was within _FTS_REBUILD_DELAY seconds, skip the
          rebuild. Vector search is always up to date (LanceDB appends are
          immediately searchable); only FTS may be briefly stale.
        - If FTS hasn't been rebuilt for _FTS_MAX_STALENESS seconds, force a
          rebuild even during active writes so FTS doesn't go indefinitely stale.
        - Only the tables that actually received writes are rebuilt — not all 6.
        """
        if not self._dirty_tables:
            return

        now = time.time()
        time_since_write = now - self._last_write_time
        time_since_rebuild = now - self._last_rebuild_time

        # Skip rebuild during active write bursts, unless FTS is too stale
        if (
            time_since_write < self._FTS_REBUILD_DELAY
            and time_since_rebuild < self._FTS_MAX_STALENESS
        ):
            logger.debug(
                "Skipping FTS rebuild — writes still active",
                time_since_write=f"{time_since_write:.1f}s",
                dirty_tables=list(self._dirty_tables),
            )
            return

        async with self._index_optimize_lock:
            # Double-check after acquiring lock
            if not self._dirty_tables:
                return

            tables = list(self._dirty_tables)
            self._dirty_tables.clear()

            logger.info(
                "Rebuilding FTS indices for dirty tables",
                tables=tables,
                trigger="staleness" if time_since_write < self._FTS_REBUILD_DELAY else "settled",
            )
            try:
                await self._optimize_tables(tables)
                self._last_rebuild_time = time.time()
            except Exception as e:
                # Put tables back so they get retried on next search
                self._dirty_tables.update(tables)
                logger.warning("FTS rebuild failed", tables=tables, error=str(e))

    async def _optimize_tables(self, table_names: list) -> None:
        """Optimize vector + FTS indices for the specified tables."""
        if self.db is None:
            raise RuntimeError("Database not connected")

        loop = asyncio.get_event_loop()

        for table_name in table_names:
            try:
                table = self.db.open_table(table_name)  # type: ignore[union-attr]
                row_count = await loop.run_in_executor(None, table.count_rows)
                logger.info(f"Optimizing {table_name}", row_count=row_count)

                # Vector index optimization (compacts IVF segments)
                await loop.run_in_executor(None, table.optimize)

                # FTS index rebuild (Tantivy doesn't auto-update)
                fts_cols = self.fts_manager.get_fts_columns(table_name)

                def rebuild_fts(tbl, cols):
                    return tbl.create_fts_index(cols, use_tantivy=True, replace=True)

                await loop.run_in_executor(None, rebuild_fts, table, fts_cols)

                logger.info(f"Optimized vector + FTS indices for {table_name}")
            except Exception as e:
                logger.warning(f"Failed to optimize {table_name}", error=str(e))

    async def optimize_indices(self) -> None:
        """Optimize all indices. Used at startup and for bulk operations."""
        await self._optimize_tables(self.ALL_TABLES)

    async def cleanup(self) -> None:
        """Cleanup resources."""
        self.db = None
        self._initialized = False
