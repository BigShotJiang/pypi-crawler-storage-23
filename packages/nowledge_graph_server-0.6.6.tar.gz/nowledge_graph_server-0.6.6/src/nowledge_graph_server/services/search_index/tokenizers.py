"""Universal text tokenization for FTS indexing.

This module provides Python-based tokenization for languages that LanceDB's
Tantivy doesn't support natively. By tokenizing at the application layer,
we can support any language with available Python tokenizers.

Language Detection:
- Uses fast-langdetect (FastText-based, 80x faster than alternatives)
- Falls back to Unicode range detection if not available

Supported Tokenizers:
- Chinese: jieba - most popular, fast, no external deps
- Japanese: Character segmentation fallback (fugashi/MeCab removed to save ~50MB)
- Korean: Native spaces (Korean has natural word boundaries)
- Latin scripts: No tokenization needed (Tantivy handles natively)
- Thai: Falls back to no tokenization (pythainlp removed to save ~110MB)

Usage:
    from .tokenizers import tokenize_for_fts

    # Tokenize text before indexing
    tokenized = tokenize_for_fts("机器学习是人工智能的分支")
    # Returns: "机器 学习 是 人工智能 的 分支"

    # Same tokenization for queries
    query = tokenize_for_fts("机器学习")
    # Returns: "机器 学习"

References:
- https://github.com/LlmKira/fast-langdetect (language detection)
- https://github.com/fxsjy/jieba (Chinese)
"""

from functools import lru_cache
from typing import Optional

import structlog

logger = structlog.get_logger(__name__)

# Lazy-loaded components
_language_detector = None
_jieba = None
_pythainlp = None
_FAST_LANGDETECT_SAMPLE_LEN = 80


def _get_language_detector():
    """Lazy-load fast-langdetect (FastText-based, very fast)."""
    global _language_detector
    if _language_detector is not None:
        return _language_detector

    try:
        from fast_langdetect import detect
        _language_detector = detect
        logger.debug("fast-langdetect initialized")
        return detect
    except ImportError:
        logger.debug("fast-langdetect not installed, using fallback detection")
        return None
    except Exception as e:
        logger.warning("Failed to initialize fast-langdetect", error=str(e))
        return None


def _get_jieba():
    """Lazy-load jieba tokenizer for Chinese."""
    global _jieba
    if _jieba is not None:
        return _jieba

    try:
        import jieba
        jieba.setLogLevel(20)  # Suppress debug output
        _jieba = jieba
        logger.debug("Jieba Chinese tokenizer initialized")
        return jieba
    except ImportError:
        logger.debug("jieba not installed, Chinese will use character segmentation")
        return None


def _get_pythainlp():
    """Lazy-load PyThaiNLP tokenizer for Thai."""
    global _pythainlp
    if _pythainlp is not None:
        return _pythainlp

    try:
        from pythainlp.tokenize import word_tokenize
        _pythainlp = word_tokenize
        logger.debug("PyThaiNLP Thai tokenizer initialized")
        return word_tokenize
    except ImportError:
        logger.debug("pythainlp not installed, Thai FTS will be limited")
        return None


@lru_cache(maxsize=1)
def get_tokenizer_status() -> dict:
    """Get status of available tokenizers.

    Returns dict with:
        - available: dict of component -> bool
        - recommendations: list of install commands for missing components
    """
    available = {
        "fast_langdetect": False,
        "jieba": False,
    }

    # Check fast-langdetect
    try:
        from fast_langdetect import detect
        available["fast_langdetect"] = True
    except ImportError:
        pass

    # Check jieba
    try:
        import jieba
        available["jieba"] = True
    except ImportError:
        pass

    recommendations = []
    if not available["fast_langdetect"]:
        recommendations.append("pip install fast-langdetect  # Language detection (FastText)")
    if not available["jieba"]:
        recommendations.append("pip install jieba  # Chinese tokenization")

    return {
        "available": available,
        "recommendations": recommendations,
    }


def _has_japanese_script(text: str) -> bool:
    """Check if text contains hiragana or katakana (Japanese-specific scripts).

    Chinese and Japanese share kanji (CJK ideographs), but only Japanese uses
    hiragana (U+3040-U+309F) and katakana (U+30A0-U+30FF). FastText's lite model
    confuses kanji-only Chinese text with Japanese. This check disambiguates.

    Matches the fast-langdetect library's own is_japanese() guard.
    """
    return any(0x3040 < ord(ch) < 0x30FF for ch in text)


def detect_language(text: str) -> Optional[str]:
    """Detect the language of text.

    Uses fast-langdetect (FastText) for speed, falls back to Unicode detection.

    Returns language code: 'zh', 'ja', 'ko', 'th', 'en', etc.
    Returns None if detection fails.
    """
    if not text or len(text.strip()) < 3:
        return None

    detect_fn = _get_language_detector()
    if detect_fn is None:
        return _fallback_detect_language(text)

    try:
        # fast-langdetect itself truncates to 80 chars by default and logs a warning.
        # Pre-truncate here to avoid per-call warning noise in indexing hot paths.
        sample = text[:_FAST_LANGDETECT_SAMPLE_LEN]

        # fast-langdetect returns list of dicts like [{'lang': 'zh', 'score': 0.99}]
        # Use model="lite" to use the bundled small model (916KB) instead of
        # downloading the large model (131MB). The small model provides excellent
        # accuracy for CJK language detection which is our primary use case.
        result = detect_fn(sample, model="lite")
        if isinstance(result, list) and result:
            lang = result[0].get("lang")
        elif isinstance(result, dict):
            lang = result.get("lang")
        else:
            lang = result

        # Guard: FastText confuses Chinese kanji-only text with Japanese.
        # If model says "ja" but text has no hiragana/katakana, it's Chinese.
        # This matches the library's own detect_language() workaround.
        if lang == "ja" and not _has_japanese_script(sample):
            lang = "zh"

        return lang
    except Exception as e:
        logger.warning("Language detection failed", error=str(e))
        return _fallback_detect_language(text)


def _fallback_detect_language(text: str) -> Optional[str]:
    """Fallback language detection using Unicode ranges.

    Used when fast-langdetect is not available.
    Returns ISO 639-1 codes to match fast-langdetect output.
    """
    import re

    # Check for CJK characters
    if re.search(r'[\u4e00-\u9fff\u3400-\u4dbf]', text):
        # Has Chinese characters - could be Chinese or Japanese
        if re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text):
            return "ja"  # Has hiragana/katakana
        return "zh"

    # Check for Korean
    if re.search(r'[\uac00-\ud7af\u1100-\u11ff]', text):
        return "ko"

    # Check for Thai
    if re.search(r'[\u0e00-\u0e7f]', text):
        return "th"

    # Check for Arabic
    if re.search(r'[\u0600-\u06ff]', text):
        return "ar"

    # Check for Cyrillic (Russian, etc.)
    if re.search(r'[\u0400-\u04ff]', text):
        return "ru"

    # Default to None (will use no tokenization)
    return None


def tokenize_chinese(text: str) -> str:
    """Tokenize Chinese text using jieba.

    Args:
        text: Chinese text

    Returns:
        Text with spaces between words
    """
    jieba = _get_jieba()
    if jieba is None:
        return _character_segment(text)

    try:
        # Use search mode for better recall in FTS
        words = jieba.lcut_for_search(text)
        return ' '.join(words)
    except Exception as e:
        logger.warning("Jieba tokenization failed", error=str(e))
        return _character_segment(text)


def tokenize_japanese(text: str) -> str:
    """Tokenize Japanese text using character segmentation.

    Uses character-level segmentation for CJK characters.
    fugashi/MeCab was removed to save ~50MB of dictionary files.

    Args:
        text: Japanese text

    Returns:
        Text with spaces between characters
    """
    return _character_segment(text)


def tokenize_thai(text: str) -> str:
    """Tokenize Thai text using PyThaiNLP.

    Args:
        text: Thai text

    Returns:
        Text with spaces between words
    """
    word_tokenize = _get_pythainlp()
    if word_tokenize is None:
        # Thai without tokenizer - return as-is (limited FTS)
        return text

    try:
        words = word_tokenize(text, engine="newmm")
        return ' '.join(words)
    except Exception as e:
        logger.warning("PyThaiNLP tokenization failed", error=str(e))
        return text


def _character_segment(text: str) -> str:
    """Fallback: segment text at character level for CJK.

    This is a last resort when proper tokenizers aren't available.
    Results in character-level matching which has lower precision.
    """
    import re
    result = []
    for char in text:
        # Add spaces around CJK characters
        if re.match(r'[\u4e00-\u9fff\u3400-\u4dbf\u3040-\u309f\u30a0-\u30ff]', char):
            result.append(f' {char} ')
        else:
            result.append(char)
    return ' '.join(''.join(result).split())


def sanitize_fts_query(query: str) -> str:
    """Strip non-word characters from FTS query to prevent Tantivy parse errors.

    Previous approach escaped known Tantivy special characters one by one,
    but this was fragile — new characters kept breaking (apostrophes from
    pinyin input, backticks from markdown, etc.).

    Allowlist approach: keep only Unicode word characters (\\w = letters,
    digits, underscore across all scripts including CJK) and whitespace.
    Everything else becomes a space. This is appropriate for FTS because
    punctuation doesn't contribute to full-text search matching.

    Examples:
        "hui'gu'de"                    -> "hui gu de"
        "`SearchOperations`"           -> "SearchOperations"
        "test{ field:value (a+b)"      -> "test field value a b"
        "昨天有啥值得hui'gu'de"          -> "昨天有啥值得hui gu de"

    Args:
        query: Raw query text

    Returns:
        Query with only word characters and spaces
    """
    import re

    if not query:
        return query

    # Replace any non-word, non-whitespace character with a space
    result = re.sub(r'[^\w\s]', ' ', query, flags=re.UNICODE)

    # Collapse runs of whitespace into a single space
    result = re.sub(r'\s+', ' ', result)

    return result.strip()


def tokenize_for_fts(text: str, lang: Optional[str] = None) -> str:
    """Tokenize text for FTS indexing.

    Detects the language and applies appropriate tokenization.
    For Latin scripts, returns text unchanged (Tantivy handles it natively).

    Args:
        text: Text to tokenize

    Returns:
        Tokenized text suitable for FTS indexing
    """
    if not text or not text.strip():
        return text or ""

    text = text.strip()

    # Detect language (returns ISO 639-1 codes like 'zh', 'ja', 'ko', 'th')
    # unless caller already detected a language for this document/source.
    detected_lang = lang or detect_language(text)

    if detected_lang == "zh":
        return tokenize_chinese(text)
    elif detected_lang == "ja":
        return tokenize_japanese(text)
    elif detected_lang == "th":
        return tokenize_thai(text)
    elif detected_lang == "ko":
        # Korean uses spaces naturally, minimal tokenization needed
        return text
    else:
        # Latin scripts and others: Tantivy handles natively
        return text
