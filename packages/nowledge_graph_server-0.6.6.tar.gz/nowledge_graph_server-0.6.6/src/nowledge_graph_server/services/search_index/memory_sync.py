"""Memory synchronization to search index."""

from typing import List, TYPE_CHECKING

import structlog

from .models import MemoryIndexRecord
from .tokenizers import detect_language, tokenize_for_fts
from .service_factory import get_search_index_service, get_bge_m3_service

if TYPE_CHECKING:
    from ...models.graph import MemoryNode

logger = structlog.get_logger(__name__)


async def sync_memory_to_index(memory: "MemoryNode") -> bool:
    """Sync a memory to the search index.

    Generates embedding and upserts to LanceDB.

    Args:
        memory: MemoryNode to sync

    Returns:
        True if synced successfully
    """
    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.debug(
                "Search index services not available, skipping sync",
                memory_id=memory.id,
            )
            return False

        # Create semantic field for embedding (original text)
        semantic_field = f"{memory.title or ''}\n{memory.content or ''}".strip()

        # Generate embedding (is_query=False since this is a document to be indexed)
        embedding = await bge_service.embed_text(semantic_field, is_query=False)
        detected_lang = detect_language(semantic_field)

        # Create index record with tokenized text for FTS
        # Tokenization handles CJK and other non-Latin scripts
        record = MemoryIndexRecord(
            id=memory.id,
            title=tokenize_for_fts(memory.title or "", lang=detected_lang),
            content=tokenize_for_fts(memory.content or "", lang=detected_lang),
            semantic_field=tokenize_for_fts(semantic_field, lang=detected_lang),
            embedding=embedding,
            importance=memory.importance,
            created_at=memory.created_at,
            updated_at=memory.updated_at,
            is_latest=getattr(memory, "is_latest", True),
            is_crystal=getattr(memory, "is_crystal", False),
            unit_type=getattr(memory, "unit_type", "fact"),
        )

        # Upsert to index
        await search_service.upsert_memory(record)

        logger.debug(
            "Memory synced to search index",
            memory_id=memory.id,
            embedding_dim=len(embedding),
        )
        return True

    except Exception as e:
        logger.warning(
            "Failed to sync memory to search index",
            memory_id=memory.id,
            error=str(e),
        )
        return False


async def sync_memories_batch(memories: List["MemoryNode"]) -> int:
    """Batch sync memories to the search index.

    Args:
        memories: List of MemoryNode objects to sync

    Returns:
        Number of successfully synced memories
    """
    if not memories:
        return 0

    try:
        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            logger.debug("Search index services not available, skipping batch sync")
            return 0

        # Generate embeddings for all memories (is_query=False since these are documents)
        semantic_fields = [
            f"{m.title or ''}\n{m.content or ''}".strip() for m in memories
        ]
        logger.info(
            "Generating embeddings for memories",
            count=len(semantic_fields),
        )
        embeddings = await bge_service.embed_batch(semantic_fields, is_query=False)
        logger.info(
            "Generated embeddings for memories",
            count=len(embeddings),
            dim=len(embeddings[0]) if embeddings else 0,
        )

        # Create index records with tokenized text for FTS
        records = []
        for memory, semantic_field, embedding in zip(
            memories, semantic_fields, embeddings
        ):
            detected_lang = detect_language(semantic_field)
            records.append(
                MemoryIndexRecord(
                    id=memory.id,
                    title=tokenize_for_fts(memory.title or "", lang=detected_lang),
                    content=tokenize_for_fts(memory.content or "", lang=detected_lang),
                    semantic_field=tokenize_for_fts(semantic_field, lang=detected_lang),
                    embedding=embedding,
                    importance=memory.importance,
                    created_at=memory.created_at,
                    updated_at=memory.updated_at,
                    is_latest=getattr(memory, "is_latest", True),
                    is_crystal=getattr(memory, "is_crystal", False),
                    unit_type=getattr(memory, "unit_type", "fact"),
                )
            )

        # Batch upsert
        count = await search_service.batch_upsert_memories(records)

        logger.info(
            "Batch synced memories to search index",
            count=count,
            total=len(memories),
        )
        return count

    except Exception as e:
        logger.warning(
            "Failed to batch sync memories to search index",
            count=len(memories),
            error=str(e),
        )
        return 0


async def delete_memory_from_index(memory_id: str) -> bool:
    """Delete a memory from the search index.

    Args:
        memory_id: ID of memory to delete

    Returns:
        True if deleted successfully
    """
    try:
        search_service = await get_search_index_service()

        if not search_service:
            return False

        await search_service.delete_memory(memory_id)

        logger.debug("Memory deleted from search index", memory_id=memory_id)
        return True

    except Exception as e:
        logger.warning(
            "Failed to delete memory from search index",
            memory_id=memory_id,
            error=str(e),
        )
        return False
