"""Full reindex operation from Kuzu to search index."""

from typing import Any, Dict

import structlog

from .service_factory import get_search_index_service, get_bge_m3_service
from .memory_sync import sync_memories_batch
from .message_sync import sync_messages_batch
from .community_sync import sync_community_to_index
from .entity_sync import sync_entities_batch

logger = structlog.get_logger(__name__)


async def full_reindex_from_kuzu(db_client: Any) -> Dict[str, Any]:
    """Perform a full reindex from Kuzu to the search index.

    This is a heavy operation that should only be triggered:
    - When the user first downloads the search embedding model
    - When the user explicitly requests a reindex
    - After a migration

    Args:
        db_client: KuzuClient instance

    Returns:
        Dict with reindex statistics
    """
    from ...utils.progress_logger import log_stage, log_progress

    stats = {
        "memories": 0,
        "messages": 0,
        "communities": 0,
        "entities": 0,
        "errors": [],
    }

    try:
        # Stage 1: Initialize services
        log_stage(
            operation="search_reindex",
            stage="initializing",
            message="Initializing search services...",
        )

        search_service = await get_search_index_service()
        bge_service = await get_bge_m3_service()

        if not search_service or not bge_service:
            log_stage(
                operation="search_reindex",
                stage="error",
                message="Search services not available",
            )
            return {
                **stats,
                "success": False,
                "error": "Search index services not available",
            }

        # Stage 1.5: Authoritative cleanup before rebuild
        # Reindex must remove stale/orphaned rows, not just upsert current rows.
        log_stage(
            operation="search_reindex",
            stage="clearing_search_index",
            message="Clearing existing search index tables before rebuild...",
        )
        try:
            await search_service.clear_table(search_service.TABLE_MEMORIES)
            await search_service.clear_table(search_service.TABLE_MESSAGES)
            await search_service.clear_table(search_service.TABLE_COMMUNITIES)
            await search_service.clear_table(search_service.TABLE_ENTITIES)
            logger.info("Full reindex: Cleared core search index tables")
        except Exception as e:
            stats["errors"].append(f"Search index cleanup failed: {e}")
            logger.error("Full reindex: Search index cleanup failed", error=str(e))

        async def _trim_embedding_cache(stage: str) -> None:
            """Best-effort MLX runtime cache release between heavy reindex phases."""
            try:
                release_fn = getattr(bge_service, "release_runtime_cache", None)
                if callable(release_fn):
                    await release_fn(reason=f"full_reindex_{stage}")
            except Exception as e:
                logger.debug(
                    "Failed to trim embedding runtime cache",
                    stage=stage,
                    error=str(e),
                )

        # Stage 2: Reindex memories (0-40%)
        log_stage(
            operation="search_reindex",
            stage="indexing_memories",
            message="Indexing memories...",
        )
        logger.info("Full reindex: Starting memory reindex...")
        try:
            memories = await db_client.list_memories(limit=10000, state="all")
            total_memories = len(memories) if memories else 0
            if memories:
                log_progress(
                    operation="search_reindex",
                    percentage=5,
                    message=f"Batch indexing {total_memories} memories...",
                )
                # Note: Batch sync is more efficient than per-memory sync
                # Progress jumps from 5% to 40% when batch completes
                stats["memories"] = await sync_memories_batch(memories)
                log_progress(
                    operation="search_reindex",
                    percentage=40,
                    message=f"Indexed {stats['memories']} memories",
                )
                logger.info(f"Full reindex: Indexed {stats['memories']} memories")
        except Exception as e:
            stats["errors"].append(f"Memory reindex failed: {e}")
            logger.error("Full reindex: Memory reindex failed", error=str(e))
        await _trim_embedding_cache("after_memories")

        # Stage 3: Reindex messages (40-70%)
        log_stage(
            operation="search_reindex",
            stage="indexing_messages",
            message="Indexing thread messages...",
        )
        log_progress(
            operation="search_reindex",
            percentage=40,
            message="Indexing thread messages...",
        )
        logger.info("Full reindex: Starting message reindex...")
        try:
            threads = await db_client.list_threads(limit=1000)
            all_messages = []
            total_threads = len(threads) if threads else 0
            for idx, thread in enumerate(threads):
                tid = thread.get("thread_id") or thread.get("id", "")
                if not tid:
                    continue

                # Progress within message indexing (40-70%)
                progress = 40 + (idx / max(total_threads, 1)) * 30
                if idx % 5 == 0:
                    log_progress(
                        operation="search_reindex",
                        percentage=progress,
                        message=f"Processing threads ({idx}/{total_threads})...",
                    )

                thread_data = await db_client.fetch_thread(tid)
                if thread_data and hasattr(thread_data, "messages"):
                    for i, msg in enumerate(thread_data.messages):
                        if isinstance(msg, dict):
                            all_messages.append(
                                {
                                    "id": msg.get("id", f"{tid}_{i}"),
                                    "thread_id": tid,
                                    "content": msg.get("content", ""),
                                    "role": msg.get("role", "user"),
                                    "order_index": i,
                                    "created_at": msg.get("created_at"),
                                }
                            )
                        else:
                            all_messages.append(
                                {
                                    "id": getattr(msg, "id", f"{tid}_{i}"),
                                    "thread_id": tid,
                                    "content": getattr(msg, "content", ""),
                                    "role": getattr(msg, "role", "user"),
                                    "order_index": i,
                                    "created_at": getattr(msg, "created_at", None),
                                }
                            )

            if all_messages:
                stats["messages"] = await sync_messages_batch(all_messages)
                logger.info(f"Full reindex: Indexed {stats['messages']} messages")
        except Exception as e:
            stats["errors"].append(f"Message reindex failed: {e}")
            logger.error("Full reindex: Message reindex failed", error=str(e))

        # Stage 4: Reindex communities (70-85%)
        log_stage(
            operation="search_reindex",
            stage="indexing_communities",
            message="Indexing communities...",
        )
        log_progress(
            operation="search_reindex",
            percentage=70,
            message="Indexing communities...",
        )
        logger.info("Full reindex: Starting community reindex...")
        try:
            if db_client.conn:
                import real_ladybug as kuzu

                result = db_client.conn.execute("MATCH (c:Community) RETURN c")
                if isinstance(result, kuzu.QueryResult):
                    while result.has_next():
                        row = result.get_next()
                        community_data = row[0]
                        success = await sync_community_to_index(
                            id=community_data.get("id", ""),
                            community_id=community_data.get("community_id", 0),
                            name=community_data.get("name", ""),
                            description=community_data.get("description", ""),
                            ai_summary=community_data.get("ai_summary", ""),
                            member_count=community_data.get("member_count", 0),
                        )
                        if success:
                            stats["communities"] += 1
            logger.info(f"Full reindex: Indexed {stats['communities']} communities")
        except Exception as e:
            stats["errors"].append(f"Community reindex failed: {e}")
            logger.error("Full reindex: Community reindex failed", error=str(e))
        await _trim_embedding_cache("after_communities")

        # Stage 5: Reindex entities (85-95%)
        log_stage(
            operation="search_reindex",
            stage="indexing_entities",
            message="Indexing entities...",
        )
        log_progress(
            operation="search_reindex",
            percentage=85,
            message="Indexing entities...",
        )
        logger.info("Full reindex: Starting entity reindex...")
        try:
            entities = await db_client.entity_repo.list_entities(limit=10000)
            if entities:
                stats["entities"] = await sync_entities_batch(entities)
                logger.info(f"Full reindex: Indexed {stats['entities']} entities")
        except Exception as e:
            stats["errors"].append(f"Entity reindex failed: {e}")
            logger.error("Full reindex: Entity reindex failed", error=str(e))
        await _trim_embedding_cache("after_entities")

        # Stage 6: Rebuild FTS indices (95-100%)
        log_stage(
            operation="search_reindex",
            stage="rebuilding_fts",
            message="Rebuilding full-text search indices...",
        )
        log_progress(
            operation="search_reindex",
            percentage=95,
            message="Rebuilding search indices...",
        )
        try:
            await search_service.rebuild_fts_indices()
            logger.info("Full reindex: FTS indices rebuilt")
        except Exception as e:
            error_msg = f"FTS rebuild failed: {e}"
            stats["errors"].append(error_msg)
            logger.error("Full reindex: FTS rebuild failed", error=str(e))
        await _trim_embedding_cache("after_fts_rebuild")

        stats["success"] = len(stats["errors"]) == 0

        # Final stage: completed
        if stats["success"]:
            log_stage(
                operation="search_reindex",
                stage="completed",
                message=f"Indexed {stats['memories']} memories, {stats['messages']} messages",
                details=stats,
            )
            log_progress(
                operation="search_reindex",
                percentage=100,
                message=f"Indexed {stats['memories']} memories",
            )
        else:
            log_stage(
                operation="search_reindex",
                stage="error",
                message=f"Completed with {len(stats['errors'])} errors",
                details={"errors": stats["errors"]},
            )

        logger.info(
            "Full reindex completed",
            memories=stats["memories"],
            messages=stats["messages"],
            communities=stats["communities"],
            entities=stats["entities"],
            errors=len(stats["errors"]),
        )

        return stats

    except Exception as e:
        logger.error("Full reindex failed", error=str(e))
        return {
            **stats,
            "success": False,
            "error": str(e),
        }
