"""LanceDB-based search index service for hybrid search (vector + BM25 FTS).

Universal Language Support Strategy:
This service is designed to work well across ALL languages without requiring
language-specific tokenizers for every script.

1. **Vector Search (Primary)**: Works for ALL languages natively.
   - Qwen3-Embedding / BGE-M3 are trained on 100+ languages
   - Handles Chinese, Japanese, Korean, Arabic, Thai, Hindi, Hebrew, etc.
   - No tokenization needed - the models use subword/character-level encoding

2. **FTS (Supplementary)**: Works well for Latin-script languages.
   - Default Tantivy tokenizer handles English, German, French, Spanish, etc.
   - Provides exact keyword matching, stemming (en_stem, de_stem, etc.)
   - When FTS can't tokenize a script, it returns 0 results

3. **Adaptive Fusion**: Gracefully degrades when FTS can't contribute.
   - Detects when FTS returns 0 results (e.g., Chinese query)
   - Does NOT penalize vector-only results in this case
   - Full vector scores are used, fusion boost only when FTS also matches

4. **Future CJK Support**: LanceDB PR #2855 adds Jieba/Lindera tokenizers.
   - When available, CJK queries will benefit from FTS too
   - No code changes needed - fusion will automatically use FTS results

Short Query Handling:
Short queries produce embeddings that cluster tightly (smaller L2 distances).
This is solved at the EMBEDDING layer, not the scoring layer:

1. **HyDE-lite Query Expansion**: Short queries are expanded before embedding
   - Uses LLM to generate context-rich expansion (if available)
   - Falls back to instruction-based prompting
2. **Objective L2 Scores**: We keep true distance-based similarity scores
   - No rank-based normalization that loses objective info
   - Scores reflect actual semantic similarity

Python Tokenizer Support:
For universal FTS, we use Python tokenizers at the application layer:
- jieba: Chinese word segmentation

Text is tokenized before indexing and querying, transparent to LanceDB.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import asyncio
import time

import structlog

from .models import (
    MemoryIndexRecord,
    MessageIndexRecord,
    CommunityIndexRecord,
    EntityIndexRecord,
    SearchResult,
)
from .index_manager import IndexManager
from .crud_operations import CRUDOperations
from .search_operations import SearchOperations
from .schemas import EMBEDDING_DIMENSION

logger = structlog.get_logger(__name__)

# Export for backward compatibility
__all__ = ["SearchIndexService", "EMBEDDING_DIMENSION"]


class SearchIndexService:
    """LanceDB search index with vector + BM25 hybrid search.

    Tables: memories_index, messages_index, communities_index, entities_index,
    sources_index, source_chunks_index
    """

    TABLE_MEMORIES = "memories_index"
    TABLE_MESSAGES = "messages_index"
    TABLE_COMMUNITIES = "communities_index"
    TABLE_ENTITIES = "entities_index"
    TABLE_SOURCES = "sources_index"
    TABLE_SOURCE_CHUNKS = "source_chunks_index"

    def __init__(self, db_path: Union[str, Path]):
        """Initialize search index service."""
        self.index_manager = IndexManager(db_path)
        self.crud: Optional[CRUDOperations] = None
        self.search_ops: Optional[SearchOperations] = None

    async def _ensure_initialized(self) -> None:
        """Ensure service is initialized before operations."""
        if not self.index_manager._initialized:
            await self.initialize()

    async def initialize(self) -> None:
        """Initialize LanceDB connection and create tables if needed."""
        await self.index_manager.initialize()
        # Initialize CRUD and search operations after index manager is ready
        self.crud = CRUDOperations(
            self.index_manager.db, self.index_manager
        )
        self.search_ops = SearchOperations(
            self.index_manager.db,
            self.index_manager,
            self.index_manager.fts_manager,
        )

    # ==================== MEMORY OPERATIONS ====================

    async def upsert_memory(self, record: MemoryIndexRecord) -> None:
        """Upsert a memory to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_MEMORIES, record.id, record.to_dict())

    async def delete_memory(self, memory_id: str) -> None:
        """Delete a memory from the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.delete(self.TABLE_MEMORIES, memory_id)

    async def batch_upsert_memories(self, records: List[MemoryIndexRecord]) -> int:
        """Batch upsert memories to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        return await self.crud.batch_upsert(
            self.TABLE_MEMORIES, [r.to_dict() for r in records]
        )

    async def search_memories_hybrid(
        self, query_text: str, query_embedding: List[float], limit: int = 20
    ) -> List[SearchResult]:
        """Hybrid search for memories."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        results = await self.search_ops.search_hybrid(
            self.TABLE_MEMORIES, query_text, query_embedding, limit
        )
        if not results:
            # Fallback to vector-only
            return await self.search_memories_vector(query_embedding, limit)
        return results

    async def search_memories_vector(
        self, query_embedding: List[float], limit: int = 20
    ) -> List[SearchResult]:
        """Vector-only search for memories."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_vector(
            self.TABLE_MEMORIES, query_embedding, limit
        )

    async def search_memories_fts(
        self, query_text: str, limit: int = 20
    ) -> List[SearchResult]:
        """FTS-only search for memories."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_fts(self.TABLE_MEMORIES, query_text, limit)

    # ==================== MESSAGE OPERATIONS ====================

    async def upsert_message(self, record: MessageIndexRecord) -> None:
        """Upsert a message to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_MESSAGES, record.id, record.to_dict())

    async def delete_message(self, message_id: str) -> None:
        """Delete a message from the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.delete(self.TABLE_MESSAGES, message_id)

    async def delete_messages_by_thread(self, thread_id: str) -> int:
        """Delete all messages for a thread."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        return await self.crud.delete_messages_by_thread(thread_id)

    async def batch_upsert_messages(self, records: List[MessageIndexRecord]) -> int:
        """Batch upsert messages to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        return await self.crud.batch_upsert(
            self.TABLE_MESSAGES, [r.to_dict() for r in records]
        )

    async def search_messages_hybrid(
        self,
        query_text: str,
        query_embedding: List[float],
        thread_id: Optional[str] = None,
        limit: int = 20,
    ) -> List[SearchResult]:
        """Hybrid search for messages."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        where = f"thread_id = '{thread_id}'" if thread_id else None
        return await self.search_ops.search_hybrid(
            self.TABLE_MESSAGES, query_text, query_embedding, limit, where
        )

    async def search_messages_fts(
        self, query_text: str, thread_id: Optional[str] = None, limit: int = 20
    ) -> List[SearchResult]:
        """FTS-only search for messages."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        where = f"thread_id = '{thread_id}'" if thread_id else None
        return await self.search_ops.search_fts(
            self.TABLE_MESSAGES, query_text, limit, where
        )

    # ==================== COMMUNITY OPERATIONS ====================

    async def upsert_community(self, record: CommunityIndexRecord) -> None:
        """Upsert a community to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_COMMUNITIES, record.id, record.to_dict())

    async def delete_community(self, community_id: str) -> None:
        """Delete a community from the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.delete(self.TABLE_COMMUNITIES, community_id)

    async def clear_communities(self) -> None:
        """Clear all communities from the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.clear_communities()

    async def clear_table(self, table_name: str) -> None:
        """Clear all records from a specific search index table."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.clear_table(table_name)

    async def search_communities_hybrid(
        self, query_text: str, query_embedding: List[float], limit: int = 5
    ) -> List[SearchResult]:
        """Hybrid search for communities."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_hybrid(
            self.TABLE_COMMUNITIES, query_text, query_embedding, limit
        )

    # ==================== ENTITY OPERATIONS ====================

    async def upsert_entity(self, record: EntityIndexRecord) -> None:
        """Upsert an entity to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_ENTITIES, record.id, record.to_dict())

    async def delete_entity(self, entity_id: str) -> None:
        """Delete an entity from the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.delete(self.TABLE_ENTITIES, entity_id)

    async def batch_upsert_entities(self, records: List[EntityIndexRecord]) -> int:
        """Batch upsert entities to the search index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        return await self.crud.batch_upsert(
            self.TABLE_ENTITIES, [r.to_dict() for r in records]
        )

    async def search_entities_hybrid(
        self, query_text: str, query_embedding: List[float], limit: int = 10
    ) -> List[SearchResult]:
        """Hybrid search for entities."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_hybrid(
            self.TABLE_ENTITIES, query_text, query_embedding, limit
        )

    async def search_entities_fts(self, query_text: str, limit: int = 10) -> List[SearchResult]:
        """FTS-only search for entities."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_fts(self.TABLE_ENTITIES, query_text, limit)

    # ==================== SOURCE OPERATIONS ====================

    async def upsert_source(self, record_id: str, data: dict) -> None:
        """Upsert a source to the sources_index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_SOURCES, record_id, data)

    async def delete_source(self, source_id: str) -> None:
        """Delete a source from the sources_index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.delete(self.TABLE_SOURCES, source_id)

    async def upsert_source_chunk(self, chunk_id: str, data: dict) -> None:
        """Upsert a source chunk to the source_chunks_index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        await self.crud.upsert(self.TABLE_SOURCE_CHUNKS, chunk_id, data)

    async def delete_source_chunks(self, source_id: str) -> int:
        """Delete all chunks for a source from the source_chunks_index."""
        await self._ensure_initialized()
        assert self.crud is not None, "CRUD operations not initialized"
        return await self.crud.delete_by_filter(
            self.TABLE_SOURCE_CHUNKS,
            f"source_id = '{source_id}'",
        )

    async def search_sources_hybrid(
        self, query_text: str, query_embedding: List[float], limit: int = 10
    ) -> List[SearchResult]:
        """Hybrid search for sources."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_hybrid(
            self.TABLE_SOURCES, query_text, query_embedding, limit
        )

    async def search_sources_fts(self, query_text: str, limit: int = 10) -> List[SearchResult]:
        """FTS-only search for sources."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        return await self.search_ops.search_fts(self.TABLE_SOURCES, query_text, limit)

    async def search_source_chunks_hybrid(
        self,
        query_text: str,
        query_embedding: List[float],
        source_id: Optional[str] = None,
        limit: int = 20,
    ) -> List[SearchResult]:
        """Hybrid search for source chunks."""
        await self._ensure_initialized()
        assert self.search_ops is not None, "Search operations not initialized"
        where = f"source_id = '{source_id}'" if source_id else None
        return await self.search_ops.search_hybrid(
            self.TABLE_SOURCE_CHUNKS, query_text, query_embedding, limit, where
        )

    # ==================== UTILITY ====================

    async def get_index_stats(self) -> Dict[str, Any]:
        """Get statistics for all index tables."""
        await self._ensure_initialized()
        loop = asyncio.get_event_loop()
        stats = {}

        for table_name in [
            self.TABLE_MEMORIES,
            self.TABLE_MESSAGES,
            self.TABLE_COMMUNITIES,
            self.TABLE_ENTITIES,
            self.TABLE_SOURCES,
            self.TABLE_SOURCE_CHUNKS,
        ]:
            try:
                table = self.index_manager.db.open_table(table_name)  # type: ignore[union-attr]
                count = await loop.run_in_executor(None, lambda t=table: t.count_rows())
                stats[table_name] = {"count": count}
            except Exception as e:
                stats[table_name] = {"count": 0, "error": str(e)}

        return stats

    async def optimize_indices(self) -> None:
        """Optimize all indices after data changes."""
        await self._ensure_initialized()
        await self.index_manager.optimize_indices()

    async def rebuild_fts_indices(self) -> None:
        """Rebuild all FTS indices (useful after bulk operations)."""
        await self._ensure_initialized()
        assert self.index_manager.fts_manager is not None, "FTS manager not initialized"
        table_names = [
            self.TABLE_MEMORIES,
            self.TABLE_MESSAGES,
            self.TABLE_COMMUNITIES,
            self.TABLE_ENTITIES,
            self.TABLE_SOURCES,
            self.TABLE_SOURCE_CHUNKS,
        ]
        await self.index_manager.fts_manager.rebuild_all_fts_indices(table_names)
        # Clear dirty state after successful rebuild
        self.index_manager._dirty_tables.clear()
        self.index_manager._last_rebuild_time = time.time()

    async def cleanup(self) -> None:
        """Cleanup resources."""
        await self.index_manager.cleanup()
        self.crud = None
        self.search_ops = None

    # Backward compatibility properties
    @property
    def db(self):
        """Backward compatibility: access to db."""
        return self.index_manager.db

    @property
    def _initialized(self) -> bool:
        """Backward compatibility: check if initialized."""
        return self.index_manager._initialized
