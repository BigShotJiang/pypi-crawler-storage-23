"""Bulk import helpers for data transfer."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

from nowledge_graph_server.services.data_transfer_utils import (
    _escape_identifier,
    _sanitize_table_name,
)

_NODE_BULK_BATCH_SIZE = 5000
_REL_BULK_BATCH_SIZE = 5000


class DataTransferBulkMixin:
    def _iter_jsonl_batches(
        self,
        jsonl_path: Path,
        record_builder: Any,
        batch_size: int,
        prefix: str,
    ) -> Iterable[Tuple[Path, int]]:
        temp_file = None
        batch_count = 0
        first = True

        def _start_file() -> Any:
            nonlocal first, batch_count
            batch_count = 0
            first = True
            tmp = tempfile.NamedTemporaryFile(prefix=prefix, suffix=".json", delete=False)
            tmp.write(b"[")
            return tmp

        def _finalize_file(tmp: Any, count: int) -> Optional[Tuple[Path, int]]:
            tmp.write(b"]")
            tmp.close()
            if count == 0:
                try:
                    Path(tmp.name).unlink(missing_ok=True)
                except Exception:
                    pass
                return None
            return (Path(tmp.name), count)

        with jsonl_path.open("r", encoding="utf-8") as src:
            for line in src:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except Exception:
                    continue
                if not isinstance(record, dict):
                    continue
                payload = record_builder(record)
                if payload is None:
                    continue
                if temp_file is None:
                    temp_file = _start_file()
                if batch_count >= batch_size:
                    finalized = _finalize_file(temp_file, batch_count)
                    if finalized is not None:
                        yield finalized
                    temp_file = _start_file()
                data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                if not first:
                    temp_file.write(b",")
                temp_file.write(data)
                first = False
                batch_count += 1

        if temp_file is not None:
            finalized = _finalize_file(temp_file, batch_count)
            if finalized is not None:
                yield finalized

    def _build_load_with_headers(
        self,
        columns: Dict[str, Optional[str]],
        include_from_to: bool = False,
    ) -> str:
        parts: list[str] = []
        if include_from_to:
            parts.append("from STRING")
            parts.append("to STRING")
        if columns:
            for name, col_type in columns.items():
                if name in {"from", "to"}:
                    continue
                type_value = col_type or "STRING"
                parts.append(f"{name} {type_value}")
        if not include_from_to and "id" not in columns:
            parts.insert(0, "id STRING")
        if not parts:
            return "LOAD FROM"
        return f"LOAD WITH HEADERS ({', '.join(parts)}) FROM"

    def _merge_value_expression(
        self,
        alias: str,
        column: str,
        col_type: Optional[str],
        var_name: str,
    ) -> str:
        prop_ref = f"{alias}.{_escape_identifier(column)}"
        value_ref = var_name
        empty_checks = [f"{prop_ref} IS NULL"]
        value_checks = [f"{value_ref} IS NOT NULL"]
        if col_type == "STRING":
            empty_checks.append(f"{prop_ref} = ''")
            value_checks.append(f"{value_ref} <> ''")
        elif col_type in {"STRING[]", "FLOAT[]"}:
            empty_checks.append(
                f"(CASE WHEN {prop_ref} IS NULL THEN 0 ELSE size({prop_ref}) END) = 0"
            )
            value_checks.append(
                f"(CASE WHEN {value_ref} IS NULL THEN 0 ELSE size({value_ref}) END) > 0"
            )
        empty_clause = " OR ".join(empty_checks)
        value_clause = " AND ".join(value_checks)
        return (
            f"{prop_ref} = CASE WHEN ({empty_clause}) AND ({value_clause}) "
            f"THEN {value_ref} ELSE {prop_ref} END"
        )

    def _overwrite_value_expression(self, alias: str, column: str, var_name: str) -> str:
        prop_ref = f"{alias}.{_escape_identifier(column)}"
        value_ref = var_name
        return f"{prop_ref} = CASE WHEN {value_ref} IS NULL THEN {prop_ref} ELSE {value_ref} END"

    def _bulk_import_nodes_jsonl(
        self,
        table: str,
        jsonl_path: Path,
        columns: Dict[str, Optional[str]],
        warnings: list[str],
        mode: str,
    ) -> int:
        total = 0

        def build_record(record: Dict[str, Any]) -> Optional[Dict[str, Any]]:
            record = {
                k: v
                for k, v in record.items()
                if isinstance(k, str) and not k.startswith("_")
            }
            record.pop("embedding", None)
            if not record.get("id"):
                return None
            if columns:
                record = {k: record.get(k) for k in columns.keys() if k in record}
            return record

        for batch_path, batch_count in self._iter_jsonl_batches(
            jsonl_path,
            build_record,
            _NODE_BULK_BATCH_SIZE,
            f"nmem-bulk-{table}-",
        ):
            try:
                self._load_nodes_batch(table, batch_path, columns, mode)
                total += batch_count
            finally:
                try:
                    batch_path.unlink(missing_ok=True)
                except Exception:
                    pass
            self._checkpoint(warnings, f"nodes {table} (bulk batch)")

        if total:
            warnings.append(
                f"Bulk import used for {table}; created/updated counts may be approximate."
            )
        return total

    def _bulk_import_relationships_jsonl(
        self,
        rel_table: str,
        jsonl_path: Path,
        columns: Dict[str, Optional[str]],
        warnings: list[str],
        mode: str,
        include_node_fn: Any,
    ) -> int:
        rel_safe = _sanitize_table_name(rel_table)
        total = 0

        writers: Dict[Tuple[str, str], Dict[str, Any]] = {}

        def _start_writer(pair: Tuple[str, str]) -> Dict[str, Any]:
            tmp = tempfile.NamedTemporaryFile(
                prefix=f"nmem-bulk-{rel_safe}-{pair[0]}-{pair[1]}-",
                suffix=".json",
                delete=False,
            )
            tmp.write(b"[")
            return {"file": tmp, "count": 0, "first": True}

        def _flush_writer(pair: Tuple[str, str], writer: Dict[str, Any]) -> None:
            nonlocal total
            fh = writer["file"]
            count = writer["count"]
            fh.write(b"]")
            fh.close()
            if count == 0:
                Path(fh.name).unlink(missing_ok=True)
                return
            try:
                self._load_relationship_batch(rel_table, Path(fh.name), columns, pair, mode)
                total += count
            finally:
                Path(fh.name).unlink(missing_ok=True)
            self._checkpoint(warnings, f"relationships {rel_table} (bulk batch)")
            writer.update(_start_writer(pair))

        with jsonl_path.open("r", encoding="utf-8") as src:
            for line in src:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except Exception:
                    continue
                if not isinstance(record, dict):
                    continue
                record = {
                    k: v
                    for k, v in record.items()
                    if isinstance(k, str) and not k.startswith("_")
                }
                start_label = record.get("start_label")
                end_label = record.get("end_label")
                start_id = record.get("start_id")
                end_id = record.get("end_id")
                if not start_label or not end_label or not start_id or not end_id:
                    continue
                if not include_node_fn(str(start_label)) or not include_node_fn(str(end_label)):
                    continue
                props = record.get("properties") or {}
                if not isinstance(props, dict):
                    props = {}
                payload: Dict[str, Any] = {"from": start_id, "to": end_id}
                if columns:
                    for key in columns.keys():
                        if key in {"from", "to"}:
                            continue
                        if key in props:
                            payload[key] = props.get(key)
                pair = (str(start_label), str(end_label))
                writer = writers.get(pair)
                if writer is None:
                    writer = _start_writer(pair)
                    writers[pair] = writer
                fh = writer["file"]
                if not writer["first"]:
                    fh.write(b",")
                fh.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
                writer["first"] = False
                writer["count"] += 1
                if writer["count"] >= _REL_BULK_BATCH_SIZE:
                    _flush_writer(pair, writer)
                    writers[pair] = writer

        for pair, writer in list(writers.items()):
            if writer["count"] > 0:
                try:
                    self._load_relationship_batch(rel_table, Path(writer["file"].name), columns, pair, mode)
                    total += writer["count"]
                finally:
                    Path(writer["file"].name).unlink(missing_ok=True)
                self._checkpoint(warnings, f"relationships {rel_table} (bulk batch)")
            else:
                try:
                    Path(writer["file"].name).unlink(missing_ok=True)
                except Exception:
                    pass

        if total:
            warnings.append(
                f"Bulk import used for {rel_table}; created/updated counts may be approximate."
            )
        return total

    def _load_nodes_batch(
        self,
        table: str,
        json_path: Path,
        columns: Dict[str, Optional[str]],
        mode: str,
    ) -> None:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        load_clause = self._build_load_with_headers(columns)
        set_cols = [c for c in columns.keys() if c != "id"]
        create_sets = ", ".join(
            [f"n.{_escape_identifier(col)} = {col}" for col in set_cols]
        )
        overwrite_sets = ", ".join(
            [self._overwrite_value_expression("n", col, col) for col in set_cols]
        )
        merge_sets = ", ".join(
            [
                self._merge_value_expression("n", col, columns.get(col), col)
                for col in set_cols
            ]
        )

        query = f"{load_clause} '{json_path}' MERGE (n:{table_safe} {{id: id}})"
        if create_sets:
            query += f" ON CREATE SET {create_sets}"
        if mode == "overwrite":
            if overwrite_sets:
                query += f" ON MATCH SET {overwrite_sets}"
        elif mode == "merge":
            if merge_sets:
                query += f" ON MATCH SET {merge_sets}"
        result = conn.execute(query)
        self._close_result(result)

    def _load_relationship_batch(
        self,
        rel_table: str,
        json_path: Path,
        columns: Dict[str, Optional[str]],
        pair: Tuple[str, str],
        mode: str,
    ) -> None:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        rel_safe = _sanitize_table_name(rel_table)
        from_label, to_label = pair
        from_safe = _sanitize_table_name(from_label)
        to_safe = _sanitize_table_name(to_label)
        load_clause = self._build_load_with_headers(columns, include_from_to=True)
        prop_cols = [c for c in columns.keys() if c not in {"from", "to"}]
        with_clause = "WITH from AS start_id, to AS end_id"
        if prop_cols:
            with_clause += ", " + ", ".join(prop_cols)
        prop_assignments = ", ".join(
            [f"{_escape_identifier(col)}: {col}" for col in prop_cols]
        )
        create_prop_clause = f" {{ {prop_assignments} }}" if prop_assignments else ""
        create_set_clause = ", ".join(
            [f"r.{_escape_identifier(col)} = {col}" for col in prop_cols]
        )

        if mode == "overwrite":
            query = (
                f"{load_clause} '{json_path}'\n"
                f"{with_clause}\n"
                "WHERE start_id IS NOT NULL AND end_id IS NOT NULL\n"
                f"MATCH (a:{from_safe} {{id: start_id}}), (b:{to_safe} {{id: end_id}})\n"
                f"OPTIONAL MATCH (a)-[r:{rel_safe}]->(b)\n"
                "DELETE r\n"
                f"CREATE (a)-[:{rel_safe}{create_prop_clause}]->(b)"
            )
        else:
            query = (
                f"{load_clause} '{json_path}'\n"
                f"{with_clause}\n"
                "WHERE start_id IS NOT NULL AND end_id IS NOT NULL\n"
                f"MATCH (a:{from_safe} {{id: start_id}}), (b:{to_safe} {{id: end_id}})\n"
                f"MERGE (a)-[r:{rel_safe}]->(b)"
            )
            if create_set_clause:
                query += f" ON CREATE SET {create_set_clause}"

        result = conn.execute(query)
        self._close_result(result)
