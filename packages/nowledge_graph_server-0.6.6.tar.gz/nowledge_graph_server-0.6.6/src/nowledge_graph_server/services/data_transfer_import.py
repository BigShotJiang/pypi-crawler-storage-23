"""Import implementation for data transfer."""

from __future__ import annotations

import json
import shutil
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import structlog

from nowledge_graph_server.agent.paths import (
    get_ai_now_home,
    get_sources_home,
    get_working_memory_path,
)
from nowledge_graph_server.services.data_transfer_bulk import DataTransferBulkMixin
from nowledge_graph_server.services.data_transfer_models import (
    EXPORT_FORMAT,
    EXPORT_VERSION,
    ImportOptions,
)
from nowledge_graph_server.services.data_transfer_utils import (
    _coerce_value_for_column,
    _ensure_dir,
    _escape_identifier,
    _files_equal,
    _node_to_dict,
    _sanitize_table_name,
)

logger = structlog.get_logger(__name__)


class DataTransferImportMixin(DataTransferBulkMixin):
    def import_data(self, import_path: Path, options: ImportOptions) -> Dict[str, Any]:
        self._ensure_initialized()
        if not self.db.conn:
            raise RuntimeError("Database connection not available")

        if not import_path.exists():
            raise FileNotFoundError(f"Import path not found: {import_path}")

        if options.mode not in {"merge", "skip", "overwrite"}:
            options.mode = "merge"

        temp_dir: Optional[tempfile.TemporaryDirectory] = None
        try:
            root_dir = import_path
            if import_path.is_file() and zipfile.is_zipfile(import_path):
                temp_dir = tempfile.TemporaryDirectory(prefix="nmem-import-")
                with zipfile.ZipFile(import_path, "r") as zf:
                    zf.extractall(temp_dir.name)
                root_dir = Path(temp_dir.name)
                # Export zips always have files at root; no nested dir enforced
            if (root_dir / "manifest.json").exists():
                export_root = root_dir
            else:
                # If extracted into a folder, look for manifest inside first-level dir
                candidates = list(root_dir.glob("*/manifest.json"))
                if not candidates:
                    raise FileNotFoundError("manifest.json not found in import bundle")
                export_root = candidates[0].parent

            manifest = json.loads((export_root / "manifest.json").read_text(encoding="utf-8"))
            format_name = manifest.get("format")
            if format_name != EXPORT_FORMAT:
                raise ValueError(f"Unsupported export format: {format_name}")
            if int(manifest.get("format_version", 0)) > EXPORT_VERSION:
                logger.warning(
                    "Importing newer export format",
                    export_version=manifest.get("format_version"),
                    supported_version=EXPORT_VERSION,
                )

            include_nodes = {
                "Memory": options.include_memories,
                "Thread": options.include_threads,
                "Message": options.include_messages,
                "Entity": options.include_entities,
                "Label": options.include_labels,
                "Source": options.include_sources,
                "Community": options.include_communities,
            }

            def should_include_node(table: str) -> bool:
                if table in include_nodes:
                    return include_nodes[table]
                return True

            counts = {"nodes": {}, "relationships": {}, "working_memory": {}, "sources": {}}
            warnings: list[str] = []

            backup_info = self._create_db_backup(warnings)

            bulk_nodes_ready = self._ensure_json_extension_loaded(warnings)
            bulk_rels_ready = bulk_nodes_ready

            self._enable_spill_to_disk(warnings)

            nodes_dir = export_root / "nodes"
            if nodes_dir.exists():
                for file_path in nodes_dir.glob("*.jsonl"):
                    table = file_path.stem
                    if not should_include_node(table):
                        continue
                    try:
                        columns = self._get_table_columns(table)
                    except Exception as e:
                        warnings.append(f"Table {table} not found; skipped ({e})")
                        continue
                    if bulk_nodes_ready:
                        try:
                            processed = self._bulk_import_nodes_jsonl(
                                table, file_path, columns, warnings, options.mode
                            )
                            counts["nodes"][table] = {
                                "created": processed,
                                "updated": 0,
                                "skipped": 0,
                            }
                            self._checkpoint(warnings, f"nodes {table}")
                            continue
                        except Exception as e:
                            warnings.append(
                                f"Bulk import failed for {table}, falling back to row import: {e}"
                            )
                    created = 0
                    updated = 0
                    skipped = 0
                    processed = 0
                    with file_path.open("r", encoding="utf-8") as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            record = json.loads(line)
                            record = record if isinstance(record, dict) else {}
                            record = {
                                k: v
                                for k, v in record.items()
                                if isinstance(k, str) and not k.startswith("_")
                            }
                            if "embedding" in record:
                                record.pop("embedding", None)
                            record_id = record.get("id")
                            if not record_id:
                                skipped += 1
                                continue
                            props = {
                                k: _coerce_value_for_column(v, columns.get(k))
                                for k, v in record.items()
                                if (not columns or k in columns) and k != "embedding"
                            }
                            exists = self._node_exists(table, record_id)
                            if exists and options.mode == "skip":
                                skipped += 1
                                continue
                            if not exists:
                                self._create_node(table, props)
                                created += 1
                            else:
                                merged = self._merge_properties(
                                    table, record_id, props, columns, mode=options.mode
                                )
                                if merged:
                                    updated += 1
                                else:
                                    skipped += 1
                            processed += 1
                            if processed % 2000 == 0:
                                self._checkpoint(warnings, f"nodes {table} (batch)")
                    counts["nodes"][table] = {
                        "created": created,
                        "updated": updated,
                        "skipped": skipped,
                    }
                    self._checkpoint(warnings, f"nodes {table}")

            # Relationships
            if options.include_edges:
                rels_dir = export_root / "relationships"
                if rels_dir.exists():
                    for file_path in rels_dir.glob("*.jsonl"):
                        rel_table = file_path.stem
                        try:
                            columns = self._get_table_columns(rel_table)
                        except Exception as e:
                            warnings.append(f"Relationship table {rel_table} not found; skipped ({e})")
                            continue
                        if bulk_rels_ready:
                            try:
                                processed = self._bulk_import_relationships_jsonl(
                                    rel_table,
                                    file_path,
                                    columns,
                                    warnings,
                                    options.mode,
                                    should_include_node,
                                )
                                counts["relationships"][rel_table] = {
                                    "created": processed,
                                    "updated": 0,
                                    "skipped": 0,
                                }
                                self._checkpoint(warnings, f"relationships {rel_table}")
                                continue
                            except Exception as e:
                                warnings.append(
                                    f"Bulk import failed for {rel_table}, falling back to row import: {e}"
                                )
                        created = 0
                        skipped = 0
                        updated = 0
                        processed = 0
                        with file_path.open("r", encoding="utf-8") as f:
                            for line in f:
                                line = line.strip()
                                if not line:
                                    continue
                                record = json.loads(line)
                                if not isinstance(record, dict):
                                    continue
                                record = {
                                    k: v
                                    for k, v in record.items()
                                    if isinstance(k, str) and not k.startswith("_")
                                }
                                start_label = record.get("start_label")
                                end_label = record.get("end_label")
                                start_id = record.get("start_id")
                                end_id = record.get("end_id")
                                if not start_label or not end_label or not start_id or not end_id:
                                    skipped += 1
                                    continue
                                if not should_include_node(start_label) or not should_include_node(end_label):
                                    skipped += 1
                                    continue
                                props = record.get("properties") or {}
                                if not isinstance(props, dict):
                                    props = {}
                                props = {
                                    k: _coerce_value_for_column(v, columns.get(k))
                                    for k, v in props.items()
                                    if (not columns or k in columns)
                                }
                                if options.mode == "overwrite":
                                    self._delete_relationship(rel_table, start_label, start_id, end_label, end_id)
                                    self._create_relationship(rel_table, start_label, start_id, end_label, end_id, props)
                                    updated += 1
                                else:
                                    created_rel = self._create_relationship_if_missing(
                                        rel_table, start_label, start_id, end_label, end_id, props
                                    )
                                    if created_rel:
                                        created += 1
                                    else:
                                        skipped += 1
                                processed += 1
                                if processed % 4000 == 0:
                                    self._checkpoint(warnings, f"relationships {rel_table} (batch)")
                        counts["relationships"][rel_table] = {
                            "created": created,
                            "updated": updated,
                            "skipped": skipped,
                        }
                        self._checkpoint(warnings, f"relationships {rel_table}")

            # Working Memory
            if options.include_working_memory:
                wm_file = export_root / "working_memory.md"
                if wm_file.exists():
                    counts["working_memory"]["current"] = self._merge_working_memory(
                        wm_file, manifest, options.mode
                    )
                else:
                    warnings.append("working_memory.md not found in import bundle")

            if options.include_working_memory_archive:
                archive_src = export_root / "working_memory_archive"
                if archive_src.exists():
                    counts["working_memory"]["archive"] = self._merge_working_memory_archive(
                        archive_src, manifest
                    )
                else:
                    warnings.append("working_memory_archive not found in import bundle")

            # Sources (Library files)
            if options.include_sources and options.include_source_files:
                sources_src = export_root / "sources"
                if sources_src.exists():
                    counts["sources"] = self._merge_sources(
                        sources_src, manifest, options.mode
                    )
                else:
                    warnings.append("sources folder not found in import bundle")

            self._checkpoint(warnings, "import completion")

            if self._should_mark_reindex(counts, options):
                self._mark_reindex_needed(warnings)
            self._audit_communities(options, warnings)

            return {
                "success": True,
                "counts": counts,
                "warnings": warnings,
                "export_id": manifest.get("export_id"),
                "backup": backup_info,
            }
        finally:
            if temp_dir is not None:
                temp_dir.cleanup()

    # ---- Backup helpers ----

    def _create_db_backup(self, warnings: list[str]) -> Dict[str, Any]:
        base_client = getattr(self.db, "base_client", None)
        db_path = getattr(base_client, "db_path", None)
        if not db_path:
            warnings.append("Database path unavailable; backup skipped.")
            return {}
        try:
            self._checkpoint(warnings, "pre-import backup")
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            backup_path = Path(db_path).parent / f"{Path(db_path).name}.backup.{ts}"
            shutil.copy2(db_path, backup_path)
            extra_paths: list[str] = []
            for suffix in (".wal", ".shadow"):
                src = Path(str(db_path) + suffix)
                if src.exists():
                    dest = Path(str(backup_path) + suffix)
                    shutil.copy2(src, dest)
                    extra_paths.append(str(dest))
            return {"path": str(backup_path), "extra_paths": extra_paths}
        except Exception as e:
            warnings.append(f"Failed to create database backup: {e}")
            return {}

    # ---- Node helpers ----

    def _should_mark_reindex(self, counts: Dict[str, Any], options: ImportOptions) -> bool:
        if not (options.include_memories or options.include_messages or options.include_threads):
            return False
        node_counts = counts.get("nodes", {})
        for table in ("Memory", "Message", "Thread"):
            stats = node_counts.get(table)
            if stats and (stats.get("created", 0) or stats.get("updated", 0)):
                return True
        return False

    def _audit_communities(self, options: ImportOptions, warnings: list[str]) -> None:
        if not (options.include_communities or options.include_entities or options.include_memories):
            return
        conn = self.db.conn
        if not conn:
            return
        try:
            result = conn.execute("MATCH (c:Community) RETURN COUNT(c)")
            community_count = 0
            if getattr(result, "has_next", lambda: False)():
                row = result.get_next()
                community_count = int(row[0]) if row else 0
            self._close_result(result)

            if not options.include_communities:
                return

            result = conn.execute(
                "MATCH (e:Entity) WHERE e.community_id IS NOT NULL RETURN COUNT(e)"
            )
            entity_with_community = 0
            if getattr(result, "has_next", lambda: False)():
                row = result.get_next()
                entity_with_community = int(row[0]) if row else 0
            self._close_result(result)

            result = conn.execute(
                "MATCH (m:Memory) WHERE m.community_id IS NOT NULL RETURN COUNT(m)"
            )
            memory_with_community = 0
            if getattr(result, "has_next", lambda: False)():
                row = result.get_next()
                memory_with_community = int(row[0]) if row else 0
            self._close_result(result)

            if community_count == 0:
                warnings.append(
                    "No Community nodes are present after import. Run Community Detection to rebuild community groups."
                )
            elif entity_with_community == 0 and memory_with_community == 0:
                warnings.append(
                    "Communities imported but no nodes have community assignments. Run Community Detection to refresh community groups."
                )
        except Exception as e:
            warnings.append(f"Community validation skipped: {e}")

    def _node_exists(self, table: str, node_id: str) -> bool:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        result = conn.execute(
            f"MATCH (n:{table_safe} {{id: $id}}) RETURN n.id",
            {"id": node_id},
        )
        try:
            has_row = bool(getattr(result, "has_next", lambda: False)())
            if has_row and getattr(result, "get_next", None):
                result.get_next()
            return has_row
        finally:
            self._close_result(result)

    def _create_node(self, table: str, props: Dict[str, Any]) -> None:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        cols = list(props.keys())
        if not cols:
            return
        assignments = ", ".join([f"{_escape_identifier(col)}: ${col}" for col in cols])
        query = f"CREATE (n:{table_safe} {{ {assignments} }})"
        result = conn.execute(query, props)
        self._close_result(result)

    def _merge_properties(
        self,
        table: str,
        node_id: str,
        props: Dict[str, Any],
        columns: Dict[str, Optional[str]],
        mode: str,
    ) -> bool:
        if mode == "skip":
            return False
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        result = conn.execute(
            f"MATCH (n:{table_safe} {{id: $id}}) RETURN n",
            {"id": node_id},
        )
        if not getattr(result, "has_next", lambda: False)():
            self._close_result(result)
            return False
        row = result.get_next()
        self._close_result(result)
        existing = row[0] if row else {}
        existing_props = _node_to_dict(existing)
        merged: Dict[str, Any] = {}
        for key, value in props.items():
            if key == "id":
                merged[key] = value
                continue
            if mode == "overwrite":
                merged[key] = value
            else:
                current = existing_props.get(key)
                if current in (None, "", [], {}):
                    merged[key] = value
                else:
                    merged[key] = current
        if len(merged) <= 1:
            return False
        set_cols = [k for k in merged.keys() if k != "id" and (not columns or k in columns)]
        if not set_cols:
            return False
        set_clause = ", ".join([f"n.{_escape_identifier(col)} = ${col}" for col in set_cols])
        params = {col: merged[col] for col in set_cols}
        params["id"] = node_id
        result = conn.execute(
            f"MATCH (n:{table_safe} {{id: $id}}) SET {set_clause}",
            params,
        )
        self._close_result(result)
        return True

    # ---- Bulk copy helpers (skip mode only) ----

    def _ensure_json_extension_loaded(self, warnings: list[str]) -> bool:
        conn = self.db.conn
        if not conn:
            return False
        try:
            result = conn.execute("CALL show_loaded_extensions() RETURN *")
            loaded = False
            if hasattr(result, "has_next"):
                while result.has_next():
                    row = result.get_next()
                    if row and str(row[0]).lower() == "json":
                        loaded = True
                        break
            self._close_result(result)
            if loaded:
                return True
            try:
                conn.execute("INSTALL json; LOAD json;")
            except Exception:
                conn.execute("LOAD json;")
            return True
        except Exception as e:
            warnings.append(f"JSON extension not available; bulk import disabled: {e}")
            return False

    def _enable_spill_to_disk(self, warnings: list[str]) -> None:
        conn = self.db.conn
        if not conn:
            return
        try:
            result = conn.execute("CALL spill_to_disk=true")
            self._close_result(result)
        except Exception as e:
            warnings.append(f"Could not enable spill-to-disk: {e}")

    def _bulk_copy_nodes_jsonl(
        self,
        table: str,
        jsonl_path: Path,
        columns: Dict[str, Optional[str]],
        warnings: list[str],
    ) -> int:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        table_safe = _sanitize_table_name(table)
        temp_json = tempfile.NamedTemporaryFile(
            prefix=f"nmem-copy-{table_safe}-", suffix=".json", delete=False
        )
        created = 0
        try:
            with temp_json as tmp:
                tmp.write(b"[")
                first = True
                with jsonl_path.open("r", encoding="utf-8") as src:
                    for line in src:
                        line = line.strip()
                        if not line:
                            continue
                        record = json.loads(line)
                        if not isinstance(record, dict):
                            continue
                        record = {
                            k: v
                            for k, v in record.items()
                            if isinstance(k, str) and not k.startswith("_")
                        }
                        record.pop("embedding", None)
                        if not record.get("id"):
                            continue
                        if columns:
                            record = {k: record.get(k) for k in columns.keys() if k in record}
                        payload = json.dumps(record, ensure_ascii=False).encode("utf-8")
                        if not first:
                            tmp.write(b",")
                        tmp.write(payload)
                        first = False
                        created += 1
                tmp.write(b"]")

            cols = list(columns.keys()) if columns else []
            column_clause = f"({', '.join(cols)})" if cols else ""
            query = (
                f"COPY {table_safe}{column_clause} FROM '{temp_json.name}' (file_format='json', ignore_errors=true)"
            )
            result = conn.execute(query)
            self._close_result(result)
            if created:
                warnings.append(
                    f"Bulk import used for {table}; counts are approximate when duplicates are skipped."
                )
            return created
        finally:
            try:
                Path(temp_json.name).unlink(missing_ok=True)
            except Exception:
                pass

    def _bulk_copy_relationships_jsonl(
        self,
        rel_table: str,
        jsonl_path: Path,
        columns: Dict[str, Optional[str]],
        warnings: list[str],
    ) -> int:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        rel_safe = _sanitize_table_name(rel_table)

        # Split by (start_label, end_label) to support multi-connection tables.
        files: Dict[Tuple[str, str], tempfile.NamedTemporaryFile] = {}
        counts: Dict[Tuple[str, str], int] = {}
        first_flags: Dict[Tuple[str, str], bool] = {}
        try:
            with jsonl_path.open("r", encoding="utf-8") as src:
                for line in src:
                    line = line.strip()
                    if not line:
                        continue
                    record = json.loads(line)
                    if not isinstance(record, dict):
                        continue
                    record = {
                        k: v
                        for k, v in record.items()
                        if isinstance(k, str) and not k.startswith("_")
                    }
                    start_label = record.get("start_label")
                    end_label = record.get("end_label")
                    start_id = record.get("start_id")
                    end_id = record.get("end_id")
                    if not start_label or not end_label or not start_id or not end_id:
                        continue
                    pair = (str(start_label), str(end_label))
                    if pair not in files:
                        temp_json = tempfile.NamedTemporaryFile(
                            prefix=f"nmem-copy-{rel_safe}-{pair[0]}-{pair[1]}-",
                            suffix=".json",
                            delete=False,
                        )
                        files[pair] = temp_json
                        counts[pair] = 0
                        first_flags[pair] = True
                        temp_json.write(b"[")
                    props = record.get("properties") or {}
                    if not isinstance(props, dict):
                        props = {}
                    payload_obj = {"from": start_id, "to": end_id, **props}
                    if columns:
                        filtered = {k: payload_obj.get(k) for k in columns.keys() if k in payload_obj}
                        payload_obj = {**filtered, "from": start_id, "to": end_id}
                    payload = json.dumps(payload_obj, ensure_ascii=False).encode("utf-8")
                    fh = files[pair]
                    if not first_flags[pair]:
                        fh.write(b",")
                    fh.write(payload)
                    first_flags[pair] = False
                    counts[pair] += 1

            total_created = 0
            for pair, fh in files.items():
                fh.write(b"]")
                fh.close()
                from_label, to_label = pair
                query = (
                    f"COPY {rel_safe} FROM '{fh.name}' (file_format='json', ignore_errors=true, from='{_sanitize_table_name(from_label)}', to='{_sanitize_table_name(to_label)}')"
                )
                result = conn.execute(query)
                self._close_result(result)
                total_created += counts.get(pair, 0)
            if total_created:
                warnings.append(
                    f"Bulk import used for {rel_table}; counts are approximate when duplicates are skipped."
                )
            return total_created
        finally:
            for fh in files.values():
                try:
                    Path(fh.name).unlink(missing_ok=True)
                except Exception:
                    pass

    # ---- Relationship helpers ----

    def _create_relationship_if_missing(
        self,
        rel_table: str,
        start_label: str,
        start_id: str,
        end_label: str,
        end_id: str,
        props: Dict[str, Any],
    ) -> bool:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        rel_safe = _sanitize_table_name(rel_table)
        start_safe = _sanitize_table_name(start_label)
        end_safe = _sanitize_table_name(end_label)
        exists_query = f"""
            MATCH (a:{start_safe} {{id: $start_id}})-[r:{rel_safe}]->(b:{end_safe} {{id: $end_id}})
            RETURN COUNT(r)
        """
        exists_result = conn.execute(
            exists_query, {"start_id": start_id, "end_id": end_id}
        )
        try:
            if getattr(exists_result, "has_next", lambda: False)():
                count = exists_result.get_next()[0]
                if count and int(count) > 0:
                    return False
        finally:
            self._close_result(exists_result)
        prop_clause = ""
        if props:
            assignments = ", ".join([f"{_escape_identifier(k)}: ${k}" for k in props.keys()])
            prop_clause = f" {{ {assignments} }}"
        query = f"""
            MATCH (a:{start_safe} {{id: $start_id}}), (b:{end_safe} {{id: $end_id}})
            CREATE (a)-[:{rel_safe}{prop_clause}]->(b)
        """
        params = {"start_id": start_id, "end_id": end_id, **props}
        result = conn.execute(query, params)
        self._close_result(result)
        return True

    def _create_relationship(
        self,
        rel_table: str,
        start_label: str,
        start_id: str,
        end_label: str,
        end_id: str,
        props: Dict[str, Any],
    ) -> None:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        rel_safe = _sanitize_table_name(rel_table)
        start_safe = _sanitize_table_name(start_label)
        end_safe = _sanitize_table_name(end_label)
        prop_clause = ""
        if props:
            assignments = ", ".join([f"{_escape_identifier(k)}: ${k}" for k in props.keys()])
            prop_clause = f" {{ {assignments} }}"
        query = f"""
            MATCH (a:{start_safe} {{id: $start_id}}), (b:{end_safe} {{id: $end_id}})
            CREATE (a)-[:{rel_safe}{prop_clause}]->(b)
        """
        params = {"start_id": start_id, "end_id": end_id, **props}
        result = conn.execute(query, params)
        self._close_result(result)

    def _delete_relationship(
        self,
        rel_table: str,
        start_label: str,
        start_id: str,
        end_label: str,
        end_id: str,
    ) -> None:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        rel_safe = _sanitize_table_name(rel_table)
        start_safe = _sanitize_table_name(start_label)
        end_safe = _sanitize_table_name(end_label)
        query = f"""
            MATCH (a:{start_safe} {{id: $start_id}})-[r:{rel_safe}]->(b:{end_safe} {{id: $end_id}})
            DELETE r
        """
        result = conn.execute(query, {"start_id": start_id, "end_id": end_id})
        self._close_result(result)

    # ---- Working memory & sources merge ----

    def _merge_working_memory(
        self,
        wm_file: Path,
        manifest: Dict[str, Any],
        mode: str,
    ) -> Dict[str, Any]:
        counts = {"imported_to_archive": 0, "current_overwritten": False, "current_archived": 0}
        local_wm = get_working_memory_path()
        export_date = manifest.get("exported_at")
        archive_root = get_ai_now_home() / "memory-archive"
        _ensure_dir(archive_root)

        # Preserve current working memory; store imported as archive snapshot
        if export_date:
            try:
                dt = datetime.fromisoformat(str(export_date).replace("Z", "+00:00"))
            except ValueError:
                dt = datetime.now(timezone.utc)
        else:
            dt = datetime.now(timezone.utc)
        archive_dir = archive_root / dt.strftime("%Y") / dt.strftime("%m")
        _ensure_dir(archive_dir)
        archive_path = archive_dir / f"{dt.strftime('%Y-%m-%d')}.md"
        if archive_path.exists():
            suffix = manifest.get("export_id", uuid.uuid4().hex[:6])
            archive_path = archive_dir / f"{dt.strftime('%Y-%m-%d')}-imported-{suffix}.md"
        shutil.copy2(wm_file, archive_path)
        counts["imported_to_archive"] += 1

        if mode == "overwrite":
            # Archive current WM before replacing.
            if local_wm.exists():
                now = datetime.now(timezone.utc)
                local_archive_dir = archive_root / now.strftime("%Y") / now.strftime("%m")
                _ensure_dir(local_archive_dir)
                local_archive_path = local_archive_dir / f"{now.strftime('%Y-%m-%d')}-pre-import.md"
                if local_archive_path.exists():
                    suffix = manifest.get("export_id", uuid.uuid4().hex[:6])
                    local_archive_path = local_archive_dir / f"{now.strftime('%Y-%m-%d')}-pre-import-{suffix}.md"
                shutil.copy2(local_wm, local_archive_path)
                counts["current_archived"] += 1
            _ensure_dir(local_wm.parent)
            shutil.copy2(wm_file, local_wm)
            counts["current_overwritten"] = True
        else:
            # If no current WM exists, restore to memory.md
            if not local_wm.exists():
                _ensure_dir(local_wm.parent)
                shutil.copy2(wm_file, local_wm)
                counts["current_overwritten"] = True
        return counts

    def _merge_working_memory_archive(self, archive_src: Path, manifest: Dict[str, Any]) -> Dict[str, Any]:
        counts = {"copied": 0, "skipped": 0, "conflicts": 0}
        archive_root = get_ai_now_home() / "memory-archive"
        for file_path in archive_src.rglob("*.md"):
            rel_path = file_path.relative_to(archive_src)
            dest_path = archive_root / rel_path
            _ensure_dir(dest_path.parent)
            if dest_path.exists():
                if dest_path.read_text(encoding="utf-8", errors="ignore") == file_path.read_text(encoding="utf-8", errors="ignore"):
                    counts["skipped"] += 1
                else:
                    suffix = manifest.get("export_id", uuid.uuid4().hex[:6])
                    conflict_path = dest_path.with_name(f"{dest_path.stem}-imported-{suffix}{dest_path.suffix}")
                    shutil.copy2(file_path, conflict_path)
                    counts["conflicts"] += 1
            else:
                shutil.copy2(file_path, dest_path)
                counts["copied"] += 1
        return counts

    def _merge_sources(self, sources_src: Path, manifest: Dict[str, Any], mode: str) -> Dict[str, Any]:
        counts = {"copied": 0, "skipped": 0, "conflicts": 0, "overwritten": 0}
        dest_root = get_sources_home()
        _ensure_dir(dest_root)
        conflict_suffix = manifest.get("export_id", uuid.uuid4().hex[:6])
        for item in sources_src.rglob("*"):
            rel_path = item.relative_to(sources_src)
            dest_path = dest_root / rel_path
            if item.is_dir():
                _ensure_dir(dest_path)
                continue
            _ensure_dir(dest_path.parent)
            if dest_path.exists():
                if dest_path.is_file() and _files_equal(item, dest_path):
                    counts["skipped"] += 1
                    continue
                if mode == "overwrite" and dest_path.is_file():
                    shutil.copy2(item, dest_path)
                    counts["overwritten"] += 1
                    continue
                conflict_path = dest_path.with_name(
                    f"{dest_path.stem}-imported-{conflict_suffix}{dest_path.suffix}"
                )
                shutil.copy2(item, conflict_path)
                counts["conflicts"] += 1
                continue
            shutil.copy2(item, dest_path)
            counts["copied"] += 1
        return counts
