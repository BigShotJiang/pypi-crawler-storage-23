"""
Content chunking utilities for processing long threads.

Provides intelligent content chunking that respects conversation boundaries.
"""

from typing import List

import structlog

logger = structlog.get_logger()


def chunk_content(content: str, max_chunk_size: int = 5000) -> List[str]:
    """Intelligently chunk content for processing long threads.

    Chunks content while respecting conversation message boundaries for better
    context preservation during LLM processing.

    Args:
        content: The content to chunk
        max_chunk_size: Maximum characters per chunk (default 5000)

    Returns:
        List of content chunks with proper boundaries
    """
    # For local LLM, use smaller chunks to reduce memory usage and inference time
    effective_chunk_size = min(max_chunk_size, 4000)

    if len(content) <= effective_chunk_size:
        return [content]

    chunks = []
    current_chunk = ""

    # Split by conversation boundaries first (messages)
    message_separators = [
        "\nUser:",
        "\nAssistant:",
        "\nHuman:",
        "\nAI:",
        "\nSystem:",
    ]

    # Find all message boundaries
    boundaries = _find_message_boundaries(content, message_separators)

    # Create chunks respecting message boundaries
    for i in range(len(boundaries) - 1):
        section = content[boundaries[i] : boundaries[i + 1]]

        if len(current_chunk) + len(section) <= effective_chunk_size:
            current_chunk += section
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())

            # If section is too large, split it further
            if len(section) > effective_chunk_size:
                sub_chunks, current_chunk = _split_large_section(
                    section, effective_chunk_size
                )
                chunks.extend(sub_chunks)
            else:
                current_chunk = section

    if current_chunk:
        chunks.append(current_chunk.strip())

    logger.debug(
        "Content chunked for local LLM performance",
        original_length=len(content),
        chunks_count=len(chunks),
        chunk_sizes=[len(c) for c in chunks],
        max_chunk_size=effective_chunk_size,
    )

    return chunks


def _find_message_boundaries(content: str, separators: List[str]) -> List[int]:
    """Find all message boundary positions in content."""
    boundaries = []

    for separator in separators:
        start = 0
        while True:
            pos = content.find(separator, start)
            if pos == -1:
                break
            boundaries.append(pos)
            start = pos + 1

    boundaries = sorted(set(boundaries))
    boundaries.insert(0, 0)
    boundaries.append(len(content))

    return boundaries


def _split_large_section(
    section: str, max_size: int
) -> tuple[List[str], str]:
    """Split a large section by sentences for better context.

    Args:
        section: The large section to split
        max_size: Maximum size per chunk

    Returns:
        Tuple of (completed chunks, remaining content for next chunk)
    """
    chunks = []
    sentences = section.split(". ")
    temp_chunk = ""

    for sentence in sentences:
        if len(temp_chunk) + len(sentence) <= max_size:
            temp_chunk += sentence + ". "
        else:
            if temp_chunk:
                chunks.append(temp_chunk.strip())
            temp_chunk = sentence + ". "

    # Return completed chunks and any remaining content
    remaining = temp_chunk.strip() if temp_chunk else ""
    return chunks, remaining
