"""
Optimized Level 2 extraction using 3 focused LLM calls with JSON outputs.
"""

import json
from typing import Dict, List, Any, Optional, Tuple
import structlog

from nowledge_graph_server.services.base_llm import EntityExtractionResult
from nowledge_graph_server.services.extraction_utils import LanguageDetector
from nowledge_graph_server.services.extraction_prompts_level2 import (
    LEVEL2_TOPIC_ENTITY_EXTRACTION,
    LEVEL2_ENTITY_ANALYSIS,
    LEVEL2_RELATIONSHIP_DETECTION,
    LEVEL2_QUALITY_REFINEMENT,
    LEVEL2_RELATIONSHIP_REFINEMENT,
    LEVEL2_SIMPLE_EXTRACTION,
)

logger = structlog.get_logger(__name__)


class OptimizedGuidedExtraction:
    """
    Optimized Level 2 extraction using minimal LLM calls.

    Design principles:
    1. 3 focused LLM calls with JSON outputs
    2. Each call does one clear task
    3. Language-agnostic approach
    4. Same output format as Level 1
    """

    def __init__(self, llm_generate_func, parse_json_func):
        self.llm_generate = llm_generate_func
        self.parse_json = parse_json_func

    async def extract(
        self, text: str, title: str = "", memory_index: int = 0
    ) -> EntityExtractionResult:
        """
        Extract entities using 3 focused LLM calls.
        """
        try:
            # Detect language for logging only
            language = LanguageDetector.detect_language(text)
            logger.info(
                "Starting optimized Level 2 extraction",
                language=language,
                text_length=len(text),
                memory_index=memory_index,
            )

            # Prepare full context
            full_text = f"{title}\n{text}" if title else text

            # Limit text length for LLM context window
            if len(full_text) > 2000:
                # Keep beginning and end
                full_text = full_text[:1000] + "\n...\n" + full_text[-800:]

            # Step 1: Extract topics and entities (1 LLM call)
            extraction_result = await self._extract_topics_and_entities(full_text)
            if not extraction_result:
                logger.warning("Extraction failed, trying fallback")
                return await self._fallback_extraction(full_text)

            # Extract entities and topics normally
            entities = extraction_result.get("entities", [])
            topics = extraction_result.get("topics", [])

            if not entities:
                logger.warning("No entities found, trying fallback")
                return await self._fallback_extraction(full_text)

            # Step 2: Analyze entities - type and description (1 LLM call)
            analyzed_entities = await self._analyze_entities(
                entities[:15],  # Limit to top 15 entities
                full_text[:800],  # Provide context
            )

            if not analyzed_entities:
                logger.warning("Entity analysis failed, using basic extraction")
                # Create basic entities without descriptions
                analyzed_entities = [
                    {
                        "name": entity,
                        "type": "CONCEPT",
                        "description": "",
                        "confidence": 0.6,
                    }
                    for entity in entities[:10]
                ]

            # Filter high-confidence entities for relationship detection
            important_entities = [
                e for e in analyzed_entities if e.get("confidence", 0) >= 0.7
            ][:10]  # Top 10

            # Step 3: Detect relationships with context (1 LLM call)
            relationships = []
            if len(important_entities) >= 2:
                entity_names = [e["name"] for e in important_entities]
                relationships = await self._detect_relationships(
                    entity_names,
                    full_text[:1000],  # Provide sufficient context
                )

            # Step 4: Quality refinement - filter to most important (2 LLM calls)
            if len(analyzed_entities) > 10:
                analyzed_entities = await self._refine_entities(analyzed_entities)

            if len(relationships) > 8:
                relationships = await self._refine_relationships(relationships)

            # Add extraction method metadata
            for entity in analyzed_entities:
                entity["extraction_method"] = "guided_optimized"

            for rel in relationships:
                rel["extraction_method"] = "guided_optimized"

            # Calculate overall confidence
            entity_confidences = [e.get("confidence", 0.5) for e in analyzed_entities]
            rel_confidences = [r.get("confidence", 0.5) for r in relationships]

            avg_confidence = (sum(entity_confidences) + sum(rel_confidences)) / max(
                len(entity_confidences) + len(rel_confidences), 1
            )

            return EntityExtractionResult(
                entities=analyzed_entities[:10],  # Limit final output
                relationships=relationships[:15],  # Limit relationships
                confidence=round(avg_confidence, 2),
            )

        except Exception as e:
            logger.error(
                f"Optimized extraction failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )
            return await self._fallback_extraction(text)

    async def _extract_topics_and_entities(self, text: str) -> Optional[Dict[str, Any]]:
        """Step 1: Extract significant topics and entity list."""
        prompt = LEVEL2_TOPIC_ENTITY_EXTRACTION.format(text=text)
        logger.info(f"Generated prompt for topics/entities extraction")

        try:
            response = await self.llm_generate(
                prompt=prompt,
                max_tokens=512,
                temperature=0.7,  # Low temperature for focused extraction
            )

            logger.info(f"LLM response for debugging: {response[:500]}...")
            result = self.parse_json(response)
            logger.info(f"Parse result: {result}")
            if result:
                logger.debug(
                    f"Parsed result type: {type(result)}, keys: {list(result.keys()) if isinstance(result, dict) else 'not a dict'}"
                )

                # Handle case where parse_json might return a string
                if isinstance(result, str):
                    try:
                        result = json.loads(result)
                        logger.debug("Parsed string result to dict")
                    except Exception as e:
                        logger.error(f"Failed to parse string result: {e}")
                        return None

                if isinstance(result, dict) and "entities" in result:
                    try:
                        entities_count = len(result.get("entities", []))
                        topics_count = len(result.get("topics", []))
                        logger.debug(
                            f"Extracted {entities_count} entities, {topics_count} topics"
                        )
                    except Exception as count_error:
                        logger.debug(f"Error counting entities/topics: {count_error}")
                    return result
                else:
                    logger.warning(f"Unexpected result format: {result}")
                    return None

        except Exception as e:
            logger.error(
                f"Topic/entity extraction failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        return None

    async def _analyze_entities(
        self, entities: List[str], context: str
    ) -> List[Dict[str, Any]]:
        """Step 2: Analyze entities for type and description."""
        if not entities:
            return []

        # Format entities for prompt
        entities_str = json.dumps(entities, ensure_ascii=False)

        prompt = LEVEL2_ENTITY_ANALYSIS.format(entities=entities_str, context=context)

        try:
            response = await self.llm_generate(
                prompt=prompt, max_tokens=768, temperature=0.7
            )

            result = self.parse_json(response)
            if result and "entities" in result:
                analyzed = result["entities"]
                logger.debug(f"Analyzed {len(analyzed)} entities")

                # Ensure all required fields
                for entity in analyzed:
                    entity.setdefault("confidence", 0.7)
                    entity.setdefault("description", "")
                    entity.setdefault("type", "CONCEPT")

                return analyzed

        except Exception as e:
            logger.error(
                f"Entity analysis failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        return []

    async def _detect_relationships(
        self, entities: List[str], text: str
    ) -> List[Dict[str, Any]]:
        """Step 3: Detect relationships between entities with context."""
        if len(entities) < 2:
            return []

        # Format entities for prompt
        entities_str = json.dumps(entities, ensure_ascii=False)

        prompt = LEVEL2_RELATIONSHIP_DETECTION.format(entities=entities_str, text=text)

        try:
            response = await self.llm_generate(
                prompt=prompt, max_tokens=768, temperature=0.7
            )

            result = self.parse_json(response)
            if result and "relationships" in result:
                relationships = result["relationships"]
                logger.debug(f"Detected {len(relationships)} relationships")

                # Validate relationships
                entity_set = set(entities)
                valid_relationships = []

                for rel in relationships:
                    if (
                        rel.get("source") in entity_set
                        and rel.get("target") in entity_set
                        and rel.get("relation")
                    ):
                        rel.setdefault("confidence", 0.7)
                        rel.setdefault("context", "")
                        valid_relationships.append(rel)

                return valid_relationships

        except Exception as e:
            logger.error(
                f"Relationship detection failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        return []

    async def _refine_entities(
        self, entities: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Refine entities to keep only the most important ones."""
        if not entities:
            return entities

        # Format entities for prompt
        entities_json = json.dumps({"entities": entities}, ensure_ascii=False, indent=2)

        prompt = LEVEL2_QUALITY_REFINEMENT.format(entities_json=entities_json)

        try:
            response = await self.llm_generate(
                prompt=prompt, max_tokens=512, temperature=0.7
            )

            result = self.parse_json(response)
            if result and "entities" in result:
                refined = result["entities"]
                logger.debug(f"Refined entities from {len(entities)} to {len(refined)}")
                return refined

        except Exception as e:
            logger.error(
                f"Entity refinement failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        # Return top entities by confidence if refinement fails
        return sorted(entities, key=lambda e: e.get("confidence", 0), reverse=True)[:10]

    async def _refine_relationships(
        self, relationships: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Refine relationships to keep only meaningful ones."""
        if not relationships:
            return relationships

        # Format relationships for prompt
        relationships_json = json.dumps(
            {"relationships": relationships}, ensure_ascii=False, indent=2
        )

        prompt = LEVEL2_RELATIONSHIP_REFINEMENT.format(
            relationships_json=relationships_json
        )

        try:
            response = await self.llm_generate(
                prompt=prompt, max_tokens=512, temperature=0.7
            )

            result = self.parse_json(response)
            if result and "relationships" in result:
                refined = result["relationships"]
                logger.debug(
                    f"Refined relationships from {len(relationships)} to {len(refined)}"
                )
                return refined

        except Exception as e:
            logger.error(
                f"Relationship refinement failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        # Return top relationships by confidence if refinement fails
        return sorted(
            relationships, key=lambda r: r.get("confidence", 0), reverse=True
        )[:10]

    async def _fallback_extraction(self, text: str) -> EntityExtractionResult:
        """Simple fallback when main extraction fails."""
        prompt = LEVEL2_SIMPLE_EXTRACTION.format(text=text[:1000])

        try:
            response = await self.llm_generate(
                prompt=prompt, max_tokens=384, temperature=0.7
            )

            result = self.parse_json(response)
            if result:
                # Ensure we have a dict
                if isinstance(result, str):
                    try:
                        result = json.loads(result)
                    except:
                        logger.error("Failed to parse string result from parse_json")
                        return EntityExtractionResult(
                            entities=[], relationships=[], confidence=0.1
                        )

                if not isinstance(result, dict):
                    logger.error(f"Unexpected result type: {type(result)}")
                    return EntityExtractionResult(
                        entities=[], relationships=[], confidence=0.1
                    )

                entities = []

                # Convert simple extraction to entity format
                for person in result.get("who", []):
                    entities.append(
                        {
                            "name": person,
                            "type": "PERSON",
                            "description": "",
                            "confidence": 0.6,
                            "extraction_method": "guided_fallback",
                        }
                    )

                for thing in result.get("what", []):
                    entities.append(
                        {
                            "name": thing,
                            "type": "CONCEPT",
                            "description": "",
                            "confidence": 0.6,
                            "extraction_method": "guided_fallback",
                        }
                    )

                for place in result.get("where", []):
                    entities.append(
                        {
                            "name": place,
                            "type": "LOCATION",
                            "description": "",
                            "confidence": 0.6,
                            "extraction_method": "guided_fallback",
                        }
                    )

                return EntityExtractionResult(
                    entities=entities[:8], relationships=[], confidence=0.5
                )

        except Exception as e:
            logger.error(
                f"Fallback extraction failed: {str(e)}, type: {type(e).__name__}",
                exc_info=True,
            )

        # Ultimate fallback
        return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)
