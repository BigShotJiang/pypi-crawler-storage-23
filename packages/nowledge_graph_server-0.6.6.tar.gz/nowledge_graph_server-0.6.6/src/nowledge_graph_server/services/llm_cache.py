"""
LLM result caching utilities.

Provides caching for preview results to avoid duplicate LLM calls.
"""

import hashlib
import time
from collections import OrderedDict
from typing import Any, Dict, Generic, Optional, Tuple, TypeVar

import structlog

logger = structlog.get_logger()

T = TypeVar("T")
U = TypeVar("U")


_MAX_CACHE_ENTRIES = 32
_CACHE_TTL_SECONDS = 600  # 10 minutes


class PreviewCache(Generic[T, U]):
    """LRU + TTL cache for preview results to avoid duplicate LLM calls.

    Entries are evicted when the cache exceeds _MAX_CACHE_ENTRIES (oldest
    first) or when an entry is older than _CACHE_TTL_SECONDS.  This prevents
    unbounded growth when users preview threads but never save.

    Type parameters:
        T: Entity extraction result type
        U: Memory distillation result type
    """

    def __init__(self):
        self._cache: OrderedDict[str, Tuple[float, T, U]] = OrderedDict()

    def generate_key(self, thread_content: str, thread_title: str = "") -> str:
        """Generate a cache key for the given content.

        Args:
            thread_content: Full thread conversation text
            thread_title: Optional thread title

        Returns:
            MD5 hash of content + title
        """
        content_hash = hashlib.md5(
            f"{thread_content}{thread_title}".encode()
        ).hexdigest()
        return content_hash

    def get(self, cache_key: str) -> Optional[Tuple[T, U]]:
        """Get cached results by key.

        Returns:
            Tuple of (entity_result, memory_result) or None if not found / expired.
        """
        entry = self._cache.get(cache_key)
        if entry is not None:
            ts, entity_result, memory_result = entry
            if (time.monotonic() - ts) > _CACHE_TTL_SECONDS:
                self._cache.pop(cache_key, None)
                logger.debug("CACHE EXPIRED", cache_key=cache_key)
                return None
            # Move to end (most-recently-used)
            self._cache.move_to_end(cache_key)
            logger.debug("CACHE HIT", cache_key=cache_key)
            return (entity_result, memory_result)

        logger.debug("CACHE MISS", cache_key=cache_key)
        return None

    def set(self, cache_key: str, entity_result: T, memory_result: U) -> None:
        """Store results in cache, evicting oldest entries if over capacity."""
        self._cache[cache_key] = (time.monotonic(), entity_result, memory_result)
        self._cache.move_to_end(cache_key)
        # Evict oldest entries beyond max size
        while len(self._cache) > _MAX_CACHE_ENTRIES:
            evicted_key, _ = self._cache.popitem(last=False)
            logger.debug("CACHE EVICTED (size limit)", evicted_key=evicted_key)
        logger.debug(
            "CACHE STORED",
            cache_key=cache_key,
            cache_size=len(self._cache),
        )

    def clear(self, cache_key: Optional[str] = None) -> None:
        """Clear cache entries.

        Args:
            cache_key: Specific key to clear, or None to clear all.
        """
        if cache_key:
            removed = self._cache.pop(cache_key, None)
            if removed is not None:
                logger.debug("CACHE CLEARED", cache_key=cache_key, cache_size=len(self._cache))
        else:
            size_before = len(self._cache)
            self._cache.clear()
            logger.debug("CACHE CLEARED ALL", size_before=size_before)

    def has_key(self, cache_key: str) -> bool:
        """Check if key exists in cache (ignores TTL)."""
        return cache_key in self._cache

    @property
    def size(self) -> int:
        """Current number of cached entries."""
        return len(self._cache)

    @property
    def keys(self) -> list:
        """List of current cache keys."""
        return list(self._cache.keys())
