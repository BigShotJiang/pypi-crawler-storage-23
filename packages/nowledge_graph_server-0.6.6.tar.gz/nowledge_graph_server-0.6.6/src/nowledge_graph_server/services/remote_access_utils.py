"""Shared remote-access utility functions.

Extracted from services.remote_access to keep the primary module below
PyArmor free-tier file-size limits while preserving behavior.
"""

from __future__ import annotations

import ipaddress
import os
import re
from typing import Mapping, Optional, Sequence

from fastapi import Request

IP_ALLOWLIST_ENV = "NOWLEDGE_IP_ALLOWLIST"

# Keep remote exposure focused on memory-center capabilities.
REMOTE_ALLOWED_PREFIXES = (
    "health",
    "stats",
    "memories",
    "threads",
    "labels",
    "entities",
    "graph",
    "favorites",
    "mcp",
    "remote-llm/status",
    "remote-llm/credentials",
    "agent/status",
    "agent/working-memory",
    "agent/feed/events",
    "agent/evolves",
    "agent/feed/input",
)


def is_remote_target_path_allowed(target_path: str) -> bool:
    normalized = target_path.strip("/")
    if not normalized:
        return False

    for prefix in REMOTE_ALLOWED_PREFIXES:
        if normalized == prefix or normalized.startswith(prefix + "/"):
            return True

    return False


def is_local_request(request: Request) -> bool:
    """Check whether a request originates from local loopback addresses."""
    host = ""
    if request.client and request.client.host:
        host = request.client.host
    if not host:
        return False

    if host in {"localhost", "127.0.0.1", "::1"}:
        return True

    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def parse_ip_allowlist(
    raw_allowlist: str,
) -> tuple[list[ipaddress.IPv4Network | ipaddress.IPv6Network], list[str]]:
    """Parse comma/newline-separated IP/CIDR entries.

    Returns:
        (allowed_networks, invalid_entries)
    """
    entries = [
        item.strip()
        for item in re.split(r"[,\n]", raw_allowlist or "")
        if item.strip()
    ]

    parsed: list[ipaddress.IPv4Network | ipaddress.IPv6Network] = []
    invalid: list[str] = []

    for entry in entries:
        try:
            if "/" in entry:
                network = ipaddress.ip_network(entry, strict=False)
            else:
                addr = ipaddress.ip_address(entry)
                network = ipaddress.ip_network(
                    f"{addr}/{addr.max_prefixlen}", strict=False
                )
            parsed.append(network)
        except ValueError:
            invalid.append(entry)

    return parsed, invalid


def load_ip_allowlist_from_env(
    env: Optional[Mapping[str, str]] = None,
) -> tuple[list[ipaddress.IPv4Network | ipaddress.IPv6Network], list[str]]:
    source = env or os.environ
    return parse_ip_allowlist(source.get(IP_ALLOWLIST_ENV, ""))


def is_ip_allowlist_match(
    host: str,
    networks: Sequence[ipaddress.IPv4Network | ipaddress.IPv6Network],
) -> bool:
    """Check whether host IP is within any allowlisted network.

    Empty networks means "allow all".
    """
    if not networks:
        return True

    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False

    return any(addr in network for network in networks)
