"""
Local LLM Service using MLX for entity extraction and memory distillation.

This service uses MLX with Qwen3-4B-4bit for on-device inference without API dependencies.

Entity extraction and distillation methods are in separate mixin modules
(local_llm_extraction.py, local_llm_distillation.py) to keep each file
within the pyarmor free-tier line limit (1 000 lines).
"""

import asyncio
import platform
import time
from typing import Any, Dict, List, Optional, Tuple, Type

import structlog

from nowledge_graph_server.services.base_llm import (
    BaseLLMProvider,
    EntityExtractionResult,
    LLMGenerationConfig,
    MemoryDistillationResult,
)
from nowledge_graph_server.services.json_utils import clean_and_parse_json
from nowledge_graph_server.services.license import get_license_service
from nowledge_graph_server.services.llm_cache import PreviewCache
from nowledge_graph_server.services.litellm_provider import LiteLLMProvider
from nowledge_graph_server.services.local_llm_distillation import DistillationMixin
from nowledge_graph_server.services.local_llm_extraction import ExtractionMixin
from nowledge_graph_server.services.remote_llm_config import get_config_manager
from nowledge_graph_server.services.remote_llm_extraction import RemoteLLMExtraction


logger = structlog.get_logger()

# MLX is only available on macOS Apple Silicon
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"

# Conditionally import MLX provider (only on macOS)
MLXLocalProvider: Optional[Type[BaseLLMProvider]] = None
if IS_APPLE_SILICON:
    try:
        from nowledge_graph_server.services.mlx_llm import MLXLocalProvider  # type: ignore[misc]
    except (ImportError, RuntimeError):
        MLXLocalProvider = None

class UnifiedLLMService:
    """Unified LLM service that abstracts different providers."""

    def __init__(self, provider: str = "mlx", **provider_kwargs):
        self.provider_name = provider
        self.provider = self._create_provider(provider, **provider_kwargs)
        self._initialized = False

    def _create_provider(self, provider: str, **kwargs) -> BaseLLMProvider:
        """Factory method to create LLM providers."""
        if provider == "mlx":
            if MLXLocalProvider is None:
                raise ValueError(
                    "MLX is not available on this platform. "
                    "MLX is only available on macOS Apple Silicon. "
                    "Please use 'litellm' provider for remote LLM access."
                )
            return MLXLocalProvider(**kwargs)
        elif provider == "litellm":
            return LiteLLMProvider()
        else:
            raise ValueError(f"Unsupported provider: {provider}")

    async def initialize(self) -> None:
        """Initialize the LLM service."""
        await self.provider.initialize()
        self._initialized = True

    async def generate_response(
        self,
        prompt: str,
        config: Optional[LLMGenerationConfig] = None,
        operation_name: Optional[str] = None,
    ) -> str:
        """Generate response using the configured provider."""
        if not self._initialized:
            await self.initialize()

        if config is None:
            config = LLMGenerationConfig()  # type: ignore

        return await self.provider.generate_response(prompt, config, operation_name=operation_name)  # type: ignore[call-arg]

    def is_idle(self, threshold_seconds: int = 300) -> bool:
        """Check if the underlying provider is idle."""
        if hasattr(self.provider, "is_idle"):
            return self.provider.is_idle(threshold_seconds)
        return False

    async def unload(self) -> None:
        """Unload the underlying provider to reclaim memory."""
        if hasattr(self.provider, "unload"):
            await self.provider.unload()
        self._initialized = False

    async def close(self) -> None:
        """Cleanup the LLM service."""
        await self.provider.close()


class LocalLLMService(ExtractionMixin, DistillationMixin):
    """Local LLM service using unified abstraction for entity extraction and memory distillation."""

    def __init__(
        self,
        model_name: str = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
        cache_dir: Optional[str] = None,
        cache_only: bool = True,
    ):
        """Initialize the local LLM service."""
        self.model_name = model_name
        self.cache_dir = cache_dir
        self.cache_only = cache_only

        # Provider instances
        self.local_llm: Optional[UnifiedLLMService] = None
        self.remote_llm: Optional[UnifiedLLMService] = None
        self._remote_initialized: bool = False
        self._initialized = False

        # Cache for preview results
        self._preview_cache: PreviewCache[EntityExtractionResult, MemoryDistillationResult] = PreviewCache()

        # Serialize MLX calls to avoid native segfaults
        self._gen_lock: asyncio.Lock = asyncio.Lock()
        self._local_init_lock: asyncio.Lock = asyncio.Lock()

        # Track last usage for UI/debugging
        self._last_usage: Dict[str, Any] = {
            "used_remote": False,
            "provider": "mlx",
            "model": self.model_name,
            "fallback": False,
        }

        # Remote LLM extraction service (initialized lazily)
        self._remote_extraction: Optional[RemoteLLMExtraction] = None

    async def initialize(self) -> None:
        """Initialize the LLM service."""
        if self._initialized:
            return

        # Prepare remote LLM
        if self.remote_llm is None:
            self.remote_llm = UnifiedLLMService(provider="litellm")
        try:
            config_manager = get_config_manager()
            license_service = get_license_service()
            if license_service.get_tier() == "pro" and config_manager.is_enabled():
                await self.remote_llm.initialize()
                self._remote_initialized = True
                cfg = config_manager.get_config()
                logger.debug("Remote LLM ready", provider=cfg.provider, model=cfg.model)
            else:
                self._remote_initialized = False
                logger.info("Remote LLM disabled (not Pro or not enabled)")
        except Exception as e:
            self._remote_initialized = False
            logger.info("Remote LLM not initialized yet", reason=str(e))

        # Initialize local MLX only when remote is not ready.
        # This avoids pinning large Metal memory when remote-only flows are active.
        if IS_APPLE_SILICON:
            if not self._remote_initialized:
                await self._ensure_local_initialized()
            else:
                logger.info(
                    "Remote LLM is ready; deferring local MLX initialization",
                    model=self.model_name,
                )
        else:
            self.local_llm = None
            logger.info("Skipping MLX initialization (not Apple Silicon)")

        self._initialized = True
        logger.info(
            "LocalLLMService initialized",
            local_ready=(self.local_llm is not None),
            remote_ready=self._remote_initialized,
            platform_apple_silicon=IS_APPLE_SILICON,
        )

    async def _ensure_local_initialized(self) -> bool:
        """Initialize local MLX provider lazily when first needed."""
        if not IS_APPLE_SILICON:
            self.local_llm = None
            return False

        if self.local_llm is not None and self.local_llm._initialized:
            return True

        async with self._local_init_lock:
            if self.local_llm is not None and self.local_llm._initialized:
                return True

            if self.local_llm is None:
                self.local_llm = UnifiedLLMService(
                    provider="mlx",
                    model_name=self.model_name,
                    cache_dir=self.cache_dir,
                    cache_only=self.cache_only,
                )

            try:
                await self.local_llm.initialize()
                logger.debug("MLX local LLM initialized successfully")
                return True
            except Exception as e:
                logger.warning("MLX initialization failed", error=str(e))
                self.local_llm = None
                return False

    def _should_use_remote_extraction(self) -> bool:
        """Determine if we should use high-quality remote LLM extraction."""
        if self.remote_llm is None or not self._remote_initialized:
            return False

        try:
            config_manager = get_config_manager()
            license_service = get_license_service()
            return (
                config_manager.is_enabled()
                and license_service.get_tier() == "pro"
                and self._remote_initialized
            )
        except Exception as e:
            logger.debug("Remote extraction check failed", error=str(e))
            return False

    async def _get_remote_extraction(self) -> Optional[RemoteLLMExtraction]:
        """Get or create the remote LLM extraction service."""
        if not self._should_use_remote_extraction():
            return None

        if self._remote_extraction is None and RemoteLLMExtraction is not None:
            async def llm_wrapper(
                prompt: str, max_tokens: int, temperature: float, operation_name: Optional[str] = None
            ) -> str:
                # Note: temperature param is accepted for interface compatibility but ignored
                # _generate_response uses fixed Qwen3 params for local, API defaults for remote
                if operation_name:
                    self._current_operation = operation_name
                return await self._generate_response(
                    prompt, max_tokens=max_tokens
                )

            def json_parser(text: str) -> Optional[Dict[str, Any]]:
                return clean_and_parse_json(text)

            # Get entity repository for deduplication
            entity_repo = None
            try:
                from nowledge_graph_server.api.dependencies import get_kuzu_client
                kuzu = await get_kuzu_client()
                entity_repo = kuzu.entity_repo
            except Exception as e:
                logger.warning("Entity repository not available", error=str(e))

            self._remote_extraction = RemoteLLMExtraction(
                llm_generate_func=llm_wrapper,
                parse_json_func=json_parser,
                entity_repository=entity_repo,
                max_concurrent=3,
                retry_attempts=3,
            )
            logger.info("Remote LLM extraction service initialized")

        return self._remote_extraction

    async def _generate_response(
        self,
        prompt: str,
        max_tokens: int = 8192,
        use_thinking: bool = False,
        temperature: float | None = None,  # Deprecated - kept for interface compatibility
        force_local: bool = False,
    ) -> str:
        """Generate response from the LLM.

        Args:
            prompt: The prompt to send to the LLM
            max_tokens: Maximum tokens to generate
            use_thinking: Whether to use thinking mode
            temperature: DEPRECATED - ignored. Local uses Qwen3 defaults, remote uses API defaults
            force_local: If True, always use local LLM regardless of config
        """
        # Note: temperature param is ignored - we use fixed values:
        # - Local LLM: Qwen3 recommended (T=0.7, TopP=0.8, TopK=20, MinP=0)
        # - Remote LLM: No sampling params passed, API uses its defaults
        if not self._initialized:
            await self.initialize()

        # Choose provider
        provider_service: Optional[UnifiedLLMService] = None
        use_remote = False

        # Only consider remote if not forced to use local
        if not force_local:
            try:
                config_manager = get_config_manager()
                license_service = get_license_service()
                if (
                    self.remote_llm is not None
                    and self._remote_initialized
                    and config_manager.is_enabled()
                    and license_service.get_tier() == "pro"
                ):
                    provider_service = self.remote_llm
                    use_remote = True
            except Exception as e:
                logger.info("Falling back to local LLM", reason=str(e))

        if not use_remote:
            local_ready = await self._ensure_local_initialized()
            if not local_ready or self.local_llm is None:
                raise RuntimeError(
                    "Local LLM unavailable. Configure Remote LLM in Settings, "
                    "or install local MLX model on macOS Apple Silicon."
                )
            provider_service = self.local_llm

        # Remote: no lock, Local: acquire lock
        if use_remote:
            return await self._generate_response_impl(
                prompt, max_tokens, use_thinking, temperature, provider_service, use_remote
            )
        else:
            async with self._gen_lock:
                return await self._generate_response_impl(
                    prompt, max_tokens, use_thinking, temperature, provider_service, use_remote
                )

    async def _generate_response_impl(
        self,
        prompt: str,
        max_tokens: int,
        use_thinking: bool,
        temperature: float | None,
        provider_service: Any,
        is_using_remote: bool,
    ) -> str:
        """Implementation of generate_response."""
        if provider_service is None:
            if self.local_llm is None and (self.remote_llm is None or not self._remote_initialized):
                raise RuntimeError(
                    "No LLM provider available. "
                    "On Intel Mac/Windows/Linux, configure Remote LLM in Settings. "
                    "On macOS Apple Silicon, ensure MLX is installed or configure Remote LLM."
                )

        assert provider_service is not None

        # Create config based on provider type
        # Remote LLM: Don't pass sampling params (temperature, top_p, etc.) - let remote API use its defaults
        # Local LLM: Use Qwen3 optimized values (Temperature=0.7, TopP=0.8, TopK=20, MinP=0)
        if is_using_remote:
            config = LLMGenerationConfig(
                max_tokens=max_tokens,
                use_thinking=use_thinking,
                # NOTE: Do NOT set temperature, top_p, top_k, min_p for remote LLM
                # Let the remote API use its own optimized defaults
            )
        else:
            config = LLMGenerationConfig(
                max_tokens=max_tokens,
                temperature=0.7,  # Qwen3 recommended
                top_p=0.8,        # Qwen3 recommended
                top_k=20,         # Qwen3 recommended
                min_p=0.0,        # Qwen3 recommended
                use_thinking=use_thinking,
            )

        try:
            operation_name = getattr(self, "_current_operation", None)
            text = await provider_service.generate_response(prompt, config, operation_name=operation_name)

            # Metadata
            used_remote = is_using_remote
            provider_name = "mlx" if not used_remote else (get_config_manager().get_config().provider or "remote")
            model_name = self.model_name if not used_remote else (get_config_manager().get_config().model or "")

            # Handle empty remote response
            if used_remote and (not text or not text.strip()):
                logger.warning("Remote LLM returned empty response, falling back to local")
                local_ready = await self._ensure_local_initialized()
                if not local_ready or self.local_llm is None:
                    raise RuntimeError("Local LLM not available for fallback")

                local_config = LLMGenerationConfig(
                    max_tokens=max_tokens,
                    temperature=0.7,  # Qwen3 recommended
                    top_p=0.8,        # Qwen3 recommended
                    top_k=20,         # Qwen3 recommended
                    min_p=0.0,        # Qwen3 recommended
                    use_thinking=use_thinking,
                )
                local_text = await self.local_llm.generate_response(prompt, local_config, operation_name=operation_name)
                self._last_usage = {
                    "used_remote": False,
                    "provider": "mlx",
                    "model": self.model_name,
                    "fallback": True,
                    "remote_provider": provider_name,
                    "remote_model": model_name,
                }
                return local_text

            self._last_usage = {
                "used_remote": used_remote,
                "provider": provider_name,
                "model": model_name,
                "fallback": False,
            }
            return text

        except Exception as gen_error:
            if provider_service is self.remote_llm:
                logger.warning("Remote LLM failed, falling back to local", error=str(gen_error))
                local_ready = await self._ensure_local_initialized()
                if not local_ready or self.local_llm is None:
                    raise RuntimeError(f"Remote LLM failed and local unavailable: {gen_error}") from gen_error

                local_config = LLMGenerationConfig(
                    max_tokens=max_tokens,
                    temperature=0.7,  # Qwen3 recommended
                    top_p=0.8,        # Qwen3 recommended
                    top_k=20,         # Qwen3 recommended
                    min_p=0.0,        # Qwen3 recommended
                    use_thinking=use_thinking,
                )
                operation_name = getattr(self, "_current_operation", None)
                local_text = await self.local_llm.generate_response(prompt, local_config, operation_name=operation_name)

                try:
                    cfg = get_config_manager().get_config()
                    remote_provider = cfg.provider
                    remote_model = cfg.model
                except Exception:
                    remote_provider = None
                    remote_model = None

                self._last_usage = {
                    "used_remote": False,
                    "provider": "mlx",
                    "model": self.model_name,
                    "fallback": True,
                    "remote_provider": remote_provider,
                    "remote_model": remote_model,
                }
                return local_text
            raise

    def get_last_usage(self) -> Dict[str, Any]:
        """Return metadata about the last generation call."""
        return dict(self._last_usage)

    # --- Cache methods ---

    def _generate_cache_key(self, thread_content: str, thread_title: str = "") -> str:
        """Generate a cache key for the given content."""
        return self._preview_cache.generate_key(thread_content, thread_title)

    async def extract_entities_cached(self, cache_key: str) -> EntityExtractionResult:
        """Extract entities with optional caching."""
        cached = self._preview_cache.get(cache_key)
        if cached:
            entity_result, _ = cached
            logger.debug("CACHE HIT: Using cached entity results", entities=len(entity_result.entities))
            return entity_result
        else:
            logger.error("CACHE MISS: Cache key not found", cache_key=cache_key)
            raise ValueError("Could not find previous entity extraction results, please try again")

    async def distill_memories_cached(
        self, thread_content: str, thread_title: str = "", cache_key: Optional[str] = None,
        extraction_level: str = "swift", preferred_language: Optional[str] = None
    ) -> MemoryDistillationResult:
        """Distill memories with optional caching.

        Args:
            thread_content: The content to distill
            thread_title: Optional title for context
            cache_key: Optional cache key to retrieve cached results
            extraction_level: "swift"/"guided" = local LLM, "expert" = remote LLM
            preferred_language: User preferred output language ('en', 'zh', or None)
        """
        if cache_key:
            cached = self._preview_cache.get(cache_key)
            if cached:
                _, memory_result = cached
                logger.debug("CACHE HIT: Using cached memory results", memories=len(memory_result.memories))
                return memory_result
            logger.warning("CACHE MISS: Cache key provided but not found")

        # force_local when using local extraction levels (swift/guided)
        force_local = extraction_level != "expert"
        return await self.distill_memories(thread_content, thread_title, force_local=force_local, preferred_language=preferred_language)

    async def generate_preview_with_cache(
        self,
        thread_content: str,
        thread_title: str = "",
        distillation_type: str = "simple_llm",
        extraction_level: str = "swift",
        preferred_language: Optional[str] = None,
    ) -> Tuple[str, EntityExtractionResult, MemoryDistillationResult]:
        """Generate preview results and cache them for later use."""
        base_key = self._generate_cache_key(thread_content, thread_title)
        # Vary cache key by preferred_language so changing language always yields fresh results
        cache_key = f"{base_key}_{preferred_language}" if preferred_language else base_key

        # Check cache
        cached = self._preview_cache.get(cache_key)
        if cached:
            entity_result, memory_result = cached
            logger.debug("CACHE HIT: Returning cached preview", entities=len(entity_result.entities))
            return cache_key, entity_result, memory_result

        logger.debug("CACHE MISS: Generating new preview", cache_key=cache_key, distillation_type=distillation_type)

        # Respect extraction_level: "swift" and "guided" = local LLM, "expert" = remote LLM
        # Only use remote if explicitly requested via "expert" level AND remote is available
        use_remote = extraction_level == "expert" and self._should_use_remote_extraction()
        logger.info("Extraction strategy", use_remote=use_remote, extraction_level=extraction_level, distillation_type=distillation_type)

        # STEP 1: Distill memories
        # force_local=True when NOT using remote (i.e., swift/guided extraction levels)
        force_local = not use_remote
        if use_remote:
            remote_extraction = await self._get_remote_extraction()
            if remote_extraction:
                logger.info("Using remote LLM for memory distillation")
                memory_result = await remote_extraction.distill_memories_remote(
                    thread_content=thread_content, max_memories=3, preferred_language=preferred_language
                )
            else:
                logger.warning("Remote extraction unavailable, falling back to local")
                memory_result = await self.distill_memories(thread_content, thread_title, force_local=True, preferred_language=preferred_language)
        else:
            memory_result = await self.distill_memories(thread_content, thread_title, force_local=force_local, preferred_language=preferred_language)

        # STEP 2: Extract entities (only for knowledge_graph mode)
        if distillation_type == "knowledge_graph" and memory_result.memories:
            entity_result = await self._extract_entities_from_memories(
                memory_result.memories, use_remote, extraction_level, force_local=force_local,
                preferred_language=preferred_language,
            )
        else:
            logger.debug("Skipping entity extraction for simple_llm mode")
            entity_result = EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

        # Cache results
        self._preview_cache.set(cache_key, entity_result, memory_result)
        logger.debug("CACHE STORED", entities=len(entity_result.entities), memories=len(memory_result.memories))

        return cache_key, entity_result, memory_result

    def clear_cache(self, cache_key: Optional[str] = None) -> None:
        """Clear cache entries."""
        self._preview_cache.clear(cache_key)

    async def verify_local_runtime(self) -> Dict[str, Any]:
        """Run a minimal local-runtime smoke test.

        Returns:
            Metadata including a short response preview on success.
        """
        if not IS_APPLE_SILICON:
            raise RuntimeError("Local LLM runtime is only supported on macOS Apple Silicon")

        if not self._initialized:
            await self.initialize()

        local_ready = await self._ensure_local_initialized()
        if not local_ready or self.local_llm is None:
            raise RuntimeError("Local MLX provider is not initialized")

        response = await self._generate_response(
            "Reply with exactly: OK",
            max_tokens=16,
            use_thinking=False,
            force_local=True,
        )

        response_text = response.strip()
        if not response_text:
            raise RuntimeError("Local LLM returned an empty response")

        return {
            "response_preview": response_text[:120],
        }

    def is_local_llm_idle(self, threshold_seconds: int = 300) -> bool:
        """Check if the local MLX LLM is idle and can be unloaded."""
        if self.local_llm is not None and self.local_llm._initialized:
            return self.local_llm.is_idle(threshold_seconds)
        return False

    async def unload_local_llm(self) -> None:
        """Unload the local MLX LLM to reclaim Metal memory.

        The model reloads seamlessly on next use via _ensure_local_initialized().
        """
        if self.local_llm is not None and self.local_llm._initialized:
            logger.info("Unloading idle local MLX LLM to reclaim memory")
            await self.local_llm.unload()

    async def close(self) -> None:
        """Clean up resources."""
        try:
            if self.local_llm:
                await self.local_llm.close()
        except Exception:
            pass
        try:
            if self.remote_llm:
                await self.remote_llm.close()
        except Exception:
            pass
        self._initialized = False
        logger.debug("Local LLM service closed")


# Global service instance
local_llm_service: Optional[LocalLLMService] = None


async def get_local_llm_service(
    model_name: str = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
    cache_dir: Optional[str] = None,
    cache_only: bool = True,
) -> LocalLLMService:
    """Get or create the local LLM service instance."""
    global local_llm_service

    if local_llm_service is None:
        local_llm_service = LocalLLMService(
            model_name=model_name,
            cache_dir=cache_dir,
            cache_only=cache_only,
        )
        await local_llm_service.initialize()

    return local_llm_service
