"""Built-in model integrity and runtime verification.

This module verifies the two built-in local models:
- Search embedding model (platform-specific)
- Local LLM model (macOS Apple Silicon only)

Verification has two levels:
- Quick check: cache presence + required files integrity
- Full check: singleton service init + runtime smoke test
"""

from __future__ import annotations

import asyncio
import math
import platform
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Literal, Optional

import structlog

from ..config import get_default_huggingface_cache, get_settings
from ..utils.download_utils import resolve_hf_cache_path, resolve_modelscope_cache_path

logger = structlog.get_logger(__name__)

IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"

SEARCH_MODEL_ID = "search_embedding"
LOCAL_LLM_MODEL_ID = "local_llm"
LOCAL_LLM_MODEL_NAME = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ"

ModelState = Literal[
    "not_installed",
    "installed_unverified",
    "ready",
    "corrupted",
    "unsupported",
]

_VERIFY_LOCK = asyncio.Lock()
_FULL_VERIFY_TTL_SECONDS = 600
_FULL_VERIFY_CACHE: Dict[str, Dict[str, Any]] = {}
_FULL_VERIFY_CACHE_TS: Dict[str, float] = {}


def _utc_now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _base_result(
    *,
    model_id: str,
    model_name: str,
    backend: str,
    platform_name: str,
    supported: bool,
) -> Dict[str, Any]:
    return {
        "model_id": model_id,
        "model_name": model_name,
        "backend": backend,
        "platform": platform_name,
        "supported": supported,
        "installed": False,
        "state": "not_installed",
        "verified": False,
        "integrity_ok": False,
        "smoke_test_ok": False,
        "singleton_initialized": False,
        "message": "",
        "cache_path": None,
        "error": None,
        "estimated_size_mb": 0,
        "checked_at": _utc_now_iso(),
        "last_verified_at": None,
    }


def _dedupe_paths(paths: Iterable[Path]) -> list[Path]:
    seen: set[str] = set()
    result: list[Path] = []
    for path in paths:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        result.append(path)
    return result


def _pick_snapshot_dir(snapshots_dir: Path) -> Optional[Path]:
    candidates = [p for p in snapshots_dir.iterdir() if p.is_dir()]
    if not candidates:
        return None
    # Prefer the most recently touched snapshot.
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _resolve_search_embedding_cache_path() -> Optional[Path]:
    from ..services.search_embedding import (
        MLX_MODEL,
        ONNX_MODEL,
    )

    settings = get_settings()

    if IS_APPLE_SILICON:
        model_name = MLX_MODEL
        hf_cache_root = Path.home() / ".cache" / "huggingface" / "hub"
        if settings.embedding_cache_dir:
            hf_cache_root = Path(settings.embedding_cache_dir)

        hf_cache_name = f"models--{model_name.replace('/', '--')}"
        hf_model_dir = hf_cache_root / hf_cache_name
        if hf_model_dir.exists():
            snapshots = hf_model_dir / "snapshots"
            if snapshots.exists():
                snapshot = _pick_snapshot_dir(snapshots)
                if snapshot is not None:
                    return snapshot

        direct_path = hf_cache_root / model_name
        if direct_path.exists():
            return direct_path
        return None

    model_name = ONNX_MODEL
    hf_cache_root = get_default_huggingface_cache()
    org, model = model_name.split("/", 1)
    hf_cache_name = f"models--{model_name.replace('/', '--')}"

    candidate_paths = [
        hf_cache_root / hf_cache_name,
        Path.home() / ".cache" / "modelscope" / "hub" / "models" / org / model,
        hf_cache_root / org / model,
    ]

    # Also check embedding_cache_dir (where ModelCacheManager downloads to, may differ from HF cache)
    if settings.embedding_cache_dir:
        embedding_cache = Path(settings.embedding_cache_dir)
        if embedding_cache != hf_cache_root:
            candidate_paths.append(embedding_cache / hf_cache_name)
            candidate_paths.append(embedding_cache / org / model)

    candidates = _dedupe_paths(candidate_paths)

    for candidate in candidates:
        if not candidate.exists():
            continue
        # HuggingFace snapshot structure
        snapshots = candidate / "snapshots"
        if snapshots.exists():
            snapshot = _pick_snapshot_dir(snapshots)
            if snapshot is not None:
                return snapshot
        # ModelScope/direct structure
        if (candidate / "onnx" / "model.onnx").exists():
            return candidate
        for child in candidate.iterdir():
            if child.is_dir() and (child / "onnx" / "model.onnx").exists():
                return child

    return None


def _resolve_local_llm_cache_path(model_name: str = LOCAL_LLM_MODEL_NAME) -> Optional[Path]:
    settings = get_settings()
    default_hf_cache = get_default_huggingface_cache()

    roots = _dedupe_paths(
        [
            Path(settings.llm_cache_dir) / "hub" if settings.llm_cache_dir else default_hf_cache,
            Path(settings.llm_cache_dir) if settings.llm_cache_dir else default_hf_cache.parent,
            default_hf_cache,
            default_hf_cache.parent,
        ]
    )

    for root in roots:
        hf_path = resolve_hf_cache_path(model_name, root)
        if hf_path:
            return hf_path
        ms_path = resolve_modelscope_cache_path(model_name, root)
        if ms_path:
            return ms_path

    return resolve_modelscope_cache_path(model_name)


def _check_search_embedding_integrity(model_path: Path) -> tuple[bool, str]:
    if not model_path.exists():
        return False, "Model path does not exist"

    if IS_APPLE_SILICON:
        has_config = (model_path / "config.json").exists()
        has_tokenizer = any(
            (model_path / name).exists()
            for name in ("tokenizer.json", "tokenizer_config.json", "tokenizer.model")
        )
        has_weights = (
            any(model_path.glob("*.safetensors"))
            or any(model_path.glob("model-*.safetensors"))
            or any(model_path.glob("weights.*.safetensors"))
            or any(model_path.glob("*.mlx"))
        )
        if not has_config:
            return False, "Missing config.json"
        if not has_tokenizer:
            return False, "Missing tokenizer files"
        if not has_weights:
            return False, "Missing model weight files"
        return True, "MLX model files look valid"

    onnx_path = model_path / "onnx" / "model.onnx"
    onnx_data_path = model_path / "onnx" / "model.onnx_data"
    has_config = (model_path / "config.json").exists() or (model_path / "onnx" / "config.json").exists()
    has_tokenizer = any(
        (model_path / name).exists()
        for name in ("tokenizer.json", "tokenizer_config.json", "sentencepiece.bpe.model")
    )

    if not onnx_path.exists():
        return False, "Missing onnx/model.onnx"
    if onnx_path.stat().st_size <= 0:
        return False, "onnx/model.onnx is empty"
    if onnx_path.stat().st_size < 10 * 1024 * 1024 and not onnx_data_path.exists():
        return False, "Missing onnx/model.onnx_data external weights"
    if onnx_data_path.exists() and onnx_data_path.stat().st_size <= 0:
        return False, "onnx/model.onnx_data is empty"
    if not has_config:
        return False, "Missing model config file"
    if not has_tokenizer:
        return False, "Missing tokenizer files"
    return True, "ONNX model files look valid"


def _check_local_llm_integrity(model_path: Path) -> tuple[bool, str]:
    if not model_path.exists():
        return False, "Model path does not exist"

    has_config = (model_path / "config.json").exists()
    has_tokenizer = any(
        (model_path / name).exists()
        for name in (
            "tokenizer.json",
            "tokenizer.model",
            "tokenizer_config.json",
            "special_tokens_map.json",
        )
    )
    weight_files = list(model_path.glob("*.safetensors")) + list(
        model_path.glob("model-*.safetensors")
    ) + list(model_path.glob("weights.*.safetensors")) + list(model_path.glob("*.mlx"))
    has_weights = any(file.exists() and file.stat().st_size > 0 for file in weight_files)

    if not has_config:
        return False, "Missing config.json"
    if not has_tokenizer:
        return False, "Missing tokenizer files"
    if not has_weights:
        return False, "Missing model weight files"
    return True, "LLM model files look valid"


def _quick_search_embedding_state() -> Dict[str, Any]:
    from ..services.search_embedding import check_search_model_exists, get_search_model_info

    info = get_search_model_info()
    result = _base_result(
        model_id=SEARCH_MODEL_ID,
        model_name=info["model_name"],
        backend=info["backend"],
        platform_name=info["platform"],
        supported=True,
    )
    result["estimated_size_mb"] = info.get("estimated_size_mb", 0)

    exists = check_search_model_exists()
    if not exists:
        result["message"] = "Model not installed"
        return result

    result["installed"] = True
    model_path = _resolve_search_embedding_cache_path()
    if model_path is None:
        result["state"] = "corrupted"
        result["message"] = "Model files could not be resolved"
        result["error"] = "Cache path resolution failed"
        return result

    result["cache_path"] = str(model_path)
    integrity_ok, detail = _check_search_embedding_integrity(model_path)
    result["integrity_ok"] = integrity_ok
    if integrity_ok:
        result["state"] = "installed_unverified"
        result["message"] = "Installed. Runtime verification not run yet."
    else:
        result["state"] = "corrupted"
        result["message"] = detail
        result["error"] = detail
    return result


def _quick_local_llm_state() -> Dict[str, Any]:
    result = _base_result(
        model_id=LOCAL_LLM_MODEL_ID,
        model_name=LOCAL_LLM_MODEL_NAME,
        backend="mlx",
        platform_name="macOS Apple Silicon" if IS_APPLE_SILICON else f"{platform.system()} {platform.machine()}",
        supported=IS_APPLE_SILICON,
    )
    result["estimated_size_mb"] = 2400

    if not IS_APPLE_SILICON:
        result["state"] = "unsupported"
        result["message"] = "Local LLM is only supported on macOS Apple Silicon"
        return result

    model_path = _resolve_local_llm_cache_path()
    if model_path is None:
        result["message"] = "Model not installed"
        return result

    result["installed"] = True
    result["cache_path"] = str(model_path)

    integrity_ok, detail = _check_local_llm_integrity(model_path)
    result["integrity_ok"] = integrity_ok
    if integrity_ok:
        result["state"] = "installed_unverified"
        result["message"] = "Installed. Runtime verification not run yet."
    else:
        result["state"] = "corrupted"
        result["message"] = detail
        result["error"] = detail
    return result


def _cache_is_fresh(model_id: str) -> bool:
    ts = _FULL_VERIFY_CACHE_TS.get(model_id)
    if ts is None:
        return False
    return (time.time() - ts) <= _FULL_VERIFY_TTL_SECONDS


def _can_reuse_cached_full(model_id: str, quick_result: Dict[str, Any]) -> bool:
    if model_id not in _FULL_VERIFY_CACHE:
        return False
    if not _cache_is_fresh(model_id):
        return False
    if quick_result["state"] in ("not_installed", "unsupported", "corrupted"):
        return False

    cached = _FULL_VERIFY_CACHE[model_id]
    quick_path = quick_result.get("cache_path")
    cached_path = cached.get("cache_path")
    if quick_path and cached_path and quick_path != cached_path:
        return False
    return True


def _merge_quick_with_cached_full(model_id: str, quick_result: Dict[str, Any]) -> Dict[str, Any]:
    cached = _FULL_VERIFY_CACHE[model_id]
    merged = dict(quick_result)
    for key in (
        "state",
        "verified",
        "smoke_test_ok",
        "singleton_initialized",
        "message",
        "error",
        "checked_at",
    ):
        merged[key] = cached.get(key)
    merged["last_verified_at"] = cached.get("checked_at")
    return merged


async def _full_verify_search_embedding(quick_result: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(quick_result)
    checked_at = _utc_now_iso()
    result["checked_at"] = checked_at

    if result["state"] in ("not_installed", "unsupported", "corrupted"):
        result["last_verified_at"] = checked_at
        return result

    from ..services.search_embedding import SEARCH_EMBEDDING_DIMENSION
    from ..services.search_index.service_factory import get_search_embedding_service

    try:
        service = await asyncio.wait_for(get_search_embedding_service(), timeout=60)
        if service is None:
            raise RuntimeError("Search embedding singleton failed to initialize")

        result["singleton_initialized"] = bool(getattr(service, "_initialized", False))
        embedding = await asyncio.wait_for(
            service.embed_text("health check", is_query=True), timeout=45
        )

        if len(embedding) != SEARCH_EMBEDDING_DIMENSION:
            raise RuntimeError(
                f"Expected {SEARCH_EMBEDDING_DIMENSION} dims, got {len(embedding)}"
            )
        if not embedding or not all(math.isfinite(float(x)) for x in embedding):
            raise RuntimeError("Embedding vector contains non-finite values")
        if max(abs(float(x)) for x in embedding) < 1e-12:
            raise RuntimeError("Embedding vector is effectively all zeros")

        result["state"] = "ready"
        result["verified"] = True
        result["smoke_test_ok"] = True
        result["message"] = "Model verified and runtime smoke test passed"
        result["error"] = None
    except Exception as exc:
        logger.warning("Search embedding verification failed", error=str(exc))
        result["state"] = "corrupted"
        result["verified"] = False
        result["smoke_test_ok"] = False
        result["message"] = "Runtime verification failed"
        result["error"] = str(exc)

    result["last_verified_at"] = checked_at
    return result


async def _full_verify_local_llm(quick_result: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(quick_result)
    checked_at = _utc_now_iso()
    result["checked_at"] = checked_at

    if result["state"] in ("not_installed", "unsupported", "corrupted"):
        result["last_verified_at"] = checked_at
        return result

    try:
        from ..services.local_llm import get_local_llm_service

        settings = get_settings()
        service = await asyncio.wait_for(
            get_local_llm_service(
                model_name=LOCAL_LLM_MODEL_NAME,
                cache_dir=settings.llm_cache_dir,
                cache_only=True,
            ),
            timeout=90,
        )
        result["singleton_initialized"] = bool(getattr(service, "_initialized", False))

        health = await asyncio.wait_for(service.verify_local_runtime(), timeout=120)
        result["state"] = "ready"
        result["verified"] = True
        result["smoke_test_ok"] = True
        result["message"] = "Model verified and runtime smoke test passed"
        result["error"] = None
        if isinstance(health, dict) and health.get("response_preview"):
            result["response_preview"] = health["response_preview"]
    except Exception as exc:
        logger.warning("Local LLM verification failed", error=str(exc))
        result["state"] = "corrupted"
        result["verified"] = False
        result["smoke_test_ok"] = False
        result["message"] = "Runtime verification failed"
        result["error"] = str(exc)

    result["last_verified_at"] = checked_at
    return result


async def get_builtin_model_states(
    *,
    full_verify: bool = False,
    force_refresh: bool = False,
    target_models: Optional[Iterable[str]] = None,
) -> Dict[str, Dict[str, Any]]:
    """Get model state for built-in local models.

    Args:
        full_verify: If True, run runtime smoke tests through singleton services.
        force_refresh: Ignore cached full-verification results.
        target_models: Optional subset of model IDs.
    """

    requested = set(target_models or (SEARCH_MODEL_ID, LOCAL_LLM_MODEL_ID))
    quick_results: Dict[str, Dict[str, Any]] = {}

    if SEARCH_MODEL_ID in requested:
        quick_results[SEARCH_MODEL_ID] = _quick_search_embedding_state()
    if LOCAL_LLM_MODEL_ID in requested:
        quick_results[LOCAL_LLM_MODEL_ID] = _quick_local_llm_state()

    if not full_verify:
        final_results: Dict[str, Dict[str, Any]] = {}
        for model_id, quick in quick_results.items():
            if _can_reuse_cached_full(model_id, quick):
                final_results[model_id] = _merge_quick_with_cached_full(model_id, quick)
            else:
                final_results[model_id] = quick
        return final_results

    async with _VERIFY_LOCK:
        final_results = {}
        for model_id, quick in quick_results.items():
            if not force_refresh and _can_reuse_cached_full(model_id, quick):
                final_results[model_id] = _merge_quick_with_cached_full(model_id, quick)
                continue

            if model_id == SEARCH_MODEL_ID:
                verified = await _full_verify_search_embedding(quick)
            elif model_id == LOCAL_LLM_MODEL_ID:
                verified = await _full_verify_local_llm(quick)
            else:
                verified = quick

            _FULL_VERIFY_CACHE[model_id] = dict(verified)
            _FULL_VERIFY_CACHE_TS[model_id] = time.time()
            final_results[model_id] = verified

        return final_results
