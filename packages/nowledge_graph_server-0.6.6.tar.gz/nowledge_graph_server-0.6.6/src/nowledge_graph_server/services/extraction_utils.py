"""
Utilities for entity extraction including language detection, normalization, and salience ranking.
"""

import re
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import Counter, defaultdict
import structlog

logger = structlog.get_logger(__name__)


class LanguageDetector:
    """Simple language detection based on character patterns and common words."""

    # Common words/particles for language detection
    LANGUAGE_MARKERS = {
        "ja": {
            "particles": [
                "は",
                "が",
                "を",
                "に",
                "で",
                "と",
                "の",
                "から",
                "まで",
                "より",
            ],
            "words": ["です", "ます", "ない", "ある", "いる", "する", "こと", "もの"],
            "scripts": ["hiragana", "katakana", "kanji"],
        },
        "zh": {
            "particles": ["的", "是", "了", "在", "和", "有", "我", "你", "他", "她"],
            "words": ["这", "那", "什么", "怎么", "为什么", "可以", "不是", "没有"],
            "scripts": ["chinese"],
        },
        "ko": {
            "particles": [
                "은",
                "는",
                "이",
                "가",
                "을",
                "를",
                "에",
                "에서",
                "으로",
                "와",
            ],
            "words": ["있다", "없다", "하다", "되다", "이다", "그", "이", "저"],
            "scripts": ["hangul"],
        },
    }

    @staticmethod
    def detect_script(text: str) -> Set[str]:
        """Detect which scripts are present in the text."""
        scripts = set()

        for char in text:
            code_point = ord(char)

            # Hiragana
            if 0x3040 <= code_point <= 0x309F:
                scripts.add("hiragana")
            # Katakana
            elif 0x30A0 <= code_point <= 0x30FF:
                scripts.add("katakana")
            # Kanji / Chinese
            elif 0x4E00 <= code_point <= 0x9FFF:
                scripts.add("chinese")  # Also includes kanji
            # Hangul
            elif 0xAC00 <= code_point <= 0xD7AF:
                scripts.add("hangul")
            # Latin
            elif (0x0041 <= code_point <= 0x005A) or (0x0061 <= code_point <= 0x007A):
                scripts.add("latin")

        return scripts

    @classmethod
    def detect_language(cls, text: str) -> str:
        """Detect the primary language of the text.

        Returns:
            Language code ('en', 'ja', 'zh', 'ko', etc.) or 'en' as default
        """
        if not text:
            return "en"

        # Check script presence
        scripts = cls.detect_script(text)

        # Japanese detection (presence of hiragana/katakana is definitive)
        if "hiragana" in scripts or "katakana" in scripts:
            return "ja"

        # Korean detection
        if "hangul" in scripts:
            return "ko"

        # Chinese vs Japanese (kanji only)
        if "chinese" in scripts and "latin" not in scripts:
            # Check for Chinese-specific particles
            zh_score = sum(
                1
                for marker in cls.LANGUAGE_MARKERS["zh"]["particles"]
                if marker in text
            )
            if zh_score > 2:
                return "zh"

        # Default to English for mixed or Latin-only text
        return "en"


class EntityNormalizer:
    """Normalize and deduplicate entities while preserving original forms."""

    @staticmethod
    def normalize_name(name: str) -> str:
        """Create normalized form for deduplication while preserving original."""
        # Remove extra whitespace
        normalized = " ".join(name.split())

        # Lowercase for Latin script only
        if all(ord(c) < 128 for c in normalized if c.isalpha()):
            normalized = normalized.lower()

        # Remove common punctuation at edges
        normalized = normalized.strip(".,;:!?\"'")

        return normalized

    @staticmethod
    def merge_entities(entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Merge duplicate entities, keeping highest confidence and all aliases."""
        entity_map = defaultdict(list)

        for entity in entities:
            normalized = EntityNormalizer.normalize_name(entity["name"])
            entity_map[normalized].append(entity)

        merged = []
        for normalized, duplicates in entity_map.items():
            # Sort by confidence
            duplicates.sort(key=lambda e: e.get("confidence", 0), reverse=True)

            # Take highest confidence entity as base
            best = duplicates[0].copy()

            # Collect all unique names as aliases
            all_names = {e["name"] for e in duplicates}
            all_names.discard(best["name"])
            if all_names:
                best["aliases"] = list(all_names)

            # Merge descriptions if different
            descriptions = {
                e.get("description", "") for e in duplicates if e.get("description")
            }
            descriptions.discard(best.get("description", ""))
            if descriptions and best.get("description"):
                best["description"] = (
                    best["description"] + " | " + " | ".join(descriptions)
                )

            merged.append(best)

        return merged


class SalienceRanker:
    """Rank entities by salience using graph-based and statistical methods."""

    @staticmethod
    def compute_salience_scores(
        entities: List[Dict[str, Any]], relationships: List[Dict[str, Any]], text: str
    ) -> List[Dict[str, Any]]:
        """Add salience scores to entities based on multiple factors."""

        # Build entity name to index map
        name_to_idx = {e["name"]: i for i, e in enumerate(entities)}

        # Factor 1: Mention frequency
        text_lower = text.lower()
        for entity in entities:
            # Count mentions (case-insensitive for Latin text)
            if all(ord(c) < 128 for c in entity["name"] if c.isalpha()):
                mentions = text_lower.count(entity["name"].lower())
            else:
                mentions = text.count(entity["name"])
            entity["mentions"] = mentions

        # Factor 2: Relationship degree (how connected)
        degree_counts = Counter()
        for rel in relationships:
            if rel["source"] in name_to_idx:
                degree_counts[rel["source"]] += 1
            if rel["target"] in name_to_idx:
                degree_counts[rel["target"]] += 1

        for entity in entities:
            entity["degree"] = degree_counts.get(entity["name"], 0)

        # Factor 3: Position bias (earlier mentions more important)
        for entity in entities:
            first_pos = text.find(entity["name"])
            if first_pos >= 0:
                # Normalize position to 0-1 (1 = beginning, 0 = end)
                entity["position_score"] = 1.0 - (first_pos / len(text))
            else:
                entity["position_score"] = 0.0

        # Combine factors into salience score
        for entity in entities:
            mention_weight = min(entity["mentions"] / 10.0, 1.0)  # Cap at 10 mentions
            degree_weight = min(entity["degree"] / 5.0, 1.0)  # Cap at 5 relationships
            position_weight = entity["position_score"]
            confidence_weight = entity.get("confidence", 0.5)

            # Weighted combination
            entity["salience"] = (
                0.3 * mention_weight
                + 0.3 * degree_weight
                + 0.2 * position_weight
                + 0.2 * confidence_weight
            )

        # Sort by salience
        entities.sort(key=lambda e: e["salience"], reverse=True)

        return entities

    @staticmethod
    def select_top_k_diverse(
        entities: List[Dict[str, Any]], k: int = 10, type_diversity: bool = True
    ) -> List[Dict[str, Any]]:
        """Select top-k entities with optional type diversity."""
        if not type_diversity or len(entities) <= k:
            return entities[:k]

        selected = []
        type_counts = defaultdict(int)

        # First pass: take highest salience per type
        seen_types = set()
        for entity in entities:
            entity_type = entity.get("type", "UNKNOWN")
            if entity_type not in seen_types and len(selected) < k:
                selected.append(entity)
                seen_types.add(entity_type)
                type_counts[entity_type] += 1

        # Second pass: fill remaining slots by salience
        for entity in entities:
            if entity not in selected and len(selected) < k:
                selected.append(entity)

        return selected


def validate_extraction_quality(
    entities: List[Dict[str, Any]],
    relationships: List[Dict[str, Any]],
    text: str,
    min_entities: int = 3,
    min_relationships: int = 1,
) -> Tuple[bool, Dict[str, Any]]:
    """Validate extraction quality and return metrics."""

    # Basic counts
    entity_count = len(entities)
    relationship_count = len(relationships)

    # Entity type diversity
    entity_types = {e.get("type", "UNKNOWN") for e in entities}
    type_diversity = len(entity_types) / max(len(entities), 1)

    # Relationship connectivity
    if relationships:
        connected_entities = set()
        for rel in relationships:
            connected_entities.add(rel.get("source"))
            connected_entities.add(rel.get("target"))
        connectivity = len(connected_entities) / max(len(entities) * 2, 1)
    else:
        connectivity = 0.0

    # Overall quality assessment
    quality_ok = (
        entity_count >= min_entities and relationship_count >= min_relationships
    )

    metrics = {
        "entity_count": entity_count,
        "relationship_count": relationship_count,
        "type_diversity": type_diversity,
        "connectivity": connectivity,
        "quality_ok": quality_ok,
    }

    return quality_ok, metrics
