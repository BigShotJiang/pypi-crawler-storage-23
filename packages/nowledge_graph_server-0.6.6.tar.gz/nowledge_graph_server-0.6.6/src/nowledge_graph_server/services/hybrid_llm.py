"""Hybrid LLM service that uses local LLM for fast operations and cloud LLM for complex tasks."""

from typing import Dict, List, Any, Optional, Tuple, Protocol
import structlog

logger = structlog.get_logger(__name__)


from nowledge_graph_server.services.local_llm import (
    LocalLLMService,
    LLMGenerationConfig,
    MemoryDistillationResult,
    EntityExtractionResult,
    UnifiedLLMService,
    BaseLLMProvider,
)
from nowledge_graph_server.services.json_utils import clean_and_parse_json
from nowledge_graph_server.services.content_chunking import chunk_content


class CloudLLMProvider(BaseLLMProvider):
    """Cloud LLM provider for fallback when local LLM is too slow or resource-intensive."""

    def __init__(
        self,
        provider: str = "openai",
        api_key: Optional[str] = None,
        model_name: str = "gpt-4o-mini",
    ):
        """Initialize cloud LLM provider.

        Args:
            provider: Cloud provider (openai, anthropic, etc.)
            api_key: API key for the provider
            model_name: Model name to use
        """
        self.provider = provider
        self.api_key = api_key
        self.model_name = model_name
        self._initialized = False
        self._uses_langfuse_client = False

    async def initialize(self) -> None:
        """Initialize the cloud LLM provider."""
        if not self.api_key:
            raise ValueError(f"API key required for {self.provider}")

        # Initialize the specific provider client
        if self.provider == "openai":
            try:
                # Use LangFuse-wrapped OpenAI client in dev mode for better observability
                import os
                dev_mode_env = os.getenv("NOWLEDGE_DEV_MODE", "")
                dev_mode = dev_mode_env.lower() in ("true", "1", "yes")
                
                if dev_mode:
                    langfuse_public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
                    langfuse_secret_key = os.getenv("LANGFUSE_SECRET_KEY")
                    
                    if langfuse_public_key and langfuse_secret_key:
                        try:
                            from langfuse.openai import openai  # type: ignore
                            logger.debug("Using LangFuse-wrapped OpenAI client for observability")
                            self._uses_langfuse_client = True
                        except ImportError:
                            logger.warning(
                                "LangFuse OpenAI wrapper not available, falling back to standard OpenAI client",
                                hint="Install langfuse to enable OpenAI observability: pip install langfuse"
                            )
                            import openai  # type: ignore
                    else:
                        logger.debug("LangFuse credentials not found, using standard OpenAI client")
                        import openai  # type: ignore
                else:
                    import openai  # type: ignore

                self.client = openai.AsyncOpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError("OpenAI not installed. Run: pip install openai")
        elif self.provider == "anthropic":
            try:
                import anthropic  # type: ignore

                self.client = anthropic.AsyncAnthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError("Anthropic not installed. Run: pip install anthropic")
        else:
            raise ValueError(f"Unsupported cloud provider: {self.provider}")

        self._initialized = True
        logger.info(
            "Cloud LLM provider initialized",
            provider=self.provider,
            model=self.model_name,
        )

    async def generate_response(self, prompt: str, config: LLMGenerationConfig, operation_name: Optional[str] = None) -> str:
        """Generate response using cloud LLM."""
        if not self._initialized:
            await self.initialize()

        try:
            if self.provider == "openai":
                # Build kwargs, only include optional params if explicitly set
                kwargs = {
                    "model": self.model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": config.max_tokens,
                }
                if config.temperature is not None:
                    kwargs["temperature"] = config.temperature
                if config.top_p is not None:
                    kwargs["top_p"] = config.top_p
                
                # Add LangFuse metadata only if client supports it
                if self._uses_langfuse_client and operation_name:
                    kwargs["name"] = operation_name
                    kwargs["metadata"] = {
                        "operation": operation_name,
                        "provider": "openai",
                        "model": self.model_name,
                    }

                response = await self.client.chat.completions.create(**kwargs)  # type: ignore[attr-defined]
                return response.choices[0].message.content or ""

            elif self.provider == "anthropic":
                # Build kwargs, only include optional params if explicitly set
                kwargs = {
                    "model": self.model_name,
                    "max_tokens": config.max_tokens,
                    "messages": [{"role": "user", "content": prompt}],
                }
                if config.temperature is not None:
                    kwargs["temperature"] = config.temperature

                response = await self.client.messages.create(**kwargs)  # type: ignore[attr-defined]
                return response.content[0].text or ""

        except Exception as e:
            logger.error(
                "Cloud LLM generation failed", provider=self.provider, error=str(e)
            )
            raise

        # This should never be reached, but added for safety
        return ""

    async def close(self) -> None:
        """Close cloud LLM provider."""
        self._initialized = False


class HybridLLMService:
    """Hybrid LLM service that uses local LLM for fast operations and cloud LLM for complex tasks."""

    def __init__(
        self,
        local_model_name: str = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
        cloud_provider: str = "openai",
        cloud_api_key: Optional[str] = None,
        cloud_model_name: str = "gpt-4o-mini",
        performance_mode: str = "balanced",  # fast, balanced, quality
    ):
        """Initialize hybrid LLM service.

        Args:
            local_model_name: Local MLX model name
            cloud_provider: Cloud provider for fallback
            cloud_api_key: API key for cloud provider
            cloud_model_name: Cloud model name
            performance_mode: Performance mode (fast=local_only, balanced=hybrid, quality=cloud_preferred)
        """
        self.local_service = LocalLLMService(local_model_name)
        self.cloud_service = None
        self.performance_mode = performance_mode
        self._initialized = False

        # Initialize cloud service if API key provided
        if cloud_api_key:
            self.cloud_service = UnifiedLLMService(
                provider="cloud",
                cloud_provider=cloud_provider,
                cloud_api_key=cloud_api_key,
                cloud_model_name=cloud_model_name,
            )

        # Performance thresholds
        self.complexity_thresholds = {
            "text_length": 12000,  # Use cloud for very long text
            "chunk_count": 4,  # Use cloud for many chunks
            "processing_time": 10.0,  # Use cloud if local is too slow
        }

    async def initialize(self) -> None:
        """Initialize both local and cloud services."""
        await self.local_service.initialize()
        if self.cloud_service:
            await self.cloud_service.initialize()
        self._initialized = True
        logger.info(
            "Hybrid LLM service initialized",
            local_available=True,
            cloud_available=bool(self.cloud_service),
            performance_mode=self.performance_mode,
        )

    async def distill_memories(
        self, thread_content: str, thread_title: str = ""
    ) -> MemoryDistillationResult:
        """Distill memories using the optimal service based on content complexity."""
        if not self._initialized:
            await self.initialize()

        # Analyze content complexity
        complexity_score = self._analyze_complexity(thread_content)
        use_cloud = self._should_use_cloud(complexity_score, "memory_distillation")

        logger.info(
            "Memory distillation service selection",
            content_length=len(thread_content),
            complexity_score=complexity_score,
            use_cloud=use_cloud,
            performance_mode=self.performance_mode,
        )

        if use_cloud and self.cloud_service:
            try:
                # Use cloud for complex processing
                logger.info("Using cloud LLM for memory distillation")
                return await self._distill_memories_cloud(thread_content, thread_title)
            except Exception as e:
                logger.warning("Cloud LLM failed, falling back to local", error=str(e))
                return await self.local_service.distill_memories(
                    thread_content, thread_title
                )
        else:
            # Use local LLM with optimized chunking
            logger.info("Using local LLM for memory distillation")
            return await self.local_service.distill_memories(
                thread_content, thread_title
            )

    async def extract_entities(self, text: str) -> EntityExtractionResult:
        """Extract entities using the optimal service."""
        if not self._initialized:
            await self.initialize()

        complexity_score = self._analyze_complexity(text)
        use_cloud = self._should_use_cloud(complexity_score, "entity_extraction")

        logger.info(
            "Entity extraction service selection",
            text_length=len(text),
            complexity_score=complexity_score,
            use_cloud=use_cloud,
        )

        if use_cloud and self.cloud_service:
            try:
                logger.info("Using cloud LLM for entity extraction")
                return await self._extract_entities_cloud(text)
            except Exception as e:
                logger.warning("Cloud LLM failed, falling back to local", error=str(e))
                raise e
        else:
            logger.info("Using local LLM for entity extraction")
            raise ValueError(
                "Could not find previous entity extraction results, please try again"
            )

    def _analyze_complexity(self, content: str) -> float:
        """Analyze content complexity to determine optimal processing strategy."""
        factors = {
            "length": min(len(content) / 20000, 1.0),  # Normalize to 0-1
            "chunk_count": min(
                len(chunk_content(content)) / 8, 1.0
            ),
            "linguistic_complexity": self._estimate_linguistic_complexity(content),
        }

        # Weighted complexity score
        weights = {"length": 0.4, "chunk_count": 0.4, "linguistic_complexity": 0.2}
        complexity = sum(factors[k] * weights[k] for k in factors)

        return complexity

    def _estimate_linguistic_complexity(self, content: str) -> float:
        """Estimate linguistic complexity of content."""
        # Simple heuristics for complexity
        factors = [
            len(content.split("\n")) / 100,  # Many messages
            len([w for w in content.split() if len(w) > 10])
            / len(content.split()),  # Long words
            content.count("```") / 10,  # Code blocks
            content.count("http") / 20,  # URLs
        ]
        return min(sum(factors) / len(factors), 1.0)

    def _should_use_cloud(self, complexity_score: float, task_type: str) -> bool:
        """Determine whether to use cloud LLM based on complexity and performance mode."""
        if not self.cloud_service:
            return False

        if self.performance_mode == "fast":
            return False  # Always use local
        elif self.performance_mode == "quality":
            return True  # Prefer cloud
        else:  # balanced
            # Use cloud for high complexity tasks
            thresholds = {
                "memory_distillation": 0.6,  # More complex task
                "entity_extraction": 0.7,  # Simpler task
            }
            return complexity_score > thresholds.get(task_type, 0.5)

    async def _distill_memories_cloud(
        self, thread_content: str, thread_title: str
    ) -> MemoryDistillationResult:
        """Distill memories using cloud LLM with full context window."""
        # Use the enhanced prompt but with cloud LLM's larger context window
        prompt = f"""Analyze this conversation to extract 1-5 of the most valuable, actionable memories.

CONVERSATION:
{thread_content}

ANALYSIS FRAMEWORK - Focus on memories that contain:
• DECISIONS: What was decided and WHY? What alternatives were considered?
• KEY INSIGHTS: Breakthrough understanding, realizations, or mental models that change thinking
• SOLUTIONS: Specific problems solved and the approaches that worked
• IMPORTANT FACTS: Critical information that will be valuable in the future
• LESSONS LEARNED: What worked, what didn't, and the reasoning behind it
• STRATEGIC IMPLICATIONS: How this changes future decisions or approaches

MEMORY QUALITY TEST - Each memory should pass:
✓ Would I want to remember this 6 months from now?
✓ Does this change how I think about or approach something?
✓ Is this specific enough to be actionable?
✓ Does it capture the WHY behind decisions, not just the what?

EXTRACTION PRIORITIES:
- Quality over quantity (fewer high-quality memories are better)
- Capture the reasoning and context, not just facts
- Focus on content with lasting value and implications
- Be specific and concrete rather than vague
- Include the broader significance of what was learned/decided

Output this EXACT JSON format:
{{"memories": [{{"title": "Clear, specific title (max 12 words)", "content": "Detailed explanation including context, reasoning, and implications", "importance": 0.9, "confidence": 0.85, "tags": ["decision", "insight", "solution", "lesson", "fact"], "context": "Why this matters and broader implications"}}], "summary": "Brief overview of key outcomes and their significance"}}

JSON:"""

        try:
            config = LLMGenerationConfig(max_tokens=4096, use_thinking=False)
            assert self.cloud_service is not None, "Cloud service is not initialized"
            response = await self.cloud_service.generate_response(prompt, config)
            parsed_result = clean_and_parse_json(response)

            if parsed_result:
                return MemoryDistillationResult(
                    memories=parsed_result.get("memories", []),
                    entities=parsed_result.get("entities", []),
                    relationships=parsed_result.get("relationships", []),
                    insights=parsed_result.get("insights", []),
                    summary=parsed_result.get("summary", ""),
                )
            else:
                raise ValueError("Failed to parse cloud LLM response")

        except Exception as e:
            logger.error("Cloud memory distillation failed", error=str(e))
            raise

    async def _extract_entities_cloud(self, text: str) -> EntityExtractionResult:
        """Extract entities using cloud LLM."""
        # Use the conservative entity extraction prompt
        prompt = f"""Analyze this text to extract only the most important entities and their STRONG, EXPLICIT relationships.

TEXT: {text}

ENTITY SELECTION CRITERIA - Only extract entities that are:
• EXPLICITLY mentioned and central to the discussion
• SPECIFIC and concrete (not vague concepts)
• ACTIONABLE or DECISION-CRITICAL (tools, technologies, specific methods)
• DIRECTLY relevant to the main topic

RELATIONSHIP SELECTION CRITERIA - Only create relationships that are:
• EXPLICITLY STATED in the text (not inferred)
• FUNCTIONALLY IMPORTANT (direct dependencies, uses, implements)
• CLEARLY DEFINED (avoid vague "relates to" connections)
• LIMIT: Maximum 1-2 relationships per entity

AVOID:
• Vague conceptual connections
• Inferential or implied relationships  
• Generic entity types like "system", "approach", "method"
• Relationships based on mere co-mention

Be CONSERVATIVE - it's better to miss weak connections than create spurious ones.

Output this EXACT JSON format:
{{"entities":[{{"name":"EntityName","type":"SPECIFIC_TYPE","mentions":1,"confidence":CONFIDENCE_SCORE,"description":"Concrete role/function in text"}}],"relationships":[{{"source":"Entity1","target":"Entity2","relation":"SPECIFIC_RELATION","confidence":CONFIDENCE_SCORE,"context":"Explicit connection stated in text"}}],"confidence":OVERALL_CONFIDENCE}}

CONFIDENCE SCORING:
- Entity confidence (0.0-1.0): How certain you are this is a real, distinct entity
  - 0.9-1.0: Explicitly named, concrete entities (tools, technologies, people)
  - 0.7-0.9: Clear functional entities with specific roles  
  - 0.5-0.7: Conceptual entities that are well-defined
  - Below 0.5: Don't include (too vague or uncertain)
- Relationship confidence (0.0-1.0): How explicitly the connection is stated
  - 0.9-1.0: Direct, functional dependencies explicitly mentioned
  - 0.7-0.9: Clear interactions or influences stated
  - 0.5-0.7: Implied connections with good evidence
  - Below 0.5: Don't include (too inferential)
- Overall confidence (0.0-1.0): How reliable this entire extraction is

JSON:"""

        try:
            config = LLMGenerationConfig(
                max_tokens=2048,  # Reduced for conservative extraction
                use_thinking=False,
            )
            assert self.cloud_service is not None, "Cloud service is not initialized"
            response = await self.cloud_service.generate_response(prompt, config)
            parsed_result = clean_and_parse_json(response)

            if parsed_result:
                entities = parsed_result.get("entities", [])
                relationships = parsed_result.get("relationships", [])

                # Apply conservative filtering to cloud results too
                filtered_entities = []
                filtered_relationships = []

                # Filter entities by confidence and specificity
                for entity in entities:
                    if (
                        entity.get("confidence", 0) >= 0.7
                    ):  # Higher confidence threshold
                        entity["extraction_method"] = "cloud_llm"
                        entity["source_type"] = "text"
                        filtered_entities.append(entity)

                # Filter relationships more aggressively
                entity_names = {e["name"] for e in filtered_entities}
                relationship_count_per_entity = {}

                for rel in relationships:
                    # Only keep relationships between filtered entities
                    if (
                        rel.get("source") in entity_names
                        and rel.get("target") in entity_names
                        and rel.get("confidence", 0) >= 0.8
                    ):  # Higher confidence for relationships
                        # Limit relationships per entity (max 2)
                        source = rel["source"]
                        target = rel["target"]

                        source_count = relationship_count_per_entity.get(source, 0)
                        target_count = relationship_count_per_entity.get(target, 0)

                        if source_count < 2 and target_count < 2:
                            rel["extraction_method"] = "cloud_llm"
                            rel["source_type"] = "text"
                            filtered_relationships.append(rel)

                            relationship_count_per_entity[source] = source_count + 1
                            relationship_count_per_entity[target] = target_count + 1

                return EntityExtractionResult(
                    entities=filtered_entities,
                    relationships=filtered_relationships,
                    confidence=parsed_result.get(
                        "confidence", 0.6
                    ),  # More conservative fallback
                )
            else:
                raise ValueError("Failed to parse cloud LLM response")

        except Exception as e:
            logger.error("Cloud entity extraction failed", error=str(e))
            raise

    async def close(self) -> None:
        """Close both services."""
        await self.local_service.close()
        if self.cloud_service:
            await self.cloud_service.close()


# Global hybrid service instance
hybrid_llm_service: Optional[HybridLLMService] = None


async def get_hybrid_llm_service(
    cloud_api_key: Optional[str] = None, performance_mode: str = "balanced"
) -> HybridLLMService:
    """Get or create the hybrid LLM service instance."""
    global hybrid_llm_service

    if hybrid_llm_service is None:
        hybrid_llm_service = HybridLLMService(
            cloud_api_key=cloud_api_key, performance_mode=performance_mode
        )
        await hybrid_llm_service.initialize()

    return hybrid_llm_service
