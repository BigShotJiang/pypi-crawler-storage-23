"""Source chunking service — splits parsed markdown into indexed chunks.

Uses Chonkie for intelligent, structure-aware chunking:
- Heading-aware splitting for structured docs (DOCX, HTML)
- Paragraph-based splitting for flat text (PDFs, plain text)
- Code-aware splitting for source code files (Phase 2: tree-sitter)

Each chunk carries offset information for provenance tracking.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

import structlog

logger = structlog.get_logger(__name__)

# Target chunk sizes (in characters — Chonkie uses token_count but
# we configure via chunk_size which maps to characters)
DEFAULT_CHUNK_SIZE = 512
MIN_CHUNK_CHARS = 100
CODE_CHUNK_SIZE = 600

# MIME types for tabular data — use schema-based chunking instead of text splitting
TABULAR_MIMES = frozenset({
    "text/csv",
    "text/tab-separated-values",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
})

# Max sample rows to include in a schema chunk
SCHEMA_SAMPLE_ROWS = 5


@dataclass
class SourceChunk:
    """A chunk of parsed source content with provenance info."""

    text: str
    chunk_index: int
    start_offset: int
    end_offset: int
    heading_context: str  # e.g. "§3.2 Authentication"
    token_count: int


def chunk_source(
    parsed_markdown: str,
    mime_type: str = "text/markdown",
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> List[SourceChunk]:
    """Split parsed markdown into chunks based on content structure.

    Strategy:
    - Structured docs (has headings): heading-aware recursive splitting
    - Flat text (no headings): paragraph-based recursive splitting
    """
    if not parsed_markdown or len(parsed_markdown.strip()) < MIN_CHUNK_CHARS:
        # Too short to chunk — return as single chunk
        return [
            SourceChunk(
                text=parsed_markdown.strip(),
                chunk_index=0,
                start_offset=0,
                end_offset=len(parsed_markdown),
                heading_context="",
                token_count=_estimate_tokens(parsed_markdown),
            )
        ]

    # Tabular data (CSV/XLSX): produce schema-level chunks instead of
    # fragmenting pipe tables into random text chunks.
    if mime_type in TABULAR_MIMES:
        return _chunk_tabular(parsed_markdown)

    has_headings = bool(re.search(r"^#{1,4}\s", parsed_markdown, re.MULTILINE))

    try:
        return _chunk_with_chonkie(parsed_markdown, has_headings, chunk_size)
    except ImportError:
        logger.warning("Chonkie not installed, falling back to simple chunking")
        return _chunk_simple(parsed_markdown, chunk_size)
    except Exception as e:
        logger.warning("Chonkie chunking failed, falling back to simple", error=str(e))
        return _chunk_simple(parsed_markdown, chunk_size)


def _chunk_with_chonkie(
    text: str, has_headings: bool, chunk_size: int
) -> List[SourceChunk]:
    """Chunk using Chonkie RecursiveChunker."""
    from chonkie import RecursiveChunker
    from chonkie.types import RecursiveRules, RecursiveLevel

    if has_headings:
        rules = RecursiveRules(
            levels=[
                RecursiveLevel(delimiters=["\n## ", "\n### ", "\n#### "]),
                RecursiveLevel(delimiters=["\n\n"]),
                RecursiveLevel(delimiters=[". ", "! ", "? "]),
                RecursiveLevel(whitespace=True),
            ]
        )
    else:
        rules = RecursiveRules(
            levels=[
                RecursiveLevel(delimiters=["\n\n", "\n"]),
                RecursiveLevel(delimiters=[". ", "! ", "? "]),
                RecursiveLevel(whitespace=True),
            ]
        )

    chunker = RecursiveChunker(
        chunk_size=chunk_size,
        rules=rules,
        min_characters_per_chunk=MIN_CHUNK_CHARS,
    )

    raw_chunks = chunker.chunk(text)

    result: List[SourceChunk] = []
    for i, chunk in enumerate(raw_chunks):
        heading = _find_heading_context(text, chunk.start_index) if has_headings else ""
        result.append(
            SourceChunk(
                text=chunk.text,
                chunk_index=i,
                start_offset=chunk.start_index,
                end_offset=chunk.end_index,
                heading_context=heading,
                token_count=chunk.token_count if hasattr(chunk, "token_count") else _estimate_tokens(chunk.text),
            )
        )

    logger.info("Chunked source", count=len(result), has_headings=has_headings)
    return result


def _chunk_tabular(text: str) -> List[SourceChunk]:
    """Schema-based chunking for tabular data (CSV/XLSX).

    Instead of fragmenting pipe tables into random 512-char text chunks
    (which loses column headers and splits rows mid-cell), produce
    1 schema chunk per table/sheet containing:
    - Column names
    - Row count
    - Sample rows (first N data rows)

    This makes SearchSourceChunks useful for tables — the schema chunk
    embeds well and is searchable by column name or sample values.
    The agent uses ReadSourceContent(limit=30000) for actual data.
    """
    lines = text.split("\n")
    chunks: List[SourceChunk] = []
    current_sheet: Optional[str] = None
    header_row: Optional[List[str]] = None
    separator_seen = False
    data_rows: List[str] = []  # raw pipe table lines
    data_count = 0
    table_start_offset = 0

    def _flush_table() -> None:
        nonlocal header_row, separator_seen, data_rows, data_count, table_start_offset
        if not header_row:
            return

        # Build schema description
        parts = []
        sheet_label = current_sheet or "Data"
        parts.append(f"Columns: {', '.join(header_row)}")
        parts.append(f"Column count: {len(header_row)}")
        parts.append(f"Data rows: {data_count}")
        if data_rows:
            # Reconstruct sample as a mini pipe table
            header_line = "| " + " | ".join(header_row) + " |"
            sep_line = "| " + " | ".join("---" for _ in header_row) + " |"
            parts.append(f"Sample rows:\n{header_line}\n{sep_line}")
            for row_line in data_rows[:SCHEMA_SAMPLE_ROWS]:
                parts.append(row_line)

        chunk_text = "\n".join(parts)
        chunks.append(
            SourceChunk(
                text=chunk_text,
                chunk_index=len(chunks),
                start_offset=table_start_offset,
                end_offset=table_start_offset + len(chunk_text),
                heading_context=f"Table Schema: {sheet_label}",
                token_count=_estimate_tokens(chunk_text),
            )
        )

        # Reset state for next table
        header_row = None
        separator_seen = False
        data_rows = []
        data_count = 0

    offset = 0
    for line in lines:
        trimmed = line.strip()

        # Detect sheet headings (## SheetName) from XLSX multi-sheet output
        if trimmed.startswith("## "):
            _flush_table()
            current_sheet = trimmed[3:].strip()
            offset += len(line) + 1
            continue

        # Pipe table row
        if trimmed.startswith("|") and trimmed.endswith("|"):
            cells = [c.strip() for c in trimmed[1:-1].split("|")]

            if header_row is None:
                # First pipe row = header
                header_row = cells
                table_start_offset = offset
            elif not separator_seen and all(re.match(r"^[\s\-:]+$", c) for c in cells):
                # Separator row
                separator_seen = True
            else:
                # Data row
                data_count += 1
                if len(data_rows) < SCHEMA_SAMPLE_ROWS:
                    data_rows.append(trimmed)
        else:
            # Non-table line — flush accumulated table
            if header_row:
                _flush_table()

        offset += len(line) + 1

    # Flush any remaining table
    _flush_table()

    # Fallback: if no tables found, return the whole text as a single chunk
    if not chunks:
        return [
            SourceChunk(
                text=text.strip(),
                chunk_index=0,
                start_offset=0,
                end_offset=len(text),
                heading_context="",
                token_count=_estimate_tokens(text),
            )
        ]

    logger.info("Chunked tabular source", sheets=len(chunks), strategy="schema")
    return chunks


def _chunk_simple(text: str, chunk_size: int) -> List[SourceChunk]:
    """Simple fallback chunking by paragraphs."""
    paragraphs = re.split(r"\n\n+", text)
    chunks: List[SourceChunk] = []
    current_text = ""
    current_start = 0
    offset = 0

    for para in paragraphs:
        para = para.strip()
        if not para:
            offset += 2  # \n\n
            continue

        if current_text and len(current_text) + len(para) > chunk_size:
            # Flush current chunk
            chunks.append(
                SourceChunk(
                    text=current_text,
                    chunk_index=len(chunks),
                    start_offset=current_start,
                    end_offset=current_start + len(current_text),
                    heading_context="",
                    token_count=_estimate_tokens(current_text),
                )
            )
            current_text = para
            current_start = offset
        else:
            if current_text:
                current_text += "\n\n" + para
            else:
                current_text = para
                current_start = offset

        offset += len(para) + 2  # paragraph + separator

    # Flush remaining
    if current_text.strip():
        chunks.append(
            SourceChunk(
                text=current_text,
                chunk_index=len(chunks),
                start_offset=current_start,
                end_offset=current_start + len(current_text),
                heading_context="",
                token_count=_estimate_tokens(current_text),
            )
        )

    return chunks


def _find_heading_context(text: str, offset: int) -> str:
    """Find the nearest heading above a given offset."""
    # Search backwards from offset for the nearest heading
    text_before = text[:offset]
    matches = list(re.finditer(r"^(#{1,4})\s+(.+)$", text_before, re.MULTILINE))
    if matches:
        last_match = matches[-1]
        level = len(last_match.group(1))
        title = last_match.group(2).strip()
        return f"{'§' * level} {title}"
    return ""


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token for English)."""
    return max(1, len(text) // 4)
