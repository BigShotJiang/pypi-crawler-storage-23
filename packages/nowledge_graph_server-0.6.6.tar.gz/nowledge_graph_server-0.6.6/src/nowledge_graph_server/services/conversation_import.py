"""Conversation import service for importing AI agent conversations into Nowledge Mem threads."""

import os
from datetime import datetime
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.models.thread import (
    ConversationImportRequest,
    ConversationImportResponse,
    MessageCreateRequest,
    ThreadCreateRequest,
)
from nowledge_graph_server.services.conversation_discovery import (
    ConversationDiscoveryService,
    ConversationFile,
)
from nowledge_graph_server.services.import_config import get_import_config_service
from nowledge_graph_server.tools.thread_file_handler import ThreadFileHandler

logger = structlog.get_logger(__name__)


class ConversationImportService:
    """Service for importing conversations from external sources."""

    def __init__(self, thread_ops: ThreadOperations):
        """Initialize with thread operations."""
        self.thread_ops = thread_ops
        self.file_handler = ThreadFileHandler(thread_ops)
        self.discovery_service = ConversationDiscoveryService()

    async def discover_conversations(
        self, source: Optional[str] = None
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Discover conversation files from AI coding assistants.

        Args:
            source: Optional source filter ("claude", "codex", "cursor", "opencode", or None for all)

        Returns:
            Dictionary mapping source names to lists of conversation file metadata
        """
        if source:
            if source == "claude":
                conversations = self.discovery_service.discover_claude_conversations()
            elif source == "codex":
                conversations = self.discovery_service.discover_codex_conversations()
            elif source == "cursor":
                conversations = self.discovery_service.discover_cursor_conversations()
            elif source == "opencode":
                conversations = self.discovery_service.discover_opencode_conversations()
            else:
                return {}
        else:
            all_conversations = self.discovery_service.discover_all()
            conversations = []
            for conv_list in all_conversations.values():
                conversations.extend(conv_list)

        # Convert to serializable format
        result: Dict[str, List[Dict[str, Any]]] = {}
        for conv in conversations:
            if conv.source not in result:
                result[conv.source] = []

            result[conv.source].append(
                {
                    "source": conv.source,  # Include source in each conversation object
                    "path": conv.path,
                    "session_id": conv.session_id,
                    "project": conv.project,
                    "workspace": conv.workspace,
                    "date": conv.date,
                    "last_modified": conv.last_modified,
                    "message_count": conv.message_count,
                    "preview": conv.preview,
                    "title": conv.title,  # Session title (e.g., Cursor composer name)
                    "metadata": conv.metadata,
                }
            )

        return result

    async def import_conversation(
        self,
        conversation_file: ConversationFile,
        thread_id_override: Optional[str] = None,
        auto_compact: bool = False,
        preserve_timestamps: bool = True,
        summary: Optional[str] = None,
    ) -> ConversationImportResponse:
        """Import a conversation file into Nowledge Mem.

        If a thread with the same ID already exists, new messages will be
        appended with deduplication (no duplicate messages).

        Args:
            conversation_file: The conversation file to import
            thread_id_override: Optional thread ID override
            auto_compact: Whether to auto-extract memories during import
            preserve_timestamps: Whether to preserve original timestamps
            summary: Optional user-provided summary

        Returns:
            ConversationImportResponse with import details
        """
        logger.info(
            "Importing conversation",
            source=conversation_file.source,
            path=conversation_file.path,
            session_id=conversation_file.session_id,
        )

        try:
            # Determine format based on source
            format_map = {
                "claude": "claude_code",
                "codex": "codex",
                "cursor": "cursor_vscdb",  # SQLite database format
                "opencode": "opencode",  # OpenCode JSON session files (legacy)
            }
            file_format = format_map.get(conversation_file.source, "auto")

            # Detect OpenCode SQLite vs JSON format
            if conversation_file.source == "opencode":
                storage_type = (conversation_file.metadata or {}).get("storage")
                if storage_type == "sqlite" or (
                    conversation_file.path and conversation_file.path.endswith(".db")
                ):
                    file_format = "opencode_sqlite"

            # Generate thread ID if not provided
            if not thread_id_override:
                thread_id_override = self._generate_thread_id(conversation_file)

            # Check if thread already exists
            existing_thread = await self.thread_ops.get_thread(thread_id_override)
            warnings: List[str] = []

            if existing_thread:
                # Thread exists - append new messages with deduplication
                logger.info(
                    "Thread exists, appending new messages",
                    thread_id=thread_id_override,
                    source=conversation_file.source,
                )

                append_result = await self.file_handler.append_messages_from_file(
                    thread_id=thread_id_override,
                    file_path=conversation_file.path,
                    format=file_format,
                    deduplicate=True,
                    truncate_large_content=False,
                    session_id=conversation_file.session_id,
                )

                # Build import summary for append
                import_summary = (
                    f"Appended {append_result['messages_added']} new messages "
                    f"(total: {append_result['total_messages']}) from {conversation_file.source}"
                )
                if conversation_file.project:
                    import_summary += f" (project: {conversation_file.project})"

                if append_result["messages_added"] == 0:
                    warnings.append("No new messages to add (all messages already exist)")

                # Fetch updated thread for response
                updated_thread_response = await self.thread_ops.get_thread(thread_id_override)
                if not updated_thread_response:
                    raise ValueError(f"Failed to fetch updated thread: {thread_id_override}")

                # Auto-add project to watched list for project-level sync
                self._auto_add_watched_project(conversation_file)

                return ConversationImportResponse(
                    thread=updated_thread_response.thread,
                    messages=[],  # Don't return all messages on append
                    import_summary=import_summary,
                    warnings=warnings,
                    created_memories=[],
                    skipped_messages=append_result.get("skipped", 0),
                )
            else:
                # Create new thread
                result = await self.file_handler.create_thread_from_file(
                    file_path=conversation_file.path,
                    format=file_format,
                    thread_id_override=thread_id_override,
                    summary=summary,
                    truncate_large_content=False,  # Preserve all content by default
                    session_id=conversation_file.session_id,
                )

                # Optionally auto-compact (extract memories)
                created_memories = []
                if auto_compact:
                    # TODO: Implement auto-compact logic
                    logger.info("Auto-compact requested but not yet implemented")

                # Build import summary
                import_summary = (
                    f"Imported {len(result.messages)} messages from {conversation_file.source}"
                )
                if conversation_file.project:
                    import_summary += f" (project: {conversation_file.project})"

                # Auto-add project to watched list for project-level sync
                self._auto_add_watched_project(conversation_file)

                return ConversationImportResponse(
                    thread=result.thread,
                    messages=result.messages,
                    import_summary=import_summary,
                    warnings=warnings,
                    created_memories=created_memories,
                    skipped_messages=0,
                )

        except Exception as e:
            logger.error(
                "Failed to import conversation",
                source=conversation_file.source,
                path=conversation_file.path,
                error=str(e),
            )
            raise

    async def import_from_request(
        self, request: ConversationImportRequest
    ) -> ConversationImportResponse:
        """Import conversation from a ConversationImportRequest.

        Args:
            request: Import request with source data

        Returns:
            ConversationImportResponse
        """
        # Convert request to ConversationFile
        source_data = request.source_data
        conversation_file = ConversationFile(
            source=request.source_type,
            path=source_data.get("path", ""),
            session_id=source_data.get("session_id"),
            project=source_data.get("project"),
            workspace=source_data.get("workspace"),
            metadata=source_data.get("metadata", {}),
        )

        return await self.import_conversation(
            conversation_file=conversation_file,
            thread_id_override=request.thread_id_override,
            auto_compact=request.auto_compact,
            preserve_timestamps=request.preserve_timestamps,
        )

    def _generate_thread_id(self, conversation_file: ConversationFile) -> str:
        """Generate a thread ID from conversation file metadata.

        Always returns lowercase to match ThreadNode validator normalization.
        """
        if conversation_file.session_id:
            return f"{conversation_file.source}-{conversation_file.session_id}".lower()

        # Fallback: use path hash (already lowercase hex)
        import hashlib

        path_hash = hashlib.md5(conversation_file.path.encode()).hexdigest()[:8]
        return f"{conversation_file.source}-{path_hash}"

    def _auto_add_watched_project(self, conversation_file: ConversationFile) -> None:
        """Add project to watched_projects in ImportConfig after successful import.

        This ensures project-level sync works independently of platform toggles.
        If a session from a project has been imported, we watch that project
        regardless of whether the platform's global toggle is enabled.
        """
        project_encoded = self._extract_project_encoded(conversation_file)
        if not project_encoded:
            return

        try:
            config_service = get_import_config_service()
            config = config_service.load()
            if project_encoded not in config.watched_projects:
                config.watched_projects.append(project_encoded)
                config_service.save(config)
                logger.info(
                    "Auto-added project to watched_projects",
                    project_encoded=project_encoded,
                    source=conversation_file.source,
                )
        except Exception as e:
            logger.warning(
                "Failed to auto-add project to watched_projects",
                project_encoded=project_encoded,
                error=str(e),
            )

    def _extract_project_encoded(self, conversation_file: ConversationFile) -> Optional[str]:
        """Extract encoded project path from conversation file."""
        path = conversation_file.path.replace("\\", "/")
        parts = path.split("/")

        if conversation_file.source == "claude":
            try:
                projects_idx = parts.index("projects")
                if projects_idx + 1 < len(parts):
                    return parts[projects_idx + 1]
            except ValueError:
                pass
        elif conversation_file.source == "codex":
            try:
                sessions_idx = parts.index("sessions")
                if sessions_idx + 3 < len(parts):
                    return f"{parts[sessions_idx + 1]}-{parts[sessions_idx + 2]}-{parts[sessions_idx + 3]}"
            except ValueError:
                pass
        elif conversation_file.source == "cursor":
            # Cursor: encode workspace path
            workspace = conversation_file.workspace or conversation_file.project or ""
            if workspace.startswith("/"):
                return "-" + workspace[1:].replace("/", "-")
        elif conversation_file.source == "opencode":
            # For SQLite-based sessions, use metadata project_id or workspace
            metadata = conversation_file.metadata or {}
            if metadata.get("storage") == "sqlite" or path.endswith(".db"):
                project_encoded = metadata.get("project_encoded")
                if project_encoded:
                    return project_encoded
                # Fall back to encoding workspace
                workspace = conversation_file.workspace
                if workspace and workspace.startswith("/"):
                    return "-" + workspace[1:].replace("/", "-")
                return metadata.get("project_id")

            # Legacy JSON: extract from path
            try:
                session_idx = parts.index("session")
                if session_idx + 1 < len(parts):
                    return parts[session_idx + 1]
            except ValueError:
                pass

        return None

    def _extract_project_name(self, workspace: Optional[str]) -> Optional[str]:
        """Extract project name from workspace path (cross-platform)."""
        if not workspace:
            return None
        return os.path.basename(workspace.rstrip("/\\"))
