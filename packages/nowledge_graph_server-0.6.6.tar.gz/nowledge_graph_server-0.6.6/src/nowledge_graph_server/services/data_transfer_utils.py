"""Shared helpers for data export/import."""

from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Optional

INTERNAL_TABLES = {
    "MigrationHistory",
    "GraphMeta",
    "AugmentationJob",
}

KNOWN_COLUMN_TYPES = {
    "STRING",
    "INT64",
    "DOUBLE",
    "BOOLEAN",
    "TIMESTAMP",
    "DATE",
    "FLOAT[]",
    "STRING[]",
}


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _is_zip_path(path: Path) -> bool:
    return path.suffix.lower() == ".zip"


def _to_jsonable(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, list):
        return [_to_jsonable(v) for v in value]
    if isinstance(value, tuple):
        return [_to_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if hasattr(value, "tolist"):
        try:
            return value.tolist()
        except Exception:
            pass
    return str(value)


def _node_to_dict(node: Any) -> Dict[str, Any]:
    if node is None:
        return {}
    if isinstance(node, dict):
        data = dict(node)
        data.pop("_ID", None)
        data.pop("_LABEL", None)
        return data
    if hasattr(node, "properties"):
        try:
            data = dict(node.properties)  # type: ignore[attr-defined]
            data.pop("_ID", None)
            data.pop("_LABEL", None)
            return data
        except Exception:
            pass
    try:
        data = dict(node)
        data.pop("_ID", None)
        data.pop("_LABEL", None)
        return data
    except Exception:
        return {}


def _files_equal(path_a: Path, path_b: Path) -> bool:
    if path_a.stat().st_size != path_b.stat().st_size:
        return False
    chunk_size = 1024 * 1024
    with path_a.open("rb") as fa, path_b.open("rb") as fb:
        while True:
            chunk_a = fa.read(chunk_size)
            chunk_b = fb.read(chunk_size)
            if chunk_a != chunk_b:
                return False
            if not chunk_a:
                return True


def _parse_datetime(value: Any) -> Any:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return value
    return value


def _parse_date(value: Any) -> Any:
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return date.fromisoformat(value)
        except ValueError:
            return value
    return value


def _coerce_value_for_column(value: Any, col_type: Optional[str]) -> Any:
    if col_type == "TIMESTAMP":
        return _parse_datetime(value)
    if col_type == "DATE":
        return _parse_date(value)
    return value


def _sanitize_table_name(table: str) -> str:
    cleaned = "".join(ch for ch in table if ch.isalnum() or ch == "_")
    return cleaned


def _escape_identifier(name: str) -> str:
    cleaned = name.replace("`", "")
    return f"`{cleaned}`"
