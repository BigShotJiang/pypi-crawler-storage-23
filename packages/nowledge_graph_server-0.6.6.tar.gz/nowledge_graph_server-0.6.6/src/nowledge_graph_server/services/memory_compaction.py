"""Memory compaction service for creating memories from conversations."""

from typing import List, Optional
from ..models import (
    MemoryNode,
    MessageNode,
    ThreadNode,
    MemoryCreateResponse,
)
# from .summarization import SummarizationService


class MemoryCompactionService:
    """Service for creating memories from conversations."""

    def __init__(
        self,
        db,
        embedding_service,
        entity_service,
        # summarization_service: Optional[SummarizationService] = None,
    ):
        """Initialize memory compaction service.

        Args:
            db: Database client
            embedding_service: Embedding service
            entity_service: Entity extraction service
            summarization_service: Optional summarization service
        """
        self.db = db
        self.embedding_service = embedding_service
        self.entity_service = entity_service
        # self.summarization_service = summarization_service

        # async def create_memory(
        #     self,
        #     content: str,
        #     source_thread_id: Optional[str] = None,
        #     importance: float = 0.5,
        #     confidence: float = 0.5,
        #     labels: Optional[List[str]] = None,
        # ) -> MemoryCreateResponse:
        """Create a memory from content.

        Args:
            content: Memory content
            source_thread_id: Optional source thread ID
            importance: Importance score
            confidence: Confidence score
            labels: Label names

        Returns:
            Memory creation response
        """
        # labels = labels or []

        # Generate summary
        # summary = content[:100] + "..." if len(content) > 100 else content
        # if self.summarization_service:
        #     try:
        #         summary = await self.summarization_service.summarize_memory(content)
        #     except Exception:
        #         pass  # Fall back to truncated content

        # # Create memory node
        # memory_node = MemoryNode(
        #     content=content,
        #     importance=importance,
        #     confidence=confidence,
        #     embedding=[],
        #     source_range={},
        #     title=summary,
        #     semantic_field=f"{summary}\n{content}",
        #     last_reindexed_at=datetime.now(),
        # )

        # # Generate embedding
        # embedding = await self.embedding_service.embed_text(content)
        # memory_node.embedding = embedding

        # # Extract entities
        # entities = await self.entity_service.extract_entities(content)

        # # Store in database
        # await self.db.create_memory(memory_node)

        # return MemoryCreateResponse(
        #     memory=memory_node,
        #     extracted_entities=entities,
        #     assigned_labels=labels,
        #     created_relationships=len(entities),
        # )

    # async def generate_thread_summary(
    #     self, thread: ThreadNode, messages: List[MessageNode]
    # ) -> str:
    #     """Generate a summary for a thread.

    #     Args:
    #         thread: Thread node
    #         messages: List of messages

    #     Returns:
    #         Thread summary
    #     """
    #     if not messages:
    #         return "Empty conversation"

    #     #Use summarization service if available
    #     if self.summarization_service:
    #         try:
    #             return await self.summarization_service.summarize_thread(
    #                 thread, messages
    #             )
    #         except Exception:
    #             pass  # Fall back to simple summary

    #     # Simple fallback summary
    #     return f"Conversation with {len(messages)} messages about {thread.title or 'general topics'}"
