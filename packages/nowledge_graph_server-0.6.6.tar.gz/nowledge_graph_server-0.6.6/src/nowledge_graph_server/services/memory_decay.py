"""
Memory Decay Service

Implements minimal practical decay model for passive retrieval.
Based on DECAY_MODEL_STUDY.md - simple recency + frequency instead of full FSRS/ACT-R.

Key formulas:
- Recency: exp(-days_since_access / half_life)
- Frequency: log(1 + access_count) / log(100)
- Decay: 0.7 * recency + 0.3 * frequency
- Floor: 0.3 + (importance * 0.2)  # Adjusted based on feedback
- Final: max(decay, floor)
"""

import math
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import structlog

logger = structlog.get_logger(__name__)


# ==============================================================================
# HYPERPARAMETERS (tunable)
# ==============================================================================

# Recency decay half-life in days
# This represents the system's "patience" - how long before memories start fading
# If system forgets too quickly, increase this number
# If system is too cluttered with old memories, decrease it
HALF_LIFE_DAYS = 30

# Importance floor formula: 0.3 + (importance * IMPORTANCE_MULTIPLIER)
# Adjusted from 0.4 to 0.2 based on feedback to prevent important memories from dominating
# This gives range 0.3-0.5 instead of 0.3-0.7
IMPORTANCE_MULTIPLIER = 0.2

# Minimum importance floor (even for importance=0)
MIN_IMPORTANCE_FLOOR = 0.3

# Decay weight in final scoring (blend with semantic score)
# Reduced from 0.2 to 0.15 based on feedback (15% influence, more conservative)
DECAY_WEIGHT = 0.15

# Recency vs frequency weight in decay score
RECENCY_WEIGHT = 0.7
FREQUENCY_WEIGHT = 0.3

# Frequency normalization factor (log base)
# access_count of 100 → frequency_score of 1.0
FREQUENCY_MAX_COUNT = 100


def compute_decay_score(
    last_accessed_at: Optional[datetime],
    access_count: int = 0,
    importance: float = 0.5,
    now: Optional[datetime] = None,
) -> float:
    """
    Compute decay score for a memory based on recency and frequency.

    Args:
        last_accessed_at: When memory was last accessed (shown or clicked)
        access_count: Total number of accesses
        importance: Memory importance (0-1)
        now: Current time (defaults to datetime.now())

    Returns:
        Decay score (0-1), never below importance floor
    """
    if now is None:
        now = datetime.now(timezone.utc)

    # Calculate recency score
    if last_accessed_at is None:
        # Never accessed → treat as very old (999 days)
        days_since = 999
    else:
        # Ensure both datetimes are timezone-aware for comparison
        if last_accessed_at.tzinfo is None:
            last_accessed_at = last_accessed_at.replace(tzinfo=timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)

        delta = now - last_accessed_at
        days_since = delta.total_seconds() / 86400  # Convert to days

    # Exponential decay: exp(-days / half_life)
    recency_score = math.exp(-days_since / HALF_LIFE_DAYS)

    # Calculate frequency score
    # Logarithmic: frequently accessed memories get a boost, but with diminishing returns
    frequency_score = math.log(1 + access_count) / math.log(FREQUENCY_MAX_COUNT)
    frequency_score = min(frequency_score, 1.0)  # Cap at 1.0

    # Combine recency and frequency
    decay_raw = RECENCY_WEIGHT * recency_score + FREQUENCY_WEIGHT * frequency_score

    # Calculate importance floor
    # Adjusted: 0.3 + (importance * 0.2) → range 0.3-0.5
    # This prevents important memories from dominating (was 0.3-0.7)
    importance_floor = MIN_IMPORTANCE_FLOOR + (importance * IMPORTANCE_MULTIPLIER)

    # Apply floor
    decay_score = max(decay_raw, importance_floor)

    # logger.debug(
    #     "Computed decay score",
    #     days_since=round(days_since, 1),
    #     access_count=access_count,
    #     recency=round(recency_score, 3),
    #     frequency=round(frequency_score, 3),
    #     decay_raw=round(decay_raw, 3),
    #     importance=importance,
    #     floor=round(importance_floor, 3),
    #     final=round(decay_score, 3),
    # )

    return decay_score


def blend_with_semantic_score(
    semantic_score: float,
    decay_score: float,
    decay_weight: float = DECAY_WEIGHT,
) -> float:
    """
    Blend semantic score with decay score.

    Args:
        semantic_score: Semantic similarity score (0-1) from vector/FTS/entity/community fusion
        decay_score: Decay score (0-1) from compute_decay_score()
        decay_weight: Weight of decay score in final blend (default 0.15 = 15% influence)

    Returns:
        Blended score (0-1)
    """
    # Weighted average: semantic_score * (1 - decay_weight) + decay_score * decay_weight
    final_score = semantic_score * (1 - decay_weight) + decay_score * decay_weight

    # logger.debug(
    #     "Blended scores",
    #     semantic=round(semantic_score, 3),
    #     decay=round(decay_score, 3),
    #     decay_weight=decay_weight,
    #     final=round(final_score, 3),
    # )

    return final_score


def compute_ctr(appearances: int, clicks: int) -> float:
    """
    Compute click-through rate.

    Args:
        appearances: Times shown in search results
        clicks: Times clicked

    Returns:
        CTR (0-1)
    """
    if appearances == 0:
        return 0.0
    return clicks / appearances


def compute_avg_dwell_time(clicks: int, total_dwell_time_ms: int) -> float:
    """
    Compute average dwell time in seconds.

    Args:
        clicks: Times clicked
        total_dwell_time_ms: Total time spent reading (milliseconds)

    Returns:
        Average dwell time in seconds
    """
    if clicks == 0:
        return 0.0
    return (total_dwell_time_ms / clicks) / 1000


def is_retrieval_successful(
    appearances: int,
    clicks: int,
    total_dwell_time_ms: int,
    ctr_threshold: float = 0.3,
    dwell_threshold: float = 5.0,
) -> bool:
    """
    Heuristic to determine if a memory retrieval was "successful".

    A retrieval is considered successful if:
    - CTR > 30% (clicked frequently when shown), OR
    - Average dwell time > 5 seconds (spent time reading)

    Args:
        appearances: Times shown in search results
        clicks: Times clicked
        total_dwell_time_ms: Total time spent reading (milliseconds)
        ctr_threshold: CTR threshold (default 0.3 = 30%)
        dwell_threshold: Dwell time threshold in seconds (default 5.0)

    Returns:
        True if retrieval is considered successful
    """
    ctr = compute_ctr(appearances, clicks)
    avg_dwell = compute_avg_dwell_time(clicks, total_dwell_time_ms)

    is_successful = (ctr >= ctr_threshold) or (avg_dwell >= dwell_threshold)

    if appearances > 0:  # Only log if memory has been shown
        # logger.debug(
        #     "Evaluated retrieval success",
        #     appearances=appearances,
        #     clicks=clicks,
        #     ctr=round(ctr, 3),
        #     avg_dwell=round(avg_dwell, 1),
        #     successful=is_successful,
        # )
        pass

    return is_successful


def get_decay_diagnostics(
    last_accessed_at: Optional[datetime],
    access_count: int,
    appearances: int,
    clicks: int,
    total_dwell_time_ms: int,
    importance: float,
    decay_score_cached: float,
    now: Optional[datetime] = None,
) -> Dict[str, Any]:
    """
    Get diagnostic information about memory decay state.

    Useful for debugging, monitoring, and user-facing explanations.

    Args:
        last_accessed_at: When memory was last accessed
        access_count: Total number of accesses
        appearances: Times shown in search results
        clicks: Times clicked
        total_dwell_time_ms: Total time spent reading (milliseconds)
        importance: Memory importance (0-1)
        decay_score_cached: Cached decay score
        now: Current time (defaults to datetime.now())

    Returns:
        Dictionary with diagnostic information
    """
    if now is None:
        now = datetime.now(timezone.utc)

    # Recompute fresh decay score
    fresh_decay = compute_decay_score(last_accessed_at, access_count, importance, now)

    # Calculate days since last access
    if last_accessed_at is None:
        days_since = None
    else:
        if last_accessed_at.tzinfo is None:
            last_accessed_at = last_accessed_at.replace(tzinfo=timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        days_since = (now - last_accessed_at).total_seconds() / 86400

    # Calculate recency and frequency components
    recency = math.exp(-days_since / HALF_LIFE_DAYS) if days_since is not None else 0.0
    frequency = min(math.log(1 + access_count) / math.log(FREQUENCY_MAX_COUNT), 1.0)

    # Calculate importance floor
    floor = MIN_IMPORTANCE_FLOOR + (importance * IMPORTANCE_MULTIPLIER)

    # CTR and dwell time
    ctr = compute_ctr(appearances, clicks)
    avg_dwell = compute_avg_dwell_time(clicks, total_dwell_time_ms)
    is_successful = is_retrieval_successful(appearances, clicks, total_dwell_time_ms)

    return {
        "decay_score": {
            "cached": round(decay_score_cached, 3),
            "fresh": round(fresh_decay, 3),
            "cache_stale": abs(fresh_decay - decay_score_cached) > 0.05,
        },
        "components": {
            "recency": round(recency, 3),
            "frequency": round(frequency, 3),
            "importance_floor": round(floor, 3),
        },
        "access_stats": {
            "last_accessed_at": last_accessed_at.isoformat() if last_accessed_at else None,
            "days_since_access": round(days_since, 1) if days_since is not None else None,
            "access_count": access_count,
        },
        "feedback_stats": {
            "appearances": appearances,
            "clicks": clicks,
            "ctr": round(ctr, 3),
            "avg_dwell_time_sec": round(avg_dwell, 1),
            "is_successful": is_successful,
        },
        "hyperparameters": {
            "half_life_days": HALF_LIFE_DAYS,
            "importance_multiplier": IMPORTANCE_MULTIPLIER,
            "decay_weight": DECAY_WEIGHT,
        },
    }
