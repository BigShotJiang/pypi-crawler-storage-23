"""Export implementation for data transfer."""

from __future__ import annotations

import json
import shutil
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

import structlog

from nowledge_graph_server.agent.paths import (
    get_ai_now_home,
    get_sources_home,
    get_working_memory_path,
)
from nowledge_graph_server.database.version_upgrade.db_version_manager import (
    get_db_version,
    CURRENT_DB_VERSION,
)
from nowledge_graph_server.services.data_transfer_models import (
    EXPORT_FORMAT,
    EXPORT_VERSION,
    ExportOptions,
)
from nowledge_graph_server.services.data_transfer_utils import (
    INTERNAL_TABLES,
    _ensure_dir,
    _is_zip_path,
    _node_to_dict,
    _sanitize_table_name,
    _to_jsonable,
)

logger = structlog.get_logger(__name__)


class DataTransferExportMixin:
    def _list_tables(self) -> Tuple[list[str], list[str]]:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")

        node_tables: list[str] = []
        rel_tables: list[str] = []
        result = conn.execute("CALL show_tables() RETURN *")
        try:
            if hasattr(result, "has_next"):
                while result.has_next():
                    row = result.get_next()
                    if not row or len(row) < 3:
                        continue
                    name = str(row[1])
                    table_type = str(row[2]).upper()
                    if name in INTERNAL_TABLES:
                        continue
                    if table_type == "NODE":
                        node_tables.append(name)
                    elif table_type == "REL":
                        rel_tables.append(name)
        finally:
            self._close_result(result)
        return node_tables, rel_tables

    def _write_jsonl(self, path: Path, rows: Iterable[Dict[str, Any]]) -> int:
        count = 0
        with path.open("w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                count += 1
        return count

    def _export_nodes(self, table: str, out_path: Path) -> int:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        query = f"MATCH (n:{table}) RETURN n"
        result = conn.execute(query)

        def _iter_rows():
            if not hasattr(result, "has_next"):
                return
            while result.has_next():
                row = result.get_next()
                if not row:
                    continue
                node = row[0]
                data = _node_to_dict(node)
                if not data and node is not None:
                    data = {"value": node}
                if "embedding" in data:
                    data.pop("embedding", None)
                yield _to_jsonable(data)
        try:
            return self._write_jsonl(out_path, _iter_rows())
        finally:
            self._close_result(result)

    def _export_relationships(self, table: str, out_path: Path) -> int:
        conn = self.db.conn
        if not conn:
            raise RuntimeError("Database connection not available")
        query = f"""
            MATCH (a)-[r:{table}]->(b)
            RETURN a AS start_node, b AS end_node,
                   LABEL(a) AS start_label,
                   LABEL(b) AS end_label,
                   r.*
        """
        result = conn.execute(query)
        column_names: list[str] = []
        if hasattr(result, "get_column_names"):
            try:
                column_names = list(result.get_column_names())
            except Exception:
                column_names = []
        prop_cols: list[str] = []
        if column_names:
            for name in column_names[4:]:
                if name.startswith("r."):
                    prop_cols.append(name.split(".", 1)[1])
                else:
                    prop_cols.append(name)
        else:
            try:
                prop_cols = list(self._get_table_columns(table).keys())
            except Exception:
                prop_cols = []

        def _iter_rows():
            if not hasattr(result, "has_next"):
                return
            while result.has_next():
                row = result.get_next()
                if not row or len(row) < 4:
                    continue
                start_node = row[0]
                end_node = row[1]
                start_label = row[2]
                end_label = row[3]
                props: Dict[str, Any] = {}
                if len(row) > 4:
                    tail = row[4:]
                    if len(tail) == 1 and isinstance(tail[0], dict):
                        props = tail[0]
                    elif prop_cols:
                        for idx, col in enumerate(prop_cols):
                            if len(row) > (4 + idx):
                                props[col] = _to_jsonable(row[4 + idx])
                start_props = _node_to_dict(start_node)
                end_props = _node_to_dict(end_node)
                record = {
                    "start_id": start_props.get("id"),
                    "start_label": str(start_label) if start_label is not None else None,
                    "end_id": end_props.get("id"),
                    "end_label": str(end_label) if end_label is not None else None,
                    "properties": _to_jsonable(props),
                }
                yield record
        try:
            return self._write_jsonl(out_path, _iter_rows())
        finally:
            self._close_result(result)

    def export_data(self, export_path: Path, options: ExportOptions) -> Dict[str, Any]:
        self._ensure_initialized()
        if not self.db.conn:
            raise RuntimeError("Database connection not available")

        conn = self.db.conn
        tx_started = False
        tx_warning: Optional[str] = None
        try:
            conn.execute("BEGIN TRANSACTION READ ONLY;")
            tx_started = True
        except Exception as e:
            tx_warning = (
                "Read-only export transaction could not be started; "
                "export may reflect concurrent writes."
            )
            logger.warning("Failed to start read-only export transaction", error=str(e))

        try:
            export_id = uuid.uuid4().hex[:8]
            exported_at = datetime.now(timezone.utc).isoformat()

            if options.compress:
                if not _is_zip_path(export_path):
                    export_path = export_path.with_suffix(".zip")
                if export_path.exists() and not options.overwrite:
                    raise FileExistsError(f"Export path already exists: {export_path}")
                tmp_dir = Path(tempfile.mkdtemp(prefix="nmem-export-"))
                export_dir = tmp_dir / f"export-{export_id}"
            else:
                export_dir = export_path
                if export_dir.exists():
                    if options.overwrite:
                        shutil.rmtree(export_dir)
                    else:
                        raise FileExistsError(f"Export path already exists: {export_dir}")

            _ensure_dir(export_dir)
            nodes_dir = export_dir / "nodes"
            rels_dir = export_dir / "relationships"
            _ensure_dir(nodes_dir)
            _ensure_dir(rels_dir)

            node_tables, rel_tables = self._list_tables()
            schema_snapshot: Dict[str, Any] = {"nodes": {}, "relationships": {}}
            include_nodes = {
                "Memory": options.include_memories,
                "Thread": options.include_threads,
                "Message": options.include_messages,
                "Entity": options.include_entities,
                "Label": options.include_labels,
                "Source": options.include_sources,
                "Community": options.include_communities,
            }

            def should_include_node(table: str) -> bool:
                if table in include_nodes:
                    return include_nodes[table]
                return True

            counts: Dict[str, Any] = {"nodes": {}, "relationships": {}}
            warnings: list[str] = []
            if tx_warning:
                warnings.append(tx_warning)

            for table in node_tables:
                if should_include_node(table):
                    out_file = nodes_dir / f"{table}.jsonl"
                    try:
                        counts["nodes"][table] = self._export_nodes(table, out_file)
                    except Exception as e:
                        warnings.append(f"Failed to export nodes for {table}: {e}")
                schema_snapshot["nodes"][table] = self._get_table_columns(table)

            core_tables = ["Memory", "Thread", "Message", "Entity", "Label"]
            core_included = [t for t in core_tables if should_include_node(t)]
            if core_included:
                total_core = sum(int(counts["nodes"].get(t, 0) or 0) for t in core_included)
                if total_core == 0:
                    warnings.append(
                        "No core nodes exported (Memory/Thread/Message/Entity/Label). "
                        "This usually means the database is empty or the backend is pointing at a different DB path."
                    )

            if options.include_edges:
                for table in rel_tables:
                    out_file = rels_dir / f"{table}.jsonl"
                    try:
                        counts["relationships"][table] = self._export_relationships(
                            table, out_file
                        )
                    except Exception as e:
                        warnings.append(f"Failed to export relationships for {table}: {e}")
                    schema_snapshot["relationships"][table] = self._get_table_columns(table)

            # Working Memory
            if options.include_working_memory:
                wm_path = get_working_memory_path()
                if wm_path.exists():
                    shutil.copy2(wm_path, export_dir / "working_memory.md")
                else:
                    warnings.append("Working memory not found; skipped working_memory.md")

            if options.include_working_memory_archive:
                archive_root = get_ai_now_home() / "memory-archive"
                if archive_root.exists():
                    shutil.copytree(
                        archive_root,
                        export_dir / "working_memory_archive",
                        dirs_exist_ok=True,
                    )
                else:
                    warnings.append("Working memory archive not found; skipped archive")

            # Sources (Library)
            if options.include_sources and options.include_source_files:
                sources_root = get_sources_home()
                if sources_root.exists():
                    shutil.copytree(
                        sources_root,
                        export_dir / "sources",
                        dirs_exist_ok=True,
                    )
                else:
                    warnings.append("Sources folder not found; skipped sources")

            readme = f"""Nowledge Mem Export

Export ID: {export_id}
Exported At: {exported_at}

Contents:
- manifest.json (format + counts)
- nodes/*.jsonl (graph nodes, one JSON object per line)
- relationships/*.jsonl (graph edges, one JSON object per line)
- working_memory.md (if included)
- working_memory_archive/ (if included)
- sources/ (if included; Library files + .meta.json)

Notes:
- Export/import is experimental. Keep backups until you verify your restore.
- Embeddings are not exported (reindex after import if needed).
- Merge mode preserves existing data and only fills empty fields.
- Overwrite mode replaces existing values and working memory.
- Re-import is idempotent for nodes (primary key) and relationships (start/end/label).
- Source file conflicts are copied with an "-imported-<id>" suffix.
"""
            (export_dir / "README.md").write_text(readme, encoding="utf-8")

            manifest = {
                "format": EXPORT_FORMAT,
                "format_version": EXPORT_VERSION,
                "export_id": export_id,
                "exported_at": exported_at,
                "app_db_version": get_db_version(self.base_client.db_path),
                "current_db_version": CURRENT_DB_VERSION,
                "included": {
                    "memories": options.include_memories,
                    "threads": options.include_threads,
                    "messages": options.include_messages,
                    "entities": options.include_entities,
                    "labels": options.include_labels,
                    "sources": options.include_sources,
                    "communities": options.include_communities,
                    "edges": options.include_edges,
                    "working_memory": options.include_working_memory,
                    "working_memory_archive": options.include_working_memory_archive,
                    "source_files": options.include_source_files,
                },
                "counts": counts,
                "schema_snapshot": schema_snapshot,
                "warnings": warnings,
            }

            (export_dir / "manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

            result = {
                "success": True,
                "export_id": export_id,
                "export_dir": str(export_dir),
                "export_path": str(export_path),
                "manifest_path": str(export_dir / "manifest.json"),
                "counts": counts,
                "warnings": warnings,
            }

            if options.compress:
                zip_path = export_path
                _ensure_dir(zip_path.parent)
                with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                    for file_path in export_dir.rglob("*"):
                        if file_path.is_file():
                            zf.write(
                                file_path,
                                arcname=file_path.relative_to(export_dir),
                            )
                shutil.rmtree(export_dir, ignore_errors=True)
                if export_dir.parent.exists():
                    shutil.rmtree(export_dir.parent, ignore_errors=True)
                result["export_path"] = str(zip_path)
                result["export_dir"] = None

            if tx_started:
                conn.execute("COMMIT;")
            return result
        except Exception:
            if tx_started:
                try:
                    conn.execute("ROLLBACK;")
                except Exception as rollback_err:
                    logger.warning("Failed to rollback export transaction", error=str(rollback_err))
            raise
