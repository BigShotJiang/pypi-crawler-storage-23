"""
Remote LLM extraction service with quality-oriented features.

This module provides high-quality extraction for remote LLMs with:
- Language alignment (input/output language matching)
- Entity deduplication (search before create)
- Temporal factor extraction
- Professional-grade compaction and reflection
- Rate limit handling and concurrency control
"""

import asyncio
import json
from typing import Dict, List, Any, Optional, Tuple
from json_repair import repair_json
import structlog
from datetime import datetime

from nowledge_graph_server.services.base_llm import (
    EntityExtractionResult,
    MemoryDistillationResult,
)
from nowledge_graph_server.services.remote_llm_prompts import (
    REMOTE_DISTILLATION_MEMORY_PROMPT,
    REMOTE_CHUNK_DISTILLATION_PROMPT,
    REMOTE_CONSOLIDATION_PROMPT,
    REMOTE_ENTITY_EXTRACTION_PROMPT,
    REMOTE_ENTITY_REFLECTION_PROMPT,
    REMOTE_ENTITY_DEDUPLICATION_PROMPT,
    REMOTE_BATCH_ENTITY_DEDUPLICATION_PROMPT,
    build_language_instruction,
    REFLECTION_LANGUAGE_PROMPT,
    REFLECTION_TEMPORAL_PROMPT,
    REFLECTION_DESCRIPTION_PROMPT,
)
from nowledge_graph_server.services.extraction_prompts import ENTITY_TYPES, RELATIONSHIP_TYPES
from nowledge_graph_server.services.extraction_utils import LanguageDetector
from nowledge_graph_server.database.entity_repository import EntityRepository

# Import progress logging
try:
    from nowledge_graph_server.utils.progress_logger import log_progress, log_stage
    PROGRESS_AVAILABLE = True
except ImportError:
    PROGRESS_AVAILABLE = False
    def log_progress(*args, **kwargs):
        pass
    def log_stage(*args, **kwargs):
        pass

logger = structlog.get_logger(__name__)


class RateLimitError(Exception):
    """Exception raised when rate limit is hit."""
    pass


class RemoteLLMExtraction:
    """
    High-quality extraction service for remote LLMs.

    Features:
    - Language-aware extraction
    - Entity deduplication via search
    - Temporal information extraction
    - Quality reflection and validation
    - Concurrent extraction with rate limit handling
    """

    def __init__(
        self,
        llm_generate_func,
        parse_json_func,
        entity_repository: Optional[EntityRepository] = None,
        max_concurrent: int = 3,
        retry_attempts: int = 3,
    ):
        """
        Initialize remote extraction service.

        Args:
            llm_generate_func: Function to generate LLM responses
            parse_json_func: Function to parse JSON from LLM responses
            entity_repository: Repository for entity search (optional)
            max_concurrent: Maximum concurrent LLM requests
            retry_attempts: Number of retry attempts for rate limits
        """
        self.llm_generate = llm_generate_func
        self.parse_json = parse_json_func
        self.entity_repository = entity_repository
        self.max_concurrent = max_concurrent
        self.retry_attempts = retry_attempts

        # Concurrency control
        self._semaphore = asyncio.Semaphore(max_concurrent)

    async def _generate_with_retry(
        self,
        prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.3,
        operation_name: Optional[str] = None,
    ) -> str:
        """
        Generate response with retry logic for rate limits.

        Args:
            prompt: The prompt to send
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (0.3 for focused extraction)
            operation_name: Optional operation name for LangFuse tracking

        Returns:
            Generated text

        Raises:
            RateLimitError: If rate limit persists after retries
        """
        last_failure = None

        for attempt in range(self.retry_attempts):
            try:
                async with self._semaphore:
                    response = await self.llm_generate(
                        prompt=prompt,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        operation_name=operation_name,
                    )
                    return response
            except Exception as e:
                last_failure = e
                error_msg = str(e).lower()

                # Check if it's a retryable error (rate limit or service overload)
                retryable_indicators = [
                    'rate limit', 'rate_limit', 'quota', 'too many requests',
                    '429', 'ratelimit',
                    # Service overload (e.g. Gemini 503 "model is overloaded")
                    'overloaded', 'unavailable', '503', 'service unavailable',
                ]
                if any(indicator in error_msg for indicator in retryable_indicators):
                    # Exponential backoff: 2s, 4s, 8s
                    wait_time = 2 ** (attempt + 1)
                    logger.warning(
                        "Retryable LLM error, backing off",
                        attempt=attempt + 1,
                        wait_time=wait_time,
                        error=str(e)
                    )
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    # Not a retryable error, raise immediately
                    raise

        # All retries exhausted
        raise RateLimitError(f"LLM error persisted after {self.retry_attempts} retries") from last_failure

    async def distill_memories_remote(
        self,
        thread_content: str,
        max_memories: int = 3,
        preferred_language: Optional[str] = None,
    ) -> MemoryDistillationResult:
        """
        Distill memories using remote LLM with quality-oriented approach.

        Args:
            thread_content: Full thread content to distill
            max_memories: Maximum number of memories to extract
            preferred_language: User preferred output language ('en', 'zh', or None)

        Returns:
            MemoryDistillationResult with high-quality memories
        """
        try:
            # Detect language for logging
            language = LanguageDetector.detect_language(thread_content)
            logger.info(
                "Starting remote memory distillation",
                language=language,
                preferred_language=preferred_language,
                content_length=len(thread_content),
                max_memories=max_memories,
            )

            # For very long content, use chunking with consolidation
            if len(thread_content) > 8000:
                return await self._distill_with_chunking(thread_content, max_memories, preferred_language=preferred_language)

            # Single-shot distillation for shorter content
            lang_instruction = build_language_instruction(preferred_language)
            prompt = REMOTE_DISTILLATION_MEMORY_PROMPT.replace("{{language_instruction}}", lang_instruction).format(
                thread_content=thread_content
            )

            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=2048,
                temperature=0.3,  # Low temperature for focused extraction
                operation_name="memory_distillation",
            )

            result = self.parse_json(response)

            if not result or "memories" not in result:
                logger.warning("Failed to parse memory distillation result")
                return MemoryDistillationResult(
                    memories=[],
                    entities=[],
                    relationships=[],
                    insights=[],
                    summary="",
                )

            memories = result.get("memories", [])[:max_memories]
            overall_quality = result.get("overall_quality", 0.7)

            logger.info(
                "Memory distillation complete",
                memories_extracted=len(memories),
                quality=overall_quality,
                detected_language=result.get("detected_language", language),
            )

            # Log extracted memories to progress for real-time UI display
            if PROGRESS_AVAILABLE:
                log_progress(
                    operation="thread_distillation",
                    percentage=50,
                    message=f"Extracted {len(memories)} memories",
                    details={
                        "memories": [
                            {
                                "title": m.get("title", "Untitled"),
                                "importance": m.get("importance", 0.5),
                                "tags": m.get("tags", []),
                            }
                            for m in memories
                        ],
                        "quality": overall_quality,
                    },
                )

            return MemoryDistillationResult(
                memories=memories,
                entities=[],  # Entities extracted separately
                relationships=[],  # Relationships extracted separately
                insights=[],  # Not extracted in remote mode
                summary="",  # Not needed for memory distillation
            )

        except Exception as e:
            logger.error(
                "Remote memory distillation failed",
                error=str(e),
                error_type=type(e).__name__,
            )
            return MemoryDistillationResult(
                memories=[],
                entities=[],
                relationships=[],
                insights=[],
                summary="",
            )

    async def _distill_with_chunking(
        self,
        thread_content: str,
        max_memories: int = 3,
        preferred_language: Optional[str] = None,
    ) -> MemoryDistillationResult:
        """
        Distill memories from long content using chunk-then-consolidate approach.

        Args:
            thread_content: Long thread content
            max_memories: Maximum final memories
            preferred_language: User preferred output language ('en', 'zh', or None)

        Returns:
            Consolidated memory distillation result
        """
        logger.info("Using chunked distillation for long content")

        lang_instruction = build_language_instruction(preferred_language)

        # Split into chunks (roughly 4000 chars each with overlap)
        chunk_size = 4000
        overlap = 500
        chunks = []

        for i in range(0, len(thread_content), chunk_size - overlap):
            chunk = thread_content[i:i + chunk_size]
            if len(chunk.strip()) > 100:  # Skip tiny chunks
                chunks.append(chunk)

        logger.info(f"Split content into {len(chunks)} chunks")

        # Extract memories from each chunk concurrently
        chunk_memories = []

        async def extract_chunk(chunk_idx: int, chunk_content: str):
            try:
                prompt = REMOTE_CHUNK_DISTILLATION_PROMPT.replace("{{language_instruction}}", lang_instruction).format(
                    chunk_content=chunk_content
                )
                response = await self._generate_with_retry(
                    prompt=prompt,
                    max_tokens=1024,
                    temperature=0.3,
                    operation_name="chunk_processing",
                )
                result = self.parse_json(response)
                return result.get("memories", []) if result else []
            except Exception as e:
                logger.warning(f"Chunk {chunk_idx} extraction failed", error=str(e))
                return []

        # Process chunks concurrently with semaphore control
        tasks = [extract_chunk(i, chunk) for i, chunk in enumerate(chunks)]
        chunk_results = await asyncio.gather(*tasks, return_exceptions=True)

        # Collect all memories from chunks
        for result in chunk_results:
            if isinstance(result, list):
                chunk_memories.extend(result)

        logger.info(f"Extracted {len(chunk_memories)} memories from chunks")

        if not chunk_memories:
            return MemoryDistillationResult(
                memories=[],
                entities=[],
                relationships=[],
                insights=[],
                summary="",
            )

        # If we have too many, consolidate
        if len(chunk_memories) > max_memories:
            return await self._consolidate_memories(chunk_memories, max_memories, preferred_language=preferred_language)

        return MemoryDistillationResult(
            memories=chunk_memories[:max_memories],
            entities=[],
            relationships=[],
            insights=[],
            summary="",
        )

    async def _consolidate_memories(
        self,
        candidate_memories: List[Dict[str, Any]],
        max_memories: int,
        preferred_language: Optional[str] = None,
    ) -> MemoryDistillationResult:
        """
        Consolidate multiple candidate memories into top few.

        Args:
            candidate_memories: List of candidate memory dicts
            max_memories: Maximum memories to keep
            preferred_language: User preferred output language ('en', 'zh', or None)

        Returns:
            Consolidated memory result
        """
        logger.info(f"Consolidating {len(candidate_memories)} memories to {max_memories}")

        lang_instruction = build_language_instruction(preferred_language)
        prompt = REMOTE_CONSOLIDATION_PROMPT.replace("{{language_instruction}}", lang_instruction).format(
            memory_count=len(candidate_memories),
            memories_json=json.dumps(candidate_memories, indent=2, ensure_ascii=False),
        )

        try:
            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=2048,
                temperature=0.3,
                operation_name="memory_consolidation",
            )

            result = self.parse_json(response)

            if result and "consolidated_memories" in result:
                consolidated = result["consolidated_memories"][:max_memories]
                logger.info(
                    "Consolidation complete",
                    final_count=len(consolidated),
                    reasoning=result.get("consolidation_reasoning", ""),
                )
                return MemoryDistillationResult(
                    memories=consolidated,
                    entities=[],
                    relationships=[],
                    insights=[],
                    summary="",
                )
        except Exception as e:
            logger.warning("Consolidation failed, using top-k by importance", error=str(e))

        # Fallback: sort by importance and take top-k
        sorted_memories = sorted(
            candidate_memories,
            key=lambda m: m.get("importance", 0.5),
            reverse=True,
        )

        return MemoryDistillationResult(
            memories=sorted_memories[:max_memories],
            entities=[],
            relationships=[],
            insights=[],
            summary="",
        )

    async def extract_entities_batch(
        self,
        memories: List[Dict[str, Any]],
        max_memories_per_batch: int = 5,
        max_chars_per_batch: int = 8000,
        preferred_language: Optional[str] = None,
    ) -> EntityExtractionResult:
        """
        Extract entities from ALL memories, chunking if needed.
        Much faster than multiple separate calls.

        Args:
            memories: List of dicts with 'title' and 'content' keys
            max_memories_per_batch: Max memories per LLM call (prevents context overflow)
            max_chars_per_batch: Max combined chars per batch

        Returns:
            Combined EntityExtractionResult with all entities/relationships
        """
        if not memories:
            return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

        # Check if we need to chunk
        total_chars = sum(len(m.get("content", "")) + len(m.get("title", "")) for m in memories)

        if len(memories) > max_memories_per_batch or total_chars > max_chars_per_batch:
            # Split into batches and process in parallel
            batches = []
            current_batch = []
            current_chars = 0

            for m in memories:
                mem_chars = len(m.get("content", "")) + len(m.get("title", ""))
                if current_batch and (len(current_batch) >= max_memories_per_batch or current_chars + mem_chars > max_chars_per_batch):
                    batches.append(current_batch)
                    current_batch = []
                    current_chars = 0
                current_batch.append(m)
                current_chars += mem_chars

            if current_batch:
                batches.append(current_batch)

            logger.info(f"Chunking {len(memories)} memories into {len(batches)} batches for extraction")

            # Process batches in parallel
            async def extract_batch(batch):
                return await self._extract_entities_single_batch(batch, preferred_language=preferred_language)

            results = await asyncio.gather(*[extract_batch(b) for b in batches], return_exceptions=True)

            # Combine results
            all_entities = []
            all_relationships = []
            for result in results:
                if isinstance(result, BaseException):
                    logger.warning(f"Batch extraction failed: {result}")
                    continue
                all_entities.extend(result.entities)
                all_relationships.extend(result.relationships)

            return EntityExtractionResult(
                entities=all_entities,
                relationships=all_relationships,
                confidence=0.7,
            )

        # Single batch - process directly
        return await self._extract_entities_single_batch(memories, preferred_language=preferred_language)

    async def _extract_entities_single_batch(
        self,
        memories: List[Dict[str, Any]],
        preferred_language: Optional[str] = None,
    ) -> EntityExtractionResult:
        """Process a single batch of memories."""
        if not memories:
            return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

        # Combine all memories into one prompt
        combined_content = "\n\n---\n\n".join([
            f"MEMORY {i+1}: {m.get('title', f'Memory {i+1}')}\n{m.get('content', '')}"
            for i, m in enumerate(memories)
        ])

        if preferred_language == "zh":
            lang_instruction = "Write entity descriptions and relationship context in Chinese (中文). Entity names must stay in their original source language."
        elif preferred_language and preferred_language != "en":
            lang_instruction = f"Write entity descriptions and relationship context in the user's preferred language ({preferred_language}). Entity names must stay in their original source language."
        else:
            lang_instruction = "Write entity descriptions and relationship context in the same language as the source text."

        prompt = REMOTE_ENTITY_EXTRACTION_PROMPT.format(
            entity_types=", ".join(ENTITY_TYPES),
            relationship_types=", ".join(RELATIONSHIP_TYPES),
            memory_title=f"Combined ({len(memories)} memories)",
            memory_content=combined_content,
            existing_entities="None (will deduplicate after extraction)",
            language_instruction=lang_instruction,
        )

        logger.info(f"Batch extracting entities from {len(memories)} memories in single call")

        try:
            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=4096,  # Larger for combined output
                temperature=0.3,
                operation_name="batch_entity_extraction",
            )

            result = self.parse_json(response)
            if not result:
                return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

            entities = result.get("entities", [])
            relationships = result.get("relationships", [])
            extraction_quality = result.get("extraction_quality", 0.7)

            # Filter by confidence
            entities = [e for e in entities if e.get("confidence", 0) >= 0.7]
            relationships = [r for r in relationships if r.get("confidence", 0) >= 0.6]

            # Validate relationships reference valid entities
            entity_names = {e["name"] for e in entities}
            valid_relationships = [
                r for r in relationships
                if r.get("source") in entity_names and r.get("target") in entity_names
            ]

            logger.info(
                "Batch extraction complete",
                memories_count=len(memories),
                entities=len(entities),
                relationships=len(valid_relationships),
            )

            return EntityExtractionResult(
                entities=entities,
                relationships=valid_relationships,
                confidence=extraction_quality,
            )

        except Exception as e:
            logger.error("Batch entity extraction failed", error=str(e))
            return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

    async def extract_entities_remote(
        self,
        memory_title: str,
        memory_content: str,
        memory_index: int = 0,
        enable_reflection: bool = True,
        enable_deduplication: bool = True,
        accumulated_entities: Optional[List[Dict[str, Any]]] = None,  # NEW: Track entities from previous chunks
        preferred_language: Optional[str] = None,
    ) -> EntityExtractionResult:
        """
        Extract entities and relationships using remote LLM with quality features.

        Features:
        - Language-aware extraction
        - Temporal information extraction
        - Entity deduplication via search
        - Quality reflection

        Args:
            memory_title: Memory title
            memory_content: Memory content
            memory_index: Memory index for tracking
            enable_reflection: Whether to run quality reflection pass
            enable_deduplication: Whether to check for duplicate entities
            preferred_language: User preferred language for entity descriptions ('zh', 'en', or None)

        Returns:
            EntityExtractionResult with entities, relationships, and temporal info
        """
        try:
            language = LanguageDetector.detect_language(memory_content)
            logger.info(
                "Starting remote entity extraction",
                language=language,
                preferred_language=preferred_language,
                memory_index=memory_index,
                enable_reflection=enable_reflection,
                enable_deduplication=enable_deduplication,
            )

            # Search for existing similar entities if deduplication enabled
            existing_entities_str = ""
            if enable_deduplication and self.entity_repository:
                existing_entities_str = await self._search_existing_entities(
                    memory_title, memory_content
                )

            # Build language instruction for entity descriptions (names always stay in source language)
            if preferred_language == "zh":
                lang_instruction = "Write entity descriptions and relationship context in Chinese (中文). Entity names must stay in their original source language."
            elif preferred_language and preferred_language != "en":
                lang_instruction = f"Write entity descriptions and relationship context in the user's preferred language ({preferred_language}). Entity names must stay in their original source language."
            else:
                lang_instruction = "Write entity descriptions and relationship context in the same language as the source text."

            # Build extraction prompt
            prompt = REMOTE_ENTITY_EXTRACTION_PROMPT.format(
                memory_title=memory_title,
                memory_content=memory_content,
                entity_types=", ".join(ENTITY_TYPES),
                relationship_types=", ".join(RELATIONSHIP_TYPES),
                existing_entities=existing_entities_str or "None found",
                language_instruction=lang_instruction,
            )

            # Extract entities and relationships
            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=3072,
                temperature=0.2,  # Very low temp for structured extraction
                operation_name="entity_extraction",
            )

            result = self.parse_json(response)

            if not result:
                logger.warning("Failed to parse entity extraction result")
                return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

            entities = result.get("entities", [])
            relationships = result.get("relationships", [])
            extraction_quality = result.get("extraction_quality", 0.7)

            logger.info(
                "Initial extraction complete",
                entities_count=len(entities),
                relationships_count=len(relationships),
                quality=extraction_quality,
            )

            # Quality reflection pass (parallel micro-tasks)
            if enable_reflection and (entities or relationships):
                reflected_result = await self.reflect_on_extraction_parallel(entities, relationships)
                if reflected_result:
                    # Apply fixes from parallel reflection
                    entities = reflected_result.get("entities", entities)
                    relationships = reflected_result.get("relationships", relationships)
                    logger.info(
                        "Reflection complete",
                        language_fixes=len(reflected_result.get("language_fixes", [])),
                        temporal_fixes=len(reflected_result.get("temporal_fixes", [])),
                        description_improvements=len(reflected_result.get("description_improvements", [])),
                    )

            # Filter by confidence thresholds
            entities = [e for e in entities if e.get("confidence", 0) >= 0.7]
            relationships = [r for r in relationships if r.get("confidence", 0) >= 0.6]

            # Validate relationships reference valid entities
            entity_names = {e["name"] for e in entities}
            valid_relationships = []
            for rel in relationships:
                if rel.get("source") in entity_names and rel.get("target") in entity_names:
                    valid_relationships.append(rel)
                else:
                    logger.debug(
                        "Filtered invalid relationship",
                        source=rel.get("source"),
                        target=rel.get("target"),
                    )

            # Post-extraction deduplication: Check against both DB and within-task entities
            # IMPORTANT: We mark duplicates but DON'T filter them out. This ensures:
            # 1. Relationships that reference duplicate entities remain valid
            # 2. MENTIONS relationships to new memories are created for existing entities
            # 3. The database layer's create_or_find_entity() handles actual deduplication
            #
            # OPTIMIZATION: Use batch deduplication (1-2 LLM calls) instead of N sequential calls
            if enable_deduplication and entities:
                duplicate_count = 0
                db_duplicates = 0
                within_task_duplicates = 0

                # Step 1: BATCH check against accumulated entities from previous chunks
                if accumulated_entities:
                    accumulated_dicts = [
                        {
                            "id": f"temp_{i}",
                            "name": e["name"],
                            "type": e.get("type", "CONCEPT"),
                            "description": e.get("description", ""),
                        }
                        for i, e in enumerate(accumulated_entities)
                    ]

                    if accumulated_dicts:
                        batch_results = await self.batch_check_entity_duplicates(
                            new_entities=entities,
                            existing_entities=accumulated_dicts,
                        )

                        for i, result in enumerate(batch_results):
                            if result["is_duplicate"]:
                                entities[i]["_is_duplicate"] = True
                                entities[i]["_duplicate_of_id"] = result["matching_id"]
                                entities[i]["_duplicate_of_name"] = result["matching_name"]
                                entities[i]["_duplicate_source"] = "within-task"
                                within_task_duplicates += 1
                                duplicate_count += 1

                # Step 2: For non-duplicates, PARALLEL DB search then BATCH LLM check
                non_duplicate_entities = [e for e in entities if not e.get("_is_duplicate")]

                if non_duplicate_entities and self.entity_repository:
                    entity_repo = self.entity_repository  # Capture for closure

                    # Parallel FTS searches for all non-duplicate entities
                    async def search_entity(entity: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Any]]:
                        search_query = f"{entity['name']} {entity.get('description', '')}"
                        existing = await entity_repo.search_entities_fts(
                            query_text=search_query,
                            limit=5,
                        )
                        return entity, existing

                    search_tasks = [search_entity(e) for e in non_duplicate_entities]
                    search_results = await asyncio.gather(*search_tasks, return_exceptions=True)

                    # Collect all DB candidates for batch check
                    entities_with_candidates = []
                    all_db_candidates = []

                    for result in search_results:
                        if isinstance(result, BaseException):
                            continue
                        entity, existing = result
                        if existing:
                            entities_with_candidates.append(entity)
                            # Flatten candidates with entity index
                            for e in existing:
                                all_db_candidates.append({
                                    "id": e.id,
                                    "name": e.name,
                                    "type": e.entity_type,
                                    "description": e.description,
                                })

                    # Deduplicate candidates list
                    seen_ids = set()
                    unique_candidates = []
                    for c in all_db_candidates:
                        if c["id"] not in seen_ids:
                            seen_ids.add(c["id"])
                            unique_candidates.append(c)

                    if entities_with_candidates and unique_candidates:
                        # Single batch check against all DB candidates
                        batch_results = await self.batch_check_entity_duplicates(
                            new_entities=entities_with_candidates,
                            existing_entities=unique_candidates,
                        )

                        for i, result in enumerate(batch_results):
                            if result["is_duplicate"]:
                                entity = entities_with_candidates[i]
                                entity["_is_duplicate"] = True
                                entity["_duplicate_of_id"] = result["matching_id"]
                                entity["_duplicate_of_name"] = result["matching_name"]
                                entity["_duplicate_source"] = "database"
                                db_duplicates += 1
                                duplicate_count += 1

                # Log duplicate detections
                for entity in entities:
                    if entity.get("_is_duplicate"):
                        logger.info(
                            "Duplicate entity detected (will reuse existing)",
                            new_entity=entity["name"],
                            matches_existing=entity.get("_duplicate_of_name"),
                            source=entity.get("_duplicate_source"),
                            existing_id=entity.get("_duplicate_of_id"),
                        )

                logger.info(
                    "Batch deduplication complete",
                    total_entities=len(entities),
                    duplicates_detected=duplicate_count,
                    db_duplicates=db_duplicates,
                    within_task_duplicates=within_task_duplicates,
                    note="Duplicates kept for relationship/mention preservation",
                )

            # Add extraction metadata
            for entity in entities:
                entity["extraction_method"] = "remote_llm_quality"
                entity["source_memory_index"] = memory_index

            for rel in valid_relationships:
                rel["extraction_method"] = "remote_llm_quality"
                # Ensure temporal_info exists (may be empty string)
                if "temporal_info" not in rel:
                    rel["temporal_info"] = ""

            logger.info(
                "Remote entity extraction complete",
                final_entities=len(entities),
                final_relationships=len(valid_relationships),
                temporal_relationships=sum(1 for r in valid_relationships if r.get("temporal_info")),
            )

            # NOTE: Progress logging moved to local_llm.py orchestration level
            # to avoid non-monotonic progress when running parallel extractions

            return EntityExtractionResult(
                entities=entities,
                relationships=valid_relationships,
                confidence=extraction_quality,
            )

        except Exception as e:
            logger.error(
                "Remote entity extraction failed",
                error=str(e),
                error_type=type(e).__name__,
                exc_info=True,
            )
            return EntityExtractionResult(entities=[], relationships=[], confidence=0.0)

    async def _search_existing_entities(
        self,
        title: str,
        content: str,
    ) -> str:
        """
        Search for existing similar entities to avoid duplicates.

        Args:
            title: Memory title
            content: Memory content

        Returns:
            Formatted string of existing entities
        """
        if not self.entity_repository:
            return ""

        try:
            # Extract key terms for search
            search_text = f"{title} {content}"

            # Search for existing entities
            existing = await self.entity_repository.search_entities_fts(
                query_text=search_text,
                limit=10,
            )

            if not existing:
                return ""

            # Format for prompt
            entities_list = []
            for entity in existing:
                desc = (entity.description or "")[:100]
                entities_list.append(
                    f"- {entity.name} ({entity.entity_type}): {desc}"
                )

            return "\n".join(entities_list)

        except Exception as e:
            logger.warning("Entity search failed", error=str(e))
            return ""

    def reflect_on_extraction_fast(
        self,
        extraction_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Fast programmatic validation - instant, no LLM.
        Filters low-confidence items and validates relationship references.
        """
        entities = extraction_result.get("entities", [])
        relationships = extraction_result.get("relationships", [])
        improvements = []

        # 1. Filter low-confidence entities (< 0.7)
        original_entity_count = len(entities)
        entities = [e for e in entities if e.get("confidence", 0.8) >= 0.7]
        if len(entities) < original_entity_count:
            improvements.append(f"Removed {original_entity_count - len(entities)} low-confidence entities")

        # 2. Build entity name set for relationship validation
        entity_names = {e["name"].lower() for e in entities}

        # 3. Filter relationships: low confidence (< 0.6) OR invalid references
        original_rel_count = len(relationships)
        valid_relationships = []
        for rel in relationships:
            if rel.get("confidence", 0.7) < 0.6:
                continue
            source = rel.get("source", "").lower()
            target = rel.get("target", "").lower()
            if source in entity_names and target in entity_names:
                valid_relationships.append(rel)
        relationships = valid_relationships
        if len(relationships) < original_rel_count:
            improvements.append(f"Removed {original_rel_count - len(relationships)} invalid/low-confidence relationships")

        return {
            "entities": entities,
            "relationships": relationships,
            "improvements_made": improvements,
        }

    async def reflect_on_extraction_llm(
        self,
        extraction_result: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """
        LLM reflection for language/description polish.
        Run in parallel with deduplication.
        """
        try:
            prompt = REMOTE_ENTITY_REFLECTION_PROMPT.format(
                extraction_json=json.dumps(extraction_result, indent=2, ensure_ascii=False)
            )
            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=3072,
                temperature=0.2,
                operation_name="entity_reflection",
            )
            return self.parse_json(response)
        except Exception as e:
            logger.warning("LLM reflection failed", error=str(e))
            return None

    async def reflect_on_extraction_parallel(
        self,
        entities: List[Dict[str, Any]],
        relationships: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Run 3 focused reflection micro-tasks in parallel:
        1. Language consistency check
        2. Temporal accuracy check
        3. Description enhancement

        Returns dict with fixes to apply.
        """
        import asyncio

        async def check_language():
            """Check entity names are in original language"""
            try:
                prompt = REFLECTION_LANGUAGE_PROMPT.format(
                    entities_json=json.dumps(
                        [{"index": i, "name": e["name"], "type": e.get("type"), "description": e.get("description", "")}
                         for i, e in enumerate(entities)],
                        ensure_ascii=False
                    )
                )
                response = await self._generate_with_retry(
                    prompt=prompt, max_tokens=1024, temperature=0.1, operation_name="reflection_language"
                )
                return self.parse_json(response) or {"fixes": []}
            except Exception as e:
                logger.warning("Language reflection failed", error=str(e))
                return {"fixes": []}

        async def check_temporal():
            """Check temporal info accuracy"""
            # Only include entities/relationships with temporal info
            temporal_entities = [
                {"index": i, "name": e["name"], "temporal": e.get("entity_temporal")}
                for i, e in enumerate(entities) if e.get("entity_temporal")
            ]
            temporal_rels = [
                {"index": i, "source": r["source"], "target": r["target"], "temporal": r.get("rel_temporal")}
                for i, r in enumerate(relationships) if r.get("rel_temporal")
            ]
            if not temporal_entities and not temporal_rels:
                return {"entity_fixes": [], "relationship_fixes": []}

            try:
                prompt = REFLECTION_TEMPORAL_PROMPT.format(
                    temporal_json=json.dumps({"entities": temporal_entities, "relationships": temporal_rels}, ensure_ascii=False)
                )
                response = await self._generate_with_retry(
                    prompt=prompt, max_tokens=1024, temperature=0.1, operation_name="reflection_temporal"
                )
                return self.parse_json(response) or {"entity_fixes": [], "relationship_fixes": []}
            except Exception as e:
                logger.warning("Temporal reflection failed", error=str(e))
                return {"entity_fixes": [], "relationship_fixes": []}

        async def enhance_descriptions():
            """Enhance vague descriptions"""
            # Only include entities with short/vague descriptions
            vague_entities = [
                {"index": i, "name": e["name"], "description": e.get("description", "")}
                for i, e in enumerate(entities)
                if e.get("description") and len(e.get("description", "")) < 30
            ]
            if not vague_entities:
                return {"improvements": []}

            try:
                prompt = REFLECTION_DESCRIPTION_PROMPT.format(
                    entities_json=json.dumps(vague_entities, ensure_ascii=False)
                )
                response = await self._generate_with_retry(
                    prompt=prompt, max_tokens=1024, temperature=0.2, operation_name="reflection_description"
                )
                return self.parse_json(response) or {"improvements": []}
            except Exception as e:
                logger.warning("Description reflection failed", error=str(e))
                return {"improvements": []}

        # Run all 3 in parallel
        lang_result, temporal_result, desc_result = await asyncio.gather(
            check_language(), check_temporal(), enhance_descriptions(),
            return_exceptions=True
        )

        # Handle exceptions
        if isinstance(lang_result, BaseException):
            lang_result = {"fixes": []}
        if isinstance(temporal_result, BaseException):
            temporal_result = {"entity_fixes": [], "relationship_fixes": []}
        if isinstance(desc_result, BaseException):
            desc_result = {"improvements": []}

        # Type guards for pyright
        lang_dict = lang_result if isinstance(lang_result, dict) else {"fixes": []}
        temporal_dict = temporal_result if isinstance(temporal_result, dict) else {"entity_fixes": [], "relationship_fixes": []}
        desc_dict = desc_result if isinstance(desc_result, dict) else {"improvements": []}

        return {
            "language_fixes": lang_dict.get("fixes", []),
            "temporal_entity_fixes": temporal_dict.get("entity_fixes", []),
            "temporal_rel_fixes": temporal_dict.get("relationship_fixes", []),
            "description_improvements": desc_dict.get("improvements", []),
        }

    async def check_entity_duplicate(
        self,
        entity_name: str,
        entity_type: str,
        entity_description: str,
        existing_entities: List[Dict[str, Any]],
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Check if an entity is a duplicate using LLM-powered deduplication.

        Args:
            entity_name: Name of new entity
            entity_type: Type of new entity
            entity_description: Description of new entity
            existing_entities: List of existing entity dicts with id, name, type, description

        Returns:
            Tuple of (is_duplicate, matching_id, matching_name)
        """
        if not existing_entities:
            return False, None, None

        try:
            prompt = REMOTE_ENTITY_DEDUPLICATION_PROMPT.format(
                new_entity_name=entity_name,
                new_entity_type=entity_type,
                new_entity_description=entity_description,
                existing_entities_json=json.dumps(existing_entities, indent=2, ensure_ascii=False),
            )

            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=512,
                temperature=0.1,  # Very low for consistent decisions
                operation_name="entity_deduplication",
            )

            result = self.parse_json(response)

            if result:
                is_duplicate = result.get("is_duplicate", False)
                matching_id = result.get("matching_entity_id")
                matching_name = result.get("matching_entity_name")
                confidence = result.get("confidence", 0.0)

                logger.debug(
                    "Deduplication check",
                    entity=entity_name,
                    is_duplicate=is_duplicate,
                    confidence=confidence,
                    reasoning=result.get("reasoning", ""),
                )

                # Only mark as duplicate if confidence is high
                if is_duplicate and confidence >= 0.75:
                    return True, matching_id, matching_name

            return False, None, None

        except Exception as e:
            logger.warning("Deduplication check failed", error=str(e))
            return False, None, None

    async def batch_check_entity_duplicates(
        self,
        new_entities: List[Dict[str, Any]],
        existing_entities: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Batch check multiple entities for duplicates in a single LLM call.
        Much faster than individual checks for remote LLM.

        Args:
            new_entities: List of new entity dicts with name, type, description
            existing_entities: List of existing entity dicts with id, name, type, description

        Returns:
            List of result dicts with is_duplicate, matching_id, matching_name per entity
        """
        if not new_entities:
            return []

        if not existing_entities:
            # No existing entities to check against
            return [
                {"is_duplicate": False, "matching_id": None, "matching_name": None}
                for _ in new_entities
            ]

        try:
            # Format entities for prompt
            new_entities_formatted = [
                {
                    "index": i,
                    "name": e.get("name", ""),
                    "type": e.get("type", "CONCEPT"),
                    "description": e.get("description", ""),
                }
                for i, e in enumerate(new_entities)
            ]

            prompt = REMOTE_BATCH_ENTITY_DEDUPLICATION_PROMPT.format(
                new_entities_json=json.dumps(new_entities_formatted, indent=2, ensure_ascii=False),
                existing_entities_json=json.dumps(existing_entities, indent=2, ensure_ascii=False),
            )

            response = await self._generate_with_retry(
                prompt=prompt,
                max_tokens=2048,  # Larger for batch results
                temperature=0.1,
                operation_name="batch_entity_deduplication",
            )

            result = self.parse_json(response)
            results_list = []

            if result and "results" in result:
                # Map results back to entities
                result_map = {r.get("new_entity_index", i): r for i, r in enumerate(result["results"])}

                for i in range(len(new_entities)):
                    r = result_map.get(i, {})
                    is_dup = r.get("is_duplicate", False)
                    conf = r.get("confidence", 0.0)

                    # Only mark as duplicate if confidence is high
                    if is_dup and conf >= 0.75:
                        results_list.append({
                            "is_duplicate": True,
                            "matching_id": r.get("matching_entity_id"),
                            "matching_name": r.get("matching_entity_name"),
                        })
                    else:
                        results_list.append({
                            "is_duplicate": False,
                            "matching_id": None,
                            "matching_name": None,
                        })

                logger.info(
                    "Batch deduplication complete",
                    total_entities=len(new_entities),
                    duplicates_found=sum(1 for r in results_list if r["is_duplicate"]),
                )
                return results_list

            # Fallback: no duplicates if parsing failed
            return [
                {"is_duplicate": False, "matching_id": None, "matching_name": None}
                for _ in new_entities
            ]

        except Exception as e:
            logger.warning("Batch deduplication failed", error=str(e))
            return [
                {"is_duplicate": False, "matching_id": None, "matching_name": None}
                for _ in new_entities
            ]
