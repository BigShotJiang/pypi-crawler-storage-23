"""
Prompts for different levels of entity extraction with multilingual support.
"""

# Entity type ontology (open-domain, flexible)
ENTITY_TYPES = [
    # People & Organizations
    "PERSON",
    "ORGANIZATION",
    "TEAM",
    "COMMUNITY",
    # Places & Locations
    "LOCATION",
    "PLACE",
    "REGION",
    "FACILITY",
    # Things & Objects
    "PRODUCT",
    "TOOL",
    "DEVICE",
    "MATERIAL",
    "RESOURCE",
    # Concepts & Ideas
    "CONCEPT",
    "METHOD",
    "TECHNIQUE",
    "THEORY",
    "PRINCIPLE",
    # Events & Activities
    "EVENT",
    "ACTIVITY",
    "PROCESS",
    "PROJECT",
    # Information & Content
    "DOCUMENT",
    "PUBLICATION",
    "MEDIA",
    "DATASET",
    # Abstract & Other
    "SYSTEM",
    "SERVICE",
    "PLATFORM",
    "STANDARD",
    "TERM",
]

# Relationship types (general purpose)
RELATIONSHIP_TYPES = [
    # Action relationships
    "USES",
    "CREATES",
    "PRODUCES",
    "AFFECTS",
    "MODIFIES",
    # Structural relationships
    "CONTAINS",
    "PART_OF",
    "BELONGS_TO",
    "CONSISTS_OF",
    # Association relationships
    "RELATED_TO",
    "WORKS_WITH",
    "CONNECTED_TO",
    "ASSOCIATED_WITH",
    # Comparison relationships
    "SIMILAR_TO",
    "DIFFERENT_FROM",
    "REPLACES",
    "ALTERNATIVE_TO",
    # Dependency relationships
    "REQUIRES",
    "DEPENDS_ON",
    "ENABLES",
    "SUPPORTS",
    # Descriptive relationships
    "DESCRIBES",
    "EXPLAINS",
    "REPRESENTS",
    "IMPLEMENTS",
]

# Level 1: Swift (current one-shot approach)
ENTITY_EXTRACTION_PROMPT_LEVEL1 = """Extract entities and relationships from text. Return only valid JSON.

RULES:
- Extract meaningful entities: tools, technologies, concepts, people, organizations, methods, etc.
- Keep entity names in their ORIGINAL LANGUAGE (don't translate)
- Use English for type and relation fields
- For relationships, both source and target must be extracted entities
- Include context showing how entities connect

EXAMPLE:
Text: "Sarah uses Docker containers with PostgreSQL database for her microservices architecture at Netflix."
JSON: {{"entities":[{{"name":"Sarah","type":"PERSON","description":"Developer/engineer","confidence":0.9}},{{"name":"Docker","type":"SOFTWARE_TOOL","description":"Container platform","confidence":0.9}},{{"name":"PostgreSQL","type":"DATABASE","description":"Relational database","confidence":0.9}},{{"name":"microservices architecture","type":"CONCEPT","description":"Distributed system design","confidence":0.8}},{{"name":"Netflix","type":"ORGANIZATION","description":"Technology company","confidence":0.8}}],"relationships":[{{"source":"Sarah","target":"Docker","relation":"USES","context":"Sarah uses Docker containers","confidence":0.9}},{{"source":"Docker","target":"PostgreSQL","relation":"WORKS_WITH","context":"Docker containers with PostgreSQL database","confidence":0.8}},{{"source":"microservices architecture","target":"PostgreSQL","relation":"USES","context":"PostgreSQL database for her microservices architecture","confidence":0.7}},{{"source":"Sarah","target":"Netflix","relation":"WORKS_AT","context":"at Netflix","confidence":0.8}}],"confidence":0.85}}

Text: {memory_text}
JSON:"""

# Level 2: Guided (few-shot with multilingual examples)
ENTITY_EXTRACTION_PROMPT_LEVEL2_CANDIDATES = """Identify the key entities (important nouns) in this text.

An entity is:
- A person, place, organization, or group
- An object, tool, product, or system  
- A concept, method, idea, or term
- An event, activity, or process
- Anything important enough to remember

Keep the ORIGINAL LANGUAGE - don't translate!

EXAMPLES:

Text: "Marie Curie discovered radium and polonium at the University of Paris."
Entities: Marie Curie, radium, polonium, University of Paris

Text: "昨日、田中さんと新宿のカフェでプロジェクトの進捗について話し合った。"
Entities: 田中さん, 新宿, カフェ, プロジェクト, 進捗

Text: "The agile methodology emphasizes iterative development and customer feedback."
Entities: agile methodology, iterative development, customer feedback

Text: {text}
Entities:"""

ENTITY_EXTRACTION_PROMPT_LEVEL2_TYPING = """Classify these entities into types.

Think: What kind of thing is each entity?
- Is it a person, place, or organization?
- Is it a physical object or tool?
- Is it an abstract concept or idea?
- Is it an event or activity?

Keep descriptions in the SAME LANGUAGE as the entity name.

EXAMPLES:

Entities: Marie Curie, University of Paris, radium
JSON: {{"entities":[{{"name":"Marie Curie","type":"PERSON","description":"Scientist who discovered radium","confidence":0.9}},{{"name":"University of Paris","type":"ORGANIZATION","description":"Educational institution","confidence":0.9}},{{"name":"radium","type":"MATERIAL","description":"Radioactive element","confidence":0.9}}]}}

Entities: 田中さん, 新宿, プロジェクト
JSON: {{"entities":[{{"name":"田中さん","type":"PERSON","description":"プロジェクトメンバー","confidence":0.8}},{{"name":"新宿","type":"LOCATION","description":"東京の地区","confidence":0.9}},{{"name":"プロジェクト","type":"PROJECT","description":"進行中の作業","confidence":0.8}}]}}

Entities: {entities}
JSON:"""

ENTITY_EXTRACTION_PROMPT_LEVEL2_RELATIONS = """Find how these entities are connected in the text.

Look for:
- Who does what? (person USES tool)
- What contains what? (place CONTAINS thing)
- What affects what? (event AFFECTS outcome)
- What is related? (concept RELATED_TO idea)

Include a short quote showing the connection.

ENTITIES:
{entities}

TEXT:
{text}

EXAMPLES:

Text: "Marie Curie discovered radium at the University of Paris"
Entities: Marie Curie, radium, University of Paris
JSON: {{"relationships":[{{"source":"Marie Curie","target":"radium","relation":"CREATES","context":"Marie Curie discovered radium","confidence":0.9}},{{"source":"Marie Curie","target":"University of Paris","relation":"WORKS_WITH","context":"at the University of Paris","confidence":0.8}}]}}

Text: "田中さんが新宿でプロジェクトについて話し合った"
Entities: 田中さん, 新宿, プロジェクト
JSON: {{"relationships":[{{"source":"田中さん","target":"プロジェクト","relation":"WORKS_WITH","context":"プロジェクトについて話し合った","confidence":0.8}},{{"source":"田中さん","target":"新宿","relation":"RELATED_TO","context":"田中さんが新宿で","confidence":0.7}}]}}

Now find relationships:
JSON:"""

# Consolidation prompt for Level 2
ENTITY_EXTRACTION_PROMPT_LEVEL2_CONSOLIDATE = """Review and consolidate these extraction results.

CURRENT RESULTS:
Entities: {entities_count} extracted
Relationships: {relationships_count} extracted
Top entities: {top_entities}

QUALITY METRICS:
- Coverage: {coverage} (domain keywords covered)
- Connectivity: {connectivity} (entities in relationships)
- Type diversity: {type_diversity}

TASK: If quality is good, return as-is. If not, suggest 2-3 most important missing entities or relationships.

RULES:
- Only suggest additions if they significantly improve coverage
- Keep original language for entity names
- Focus on domain-specific technical entities

TEXT EXCERPT:
{text_excerpt}

JSON:"""
