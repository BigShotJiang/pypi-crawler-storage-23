"""
LiteLLM model listing functions.

Functions for discovering and listing available models from providers.
"""

import os
from typing import Dict, Any, Optional, TYPE_CHECKING, List

import structlog

from .env import scoped_provider_env
from .utils import normalize_api_base, get_models_dev_provider_model_ids

if TYPE_CHECKING:
    from nowledge_graph_server.services.remote_llm_config import RemoteLLMConfig

logger = structlog.get_logger(__name__)

_KEY_REQUIRED_PROVIDERS = {
    "openai",
    "anthropic",
    "xai",
    "deepseek",
    "minimax",
    "zai",
    "moonshot",
    "openrouter",
    "gemini",
    "azure",
}


async def list_models_for_provider(
    provider: str,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    api_version: Optional[str] = None,
) -> Dict[str, Any]:
    """List available models for a provider.
    
    Args:
        provider: Provider name (e.g., 'openai', 'anthropic')
        api_key: API key for the provider
        api_base: API base URL
        api_version: API version (for Azure)
        
    Returns:
        Dict with success status and list of models
    """
    from litellm.utils import get_valid_models
    provider = (provider or "").strip()
    provider_lower = provider.lower()

    # GitHub Copilot: return model list from models.dev
    if provider_lower == "github_copilot":
        return await _list_github_copilot_models(provider)

    # OpenAI Codex: return hardcoded model list (same as regular OpenAI)
    if provider_lower == "openai_codex":
        return await _list_openai_codex_models(provider)

    # OpenAI-Compatible: cannot list models
    if provider_lower == "openai_compatible":
        return {"success": True, "provider": provider, "models": []}

    # Ollama: query endpoint directly
    if provider_lower == "ollama":
        return await _list_ollama_models(api_base, provider)

    if provider_lower in _KEY_REQUIRED_PROVIDERS and not (api_key or "").strip():
        return {
            "success": False,
            "provider": provider,
            "models": [],
            "error": (
                f"{provider} API key is not configured. "
                "Set provider credentials in Settings > Providers and save."
            ),
        }

    # OpenRouter: query directly with headers
    if provider_lower == "openrouter":
        return await _list_openrouter_models(api_key, api_base, provider)

    # xAI: query directly with safe base normalization
    if provider_lower == "xai":
        return await _list_xai_models(api_key, api_base, provider)

    # Gemini: ensure env vars are set
    if provider_lower == "gemini":
        return await _list_gemini_models(api_key, api_base, provider)

    # models.dev-backed providers
    if provider_lower in {"minimax", "zai", "moonshot", "deepseek"}:
        return await _list_models_dev_openai_compatible_models(provider_lower, api_base)

    # Generic LiteLLM helper
    with scoped_provider_env(provider, api_key, api_base, api_version):
        models = get_valid_models(
            check_provider_endpoint=True, custom_llm_provider=provider
        ) or []
        return {"success": True, "provider": provider, "models": models}


async def _list_github_copilot_models(provider: str) -> Dict[str, Any]:
    """List GitHub Copilot models from models.dev."""
    try:
        ids = await get_models_dev_provider_model_ids("github-copilot")
    except Exception as e:
        ids = []
        logger.warning("Failed to fetch models.dev Copilot list; falling back", error=str(e))

    models = [f"github_copilot/{m}" for m in ids] if ids else [
        "github_copilot/gpt-5-mini",
        "github_copilot/gpt-5-nano",
        "github_copilot/gpt-5.1-codex",
        "github_copilot/text-embedding-3-small",
    ]
    return {
        "success": True,
        "provider": provider,
        "models": models,
        "note": "Model list from models.dev (may include models not enabled on your Copilot plan).",
    }


async def _list_openai_codex_models(provider: str) -> Dict[str, Any]:
    """List OpenAI Codex models.

    Codex uses the same models as OpenAI via ChatGPT Plus/Pro subscription.
    Returns a curated list of models available to Codex CLI users.
    Models sourced from: https://developers.openai.com/codex/models/
    """
    # Prefer live OpenAI model catalog from models.dev.
    # We keep only Codex and GPT-5 family IDs, since ChatGPT Codex backend rejects
    # older families such as gpt-4o/gpt-4-turbo for this flow.
    try:
        ids = await get_models_dev_provider_model_ids("openai")
    except Exception as e:
        ids = []
        logger.warning("Failed to fetch models.dev OpenAI list; using fallback", error=str(e))

    filtered_ids = [
        m
        for m in ids
        if isinstance(m, str)
        and m
        and (
            "codex" in m.lower()
            or m.lower().startswith("gpt-5")
        )
    ]

    # Rank codex-first for coding workflows, then general GPT-5 models.
    codex_ids = [m for m in filtered_ids if "codex" in m.lower()]
    general_ids = [m for m in filtered_ids if "codex" not in m.lower()]
    ordered_ids = list(dict.fromkeys(codex_ids + general_ids))

    fallback_ids = [
        "gpt-5.3-codex",
        "gpt-5.3-codex-spark",
        "gpt-5.2-codex",
        "gpt-5.1-codex-max",
        "gpt-5.1-codex-mini",
        "gpt-5.1-codex",
        "codex-mini-latest",
        "gpt-5-codex",
        "gpt-5.2-pro",
        "gpt-5.2-chat-latest",
        "gpt-5.2",
        "gpt-5.1-chat-latest",
        "gpt-5.1",
        "gpt-5-chat-latest",
        "gpt-5-pro",
        "gpt-5-mini",
        "gpt-5-nano",
        "gpt-5",
    ]
    model_ids = ordered_ids or fallback_ids
    models = [f"openai_codex/{m}" for m in model_ids]
    return {
        "success": True,
        "provider": provider,
        "models": models,
        "note": "Model list derived from models.dev OpenAI catalog (Codex + GPT-5 family). Availability depends on your subscription plan.",
    }


async def _list_models_dev_openai_compatible_models(
    provider: str, api_base: Optional[str]
) -> Dict[str, Any]:
    """List models for OpenAI-compatible providers from models.dev.

    This keeps model pickers current for providers whose model catalogs change often.
    """
    provider_ids: List[str]
    fallback_ids: List[str]
    base = (api_base or "").lower()

    if provider == "minimax":
        # models.dev exposes both global and China endpoints for MiniMax.
        # Pick the provider catalog based on configured api_base when available.
        if "minimaxi.com" in base:
            provider_ids = ["minimax-cn"]
        else:
            provider_ids = ["minimax"]
        fallback_ids = [
            "MiniMax-M2",
            "MiniMax-M2.5",
            "MiniMax-M2.5-highspeed",
            "MiniMax-M2.1",
        ]
    elif provider == "zai":
        # Z.AI has a coding-plan catalog under a dedicated API path.
        if "/api/coding/paas/" in base:
            provider_ids = ["zai-coding-plan"]
            fallback_ids = [
                "glm-5",
                "glm-4.7",
                "glm-4.7-flashx",
                "glm-4.7-flash",
                "glm-4.6",
                "glm-4.6v",
                "glm-4.5",
                "glm-4.5-air",
                "glm-4.5-flash",
                "glm-4.5v",
            ]
        else:
            provider_ids = ["zai"]
            fallback_ids = [
                "glm-5",
                "glm-4.7",
                "glm-4.7-flash",
                "glm-4.6",
                "glm-4.6v",
                "glm-4.5",
                "glm-4.5-air",
                "glm-4.5-flash",
                "glm-4.5v",
            ]
    elif provider == "deepseek":
        provider_ids = ["deepseek"]
        fallback_ids = [
            "deepseek-chat",
        ]
    else:  # moonshot
        # Respect region-specific base URLs while still supporting unknown/custom bases.
        if "api.kimi.com/coding" in base:
            provider_ids = ["kimi-for-coding"]
        elif "moonshot.cn" in base:
            provider_ids = ["moonshotai-cn"]
        elif "moonshot.ai" in base:
            provider_ids = ["moonshotai"]
        else:
            # Unknown/custom base URL: include both global and CN catalogs.
            provider_ids = ["moonshotai", "moonshotai-cn", "kimi-for-coding"]
        fallback_ids = [
            "kimi-k2-thinking-turbo",
            "kimi-k2-thinking",
            "kimi-k2-0711-preview",
            "k2p5",
            "kimi-k2-0905-preview",
            "kimi-k2.5",
            "kimi-k2-turbo-preview",
        ]

    model_ids: List[str] = []
    for provider_id in provider_ids:
        try:
            fetched = await get_models_dev_provider_model_ids(provider_id)
            model_ids.extend(fetched)
        except Exception as e:
            logger.warning(
                "Failed to fetch models.dev provider list",
                provider=provider,
                models_dev_provider_id=provider_id,
                error=str(e),
            )

    # Preserve order while deduplicating.
    deduped_ids = list(dict.fromkeys([m for m in model_ids if isinstance(m, str) and m.strip()]))
    ids = deduped_ids or fallback_ids
    if provider == "deepseek":
        # `deepseek-reasoner` does not support tool-calling, so we keep it out of
        # guided model pickers used by AI-Now/agents.
        ids = [m for m in ids if m.strip().lower() != "deepseek-reasoner"]
        if not ids:
            ids = fallback_ids
    models = [f"{provider}/{m}" for m in ids]

    return {
        "success": True,
        "provider": provider,
        "models": models,
        "note": (
            "Model list from models.dev (fallback list used if network fetch fails). "
            "For DeepSeek, `deepseek-reasoner` is excluded because it does not support tool use."
            if provider == "deepseek"
            else "Model list from models.dev (fallback list used if network fetch fails)."
        ),
    }


async def _list_ollama_models(api_base: Optional[str], provider: str) -> Dict[str, Any]:
    """List Ollama models via /api/tags endpoint."""
    import httpx
    
    base = (api_base or "http://localhost:11434").rstrip("/")
    # Normalize base URL - remove /api suffix if present, we'll add /api/tags
    if base.endswith("/api"):
        base = base[:-4]
    tags_url = base + "/api/tags"
    
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(tags_url)
            resp.raise_for_status()
            data = resp.json()
            # Ollama returns {"models": [...]} where each model has a "name" field
            model_list = data.get("models") if isinstance(data, dict) else data
            models = [
                item.get("name", "").strip()
                for item in (model_list or [])
                if isinstance(item, dict) and item.get("name")
            ]
        return {"success": True, "provider": provider, "models": models}
    except Exception as e:
        logger.warning(f"Failed to list Ollama models: {e}")
        return {"success": False, "provider": provider, "models": [], "error": str(e)}


async def _list_openrouter_models(
    api_key: Optional[str],
    api_base: Optional[str],
    provider: str,
) -> Dict[str, Any]:
    """List OpenRouter models via /models endpoint."""
    import httpx
    
    base = (api_base or "https://openrouter.ai/api/v1").rstrip("/")
    headers = {
        "Authorization": f"Bearer {api_key}",
        "HTTP-Referer": "https://mem.nowledge.co",
        "X-Title": "Nowledge Mem",
    }
    
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{base}/models", headers=headers)
            resp.raise_for_status()
            data = resp.json()
            items = []
            if isinstance(data, dict):
                items = data.get("data") or data.get("models") or []
            models = [
                str(item.get("id") or item.get("name") or "").strip()
                for item in items
                if isinstance(item, dict)
            ]
            return {"success": True, "provider": provider, "models": models}
    except Exception as e:
        logger.warning(f"Failed to list OpenRouter models: {e}")
        return {"success": False, "provider": provider, "models": [], "error": str(e)}


async def _list_xai_models(
    api_key: Optional[str],
    api_base: Optional[str],
    provider: str,
) -> Dict[str, Any]:
    """List xAI models via /v1/models, avoiding /v1/v1 path duplication."""
    import httpx

    if not (api_key or "").strip():
        return {
            "success": False,
            "provider": provider,
            "models": [],
            "error": "xAI API key is required to fetch models",
        }

    base = (api_base or "https://api.x.ai").rstrip("/")
    # UI default commonly stores https://api.x.ai/v1; xAI model endpoint is /v1/models.
    if base.endswith("/v1"):
        base = base[:-3]

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                f"{base}/v1/models",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            resp.raise_for_status()
            data = resp.json()
            items = data.get("data") if isinstance(data, dict) else []
            models = [
                f"xai/{mid}"
                for mid in [
                    str(item.get("id") or "").strip()
                    for item in items
                    if isinstance(item, dict)
                ]
                if mid
            ]
            return {"success": True, "provider": provider, "models": models}
    except Exception as e:
        logger.warning(f"Failed to list xAI models: {e}")
        return {"success": False, "provider": provider, "models": [], "error": str(e)}


async def _list_gemini_models(
    api_key: Optional[str],
    api_base: Optional[str],
    provider: str,
) -> Dict[str, Any]:
    """List Gemini models."""
    from litellm.utils import get_valid_models
    
    with scoped_provider_env("gemini", api_key, api_base):
        try:
            models = get_valid_models(
                check_provider_endpoint=True, custom_llm_provider="gemini"
            ) or []
            return {"success": True, "provider": provider, "models": models}
        except Exception as e:
            logger.warning(f"Failed to list Gemini models: {e}")
            return {"success": False, "provider": provider, "models": [], "error": str(e)}


async def list_models_with_config(
    config: "RemoteLLMConfig",
    provider: Optional[str] = None,
    config_manager: Optional[Any] = None,
) -> Dict[str, Any]:
    """List models using explicit config overrides.
    
    Args:
        config: RemoteLLMConfig with override values
        provider: Optional provider name (defaults to config.provider)
        config_manager: Optional config manager for resolving persisted credentials
        
    Returns:
        Dict with success status and list of models
    """
    target_provider = provider or config.provider
    provider_type = (getattr(config, "provider_type", None) or "").strip() or target_provider

    # Resolve effective credentials
    persisted = None
    if config_manager:
        try:
            all_cfgs = config_manager.get_all_provider_configs()
            persisted = all_cfgs.get(target_provider)
        except Exception:
            pass

    def eff(attr: str) -> Optional[str]:
        val = getattr(config, attr, None)
        if val:
            return val
        if persisted:
            return getattr(persisted, attr, None)
        return None

    return await list_models_for_provider(
        provider=provider_type,
        api_key=eff("api_key"),
        api_base=eff("api_base"),
        api_version=eff("api_version"),
    )
