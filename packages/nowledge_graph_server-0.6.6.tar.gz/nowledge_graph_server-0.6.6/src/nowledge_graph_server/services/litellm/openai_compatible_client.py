"""Helpers for OpenAI-compatible client construction.

This module centralizes how we build OpenAI clients for custom endpoints.
For local/private API bases we bypass environment proxies to avoid routing
failures where curl works but in-process HTTP clients go through a proxy.
"""

from __future__ import annotations

import ipaddress
from typing import Any, Optional, Tuple
from urllib.parse import urlparse

import httpx


def _extract_hostname(api_base: Optional[str]) -> Optional[str]:
    if not api_base:
        return None
    try:
        parsed = urlparse(api_base)
        if parsed.hostname:
            return parsed.hostname
    except Exception:
        return None
    return None


def should_bypass_proxy_for_api_base(api_base: Optional[str]) -> bool:
    """Return True when endpoint is local/private and should skip env proxies."""
    host = _extract_hostname(api_base)
    if not host:
        return False

    host_lower = host.strip().lower()
    if host_lower in {"localhost", "127.0.0.1", "::1"}:
        return True

    try:
        ip = ipaddress.ip_address(host_lower)
        return bool(ip.is_loopback or ip.is_private or ip.is_link_local)
    except ValueError:
        # Non-IP hostnames keep default proxy behavior.
        return False

def build_openai_compatible_client(
    openai_client_class: Any,
    *,
    api_key: str,
    api_base: Optional[str],
    max_retries: int = 0,
) -> Tuple[Any, bool]:
    """Create OpenAI client; bypass proxies for local/private endpoints."""
    bypass_proxy = should_bypass_proxy_for_api_base(api_base)
    kwargs: dict[str, Any] = {
        "api_key": api_key,
        "base_url": api_base,
        "max_retries": max_retries,
    }

    if bypass_proxy:
        # Avoid HTTP(S)_PROXY/ALL_PROXY for LAN/local hosts.
        kwargs["http_client"] = httpx.Client(trust_env=False)

    client = openai_client_class(**kwargs)
    return client, bypass_proxy
