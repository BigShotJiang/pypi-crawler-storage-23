"""
LiteLLM provider validation functions.

Provider-specific connection testing and validation logic.
"""

import os
from typing import Dict, Any, Optional

import structlog

from .env import (
    scoped_provider_env,
    setup_github_copilot_env,
    check_copilot_authenticated,
    setup_openai_codex_env,
    check_codex_authenticated,
)
from .utils import (
    normalize_api_base,
    get_models_dev_provider_model_ids,
    is_minimax_anthropic_base,
)
from .openai_compatible_client import build_openai_compatible_client

logger = structlog.get_logger(__name__)


def _normalize_model_for_validation(
    provider_type: str,
    api_base: Optional[str],
    model: Optional[str],
) -> str:
    """Normalize model id for LiteLLM key/endpoint validation.

    `litellm.utils.check_valid_key()` only accepts `(model, api_key)` and does
    not receive `custom_llm_provider`, so provider-prefixed model ids are
    required for non-OpenAI families (e.g. `moonshot/kimi-k2-thinking`).
    """
    model_to_check = (model or "").strip()
    if not model_to_check:
        return model_to_check

    # Keep validation routing behavior aligned with runtime routing behavior.
    if provider_type == "anthropic" and is_kimi_coding_base(api_base):
        # Kimi coding-plan models may be stored as "moonshot/<id>" in config.
        if model_to_check.startswith("moonshot/"):
            model_to_check = model_to_check[len("moonshot/") :]
    if provider_type == "anthropic":
        # MiniMax Anthropic-compatible endpoints may carry "minimax/<id>".
        if model_to_check.startswith("minimax/"):
            model_to_check = model_to_check[len("minimax/") :]

    needs_prefix = provider_type in {
        "openrouter",
        "anthropic",
        "openai",
        "xai",
        "deepseek",
        "gemini",
        "minimax",
        "zai",
        "moonshot",
        "github_copilot",
        "openai_codex",
    }
    if needs_prefix and not model_to_check.startswith(f"{provider_type}/"):
        return f"{provider_type}/{model_to_check}"
    return model_to_check


async def validate_openrouter(
    api_key: Optional[str],
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate OpenRouter connection.
    
    Tries LiteLLM helper first, then falls back to direct HTTP.
    """
    import httpx
    from litellm.utils import get_valid_models
    
    with scoped_provider_env("openrouter", api_key, api_base):
        # Try LiteLLM helper first
        try:
            models = get_valid_models(
                check_provider_endpoint=True, custom_llm_provider="openrouter"
            ) or []
            if models:
                picked = model or str(models[0])
                return {
                    "success": True,
                    "message": "Connection with key successful",
                    "provider": provider_id,
                    "model": picked,
                }
        except Exception as e:
            logger.warning(f"Failed to get OpenRouter models via LiteLLM: {e}")

        # Fallback: direct HTTP call
        try:
            base = (api_base or "https://openrouter.ai/api/v1").rstrip("/")
            headers = {
                "Authorization": f"Bearer {api_key}",
                "HTTP-Referer": "https://mem.nowledge.co",
                "X-Title": "Nowledge Mem",
            }
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(f"{base}/models", headers=headers)
                resp.raise_for_status()
                data = resp.json()
                items = data.get("data") if isinstance(data, dict) else []
                models = [
                    str(m.get("id") or m.get("name") or "").strip()
                    for m in (items or [])
                    if isinstance(m, dict)
                ]
                picked = model or (models[0] if models else "")
                return {
                    "success": True,
                    "message": "Connection with key successful",
                    "provider": provider_id,
                    "model": picked,
                }
        except Exception as http_err:
            logger.error(f"Failed to get OpenRouter models via HTTP: {http_err}")
            return {
                "success": False,
                "message": f"OpenRouter validation failed: {http_err}",
            }


async def validate_xai(
    api_key: Optional[str],
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate xAI connection using direct HTTP."""
    import httpx
    
    try:
        base = (api_base or "https://api.x.ai/v1").rstrip("/")
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{base}/models", headers=headers)
            resp.raise_for_status()
            data = resp.json()
            items = data.get("data") if isinstance(data, dict) else []
            models = [
                str(m.get("id") or m.get("name") or "").strip()
                for m in (items or [])
                if isinstance(m, dict)
            ]
            picked = model or (f"xai/{models[0]}" if models else "xai/grok-2-latest")
            if not picked.startswith("xai/"):
                picked = f"xai/{picked}"
            return {
                "success": True,
                "message": "Connection with key successful",
                "provider": provider_id,
                "model": picked,
            }
    except Exception as e:
        logger.warning(f"xAI direct validation failed: {e}")
        return {
            "success": False,
            "message": f"xAI validation failed: {e}",
        }


async def validate_anthropic(
    api_key: Optional[str],
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate Anthropic connection using minimal LiteLLM call."""
    import litellm
    
    with scoped_provider_env("anthropic", api_key, api_base):
        model_to_check = model or "claude-3-5-haiku-20241022"
        if isinstance(model_to_check, str) and not model_to_check.startswith("anthropic/"):
            model_to_check = f"anthropic/{model_to_check}"

        params: Dict[str, Any] = {
            "model": model_to_check,
            "api_key": api_key or "",
            "max_tokens": 1,
        }
        if api_base:
            params["api_base"] = normalize_api_base("anthropic", api_base) or api_base
        # MiniMax Anthropic-compatible endpoint now expects Bearer auth.
        if api_key and is_minimax_anthropic_base(api_base):
            params["extra_headers"] = {"Authorization": f"Bearer {api_key}"}

        try:
            response = await litellm.acompletion(
                messages=[{"role": "user", "content": "ping"}],
                **params,
            )
            ok = bool(response and getattr(response, "choices", None))
            return {
                "success": ok,
                "message": "Connection with key successful" if ok else "Validation failed",
                "provider": provider_id,
                "model": model_to_check,
            }
        except Exception as e:
            logger.warning("Anthropic validation failed", error=str(e))
            return {
                "success": False,
                "message": f"Anthropic validation failed: {e}",
            }


async def validate_gemini(
    api_key: Optional[str],
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate Gemini (Google AI Studio) connection."""
    import litellm
    
    with scoped_provider_env("gemini", api_key, api_base):
        model_to_check = model or "gemini-flash-latest"
        if isinstance(model_to_check, str) and not model_to_check.startswith("gemini/"):
            model_to_check = f"gemini/{model_to_check}"

        normalized_base = normalize_api_base("gemini", api_base)

        params: Dict[str, Any] = {
            "model": model_to_check,
            "api_key": api_key or "",
            "max_tokens": 8,
        }
        if normalized_base:
            params["api_base"] = normalized_base

        try:
            response = await litellm.acompletion(
                messages=[{"role": "user", "content": "ping"}],
                **params,
            )
            ok = bool(response and getattr(response, "choices", None))
            return {
                "success": ok,
                "message": "Connection with key successful" if ok else "Validation failed",
                "provider": provider_id,
                "model": model_to_check,
            }
        except Exception as e:
            return {"success": False, "message": f"Gemini validation failed: {e}"}


async def validate_ollama(
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate Ollama connection by pinging /api/version."""
    import httpx
    
    try:
        base = (api_base or "http://localhost:11434").rstrip("/")
        url = base + "/api/version"
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(url)
            resp.raise_for_status()
        return {
            "success": True,
            "message": "Connection with key successful",
            "provider": provider_id,
            "model": model or "",
        }
    except Exception as e:
        logger.warning(f"Ollama direct ping failed: {e}")
        return {
            "success": False,
            "message": f"Ollama validation failed: {e}",
        }


async def validate_github_copilot(
    config_path_parent: Any,
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate GitHub Copilot authentication using OAuth device flow."""
    import json as _json
    import time as _time
    import httpx
    
    from litellm.llms.github_copilot.authenticator import (
        Authenticator,
        GITHUB_ACCESS_TOKEN_URL,
        GITHUB_CLIENT_ID,
    )
    
    token_dir = setup_github_copilot_env(config_path_parent)
    if not token_dir:
        return {
            "success": False,
            "message": "Failed to set up Copilot token directory",
            "provider": provider_id,
        }

    model_to_check = model or "github_copilot/gpt-4"
    if isinstance(model_to_check, str) and not model_to_check.startswith("github_copilot/"):
        model_to_check = f"github_copilot/{model_to_check}"

    # If already authenticated, return success quickly
    if check_copilot_authenticated(token_dir):
        return {
            "success": True,
            "message": "Authenticated",
            "provider": provider_id,
            "model": model_to_check,
        }

    # Device code flow
    device_state_path = os.path.join(token_dir, "device-code.json")
    logger.info(
        "Copilot auth: using token directory",
        token_dir=str(token_dir),
        device_state_path=str(device_state_path),
    )

    def _load_state():
        try:
            with open(device_state_path, "r", encoding="utf-8") as f:
                state = _json.load(f) or {}
            if not state.get("created_at"):
                return None
            created_at = float(state.get("created_at") or 0.0)
            expires_in = float(state.get("expires_in") or 900.0)
            if created_at and expires_in and (_time.time() - created_at) > expires_in:
                return None
            return state
        except Exception:
            return None

    def _save_state(info: Dict[str, Any]) -> None:
        info["created_at"] = _time.time()
        try:
            with open(device_state_path, "w", encoding="utf-8") as f:
                _json.dump(info, f)
        except Exception as write_err:
            logger.warning(
                "Failed to persist Copilot device-code state",
                error=str(write_err),
                path=device_state_path,
            )

    def _clear_state() -> None:
        try:
            os.remove(device_state_path)
        except Exception:
            pass

    state = _load_state()

    # If we have a device_code, poll once to see if user finished login
    if state and state.get("device_code"):
        auth = Authenticator()
        headers = auth._get_github_headers()
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(
                    GITHUB_ACCESS_TOKEN_URL,
                    headers=headers,
                    json={
                        "client_id": GITHUB_CLIENT_ID,
                        "device_code": state["device_code"],
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                )
                resp.raise_for_status()
                data = resp.json() if resp.content else {}
        except Exception as e:
            return {
                "success": False,
                "message": f"GitHub Copilot authentication failed: {e}",
                "provider": provider_id,
            }

        if isinstance(data, dict) and data.get("access_token"):
            # Persist token and succeed
            access_token_path = os.path.join(
                token_dir,
                os.environ.get("GITHUB_COPILOT_ACCESS_TOKEN_FILE", "access-token"),
            )
            with open(access_token_path, "w", encoding="utf-8") as f:
                f.write(str(data["access_token"]).strip())
            _clear_state()
            return {
                "success": True,
                "message": "Authenticated",
                "provider": provider_id,
                "model": model_to_check,
            }

        # Handle device-flow errors
        if isinstance(data, dict):
            err = str(data.get("error") or "").strip().lower()
            url = state.get("verification_uri") or "https://github.com/login/device"
            code = state.get("user_code") or "(see logs)"

            if err == "authorization_pending":
                return {
                    "success": False,
                    "message": f"GitHub Copilot authentication required. Visit {url} and enter code {code}, then click Authenticate again.",
                    "provider": provider_id,
                    "model": model_to_check,
                }
            if err == "slow_down":
                interval = state.get("interval") or 5
                try:
                    interval = int(interval)
                except Exception:
                    interval = 5
                wait_s = max(10, interval + 5)
                return {
                    "success": False,
                    "message": f"GitHub Copilot authentication in progress (please wait ~{wait_s}s). Visit {url} and enter code {code} if you haven't already.",
                    "provider": provider_id,
                    "model": model_to_check,
                }
            if err in ("expired_token", "bad_verification_code"):
                _clear_state()
                state = None
            if err == "access_denied":
                _clear_state()
                return {
                    "success": False,
                    "message": f"GitHub denied the Copilot device authorization. Double-check you approved the request at {url} with the same GitHub account and that the account has Copilot access, then click Authenticate again.",
                    "provider": provider_id,
                    "model": model_to_check,
                }

    # No valid state or expired: start new device flow
    auth = Authenticator()
    info = auth._get_device_code()
    _save_state(info)

    url = info.get("verification_uri") or "https://github.com/login/device"
    code = info.get("user_code") or "(see logs)"
    logger.info(
        "Copilot auth: issued new device code",
        user_code=code,
        verification_uri=url,
    )
    return {
        "success": False,
        "message": f"GitHub Copilot authentication required. Visit {url} and enter code {code}, then click Authenticate again.",
        "provider": provider_id,
        "model": model_to_check,
    }


async def validate_openai_compatible(
    api_key: Optional[str],
    api_base: Optional[str],
    model: Optional[str],
    provider_id: str,
    openai_client_class: Any,
) -> Dict[str, Any]:
    """Validate OpenAI-compatible endpoint."""
    import asyncio
    
    if openai_client_class is None:
        return {"success": False, "message": "OpenAI client not installed"}
    
    try:
        effective_api_base = api_base or os.environ.get("OPENAI_BASE_URL")
        api_key_value = (api_key or os.environ.get("OPENAI_API_KEY", ""))

        async def _attempt_once(target_base: Optional[str]):
            client, bypass_proxy = build_openai_compatible_client(
                openai_client_class,
                api_key=api_key_value,
                api_base=target_base,
                max_retries=0,
            )
            try:
                logger.info(
                    "OpenAI-compatible validation request",
                    provider=provider_id,
                    model=(model or ""),
                    api_base=target_base,
                    bypass_proxy=bypass_proxy,
                )
                return await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: client.chat.completions.create(
                        model=(model or ""),
                        messages=[{"role": "user", "content": "ping"}],
                        max_tokens=8,
                    ),
                )
            finally:
                client.close()

        resp = await _attempt_once(effective_api_base)
        ok = bool(resp and getattr(resp, "choices", None))
        return {
            "success": ok,
            "message": "Connection with key successful" if ok else "Validation failed",
            "provider": provider_id,
            "model": model or "",
        }
    except Exception as e:
        logger.warning(
            "OpenAI-compatible validation failed",
            provider=provider_id,
            model=(model or ""),
            api_base=(api_base or os.environ.get("OPENAI_BASE_URL")),
            error=str(e),
        )
        return {
            "success": False,
            "message": f"OpenAI-compatible validation failed: {e}",
        }


async def validate_generic(
    provider_type: str,
    api_key: Optional[str],
    api_base: Optional[str],
    api_version: Optional[str],
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Generic validation using LiteLLM helpers."""
    from litellm.utils import get_valid_models, check_valid_key

    from .constants import DEFAULT_MODELS

    with scoped_provider_env(provider_type, api_key, api_base, api_version):
        model_to_check = _normalize_model_for_validation(provider_type, api_base, model)

        # If model not provided, try to discover or use defaults
        if not model_to_check:
            try:
                discovered = get_valid_models(
                    check_provider_endpoint=True, custom_llm_provider=provider_type
                ) or []
            except Exception as e:
                logger.warning(f"Failed to discover models for {provider_type}: {e}")
                discovered = []

            if provider_type == "openrouter":
                preferred = [
                    "openrouter/google/palm-2-chat-bison",
                    "openrouter/anthropic/claude-3-haiku",
                    "openrouter/openai/gpt-4o-mini",
                ]
                pick = next((m for m in preferred if m in discovered), None)
                model_to_check = pick or "openrouter/google/palm-2-chat-bison"
            else:
                model_to_check = (
                    discovered[0] if discovered else None
                ) or DEFAULT_MODELS.get(provider_type, "openai/gpt-4o")

        # Validate using LiteLLM helper
        is_valid = False
        try:
            logger.info(
                "LiteLLM test_connection validation prepared",
                provider=provider_type,
                model=model_to_check,
            )
            is_valid = bool(
                check_valid_key(model=model_to_check, api_key=(api_key or ""))
            )
        except Exception as e:
            logger.warning(f"Failed to validate key for {provider_type}: {e}")
            try:
                _ = get_valid_models(
                    check_provider_endpoint=True, custom_llm_provider=provider_type
                )
                is_valid = True
            except Exception as e2:
                logger.error(f"Failed to validate models for {provider_type}: {e2}")
                is_valid = False

        if is_valid:
            return {
                "success": True,
                "message": "Connection with key successful",
                "provider": provider_id,
                "model": model_to_check,
            }
        return {"success": False, "message": "Key or endpoint validation failed"}


async def validate_openai_codex(
    config_path_parent: Any,
    model: Optional[str],
    provider_id: str,
) -> Dict[str, Any]:
    """Validate OpenAI Codex authentication using OAuth device flow.

    Uses the 3-step device code flow matching the official OpenAI Codex CLI
    and OpenCode implementation:
      1. POST /api/accounts/deviceauth/usercode → {device_auth_id, user_code, interval}
      2. POST /api/accounts/deviceauth/token (poll) → {authorization_code, code_verifier}
      3. POST /oauth/token (exchange) → {access_token, refresh_token, id_token, expires_in}

    Reference: https://github.com/anomalyco/opencode/blob/main/packages/opencode/src/plugin/codex.ts
    """
    import json as _json
    import time as _time
    import httpx

    from .constants import (
        OPENAI_CODEX_CLIENT_ID,
        OPENAI_CODEX_DEVICE_CODE_URL,
        OPENAI_CODEX_TOKEN_POLL_URL,
        OPENAI_CODEX_TOKEN_EXCHANGE_URL,
        OPENAI_CODEX_VERIFICATION_URL,
        OPENAI_CODEX_DEVICE_AUTH_CALLBACK,
    )

    token_dir = setup_openai_codex_env(config_path_parent)
    if not token_dir:
        return {
            "success": False,
            "message": "Failed to set up Codex token directory",
            "provider": provider_id,
        }

    model_to_check = model or "openai_codex/gpt-5.2-codex"
    if isinstance(model_to_check, str) and not model_to_check.startswith("openai_codex/"):
        model_to_check = f"openai_codex/{model_to_check}"

    # If already authenticated, return success quickly
    if check_codex_authenticated(token_dir):
        return {
            "success": True,
            "message": "Authenticated",
            "provider": provider_id,
            "model": model_to_check,
        }

    # Device code flow state management
    device_state_path = os.path.join(token_dir, "device-code.json")
    logger.info(
        "Codex auth: using token directory",
        token_dir=str(token_dir),
        device_state_path=str(device_state_path),
    )

    _req_headers = {
        "Content-Type": "application/json",
        "User-Agent": "Nowledge/1.0",
    }

    def _load_state():
        try:
            with open(device_state_path, "r", encoding="utf-8") as f:
                state = _json.load(f) or {}
            if not state.get("created_at"):
                return None
            created_at = float(state.get("created_at") or 0.0)
            # Device codes expire in 15 minutes
            if created_at and (_time.time() - created_at) > 900:
                return None
            return state
        except Exception:
            return None

    def _save_state(info: Dict[str, Any]) -> None:
        info["created_at"] = _time.time()
        try:
            with open(device_state_path, "w", encoding="utf-8") as f:
                _json.dump(info, f)
        except Exception as write_err:
            logger.warning(
                "Failed to persist Codex device-code state",
                error=str(write_err),
                path=device_state_path,
            )

    def _clear_state() -> None:
        try:
            os.remove(device_state_path)
        except Exception:
            pass

    async def _exchange_token(authorization_code: str, code_verifier: str) -> Optional[Dict[str, Any]]:
        """Step 3: Exchange authorization_code for access/refresh tokens."""
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    OPENAI_CODEX_TOKEN_EXCHANGE_URL,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    data={
                        "grant_type": "authorization_code",
                        "code": authorization_code,
                        "redirect_uri": OPENAI_CODEX_DEVICE_AUTH_CALLBACK,
                        "client_id": OPENAI_CODEX_CLIENT_ID,
                        "code_verifier": code_verifier,
                    },
                )
                if resp.status_code == 200:
                    return resp.json()
                logger.warning(
                    "Codex token exchange failed",
                    status=resp.status_code,
                    body=resp.text[:500],
                )
        except Exception as e:
            logger.warning("Codex token exchange error", error=str(e))
        return None

    state = _load_state()

    # If we have a pending device_auth_id, poll once to see if user finished login
    if state and state.get("device_auth_id"):
        url = OPENAI_CODEX_VERIFICATION_URL
        code = state.get("user_code") or "(see logs)"

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    OPENAI_CODEX_TOKEN_POLL_URL,
                    headers=_req_headers,
                    json={
                        "device_auth_id": state["device_auth_id"],
                        "user_code": state.get("user_code", ""),
                    },
                )
        except Exception as e:
            return {
                "success": False,
                "message": f"ChatGPT Subscription authentication failed: {e}",
                "provider": provider_id,
            }

        # Success: got authorization_code + code_verifier
        if resp.status_code == 200:
            poll_data = resp.json()
            auth_code = poll_data.get("authorization_code")
            verifier = poll_data.get("code_verifier")

            if auth_code and verifier:
                # Step 3: Exchange for tokens
                tokens = await _exchange_token(auth_code, verifier)
                if tokens and tokens.get("access_token"):
                    from .env import _extract_codex_account_id, _get_jwt_expires_at

                    access_token_path = os.path.join(
                        token_dir,
                        os.environ.get("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json"),
                    )
                    new_access_token = str(tokens["access_token"]).strip()
                    new_id_token = str(tokens.get("id_token", "")).strip()

                    # Prefer JWT exp claim (matches LiteLLM), fall back to expires_in
                    expires_at = _get_jwt_expires_at(new_access_token)
                    if expires_at is None:
                        expires_in = tokens.get("expires_in") or 3600
                        expires_at = int(_time.time() + expires_in)

                    account_id = _extract_codex_account_id(new_id_token) if new_id_token else None

                    token_data = {
                        "access_token": new_access_token,
                        "refresh_token": str(tokens.get("refresh_token", "")).strip(),
                        "id_token": new_id_token,
                        "expires_at": expires_at,
                        "account_id": account_id,
                        "api_base": "https://chatgpt.com/backend-api/codex",
                    }
                    with open(access_token_path, "w", encoding="utf-8") as f:
                        _json.dump(token_data, f)
                    _clear_state()
                    return {
                        "success": True,
                        "message": "Authenticated",
                        "provider": provider_id,
                        "model": model_to_check,
                    }
                else:
                    _clear_state()
                    return {
                        "success": False,
                        "message": "Token exchange failed. Please try authenticating again.",
                        "provider": provider_id,
                    }

        # 403/404 = user hasn't authorized yet (keep polling)
        if resp.status_code in (403, 404):
            return {
                "success": False,
                "message": f"ChatGPT Subscription authentication required. Visit {url} and enter code {code}, then click Authenticate again.",
                "provider": provider_id,
                "model": model_to_check,
            }

        # Other errors: clear state and start fresh
        _clear_state()
        state = None

    # No valid state or expired: start new device flow (Step 1)
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                OPENAI_CODEX_DEVICE_CODE_URL,
                headers=_req_headers,
                json={
                    "client_id": OPENAI_CODEX_CLIENT_ID,
                },
            )
            resp.raise_for_status()
            info = resp.json()
    except Exception as e:
        return {
            "success": False,
            "message": f"Failed to initiate Codex device flow: {e}",
            "provider": provider_id,
        }

    _save_state(info)

    url = OPENAI_CODEX_VERIFICATION_URL
    code = info.get("user_code") or "(see logs)"
    logger.info(
        "Codex auth: issued new device code",
        user_code=code,
        device_auth_id=info.get("device_auth_id", ""),
    )
    return {
        "success": False,
        "message": f"ChatGPT Subscription authentication required. Visit {url} and enter code {code}, then click Authenticate again.",
        "provider": provider_id,
        "model": model_to_check,
    }
