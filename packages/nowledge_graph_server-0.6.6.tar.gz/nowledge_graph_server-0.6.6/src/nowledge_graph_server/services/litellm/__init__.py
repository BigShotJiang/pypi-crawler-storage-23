"""
LiteLLM integration package.

This package provides a modular LiteLLM provider with support for 100+ LLM backends.

Modules:
    - constants: Shared constants and configuration values
    - utils: Utility functions for API normalization and LangFuse setup
    - env: Environment variable management for provider isolation
    - validation: Provider-specific connection validation
    - models: Model discovery and listing functions
    - provider: Main LiteLLMProvider class
"""

from .provider import LiteLLMProvider, get_openai_client_class
from .utils import (
    normalize_api_base,
    get_models_dev_provider_model_ids,
    setup_langfuse_otel,
    infer_operation_name,
    detect_json_requirement,
)
from .env import (
    scoped_provider_env,
    setup_github_copilot_env,
    check_copilot_authenticated,
    get_copilot_ide_headers,
)
from .validation import (
    validate_openrouter,
    validate_xai,
    validate_anthropic,
    validate_gemini,
    validate_ollama,
    validate_github_copilot,
    validate_openai_compatible,
    validate_generic,
)
from .models import (
    list_models_for_provider,
    list_models_with_config,
)
from .api import (
    test_connection,
    list_models,
    test_connection_with_config,
)
from .constants import (
    PROVIDER_ENV_KEYS,
    ALL_PROVIDER_ENV_KEYS,
    JSON_FORMAT_PROVIDERS,
    DEFAULT_MODELS,
)

__all__ = [
    # Main provider
    "LiteLLMProvider",
    "get_openai_client_class",
    # Utils
    "normalize_api_base",
    "get_models_dev_provider_model_ids",
    "setup_langfuse_otel",
    "infer_operation_name",
    "detect_json_requirement",
    # Environment
    "scoped_provider_env",
    "setup_github_copilot_env",
    "check_copilot_authenticated",
    "get_copilot_ide_headers",
    # Validation
    "validate_openrouter",
    "validate_xai",
    "validate_anthropic",
    "validate_gemini",
    "validate_ollama",
    "validate_github_copilot",
    "validate_openai_compatible",
    "validate_generic",
    # Models
    "list_models_for_provider",
    "list_models_with_config",
    # API (high-level functions)
    "test_connection",
    "list_models",
    "test_connection_with_config",
    # Constants
    "PROVIDER_ENV_KEYS",
    "ALL_PROVIDER_ENV_KEYS",
    "JSON_FORMAT_PROVIDERS",
    "DEFAULT_MODELS",
]
