"""
LiteLLM constants and shared state.
"""

from typing import Dict, Any, List

# Environment variable keys for each provider
PROVIDER_ENV_KEYS: Dict[str, List[str]] = {
    "openai": ["OPENAI_API_KEY", "OPENAI_BASE_URL"],
    "anthropic": ["ANTHROPIC_API_KEY", "ANTHROPIC_API_BASE"],
    "xai": ["XAI_API_KEY", "XAI_API_BASE"],
    "deepseek": ["DEEPSEEK_API_KEY", "DEEPSEEK_API_BASE"],
    "minimax": ["MINIMAX_API_KEY", "MINIMAX_API_BASE"],
    "zai": ["ZAI_API_KEY", "ZAI_API_BASE"],
    "moonshot": ["MOONSHOT_API_KEY", "MOONSHOT_API_BASE"],
    "azure": ["AZURE_API_KEY", "AZURE_API_BASE", "AZURE_API_VERSION", "AZURE_API_TYPE"],
    "openrouter": ["OPENROUTER_API_KEY", "OPENROUTER_API_BASE"],
    "gemini": ["GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_BASE"],
    "github_copilot": [
        "GITHUB_COPILOT_TOKEN_DIR",
        "GITHUB_COPILOT_ACCESS_TOKEN_FILE",
        "GITHUB_COPILOT_API_KEY_FILE",
    ],
    "openai_codex": [
        "OPENAI_CODEX_TOKEN_DIR",
        "OPENAI_CODEX_ACCESS_TOKEN_FILE",
        "OPENAI_CODEX_REFRESH_TOKEN_FILE",
        "CHATGPT_TOKEN_DIR",
        "CHATGPT_AUTH_FILE",
    ],
}

# All provider env keys for clearing
ALL_PROVIDER_ENV_KEYS: List[str] = [
    "OPENAI_API_KEY",
    "OPENAI_BASE_URL",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_API_BASE",
    "XAI_API_KEY",
    "XAI_API_BASE",
    "DEEPSEEK_API_KEY",
    "DEEPSEEK_API_BASE",
    "MINIMAX_API_KEY",
    "MINIMAX_API_BASE",
    "ZAI_API_KEY",
    "ZAI_API_BASE",
    "MOONSHOT_API_KEY",
    "MOONSHOT_API_BASE",
    "AZURE_API_KEY",
    "AZURE_API_BASE",
    "AZURE_API_VERSION",
    "AZURE_API_TYPE",
    "OPENROUTER_API_KEY",
    "OPENROUTER_API_BASE",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "GEMINI_API_BASE",
    "GITHUB_COPILOT_TOKEN_DIR",
    "GITHUB_COPILOT_ACCESS_TOKEN_FILE",
    "GITHUB_COPILOT_API_KEY_FILE",
    "OPENAI_CODEX_TOKEN_DIR",
    "OPENAI_CODEX_ACCESS_TOKEN_FILE",
    "OPENAI_CODEX_REFRESH_TOKEN_FILE",
    "CHATGPT_TOKEN_DIR",
    "CHATGPT_AUTH_FILE",
]

# Providers supporting native JSON response_format
JSON_FORMAT_PROVIDERS: List[str] = [
    "openai",
    # Note: openai_codex (ChatGPT Subscription) is NOT listed here because
    # LiteLLM's native chatgpt provider strips response_format automatically.
    "anthropic",
    "xai",
    "deepseek",
    "azure",
    "groq",
    "ollama",
]

# Default models by provider
DEFAULT_MODELS: Dict[str, str] = {
    "openai": "openai/gpt-4o",
    "anthropic": "anthropic/claude-3-sonnet-20240229",
    "xai": "xai/grok-2-latest",
    "deepseek": "deepseek/deepseek-chat",
    "minimax": "minimax/MiniMax-M2.1",
    "zai": "zai/glm-4.7",
    "moonshot": "moonshot/kimi-k2-thinking",
    "azure": "azure/gpt-4o",
    "gemini": "gemini/gemini-flash-latest",
    "github_copilot": "github_copilot/gpt-4",
    "openai_codex": "openai_codex/gpt-5.2-codex",
}

# models.dev cache for GitHub Copilot
_MODELS_DEV_CACHE: Dict[str, Any] = {"ts": 0.0, "data": None}

# OpenAI Codex OAuth configuration
# Reference: https://github.com/anomalyco/opencode/blob/main/packages/opencode/src/plugin/codex.ts
OPENAI_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
OPENAI_CODEX_AUTH_BASE_URL = "https://auth.openai.com"
OPENAI_CODEX_DEVICE_CODE_URL = "https://auth.openai.com/api/accounts/deviceauth/usercode"
OPENAI_CODEX_TOKEN_POLL_URL = "https://auth.openai.com/api/accounts/deviceauth/token"
OPENAI_CODEX_TOKEN_EXCHANGE_URL = "https://auth.openai.com/oauth/token"
OPENAI_CODEX_REFRESH_TOKEN_URL = "https://auth.openai.com/oauth/token"
OPENAI_CODEX_VERIFICATION_URL = "https://auth.openai.com/codex/device"
OPENAI_CODEX_DEVICE_AUTH_CALLBACK = "https://auth.openai.com/deviceauth/callback"
OPENAI_CODEX_API_BASE_URL = "https://chatgpt.com/backend-api/codex"
