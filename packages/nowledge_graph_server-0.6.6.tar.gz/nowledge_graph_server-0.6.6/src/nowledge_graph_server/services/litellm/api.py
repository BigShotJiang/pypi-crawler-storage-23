"""
High-level API functions for LiteLLM operations.

These functions provide a simple interface for connection testing and model listing,
coordinating between the validation and models modules.
"""

from typing import Dict, Any, Optional, TYPE_CHECKING

import structlog

from nowledge_graph_server.services.remote_llm_config import get_config_manager

from .provider import get_openai_client_class
from .utils import resolve_provider_for_api_base
from .validation import (
    validate_openrouter,
    validate_xai,
    validate_anthropic,
    validate_gemini,
    validate_ollama,
    validate_github_copilot,
    validate_openai_codex,
    validate_openai_compatible,
    validate_generic,
)
from .models import list_models_for_provider, list_models_with_config as _list_models_with_config

if TYPE_CHECKING:
    from nowledge_graph_server.services.remote_llm_config import RemoteLLMConfig

logger = structlog.get_logger(__name__)


async def test_connection() -> Dict[str, Any]:
    """Test connection to the configured remote LLM.

    Returns:
        Dict with status and message
    """
    try:
        config_manager = get_config_manager()
        config = config_manager.get_config()

        if not config.enabled:
            return {"success": False, "message": "Remote LLM is not enabled"}

        return await test_connection_with_config(config)

    except Exception as e:
        logger.error("Connection test failed", error=str(e))
        return {"success": False, "message": f"Connection failed: {str(e)}"}


async def list_models(provider: Optional[str] = None) -> Dict[str, Any]:
    """List available models for a provider.

    Args:
        provider: Provider name. If None, uses configured provider.

    Returns:
        Dict with available models
    """
    config_manager = get_config_manager()
    config = config_manager.get_config()

    target_provider = provider or config.provider

    # Resolve provider_type + provider-scoped credentials
    provider_type = target_provider
    target_cfg = None
    try:
        cfgs = config_manager.get_all_provider_configs()
        if target_provider in cfgs:
            target_cfg = cfgs[target_provider]
            provider_type = (
                getattr(target_cfg, "provider_type", None) or target_provider
            ).strip()
    except Exception:
        pass

    api_key = (getattr(target_cfg, "api_key", None) if target_cfg else None) or (
        config.api_key if target_provider == config.provider else None
    )
    api_base = (getattr(target_cfg, "api_base", None) if target_cfg else None) or (
        config.api_base if target_provider == config.provider else None
    )
    api_version = (
        (getattr(target_cfg, "api_version", None) if target_cfg else None)
        or (config.api_version if target_provider == config.provider else None)
    )

    return await list_models_for_provider(
        provider=provider_type,
        api_key=api_key,
        api_base=api_base,
        api_version=api_version,
    )


async def test_connection_with_config(override: "RemoteLLMConfig") -> Dict[str, Any]:
    """Test connection using explicit config overrides (does not persist).
    
    Args:
        override: RemoteLLMConfig with override values
        
    Returns:
        Dict with connection test results
    """
    config = override
    config_manager = get_config_manager()

    # Pull provider-specific persisted config
    try:
        all_cfgs = config_manager.get_all_provider_configs()
        persisted = all_cfgs.get(config.provider)
        logger.debug(
            "Resolved persisted provider config for test",
            provider_count=len(all_cfgs),
            providers=list(all_cfgs.keys()),
            target_provider=config.provider,
            found=persisted is not None,
        )
    except Exception as e:
        logger.error(f"Failed to get provider config for {config.provider}: {e}")
        persisted = None

    # Resolve effective values
    api_key = config.api_key or (persisted.api_key if persisted else None)
    api_base = config.api_base or (persisted.api_base if persisted else None)
    api_version = config.api_version or (persisted.api_version if persisted else None)

    provider_id = (config.provider or "").strip()
    provider_type = (
        (getattr(config, "provider_type", None) or "").strip()
        or (getattr(persisted, "provider_type", None) or "").strip()
        or provider_id
    )
    provider_type = resolve_provider_for_api_base(provider_type, api_base)

    # Route to provider-specific validation
    if provider_type == "openrouter":
        return await validate_openrouter(api_key, api_base, config.model, provider_id)

    if provider_type == "xai":
        return await validate_xai(api_key, api_base, config.model, provider_id)

    if provider_type == "anthropic":
        return await validate_anthropic(api_key, api_base, config.model, provider_id)

    if provider_type == "gemini":
        return await validate_gemini(api_key, api_base, config.model, provider_id)

    if provider_type == "ollama":
        result = await validate_ollama(api_base, config.model, provider_id)
        if result["success"]:
            return result
        # Fall through to generic on failure

    if provider_type == "github_copilot":
        return await validate_github_copilot(
            config_manager.config_path.parent,
            config.model,
            provider_id,
        )

    if provider_type == "openai_codex":
        return await validate_openai_codex(
            config_manager.config_path.parent,
            config.model,
            provider_id,
        )

    if provider_type == "openai_compatible":
        return await validate_openai_compatible(
            api_key,
            api_base,
            config.model,
            provider_id,
            get_openai_client_class(),
        )

    # Generic validation
    return await validate_generic(
        provider_type,
        api_key,
        api_base,
        api_version,
        config.model,
        provider_id,
    )


async def list_models_with_config(
    override: "RemoteLLMConfig",
    provider: Optional[str] = None,
) -> Dict[str, Any]:
    """List models using explicit config overrides.
    
    Args:
        override: RemoteLLMConfig with override values
        provider: Optional provider name
        
    Returns:
        Dict with models list
    """
    config_manager = get_config_manager()
    return await _list_models_with_config(override, provider, config_manager)
