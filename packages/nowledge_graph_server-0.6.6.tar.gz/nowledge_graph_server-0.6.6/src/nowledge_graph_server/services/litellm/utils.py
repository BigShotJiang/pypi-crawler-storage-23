"""
LiteLLM utility functions.

Helper functions for API base normalization, models.dev fetching, and LangFuse setup.
"""

import os
from typing import Optional, List

import structlog

from .constants import _MODELS_DEV_CACHE

logger = structlog.get_logger(__name__)


def is_kimi_coding_base(api_base: Optional[str]) -> bool:
    """Return True when API base targets Kimi Coding endpoint."""
    base = (api_base or "").strip().lower()
    return "api.kimi.com/coding" in base


def is_minimax_anthropic_base(api_base: Optional[str]) -> bool:
    """Return True when API base targets MiniMax Anthropic-compatible endpoint."""
    base = (api_base or "").strip().lower()
    return "/anthropic" in base and ("api.minimax.io" in base or "api.minimaxi.com" in base)


def resolve_provider_for_api_base(provider_name: str, api_base: Optional[str]) -> str:
    """Resolve effective provider transport for special base URLs.

    Kimi Coding endpoint is Anthropic-compatible (Claude Code style), even when
    the configured provider family is Moonshot.
    """
    if provider_name == "moonshot" and is_kimi_coding_base(api_base):
        return "anthropic"
    if provider_name == "minimax" and is_minimax_anthropic_base(api_base):
        return "anthropic"
    return provider_name


def normalize_api_base(provider_name: str, api_base: Optional[str]) -> Optional[str]:
    """Normalize api_base values to match LiteLLM's provider expectations.
    
    Args:
        provider_name: The provider type (e.g., 'ollama', 'anthropic', 'gemini')
        api_base: The raw API base URL
        
    Returns:
        Normalized API base URL or None if not needed
    """
    if not api_base or not isinstance(api_base, str):
        return None
    base = api_base.strip()
    if not base:
        return None

    # Keep normalization rules consistent with RemoteLLMConfigManager.get_litellm_params()
    if provider_name == "ollama":
        # Ollama: strip /api suffix if present (LiteLLM adds it automatically)
        if base.rstrip("/").endswith("/api"):
            base = base.rstrip("/")[:-4]
    elif provider_name == "anthropic":
        # Anthropic: strip /v1 suffix if present (LiteLLM adds /v1/messages automatically)
        if base.rstrip("/").endswith("/v1"):
            base = base.rstrip("/")[:-3]
    elif provider_name == "gemini":
        # Gemini (Google AI Studio): strip /v1beta or /v1, LiteLLM adds it internally.
        base = base.rstrip("/")
        if base.endswith("/v1beta"):
            base = base[:-7]
        elif base.endswith("/v1"):
            base = base[:-3]
        # Do NOT pass default base URL (LiteLLM handles /v1beta internally).
        if base == "https://generativelanguage.googleapis.com":
            return None
    elif provider_name == "xai":
        # xAI OpenAI-compatible endpoints are under /v1.
        # Normalize host-only/custom bases to include /v1 for chat completions.
        base = base.rstrip("/")
        if not base.endswith("/v1"):
            base = f"{base}/v1"

    return base


async def get_models_dev_provider_model_ids(provider_id: str) -> List[str]:
    """Fetch model IDs for a provider from models.dev/api.json (cached).
    
    The results are cached for 6 hours to avoid frequent network calls.
    
    Args:
        provider_id: The provider identifier for models.dev (e.g., 'github-copilot')
        
    Returns:
        List of model IDs for the provider
    """
    import time as _time
    import httpx

    now = _time.time()
    # Cache for 6 hours to avoid frequent network calls
    if (
        isinstance(_MODELS_DEV_CACHE.get("data"), dict)
        and now - float(_MODELS_DEV_CACHE.get("ts") or 0.0) < 6 * 60 * 60
    ):
        data = _MODELS_DEV_CACHE["data"]
    else:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get("https://models.dev/api.json")
            resp.raise_for_status()
            data = resp.json()
        _MODELS_DEV_CACHE["ts"] = now
        _MODELS_DEV_CACHE["data"] = data

    prov = data.get(provider_id) if isinstance(data, dict) else None
    models = prov.get("models") if isinstance(prov, dict) else None
    if isinstance(models, dict):
        ids = list(models.keys())
        return [m for m in ids if isinstance(m, str) and m.strip()]
    if isinstance(models, list):
        # If models is a list of dicts with id fields
        out: List[str] = []
        for item in models:
            if isinstance(item, dict):
                mid = item.get("id")
                if isinstance(mid, str) and mid.strip():
                    out.append(mid.strip())
        return out
    return []


def setup_langfuse_otel() -> bool:
    """Set up LangFuse OpenTelemetry integration for debugging (dev mode only).
    
    Requires NOWLEDGE_DEV_MODE=true and LANGFUSE_PUBLIC_KEY/LANGFUSE_SECRET_KEY
    environment variables to be set.
    
    Returns:
        bool: True if LangFuse was successfully configured, False otherwise
    """
    try:
        import litellm
    except ImportError:
        return False

    # Check if we're in dev mode
    dev_mode_env = os.getenv("NOWLEDGE_DEV_MODE", "")
    dev_mode = dev_mode_env.lower() in ("true", "1", "yes")
    
    logger.debug(
        "Checking LangFuse setup",
        dev_mode_env=dev_mode_env,
        dev_mode=dev_mode,
    )
    
    if not dev_mode:
        logger.debug("LangFuse setup skipped (NOWLEDGE_DEV_MODE not enabled)")
        return False
    
    # Check if LangFuse credentials are provided
    langfuse_public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
    langfuse_secret_key = os.getenv("LANGFUSE_SECRET_KEY")
    
    logger.debug(
        "LangFuse credentials check",
        has_public_key=bool(langfuse_public_key),
        has_secret_key=bool(langfuse_secret_key),
    )
    
    if not langfuse_public_key or not langfuse_secret_key:
        logger.warning(
            "LangFuse credentials not found",
            missing_keys=[
                k for k in ["LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"]
                if not os.getenv(k)
            ],
        )
        return False
    
    # Check if OpenTelemetry packages are available
    try:
        import base64
        import opentelemetry  # type: ignore
        import opentelemetry.sdk  # type: ignore
        import opentelemetry.exporter.otlp  # type: ignore
        logger.debug("OpenTelemetry packages imported successfully")
    except ImportError as e:
        logger.warning(
            "OpenTelemetry packages not installed",
            error=str(e),
            hint="Install dev dependencies to enable LangFuse debugging (build with --dev flag)",
        )
        return False
    
    try:
        # Set up LangFuse OTEL endpoint
        langfuse_host = os.getenv("LANGFUSE_OTEL_HOST", "https://us.cloud.langfuse.com")
        otel_endpoint = f"{langfuse_host}/api/public/otel"
        
        # Create Basic Auth header
        langfuse_auth = base64.b64encode(
            f"{langfuse_public_key}:{langfuse_secret_key}".encode()
        ).decode()
        
        # Configure OpenTelemetry environment variables
        os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = otel_endpoint
        os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = f"Authorization=Basic {langfuse_auth}"
        
        logger.debug(
            "OpenTelemetry environment configured",
            endpoint=otel_endpoint,
            host=langfuse_host,
            has_auth_header=bool(langfuse_auth),
        )
        
        # Enable LangFuse callback in LiteLLM
        if not hasattr(litellm, "callbacks") or litellm.callbacks is None:
            litellm.callbacks = []  # type: ignore[attr-defined]
        
        if "langfuse_otel" not in litellm.callbacks:  # type: ignore[attr-defined]
            litellm.callbacks.append("langfuse_otel")  # type: ignore[attr-defined]
            logger.debug("Added langfuse_otel callback to LiteLLM")
        else:
            logger.debug("langfuse_otel callback already present in LiteLLM")
        
        logger.info(
            "LangFuse OpenTelemetry integration enabled",
            endpoint=otel_endpoint,
            host=langfuse_host,
            callbacks=litellm.callbacks,  # type: ignore[attr-defined]
        )
        return True
        
    except Exception as e:
        logger.warning(
            "Failed to set up LangFuse OpenTelemetry integration",
            error=str(e),
            error_type=type(e).__name__,
            exc_info=True,
        )
        return False


def infer_operation_name(prompt: str) -> str:
    """Infer operation name from prompt content for LangFuse tracking.
    
    Args:
        prompt: The LLM prompt text
        
    Returns:
        Inferred operation name for tracing
    """
    prompt_lower = prompt.lower()
    if "distill" in prompt_lower or ("memory" in prompt_lower and "extract" not in prompt_lower):
        return "memory_distillation"
    elif "entity" in prompt_lower or ("extract" in prompt_lower and "entity" in prompt_lower):
        return "entity_extraction"
    elif "hyde" in prompt_lower or "hypothetical" in prompt_lower:
        return "hyde_query_expansion"
    elif "label" in prompt_lower or ("tag" in prompt_lower and "label" in prompt_lower):
        return "label_suggestion"
    elif "search" in prompt_lower and "context" in prompt_lower:
        return "search_context_analysis"
    elif "graph" in prompt_lower or "relationship" in prompt_lower:
        return "graph_analysis"
    elif "chunk" in prompt_lower:
        return "chunk_processing"
    elif "consolidat" in prompt_lower:
        return "memory_consolidation"
    else:
        return "llm_generation"


def detect_json_requirement(prompt: str) -> bool:
    """Detect if a prompt requires JSON output.
    
    Args:
        prompt: The LLM prompt text
        
    Returns:
        True if JSON output is expected
    """
    prompt_lower = prompt.lower()
    return any(indicator in prompt_lower for indicator in [
        "json:", "output json", "return json", "json format",
        "json output", "```json", "{\"", "output format: json", "output this exact json"
    ])
