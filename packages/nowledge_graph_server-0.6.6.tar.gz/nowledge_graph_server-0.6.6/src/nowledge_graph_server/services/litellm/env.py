"""
LiteLLM environment variable management.

Provides scoped environment context for provider-specific credentials.
"""

import os
import threading
from contextlib import contextmanager
from typing import Optional, Dict, Any, Generator

import structlog

from .constants import ALL_PROVIDER_ENV_KEYS
from .utils import normalize_api_base

logger = structlog.get_logger(__name__)

_CODEX_REFRESH_LOCK = threading.Lock()


def _decode_jwt_claims(token: str) -> dict:
    """Decode JWT payload without verification (for extracting claims only).

    Args:
        token: A JWT string (access_token or id_token).

    Returns:
        Decoded claims dict, or empty dict on failure.
    """
    import base64
    import json as _json

    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        # Add padding
        payload = parts[1]
        payload += "=" * (4 - len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload)
        return _json.loads(decoded)
    except Exception:
        return {}


def _extract_codex_account_id(id_token: str) -> Optional[str]:
    """Extract chatgpt_account_id from an OpenAI id_token JWT.

    LiteLLM's chatgpt authenticator expects this field in the token file
    and uses it for the ``ChatGPT-Account-Id`` request header.

    Args:
        id_token: The id_token JWT from the OAuth response.

    Returns:
        The account ID string, or None if not found.
    """
    claims = _decode_jwt_claims(id_token)
    try:
        return claims.get("https://api.openai.com/auth", {}).get("chatgpt_account_id")
    except Exception:
        return None


def _get_jwt_expires_at(token: str) -> Optional[int]:
    """Extract ``exp`` claim from a JWT.

    Args:
        token: A JWT string.

    Returns:
        The expiry as a unix timestamp (int), or None.
    """
    claims = _decode_jwt_claims(token)
    exp = claims.get("exp")
    if exp is not None:
        return int(exp)
    return None


@contextmanager
def scoped_provider_env(
    provider_type: str,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    api_version: Optional[str] = None,
    preserve_keys: Optional[Dict[str, str]] = None,
) -> Generator[None, None, None]:
    """Context manager for scoped provider environment variables.
    
    Clears all provider env keys, sets only the specified provider's credentials,
    and restores the original environment on exit.
    
    Args:
        provider_type: The provider type (openai, anthropic, etc.)
        api_key: API key for the provider
        api_base: API base URL for the provider
        api_version: API version (for Azure)
        preserve_keys: Optional dict of keys to preserve across the scope
        
    Yields:
        None
    """
    old_env = os.environ.copy()
    try:
        # Clear all provider keys first to avoid leakage
        for k in ALL_PROVIDER_ENV_KEYS:
            os.environ.pop(k, None)

        # Set provider-specific environment
        _set_provider_env(provider_type, api_key, api_base, api_version)
        
        yield
    finally:
        os.environ.clear()
        os.environ.update(old_env)
        # Restore any keys that should be preserved
        if preserve_keys:
            for k, v in preserve_keys.items():
                os.environ.setdefault(k, v)


def _set_provider_env(
    provider_type: str,
    api_key: Optional[str],
    api_base: Optional[str],
    api_version: Optional[str] = None,
) -> None:
    """Set environment variables for a specific provider.
    
    Args:
        provider_type: The provider type
        api_key: API key
        api_base: API base URL
        api_version: API version (for Azure)
    """
    if provider_type == "openai":
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
        if api_base:
            os.environ["OPENAI_BASE_URL"] = api_base
    elif provider_type == "anthropic":
        if api_key:
            os.environ["ANTHROPIC_API_KEY"] = api_key
        if api_base:
            normalized = normalize_api_base(provider_type, api_base)
            os.environ["ANTHROPIC_API_BASE"] = normalized or api_base
    elif provider_type == "xai":
        if api_key:
            os.environ["XAI_API_KEY"] = api_key
        if api_base:
            os.environ["XAI_API_BASE"] = api_base
    elif provider_type == "deepseek":
        if api_key:
            os.environ["DEEPSEEK_API_KEY"] = api_key
        if api_base:
            os.environ["DEEPSEEK_API_BASE"] = api_base
    elif provider_type == "minimax":
        if api_key:
            os.environ["MINIMAX_API_KEY"] = api_key
        if api_base:
            os.environ["MINIMAX_API_BASE"] = api_base
    elif provider_type == "zai":
        if api_key:
            os.environ["ZAI_API_KEY"] = api_key
        if api_base:
            os.environ["ZAI_API_BASE"] = api_base
    elif provider_type == "moonshot":
        if api_key:
            os.environ["MOONSHOT_API_KEY"] = api_key
        if api_base:
            os.environ["MOONSHOT_API_BASE"] = api_base
    elif provider_type == "azure":
        if api_key:
            os.environ["AZURE_API_KEY"] = api_key
        if api_base:
            os.environ["AZURE_API_BASE"] = api_base
        if api_version:
            os.environ["AZURE_API_VERSION"] = api_version
        os.environ["AZURE_API_TYPE"] = "azure"
    elif provider_type == "openrouter":
        if api_key:
            os.environ["OPENROUTER_API_KEY"] = api_key
        if api_base:
            os.environ["OPENROUTER_API_BASE"] = api_base
    elif provider_type == "gemini":
        if api_key:
            os.environ["GEMINI_API_KEY"] = api_key
            os.environ["GOOGLE_API_KEY"] = api_key
        # Only set base if non-default
        if api_base:
            normalized = normalize_api_base(provider_type, api_base)
            if normalized:
                os.environ["GEMINI_API_BASE"] = normalized


def setup_github_copilot_env(config_path_parent: Any) -> Optional[str]:
    """Set up GitHub Copilot environment with token directory.
    
    Args:
        config_path_parent: Parent path for config (typically config_manager.config_path.parent)
        
    Returns:
        Token directory path or None if setup failed
    """
    import json as _json
    
    try:
        token_dir = str(config_path_parent / "github_copilot")
        os.makedirs(token_dir, exist_ok=True)
        os.environ["GITHUB_COPILOT_TOKEN_DIR"] = token_dir
        os.environ.setdefault("GITHUB_COPILOT_ACCESS_TOKEN_FILE", "access-token")
        os.environ.setdefault("GITHUB_COPILOT_API_KEY_FILE", "api-key.json")

        # Ensure api-key.json exists so LiteLLM can resolve endpoints.api
        api_key_path = os.path.join(
            token_dir, os.environ["GITHUB_COPILOT_API_KEY_FILE"]
        )
        if not os.path.exists(api_key_path):
            with open(api_key_path, "w", encoding="utf-8") as f:
                _json.dump(
                    {"endpoints": {"api": "https://api.githubcopilot.com"}},
                    f,
                )
        
        return token_dir
    except Exception as e:
        logger.warning("Failed to set up GitHub Copilot token directory", error=str(e))
        return None


def check_copilot_authenticated(token_dir: str) -> bool:
    """Check if GitHub Copilot is authenticated.
    
    Args:
        token_dir: Path to the Copilot token directory
        
    Returns:
        True if an access token exists and is non-empty
    """
    try:
        access_token_path = os.path.join(
            token_dir,
            os.environ.get("GITHUB_COPILOT_ACCESS_TOKEN_FILE", "access-token"),
        )
        if os.path.exists(access_token_path):
            with open(access_token_path, "r", encoding="utf-8") as f:
                return bool(f.read().strip())
    except Exception:
        pass
    return False


def get_copilot_ide_headers(existing_headers: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Get required IDE headers for GitHub Copilot requests.

    Args:
        existing_headers: Existing headers to merge with

    Returns:
        Dict of headers including required Copilot headers
    """
    defaults = {
        "Editor-Version": "vscode/1.85.1",
        "Editor-Plugin-Version": "copilot/1.155.0",
        "User-Agent": "GithubCopilot/1.155.0",
        "Copilot-Integration-Id": "vscode-chat",
        "Accept": "application/json",
    }
    if existing_headers:
        return {**defaults, **existing_headers}
    return defaults


# =============================================================================
# OpenAI Codex Environment Setup
# =============================================================================

def setup_openai_codex_env(config_path_parent: Any) -> Optional[str]:
    """Set up OpenAI Codex environment with token directory.

    Args:
        config_path_parent: Parent path for config (typically config_manager.config_path.parent)

    Returns:
        Token directory path or None if setup failed
    """
    import json as _json

    try:
        token_dir = str(config_path_parent / "openai_codex")
        os.makedirs(token_dir, exist_ok=True)
        os.environ["OPENAI_CODEX_TOKEN_DIR"] = token_dir
        os.environ.setdefault("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json")
        os.environ.setdefault("OPENAI_CODEX_REFRESH_TOKEN_FILE", "refresh-token")

        # Ensure token info file exists with default structure
        token_info_path = os.path.join(
            token_dir, os.environ["OPENAI_CODEX_ACCESS_TOKEN_FILE"]
        )
        if not os.path.exists(token_info_path):
            with open(token_info_path, "w", encoding="utf-8") as f:
                _json.dump(
                    {"api_base": "https://chatgpt.com/backend-api/codex"},
                    f,
                )

        return token_dir
    except Exception as e:
        logger.warning("Failed to set up OpenAI Codex token directory", error=str(e))
        return None


def ensure_chatgpt_auth_file(token_dir: str) -> Optional[str]:
    """Ensure LiteLLM's ChatGPT auth file exists from our Codex token cache."""
    import json as _json

    access_token_path = os.path.join(
        token_dir,
        os.environ.get("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json"),
    )
    auth_path = os.path.join(
        token_dir,
        os.environ.get("CHATGPT_AUTH_FILE", "auth.json"),
    )

    try:
        if not os.path.exists(access_token_path):
            return None
        with open(access_token_path, "r", encoding="utf-8") as f:
            data = _json.load(f) or {}
        if not isinstance(data, dict):
            return None

        access_token = (data.get("access_token") or "").strip()
        if not access_token:
            return None

        refresh_token = (data.get("refresh_token") or "").strip()
        id_token = (data.get("id_token") or "").strip()
        expires_at = data.get("expires_at")
        if expires_at is None:
            expires_at = _get_jwt_expires_at(access_token)

        account_id = data.get("account_id")
        if not account_id:
            account_id = _extract_codex_account_id(id_token or access_token)

        auth_data = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "id_token": id_token,
            "expires_at": expires_at,
            "account_id": account_id,
            "api_base": "https://chatgpt.com/backend-api/codex",
        }

        with open(auth_path, "w", encoding="utf-8") as f:
            _json.dump(auth_data, f)
        return auth_path
    except Exception as e:
        logger.warning("Failed to write ChatGPT auth file", error=str(e))
        return None


def check_codex_authenticated(token_dir: str) -> bool:
    """Check if OpenAI Codex is authenticated.

    Args:
        token_dir: Path to the Codex token directory

    Returns:
        True if an access token exists and is non-empty
    """
    import json as _json

    try:
        access_token_path = os.path.join(
            token_dir,
            os.environ.get("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json"),
        )
        if os.path.exists(access_token_path):
            with open(access_token_path, "r", encoding="utf-8") as f:
                data = _json.load(f)
                # Check for valid access_token in the stored data
                return bool(data.get("access_token", "").strip())
    except Exception:
        pass
    return False


def get_codex_api_headers(existing_headers: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Get required headers for OpenAI Codex API requests.

    Args:
        existing_headers: Existing headers to merge with

    Returns:
        Dict of headers including required Codex headers
    """
    defaults = {
        "User-Agent": "Codex-CLI/1.0 Nowledge/1.0",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if existing_headers:
        return {**defaults, **existing_headers}
    return defaults


def get_codex_access_token(token_dir: str) -> Optional[str]:
    """Get the current access token from the token directory.

    Args:
        token_dir: Path to the Codex token directory

    Returns:
        The access token string or None if not available
    """
    import json as _json
    import time as _time

    try:
        access_token_path = os.path.join(
            token_dir,
            os.environ.get("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json"),
        )
        if os.path.exists(access_token_path):
            with open(access_token_path, "r", encoding="utf-8") as f:
                data = _json.load(f)

            access_token = data.get("access_token", "").strip()
            if not access_token:
                return None

            # Check if token is expired
            expires_at = data.get("expires_at", 0)
            if expires_at and _time.time() > expires_at - 60:  # 60s buffer
                # Token expired, try to refresh (guarded to avoid duplicate refreshes)
                refresh_token = data.get("refresh_token", "").strip()
                if refresh_token:
                    with _CODEX_REFRESH_LOCK:
                        # Re-read in case another thread/process refreshed it
                        try:
                            with open(access_token_path, "r", encoding="utf-8") as f:
                                data = _json.load(f)
                            access_token = data.get("access_token", "").strip()
                            expires_at = data.get("expires_at", 0)
                            if access_token and expires_at and _time.time() <= expires_at - 60:
                                return access_token
                        except Exception:
                            pass

                        refreshed = refresh_codex_token(token_dir, refresh_token)
                        if refreshed:
                            # Re-read the refreshed token
                            with open(access_token_path, "r", encoding="utf-8") as f:
                                data = _json.load(f)
                            return data.get("access_token", "").strip()
                return None

            return access_token
    except Exception as e:
        logger.warning("Failed to get Codex access token", error=str(e))
    return None


def refresh_codex_token(token_dir: str, refresh_token: str) -> bool:
    """Refresh the OpenAI Codex access token using the refresh token.

    Args:
        token_dir: Path to the Codex token directory
        refresh_token: The refresh token to use

    Returns:
        True if refresh was successful
    """
    import json as _json
    import time as _time
    import httpx

    from .constants import OPENAI_CODEX_CLIENT_ID, OPENAI_CODEX_REFRESH_TOKEN_URL

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                OPENAI_CODEX_REFRESH_TOKEN_URL,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                },
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": OPENAI_CODEX_CLIENT_ID,
                    "scope": "openid profile email",
                },
            )
            resp.raise_for_status()
            data = resp.json()

        if data.get("access_token"):
            # Save the new tokens in the format LiteLLM's native chatgpt
            # authenticator expects: access_token, refresh_token, id_token,
            # expires_at, account_id.
            access_token_path = os.path.join(
                token_dir,
                os.environ.get("OPENAI_CODEX_ACCESS_TOKEN_FILE", "access-token.json"),
            )

            new_access_token = data["access_token"]
            new_id_token = data.get("id_token", "")

            # Prefer JWT exp claim (matches LiteLLM), fall back to expires_in
            expires_at = _get_jwt_expires_at(new_access_token)
            if expires_at is None:
                expires_in = data.get("expires_in") or 3600
                expires_at = int(_time.time() + expires_in)

            account_id = _extract_codex_account_id(new_id_token) if new_id_token else None

            token_data = {
                "access_token": new_access_token,
                "refresh_token": data.get("refresh_token", refresh_token),
                "id_token": new_id_token,
                "expires_at": expires_at,
                "account_id": account_id,
                "api_base": "https://chatgpt.com/backend-api/codex",
            }

            with open(access_token_path, "w", encoding="utf-8") as f:
                _json.dump(token_data, f)

            logger.info("Successfully refreshed Codex access token")
            return True
    except Exception as e:
        logger.warning("Failed to refresh Codex access token", error=str(e))

    return False
