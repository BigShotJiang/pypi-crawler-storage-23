"""
LiteLLM Provider for remote LLM inference.

Supports 100+ LLM providers through LiteLLM's unified interface.
"""

import os
import asyncio
import traceback
from typing import Optional, Dict, Any, List, Set

import structlog

from nowledge_graph_server.services.base_llm import (
    BaseLLMProvider,
    LLMGenerationConfig,
)
from nowledge_graph_server.services.remote_llm_config import get_config_manager

from .constants import JSON_FORMAT_PROVIDERS, ALL_PROVIDER_ENV_KEYS
from .env import (
    setup_github_copilot_env,
    check_copilot_authenticated,
    get_copilot_ide_headers,
    setup_openai_codex_env,
    check_codex_authenticated,
    get_codex_access_token,
)
from .utils import (
    normalize_api_base,
    setup_langfuse_otel,
    infer_operation_name,
    detect_json_requirement,
    resolve_provider_for_api_base,
    is_minimax_anthropic_base,
)
from .openai_compatible_client import build_openai_compatible_client

# Module-level state — initialized lazily by _ensure_litellm_loaded()
_USING_LANGFUSE_OPENAI_CLIENT = False
_OpenAIClient = None  # type: ignore
_FINISH_REASON_PATCHED = False
_INVALID_FINISH_REASON_LOGGED = False
_LITELLM_LOADED = False

# Lazy references — set by _ensure_litellm_loaded(), used by methods at call time
litellm: Any = None  # type: ignore
ChatCompletionUserMessageParam: Any = None  # type: ignore


def _ensure_litellm_loaded() -> None:
    """Lazy-load litellm and openai on first use (~200MB RAM savings at startup).

    All LiteLLMProvider methods call this before using litellm.  The module-level
    ``litellm`` variable is updated in-place so existing ``litellm.xxx`` references
    in method bodies resolve correctly at call time.
    """
    global _LITELLM_LOADED, litellm, ChatCompletionUserMessageParam
    global _OpenAIClient, _USING_LANGFUSE_OPENAI_CLIENT, _FINISH_REASON_PATCHED
    if _LITELLM_LOADED:
        return

    try:
        import litellm as _litellm_mod
        litellm = _litellm_mod

        from openai.types.chat.chat_completion_user_message_param import (
            ChatCompletionUserMessageParam as _CCUMP,
        )
        ChatCompletionUserMessageParam = _CCUMP

        # Import OpenAI client - try LangFuse wrapper in dev mode
        try:
            dev_mode_env = os.getenv("NOWLEDGE_DEV_MODE", "")
            dev_mode = dev_mode_env.lower() in ("true", "1", "yes")

            if dev_mode:
                langfuse_public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
                langfuse_secret_key = os.getenv("LANGFUSE_SECRET_KEY")

                if langfuse_public_key and langfuse_secret_key:
                    try:
                        from langfuse.openai import OpenAI as _LangFuseOpenAI  # type: ignore[import-not-found]
                        _OpenAIClient = _LangFuseOpenAI
                        _USING_LANGFUSE_OPENAI_CLIENT = True
                        import sys
                        print("Using LangFuse-wrapped OpenAI client for observability", file=sys.stderr)
                    except ImportError:
                        from openai import OpenAI as _OpenAIClient  # type: ignore
                else:
                    from openai import OpenAI as _OpenAIClient  # type: ignore
            else:
                from openai import OpenAI as _OpenAIClient  # type: ignore
        except ImportError as e:
            import sys
            print(f"Warning: OpenAI client not available: {e}. openai_compatible provider will not work.", file=sys.stderr)
            _OpenAIClient = None  # type: ignore
        except Exception as e:
            import sys
            print(f"Unexpected error importing OpenAI client: {e}", file=sys.stderr)
            _OpenAIClient = None  # type: ignore

        # Configure LiteLLM
        litellm.drop_params = True
        litellm.set_verbose = False  # type: ignore[attr-defined]

        _patch_finish_reason_error()

    except ImportError:
        raise ImportError("LiteLLM not installed. Run: pip install litellm")
    finally:
        _LITELLM_LOADED = True


def _patch_finish_reason_error() -> None:
    """Normalize invalid finish_reason values (e.g. OpenRouter 'error')."""
    global _FINISH_REASON_PATCHED
    if _FINISH_REASON_PATCHED:
        return

    try:
        from litellm.litellm_core_utils.llm_response_utils import (
            convert_dict_to_response as _convert_mod,
        )
    except Exception:
        return

    original = _convert_mod.convert_to_model_response_object

    def patched_convert_to_model_response_object(*args, **kwargs):
        global _INVALID_FINISH_REASON_LOGGED
        response_object = kwargs.get("response_object")
        if response_object is None and args:
            response_object = args[0]

        if isinstance(response_object, dict):
            choices = response_object.get("choices")
            if isinstance(choices, list):
                patched = False
                for choice in choices:
                    if (
                        isinstance(choice, dict)
                        and choice.get("finish_reason") == "error"
                    ):
                        choice["finish_reason"] = "finish_reason_unspecified"
                        patched = True
                if patched and not _INVALID_FINISH_REASON_LOGGED:
                    _INVALID_FINISH_REASON_LOGGED = True
                    logger.warning(
                        "Normalized invalid finish_reason from provider response",
                        provider=(response_object.get("provider") or "unknown"),
                        model=(response_object.get("model") or "unknown"),
                    )
            if "response_object" in kwargs:
                kwargs["response_object"] = response_object

        return original(*args, **kwargs)

    _convert_mod.convert_to_model_response_object = patched_convert_to_model_response_object
    _FINISH_REASON_PATCHED = True


logger = structlog.get_logger(__name__)


class LiteLLMProvider(BaseLLMProvider):
    """Remote LLM provider using LiteLLM for multi-provider support."""

    def __init__(self):
        """Initialize the LiteLLM provider."""
        _ensure_litellm_loaded()
        self.config_manager = get_config_manager()
        self._initialized = False
        # Serialize env manipulation around litellm calls.
        # LiteLLM's chatgpt provider reads CHATGPT_TOKEN_DIR/CHATGPT_AUTH_FILE from
        # os.environ at call time. Concurrent async calls interleave at await points,
        # causing env clobbering and 403s after the first successful call.
        self._env_lock = asyncio.Lock()

    async def initialize(self) -> None:
        """Initialize the provider."""
        if self._initialized:
            return

        config = self.config_manager.get_config()

        if not config.enabled:
            raise RuntimeError("Remote LLM is not enabled in configuration")

        # Set up LangFuse debugging in dev mode
        setup_langfuse_otel()

        logger.info(
            "LiteLLM provider initialized",
            provider=config.provider,
            model=config.model,
            has_api_key=bool(config.api_key),
            api_base=config.api_base,
        )

        self._initialized = True

    async def generate_response(
        self, prompt: str, config: Optional[LLMGenerationConfig] = None, operation_name: Optional[str] = None
    ) -> str:
        """Generate response using LiteLLM.

        Args:
            prompt: The prompt to send to the LLM
            config: Optional generation configuration
            operation_name: Optional operation name for LangFuse tracking

        Returns:
            Generated text response
        """
        if not self._initialized:
            await self.initialize()

        llm_config = self.config_manager.get_config()
        litellm_params = self.config_manager.get_litellm_params()
        provider_id = (llm_config.provider or "").strip()
        provider_type = (getattr(llm_config, "provider_type", None) or "").strip() or provider_id

        # Ensure model id is valid for provider
        self._normalize_model_param(litellm_params, provider_type)

        # Remove params that may cause issues with remote providers
        for param in ["temperature", "top_p", "top_k", "min_p", "max_tokens"]:
            litellm_params.pop(param, None)

        # Disable model thinking/reasoning - we don't use thinking features
        # Each provider has different params, handle per-provider:
        model_name = (litellm_params.get("model") or llm_config.model or "").lower()
        self._disable_thinking_for_provider(litellm_params, provider_type, model_name)

        # Enable JSON mode if needed
        needs_json = detect_json_requirement(prompt)
        if needs_json:
            self._configure_json_mode(litellm_params, provider_type)

        messages: List[ChatCompletionUserMessageParam] = [
            ChatCompletionUserMessageParam(role="user", content=prompt)
        ]

        # Note: ChatGPT Subscription (openai_codex) uses LiteLLM's native chatgpt provider
        # which automatically handles the instructions field — no system message injection needed.

        logger.debug(
            "Calling LiteLLM completion",
            provider=llm_config.provider,
            model=llm_config.model,
            prompt_length=len(prompt),
            json_mode=needs_json,
        )

        try:
            # Special handling: openai_compatible uses OpenAI client directly
            if provider_type == "openai_compatible":
                return await self._generate_openai_compatible(
                    llm_config, messages, needs_json, operation_name
                )

            # Standard LiteLLM path
            return await self._generate_with_litellm(
                llm_config, litellm_params, messages, provider_type, prompt, operation_name
            )

        except Exception as e:
            provider = (getattr(llm_config, "provider_type", None) or llm_config.provider or "").strip()
            error_prefix = "OpenAI-compatible" if provider == "openai_compatible" else "LiteLLM"
            logger.error(
                f"{error_prefix} generation failed",
                error=str(e),
                provider=provider,
                model=llm_config.model,
            )
            logger.debug(traceback.format_exc())
            raise RuntimeError(f"{error_prefix} generation failed: {str(e)}") from e

    def _normalize_model_param(self, litellm_params: Dict[str, Any], provider_type: str) -> None:
        """Normalize model parameter to include provider prefix if needed."""
        try:
            model_param = litellm_params.get("model", "")
            if isinstance(model_param, str) and provider_type:
                if not model_param.startswith(provider_type + "/") and "/" not in model_param:
                    litellm_params["model"] = f"{provider_type}/{model_param}" if model_param else model_param
        except Exception:
            pass

    def _disable_thinking_for_provider(
        self, litellm_params: Dict[str, Any], provider_type: str, model_name: str
    ) -> None:
        """Disable thinking/reasoning for each provider using their specific params.
        
        We don't use thinking features to save costs and reduce latency.
        
        References (from LiteLLM docs):
        - Gemini: https://docs.litellm.ai/docs/providers/gemini
          Use reasoning_effort="none" for up to 96% cost savings
        - Anthropic: https://docs.litellm.ai/docs/providers/anthropic
          Thinking is opt-in via `thinking` param, don't send = disabled
        - xAI: https://docs.litellm.ai/docs/providers/xai
          No control param, just don't send thinking params
        - Ollama: https://docs.litellm.ai/docs/providers/ollama
          No thinking params supported
        - OpenRouter: https://docs.litellm.ai/docs/providers/openrouter
          Passes through to underlying model
        """
        # First, remove any thinking params that might have been set elsewhere
        # This prevents conflicts (e.g., Gemini can't have both thinking and thinking_level)
        thinking_params = [
            "thinking", "thinking_level", "thinking_budget", 
            "extended_thinking", "thinkingConfig"
        ]
        for param in thinking_params:
            litellm_params.pop(param, None)
        
        # Gemini: Use reasoning_effort="none" for cost optimization (up to 96% cheaper)
        # https://docs.litellm.ai/docs/providers/gemini#usage---thinking--reasoning_content
        # Note: reasoning_effort="none" maps to thinking.budget_tokens=0, includeThoughts=false
        is_gemini = provider_type == "gemini" or "gemini" in model_name
        if is_gemini:
            litellm_params["reasoning_effort"] = "none"
            logger.debug("Gemini: set reasoning_effort=none for cost optimization")
            return
        
        # OpenAI o1/o3/o4 models: use reasoning_effort="low" to minimize reasoning
        # Note: Can't fully disable reasoning on these models
        is_openai_reasoning = (
            provider_type == "openai" 
            and any(x in model_name for x in ["-o1", "-o3", "-o4", "o1-", "o3-", "o4-"])
        )
        if is_openai_reasoning:
            litellm_params["reasoning_effort"] = "low"
            logger.debug("OpenAI: set reasoning_effort=low for reasoning model")
            return
        
        # For other providers, remove reasoning_effort too (might cause issues)
        litellm_params.pop("reasoning_effort", None)
        
        # Anthropic: Thinking is opt-in, don't send thinking param = disabled
        # xAI: No control param, just don't send thinking params  
        # Ollama: No thinking params supported
        # OpenRouter: Passes through to underlying model
        # Azure, openai_compatible: No thinking params supported

    def _configure_json_mode(self, litellm_params: Dict[str, Any], provider_type: str) -> None:
        """Configure JSON response format for supported providers."""
        if provider_type == "openrouter":
            litellm_params["extra_body"] = {
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "structured_output",
                        "strict": True,
                        "schema": {
                            "type": "object",
                            "properties": {},
                            "additionalProperties": True
                        }
                    }
                }
            }
            logger.debug("Enabled JSON mode for OpenRouter via extra_body")
        elif provider_type == "ollama":
            # Ollama: Use format="json" for better compatibility with models like Qwen3
            litellm_params["format"] = "json"
            logger.debug("Enabled JSON mode for Ollama via format param")
        elif provider_type in JSON_FORMAT_PROVIDERS:
            litellm_params["response_format"] = {"type": "json_object"}
            logger.debug(f"Enabled JSON mode for {provider_type} via response_format")
        elif provider_type in ("github_copilot", "openai_codex"):
            logger.debug(f"Skipping response_format for {provider_type}; prompt enforces JSON-only")
        else:
            litellm_params["response_format"] = {"type": "json_object"}
            logger.debug(f"Attempting JSON mode for {provider_type}")

    async def _generate_openai_compatible(
        self,
        llm_config: Any,
        messages: List[ChatCompletionUserMessageParam],
        needs_json: bool,
        operation_name: Optional[str],
    ) -> str:
        """Generate using OpenAI-compatible endpoint."""
        if _OpenAIClient is None:
            raise RuntimeError("OpenAI client not installed. Run: pip install openai>=1.0.0")

        effective_api_base = llm_config.api_base or os.environ.get("OPENAI_BASE_URL")
        client, bypass_proxy = build_openai_compatible_client(
            _OpenAIClient,
            api_key=(llm_config.api_key or os.environ.get("OPENAI_API_KEY", "")),
            api_base=effective_api_base,
            max_retries=0,
        )
        logger.debug(
            "OpenAI-compatible generation request",
            api_base=effective_api_base,
            model=(llm_config.model or ""),
            bypass_proxy=bypass_proxy,
        )

        try:
            openai_kwargs: Dict[str, Any] = {
                "model": (llm_config.model or ""),
                "messages": messages,
            }

            if needs_json:
                openai_kwargs["response_format"] = {"type": "json_object"}
                logger.debug("Enabled JSON mode for openai_compatible")

            if operation_name and _USING_LANGFUSE_OPENAI_CLIENT:
                openai_kwargs["name"] = operation_name
                openai_kwargs["metadata"] = {
                    "operation": operation_name,
                    "provider": "openai_compatible",
                    "model": llm_config.model or "",
                }

            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: client.chat.completions.create(**openai_kwargs),
            )
        finally:
            client.close()

        text = resp.choices[0].message.content if resp and resp.choices else ""
        if not text or not text.strip():
            raise ValueError("Empty response from OpenAI-compatible server")

        # Record token usage to centralized tracker
        try:
            from nowledge_graph_server.agent import token_tracker
            usage = getattr(resp, "usage", None)
            if usage:
                token_tracker.record(
                    getattr(usage, "prompt_tokens", 0) or 0,
                    getattr(usage, "completion_tokens", 0) or 0,
                    source="litellm_provider",
                )
        except Exception:
            pass

        logger.debug(
            "OpenAI-compatible generation successful",
            response_length=len(text),
            model=llm_config.model,
        )
        return text

    async def _generate_with_litellm(
        self,
        llm_config: Any,
        litellm_params: Dict[str, Any],
        messages: List[ChatCompletionUserMessageParam],
        provider_type: str,
        prompt: str,
        operation_name: Optional[str],
    ) -> str:
        """Generate using LiteLLM with provider-scoped environment.

        Uses an asyncio lock to serialize env manipulation. Without this,
        concurrent async calls (e.g. 3 parallel reflection tasks) interleave
        at await points, clobbering each other's env vars. LiteLLM's chatgpt
        provider reads CHATGPT_TOKEN_DIR from os.environ at call time, so
        a stale/empty env causes 403 errors or endless device-code auth loops.
        """
        async with self._env_lock:
            # Track which env keys we add so we can surgically remove them.
            # NEVER use os.environ.clear() — it nukes ALL env vars for the
            # entire process, breaking concurrent operations.
            added_keys: Set[str] = set()
            old_values: Dict[str, str] = {}
            try:
                # Get provider config
                try:
                    all_cfgs = self.config_manager.get_all_provider_configs()
                    prov_cfg = all_cfgs.get((llm_config.provider or "").strip(), llm_config)
                except Exception:
                    prov_cfg = llm_config

                provider_type = (getattr(prov_cfg, "provider_type", None) or "").strip() or (llm_config.provider or "").strip()
                provider_type = resolve_provider_for_api_base(
                    provider_type, getattr(prov_cfg, "api_base", None)
                )

                # Clear provider env keys (save old values for restore)
                for k in ALL_PROVIDER_ENV_KEYS:
                    if k in os.environ:
                        old_values[k] = os.environ.pop(k)
                    else:
                        os.environ.pop(k, None)

                # Snapshot env before setup to detect what gets added
                pre_setup_keys = set(os.environ.keys())

                # Remove stale api_key from params
                litellm_params.pop("api_key", None)

                # Set provider-specific environment
                self._setup_provider_env(provider_type, prov_cfg, litellm_params)

                # Track added keys
                added_keys = set(os.environ.keys()) - pre_setup_keys

                # Add LangFuse metadata
                inferred_operation = operation_name or infer_operation_name(prompt)
                litellm_params["metadata"] = {
                    "generation_name": inferred_operation,
                    "operation": inferred_operation,
                    "provider": provider_type,
                    "model": litellm_params.get("model", llm_config.model),
                }

                logger.info(
                    "LiteLLM call prepared",
                    provider=provider_type,
                    model=litellm_params.get("model"),
                    api_base=litellm_params.get("api_base"),
                )

                response = await litellm.acompletion(messages=messages, **litellm_params)

            finally:
                # Surgical cleanup: only remove keys we added, restore old values
                for k in added_keys:
                    if k in old_values:
                        os.environ[k] = old_values[k]
                    else:
                        os.environ.pop(k, None)
                # Restore any provider keys that existed before
                for k, v in old_values.items():
                    if k not in os.environ:
                        os.environ[k] = v

        # Extract and validate response
        if not response or not response.choices:  # type: ignore[attr-defined]
            logger.error("Empty response from LiteLLM", response_obj=str(response))
            raise ValueError("Empty response from LiteLLM")

        choice = response.choices[0]  # type: ignore[attr-defined]
        message = choice.message  # type: ignore[attr-defined]
        generated_text = message.content

        # Handle thinking models (Qwen3, DeepSeek, etc.) that may return content in different fields
        if not generated_text or not generated_text.strip():
            alt_content = None
            
            # Check for reasoning_content (Qwen3/DeepSeek-style thinking)
            if hasattr(message, 'reasoning_content') and message.reasoning_content:
                alt_content = message.reasoning_content
                logger.debug("Using reasoning_content from thinking model")
            
            # Check for thinking field (some providers)
            elif hasattr(message, 'thinking') and message.thinking:  # type: ignore[attr-defined]
                alt_content = message.thinking  # type: ignore[attr-defined]
                logger.debug("Using thinking field from model")
            
            # Check for tool_calls that might contain content
            elif hasattr(message, 'tool_calls') and message.tool_calls:
                for tc in message.tool_calls:
                    if hasattr(tc, 'function') and hasattr(tc.function, 'arguments'):
                        alt_content = tc.function.arguments
                        logger.debug("Using tool_call arguments as content")
                        break
            
            if alt_content and alt_content.strip():
                generated_text = alt_content
                logger.info(
                    "Recovered content from alternative field",
                    model=response.model if hasattr(response, "model") else None,
                    content_length=len(alt_content),
                )

        if not generated_text or not generated_text.strip():
            refusal = getattr(message, 'refusal', None) if message else None
            finish_reason = getattr(choice, 'finish_reason', None)
            logger.warning(
                "LiteLLM returned empty content",
                model=response.model if hasattr(response, "model") else None,
                finish_reason=finish_reason,
                refusal=refusal,
            )
            raise ValueError(f"Empty content from LiteLLM (finish_reason={finish_reason}, refusal={refusal})")

        # Record token usage to centralized tracker
        try:
            from nowledge_graph_server.agent import token_tracker
            usage = getattr(response, "usage", None)
            if usage:
                token_tracker.record(
                    getattr(usage, "prompt_tokens", 0) or 0,
                    getattr(usage, "completion_tokens", 0) or 0,
                    source="litellm_provider",
                )
        except Exception:
            pass

        logger.debug(
            "LiteLLM generation successful",
            response_length=len(generated_text),
            model=response.model if hasattr(response, "model") else None,
        )

        return generated_text

    def _setup_provider_env(
        self,
        provider_type: str,
        prov_cfg: Any,
        litellm_params: Dict[str, Any],
    ) -> None:
        """Set up environment and params for a specific provider."""
        if provider_type == "openai":
            if prov_cfg.api_key:
                os.environ["OPENAI_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["OPENAI_BASE_URL"] = prov_cfg.api_base
        elif provider_type == "anthropic":
            if prov_cfg.api_key:
                os.environ["ANTHROPIC_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["ANTHROPIC_API_BASE"] = normalize_api_base(provider_type, prov_cfg.api_base) or prov_cfg.api_base
            # MiniMax Anthropic-compatible endpoint requires Bearer auth header.
            if prov_cfg.api_key and is_minimax_anthropic_base(prov_cfg.api_base):
                existing_headers: Dict[str, Any] = {}
                try:
                    raw = litellm_params.get("extra_headers")
                    if isinstance(raw, dict):
                        existing_headers = dict(raw)
                except Exception:
                    pass
                existing_headers["Authorization"] = f"Bearer {prov_cfg.api_key}"
                litellm_params["extra_headers"] = existing_headers
        elif provider_type == "xai":
            if prov_cfg.api_key:
                os.environ["XAI_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["XAI_API_BASE"] = prov_cfg.api_base
        elif provider_type == "deepseek":
            if prov_cfg.api_key:
                os.environ["DEEPSEEK_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["DEEPSEEK_API_BASE"] = prov_cfg.api_base
        elif provider_type == "minimax":
            if prov_cfg.api_key:
                os.environ["MINIMAX_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["MINIMAX_API_BASE"] = prov_cfg.api_base
        elif provider_type == "zai":
            if prov_cfg.api_key:
                os.environ["ZAI_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["ZAI_API_BASE"] = prov_cfg.api_base
        elif provider_type == "moonshot":
            if prov_cfg.api_key:
                os.environ["MOONSHOT_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["MOONSHOT_API_BASE"] = prov_cfg.api_base
        elif provider_type == "azure":
            if prov_cfg.api_key:
                os.environ["AZURE_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["AZURE_API_BASE"] = prov_cfg.api_base
            if prov_cfg.api_version:
                os.environ["AZURE_API_VERSION"] = prov_cfg.api_version
            os.environ["AZURE_API_TYPE"] = "azure"
        elif provider_type == "openrouter":
            if prov_cfg.api_key:
                os.environ["OPENROUTER_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                os.environ["OPENROUTER_API_BASE"] = prov_cfg.api_base
        elif provider_type == "gemini":
            if prov_cfg.api_key:
                os.environ["GEMINI_API_KEY"] = prov_cfg.api_key
                os.environ["GOOGLE_API_KEY"] = prov_cfg.api_key
            if prov_cfg.api_base:
                normalized = normalize_api_base(provider_type, prov_cfg.api_base)
                if normalized:
                    os.environ["GEMINI_API_BASE"] = normalized
        elif provider_type == "github_copilot":
            self._setup_github_copilot(litellm_params)
        elif provider_type == "openai_codex":
            self._setup_openai_codex(litellm_params)

        # Remove stale headers
        litellm_params.pop("headers", None)

        # Inject api_key for providers that need it at call-time
        if provider_type in (
            "openai",
            "anthropic",
            "xai",
            "deepseek",
            "minimax",
            "zai",
            "moonshot",
            "openrouter",
            "gemini",
        ) and prov_cfg.api_key:
            litellm_params["api_key"] = prov_cfg.api_key

        # Set effective api_base (skip for auth-based providers that set it themselves)
        if provider_type not in ("github_copilot", "openai_codex"):
            eff_api_base = normalize_api_base(provider_type, prov_cfg.api_base)
            if eff_api_base:
                litellm_params["api_base"] = eff_api_base
            else:
                litellm_params.pop("api_base", None)

    def _setup_github_copilot(self, litellm_params: Dict[str, Any]) -> None:
        """Set up GitHub Copilot specific configuration."""
        token_dir = setup_github_copilot_env(self.config_manager.config_path.parent)
        if not token_dir:
            raise RuntimeError("Failed to set up Copilot token directory")

        # Ensure authenticated
        if not check_copilot_authenticated(token_dir):
            raise RuntimeError(
                "GitHub Copilot is not authenticated. "
                "Open Settings → Remote LLM → GitHub Copilot and click Authenticate."
            )

        # Do not pass api_base for Copilot
        litellm_params.pop("api_base", None)

        # Add required IDE headers
        existing_headers: Dict[str, Any] = {}
        try:
            raw = litellm_params.get("extra_headers")
            if isinstance(raw, dict):
                existing_headers = dict(raw)
        except Exception:
            pass

        litellm_params["extra_headers"] = get_copilot_ide_headers(existing_headers)

        # Strip params that Copilot rejects
        for k in ["response_format", "reasoning_effort", "thinking"]:
            litellm_params.pop(k, None)

    def _setup_openai_codex(self, litellm_params: Dict[str, Any]) -> None:
        """Set up OpenAI Codex (ChatGPT Subscription) configuration.

        Uses LiteLLM's native ``chatgpt`` provider which automatically handles
        the ChatGPT backend API format (store=false, instructions field, stripping
        unsupported params like max_tokens/metadata).

        Auth tokens are managed by our own OAuth device flow and stored in the
        ``openai_codex/`` token directory.  We point LiteLLM's ``CHATGPT_TOKEN_DIR``
        and ``CHATGPT_AUTH_FILE`` env vars at our token file so the native provider
        can read the access token.
        """
        token_dir = setup_openai_codex_env(self.config_manager.config_path.parent)
        if not token_dir:
            raise RuntimeError("Failed to set up Codex token directory")

        # Ensure authenticated
        if not check_codex_authenticated(token_dir):
            raise RuntimeError(
                "ChatGPT Subscription is not authenticated. "
                "Open Settings → Remote LLM → ChatGPT Subscription and click Authenticate."
            )

        # Get access token (auto-refreshes if expired)
        access_token = get_codex_access_token(token_dir)
        if not access_token:
            raise RuntimeError(
                "ChatGPT Subscription access token expired or invalid. "
                "Open Settings → Remote LLM → ChatGPT Subscription and click Authenticate again."
            )

        # Point LiteLLM's native chatgpt provider at our token file.
        # CHATGPT_TOKEN_DIR + CHATGPT_AUTH_FILE tell the provider where to read the token.
        os.environ["CHATGPT_TOKEN_DIR"] = token_dir
        os.environ["CHATGPT_AUTH_FILE"] = "auth.json"
        try:
            from .env import ensure_chatgpt_auth_file

            ensure_chatgpt_auth_file(token_dir)
        except Exception:
            pass

        # Override LiteLLM's default Codex CLI system prompt with a concise one
        # appropriate for Nowledge's knowledge-graph extraction use case.
        os.environ.setdefault(
            "CHATGPT_DEFAULT_INSTRUCTIONS",
            "You are a helpful assistant.",
        )

        # Also set OPENAI_API_KEY as fallback — some LiteLLM code paths check it.
        os.environ["OPENAI_API_KEY"] = access_token
        litellm_params["api_key"] = access_token

        # Don't set api_base — the native chatgpt provider knows its own endpoint.
        litellm_params.pop("api_base", None)

        # Transform model prefix: openai_codex/X → chatgpt/X
        # LiteLLM's native chatgpt provider uses the chatgpt/ prefix for routing.
        model = litellm_params.get("model", "")
        if model.startswith("openai_codex/"):
            raw_model = model[len("openai_codex/"):]
            litellm_params["model"] = f"chatgpt/{raw_model}"

        # Strip params that the ChatGPT backend rejects (native provider also strips
        # these, but be defensive).
        for k in ["response_format", "reasoning_effort", "thinking"]:
            litellm_params.pop(k, None)

    async def close(self) -> None:
        """Cleanup the provider."""
        self._initialized = False
        logger.info("LiteLLM provider closed")


# Export OpenAI client for validation module
def get_openai_client_class() -> Any:
    """Get the OpenAI client class (may be LangFuse-wrapped)."""
    _ensure_litellm_loaded()
    return _OpenAIClient
