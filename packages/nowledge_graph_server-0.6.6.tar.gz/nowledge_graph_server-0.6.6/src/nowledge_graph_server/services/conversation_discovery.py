"""Conversation discovery service for finding AI agent conversation files.

This module has been refactored into a modular structure under discovery/.
This file re-exports all public APIs for backward compatibility.

Module structure:
- discovery/base.py: ConversationFile dataclass and path utilities
- discovery/claude.py: Claude Code discovery
- discovery/codex.py: Codex CLI discovery
- discovery/cursor.py: Cursor IDE discovery
- discovery/opencode.py: OpenCode CLI discovery
- discovery/service.py: Main ConversationDiscoveryService
"""

# Re-export all public APIs from the discovery module
from nowledge_graph_server.services.discovery import (
    ConversationFile,
    ConversationDiscoveryService,
    decode_project_path_enhanced,
    decode_project_path_windows,
)

__all__ = [
    "ConversationFile",
    "ConversationDiscoveryService",
    "decode_project_path_enhanced",
    "decode_project_path_windows",
]
