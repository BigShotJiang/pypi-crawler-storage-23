"""Source storage service — file operations for ~/ai-now/sources/.

Handles:
- Copying uploaded files into per-source directories
- Writing parsed markdown alongside originals
- Writing .meta.json for each source
- Managing .versions/ for historical revisions
- SHA-256 hashing for dedup/change detection
"""

from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

import structlog

from nowledge_graph_server.agent.paths import get_sources_home

logger = structlog.get_logger(__name__)


def _generate_source_id() -> str:
    """Generate a unique source ID."""
    import uuid

    short = uuid.uuid4().hex[:8]
    return f"src_{short}"


def sha256_file(file_path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    """Compute SHA-256 hash of bytes."""
    return hashlib.sha256(data).hexdigest()


class SourceStorageService:
    """Manages source files on disk in ~/ai-now/sources/."""

    def __init__(self, sources_root: Optional[Path] = None):
        self.sources_root = sources_root or get_sources_home()

    def _ensure_root(self) -> None:
        self.sources_root.mkdir(parents=True, exist_ok=True)

    def source_dir(self, source_id: str) -> Path:
        """Get the directory for a specific source."""
        return self.sources_root / source_id

    def ingest_file(
        self,
        file_path: Path,
        source_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Copy an uploaded file into the source storage.

        Returns dict with: source_id, file_path, sha256, size_bytes, original_name
        """
        self._ensure_root()

        if not file_path.exists():
            raise FileNotFoundError(f"Source file not found: {file_path}")

        sid = source_id or _generate_source_id()
        dest_dir = self.source_dir(sid)
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Copy the raw file
        dest_file = dest_dir / file_path.name
        shutil.copy2(file_path, dest_file)

        content_hash = sha256_file(dest_file)
        size_bytes = dest_file.stat().st_size

        # Write .meta.json
        meta = {
            "source_id": sid,
            "source_type": "file",
            "original_name": file_path.name,
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "ingested_at": datetime.now(timezone.utc).isoformat(),
            **(metadata or {}),
        }
        self._write_meta(sid, meta)

        logger.info(
            "Ingested file",
            source_id=sid,
            name=file_path.name,
            size=size_bytes,
        )

        return {
            "source_id": sid,
            "file_path": str(dest_file),
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "original_name": file_path.name,
        }

    def ingest_url(
        self,
        url: str,
        html_content: str,
        title: Optional[str] = None,
        source_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Store fetched URL content.

        Returns dict with: source_id, sha256, size_bytes, original_name
        """
        self._ensure_root()

        sid = source_id or _generate_source_id()
        dest_dir = self.source_dir(sid)
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Derive a safe filename from title or URL
        safe_name = _safe_filename(title or url)
        html_path = dest_dir / f"{safe_name}.html"
        html_path.write_text(html_content, encoding="utf-8")

        content_hash = sha256_bytes(html_content.encode("utf-8"))
        size_bytes = len(html_content.encode("utf-8"))

        meta = {
            "source_id": sid,
            "source_type": "url",
            "source_url": url,
            "original_name": title or url,
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            **(metadata or {}),
        }
        self._write_meta(sid, meta)

        logger.info("Ingested URL", source_id=sid, url=url)

        return {
            "source_id": sid,
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "original_name": title or url,
        }

    def ingest_url_file(
        self,
        url: str,
        file_content: bytes,
        filename: Optional[str] = None,
        mime_type: Optional[str] = None,
        source_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Store fetched URL content as a raw file (e.g. direct PDF URL)."""
        self._ensure_root()

        sid = source_id or _generate_source_id()
        dest_dir = self.source_dir(sid)
        dest_dir.mkdir(parents=True, exist_ok=True)

        raw_name = filename or "download"
        raw_path = Path(raw_name)
        stem = _safe_filename(raw_path.stem or "download")
        ext = raw_path.suffix.lower() or _extension_from_mime(mime_type)
        if not ext:
            ext = ".bin"

        dest_file = dest_dir / f"{stem}{ext}"
        dest_file.write_bytes(file_content)

        content_hash = sha256_bytes(file_content)
        size_bytes = len(file_content)
        original_name = raw_path.name if raw_path.name else dest_file.name

        meta = {
            "source_id": sid,
            "source_type": "url",
            "source_url": url,
            "original_name": original_name,
            "mime_type": mime_type or "",
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            **(metadata or {}),
        }
        self._write_meta(sid, meta)

        logger.info(
            "Ingested URL file",
            source_id=sid,
            url=url,
            name=original_name,
            mime_type=mime_type,
        )

        return {
            "source_id": sid,
            "file_path": str(dest_file),
            "sha256": content_hash,
            "size_bytes": size_bytes,
            "original_name": original_name,
        }

    def write_parsed(self, source_id: str, parsed_markdown: str, stem: Optional[str] = None) -> Path:
        """Write parsed markdown alongside the original file.

        Returns path to the .md file.
        """
        dest_dir = self.source_dir(source_id)
        dest_dir.mkdir(parents=True, exist_ok=True)

        name = stem or "parsed"
        md_path = dest_dir / f"{name}.md"
        md_path.write_text(parsed_markdown, encoding="utf-8")

        logger.debug("Wrote parsed markdown", source_id=source_id, path=str(md_path))
        return md_path

    def archive_version(self, source_id: str, version: int) -> Optional[Path]:
        """Move current source files to .versions/ before replacing with new version."""
        src_dir = self.source_dir(source_id)
        if not src_dir.exists():
            return None

        versions_dir = self.sources_root / ".versions" / source_id
        version_dir = versions_dir / f"v{version}_{datetime.now(timezone.utc).strftime('%Y-%m-%d')}"
        version_dir.mkdir(parents=True, exist_ok=True)

        # Copy all non-hidden files (not .meta.json)
        for item in src_dir.iterdir():
            if not item.name.startswith("."):
                shutil.copy2(item, version_dir / item.name)

        logger.info("Archived version", source_id=source_id, version=version)
        return version_dir

    def read_meta(self, source_id: str) -> Optional[Dict[str, Any]]:
        """Read .meta.json for a source."""
        meta_path = self.source_dir(source_id) / ".meta.json"
        if meta_path.exists():
            return json.loads(meta_path.read_text(encoding="utf-8"))
        return None

    def _write_meta(self, source_id: str, meta: Dict[str, Any]) -> None:
        """Write or update .meta.json."""
        meta_path = self.source_dir(source_id) / ".meta.json"
        meta_path.write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")

    def get_parsed_path(self, source_id: str) -> Optional[Path]:
        """Find the parsed .md file for a source."""
        src_dir = self.source_dir(source_id)
        if not src_dir.exists():
            return None

        md_files = list(src_dir.glob("*.md"))
        return md_files[0] if md_files else None

    def get_raw_path(self, source_id: str) -> Optional[Path]:
        """Find the original raw file for a source."""
        src_dir = self.source_dir(source_id)
        if not src_dir.exists():
            return None

        for item in src_dir.iterdir():
            if not item.name.startswith(".") and item.suffix != ".md":
                return item
        return None

    def delete_source_dir(self, source_id: str) -> bool:
        """Delete a source's directory and all its contents (raw, parsed, images, meta).

        Also removes version archives if present.
        """
        deleted = False

        # Remove main source directory
        source_dir = self.source_dir(source_id)
        if source_dir.exists():
            shutil.rmtree(source_dir)
            logger.info("Deleted source directory", source_id=source_id, path=str(source_dir))
            deleted = True

        # Remove version archives
        versions_dir = self.sources_root / ".versions" / source_id
        if versions_dir.exists():
            shutil.rmtree(versions_dir)
            logger.info("Deleted source version archives", source_id=source_id)
            deleted = True

        return deleted


def _safe_filename(name: str, max_len: int = 60) -> str:
    """Convert a name/URL into a safe filename stem."""
    import re

    # Strip protocol
    name = re.sub(r"^https?://", "", name)
    # Replace unsafe chars
    name = re.sub(r"[^\w\s\-.]", "-", name)
    # Collapse runs
    name = re.sub(r"[-\s]+", "-", name).strip("-")
    return name[:max_len] or "source"


def _extension_from_mime(mime_type: Optional[str]) -> str:
    """Best-effort file extension mapping for fetched URL files."""
    if not mime_type:
        return ""
    normalized = mime_type.split(";", 1)[0].strip().lower()
    mapping = {
        "application/pdf": ".pdf",
        "text/html": ".html",
        "text/plain": ".txt",
        "text/markdown": ".md",
        "application/json": ".json",
        "text/csv": ".csv",
    }
    return mapping.get(normalized, "")
