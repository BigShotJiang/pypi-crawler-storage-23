"""
Optimized Level 2 prompts using focused JSON outputs.
"""

# Step 1: Topic + Entity Extraction
LEVEL2_TOPIC_ENTITY_EXTRACTION = """Extract what's important and list key entities from this text.

Focus on:
- Main subjects and key concepts
- Specific names (people, tools, technologies, methods)
- Important relationships or decisions

Skip:
- Generic words like "system", "approach", "method" without specifics
- Common verbs and adjectives
- Minor details

Keep entities in ORIGINAL LANGUAGE - don't translate!

EXAMPLES:

Text: "Marie Curie discovered radium at University of Paris in 1898, revolutionizing our understanding of radioactivity."
JSON: {{"topics":["Marie Curie discovered radium","radioactivity research breakthrough"],"entities":["Marie Curie","radium","University of Paris","radioactivity"]}}

Text: "昨天在星巴克喝咖啡时，我和李明讨论了新的机器学习项目，决定使用PyTorch框架。"
JSON: {{"topics":["讨论机器学习项目","决定使用PyTorch框架"],"entities":["李明","机器学习项目","PyTorch"]}}

Text: "The BERT model uses transformer architecture with self-attention mechanisms to process text bidirectionally."
JSON: {{"topics":["BERT model architecture","transformer with self-attention"],"entities":["BERT","transformer architecture","self-attention mechanisms"]}}

Text: {text}
JSON:"""

# Step 2: Entity Analysis with typing and descriptions
LEVEL2_ENTITY_ANALYSIS = """Analyze each entity - determine type and write a brief description.

Entity types: PERSON, ORGANIZATION, LOCATION, TOOL, MATERIAL, CONCEPT, METHOD, EVENT, SYSTEM, DOCUMENT, PROJECT, OTHER

Rules:
- Give higher confidence (0.8-1.0) to specific, named entities
- Give lower confidence (0.5-0.7) to generic or vague entities
- Keep descriptions brief and in the SAME LANGUAGE as the entity

EXAMPLES:

Entities: ["Marie Curie", "radium", "University of Paris"]
Context: "Marie Curie discovered radium at University of Paris in 1898"
JSON: {{"entities":[{{"name":"Marie Curie","type":"PERSON","description":"Scientist who discovered radium","confidence":0.9}},{{"name":"radium","type":"MATERIAL","description":"Radioactive element","confidence":0.9}},{{"name":"University of Paris","type":"ORGANIZATION","description":"Research institution","confidence":0.8}}]}}

Entities: ["李明", "机器学习项目", "PyTorch"]
Context: "我和李明讨论了新的机器学习项目，决定使用PyTorch框架"
JSON: {{"entities":[{{"name":"李明","type":"PERSON","description":"项目讨论者","confidence":0.8}},{{"name":"机器学习项目","type":"PROJECT","description":"新ML项目","confidence":0.7}},{{"name":"PyTorch","type":"TOOL","description":"深度学习框架","confidence":0.9}}]}}

Entities: {entities}
Context: {context}
JSON:"""

# Step 3: Relationship Detection with Context
LEVEL2_RELATIONSHIP_DETECTION = """Find how these entities are connected. Include the text evidence.

Relationship types: USES, CREATES, WORKS_WITH, BELONGS_TO, LOCATED_AT, DEPENDS_ON, RELATED_TO, CONTAINS, AFFECTS, ENABLES, IMPLEMENTS, DISCOVERS, DISCUSSES, DECIDES

EXAMPLES:

Entities: ["Marie Curie", "radium", "University of Paris"]
Text: "Marie Curie discovered radium at University of Paris in 1898"
JSON: {{"relationships":[{{"source":"Marie Curie","target":"radium","relation":"DISCOVERS","context":"Marie Curie discovered radium","confidence":0.9}},{{"source":"Marie Curie","target":"University of Paris","relation":"WORKS_WITH","context":"at University of Paris","confidence":0.8}}]}}

Entities: ["李明", "机器学习项目", "PyTorch框架", "星巴克"]
Text: "在星巴克喝咖啡时，我和李明讨论了新的机器学习项目，决定使用PyTorch框架"
JSON: {{"relationships":[{{"source":"李明","target":"机器学习项目","relation":"DISCUSSES","context":"李明讨论了新的机器学习项目","confidence":0.8}},{{"source":"机器学习项目","target":"PyTorch框架","relation":"USES","context":"机器学习项目，决定使用PyTorch框架","confidence":0.9}},{{"source":"李明","target":"星巴克","relation":"LOCATED_AT","context":"在星巴克喝咖啡时，我和李明","confidence":0.7}}]}}

Entities: {entities}
Text: {text}
JSON:"""

# Quality refinement prompt
LEVEL2_QUALITY_REFINEMENT = """Review these extracted entities and filter to only the MOST IMPORTANT ones.

Current entities:
{entities_json}

Rules for importance:
- Keep entities that are CENTRAL to the main topic
- Keep entities mentioned multiple times or in key contexts
- Remove generic terms (e.g., "system", "method", "approach" without specifics)
- Remove overly specific details unless they're crucial
- Aim for 5-10 most significant entities

Return filtered entities in same JSON format:
{{"entities":[...filtered list...]}}"""

# Relationship importance prompt
LEVEL2_RELATIONSHIP_REFINEMENT = """Review these relationships and keep only the meaningful ones.

Current relationships:
{relationships_json}

Keep relationships that:
- Show important connections between key entities
- Have clear evidence in the text
- Add value to understanding the memory

Remove relationships that:
- Are too vague or generic
- Have weak evidence
- Connect to unimportant entities

Return filtered relationships in same JSON format:
{{"relationships":[...filtered list...]}}"""

# Fallback prompt when main extraction fails
LEVEL2_SIMPLE_EXTRACTION = """Extract the most important facts from this text.

WHO is mentioned? (people, organizations)
WHAT is discussed? (objects, concepts, tools)
WHERE does it happen? (places, locations)
WHAT happens? (actions, relationships)

Text: {text}

Answer in JSON:
{{"who":[],"what":[],"where":[],"actions":[]}}"""
