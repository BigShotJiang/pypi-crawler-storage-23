"""Session persistence service for saving coding sessions as conversation threads.

This service provides the core logic for persisting Claude Code and Codex sessions.
It is used by both the MCP tool and the REST API endpoint.
"""

import json
import os
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.core.thread_operations import ThreadOperations
from nowledge_graph_server.tools.thread_file_handler import ThreadFileHandler
from nowledge_graph_server.utils.progress_logger import log_data_change

logger = structlog.get_logger(__name__)


@dataclass
class SessionInfo:
    """Information about a discovered session."""

    file: Path
    session_id: str
    user_messages: int
    assistant_messages: int
    total_lines: int
    mtime: float
    last_message_time: Optional[float] = None
    last_message_timestamp: Optional[str] = None
    seconds_since_modification: float = 0.0
    cwd: Optional[str] = None  # For Codex


@dataclass
class PersistResult:
    """Result of persisting a single session."""

    action: str  # "created" or "appended"
    session_id: str
    thread_id: str
    message_count: int
    messages_added: int = 0
    total_messages: int = 0
    file: str = ""
    user_messages: int = 0
    assistant_messages: int = 0


@dataclass
class SessionPersistenceResponse:
    """Response from session persistence operation."""

    status: str
    client: str
    project_path: str
    persist_mode: str
    results: List[Dict[str, Any]]
    error: Optional[str] = None
    hint: Optional[str] = None


class SessionPersistenceService:
    """Service for persisting coding sessions as conversation threads."""

    def __init__(self, thread_operations: ThreadOperations):
        """Initialize with thread operations."""
        self.thread_operations = thread_operations
        self.file_handler = ThreadFileHandler(thread_operations)

    async def persist_session(
        self,
        client: str,
        project_path: str,
        persist_mode: str = "current",
        session_id: Optional[str] = None,
        summary: Optional[str] = None,
        truncate_large_content: bool = False,
    ) -> SessionPersistenceResponse:
        """Persist coding session(s) as conversation thread(s).

        Args:
            client: Client type ("claude-code" or "codex")
            project_path: Project working directory path
            persist_mode: "current" (most recent) or "all" (all project sessions)
            session_id: Optional session ID (Codex only)
            summary: Optional user-provided summary
            truncate_large_content: Whether to truncate large tool results >10KB

        Returns:
            SessionPersistenceResponse with operation results
        """
        if client not in ["claude-code", "codex"]:
            return SessionPersistenceResponse(
                status="error",
                client=client,
                project_path=project_path,
                persist_mode=persist_mode,
                results=[],
                error=f"Unsupported client: {client}. Supported: claude-code, codex",
            )

        if client == "claude-code":
            return await self._persist_claude_code_sessions(
                project_path=project_path,
                persist_mode=persist_mode,
                summary=summary,
                truncate_large_content=truncate_large_content,
            )
        else:  # codex
            return await self._persist_codex_sessions(
                project_path=project_path,
                persist_mode=persist_mode,
                session_id=session_id,
                summary=summary,
                truncate_large_content=truncate_large_content,
            )

    async def _persist_claude_code_sessions(
        self,
        project_path: str,
        persist_mode: str,
        summary: Optional[str],
        truncate_large_content: bool,
    ) -> SessionPersistenceResponse:
        """Persist Claude Code sessions for a project."""
        # Encode project path to find Claude session directory
        encoded_path = project_path.replace(os.sep, "-")
        if encoded_path.startswith("-"):
            encoded_path = encoded_path[1:]
        encoded_path = f"-{encoded_path}"

        claude_base = Path.home() / ".claude" / "projects" / encoded_path

        if not claude_base.exists() or not claude_base.is_dir():
            return SessionPersistenceResponse(
                status="error",
                client="claude-code",
                project_path=project_path,
                persist_mode=persist_mode,
                results=[],
                error=f"Claude Code session directory not found for project: {project_path}",
                hint="Make sure Claude Code has created sessions for this project",
            )

        # Find and analyze session files
        all_session_files = list(claude_base.glob("*.jsonl"))
        valid_sessions = self._analyze_claude_sessions(all_session_files)

        if not valid_sessions:
            return SessionPersistenceResponse(
                status="error",
                client="claude-code",
                project_path=project_path,
                persist_mode=persist_mode,
                results=[],
                error=f"No valid conversation sessions found in: {claude_base}",
                hint="Found session files, but they only contain snapshots or warmup messages",
            )

        # Determine which sessions to process
        sessions_to_process = (
            valid_sessions if persist_mode == "all" else [valid_sessions[0]]
        )

        logger.info(
            "Found valid Claude Code sessions",
            total_files=len(all_session_files),
            valid_sessions=len(valid_sessions),
            processing=len(sessions_to_process),
            mode=persist_mode,
        )

        # Process sessions
        results = []
        for i, session_info in enumerate(sessions_to_process):
            # Only apply summary to the most recent session
            session_summary = summary if i == 0 else None
            result = await self._process_claude_session(
                session_info=session_info,
                summary=session_summary,
                truncate_large_content=truncate_large_content,
            )
            results.append(result.__dict__)

        return SessionPersistenceResponse(
            status="success",
            client="claude-code",
            project_path=project_path,
            persist_mode=persist_mode,
            results=results,
        )

    def _analyze_claude_sessions(
        self, session_files: List[Path]
    ) -> List[SessionInfo]:
        """Analyze Claude Code session files and return valid conversations."""
        valid_sessions: List[SessionInfo] = []
        current_time = time.time()

        for session_file in session_files:
            try:
                with open(session_file) as f:
                    lines = f.readlines()

                user_messages = 0
                assistant_messages = 0
                last_message_time: Optional[float] = None
                last_message_timestamp: Optional[str] = None

                for line in lines:
                    try:
                        event = json.loads(line.strip())
                        event_type = event.get("type")

                        if event_type in ["file-history-snapshot", "summary"]:
                            continue

                        if event_type in ["user", "assistant"]:
                            timestamp_str = event.get("timestamp")
                            if timestamp_str:
                                try:
                                    dt = datetime.fromisoformat(
                                        timestamp_str.replace("Z", "+00:00")
                                    )
                                    timestamp_unix = dt.timestamp()
                                    if (
                                        last_message_time is None
                                        or timestamp_unix > last_message_time
                                    ):
                                        last_message_timestamp = timestamp_str
                                        last_message_time = timestamp_unix
                                except (ValueError, AttributeError):
                                    pass

                        if event_type == "user":
                            msg_content = event.get("message", {}).get("content", "")
                            if msg_content not in ["Warmup", "warmup"] and not event.get(
                                "isMeta"
                            ):
                                user_messages += 1
                        elif event_type == "assistant":
                            assistant_messages += 1
                    except json.JSONDecodeError:
                        continue

                # Only include sessions with real conversation
                if user_messages > 0 or assistant_messages > 1:
                    file_mtime = session_file.stat().st_mtime
                    valid_sessions.append(
                        SessionInfo(
                            file=session_file,
                            session_id=session_file.stem,
                            user_messages=user_messages,
                            assistant_messages=assistant_messages,
                            total_lines=len(lines),
                            mtime=file_mtime,
                            last_message_time=last_message_time,
                            last_message_timestamp=last_message_timestamp,
                            seconds_since_modification=current_time - file_mtime,
                        )
                    )
            except Exception as e:
                logger.warning(
                    "Failed to analyze session file",
                    file=session_file.name,
                    error=str(e),
                )
                continue

        # Sort by last message timestamp (most recent first)
        valid_sessions.sort(
            key=lambda s: (s.last_message_time or 0, s.mtime), reverse=True
        )
        return valid_sessions

    async def _process_claude_session(
        self,
        session_info: SessionInfo,
        summary: Optional[str],
        truncate_large_content: bool,
    ) -> PersistResult:
        """Process a single Claude Code session."""
        thread_id = f"claude-code-{session_info.session_id}"

        # Check if thread already exists
        existing_thread = await self.thread_operations.get_thread(thread_id)

        if existing_thread:
            # Thread exists - append new messages
            logger.info(
                "Thread exists, appending new messages",
                thread_id=thread_id,
                session_file=session_info.file.name,
            )

            append_result = await self.file_handler.append_messages_from_file(
                thread_id=thread_id,
                file_path=str(session_info.file),
                format="claude_code",
                deduplicate=True,
                truncate_large_content=truncate_large_content,
            )

            return PersistResult(
                action="appended",
                session_id=session_info.session_id,
                thread_id=thread_id,
                message_count=append_result["total_messages"],
                messages_added=append_result["messages_added"],
                total_messages=append_result["total_messages"],
                file=session_info.file.name,
            )
        else:
            # Create new thread
            logger.info(
                "Creating new thread from session",
                thread_id=thread_id,
                session_file=session_info.file.name,
            )

            create_result = await self.file_handler.create_thread_from_file(
                file_path=str(session_info.file),
                format="claude_code",
                thread_id_override=thread_id,
                summary=summary,
                truncate_large_content=truncate_large_content,
            )

            log_data_change(
                change_type="thread_created",
                entity_type="thread",
                entity_id=create_result.thread.thread_id,
                details={"source": "session_persistence", "format": "claude_code"},
            )

            return PersistResult(
                action="created",
                session_id=session_info.session_id,
                thread_id=create_result.thread.id,
                message_count=len(create_result.messages),
                file=session_info.file.name,
                user_messages=session_info.user_messages,
                assistant_messages=session_info.assistant_messages,
            )

    async def _persist_codex_sessions(
        self,
        project_path: str,
        persist_mode: str,
        session_id: Optional[str],
        summary: Optional[str],
        truncate_large_content: bool,
    ) -> SessionPersistenceResponse:
        """Persist Codex sessions for a project."""
        codex_base = Path.home() / ".codex" / "sessions"

        if not codex_base.exists() or not codex_base.is_dir():
            return SessionPersistenceResponse(
                status="error",
                client="codex",
                project_path=project_path,
                persist_mode=persist_mode,
                results=[],
                error=f"Codex sessions directory not found: {codex_base}",
                hint="Make sure Codex has created sessions",
            )

        # Find session files matching project_path
        all_session_files = list(codex_base.glob("**/rollout-*.jsonl"))
        valid_sessions = self._find_codex_sessions_for_project(
            all_session_files, project_path, session_id
        )

        if not valid_sessions:
            return SessionPersistenceResponse(
                status="error",
                client="codex",
                project_path=project_path,
                persist_mode=persist_mode,
                results=[],
                error=f"No Codex sessions found for project: {project_path}",
                hint="Make sure you have run Codex in this project directory",
            )

        # Determine which sessions to process
        sessions_to_process = (
            valid_sessions if persist_mode == "all" else [valid_sessions[0]]
        )

        logger.info(
            "Found valid Codex sessions",
            total_files=len(all_session_files),
            valid_sessions=len(valid_sessions),
            processing=len(sessions_to_process),
            mode=persist_mode,
        )

        # Process sessions
        results = []
        for i, session_info in enumerate(sessions_to_process):
            session_summary = summary if i == 0 else None
            result = await self._process_codex_session(
                session_info=session_info,
                summary=session_summary,
                truncate_large_content=truncate_large_content,
            )
            results.append(result.__dict__)

        return SessionPersistenceResponse(
            status="success",
            client="codex",
            project_path=project_path,
            persist_mode=persist_mode,
            results=results,
        )

    def _find_codex_sessions_for_project(
        self,
        session_files: List[Path],
        project_path: str,
        target_session_id: Optional[str],
    ) -> List[SessionInfo]:
        """Find Codex sessions matching the project path."""
        valid_sessions: List[SessionInfo] = []

        for session_file in session_files:
            try:
                with open(session_file) as f:
                    first_line = f.readline().strip()
                    if not first_line:
                        continue

                    session_meta = json.loads(first_line)
                    if session_meta.get("type") != "session_meta":
                        continue

                    payload = session_meta.get("payload", {})
                    session_cwd = payload.get("cwd", "")

                    # Match by cwd
                    if session_cwd == project_path:
                        # Extract session ID from filename
                        filename = session_file.stem
                        parts = filename.rsplit("-", 1)
                        file_session_id = parts[1] if len(parts) > 1 else filename

                        # Filter by session_id if provided
                        if target_session_id and file_session_id != target_session_id:
                            continue

                        valid_sessions.append(
                            SessionInfo(
                                file=session_file,
                                session_id=file_session_id,
                                user_messages=0,  # Not analyzed for Codex
                                assistant_messages=0,
                                total_lines=0,
                                mtime=session_file.stat().st_mtime,
                                cwd=session_cwd,
                            )
                        )
            except Exception as e:
                logger.warning(
                    "Failed to analyze Codex session file",
                    file=session_file.name,
                    error=str(e),
                )
                continue

        # Sort by modification time (most recent first)
        valid_sessions.sort(key=lambda s: s.mtime, reverse=True)
        return valid_sessions

    async def _process_codex_session(
        self,
        session_info: SessionInfo,
        summary: Optional[str],
        truncate_large_content: bool,
    ) -> PersistResult:
        """Process a single Codex session."""
        thread_id = f"codex-{session_info.session_id}"

        # Check if thread already exists
        existing_thread = await self.thread_operations.get_thread(thread_id)

        if existing_thread:
            # Thread exists - append new messages
            logger.info(
                "Thread exists, appending new messages",
                thread_id=thread_id,
                session_file=session_info.file.name,
            )

            append_result = await self.file_handler.append_messages_from_file(
                thread_id=thread_id,
                file_path=str(session_info.file),
                format="codex",
                deduplicate=True,
                truncate_large_content=truncate_large_content,
            )

            return PersistResult(
                action="appended",
                session_id=session_info.session_id,
                thread_id=thread_id,
                message_count=append_result["total_messages"],
                messages_added=append_result["messages_added"],
                total_messages=append_result["total_messages"],
                file=session_info.file.name,
            )
        else:
            # Create new thread
            logger.info(
                "Creating new thread from session",
                thread_id=thread_id,
                session_file=session_info.file.name,
            )

            create_result = await self.file_handler.create_thread_from_file(
                file_path=str(session_info.file),
                format="codex",
                thread_id_override=thread_id,
                summary=summary,
                truncate_large_content=truncate_large_content,
            )

            log_data_change(
                change_type="thread_created",
                entity_type="thread",
                entity_id=create_result.thread.thread_id,
                details={"source": "session_persistence", "format": "codex"},
            )

            return PersistResult(
                action="created",
                session_id=session_info.session_id,
                thread_id=create_result.thread.id,
                message_count=len(create_result.messages),
                file=session_info.file.name,
            )
