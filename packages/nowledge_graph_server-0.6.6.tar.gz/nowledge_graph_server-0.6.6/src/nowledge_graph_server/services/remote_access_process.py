"""Process-management helpers for remote access."""

from __future__ import annotations

from typing import Any, Optional

import psutil


def iter_managed_cloudflared_processes(
    *,
    owner: str,
    managed_env_key: str,
    owner_env_key: str,
    logger: Any,
) -> list[psutil.Process]:
    managed: list[psutil.Process] = []
    for process in psutil.process_iter(attrs=["pid", "name", "cmdline"]):
        try:
            name = (process.info.get("name") or "").lower()
            cmdline = process.info.get("cmdline") or []
            looks_like_cloudflared = "cloudflared" in name or any(
                "cloudflared" in str(part).lower() for part in cmdline
            )
            if not looks_like_cloudflared:
                continue

            env = process.environ()
            if env.get(managed_env_key) != "1":
                continue
            if env.get(owner_env_key) != owner:
                continue

            managed.append(process)
        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess,
        ):
            continue
        except Exception as exc:
            logger.debug(
                "Skipping process during managed cloudflared scan",
                error=str(exc),
            )
    return managed


def cleanup_orphaned_managed_cloudflared_processes(
    *,
    owner: str,
    managed_env_key: str,
    owner_env_key: str,
    logger: Any,
    current_pid: Optional[int] = None,
) -> int:
    cleaned = 0
    for process in iter_managed_cloudflared_processes(
        owner=owner,
        managed_env_key=managed_env_key,
        owner_env_key=owner_env_key,
        logger=logger,
    ):
        if current_pid and process.pid == current_pid:
            continue
        try:
            process.terminate()
            try:
                process.wait(timeout=5)
            except psutil.TimeoutExpired:
                process.kill()
                process.wait(timeout=3)
            cleaned += 1
        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess,
        ):
            continue
        except Exception as exc:
            logger.warning(
                "Failed to cleanup managed cloudflared process",
                pid=process.pid,
                error=str(exc),
            )
    return cleaned
