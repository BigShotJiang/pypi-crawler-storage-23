"""Embedding service for vector similarity search."""

import asyncio
from pathlib import Path
from typing import List, Optional, Union, Any, Tuple, Callable
import numpy as np
import structlog
import platform
from enum import Enum

logger = structlog.get_logger(__name__)

# Detect platform and import appropriate libraries
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"
IS_INTEL_MAC = platform.system() == "Darwin" and platform.machine() == "x86_64"
SHOULD_USE_ONNX = IS_WINDOWS or IS_LINUX or IS_INTEL_MAC

# Global download lock to prevent parallel model downloads corrupting cache
_GLOBAL_DOWNLOAD_LOCK: asyncio.Lock = asyncio.Lock()

# Global MLX inference lock - now uses shared lock from mlx_locks.py
#
# Problem:
#   Metal/MLX is NOT thread-safe for concurrent GPU command encoding.
#   When multiple search requests arrive simultaneously, they trigger parallel
#   embedding operations via run_in_executor(), causing:
#   - "failed assertion 'A command encoder is already encoding to this command buffer'"
#   - "failed assertion 'Completed handler provided after commit call'"
#   - Exit code 134 (Abort trap: 6)
#
# Solution:
#   All MLX operations (embeddings + LLM) share a single asyncio.Lock from mlx_locks.py.
#   This ensures only one Metal operation executes at a time across all services.
#
# See: https://github.com/ml-explore/mlx/issues/1335
from .mlx_locks import get_mlx_inference_lock


class DownloadSource(Enum):
    """Download source options for model caching."""

    HUGGINGFACE = "huggingface"
    MODELSCOPE = "modelscope"
    AUTO = "auto"  # Try modelscope first in China, otherwise huggingface


# Type definitions for better type safety
SentenceTransformerType = (
    Any  # Will be set to actual SentenceTransformer class when imported
)
MLXModelType = Any
MLXTokenizerType = Any


# Lazy imports for better startup performance
def _import_sentence_transformers():
    """Lazy import for sentence transformers (PyTorch fallback)."""
    try:
        from sentence_transformers import SentenceTransformer # type: ignore

        return SentenceTransformer
    except ImportError as e:
        logger.error("Failed to import sentence_transformers", error=str(e))
        raise


def _import_mlx_embeddings() -> Tuple[Optional[Callable[[str], Tuple[Any, Any]]], Optional[Any]]:
    """Lazy import for MLX embeddings (Apple Silicon optimized)."""
    try:
        from mlx_embeddings.utils import load
        import mlx.core as mx

        return load, mx
    except ImportError as e:
        logger.warning("MLX embeddings not available", error=str(e))
        return None, None


def _get_download_function(source: DownloadSource) -> Tuple[Callable[[str], str], str]:
    """Get download function based on specified source."""
    if source == DownloadSource.HUGGINGFACE:
        try:
            # Ensure offline mode is disabled and XET is disabled before importing huggingface_hub
            import os

            os.environ["HF_HUB_OFFLINE"] = "0"
            os.environ["TRANSFORMERS_OFFLINE"] = "0"
            if "HF_HUB_DISABLE_XET" not in os.environ:
                os.environ["HF_HUB_DISABLE_XET"] = "1"

            from huggingface_hub import snapshot_download # type: ignore
            import huggingface_hub.constants
            huggingface_hub.constants.HF_HUB_OFFLINE = False

            return snapshot_download, "huggingface" # type: ignore
        except ImportError:
            raise ImportError(
                "huggingface_hub not available. Install with: pip install huggingface_hub"
            )

    elif source == DownloadSource.MODELSCOPE:
        try:
            from modelscope.hub.snapshot_download import snapshot_download # type: ignore

            return snapshot_download, "modelscope" # type: ignore
        except ImportError:
            raise ImportError(
                "modelscope not available. Install with: pip install modelscope"
            )

    elif source == DownloadSource.AUTO:
        # Auto-detect based on region (timezone) like LLM service does
        from ..utils.model_cache import HuggingFaceMirrorManager

        region = HuggingFaceMirrorManager.detect_region()

        if region == "china":
            # Try ModelScope first in China regions
            try:
                from modelscope.hub.snapshot_download import snapshot_download # type: ignore

                logger.info(
                    "Using modelscope for model downloads (auto-detected China region)"
                )
                return snapshot_download, "modelscope" # type: ignore
            except ImportError:
                logger.warning("ModelScope not available, falling back to HuggingFace")
                try:
                    # Ensure offline mode is disabled and XET is disabled before importing huggingface_hub
                    import os

                    os.environ["HF_HUB_OFFLINE"] = "0"
                    os.environ["TRANSFORMERS_OFFLINE"] = "0"
                    if "HF_HUB_DISABLE_XET" not in os.environ:
                        os.environ["HF_HUB_DISABLE_XET"] = "1"

                    from huggingface_hub import snapshot_download # type: ignore
                    import huggingface_hub.constants
                    huggingface_hub.constants.HF_HUB_OFFLINE = False

                    logger.info(
                        "Using huggingface_hub for model downloads (ModelScope fallback)"
                    )
                    return snapshot_download, "huggingface" # type: ignore
                except ImportError:
                    raise ImportError(
                        "Neither modelscope nor huggingface_hub available. Install at least one."
                    )
        else:
            # Try HuggingFace first in non-China regions
            try:
                # Ensure offline mode is disabled and XET is disabled before importing huggingface_hub
                import os

                os.environ["HF_HUB_OFFLINE"] = "0"
                os.environ["TRANSFORMERS_OFFLINE"] = "0"
                if "HF_HUB_DISABLE_XET" not in os.environ:
                    os.environ["HF_HUB_DISABLE_XET"] = "1"

                from huggingface_hub import snapshot_download # type: ignore
                import huggingface_hub.constants
                huggingface_hub.constants.HF_HUB_OFFLINE = False

                logger.info(
                    "Using huggingface_hub for model downloads (auto-detected non-China region)"
                )
                return snapshot_download, "huggingface" # type: ignore
            except ImportError:
                logger.warning(
                    "HuggingFace Hub not available, falling back to ModelScope"
                )
                try:
                    from modelscope.hub.snapshot_download import snapshot_download # type: ignore

                    logger.info(
                        "Using modelscope for model downloads (HuggingFace fallback)"
                    )
                    return snapshot_download, "modelscope" # type: ignore
                except ImportError:
                    raise ImportError(
                        "Neither modelscope nor huggingface_hub available. Install at least one."
                    )

    else:
        raise ValueError(f"Unsupported download source: {source}")


class EmbeddingService:
    """Service for generating and managing embeddings.

    Backend selection:
    - macOS Apple Silicon: MLX
    - non-Apple-Silicon platforms: FastEmbed/ONNX
    - sentence-transformers fallback: only if the primary backend fails
    """

    def __init__(
        self,
        model_name: str = "",  # Will be set based on platform
        device: str = "cpu",
        dimension: int = 1024,
        cache_dir: Optional[str] = None,
        force_download: bool = False,
        cache_only: bool = True,
        prefer_mlx: bool = True,  # Prefer MLX on Apple Silicon
        download_source: DownloadSource = DownloadSource.AUTO,  # Configurable download source
    ):
        """Initialize embedding service.

        Args:
            model_name: Model name (MLX or HuggingFace format)
            device: Device for computation (cpu/cuda/mps)
            dimension: Embedding dimension
            cache_dir: Local cache directory for models
            force_download: Force download even if cached
            cache_only: Use only cached models (don't download)
            prefer_mlx: Prefer MLX implementation on Apple Silicon
            download_source: Download source preference (auto/modelscope/huggingface)
        """
        # Set platform-specific default model if not specified
        if not model_name:
            if IS_APPLE_SILICON:
                model_name = "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"
            else:
                model_name = "BAAI/bge-m3"
            logger.info("Using default embedding model for platform", model=model_name, is_apple_silicon=IS_APPLE_SILICON)

        self.model_name = model_name
            
        self.device = device
        self.dimension = dimension
        self.cache_dir = cache_dir
        self.force_download = force_download
        self.cache_only = cache_only
        self.prefer_mlx = prefer_mlx and IS_APPLE_SILICON
        self.download_source = download_source
        self._initialized: bool = False

        # Model instances (will be set during initialization)
        self.model: Optional[Union[SentenceTransformerType, MLXModelType]] = None
        self.tokenizer: Optional[MLXTokenizerType] = None
        self.is_mlx = False  # Track which backend is being used

        # Updated model dimensions - platform-specific defaults
        self.model_dimensions = {
            # Primary models (1024-dim)
            "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ": 1024,  # macOS Apple Silicon
            "BAAI/bge-m3": 1024,  # non-Apple-Silicon
            # Fallback models (smaller, faster)
            "sentence-transformers/all-MiniLM-L6-v2": 384,
            "sentence-transformers/all-mpnet-base-v2": 768,
            "paraphrase-multilingual-MiniLM-L12-v2": 384,
            "BAAI/bge-small-en-v1.5": 384,
            # Traditional models (aliases)
            "all-MiniLM-L6-v2": 384,
            "all-mpnet-base-v2": 768,
            "all-distilroberta-v1": 768,
            "multi-qa-MiniLM-L6-cos-v1": 384,
        }

    def _is_model_cached(self) -> bool:
        """Check if the model is cached locally."""

        try:
            # Determine cache directory
            if self.cache_dir:
                cache_path = Path(self.cache_dir)
            else:
                # Default HuggingFace cache directory
                raise ValueError("Cache directory required for MLX models")

            # For MLX models, check both HuggingFace format and direct path structure
            if self._is_mlx_model():
                # Check HuggingFace cache format: models--org--model
                hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
                hf_model_path = cache_path / hf_cache_name

                # Also check direct path format: model_name/
                direct_model_path = cache_path / self.model_name

                # Check both paths and validate using HuggingFace snapshot structure
                for candidate_path in [hf_model_path, direct_model_path]:
                    if candidate_path.exists():
                        logger.debug(
                            "Checking MLX model cache",
                            model=self.model_name,
                            cache_path=str(cache_path),
                            candidate_path=str(candidate_path),
                        )

                        # Validate using HuggingFace snapshot structure or direct structure
                        if self._validate_model_cache(candidate_path):
                            logger.info(
                                "Found cached MLX model",
                                model=self.model_name,
                                path=str(candidate_path),
                            )
                            return True
                        else:
                            logger.debug(
                                "MLX cache directory exists but validation failed",
                                path=str(candidate_path),
                            )

            # For sentence-transformers models, check HuggingFace cache format
            model_cache_paths = [
                cache_path / f"models--{self.model_name.replace('/', '--')}",
                cache_path
                / f"models--sentence-transformers--{self.model_name.replace('/', '--')}",
            ]

            for model_path in model_cache_paths:
                if model_path.exists():
                    logger.info(
                        "Found cached model",
                        model=self.model_name,
                        path=str(model_path),
                    )
                    return True

            # Also check if we can load the model without downloading
            try:
                # Try to load model in offline mode
                SentenceTransformerClass: SentenceTransformerType = _import_sentence_transformers()
                _ = SentenceTransformerClass(
                    self.model_name,
                    device=self.device,
                    cache_folder=self.cache_dir,
                    local_files_only=True,  # ✅ This prevents downloads
                )
                logger.info(
                    "Model successfully loaded in offline mode", model=self.model_name
                )
                return True
            except Exception as e:
                logger.debug(
                    "Model not available offline", model=self.model_name, error=str(e)
                )
                return False

        except Exception as e:
            logger.warning(
                "Failed to check model cache", model=self.model_name, error=str(e)
            )
            return False

    async def initialize(self) -> None:
        """Initialize the embedding model using platform-appropriate backend.
        
        - macOS (Apple Silicon): MLX
        - non-Apple-Silicon: ONNX Runtime
        - Fallback: sentence-transformers
        """

        try:
            logger.info(
                "Initializing embedding model",
                model=self.model_name,
                device=self.device,
                cache_only=self.cache_only,
                force_download=self.force_download,
                prefer_mlx=self.prefer_mlx,
                is_apple_silicon=IS_APPLE_SILICON,
                is_windows=IS_WINDOWS,
                is_linux=IS_LINUX,
                is_intel_mac=IS_INTEL_MAC,
                should_use_onnx=SHOULD_USE_ONNX,
            )

            # Use FastEmbed on non-Apple-Silicon (lightweight, uses ONNX internally)
            if SHOULD_USE_ONNX:
                try:
                    await self._initialize_fastembed()
                    return
                except Exception as e:
                    logger.warning("FastEmbed initialization failed, falling back to sentence-transformers", error=str(e))
                    # Fall through to sentence-transformers initialization

            # Try MLX first if preferred and on Apple Silicon
            if self.prefer_mlx and self._is_mlx_model():
                try:
                    await self._initialize_mlx()
                    return
                except Exception as e:
                    logger.warning("MLX initialization failed", error=str(e))
                    raise

            # Fallback to sentence-transformers (when ONNX/MLX initialization fails)
            try:
                await self._initialize_sentence_transformers()
                return
            except Exception as e:
                logger.warning("sentence-transformers initialization failed", error=str(e))
                raise

        except Exception as e:
            logger.error(
                "Failed to initialize embedding model",
                model=self.model_name,
                error=str(e),
            )
            raise

    def _is_mlx_model(self) -> bool:
        """Check if the model name suggests it's an MLX model."""
        return "mlx-community" in self.model_name or self.model_name.endswith("-mlx")

    def _validate_model_cache(self, cache_path: Path) -> bool:
        """
        Validate that a cached model directory contains required files.
        Supports both HuggingFace snapshot structure and direct model structure.
        """
        try:
            # Support both HF cache layout (snapshots/<hash>) and direct layout
            snapshots_dir = cache_path / "snapshots"
            candidate_dirs = []

            if snapshots_dir.exists():
                # HuggingFace cache structure: models--org--model/snapshots/<hash>/
                candidate_dirs = [d for d in snapshots_dir.iterdir() if d.is_dir()]
            else:
                # Direct structure: model files directly in cache_path
                candidate_dirs = [cache_path]

            for snapshot_dir in candidate_dirs:
                # Check for config files (flexible)
                has_config = (snapshot_dir / "config.json").exists() or (
                    snapshot_dir / "model_config.json"
                ).exists()

                # Check for weight files (multiple formats and naming patterns)
                has_single = (snapshot_dir / "model.safetensors").exists()
                has_sharded = any(
                    p.name.startswith("model-") and p.suffix == ".safetensors"
                    for p in snapshot_dir.iterdir()
                )
                has_weights_format = any(
                    p.name.startswith("weights.") and p.suffix == ".safetensors"
                    for p in snapshot_dir.iterdir()
                )
                has_mlx = any(p.suffix == ".mlx" for p in snapshot_dir.iterdir())
                has_pytorch = (snapshot_dir / "pytorch_model.bin").exists() or any(
                    p.name.startswith("pytorch_model") for p in snapshot_dir.iterdir()
                )
                has_weights = (
                    has_single
                    or has_sharded
                    or has_weights_format
                    or has_mlx
                    or has_pytorch
                )

                # Check for tokenizer files
                has_tokenizer = (snapshot_dir / "tokenizer.json").exists() or (
                    snapshot_dir / "tokenizer_config.json"
                ).exists()

                logger.debug(
                    "Model cache validation",
                    snapshot_dir=str(snapshot_dir),
                    has_config=has_config,
                    has_weights=has_weights,
                    has_tokenizer=has_tokenizer,
                )

                # Valid if has config and weights (tokenizer is optional for some models)
                if has_config and has_weights:
                    return True

            return False
        except Exception as e:
            logger.debug("Model cache validation failed", error=str(e))
            return False

    def _get_model_snapshot_path(self, cache_path: Path) -> Optional[Path]:
        """
        Get the actual model snapshot path from a cache directory.
        Returns the path to the directory containing model files.
        """
        try:
            # Support both HF cache layout (snapshots/<hash>) and direct layout
            snapshots_dir = cache_path / "snapshots"

            if snapshots_dir.exists():
                # HuggingFace cache structure: find the first valid snapshot
                for snapshot_dir in snapshots_dir.iterdir():
                    if snapshot_dir.is_dir() and self._validate_model_cache(
                        snapshot_dir
                    ):
                        return snapshot_dir
            else:
                # Direct structure: return cache_path if valid
                if self._validate_model_cache(cache_path):
                    return cache_path

            return None
        except Exception as e:
            logger.debug("Failed to get model snapshot path", error=str(e))
            return None

    async def _initialize_fastembed(self) -> None:
        """Initialize using FastEmbed (non-Apple-Silicon) - lightweight ONNX-based."""
        from .fastembed_onnx_service import FastEmbedONNXService
        
        logger.info("Initializing FastEmbed embedding model (ONNX-only downloads)", model=self.model_name)
        
        # Create FastEmbed service with explicit ONNX-only downloads
        fastembed_service = FastEmbedONNXService(
            model_name=self.model_name,
            cache_dir=self.cache_dir,
            cache_only=self.cache_only,
            download_source=self.download_source.value if hasattr(self.download_source, 'value') else str(self.download_source),
        )
        
        await fastembed_service.initialize()
        
        # Store the FastEmbed service as our model
        self.model = fastembed_service
        self.is_mlx = False  # Mark as not MLX
        self._initialized = True
        
        # Update dimension
        self.dimension = fastembed_service.dimension
        
        logger.info(
            "FastEmbed embedding model initialized successfully",
            model=self.model_name,
            dimension=self.dimension,
        )

    async def _initialize_mlx(self) -> None:
        """Initialize using MLX embeddings."""
        load_func, mx = _import_mlx_embeddings()
        if load_func is None or mx is None:
            raise RuntimeError("MLX embeddings not available")

        logger.info("Initializing MLX embedding model", model=self.model_name)

        # Check if model is cached
        model_path = await self._get_or_download_model()

        # Load MLX model
        loop = asyncio.get_event_loop()
        self.model, self.tokenizer = await loop.run_in_executor(
            None, lambda: load_func(model_path)
        )

        self.is_mlx = True
        self._initialized = True

        # Update dimension based on model
        expected_dim = self.model_dimensions.get(self.model_name, self.dimension)
        self.dimension = expected_dim

        logger.info(
            "MLX embedding model initialized successfully",
            model=self.model_name,
            dimension=self.dimension,
            model_path=model_path,
        )

    async def _initialize_sentence_transformers(self) -> None:
        """Initialize using sentence-transformers (PyTorch)."""
        SentenceTransformerClass = _import_sentence_transformers()

        logger.info("Initializing sentence-transformers model", model=self.model_name)

        # Check if model is cached when in offline mode
        if self.cache_only and not self.force_download:
            if not self._is_model_cached():
                cache_cmd = f"python -m nowledge_graph_server.utils.model_cache cache-embedding --model {self.model_name}"
                if self.cache_dir:
                    cache_cmd += f" --cache-dir {self.cache_dir}"

                error_msg = (
                    f"Embedding model '{self.model_name}' not found in cache and cache_only mode is enabled.\n"
                    f"Please cache the model first by running:\n"
                    f"  {cache_cmd}\n"
                    f"Or set embedding_cache_only=false in your configuration to download automatically."
                )
                logger.error(
                    "Embedding model not cached",
                    model=self.model_name,
                    cache_dir=self.cache_dir,
                    suggested_command=cache_cmd,
                )
                raise RuntimeError(error_msg)

        loop = asyncio.get_event_loop()
        self.model = await loop.run_in_executor(
            None,
            lambda: SentenceTransformerClass(
                self.model_name,
                device=self.device,
                cache_folder=self.cache_dir,
                local_files_only=self.cache_only,
            ),
        )

        self.is_mlx = False

        # Validate dimension
        if self.model:
            expected_dim = self.model_dimensions.get(self.model_name, self.dimension)
            actual_dim = self.model.get_sentence_embedding_dimension()
            if actual_dim != expected_dim:
                logger.warning(
                    "Model dimension mismatch",
                    expected=expected_dim,
                    actual=actual_dim,
                )

            self.dimension = actual_dim
            self._initialized = True
            logger.info(
                "Sentence-transformers model initialized successfully",
                model=self.model_name,
                dimension=self.dimension,
            )
        else:
            logger.warning("Failed to load model")
            raise RuntimeError("Failed to load sentence-transformers model")

    async def _get_or_download_model(self) -> str:
        """Get model path, downloading if necessary using modelscope or huggingface."""
        if not self.cache_dir:
            raise ValueError("Cache directory required for MLX models")

        cache_path = Path(self.cache_dir)

        # Check multiple possible cache locations in order of preference
        hf_cache_name = f"models--{self.model_name.replace('/', '--')}"

        # Possible cache locations:
        # 1. HuggingFace format in base cache: cache_dir/models--org--model/
        # 2. Direct ModelScope format: cache_dir/org/model/
        # 3. Mixed structure: cache_dir/org/model/models--org--model/ (corrupted cache)
        candidate_paths = [
            cache_path / hf_cache_name,  # HF format in base
            cache_path / self.model_name,  # ModelScope format
            cache_path / self.model_name / hf_cache_name,  # Mixed structure
        ]

        # Find the first valid cache path
        for candidate_path in candidate_paths:
            if candidate_path.exists():
                # Try to get a valid snapshot path from this candidate
                snapshot_path = self._get_model_snapshot_path(candidate_path)
                if snapshot_path:
                    logger.info(
                        "Found cached MLX model",
                        candidate_path=str(candidate_path),
                        snapshot_path=str(snapshot_path),
                    )
                    return str(snapshot_path)
                else:
                    logger.debug(
                        "Cache path exists but no valid model found",
                        path=str(candidate_path),
                    )

        # No valid cached model found
        if not self.force_download:
            logger.debug(
                "No valid cached model found in any location",
                checked_paths=[str(p) for p in candidate_paths],
            )

        # Default to HuggingFace format for new downloads
        _ = candidate_paths[0]  # HF format in base cache

        if self.cache_only:
            # Provide detailed information about all locations we checked
            cache_info = {
                "model": self.model_name,
                "base_cache_dir": str(cache_path),
                "cache_dir_exists": cache_path.exists(),
            }

            # Add info about each candidate path
            for i, candidate_path in enumerate(candidate_paths):
                cache_info[f"candidate_{i + 1}_path"] = str(candidate_path)
                cache_info[f"candidate_{i + 1}_exists"] = candidate_path.exists()
                if candidate_path.exists():
                    try:
                        cache_info[f"candidate_{i + 1}_contents"] = [ # type: ignore
                            str(p.name) for p in candidate_path.iterdir()
                        ]
                    except Exception:
                        cache_info[f"candidate_{i + 1}_contents"] = "error_reading"

            logger.error("Model not found in cache", **cache_info)

            candidate_paths_str = ", ".join(str(p) for p in candidate_paths)
            raise RuntimeError(
                f"Model {self.model_name} not cached and cache_only mode enabled. "
                f"Checked locations: {candidate_paths_str}"
            )

        # Download model using configured source with global lock to avoid parallel corruption
        logger.info(
            "Downloading MLX model",
            model=self.model_name,
            source=self.download_source.value,
        )
        download_func, source_name = _get_download_function(self.download_source)
        loop = asyncio.get_event_loop()
        try:
            async with _GLOBAL_DOWNLOAD_LOCK:
                model_path: str = await loop.run_in_executor( # type: ignore
                    None,
                    lambda: download_func(self.model_name, cache_dir=str(cache_path)) # type: ignore
                )
                logger.info(
                    "Downloaded MLX model successfully",
                    path=model_path,
                    source=source_name,
                )

            # Post-download validation to catch partial caches (more lenient)
            final_path = Path(model_path)
            has_config = (final_path / "config.json").exists() or (
                final_path / "model_config.json"
            ).exists()
            has_single = (final_path / "model.safetensors").exists()
            has_sharded = any(
                p.name.startswith("model-") and p.suffix == ".safetensors"
                for p in final_path.iterdir()
            )
            has_mlx = any(p.suffix == ".mlx" for p in final_path.iterdir())
            has_pytorch = (final_path / "pytorch_model.bin").exists() or any(
                p.name.startswith("pytorch_model") for p in final_path.iterdir()
            )
            has_tokenizer = (final_path / "tokenizer.json").exists() or (
                final_path / "tokenizer_config.json"
            ).exists()
            has_weights = has_single or has_sharded or has_mlx or has_pytorch

            logger.debug(
                "Post-download validation",
                path=str(final_path),
                has_config=has_config,
                has_weights=has_weights,
                has_tokenizer=has_tokenizer,
                files=[p.name for p in final_path.iterdir() if p.is_file()][:10],
            )

            # More lenient: config + (weights OR tokenizer)
            if not (has_config and (has_weights or has_tokenizer)):
                logger.error(
                    "Downloaded path missing essential files",
                    path=str(final_path),
                    has_config=has_config,
                    has_weights=has_weights,
                    has_tokenizer=has_tokenizer,
                    contents=[p.name for p in final_path.iterdir()][:20],
                )
                raise RuntimeError(
                    "Model appears partially downloaded (missing essential files). Please retry download."
                )

            return str(final_path)
        except Exception as e:
            logger.error(
                "Model download failed",
                model=self.model_name,
                source=source_name,
                error=str(e),
            )
            raise RuntimeError(f"Failed to download model from {source_name}: {e}")

    async def cleanup(self) -> None:
        """Cleanup resources."""
        if hasattr(self, "model") and self.model is not None:
            del self.model
        self._initialized = False
        logger.info("Embedding service cleaned up")

    async def embed_text(self, text: str, prefix: str = "query") -> List[float]:
        """Generate embedding for text using MLX or sentence-transformers.

        Args:
            text: Input text
            prefix: Prefix type - "query" for search queries, "passage" for documents
                    (used by some models like BGE-M3 for instruction-based embedding)

        Returns:
            Embedding vector as a list of floats
        """
        if not self._initialized:
            raise RuntimeError("Embedding service not initialized")

        if not text or not text.strip():
            return [0.0] * (self.dimension or 384)  # Use default dimension if None
        
        # CRITICAL: Truncate text to model's max length BEFORE embedding
        # Most embedding models have max_seq_length of 512-8192 tokens
        # We use a conservative limit and actual tokenizer to count tokens accurately
        MAX_TOKENS = 480  # Leave some room for special tokens and instruction prefixes
        
        # First do a rough character-based pre-truncation to avoid tokenizer errors
        # Chinese: ~1.5 tokens per char, English: ~0.25 tokens per char
        # Use conservative estimate: 2 chars per token for safety
        ESTIMATED_CHARS_PER_TOKEN = 2
        rough_max_chars = MAX_TOKENS * ESTIMATED_CHARS_PER_TOKEN
        
        if len(text) > rough_max_chars:
            text = text[:rough_max_chars]
            logger.debug(
                "Pre-truncated text before tokenization",
                original_length=len(text),
                rough_max_chars=rough_max_chars
            )
        
        try:
            # Now count actual tokens using the tokenizer (text is already roughly truncated)
            if self.is_mlx and self.tokenizer:
                # MLX tokenizer - encode without triggering model
                test_tokens = self.tokenizer.encode(text.strip())
                token_count = len(test_tokens)
            elif SHOULD_USE_ONNX and self.model and hasattr(self.model, 'tokenizer') and self.model.tokenizer:
                # ONNX tokenizer
                test_tokens = self.model.tokenizer.encode(text.strip(), add_special_tokens=False)
                token_count = len(test_tokens)
            elif self.model and hasattr(self.model, 'tokenizer'):
                # Sentence-transformers tokenizer
                test_tokens = self.model.tokenizer.encode(text.strip(), add_special_tokens=False)
                token_count = len(test_tokens)
            else:
                # Fallback to character approximation if no tokenizer available
                token_count = len(text) // ESTIMATED_CHARS_PER_TOKEN
            
            if token_count > MAX_TOKENS:
                # Need further truncation - use binary search
                logger.warning(
                    "Text still exceeds max token length after pre-truncation, refining",
                    current_tokens=token_count,
                    max_tokens=MAX_TOKENS
                )
                
                # Binary search for the right length
                left, right = 0, len(text)
                best_length = 0
                
                while left <= right:
                    mid = (left + right) // 2
                    truncated = text[:mid]
                    
                    # Count tokens of truncated text
                    if self.is_mlx and self.tokenizer:
                        test_tokens = self.tokenizer.encode(truncated)
                        test_count = len(test_tokens)
                    elif SHOULD_USE_ONNX and self.model and hasattr(self.model, 'tokenizer') and self.model.tokenizer:
                        test_tokens = self.model.tokenizer.encode(truncated, add_special_tokens=False)
                        test_count = len(test_tokens)
                    elif self.model and hasattr(self.model, 'tokenizer'):
                        test_tokens = self.model.tokenizer.encode(truncated, add_special_tokens=False)
                        test_count = len(test_tokens)
                    else:
                        test_count = mid // ESTIMATED_CHARS_PER_TOKEN
                    
                    if test_count <= MAX_TOKENS:
                        best_length = mid
                        left = mid + 1
                    else:
                        right = mid - 1
                
                text = text[:best_length]
                logger.info(
                    "Text truncated to fit token limit",
                    original_tokens=token_count,
                    final_tokens=test_count if 'test_count' in locals() else MAX_TOKENS,
                    final_chars=best_length,
                    max_tokens=MAX_TOKENS
                )
        except Exception as e:
            # If tokenization fails, fall back to character-based truncation
            logger.warning(f"Token counting failed, using character approximation: {e}")
            MAX_CHARS = 960  # 480 tokens * 2 chars/token
            if len(text) > MAX_CHARS:
                text = text[:MAX_CHARS]
                logger.warning(
                    "Text truncated using character approximation",
                    original_length=len(text),
                    truncated_length=MAX_CHARS
                )
        
        # Prepare text with instruction prefix if needed by the model
        prepared_text = self._prepare_text_with_prefix(text.strip(), prefix)

        try:
            # Check if model is a FastEmbed service (non-Apple-Silicon) or ONNX service
            if SHOULD_USE_ONNX and hasattr(self.model, 'embed_text'):
                logger.debug("Embedding text using FastEmbed/ONNX", text=prepared_text[:100])
                # ONNX services handle text preparation internally
                assert self.model is not None, "Model is None in ONNX embedding service"
                return await self.model.embed_text(text.strip(), prefix=prefix)
            elif self.is_mlx:
                logger.debug("Embedding text using MLX", text=prepared_text[:100])
                return await self._embed_text_mlx(prepared_text)
            else:
                logger.debug(
                    "Embedding text using sentence-transformers", text=prepared_text[:100]
                )
                return await self._embed_text_sentence_transformers(prepared_text)

        except Exception as e:
            backend = "onnx" if SHOULD_USE_ONNX else ("mlx" if self.is_mlx else "sentence_transformers")
            logger.error(
                "Failed to generate embedding",
                text=text[:100],
                error=str(e),
                backend=backend,
            )
            raise
    
    def _prepare_text_with_prefix(self, text: str, prefix: str = "query") -> str:
        """Add instruction prefix if needed by the model.

        Args:
            text: Input text
            prefix: "query" or "passage"

        Returns:
            Text with appropriate prefix for the model
        """
        # Most modern embedding models (Qwen3-Embedding, BGE-M3) handle instructions
        # internally or don't require explicit prefixes. Return text as-is.
        # The model's tokenizer/encoder will handle any needed formatting.
        return text

    async def _embed_text_mlx(self, text: str) -> List[float]:
        """Generate embedding using MLX.

        IMPORTANT: This method uses shared MLX lock to serialize Metal GPU operations.
        Metal is not thread-safe and concurrent command encoding causes crashes:
        "failed assertion 'A command encoder is already encoding to this command buffer'"
        """
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("MLX model or tokenizer not initialized")

        loop = asyncio.get_event_loop()

        def _encode_mlx() -> List[float]:
            # Based on your successful test:
            # from mlx_embeddings.utils import load
            # model, tokenizer = load(model_dir)
            # Model does the encoding directly, not tokenizer

            assert self.model is not None, "Model is None"

            try:
                # Correct mlx-embeddings usage pattern from documentation:
                # model, tokenizer = load(model_name)
                # input_ids = tokenizer.encode(text, return_tensors="mlx")
                # outputs = model(input_ids)
                # text_embeds = outputs.text_embeds  # mean pooled and normalized embeddings

                # logger.debug("Using correct MLX embeddings pattern",
                #            has_tokenizer=self.tokenizer is not None,
                #            model_type=type(self.model).__name__,
                #            tokenizer_type=type(self.tokenizer).__name__ if self.tokenizer else "None")

                if self.tokenizer is None:
                    raise RuntimeError("MLX tokenizer not available")

                # Step 1: Tokenize the text
                input_ids = self.tokenizer.encode(text, return_tensors="mlx")
                # logger.debug("Tokenized text",
                #            input_ids_type=type(input_ids).__name__,
                #            input_ids_shape=getattr(input_ids, 'shape', 'no_shape'))

                # Step 2: Get model outputs
                outputs = self.model(input_ids)
                # logger.debug("Model outputs",
                #            outputs_type=type(outputs).__name__,
                #            has_text_embeds=hasattr(outputs, 'text_embeds'))

                # Step 3: Extract embeddings (use text_embeds for mean pooled and normalized)
                if hasattr(outputs, "text_embeds"):
                    embedding = outputs.text_embeds
                    # logger.debug("Using text_embeds",
                    #            embedding_type=type(embedding).__name__,
                    #            embedding_shape=getattr(embedding, 'shape', 'no_shape'))
                elif hasattr(outputs, "last_hidden_state"):
                    # Fallback: use CLS token from last_hidden_state
                    embedding = outputs.last_hidden_state[:, 0, :]  # CLS token
                    # logger.debug("Using CLS token from last_hidden_state",
                    #            embedding_type=type(embedding).__name__,
                    #            embedding_shape=getattr(embedding, 'shape', 'no_shape'))
                else:
                    raise RuntimeError(
                        "Model outputs don't have text_embeds or last_hidden_state"
                    )

                # Convert to list of floats
                # logger.debug("Converting embedding to list",
                #            embedding_type=type(embedding).__name__,
                #            has_tolist=hasattr(embedding, 'tolist'),
                #            has_iter=hasattr(embedding, '__iter__'),
                #            is_string=isinstance(embedding, str))

                if isinstance(embedding, str):
                    raise RuntimeError(
                        f"Embedding returned string instead of array: {embedding[:100]}"
                    )
                elif hasattr(embedding, "tolist"):
                    # Handle 2D array (batch, features) - squeeze to 1D
                    embedding_list: List[float] = embedding.tolist()
                    if isinstance(embedding_list, list) and len(embedding_list) > 0: # type: ignore
                        if isinstance(embedding_list[0], list):
                            # 2D array: take first item (batch dimension)
                            return embedding_list[0]
                        else:
                            # Already 1D
                            return embedding_list
                    else:
                        return embedding_list
                elif hasattr(embedding, "__iter__"):
                    return [float(x) for x in embedding]
                else:
                    return [float(embedding)]

            except Exception as e:
                logger.error(
                    "MLX embedding generation failed", error=str(e), text=text[:50]
                )
                raise RuntimeError(f"MLX embedding failed: {e}")

        # Acquire MLX inference lock to prevent concurrent Metal GPU operations
        # This is critical for thread-safety on macOS with Metal
        mlx_lock = get_mlx_inference_lock()
        if mlx_lock is not None:
            async with mlx_lock:
                embedding = await loop.run_in_executor(None, _encode_mlx)
        else:
            # Non-macOS fallback (shouldn't reach here for MLX, but defensive)
            embedding = await loop.run_in_executor(None, _encode_mlx)

        # MLX-Embeddings text_embeds are already "mean pooled and normalized"
        # No additional normalization needed
        return [float(x) for x in embedding]

    async def _embed_text_sentence_transformers(self, text: str) -> List[float]:
        """Generate embedding using sentence-transformers (PyTorch)."""
        if self.model is None:
            raise RuntimeError("Sentence-transformers model not initialized")

        loop = asyncio.get_event_loop()
        model = self.model  # Capture to satisfy type checker
        assert model is not None, "Model should not be None after check"
        embedding = await loop.run_in_executor(
            None, lambda: model.encode(text, convert_to_tensor=False)
        )

        # Ensure embedding is a list of floats
        if isinstance(embedding, np.ndarray):
            embedding = embedding.tolist() # type: ignore

        # Normalize embedding to unit vector for consistent cosine distance behavior
        embedding_array = np.array(embedding, dtype=np.float32)
        norm = np.linalg.norm(embedding_array)
        if norm > 0:
            embedding_array = embedding_array / norm

        return [float(x) for x in embedding_array]

    async def embed_batch(self, texts: List[str]) -> List[List[float] | None]:
        """Generate embeddings for batch of texts using MLX or sentence-transformers.

        Args:
            texts: List of input texts

        Returns:
            List of embedding vectors
        """
        if not self._initialized:
            raise RuntimeError("Embedding service not initialized")

        if not texts:
            return []

        # Preallocate results list to preserve original length and ordering
        result: List[List[float] | None] = [None] * len(texts) # type: ignore

        # Record indices and values of non-empty inputs
        valid_indices = []
        valid_texts = []
        for idx, text in enumerate(texts):
            stripped = text.strip() if text else ""
            if stripped:
                valid_indices.append(idx)
                valid_texts.append(stripped)
            else:
                # Pre-fill empty entries with None (will be replaced with zero vector)
                result[idx] = None

        if not valid_texts:
            logger.warning("No valid texts to embed", texts=texts)
            # All inputs were empty - return zero vectors for all
            dimension = self.dimension or 384
            return [[0.0] * dimension for _ in texts]

        try:
            # Check if model is a FastEmbed service (non-Apple-Silicon) or ONNX service
            if SHOULD_USE_ONNX and hasattr(self.model, 'embed_batch'):
                assert self.model is not None, "Model is None in ONNX embedding service"
                embeddings = await self.model.embed_batch(valid_texts)
            elif self.is_mlx:
                embeddings = await self._embed_batch_mlx(valid_texts)
            else:
                embeddings = await self._embed_batch_sentence_transformers(valid_texts)

            # Infer dimension from first embedding if needed
            if embeddings:
                inferred_dimension = len(embeddings[0])
            else:
                inferred_dimension = self.dimension or 384

            # Map embeddings back to original indices
            for idx, embedding in zip(valid_indices, embeddings):
                result[idx] = embedding

            # Fill empty entries with zero vectors
            zero_vector = [0.0] * inferred_dimension
            for idx in range(len(result)):
                if result[idx] is None:
                    result[idx] = zero_vector

            # Verify output length matches input length
            assert len(result) == len(texts), f"Output length {len(result)} != input length {len(texts)}"
            
            return result

        except Exception as e:
            backend = "onnx" if SHOULD_USE_ONNX else ("mlx" if self.is_mlx else "sentence_transformers")
            logger.error(
                "Failed to generate batch embeddings",
                count=len(texts),
                backend=backend,
                error=str(e),
            )
            raise

    async def _embed_batch_mlx(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings using MLX.
        
        IMPORTANT: This method uses shared MLX lock to serialize Metal GPU operations.
        Metal is not thread-safe and concurrent command encoding causes crashes:
        "failed assertion 'A command encoder is already encoding to this command buffer'"
        """
        if self.model is None:
            raise RuntimeError("MLX model not initialized")

        loop = asyncio.get_event_loop()

        def _encode_batch_mlx() -> List[List[float]]:
            assert self.model is not None, "Model is None"

            try:
                # Use the same pattern as your successful test but for batch
                if hasattr(self.model, "encode"):
                    # Direct batch encode - mlx-embeddings can handle lists
                    embeddings = self.model.encode(texts)  # Pass all texts at once

                    # Convert each embedding to list of floats
                    # MLX-Embeddings text_embeds are already "mean pooled and normalized"
                    result: List[List[float]] = []
                    for emb in embeddings:
                        if hasattr(emb, "tolist"):
                            embedding_list: List[float] = emb.tolist() # type: ignore
                        elif hasattr(emb, "__iter__"):
                            embedding_list: List[float] = [float(x) for x in emb] # type: ignore
                        else:
                            embedding_list: List[float] = [float(emb)] # type: ignore

                        result.append(embedding_list) # type: ignore

                    return result

                # Fallback: process individually
                else:
                    model = self.model  # Capture for type checker
                    assert model is not None, "Model should not be None"
                    all_embeddings = []
                    for text in texts:
                        if hasattr(model, "__call__"):
                            embedding = model(text)
                        else:
                            raise RuntimeError("Unsupported MLX model interface")

                        # Convert to list
                        if hasattr(embedding, "tolist"):
                            all_embeddings.append(embedding.tolist()) # type: ignore
                        elif hasattr(embedding, "__iter__"):
                            all_embeddings.append([float(x) for x in embedding]) # type: ignore
                        else:
                            all_embeddings.append([float(embedding)]) # type: ignore

                    return all_embeddings # type: ignore

            except Exception as e:
                logger.error(
                    "MLX batch embedding generation failed",
                    error=str(e),
                    text_count=len(texts),
                )
                raise RuntimeError(f"MLX batch embedding failed: {e}")

        # Acquire MLX inference lock to prevent concurrent Metal GPU operations
        # This is critical for thread-safety on macOS with Metal
        mlx_lock = get_mlx_inference_lock()
        if mlx_lock is not None:
            async with mlx_lock:
                embeddings = await loop.run_in_executor(None, _encode_batch_mlx)
        else:
            # Non-macOS fallback (shouldn't reach here for MLX, but defensive)
            embeddings = await loop.run_in_executor(None, _encode_batch_mlx)
        
        logger.debug(
            "MLX batch embedding generated",
            embeddings=embeddings,
            text=texts,
            model=self.model_name,
            cache_dir=str(self.cache_dir),
        )
        return [[float(x) for x in embedding] for embedding in embeddings]

    async def _embed_batch_sentence_transformers(
        self, texts: List[str]
    ) -> List[List[float]]:
        """Generate batch embeddings using sentence-transformers."""
        if self.model is None:
            raise RuntimeError("Sentence-transformers model not initialized")

        loop = asyncio.get_event_loop()
        model = self.model  # Capture to satisfy type checker
        assert model is not None, "Model should not be None after check"
        embeddings = await loop.run_in_executor(
            None, lambda: model.encode(texts, convert_to_tensor=False)
        )

        # Ensure embeddings are lists of floats
        if isinstance(embeddings, np.ndarray):
            embeddings: List[List[float]] = embeddings.tolist() # type: ignore

        return [[float(x) for x in embedding] for embedding in embeddings] # type: ignore
