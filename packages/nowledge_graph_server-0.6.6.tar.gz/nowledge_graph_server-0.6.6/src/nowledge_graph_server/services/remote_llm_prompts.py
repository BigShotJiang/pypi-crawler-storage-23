"""
High-quality prompts optimized for remote LLM extraction.

These prompts are designed for powerful remote models (GPT-4, Claude, etc.)
with focus on:
- Language awareness and alignment
- Temporal information extraction
- Better quality and reflection
- Professional-grade compaction and deduplication
"""

from typing import Optional

from nowledge_graph_server.services.extraction_prompts import ENTITY_TYPES, RELATIONSHIP_TYPES

# ---------------------------------------------------------------------------
# Language helpers
# ---------------------------------------------------------------------------

_LANGUAGE_NAMES: dict[str, str] = {
    "en": "English",
    "zh": "Chinese (中文)",
    "ja": "Japanese (日本語)",
    "ko": "Korean (한국어)",
    "de": "German (Deutsch)",
    "fr": "French (Français)",
    "es": "Spanish (Español)",
    "pt": "Portuguese (Português)",
    "ru": "Russian (Русский)",
    "ar": "Arabic (العربية)",
    "it": "Italian (Italiano)",
    "nl": "Dutch (Nederlands)",
    "tr": "Turkish (Türkçe)",
    "vi": "Vietnamese (Tiếng Việt)",
    "th": "Thai (ภาษาไทย)",
    "id": "Indonesian (Bahasa Indonesia)",
    "pl": "Polish (Polski)",
    "sv": "Swedish (Svenska)",
    "hi": "Hindi (हिन्दी)",
    "uk": "Ukrainian (Українська)",
}


def build_language_instruction(preferred_language: Optional[str]) -> str:
    """Return a language output instruction for use in distillation prompts.

    - preferred_language="zh"  → force Chinese output
    - preferred_language="en"  → force English output
    - None / unknown           → follow input language
    """
    if preferred_language and preferred_language in _LANGUAGE_NAMES:
        lang = _LANGUAGE_NAMES[preferred_language]
        return f"Write all output (titles, content, tags) in {lang}."
    return "Use the same language as the conversation."


# Memory Distillation Prompts

REMOTE_DISTILLATION_MEMORY_PROMPT = """<task>
Extract 1-3 valuable memories from the conversation. {{language_instruction}}
</task>

<rules>
- Extract: decisions, insights, solutions, learnings, concrete facts
- Skip: casual chat, trivial info, well-known facts, duplicates
- Each memory must be self-contained (understandable alone)
- Be specific: include names, details, context
- importance: 0.0-1.0 (how useful in 6 months?)
- confidence: 0.0-1.0 (how accurate?)
- unit_type: classify as one of: fact, preference, decision, plan, procedure, learning, context, event
- tags: 2-5 keywords in source language
- temporal: ONLY if date explicitly stated. Do NOT invent precision. If vague ("a few years ago"), set null.
</rules>

<unit_type_guide>
- fact: Objective information, observations, data points
- preference: Personal preferences, likes, dislikes, opinions
- decision: Decisions made, choices, commitments
- plan: Future plans, goals, intentions, todos
- procedure: How-to knowledge, processes, step-by-step instructions
- learning: Lessons learned, realizations, insights from experience
- context: Background context, settings, environment descriptions
- event: Events, occurrences, happenings with temporal grounding
When uncertain, default to "fact".
</unit_type_guide>

<input>
{thread_content}
</input>

<output_format>
Return ONLY valid JSON, no other text:
{{
  "memories": [
    {{
      "title": "Brief title",
      "content": "Self-contained memory (2-4 sentences)",
      "importance": 0.8,
      "confidence": 0.9,
      "unit_type": "fact",
      "tags": ["tag1", "tag2"],
      "temporal": {{"type": "exact", "start": "2020", "end": null, "confidence": 0.9, "context": "past"}},
      "reasoning": "Why valuable"
    }}
  ],
  "detected_language": "en",
  "overall_quality": 0.85
}}
</output_format>

<temporal_rules>
- type: "exact" | "range" | "unknown"
- start/end: "YYYY" or "YYYY-MM" or "YYYY-MM-DD"
- If no date mentioned: set temporal to null
- "In 2020" → {{"type":"exact","start":"2020","end":null,"confidence":0.9,"context":"past"}}
- "2018-2021" → {{"type":"range","start":"2018","end":"2021","confidence":0.9,"context":"past"}}
- No date cue → null
</temporal_rules>

Output ONLY the JSON object, nothing else:"""

REMOTE_CHUNK_DISTILLATION_PROMPT = """<task>
Extract 1-2 valuable memories from this chunk. {{language_instruction}}
</task>

<rules>
- Extract: insights, decisions, solutions worth keeping
- Skip: trivial info, casual chat
- Self-contained memories only
- unit_type: fact|preference|decision|plan|procedure|learning|context|event (default: fact)
- temporal: only if date explicitly stated, else null
</rules>

<input>
{chunk_content}
</input>

<output_format>
Return ONLY valid JSON:
{{
  "memories": [
    {{
      "title": "Title",
      "content": "Self-contained memory",
      "importance": 0.8,
      "confidence": 0.9,
      "unit_type": "fact",
      "tags": ["tag1", "tag2"],
      "temporal": null
    }}
  ]
}}
</output_format>

Output ONLY the JSON object, nothing else:"""

REMOTE_CONSOLIDATION_PROMPT = """<task>
Consolidate {memory_count} memories into top 3. {{language_instruction}}
</task>

<rules>
- Remove duplicates
- Merge related memories
- Keep only top 3 most valuable
- Preserve specific details
</rules>

<input>
{memories_json}
</input>

<output_format>
Return ONLY valid JSON:
{{
  "consolidated_memories": [
    {{
      "title": "Title",
      "content": "Consolidated content",
      "importance": 0.9,
      "confidence": 0.85,
      "tags": ["tag1", "tag2"],
      "sources_merged": ["Original title 1"]
    }}
  ],
  "consolidation_reasoning": "Brief explanation"
}}
</output_format>

Output ONLY the JSON object, nothing else:"""

# Knowledge Graph Extraction Prompts

REMOTE_ENTITY_EXTRACTION_PROMPT = """<task>
Extract entities and relationships from the memory content. {language_instruction}
</task>

<entity_types>
{entity_types}
</entity_types>

<relationship_types>
{relationship_types}
</relationship_types>

<input>
Title: {memory_title}
Content: {memory_content}

Existing entities (avoid duplicates): {existing_entities}
</input>

<language_rules>
Entity names must preserve the original language from the source text:
- Non-English source → keep entity names in the original language
- English source → keep entity names in English
- Exception: internationally recognized proper nouns (brand names, product names, 
  technical terms) should retain their original form regardless of source language

For multilingual content, set the "language" field to the entity's primary language code.
Include translations in "aliases" when the entity has well-known alternative names.
</language_rules>

<extraction_rules>
- Entity confidence >= 0.7 to include
- Relationship confidence >= 0.6 to include
- Relationship source/target must EXACTLY match an entity name from your entities list
- Temporal info: only include if explicitly stated in the text
  - If temporal info is vague or uncertain, set to null
</extraction_rules>

<output_format>
Return ONLY valid JSON:
{{
  "entities": [
    {{
      "name": "Entity name in original language",
      "type": "TYPE",
      "description": "Brief description in source language",
      "confidence": 0.85,
      "language": "ISO 639-1 code",
      "aliases": [],
      "entity_temporal": null
    }}
  ],
  "relationships": [
    {{
      "source": "Exact entity name from entities list",
      "target": "Exact entity name from entities list",
      "relation": "RELATION_TYPE",
      "context": "Text excerpt showing connection",
      "rel_temporal": null,
      "strength": 0.8,
      "confidence": 0.75
    }}
  ],
  "extraction_quality": 0.8,
  "language_detected": "ISO 639-1 code"
}}
</output_format>

<examples>
Example 1 - English source:
Input: "Dr. Chen developed a neural network for medical diagnosis in 2022"
Output:
{{
  "entities": [
    {{"name": "Dr. Chen", "type": "PERSON", "description": "Researcher", "confidence": 0.9, "language": "en", "aliases": [], "entity_temporal": null}},
    {{"name": "neural network", "type": "TECHNOLOGY", "description": "Machine learning model", "confidence": 0.85, "language": "en", "aliases": [], "entity_temporal": null}},
    {{"name": "medical diagnosis", "type": "CONCEPT", "description": "Healthcare application", "confidence": 0.8, "language": "en", "aliases": [], "entity_temporal": null}}
  ],
  "relationships": [
    {{"source": "Dr. Chen", "target": "neural network", "relation": "CREATES", "context": "developed a neural network", "rel_temporal": {{"temporal_type": "exact", "rel_start": "2022", "rel_end": null, "is_ongoing": true, "temporal_confidence": 0.9}}, "strength": 0.9, "confidence": 0.9}}
  ],
  "extraction_quality": 0.85,
  "language_detected": "en"
}}

Example 2 - Non-English source (Japanese):
Input: "田中さんは機械学習を使って画像認識システムを開発した"
Output:
{{
  "entities": [
    {{"name": "田中さん", "type": "PERSON", "description": "開発者", "confidence": 0.9, "language": "ja", "aliases": ["Tanaka-san"], "entity_temporal": null}},
    {{"name": "機械学習", "type": "TECHNOLOGY", "description": "AI技術", "confidence": 0.9, "language": "ja", "aliases": ["machine learning"], "entity_temporal": null}},
    {{"name": "画像認識システム", "type": "SYSTEM", "description": "コンピュータビジョン応用", "confidence": 0.85, "language": "ja", "aliases": ["image recognition system"], "entity_temporal": null}}
  ],
  "relationships": [
    {{"source": "田中さん", "target": "機械学習", "relation": "USES", "context": "機械学習を使って", "strength": 0.9, "confidence": 0.9}},
    {{"source": "田中さん", "target": "画像認識システム", "relation": "CREATES", "context": "画像認識システムを開発した", "strength": 0.9, "confidence": 0.9}}
  ],
  "extraction_quality": 0.9,
  "language_detected": "ja"
}}
</examples>

Output ONLY the JSON object, nothing else:"""

# Original full reflection prompt (kept for reference, not used)
REMOTE_ENTITY_REFLECTION_PROMPT = """You are a quality control expert reviewing extracted entities and relationships.

Review the extraction results and improve them by:
1. Removing low-confidence or low-quality entities/relationships
2. Fixing any language inconsistencies (entity names should stay in original language)
3. Improving temporal information accuracy and completeness
4. Ensuring all relationships reference valid extracted entities
5. Enhancing descriptions for clarity

ORIGINAL EXTRACTION:
{extraction_json}

QUALITY CHECKS:
- Are entity names in their original language?
- Are descriptions clear and in matching language?
- Is temporal information specific and accurate?
- Are relationship contexts meaningful?
- Are confidence scores realistic?
- Do all relationships reference extracted entities?

OUTPUT FORMAT (JSON):
{{
  "entities": [/* improved entity list */],
  "relationships": [/* improved relationship list */],
  "improvements_made": ["List of improvements"],
  "quality_score": 0.9
}}

Return the improved extraction:"""

# ============================================================================
# MICRO-PROMPTS FOR PARALLEL REFLECTION
# These 3 prompts run in parallel, each focusing on one aspect of reflection
# ============================================================================

REFLECTION_LANGUAGE_PROMPT = """<task>
Fix translated entity names back to original language.
</task>

<input>
{entities_json}
</input>

<output_format>
Return ONLY valid JSON:
{{"fixes": [{{"index": 0, "original_name": "Tokyo", "corrected_name": "東京", "reason": "Japanese original"}}]}}

If no fixes: {{"fixes": []}}
</output_format>

Output ONLY the JSON object, nothing else:"""

REFLECTION_TEMPORAL_PROMPT = """<task>
Review temporal info accuracy. Flag vague or incorrect dates.
</task>

<input>
{temporal_json}
</input>

<output_format>
Return ONLY valid JSON:
{{"entity_fixes": [{{"index": 0, "issue": "Date vague", "suggested_fix": "2020s → 2020"}}], "relationship_fixes": []}}

If no fixes: {{"entity_fixes": [], "relationship_fixes": []}}
</output_format>

Output ONLY the JSON object, nothing else:"""

REFLECTION_DESCRIPTION_PROMPT = """<task>
Improve vague entity descriptions. Keep concise.
</task>

<input>
{entities_json}
</input>

<output_format>
Return ONLY valid JSON:
{{"improvements": [{{"index": 0, "original": "A tool", "improved": "Build automation tool for Java"}}]}}

If no improvements: {{"improvements": []}}
</output_format>

Output ONLY the JSON object, nothing else:"""

REMOTE_ENTITY_DEDUPLICATION_PROMPT = """<task>
Check if new entity is duplicate of existing. Consider name variations and translations.
</task>

<new_entity>
Name: {new_entity_name}
Type: {new_entity_type}
Description: {new_entity_description}
</new_entity>

<existing_entities>
{existing_entities_json}
</existing_entities>

<output_format>
Return ONLY valid JSON:
{{"is_duplicate": true, "matching_entity_id": "e1", "matching_entity_name": "Name", "confidence": 0.9, "reasoning": "Same entity"}}

If not duplicate:
{{"is_duplicate": false, "matching_entity_id": null, "matching_entity_name": null, "confidence": 0.9, "reasoning": "Different entities"}}
</output_format>

<examples>
Tokyo vs 東京 → duplicate (same city, different language)
React vs React Native → not duplicate (different technologies)
</examples>

Output ONLY the JSON object, nothing else:"""

# Batch deduplication prompt - check multiple entities at once for speed
REMOTE_BATCH_ENTITY_DEDUPLICATION_PROMPT = """<task>
Check each new entity against existing entities for duplicates.
Consider name variations and translations (東京 = Tokyo).
</task>

<new_entities>
{new_entities_json}
</new_entities>

<existing_entities>
{existing_entities_json}
</existing_entities>

<rules>
- Return one result per new entity, in same order
- Only mark duplicate if confidence >= 0.75
</rules>

<output_format>
Return ONLY valid JSON:
{{
  "results": [
    {{"new_entity_index": 0, "is_duplicate": false, "matching_entity_id": null, "matching_entity_name": null, "confidence": 0.9, "reasoning": "No match"}},
    {{"new_entity_index": 1, "is_duplicate": true, "matching_entity_id": "e1", "matching_entity_name": "Name", "confidence": 0.95, "reasoning": "Same entity"}}
  ]
}}
</output_format>

Output ONLY the JSON object, nothing else:"""

# Temporal Intent Extraction for Search Queries

TEMPORAL_INTENT_EXTRACTION_PROMPT = """<task>
Analyze the query for temporal intent. Query may be in ANY language. Respond with JSON only.
</task>

<current_date>
Today's date: {current_date}
</current_date>

<fields>
- has_temporal_intent: boolean (does query mention time/dates?)
- temporal_type: "year" | "range" | "relative" | "context" | "reference" | null
- temporal_value: extracted temporal information or null
- temporal_confidence: 0.0-1.0
</fields>

<temporal_types>
- year: specific year mentioned (e.g., "2020", "2023年")
- range: date range (e.g., "2018-2022", "between 2020 and 2023")
- relative: relative time reference (e.g., "recent", "last year", "最近")
- context: temporal context (e.g., "future plans", "past decisions", "upcoming")
- reference: before/after reference (e.g., "before migration", "after Q2")
</temporal_types>

<examples>
Query: "what happened in 2020"
Output: {{"has_temporal_intent": true, "temporal_type": "year", "temporal_value": "2020", "temporal_confidence": 0.95}}

Query: "2020年发生了什么"
Output: {{"has_temporal_intent": true, "temporal_type": "year", "temporal_value": "2020", "temporal_confidence": 0.95}}

Query: "recent changes"
Output: {{"has_temporal_intent": true, "temporal_type": "relative", "temporal_value": {{"relative": "recent", "days": 30}}, "temporal_confidence": 0.8}}

Query: "最近的变化"
Output: {{"has_temporal_intent": true, "temporal_type": "relative", "temporal_value": {{"relative": "recent", "days": 30}}, "temporal_confidence": 0.8}}

Query: "explain OAuth2"
Output: {{"has_temporal_intent": false, "temporal_type": null, "temporal_value": null, "temporal_confidence": 0.0}}

Query: "decisions before Q2 2023"
Output: {{"has_temporal_intent": true, "temporal_type": "range", "temporal_value": {{"to": "2023-03"}}, "temporal_confidence": 0.9}}

Query: "between 2018 and 2022"
Output: {{"has_temporal_intent": true, "temporal_type": "range", "temporal_value": {{"from": "2018", "to": "2022"}}, "temporal_confidence": 0.95}}

Query: "future roadmap"
Output: {{"has_temporal_intent": true, "temporal_type": "context", "temporal_value": "future", "temporal_confidence": 0.85}}

Query: "last year's decisions"
Output: {{"has_temporal_intent": true, "temporal_type": "relative", "temporal_value": {{"relative": "last_year", "year": "{last_year}"}}, "temporal_confidence": 0.9}}
</examples>

<rules>
- Extract dates in ISO 8601 format (YYYY-MM-DD or YYYY-MM or YYYY)
- For relative references, use current_date to resolve actual dates
- temporal_context values: "past" | "present" | "future" | "timeless"
- If query has no temporal intent, all fields except has_temporal_intent should be null
- Work across all languages - understand temporal intent regardless of language
</rules>

<query>
{query_text}
</query>

<output_format>
Return ONLY valid JSON:
{{
  "has_temporal_intent": true/false,
  "temporal_type": "year" | "range" | "relative" | "context" | "reference" | null,
  "temporal_value": {{...}} | string | null,
  "temporal_confidence": 0.0-1.0
}}
</output_format>

Output ONLY the JSON object, nothing else:"""
