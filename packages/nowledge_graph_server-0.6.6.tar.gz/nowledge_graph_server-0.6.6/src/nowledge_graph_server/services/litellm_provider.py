"""
LiteLLM Provider for remote LLM inference.

Supports 100+ LLM providers through LiteLLM's unified interface.

This module serves as a facade that re-exports the modular litellm package.
The implementation has been refactored into the following submodules:

    - litellm.constants: Shared constants and configuration values
    - litellm.utils: Utility functions for API normalization and LangFuse setup
    - litellm.env: Environment variable management for provider isolation
    - litellm.validation: Provider-specific connection validation
    - litellm.models: Model discovery and listing functions
    - litellm.provider: Main LiteLLMProvider class
    - litellm.api: High-level convenience functions
"""

# Re-export public API for backward compatibility
from nowledge_graph_server.services.litellm import (
    # Main provider class
    LiteLLMProvider,
    # Constants (private but commonly used)
    DEFAULT_MODELS,
    JSON_FORMAT_PROVIDERS,
    ALL_PROVIDER_ENV_KEYS,
    PROVIDER_ENV_KEYS,
)

from nowledge_graph_server.services.litellm.api import (
    # Convenience functions
    test_connection,
    list_models,
    test_connection_with_config,
    list_models_with_config,
)

# Expose internal utility for backward compatibility
from nowledge_graph_server.services.litellm.utils import (
    normalize_api_base as _normalize_api_base,
    get_models_dev_provider_model_ids as _get_models_dev_provider_model_ids,
    setup_langfuse_otel as _setup_langfuse_otel,
)

# Keep old names for backward compatibility
_MODELS_DEV_CACHE = {"ts": 0.0, "data": None}  # Deprecated: use litellm.constants instead


__all__ = [
    "LiteLLMProvider",
    "test_connection",
    "list_models",
    "test_connection_with_config",
    "list_models_with_config",
]
