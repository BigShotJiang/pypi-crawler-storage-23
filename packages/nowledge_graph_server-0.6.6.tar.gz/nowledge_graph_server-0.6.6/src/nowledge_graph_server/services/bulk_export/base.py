"""Base classes for bulk export parsing."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from datetime import datetime

from nowledge_graph_server.services.thread_parsing import ParsedThread, ParsedMessage


@dataclass
class FormatSignature:
    """Declarative signature for detecting export formats.

    Each export format is defined by a FormatSignature that declares
    detection criteria using a combination of file-level and content-level patterns.
    """

    # Identity
    format_id: str  # e.g., "chatgpt_html_bulk", "gemini_json"
    format_name: str  # e.g., "ChatGPT HTML Export"
    source: str  # e.g., "ChatGPT", "Gemini", "Claude"
    version: str = "1.0"  # Format version for future compat

    # File-level detection (fast, checked first)
    file_extensions: List[str] = field(
        default_factory=list
    )  # e.g., [".html"], [".json", ".zip"]
    filename_patterns: List[str] = field(default_factory=list)  # Regex patterns

    # Content-level detection (checked if file-level passes)
    required_patterns: List[str] = field(
        default_factory=list
    )  # ALL must match in first N bytes
    optional_patterns: List[str] = field(
        default_factory=list
    )  # Boost confidence if matched
    forbidden_patterns: List[str] = field(
        default_factory=list
    )  # If ANY match, reject this format

    # Detection config
    sample_size: int = 8192  # Bytes to read for content detection
    min_confidence: float = 0.7  # Threshold to accept this format
    priority: int = 100  # Higher = checked first (specificity)

    # Parser reference
    parser_class: str = ""  # e.g., "ChatGPTBulkParser"
    is_bulk: bool = True  # True for multi-thread exports


@dataclass
class FormatDetectionResult:
    """Result of format detection."""

    format_id: str
    format_name: str
    source: str
    confidence: float
    matched_patterns: List[str]
    parser_class: str
    is_bulk: bool


@dataclass
class BulkParseResult:
    """Result from parsing a bulk export file."""

    source: str
    format_id: str
    threads: List[ParsedThread]
    total_messages: int
    parse_warnings: List[str] = field(default_factory=list)  # Non-fatal issues
    parse_errors: List[str] = field(
        default_factory=list
    )  # Threads that failed to parse
    metadata: Dict[str, Any] = field(default_factory=dict)  # Format-specific metadata


class BulkExportParser(ABC):
    """Base class for bulk export parsers.

    Subclasses must implement:
    - format_id property: Return the format ID this parser handles
    - parse(): Parse all threads from the export file
    - parse_single_thread(): Parse a single thread from raw data
    """

    @property
    @abstractmethod
    def format_id(self) -> str:
        """Return the format ID this parser handles."""
        pass

    @abstractmethod
    def parse(self, file_path: str) -> BulkParseResult:
        """Parse all threads from the export file.

        Args:
            file_path: Path to the export file

        Returns:
            BulkParseResult containing all parsed threads
        """
        pass

    @abstractmethod
    def parse_single_thread(self, thread_data: Any) -> Optional[ParsedThread]:
        """Parse a single thread from raw data.

        Used for selective import where only specific threads are needed.

        Args:
            thread_data: Raw thread data in format-specific structure

        Returns:
            ParsedThread if successful, None if thread should be skipped
        """
        pass

    def _format_timestamp(self, ts: Optional[float]) -> Optional[str]:
        """Format Unix timestamp to ISO string.

        Args:
            ts: Unix timestamp (seconds since epoch)

        Returns:
            ISO formatted datetime string or None
        """
        if not ts:
            return None
        try:
            return datetime.fromtimestamp(ts).isoformat()
        except (ValueError, OSError, OverflowError):
            return None
