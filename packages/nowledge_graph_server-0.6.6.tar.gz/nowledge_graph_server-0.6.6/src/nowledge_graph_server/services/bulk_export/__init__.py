"""Bulk export parsing system.

This module provides a robust, extensible system for parsing bulk exports
from various AI chat platforms (ChatGPT, Gemini, Claude, etc.).

Key components:
- FormatSignature: Declarative format definition with detection criteria
- FormatRegistry: Central detection engine with pattern matching
- BulkExportParser: Base class for format-specific parsers

Usage:
    from nowledge_graph_server.services.bulk_export import (
        format_registry,
        initialize_registry,
    )

    # Initialize on startup
    initialize_registry()

    # Detect format
    result = format_registry.detect_format("/path/to/chat.html")
    if result:
        parser = format_registry.get_parser(result.format_id)
        parse_result = parser.parse("/path/to/chat.html")
"""

from .base import (
    FormatSignature,
    FormatDetectionResult,
    BulkParseResult,
    BulkExportParser,
)
from .registry import (
    FormatRegistry,
    format_registry,
    initialize_registry,
)
from .signatures import (
    CHATGPT_HTML_BULK,
    CHATGPT_JSON_BULK,
    GEMINI_JSON_BULK,
    CLAUDE_JSON_BULK,
    ALL_SIGNATURES,
    IMPLEMENTED_SIGNATURES,
)

__all__ = [
    # Base classes
    "FormatSignature",
    "FormatDetectionResult",
    "BulkParseResult",
    "BulkExportParser",
    # Registry
    "FormatRegistry",
    "format_registry",
    "initialize_registry",
    # Signatures
    "CHATGPT_HTML_BULK",
    "CHATGPT_JSON_BULK",
    "GEMINI_JSON_BULK",
    "CLAUDE_JSON_BULK",
    "ALL_SIGNATURES",
    "IMPLEMENTED_SIGNATURES",
]
