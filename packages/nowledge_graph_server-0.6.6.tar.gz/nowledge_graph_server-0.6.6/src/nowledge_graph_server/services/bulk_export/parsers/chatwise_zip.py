"""ChatWise ZIP bulk export parser.

This parser handles the ZIP export from ChatWise app.
The export contains multiple chat-*.json files, each representing
a single conversation.

File structure:
```
chatwise-export-YYYY-MM-DD-HH-MM.zip
├── chat-xxxx.json
├── chat-yyyy.json
├── ...
└── chatwise-export-verison.txt
```

Each chat JSON has:
```json
{
  "id": "xxx",
  "title": "Conversation Title",
  "createdAt": "2025-11-12T09:04:23.033Z",
  "updatedAt": "2025-11-12T09:05:11.754Z",
  "model": "cus_kimi-maxfr34a5z",
  "messages": [
    {
      "id": "xxx",
      "chatId": "xxx",
      "createdAt": "2025-11-12T09:04:21.999Z",
      "content": "message text",
      "role": "user" | "assistant",
      "model": null | "model-name"
    }
  ]
}
```
"""

import json
import zipfile
import structlog
from typing import Any, Dict, List, Optional
from datetime import datetime

from ..base import BulkExportParser, BulkParseResult
from nowledge_graph_server.services.thread_parsing import ParsedThread, ParsedMessage

logger = structlog.get_logger(__name__)


class ChatWiseZipParser(BulkExportParser):
    """Parser for ChatWise ZIP bulk exports.

    This parser:
    1. Opens the ZIP file
    2. Finds all chat-*.json files inside
    3. Parses each JSON file as a conversation
    4. Returns ordered messages for each thread
    """

    @property
    def format_id(self) -> str:
        return "chatwise_zip_bulk"

    def parse(self, file_path: str) -> BulkParseResult:
        """Parse all threads from the ChatWise ZIP export.

        Args:
            file_path: Path to the .zip file

        Returns:
            BulkParseResult with all parsed conversations
        """
        logger.info("Parsing ChatWise ZIP export", file_path=file_path)

        threads: List[ParsedThread] = []
        errors: List[str] = []
        warnings: List[str] = []
        total_messages = 0

        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                # Find all chat-*.json files
                chat_files = [
                    name
                    for name in zf.namelist()
                    if name.startswith("chat-") and name.endswith(".json")
                ]

                logger.info("Found chat files in ZIP", count=len(chat_files))

                for i, chat_file in enumerate(chat_files):
                    try:
                        with zf.open(chat_file) as f:
                            chat_data = json.load(f)

                        thread = self.parse_single_thread(chat_data)
                        if thread:
                            threads.append(thread)
                            total_messages += thread.message_count
                        else:
                            warnings.append(f"{chat_file}: No valid messages found")

                    except json.JSONDecodeError as e:
                        errors.append(f"{chat_file}: Invalid JSON - {str(e)}")
                        logger.warning(
                            "Failed to parse chat JSON", file=chat_file, error=str(e)
                        )
                    except Exception as e:
                        errors.append(f"{chat_file}: {str(e)}")
                        logger.warning(
                            "Failed to parse chat file", file=chat_file, error=str(e)
                        )

        except zipfile.BadZipFile:
            logger.error("Invalid ZIP file", file_path=file_path)
            return BulkParseResult(
                source="ChatWise",
                format_id=self.format_id,
                threads=[],
                total_messages=0,
                parse_errors=["Invalid ZIP file"],
            )
        except Exception as e:
            logger.error("Failed to read ZIP file", file_path=file_path, error=str(e))
            return BulkParseResult(
                source="ChatWise",
                format_id=self.format_id,
                threads=[],
                total_messages=0,
                parse_errors=[f"Failed to read ZIP file: {str(e)}"],
            )

        logger.info(
            "Parsing complete",
            threads=len(threads),
            total_messages=total_messages,
            errors=len(errors),
            warnings=len(warnings),
        )

        return BulkParseResult(
            source="ChatWise",
            format_id=self.format_id,
            threads=threads,
            total_messages=total_messages,
            parse_warnings=warnings,
            parse_errors=errors,
            metadata={
                "file_count": len(chat_files) if "chat_files" in dir() else 0,
                "parsed_count": len(threads),
                "file_path": file_path,
            },
        )

    def parse_single_thread(self, thread_data: Any) -> Optional[ParsedThread]:
        """Parse a single conversation from ChatWise JSON.

        Args:
            thread_data: Raw chat dict from the JSON file

        Returns:
            ParsedThread if successful, None if conversation should be skipped
        """
        if not isinstance(thread_data, dict):
            return None

        title = thread_data.get("title") or "Untitled Conversation"
        created_at = thread_data.get("createdAt")
        updated_at = thread_data.get("updatedAt")
        messages_data = thread_data.get("messages", [])

        if not messages_data:
            return None

        # Parse messages
        messages: List[ParsedMessage] = []
        for msg in messages_data:
            parsed = self._parse_message(msg)
            if parsed:
                messages.append(parsed)

        if not messages:
            return None

        # Build export info
        export_info_parts = []
        if created_at:
            export_info_parts.append(
                f"Created: {self._format_iso_timestamp(created_at)}"
            )
        if updated_at:
            export_info_parts.append(
                f"Updated: {self._format_iso_timestamp(updated_at)}"
            )
        export_info = " | ".join(export_info_parts) if export_info_parts else None

        return ParsedThread(
            title=title,
            source="ChatWise",
            messages=messages,
            export_info=export_info,
        )

    def _parse_message(self, msg: Dict) -> Optional[ParsedMessage]:
        """Parse a single message into ParsedMessage format.

        Args:
            msg: The message dict from ChatWise

        Returns:
            ParsedMessage if valid, None if message should be skipped
        """
        role = msg.get("role", "")
        content = msg.get("content", "")
        created_at = msg.get("createdAt")

        # Map roles
        if role == "assistant":
            speaker = "assistant"
        elif role == "user":
            speaker = "user"
        else:
            speaker = role or "unknown"

        # Skip empty messages
        if not content or not content.strip():
            return None

        # Parse timestamp
        timestamp = self._format_iso_timestamp(created_at) if created_at else None

        return ParsedMessage(
            speaker=speaker,
            content=content.strip(),
            timestamp=timestamp,
        )

    def _format_iso_timestamp(self, iso_str: Optional[str]) -> Optional[str]:
        """Format ISO timestamp string.

        Args:
            iso_str: ISO format timestamp string (e.g., "2025-11-12T09:04:23.033Z")

        Returns:
            Formatted datetime string or None
        """
        if not iso_str:
            return None
        try:
            # Parse ISO format
            dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
            return dt.isoformat()
        except (ValueError, AttributeError):
            return iso_str  # Return as-is if parsing fails
