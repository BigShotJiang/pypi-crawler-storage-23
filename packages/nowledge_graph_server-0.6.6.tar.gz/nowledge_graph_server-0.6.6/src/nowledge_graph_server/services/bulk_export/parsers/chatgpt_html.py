"""ChatGPT HTML bulk export parser.

This parser handles the chat.html file that ChatGPT provides in their
data export. The file contains embedded JSON with all conversations
in a tree structure.

File structure:
```html
<script>
var jsonData = [
  {
    "title": "Conversation Title",
    "create_time": 1763427399.488538,
    "update_time": 1765854171.870885,
    "mapping": {
      "msg-id": {
        "message": {
          "author": {"role": "user"},
          "content": {"content_type": "text", "parts": ["message text"]},
          "metadata": {"is_visually_hidden_from_conversation": false}
        },
        "parent": "parent-id",
        "children": ["child-id"]
      }
    }
  }
]
</script>
```
"""

import json
import re
import structlog
from typing import Any, Dict, List, Optional

from ..base import BulkExportParser, BulkParseResult
from nowledge_graph_server.services.thread_parsing import ParsedThread, ParsedMessage

logger = structlog.get_logger(__name__)


class ChatGPTBulkParser(BulkExportParser):
    """Parser for ChatGPT chat.html bulk exports.

    This parser:
    1. Extracts the embedded JSON from the HTML file
    2. For each conversation, traverses the message tree
    3. Filters out hidden/system messages
    4. Returns ordered messages for each thread
    """

    @property
    def format_id(self) -> str:
        return "chatgpt_html_bulk"

    def parse(self, file_path: str) -> BulkParseResult:
        """Parse all threads from the ChatGPT HTML export.

        Args:
            file_path: Path to the chat.html file

        Returns:
            BulkParseResult with all parsed conversations
        """
        logger.info("Parsing ChatGPT HTML export", file_path=file_path)

        # Read HTML file
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            logger.error("Failed to read file", file_path=file_path, error=str(e))
            return BulkParseResult(
                source="ChatGPT",
                format_id=self.format_id,
                threads=[],
                total_messages=0,
                parse_errors=[f"Failed to read file: {str(e)}"],
            )

        # Extract JSON from script tag
        try:
            json_data = self._extract_json_data(content)
        except Exception as e:
            logger.error("Failed to extract JSON", error=str(e))
            return BulkParseResult(
                source="ChatGPT",
                format_id=self.format_id,
                threads=[],
                total_messages=0,
                parse_errors=[f"Failed to extract JSON: {str(e)}"],
            )

        # Parse each conversation
        threads: List[ParsedThread] = []
        errors: List[str] = []
        warnings: List[str] = []
        total_messages = 0

        logger.info("Found conversations", count=len(json_data))

        for i, conv in enumerate(json_data):
            try:
                thread = self.parse_single_thread(conv)
                if thread:
                    threads.append(thread)
                    total_messages += thread.message_count
                else:
                    warnings.append(f"Conversation {i}: No valid messages found")
            except Exception as e:
                error_msg = (
                    f"Conversation {i} ('{conv.get('title', 'Untitled')}'): {str(e)}"
                )
                errors.append(error_msg)
                logger.warning("Failed to parse conversation", index=i, error=str(e))

        logger.info(
            "Parsing complete",
            threads=len(threads),
            total_messages=total_messages,
            errors=len(errors),
            warnings=len(warnings),
        )

        return BulkParseResult(
            source="ChatGPT",
            format_id=self.format_id,
            threads=threads,
            total_messages=total_messages,
            parse_warnings=warnings,
            parse_errors=errors,
            metadata={
                "conversation_count": len(json_data),
                "parsed_count": len(threads),
                "file_path": file_path,
            },
        )

    def parse_single_thread(self, thread_data: Any) -> Optional[ParsedThread]:
        """Parse a single conversation from ChatGPT export.

        Args:
            thread_data: Raw conversation dict from the JSON

        Returns:
            ParsedThread if successful, None if conversation should be skipped
        """
        if not isinstance(thread_data, dict):
            return None

        title = thread_data.get("title") or "Untitled Conversation"
        create_time = thread_data.get("create_time")
        update_time = thread_data.get("update_time")
        mapping = thread_data.get("mapping", {})

        if not mapping:
            return None

        # Traverse message tree
        messages = self._traverse_message_tree(mapping)

        if not messages:
            return None

        # Build export info
        export_info_parts = []
        if create_time:
            export_info_parts.append(f"Created: {self._format_timestamp(create_time)}")
        if update_time:
            export_info_parts.append(f"Updated: {self._format_timestamp(update_time)}")
        export_info = " | ".join(export_info_parts) if export_info_parts else None

        return ParsedThread(
            title=title,
            source="ChatGPT",
            messages=messages,
            export_info=export_info,
        )

    def _extract_json_data(self, html_content: str) -> List[Dict]:
        """Extract jsonData array from HTML.

        The ChatGPT export contains JavaScript with:
        var jsonData = [...];

        Args:
            html_content: The full HTML content

        Returns:
            List of conversation dictionaries

        Raises:
            ValueError: If jsonData cannot be found or parsed
        """
        # Find the start of jsonData array
        start_pattern = r"var\s+jsonData\s*=\s*\["
        match = re.search(start_pattern, html_content)

        if not match:
            raise ValueError("Could not find jsonData in HTML content")

        # Find the position where the array starts (after the '[')
        array_start = match.end() - 1  # -1 to include the '['

        # Use bracket matching to find the end of the array
        # This is more reliable than regex for large nested JSON
        json_str = self._extract_balanced_json(html_content, array_start)

        if not json_str:
            raise ValueError("Could not extract JSON array - unbalanced brackets")

        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            # Try to provide more context
            raise ValueError(f"Invalid JSON in jsonData: {str(e)}")

    def _extract_balanced_json(self, content: str, start_pos: int) -> Optional[str]:
        """Extract a balanced JSON array using bracket matching.

        Args:
            content: The full content string
            start_pos: Position of the opening '['

        Returns:
            The JSON string including brackets, or None if unbalanced
        """
        if start_pos >= len(content) or content[start_pos] != "[":
            return None

        depth = 0
        in_string = False
        escape_next = False
        pos = start_pos

        while pos < len(content):
            char = content[pos]

            if escape_next:
                escape_next = False
                pos += 1
                continue

            if char == "\\":
                escape_next = True
                pos += 1
                continue

            if char == '"' and not escape_next:
                in_string = not in_string
                pos += 1
                continue

            if not in_string:
                if char == "[":
                    depth += 1
                elif char == "]":
                    depth -= 1
                    if depth == 0:
                        # Found the matching closing bracket
                        return content[start_pos : pos + 1]

            pos += 1

        return None  # Unbalanced brackets

    def _traverse_message_tree(self, mapping: Dict) -> List[ParsedMessage]:
        """Traverse the message tree to get messages in chronological order.

        ChatGPT stores messages in a tree structure with parent/children
        relationships. We need to:
        1. Find the root node
        2. Traverse following children to get the main conversation path

        Args:
            mapping: The mapping dict with all message nodes

        Returns:
            List of ParsedMessage in order
        """
        if not mapping:
            return []

        # Find root node (no parent or parent not in mapping)
        root_id = None
        for node_id, node in mapping.items():
            parent = node.get("parent")
            if not parent or parent not in mapping:
                root_id = node_id
                break

        if not root_id:
            # No clear root, try to find by looking at all nodes
            # and finding one with null parent
            for node_id, node in mapping.items():
                if node.get("parent") is None:
                    root_id = node_id
                    break

        if not root_id:
            logger.warning("Could not find root node in message tree")
            return []

        # BFS traversal following children
        # This gives us messages in conversation order
        messages: List[ParsedMessage] = []
        queue = [root_id]
        visited = set()

        while queue:
            node_id = queue.pop(0)
            if node_id in visited:
                continue
            visited.add(node_id)

            node = mapping.get(node_id, {})
            msg_data = node.get("message")

            # Extract message if valid and visible
            if msg_data and self._is_visible_message(msg_data):
                parsed_msg = self._parse_message(msg_data)
                if parsed_msg:
                    messages.append(parsed_msg)

            # Add children to queue (in order)
            children = node.get("children", [])
            queue.extend(children)

        return messages

    def _is_visible_message(self, msg: Dict) -> bool:
        """Check if a message should be included in the output.

        Filters out:
        - Visually hidden messages (system prompts, etc.)
        - Pure system messages
        - Empty messages

        Args:
            msg: The message dict

        Returns:
            True if message should be included
        """
        metadata = msg.get("metadata", {})

        # Check if explicitly hidden
        if metadata.get("is_visually_hidden_from_conversation"):
            return False

        author = msg.get("author", {})
        role = author.get("role", "")

        # Skip system messages (they're typically context/instructions)
        if role == "system":
            return False

        # Check content exists and is non-empty
        content_obj = msg.get("content", {})
        if not content_obj:
            return False

        content_type = content_obj.get("content_type", "")

        # For text content, check parts
        if content_type == "text":
            parts = content_obj.get("parts", [])
            if not parts or not any(
                str(p).strip() for p in parts if isinstance(p, str)
            ):
                return False

        return True

    def _parse_message(self, msg: Dict) -> Optional[ParsedMessage]:
        """Parse a single message into ParsedMessage format.

        Args:
            msg: The message dict from ChatGPT

        Returns:
            ParsedMessage if valid, None if message should be skipped
        """
        author = msg.get("author", {})
        role = author.get("role", "unknown")
        content_obj = msg.get("content", {})

        # Map ChatGPT roles to our standard roles
        if role == "assistant":
            speaker = "assistant"
        elif role == "user":
            speaker = "user"
        elif role == "tool":
            speaker = "tool"
        else:
            speaker = role

        # Extract text content based on content type
        content_type = content_obj.get("content_type", "")
        content = ""

        if content_type == "text":
            parts = content_obj.get("parts", [])
            # Join all string parts
            text_parts = [
                str(p) for p in parts if isinstance(p, str) and str(p).strip()
            ]
            content = "\n".join(text_parts)
        elif content_type == "code":
            # Code execution results
            content = content_obj.get("text", "")
            language = content_obj.get("language", "")
            if language:
                content = f"```{language}\n{content}\n```"
        elif content_type == "execution_output":
            # Execution output
            content = content_obj.get("text", "")
        elif content_type == "thoughts":
            # Internal reasoning (o1/o3 models)
            thoughts = content_obj.get("thoughts", [])
            if thoughts:
                thought_texts = []
                for thought in thoughts:
                    if isinstance(thought, dict):
                        thought_content = thought.get("content", "")
                        if thought_content:
                            thought_texts.append(thought_content)
                    elif isinstance(thought, str):
                        thought_texts.append(thought)
                content = "\n\n".join(thought_texts)
        else:
            # Try to extract text from parts anyway
            parts = content_obj.get("parts", [])
            if parts:
                text_parts = [
                    str(p) for p in parts if isinstance(p, str) and str(p).strip()
                ]
                content = "\n".join(text_parts)

        if not content.strip():
            return None

        # Extract timestamp
        create_time = msg.get("create_time")
        timestamp = self._format_timestamp(create_time) if create_time else None

        return ParsedMessage(
            speaker=speaker,
            content=content.strip(),
            timestamp=timestamp,
        )
