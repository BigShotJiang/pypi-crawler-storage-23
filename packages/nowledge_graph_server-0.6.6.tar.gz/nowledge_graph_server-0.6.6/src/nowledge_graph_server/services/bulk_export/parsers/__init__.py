"""Bulk export parsers package.

This package contains parser implementations for various export formats.
Each parser inherits from BulkExportParser and handles a specific format.
"""

from typing import Optional, Type

from ..base import BulkExportParser


def get_parser_class(parser_class_name: str) -> Optional[Type[BulkExportParser]]:
    """Get a parser class by name.

    Args:
        parser_class_name: The class name of the parser (e.g., "ChatGPTBulkParser")

    Returns:
        The parser class if found, None otherwise
    """
    # Import parsers lazily to avoid circular imports
    from .chatgpt_html import ChatGPTBulkParser
    from .chatwise_zip import ChatWiseZipParser

    parsers = {
        "ChatGPTBulkParser": ChatGPTBulkParser,
        "ChatWiseZipParser": ChatWiseZipParser,
        # Add more parsers as they are implemented:
        # "ChatGPTJSONBulkParser": ChatGPTJSONBulkParser,
        # "GeminiBulkParser": GeminiBulkParser,
        # "ClaudeBulkParser": ClaudeBulkParser,
    }

    return parsers.get(parser_class_name)


__all__ = [
    "get_parser_class",
]
