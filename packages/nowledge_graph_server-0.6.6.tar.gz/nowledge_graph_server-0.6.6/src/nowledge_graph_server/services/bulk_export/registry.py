"""Format registry for bulk export detection and parser resolution.

The FormatRegistry is the central component for:
1. Detecting export file formats based on signatures
2. Resolving the appropriate parser for a detected format
3. Managing registered format signatures
"""

import re
import structlog
from pathlib import Path
from typing import Dict, List, Optional, Type

from .base import FormatSignature, FormatDetectionResult, BulkExportParser

logger = structlog.get_logger(__name__)


class FormatRegistry:
    """Central registry for format detection and parser resolution.

    The registry uses a two-phase detection approach:
    1. Fast file-level checks (extension, filename patterns)
    2. Accurate content-level checks (pattern matching in file content)

    Signatures are checked in priority order (highest first), and the
    first signature that matches with sufficient confidence is returned.
    """

    def __init__(self):
        self._signatures: Dict[str, FormatSignature] = {}
        self._parsers: Dict[str, Type[BulkExportParser]] = {}
        self._initialized = False

    def register(
        self,
        signature: FormatSignature,
        parser_class: Optional[Type[BulkExportParser]] = None,
    ) -> None:
        """Register a format signature and optionally its parser.

        Args:
            signature: The format signature to register
            parser_class: Optional parser class for this format
        """
        self._signatures[signature.format_id] = signature
        if parser_class is not None:
            self._parsers[signature.format_id] = parser_class
            logger.debug(
                "Registered format with parser",
                format_id=signature.format_id,
                parser=parser_class.__name__,
            )
        else:
            logger.debug(
                "Registered format signature only",
                format_id=signature.format_id,
            )

    def register_parser(
        self, format_id: str, parser_class: Type[BulkExportParser]
    ) -> None:
        """Register a parser for an existing signature.

        Args:
            format_id: The format ID to register the parser for
            parser_class: The parser class

        Raises:
            ValueError: If the format_id is not registered
        """
        if format_id not in self._signatures:
            raise ValueError(f"Unknown format_id: {format_id}")
        self._parsers[format_id] = parser_class
        logger.debug(
            "Registered parser for format",
            format_id=format_id,
            parser=parser_class.__name__,
        )

    def detect_format(self, file_path: str) -> Optional[FormatDetectionResult]:
        """Detect format of a file using signature matching.

        Args:
            file_path: Path to the file to detect

        Returns:
            FormatDetectionResult if a format is detected, None otherwise
        """
        path = Path(file_path)
        if not path.exists():
            logger.warning("File does not exist", file_path=file_path)
            return None

        filename = path.name
        extension = path.suffix.lower()

        # Sort by priority (highest first)
        candidates = sorted(
            self._signatures.values(), key=lambda s: s.priority, reverse=True
        )

        logger.debug(
            "Detecting format",
            file_path=file_path,
            candidates=len(candidates),
        )

        for sig in candidates:
            result = self._match_signature(file_path, filename, extension, sig)
            if result and result.confidence >= sig.min_confidence:
                logger.info(
                    "Format detected",
                    format_id=result.format_id,
                    confidence=result.confidence,
                    matched_patterns=len(result.matched_patterns),
                )
                return result

        logger.debug("No format detected", file_path=file_path)
        return None

    def _match_signature(
        self, file_path: str, filename: str, extension: str, sig: FormatSignature
    ) -> Optional[FormatDetectionResult]:
        """Match a single signature against a file.

        Args:
            file_path: Full path to the file
            filename: Just the filename
            extension: File extension (lowercase, with dot)
            sig: The signature to match against

        Returns:
            FormatDetectionResult if matched, None if not
        """
        confidence = 0.0
        matched_patterns: List[str] = []

        # Phase 1: File-level checks (fast)
        if extension not in sig.file_extensions:
            return None
        confidence += 0.2
        matched_patterns.append(f"extension:{extension}")

        # Filename pattern matching
        filename_matched = False
        for pattern in sig.filename_patterns:
            try:
                if re.match(pattern, filename, re.IGNORECASE):
                    confidence += 0.2
                    matched_patterns.append(f"filename:{pattern}")
                    filename_matched = True
                    break
            except re.error as e:
                logger.warning("Invalid regex pattern", pattern=pattern, error=str(e))

        # If no filename pattern matched but we have patterns defined,
        # we can still proceed with lower confidence
        if not filename_matched and sig.filename_patterns:
            confidence += 0.05  # Small boost for matching extension only

        # Phase 2: Content-level checks (read sample)
        # Skip content matching for binary formats (e.g., .zip)
        binary_extensions = {".zip", ".gz", ".tar", ".7z", ".rar"}
        if extension in binary_extensions:
            # For binary files, rely solely on file-level checks
            # Give a confidence boost if filename matched well
            if filename_matched:
                confidence += 0.3  # Strong filename match for binary
            return FormatDetectionResult(
                format_id=sig.format_id,
                format_name=sig.format_name,
                source=sig.source,
                confidence=confidence,
                matched_patterns=matched_patterns,
                parser_class=sig.parser_class,
                is_bulk=sig.is_bulk,
            )

        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                sample = f.read(sig.sample_size)
        except Exception as e:
            logger.warning("Failed to read file", file_path=file_path, error=str(e))
            return None

        # Check forbidden patterns (instant reject)
        for pattern in sig.forbidden_patterns:
            try:
                if re.search(pattern, sample, re.IGNORECASE | re.DOTALL):
                    logger.debug(
                        "Forbidden pattern matched, rejecting",
                        format_id=sig.format_id,
                        pattern=pattern[:50],
                    )
                    return None
            except re.error:
                pass

        # Check required patterns (all must match)
        if sig.required_patterns:
            required_matched = 0
            for pattern in sig.required_patterns:
                try:
                    if re.search(pattern, sample, re.IGNORECASE | re.DOTALL):
                        required_matched += 1
                        matched_patterns.append(f"required:{pattern[:40]}...")
                except re.error as e:
                    logger.warning(
                        "Invalid required pattern", pattern=pattern, error=str(e)
                    )

            if required_matched < len(sig.required_patterns):
                # Not all required patterns matched
                return None

            confidence += 0.4 * (required_matched / len(sig.required_patterns))

        # Check optional patterns (boost confidence)
        for pattern in sig.optional_patterns:
            try:
                if re.search(pattern, sample, re.IGNORECASE | re.DOTALL):
                    confidence += 0.05
                    matched_patterns.append(f"optional:{pattern[:40]}...")
            except re.error:
                pass

        # Cap confidence at 1.0
        confidence = min(confidence, 1.0)

        return FormatDetectionResult(
            format_id=sig.format_id,
            format_name=sig.format_name,
            source=sig.source,
            confidence=confidence,
            matched_patterns=matched_patterns,
            parser_class=sig.parser_class,
            is_bulk=sig.is_bulk,
        )

    def get_parser(self, format_id: str) -> Optional[BulkExportParser]:
        """Get parser instance for a format.

        Args:
            format_id: The format ID to get parser for

        Returns:
            Parser instance if available, None otherwise
        """
        parser_class = self._parsers.get(format_id)
        if parser_class:
            return parser_class()
        logger.warning("No parser registered for format", format_id=format_id)
        return None

    def has_parser(self, format_id: str) -> bool:
        """Check if a parser is registered for a format.

        Args:
            format_id: The format ID to check

        Returns:
            True if parser is registered
        """
        return format_id in self._parsers

    def list_formats(self) -> List[Dict]:
        """List all registered formats.

        Returns:
            List of format info dicts
        """
        return [
            {
                "format_id": sig.format_id,
                "format_name": sig.format_name,
                "source": sig.source,
                "has_parser": self.has_parser(sig.format_id),
                "is_bulk": sig.is_bulk,
                "file_extensions": sig.file_extensions,
            }
            for sig in self._signatures.values()
        ]

    def get_signature(self, format_id: str) -> Optional[FormatSignature]:
        """Get a format signature by ID.

        Args:
            format_id: The format ID

        Returns:
            FormatSignature if found, None otherwise
        """
        return self._signatures.get(format_id)


# Global registry instance
format_registry = FormatRegistry()


def initialize_registry() -> None:
    """Initialize the format registry with all implemented signatures and parsers.

    This function is called automatically when the module is imported,
    but can be called again to reinitialize if needed.
    """
    from .signatures import IMPLEMENTED_SIGNATURES
    from .parsers import get_parser_class

    for sig in IMPLEMENTED_SIGNATURES:
        parser_class = get_parser_class(sig.parser_class)
        format_registry.register(sig, parser_class)

    logger.info(
        "Format registry initialized",
        signatures=len(format_registry._signatures),
        parsers=len(format_registry._parsers),
    )
