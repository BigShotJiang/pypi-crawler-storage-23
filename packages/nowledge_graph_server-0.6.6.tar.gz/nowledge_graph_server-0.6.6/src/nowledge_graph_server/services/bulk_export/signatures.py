"""Pre-defined format signatures for bulk export detection.

Each signature defines the detection criteria for a specific export format.
To add a new format, define a new FormatSignature here and register it
in the registry with its corresponding parser.
"""

from .base import FormatSignature


# =============================================================================
# ChatGPT Formats
# =============================================================================

CHATGPT_HTML_BULK = FormatSignature(
    format_id="chatgpt_html_bulk",
    format_name="ChatGPT Full Export (HTML)",
    source="ChatGPT",
    version="1.0",
    file_extensions=[".html"],
    filename_patterns=[
        r"^chat\.html$",  # Standard export name
        r"chatgpt.*\.html$",  # Variations
        r".*conversations.*\.html$",
    ],
    required_patterns=[
        r"var\s+jsonData\s*=",  # The embedded JSON variable
        r'"mapping"\s*:',  # Message tree structure
        r'"author"\s*:\s*\{',  # Message author object
    ],
    optional_patterns=[
        r"ChatGPT Data Export",  # Title tag
        r'"content_type"\s*:\s*"text"',  # Content structure
        r'"model_slug"\s*:',  # Model info
        r'"create_time"\s*:',  # Timestamp fields
    ],
    forbidden_patterns=[
        r'class="message-role".*class="message-content"',  # ChatWise HTML format
        r'<div class="message-role">',  # ChatWise structure
    ],
    sample_size=15000,  # Need enough to see the patterns
    min_confidence=0.7,
    priority=200,  # High priority - very specific format
    parser_class="ChatGPTBulkParser",
    is_bulk=True,
)

CHATGPT_JSON_BULK = FormatSignature(
    format_id="chatgpt_json_bulk",
    format_name="ChatGPT Data Export (JSON)",
    source="ChatGPT",
    version="1.0",
    file_extensions=[".json"],
    filename_patterns=[
        r"^conversations\.json$",  # Standard takeout filename
    ],
    required_patterns=[
        r"^\s*\[",  # Starts with JSON array
        r'"conversation_id"\s*:',  # Conversation ID field
        r'"mapping"\s*:',  # Message tree structure
    ],
    optional_patterns=[
        r'"model_slug"\s*:',
        r'"title"\s*:',
        r'"create_time"\s*:',
    ],
    forbidden_patterns=[],
    sample_size=10000,
    min_confidence=0.7,
    priority=150,
    parser_class="ChatGPTJSONBulkParser",
    is_bulk=True,
)


# =============================================================================
# ChatWise Formats
# =============================================================================

CHATWISE_ZIP_BULK = FormatSignature(
    format_id="chatwise_zip_bulk",
    format_name="ChatWise Export (ZIP)",
    source="ChatWise",
    version="1.0",
    file_extensions=[".zip"],
    filename_patterns=[
        r"^chatwise-export-.*\.zip$",  # Standard export name
        r"chatwise.*\.zip$",  # Variations
    ],
    required_patterns=[
        # ZIP files can't be pattern-matched via content,
        # but we check for chat-*.json files inside during parsing
    ],
    optional_patterns=[],
    forbidden_patterns=[],
    sample_size=0,  # No content sampling for ZIP
    min_confidence=0.5,  # Lower threshold since we rely on filename
    priority=180,  # High priority
    parser_class="ChatWiseZipParser",
    is_bulk=True,
)


# =============================================================================
# Gemini Formats (Placeholder - to be implemented when format is analyzed)
# =============================================================================

GEMINI_JSON_BULK = FormatSignature(
    format_id="gemini_json_bulk",
    format_name="Google Gemini Export",
    source="Gemini",
    version="1.0",
    file_extensions=[".json"],
    filename_patterns=[
        r"gemini.*\.json$",
        r"bard.*\.json$",
        r".*gemini_conversations.*\.json$",
    ],
    required_patterns=[
        # TBD - needs analysis of actual Gemini export format
    ],
    optional_patterns=[],
    forbidden_patterns=[],
    sample_size=10000,
    min_confidence=0.7,
    priority=100,
    parser_class="GeminiBulkParser",
    is_bulk=True,
)


# =============================================================================
# Claude Formats (Placeholder - to be implemented when format is analyzed)
# =============================================================================

CLAUDE_JSON_BULK = FormatSignature(
    format_id="claude_json_bulk",
    format_name="Claude Export",
    source="Claude",
    version="1.0",
    file_extensions=[".json"],
    filename_patterns=[
        r"claude.*\.json$",
        r".*claude_conversations.*\.json$",
    ],
    required_patterns=[
        # TBD - needs analysis of actual Claude export format
    ],
    optional_patterns=[],
    forbidden_patterns=[],
    sample_size=10000,
    min_confidence=0.7,
    priority=100,
    parser_class="ClaudeBulkParser",
    is_bulk=True,
)


# =============================================================================
# All signatures list for easy registration
# =============================================================================

ALL_SIGNATURES = [
    CHATGPT_HTML_BULK,
    CHATGPT_JSON_BULK,
    CHATWISE_ZIP_BULK,
    GEMINI_JSON_BULK,
    CLAUDE_JSON_BULK,
]

# Only signatures with implemented parsers
IMPLEMENTED_SIGNATURES = [
    CHATGPT_HTML_BULK,
    CHATWISE_ZIP_BULK,
]
