"""MLX-based local LLM provider using Qwen3-4B. This service uses MLX with Qwen3-4B for on-device inference without API dependencies."""
import asyncio
import gc
import os
import platform
import threading
import time
from pathlib import Path
from typing import List, Optional, Any

import structlog

from concurrent.futures import ThreadPoolExecutor

from nowledge_graph_server.services.base_llm import (
    BaseLLMProvider,
    LLMGenerationConfig,
)
from nowledge_graph_server.services.mlx_locks import get_mlx_inference_lock

# MLX is only available on macOS Apple Silicon
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"

# Conditionally import MLX modules (only on macOS)
_mlx_load: Optional[Any] = None
_mlx_generate: Optional[Any] = None
_mlx_make_sampler: Optional[Any] = None

if IS_APPLE_SILICON:
    try:
        from mlx_lm.utils import load as _mlx_load  # type: ignore[misc]
        from mlx_lm.generate import generate as _mlx_generate  # type: ignore[misc]
        from mlx_lm.sample_utils import make_sampler as _mlx_make_sampler  # type: ignore[misc]
    except ImportError:
        # On macOS but MLX not installed - this is an error
        raise RuntimeError(
            "MLX loading failure, Nowledge Mem might be installed on an"
            "unsupported environment, read"
            "https://mem.nowledge.co/docs/installation#system-requirements for"
            "details")
else:
    # On non-macOS platforms, MLX is not available - that's OK
    pass


logger = structlog.get_logger(__name__)


class MLXLocalProvider(BaseLLMProvider):
    """MLX-based local LLM provider using Qwen3-4B.
    
    NOTE: Only available on macOS Apple Silicon.
    """

    def __init__(
        self,
        model_name: str = "mlx-community/Qwen3-4B-Instruct-2507-DDWQ",
        cache_dir: str | None = None,
        cache_only: bool = True,
    ):
        if not IS_APPLE_SILICON:
            raise RuntimeError(
                "MLXLocalProvider is only available on macOS Apple Silicon. "
                "On Intel Mac/Windows/Linux, please use remote LLM providers (litellm)."
            )
        if _mlx_load is None or _mlx_generate is None or _mlx_make_sampler is None:
            raise RuntimeError(
                "MLX libraries are not available. "
                "Please install mlx-lm: pip install mlx-lm"
            )
        
        self.model_name = model_name
        self.cache_dir = cache_dir
        self.cache_only = cache_only
        self.model = None
        self.tokenizer = None
        self._initialized = False
        self._gen_mutex = threading.Lock()
        # Dedicated single-thread executor to avoid thread-pool
        # contention and match prior sequential behavior
        self._executor: ThreadPoolExecutor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="mlx-gen")

        # Idle tracking for memory management
        self._last_used_at: float = 0.0

        # Set HuggingFace cache directory immediately
        self._setup_cache_environment()

    def _setup_cache_environment(self) -> None:
        """Set up HuggingFace cache environment variables."""

        if self.cache_dir:
            # Treat cache_dir as the HuggingFace root (ends with .../.cache/huggingface)
            hf_home = str(Path(self.cache_dir))
            os.environ["HF_HOME"] = hf_home
            os.environ["HUGGINGFACE_HUB_CACHE"] = str(Path(hf_home) / "hub")
            logger.debug(
                "Set HuggingFace cache directory",
                cache_dir=self.cache_dir,
                hf_home=hf_home,
                hf_hub_cache=os.environ["HUGGINGFACE_HUB_CACHE"],
            )

        if self.cache_only:
            # Set cache-only mode environment variables
            os.environ["HF_HUB_OFFLINE"] = "1"
            os.environ["TRANSFORMERS_OFFLINE"] = "1"
            logger.debug("Enabled HuggingFace cache-only mode")

    def _is_model_cached(self) -> bool:
        """Check if the MLX model is cached locally (HuggingFace or ModelScope)."""
        try:

            def has_weights(dir_path: Path) -> bool:
                if not dir_path.exists():
                    return False
                # HF: expect snapshots/<hash>/
                snapshots_dir = dir_path / "snapshots"
                candidates = []
                if snapshots_dir.exists():
                    candidates = [d for d in snapshots_dir.iterdir() if d.is_dir()]
                else:
                    candidates = [dir_path]
                for c in candidates:
                    has_config = (c / "config.json").exists()
                    has_single = (c / "model.safetensors").exists()
                    has_sharded = any(p.name.startswith("model-") and p.suffix == ".safetensors" for p in c.iterdir())
                    has_weights_format = any(
                        p.name.startswith("weights.") and p.suffix == ".safetensors" for p in c.iterdir()
                    )
                    has_mlx = any(p.suffix == ".mlx" for p in c.iterdir())
                    if has_config and (has_single or has_sharded or has_weights_format or has_mlx):
                        return True
                return False

            # 1. Check HuggingFace cache locations
            cache_locations: List[Path] = []
            modelscope_locations: List[Path] = []
            hf_root_candidates: List[Path] = []

            if self.cache_dir:
                # Custom cache directory
                cache_root = Path(self.cache_dir)
                cache_locations.append(cache_root / "hub" / f"models--{self.model_name.replace('/', '--')}")
                hf_root_candidates.append(cache_root)
            else:
                # Check environment variables
                hf_home = os.environ.get("HF_HOME")
                hf_cache = os.environ.get("HUGGINGFACE_HUB_CACHE")

                if hf_home:
                    hf_root = Path(hf_home)
                    cache_locations.append(hf_root / "hub" / f"models--{self.model_name.replace('/', '--')}")
                    hf_root_candidates.append(hf_root)
                elif hf_cache:
                    hf_cache_path = Path(hf_cache)
                    cache_locations.append(hf_cache_path / f"models--{self.model_name.replace('/', '--')}")
                    hf_root_candidates.append(
                        hf_cache_path.parent if hf_cache_path.name == "hub" else hf_cache_path
                    )
                else:
                    # Default HuggingFace cache directory
                    default_hf_root = Path.home() / ".cache" / "huggingface"
                    cache_locations.append(
                        default_hf_root / "hub" / f"models--{self.model_name.replace('/', '--')}"
                    )
                    hf_root_candidates.append(default_hf_root)

            # Check HuggingFace cache format with weights verification
            for model_cache_path in cache_locations:
                if has_weights(model_cache_path):
                    logger.info(
                        "Found cached MLX model in HF cache",
                        model=self.model_name,
                        path=str(model_cache_path),
                    )
                    return True

            # 2. Check ModelScope cache locations (default + ModelScope format inside HF root)
            try:
                org_name, model_name_part = self.model_name.split("/", 1)
            except ValueError:
                org_name, model_name_part = None, None

            if org_name and model_name_part:
                modelscope_cache_root = Path.home() / ".cache" / "modelscope"
                if modelscope_cache_root.exists():
                    modelscope_model_path = (
                        modelscope_cache_root / "hub" / "models" / org_name / model_name_part
                    )
                    modelscope_locations.append(modelscope_model_path)

                for hf_root in hf_root_candidates:
                    modelscope_locations.append(hf_root / org_name / model_name_part)

            for modelscope_path in modelscope_locations:
                if has_weights(modelscope_path):
                    logger.info(
                        "Found cached MLX model in ModelScope cache",
                        model=self.model_name,
                        path=str(modelscope_path),
                    )
                    return True

            logger.debug("MLX model not found in any cache", model=self.model_name)
            return False

        except Exception as e:
            logger.warning("Failed to check MLX model cache", model=self.model_name, error=str(e))
            return False

    async def initialize(self) -> None:
        """Initialize the MLX model and tokenizer."""
        if self._initialized:
            return

        logger.info(
            "Loading MLX model",
            model=self.model_name,
            offline_mode=self.cache_only,
            cache_dir=self.cache_dir,
        )

        try:
            # Check if model is cached before trying to download
            if self.cache_only and not self._is_model_cached():
                # Provide a clearer hint about expected cache layout
                _model_name_hf_cache = self.model_name.replace('/', '--')
                _model_name_hf_cache_path = f"models--{_model_name_hf_cache}/snapshots/<hash>/"
                raise RuntimeError(
                    f"Model {self.model_name} not found in local cache. "
                    f"Ensure HF cache contains {_model_name_hf_cache_path} with config.json and weights."
                )

            # Load model in a thread pool to avoid blocking
            loop = asyncio.get_event_loop()

            # Create a loading function that uses our offline-aware loader
            def load_model():
                try:
                    # Use our custom offline loader to bypass HuggingFace API calls
                    from ..utils.offline_mlx_loader import load_offline_mlx_model  # type: ignore[misc]

                    logger.debug("Using offline-aware MLX loader", model=self.model_name)

                    return load_offline_mlx_model(
                        path_or_hf_repo=self.model_name,
                        lazy=True,
                    )
                except Exception as e:
                    if self.cache_only:
                        logger.error(
                            "Failed to load MLX model in cache-only mode",
                            model=self.model_name,
                            error=str(e),
                        )
                        raise RuntimeError(f"Failed to load cached model {self.model_name}: {str(e)}")
                    else:
                        # Fallback to standard MLX loading (may download)
                        logger.warning(
                            "Failed to load with offline loader, attempting standard download",
                            model=self.model_name,
                        )
                        if _mlx_load is None:
                            raise RuntimeError("MLX is not available on this platform")
                        return _mlx_load(self.model_name, lazy=True)

            self.model, self.tokenizer = await loop.run_in_executor(None, load_model)
            self._initialized = True
            self._last_used_at = time.monotonic()  # start idle timer from load time
            logger.info("MLX model loaded successfully", model=self.model_name)
        except Exception as e:
            logger.warning(
                "Failed to load MLX model, need to download from Settings > Models.",
                model=self.model_name,
                offline_mode=self.cache_only,
                error=str(e),
            )

    async def generate_response(self, prompt: str, config: LLMGenerationConfig, operation_name: Optional[str] = None) -> str:
        """Generate response using MLX."""
        if not self._initialized:
            await self.initialize()

        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model or tokenizer not properly initialized")

        self._last_used_at = time.monotonic()

        try:
            logger.debug(
                "Generating response",
                prompt_char_length=len(prompt),
                max_tokens=config.max_tokens,
                use_thinking=config.use_thinking,
                config=config,
            )

            # Create sampler with Qwen-4B best practices
            # Use config values if provided, otherwise use Qwen3-4B recommended defaults
            if _mlx_make_sampler is None:
                raise RuntimeError("MLX is not available on this platform")
            sampler = _mlx_make_sampler(
                temp=config.temperature if config.temperature is not None else 0.7,
                top_p=config.top_p if config.top_p is not None else 0.8,
                top_k=config.top_k if config.top_k is not None else 20,
                min_p=config.min_p if config.min_p is not None else 0.0,
            )

            # Generate response using MLX-LM in thread pool to avoid blocking event loop
            loop = asyncio.get_event_loop()

            # Type assertions and local capture after None check
            assert self.model is not None, "Model should be initialized"
            assert self.tokenizer is not None, "Tokenizer should be initialized"
            model = self.model
            tokenizer = self.tokenizer

            # Guard MLX generate with a mutex to prevent native crashes from concurrent calls
            def _do_generate():
                with self._gen_mutex:
                    if _mlx_generate is None:
                        raise RuntimeError("MLX is not available on this platform")
                    return _mlx_generate(
                        model=model,
                        tokenizer=tokenizer,
                        prompt=prompt,
                        max_tokens=config.max_tokens,
                        verbose=False,
                        sampler=sampler,
                    )

            # Use shared MLX lock to prevent Metal conflicts with embedding service
            mlx_lock = get_mlx_inference_lock()
            if mlx_lock is not None:
                async with mlx_lock:
                    response = await loop.run_in_executor(self._executor, _do_generate)
            else:
                response = await loop.run_in_executor(self._executor, _do_generate)
            logger.debug("MLX prompt", prompt=prompt)

            # Release Metal KV cache and compilation artifacts after inference.
            # Model weights stay loaded; only transient buffers are freed.
            self._clear_metal_cache()

            # Clean response: strip at special tokens that indicate end of generation
            # MLX-LM sometimes includes <|endoftext|>, <|im_end|>, etc. in output
            clean_response = response
            for stop_marker in ["<|endoftext|>", "<|im_end|>", "<|end|>", "<|eot_id|>"]:
                if stop_marker in clean_response:
                    clean_response = clean_response.split(stop_marker)[0]

            logger.debug("MLX response", response=clean_response)

            return clean_response

        except Exception as e:
            logger.error("LLM generation failed", error=str(e))
            raise

    # ------------------------------------------------------------------
    # Idle memory management
    # ------------------------------------------------------------------

    def is_idle(self, threshold_seconds: int = 300) -> bool:
        """Return True if the model has not been used for *threshold_seconds*."""
        if not self._initialized:
            return False
        return (time.monotonic() - self._last_used_at) > threshold_seconds

    async def unload(self) -> None:
        """Release model weights and Metal memory to reclaim RAM.

        The provider can be seamlessly reloaded via ``initialize()`` on next use
        because ``generate_response()`` already checks ``_initialized``.
        """
        if not self._initialized:
            return

        logger.info(
            "Unloading MLX LLM model to reclaim memory",
            model=self.model_name,
            idle_seconds=int(time.monotonic() - self._last_used_at) if self._last_used_at else 0,
        )

        self.model = None
        self.tokenizer = None
        self._initialized = False

        # Release Metal caches and run GC
        self._clear_metal_cache()
        gc.collect()

    def _clear_metal_cache(self) -> None:
        """Best-effort Metal cache clear (KV cache, compilation artifacts)."""
        try:
            import mlx.core as mx
            if hasattr(mx, "clear_cache"):
                mx.clear_cache()
            elif hasattr(mx, "metal") and hasattr(mx.metal, "clear_cache"):
                mx.metal.clear_cache()
        except Exception:
            pass

    async def close(self) -> None:
        """Cleanup MLX resources."""
        self.model = None
        self.tokenizer = None
        self._initialized = False
        self._clear_metal_cache()
        try:
            self._executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
