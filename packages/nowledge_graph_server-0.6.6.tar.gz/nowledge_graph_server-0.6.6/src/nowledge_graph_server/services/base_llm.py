from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from abc import ABC, abstractmethod
import structlog

logger = structlog.get_logger(__name__)


class LLMGenerationConfig(BaseModel):
    """Configuration for LLM generation."""

    max_tokens: int | None = 2048
    ###########
    # Qwen3 best practices for non-thinking mode
    # Note: These are Optional to allow remote LLM providers to use their own defaults
    # Local LLM should explicitly set these values
    temperature: float | None = None  # Default: None (let provider decide)
    top_p: float | None = None  # Default: None (let provider decide)
    top_k: int | None = None  # Default: None (let provider decide)
    min_p: float | None = None  # Default: None (let provider decide)
    ###########
    use_thinking: bool = False


class BaseLLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the LLM provider."""
        pass

    @abstractmethod
    async def generate_response(self, prompt: str, config: LLMGenerationConfig, operation_name: Optional[str] = None) -> str:
        """Generate a response from the LLM.
        
        Args:
            prompt: The prompt to send to the LLM
            config: Generation configuration
            operation_name: Optional operation name for tracking (e.g., "memory_distillation", "entity_extraction")
        """
        pass

    @abstractmethod
    async def close(self) -> None:
        """Cleanup the LLM provider."""
        pass


class EntityExtractionResult(BaseModel):
    """Result of entity extraction."""

    entities: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    confidence: float


class MemoryDistillationResult(BaseModel):
    """Result of memory distillation."""

    memories: List[Dict[str, Any]]
    entities: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    insights: List[Dict[str, Any]]
    summary: str


CONSOLIDATION_PROMPT_TEMPLATE = """Consolidate these {num_memories} memories into the best 3.

MEMORIES:
{memories_text}

Select and refine the 3 most valuable memories. Focus on:
• Unique insights or decisions
• Actionable information
• Non-redundant content

TEMPORAL: If any source memory has temporal info, preserve it in the consolidated memory.

Output ONLY this JSON format:
{{"memories": [{{"title": "Memory title", "content": "Refined content", "importance": IMPORTANCE_SCORE, "confidence": CONFIDENCE_SCORE, "tags": ["tag1"], "context": "Why this matters", "temporal": {{"type": "exact", "start": "2024", "end": null, "confidence": 0.9, "context": "past"}} }}]}}

Note: If no date info, use "temporal": null

SCORING (0.0-1.0):
- importance: How valuable for future reference (critical insights=0.9+, useful info=0.5-0.7)
- confidence: How certain the content is accurate (clear facts=0.9+, some uncertainty=0.5-0.7)

JSON:"""


CHUNK_PROMPT_TEMPLATE = """Extract 1-2 key memories from this conversation chunk.

CHUNK {chunk_number}/{total_chunks}:
{chunk_content}

Focus on:
• Important decisions or solutions
• Key insights or realizations
• Actionable information

TEMPORAL EXTRACTION:
- If a specific date/year is mentioned (e.g., "in 2020", "last March"), include it
- If no date is explicitly mentioned, set temporal to null
- Do NOT invent dates - only extract what is explicitly stated

Output ONLY this JSON format:
{{"memories": [{{"title": "Memory title", "content": "Key content", "importance": IMPORTANCE_SCORE, "confidence": CONFIDENCE_SCORE, "tags": ["tag1", "tag2"], "context": "Why this matters", "temporal": {{"type": "exact", "start": "2024", "end": null, "confidence": 0.9, "context": "past"}} }}], "summary": "Brief chunk summary"}}

Note: If no date is mentioned, use "temporal": null

SCORING GUIDELINES:
- importance (0.0-1.0): How valuable this memory is for future reference
  - 0.9-1.0: Critical insights, key decisions, major breakthroughs
  - 0.7-0.9: Important learnings, significant solutions
  - 0.5-0.7: Useful information, minor insights
  - Below 0.5: Not worth preserving
- confidence (0.0-1.0): How certain you are about the memory content
  - 0.9-1.0: Clear, factual, well-supported information
  - 0.7-0.9: Good understanding, minor ambiguity
  - 0.5-0.7: Some uncertainty, but generally reliable
  - Below 0.5: Significant uncertainty, contradictory info

JSON:"""


DISTILLATION_MEMORY_PROMPT_TEMPLATE = """Analyze this conversation to extract 1-3 of the most valuable, actionable memories.

CONVERSATION:
{thread_content}

ANALYSIS FRAMEWORK - Focus on memories that contain:
• DECISIONS: What was decided and WHY? What alternatives were considered?
• KEY INSIGHTS: Breakthrough understanding, realizations, or mental models that change thinking
• SOLUTIONS: Specific problems solved and the approaches that worked
• IMPORTANT FACTS: Critical information that will be valuable in the future
• LESSONS LEARNED: What worked, what didn't, and the reasoning behind it
• STRATEGIC IMPLICATIONS: How this changes future decisions or approaches

MEMORY QUALITY TEST - Each memory should pass:
✓ Would I want to remember this 6 months from now?
✓ Does this change how I think about or approach something?
✓ Is this specific enough to be actionable?
✓ Does it capture the WHY behind decisions, not just the what?

EXTRACTION PRIORITIES:
- Quality over quantity (1-3 exceptional memories beat 5 mediocre ones)
- Capture the reasoning and context, not just facts
- Focus on content with lasting value and implications
- Be specific and concrete rather than vague
- Include the broader significance of what was learned/decided

TEMPORAL EXTRACTION:
- If a specific date/year is mentioned (e.g., "in 2020", "last March", "Q3 2023"), include it
- If no date is explicitly mentioned, set temporal to null
- Do NOT invent dates - only extract what is explicitly stated
- Format: YYYY, YYYY-MM, or YYYY-MM-DD

Output this EXACT JSON format:
{{"memories": [{{"title": "Clear, specific title (max 12 words)", "content": "Detailed explanation including context, reasoning, and implications", "importance": 0.9, "confidence": 0.85, "tags": ["decision", "insight", "solution", "lesson", "fact"], "context": "Why this matters and broader implications", "temporal": {{"type": "exact", "start": "2024", "end": null, "confidence": 0.9, "context": "past"}} }}], "summary": "Brief overview of key outcomes and their significance"}}

Note: If no date is mentioned, use "temporal": null

JSON:"""

ENTITY_EXTRACTION_PROMPT_SINGLE_MEMORY_TEMPLATE = """Extract entities and relationships from text. Return only valid JSON.

RULES:
- Extract meaningful entities: tools, technologies, concepts, people, organizations, methods, etc.
- Keep entity names in their ORIGINAL LANGUAGE from the source text (do not translate)
- Use appropriate type names based on context (be flexible and descriptive)
- For relationships, both source and target must be extracted entities
- Include context showing how entities connect
- DIRECTLY OUTPUT THE JSON, NO THINKING, NO EXPLANATION, NO COMMENTS
- Focus on the most important entities and relationships, up to 10 entities and 20 relationships

EXAMPLE:
Text: "Sarah uses Docker containers with PostgreSQL database for her microservices architecture at Netflix."
JSON: {{"entities":[{{"name":"Sarah","type":"PERSON","description":"Developer/engineer","confidence":0.9}},{{"name":"Docker","type":"CONTAINERIZATION_TOOL","description":"Container platform","confidence":0.8}},{{"name":"PostgreSQL","type":"DATABASE","description":"Relational database system","confidence":0.7}},{{"name":"microservices architecture","type":"DESIGN_PATTERN","description":"Distributed system approach","confidence":0.71}},{{"name":"Netflix","type":"COMPANY","description":"Technology company","confidence":0.5}}],"relationships":[{{"source":"Sarah","target":"Docker","relation":"USES","context":"Sarah uses Docker containers","confidence":0.8}},{{"source":"Docker","target":"PostgreSQL","relation":"WORKS_WITH","context":"Docker containers with PostgreSQL database","confidence":0.7}},{{"source":"PostgreSQL","target":"microservices architecture","relation":"ENABLES","context":"PostgreSQL database for her microservices architecture","confidence":0.32}},{{"source":"Sarah","target":"Netflix","relation":"WORKS_AT","context":"works at Netflix","confidence":0.5}}],"confidence":0.85}}

Text: {memory_text}
JSON:"""
