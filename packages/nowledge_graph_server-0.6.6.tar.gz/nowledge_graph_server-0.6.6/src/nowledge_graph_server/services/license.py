"""License service for reading and activating licenses.

Supports both Tauri-managed license files and direct Python-side activation
for headless/server deployments (Linux servers without Tauri).
"""

import base64
import json
import time
from pathlib import Path
from typing import Optional, Dict, Any, Literal
import hashlib
import platform
import getpass
import structlog

import httpx
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import load_der_public_key

from nowledge_graph_server.utils.app_paths import (
    get_app_config_dir,
    get_legacy_app_data_dir,
    resolve_config_file_path,
)

logger = structlog.get_logger(__name__)

# License server
WORKER_ORIGIN = "https://backbone-mem.nowledge.co"

# Ed25519 public key for license signature verification (SPKI DER, base64)
PUBKEY_BASE64 = "MCowBQYDK2VwAyEANFKjLPH5EpqN/dK0qZU9QDahJ8ORnRlAsC3Ilrgoer4="

# Platform string for activation request
_PLATFORM_MAP = {"Darwin": "mac", "Linux": "linux", "Windows": "windows"}


class LicenseService:
    """Service for reading license status from the Tauri-managed license file."""

    # Device fingerprint salt (must match Rust implementation)
    DEVICE_SALT = "nowledge-mem-app-salt-1-xffd"

    def __init__(self):
        self._cached_license: Optional[Dict[str, Any]] = None
        self._cache_mtime: Optional[float] = None
        self._device_id = self._compute_device_id()
        # Migrate license files from legacy app-data location if needed.
        self._migrate_legacy_license_files()

    def _migrate_legacy_license_files(self) -> None:
        """Migrate license files from legacy location to correct location.

        Older builds stored license files in app data dir instead of app config dir.
        Migrate them transparently so upgrades are non-breaking.
        """
        legacy_dir = get_legacy_app_data_dir()
        current_dir = self._get_app_data_dir()
        if legacy_dir == current_dir:
            return

        # Files to migrate
        files_to_migrate = ["license.json", "device_auth.json"]

        for filename in files_to_migrate:
            legacy_path = legacy_dir / filename
            current_path = current_dir / filename

            # Only migrate if:
            # 1. Legacy file exists
            # 2. Current location doesn't have the file (don't overwrite newer files)
            if legacy_path.exists() and not current_path.exists():
                try:
                    # Ensure target directory exists
                    current_dir.mkdir(parents=True, exist_ok=True)

                    # Copy file to new location (keep original as backup)
                    import shutil

                    shutil.copy2(legacy_path, current_path)
                    logger.info(
                        "Migrated license file from legacy location",
                        filename=filename,
                        from_path=str(legacy_path),
                        to_path=str(current_path),
                    )
                except Exception as e:
                    logger.warning(
                        "Failed to migrate license file",
                        filename=filename,
                        error=str(e),
                    )

    def _get_app_data_dir(self) -> Path:
        """Get the canonical app config directory path.

        Paths must match Tauri's appConfigDir() for each platform:
        - macOS: ~/Library/Application Support/co.nowledge.mem.desktop
        - Windows: %APPDATA%/co.nowledge.mem.desktop
        - Linux: ~/.config/co.nowledge.mem.desktop (XDG_CONFIG_HOME)
        """
        return get_app_config_dir()

    def _get_license_path(self) -> Path:
        """Get canonical write path to the license file."""
        return self._get_app_data_dir() / "license.json"

    def _get_device_auth_path(self) -> Path:
        """Get canonical write path to the device authorization file."""
        return self._get_app_data_dir() / "device_auth.json"

    def _get_stable_machine_id(self) -> str:
        """Get a stable machine identifier that doesn't change with network state.
        
        On macOS, platform.node() returns the network hostname which can change
        between WiFi on/off (e.g., "Mac.lan" vs "m2-96.local").
        We use the ComputerName (user-assigned name) which is stable.
        """
        system = platform.system()
        
        if system == "Darwin":
            # On macOS, use scutil to get the stable ComputerName
            try:
                import subprocess
                result = subprocess.run(
                    ["scutil", "--get", "ComputerName"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip()
            except Exception:
                pass  # Fall through to default
        
        # For Linux/Windows or fallback, use platform.node()
        return platform.node() or "unknown"

    def _get_platform_name(self) -> str:
        """Get platform name matching Rust's whoami::platform().to_string() values."""
        system = platform.system()
        if system == "Darwin":
            return "Mac OS"  # Match Rust output exactly (with space)
        elif system == "Linux":
            return "Linux"
        elif system == "Windows":
            return "Windows"
        else:
            return system

    def _compute_device_id(self) -> str:
        """Compute a stable device fingerprint.

        This should match the Rust implementation for consistency.
        IMPORTANT: Uses stable machine ID instead of hostname, which can change with network state.
        """
        machine_id = self._get_stable_machine_id()
        platform_name = self._get_platform_name()
        username = getpass.getuser()

        # Create device fingerprint (must match Rust format exactly)
        fingerprint = f"{machine_id}:{platform_name}:{username}:{self.DEVICE_SALT}"

        # Hash it
        device_id = hashlib.sha256(fingerprint.encode()).hexdigest()
        return device_id

    def _compute_legacy_device_id(self) -> str:
        """Compute device ID using the LEGACY method (hostname-based).
        
        This is needed for backward compatibility with existing users who activated
        with the old hostname-based device ID.
        """
        hostname = platform.node() or "unknown"
        platform_name = self._get_platform_name()
        username = getpass.getuser()

        fingerprint = f"{hostname}:{platform_name}:{username}:{self.DEVICE_SALT}"
        return hashlib.sha256(fingerprint.encode()).hexdigest()

    def _device_id_matches(self, auth_device_id: str) -> bool:
        """Check if a given device ID matches either the current stable ID or the legacy ID.
        
        This provides backward compatibility for existing users.
        """
        # Check stable (new) device ID
        if auth_device_id == self._device_id:
            return True
        
        # Check legacy (hostname-based) device ID for backward compatibility
        legacy_id = self._compute_legacy_device_id()
        if auth_device_id == legacy_id:
            logger.debug("Legacy device ID detected - will be migrated on next activation")
            return True
        
        return False

    def read_license(self) -> Optional[Dict[str, Any]]:
        """Read and cache the license file.

        Returns:
            License data if available, None if no license file exists
        """
        license_path = resolve_config_file_path("license.json")

        # Check if file exists
        if not license_path.exists():
            logger.debug("No license file found", path=str(license_path))
            return None

        try:
            # Check if cache is still valid
            current_mtime = license_path.stat().st_mtime
            if self._cached_license and self._cache_mtime == current_mtime:
                return self._cached_license

            # Read and parse license file
            with open(license_path, "r") as f:
                license_data = json.load(f)

            # Update cache
            self._cached_license = license_data
            self._cache_mtime = current_mtime

            # logger.debug("License file loaded", uid=license_data.get('uid'))
            return license_data

        except Exception as e:
            logger.error("Failed to read license file", error=str(e))
            return None

    def read_device_auth(self) -> Optional[Dict[str, Any]]:
        """Read the device authorization file.

        Returns:
            Device auth data if available and valid, None otherwise
        """
        auth_path = resolve_config_file_path("device_auth.json")

        if not auth_path.exists():
            logger.debug("No device auth file found")
            return None

        try:
            with open(auth_path, "r") as f:
                auth_data = json.load(f)

            # Verify this auth is for the current device
            expected_device_id = self._device_id
            actual_device_id = auth_data.get("device_id")
            # logger.debug(f"Expected device ID: {expected_device_id}")
            # logger.debug(f"Actual device ID: {actual_device_id}")
            if actual_device_id != expected_device_id:
                logger.warning(
                    "Device auth is for different device",
                    expected_device_id=expected_device_id,
                    actual_device_id=actual_device_id,
                )
                return None

            # Check if auth has expired
            import time

            if auth_data.get("authorized_until", 0) < time.time():
                logger.info("Device auth has expired")
                return None

            return auth_data

        except Exception as e:
            logger.error("Failed to read device auth", error=str(e))
            return None

    def get_tier(self) -> Literal["free", "pro"]:
        """Get the license tier based on what the user PAID for.

        This returns "pro" if the user has a valid (non-expired) license,
        regardless of device authorization status. Use is_device_activated()
        to check if the current device is authorized to use pro features.

        Returns:
            "pro" if valid license exists, "free" otherwise
        """
        # Step 1: Check license file exists and is valid
        license_data = self.read_license()
        if not license_data:
            logger.debug("No valid license found")
            return "free"

        # Step 2: Check if license is expired
        import time

        exp = license_data.get("exp", 0)
        if 0 < exp < time.time():
            logger.debug("License expired", exp=exp)
            return "free"

        # User has a valid pro license
        return "pro"

    def is_device_activated(self) -> bool:
        """Check if the current device is authorized to use pro features.

        IMPORTANT: If a device was EVER activated for a valid license, we trust it.
        Network failures during re-activation should NOT degrade the user experience.
        The device auth expiration is just a periodic check-in, not a hard cutoff.

        Returns:
            True if device has authorization (current or expired) matching a valid license
        """
        # Step 1: Check we have a valid license first
        license_data = self.read_license()
        if not license_data:
            return False

        # Step 2: Check if license itself is expired
        import time
        exp = license_data.get("exp", 0)
        if 0 < exp < time.time():
            return False  # License expired - this IS a hard cutoff

        # Step 3: Check device authorization exists (even if expired)
        # If the device was ever activated for this license, we trust it
        auth_path = resolve_config_file_path("device_auth.json")
        if not auth_path.exists():
            logger.debug("No device authorization file")
            return False

        try:
            with open(auth_path, "r") as f:
                auth_data = json.load(f)

            # IMPORTANT: On macOS, hostname can change unpredictably (WiFi on/off, etc.)
            # This makes device_id matching unreliable.
            # New approach: If license_id matches and device_auth exists, trust the user.
            # They clearly activated this license at some point.
            
            # Verify device auth matches license (this is the key check)
            if auth_data.get("license_id") != license_data.get("lid"):
                logger.warning("Device auth doesn't match license")
                return False

            # License matches - trust this device even if device_id doesn't match
            # (device_id may differ due to hostname changes on macOS)
            auth_device_id = auth_data.get("device_id", "")
            if not self._device_id_matches(auth_device_id):
                logger.debug("Device ID mismatch (hostname may have changed) - trusting based on license_id match")

            # Device was activated for this license at some point - trust it!
            return True

        except Exception as e:
            logger.error("Failed to read device auth", error=str(e))
            return False

    def get_activation_status(self) -> Literal["activated", "expired", "not_activated"]:
        """Get detailed activation status for the current device.

        Returns:
            "activated" - Device is authorized and authorization is valid
            "expired" - Device was authorized but authorization has expired
            "not_activated" - Device was never activated or no license exists
        """
        license_data = self.read_license()
        if not license_data:
            return "not_activated"

        auth_path = resolve_config_file_path("device_auth.json")
        if not auth_path.exists():
            return "not_activated"

        try:
            with open(auth_path, "r") as f:
                auth_data = json.load(f)

            # IMPORTANT: Trust based on license_id match, not device_id
            # (device_id can change due to hostname instability on macOS)
            if auth_data.get("license_id") != license_data.get("lid"):
                return "not_activated"

            # License matches - check if auth has expired
            import time
            if auth_data.get("authorized_until", 0) < time.time():
                return "expired"

            return "activated"

        except Exception as e:
            logger.error("Failed to check activation status", error=str(e))
            return "not_activated"

    def get_email(self) -> Optional[str]:
        """Get the license email (uid field)."""
        license_data = self.read_license()
        return license_data.get("uid") if license_data else None

    def get_device_id(self) -> str:
        """Get the computed device ID for this machine."""
        return self._device_id

    # =========================================================================
    # License activation (ported from Rust license.rs)
    # =========================================================================

    @staticmethod
    def _decode_license_b64(license_code_b64: str) -> Dict[str, Any]:
        """Decode a base64-encoded license code into a license dict.

        Raises ValueError on invalid input.
        """
        cleaned = license_code_b64.strip()
        if not cleaned:
            raise ValueError("License key cannot be empty")

        try:
            decoded = base64.b64decode(cleaned)
        except Exception as e:
            raise ValueError(f"Invalid license key format: {e}") from e

        try:
            license_data = json.loads(decoded)
        except Exception as e:
            raise ValueError(f"Invalid license key: malformed license data ({e})") from e

        required = {"uid", "lid", "max_devices", "exp", "created", "sig"}
        missing = required - set(license_data.keys())
        if missing:
            raise ValueError(f"Invalid license key: missing fields {missing}")

        return license_data

    @staticmethod
    def _canonical_unsigned_json(lic: Dict[str, Any]) -> str:
        """Build the canonical JSON string for signature verification.

        MUST match the Rust implementation: exact key order uid, lid, max_devices, exp, created.
        """
        return (
            f'{{"uid":"{lic["uid"]}","lid":"{lic["lid"]}",'
            f'"max_devices":{lic["max_devices"]},'
            f'"exp":{lic["exp"]},"created":{lic["created"]}}}'
        )

    @staticmethod
    def _verify_signature(lic: Dict[str, Any]) -> None:
        """Verify the Ed25519 signature on a license.

        Raises ValueError if verification fails.
        """
        message = LicenseService._canonical_unsigned_json(lic)
        sig_bytes = base64.b64decode(lic["sig"])
        pubkey_der = base64.b64decode(PUBKEY_BASE64)

        public_key = load_der_public_key(pubkey_der)
        if not isinstance(public_key, Ed25519PublicKey):
            raise ValueError("Public key is not Ed25519")

        try:
            public_key.verify(sig_bytes, message.encode())
        except Exception as e:
            raise ValueError(f"Signature verification failed: {e}") from e

    def _save_license_file(self, lic: Dict[str, Any]) -> None:
        """Save the license dict to license.json."""
        path = self._get_license_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(lic, indent=2), encoding="utf-8")
        # Invalidate cache so next read picks up the new file
        self._cached_license = None
        self._cache_mtime = None

    def _save_device_auth(self, auth: Dict[str, Any]) -> None:
        """Save device authorization to device_auth.json."""
        path = self._get_device_auth_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(auth, indent=2), encoding="utf-8")

    async def activate_license(
        self,
        license_code_b64: str,
        email: str,
        device_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Activate a license — full flow matching the Rust implementation.

        1. Decode + validate the base64 license
        2. Verify Ed25519 signature
        3. Check email matches
        4. Save license.json
        5. Call remote server for device activation
        6. Save device_auth.json

        Returns dict with status and message.
        """
        # 1. Decode
        try:
            lic = self._decode_license_b64(license_code_b64)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        # 2. Check expiration
        if lic.get("exp", 0) > 0 and time.time() > lic["exp"]:
            return {"status": "error", "message": "License expired"}

        # 3. Verify signature
        try:
            self._verify_signature(lic)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        # 4. Verify email matches
        if lic["uid"].lower() != email.strip().lower():
            return {
                "status": "error",
                "message": "Email address does not match the license.",
            }

        # 5. Save license to disk immediately (enables offline use)
        self._save_license_file(lic)

        # Determine device_id: reuse existing if same license, else compute fresh
        existing_auth = self._read_raw_device_auth()
        if existing_auth and existing_auth.get("license_id") == lic["lid"]:
            device_id = existing_auth["device_id"]
        else:
            device_id = self._device_id

        if not device_name:
            device_name = f"{platform.node() or 'Unknown'} ({self._get_platform_name()})"

        platform_str = _PLATFORM_MAP.get(platform.system(), "linux")

        # 6. Try online activation
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    f"{WORKER_ORIGIN}/licenses/activate",
                    json={
                        "license_id": lic["lid"],
                        "device_id": device_id,
                        "device_name": device_name,
                        "platform": platform_str,
                    },
                    headers={"User-Agent": "Mozilla/5.0"},
                )
                if resp.status_code == 409:
                    return {"status": "error", "message": "Device limit reached for this license."}
                resp.raise_for_status()
                data = resp.json()

            authorized_until = data.get("authorized_until") or int(
                time.time() + 30 * 24 * 3600
            )
            auth = {
                "device_id": device_id,
                "device_name": device_name,
                "license_id": lic["lid"],
                "authorized_until": authorized_until,
                "auth_token": data.get("token"),
            }
            self._save_device_auth(auth)
            logger.info("License activated online", email=email, device_id=device_id)
            return {"status": "activated", "message": "License activated successfully."}

        except httpx.HTTPStatusError as e:
            logger.warning("Online activation HTTP error", status=e.response.status_code, error=str(e))
            # Offline fallback — 1-day grace
            auth = {
                "device_id": device_id,
                "device_name": device_name,
                "license_id": lic["lid"],
                "authorized_until": int(time.time() + 24 * 3600),
                "auth_token": None,
            }
            self._save_device_auth(auth)
            return {
                "status": "verified_offline",
                "message": "License verified offline. Online activation pending.",
            }
        except Exception as e:
            logger.warning("Online activation failed", error=str(e))
            auth = {
                "device_id": device_id,
                "device_name": device_name,
                "license_id": lic["lid"],
                "authorized_until": int(time.time() + 24 * 3600),
                "auth_token": None,
            }
            self._save_device_auth(auth)
            return {
                "status": "verified_offline",
                "message": f"License verified. Online activation failed: {e}",
            }

    def deactivate_license(self) -> Dict[str, Any]:
        """Remove license and device auth files."""
        removed: list[str] = []
        failed: list[str] = []
        paths_to_remove = {
            self._get_license_path(),
            self._get_device_auth_path(),
            get_legacy_app_data_dir() / "license.json",
            get_legacy_app_data_dir() / "device_auth.json",
        }
        for path in paths_to_remove:
            try:
                if path.exists():
                    path.unlink()
                    if path.name not in removed:
                        removed.append(path.name)
            except Exception:
                failed.append(str(path))

        # Invalidate cache
        self._cached_license = None
        self._cache_mtime = None

        return {"success": True, "removed": removed, "failed": failed}

    async def renew_activation(self) -> Dict[str, Any]:
        """Try to renew the device authorization (30-day rolling auth).

        Re-calls the activation server to get a fresh authorized_until.
        """
        lic = self.read_license()
        if not lic:
            return {"success": False, "message": "No license found"}

        if lic.get("exp", 0) > 0 and time.time() > lic["exp"]:
            return {"success": False, "message": "License expired"}

        auth = self._read_raw_device_auth()
        if not auth:
            return {"success": False, "message": "No device authorization found. Activate first."}

        device_id = auth.get("device_id", self._device_id)
        device_name = auth.get("device_name", platform.node())
        platform_str = _PLATFORM_MAP.get(platform.system(), "linux")

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    f"{WORKER_ORIGIN}/licenses/activate",
                    json={
                        "license_id": lic["lid"],
                        "device_id": device_id,
                        "device_name": device_name,
                        "platform": platform_str,
                    },
                    headers={"User-Agent": "Mozilla/5.0"},
                )
                resp.raise_for_status()
                data = resp.json()

            authorized_until = data.get("authorized_until") or int(
                time.time() + 30 * 24 * 3600
            )
            auth["authorized_until"] = authorized_until
            auth["auth_token"] = data.get("token") or auth.get("auth_token")
            self._save_device_auth(auth)
            logger.info("Device authorization renewed", authorized_until=authorized_until)
            return {"success": True, "message": "Authorization renewed."}

        except Exception as e:
            logger.warning("Renewal failed", error=str(e))
            return {"success": False, "message": f"Renewal failed: {e}"}

    def _read_raw_device_auth(self) -> Optional[Dict[str, Any]]:
        """Read device_auth.json without validation (for reuse during activation)."""
        path = resolve_config_file_path("device_auth.json")
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None


# Global instance
_license_service = LicenseService()


def get_license_service() -> LicenseService:
    """Get the global license service instance."""
    return _license_service
