"""Custom ONNX download service for FastEmbed using explicit HuggingFace downloads.

This ensures we ONLY download ONNX files from the onnx/ subdirectory,
avoiding the heavy transformer model files.
"""

import asyncio
import os
from pathlib import Path
from typing import List, Optional, Any
import structlog

logger = structlog.get_logger(__name__)


def _import_fastembed():
    """Lazy import for fastembed."""
    try:
        from fastembed import TextEmbedding  # type: ignore
        return TextEmbedding
    except ImportError as e:
        logger.error("Failed to import fastembed", error=str(e))
        raise ImportError(
            "fastembed is REQUIRED for non-Apple-Silicon embeddings. "
            "Install with: pip install fastembed"
        )


class FastEmbedONNXService:
    """FastEmbed service with explicit ONNX-only downloads.
    
    This service manually downloads ONNX files from HuggingFace/ModelScope
    before initializing FastEmbed, ensuring we never download transformer files.
    """
    
    def __init__(
        self,
        model_name: str = "BAAI/bge-m3",
        cache_dir: Optional[str] = None,
        cache_only: bool = True,
        download_source: str = "huggingface",
    ):
        """Initialize FastEmbed service with ONNX-only downloads.

        Args:
            model_name: Model name (e.g., BAAI/bge-m3)
            cache_dir: Local cache directory for models
            cache_only: Use only cached models (don't download)
            download_source: Download source (huggingface/modelscope)
        """
        self.model_name = model_name
        self.cache_dir = cache_dir
        self.cache_only = cache_only
        self.download_source = download_source
        self._initialized: bool = False

        # Model dimension mappings
        self.model_dimensions = {
            "BAAI/bge-m3": 1024,  # Default for non-Apple-Silicon
            "sentence-transformers/all-MiniLM-L6-v2": 384,
            "sentence-transformers/all-mpnet-base-v2": 768,
            "BAAI/bge-small-en-v1.5": 384,
        }

        self.dimension = self.model_dimensions.get(model_name, 1024)
        self.model: Optional[Any] = None
    
    async def _download_onnx_files_only(self, hf_cache_root: Path) -> Path:
        """Download ONLY ONNX files from HuggingFace/ModelScope.
        
        Downloads to HuggingFace's cache directory so FastEmbed can find them.
        
        Args:
            hf_cache_root: HuggingFace cache root directory (~/.cache/huggingface/hub)
        
        Returns:
            Path to the model snapshot directory containing ONNX files
        """
        logger.info(
            "Downloading ONNX files ONLY (skipping transformer files)",
            model=self.model_name,
            source=self.download_source,
            hf_cache=str(hf_cache_root),
        )
        
        if self.download_source == "modelscope":
            # ModelScope download - download all needed files explicitly
            from modelscope.hub.file_download import model_file_download
            
            loop = asyncio.get_event_loop()
            
            # Files to download (ONNX + tokenizer, NO transformer files)
            files_to_download = [
                "onnx/model.onnx",  # ONNX model
                "tokenizer.json",
                "tokenizer_config.json",
                "special_tokens_map.json",
                "sentencepiece.bpe.model",  # For some multilingual models
                "config.json",
            ]
            
            downloaded_files = []
            
            logger.info(
                "Downloading ONNX files from ModelScope",
                model=self.model_name,
                files=files_to_download,
            )
            
            for file_path in files_to_download:
                try:
                    logger.info(f"Downloading {file_path} from ModelScope")
                    local_path = await loop.run_in_executor(
                        None,
                        lambda f=file_path: model_file_download(
                            model_id=self.model_name,
                            file_path=f,
                            cache_dir=str(hf_cache_root),
                        ),
                    )
                    downloaded_files.append(local_path)
                    logger.info(f"✅ Downloaded {file_path} from ModelScope", path=local_path)
                except Exception as e:
                    logger.warning(f"Could not download {file_path} from ModelScope", error=str(e))
                    # Continue with other files
            
            if not downloaded_files:
                raise RuntimeError(
                    f"Failed to download any files from ModelScope for {self.model_name}. "
                    f"Check if the model has ONNX files."
                )
            
            # Return the snapshot directory (where files are actually stored)
            snapshot_dir = Path(downloaded_files[0]).parent
            logger.info(
                "✅ Downloaded ONNX files from ModelScope successfully",
                snapshot_dir=str(snapshot_dir),
                files_downloaded=len(downloaded_files),
            )
            return snapshot_dir
            
        else:
            # HuggingFace download - use snapshot_download with allow_patterns to download only needed files
            import os
            import logging
            
            # CRITICAL: Temporarily allow online access for downloads BEFORE importing
            # We set HF_HUB_OFFLINE=1 globally in config.py, but downloads need online access
            # HuggingFace Hub checks this at import time, so we must set it before importing
            original_hf_offline = os.environ.get("HF_HUB_OFFLINE")
            original_transformers_offline = os.environ.get("TRANSFORMERS_OFFLINE")
            
            # Suppress HuggingFace Hub's verbose lock messages
            # These INFO logs about lock acquisition/release are not useful for users
            hf_hub_logger = logging.getLogger("huggingface_hub")
            original_hf_hub_level = hf_hub_logger.level
            hf_hub_logger.setLevel(logging.WARNING)  # Only show WARNING and above
            
            try:
                # Temporarily enable online access BEFORE importing snapshot_download
                if not self.cache_only:
                    os.environ["HF_HUB_OFFLINE"] = "0"
                    os.environ["TRANSFORMERS_OFFLINE"] = "0"
                    logger.debug("Temporarily enabled online access for HuggingFace download (before import)")

                from huggingface_hub import snapshot_download
                import huggingface_hub.constants
                # Override cached constant in case huggingface_hub was imported elsewhere first
                if not self.cache_only:
                    huggingface_hub.constants.HF_HUB_OFFLINE = False

                loop = asyncio.get_event_loop()
                
                # Patterns to download (ONNX folder + tokenizer files, NO transformer files)
                # This downloads only the files we need, avoiding heavy transformer files
                allow_patterns = [
                    "onnx/*",  # All files in onnx/ folder (including model.onnx)
                    "tokenizer.json",
                    "tokenizer_config.json",
                    "special_tokens_map.json",
                    "sentencepiece.bpe.model",  # For some multilingual models
                    "config.json",
                ]
                
                logger.info(
                    "Downloading ONNX files from HuggingFace using snapshot_download",
                    model=self.model_name,
                    patterns=allow_patterns,
                    cache_dir=str(hf_cache_root),
                )
                
                # Use snapshot_download with allow_patterns to download only specific files
                # Environment variables are already set to allow online access
                model_dir = await loop.run_in_executor(
                    None,
                    lambda: snapshot_download(
                        repo_id=self.model_name,
                        allow_patterns=allow_patterns,
                        cache_dir=str(hf_cache_root),
                        local_files_only=self.cache_only,
                    ),
                )
                
                # Verify ONNX file exists
                model_path = Path(model_dir)
                onnx_file = model_path / "onnx" / "model.onnx"
                
                if not onnx_file.exists():
                    raise RuntimeError(
                        f"ONNX file not found after download: {onnx_file}. "
                        f"Model directory: {model_dir}"
                    )
                
                logger.info(
                    "✅ Downloaded ONNX files successfully using snapshot_download",
                    model_dir=str(model_dir),
                    onnx_file=str(onnx_file),
                )
                
                # Return the model directory (snapshot_download returns the snapshot directory)
                return model_path
                
            except Exception as e:
                logger.error(
                    f"Failed to download ONNX files from HuggingFace using snapshot_download",
                    error=str(e),
                    model=self.model_name,
                )
                raise RuntimeError(
                    f"Failed to download ONNX files for {self.model_name} from HuggingFace. "
                    f"Error: {str(e)}. "
                    f"Try downloading from ModelScope instead, or check if the model has ONNX files."
                )
            finally:
                # Restore original offline settings
                if not self.cache_only:
                    if original_hf_offline is not None:
                        os.environ["HF_HUB_OFFLINE"] = original_hf_offline
                    else:
                        os.environ.pop("HF_HUB_OFFLINE", None)
                    
                    if original_transformers_offline is not None:
                        os.environ["TRANSFORMERS_OFFLINE"] = original_transformers_offline
                    else:
                        os.environ.pop("TRANSFORMERS_OFFLINE", None)
                
                # Restore HuggingFace Hub logger level
                hf_hub_logger.setLevel(original_hf_hub_level)
                
                logger.debug("Restored offline mode settings after download")
    
    async def initialize(self) -> None:
        """Initialize the FastEmbed model with ONNX-only downloads."""
        if self._initialized:
            return
        
        TextEmbedding = _import_fastembed()
        
        try:
            logger.info(
                "Initializing FastEmbed with ONNX-only downloads",
                model=self.model_name,
                cache_only=self.cache_only,
                cache_dir=self.cache_dir,
            )
            
            # CRITICAL: Set environment variables BEFORE initializing FastEmbed
            import os
            
            # Find HuggingFace cache directory where we downloaded the ONNX files
            # FastEmbed needs to use HuggingFace's cache structure, not its own
            from ..config import get_default_huggingface_cache
            
            hf_cache_root = get_default_huggingface_cache()
            
            # Find the model snapshot directory with ONNX files
            # Check BOTH HuggingFace cache and ModelScope cache (different structures)
            # Also check embedding cache (model_cache might download to embedding cache)
            hf_cache_name = f"models--{self.model_name.replace('/', '--')}"
            
            # Extract org and model name for ModelScope structure
            org_name, model_name_part = self.model_name.split("/", 1) if "/" in self.model_name else ("", self.model_name)
            
            # Candidate cache locations to check
            candidate_cache_dirs = []
            
            # 1. HuggingFace standard cache (~/.cache/huggingface/hub)
            hf_cache_dir = hf_cache_root / hf_cache_name
            candidate_cache_dirs.append(("HuggingFace cache", hf_cache_dir, "hf"))
            
            # 2. ModelScope cache (~/.cache/modelscope/hub/models/org/model-name)
            modelscope_cache_root = Path.home() / ".cache" / "modelscope" / "hub" / "models"
            if org_name and model_name_part:
                modelscope_model_dir = modelscope_cache_root / org_name / model_name_part
                candidate_cache_dirs.append(("ModelScope cache", modelscope_model_dir, "modelscope"))
            
            # 3. Embedding cache directory (where model_cache.py might download to)
            if self.cache_dir:
                embedding_cache_dir = Path(self.cache_dir) / hf_cache_name
                candidate_cache_dirs.append(("Embedding cache", embedding_cache_dir, "hf"))
                
                # Also check ModelScope format in embedding cache
                if org_name and model_name_part:
                    embedding_modelscope_dir = Path(self.cache_dir) / org_name / model_name_part
                    candidate_cache_dirs.append(("Embedding cache (ModelScope)", embedding_modelscope_dir, "modelscope"))
            
            # Also check if cache_dir itself is a HuggingFace-style cache
            if self.cache_dir:
                cache_path = Path(self.cache_dir)
                # Check if cache_dir is the HF hub root or parent
                if cache_path.name == "hub" or (cache_path.parent.name == "hub" and cache_path.parent.parent.name == "huggingface"):
                    hf_cache_in_custom = cache_path / hf_cache_name if cache_path.name == "hub" else cache_path.parent / hf_cache_name
                    candidate_cache_dirs.append(("Custom HF cache", hf_cache_in_custom, "hf"))
            
            local_model_path = None
            searched_locations = []
            
            for location_name, model_cache_dir, cache_type in candidate_cache_dirs:
                searched_locations.append(str(model_cache_dir))
                if model_cache_dir.exists():
                    if cache_type == "hf":
                        # HuggingFace structure: models--org--model/snapshots/<hash>/
                        snapshots_dir = model_cache_dir / "snapshots"
                        if snapshots_dir.exists():
                            for snapshot_dir in snapshots_dir.iterdir():
                                if snapshot_dir.is_dir() and (snapshot_dir / "onnx" / "model.onnx").exists():
                                    local_model_path = snapshot_dir
                                    logger.info(
                                        "Found local ONNX model (HuggingFace structure)",
                                        location=location_name,
                                        path=str(local_model_path),
                                    )
                                    break
                    else:  # modelscope
                        # ModelScope structure: org/model-name/ (direct, no snapshots/)
                        # Check if ONNX files are directly in this directory
                        if (model_cache_dir / "onnx" / "model.onnx").exists():
                            local_model_path = model_cache_dir
                            logger.info(
                                "Found local ONNX model (ModelScope structure)",
                                location=location_name,
                                path=str(local_model_path),
                            )
                        else:
                            # ModelScope might also have subdirectories - check recursively
                            for subdir in model_cache_dir.iterdir():
                                if subdir.is_dir() and (subdir / "onnx" / "model.onnx").exists():
                                    local_model_path = subdir
                                    logger.info(
                                        "Found local ONNX model (ModelScope structure, subdir)",
                                        location=location_name,
                                        path=str(local_model_path),
                                    )
                                    break
                    
                    if local_model_path:
                        break
                else:
                    logger.debug(f"Cache directory does not exist", location=location_name, path=str(model_cache_dir))
            
            if not local_model_path:
                logger.debug(
                    "ONNX model not found in any cache location",
                    searched_locations=searched_locations,
                )
            
            # CRITICAL: Force offline mode BEFORE any FastEmbed operations
            # This prevents FastEmbed from calling HuggingFace API during runtime
            if self.cache_only:
                os.environ["HF_HUB_OFFLINE"] = "1"
                os.environ["TRANSFORMERS_OFFLINE"] = "1"
                logger.info("Set HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1 for offline mode")
            
            # Download ONNX files ONLY (if not in cache and not cache_only)
            if not self.cache_only and local_model_path is None:
                downloaded_snapshot = await self._download_onnx_files_only(hf_cache_root)
                local_model_path = downloaded_snapshot
                logger.info("Downloaded ONNX model", snapshot_dir=str(local_model_path))
            
            # Register custom model for FastEmbed BEFORE initialization if needed
            # FastEmbed has built-in support for BGE-M3, so no custom registration needed
            if not local_model_path and self.cache_only:
                # If model not found locally and cache_only, fail with helpful message
                raise RuntimeError(
                    f"ONNX model not found in cache for {self.model_name}. "
                    f"Searched in: {', '.join(searched_locations)}. "
                    f"Please download the model first with cache_only=False or use the UI to download the embedding model."
                )
            elif not local_model_path:
                # Otherwise, let FastEmbed try to download (but this will fail in offline mode)
                logger.warning("Local ONNX model not found, FastEmbed will attempt download (may fail in offline mode)")
            
            loop = asyncio.get_event_loop()
            
            def _init():
                # Initialize FastEmbed with direct path to model if found locally
                # This bypasses FastEmbed's download mechanism entirely
                if local_model_path:
                    logger.info(
                        "Initializing FastEmbed TextEmbedding with specific_model_path",
                        model=self.model_name,
                        specific_model_path=str(local_model_path),
                        local_files_only=self.cache_only,
                    )
                    # Use specific_model_path to point directly to the snapshot directory
                    # This bypasses FastEmbed's download/retrieval mechanism
                    model = TextEmbedding(
                        model_name=self.model_name,
                        specific_model_path=str(local_model_path),  # Direct path to model directory
                        cache_dir=str(hf_cache_root.parent),  # Use HF cache root for tokenizer
                        local_files_only=self.cache_only,  # CRITICAL: This prevents HF API calls
                    )
                    logger.info("✅ FastEmbed TextEmbedding initialized with local model path")
                else:
                    # Fallback: let FastEmbed try to find it in cache
                    logger.info(
                        "Initializing FastEmbed TextEmbedding (will search cache)",
                        model=self.model_name,
                        hf_cache=str(hf_cache_root),
                        local_files_only=self.cache_only,
                    )
                    model = TextEmbedding(
                        model_name=self.model_name,
                        cache_dir=str(hf_cache_root.parent),  # Use HF cache root (~/.cache/huggingface)
                        local_files_only=self.cache_only,  # CRITICAL: This prevents HF API calls
                    )
                    logger.info("✅ FastEmbed TextEmbedding initialized")
                
                return model
            
            self.model = await loop.run_in_executor(None, _init)
            self._initialized = True
            
            logger.info(
                "✅ FastEmbed initialized successfully with ONNX-only files",
                model=self.model_name,
                dimension=self.dimension,
                offline_mode=self.cache_only,
            )
            
        except Exception as e:
            logger.error(
                "Failed to initialize FastEmbed",
                model=self.model_name,
                error=str(e),
            )
            raise
    
    def _prepare_text(self, text: str, prefix: str = "query") -> str:
        """Prepare text for embedding.

        Args:
            text: Input text
            prefix: Either "query" or "passage" (not used by BGE-M3)
        """
        # BGE-M3 and most modern models don't require prefix tokens
        # They handle query/passage distinction internally
        return text
    
    async def embed_text(self, text: str, prefix: str = "query") -> List[float]:
        """Generate embedding using FastEmbed.
        
        Args:
            text: Input text
            prefix: Either "query" (for search queries) or "passage" (for documents/memories to index)
        """
        if not self._initialized or self.model is None:
            raise RuntimeError("FastEmbed service not initialized")
        
        if not text or not text.strip():
            return [0.0] * self.dimension
        
        try:
            prepared_text = self._prepare_text(text.strip(), prefix=prefix)
            
            loop = asyncio.get_event_loop()
            
            def _embed():
                embeddings = list(self.model.embed([prepared_text]))  # type: ignore
                if embeddings:
                    return embeddings[0].tolist()
                return [0.0] * self.dimension
            
            embedding = await loop.run_in_executor(None, _embed)
            return [float(x) for x in embedding]
            
        except Exception as e:
            logger.error("Failed to generate embedding", text=text[:100], error=str(e))
            raise
    
    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings using FastEmbed."""
        if not self._initialized or self.model is None:
            raise RuntimeError("FastEmbed service not initialized")
        
        if not texts:
            return []
        
        valid_texts = [self._prepare_text(text.strip(), prefix="passage") for text in texts if text and text.strip()]
        
        if not valid_texts:
            return [[0.0] * self.dimension for _ in texts]
        
        try:
            loop = asyncio.get_event_loop()
            
            def _embed_batch():
                embeddings = list(self.model.embed(valid_texts))  # type: ignore
                return [emb.tolist() for emb in embeddings]
            
            embeddings = await loop.run_in_executor(None, _embed_batch)
            return [[float(x) for x in emb] for emb in embeddings]
            
        except Exception as e:
            logger.error("Failed to generate batch embeddings", count=len(texts), error=str(e))
            raise
    
    async def cleanup(self) -> None:
        """Cleanup resources."""
        if hasattr(self, "model") and self.model is not None:
            del self.model
        self._initialized = False
        logger.info("FastEmbed service cleaned up")
