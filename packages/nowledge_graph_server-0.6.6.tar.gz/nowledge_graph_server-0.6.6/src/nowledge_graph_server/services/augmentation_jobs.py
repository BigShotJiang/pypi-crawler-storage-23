"""Background job service for graph augmentation operations."""

import asyncio
import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List, Union, Tuple
import structlog
import real_ladybug as kuzu
from ..database.kuzu_client import KuzuClient
from .graph_analysis import GraphAnalysisService
from ..utils.progress_logger import log_progress, log_stage
from .search_index import sync_community_to_index, clear_communities_from_index

logger = structlog.get_logger(__name__)


class AugmentationJobService:
    """Service for managing background augmentation jobs."""

    def __init__(self, kuzu_client: KuzuClient):
        self.kuzu_client = kuzu_client
        assert kuzu_client.conn is not None, "Kuzu client connection is None"
        self.graph_analysis_service = GraphAnalysisService(kuzu_client.conn)
        self.running_jobs: Dict[str, asyncio.Task[None]] = {}  # job_id -> asyncio.Task

    async def initialize(self) -> None:
        """Initialize the augmentation job service."""
        await self.graph_analysis_service.initialize()
        logger.info("AugmentationJobService initialized")

    async def create_job(self, job_type: str, parameters: Dict[str, Any]) -> str:
        """Create a new augmentation job."""
        job_id = str(uuid.uuid4())

        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute(
                """
                CREATE (j:AugmentationJob {
                    job_id: $job_id,
                    job_type: $job_type,
                    status: 'pending',
                    progress: 0.0,
                    message: 'Job created',
                    parameters: $parameters,
                    result: '{}',
                    error_message: '',
                    started_at: NULL,
                    completed_at: NULL
                })
            """,
                {
                    "job_id": job_id,
                    "job_type": job_type,
                    "parameters": json.dumps(parameters),
                },
            )

            logger.info(f"Created augmentation job {job_id} of type {job_type}")
            return job_id

        except Exception as e:
            logger.error(f"Failed to create augmentation job: {e}")
            raise

    async def start_job(self, job_id: str) -> None:
        """Start a background job."""
        try:
            # Get job details
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            job_result = self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                RETURN j.job_type, j.parameters
            """,
                {"job_id": job_id},
            )

            assert isinstance(job_result, kuzu.QueryResult), (
                "Expected QueryResult from job query"
            )
            if not job_result.has_next():
                raise ValueError(f"Job {job_id} not found")

            job_row = job_result.get_next()
            job_type = job_row[0]  # type: ignore
            parameters_str = job_row[1]  # type: ignore
            parameters = (
                json.loads(parameters_str) if isinstance(parameters_str, str) else {}
            )

            # Update job status to running
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                SET j.status = 'running',
                    j.started_at = CURRENT_TIMESTAMP(),
                    j.message = 'Job started'
            """,
                {"job_id": job_id},
            )

            # Start the appropriate job
            if job_type == "community_detection":
                task = asyncio.create_task(
                    self._run_community_detection(job_id, parameters)
                )
            elif job_type == "pagerank_calculation":
                task = asyncio.create_task(
                    self._run_pagerank_calculation(job_id, parameters)
                )
            elif job_type == "undo_community_detection":
                task = asyncio.create_task(
                    self._run_undo_community_detection(job_id, parameters)
                )
            elif job_type == "undo_pagerank_calculation":
                task = asyncio.create_task(
                    self._run_undo_pagerank_calculation(job_id, parameters)
                )
            else:
                raise ValueError(f"Unknown job type: {job_type}")

            self.running_jobs[job_id] = task
            logger.info(f"Started augmentation job {job_id} of type {job_type}")

        except Exception as e:
            logger.error(f"Failed to start job {job_id}: {e}")
            await self._mark_job_failed(job_id, str(e))

    async def _run_community_detection(
        self, job_id: str, parameters: Dict[str, Any]
    ) -> None:
        """Run community detection job."""
        try:
            await self._update_job_progress(
                job_id, 10.0, "Starting community detection..."
            )

            resolution = parameters.get("resolution", 1.0)
            generate_ai_summary = parameters.get("generate_ai_summary", False)
            max_iterations = parameters.get("max_iterations", 100)

            # Run community detection
            await self._update_job_progress(
                job_id, 30.0, "Running Louvain algorithm..."
            )
            result = await self.graph_analysis_service.detect_communities(
                resolution=resolution,
                include_summarization=generate_ai_summary,
                max_iterations=max_iterations,
            )

            await self._update_job_progress(job_id, 60.0, "Updating node properties...")

            # Update node properties with community assignments
            node_communities = result.get("node_communities", {})
            for node_id, community_id in node_communities.items():
                assert self.kuzu_client.conn is not None, (
                    "Kuzu client connection is None"
                )
                self.kuzu_client.conn.execute(
                    """
                    MATCH (n) WHERE n.id = $node_id
                    SET n.community_id = $community_id
                """,
                    {"node_id": node_id, "community_id": community_id},
                )

            await self._update_job_progress(job_id, 80.0, "Creating community nodes...")

            # First, remove any existing community nodes to avoid conflicts
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("MATCH (c:Community) DELETE c")

            # Clear communities from search index before re-creating
            try:
                await clear_communities_from_index()
            except Exception as e:
                logger.debug(
                    "Search index community clear skipped",
                    error=str(e),
                )

            # Create community nodes
            communities = result.get("communities", {})
            for community_id, community_data in communities.items():
                assert self.kuzu_client.conn is not None, (
                    "Kuzu client connection is None"
                )

                # Generate UUID for primary key - the new schema requires 'id' as PK
                community_uuid = str(uuid.uuid4())
                community_name = community_data.get("name", f"Community {community_id}")
                community_description = community_data.get("description", "")
                community_ai_summary = community_data.get("ai_summary", "")
                community_member_count = community_data.get("member_count", 0)

                # Use CREATE to properly insert new community nodes with primary key
                # KuzuDB requires primary key to be set during CREATE, not SET
                self.kuzu_client.conn.execute(
                    """
                    CREATE (c:Community {
                        id: $id,
                        community_id: $community_id,
                        name: $name,
                        description: $description,
                        ai_summary: $ai_summary,
                        member_count: $member_count,
                        algorithm: 'louvain',
                        resolution: $resolution,
                        created_at: CURRENT_TIMESTAMP(),
                        updated_at: CURRENT_TIMESTAMP()
                    })
                """,
                    {
                        "id": community_uuid,  # UUID primary key
                        "community_id": community_id,  # Louvain algorithm ID (updatable)
                        "name": community_name,
                        "description": community_description,
                        "ai_summary": community_ai_summary,
                        "member_count": community_member_count,
                        "resolution": resolution,
                    },
                )

                # Sync community to search index (non-blocking, best-effort)
                try:
                    await sync_community_to_index(
                        id=community_uuid,
                        community_id=int(community_id),  # Louvain algorithm ID
                        name=community_name,
                        description=community_description,
                        ai_summary=community_ai_summary,
                        member_count=community_member_count,
                    )
                except Exception as sync_error:
                    logger.debug(
                        "Search index sync skipped for community",
                        community_id=community_uuid,
                        error=str(sync_error),
                    )

            await self._update_job_progress(job_id, 95.0, "Updating graph metadata...")

            # Update graph metadata
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute(
                """
                MATCH (m:GraphMeta {meta_id: 'main'})
                SET m.community_detection_applied = true,
                    m.community_algorithm = 'louvain',
                    m.community_resolution = $resolution,
                    m.community_count = $count,
                    m.last_augmentation_at = CURRENT_TIMESTAMP(),
                    m.updated_at = CURRENT_TIMESTAMP()
            """,
                {"resolution": resolution, "count": len(communities)},
            )

            await self._mark_job_completed(job_id, result)

        except Exception as e:
            logger.error(f"Community detection job {job_id} failed: {e}")
            await self._mark_job_failed(job_id, str(e))

    async def _run_pagerank_calculation(
        self, job_id: str, parameters: Dict[str, Any]
    ) -> None:
        """Run PageRank calculation job."""
        try:
            await self._update_job_progress(
                job_id, 10.0, "Starting PageRank calculation..."
            )

            # The calculate_centrality method only takes persist_results parameter
            await self._update_job_progress(
                job_id, 30.0, "Running PageRank algorithm..."
            )
            result = await self.graph_analysis_service.calculate_centrality(
                persist_results=False  # We'll handle persistence manually
            )

            await self._update_job_progress(job_id, 60.0, "Updating node properties...")

            # Update node properties with PageRank scores
            node_scores = result.get("node_scores", {})
            for node_id, score in node_scores.items():
                assert self.kuzu_client.conn is not None, (
                    "Kuzu client connection is None"
                )
                self.kuzu_client.conn.execute(
                    """
                    MATCH (n) WHERE n.id = $node_id
                    SET n.pagerank_score = $score
                """,
                    {"node_id": node_id, "score": score},
                )

            await self._update_job_progress(job_id, 95.0, "Updating graph metadata...")

            # Update graph metadata
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute(
                """
                MATCH (m:GraphMeta {meta_id: 'main'})
                SET m.pagerank_applied = true,
                    m.pagerank_algorithm = 'pagerank',
                    m.pagerank_damping = 0.85,
                    m.pagerank_iterations = $iterations,
                    m.last_augmentation_at = CURRENT_TIMESTAMP(),
                    m.updated_at = CURRENT_TIMESTAMP()
            """,
                {"iterations": result.get("iterations", 0)},
            )

            await self._mark_job_completed(job_id, result)

        except Exception as e:
            logger.error(f"PageRank calculation job {job_id} failed: {e}")
            await self._mark_job_failed(job_id, str(e))

    async def _run_undo_community_detection(
        self, job_id: str, parameters: Dict[str, Any]
    ) -> None:
        """Undo community detection augmentation."""
        try:
            await self._update_job_progress(job_id, 20.0, "Removing community nodes...")

            # Remove all community nodes
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("MATCH (c:Community) DELETE c")

            # Clear communities from search index
            try:
                await clear_communities_from_index()
            except Exception as e:
                logger.debug(
                    "Search index community clear skipped",
                    error=str(e),
                )

            await self._update_job_progress(
                job_id, 50.0, "Clearing community assignments..."
            )

            # Clear community_id from all nodes
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("""
                MATCH (n) WHERE n.community_id IS NOT NULL
                SET n.community_id = NULL
            """)

            await self._update_job_progress(job_id, 80.0, "Updating graph metadata...")

            # Update graph metadata
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("""
                MATCH (m:GraphMeta {meta_id: 'main'})
                SET m.community_detection_applied = false,
                    m.community_algorithm = '',
                    m.community_resolution = 1.0,
                    m.community_count = 0,
                    m.updated_at = CURRENT_TIMESTAMP()
            """)

            await self._mark_job_completed(job_id, {"undone": True})

        except Exception as e:
            logger.error(f"Undo community detection job {job_id} failed: {e}")
            await self._mark_job_failed(job_id, str(e))

    async def _run_undo_pagerank_calculation(
        self, job_id: str, parameters: Dict[str, Any]
    ) -> None:
        """Undo PageRank calculation augmentation."""
        try:
            await self._update_job_progress(job_id, 30.0, "Clearing PageRank scores...")

            # Clear pagerank_score from all nodes
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("""
                MATCH (n) WHERE n.pagerank_score IS NOT NULL
                SET n.pagerank_score = 0.0
            """)

            await self._update_job_progress(job_id, 80.0, "Updating graph metadata...")

            # Update graph metadata
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute("""
                MATCH (m:GraphMeta {meta_id: 'main'})
                SET m.pagerank_applied = false,
                    m.pagerank_algorithm = '',
                    m.pagerank_damping = 0.85,
                    m.pagerank_iterations = 0,
                    m.updated_at = CURRENT_TIMESTAMP()
            """)

            await self._mark_job_completed(job_id, {"undone": True})

        except Exception as e:
            logger.error(f"Undo PageRank calculation job {job_id} failed: {e}")
            await self._mark_job_failed(job_id, str(e))

    async def _update_job_progress(
        self, job_id: str, progress: float, message: str
    ) -> None:
        """Update job progress."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                SET j.progress = $progress,
                    j.message = $message
            """,
                {"job_id": job_id, "progress": progress, "message": message},
            )

            # Also log to progress file for real-time UI updates
            # Determine operation type from job
            result = self.kuzu_client.conn.execute(
                "MATCH (j:AugmentationJob {job_id: $job_id}) RETURN j.job_type",
                {"job_id": job_id}
            )
            job_type = None
            while result.has_next():
                row = result.get_next()
                job_type = row[0]

            operation = "augmentation"
            if job_type == "community_detection":
                operation = "community_detection"
            elif job_type == "pagerank_calculation":
                operation = "pagerank_calculation"

            log_progress(
                operation=operation,
                percentage=progress,
                message=message,
                details={"job_id": job_id, "job_type": job_type}
            )

        except Exception as e:
            logger.error(f"Failed to update job progress: {e}")

    async def _mark_job_completed(self, job_id: str, result: Dict[str, Any]) -> None:
        """Mark job as completed."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"

            # Get job type for progress logging
            result_query = self.kuzu_client.conn.execute(
                "MATCH (j:AugmentationJob {job_id: $job_id}) RETURN j.job_type",
                {"job_id": job_id}
            )
            job_type = None
            while result_query.has_next():
                row = result_query.get_next()
                job_type = row[0]

            self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                SET j.status = 'completed',
                    j.progress = 100.0,
                    j.message = 'Job completed successfully',
                    j.result = $result,
                    j.completed_at = CURRENT_TIMESTAMP()
            """,
                {"job_id": job_id, "result": json.dumps(result)},
            )

            # Log completion to progress file
            operation = "augmentation"
            if job_type == "community_detection":
                operation = "community_detection"
            elif job_type == "pagerank_calculation":
                operation = "pagerank_calculation"

            log_stage(
                operation=operation,
                stage="completed",
                message="Job completed successfully",
                details={"job_id": job_id, "job_type": job_type}
            )

            # Clean up running job
            if job_id in self.running_jobs:
                del self.running_jobs[job_id]

        except Exception as e:
            logger.error(f"Failed to mark job as completed: {e}")

    async def _mark_job_failed(self, job_id: str, error_message: str) -> None:
        """Mark job as failed."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"

            # Get job type for progress logging
            result_query = self.kuzu_client.conn.execute(
                "MATCH (j:AugmentationJob {job_id: $job_id}) RETURN j.job_type",
                {"job_id": job_id}
            )
            job_type = None
            while result_query.has_next():
                row = result_query.get_next()
                job_type = row[0]

            self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                SET j.status = 'failed',
                    j.message = 'Job failed',
                    j.error_message = $error_message,
                    j.completed_at = CURRENT_TIMESTAMP()
            """,
                {"job_id": job_id, "error_message": error_message},
            )

            # Log failure to progress file
            operation = "augmentation"
            if job_type == "community_detection":
                operation = "community_detection"
            elif job_type == "pagerank_calculation":
                operation = "pagerank_calculation"

            log_stage(
                operation=operation,
                stage="error",
                message=f"Job failed: {error_message}",
                details={"job_id": job_id, "job_type": job_type, "error": error_message}
            )

            # Clean up running job
            if job_id in self.running_jobs:
                del self.running_jobs[job_id]

        except Exception as e:
            logger.error(f"Failed to mark job as failed: {e}")

    async def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get job status."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute(
                """
                MATCH (j:AugmentationJob {job_id: $job_id})
                RETURN j.job_type, j.status, j.progress, j.message, 
                       j.result, j.error_message, j.started_at, j.completed_at
            """,
                {"job_id": job_id},
            )

            assert isinstance(result, kuzu.QueryResult), (
                "Expected QueryResult from job status query"
            )
            if not result.has_next():
                return {"error": "Job not found"}

            job_row = result.get_next()
            job_type = job_row[0]  # type: ignore
            status = job_row[1]  # type: ignore
            progress = job_row[2]  # type: ignore
            message = job_row[3]  # type: ignore
            result_data = job_row[4]  # type: ignore
            error_message = job_row[5]  # type: ignore
            started_at = job_row[6]  # type: ignore
            completed_at = job_row[7]  # type: ignore

            # Parse result data
            parsed_result: Union[Dict[str, Any], List[Any]] = {}
            if isinstance(result_data, str) and result_data:
                try:
                    parsed_result = json.loads(result_data)
                except json.JSONDecodeError:
                    parsed_result = {}
            elif isinstance(result_data, (dict, list)):
                parsed_result = result_data

            return {
                "job_id": job_id,
                "job_type": job_type,
                "status": status,
                "progress": progress,
                "message": message,
                "result": parsed_result,
                "error_message": error_message,
                "started_at": started_at,
                "completed_at": completed_at,
            }

        except Exception as e:
            logger.error(f"Failed to get job status: {e}")
            return {"error": str(e)}

    async def get_graph_augmentation_state(self) -> Dict[str, Any]:
        """Get the current graph augmentation state."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"
            result = self.kuzu_client.conn.execute("""
                MATCH (m:GraphMeta {meta_id: 'main'})
                RETURN m.community_detection_applied, m.pagerank_applied,
                       m.community_algorithm, m.community_resolution, m.community_count,
                       m.pagerank_algorithm, m.pagerank_damping, m.pagerank_iterations,
                       m.last_augmentation_at, m.schema_version
            """)

            assert isinstance(result, kuzu.QueryResult), (
                "Expected QueryResult from graph state query"
            )
            if not result.has_next():
                return {
                    "community_detection_applied": False,
                    "pagerank_applied": False,
                    "community_algorithm": "",
                    "community_resolution": 1.0,
                    "community_count": 0,
                    "pagerank_algorithm": "",
                    "pagerank_damping": 0.85,
                    "pagerank_iterations": 0,
                    "last_augmentation_at": None,
                    "schema_version": "1.0.0",
                }

            row = result.get_next()
            return {
                "community_detection_applied": bool(row[0]),  # type: ignore
                "pagerank_applied": bool(row[1]),  # type: ignore
                "community_algorithm": str(row[2]) if row[2] else "",  # type: ignore
                "community_resolution": float(row[3]) if row[3] is not None else 1.0,  # type: ignore
                "community_count": int(row[4]) if row[4] is not None else 0,  # type: ignore
                "pagerank_algorithm": str(row[5]) if row[5] else "",  # type: ignore
                "pagerank_damping": float(row[6]) if row[6] is not None else 0.85,  # type: ignore
                "pagerank_iterations": int(row[7]) if row[7] is not None else 0,  # type: ignore
                "last_augmentation_at": row[8],  # type: ignore
                "schema_version": str(row[9]) if row[9] else "1.0.0",  # type: ignore
            }

        except Exception as e:
            logger.error(f"Failed to get graph augmentation state: {e}")
            return {"error": str(e)}

    async def list_jobs(
        self, limit: int = 10, status_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """List augmentation jobs with optional filtering."""
        try:
            assert self.kuzu_client.conn is not None, "Kuzu client connection is None"

            # Build query based on filter
            if status_filter:
                query = """
                    MATCH (j:AugmentationJob)
                    WHERE j.status = $status
                    RETURN j.job_id, j.job_type, j.status, j.progress, j.message,
                           j.started_at, j.completed_at
                    ORDER BY j.started_at DESC
                    LIMIT $limit
                """
                params = {"status": status_filter, "limit": limit}
            else:
                query = """
                    MATCH (j:AugmentationJob)
                    RETURN j.job_id, j.job_type, j.status, j.progress, j.message,
                           j.started_at, j.completed_at
                    ORDER BY j.started_at DESC
                    LIMIT $limit
                """
                params = {"limit": limit}

            result = self.kuzu_client.conn.execute(query, params)
            assert isinstance(result, kuzu.QueryResult), (
                "Expected QueryResult from jobs list query"
            )

            jobs = []
            while result.has_next():
                row = result.get_next()
                jobs.append(
                    {
                        "job_id": row[0],  # type: ignore
                        "job_type": row[1],  # type: ignore
                        "status": row[2],  # type: ignore
                        "progress": row[3],  # type: ignore
                        "message": row[4],  # type: ignore
                        "started_at": row[5],  # type: ignore
                        "completed_at": row[6],  # type: ignore
                    }
                )

            return jobs

        except Exception as e:
            logger.error(f"Failed to list jobs: {e}")
            return []
