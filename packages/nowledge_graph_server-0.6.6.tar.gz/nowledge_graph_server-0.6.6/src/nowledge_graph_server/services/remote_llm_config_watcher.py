"""Remote LLM config file watcher."""

from pathlib import Path

import structlog
from watchdog.events import FileSystemEventHandler

logger = structlog.get_logger(__name__)


class ConfigFileWatcher(FileSystemEventHandler):
    """Watches config file for changes (both creation and modification).

    IMPORTANT: We must handle both on_created and on_modified events because:
    - When Tauri creates a new config file, only on_created fires
    - When Tauri modifies an existing config file, on_modified fires
    - This fixes the race condition where Python starts before Tauri writes config
    """

    def __init__(self, config_path: Path, on_change_callback):
        self.config_path = config_path
        self.on_change_callback = on_change_callback
        self._config_path_str = str(config_path)
        # Also track resolved path in case of symlinks
        try:
            self._config_path_resolved = str(config_path.resolve())
        except Exception:
            self._config_path_resolved = self._config_path_str

    def _matches_config_path(self, event_path: str) -> bool:
        """Check if event path matches our config file (handles path variations)."""
        return event_path == self._config_path_str or event_path == self._config_path_resolved

    def on_created(self, event):
        """Handle file creation - critical for Tauri/Python startup race condition."""
        if self._matches_config_path(event.src_path):
            logger.info(
                "Remote LLM config file CREATED, reloading",
                path=str(self.config_path),
                event_path=event.src_path,
            )
            self.on_change_callback()

    def on_modified(self, event):
        """Handle file modification."""
        if self._matches_config_path(event.src_path):
            logger.info(
                "Remote LLM config file MODIFIED, reloading",
                path=str(self.config_path),
                event_path=event.src_path,
            )
            self.on_change_callback()
