"""Memory distillation methods for LocalLLMService (mixin).

Separated from local_llm.py to stay within the pyarmor free-tier
line limit (1 000 lines per file).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import structlog

from nowledge_graph_server.services.base_llm import (
    CHUNK_PROMPT_TEMPLATE,
    CONSOLIDATION_PROMPT_TEMPLATE,
    DISTILLATION_MEMORY_PROMPT_TEMPLATE,
    MemoryDistillationResult,
)
from nowledge_graph_server.services.content_chunking import chunk_content
from nowledge_graph_server.services.json_utils import clean_and_parse_json
from nowledge_graph_server.services.remote_llm_prompts import build_language_instruction
from nowledge_graph_server.utils.progress_logger import log_progress

logger = structlog.get_logger()


class DistillationMixin:
    """Memory distillation capabilities mixed into LocalLLMService."""

    async def distill_memories(self, thread_content: str, thread_title: str = "", force_local: bool = False, preferred_language: Optional[str] = None) -> MemoryDistillationResult:
        """Distill memories from thread content with intelligent chunking support.

        Args:
            thread_content: The content to distill
            thread_title: Optional title for context
            force_local: If True, always use local LLM regardless of config
            preferred_language: User preferred output language ('en', 'zh', or None)
        """
        CHUNK_SIZE = 5000
        if len(thread_content) > CHUNK_SIZE:
            logger.debug("Content is long, using map-reduce chunking", content_length=len(thread_content))
            chunks = chunk_content(thread_content, CHUNK_SIZE)
            return await self._map_reduce_memories(chunks, thread_title, force_local=force_local, preferred_language=preferred_language)
        else:
            return await self._distill_memories_single_chunk(thread_content, thread_title, force_local=force_local, preferred_language=preferred_language)

    async def _distill_memories_single_chunk(
        self, thread_content: str, thread_title: str = "", force_local: bool = False, preferred_language: Optional[str] = None
    ) -> MemoryDistillationResult:
        """Distill memories from a single chunk of content."""
        lang_instruction = build_language_instruction(preferred_language)
        distillation_prompt = f"LANGUAGE: {lang_instruction}\n\n" + DISTILLATION_MEMORY_PROMPT_TEMPLATE.format(thread_content=thread_content)

        max_retries = 3
        retry_count = 0
        last_failure = None

        while retry_count < max_retries:
            try:
                max_tokens = 3072 if retry_count == 0 else 4096
                self._current_operation = "memory_distillation"
                response = await self._generate_response(distillation_prompt, max_tokens=max_tokens, use_thinking=False, force_local=force_local)

                if not response or not response.strip():
                    retry_count += 1
                    last_failure = f"LLM returned empty response on attempt {retry_count}"
                    logger.warning(f"Attempt {retry_count} failed - LLM returned empty")
                    continue

                result_data = clean_and_parse_json(response)

                if result_data is not None and result_data.get("memories"):
                    return MemoryDistillationResult(
                        memories=result_data.get("memories", []),
                        entities=result_data.get("entities", []),
                        relationships=result_data.get("relationships", []),
                        insights=result_data.get("insights", []),
                        summary=result_data.get("summary", ""),
                    )
                else:
                    retry_count += 1
                    last_failure = f"JSON parsing failed on attempt {retry_count}"
                    logger.warning(f"Attempt {retry_count} failed - JSON parsing failed")
                    continue

            except Exception as e:
                retry_count += 1
                last_failure = str(e)
                logger.error(f"Memory distillation attempt {retry_count} failed", error=str(e))
                continue

        # Fallback to chunking
        logger.warning("Single chunk distillation failed, trying chunking approach")
        if len(thread_content) > 1000:
            chunks = chunk_content(thread_content, 3000)
            return await self._map_reduce_memories(chunks, thread_title, force_local=force_local)
        else:
            raise ValueError(f"Failed to distill memories after {max_retries} attempts: {last_failure}")

    async def _map_reduce_memories(self, chunks: List[str], thread_title: str = "", force_local: bool = False, preferred_language: Optional[str] = None) -> MemoryDistillationResult:
        """Map-reduce approach for memory distillation."""
        if not chunks:
            return MemoryDistillationResult(memories=[], entities=[], relationships=[], insights=[], summary="")

        logger.debug("Starting MAP phase", chunk_count=len(chunks))

        lang_instruction = build_language_instruction(preferred_language)
        total_chunks = len(chunks)
        chunk_results = []

        for i, chunk_item in enumerate(chunks):
            try:
                base_progress = 15
                progress_range = 40
                chunk_progress = base_progress + ((i + 1) / total_chunks) * progress_range

                chunk_preview = chunk_item[:100].replace('\n', ' ').strip()
                if len(chunk_item) > 100:
                    chunk_preview += "..."

                log_progress(
                    operation="thread_distillation",
                    percentage=chunk_progress,
                    message=f"Processing chunk {i + 1}/{total_chunks}: {chunk_preview}",
                    details={"chunk_index": i + 1, "total_chunks": total_chunks}
                )

                chunk_prompt = f"LANGUAGE: {lang_instruction}\n\n" + CHUNK_PROMPT_TEMPLATE.format(
                    chunk_number=i + 1, total_chunks=len(chunks), chunk_content=chunk_item
                )

                self._current_operation = "chunk_processing"
                response = await self._generate_response(chunk_prompt, max_tokens=1024, use_thinking=False, force_local=force_local)

                if not response or not response.strip():
                    logger.warning(f"LLM returned empty response for chunk {i + 1}")
                    continue

                parsed_result = clean_and_parse_json(response)
                if parsed_result and parsed_result.get("memories"):
                    chunk_results.append(parsed_result)
                    logger.debug(f"Chunk {i + 1} processed", memories=len(parsed_result.get("memories", [])))
                else:
                    logger.warning(f"Failed to extract memories from chunk {i + 1}")

            except Exception as e:
                logger.error(f"Error processing chunk {i + 1}", error=str(e))
                continue

        # REDUCE phase
        log_progress(
            operation="thread_distillation",
            percentage=55,
            message="Consolidating extracted memories",
            details={"chunk_results_count": len(chunk_results)}
        )

        if not chunk_results:
            logger.warning("No chunk results to consolidate")
            return MemoryDistillationResult(memories=[], entities=[], relationships=[], insights=[], summary="")

        all_memories = []
        for result in chunk_results:
            all_memories.extend(result.get("memories", []))

        consolidated_memories = await self._consolidate_memories_lightweight(all_memories, thread_title, force_local=force_local, preferred_language=preferred_language)
        final_summary = f"Processed {len(chunks)} chunks, extracted {len(consolidated_memories)} key memories"

        return MemoryDistillationResult(
            memories=consolidated_memories,
            entities=[],
            relationships=[],
            insights=[],
            summary=final_summary,
        )

    async def _consolidate_memories_lightweight(
        self, all_memories: List[Dict[str, Any]], thread_title: str = "", force_local: bool = False, preferred_language: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Lightweight memory consolidation."""
        if not all_memories:
            return []

        sorted_memories = sorted(
            all_memories,
            key=lambda m: (m.get("importance", 0) + m.get("confidence", 0)) / 2,
            reverse=True,
        )

        top_memories = sorted_memories[:5]

        if len(top_memories) <= 3 and all(m.get("importance", 0) > 0.7 for m in top_memories):
            logger.debug("Returning top memories without LLM consolidation", count=len(top_memories))
            return top_memories

        memories_text = "\n\n".join(
            [f"Memory {i + 1}: {m.get('title', '')}\n{m.get('content', '')}" for i, m in enumerate(top_memories)]
        )

        lang_instruction = build_language_instruction(preferred_language)
        consolidation_prompt = f"LANGUAGE: {lang_instruction}\n\n" + CONSOLIDATION_PROMPT_TEMPLATE.format(
            num_memories=len(top_memories), memories_text=memories_text
        )

        try:
            self._current_operation = "memory_consolidation"
            response = await self._generate_response(consolidation_prompt, max_tokens=1536, use_thinking=False, force_local=force_local)

            if not response or not response.strip():
                logger.warning("LLM returned empty response for memory consolidation")
                return top_memories[:3]

            parsed_result = clean_and_parse_json(response)

            if parsed_result and parsed_result.get("memories"):
                consolidated = parsed_result["memories"]
                logger.debug("Memory consolidation completed", original=len(all_memories), consolidated=len(consolidated))
                return consolidated

        except Exception as e:
            logger.error("Memory consolidation failed", error=str(e))

        logger.debug("Using fallback consolidation (top 3)")
        return top_memories[:3]
