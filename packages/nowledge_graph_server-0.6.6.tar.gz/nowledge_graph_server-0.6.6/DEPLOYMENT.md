# Self-Contained App Deployment Guide

## Overview

This guide explains how to deploy the Nowledge Graph system as a self-contained application with proper cache management for offline operation.

## Cache Directory Configuration

The system now supports proper cache directory configuration for self-contained/bundled applications:

**Key Features:**
- **Automatic Cache Directory Detection**: Detects if running in a bundled app (PyInstaller, cx_Freeze, etc.)
- **App-Relative Cache Paths**: Uses cache directories relative to the executable, not user home directory
- **Offline-First Configuration**: Defaults to offline mode to prevent internet access in packaged apps
- **HuggingFace Cache Support**: Properly handles MLX model caching via HuggingFace Hub

## Cache Directory Structure

```
your-app/
├── cache/
│   ├── embeddings/           # Sentence transformer models
│   ├── llm/                  # Local LLM cache (if needed)
│   └── huggingface/          # MLX models from HuggingFace
├── data/
│   └── nowledge_graph.db     # Database file
└── your-app-executable
```

## Configuration for Bundled Apps

For bundled applications, the system automatically:

1. **Detects Bundle Environment**: Checks `sys.frozen` or `sys._MEIPASS` (PyInstaller)
2. **Sets App-Relative Cache**: Uses `./cache/` directory relative to executable
3. **Configures HuggingFace Environment**: Sets `HF_HOME` and `HUGGINGFACE_HUB_CACHE`
4. **Enables Offline Mode**: Prevents model downloads in production

## Pre-Caching Models

Before packaging your application:

```bash
# 1. Cache embedding models
python -m nowledge_graph_server.utils.model_cache cache-embedding

# 2. Cache LLM models  
python -m nowledge_graph_server.utils.model_cache cache-llm

# 3. Verify cached models
python -m nowledge_graph_server.utils.model_cache info
```

## Environment Variables

For manual configuration or development:

```bash
# Core cache directories
export HUGGINGFACE_CACHE_DIR=./cache/huggingface
export EMBEDDING_CACHE_DIR=./cache/embeddings
export LLM_CACHE_DIR=./cache/llm

# HuggingFace offline mode (for MLX models)
export HF_HOME=./cache/huggingface
export HUGGINGFACE_HUB_CACHE=./cache/huggingface
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

# Application offline mode
export EMBEDDING_OFFLINE_MODE=true
export LLM_OFFLINE_MODE=true
```

## Testing Offline Mode

```bash
# Test with offline configuration
cp config.offline.env config.env
python -m nowledge_graph_server.cli serve

# Test in air-gapped environment
# (disconnect internet and verify functionality)
```

## Binary Packaging Checklist

1. **Pre-cache all models** using the model cache utility
2. **Include cache directory** in your package bundle
3. **Set cache paths relative to executable**
4. **Test offline functionality** before packaging
5. **Verify no internet access required** in production environment

## Troubleshooting

**Issue**: MLX models downloading instead of using cache
**Solution**: Check that `HUGGINGFACE_CACHE_DIR` is set and models are cached in HuggingFace format

**Issue**: "Model not found in cache" errors
**Solution**: Run model caching utility and verify cache directory structure

**Issue**: Internet access required in bundled app
**Solution**: Enable offline mode and ensure all models are pre-cached

## Example: PyInstaller Packaging

```bash
# 1. Pre-cache models
python -m nowledge_graph_server.utils.model_cache cache-all

# 2. Create PyInstaller spec
pyinstaller --onefile --add-data "cache:cache" your_app.py

# 3. Test the bundled app offline
./dist/your_app
```

## Configuration Files

### config.offline.env
Use this configuration for offline deployment:

```bash
# Database Configuration
DATABASE_PATH=./nowledge_graph.db

# Embedding Configuration - Offline Mode
EMBEDDING_OFFLINE_MODE=true
EMBEDDING_CACHE_DIR=./cache/embeddings

# LLM Configuration - Offline Mode  
LLM_OFFLINE_MODE=true
HUGGINGFACE_CACHE_DIR=./cache/huggingface

# HuggingFace Environment Variables
HF_HOME=./cache/huggingface
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
```

## Key Fixes Applied

1. **MLX Cache Directory**: Fixed MLX models to use configured `HUGGINGFACE_CACHE_DIR` instead of default user home
2. **Self-Contained App Detection**: Added automatic detection of bundled applications
3. **Environment Variables**: Set HuggingFace cache variables before model loading
4. **Offline-First Defaults**: Changed default configuration to offline mode
5. **App-Relative Cache Paths**: Use cache directories relative to executable location 