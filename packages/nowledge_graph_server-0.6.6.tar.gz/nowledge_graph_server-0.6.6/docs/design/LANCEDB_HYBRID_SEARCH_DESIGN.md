# LanceDB Hybrid Search Implementation Guide

> **Status**: Implementation complete. non-Apple-Silicon ONNX testing complete. Ready for release.

---

## Implementation Status

### Completed
- [x] LanceDB hybrid search (Vector + BM25 FTS with Tantivy)
- [x] Platform-specific embeddings (Qwen3 MLX / BGE-M3 ONNX)
- [x] Universal FTS tokenizers (Chinese, Japanese, Thai)
- [x] Deep mode LLM reranking with human-friendly explanations
- [x] Parallel intent analysis for latency optimization (~50% reduction)
- [x] UI score tooltip with AI explanations
- [x] Search Query Details panel with LLM Reranking indicator
- [x] Reindex UI and progress indicators
- [x] Model download UI with real-time progress
- [x] E5 model cleanup on upgrade
- [x] Kuzu workaround cleanup (v1 code kept for backward compatibility)
- [x] **non-Apple-Silicon ONNX embedding via FastEmbed**
- [x] **FastEmbed patching for custom model cache**
- [x] **HuggingFace/ModelScope region-based download**

---

## Goal

Replace Kuzu FTS/Vector search with LanceDB. **No fallback** - delete Kuzu indexes entirely.

```
BEFORE (v1):
- Kuzu: Graph + Vector (E5 384-dim) + FTS
- E5 embedding model (~240MB)

AFTER (v2):
- Kuzu: Graph ONLY (relationships, traversal, algorithms)
- LanceDB: Vector + FTS hybrid search
- New search embedding (1024-dim)
- DELETE: Kuzu indexes, E5 model files
```

---

## Search Embedding Models (Platform-Specific)

| Platform | Model | Library | Dimension |
|----------|-------|---------|-----------|
| **macOS Apple Silicon** | `mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ` | `mlx-embeddings` | 1024 |
| **non-Apple-Silicon (Windows/Linux/macOS Intel)** | `BAAI/bge-m3` | `fastembed` (ONNX) | 1024 |

**Why different models?**
- FastEmbed has no native macOS ARM binary → slow on Apple Silicon
- No BGE-M3 MLX variant exists
- No Qwen3-Embedding ONNX variant in FastEmbed

**Region-based source selection** (same as existing E5):
- GMT+8 timezone → ModelScope (`modelscope.cn`)
- Other regions → HuggingFace (`huggingface.co`)

### FastEmbed Integration (non-Apple-Silicon)

FastEmbed is patched to use our custom model cache:

```python
# Patch FastEmbed to use our downloaded model
fastembed.text.onnx_embedding.OnnxTextModel._get_model_dir = classmethod(
    lambda cls, model_id: custom_cache_path
)
```

This allows:
- Better download control (HuggingFace vs ModelScope)
- Progress logging during download
- Consistent cache paths with E5 model

---

## Universal FTS Tokenizers

For non-Latin scripts, Python tokenizers pre-process text before LanceDB indexing:

| Language | Tokenizer | Package | Notes |
|----------|-----------|---------|-------|
| Chinese | jieba | `jieba>=0.42.1` | Most popular, fast |
| Japanese | Character segmentation | (built-in) | fugashi/ipadic removed to save ~50MB |
| Language Detection | fast-langdetect | `fast-langdetect>=0.3.0` | FastText-based, 80x faster |
| Thai | (removed) | - | Removed to save ~110MB (pythainlp + pandas) |

**File:** `services/search_index/tokenizers.py`

```python
def tokenize_for_fts(text: str) -> str:
    """Tokenize text for FTS indexing."""
    lang = detect_language(text)
    if lang == "zh":
        return tokenize_chinese(text)  # jieba
    elif lang == "ja":
        return tokenize_japanese(text)  # character segmentation
    elif lang == "th":
        return tokenize_thai(text)  # pythainlp
    else:
        return text  # Latin scripts: Tantivy handles natively
```

---

## Deep Mode LLM Features

### Search Pipeline (Optimized)

```
┌─ Intent Analysis (LLM) ────────┐
│   - Query classification       │
│   - Temporal intent extraction │
│   - Strategy weight calculation├─ Fusion → Rerank → Results
├─ Memory Hybrid Search ─────────┤
├─ Community Strategy ───────────┤
└─ Entity Strategy (LLM) ────────┘

Total latency: ~15-18s (was ~35s)
```

### LLM Reranking

Deep mode exclusive feature that evaluates search results and generates human-friendly explanations.

**File:** `database/search_engine_lancedb.py`

```python
async def llm_rerank_results(query: str, results: List, top_k: int = 5):
    """Rerank top results using LLM evaluation."""
    prompt = f"""Rank results for query "{query}". JSON only.
    {results_block}
    {{"rankings":[{{"index":N,"score":0-10,"explanation":"..."}}]}}"""
    # Blends LLM score (70%) with original score (30%)
```

### UI Integration

**Score Tooltip** (`memory-card.tsx`):
- Detects LLM explanations (simple sentences without technical markers)
- Shows "AI Analysis" header with sparkle icon for deep mode results
- Falls back to technical breakdown for fast mode

**Search Query Details** (`advanced-search.tsx`):
- Shows "LLM Reranking Active" indicator when deep mode reranking was used
- Guides users to hover over scores for AI explanations

---

## Latency Optimizations

| Optimization | Before | After | Savings |
|--------------|--------|-------|---------|
| **Parallel intent + search** | Sequential | Concurrent | ~10s |
| **Rerank top_k** | 10 | 5 | ~10s |
| **Optimized prompts** | Verbose | Compact | ~5s |
| **Total deep search** | ~35s | ~15-18s | ~50% |

### Implementation Details

**Parallel Execution** (`search_operations.py`):
```python
# Start intent analysis as background task
intent_task = asyncio.create_task(_analyze_search_context(query))

# Execute strategies AND intent analysis concurrently
all_tasks = strategies_to_run + [intent_task]
all_results_raw = await asyncio.gather(*all_tasks, return_exceptions=True)
```

**Optimized Prompts**:
- Rerank: Content preview 300→150 chars, max_tokens 500→250
- Entity extraction: Removed verbose example, max_tokens 50→30

---

## File Structure

### New Files

```
services/search_index/
├── __init__.py       # Exports service getters
├── models.py         # SearchResult, IndexRecord dataclasses
├── service.py        # LanceDB operations (hybrid search, CRUD)
├── sync.py           # CRUD sync with tokenization
└── tokenizers.py     # Universal FTS tokenization (CJK support)

services/
├── search_embedding.py   # Platform-specific embedding service
└── bge_m3_embedding.py   # MLX Qwen3-Embedding service (macOS)

database/
├── search_engine_lancedb.py      # LLM functions, reranking, fusion
└── search_strategies_lancedb.py  # Search strategy implementations
```

### Modified Files

| File | Key Changes |
|------|-------------|
| `core/search_operations.py` | Parallel intent analysis, reduced rerank top_k |
| `database/search_engine_lancedb.py` | Optimized prompts, LLM reranking |
| `components/memory-card.tsx` | LLM explanation display in tooltip |
| `components/advanced-search.tsx` | LLM Reranking indicator |
| `components/settings-view.tsx` | Search Settings section |
| `components/title-bar.tsx` | Reindex button and progress |
| `api/client.ts` | searchModel API methods |
| `pyproject.toml` | Universal tokenizer dependencies |

---

## Dependencies

**Python** (`pyproject.toml`):
```toml
# LanceDB for v2+ hybrid search
"lancedb>=0.26.1",
"tantivy>=0.25.1",
"pylance>=0.8.0",
"pyarrow>=18.0.0",

# Universal FTS tokenizers (optimized for size)
"fast-langdetect>=0.3.0",  # Language detection
"jieba>=0.42.1",           # Chinese (~38MB)
# fugashi/ipadic removed to save ~50MB (Japanese uses char segmentation)
# pythainlp removed to save ~110MB (63MB + pandas 50MB)

# ONNX embedding (non-Apple-Silicon)
"fastembed>=0.7.0; platform_system == 'Windows' or platform_system == 'Linux' or (platform_system == 'Darwin' and platform_machine == 'x86_64')",
```

**Size Optimizations** (saves ~430MB):
- `fugashi`/`ipadic` removed: -50MB (Japanese uses character segmentation)
- `pythainlp` removed: -113MB (includes pandas)
- `transformers` excluded via uv: -58MB
- `unidic-lite` avoided: -210MB (was never used, ipadic was chosen instead)

---

## Migration Flow

```
v1 → v2 Upgrade:
1. Backup v1 database
2. Rename to _v2.db
3. Update version metadata
4. Title bar shows: "Enable Search" button
5. User clicks → Download search embedding model (platform-appropriate)
6. After download → "Build Index" button
7. Reindex all memories/entities/communities to LanceDB
8. Delete E5 model files from cache (optional, saves ~240MB)
```

---

## Platform-Specific Notes

### macOS Apple Silicon
- Uses MLX for fast inference
- Model: Qwen3-Embedding-0.6B-4bit-DWQ (~500MB)
- Source: ModelScope for CN region, HuggingFace otherwise

### non-Apple-Silicon (Windows/Linux/macOS Intel)
- Uses ONNX Runtime via FastEmbed
- Model: BGE-M3 (~2.3GB ONNX files)
- Source: HuggingFace (default) or ModelScope
- FastEmbed patched to use our model cache paths

### Windows-Specific Fixes Applied
1. **HF_HUB_OFFLINE**: Import FastEmbed only after model download
2. **Region detection**: Default to 'auto' with fallback
3. **Path handling**: Proper normalization for Windows paths
4. **FTS lambda capture**: Use regular functions in loops
5. **Download state race**: Proper UI state management

---

## Changelog (v0.6.0)

### Search Engine
- **LanceDB Hybrid Search**: Replaced Kuzu FTS/Vector with LanceDB for unified vector + BM25 search
- **Platform-specific Embeddings**: Qwen3-Embedding (MLX) for macOS Apple Silicon, BGE-M3 (ONNX) for non-Apple-Silicon
- **Universal FTS**: Added Python tokenizers for Chinese (jieba), Japanese (char segmentation)
- **Deep Mode Reranking**: LLM-based result reranking with human-friendly explanations

### Performance
- **50% Latency Reduction**: Parallelized intent analysis with search strategies
- **Optimized LLM Prompts**: Reduced token usage for reranking and entity extraction

### UI
- **AI Analysis Tooltip**: Score hover shows LLM-generated explanations in deep mode
- **LLM Reranking Indicator**: Search Query Details panel shows when AI reranking is active
- **Search Settings**: Model download and index rebuild with real-time progress

### Platform Fixes (non-Apple-Silicon)
- **ONNX Model Download**: Fixed HuggingFace download with proper HF_HUB_OFFLINE handling
- **FastEmbed Integration**: Patched to use custom model cache paths
- **FTS Indexing**: Fixed lambda capture bug in rebuild_fts_indices
- **Region Detection**: Improved timezone-based region detection with fallback

### Dependencies
- Added: `lancedb`, `tantivy`, `pylance`, `pyarrow`
- Added: `fast-langdetect`, `jieba`
- Added: `fastembed`, `onnxruntime` (non-Apple-Silicon)

### Kuzu Workaround Cleanup
- Removed dead v0 (alpine) special case code
- Fixed misleading comments about DETACH DELETE and vector indexes
- **v1 workarounds retained** for backward compatibility (all gated by version check)
