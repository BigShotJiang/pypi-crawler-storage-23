# Nowledge Mem TUI Design Document

## Overview

The **nmem tui** command launches an elegant Textual-based Terminal User Interface that provides a full-featured experience for managing memories, threads, and exploring the knowledge graph—all from the terminal.

This TUI is designed to complement the Tauri desktop app while providing a powerful alternative for terminal-centric workflows, remote access via SSH, and headless environments.

## Design Philosophy

1. **Keyboard-First**: Every action accessible via intuitive keybindings
2. **Information Density**: Show more data than the GUI without cluttering
3. **Vim-Style Navigation**: `j/k` for list navigation, `/` for search, `g` for goto
4. **Progressive Disclosure**: Start simple, reveal complexity as needed
5. **Responsive Layout**: Adapt to terminal size gracefully
6. **Beautiful by Default**: Modern color schemes with consistent styling

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              NMEM TUI                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  tui/                                                                       │
│  ├── __init__.py              # Entry point (run_tui)                       │
│  ├── app.py                   # Main NowledgeMemApp(App) + embedded CSS     │
│  ├── api_client.py            # Async HTTP client for backend               │
│  ├── screens/                 # Screen definitions                          │
│  │   ├── __init__.py                                                        │
│  │   ├── dashboard.py         # Overview/Stats dashboard                    │
│  │   ├── memories.py          # Memory list & search                        │
│  │   ├── memory_detail.py     # Single memory view (Screen)                 │
│  │   ├── threads.py           # Thread list & search                        │
│  │   ├── thread_detail.py     # Thread with messages (Screen)               │
│  │   ├── graph.py             # ASCII graph visualization                   │
│  │   ├── settings.py          # Configuration screen                        │
│  │   └── help.py              # Help overlay (ModalScreen)                  │
│  └── widgets/                 # Reusable UI components (expandable)         │
│      └── __init__.py                                                        │
└─────────────────────────────────────────────────────────────────────────────┘

Note: CSS is embedded in DEFAULT_CSS class variables for portability in bundled apps.
```

---

## Screen Designs

### 1. Dashboard (Home Screen)

The landing screen showing system status and key metrics.

```
┌─ NOWLEDGE MEM ─────────────────────────────────────────────────────────────┐
│                                                                             │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐  ┌──────────────┐ │
│  │   💡 156      │  │   🔗 423      │  │   🧵 28       │  │  ⚡ ok       │ │
│  │   Memories    │  │   Entities    │  │   Threads     │  │  Server      │ │
│  └───────────────┘  └───────────────┘  └───────────────┘  └──────────────┘ │
│                                                                             │
│  Recent Memories ─────────────────────────────────────────────────────────  │
│  │ React hooks best practices for state management          0.8  today    │ │
│  │ Database schema design for multi-tenant applications     0.7  today    │ │
│  │ Kubernetes pod scheduling strategies explained           0.6  yesterday│ │
│  │ GraphQL vs REST API comparison notes                     0.5  2d ago   │ │
│                                                                             │
│  Quick Actions ───────────────────────────────────────────────────────────  │
│  [/] Search    [m] Memories    [t] Threads    [g] Graph    [?] Help        │
│                                                                             │
└─ [q] Quit  [/] Search  [?] Help ───────────────────────────────────────────┘
```

### 2. Memories Screen

List and search memories with real-time filtering.

```
┌─ MEMORIES ──────────────────────────────────────────────────── 156 total ──┐
│                                                                             │
│  🔍 Search: react hooks                                           [Enter]  │
│  ─────────────────────────────────────────────────────────────────────────  │
│  Filters: [importance ≥0.5] [labels: all] [time: all]                      │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────┤
│  │ ► React hooks best practices for state management                       │
│  │   ★ 0.85  │  📅 2025-12-15  │  🏷️ react, frontend  │  cursor           │
│  │   Use useCallback for memoizing callbacks, useMemo for expensive...     │
│  ├─────────────────────────────────────────────────────────────────────────┤
│  │   Building custom hooks: abstracting reusable logic                     │
│  │   ★ 0.72  │  📅 2025-12-14  │  🏷️ react, patterns  │  chatwise         │
│  │   Custom hooks follow naming convention useXxx and can combine...       │
│  ├─────────────────────────────────────────────────────────────────────────┤
│  │   React 19 new features and improvements                                │
│  │   ★ 0.68  │  📅 2025-12-12  │  🏷️ react           │  cursor            │
│  │   React 19 introduces automatic batching, suspense improvements...      │
│  └─────────────────────────────────────────────────────────────────────────┘
│                                                                             │
│  ───────────────────────────────────────────────────────────── 1-10 of 23  │
└─ [j/k] Navigate  [Enter] View  [a] Add  [d] Delete  [l] Labels  [/] Search ┘
```

### 3. Memory Detail Screen

Full view of a single memory with actions.

```
┌─ MEMORY ─────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  React hooks best practices for state management                              │
│  ══════════════════════════════════════════════════════════════════════════  │
│                                                                               │
│  ┌─ Metadata ─────────────────────────────────────────────────────────────┐  │
│  │  ID:         mem_1734289541_a3f2c1                                     │  │
│  │  Importance: ████████░░ 0.85                                           │  │
│  │  Created:    2025-12-15 10:45:21                                       │  │
│  │  Source:     cursor                                                    │  │
│  │  Labels:     [react] [frontend] [best-practices]                       │  │
│  │  Thread:     cursor-20251215-react-optimization                        │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Content ──────────────────────────────────────────────────────────────┐  │
│  │                                                                         │  │
│  │  # React Hooks Best Practices                                          │  │
│  │                                                                         │  │
│  │  ## State Management                                                    │  │
│  │  - Use `useState` for simple local state                               │  │
│  │  - Use `useReducer` for complex state logic                            │  │
│  │  - Consider context for global state before reaching for Redux         │  │
│  │                                                                         │  │
│  │  ## Performance Optimization                                            │  │
│  │  - `useCallback` for memoizing callbacks passed to children            │  │
│  │  - `useMemo` for expensive computations                                │  │
│  │  - Avoid premature optimization - measure first                        │  │
│  │                                                                         │  │
│  │  ## Custom Hooks                                                        │  │
│  │  - Extract reusable logic into `useXxx` functions                      │  │
│  │  - Return tuple `[value, setValue]` for consistency                    │  │
│  │                                                                         │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Related Entities ─────────────────────────────────────────────────────┐  │
│  │  React (tool) ───────► useState (concept) ───────► Performance (topic) │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
└─ [Esc] Back  [e] Edit  [d] Delete  [l] Labels  [f] Favorite  [k] KG Extract ─┘
```

### 4. Threads Screen

Browse and search conversation threads.

```
┌─ THREADS ────────────────────────────────────────────────────── 28 total ──┐
│                                                                             │
│  🔍 Search threads...                                             [Enter]  │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────┤
│  │ ► React Performance Optimization Discussion                             │
│  │   💬 24 messages  │  📅 2025-12-15  │  cursor  │  ✅ distilled          │
│  ├─────────────────────────────────────────────────────────────────────────┤
│  │   Database Design for Multi-tenant SaaS                                 │
│  │   💬 18 messages  │  📅 2025-12-14  │  cursor  │  ⏳ pending            │
│  ├─────────────────────────────────────────────────────────────────────────┤
│  │   Kubernetes Architecture Deep Dive                                     │
│  │   💬 32 messages  │  📅 2025-12-13  │  chatwise │  ✅ distilled         │
│  ├─────────────────────────────────────────────────────────────────────────┤
│  │   GraphQL Schema Design Patterns                                        │
│  │   💬 15 messages  │  📅 2025-12-12  │  cursor   │  ⏳ pending           │
│  └─────────────────────────────────────────────────────────────────────────┘
│                                                                             │
└─ [j/k] Navigate  [Enter] View  [i] Import  [D] Distill  [x] Delete ────────┘
```

### 5. Thread Detail Screen

View thread with messages and distillation options.

```
┌─ THREAD: React Performance Optimization Discussion ──────────────────────────┐
│                                                                               │
│  ┌─ Info ─────────────────────────────────────────────────────────────────┐  │
│  │  ID: cursor-20251215-react-perf   │  Messages: 24  │  Source: cursor   │  │
│  │  Created: 2025-12-15 09:30:00     │  Status: ✅ Distilled              │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Messages ─────────────────────────────────────────────────────────────┐  │
│  │                                                                         │  │
│  │  ┌─ USER ──────────────────────────────────────────────────────────┐   │  │
│  │  │ I'm experiencing slow renders in my React app when updating      │   │  │
│  │  │ a large list. Any suggestions for optimization?                  │   │  │
│  │  └──────────────────────────────────────────────────────────────────┘   │  │
│  │                                                                         │  │
│  │  ┌─ ASSISTANT ─────────────────────────────────────────────────────┐   │  │
│  │  │ Here are several approaches to optimize list rendering:          │   │  │
│  │  │                                                                  │   │  │
│  │  │ 1. **Virtualization**: Use react-window or react-virtualized    │   │  │
│  │  │ 2. **Memoization**: Wrap list items with React.memo()           │   │  │
│  │  │ 3. **Key optimization**: Use stable, unique keys                │   │  │
│  │  │ ...                                                             │   │  │
│  │  └──────────────────────────────────────────────────────────────────┘   │  │
│  │                                                                         │  │
│  │  ┌─ USER ──────────────────────────────────────────────────────────┐   │  │
│  │  │ How does react-window work exactly?                              │   │  │
│  │  └──────────────────────────────────────────────────────────────────┘   │  │
│  │                                                                         │  │
│  └──────────────────────────────────────────────────────── [j/k] scroll ──┘  │
│                                                                               │
│  ┌─ Extracted Memories ───────────────────────────────────────────────────┐  │
│  │  • React hooks best practices for state management (★ 0.85)            │  │
│  │  • Virtualization techniques for large lists (★ 0.78)                  │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
└─ [Esc] Back  [D] Distill  [x] Delete  [m] View Memory ───────────────────────┘
```

### 6. Graph Screen

ASCII-based knowledge graph visualization.

```
┌─ KNOWLEDGE GRAPH ────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Search graph: react                                                       │
│  ─────────────────────────────────────────────────────────────────────────    │
│                                                                               │
│  Stats: 423 entities │ 1,247 relationships │ 12 communities                  │
│                                                                               │
│  ┌─ Graph View ───────────────────────────────────────────────────────────┐  │
│  │                                                                         │  │
│  │           ┌────────────┐                                               │  │
│  │           │   React    │◄────────┐                                     │  │
│  │           │  (tool)    │         │                                     │  │
│  │           └─────┬──────┘         │                                     │  │
│  │                 │                │                                     │  │
│  │       ┌─────────┼─────────┐      │                                     │  │
│  │       ▼         ▼         ▼      │                                     │  │
│  │  ┌─────────┐ ┌─────────┐ ┌───────┴───┐                                 │  │
│  │  │useState │ │useMemo  │ │Performance│                                 │  │
│  │  │(concept)│ │(concept)│ │  (topic)  │                                 │  │
│  │  └─────────┘ └─────────┘ └───────────┘                                 │  │
│  │       │                       ▲                                         │  │
│  │       └───────────────────────┘                                         │  │
│  │           optimizes                                                     │  │
│  │                                                                         │  │
│  └─────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Communities ──────────────────────────────────────────────────────────┐  │
│  │  [Frontend Dev] 45 members  │  [Backend Systems] 38 members  │ ...     │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
└─ [/] Search  [c] Communities  [p] PageRank  [e] Expand  [r] Refresh ─────────┘
```

### 7. Settings Screen

Configuration and system settings.

```
┌─ SETTINGS ───────────────────────────────────────────────────────────────────┐
│                                                                               │
│  ┌─ Connection ───────────────────────────────────────────────────────────┐  │
│  │  API URL:     http://127.0.0.1:14242                         [Edit]    │  │
│  │  Status:      ● Connected                                              │  │
│  │  Version:     0.5.3                                                    │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Display ──────────────────────────────────────────────────────────────┐  │
│  │  Theme:           [Dark ▼]                                             │  │
│  │  Memory Preview:  [3 lines ▼]                                          │  │
│  │  Date Format:     [Relative ▼]                                         │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Search ───────────────────────────────────────────────────────────────┐  │
│  │  Default Mode:    [Deep ▼]                                             │  │
│  │  Results Limit:   [20  ▼]                                              │  │
│  │  Show Scores:     [Yes ▼]                                              │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌─ Keyboard Shortcuts ───────────────────────────────────────────────────┐  │
│  │  Navigation:  j/k (up/down)  h/l (left/right)  g (go to)               │  │
│  │  Actions:     Enter (select)  Esc (back)  / (search)  ? (help)         │  │
│  │  Screens:     1 (dashboard)  2 (memories)  3 (threads)  4 (graph)      │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
└─ [Esc] Back  [s] Save ───────────────────────────────────────────────────────┘
```

---

## Keybindings

### Global Keybindings

| Key | Action |
|-----|--------|
| `q` | Quit application |
| `?` | Show help overlay |
| `/` | Focus search bar |
| `Esc` | Go back / Cancel |
| `1` | Go to Dashboard |
| `2` | Go to Memories |
| `3` | Go to Threads |
| `4` | Go to Graph |
| `5` | Go to Settings |

### List Navigation

| Key | Action |
|-----|--------|
| `j` / `↓` | Move down |
| `k` / `↑` | Move up |
| `g` `g` | Go to top |
| `G` | Go to bottom |
| `Enter` | Select / View |
| `Space` | Toggle selection |

### Memory Actions

| Key | Action |
|-----|--------|
| `a` | Add new memory |
| `e` | Edit memory |
| `d` | Delete memory |
| `l` | Manage labels |
| `f` | Toggle favorite |
| `K` | Extract knowledge graph |
| `y` | Copy memory ID |

### Thread Actions

| Key | Action |
|-----|--------|
| `i` | Import thread |
| `D` | Distill to memories |
| `x` | Delete thread |
| `m` | View related memory |

---

## Color Scheme

Using a modern terminal-friendly palette:

```css
/* main.tcss */
$primary: #60a5fa;       /* Blue - primary actions */
$secondary: #a78bfa;     /* Purple - secondary elements */
$success: #34d399;       /* Green - success states */
$warning: #fbbf24;       /* Yellow - warnings */
$error: #f87171;         /* Red - errors/destructive */
$muted: #6b7280;         /* Gray - muted text */

/* Importance levels */
$importance-high: #22c55e;
$importance-medium: #eab308;
$importance-low: #6b7280;

/* Node types */
$node-memory: #60a5fa;
$node-entity: #a78bfa;
$node-thread: #34d399;
$node-community: #f97316;
```

---

## Implementation Notes

### API Client

The TUI uses the same REST API as the Tauri app. Key endpoints:

```python
# Core endpoints used by TUI
GET  /health                    # Server status
GET  /stats                     # Database statistics
GET  /memories                  # List memories
GET  /memories/search           # Search memories
GET  /memories/{id}             # Get memory details
POST /memories                  # Create memory
DELETE /memories/{id}           # Delete memory
GET  /threads                   # List threads
GET  /threads/{id}              # Get thread with messages
POST /threads/distill           # Distill thread
GET  /graph/search              # Search graph
GET  /graph/sample              # Get graph sample
GET  /graph/analysis            # Graph analytics
```

### Textual Features Used

- **Screens**: Multiple screen navigation with push/pop
- **DataTable**: Efficient list rendering with virtualization
- **Input**: Search and form inputs
- **Markdown**: Render memory content
- **Static**: Display formatted text
- **Footer**: Context-aware keybinding hints
- **Notifications**: Toast messages for actions
- **Loading**: Async data loading indicators

### Progressive Loading

For large datasets:
1. Load initial page (20 items)
2. Show loading indicator on scroll
3. Fetch next page when near bottom
4. Cache previous pages for smooth scrolling

---

## Future Enhancements

1. **Fuzzy Search**: Add fzf-style fuzzy matching for quick navigation
2. **Batch Operations**: Multi-select for bulk actions
3. **Clipboard Integration**: Copy memory content to clipboard
4. **Export Options**: Export memories to markdown/JSON
5. **Offline Mode**: Cache data for offline browsing
6. **Split View**: Side-by-side memory/thread viewing
7. **Graph ASCII Art**: More sophisticated graph rendering using box-drawing characters
8. **Session Persistence**: Remember last viewed screen and scroll position
