# WAL Corruption Prevention Fix

## Problem Description

Users reported database corruption issues with error messages like:
- "Corrupted wal file" 
- Database needs to be deleted to recover (losing all memories)

The trigger was often the `thread_persist` MCP tool call from Codex CLI or Claude Code, which performs bulk writes to the database.

### Root Cause Analysis

The corruption was caused by multiple factors related to Write-Ahead Log (WAL) handling:

1. **No checkpoint on close()**: When the database was closed (or the process crashed/was killed), any unflushed WAL entries could become corrupted. The `close()` method did not checkpoint before closing.

2. **Checkpoint failures were swallowed**: Checkpoint failures were logged as warnings but execution continued, leaving data in an unflushed WAL state that could become corrupted.

3. **No retry logic**: Transient checkpoint failures (due to temporary resource contention) were not retried, leading to persistent unflushed WAL data.

4. **No emergency shutdown handling**: If the process was killed without graceful shutdown, WAL data could be left in an inconsistent state.

## Solution

### 1. Checkpoint on Close (base_client.py)

The `close()` method now performs a final checkpoint before closing the database connection:

```python
async def close(self) -> None:
    """Close database connection with final checkpoint."""
    if self._initialized and self.conn:
        # Checkpoint before closing to flush any pending WAL entries
        checkpoint_success = self.checkpoint(
            reason="close",
            retry_count=3,
            raise_on_failure=False,
        )
        if not checkpoint_success:
            logger.warning("Final checkpoint failed - WAL may contain unflushed data")
    # ... close connection
```

### 2. Checkpoint Retry Logic (base_client.py)

The `checkpoint()` method now includes retry logic with exponential backoff:

```python
def checkpoint(
    self,
    *,
    reason: str | None = None,
    retry_count: int = 3,
    retry_delay_base: float = 0.1,
    raise_on_failure: bool = False,
) -> bool:
    """Flush WAL to main store with retry logic."""
    for attempt in range(retry_count):
        try:
            self.conn.execute("CHECKPOINT;")
            self._last_checkpoint_time = datetime.now(timezone.utc)
            return True
        except Exception as e:
            if attempt < retry_count - 1:
                delay = retry_delay_base * (2 ** attempt)  # Exponential backoff
                time.sleep(delay)
    return False
```

### 3. Checkpoint Status Tracking (base_client.py)

Added tracking for checkpoint status to help diagnose issues:

```python
_last_checkpoint_time: Optional[datetime] = None
_checkpoint_failure_count: int = 0
_last_checkpoint_failure: Optional[str] = None

def get_checkpoint_status(self) -> Dict[str, Any]:
    """Get checkpoint status for diagnostics."""
    return {
        "last_checkpoint_time": self._last_checkpoint_time.isoformat() if self._last_checkpoint_time else None,
        "failure_count": self._checkpoint_failure_count,
        "last_failure": self._last_checkpoint_failure,
    }
```

### 4. Emergency Shutdown Handler (main.py)

Added atexit handler as a last-resort fallback:

```python
def _sync_emergency_checkpoint():
    """Synchronous emergency checkpoint for atexit handler."""
    global _shutdown_initiated
    if _shutdown_initiated:
        return  # Normal shutdown already handled this
    # Attempt emergency checkpoint
    if kuzu_client and kuzu_client.conn:
        kuzu_client.conn.execute("CHECKPOINT;")

atexit.register(_sync_emergency_checkpoint)
```

### 5. Improved Shutdown Logging (dependencies.py)

Enhanced shutdown logging to track checkpoint status:

```python
async def shutdown():
    """Cleanup on shutdown with WAL flushing."""
    logger.info("API server shutdown initiated - flushing database and cleaning up")
    # Log checkpoint status before closing
    checkpoint_status = kuzu_client.base_client.get_checkpoint_status()
    logger.info("Database checkpoint status before shutdown", **checkpoint_status)
    await kuzu_client.close()
```

## Files Modified

1. `src/nowledge_graph_server/database/base_client.py`
   - Added checkpoint retry logic with exponential backoff
   - Added checkpoint status tracking
   - Added checkpoint on close()
   - Added docstring explaining WAL corruption prevention

2. `src/nowledge_graph_server/api/dependencies.py`
   - Enhanced shutdown logging
   - Log checkpoint status before closing

3. `src/nowledge_graph_server/main.py`
   - Added atexit emergency checkpoint handler
   - Added shutdown initiated tracking

4. `src/nowledge_graph_server/core/memory_operations/base.py`
   - Updated to use base_client checkpoint method with retry logic

5. `src/nowledge_graph_server/database/thread_repository.py`
   - Fixed `append_messages()` to include `created_at` and `updated_at` fields
   - This ensures Message nodes have consistent timestamps regardless of creation method

6. `src/nowledge_graph_server/core/thread_operations.py`
   - Fixed code formatting issue (stray empty line in deduplicate block)

## Testing

After this fix, the following scenarios should be handled correctly:

1. **Normal shutdown**: WAL is flushed before connection closes
2. **Checkpoint failure**: Retried with exponential backoff
3. **Transient errors**: Handled by retry logic
4. **Process killed**: atexit handler attempts emergency checkpoint
5. **Diagnostic**: Checkpoint status can be queried for troubleshooting

### E2E Testing Guide

#### Prerequisites
1. Start the Nowledge Mem server: `uv run python -m nowledge_graph_server.main`
2. Configure Codex CLI or Claude Code with MCP pointing to your server

#### Test Case 1: Normal Thread Persist Flow
```bash
# In Codex CLI, save a session
# The thread_persist tool should complete successfully
# Check server logs for: "Checkpointed" and "Final checkpoint completed successfully"
```

**Expected**: Thread is created/appended successfully with checkpoints after each transaction.

#### Test Case 2: Graceful Shutdown After Write
```bash
# 1. Use thread_persist to save a session
# 2. Immediately stop the server with Ctrl+C
# 3. Check logs for: "Graceful shutdown initiated" and "Database closed successfully with WAL flushed"
# 4. Restart the server
# 5. Verify the thread data is intact using thread_search or UI
```

**Expected**: Data is preserved after graceful shutdown.

#### Test Case 3: Simulate Checkpoint Failure Recovery
```bash
# 1. Create multiple threads in quick succession using thread_persist
# 2. Monitor logs for checkpoint retry messages
# 3. If you see "Checkpoint failed, retrying", verify it eventually succeeds
```

**Expected**: Transient failures are retried and eventually succeed.

#### Test Case 4: Large Session Handling
```bash
# 1. Create a Codex session with many messages (50+ messages)
# 2. Use thread_persist to save it
# 3. Verify the thread is created with all messages
# 4. Check logs for transaction and checkpoint completion
```

**Expected**: Large sessions are handled correctly with single transaction + checkpoint.

#### Test Case 5: Append Messages Flow
```bash
# 1. Use thread_persist to save a session (creates new thread)
# 2. Continue the Codex session with more messages
# 3. Use thread_persist again (should append)
# 4. Verify the thread now has all messages (old + new)
# 5. Check that messages have created_at/updated_at timestamps
```

**Expected**: Messages are appended with proper deduplication and timestamps.

#### Test Case 6: Database Integrity After Kill
```bash
# 1. Use thread_persist to save a session
# 2. Kill the server process abruptly (kill -9 or Task Manager)
# 3. Restart the server
# 4. Check for WAL corruption messages in logs
# 5. Verify the database opens successfully
```

**Expected**: 
- If kill happens after checkpoint: data preserved
- If kill happens before checkpoint: atexit may have checkpointed
- If WAL is corrupted: it's moved aside and recovery attempted

#### Test Case 7: Concurrent Access (Advanced)
```bash
# 1. Open two Codex sessions in different terminals
# 2. Persist both sessions simultaneously
# 3. Verify both threads are created correctly
# 4. No WAL corruption should occur
```

**Expected**: Concurrent writes are handled correctly via transactions.

### Verification Commands

```bash
# Check server logs for checkpoint activity
grep -E "(Checkpoint|checkpoint|WAL|wal)" ~/.local/share/nowledge/logs/*.log

# Check database file exists and is valid
ls -la ~/.local/share/nowledge/*.nowledge

# Verify no corrupt WAL files
ls -la ~/.local/share/nowledge/*.wal* 2>/dev/null || echo "No WAL files (good)"
```

### Stress Testing (Optional)

For stress testing, you can use a script that repeatedly saves sessions:

```python
import asyncio
import httpx

async def stress_test():
    async with httpx.AsyncClient() as client:
        for i in range(10):
            # Trigger thread_persist via MCP proxy
            response = await client.post(
                "http://127.0.0.1:14242/mcp-proxy/tools/thread_persist",
                json={
                    "client": "codex",
                    "project_path": "/your/project/path",
                    "persist_mode": "current",
                }
            )
            print(f"Iteration {i}: {response.status_code}")
            await asyncio.sleep(0.5)  # Small delay

asyncio.run(stress_test())
```

## Monitoring

To monitor checkpoint health, check the logs for:

- `"Checkpoint failed, retrying"` - transient failures being retried
- `"Checkpoint failed after all retries"` - persistent failures
- `"Final checkpoint completed successfully"` - successful shutdown
- `"Database checkpoint status before shutdown"` - status at shutdown

## Known Limitations

1. If the process is forcibly killed (SIGKILL), the atexit handler won't run
2. If the database file is corrupted (not just WAL), recovery is not possible
3. WAL corruption recovery (moving WAL aside) may lose recent uncommitted data

## References

- [KuzuDB Vector Index Bug #6045](https://github.com/kuzudb/kuzu/issues/6045)
- Ladybug (community fork of KuzuDB) documentation
