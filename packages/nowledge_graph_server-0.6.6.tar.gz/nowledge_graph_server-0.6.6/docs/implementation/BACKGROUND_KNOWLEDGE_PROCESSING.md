# Background Knowledge Processing Pipeline

## Overview

The Knowledge Agent manager (`agent/manager.py`) handles scheduled background tasks that maintain and enrich the knowledge graph. Tasks are dispatched either through the LLM agent session (for tasks requiring reasoning) or via direct Python functions (for compute-heavy operations).

## Architecture

### Task Dispatch

Two dispatch paths in `_execute_task()`:

1. **Direct executors** (`_direct_executors` dict): Python functions for compute-heavy tasks
   - `community_detection` → `_execute_community_detection()`
   - `kg_extraction_backfill` → `_execute_kg_extraction_backfill()`

2. **LLM agent session**: For tasks requiring reasoning
   - `daily_briefing`, `crystallization_review`, `insight_detection`
   - Session is restarted fresh (`restart_fresh()`) before each task to prevent context accumulation

### Settings Gates

All scheduled tasks are gated by user settings from `app-settings.json`:

| Task | Setting Key | Default |
|------|------------|---------|
| KG Extraction | `autoKGExtraction` | true |
| Community Detection | `autoCommunityDetection` | true |
| Daily Briefing | `autoDailyBriefing` | true |
| Crystallization | `autoCrystallization` | true |
| Insight Detection | `autoInsightDetection` | true |
| Briefing Hour | `briefingHour` | 5 (5 AM) |
| Community AI Summary | `generateCommunityAISummary` | true |

Settings are read from `~/Library/Application Support/co.nowledge.mem.desktop/app-settings.json` via `settings_reader.py`. The gate only applies to scheduled (LOW priority) runs — manual triggers from Settings UI always execute.

### KG Extraction Scoping

The backfill executor applies intelligent filtering:
- **Batch cap**: 10 memories per run (prevents resource exhaustion and rate limits)
- **Content length filter**: Skip < 50 chars (too short) and > 20,000 chars (too long)
- **Unit type filter**: Skip `url_capture` and `thread_message` (raw captures)
- **Richest-first sorting**: Process longest content first for maximum entity yield
- **Sequential quality extraction**: Each memory is processed individually via `extract_entities_remote()` with reflection + deduplication enabled (not batch), with 1.5s inter-memory delay to avoid rate limits
- **Progress tracking**: `_current_task["progress"]` updated to `"N/M"` after each memory for live UI display

### Community Detection

Parameters are configurable via settings:
- `communityDetectionIntervalDays`: 7, 14, or 30 days (default: 14)
- `communityResolution`: 0.5–2.0 (default: 1.0, higher = more communities)
- `generateCommunityAISummary`: Whether to generate LLM summaries (default: true)

### Feed Event Integration

Both direct executors emit feed events via `emit_feed_event()` with structured metadata:

**KG Extraction events** include:
- `processed_count`, `total_entities`, `total_relationships`

**Community Detection events** include:
- `num_communities`, `resolution`, `generate_summaries`

These metadata fields are displayed in the Feed context panel when the event is selected.

## Settings UI

Knowledge processing controls are in Settings → "Search & Processing" (merged with the search index section). Three card groups:

1. **Scheduled Tasks**: Toggle switches + manual "Run" buttons for Daily Briefing, Crystallization, Insight Detection
2. **Entity Extraction**: Auto-extract toggle + "Run Backfill" button
3. **Community Detection**: Auto-detect toggle + AI Summary toggle + interval/resolution selectors + "Run Detection" button

## API Endpoints

Manual triggers: `POST /agent/trigger/{task-type}`
- `/trigger/daily-briefing`
- `/trigger/crystallization`
- `/trigger/insight-detection`
- `/trigger/community-detection?resolution=&generate_ai_summary=`
- `/trigger/kg-extraction?backfill=true&memory_ids=id1,id2` (memory_ids for scoped extraction)

Status: `GET /agent/knowledge-processing/status`
- Returns `last_run`: merged dict of scheduler `last_fired` timestamps + direct executor `_last_executed` timestamps
- Returns `current_task`: `{ task_type, started_at, progress? }` or null — used by frontend for live progress display

## Files

| File | Role |
|------|------|
| `agent/manager.py` | Task dispatch, direct executors, settings gates |
| `agent/settings_reader.py` | Read `app-settings.json` KP section |
| `agent/knowledge_tools/graph_jobs.py` | Knowledge Agent tools for KG/community |
| `api/routers/agent.py` | REST trigger endpoints |
| `services/app-settings.ts` | Frontend settings types + persistence |
| `settings-view.tsx` | Settings UI (SearchIndexSection) |
| `lib.rs` | Tauri command bridge |
| `client.ts` | Frontend API wrappers |
