# Remote LLM (Phase 1) – Implementation Notes

Short reference for the first production-ready iteration of Remote LLM.

## Core behavior

- Single routing point: all LLM calls go through `LocalLLMService._generate_response()` which selects Remote vs Local at call time.
- Pro gating: Remote LLM is used only when license tier is "pro"; otherwise hard-falls back to local MLX.
- Safety fallback: Any remote failure auto-falls back to local without crashing the user flow.

## Config and persistence

- Multi‑provider config with active provider
  - Stored at: `~/Library/Application Support/co.nowledge.mem.desktop/remote_llm.json` (platform-appropriate path).
  - Shape: `{ enabled, active_provider, providers: { <provider>: { model, api_base, api_version, extra_params, ... } } }`.
  - Backwards compatible with the legacy flat format (auto-read, re-saved in the new layout).
- Purpose routing (v2)
  - The config now supports **two purposes**:
    - `default`: used by the main app remote inference.
    - `ai_now`: used by the `kimi-cli` AI Now agent (defaults to inheriting `default`).
  - Persisted under `purposes: { default: { provider, model }, ai_now: { provider?, model? } }` where missing `ai_now` values mean “use default”.
- Secrets at rest
  - `api_key` is stored encrypted (AES‑GCM) as `api_key_enc` + `api_key_nonce`.
  - Encryption key: `nowledge_graph_server/services/secure_keys.py` (hardcoded dev key; replace later).

### Multi-instance OpenAI-compatible providers (v2)

For custom OpenAI-compatible endpoints, we support **multiple named instances**:

- Each instance is a distinct provider id in `providers{}` (e.g. `openai_compatible:my-local-abc123`)
- Each instance stores:
  - `type: "openai_compatible"` (provider driver)
  - `display_name: "My Local LLM"` (user-facing label)
  - `api_base`, `model`, and encrypted `api_key`

This keeps backward compatibility: older configs with a single `openai_compatible` entry are still valid.

## Remote generation rules

- Do not forward local-only sampling knobs to remote providers: `temperature`, `top_p`, `top_k`, `min_p` are omitted.
- `max_tokens` is respected for remote calls.
- Model ID normalization for LiteLLM: prefer `provider/model`; accept fully-qualified routes.

## Provider support (Phase 1)

- OpenAI, Anthropic, xAI, OpenRouter, Ollama.
- Gemini (`gemini/*`) via LiteLLM provider `gemini` (Google AI Studio).
- GitHub Copilot (`github_copilot/*`) via LiteLLM provider `github_copilot` (OAuth device flow).
- Azure temporarily hidden in UI (validation friction upstream); backend keeps generic support paths.

## Provider-specific notes

### Gemini (Google AI Studio / LiteLLM `gemini`)

- **Model prefix**: use `gemini/<model>` (example: `gemini/gemini-flash-latest`).
- **Base URL**: do **not** pass `api_base` when it equals `https://generativelanguage.googleapis.com`.
  - LiteLLM handles the correct `/v1beta` routing internally; passing the default host as `api_base` can lead to 404s.
- **Credentials**: set `GEMINI_API_KEY` (and `GOOGLE_API_KEY` for compatibility) only within the scoped provider call to avoid env leakage.

### GitHub Copilot (LiteLLM `github_copilot`)

- **Auth**: Copilot uses **OAuth device flow**, not a user-supplied API key.
  - Token cache is stored under app data: `{appData}/github_copilot/` (alongside `remote_llm.json`).
  - Auth status is determined by presence of a non-empty `access-token` file.
- **No `api_base`**: never persist or forward `api_base` for Copilot. LiteLLM resolves endpoints from the local token cache.
- **Fail-fast inference**: if no cached `access-token` exists, inference should error immediately and instruct the user to authenticate in Settings (avoid triggering device flow during normal requests).
- **Required headers**: Copilot requests must include IDE-identifying headers (e.g. `Editor-Version`, `Copilot-Integration-Id`), otherwise Copilot rejects the request.
- **Model listing**: Copilot model IDs are listed from `models.dev/api.json` (cached) to avoid calling Copilot endpoints that can block on auth.

## AI Now (kimi-cli) integration notes

- **Provider mapping**: our Remote LLM provider is synced into kimi-cli `config.json` via `nowledge-graph/src/services/kimi-config.ts`.
  - Gemini/Google → kimi-cli `google_genai` (native).
  - GitHub Copilot → kimi-cli `openai_legacy` with Copilot headers; Copilot API token is injected at startup.
- **MCP schema compatibility**: kimi-cli’s `google_genai` provider is strict about tool schema fields (e.g. rejects JSON Schema `examples`).
  - We keep `examples` in MCP tool schemas for other clients.
  - When AI Now runs with `google_genai`, tool schemas are sanitized (strip `examples`/`example`) before they reach the LLM.
  - The desktop app forwards the selected provider type via `X-AINOW-LLM-PROVIDER` so the MCP server can apply conditional sanitization.

## Test/Models utilities

- Test connection and list models endpoints accept transient UI configs and merge with saved credentials.
- OpenRouter: first try LiteLLM helpers; fallback to direct `GET /models` with required headers (`HTTP-Referer`, `X-Title`).
- Ollama: direct HTTP `GET /tags` with base URL normalization.

## UI highlights (settings)

- Pro-only: if not Pro, show upsell; do not load remote config.
- Multi‑provider persistence: configured providers are remembered; no need to retype keys (masked, with `hasSavedKey`).
- Instant toggle persistence for master enable/disable.
- “Select” (activate) a provider updates active provider and refreshes the header; pre-activation quick test guards unusable models.
- Keys are never shown; placeholder indicates a saved key exists; “show” action only for newly typed key.

## Logging and diagnostics

- Clear provider selection logs from `LocalLLMService` for each call (remote/local, remote init state).
- Connection/test logs include provider and effective settings used by helpers (with secrets masked).

## Known limitations / Next

- Azure UI disabled pending upstream fixes; re-enable once LiteLLM validation stabilizes.
- Dev-only encryption key; replace with OS keychain/Keyring for production.
- Consider richer provider-specific defaults and better error surfacing in UI.
