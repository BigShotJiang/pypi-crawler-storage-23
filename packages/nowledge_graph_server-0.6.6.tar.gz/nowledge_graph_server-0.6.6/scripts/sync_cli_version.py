#!/usr/bin/env python3
"""
Sync version numbers between nowledge-graph-server and nmem-cli packages.

Usage:
    python scripts/sync_cli_version.py [--bump patch|minor|major]
"""

import re
import sys
from pathlib import Path


def get_version(pyproject_path: Path) -> str:
    """Extract version from pyproject.toml."""
    content = pyproject_path.read_text()
    match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
    if not match:
        raise ValueError(f"Could not find version in {pyproject_path}")
    return match.group(1)


def set_version(file_path: Path, version: str, is_main_pyproject: bool = False) -> None:
    """Set version in a file (pyproject.toml or __init__.py)."""
    content = file_path.read_text()

    if file_path.name == "pyproject.toml":
        # Update the package version
        new_content = re.sub(
            r'^version\s*=\s*"[^"]+"',
            f'version = "{version}"',
            content,
            flags=re.MULTILINE
        )
        # Also update nmem-cli dependency version in main pyproject.toml
        if is_main_pyproject:
            new_content = re.sub(
                r'"nmem-cli>=[\d.]+"',
                f'"nmem-cli>={version}"',
                new_content
            )
    else:  # __init__.py
        new_content = re.sub(
            r'^__version__\s*=\s*"[^"]+"',
            f'__version__ = "{version}"',
            content,
            flags=re.MULTILINE
        )

    file_path.write_text(new_content)


def bump_version(version: str, bump_type: str) -> str:
    """Bump version number."""
    parts = version.split(".")
    if len(parts) != 3:
        raise ValueError(f"Invalid version format: {version}")

    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])

    if bump_type == "major":
        return f"{major + 1}.0.0"
    elif bump_type == "minor":
        return f"{major}.{minor + 1}.0"
    elif bump_type == "patch":
        return f"{major}.{minor}.{patch + 1}"
    else:
        raise ValueError(f"Invalid bump type: {bump_type}")


def main():
    root = Path(__file__).parent.parent

    # File paths
    main_pyproject = root / "pyproject.toml"
    main_init = root / "src" / "nowledge_graph_server" / "__init__.py"
    cli_pyproject = root / "packages" / "nmem-cli" / "pyproject.toml"
    cli_init = root / "packages" / "nmem-cli" / "src" / "nmem_cli" / "__init__.py"

    # Get current version from main package
    current_version = get_version(main_pyproject)
    print(f"Current version: {current_version}")

    # Check for bump argument
    new_version = current_version
    if len(sys.argv) > 1:
        if sys.argv[1] == "--bump" and len(sys.argv) > 2:
            new_version = bump_version(current_version, sys.argv[2])
            print(f"Bumping to: {new_version}")
        elif sys.argv[1] in ("--help", "-h"):
            print(__doc__)
            return

    # Sync all files
    files_to_update = [
        (main_pyproject, True),   # Main pyproject needs nmem-cli dep update
        (main_init, False),
        (cli_pyproject, False),
        (cli_init, False),
    ]

    for file_path, is_main in files_to_update:
        if file_path.exists():
            set_version(file_path, new_version, is_main_pyproject=is_main)
            print(f"Updated: {file_path.relative_to(root)}")
        else:
            print(f"Warning: {file_path.relative_to(root)} not found")

    print(f"\nVersion synced to {new_version}")


if __name__ == "__main__":
    main()
