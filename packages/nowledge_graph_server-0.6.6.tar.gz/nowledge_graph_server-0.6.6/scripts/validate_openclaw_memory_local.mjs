#!/usr/bin/env node

import { spawnSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { access } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath, pathToFileURL } from "node:url";

const DEFAULT_API_URL = process.env.NMEM_API_URL?.trim() || "http://127.0.0.1:14242";

function parseArgs(argv) {
  const parsed = {
    apiUrl: DEFAULT_API_URL,
    apiKey: process.env.NMEM_API_KEY?.trim() || "",
    keepData: false,
    timeoutMs: 30_000,
  };

  for (const token of argv) {
    if (token === "--keep-data") {
      parsed.keepData = true;
      continue;
    }

    if (token.startsWith("--api-url=")) {
      parsed.apiUrl = token.slice("--api-url=".length).trim();
      continue;
    }

    if (token.startsWith("--api-key=")) {
      parsed.apiKey = token.slice("--api-key=".length).trim();
      continue;
    }

    if (token.startsWith("--timeout-ms=")) {
      const value = Number(token.slice("--timeout-ms=".length));
      if (Number.isFinite(value) && value > 0) {
        parsed.timeoutMs = Math.trunc(value);
      }
      continue;
    }

    if (token === "--help" || token === "-h") {
      printHelp();
      process.exit(0);
    }
  }

  return parsed;
}

function printHelp() {
  console.log(`OpenClaw memory provider local validator

Usage:
  node nowledge-graph-py/scripts/validate_openclaw_memory_local.mjs [options]

Options:
  --api-url=<url>      nmem API URL (default: ${DEFAULT_API_URL})
  --api-key=<key>      nmem API key (optional)
  --timeout-ms=<ms>    HTTP timeout in milliseconds (default: 30000)
  --keep-data          Keep created validation data (threads/memories)
  -h, --help           Show this help
`);
}

function assertCondition(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function logStep(step) {
  console.log(`\n[STEP] ${step}`);
}

function logPass(message) {
  console.log(`[PASS] ${message}`);
}

function logWarn(message) {
  console.log(`[WARN] ${message}`);
}

function logInfo(message) {
  console.log(`[INFO] ${message}`);
}

function commandResultToText(result) {
  const stdout = String(result.stdout || "").trim();
  const stderr = String(result.stderr || "").trim();
  return [stdout, stderr].filter(Boolean).join("\n");
}

function resolveNmemCommand() {
  const candidates = [
    ["nmem"],
    ["uvx", "--from", "nmem-cli", "nmem"],
  ];

  for (const candidate of candidates) {
    const [bin, ...baseArgs] = candidate;
    const result = spawnSync(bin, [...baseArgs, "--version"], {
      encoding: "utf-8",
      timeout: 10_000,
      stdio: ["ignore", "pipe", "pipe"],
    });

    if (result.status === 0) {
      return candidate;
    }
  }

  throw new Error("nmem CLI not found on PATH. Install nmem-cli first.");
}

function runCommand(bin, args, timeoutMs = 30_000) {
  const result = spawnSync(bin, args, {
    encoding: "utf-8",
    timeout: timeoutMs,
    stdio: ["ignore", "pipe", "pipe"],
  });

  if (result.error) {
    throw result.error;
  }

  if (result.status !== 0) {
    throw new Error(commandResultToText(result) || `${bin} exited with code ${String(result.status)}`);
  }

  return result;
}

function createApiHelpers(options) {
  function buildHeaders() {
    const headers = {
      "content-type": "application/json",
    };
    if (options.apiKey) {
      headers.authorization = `Bearer ${options.apiKey}`;
      headers["x-nmem-api-key"] = options.apiKey;
    }
    return headers;
  }

  async function apiJson(method, apiPath, body) {
    const maxAttempts = 3;
    const url = `${options.apiUrl}${apiPath}`;

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), options.timeoutMs);

      try {
        const response = await fetch(url, {
          method,
          headers: buildHeaders(),
          body: body === undefined ? undefined : JSON.stringify(body),
          signal: controller.signal,
        });

        const text = await response.text();
        let data = {};
        try {
          data = text ? JSON.parse(text) : {};
        } catch {
          data = { raw: text };
        }

        if (!response.ok) {
          const detail =
            typeof data?.detail === "string"
              ? data.detail
              : typeof data?.message === "string"
                ? data.message
                : typeof data?.raw === "string"
                  ? data.raw
                  : `HTTP ${response.status}`;

          const isRetryableStatus = response.status >= 500;
          if (isRetryableStatus && attempt < maxAttempts) {
            await new Promise((resolve) => setTimeout(resolve, 250 * attempt));
            continue;
          }
          throw new Error(`${method} ${apiPath} failed (${response.status}): ${detail}`);
        }

        return data;
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const isLastAttempt = attempt >= maxAttempts;
        if (!isLastAttempt) {
          await new Promise((resolve) => setTimeout(resolve, 250 * attempt));
          continue;
        }
        throw new Error(`${method} ${apiPath} request error: ${message}`);
      } finally {
        clearTimeout(timeout);
      }
    }

    throw new Error(`${method} ${apiPath} request failed after retries`);
  }

  return { apiJson };
}

function sanitizeIdPart(input, max = 48) {
  const normalized = String(input || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!normalized) return "session";
  return normalized.slice(0, max);
}

function expectedThreadId(sessionIdOrKey) {
  const base = String(sessionIdOrKey || "session");
  const slug = sanitizeIdPart(base);
  const digest = createHash("sha1").update(base).digest("hex").slice(0, 10);
  return `openclaw-${slug}-${digest}`;
}

async function ensurePluginFiles(repoRoot) {
  const pluginClientPath = path.join(
    repoRoot,
    "community",
    "nowledge-mem-openclaw-plugin",
    "src",
    "client.js",
  );
  await access(pluginClientPath);
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const scriptDir = path.dirname(fileURLToPath(import.meta.url));
  const repoRoot = path.resolve(scriptDir, "..", "..");
  const marker = `oc-validator-${Date.now()}-${randomUUID().slice(0, 8)}`;
  const threadsToDelete = new Set();
  const memoriesToDelete = new Set();

  logInfo(`Repo root: ${repoRoot}`);
  logInfo(`API URL: ${options.apiUrl}`);
  logInfo(`Run marker: ${marker}`);

  const nmemCmd = resolveNmemCommand();
  const [nmemBin, ...nmemBaseArgs] = nmemCmd;
  logInfo(`nmem command: ${nmemCmd.join(" ")}`);

  const { apiJson } = createApiHelpers(options);

  let capturedThreadId = "";

  try {
    logStep("CLI capability checks");
    const versionRes = runCommand(nmemBin, [...nmemBaseArgs, "--version"], 10_000);
    const versionText = commandResultToText(versionRes);
    assertCondition(versionText.length > 0, "nmem --version returned empty output");

    const threadsHelp = commandResultToText(
      runCommand(nmemBin, [...nmemBaseArgs, "t", "--help"], 10_000),
    );
    const createHelp = commandResultToText(
      runCommand(nmemBin, [...nmemBaseArgs, "t", "create", "--help"], 10_000),
    );
    const appendHelp = commandResultToText(
      runCommand(nmemBin, [...nmemBaseArgs, "t", "append", "--help"], 10_000),
    );

    assertCondition(threadsHelp.includes("append"), "nmem t --help does not list append");
    assertCondition(createHelp.includes("--id"), "nmem t create --help missing --id");
    assertCondition(
      appendHelp.includes("--idempotency-key"),
      "nmem t append --help missing --idempotency-key",
    );
    logPass(`CLI surface is ready (${versionText})`);

    logStep("API health check");
    const health = await apiJson("GET", "/health");
    assertCondition(health.status === "ok", `health.status is ${String(health.status)}`);
    assertCondition(health.database_connected === true, "health.database_connected is not true");
    assertCondition(health.services_ready === true, "health.services_ready is not true");
    logPass("API health is OK");

    logStep("Thread metadata + append idempotency round-trip");
    const threadId = `oc-e2e-${Date.now()}-${randomUUID().slice(0, 6)}`;
    threadsToDelete.add(threadId);

    const createMessages = [
      {
        role: "user",
        content: `create marker ${marker}`,
        metadata: {
          external_id: `${marker}-create-user`,
          marker,
          source: "validator",
        },
      },
      {
        role: "assistant",
        content: `create reply ${marker}`,
        metadata: {
          external_id: `${marker}-create-assistant`,
          marker,
          source: "validator",
        },
      },
    ];

    await apiJson("POST", "/threads", {
      thread_id: threadId,
      title: `OpenClaw validator ${marker}`,
      source: "openclaw-validator",
      messages: createMessages,
    });

    const appendPayload = {
      messages: [
        {
          role: "assistant",
          content: `append marker ${marker}`,
          metadata: {
            external_id: `${marker}-append-1`,
            marker,
            source: "validator",
          },
        },
      ],
      deduplicate: true,
      idempotency_key: `${marker}-append-key`,
    };

    const appendFirst = await apiJson(
      "POST",
      `/threads/${encodeURIComponent(threadId)}/append`,
      appendPayload,
    );
    const appendRetry = await apiJson(
      "POST",
      `/threads/${encodeURIComponent(threadId)}/append`,
      appendPayload,
    );

    assertCondition(
      Number(appendFirst.messages_added ?? 0) >= 1,
      "first append did not add messages",
    );
    assertCondition(
      Number(appendRetry.messages_added ?? -1) === 0,
      "retry append was not idempotent",
    );

    const fetchedThread = await apiJson("GET", `/threads/${encodeURIComponent(threadId)}`);
    const fetchedMessages = Array.isArray(fetchedThread.messages) ? fetchedThread.messages : [];
    const metadataFound = fetchedMessages.some(
      (message) => message?.metadata?.external_id === `${marker}-append-1`,
    );
    assertCondition(metadataFound, "message metadata.external_id was not preserved on fetch");
    logPass("Thread append idempotency and metadata preservation verified");

    logStep("Plugin client + tool contract checks");
    await ensurePluginFiles(repoRoot);

    const pluginSrcDir = path.join(repoRoot, "community", "nowledge-mem-openclaw-plugin", "src");
    const pluginClientPath = pathToFileURL(path.join(pluginSrcDir, "client.js")).href;
    const pluginSearchPath = pathToFileURL(path.join(pluginSrcDir, "tools", "memory-search.js")).href;
    const pluginGetPath = pathToFileURL(path.join(pluginSrcDir, "tools", "memory-get.js")).href;
    const pluginCapturePath = pathToFileURL(path.join(pluginSrcDir, "hooks", "capture.js")).href;

    const [{ NowledgeMemClient }, { createMemorySearchTool }, { createMemoryGetTool }, captureMod] =
      await Promise.all([
        import(pluginClientPath),
        import(pluginSearchPath),
        import(pluginGetPath),
        import(pluginCapturePath),
      ]);
    const { buildAgentEndCaptureHandler, buildBeforeResetCaptureHandler } = captureMod;

    const pluginLogger = {
      info: (message) => {
        const text = String(message || "");
        const captureStored = text.match(/capture: stored memory ([a-zA-Z0-9_-]+)/);
        if (captureStored?.[1]) {
          memoriesToDelete.add(captureStored[1]);
        }
        logInfo(`plugin: ${text}`);
      },
      warn: (message) => logWarn(`plugin: ${message}`),
      error: (message) => {
        const text = String(message || "");
        const expectedFirstAppendMiss =
          text.includes(" t append ") && text.toLowerCase().includes("thread not found");
        if (expectedFirstAppendMiss) {
          const threadIdMatch = text.match(/thread not found:\s*([a-zA-Z0-9-]+)/i);
          const target = threadIdMatch?.[1] || "unknown-thread";
          logInfo(`plugin: expected append-before-create miss (${target})`);
          return;
        }
        logWarn(`plugin-error: ${text}`);
      },
    };

    const client = new NowledgeMemClient(pluginLogger);
    const resolvedCmd = client.resolveCommand();
    assertCondition(Array.isArray(resolvedCmd) && resolvedCmd.length > 0, "plugin failed to resolve nmem command");

    const clientAppendMessage = {
      role: "user",
      content: `client append marker ${marker}`,
      metadata: {
        external_id: `${marker}-client-append`,
        marker,
      },
    };

    const clientAppendKey = `${marker}-client-key`;
    const clientAppendFirst = await client.appendThread({
      threadId,
      messages: [clientAppendMessage],
      deduplicate: true,
      idempotencyKey: clientAppendKey,
    });
    const clientAppendRetry = await client.appendThread({
      threadId,
      messages: [clientAppendMessage],
      deduplicate: true,
      idempotencyKey: clientAppendKey,
    });

    assertCondition(clientAppendFirst.messagesAdded >= 1, "plugin client append did not add messages");
    assertCondition(clientAppendRetry.messagesAdded === 0, "plugin client append retry was not idempotent");

    const markerMemoryText = `OpenClaw validator handoff marker ${marker} for memory_search and memory_get contract`;
    const markerMemoryId = await client.addMemory(markerMemoryText, `Validator ${marker}`, 0.73);
    memoriesToDelete.add(String(markerMemoryId));

    const memorySearchTool = createMemorySearchTool(client, pluginLogger);
    const memoryGetTool = createMemoryGetTool(client, pluginLogger);

    const searchToolResult = await memorySearchTool.execute("validator-search", {
      query: marker,
      maxResults: 8,
      minScore: 0,
    });
    const searchPayload = JSON.parse(String(searchToolResult?.content?.[0]?.text || "{}"));
    const searchResults = Array.isArray(searchPayload.results) ? searchPayload.results : [];
    assertCondition(searchResults.length > 0, "memory_search returned no results for marker");

    const selectedResult =
      searchResults.find((entry) => String(entry.snippet || "").includes(marker)) || searchResults[0];
    assertCondition(
      typeof selectedResult?.path === "string" &&
        selectedResult.path.startsWith("nowledgemem://memory/"),
      "memory_search did not return nowledgemem://memory/<id> path",
    );

    const memoryGetResult = await memoryGetTool.execute("validator-get", {
      path: selectedResult.path,
    });
    const memoryGetPayload = JSON.parse(String(memoryGetResult?.content?.[0]?.text || "{}"));
    assertCondition(
      String(memoryGetPayload.text || "").includes(marker),
      "memory_get did not return content for memory_search path",
    );

    const wmGetResult = await memoryGetTool.execute("validator-wm", {
      path: "MEMORY.md",
      from: 1,
      lines: 20,
    });
    const wmPayload = JSON.parse(String(wmGetResult?.content?.[0]?.text || "{}"));
    if (wmPayload.source === "working-memory") {
      logPass("memory_get MEMORY.md alias mapped to Working Memory");
    } else {
      assertCondition(
        typeof wmPayload.error === "string" && wmPayload.error.length > 0,
        "memory_get MEMORY.md returned unexpected payload",
      );
      logWarn(`memory_get MEMORY.md alias not available: ${wmPayload.error}`);
    }
    logPass("memory_search -> memory_get tool contract verified");

    logStep("Capture lifecycle dedup check (agent_end + before_reset/compaction)");
    const captureSessionId = `validator-session-${randomUUID()}`;
    const captureSessionKey = `validator-key-${randomUUID().slice(0, 12)}`;
    capturedThreadId = expectedThreadId(captureSessionId);
    threadsToDelete.add(capturedThreadId);

    const captureMessages = [
      {
        role: "user",
        content:
          `Please remember this durable marker ${marker} across reset and compaction ` +
          "because this sentence is intentionally long and information-dense for capture.",
      },
      {
        role: "assistant",
        content: `Captured marker ${marker} for continuity.`,
      },
    ];

    const agentEndHandler = buildAgentEndCaptureHandler(client, {}, pluginLogger);
    const threadCaptureHandler = buildBeforeResetCaptureHandler(client, {}, pluginLogger);

    await agentEndHandler(
      {
        success: true,
        messages: captureMessages,
      },
      {
        sessionId: captureSessionId,
        sessionKey: captureSessionKey,
      },
    );

    await threadCaptureHandler(
      {
        reason: "before_reset",
        messages: captureMessages,
      },
      {
        sessionId: captureSessionId,
        sessionKey: captureSessionKey,
      },
    );

    await threadCaptureHandler(
      {
        reason: "compaction",
        messages: captureMessages,
      },
      {
        sessionId: captureSessionId,
        sessionKey: captureSessionKey,
      },
    );

    const captureThread = await apiJson("GET", `/threads/${encodeURIComponent(capturedThreadId)}`);
    const captureThreadMessages = Array.isArray(captureThread.messages) ? captureThread.messages : [];
    assertCondition(
      captureThreadMessages.length === 2,
      `capture lifecycle produced ${captureThreadMessages.length} messages (expected 2 with dedup)`,
    );
    logPass("Capture lifecycle dedup behavior verified");

    console.log("\n[RESULT] PASS - OpenClaw memory provider local validation succeeded");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`\n[RESULT] FAIL - ${message}`);
    process.exitCode = 1;
  } finally {
    if (!options.keepData) {
      logStep("Cleanup");

      try {
        const memoriesList = await apiJson("GET", "/memories?limit=100&offset=0");
        const memories = Array.isArray(memoriesList.memories) ? memoriesList.memories : [];
        for (const memory of memories) {
          const memoryId = String(memory?.id || "").trim();
          const title = String(memory?.title || "");
          const content = String(memory?.content || "");
          if (!memoryId) continue;
          if (title.includes(marker) || content.includes(marker)) {
            memoriesToDelete.add(memoryId);
          }
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logWarn(`cleanup memory list discovery failed: ${message}`);
      }

      try {
        const memorySearch = await apiJson(
          "GET",
          `/memories/search?q=${encodeURIComponent(marker)}&limit=20&mode=fast`,
        );
        const memories = Array.isArray(memorySearch.memories) ? memorySearch.memories : [];
        for (const memory of memories) {
          const memoryId = String(memory?.id || "").trim();
          const title = String(memory?.title || "");
          const content = String(memory?.content || "");
          if (!memoryId) continue;
          if (title.includes(marker) || content.includes(marker)) {
            memoriesToDelete.add(memoryId);
          }
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logWarn(`cleanup memory search discovery failed: ${message}`);
      }

      for (const memoryId of memoriesToDelete) {
        try {
          await apiJson("DELETE", `/memories/${encodeURIComponent(memoryId)}`);
        } catch {
          // best effort
        }
      }

      for (const threadId of threadsToDelete) {
        try {
          await apiJson(
            "DELETE",
            `/threads/${encodeURIComponent(threadId)}?cascade_delete_memories=false`,
          );
        } catch {
          // best effort
        }
      }

      logPass(
        `Cleanup done (threads attempted: ${threadsToDelete.size}, memories attempted: ${memoriesToDelete.size})`,
      );
    } else {
      logWarn("Skipping cleanup because --keep-data was set");
    }
  }

  if (process.exitCode && process.exitCode !== 0) {
    process.exit(process.exitCode);
  }
}

await main();
