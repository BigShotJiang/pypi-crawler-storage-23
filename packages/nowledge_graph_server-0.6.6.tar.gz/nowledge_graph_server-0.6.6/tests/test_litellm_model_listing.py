from __future__ import annotations

import sys
import types

import pytest

from nowledge_graph_server.services.litellm import api as litellm_api
from nowledge_graph_server.services.litellm import models as litellm_models
from nowledge_graph_server.services.remote_llm_config import RemoteLLMConfig


class _FakeManager:
    def __init__(self) -> None:
        self._active = RemoteLLMConfig(
            enabled=True,
            provider="openai",
            provider_type="openai",
            model="openai/gpt-4.1",
            api_key="openai-key",
            api_base="https://api.openai.com/v1",
        )
        self._providers = {
            "openai": self._active,
            "gemini": RemoteLLMConfig(
                enabled=True,
                provider="gemini",
                provider_type="gemini",
                model="gemini/gemini-flash-latest",
                api_key="gemini-key",
                api_base="https://generativelanguage.googleapis.com",
            ),
            "openai_compatible:lab": RemoteLLMConfig(
                enabled=True,
                provider="openai_compatible:lab",
                provider_type="openai_compatible",
                model="qwen/qwen3-coder",
                api_key="lab-key",
                api_base="http://localhost:1234/v1",
            ),
        }

    def get_config(self) -> RemoteLLMConfig:
        return self._active

    def get_all_provider_configs(self) -> dict[str, RemoteLLMConfig]:
        return self._providers


@pytest.mark.asyncio
async def test_list_models_uses_target_provider_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    manager = _FakeManager()
    captured: dict[str, str | None] = {}

    async def _fake_list_models_for_provider(**kwargs):
        captured.update(kwargs)
        return {"success": True, "provider": kwargs["provider"], "models": []}

    monkeypatch.setattr(litellm_api, "get_config_manager", lambda: manager)
    monkeypatch.setattr(litellm_api, "list_models_for_provider", _fake_list_models_for_provider)

    await litellm_api.list_models("gemini")

    assert captured["provider"] == "gemini"
    assert captured["api_key"] == "gemini-key"
    assert captured["api_base"] == "https://generativelanguage.googleapis.com"


@pytest.mark.asyncio
async def test_list_models_uses_target_provider_type_for_custom_instance(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = _FakeManager()
    captured: dict[str, str | None] = {}

    async def _fake_list_models_for_provider(**kwargs):
        captured.update(kwargs)
        return {"success": True, "provider": kwargs["provider"], "models": []}

    monkeypatch.setattr(litellm_api, "get_config_manager", lambda: manager)
    monkeypatch.setattr(litellm_api, "list_models_for_provider", _fake_list_models_for_provider)

    await litellm_api.list_models("openai_compatible:lab")

    assert captured["provider"] == "openai_compatible"
    assert captured["api_key"] == "lab-key"
    assert captured["api_base"] == "http://localhost:1234/v1"


@pytest.mark.asyncio
async def test_list_models_for_provider_returns_clear_error_when_key_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Ensure test does not require real litellm installation.
    fake_litellm = types.ModuleType("litellm")
    fake_utils = types.ModuleType("litellm.utils")

    def _fake_get_valid_models(**_kwargs):
        return ["unused"]

    fake_utils.get_valid_models = _fake_get_valid_models  # type: ignore[attr-defined]
    fake_litellm.utils = fake_utils  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "litellm", fake_litellm)
    monkeypatch.setitem(sys.modules, "litellm.utils", fake_utils)

    result = await litellm_models.list_models_for_provider("gemini", api_key="")

    assert result["success"] is False
    assert result["models"] == []
    assert "API key is not configured" in result["error"]
    assert "GEMINI_API_BASE" not in result["error"]
