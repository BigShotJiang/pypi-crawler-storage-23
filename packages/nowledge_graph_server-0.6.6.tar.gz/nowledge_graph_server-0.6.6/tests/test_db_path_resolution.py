from __future__ import annotations

from pathlib import Path

from nowledge_graph_server.database.version_upgrade import db_version_manager


def test_get_db_path_prefers_existing_env_path(tmp_path: Path, monkeypatch) -> None:
    db_path = tmp_path / "custom.db"
    db_path.write_text("x", encoding="utf-8")

    monkeypatch.setenv("NOWLEDGE_DB_PATH", str(db_path))
    resolved = db_version_manager.get_db_path()
    assert resolved == db_path


def test_get_db_path_recovers_from_missing_env_path_with_sibling_v2(
    tmp_path: Path, monkeypatch
) -> None:
    broken_env_path = tmp_path / "nowledge_graph.db"
    v2_path = tmp_path / "nowledge_graph_v2.db"
    v2_path.write_text("x", encoding="utf-8")

    monkeypatch.setenv("NOWLEDGE_DB_PATH", str(broken_env_path))
    resolved = db_version_manager.get_db_path()
    assert resolved == v2_path


def test_get_db_path_env_missing_family_falls_back_to_global_candidates(
    tmp_path: Path, monkeypatch
) -> None:
    stale_root = tmp_path / "stale"
    real_root = tmp_path / "real"
    stale_root.mkdir(parents=True, exist_ok=True)
    real_root.mkdir(parents=True, exist_ok=True)

    v2_path = real_root / "nowledge_graph_v2.db"
    v2_path.write_text("real-db", encoding="utf-8")

    monkeypatch.setattr(
        db_version_manager,
        "_candidate_data_dirs",
        lambda: [stale_root, real_root],
    )
    monkeypatch.setenv("NOWLEDGE_DB_PATH", str(stale_root / "nowledge_graph.db"))

    resolved = db_version_manager.get_db_path()
    assert resolved == v2_path


def test_get_db_path_env_missing_family_without_any_existing_db_uses_requested_path(
    tmp_path: Path, monkeypatch
) -> None:
    stale_root = tmp_path / "stale"
    empty_root = tmp_path / "empty"
    stale_root.mkdir(parents=True, exist_ok=True)
    empty_root.mkdir(parents=True, exist_ok=True)

    requested = stale_root / "nowledge_graph.db"

    monkeypatch.setattr(
        db_version_manager,
        "_candidate_data_dirs",
        lambda: [empty_root],
    )
    monkeypatch.setenv("NOWLEDGE_DB_PATH", str(requested))

    resolved = db_version_manager.get_db_path()
    assert resolved == requested
