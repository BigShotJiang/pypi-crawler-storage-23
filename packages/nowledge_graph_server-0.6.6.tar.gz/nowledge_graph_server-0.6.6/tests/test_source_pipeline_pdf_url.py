from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
import types

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.modules.setdefault("real_ladybug", types.SimpleNamespace(Connection=object, QueryResult=object))

from nowledge_graph_server.services import source_pipeline as source_pipeline_module
from nowledge_graph_server.services.source_parser import is_probable_pdf_url
from nowledge_graph_server.services.source_pipeline import SourcePipeline
from nowledge_graph_server.services.source_storage import SourceStorageService


class _FakeSourceRepo:
    def __init__(self) -> None:
        self._sources: dict[str, object] = {}

    async def get_source_by_sha256(self, sha256: str):
        for source in self._sources.values():
            if getattr(source, "sha256", None) == sha256:
                return source
        return None

    async def create_source(self, source):
        self._sources[source.id] = source
        return source

    async def update_lifecycle_state(
        self,
        source_id: str,
        state: str,
        error_message: str | None = None,
        **extra_fields,
    ) -> bool:
        source = self._sources[source_id]
        source.lifecycle_state = state
        if error_message is not None:
            source.error_message = error_message
        for key, value in extra_fields.items():
            setattr(source, key, value)
        return True

    async def get_source(self, source_id: str):
        return self._sources.get(source_id)


@pytest.fixture
def fake_pipeline(tmp_path: Path) -> SourcePipeline:
    repo = _FakeSourceRepo()
    db = SimpleNamespace(source_repo=repo)
    storage = SourceStorageService(sources_root=tmp_path)
    return SourcePipeline(db_client=db, storage=storage)


def test_is_probable_pdf_url_detection():
    assert is_probable_pdf_url("https://example.com/docs/report.pdf")
    assert is_probable_pdf_url("https://example.com/download?file=report.PDF")
    assert is_probable_pdf_url("https://arxiv.org/pdf/2501.01234")
    assert not is_probable_pdf_url("https://example.com/article?id=123")


@pytest.mark.asyncio
async def test_ingest_url_direct_pdf_uses_file_pipeline(fake_pipeline: SourcePipeline, monkeypatch):
    monkeypatch.setattr(source_pipeline_module, "is_probable_pdf_url", lambda _url: True)

    async def _fake_fetch_url_file(_url: str):
        return b"%PDF-1.7 test content", "application/pdf", "paper.pdf", "httpx_file"

    async def _should_not_fetch_html(_url: str):
        raise AssertionError("HTML fetch should not run for direct PDF URL")

    monkeypatch.setattr(source_pipeline_module, "fetch_url_file", _fake_fetch_url_file)
    monkeypatch.setattr(source_pipeline_module, "fetch_url_html", _should_not_fetch_html)

    async def _fake_parse(self, source):
        source.parsed_path = str(self.storage.source_dir(source.id) / "paper.md")
        source.lifecycle_state = "parsed"
        return source

    async def _fake_chunk(self, source):
        source.chunk_count = 1
        source.lifecycle_state = "chunked"
        return source

    async def _fake_index(self, source):
        source.lifecycle_state = "indexed"
        return source

    monkeypatch.setattr(SourcePipeline, "_parse", _fake_parse)
    monkeypatch.setattr(SourcePipeline, "_chunk", _fake_chunk)
    monkeypatch.setattr(SourcePipeline, "_index", _fake_index)

    source = await fake_pipeline.ingest_url("https://example.com/paper.pdf")

    assert source.source_type == "url"
    assert source.mime_type == "application/pdf"
    assert source.file_path is not None
    assert source.file_path.endswith(".pdf")
    assert Path(source.file_path).exists()
    assert source.metadata["fetch_method"] == "httpx_file"
    assert source.lifecycle_state == "indexed"


@pytest.mark.asyncio
async def test_ingest_url_pdf_candidate_falls_back_to_html(fake_pipeline: SourcePipeline, monkeypatch):
    monkeypatch.setattr(source_pipeline_module, "is_probable_pdf_url", lambda _url: True)

    async def _fake_fetch_url_file(_url: str):
        return b"<html>not pdf</html>", "text/html", "index.html", "httpx_file"

    async def _fake_fetch_url_html(_url: str):
        return "<html><title>Fallback</title><body>Hello</body></html>", "Fallback", "httpx"

    def _fake_parse_html(_html: str, title: str | None = None):
        return "# Parsed HTML", title or "Fallback", None

    async def _should_not_parse_file(self, source):
        raise AssertionError("File parse should not run for HTML fallback")

    async def _fake_chunk(self, source):
        source.chunk_count = 1
        source.lifecycle_state = "chunked"
        return source

    async def _fake_index(self, source):
        source.lifecycle_state = "indexed"
        return source

    monkeypatch.setattr(source_pipeline_module, "fetch_url_file", _fake_fetch_url_file)
    monkeypatch.setattr(source_pipeline_module, "fetch_url_html", _fake_fetch_url_html)
    monkeypatch.setattr(source_pipeline_module, "parse_html", _fake_parse_html)
    monkeypatch.setattr(SourcePipeline, "_parse", _should_not_parse_file)
    monkeypatch.setattr(SourcePipeline, "_chunk", _fake_chunk)
    monkeypatch.setattr(SourcePipeline, "_index", _fake_index)

    source = await fake_pipeline.ingest_url("https://example.com/report.pdf?download=1")

    assert source.source_type == "url"
    assert source.mime_type == "text/html"
    assert source.file_path is None
    assert source.metadata["fetch_method"] == "httpx"
    assert source.lifecycle_state == "indexed"
