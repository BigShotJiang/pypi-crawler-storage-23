from __future__ import annotations

import sys
from pathlib import Path

from starlette.datastructures import Headers
from starlette.requests import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nowledge_graph_server.api.routers.browser_bridge import (
    is_local_browser_bridge_http_request,
    is_local_browser_bridge_ws_connection,
)


def _make_http_request(
    *,
    client_ip: str,
    headers: dict[str, str] | None = None,
) -> Request:
    encoded_headers = [
        (key.lower().encode("utf-8"), value.encode("utf-8"))
        for key, value in (headers or {}).items()
    ]
    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": "GET",
        "path": "/browser-bridge/status",
        "raw_path": b"/browser-bridge/status",
        "query_string": b"",
        "headers": encoded_headers,
        "client": (client_ip, 12345),
        "server": ("127.0.0.1", 14242),
        "scheme": "http",
    }
    return Request(scope)


class _DummyClient:
    def __init__(self, host: str):
        self.host = host


class _DummyWebSocket:
    def __init__(self, *, client_host: str, headers: dict[str, str] | None = None):
        self.client = _DummyClient(client_host)
        self.headers = Headers(headers or {})


def test_browser_bridge_http_local_loopback_allowed():
    request = _make_http_request(client_ip="127.0.0.1")
    assert is_local_browser_bridge_http_request(request) is True


def test_browser_bridge_http_tunnel_marked_request_blocked():
    request = _make_http_request(
        client_ip="127.0.0.1",
        headers={"cf-connecting-ip": "203.0.113.10"},
    )
    assert is_local_browser_bridge_http_request(request) is False


def test_browser_bridge_http_non_loopback_blocked():
    request = _make_http_request(client_ip="192.168.1.20")
    assert is_local_browser_bridge_http_request(request) is False


def test_browser_bridge_ws_local_loopback_allowed():
    ws = _DummyWebSocket(client_host="127.0.0.1")
    assert is_local_browser_bridge_ws_connection(ws) is True


def test_browser_bridge_ws_tunnel_marked_blocked():
    ws = _DummyWebSocket(
        client_host="127.0.0.1",
        headers={"cf-connecting-ip": "203.0.113.10"},
    )
    assert is_local_browser_bridge_ws_connection(ws) is False


def test_browser_bridge_ws_non_loopback_blocked():
    ws = _DummyWebSocket(client_host="203.0.113.10")
    assert is_local_browser_bridge_ws_connection(ws) is False
