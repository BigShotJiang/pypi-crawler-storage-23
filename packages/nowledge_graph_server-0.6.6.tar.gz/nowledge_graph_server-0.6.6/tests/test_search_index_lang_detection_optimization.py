from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
import types

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
# Minimal LanceDB stubs for import-time dependencies in search_index package.
sys.modules.setdefault("lancedb", types.SimpleNamespace())
sys.modules.setdefault("lancedb.pydantic", types.SimpleNamespace(LanceModel=object, Vector=list))
sys.modules.setdefault("lancedb.table", types.SimpleNamespace(Table=object))

from nowledge_graph_server.services.search_index import source_sync
from nowledge_graph_server.services.search_index import tokenizers


def test_detect_language_truncates_input_for_fast_langdetect(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: dict[str, object] = {}

    def _fake_detect(text: str, model: str = "lite") -> dict[str, str]:
        calls["text_len"] = len(text)
        calls["model"] = model
        return {"lang": "en"}

    monkeypatch.setattr(tokenizers, "_get_language_detector", lambda: _fake_detect)

    detected = tokenizers.detect_language("x" * 500)

    assert detected == "en"
    assert calls["model"] == "lite"
    # Pre-truncated before calling fast-langdetect to avoid repeated warning noise.
    assert calls["text_len"] == 80


@pytest.mark.asyncio
async def test_source_chunk_sync_detects_language_once_per_source(monkeypatch: pytest.MonkeyPatch) -> None:
    detect_calls = {"count": 0}
    tokenized_langs: list[str | None] = []

    def _fake_detect_language(_text: str) -> str:
        detect_calls["count"] += 1
        return "en"

    def _fake_tokenize(text: str, lang: str | None = None) -> str:
        tokenized_langs.append(lang)
        return text

    class _FakeSearchService:
        def __init__(self) -> None:
            self.rows: list[dict] = []

        async def upsert_source_chunk(self, _chunk_id: str, data: dict) -> None:
            self.rows.append(data)

    class _FakeBgeService:
        async def embed_text(self, _text: str, is_query: bool = False) -> list[float]:
            assert is_query is False
            return [0.1, 0.2]

    fake_search = _FakeSearchService()

    async def _fake_get_search_index_service():
        return fake_search

    async def _fake_get_bge_m3_service():
        return _FakeBgeService()

    monkeypatch.setattr(source_sync, "detect_language", _fake_detect_language)
    monkeypatch.setattr(source_sync, "tokenize_for_fts", _fake_tokenize)
    monkeypatch.setattr(source_sync, "get_search_index_service", _fake_get_search_index_service)
    monkeypatch.setattr(source_sync, "get_bge_m3_service", _fake_get_bge_m3_service)

    chunks = [
        SimpleNamespace(
            text="Chunk A content",
            heading_context="Heading A",
            chunk_index=0,
            token_count=10,
        ),
        SimpleNamespace(
            text="Chunk B content",
            heading_context="Heading B",
            chunk_index=1,
            token_count=12,
        ),
    ]

    synced = await source_sync.sync_source_chunks_to_index("src_test", chunks)

    assert synced == 2
    assert len(fake_search.rows) == 2
    # Exactly one language detection for the whole source chunk batch.
    assert detect_calls["count"] == 1
    # Two tokenized fields per chunk (content + heading_context), all reuse source lang.
    assert tokenized_langs == ["en", "en", "en", "en"]
