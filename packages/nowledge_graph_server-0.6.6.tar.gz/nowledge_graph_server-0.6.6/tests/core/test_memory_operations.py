"""
Comprehensive test suite for MemoryOperations core business logic.

This test module verifies all memory-related operations work correctly
and serves as regression testing for future development.
"""

import pytest
from datetime import datetime
from typing import List, Optional

from tests import test_core_services, SAMPLE_MEMORIES, TestAssertions
from src.nowledge_graph_server.models import MemoryCreateResponse, MemorySearchResult
from src.nowledge_graph_server.core.memory_operations import MemoryOperations


class TestMemoryOperations:
    """Comprehensive test suite for MemoryOperations."""

    @pytest.mark.asyncio
    async def test_memory_creation_basic(self) -> None:
        """Test basic memory creation functionality."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Test data
            content = "React.memo prevents unnecessary re-renders in React components"
            importance = 0.8

            # Create memory
            result = await memory_ops.create_memory(
                content=content,
                importance=importance,
                extract_entities=False,
            )

            # Verify response structure
            assert result is not None
            assert isinstance(result, MemoryCreateResponse)
            TestAssertions.assert_memory_node_valid(result.memory, content)
            assert result.memory.importance == importance
            assert result.created_relationships >= 0

            # Verify memory was stored in database
            stored_memory = await memory_ops.get_memory_by_id(result.memory.id)
            assert stored_memory is not None
            TestAssertions.assert_memory_node_valid(stored_memory, content)

    @pytest.mark.asyncio
    async def test_memory_creation_with_labels(self) -> None:
        """Test memory creation with label assignment."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            content = "Python async/await enables asynchronous programming"
            labels = ["python", "async", "programming"]

            result = await memory_ops.create_memory(
                content=content,
                importance=0.7,
                labels=labels,
                extract_entities=False,
            )

            assert result is not None
            TestAssertions.assert_memory_node_valid(result.memory, content)
            # Note: Label assignment might fail due to schema issues, but memory should still be created
            assert isinstance(result.assigned_labels, list)

    @pytest.mark.asyncio
    async def test_memory_creation_with_metadata(self) -> None:
        """Test memory creation with custom metadata."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            content = "KuzuDB supports vector operations for graph analytics"
            metadata = {
                "category": "infrastructure",
                "technology": "database",
                "source": "documentation",
            }

            result = await memory_ops.create_memory(
                content=content,
                importance=0.9,
                metadata=metadata,
                extract_entities=False,
            )

            assert result is not None
            TestAssertions.assert_memory_node_valid(result.memory, content)
            assert result.memory.metadata["category"] == "infrastructure"
            assert result.memory.metadata["technology"] == "database"

    @pytest.mark.asyncio
    async def test_memory_retrieval_by_id(self) -> None:
        """Test retrieving memories by ID."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create a memory
            content = "Test memory for ID retrieval functionality"
            result = await memory_ops.create_memory(
                content=content,
                importance=0.6,
                extract_entities=False,
            )
            assert result is not None
            memory_id = result.memory.id

            # Retrieve by ID
            retrieved = await memory_ops.get_memory_by_id(memory_id)

            assert retrieved is not None
            TestAssertions.assert_memory_node_valid(retrieved, content)
            assert retrieved.id == memory_id
            assert retrieved.importance == 0.6

            # Test non-existent ID
            non_existent = await memory_ops.get_memory_by_id("nonexistent_id_12345")
            assert non_existent is None

    @pytest.mark.asyncio
    async def test_memory_search_functionality(self) -> None:
        """Test memory search with semantic similarity."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create multiple memories with different content
            memories_content = [
                "React.memo optimizes component rendering performance in React applications",
                "Vue.js provides reactive data binding for frontend development",
                "Python asyncio enables concurrent programming patterns",
                "JavaScript promises handle asynchronous operations effectively",
            ]

            created_ids = []
            for content in memories_content:
                result = await memory_ops.create_memory(
                    content=content,
                    importance=0.5,
                    extract_entities=False,
                )
                assert result is not None
                created_ids.append(result.memory.id)

            # Test search for React-related content
            search_results = await memory_ops.search_memories(
                query="React performance optimization components",
                limit=10,
            )

            # Verify search results structure
            assert isinstance(search_results, list)
            for result in search_results:
                assert isinstance(result, MemorySearchResult)
                TestAssertions.assert_memory_node_valid(result.memory)
                assert 0.0 <= result.similarity_score <= 1.0
                # assert result.memory.id in created_ids

    @pytest.mark.asyncio
    async def test_memory_listing_and_pagination(self) -> None:
        """Test listing memories with filtering and pagination."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create memories with different importance scores
            test_data = [
                ("High importance memory content", 0.9),
                ("Medium importance memory content", 0.5),
                ("Low importance memory content", 0.2),
                ("Another high importance memory", 0.8),
            ]

            created_ids = []
            for content, importance in test_data:
                result = await memory_ops.create_memory(
                    content=content,
                    importance=importance,
                    extract_entities=False,
                )
                assert result is not None
                created_ids.append(result.memory.id)

            # Test listing all memories
            all_memories = await memory_ops.list_memories(limit=10)
            assert isinstance(all_memories, list)
            assert len(all_memories) >= 4

            # Test filtering by importance
            high_importance = await memory_ops.list_memories(
                limit=10, importance_min=0.8
            )
            assert (
                len(high_importance) >= 2
            )  # Should find at least 2 high importance memories
            for memory in high_importance:
                assert memory.importance >= 0.8

            # Test pagination with limit
            limited = await memory_ops.list_memories(limit=2)
            assert len(limited) <= 2

    @pytest.mark.asyncio
    async def test_memory_state_management(self) -> None:
        """Test memory state transitions (active, paused, archived)."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create a memory
            result = await memory_ops.create_memory(
                content="Memory for state management testing",
                importance=0.5,
                extract_entities=False,
            )
            assert result is not None
            memory_id = result.memory.id

            # Test state update to paused
            updated = await memory_ops.update_memory_state(memory_id, "paused")
            assert updated is not None
            # Note: Checking return type - this might be a dict or MemoryNode depending on implementation

            # Verify state was updated in database
            retrieved = await memory_ops.get_memory_by_id(memory_id)
            assert retrieved is not None
            # State should be stored in metadata or as a property

    @pytest.mark.asyncio
    async def test_memory_batch_operations(self) -> None:
        """Test batch operations for efficiency."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create multiple memories in sequence
            batch_data = SAMPLE_MEMORIES[:2]  # Use first 2 sample memories
            created_memories = []

            for memory_data in batch_data:
                result = await memory_ops.create_memory(
                    content=memory_data["content"],
                    importance=memory_data["importance"],
                    labels=memory_data["labels"],
                    metadata=memory_data["metadata"],
                    extract_entities=False,
                )
                assert result is not None
                created_memories.append(result.memory)

            # Verify all memories were created
            assert len(created_memories) == 2
            for memory in created_memories:
                TestAssertions.assert_memory_node_valid(memory)

            # Test batch retrieval
            all_memories = await memory_ops.list_memories(limit=10)
            assert len(all_memories) >= 2

    @pytest.mark.asyncio
    async def test_memory_validation_and_errors(self) -> None:
        """Test input validation and error handling based on actual MemoryNode constraints."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Test invalid importance score > 1.0 - should return None
            result = await memory_ops.create_memory(
                content="Test content",
                importance=1.5,  # Invalid - should be 0.0-1.0
                extract_entities=False,
            )
            assert result is None, "Should return None for importance > 1.0"

            # Test invalid importance score < 0.0 - should return None
            result = await memory_ops.create_memory(
                content="Test content",
                importance=-0.1,  # Invalid - should be 0.0-1.0
                extract_entities=False,
            )
            assert result is None, "Should return None for importance < 0.0"

            # Test invalid confidence score > 1.0 - should return None
            result = await memory_ops.create_memory(
                content="Test content",
                importance=0.5,
                confidence=1.5,  # Invalid - should be 0.0-1.0
                extract_entities=False,
            )
            assert result is None, "Should return None for confidence > 1.0"

            # Test content too long (> 5000 chars) - should return None
            very_long_content = "x" * 5001  # Exceeds max length
            result = await memory_ops.create_memory(
                content=very_long_content,
                importance=0.5,
                extract_entities=False,
            )
            assert result is None, "Should return None for content > 5000 characters"

            # Test that VALID cases work properly

            # Empty content is valid according to MemoryNode model
            result = await memory_ops.create_memory(
                content="",  # Empty content is actually valid!
                importance=0.5,
                extract_entities=False,
            )
            assert result is not None, "Empty content should be valid"
            if result is not None:  # Type guard for linter
                assert result.memory.content == ""

            # Boundary values should work
            result = await memory_ops.create_memory(
                content="Boundary test",
                importance=0.0,  # Minimum valid value
                confidence=1.0,  # Maximum valid value
                extract_entities=False,
            )
            assert result is not None, "Boundary values should be valid"
            if result is not None:  # Type guard for linter
                assert result.memory.importance == 0.0
                assert result.memory.confidence == 1.0

    @pytest.mark.asyncio
    async def test_memory_search_edge_cases(self) -> None:
        """Test search functionality with edge cases."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create a memory first
            result = await memory_ops.create_memory(
                content="Test memory for edge case searching",
                importance=0.5,
                extract_entities=False,
            )
            assert result is not None

            # Test search with empty query (should handle gracefully)
            try:
                empty_results = await memory_ops.search_memories(
                    query="",
                    limit=5,
                )
                # Should either return empty results or raise an appropriate error
                assert isinstance(empty_results, list)
            except (ValueError, AssertionError):
                # This is also acceptable behavior
                pass

            # Test search with very high similarity threshold
            strict_results = await memory_ops.search_memories(
                query="completely unrelated quantum physics content",
                limit=5,
            )
            assert isinstance(strict_results, list)
            # Should return few or no results

            # Test search with very low similarity threshold
            loose_results = await memory_ops.search_memories(
                query="test",
                limit=5,
            )
            assert isinstance(loose_results, list)

    @pytest.mark.asyncio
    async def test_memory_embeddings_and_vectors(self) -> None:
        """Test that embeddings are properly generated and stored."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            content = "This content should generate consistent embeddings"

            # Create memory
            result = await memory_ops.create_memory(
                content=content,
                importance=0.7,
                extract_entities=False,
            )

            assert result is not None
            # Verify embedding was generated
            memory = result.memory
            assert memory.embedding is not None
            assert isinstance(memory.embedding, list)
            assert len(memory.embedding) == 384  # Expected dimension

            # All embedding values should be floats
            for value in memory.embedding:
                assert isinstance(value, (int, float))

            # Test that similar content produces similar embeddings
            similar_content = "This content should also generate consistent embeddings"
            result2 = await memory_ops.create_memory(
                content=similar_content,
                importance=0.7,
                extract_entities=False,
            )

            assert result2 is not None
            # Both memories should have embeddings
            assert result2.memory.embedding is not None
            assert len(result2.memory.embedding) == 384

    @pytest.mark.asyncio
    async def test_memory_deletion(self) -> None:
        """Test memory deletion functionality."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create a memory
            result = await memory_ops.create_memory(
                content="Memory to be deleted",
                importance=0.5,
                extract_entities=False,
            )
            assert result is not None
            memory_id = result.memory.id

            # Verify memory exists
            retrieved = await memory_ops.get_memory_by_id(memory_id)
            assert retrieved is not None

            # Delete the memory
            deletion_result = await memory_ops.delete_memory(memory_id)

            # Verify deletion result (may fail gracefully if not fully implemented)
            assert isinstance(deletion_result, dict)
            assert deletion_result["memory_id"] == memory_id

            # Check if deletion succeeded or failed gracefully
            if deletion_result["deleted"]:
                # Deletion succeeded - verify memory no longer exists
                deleted_memory = await memory_ops.get_memory_by_id(memory_id)
                assert deleted_memory is None
            else:
                # Deletion failed gracefully (not fully implemented) - that's acceptable
                assert "error" in deletion_result
                assert isinstance(deletion_result["error"], str)

    @pytest.mark.asyncio
    async def test_memory_bulk_deletion(self) -> None:
        """Test bulk memory deletion functionality."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            created_ids = []
            for idx in range(2):
                result = await memory_ops.create_memory(
                    content=f"Bulk deletion memory {idx}",
                    importance=0.5,
                    extract_entities=False,
                )
                assert result is not None
                created_ids.append(result.memory.id)

            missing_id = "mem_nonexistent_for_bulk_delete"
            bulk_ids = [created_ids[0], created_ids[1], missing_id]
            deletion_result = await memory_ops.bulk_delete_memories(bulk_ids)

            assert isinstance(deletion_result, dict)
            assert deletion_result["requested_count"] == len(bulk_ids)
            assert deletion_result["processed_count"] == len(bulk_ids)
            assert deletion_result["deleted_count"] + deletion_result["failed_count"] == len(bulk_ids)

            result_by_id = {
                item["memory_id"]: item
                for item in deletion_result["results"]
            }
            for memory_id in created_ids:
                assert memory_id in result_by_id
                item = result_by_id[memory_id]
                assert isinstance(item.get("deleted"), bool)
                if item.get("deleted"):
                    deleted_memory = await memory_ops.get_memory_by_id(memory_id)
                    assert deleted_memory is None
                else:
                    assert isinstance(item.get("error"), str)

            assert missing_id in result_by_id
            missing_result = result_by_id[missing_id]
            assert missing_result.get("deleted") is False
            assert isinstance(missing_result.get("error"), str)

    @pytest.mark.asyncio
    async def test_memory_bulk_deletion_batched_maintenance(self, monkeypatch) -> None:
        """Bulk deletion should checkpoint in batches, not per-item."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            delete_calls = []
            maintenance_calls = []

            async def fake_delete_memory(
                *,
                memory_id: str,
                cascade_delete: bool = True,
                run_post_deletion_maintenance: bool = True,
            ):
                delete_calls.append(
                    {
                        "memory_id": memory_id,
                        "cascade_delete": cascade_delete,
                        "run_post_deletion_maintenance": run_post_deletion_maintenance,
                    }
                )
                return {
                    "memory_id": memory_id,
                    "deleted": True,
                    "deleted_relationships": 0,
                    "deleted_entities": 0,
                }

            async def fake_post_delete_maintenance(memory_id: str):
                maintenance_calls.append(memory_id)

            monkeypatch.setattr(memory_ops, "delete_memory", fake_delete_memory)
            monkeypatch.setattr(
                memory_ops,
                "_handle_post_deletion_maintenance",
                fake_post_delete_maintenance,
            )

            # 25 triggers an interval checkpoint, +1 triggers a final checkpoint.
            bulk_ids = [f"mem-{i}" for i in range(26)]
            result = await memory_ops.bulk_delete_memories(bulk_ids)

            assert len(delete_calls) == 26
            assert all(
                call["run_post_deletion_maintenance"] is False for call in delete_calls
            )
            assert maintenance_calls == [
                "bulk_delete:checkpoint",
                "bulk_delete:final",
            ]
            assert result["deleted_count"] == 26
            assert result["failed_count"] == 0
