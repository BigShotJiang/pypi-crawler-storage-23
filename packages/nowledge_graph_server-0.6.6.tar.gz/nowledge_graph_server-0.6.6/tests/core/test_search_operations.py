"""
Comprehensive test suite for SearchOperations core business logic.

This test module verifies all search-related operations work correctly,
including universal search, contextual search, semantic similarity,
and vector search capabilities using KuzuDB vector indexes.
"""

import pytest
from datetime import datetime, timezone
from typing import List, Dict, Any

from tests import test_core_services, SAMPLE_MEMORIES, SAMPLE_THREADS, TestAssertions
from src.nowledge_graph_server.models import MemorySearchResult, ThreadSearchResult
from src.nowledge_graph_server.core.search_operations import SearchOperations


class TestSearchOperations:
    """Comprehensive test suite for SearchOperations."""

    @pytest.mark.asyncio
    async def test_universal_search_basic(self) -> None:
        """Test basic universal search functionality across content types."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create test data
            memory_data = SAMPLE_MEMORIES[0]
            memory_result = await memory_ops.create_memory(
                content=memory_data["content"],
                importance=memory_data["importance"],
                labels=memory_data["labels"],
                metadata=memory_data["metadata"],
                extract_entities=False,
            )
            assert memory_result is not None

            thread_data = SAMPLE_THREADS[0]
            thread_result = await thread_ops.create_thread(
                thread_id=thread_data["thread_id"],
                messages=thread_data["messages"],
                title=thread_data["title"],
                source=thread_data["source"],
                auto_extract_memories=False,
            )
            assert thread_result is not None

            # Perform universal search
            search_results = await search_ops.universal_search(
                query="React performance optimization",
                limit=10,
                include_memories=True,
                include_threads=True,
                include_entities=False,
            )

            # Verify response structure
            assert isinstance(search_results, dict)
            assert "query" in search_results
            assert "memories" in search_results
            assert "threads" in search_results
            assert "entities" in search_results
            assert "total_found" in search_results
            assert "search_metadata" in search_results

            assert search_results["query"] == "React performance optimization"
            assert isinstance(search_results["memories"], list)
            assert isinstance(search_results["threads"], list)
            assert isinstance(search_results["entities"], list)
            assert search_results["total_found"] >= 0

            # Verify search metadata
            metadata = search_results["search_metadata"]
            assert "embedding_model" in metadata
            assert "filters_applied" in metadata

    @pytest.mark.asyncio
    async def test_universal_search_with_filters(self) -> None:
        """Test universal search with content type filters."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create test data
            for memory_data in SAMPLE_MEMORIES[:2]:
                result = await memory_ops.create_memory(
                    content=memory_data["content"],
                    importance=memory_data["importance"],
                    extract_entities=False,
                )
                assert result is not None

            # Search memories only
            memory_only_results = await search_ops.universal_search(
                query="Python programming",
                limit=5,
                include_memories=True,
                include_threads=False,
                include_entities=False,
            )

            assert len(memory_only_results["threads"]) == 0
            assert len(memory_only_results["entities"]) == 0
            assert memory_only_results["total_found"] == len(
                memory_only_results["memories"]
            )

            # Search threads only
            thread_only_results = await search_ops.universal_search(
                query="optimization",
                limit=5,
                include_memories=False,
                include_threads=True,
                include_entities=False,
            )

            assert len(thread_only_results["memories"]) == 0
            assert len(thread_only_results["entities"]) == 0
            assert thread_only_results["total_found"] == len(
                thread_only_results["threads"]
            )

    @pytest.mark.asyncio
    async def test_universal_search_empty_results(self) -> None:
        """Test universal search with no matching results."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Search for something that shouldn't match
            search_results = await search_ops.universal_search(
                query="completely unrelated quantum physics terminology",
                limit=10,
                include_memories=True,
                include_threads=True,
                include_entities=True,
            )

            assert isinstance(search_results, dict)
            assert search_results["total_found"] >= 0
            assert isinstance(search_results["memories"], list)
            assert isinstance(search_results["threads"], list)
            assert isinstance(search_results["entities"], list)

            # Structure should still be valid even with no results
            assert "search_metadata" in search_results

    @pytest.mark.asyncio
    async def test_search_with_context_semantic(self) -> None:
        """Test contextual search with semantic context expansion."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create related memories
            related_memories = [
                "React.memo optimizes component rendering performance",
                "useMemo and useCallback are React performance hooks",
                "React.lazy enables code splitting for performance",
            ]

            for content in related_memories:
                result = await memory_ops.create_memory(
                    content=content,
                    importance=0.7,
                    extract_entities=False,
                )
                assert result is not None

            # Perform contextual search
            context_results = await search_ops.search_with_context(
                query="React performance",
                context_type="semantic",
                limit=10,
                depth=2,
            )

            # Verify response structure
            assert isinstance(context_results, dict)
            assert "query" in context_results
            assert "primary_results" in context_results
            assert "contextual_results" in context_results
            assert "context_type" in context_results
            assert "depth" in context_results
            assert "total_found" in context_results

            assert context_results["query"] == "React performance"
            assert context_results["context_type"] == "semantic"
            assert context_results["depth"] == 2

            # Primary results should have search structure
            primary = context_results["primary_results"]
            assert isinstance(primary, dict)
            assert "memories" in primary
            assert "threads" in primary
            assert "entities" in primary

            # Contextual results should be a list
            contextual = context_results["contextual_results"]
            assert isinstance(contextual, list)

    @pytest.mark.asyncio
    async def test_search_with_context_related(self) -> None:
        """Test contextual search with related context type."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create test data
            memory_result = await memory_ops.create_memory(
                content="Graph databases provide powerful relationship queries",
                importance=0.8,
                extract_entities=False,
            )
            assert memory_result is not None

            # Test related context (may return empty if not implemented)
            context_results = await search_ops.search_with_context(
                query="database relationships",
                context_type="related",
                limit=8,
                depth=1,
            )

            assert isinstance(context_results, dict)
            assert context_results["context_type"] == "related"
            assert context_results["depth"] == 1
            assert "primary_results" in context_results
            assert "contextual_results" in context_results

    @pytest.mark.asyncio
    async def test_search_with_context_temporal(self) -> None:
        """Test contextual search with temporal context type."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create test data with temporal context
            thread_data = SAMPLE_THREADS[0]
            result = await thread_ops.create_thread(
                thread_id=thread_data["thread_id"],
                messages=thread_data["messages"],
                title=thread_data["title"],
                source=thread_data["source"],
                auto_extract_memories=False,
            )
            assert result is not None

            # Test temporal context (may return empty if not implemented)
            context_results = await search_ops.search_with_context(
                query="optimization discussion",
                context_type="temporal",
                limit=6,
                depth=1,
            )

            assert isinstance(context_results, dict)
            assert context_results["context_type"] == "temporal"
            assert "primary_results" in context_results
            assert "contextual_results" in context_results

    @pytest.mark.asyncio
    async def test_search_suggestions(self) -> None:
        """Test search query suggestions functionality."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Test basic suggestions
            suggestions = await search_ops.search_suggestions(
                partial_query="React",
                limit=5,
            )

            assert isinstance(suggestions, list)
            assert len(suggestions) <= 5
            for suggestion in suggestions:
                assert isinstance(suggestion, str)
                assert "React" in suggestion

            # Test with different partial query
            python_suggestions = await search_ops.search_suggestions(
                partial_query="Python",
                limit=3,
            )

            assert isinstance(python_suggestions, list)
            assert len(python_suggestions) <= 3
            for suggestion in python_suggestions:
                assert isinstance(suggestion, str)
                assert "Python" in suggestion

            # Test with empty partial query
            empty_suggestions = await search_ops.search_suggestions(
                partial_query="",
                limit=5,
            )

            assert isinstance(empty_suggestions, list)

    @pytest.mark.asyncio
    async def test_search_edge_cases(self) -> None:
        """Test search functionality with edge cases and error conditions."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Test empty query
            try:
                empty_results = await search_ops.universal_search(
                    query="",
                    limit=5,
                )
                # Should handle empty query gracefully
                assert isinstance(empty_results, dict)
            except (ValueError, AssertionError):
                # This is also acceptable behavior
                pass

            # Test very long query
            long_query = "test query " * 100
            long_results = await search_ops.universal_search(
                query=long_query,
                limit=5,
            )
            assert isinstance(long_results, dict)

            # Test very high similarity threshold
            strict_results = await search_ops.universal_search(
                query="test query",
                limit=5,
            )
            assert isinstance(strict_results, dict)
            # Should likely return no results due to high threshold

            # Test zero limit (should handle gracefully)
            try:
                zero_results = await search_ops.universal_search(
                    query="test",
                    limit=0,
                )
                assert isinstance(zero_results, dict)
            except (ValueError, AssertionError):
                # This is acceptable behavior
                pass

    @pytest.mark.asyncio
    async def test_vector_search_functionality(self) -> None:
        """Test vector search capabilities using embedding similarity."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create memories with known content for vector similarity testing
            vector_test_memories = [
                "Machine learning algorithms optimize data processing",
                "Deep learning neural networks learn complex patterns",
                "Natural language processing enables text understanding",
                "Computer vision analyzes images and visual data",
            ]

            created_memories = []
            for content in vector_test_memories:
                result = await memory_ops.create_memory(
                    content=content,
                    importance=0.8,
                    extract_entities=False,
                )
                assert result is not None
                created_memories.append(result.memory)

            # Test vector similarity search for ML content
            # Note: Offline embeddings have much lower similarity scores than real embeddings
            # So we use a very low threshold (0.01 = 1%) instead of 0.1 (10%)
            ml_search = await search_ops.universal_search(
                query="artificial intelligence machine learning",
                limit=10,
                include_memories=True,
                include_threads=False,
                include_entities=False,
            )

            # Verify we get vector-based similarity results
            assert len(ml_search["memories"]) > 0
            for memory_result in ml_search["memories"]:
                assert isinstance(memory_result, MemorySearchResult)
                assert 0.0 <= memory_result.similarity_score <= 1.0
                # Content should be one of our created memories
                assert any(memory_result.memory.id == m.id for m in created_memories)

            # Test vector search with different query to verify ranking
            cv_search = await search_ops.universal_search(
                query="computer vision image recognition",
                limit=10,
                include_memories=True,
                include_threads=False,
                include_entities=False,
            )

            # Should find results (though ranking may not be perfect with offline embeddings)
            if len(cv_search["memories"]) > 0:
                top_result = cv_search["memories"][0]
                # With offline embeddings, we just verify we get results
                # The semantic ranking won't be as good as with real embeddings
                assert isinstance(top_result, MemorySearchResult)
                assert top_result.similarity_score > 0.0

    @pytest.mark.asyncio
    async def test_search_results_validation(self) -> None:
        """Test that search results have proper structure and validation."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create test data
            memory_result = await memory_ops.create_memory(
                content="Test memory for search result validation",
                importance=0.5,
                extract_entities=False,
            )
            assert memory_result is not None

            thread_result = await thread_ops.create_thread(
                thread_id="validation_test_thread",
                messages=[{"content": "Test message for validation", "role": "user"}],
                title="Validation Test Thread",
                source="test",
                auto_extract_memories=False,
            )
            assert thread_result is not None

            # Perform search
            search_results = await search_ops.universal_search(
                query="validation test",
                limit=10,
                include_memories=True,
                include_threads=True,
                include_entities=False,
            )

            # Use test assertions to validate results
            TestAssertions.assert_search_results_valid(search_results, min_results=0)

            # Validate memory search results structure
            for memory_result in search_results["memories"]:
                assert isinstance(memory_result, MemorySearchResult)
                TestAssertions.assert_memory_node_valid(memory_result.memory)
                assert hasattr(memory_result, "similarity_score")
                assert 0.0 <= memory_result.similarity_score <= 1.0

            # Validate thread search results structure
            for thread_result_item in search_results["threads"]:
                assert isinstance(thread_result_item, ThreadSearchResult)
                TestAssertions.assert_thread_node_valid(thread_result_item.thread)
                assert hasattr(thread_result_item, "similarity_score")
                assert 0.0 <= thread_result_item.similarity_score <= 1.0

    @pytest.mark.asyncio
    async def test_search_performance_with_large_dataset(self) -> None:
        """Test search performance and behavior with larger dataset."""
        async with test_core_services() as services:
            db, embedding_service, memory_ops, thread_ops, search_ops = services

            # Create a larger dataset for performance testing
            import asyncio

            # Create multiple memories
            memory_tasks = []
            for i in range(10):
                content = f"Performance test memory {i} with various content about technology, programming, and optimization"
                task = memory_ops.create_memory(
                    content=content,
                    importance=0.5 + (i * 0.05),  # Varying importance
                    extract_entities=False,
                )
                memory_tasks.append(task)

            # Create memories concurrently
            memory_results = await asyncio.gather(*memory_tasks)
            created_count = sum(1 for r in memory_results if r is not None)
            assert created_count >= 5  # At least half should succeed

            # Test search performance with pagination
            start_time = datetime.now()

            search_results = await search_ops.universal_search(
                query="performance optimization technology",
                limit=50,  # Large limit
                include_memories=True,
                include_threads=True,
                include_entities=False,
            )

            end_time = datetime.now()
            search_duration = (end_time - start_time).total_seconds()

            # Search should complete in reasonable time (less than 30 seconds)
            assert search_duration < 30.0

            # Should return structured results
            assert isinstance(search_results, dict)
            assert search_results["total_found"] >= 0

            # Test that similarity scores are properly ranked (descending)
            memory_results = search_results["memories"]
            if len(memory_results) > 1:
                for i in range(len(memory_results) - 1):
                    current_score = memory_results[i].similarity_score
                    next_score = memory_results[i + 1].similarity_score
                    assert current_score >= next_score, (
                        "Results should be ranked by similarity score"
                    )
