"""Core operations test module."""
