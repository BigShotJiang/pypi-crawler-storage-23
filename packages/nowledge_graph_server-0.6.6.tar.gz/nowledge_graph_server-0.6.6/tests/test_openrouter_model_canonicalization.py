from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nowledge_graph_server.api.routers.remote_llm import (  # noqa: E402
    _canonicalize_openrouter_model_id,
)


def test_canonicalize_openrouter_model_preserves_prefixed_when_catalog_empty():
    model_id = "openrouter/minimax/minimax-m2.5"
    assert _canonicalize_openrouter_model_id(model_id, []) == model_id


def test_canonicalize_openrouter_model_uses_unique_suffix_match():
    model_id = "minimax-m2.5"
    catalog = [{"id": "minimax/minimax-m2.5"}, {"id": "openai/gpt-4o-mini"}]
    assert (
        _canonicalize_openrouter_model_id(model_id, catalog)
        == "minimax/minimax-m2.5"
    )


def test_canonicalize_openrouter_model_preserves_prefixed_when_unresolved():
    model_id = "openrouter/minimax/minimax-m2.5"
    catalog = [{"id": "openai/gpt-4o-mini"}]
    assert _canonicalize_openrouter_model_id(model_id, catalog) == model_id
