"""Tests for the lightweight Obsidian vault implementation.

Tests the pure-Python vault parser that replaces obsidiantools.
"""

import tempfile
from pathlib import Path

import pytest

from nowledge_graph_server.mcp.tools.obsidian_vault import (
    CODE_BLOCK_REGEX,
    FRONT_MATTER_REGEX,
    TAG_REGEX,
    WIKILINK_REGEX,
    ObsidianVault,
    extract_embedded_files,
    extract_tags,
    extract_wikilinks,
    get_readable_text,
    get_real_icloud_path,
    is_file_available,
    is_icloud_placeholder,
    parse_front_matter,
    remove_code_blocks,
    safe_read_text,
)


# ============================================================================
# Test Fixtures
# ============================================================================


@pytest.fixture
def sample_vault(tmp_path: Path) -> Path:
    """Create a sample vault with test notes."""
    vault = tmp_path / "test-vault"
    vault.mkdir()
    
    # Create a simple note
    (vault / "Simple Note.md").write_text("""# Simple Note

This is a simple test note with some content.

#simple #test
""")
    
    # Create a note with front matter
    (vault / "With Frontmatter.md").write_text("""---
title: Test Note
tags: [meta-tag, another-tag]
date: 2024-01-15
draft: false
---

# Note with Front Matter

This note has YAML front matter.
""")
    
    # Create a note with links
    (vault / "With Links.md").write_text("""# Note with Links

This note links to [[Simple Note]] and [[With Frontmatter|FM Note]].

It also has a [[Non Existent Note]] link.

Embedded image: ![[image.png]]
Embedded file: ![[attachment.pdf]]

And a [[Simple Note#Header]] link with header.
""")
    
    # Create a note with code blocks
    (vault / "Code Examples.md").write_text("""# Code Examples

Here's some Python code:

```python
# This is a code block
wikilink = "[[Not A Link]]"
tag = "#not-a-tag"
```

And inline code: `[[also not a link]]`

But this is a real link: [[Simple Note]]
And a real tag: #coding

```
More code
#not-a-tag-either
```
""")
    
    # Create a subdirectory with notes
    subdir = vault / "projects"
    subdir.mkdir()
    (subdir / "Project Alpha.md").write_text("""---
project: alpha
status: active
---

# Project Alpha

This is a project note. #project #active

Links to [[Simple Note]] and [[../With Links]].
""")
    
    # Create note with same name in different directory (for duplicate testing)
    another_subdir = vault / "archive"
    another_subdir.mkdir()
    (another_subdir / "Simple Note.md").write_text("""# Archived Simple Note

This is a different note with the same name.
""")
    
    return vault


@pytest.fixture
def complex_frontmatter_note() -> str:
    """Return content with complex front matter."""
    return """---
title: "Complex Note"
tags: [tag1, tag2, tag3]
aliases:
  - "alias1"
  - "alias2"
count: 42
ratio: 3.14
enabled: true
disabled: false
empty_string: ""
---

# Complex Note Content
"""


# ============================================================================
# Test Regex Patterns
# ============================================================================


class TestWikilinkRegex:
    """Tests for wikilink regex pattern."""
    
    def test_simple_wikilink(self):
        matches = WIKILINK_REGEX.findall("[[Simple Link]]")
        assert len(matches) == 1
        assert matches[0] == ('', 'Simple Link')
    
    def test_wikilink_with_alias(self):
        matches = WIKILINK_REGEX.findall("[[Note Name|Display Text]]")
        assert len(matches) == 1
        assert matches[0] == ('', 'Note Name|Display Text')
    
    def test_embedded_file(self):
        matches = WIKILINK_REGEX.findall("![[image.png]]")
        assert len(matches) == 1
        assert matches[0] == ('!', 'image.png')
    
    def test_multiple_links(self):
        text = "See [[Note A]] and [[Note B|B]] plus ![[embed.png]]"
        matches = WIKILINK_REGEX.findall(text)
        assert len(matches) == 3
    
    def test_link_with_header(self):
        matches = WIKILINK_REGEX.findall("[[Note#Header Section]]")
        assert len(matches) == 1
        assert matches[0][1] == 'Note#Header Section'


class TestTagRegex:
    """Tests for tag regex pattern."""
    
    def test_simple_tag(self):
        matches = TAG_REGEX.findall("This has a #simple tag")
        assert 'simple' in matches
    
    def test_nested_tag(self):
        matches = TAG_REGEX.findall("A #project/work/urgent tag")
        assert 'project/work/urgent' in matches
    
    def test_tag_with_numbers(self):
        matches = TAG_REGEX.findall("#tag123 and #123tag")
        assert 'tag123' in matches
        # #123tag should not match (starts with number)
    
    def test_escaped_tag(self):
        matches = TAG_REGEX.findall("Not a \\#escaped tag")
        assert 'escaped' not in matches


class TestCodeBlockRegex:
    """Tests for code block regex pattern."""
    
    def test_fenced_code_block(self):
        text = """Before
```python
code inside
```
After"""
        result = CODE_BLOCK_REGEX.sub('', text)
        assert 'code inside' not in result
        assert 'Before' in result
        assert 'After' in result
    
    def test_tilde_code_block(self):
        text = """Before
~~~
code inside
~~~
After"""
        result = CODE_BLOCK_REGEX.sub('', text)
        assert 'code inside' not in result


# ============================================================================
# Test Parsing Functions
# ============================================================================


class TestParseFrontMatter:
    """Tests for front matter parsing."""
    
    def test_simple_front_matter(self):
        content = """---
title: Test
---

Body content"""
        front_matter, body = parse_front_matter(content)
        assert front_matter.get('title') == 'Test'
        assert 'Body content' in body
    
    def test_no_front_matter(self):
        content = "Just regular content"
        front_matter, body = parse_front_matter(content)
        assert front_matter == {}
        assert body == content
    
    def test_list_in_front_matter(self):
        content = """---
tags: [a, b, c]
---

Content"""
        front_matter, body = parse_front_matter(content)
        assert front_matter.get('tags') == ['a', 'b', 'c']
    
    def test_boolean_values(self):
        content = """---
enabled: true
disabled: false
---

Content"""
        front_matter, body = parse_front_matter(content)
        assert front_matter.get('enabled') is True
        assert front_matter.get('disabled') is False
    
    def test_numeric_values(self):
        content = """---
count: 42
ratio: 3.14
---

Content"""
        front_matter, body = parse_front_matter(content)
        assert front_matter.get('count') == 42
        assert front_matter.get('ratio') == 3.14


class TestExtractWikilinks:
    """Tests for wikilink extraction."""
    
    def test_extract_simple_links(self):
        content = "Link to [[Note A]] and [[Note B]]"
        links = extract_wikilinks(content)
        assert 'Note A' in links
        assert 'Note B' in links
    
    def test_remove_aliases(self):
        content = "[[Note|Alias]]"
        links = extract_wikilinks(content, remove_aliases=True)
        assert links == ['Note']
    
    def test_remove_headers(self):
        content = "[[Note#Section]]"
        links = extract_wikilinks(content)
        assert links == ['Note']
    
    def test_skip_embeds(self):
        content = "[[Link]] and ![[Embed]]"
        links = extract_wikilinks(content)
        assert 'Link' in links
        assert 'Embed' not in links
    
    def test_skip_code_blocks(self):
        content = """[[Real Link]]
```
[[Not A Link]]
```"""
        links = extract_wikilinks(content)
        assert 'Real Link' in links
        assert 'Not A Link' not in links
    
    def test_skip_same_file_header_links(self):
        """Same-file header links like [[#Header]] should be skipped."""
        content = "See [[#Section]] and [[Note#Section]]"
        links = extract_wikilinks(content)
        assert 'Note' in links
        assert '' not in links
        assert len(links) == 1
    
    def test_handle_escaped_pipes_in_tables(self):
        r"""Escaped pipes in tables like [[Note\|alias]] should work."""
        content = r"| [[Note\|alias]] | description |"
        links = extract_wikilinks(content)
        assert 'Note' in links
        assert '\\' not in links[0]


class TestExtractTags:
    """Tests for tag extraction."""
    
    def test_extract_simple_tags(self):
        content = "Note with #tag1 and #tag2"
        tags = extract_tags(content)
        assert 'tag1' in tags
        assert 'tag2' in tags
    
    def test_nested_tags_included(self):
        content = "#parent/child/grandchild"
        tags = extract_tags(content, show_nested=True)
        assert 'parent/child/grandchild' in tags
    
    def test_nested_tags_top_only(self):
        content = "#parent/child"
        tags = extract_tags(content, show_nested=False)
        assert 'parent' in tags
        assert 'parent/child' not in tags
    
    def test_skip_code_blocks(self):
        content = """#real-tag
```
#not-a-tag
```"""
        tags = extract_tags(content)
        assert 'real-tag' in tags
        assert 'not-a-tag' not in tags
    
    def test_no_duplicates(self):
        content = "#tag #tag #tag"
        tags = extract_tags(content)
        assert len(tags) == 1
    
    def test_unicode_tags(self):
        """Tags should support Unicode characters."""
        content = "#english #中文 #日本語 #한국어 #русский"
        tags = extract_tags(content)
        assert 'english' in tags
        assert '中文' in tags
        assert '日本語' in tags
        assert '한국어' in tags
        assert 'русский' in tags
    
    def test_skip_wikilink_headers(self):
        """Tags inside wikilinks like [[#header]] should be skipped."""
        content = "See [[#Header]] for details #realtag"
        tags = extract_tags(content)
        assert 'realtag' in tags
        assert 'Header' not in tags
    
    def test_tags_with_dashes(self):
        """Tags can contain dashes."""
        content = "#my-tag-with-dashes"
        tags = extract_tags(content)
        assert 'my-tag-with-dashes' in tags


class TestExtractEmbeddedFiles:
    """Tests for embedded file extraction."""
    
    def test_extract_images(self):
        content = "![[image.png]] and ![[photo.jpg]]"
        embeds = extract_embedded_files(content)
        assert 'image.png' in embeds
        assert 'photo.jpg' in embeds
    
    def test_skip_wikilinks(self):
        content = "[[Link]] and ![[Embed]]"
        embeds = extract_embedded_files(content)
        assert 'Embed' in embeds
        assert 'Link' not in embeds


class TestGetReadableText:
    """Tests for readable text conversion."""
    
    def test_removes_front_matter(self):
        content = """---
title: Test
---

Body"""
        readable = get_readable_text(content)
        assert 'title:' not in readable
        assert 'Body' in readable
    
    def test_removes_wikilink_syntax(self):
        content = "See [[Note Name]]"
        readable = get_readable_text(content)
        assert '[[' not in readable
        assert ']]' not in readable
        assert 'Note Name' in readable
    
    def test_uses_alias_text(self):
        content = "See [[Note|Display Text]]"
        readable = get_readable_text(content)
        assert 'Display Text' in readable
    
    def test_removes_markdown_formatting(self):
        content = "**bold** and *italic* and ~~strikethrough~~"
        readable = get_readable_text(content)
        assert '**' not in readable
        assert '*' not in readable
        assert '~~' not in readable
        assert 'bold' in readable


# ============================================================================
# Test iCloud Compatibility
# ============================================================================


class TestICloudCompatibility:
    """Tests for iCloud file handling."""
    
    def test_is_icloud_placeholder(self):
        assert is_icloud_placeholder(Path(".note.md.icloud"))
        assert not is_icloud_placeholder(Path("note.md"))
        assert not is_icloud_placeholder(Path(".hidden"))
    
    def test_get_real_icloud_path(self):
        placeholder = Path("/vault/.note.md.icloud")
        real_path = get_real_icloud_path(placeholder)
        assert real_path.name == "note.md"
    
    def test_is_file_available(self, tmp_path: Path):
        # Existing file
        existing = tmp_path / "exists.md"
        existing.write_text("content")
        assert is_file_available(existing)
        
        # Non-existing file
        assert not is_file_available(tmp_path / "not-exists.md")
    
    def test_safe_read_text_success(self, tmp_path: Path):
        test_file = tmp_path / "test.md"
        test_file.write_text("Hello World")
        content = safe_read_text(test_file)
        assert content == "Hello World"
    
    def test_safe_read_text_missing(self, tmp_path: Path):
        content = safe_read_text(tmp_path / "missing.md")
        assert content is None


# ============================================================================
# Test ObsidianVault Class
# ============================================================================


class TestObsidianVault:
    """Tests for the ObsidianVault class."""
    
    def test_init_scans_files(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault)
        assert len(vault.md_file_index) > 0
        assert 'With Links' in vault.md_file_index
    
    def test_handles_duplicate_names(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault)
        # Should have both "Simple Note" files, with one having full path
        names = list(vault.md_file_index.keys())
        simple_notes = [n for n in names if 'Simple Note' in n]
        assert len(simple_notes) == 2
    
    def test_connect_parses_metadata(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault)
        vault.connect()
        
        assert vault.is_connected
        assert 'With Links' in vault.tags_index
        assert 'With Links' in vault.wikilinks_index
    
    def test_connect_extracts_wikilinks(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        links = vault.get_wikilinks('With Links')
        assert 'Simple Note' in links
        assert 'With Frontmatter' in links
        assert 'Non Existent Note' in links
    
    def test_connect_builds_backlinks(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        # Simple Note should have backlinks from other notes
        backlinks = vault.get_backlinks('Simple Note')
        assert len(backlinks) > 0
    
    def test_connect_extracts_tags(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        tags = vault.get_tags('Simple Note')
        assert 'simple' in tags
        assert 'test' in tags
    
    def test_connect_extracts_embedded_files(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        embeds = vault.get_embedded_files('With Links')
        assert 'image.png' in embeds
        assert 'attachment.pdf' in embeds
    
    def test_connect_parses_front_matter(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        fm = vault.get_front_matter('With Frontmatter')
        assert fm.get('title') == 'Test Note'
    
    def test_gather_loads_content(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect().gather()
        
        assert vault.is_gathered
        source = vault.get_source_text('Simple Note')
        assert 'simple test note' in source
    
    def test_get_readable_text(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect().gather()
        
        readable = vault.get_readable_text('With Links')
        # Should not contain wikilink syntax
        assert '[[' not in readable
        assert ']]' not in readable
    
    def test_nonexistent_notes(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        nonexistent = vault.nonexistent_notes
        assert 'Non Existent Note' in nonexistent
    
    def test_isolated_notes(self, sample_vault: Path):
        # Add a truly isolated note for testing
        (sample_vault / "Truly Isolated.md").write_text("# Isolated\n\nNo links here.")
        
        vault = ObsidianVault(sample_vault).connect()
        
        isolated = vault.isolated_notes
        # Truly Isolated has no links and no backlinks
        assert isinstance(isolated, list)
        assert "Truly Isolated" in isolated
    
    def test_fluent_api(self, sample_vault: Path):
        # Should support chaining
        vault = ObsidianVault(sample_vault).connect().gather()
        assert vault.is_connected
        assert vault.is_gathered
    
    def test_skips_code_in_wikilinks(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        links = vault.get_wikilinks('Code Examples')
        assert 'Simple Note' in links
        assert 'Not A Link' not in links
    
    def test_skips_code_in_tags(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        tags = vault.get_tags('Code Examples')
        assert 'coding' in tags
        assert 'not-a-tag' not in tags
    
    def test_skips_hidden_directories(self, sample_vault: Path):
        # Create .obsidian directory with a note (should be skipped)
        obsidian_dir = sample_vault / ".obsidian"
        obsidian_dir.mkdir()
        (obsidian_dir / "config.md").write_text("# Config\nShould be skipped")
        
        vault = ObsidianVault(sample_vault)
        assert 'config' not in vault.md_file_index
    
    def test_error_on_get_before_connect(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault)
        
        with pytest.raises(AttributeError):
            vault.get_wikilinks('Simple Note')
    
    def test_error_on_get_text_before_gather(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        with pytest.raises(AttributeError):
            vault.get_source_text('Simple Note')
    
    def test_error_on_nonexistent_note(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault).connect()
        
        with pytest.raises(ValueError):
            vault.get_wikilinks('Does Not Exist')


class TestVaultSubdirectoryFiltering:
    """Tests for subdirectory filtering."""
    
    def test_include_subdirs_filter(self, sample_vault: Path):
        vault = ObsidianVault(
            sample_vault,
            include_subdirs=['projects'],
            include_root=False
        )
        
        # Should only have notes from projects/
        for name in vault.md_file_index:
            path = vault.md_file_index[name]
            assert 'projects' in str(path)
    
    def test_include_root_false(self, sample_vault: Path):
        vault = ObsidianVault(sample_vault, include_root=False)
        
        # Root-level notes should be excluded
        # But subdirectory notes should be included
        has_subdir_notes = any(
            len(Path(str(p)).parts) > 1 
            for p in vault.md_file_index.values()
        )
        assert has_subdir_notes


# ============================================================================
# Integration Tests
# ============================================================================


class TestVaultIntegration:
    """Integration tests for the vault."""
    
    def test_full_workflow(self, sample_vault: Path):
        """Test a complete vault usage workflow."""
        # Initialize
        vault = ObsidianVault(sample_vault)
        assert len(vault.md_file_index) > 0
        
        # Connect
        vault.connect(show_nested_tags=True)
        assert vault.is_connected
        
        # Access metadata
        for note_name in vault.md_file_index:
            tags = vault.tags_index.get(note_name, [])
            links = vault.wikilinks_index.get(note_name, [])
            backlinks = vault.backlinks_index.get(note_name, [])
            fm = vault.front_matter_index.get(note_name, {})
            
            assert isinstance(tags, list)
            assert isinstance(links, list)
            assert isinstance(backlinks, list)
            assert isinstance(fm, dict)
        
        # Gather content
        vault.gather()
        assert vault.is_gathered
        
        # Access content
        for note_name in vault.md_file_index:
            source = vault.source_text_index.get(note_name, "")
            readable = vault.readable_text_index.get(note_name, "")
            
            assert isinstance(source, str)
            assert isinstance(readable, str)
    
    def test_lowercase_index_optimization(self, sample_vault: Path):
        """Test the pre-computed lowercase index for fast search."""
        vault = ObsidianVault(sample_vault).connect().gather()
        
        # Access lowercase index
        lower_index = vault.readable_text_lower_index
        
        assert len(lower_index) == len(vault.readable_text_index)
        
        # Verify all values are lowercase
        for name, text in lower_index.items():
            assert text == text.lower(), f"Text not lowercase for {name}"
        
        # Verify caching (same object returned)
        lower_index2 = vault.readable_text_lower_index
        assert lower_index is lower_index2, "Should return cached index"
    
    def test_empty_vault(self, tmp_path: Path):
        """Test handling of empty vault."""
        empty_vault = tmp_path / "empty-vault"
        empty_vault.mkdir()
        
        vault = ObsidianVault(empty_vault).connect().gather()
        
        assert len(vault.md_file_index) == 0
        assert vault.is_connected
        assert vault.is_gathered
    
    def test_nonexistent_vault_path(self, tmp_path: Path):
        """Test handling of nonexistent vault path."""
        vault = ObsidianVault(tmp_path / "does-not-exist")
        
        # Should not crash, just have empty index
        assert len(vault.md_file_index) == 0
