import real_ladybug as kuzu

db = kuzu.Database("nowledge-graph-py/data/nowledge_graph.db")
conn = kuzu.Connection(db)
from sentence_transformers import SentenceTransformer

conn.execute("INSTALL VECTOR; LOAD EXTENSION VECTOR;")

embedding_model = "multi-qa-MiniLM-L6-cos-v1"
embedding_dimension = 384

"""
// Doc
CALL CREATE_VECTOR_INDEX(
    'table_name',      // Name of the table containing the vector column
    'index_name',      // Name to identify the vector index
    'column_name',     // Name of the column containing vector embeddings
    [option_name := option_value]  // Optional parameters for index configuration
);

// Syntax for querying the index
CALL QUERY_VECTOR_INDEX(
    'table_name',      // Name of the table
    'index_name',      // Name of the vector index
    query_vector,      // Vector to search for
    k,                 // Number of nearest neighbors to return
    [option_name := option_value]  // Optional parameters
) RETURN node.id ORDER BY distance;
"""
query = "What is the capital of France?"
model = SentenceTransformer(embedding_model)
query_vector = model.encode(query).tolist()


result = conn.execute(
    """
    CALL QUERY_VECTOR_INDEX(
        'Memory',
        'memory_embedding_idx_new',
        $query_vector,
        2
    )
    RETURN node.content, node.summary, distance ORDER BY distance;
    """,
    {"query_vector": query_vector},
)
print(result.get_as_pl())  # type: ignore

# good!
# shape: (1, 2)
# ┌─────────────────────────────────┬─────────────────────────────────┐
# │ node.content                    ┆ node.summary                    │
# │ ---                             ┆ ---                             │
# │ str                             ┆ str                             │
# ╞═════════════════════════════════╪═════════════════════════════════╡
# │ Install mlx-embeddings, load B… ┆ Install mlx-embeddings, load B… │
# └─────────────────────────────────┴─────────────────────────────────┘

result = conn.execute(
    """
CALL SHOW_INDEXES() RETURN *;

"""
)

# print(result.get_as_pl())

# good!
# shape: (2, 6)
# ┌────────────┬────────────────────────┬────────────┬────────────────────────┬──────────────────┬─────────────────────────────────┐
# │ table_name ┆ index_name             ┆ index_type ┆ property_names         ┆ extension_loaded ┆ index_definition                │
# │ ---        ┆ ---                    ┆ ---        ┆ ---                    ┆ ---              ┆ ---                             │
# │ str        ┆ str                    ┆ str        ┆ list[str]              ┆ bool             ┆ str                             │
# ╞════════════╪════════════════════════╪════════════╪════════════════════════╪══════════════════╪═════════════════════════════════╡
# │ Memory     ┆ memory_content_index   ┆ FTS        ┆ ["content", "summary"] ┆ false            ┆                                 │
# │ Memory     ┆ memory_embedding_index ┆ HNSW       ┆ ["embedding"]          ┆ true             ┆ CALL CREATE_VECTOR_INDEX('Memo… │
# └────────────┴────────────────────────┴────────────┴────────────────────────┴──────────────────┴─────────────────────────────────┘
