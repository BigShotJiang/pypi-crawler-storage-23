"""Unit tests for FTS tokenizers and query sanitization.

These tests verify the sanitize_fts_query function strips non-word
characters to prevent Tantivy FTS query syntax errors, and the
escape_cypher_regex function escapes for safe use in Cypher regex patterns.
"""

import re

import pytest


def _sanitize_fts_query(query: str) -> str:
    """Local copy of sanitize_fts_query for isolated testing.

    This avoids importing the full module which has heavy dependencies.
    The actual implementation is in:
    src/nowledge_graph_server/services/search_index/tokenizers.py
    """
    if not query:
        return query

    # Replace any non-word, non-whitespace character with a space
    result = re.sub(r'[^\w\s]', ' ', query, flags=re.UNICODE)

    # Collapse runs of whitespace into a single space
    result = re.sub(r'\s+', ' ', result)

    return result.strip()


class TestSanitizeFtsQuery:
    """Tests for sanitize_fts_query - allowlist approach strips non-word chars."""

    def test_special_chars_stripped(self) -> None:
        """Test that Tantivy special characters are stripped."""
        assert _sanitize_fts_query("test{") == "test"
        assert _sanitize_fts_query("{test}") == "test"
        assert _sanitize_fts_query("func() { return }") == "func return"
        assert _sanitize_fts_query("array[0]") == "array 0"
        assert _sanitize_fts_query("(a OR b)") == "a OR b"

    def test_operators_stripped(self) -> None:
        """Test that boolean/boost/fuzzy operators are stripped."""
        assert _sanitize_fts_query("a + b") == "a b"
        assert _sanitize_fts_query("a - b") == "a b"
        assert _sanitize_fts_query("!important") == "important"
        assert _sanitize_fts_query("term^2") == "term 2"
        assert _sanitize_fts_query("term~2") == "term 2"

    def test_wildcards_stripped(self) -> None:
        """Test that wildcards are stripped."""
        assert _sanitize_fts_query("test*") == "test"
        assert _sanitize_fts_query("te?t") == "te t"

    def test_quotes_stripped(self) -> None:
        """Test that quotes are stripped."""
        assert _sanitize_fts_query('"exact phrase"') == "exact phrase"
        assert _sanitize_fts_query("it's") == "it s"

    def test_separators_stripped(self) -> None:
        """Test that colons, slashes, etc. are stripped."""
        assert _sanitize_fts_query("field:value") == "field value"
        assert _sanitize_fts_query("path/to/file") == "path to file"

    def test_plain_text_unchanged(self) -> None:
        """Test that plain alphanumeric text is unchanged."""
        assert _sanitize_fts_query("hello world") == "hello world"
        assert _sanitize_fts_query("Python123") == "Python123"
        assert _sanitize_fts_query("") == ""

    def test_underscores_preserved(self) -> None:
        """Test that underscores are preserved (part of \\w)."""
        assert _sanitize_fts_query("snake_case") == "snake_case"
        assert _sanitize_fts_query("__init__") == "__init__"

    def test_none_handling(self) -> None:
        """Test handling of None/empty input."""
        assert _sanitize_fts_query("") == ""
        assert _sanitize_fts_query(None) is None  # type: ignore

    def test_whitespace_collapsed(self) -> None:
        """Test that multiple spaces/stripped chars collapse to single space."""
        assert _sanitize_fts_query("a    b") == "a b"
        assert _sanitize_fts_query("a---b") == "a b"
        assert _sanitize_fts_query("  hello  ") == "hello"

    def test_cjk_characters_preserved(self) -> None:
        """Test that CJK characters pass through (they're \\w in Unicode)."""
        assert _sanitize_fts_query("机器学习") == "机器学习"
        assert _sanitize_fts_query("テスト") == "テスト"
        assert _sanitize_fts_query("테스트") == "테스트"

    def test_real_world_failures(self) -> None:
        """Test inputs that previously caused Tantivy syntax errors."""
        # Pinyin with apostrophes: hui'gu'de -> hui gu de
        assert _sanitize_fts_query("hui'gu'de") == "hui gu de"
        assert _sanitize_fts_query("昨天有啥值得hui'gu'de") == "昨天有啥值得hui gu de"

        # Markdown backticks: `SearchOperations` -> SearchOperations
        assert _sanitize_fts_query("`SearchOperations`") == "SearchOperations"
        assert _sanitize_fts_query("i found we used to have `SearchOperations`") == "i found we used to have SearchOperations"

        # JSON-like content
        assert _sanitize_fts_query('{"key": "value"}') == "key value"

        # Code snippets
        assert _sanitize_fts_query("func() {}") == "func"

        # URLs
        assert _sanitize_fts_query("https://example.com/path?q=1") == "https example com path q 1"


def _escape_cypher_regex(value: str) -> str:
    """Local copy of escape_cypher_regex for isolated testing.

    This avoids importing the full module which has heavy dependencies.
    The actual implementation is in:
    src/nowledge_graph_server/database/utils.py
    """
    if not value:
        return value

    # First, escape backslashes (special case: need 4 backslashes in Cypher string)
    result = value.replace('\\', '\\\\\\\\')

    # Then escape other regex metacharacters
    other_metacharacters = ['^', '$', '.', '|', '?', '*', '+', '(', ')', '[', ']', '{', '}']
    for char in other_metacharacters:
        result = result.replace(char, f'\\\\{char}')

    # Escape single quotes - not a regex metacharacter, but terminates
    # Cypher single-quoted string literals. Only needs single-level escaping.
    # Common in pinyin input like "hui'gu'de" for 回顾的.
    result = result.replace("'", "\\'")

    return result


class TestEscapeCypherRegex:
    """Tests for escape_cypher_regex function - escaping for Cypher regex patterns."""

    def test_curly_braces_escaped(self) -> None:
        """Test that curly braces are properly escaped for Cypher regex."""
        # In Cypher string, \\ becomes a single backslash in the regex
        assert _escape_cypher_regex("test{") == "test\\\\{"
        assert _escape_cypher_regex("test}") == "test\\\\}"
        assert _escape_cypher_regex("{test}") == "\\\\{test\\\\}"

    def test_square_brackets_escaped(self) -> None:
        """Test that square brackets are properly escaped."""
        assert _escape_cypher_regex("array[0]") == "array\\\\[0\\\\]"

    def test_parentheses_escaped(self) -> None:
        """Test that parentheses are properly escaped."""
        assert _escape_cypher_regex("func()") == "func\\\\(\\\\)"

    def test_dot_escaped(self) -> None:
        """Test that dots are properly escaped (regex wildcard)."""
        assert _escape_cypher_regex("Node.js") == "Node\\\\.js"
        assert _escape_cypher_regex("test.py") == "test\\\\.py"

    def test_pipe_escaped(self) -> None:
        """Test that pipe (OR operator) is properly escaped."""
        assert _escape_cypher_regex("a|b") == "a\\\\|b"

    def test_wildcards_escaped(self) -> None:
        """Test that wildcards are properly escaped."""
        assert _escape_cypher_regex("test*") == "test\\\\*"
        assert _escape_cypher_regex("te?t") == "te\\\\?t"
        assert _escape_cypher_regex("foo+bar") == "foo\\\\+bar"

    def test_anchors_escaped(self) -> None:
        """Test that anchors are properly escaped."""
        assert _escape_cypher_regex("^start") == "\\\\^start"
        assert _escape_cypher_regex("end$") == "end\\\\$"

    def test_backslash_escaped(self) -> None:
        """Test that backslashes are escaped first (order matters)."""
        # Single backslash becomes quadruple (escaped twice for Cypher + regex)
        assert _escape_cypher_regex("a\\b") == "a\\\\\\\\b"

    def test_plain_text_unchanged(self) -> None:
        """Test that plain alphanumeric text is unchanged."""
        assert _escape_cypher_regex("hello world") == "hello world"
        assert _escape_cypher_regex("Python123") == "Python123"
        assert _escape_cypher_regex("") == ""

    def test_none_handling(self) -> None:
        """Test handling of None input."""
        assert _escape_cypher_regex("") == ""
        assert _escape_cypher_regex(None) is None  # type: ignore

    def test_apostrophe_escaped(self) -> None:
        """Test that apostrophes are escaped for Cypher string literals.

        Apostrophes terminate single-quoted Cypher strings.
        Common in pinyin input like "hui'gu'de" for 回顾的.
        """
        assert _escape_cypher_regex("hui'gu'de") == "hui\\'gu\\'de"
        assert _escape_cypher_regex("it's") == "it\\'s"
        assert _escape_cypher_regex("'quoted'") == "\\'quoted\\'"

    def test_real_world_examples(self) -> None:
        """Test real-world label examples that caused issues."""
        # The original issue: curly brace in query
        assert _escape_cypher_regex("test{") == "test\\\\{"

        # Programming languages with special chars
        assert _escape_cypher_regex("C++") == "C\\\\+\\\\+"
        assert _escape_cypher_regex("C#") == "C#"  # # is not a regex metachar
        assert _escape_cypher_regex("Node.js") == "Node\\\\.js"

        # Code patterns
        assert _escape_cypher_regex("func() {}") == "func\\\\(\\\\) \\\\{\\\\}"

        # Pinyin input with apostrophes (caused Cypher parse error)
        assert _escape_cypher_regex("昨天有啥值得hui'gu'de") == "昨天有啥值得hui\\'gu\\'de"
