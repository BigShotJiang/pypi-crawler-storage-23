import time

import pytest

from nowledge_graph_server.services import model_verification as mv


@pytest.fixture(autouse=True)
def reset_verification_cache():
    mv._FULL_VERIFY_CACHE.clear()
    mv._FULL_VERIFY_CACHE_TS.clear()
    yield
    mv._FULL_VERIFY_CACHE.clear()
    mv._FULL_VERIFY_CACHE_TS.clear()


@pytest.mark.asyncio
async def test_quick_status_reuses_fresh_full_cache(monkeypatch: pytest.MonkeyPatch):
    model_id = mv.SEARCH_MODEL_ID
    cached = {
        "model_id": model_id,
        "state": "ready",
        "verified": True,
        "smoke_test_ok": True,
        "singleton_initialized": True,
        "message": "cached full verify",
        "error": None,
        "cache_path": "/tmp/model",
        "checked_at": "2026-02-23T00:00:00Z",
    }
    mv._FULL_VERIFY_CACHE[model_id] = cached
    mv._FULL_VERIFY_CACHE_TS[model_id] = time.time()

    monkeypatch.setattr(
        mv,
        "_quick_search_embedding_state",
        lambda: {
            "model_id": model_id,
            "state": "installed_unverified",
            "verified": False,
            "smoke_test_ok": False,
            "singleton_initialized": False,
            "message": "quick",
            "error": None,
            "cache_path": "/tmp/model",
            "checked_at": "2026-02-23T00:00:01Z",
        },
    )

    states = await mv.get_builtin_model_states(
        full_verify=False, target_models=[mv.SEARCH_MODEL_ID]
    )

    assert states[model_id]["state"] == "ready"
    assert states[model_id]["verified"] is True
    assert states[model_id]["message"] == "cached full verify"


@pytest.mark.asyncio
async def test_quick_status_keeps_corrupted_even_if_cache_ready(
    monkeypatch: pytest.MonkeyPatch,
):
    model_id = mv.SEARCH_MODEL_ID
    mv._FULL_VERIFY_CACHE[model_id] = {
        "model_id": model_id,
        "state": "ready",
        "verified": True,
        "smoke_test_ok": True,
        "singleton_initialized": True,
        "message": "cached full verify",
        "error": None,
        "cache_path": "/tmp/model",
        "checked_at": "2026-02-23T00:00:00Z",
    }
    mv._FULL_VERIFY_CACHE_TS[model_id] = time.time()

    monkeypatch.setattr(
        mv,
        "_quick_search_embedding_state",
        lambda: {
            "model_id": model_id,
            "state": "corrupted",
            "verified": False,
            "smoke_test_ok": False,
            "singleton_initialized": False,
            "message": "integrity failed",
            "error": "integrity failed",
            "cache_path": "/tmp/model",
            "checked_at": "2026-02-23T00:00:01Z",
        },
    )

    states = await mv.get_builtin_model_states(
        full_verify=False, target_models=[mv.SEARCH_MODEL_ID]
    )

    assert states[model_id]["state"] == "corrupted"
    assert states[model_id]["verified"] is False
    assert states[model_id]["message"] == "integrity failed"


@pytest.mark.asyncio
async def test_full_verify_updates_cache(monkeypatch: pytest.MonkeyPatch):
    model_id = mv.SEARCH_MODEL_ID

    monkeypatch.setattr(
        mv,
        "_quick_search_embedding_state",
        lambda: {
            "model_id": model_id,
            "state": "installed_unverified",
            "verified": False,
            "smoke_test_ok": False,
            "singleton_initialized": False,
            "message": "quick",
            "error": None,
            "cache_path": "/tmp/model",
            "checked_at": "2026-02-23T00:00:01Z",
        },
    )

    async def fake_full_verify(_: dict):
        return {
            "model_id": model_id,
            "state": "ready",
            "verified": True,
            "smoke_test_ok": True,
            "singleton_initialized": True,
            "message": "verified",
            "error": None,
            "cache_path": "/tmp/model",
            "checked_at": "2026-02-23T00:00:02Z",
            "last_verified_at": "2026-02-23T00:00:02Z",
        }

    monkeypatch.setattr(mv, "_full_verify_search_embedding", fake_full_verify)

    states = await mv.get_builtin_model_states(
        full_verify=True,
        force_refresh=True,
        target_models=[mv.SEARCH_MODEL_ID],
    )

    assert states[model_id]["state"] == "ready"
    assert mv._FULL_VERIFY_CACHE[model_id]["state"] == "ready"
