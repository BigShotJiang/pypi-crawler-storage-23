"""
Nowledge Graph Test Suite

Comprehensive test coverage for the unified API & MCP architecture.
This test suite ensures our core operations maintain functionality
across future development iterations.

Test Categories:
- Core Operations: Memory, Thread, Search, Entity, Graph operations
- Database Integration: KuzuClient methods and schema operations
- Service Integration: Embedding, Entity extraction, etc.
- API Integration: FastAPI endpoints and MCP tools
- End-to-end Workflows: Complete user scenarios

Usage:
    pytest tests/                    # Run all tests
    pytest tests/core/              # Run core operations tests
    pytest tests/integration/      # Run integration tests
    pytest -v tests/                # Verbose output
    pytest -k "memory"              # Run memory-related tests only
"""

import os
import tempfile
import asyncio
from pathlib import Path
from contextlib import asynccontextmanager
from typing import AsyncIterator, Tuple, Optional, Any

# Test configuration
TEST_DB_PREFIX = "nowledge_test_"
TEST_EMBEDDING_MODEL = "all-MiniLM-L6-v2"
TEST_EMBEDDING_DIMENSION = 384


class TestEnvironment:
    """Shared test environment and utilities."""

    @staticmethod
    def get_test_db_path() -> Path:
        """Get a unique temporary database path for testing."""
        temp_dir = tempfile.mkdtemp()
        return Path(temp_dir) / f"{TEST_DB_PREFIX}{os.getpid()}"

    @staticmethod
    async def cleanup_db(db_path: Path) -> None:
        """Clean up test database files."""
        try:
            if db_path.exists():
                import shutil

                shutil.rmtree(db_path.parent)
        except Exception:
            pass  # Best effort cleanup


@asynccontextmanager
async def test_core_services() -> AsyncIterator[Tuple[Any, Any, Any, Any, Any]]:
    """
    Create test services for core operations testing.

    Returns:
        Tuple of (db, embedding_service, memory_ops, thread_ops, search_ops)
    """
    from src.nowledge_graph_server.database.kuzu_client import KuzuClient
    from src.nowledge_graph_server.services.embedding import EmbeddingService
    from src.nowledge_graph_server.core.memory_operations import MemoryOperations
    from src.nowledge_graph_server.core.thread_operations import ThreadOperations
    from src.nowledge_graph_server.core.search_operations import SearchOperations
    from src.nowledge_graph_server.core.graph_operations import GraphOperations

    # Setup
    db_path = TestEnvironment.get_test_db_path()
    db = None
    embedding_service = None

    try:
        # Initialize database with test embedding dimension
        db = KuzuClient(db_path, embedding_dimension=TEST_EMBEDDING_DIMENSION)
        await db.initialize()

        # Initialize embedding service
        embedding_service = EmbeddingService(
            model_name=TEST_EMBEDDING_MODEL,
            device="cpu",
            dimension=TEST_EMBEDDING_DIMENSION,
            cache_only=True,  # Use cache_only instead of offline_mode
        )
        await embedding_service.initialize()

        # Initialize core operations
        memory_ops = MemoryOperations(
            db=db,
            embedding_service=embedding_service,
        )
        graph_ops = GraphOperations(kuzu_client=db)

        thread_ops = ThreadOperations(
            db=db,
            embedding_service=embedding_service,
            graph_ops=graph_ops,
        )

        search_ops = SearchOperations(
            db=db,
            embedding_service=embedding_service,
        )

        yield db, embedding_service, memory_ops, thread_ops, search_ops

    finally:
        # Cleanup
        if embedding_service:
            await embedding_service.cleanup()
        if db:
            await db.close()
        await TestEnvironment.cleanup_db(db_path)


# Sample test data for consistent testing
SAMPLE_MEMORIES = [
    {
        "content": "React.memo is a higher-order component that optimizes React applications by preventing unnecessary re-renders when props haven't changed",
        "importance": 0.8,
        "labels": ["react", "performance", "optimization"],
        "metadata": {"category": "frontend", "technology": "react"},
    },
    {
        "content": "Python async/await syntax provides a way to write asynchronous code that looks and behaves like synchronous code, making it easier to reason about",
        "importance": 0.7,
        "labels": ["python", "async", "programming"],
        "metadata": {"category": "backend", "technology": "python"},
    },
    {
        "content": "KuzuDB is a graph database optimized for analytics with native support for vector operations, making it ideal for knowledge graph applications",
        "importance": 0.9,
        "labels": ["database", "graph", "vector-search"],
        "metadata": {"category": "infrastructure", "technology": "database"},
    },
]

SAMPLE_THREADS = [
    {
        "thread_id": "react_optimization_guide",
        "title": "React Performance Optimization Guide",
        "source": "cursor",
        "participants": ["developer", "assistant"],
        "messages": [
            {
                "content": "How can I optimize my React application for better performance?",
                "role": "user",
            },
            {
                "content": "There are several key strategies: use React.memo to prevent unnecessary re-renders, implement proper key props for lists, and consider code splitting with React.lazy.",
                "role": "assistant",
            },
            {"content": "Can you explain more about React.memo?", "role": "user"},
            {
                "content": "React.memo is a higher-order component that wraps your component and only re-renders when props actually change, using shallow comparison by default.",
                "role": "assistant",
            },
        ],
        "metadata": {"project": "react-app", "session": "optimization"},
    },
    {
        "thread_id": "python_async_tutorial",
        "title": "Understanding Python Async Programming",
        "source": "chatwise",
        "participants": ["student", "tutor"],
        "messages": [
            {
                "content": "I'm confused about async/await in Python. Can you explain it?",
                "role": "user",
            },
            {
                "content": "async/await allows you to write asynchronous code that doesn't block. When you await something, your function pauses and lets other code run.",
                "role": "assistant",
            },
            {
                "content": "When should I use async vs regular functions?",
                "role": "user",
            },
            {
                "content": "Use async for I/O-bound operations like network requests, file operations, or database queries. For CPU-bound tasks, regular functions or multiprocessing is better.",
                "role": "assistant",
            },
        ],
        "metadata": {"course": "python-advanced", "lesson": "concurrency"},
    },
]


# Test assertions and utilities
class TestAssertions:
    """Custom assertions for testing Nowledge Graph functionality."""

    @staticmethod
    def assert_memory_node_valid(
        memory_node: Any, expected_content: Optional[str] = None
    ) -> None:
        """Assert that a memory node has valid structure and content."""
        assert memory_node is not None, "Memory node should not be None"
        assert hasattr(memory_node, "id"), "Memory should have an ID"
        assert hasattr(memory_node, "content"), "Memory should have content"
        assert hasattr(memory_node, "importance"), "Memory should have importance"
        assert hasattr(memory_node, "confidence"), "Memory should have confidence"
        assert hasattr(memory_node, "embedding"), "Memory should have embedding"
        assert hasattr(memory_node, "created_at"), "Memory should have created_at"

        if expected_content:
            assert memory_node.content == expected_content

        assert 0.0 <= memory_node.importance <= 1.0, (
            "Importance should be between 0 and 1"
        )
        assert 0.0 <= memory_node.confidence <= 1.0, (
            "Confidence should be between 0 and 1"
        )

        if memory_node.embedding:
            assert len(memory_node.embedding) == TEST_EMBEDDING_DIMENSION, (
                f"Embedding should have {TEST_EMBEDDING_DIMENSION} dimensions"
            )

    @staticmethod
    def assert_thread_node_valid(
        thread_node: Any, expected_thread_id: Optional[str] = None
    ) -> None:
        """Assert that a thread node has valid structure."""
        assert thread_node is not None, "Thread node should not be None"
        assert hasattr(thread_node, "id"), "Thread should have an ID"
        assert hasattr(thread_node, "thread_id"), "Thread should have a thread_id"
        assert hasattr(thread_node, "title"), "Thread should have a title"
        assert hasattr(thread_node, "message_count"), "Thread should have message_count"
        assert hasattr(thread_node, "created_at"), "Thread should have created_at"

        if expected_thread_id:
            assert thread_node.thread_id == expected_thread_id

        assert thread_node.message_count >= 0, "Message count should be non-negative"

    @staticmethod
    def assert_search_results_valid(results: Any, min_results: int = 0) -> None:
        """Assert that search results have valid structure."""
        assert isinstance(results, (list, dict)), "Results should be list or dict"

        if isinstance(results, dict):
            assert "total_found" in results, "Search results should include total_found"
            assert results["total_found"] >= min_results, (
                f"Should find at least {min_results} results"
            )
        else:
            assert len(results) >= min_results, (
                f"Should find at least {min_results} results"
            )
            for result in results:
                assert hasattr(result, "similarity_score"), (
                    "Search result should have similarity_score"
                )
                assert 0.0 <= result.similarity_score <= 1.0, (
                    "Similarity score should be between 0 and 1"
                )
