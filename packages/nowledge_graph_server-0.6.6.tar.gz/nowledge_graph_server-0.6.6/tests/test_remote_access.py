from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import time
from pathlib import Path

from starlette.requests import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nowledge_graph_server.api.routers import remote_access as remote_access_router
from nowledge_graph_server.services import remote_access as remote_access_module
from nowledge_graph_server.services.remote_access import (
    CLOUDFLARED_URL_PATTERN,
    IP_ALLOWLIST_ENV,
    TUNNEL_MODE_ACCOUNT,
    TUNNEL_MODE_QUICK,
    CLOUDFLARED_MANAGED_ENV,
    CLOUDFLARED_OWNER_ENV,
    is_ip_allowlist_match,
    is_local_request,
    is_remote_target_path_allowed,
    load_ip_allowlist_from_env,
    parse_ip_allowlist,
)


def _make_request(
    headers: dict[str, str],
    client_ip: str = "203.0.113.9",
    query_string: str = "",
    cookies: dict[str, str] | None = None,
    tunneled: bool = False,
) -> Request:
    encoded_headers = [(k.lower().encode(), v.encode()) for k, v in headers.items()]
    if tunneled:
        encoded_headers.append((b"cf-connecting-ip", client_ip.encode()))
    if cookies:
        cookie_value = "; ".join(f"{key}={value}" for key, value in cookies.items())
        encoded_headers.append((b"cookie", cookie_value.encode()))
    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": "GET",
        "path": "/remote-api/health",
        "raw_path": b"/remote-api/health",
        "query_string": query_string.encode(),
        "headers": encoded_headers,
        "client": (client_ip, 12345),
        "server": ("127.0.0.1", 14242),
        "scheme": "http",
    }
    return Request(scope)


def _make_management_request(client_ip: str = "127.0.0.1") -> Request:
    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": "POST",
        "path": "/api/remote-access/shutdown",
        "raw_path": b"/api/remote-access/shutdown",
        "query_string": b"",
        "headers": [],
        "client": (client_ip, 12345),
        "server": ("127.0.0.1", 14242),
        "scheme": "http",
    }
    return Request(scope)


def test_remote_access_auth_success(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    request = _make_request({"authorization": f"Bearer {api_key}"})

    result = manager.authenticate_request(request)
    assert result.ok is True


def test_remote_access_auth_success_with_x_header(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    request = _make_request({"x-nmem-api-key": api_key})

    result = manager.authenticate_request(request)
    assert result.ok is True


def test_remote_access_auth_success_with_cookie_fallback(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    request = _make_request({}, cookies={"nmem_api_key": api_key}, tunneled=True)

    result = manager.authenticate_request(request)
    assert result.ok is True


def test_remote_access_auth_success_with_query_fallback(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    request = _make_request({}, query_string=f"nmem_api_key={api_key}", tunneled=True)

    result = manager.authenticate_request(request)
    assert result.ok is True


def test_remote_access_missing_key_error_lists_supported_auth_paths(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    _ = manager._set_new_api_key()

    result = manager.authenticate_request(_make_request({}, tunneled=True))
    assert result.ok is False
    assert result.status_code == 401
    assert "Authorization: Bearer <key>" in result.detail
    assert "X-NMEM-API-Key" in result.detail
    assert "nmem_api_key cookie/query" in result.detail


def test_remote_access_local_missing_key_error_does_not_suggest_query(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    _ = manager._set_new_api_key()

    result = manager.authenticate_request(_make_request({}))
    assert result.ok is False
    assert result.status_code == 401
    assert "Authorization: Bearer <key>" in result.detail
    assert "X-NMEM-API-Key" in result.detail
    assert "nmem_api_key cookie/query" not in result.detail


def test_remote_access_auth_throttle(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    _ = manager._set_new_api_key()
    request = _make_request({"authorization": "Bearer wrong-key"})

    # First N attempts: unauthorized
    for _ in range(remote_access_module.AUTH_MAX_FAILURES):
        result = manager.authenticate_request(request)
        assert result.ok is False
        assert result.status_code == 401

    # Next attempt should be blocked by throttle window
    blocked = manager.authenticate_request(request)
    assert blocked.ok is False
    assert blocked.status_code == 429
    assert blocked.retry_after_seconds is not None


def test_remote_access_auth_blocked_client_recovers_with_valid_key(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    wrong_request = _make_request({"authorization": "Bearer wrong-key"})
    valid_request = _make_request({"authorization": f"Bearer {api_key}"})

    for _ in range(remote_access_module.AUTH_MAX_FAILURES + 1):
        _ = manager.authenticate_request(wrong_request)

    recovered = manager.authenticate_request(valid_request)
    assert recovered.ok is True


def test_remote_access_allowed_paths():
    assert is_remote_target_path_allowed("health") is True
    assert is_remote_target_path_allowed("memories/search") is True
    assert is_remote_target_path_allowed("mcp") is True
    assert is_remote_target_path_allowed("remote-llm/status") is True
    assert is_remote_target_path_allowed("remote-llm/credentials") is True
    assert is_remote_target_path_allowed("agent/status") is True

    assert is_remote_target_path_allowed("") is False
    assert is_remote_target_path_allowed("api/license/status") is False
    assert is_remote_target_path_allowed("browser-bridge/ws") is False
    assert is_remote_target_path_allowed("browser-bridge/status") is False
    assert is_remote_target_path_allowed("remote-llm/config") is False


def test_is_local_request_detection():
    assert is_local_request(_make_request({}, client_ip="127.0.0.1")) is True
    assert is_local_request(_make_request({}, client_ip="::1")) is True
    assert is_local_request(_make_request({}, client_ip="192.168.1.50")) is False


def test_parse_ip_allowlist_supports_ips_and_cidr():
    parsed, invalid = parse_ip_allowlist(
        "192.168.1.10, 10.0.0.0/24\n2001:db8::1, 2001:db8::/64"
    )

    assert invalid == []
    assert [str(network) for network in parsed] == [
        "192.168.1.10/32",
        "10.0.0.0/24",
        "2001:db8::1/128",
        "2001:db8::/64",
    ]


def test_parse_ip_allowlist_collects_invalid_entries():
    parsed, invalid = parse_ip_allowlist("192.168.1.10, nope, 10.0.0.0/24, bad/xyz")

    assert [str(network) for network in parsed] == ["192.168.1.10/32", "10.0.0.0/24"]
    assert invalid == ["nope", "bad/xyz"]


def test_load_ip_allowlist_from_env_uses_expected_var():
    parsed, invalid = load_ip_allowlist_from_env(
        {
            IP_ALLOWLIST_ENV: "192.168.1.0/24, 10.0.0.5",
        }
    )

    assert invalid == []
    assert [str(network) for network in parsed] == ["192.168.1.0/24", "10.0.0.5/32"]


def test_is_ip_allowlist_match_behavior():
    networks, invalid = parse_ip_allowlist("192.168.1.0/24, 2001:db8::/64")
    assert invalid == []

    assert is_ip_allowlist_match("192.168.1.42", networks) is True
    assert is_ip_allowlist_match("10.0.0.42", networks) is False
    assert is_ip_allowlist_match("2001:db8::1234", networks) is True
    assert is_ip_allowlist_match("2001:4860::1", networks) is False
    assert is_ip_allowlist_match("not-an-ip", networks) is False
    assert is_ip_allowlist_match("203.0.113.1", []) is True


def test_status_includes_backend_ip_allowlist_details(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    monkeypatch.setenv(
        IP_ALLOWLIST_ENV,
        "192.168.1.0/24, invalid-entry, 10.0.0.10",
    )
    manager = remote_access_module.RemoteAccessManager()

    status = manager.get_status()
    assert status["backend_ip_allowlist"] == ["192.168.1.0/24", "10.0.0.10/32"]
    assert status["backend_ip_allowlist_invalid"] == ["invalid-entry"]


def test_cleanup_orphaned_managed_cloudflared_processes_only_kills_mem_owned(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    owner = manager._cloudflared_owner

    env_marked = os.environ.copy()
    env_marked[CLOUDFLARED_MANAGED_ENV] = "1"
    env_marked[CLOUDFLARED_OWNER_ENV] = owner

    env_unmarked = os.environ.copy()
    env_unmarked[CLOUDFLARED_MANAGED_ENV] = "1"
    env_unmarked[CLOUDFLARED_OWNER_ENV] = "some-other-owner"

    managed = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(60)", "cloudflared"],
        env=env_marked,
    )
    other = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(60)", "cloudflared"],
        env=env_unmarked,
    )

    try:
        time.sleep(0.2)
        manager._cleanup_orphaned_managed_cloudflared_processes()
        time.sleep(0.2)

        assert managed.poll() is not None
        assert other.poll() is None
    finally:
        if managed.poll() is None:
            managed.terminate()
            managed.wait(timeout=3)
        if other.poll() is None:
            other.terminate()
            other.wait(timeout=3)


def test_cloudflared_resolution_prefers_env(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    bundled = tmp_path / "cloudflared"
    bundled.write_text("#!/bin/sh\necho cloudflared\n", encoding="utf-8")
    bundled.chmod(0o755)
    monkeypatch.setenv("NOWLEDGE_CLOUDFLARED_PATH", str(bundled))

    manager = remote_access_module.RemoteAccessManager()
    resolved_path, source = manager.resolve_cloudflared()

    assert resolved_path == str(bundled)
    assert source == "env"


def test_cloudflared_resolution_falls_back_to_system(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    monkeypatch.delenv("NOWLEDGE_CLOUDFLARED_PATH", raising=False)
    monkeypatch.setattr(
        remote_access_module.RemoteAccessManager,
        "_bundled_cloudflared_candidates",
        lambda self: [],
    )
    monkeypatch.setattr(
        remote_access_module.shutil,
        "which",
        lambda cmd: "/usr/local/bin/cloudflared" if cmd == "cloudflared" else None,
    )

    manager = remote_access_module.RemoteAccessManager()
    resolved_path, source = manager.resolve_cloudflared()

    assert resolved_path == "/usr/local/bin/cloudflared"
    assert source == "system"


def test_cloudflared_url_pattern_matches_quick_tunnel_output():
    line = (
        "INF |  https://planet-spell-favor-beliefs.trycloudflare.com  |"
    )
    match = CLOUDFLARED_URL_PATTERN.search(line)
    assert match is not None
    assert match.group(0) == "https://planet-spell-favor-beliefs.trycloudflare.com"


def test_account_tunnel_config_encrypts_token(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    status = asyncio.run(
        manager.configure_tunnel(
            mode=TUNNEL_MODE_ACCOUNT,
            account_tunnel_url="https://mem.example.com/",
            account_tunnel_token="super-secret-token",
        )
    )

    assert status["mode"] == TUNNEL_MODE_ACCOUNT
    assert status["account_tunnel_url"] == "https://mem.example.com"
    assert status["account_tunnel_token_configured"] is True
    assert manager._get_account_tunnel_token() == "super-secret-token"

    state_text = (tmp_path / "remote-access.json").read_text(encoding="utf-8")
    assert "super-secret-token" not in state_text


def test_api_key_reveal_roundtrip_and_state_encrypted(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    api_key = manager._set_new_api_key()
    revealed = asyncio.run(manager.reveal_api_key())
    status = manager.get_status()

    assert revealed == api_key
    assert status["api_key_configured"] is True
    assert status["api_key_recoverable"] is True

    state_text = (tmp_path / "remote-access.json").read_text(encoding="utf-8")
    assert api_key not in state_text


def test_legacy_api_key_without_encrypted_copy_prompts_rotation(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    _ = manager._set_new_api_key()
    manager._api_key_enc = None
    manager._api_key_nonce = None
    manager._save_state()

    reloaded = remote_access_module.RemoteAccessManager()
    status = reloaded.get_status()
    assert status["api_key_configured"] is True
    assert status["api_key_recoverable"] is False

    try:
        asyncio.run(reloaded.reveal_api_key())
    except RuntimeError as exc:
        assert "Click Rotate once" in str(exc)
    else:
        raise AssertionError("Expected reveal_api_key() to fail for legacy key state")


def test_account_tunnel_config_rejects_non_https_url(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    try:
        asyncio.run(
            manager.configure_tunnel(
                mode=TUNNEL_MODE_ACCOUNT,
                account_tunnel_url="http://mem.example.com",
            )
        )
    except ValueError as exc:
        assert "HTTPS URL" in str(exc)
    else:
        raise AssertionError("Expected ValueError for non-HTTPS account tunnel URL")


def test_account_tunnel_config_rejects_path_suffix(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    try:
        asyncio.run(
            manager.configure_tunnel(
                mode=TUNNEL_MODE_ACCOUNT,
                account_tunnel_url="https://mem.example.com/remote-api",
            )
        )
    except ValueError as exc:
        assert "Do not add /remote-api" in str(exc)
    else:
        raise AssertionError("Expected ValueError for account URL path suffix")


def test_remote_access_mode_normalization_defaults_to_quick(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    assert manager.configured_mode == TUNNEL_MODE_QUICK


def test_remote_access_auto_start_persisted_in_state(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    manager._auto_start_enabled = True
    manager._save_state()

    reloaded = remote_access_module.RemoteAccessManager()
    assert reloaded.auto_start_enabled is True


def test_stop_tunnel_disables_auto_start_by_default(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    manager._auto_start_enabled = True

    status = asyncio.run(manager.stop_tunnel())
    assert status["auto_start_enabled"] is False


def test_stop_tunnel_can_keep_auto_start_enabled(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    manager._auto_start_enabled = True

    status = asyncio.run(manager.stop_tunnel(disable_auto_start=False))
    assert status["auto_start_enabled"] is True


def test_shutdown_preserves_auto_start(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()
    manager._auto_start_enabled = True

    stop_calls = {"count": 0}

    async def fake_stop_process_locked():
        stop_calls["count"] += 1

    monkeypatch.setattr(manager, "_stop_process_locked", fake_stop_process_locked)
    asyncio.run(manager.shutdown())

    assert stop_calls["count"] == 1
    assert manager.auto_start_enabled is True


def test_shutdown_route_stops_tunnel_without_disabling_auto_start(monkeypatch):
    class DummyManager:
        def __init__(self):
            self.shutdown_called = False

        async def shutdown(self):
            self.shutdown_called = True

        def get_status(self):
            return {"running": False, "auto_start_enabled": True}

    manager = DummyManager()
    monkeypatch.setattr(
        remote_access_router,
        "get_remote_access_manager",
        lambda: manager,
    )

    status = asyncio.run(
        remote_access_router.shutdown_remote_access(_make_management_request())
    )

    assert manager.shutdown_called is True
    assert status["running"] is False
    assert status["auto_start_enabled"] is True


def test_quick_tunnel_status_returns_base_url(tmp_path, monkeypatch):
    monkeypatch.setattr(remote_access_module, "get_app_data_dir", lambda: tmp_path)
    manager = remote_access_module.RemoteAccessManager()

    manager._process = type("Proc", (), {"returncode": None})()
    manager._active_mode = TUNNEL_MODE_QUICK
    manager._public_url = "https://planet-spell-favor-beliefs.trycloudflare.com"

    status = manager.get_status()
    assert status["running"] is True
    assert (
        status["tunnel_url"]
        == "https://planet-spell-favor-beliefs.trycloudflare.com"
    )
