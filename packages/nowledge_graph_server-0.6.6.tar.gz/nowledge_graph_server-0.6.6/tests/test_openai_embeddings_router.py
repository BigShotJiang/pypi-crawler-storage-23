from __future__ import annotations

import base64
import sys
import types
from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.modules.setdefault("lancedb", types.SimpleNamespace())
sys.modules.setdefault(
    "lancedb.pydantic",
    types.SimpleNamespace(LanceModel=object, Vector=list),
)
sys.modules.setdefault("lancedb.table", types.SimpleNamespace(Table=object))

import nowledge_graph_server.api.routers.openai_embeddings as openai_embeddings

CANONICAL_TEST_MODEL = "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"


class _FakeEmbeddingService:
    def __init__(self) -> None:
        self.model_name = CANONICAL_TEST_MODEL
        self.calls: list[tuple[list[str], bool]] = []

    async def embed_batch(
        self,
        texts: list[str],
        is_query: bool = False,
    ) -> list[list[float]]:
        self.calls.append((texts, is_query))
        return [[float(i + 1), float(i + 2)] for i, _ in enumerate(texts)]


def _build_client() -> TestClient:
    app = FastAPI()
    app.include_router(openai_embeddings.router)
    return TestClient(app)


def test_openai_models_list_returns_only_backend_model(monkeypatch) -> None:
    monkeypatch.setattr(
        openai_embeddings,
        "get_search_model_info",
        lambda: {"model_name": "BAAI/bge-m3"},
    )

    client = _build_client()
    response = client.get("/v1/models")

    assert response.status_code == 200
    payload = response.json()

    assert payload["object"] == "list"
    assert len(payload["data"]) == 1
    model = payload["data"][0]
    assert model["id"] == "BAAI/bge-m3"
    assert model["object"] == "model"
    assert model["owned_by"] == "nowledge-local"
    assert model["root"] == "BAAI/bge-m3"


def test_openai_models_list_alias_root_points_to_backend(monkeypatch) -> None:
    monkeypatch.setattr(
        openai_embeddings,
        "get_search_model_info",
        lambda: {"model_name": "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"},
    )

    client = _build_client()
    response = client.get("/v1/models")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload["data"]) == 1
    assert payload["data"][0]["id"] == "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"
    assert payload["data"][0]["root"] == "mlx-community/Qwen3-Embedding-0.6B-4bit-DWQ"


def test_openai_embeddings_single_input_success(monkeypatch) -> None:
    fake_service = _FakeEmbeddingService()

    async def _fake_get_search_embedding_service():
        return fake_service

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: True)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": CANONICAL_TEST_MODEL,
            "input": "hello embedding world",
        },
    )

    assert response.status_code == 200
    payload = response.json()

    assert payload["object"] == "list"
    assert payload["model"] == CANONICAL_TEST_MODEL
    assert payload["data"][0]["object"] == "embedding"
    assert payload["data"][0]["index"] == 0
    assert payload["data"][0]["embedding"] == [1.0, 2.0]
    assert payload["usage"]["prompt_tokens"] >= 1
    assert payload["usage"]["total_tokens"] == payload["usage"]["prompt_tokens"]
    assert fake_service.calls == [(["hello embedding world"], False)]


def test_openai_embeddings_query_input_type_sets_query_mode(monkeypatch) -> None:
    fake_service = _FakeEmbeddingService()

    async def _fake_get_search_embedding_service():
        return fake_service

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: True)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": CANONICAL_TEST_MODEL,
            "input": ["alpha", "beta"],
            "input_type": "query",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload["data"]) == 2
    assert fake_service.calls == [(["alpha", "beta"], True)]


def test_openai_embeddings_base64_encoding(monkeypatch) -> None:
    fake_service = _FakeEmbeddingService()

    async def _fake_get_search_embedding_service():
        return fake_service

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: True)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": CANONICAL_TEST_MODEL,
            "input": ["single"],
            "encoding_format": "base64",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    encoded = payload["data"][0]["embedding"]
    decoded = base64.b64decode(encoded)
    assert isinstance(encoded, str)
    # 2 float32 values from _FakeEmbeddingService.
    assert len(decoded) == 8


def test_openai_embeddings_rejects_alias_model_id(monkeypatch) -> None:
    fake_service = _FakeEmbeddingService()

    async def _fake_get_search_embedding_service():
        return fake_service

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: True)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": "text-embedding-3-small",
            "input": "hello",
        },
    )

    assert response.status_code == 400
    payload = response.json()["error"]
    assert payload["type"] == "invalid_request_error"
    assert payload["param"] == "model"
    assert payload["code"] == "model_mismatch"
    assert CANONICAL_TEST_MODEL in payload["message"]


def test_openai_embeddings_service_unavailable_when_model_not_installed(monkeypatch) -> None:
    async def _fake_get_search_embedding_service():
        return None

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: False)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": CANONICAL_TEST_MODEL,
            "input": "hello",
        },
    )

    assert response.status_code == 503
    payload = response.json()["error"]
    assert payload["type"] == "service_unavailable_error"
    assert payload["code"] == "embedding_service_unavailable"


def test_openai_embeddings_invalid_input_type_returns_openai_error(monkeypatch) -> None:
    fake_service = _FakeEmbeddingService()

    async def _fake_get_search_embedding_service():
        return fake_service

    monkeypatch.setattr(
        openai_embeddings,
        "get_search_embedding_service",
        _fake_get_search_embedding_service,
    )
    monkeypatch.setattr(openai_embeddings, "check_search_model_exists", lambda: True)

    client = _build_client()
    response = client.post(
        "/v1/embeddings",
        json={
            "model": CANONICAL_TEST_MODEL,
            "input": 123,
        },
    )

    assert response.status_code == 400
    payload = response.json()["error"]
    assert payload["type"] == "invalid_request_error"
    assert payload["param"] == "input"
    assert payload["code"] == "invalid_input_type"
