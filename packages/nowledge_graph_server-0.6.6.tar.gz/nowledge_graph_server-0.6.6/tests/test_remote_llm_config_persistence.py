from __future__ import annotations

import json
from pathlib import Path

import nowledge_graph_server.services.remote_llm_config as remote_llm_config_module
from nowledge_graph_server.services.remote_llm_config import (
    RemoteLLMConfig,
    RemoteLLMConfigManager,
)


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def test_save_preserves_legacy_plaintext_key_on_partial_update(tmp_path: Path) -> None:
    config_path = tmp_path / "co.nowledge.mem.desktop" / "remote_llm.json"
    _write_json(
        config_path,
        {
            "enabled": True,
            "active_provider": "openai",
            "purposes": {
                "default": {"provider": "openai", "model": "openai/gpt-4o"},
                "ai_now": {"provider": None, "model": None},
            },
            "providers": {
                "openai": {
                    "type": "openai",
                    "model": "openai/gpt-4o",
                    "api_key": "sk-legacy-plain",
                }
            },
        },
    )

    manager = RemoteLLMConfigManager(config_path=config_path)
    assert manager.get_all_provider_configs()["openai"].api_key == "sk-legacy-plain"

    manager.update_config(
        RemoteLLMConfig(
            enabled=True,
            provider="openai",
            provider_type="openai",
            model="openai/gpt-4.1",
            # No api_key provided: should preserve existing key
            api_key=None,
        )
    )

    saved = json.loads(config_path.read_text(encoding="utf-8"))
    provider = saved["providers"]["openai"]
    assert provider.get("api_key") is None
    assert isinstance(provider.get("api_key_enc"), str) and provider["api_key_enc"]
    assert isinstance(provider.get("api_key_nonce"), str) and provider["api_key_nonce"]

    reloaded = RemoteLLMConfigManager(config_path=config_path)
    cfg = reloaded.get_all_provider_configs()["openai"]
    assert cfg.api_key == "sk-legacy-plain"
    assert cfg.model == "openai/gpt-4.1"


def test_load_recovers_missing_keys_from_legacy_config_path(
    tmp_path: Path, monkeypatch
) -> None:
    canonical_dir = tmp_path / "config"
    legacy_dir = tmp_path / "legacy"
    home_dir = tmp_path / "home"

    config_path = canonical_dir / "remote_llm.json"
    _write_json(
        config_path,
        {
            "enabled": True,
            "active_provider": "openai",
            "purposes": {
                "default": {"provider": "openai", "model": "openai/gpt-4o"},
                "ai_now": {"provider": None, "model": None},
            },
            "providers": {
                "openai": {
                    "type": "openai",
                    "model": "openai/gpt-4o",
                }
            },
        },
    )

    _write_json(
        legacy_dir / "remote_llm.json",
        {
            "enabled": True,
            "active_provider": "openai",
            "providers": {
                "openai": {
                    "type": "openai",
                    "model": "openai/gpt-4o",
                    "api_key": "sk-recovered",
                }
            },
        },
    )

    monkeypatch.setattr(remote_llm_config_module, "get_app_config_dir", lambda: canonical_dir)
    monkeypatch.setattr(remote_llm_config_module, "get_legacy_app_data_dir", lambda: legacy_dir)
    monkeypatch.setattr(remote_llm_config_module, "get_real_home", lambda: home_dir)

    manager = RemoteLLMConfigManager(config_path=config_path)
    cfg = manager.get_all_provider_configs()["openai"]
    assert cfg.api_key == "sk-recovered"

    persisted = json.loads(config_path.read_text(encoding="utf-8"))
    p = persisted["providers"]["openai"]
    assert isinstance(p.get("api_key_enc"), str) and p["api_key_enc"]
    assert isinstance(p.get("api_key_nonce"), str) and p["api_key_nonce"]
    assert p.get("api_key") is None


def test_save_keeps_key_when_encryption_fails(tmp_path: Path, monkeypatch) -> None:
    config_path = tmp_path / "co.nowledge.mem.desktop" / "remote_llm.json"
    _write_json(
        config_path,
        {
            "enabled": True,
            "active_provider": "gemini",
            "purposes": {
                "default": {"provider": "gemini", "model": "gemini/gemini-flash-latest"},
                "ai_now": {"provider": None, "model": None},
            },
            "providers": {
                "gemini": {
                    "type": "gemini",
                    "model": "gemini/gemini-flash-latest",
                }
            },
        },
    )

    monkeypatch.setattr(
        remote_llm_config_module,
        "get_encryption_key_bytes",
        lambda: (_ for _ in ()).throw(RuntimeError("simulated encryption failure")),
    )

    manager = RemoteLLMConfigManager(config_path=config_path)
    manager.update_config(
        RemoteLLMConfig(
            enabled=True,
            provider="gemini",
            provider_type="gemini",
            model="gemini/gemini-flash-latest",
            api_key="gk-new-plain",
        )
    )

    saved = json.loads(config_path.read_text(encoding="utf-8"))
    provider = saved["providers"]["gemini"]
    assert provider.get("api_key") == "gk-new-plain"
    assert provider.get("api_key_enc") is None
    assert provider.get("api_key_nonce") is None


def test_save_creates_backup_of_previous_config(tmp_path: Path) -> None:
    config_path = tmp_path / "co.nowledge.mem.desktop" / "remote_llm.json"
    _write_json(
        config_path,
        {
            "enabled": True,
            "active_provider": "openai",
            "purposes": {
                "default": {"provider": "openai", "model": "openai/gpt-4o"},
                "ai_now": {"provider": None, "model": None},
            },
            "providers": {
                "openai": {
                    "type": "openai",
                    "model": "openai/gpt-4o",
                    "api_key": "sk-old",
                }
            },
        },
    )
    manager = RemoteLLMConfigManager(config_path=config_path)
    manager.update_config(
        RemoteLLMConfig(
            enabled=True,
            provider="openai",
            provider_type="openai",
            model="openai/gpt-4.1",
        )
    )

    backup_path = config_path.with_suffix(config_path.suffix + ".backup")
    assert backup_path.exists()
    backup = json.loads(backup_path.read_text(encoding="utf-8"))
    assert backup["providers"]["openai"]["model"] == "openai/gpt-4o"


def test_save_keeps_original_file_if_atomic_replace_fails(
    tmp_path: Path, monkeypatch
) -> None:
    config_path = tmp_path / "co.nowledge.mem.desktop" / "remote_llm.json"
    _write_json(
        config_path,
        {
            "enabled": True,
            "active_provider": "openai",
            "purposes": {
                "default": {"provider": "openai", "model": "openai/gpt-4o"},
                "ai_now": {"provider": None, "model": None},
            },
            "providers": {
                "openai": {
                    "type": "openai",
                    "model": "openai/gpt-4o",
                    "api_key": "sk-stable",
                }
            },
        },
    )
    original_content = config_path.read_text(encoding="utf-8")

    monkeypatch.setattr(
        remote_llm_config_module.os,
        "replace",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(OSError("simulated replace failure")),
    )

    manager = RemoteLLMConfigManager(config_path=config_path)
    manager.update_config(
        RemoteLLMConfig(
            enabled=True,
            provider="openai",
            provider_type="openai",
            model="openai/gpt-4.1",
        )
    )

    # Save failure is swallowed by manager; original file should remain valid and unchanged.
    assert config_path.read_text(encoding="utf-8") == original_content
    # Ensure temporary file does not leak.
    tmp_path_file = config_path.with_suffix(config_path.suffix + ".tmp")
    assert not tmp_path_file.exists()
