from __future__ import annotations

import shutil
from pathlib import Path
from unittest.mock import patch

from nowledge_graph_server.utils import app_paths


def _configure_linux_env(tmp_path: Path, monkeypatch) -> tuple[Path, Path]:
    home = tmp_path / "home"
    config_home = home / ".config"
    data_home = home / ".local" / "share"

    monkeypatch.setattr(app_paths, "_REAL_HOME", home)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(config_home))
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))

    return config_home, data_home


def test_resolve_config_file_path_migrates_from_legacy_linux(tmp_path: Path, monkeypatch) -> None:
    config_home, data_home = _configure_linux_env(tmp_path, monkeypatch)
    legacy = data_home / "co.nowledge.mem.desktop" / "settings.json"
    legacy.parent.mkdir(parents=True, exist_ok=True)
    legacy.write_text('{"ok": true}', encoding="utf-8")

    with patch("platform.system", return_value="Linux"):
        resolved = app_paths.resolve_config_file_path("settings.json")

    expected = config_home / "co.nowledge.mem.desktop" / "settings.json"
    assert resolved == expected
    assert expected.exists()
    assert expected.read_text(encoding="utf-8") == '{"ok": true}'


def test_resolve_config_subdir_path_moves_legacy_directory_linux(tmp_path: Path, monkeypatch) -> None:
    config_home, data_home = _configure_linux_env(tmp_path, monkeypatch)
    legacy_dir = data_home / "co.nowledge.mem.desktop" / "kimi_home"
    legacy_dir.mkdir(parents=True, exist_ok=True)
    (legacy_dir / "marker.txt").write_text("legacy", encoding="utf-8")

    with patch("platform.system", return_value="Linux"):
        resolved = app_paths.resolve_config_subdir_path("kimi_home")

    expected = config_home / "co.nowledge.mem.desktop" / "kimi_home"
    assert resolved == expected
    assert (expected / "marker.txt").read_text(encoding="utf-8") == "legacy"
    assert not legacy_dir.exists()


def test_resolve_config_subdir_path_falls_back_to_legacy_on_move_failure(
    tmp_path: Path, monkeypatch
) -> None:
    _config_home, data_home = _configure_linux_env(tmp_path, monkeypatch)
    legacy_dir = data_home / "co.nowledge.mem.desktop" / "builtin_agents"
    legacy_dir.mkdir(parents=True, exist_ok=True)

    with patch("platform.system", return_value="Linux"):
        with patch.object(shutil, "move", side_effect=OSError("simulated")):
            resolved = app_paths.resolve_config_subdir_path("builtin_agents")

    assert resolved == legacy_dir


def test_darwin_config_and_legacy_roots_are_identical(tmp_path: Path, monkeypatch) -> None:
    home = tmp_path / "home"
    monkeypatch.setattr(app_paths, "_REAL_HOME", home)

    with patch("platform.system", return_value="Darwin"):
        assert app_paths.get_app_config_dir() == app_paths.get_legacy_app_data_dir()
