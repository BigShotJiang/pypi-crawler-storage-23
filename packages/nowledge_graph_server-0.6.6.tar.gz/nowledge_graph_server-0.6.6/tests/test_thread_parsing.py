"""Tests for thread parsing service."""

import pytest
from nowledge_graph_server.services.thread_parsing import (
    ThreadParsingService,
    CursorMarkdownParser,
    ChatWiseParser,
    ChatGPTParser,
    ClaudeParser,
    NowledgeMemMarkdownParser,
    thread_parsing_service,
)


class TestThreadParsingService:
    """Test the thread parsing service."""

    def setup_method(self):
        self.service = ThreadParsingService()

    def test_chatwise_parser_detection(self):
        """Test ChatWise parser detection."""
        chatwise_content = """
        <!DOCTYPE html>
        <html>
        <head>
        <title>RAG Technology Benchmark Comparison</title>
        </head>
        <body>
        <div class="messages">
        <div class="message">
        <div class="message-role">
        <strong>user</strong>
        </div>
        <div class="message-content">
        Write me markdown tables of this RAG tech comparison
        </div>
        </div>
        </div>
        </body>
        </html>
        """

        parser = ChatWiseParser()
        assert parser.can_parse(chatwise_content, "chat.html")
        assert not parser.can_parse(chatwise_content, "chat.md")
        assert not parser.can_parse("random content", "chat.html")

    def test_chatwise_parser_parsing(self):
        """Test ChatWise parser parsing."""
        chatwise_content = """
        <!DOCTYPE html>
        <html>
        <head>
        <title>RAG Technology Benchmark Comparison</title>
        </head>
        <body>
        <div class="messages">
        <div class="message">
        <div class="message-role">
        <strong>user</strong>
        </div>
        <div class="message-content">
        Write me markdown tables of this RAG tech comparison
        </div>
        </div>
        <div class="message">
        <div class="message-role">
        <strong>copilot-claude-4-sonnet</strong>
        </div>
        <div class="message-content">
        <h1>RAG Technology Benchmark Comparison</h1>
        <p>Here's your comparison table...</p>
        </div>
        </div>
        </div>
        </body>
        </html>
        """

        parser = ChatWiseParser()
        result = parser.parse(chatwise_content, "chat.html")

        assert result.title == "RAG Technology Benchmark Comparison"
        assert result.source == "ChatWise"
        assert len(result.messages) == 2
        assert result.messages[0].speaker == "user"
        assert "RAG tech comparison" in result.messages[0].content
        assert result.messages[1].speaker == "copilot-claude-4-sonnet"
        assert "RAG Technology Benchmark Comparison" in result.messages[1].content

    def test_cursor_parser_detection(self):
        """Test Cursor parser detection."""
        cursor_content = """
        # Test Conversation
        
        _Exported on 2024-01-01 from Cursor_
        
        **User**
        Hello world
        
        **Assistant**
        Hi there!
        """

        parser = CursorMarkdownParser()
        assert parser.can_parse(cursor_content, "conversation.md")
        assert not parser.can_parse(cursor_content, "conversation.html")
        assert not parser.can_parse("random content", "conversation.md")

    def test_service_format_detection(self):
        """Test service format detection."""
        # Test ChatWise
        chatwise_content = '<div class="message-role"><strong>user</strong></div>'
        assert self.service.detect_format(chatwise_content, "chat.html") == "chatwise"

        # Test Cursor
        cursor_content = "_Exported on 2024-01-01 from Cursor_"
        assert self.service.detect_format(cursor_content, "chat.md") == "cursormarkdown"

        # Test unknown
        unknown_content = "random content"
        assert self.service.detect_format(unknown_content, "unknown.txt") == "unknown"

    def test_service_parsing_integration(self):
        """Test full service parsing integration."""
        chatwise_content = """
        <html><head><title>Test Chat</title></head><body>
        <div class="message-role"><strong>user</strong></div>
        <div class="message-content">Hello world</div>
        </body></html>
        """

        result = self.service.parse_thread(chatwise_content, "test.html")
        assert result.title == "Test Chat"
        assert result.source == "ChatWise"
        assert len(result.messages) == 1
        assert result.messages[0].content == "Hello world"

    def test_unsupported_format(self):
        """Test unsupported format handling."""
        with pytest.raises(ValueError, match="Unsupported format"):
            self.service.parse_thread("random content", "unknown.txt")


def test_nowledge_mem_markdown_parser():
    """Test parsing of nowledge-mem markdown exports."""
    sample_content = """# Resolving Python Typing Issue
_Exported on 07/13/2025 at 22:24:11 GMT from nowledge-mem_

---

**User**

please see if it's typing issue or

---

**Assistant**

Looking at the code and linter errors, there appears to be a typing issue with the `text_to_knowledge_func` parameter. Let me explain the problem:

1. The function signature shows:
```python
text_to_knowledge_func: Callable[[str, Any], BulkObjects]
```

2. But in the code, it's being called with only one argument:
```python
kg = text_to_knowledge_func(
chunk_node.text, **text_to_knowledge_func_extra_params
)
```

---

**Thread Metadata**

- Source: Cursor
- Created: 2025-07-13 12:28:38
- Messages: 6
- Participants: user, assistant
- Thread ID: imported-1752409718590
"""

    # Test format detection
    assert (
        thread_parsing_service.detect_format(sample_content, "test.md")
        == "nowledgememmarkdown"
    )

    # Test parsing
    parsed = thread_parsing_service.parse_thread(sample_content, "test.md")

    # Verify basic properties
    assert parsed.title == "Resolving Python Typing Issue"
    assert parsed.source == "Cursor"  # Should extract from metadata
    assert (
        parsed.export_info == "Exported on 07/13/2025 at 22:24:11 GMT from nowledge-mem"
    )
    assert len(parsed.messages) == 2

    # Verify messages
    assert parsed.messages[0].speaker == "user"
    assert parsed.messages[0].content == "please see if it's typing issue or"

    assert parsed.messages[1].speaker == "assistant"
    assert (
        "typing issue with the `text_to_knowledge_func` parameter"
        in parsed.messages[1].content
    )
    assert (
        "text_to_knowledge_func: Callable[[str, Any], BulkObjects]"
        in parsed.messages[1].content
    )

    # Verify participants
    assert "user" in parsed.participants
    assert "assistant" in parsed.participants


def test_nowledge_mem_parser_can_parse():
    """Test that the parser correctly identifies nowledge-mem format."""
    parser = NowledgeMemMarkdownParser()

    # Should detect nowledge-mem format
    nowledge_mem_content = """# Test
_Exported on 01/10/2025 at 14:30:25 GMT from nowledge-mem_

**User**
Hello
"""
    assert parser.can_parse(nowledge_mem_content, "test.md") == True

    # Should not detect other formats
    cursor_content = """# Test
_Exported on 01/10/2025 at 14:30:25 GMT from Cursor_

**User**
Hello
"""
    assert parser.can_parse(cursor_content, "test.md") == False

    # Should not detect non-markdown files
    assert parser.can_parse(nowledge_mem_content, "test.txt") == False


def test_nowledge_mem_parser_without_metadata():
    """Test parsing nowledge-mem format without thread metadata section."""
    content = """# Simple Thread
_Exported on 01/10/2025 at 14:30:25 GMT from nowledge-mem_

---

**User**

Hello world

---

**Assistant**

Hi there! How can I help you today?
"""

    parsed = thread_parsing_service.parse_thread(content, "test.md")

    assert parsed.title == "Simple Thread"
    assert parsed.source == "nowledge-mem"  # Default when no metadata
    assert len(parsed.messages) == 2
    assert parsed.messages[0].speaker == "user"
    assert parsed.messages[0].content == "Hello world"
    assert parsed.messages[1].speaker == "assistant"
    assert parsed.messages[1].content == "Hi there! How can I help you today?"
