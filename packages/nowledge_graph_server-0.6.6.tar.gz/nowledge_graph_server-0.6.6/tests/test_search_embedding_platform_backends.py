from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nowledge_graph_server.services import search_embedding


def test_search_embedding_service_selects_mlx_backend_on_apple(monkeypatch) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", True)

    service = search_embedding.SearchEmbeddingService(cache_only=True)

    assert service.model_name == search_embedding.MLX_MODEL
    assert service._backend == "mlx"


def test_search_embedding_service_selects_fastembed_backend_on_non_apple(
    monkeypatch,
) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", False)

    service = search_embedding.SearchEmbeddingService(cache_only=True)

    assert service.model_name == search_embedding.ONNX_MODEL
    assert service._backend == "fastembed"


def test_get_search_model_info_non_apple_reports_intel_macos_platform(
    monkeypatch,
) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", False)

    info = search_embedding.get_search_model_info()

    assert info["model_name"] == search_embedding.ONNX_MODEL
    assert info["backend"] == "fastembed"
    assert info["platform"] == "Windows/Linux/macOS Intel"


def test_embed_text_uses_qwen_query_instruction_on_apple(monkeypatch) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", True)
    service = search_embedding.SearchEmbeddingService(cache_only=True)
    service._initialized = True

    seen_inputs: list[str] = []

    async def _fake_embed_mlx(text: str) -> list[float]:
        seen_inputs.append(text)
        return [0.1, 0.2]

    monkeypatch.setattr(service, "_embed_mlx", _fake_embed_mlx)

    # Short query -> short query instruction
    short_result = asyncio.run(service.embed_text("ai", is_query=True))
    assert short_result == [0.1, 0.2]
    assert len(seen_inputs) == 1
    assert seen_inputs[0].startswith("Instruct: ")
    assert search_embedding.QWEN3_SHORT_QUERY_INSTRUCTION in seen_inputs[0]
    assert seen_inputs[0].endswith("Query:ai")

    # Longer query -> standard query instruction
    long_query = "how to design distributed systems for reliability"
    _ = asyncio.run(service.embed_text(long_query, is_query=True))
    assert len(seen_inputs) == 2
    assert search_embedding.QWEN3_QUERY_INSTRUCTION in seen_inputs[1]
    assert seen_inputs[1].endswith(f"Query:{long_query}")


def test_embed_text_non_apple_uses_fastembed_without_query_prefix(monkeypatch) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", False)
    service = search_embedding.SearchEmbeddingService(cache_only=True)
    service._initialized = True

    seen_inputs: list[str] = []

    async def _fake_embed_fastembed(text: str) -> list[float]:
        seen_inputs.append(text)
        return [0.3, 0.4]

    monkeypatch.setattr(service, "_embed_fastembed", _fake_embed_fastembed)

    result = asyncio.run(service.embed_text("  hello world  ", is_query=True))

    assert result == [0.3, 0.4]
    assert seen_inputs == ["hello world"]


def test_embed_batch_on_apple_applies_query_instruction(monkeypatch) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", True)
    service = search_embedding.SearchEmbeddingService(cache_only=True)
    service._initialized = True

    captured_batches: list[list[str]] = []

    async def _fake_embed_batch_mlx(texts: list[str]) -> list[list[float]]:
        captured_batches.append(texts)
        return [[0.0, 1.0] for _ in texts]

    monkeypatch.setattr(service, "_embed_batch_mlx", _fake_embed_batch_mlx)

    result = asyncio.run(service.embed_batch(["alpha", "beta"], is_query=True))

    assert len(result) == 2
    assert result[0] == [0.0, 1.0]
    assert result[1] == [0.0, 1.0]
    assert len(captured_batches) == 1
    assert all(
        text.startswith(f"Instruct: {search_embedding.QWEN3_QUERY_INSTRUCTION}\nQuery:")
        for text in captured_batches[0]
    )


def test_embed_batch_non_apple_uses_fastembed_path(monkeypatch) -> None:
    monkeypatch.setattr(search_embedding, "IS_APPLE_SILICON", False)
    service = search_embedding.SearchEmbeddingService(cache_only=True)
    service._initialized = True

    captured_batches: list[list[str]] = []

    async def _fake_embed_batch_fastembed(texts: list[str]) -> list[list[float]]:
        captured_batches.append(texts)
        return [[1.0, 2.0] for _ in texts]

    monkeypatch.setattr(service, "_embed_batch_fastembed", _fake_embed_batch_fastembed)

    # Include empty/whitespace value to validate filtering and position mapping.
    result = asyncio.run(service.embed_batch(["hello", "   ", "world"], is_query=True))

    assert len(captured_batches) == 1
    assert captured_batches[0] == ["hello", "world"]
    assert result[0] == [1.0, 2.0]
    assert result[1] == [0.0] * search_embedding.SEARCH_EMBEDDING_DIMENSION
    assert result[2] == [1.0, 2.0]
