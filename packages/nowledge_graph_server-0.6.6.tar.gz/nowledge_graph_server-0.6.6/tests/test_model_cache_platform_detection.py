from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nowledge_graph_server.utils import model_cache


def test_check_models_exist_detects_onnx_embedding_on_non_apple_platform(
    monkeypatch,
    tmp_path: Path,
) -> None:
    cache_root = tmp_path / "cache"
    manager = model_cache.ModelCacheManager(cache_dir=str(cache_root))

    # Simulate Intel macOS / non-Apple-Silicon behavior.
    monkeypatch.setattr(model_cache, "IS_APPLE_SILICON", False)
    monkeypatch.setattr(model_cache, "IS_INTEL_MAC", True)
    monkeypatch.setattr(model_cache, "IS_ONNX_PLATFORM", True)

    onnx_path = manager.embedding_cache_dir / "BAAI" / "bge-m3" / "onnx"
    onnx_path.mkdir(parents=True)
    (onnx_path / "model.onnx").write_bytes(b"onnx")

    status = manager.check_models_exist()

    assert status["embedding"] is True
