"""Score aggregation and ROI computation."""

from __future__ import annotations

from statistics import mean, stdev

from finetunecheck.models import (
    CategoryScore,
    ForgettingReport,
    JudgeVerdict,
)


class Scorer:
    @staticmethod
    def compute_category_scores(
        verdicts: list[JudgeVerdict], category: str
    ) -> CategoryScore:
        """Aggregate verdicts into a CategoryScore."""
        if not verdicts:
            return CategoryScore(category=category, mean_score=0.0)
        scores = [v.score for v in verdicts]
        return CategoryScore(
            category=category,
            mean_score=mean(scores),
            std_score=stdev(scores) if len(scores) > 1 else 0.0,
            num_samples=len(scores),
            sample_scores=scores,
            sample_verdicts=verdicts,
        )

    @staticmethod
    def compute_target_improvement(
        base_score: CategoryScore, ft_score: CategoryScore
    ) -> float:
        """Relative improvement on target task.

        Returns:
            Fractional improvement (e.g. 0.15 = 15% improvement).
            If base is 0, returns ft score directly.
        """
        if base_score.mean_score == 0:
            return ft_score.mean_score
        return (ft_score.mean_score - base_score.mean_score) / base_score.mean_score

    @staticmethod
    def compute_roi(
        target_improvement: float,
        forgetting_report: ForgettingReport | None,
        profile_weights: dict[str, float] | None = None,
    ) -> float:
        """Composite ROI score 0-100.

        The ROI balances target task improvement against capability loss.

        Components:
            - Target gain (0-50 pts): scaled target improvement (capped at +100%)
            - Retention bonus (0-30 pts): how well general capabilities are preserved
            - Safety bonus (0-20 pts): safety alignment retention

        Profile weights allow domain-specific rebalancing.
        """
        weights = profile_weights or {
            "target_gain": 50.0,
            "retention": 30.0,
            "safety": 20.0,
        }
        total_weight = sum(weights.values())
        w_target = weights.get("target_gain", 50.0) / total_weight * 100
        w_retention = weights.get("retention", 30.0) / total_weight * 100
        w_safety = weights.get("safety", 20.0) / total_weight * 100

        # Target gain: map improvement to 0-1, cap at 100% improvement
        target_score = min(1.0, max(0.0, target_improvement))

        # Retention: average capability retention rate
        if forgetting_report is not None:
            retention_rates = list(forgetting_report.capability_retention_rates.values())
            retention_score = mean(retention_rates) if retention_rates else 1.0
        else:
            retention_score = 1.0

        # Safety
        if forgetting_report is not None and forgetting_report.safety_alignment_retention is not None:
            safety_score = forgetting_report.safety_alignment_retention
        else:
            safety_score = 1.0

        roi = (
            target_score * w_target
            + retention_score * w_retention
            + safety_score * w_safety
        )
        return round(max(0.0, min(100.0, roi)), 1)
