"""
Bootstrapped Static PPMI Synonym Dictionary for antaris-memory v4.5.0.

Provides a lightweight, zero-dependency synonym expansion layer backed by a
hand-curated Positive Pointwise Mutual Information (PPMI)-inspired static
dictionary.  Strength values (0.0–1.0) approximate the co-occurrence weight
between source and related terms as they would appear in a domain-specific
corpus.

This is Layer 6 of the antaris-memory search enhancement stack.
"""

import re
from typing import Dict, List, Set, Tuple


# ---------------------------------------------------------------------------
# PPMI Dictionary
# source_word → [(related_word, strength), ...]
# Strength: 0.9 = near-synonym, 0.7 = strongly related, 0.5 = related,
#           0.3 = loosely related (default threshold)
# ---------------------------------------------------------------------------

_PPMI_DICT: Dict[str, List[Tuple[str, float]]] = {

    # ── Financial / Money ────────────────────────────────────────────────────
    "money": [("cash", 0.9), ("funds", 0.85), ("capital", 0.8), ("currency", 0.75),
              ("budget", 0.7), ("finance", 0.65), ("wealth", 0.6), ("income", 0.55)],
    "budget": [("spending", 0.9), ("cost", 0.85), ("allocation", 0.8), ("expense", 0.8),
               ("estimate", 0.65), ("forecast", 0.6), ("plan", 0.55), ("finance", 0.5)],
    "expense": [("cost", 0.9), ("spending", 0.85), ("outlay", 0.8), ("payment", 0.75),
                ("bill", 0.7), ("charge", 0.65), ("fee", 0.6), ("expenditure", 0.6)],
    "invoice": [("bill", 0.9), ("receipt", 0.85), ("payment", 0.8), ("charge", 0.75),
                ("statement", 0.65), ("transaction", 0.6), ("purchase", 0.55)],
    "revenue": [("income", 0.9), ("earnings", 0.85), ("profit", 0.8), ("sales", 0.75),
                ("turnover", 0.7), ("proceeds", 0.6), ("gross", 0.5)],
    "profit": [("earnings", 0.9), ("revenue", 0.8), ("margin", 0.75), ("gain", 0.7),
               ("return", 0.65), ("surplus", 0.6), ("income", 0.55)],
    "tax": [("taxation", 0.9), ("levy", 0.75), ("duty", 0.7), ("filing", 0.65),
            ("irs", 0.6), ("withholding", 0.55), ("deduction", 0.5), ("refund", 0.45)],
    "salary": [("pay", 0.9), ("compensation", 0.85), ("wage", 0.85), ("earnings", 0.8),
               ("income", 0.75), ("remuneration", 0.7), ("paycheck", 0.65)],
    "investment": [("portfolio", 0.8), ("asset", 0.75), ("equity", 0.7), ("stock", 0.65),
                   ("fund", 0.6), ("return", 0.55), ("capital", 0.5)],
    "loan": [("debt", 0.85), ("credit", 0.8), ("mortgage", 0.75), ("borrowing", 0.75),
             ("repayment", 0.7), ("interest", 0.65), ("principal", 0.6)],
    "payment": [("transaction", 0.85), ("transfer", 0.8), ("charge", 0.75),
                ("remittance", 0.7), ("settlement", 0.65), ("pay", 0.6)],
    "subscription": [("plan", 0.8), ("billing", 0.75), ("recurring", 0.7),
                     ("membership", 0.65), ("license", 0.6), ("tier", 0.55)],
    "cash": [("money", 0.9), ("currency", 0.8), ("funds", 0.75), ("liquidity", 0.65),
             ("payment", 0.55), ("coin", 0.5)],
    "discount": [("coupon", 0.8), ("promo", 0.75), ("deal", 0.7), ("reduction", 0.65),
                 ("markdown", 0.6), ("offer", 0.55), ("savings", 0.5)],
    "refund": [("return", 0.85), ("reimbursement", 0.8), ("credit", 0.7),
               ("chargeback", 0.65), ("reversal", 0.6), ("repayment", 0.55)],

    # ── Technical / Infrastructure ────────────────────────────────────────────
    "server": [("host", 0.85), ("machine", 0.8), ("instance", 0.8), ("node", 0.75),
               ("backend", 0.7), ("cluster", 0.65), ("infrastructure", 0.6)],
    "database": [("db", 0.95), ("storage", 0.75), ("datastore", 0.8), ("sql", 0.7),
                 ("postgres", 0.65), ("mysql", 0.65), ("mongo", 0.6), ("schema", 0.55)],
    "api": [("endpoint", 0.9), ("interface", 0.75), ("service", 0.7), ("rest", 0.65),
            ("graphql", 0.6), ("webhook", 0.55), ("integration", 0.5)],
    "deploy": [("deployment", 0.95), ("release", 0.85), ("ship", 0.75), ("push", 0.7),
               ("launch", 0.65), ("rollout", 0.65), ("publish", 0.6)],
    "bug": [("issue", 0.9), ("defect", 0.85), ("error", 0.8), ("flaw", 0.75),
            ("glitch", 0.7), ("regression", 0.65), ("fix", 0.6), ("patch", 0.55)],
    "error": [("exception", 0.85), ("failure", 0.8), ("bug", 0.75), ("fault", 0.7),
              ("crash", 0.65), ("problem", 0.6), ("issue", 0.55)],
    "performance": [("latency", 0.85), ("speed", 0.8), ("throughput", 0.75),
                    ("response", 0.7), ("optimize", 0.65), ("benchmark", 0.6), ("slow", 0.55)],
    "cache": [("redis", 0.75), ("memcached", 0.7), ("ttl", 0.65), ("invalidation", 0.6),
              ("hit", 0.55), ("miss", 0.5), ("warm", 0.45)],
    "kubernetes": [("k8s", 0.95), ("pod", 0.85), ("cluster", 0.8), ("helm", 0.75),
                   ("container", 0.7), ("orchestration", 0.65), ("namespace", 0.6)],
    "docker": [("container", 0.9), ("image", 0.8), ("dockerfile", 0.85), ("registry", 0.7),
               ("compose", 0.65), ("build", 0.6)],
    "cloud": [("aws", 0.75), ("gcp", 0.75), ("azure", 0.75), ("infrastructure", 0.7),
              ("hosting", 0.65), ("saas", 0.6), ("paas", 0.6), ("iaas", 0.55)],
    "code": [("repository", 0.8), ("codebase", 0.85), ("source", 0.75), ("script", 0.65),
             ("program", 0.6), ("implementation", 0.55)],
    "repository": [("repo", 0.95), ("git", 0.85), ("codebase", 0.8), ("branch", 0.7),
                   ("source", 0.65), ("github", 0.65), ("gitlab", 0.65)],
    "authentication": [("auth", 0.95), ("login", 0.85), ("sso", 0.75), ("oauth", 0.75),
                       ("jwt", 0.7), ("token", 0.65), ("session", 0.6), ("2fa", 0.55)],
    "security": [("vulnerability", 0.8), ("threat", 0.75), ("risk", 0.7), ("patch", 0.65),
                 ("pentest", 0.6), ("audit", 0.6), ("encryption", 0.55), ("firewall", 0.5)],
    "pipeline": [("cicd", 0.9), ("workflow", 0.8), ("build", 0.75), ("deploy", 0.7),
                 ("automation", 0.65), ("github-actions", 0.6), ("jenkins", 0.55)],
    "microservice": [("service", 0.85), ("api", 0.75), ("backend", 0.7), ("container", 0.65),
                     ("architecture", 0.6), ("endpoint", 0.55)],
    "config": [("configuration", 0.95), ("setting", 0.85), ("parameter", 0.8),
               ("option", 0.75), ("environment", 0.65), ("yaml", 0.6), ("dotenv", 0.55)],
    "log": [("logging", 0.95), ("trace", 0.8), ("debug", 0.75), ("audit", 0.65),
            ("event", 0.6), ("record", 0.55)],
    "network": [("dns", 0.75), ("firewall", 0.7), ("vpn", 0.7), ("subnet", 0.65),
                ("ip", 0.65), ("bandwidth", 0.6), ("proxy", 0.55)],
    "storage": [("disk", 0.8), ("s3", 0.75), ("bucket", 0.7), ("backup", 0.65),
                ("volume", 0.6), ("filesystem", 0.55), ("archive", 0.5)],
    "monitoring": [("observability", 0.85), ("alerting", 0.8), ("metrics", 0.75),
                   ("dashboard", 0.65), ("prometheus", 0.6), ("grafana", 0.6), ("pagerduty", 0.55)],
    "testing": [("qa", 0.9), ("test", 0.9), ("validation", 0.75), ("staging", 0.65),
                ("regression", 0.65), ("coverage", 0.6), ("unittest", 0.6)],

    # ── Health / Medical ──────────────────────────────────────────────────────
    "health": [("wellness", 0.85), ("medical", 0.8), ("fitness", 0.75), ("wellbeing", 0.75),
               ("condition", 0.65), ("vitality", 0.6), ("care", 0.55)],
    "doctor": [("physician", 0.9), ("specialist", 0.75), ("clinician", 0.7), ("gp", 0.7),
               ("practitioner", 0.65), ("medical", 0.6), ("clinic", 0.55)],
    "medication": [("medicine", 0.9), ("drug", 0.8), ("prescription", 0.85), ("treatment", 0.7),
                   ("pill", 0.65), ("dose", 0.65), ("dosage", 0.6), ("therapy", 0.55)],
    "appointment": [("booking", 0.85), ("visit", 0.8), ("consultation", 0.75), ("checkup", 0.7),
                    ("schedule", 0.65), ("meeting", 0.6), ("session", 0.55)],
    "symptom": [("sign", 0.75), ("condition", 0.7), ("complaint", 0.65), ("indicator", 0.6),
                ("feeling", 0.55), ("onset", 0.5)],
    "therapy": [("treatment", 0.9), ("counseling", 0.8), ("rehab", 0.75), ("session", 0.65),
                ("intervention", 0.6), ("healing", 0.55), ("recovery", 0.5)],
    "fitness": [("exercise", 0.9), ("workout", 0.9), ("training", 0.8), ("health", 0.75),
                ("gym", 0.7), ("sport", 0.65), ("activity", 0.6)],
    "diet": [("nutrition", 0.85), ("eating", 0.8), ("food", 0.75), ("meal", 0.7),
             ("calories", 0.65), ("intake", 0.6), ("weight", 0.55)],
    "sleep": [("rest", 0.85), ("insomnia", 0.7), ("nap", 0.65), ("fatigue", 0.6),
              ("recovery", 0.55), ("circadian", 0.5)],
    "stress": [("anxiety", 0.85), ("pressure", 0.8), ("burnout", 0.75), ("tension", 0.7),
               ("overload", 0.65), ("worry", 0.6), ("fatigue", 0.55)],

    # ── Time / Scheduling ─────────────────────────────────────────────────────
    "deadline": [("due", 0.9), ("duedate", 0.9), ("target", 0.8), ("cutoff", 0.75),
                 ("eta", 0.75), ("timeline", 0.7), ("milestone", 0.65)],
    "meeting": [("call", 0.85), ("sync", 0.85), ("standup", 0.8), ("conference", 0.75),
                ("discussion", 0.7), ("session", 0.65), ("agenda", 0.6)],
    "schedule": [("calendar", 0.9), ("timetable", 0.8), ("plan", 0.75), ("agenda", 0.7),
                 ("routine", 0.65), ("timeline", 0.65), ("booking", 0.6)],
    "calendar": [("schedule", 0.9), ("agenda", 0.8), ("event", 0.75), ("booking", 0.7),
                 ("reminder", 0.65), ("date", 0.6)],
    "reminder": [("alert", 0.85), ("notification", 0.8), ("prompt", 0.75), ("nudge", 0.7),
                 ("ping", 0.65), ("alarm", 0.6), ("follow-up", 0.55)],
    "daily": [("everyday", 0.9), ("routine", 0.8), ("regular", 0.7), ("recurring", 0.65),
              ("morning", 0.6), ("evening", 0.55)],
    "weekly": [("recurring", 0.8), ("regular", 0.75), ("weekly-review", 0.7),
               ("standup", 0.65), ("sprint", 0.6)],
    "today": [("now", 0.85), ("current", 0.75), ("present", 0.7), ("immediate", 0.65),
              ("urgent", 0.55)],
    "urgent": [("priority", 0.85), ("critical", 0.8), ("immediate", 0.8), ("asap", 0.8),
               ("emergency", 0.75), ("pressing", 0.65), ("important", 0.6)],

    # ── Problems / Issues ─────────────────────────────────────────────────────
    "problem": [("issue", 0.9), ("trouble", 0.85), ("challenge", 0.8), ("difficulty", 0.75),
                ("obstacle", 0.7), ("hurdle", 0.65), ("blocker", 0.65)],
    "incident": [("outage", 0.85), ("failure", 0.8), ("disruption", 0.8), ("event", 0.7),
                 ("alert", 0.65), ("postmortem", 0.6), ("downtime", 0.55)],
    "outage": [("downtime", 0.9), ("incident", 0.85), ("disruption", 0.8), ("failure", 0.75),
               ("degradation", 0.7), ("unavailable", 0.65), ("offline", 0.6)],
    "crash": [("failure", 0.85), ("error", 0.8), ("exception", 0.75), ("panic", 0.7),
              ("downtime", 0.65), ("abort", 0.6)],
    "blocker": [("obstacle", 0.85), ("dependency", 0.75), ("impediment", 0.8), ("issue", 0.7),
                ("bottleneck", 0.65), ("blocker", 0.6)],
    "risk": [("threat", 0.85), ("vulnerability", 0.8), ("exposure", 0.75), ("danger", 0.7),
             ("concern", 0.65), ("uncertainty", 0.6)],

    # ── People / Team ─────────────────────────────────────────────────────────
    "team": [("group", 0.85), ("squad", 0.8), ("crew", 0.75), ("staff", 0.75),
             ("colleagues", 0.7), ("members", 0.65), ("department", 0.6)],
    "manager": [("lead", 0.85), ("boss", 0.8), ("supervisor", 0.8), ("director", 0.75),
                ("head", 0.7), ("vp", 0.6), ("executive", 0.55)],
    "engineer": [("developer", 0.9), ("programmer", 0.85), ("coder", 0.8), ("devs", 0.75),
                 ("swe", 0.75), ("sde", 0.7), ("architect", 0.6)],
    "customer": [("client", 0.9), ("user", 0.8), ("account", 0.75), ("tenant", 0.7),
                 ("subscriber", 0.65), ("consumer", 0.65), ("buyer", 0.6)],
    "colleague": [("coworker", 0.95), ("teammate", 0.9), ("collaborator", 0.85),
                  ("associate", 0.75), ("partner", 0.7), ("peer", 0.7)],
    "ceo": [("founder", 0.75), ("executive", 0.8), ("president", 0.75), ("chief", 0.8),
            ("leader", 0.65)],
    "hire": [("recruit", 0.9), ("onboard", 0.8), ("hiring", 0.95), ("candidate", 0.7),
             ("interview", 0.65), ("headcount", 0.6), ("talent", 0.55)],

    # ── Projects / Tasks ─────────────────────────────────────────────────────
    "project": [("initiative", 0.85), ("program", 0.8), ("effort", 0.75), ("work", 0.7),
                ("task", 0.65), ("deliverable", 0.6), ("objective", 0.55)],
    "task": [("todo", 0.9), ("action", 0.85), ("item", 0.8), ("work", 0.75),
             ("ticket", 0.7), ("assignment", 0.65), ("job", 0.6)],
    "sprint": [("iteration", 0.9), ("cycle", 0.8), ("week", 0.65), ("phase", 0.6),
               ("scrum", 0.75), ("agile", 0.7)],
    "milestone": [("goal", 0.85), ("checkpoint", 0.8), ("target", 0.75), ("phase", 0.7),
                  ("deliverable", 0.65), ("release", 0.6)],
    "roadmap": [("plan", 0.85), ("strategy", 0.8), ("vision", 0.75), ("direction", 0.7),
                ("priority", 0.65), ("backlog", 0.6)],
    "backlog": [("queue", 0.85), ("list", 0.75), ("pending", 0.7), ("todo", 0.65),
                ("issues", 0.65), ("tickets", 0.65), ("tasks", 0.6)],
    "priority": [("importance", 0.85), ("urgency", 0.8), ("rank", 0.75), ("critical", 0.7),
                 ("high-priority", 0.65), ("p0", 0.6), ("p1", 0.55)],
    "goal": [("objective", 0.9), ("target", 0.85), ("aim", 0.8), ("purpose", 0.75),
             ("mission", 0.7), ("outcome", 0.65), ("kpi", 0.6)],

    # ── Personal Assistant ────────────────────────────────────────────────────
    "note": [("memo", 0.9), ("record", 0.85), ("entry", 0.8), ("jot", 0.75),
             ("log", 0.7), ("document", 0.6), ("capture", 0.55)],
    "memory": [("recall", 0.85), ("remember", 0.85), ("recollection", 0.8),
               ("reminder", 0.75), ("note", 0.7), ("log", 0.65)],
    "search": [("find", 0.9), ("lookup", 0.9), ("query", 0.85), ("retrieve", 0.8),
               ("locate", 0.75), ("discover", 0.65), ("seek", 0.6)],
    "summary": [("overview", 0.9), ("recap", 0.85), ("digest", 0.8), ("brief", 0.75),
                ("tldr", 0.75), ("synopsis", 0.7), ("highlights", 0.65)],
    "question": [("query", 0.9), ("inquiry", 0.85), ("ask", 0.8), ("request", 0.75),
                 ("prompt", 0.7), ("issue", 0.6)],
    "answer": [("response", 0.9), ("reply", 0.85), ("solution", 0.8), ("result", 0.75),
               ("explanation", 0.7), ("output", 0.65)],
    "help": [("support", 0.9), ("assist", 0.9), ("guide", 0.8), ("advice", 0.75),
             ("tip", 0.7), ("resource", 0.65), ("aid", 0.6)],
    "update": [("change", 0.85), ("revision", 0.8), ("modify", 0.8), ("patch", 0.75),
               ("upgrade", 0.7), ("refresh", 0.65), ("edit", 0.6)],
    "report": [("summary", 0.85), ("document", 0.8), ("analysis", 0.75), ("findings", 0.7),
               ("writeup", 0.7), ("review", 0.65), ("dashboard", 0.6)],
    "plan": [("strategy", 0.85), ("roadmap", 0.8), ("approach", 0.8), ("proposal", 0.75),
             ("blueprint", 0.7), ("design", 0.65), ("outline", 0.6)],
    "idea": [("concept", 0.9), ("thought", 0.85), ("suggestion", 0.8), ("proposal", 0.75),
             ("brainstorm", 0.7), ("insight", 0.65)],
    "research": [("investigation", 0.85), ("study", 0.8), ("exploration", 0.75),
                 ("analysis", 0.7), ("review", 0.65), ("findings", 0.6)],

    # ── Communication ─────────────────────────────────────────────────────────
    "email": [("message", 0.85), ("mail", 0.9), ("notification", 0.7), ("inbox", 0.65),
              ("correspondence", 0.7), ("reply", 0.65), ("thread", 0.6)],
    "message": [("chat", 0.85), ("dm", 0.8), ("text", 0.75), ("notification", 0.7),
                ("reply", 0.65), ("communication", 0.6)],
    "notification": [("alert", 0.9), ("ping", 0.85), ("reminder", 0.8), ("message", 0.75),
                     ("push", 0.7), ("nudge", 0.65)],
    "feedback": [("review", 0.85), ("comment", 0.85), ("critique", 0.8), ("opinion", 0.75),
                 ("rating", 0.7), ("response", 0.65), ("input", 0.6)],
    "announcement": [("notice", 0.85), ("update", 0.8), ("release", 0.75), ("broadcast", 0.7),
                     ("news", 0.65), ("memo", 0.6)],
    "discussion": [("conversation", 0.9), ("talk", 0.85), ("debate", 0.75), ("chat", 0.75),
                   ("dialogue", 0.7), ("thread", 0.65)],

    # ── Work / Productivity ───────────────────────────────────────────────────
    "work": [("job", 0.85), ("task", 0.8), ("effort", 0.75), ("assignment", 0.7),
             ("labor", 0.65), ("employment", 0.65), ("career", 0.6)],
    "meeting-notes": [("recap", 0.9), ("minutes", 0.9), ("summary", 0.85),
                      ("notes", 0.9), ("action-items", 0.8)],
    "decision": [("choice", 0.85), ("resolution", 0.8), ("verdict", 0.75), ("ruling", 0.7),
                 ("agreement", 0.65), ("conclusion", 0.65)],
    "review": [("audit", 0.8), ("assessment", 0.8), ("evaluation", 0.8), ("check", 0.75),
               ("inspection", 0.7), ("feedback", 0.65), ("approval", 0.6)],
    "approval": [("sign-off", 0.9), ("authorization", 0.85), ("greenlight", 0.8),
                 ("confirmation", 0.75), ("accept", 0.7), ("permit", 0.65)],
    "documentation": [("docs", 0.95), ("readme", 0.85), ("wiki", 0.8), ("guide", 0.75),
                      ("spec", 0.7), ("manual", 0.65), ("reference", 0.6)],
    "onboarding": [("setup", 0.85), ("orientation", 0.8), ("getting-started", 0.8),
                   ("training", 0.75), ("introduction", 0.65), ("bootstrap", 0.6)],
    "offboarding": [("departure", 0.85), ("exit", 0.85), ("termination", 0.8),
                    ("transition", 0.75), ("handover", 0.7)],

    # ── Analytics / Data ──────────────────────────────────────────────────────
    "data": [("information", 0.8), ("records", 0.75), ("dataset", 0.85), ("stats", 0.7),
             ("analytics", 0.7), ("metrics", 0.65), ("insights", 0.6)],
    "metric": [("measure", 0.85), ("kpi", 0.85), ("indicator", 0.8), ("statistic", 0.75),
               ("benchmark", 0.7), ("measurement", 0.7)],
    "dashboard": [("report", 0.8), ("visualization", 0.8), ("chart", 0.75), ("graph", 0.7),
                  ("panel", 0.65), ("overview", 0.6)],
    "trend": [("pattern", 0.85), ("trajectory", 0.8), ("direction", 0.75), ("growth", 0.7),
              ("movement", 0.65), ("shift", 0.6)],
    "analysis": [("review", 0.8), ("investigation", 0.8), ("study", 0.75), ("research", 0.7),
                 ("examination", 0.65), ("breakdown", 0.6)],
    "insight": [("finding", 0.85), ("discovery", 0.8), ("observation", 0.75), ("conclusion", 0.7),
                ("learning", 0.65), ("takeaway", 0.65)],

    # ── Legal / Compliance ────────────────────────────────────────────────────
    "contract": [("agreement", 0.9), ("deal", 0.8), ("terms", 0.75), ("sla", 0.7),
                 ("nda", 0.7), ("mou", 0.65), ("legal", 0.6)],
    "compliance": [("regulation", 0.85), ("policy", 0.8), ("audit", 0.75), ("gdpr", 0.7),
                   ("soc2", 0.7), ("legal", 0.65), ("governance", 0.6)],
    "privacy": [("gdpr", 0.8), ("data-protection", 0.85), ("consent", 0.75), ("policy", 0.7),
                ("security", 0.65), ("confidential", 0.6)],

    # ── Travel ────────────────────────────────────────────────────────────────
    "travel": [("trip", 0.9), ("journey", 0.85), ("flight", 0.8), ("itinerary", 0.75),
               ("hotel", 0.7), ("booking", 0.65), ("destination", 0.6)],
    "flight": [("airline", 0.85), ("booking", 0.8), ("departure", 0.75), ("arrival", 0.7),
               ("ticket", 0.75), ("airport", 0.7), ("itinerary", 0.65)],
    "hotel": [("accommodation", 0.9), ("lodging", 0.85), ("booking", 0.8), ("stay", 0.75),
              ("reservation", 0.7), ("room", 0.65), ("hostel", 0.55)],

    # ── Sales / Marketing ─────────────────────────────────────────────────────
    "sales": [("revenue", 0.8), ("deal", 0.75), ("pipeline", 0.75), ("conversion", 0.7),
              ("close", 0.65), ("quota", 0.65), ("crm", 0.6)],
    "marketing": [("campaign", 0.85), ("outreach", 0.8), ("promotion", 0.75), ("brand", 0.7),
                  ("advertising", 0.75), ("seo", 0.65), ("content", 0.6)],
    "lead": [("prospect", 0.9), ("opportunity", 0.8), ("contact", 0.75), ("pipeline", 0.7),
             ("deal", 0.65), ("conversion", 0.6)],
    "conversion": [("sign-up", 0.8), ("acquisition", 0.8), ("sale", 0.75), ("close", 0.7),
                   ("onboarding", 0.65), ("activation", 0.65)],
    "churn": [("attrition", 0.9), ("cancellation", 0.85), ("retention", 0.75),
              ("unsubscribe", 0.7), ("loss", 0.65), ("departure", 0.6)],

    # ── Machine Learning / AI ─────────────────────────────────────────────────
    "model": [("ml", 0.8), ("ai", 0.8), ("llm", 0.75), ("neural-network", 0.7),
              ("algorithm", 0.65), ("training", 0.65), ("inference", 0.6)],
    "training": [("fine-tuning", 0.85), ("learning", 0.8), ("optimization", 0.75),
                 ("dataset", 0.7), ("epoch", 0.65), ("gradient", 0.6)],
    "prompt": [("instruction", 0.8), ("query", 0.75), ("input", 0.75), ("request", 0.7),
               ("template", 0.65), ("system-message", 0.6)],
    "embedding": [("vector", 0.9), ("representation", 0.8), ("encoding", 0.8),
                  ("similarity", 0.75), ("semantic", 0.7)],

    # ── Support / Help ────────────────────────────────────────────────────────
    "ticket": [("issue", 0.85), ("request", 0.8), ("case", 0.8), ("support", 0.75),
               ("task", 0.7), ("bug", 0.65), ("jira", 0.6)],
    "escalation": [("urgent", 0.8), ("priority", 0.75), ("critical", 0.75), ("alert", 0.7),
                   ("pagerduty", 0.65), ("oncall", 0.65)],
    "workaround": [("fix", 0.8), ("solution", 0.8), ("patch", 0.75), ("mitigation", 0.75),
                   ("hack", 0.65), ("temporary", 0.6)],

    # ── Personal ──────────────────────────────────────────────────────────────
    "birthday": [("anniversary", 0.75), ("celebration", 0.7), ("party", 0.65),
                 ("gift", 0.6), ("date", 0.55)],
    "family": [("personal", 0.75), ("home", 0.7), ("relative", 0.65), ("household", 0.6),
               ("kids", 0.55), ("spouse", 0.55)],
    "hobby": [("interest", 0.85), ("activity", 0.8), ("passion", 0.75), ("pastime", 0.8),
              ("leisure", 0.7), ("recreation", 0.65)],
    "preference": [("like", 0.85), ("want", 0.8), ("favorite", 0.8), ("choice", 0.75),
                   ("setting", 0.7), ("option", 0.65)],
    "goal": [("objective", 0.9), ("target", 0.85), ("aim", 0.8), ("aspiration", 0.75),
             ("resolution", 0.7), ("ambition", 0.65)],
    "habit": [("routine", 0.9), ("pattern", 0.8), ("behavior", 0.75), ("practice", 0.75),
              ("custom", 0.65), ("ritual", 0.65)],
    "mood": [("feeling", 0.85), ("emotion", 0.85), ("state", 0.75), ("attitude", 0.7),
             ("vibe", 0.65), ("tone", 0.6)],

    # ── Additional Financial ───────────────────────────────────────────────────
    "spending": [("cost", 0.9), ("expenditure", 0.85), ("expense", 0.85), ("outlay", 0.8),
                 ("budget", 0.75), ("bill", 0.65), ("payment", 0.6)],
    "cost": [("price", 0.9), ("expense", 0.85), ("charge", 0.8), ("fee", 0.75),
             ("rate", 0.7), ("budget", 0.65), ("expenditure", 0.65)],
    "price": [("cost", 0.9), ("rate", 0.85), ("fee", 0.8), ("charge", 0.75),
              ("value", 0.65), ("quote", 0.6), ("estimate", 0.55)],
    "fee": [("charge", 0.9), ("cost", 0.85), ("rate", 0.8), ("price", 0.75),
            ("payment", 0.7), ("dues", 0.65), ("bill", 0.6)],
    "bill": [("invoice", 0.9), ("statement", 0.85), ("charge", 0.8), ("expense", 0.75),
             ("payment", 0.7), ("fee", 0.65)],
    "finance": [("financial", 0.9), ("money", 0.8), ("accounting", 0.8), ("budget", 0.75),
                ("economics", 0.7), ("funds", 0.65)],
    "accounting": [("finance", 0.85), ("bookkeeping", 0.85), ("audit", 0.8), ("ledger", 0.75),
                   ("reconciliation", 0.7), ("expense", 0.65)],
    "transaction": [("payment", 0.9), ("transfer", 0.85), ("purchase", 0.8), ("sale", 0.75),
                    ("exchange", 0.7), ("charge", 0.65)],
    "bank": [("account", 0.8), ("financial", 0.75), ("transfer", 0.7), ("deposit", 0.8),
             ("withdraw", 0.75), ("balance", 0.7)],
    "savings": [("fund", 0.8), ("reserve", 0.8), ("deposit", 0.75), ("capital", 0.7),
                ("balance", 0.65), ("nest-egg", 0.6)],
    "payroll": [("salary", 0.9), ("wages", 0.9), ("compensation", 0.85), ("pay", 0.85),
                ("hr", 0.65), ("direct-deposit", 0.6)],
    "stock": [("equity", 0.85), ("share", 0.85), ("investment", 0.8), ("market", 0.75),
              ("portfolio", 0.7), ("ticker", 0.6)],
    "fund": [("capital", 0.8), ("pool", 0.75), ("reserve", 0.75), ("endowment", 0.65),
             ("investment", 0.7), ("money", 0.6)],
    "forecast": [("projection", 0.9), ("estimate", 0.85), ("prediction", 0.8), ("outlook", 0.75),
                 ("plan", 0.65), ("budget", 0.65)],
    "quote": [("estimate", 0.85), ("bid", 0.8), ("proposal", 0.75), ("price", 0.8),
              ("offer", 0.7), ("tender", 0.6)],

    # ── Additional Technical ───────────────────────────────────────────────────
    "endpoint": [("api", 0.9), ("url", 0.85), ("route", 0.8), ("path", 0.75),
                 ("interface", 0.7), ("resource", 0.65)],
    "service": [("api", 0.8), ("backend", 0.8), ("microservice", 0.85), ("application", 0.75),
                ("system", 0.7), ("component", 0.65)],
    "application": [("app", 0.95), ("software", 0.85), ("program", 0.8), ("service", 0.75),
                    ("system", 0.7), ("tool", 0.65)],
    "software": [("application", 0.85), ("tool", 0.8), ("program", 0.8), ("system", 0.75),
                 ("platform", 0.7), ("product", 0.65)],
    "architecture": [("design", 0.85), ("structure", 0.8), ("system", 0.75), ("pattern", 0.7),
                     ("blueprint", 0.7), ("diagram", 0.6)],
    "integration": [("connector", 0.8), ("api", 0.75), ("sync", 0.75), ("webhook", 0.7),
                    ("plugin", 0.65), ("interface", 0.65)],
    "webhook": [("callback", 0.9), ("endpoint", 0.8), ("event", 0.75), ("trigger", 0.75),
                ("notification", 0.7), ("api", 0.65)],
    "query": [("search", 0.85), ("request", 0.8), ("lookup", 0.8), ("sql", 0.75),
              ("filter", 0.7), ("fetch", 0.65)],
    "schema": [("model", 0.8), ("structure", 0.8), ("definition", 0.75), ("database", 0.7),
               ("table", 0.7), ("design", 0.65)],
    "migration": [("upgrade", 0.8), ("update", 0.8), ("transfer", 0.75), ("database", 0.7),
                  ("change", 0.65), ("version", 0.6)],
    "version": [("release", 0.85), ("tag", 0.75), ("changelog", 0.7), ("update", 0.7),
                ("upgrade", 0.65), ("semver", 0.6)],
    "release": [("deployment", 0.85), ("version", 0.85), ("launch", 0.8), ("publish", 0.75),
                ("ship", 0.7), ("rollout", 0.7)],
    "feature": [("enhancement", 0.85), ("functionality", 0.8), ("capability", 0.75),
                ("improvement", 0.7), ("addition", 0.65), ("requirement", 0.6)],
    "dependency": [("library", 0.8), ("package", 0.85), ("module", 0.8), ("requirement", 0.75),
                   ("import", 0.7), ("blocker", 0.6)],
    "package": [("library", 0.85), ("module", 0.85), ("dependency", 0.8), ("npm", 0.7),
                ("pip", 0.7), ("bundle", 0.65)],
    "script": [("code", 0.85), ("automation", 0.8), ("program", 0.75), ("command", 0.7),
               ("tool", 0.65), ("executable", 0.6)],
    "cli": [("command-line", 0.95), ("terminal", 0.85), ("shell", 0.85), ("script", 0.7),
            ("tool", 0.65), ("interface", 0.6)],
    "token": [("credential", 0.8), ("key", 0.8), ("secret", 0.8), ("authentication", 0.75),
              ("jwt", 0.75), ("api-key", 0.7)],
    "encryption": [("security", 0.8), ("tls", 0.8), ("ssl", 0.8), ("cipher", 0.75),
                   ("crypto", 0.75), ("hash", 0.7)],
    "vulnerability": [("cve", 0.9), ("exploit", 0.85), ("weakness", 0.8), ("flaw", 0.8),
                      ("threat", 0.75), ("risk", 0.7), ("patch", 0.65)],
    "patch": [("fix", 0.9), ("update", 0.85), ("hotfix", 0.9), ("bugfix", 0.9),
              ("security", 0.7), ("version", 0.65)],
    "port": [("network", 0.75), ("tcp", 0.7), ("socket", 0.7), ("service", 0.65),
             ("endpoint", 0.65), ("listener", 0.6)],
    "ssl": [("tls", 0.95), ("certificate", 0.85), ("https", 0.8), ("encryption", 0.8),
            ("security", 0.75), ("domain", 0.6)],
    "cpu": [("processor", 0.9), ("compute", 0.8), ("performance", 0.75), ("utilization", 0.7),
            ("core", 0.65), ("load", 0.65)],
    "memory": [("ram", 0.85), ("heap", 0.75), ("storage", 0.7), ("allocation", 0.65),
               ("gc", 0.6), ("leak", 0.6)],
    "queue": [("backlog", 0.8), ("buffer", 0.75), ("list", 0.7), ("task", 0.65),
              ("job", 0.65), ("pending", 0.6)],
    "event": [("trigger", 0.8), ("action", 0.75), ("notification", 0.7), ("webhook", 0.7),
              ("incident", 0.65), ("signal", 0.6)],
    "latency": [("delay", 0.9), ("lag", 0.85), ("response-time", 0.85), ("performance", 0.8),
                ("slow", 0.75), ("throughput", 0.65)],
    "uptime": [("availability", 0.9), ("sla", 0.8), ("reliability", 0.85), ("uptime", 0.9),
               ("downtime", 0.8), ("incident", 0.65)],

    # ── Additional Health ──────────────────────────────────────────────────────
    "wellness": [("health", 0.9), ("wellbeing", 0.9), ("fitness", 0.8), ("mental-health", 0.75),
                 ("balance", 0.65), ("care", 0.6)],
    "exercise": [("workout", 0.95), ("fitness", 0.9), ("training", 0.85), ("activity", 0.8),
                 ("run", 0.75), ("gym", 0.7)],
    "nutrition": [("diet", 0.9), ("food", 0.8), ("eating", 0.8), ("health", 0.75),
                  ("vitamins", 0.65), ("supplements", 0.65)],
    "insurance": [("coverage", 0.9), ("policy", 0.85), ("plan", 0.8), ("benefit", 0.75),
                  ("premium", 0.7), ("claim", 0.65)],
    "prescription": [("medication", 0.9), ("drug", 0.85), ("medicine", 0.85), ("pharmacy", 0.75),
                     ("dose", 0.7), ("doctor", 0.65)],

    # ── Additional People ──────────────────────────────────────────────────────
    "founder": [("ceo", 0.8), ("entrepreneur", 0.85), ("cofounder", 0.9), ("executive", 0.75),
                ("owner", 0.7), ("visionary", 0.65)],
    "designer": [("ux", 0.85), ("ui", 0.85), ("product", 0.75), ("creative", 0.7),
                 ("graphic", 0.65), ("artist", 0.6)],
    "analyst": [("data", 0.8), ("researcher", 0.75), ("business", 0.75), ("insights", 0.7),
                ("reporting", 0.65), ("metrics", 0.65)],
    "stakeholder": [("executive", 0.8), ("sponsor", 0.8), ("partner", 0.75), ("client", 0.75),
                    ("decision-maker", 0.75), ("owner", 0.65)],
    "vendor": [("supplier", 0.9), ("partner", 0.8), ("contractor", 0.75), ("provider", 0.8),
               ("third-party", 0.75), ("outsource", 0.7)],
    "contractor": [("freelancer", 0.9), ("consultant", 0.85), ("vendor", 0.75), ("hire", 0.7),
                   ("outsource", 0.75), ("contract", 0.7)],
    "intern": [("trainee", 0.85), ("student", 0.75), ("junior", 0.7), ("hire", 0.65),
               ("apprentice", 0.8)],
    "user": [("customer", 0.85), ("member", 0.8), ("account", 0.75), ("visitor", 0.7),
             ("person", 0.65), ("individual", 0.6)],

    # ── Additional Projects / Tasks ────────────────────────────────────────────
    "ticket": [("issue", 0.9), ("task", 0.85), ("request", 0.8), ("bug", 0.75),
               ("story", 0.75), ("jira", 0.7), ("linear", 0.65)],
    "epic": [("initiative", 0.85), ("project", 0.8), ("theme", 0.75), ("objective", 0.7),
             ("stories", 0.7), ("roadmap", 0.65)],
    "standup": [("daily", 0.85), ("sync", 0.85), ("scrum", 0.8), ("meeting", 0.75),
                ("update", 0.7), ("check-in", 0.7)],
    "retrospective": [("retro", 0.95), ("review", 0.85), ("reflection", 0.8), ("feedback", 0.75),
                      ("improvement", 0.7), ("lessons-learned", 0.7)],
    "launch": [("release", 0.9), ("deploy", 0.85), ("ship", 0.85), ("go-live", 0.8),
               ("rollout", 0.8), ("publish", 0.75)],
    "demo": [("presentation", 0.85), ("showcase", 0.85), ("prototype", 0.8), ("preview", 0.75),
             ("pitch", 0.7), ("walkthrough", 0.7)],

    # ── Additional Personal Assistant ──────────────────────────────────────────
    "todo": [("task", 0.9), ("action-item", 0.9), ("item", 0.8), ("checklist", 0.8),
             ("reminder", 0.75), ("backlog", 0.65)],
    "checklist": [("list", 0.9), ("todo", 0.85), ("items", 0.8), ("tasks", 0.8),
                  ("steps", 0.75), ("procedure", 0.65)],
    "tag": [("label", 0.9), ("category", 0.85), ("keyword", 0.8), ("marker", 0.75),
            ("filter", 0.7), ("annotation", 0.65)],
    "category": [("type", 0.85), ("group", 0.8), ("label", 0.8), ("domain", 0.75),
                 ("class", 0.7), ("tag", 0.7)],
    "context": [("background", 0.85), ("information", 0.8), ("situation", 0.75),
                ("detail", 0.7), ("setting", 0.65), ("scope", 0.6)],
    "link": [("url", 0.9), ("resource", 0.8), ("reference", 0.8), ("bookmark", 0.75),
             ("shortcut", 0.65), ("connection", 0.65)],
    "conversation": [("chat", 0.9), ("discussion", 0.85), ("dialogue", 0.85), ("thread", 0.8),
                     ("exchange", 0.75), ("session", 0.65)],
    "session": [("conversation", 0.8), ("meeting", 0.75), ("period", 0.7), ("instance", 0.65),
                ("context", 0.65), ("window", 0.6)],
    "notification": [("alert", 0.9), ("ping", 0.85), ("reminder", 0.85), ("push", 0.75),
                     ("message", 0.7), ("nudge", 0.7)],
    "action": [("task", 0.85), ("step", 0.8), ("activity", 0.8), ("item", 0.75),
               ("todo", 0.75), ("operation", 0.65)],
    "keyword": [("term", 0.85), ("tag", 0.8), ("label", 0.75), ("search-term", 0.8),
                ("phrase", 0.7), ("token", 0.65)],
    "template": [("pattern", 0.8), ("boilerplate", 0.85), ("layout", 0.75), ("format", 0.8),
                 ("structure", 0.7), ("draft", 0.65)],
    "draft": [("wip", 0.8), ("version", 0.75), ("work-in-progress", 0.9), ("outline", 0.75),
              ("sketch", 0.7), ("prototype", 0.65)],
    "archive": [("store", 0.8), ("backup", 0.75), ("history", 0.75), ("record", 0.7),
                ("preserve", 0.65), ("past", 0.6)],

    # ── Additional Communication ───────────────────────────────────────────────
    "slack": [("messaging", 0.85), ("chat", 0.85), ("dm", 0.8), ("workspace", 0.75),
              ("channel", 0.75), ("notification", 0.7)],
    "discord": [("chat", 0.85), ("messaging", 0.8), ("server", 0.75), ("channel", 0.75),
                ("community", 0.7), ("voice", 0.65)],
    "thread": [("discussion", 0.85), ("conversation", 0.85), ("reply", 0.8), ("topic", 0.75),
               ("channel", 0.65), ("email", 0.6)],
    "reply": [("response", 0.9), ("answer", 0.85), ("follow-up", 0.8), ("message", 0.75),
              ("feedback", 0.65), ("react", 0.6)],
    "mention": [("tag", 0.8), ("ping", 0.85), ("notify", 0.8), ("reference", 0.75),
                ("alert", 0.7), ("notification", 0.65)],
    "broadcast": [("announcement", 0.9), ("message", 0.8), ("send", 0.75), ("publish", 0.75),
                  ("notify", 0.7), ("share", 0.65)],

    # ── Additional Analytics ───────────────────────────────────────────────────
    "kpi": [("metric", 0.9), ("indicator", 0.85), ("measure", 0.8), ("goal", 0.75),
            ("target", 0.75), ("performance", 0.7)],
    "visualization": [("chart", 0.9), ("graph", 0.9), ("dashboard", 0.85), ("plot", 0.8),
                      ("report", 0.75), ("display", 0.7)],
    "benchmark": [("baseline", 0.85), ("standard", 0.8), ("comparison", 0.75), ("reference", 0.75),
                  ("performance", 0.7), ("test", 0.65)],
    "segment": [("cohort", 0.85), ("group", 0.8), ("subset", 0.8), ("audience", 0.75),
                ("filter", 0.7), ("partition", 0.65)],
    "retention": [("churn", 0.8), ("engagement", 0.8), ("loyalty", 0.75), ("stickiness", 0.75),
                  ("renewal", 0.7), ("subscription", 0.65)],

    # ── Additional Work / Productivity ────────────────────────────────────────
    "agenda": [("plan", 0.85), ("schedule", 0.85), ("meeting-notes", 0.8), ("items", 0.75),
               ("objectives", 0.7), ("topics", 0.7)],
    "postmortem": [("incident-review", 0.9), ("retrospective", 0.85), ("analysis", 0.8),
                   ("report", 0.75), ("follow-up", 0.7), ("lessons-learned", 0.7)],
    "workflow": [("process", 0.9), ("procedure", 0.85), ("pipeline", 0.8), ("automation", 0.75),
                 ("flow", 0.75), ("steps", 0.7)],
    "process": [("workflow", 0.9), ("procedure", 0.85), ("steps", 0.8), ("method", 0.75),
                ("approach", 0.7), ("system", 0.65)],
    "strategy": [("plan", 0.9), ("approach", 0.85), ("direction", 0.8), ("vision", 0.75),
                 ("initiative", 0.7), ("objective", 0.65)],
    "initiative": [("project", 0.85), ("program", 0.85), ("effort", 0.8), ("strategy", 0.75),
                   ("campaign", 0.7), ("objective", 0.65)],
    "deliverable": [("output", 0.85), ("artifact", 0.8), ("product", 0.75), ("milestone", 0.75),
                    ("result", 0.7), ("item", 0.65)],
    "handover": [("transition", 0.9), ("handoff", 0.95), ("transfer", 0.85), ("offboarding", 0.75),
                 ("documentation", 0.7), ("knowledge-transfer", 0.7)],
    "standup": [("daily", 0.85), ("meeting", 0.8), ("scrum", 0.8), ("sync", 0.75),
                ("check-in", 0.75), ("update", 0.7)],
}


# Stopwords to skip during expansion
_STOPWORDS: frozenset = frozenset({
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'need', 'dare', 'ought',
    'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from',
    'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
    'between', 'out', 'off', 'over', 'under', 'again', 'further', 'then',
    'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both',
    'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
    'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just',
    'don', 'now', 'and', 'but', 'or', 'if', 'while', 'that', 'this',
    'it', 'its', 'he', 'she', 'they', 'them', 'his', 'her', 'their',
    'what', 'which', 'who', 'whom', 'these', 'those', 'am', 'about',
    'up', 'down', 'we', 'our', 'you', 'your', 'my', 'me', 'i', 'much',
    'get', 'got', 'give', 'make', 'take', 'let', 'put', 'set',
})


def _tokenize(text: str) -> List[str]:
    """Lightweight tokeniser — splits on non-word chars, filters short/stop tokens."""
    tokens = re.findall(r'\w{2,}', text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


class PPMIBootstrap:
    """Bootstrapped Static PPMI Synonym Dictionary.

    Provides lightweight query expansion using a hand-curated, PPMI-inspired
    static dictionary covering 200+ source words across financial, technical,
    health, time, problems, people, projects, and personal assistant domains.

    Strength values (0.0–1.0) reflect approximate co-occurrence weight.
    All operations are O(1) or O(n) on the number of tokens — zero I/O,
    zero external dependencies.

    Usage::

        ppmi = PPMIBootstrap()

        # Get related words above a strength threshold
        ppmi.related("budget")          # → ["spending", "cost", "allocation", ...]
        ppmi.related("budget", 0.8)     # → ["spending", "cost", "allocation"]

        # Expand a query string
        ppmi.expand_query("server error")
        # → "server error host machine instance node backend ..."
    """

    def __init__(self) -> None:
        self._dict: Dict[str, List[Tuple[str, float]]] = _PPMI_DICT

    # ── Public API ────────────────────────────────────────────────────────────

    def related(self, word: str, threshold: float = 0.3) -> List[str]:
        """Return related words above the given strength threshold.

        Words are returned in descending strength order.

        Args:
            word: Source word to look up (case-insensitive).
            threshold: Minimum strength (inclusive). Default 0.3.

        Returns:
            List of related words (strings), sorted by strength descending.
            Returns an empty list if the word is not in the dictionary.
        """
        word = word.lower().strip()
        entries = self._dict.get(word, [])
        filtered = [(w, s) for w, s in entries if s >= threshold]
        filtered.sort(key=lambda x: x[1], reverse=True)
        return [w for w, _ in filtered]

    def expand_query(self, query: str, max_per_word: int = 3) -> str:
        """Expand a query string by appending PPMI-related terms.

        For each meaningful token in the query, up to ``max_per_word`` related
        terms (above the default threshold of 0.3) are appended.  The original
        query is preserved verbatim; no duplicates are added.

        Args:
            query: Raw query string (may contain punctuation, mixed case).
            max_per_word: Maximum number of related terms to add per source token.
                          Default 3.

        Returns:
            The original query string with related terms appended, or the
            original query unchanged if no expansions are found.
        """
        tokens = _tokenize(query)
        existing: Set[str] = set(_tokenize(query))  # track all terms already in query
        additions: List[str] = []

        for token in tokens:
            count = 0
            for related_word in self.related(token):  # already sorted by strength desc
                if count >= max_per_word:
                    break
                if related_word not in existing and related_word not in _STOPWORDS:
                    existing.add(related_word)
                    additions.append(related_word)
                    count += 1

        if not additions:
            return query
        return query + " " + " ".join(additions)

    # ── Introspection ─────────────────────────────────────────────────────────

    def known_words(self) -> Set[str]:
        """Return the set of all source words in the dictionary."""
        return set(self._dict.keys())

    def entry_count(self) -> int:
        """Return the number of source words in the dictionary."""
        return len(self._dict)
