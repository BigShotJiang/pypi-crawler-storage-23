"""
Google Cloud Storage backend for antaris-memory.

Status: STUB — interface defined, not yet implemented.
Full implementation in antaris-memory v4.3.0.
"""


class GCSMemoryBackend:
    """Google Cloud Storage backend for antaris-memory.

    Drop-in replacement for the default filesystem backend.
    Requires: google-cloud-storage (optional dependency)

    Usage::

        from antaris_memory.backends.gcs import GCSMemoryBackend
        backend = GCSMemoryBackend(bucket="my-bucket", prefix="users/{user_id}/memory/")
        memory = MemorySystem(workspace=..., backend=backend)

    Status: STUB — interface defined, not yet implemented.
    Full implementation in antaris-memory v4.3.0.
    """

    def __init__(
        self,
        bucket: str,
        prefix: str = "",
        credentials_path: str = None,
    ):
        self.bucket = bucket
        self.prefix = prefix
        self._available = self._check_gcs_available()

    def _check_gcs_available(self) -> bool:
        try:
            import google.cloud.storage  # noqa
            return True
        except ImportError:
            return False

    def is_available(self) -> bool:
        """Return True if the google-cloud-storage package is installed."""
        return self._available

    def read_file(self, path: str) -> str:
        raise NotImplementedError(
            "GCSMemoryBackend.read_file() not yet implemented. "
            "Full GCS support coming in antaris-memory v4.3.0."
        )

    def write_file(self, path: str, content: str) -> None:
        raise NotImplementedError(
            "GCSMemoryBackend.write_file() not yet implemented. "
            "Full GCS support coming in antaris-memory v4.3.0."
        )

    def list_files(self, prefix: str = "") -> list[str]:
        raise NotImplementedError(
            "GCSMemoryBackend.list_files() not yet implemented."
        )

    def delete_file(self, path: str) -> None:
        raise NotImplementedError(
            "GCSMemoryBackend.delete_file() not yet implemented."
        )
