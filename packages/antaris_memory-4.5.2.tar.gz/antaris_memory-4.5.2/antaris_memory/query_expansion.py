"""
Query expansion via synonym map for antaris-memory v4.5.0.

Expands query terms to their synonyms before BM25 scoring so that
"how much are we spending?" also matches memories containing
"cost", "budget", "price", "expense", etc.

Zero external dependencies — stdlib only.
"""

import re
from typing import List, Dict, Set


# ---------------------------------------------------------------------------
# Synonym groups — each group is a frozenset of interchangeable terms.
# The build_synonym_map() helper turns this into a bidirectional dict at
# import time so look-up is O(1).
# ---------------------------------------------------------------------------

_SYNONYM_GROUPS: List[Set[str]] = [
    # 0 — Financial / money
    {"spending", "cost", "budget", "expense", "price", "payment",
     "fee", "bill", "charge", "invoice", "subscription", "pay",
     "pricing", "rate", "expenditure", "outlay", "revenue", "income",
     "money", "cash", "fund"},

    # 1 — Medical / health
    {"medical", "health", "doctor", "dentist", "appointment",
     "checkup", "prescription", "clinic", "hospital", "physician",
     "nurse", "therapy", "treatment", "diagnosis", "medication",
     "symptom", "wellness"},

    # 2 — Technical infrastructure
    {"server", "infrastructure", "api", "endpoint", "backend",
     "cloud", "deployment", "service", "instance", "node",
     "cluster", "container", "kubernetes", "docker", "microservice",
     "platform", "environment", "infrastructure"},

    # 3 — Meeting / scheduling
    {"meeting", "schedule", "calendar", "session", "call",
     "standup", "sync", "event", "appointment", "conference",
     "discussion", "agenda", "recap", "review"},

    # 4 — Security / vulnerabilities
    {"vulnerability", "bug", "issue", "threat", "risk",
     "exploit", "patch", "cve", "security", "attack",
     "breach", "flaw", "weakness", "exposure", "incident",
     "pentest", "audit"},

    # 5 — Travel
    {"travel", "flight", "trip", "journey", "hotel",
     "booking", "itinerary", "accommodation", "ticket",
     "departure", "arrival", "destination", "passport",
     "visa", "airline", "reservation"},

    # 6 — Incident / outage
    {"incident", "outage", "downtime", "failure", "crash",
     "error", "problem", "disruption", "degradation",
     "postmortem", "alert", "alarm", "pagerduty", "oncall"},

    # 7 — Team / people
    {"team", "colleague", "coworker", "member", "staff",
     "employee", "worker", "person", "collaborator",
     "teammate", "associate", "partner", "hire", "headcount"},

    # 8 — Personal preferences
    {"preference", "want", "like", "prefer", "enjoy",
     "favorite", "favourite", "wish", "desire", "interest",
     "hobby", "passion", "choice"},

    # 9 — Project management
    {"project", "task", "ticket", "story", "epic",
     "milestone", "sprint", "backlog", "jira", "linear",
     "roadmap", "deliverable", "objective", "goal"},

    # 10 — Authentication / access
    {"login", "password", "credential", "auth", "authentication",
     "authorization", "token", "key", "secret", "access",
     "permission", "sso", "oauth", "2fa", "mfa"},

    # 11 — Database
    {"database", "db", "query", "sql", "table",
     "schema", "record", "row", "column", "index",
     "migration", "postgres", "mysql", "mongo", "redis"},

    # 12 — Code / development
    {"code", "repository", "repo", "branch", "commit",
     "pull", "push", "merge", "pr", "review",
     "diff", "patch", "release", "version", "changelog"},

    # 13 — Configuration / settings
    {"config", "configuration", "setting", "option",
     "parameter", "flag", "env", "environment", "variable",
     "yaml", "json", "toml", "dotenv"},

    # 14 — Communication / messaging
    {"message", "email", "slack", "discord", "notification",
     "alert", "chat", "dm", "thread", "ping", "mention"},

    # 15 — Performance / metrics
    {"performance", "latency", "throughput", "metric",
     "benchmark", "profiling", "memory", "cpu", "load",
     "response", "speed", "slow", "fast", "optimize"},

    # 16 — Analytics / data
    {"analytics", "data", "report", "dashboard", "chart",
     "graph", "visualization", "insight", "trend", "statistic",
     "kpi", "metric", "segment"},

    # 17 — Customer / user
    {"customer", "client", "user", "account", "subscriber",
     "member", "consumer", "prospect", "lead", "tenant"},

    # 18 — Support / help
    {"support", "help", "assist", "ticket", "issue",
     "question", "request", "inquiry", "complaint", "feedback",
     "resolution", "fix", "workaround", "escalation"},

    # 19 — Document / file
    {"document", "file", "attachment", "pdf", "spreadsheet",
     "doc", "sheet", "note", "wiki", "page", "article",
     "readme", "specification", "spec"},

    # 20 — Plan / strategy
    {"plan", "strategy", "initiative", "proposal", "approach",
     "design", "architecture", "blueprint", "roadmap", "vision"},

    # 21 — Review / approval
    {"review", "approve", "approval", "sign-off", "signoff",
     "feedback", "comment", "lgtm", "accept", "reject",
     "decision", "vote"},

    # 22 — Time / deadline
    {"deadline", "due", "eta", "timeline", "date",
     "time", "schedule", "target", "milestone", "duedate"},

    # 23 — Test / QA
    {"test", "testing", "qa", "quality", "assurance",
     "unittest", "integration", "regression", "coverage",
     "staging", "sandbox", "validation"},

    # 24 — Logging / debugging
    {"log", "logging", "debug", "trace", "stacktrace",
     "exception", "error", "warning", "crash", "core-dump"},

    # 25 — Networking
    {"network", "dns", "ip", "subnet", "firewall",
     "vpn", "proxy", "load-balancer", "cdn", "ssl",
     "tls", "certificate", "domain", "hostname"},

    # 26 — Storage / backup
    {"storage", "disk", "backup", "restore", "snapshot",
     "archive", "bucket", "s3", "blob", "volume",
     "filesystem", "mount"},

    # 27 — CI/CD pipeline
    {"pipeline", "cicd", "ci", "cd", "build",
     "deploy", "artifact", "github-actions", "jenkins",
     "workflow", "job", "run"},

    # 28 — Payment / billing (B2B)
    {"invoice", "billing", "payment", "receipt",
     "charge", "refund", "stripe", "subscription", "plan",
     "tier", "overage", "quota"},

    # 29 — Machine learning / AI
    {"model", "ml", "ai", "training", "inference",
     "prediction", "embedding", "llm", "prompt", "fine-tuning",
     "dataset", "label", "annotation"},

    # 30 — Onboarding / setup
    {"onboarding", "setup", "installation", "install",
     "configure", "initialization", "bootstrap", "provision",
     "wizard", "getting-started"},

    # 31 — Legal / compliance
    {"legal", "compliance", "gdpr", "privacy", "policy",
     "terms", "contract", "agreement", "regulation",
     "audit", "governance", "soc2"},

    # 32 — Sales / marketing
    {"sales", "marketing", "campaign", "lead", "funnel",
     "conversion", "acquisition", "churn", "retention",
     "outreach", "demo", "pitch"},

    # 33 — Notification / reminder
    {"notification", "reminder", "alert", "nudge", "ping",
     "prompt", "notice", "warning", "announcement"},

    # 34 — Feedback / survey
    {"feedback", "survey", "review", "rating", "nps",
     "satisfaction", "response", "opinion", "reaction"},
]


def _build_synonym_map(groups: List[Set[str]]) -> Dict[str, Set[str]]:
    """Build a bidirectional term → synonym-set lookup in O(n) time.

    For each group, every term maps to the full group (minus itself).
    If a term appears in multiple groups its synonyms are unioned together.
    """
    mapping: Dict[str, Set[str]] = {}
    for group in groups:
        for term in group:
            if term not in mapping:
                mapping[term] = set()
            # Union in all other terms from this group
            mapping[term] |= group - {term}
    return mapping


# Module-level singleton — built once at import time.
_SYNONYM_MAP: Dict[str, Set[str]] = _build_synonym_map(_SYNONYM_GROUPS)


# Stopwords to skip during expansion (mirrors SearchEngine.STOPWORDS)
_STOPWORDS: frozenset = frozenset({
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'need', 'dare', 'ought',
    'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from',
    'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
    'between', 'out', 'off', 'over', 'under', 'again', 'further', 'then',
    'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both',
    'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
    'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just',
    'don', 'now', 'and', 'but', 'or', 'if', 'while', 'that', 'this',
    'it', 'its', 'he', 'she', 'they', 'them', 'his', 'her', 'their',
    'what', 'which', 'who', 'whom', 'these', 'those', 'am', 'about',
    'up', 'down', 'we', 'our', 'you', 'your', 'my', 'me', 'i', 'much',
    'get', 'got', 'give', 'make', 'take', 'let', 'put', 'set',
})


def _tokenize(text: str) -> List[str]:
    """Lightweight tokeniser — same regex as SearchEngine._tokenize."""
    tokens = re.findall(r'\w{2,}', text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


class QueryExpander:
    """Expands query terms with synonyms before BM25 scoring.

    Uses a built-in synonym map with 35+ semantic groups.  The map is
    bidirectional: if A → {B, C} then B → {A, C} and C → {A, B}.

    Usage::

        expander = QueryExpander()
        expanded = expander.expand("how much are we spending?")
        # → "how much are we spending? cost budget expense price payment ..."

    Args:
        extra_synonyms: Optional dict[str, list[str]] of additional groups
            to merge into the built-in map at construction time.
    """

    def __init__(self, extra_synonyms: Dict[str, List[str]] = None):
        # Start with the module-level map
        if extra_synonyms:
            # Deep-copy so we don't mutate the module global
            merged: Dict[str, Set[str]] = {k: set(v) for k, v in _SYNONYM_MAP.items()}
            # Treat each key + its values as a new synonym group
            for term, synonyms in extra_synonyms.items():
                group = {term} | set(synonyms)
                for t in group:
                    if t not in merged:
                        merged[t] = set()
                    merged[t] |= group - {t}
            self._map = merged
        else:
            self._map = _SYNONYM_MAP

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def expand(self, query: str) -> str:
        """Expand a query string by appending synonyms of recognised terms.

        The original query is preserved verbatim; synonyms are appended so
        that the expanded string naturally feeds into the existing tokeniser.
        Duplicates and stopwords are removed from the appended portion only —
        the original wording is never altered.

        Args:
            query: The raw user query.

        Returns:
            The original query with synonym terms appended, e.g.:
            ``"spending cost budget expense price payment fee bill charge ..."``.
        """
        extra = self.expand_tokens(_tokenize(query))
        original_tokens = set(_tokenize(query))
        additions = [t for t in extra if t not in original_tokens]
        if not additions:
            return query
        return query + " " + " ".join(additions)

    def expand_tokens(self, tokens: List[str]) -> List[str]:
        """Expand a list of tokens, returning deduplicated original + synonyms.

        Args:
            tokens: Pre-tokenised query terms (lowercase, no stopwords).

        Returns:
            A new list starting with the original tokens, followed by all
            unique synonyms found in the map, preserving insertion order.
        """
        seen: Set[str] = set()
        result: List[str] = []

        # First pass — add original tokens
        for t in tokens:
            if t not in seen:
                seen.add(t)
                result.append(t)

        # Second pass — add synonyms
        for t in tokens:
            for syn in self._map.get(t, set()):
                if syn not in seen and syn not in _STOPWORDS:
                    seen.add(syn)
                    result.append(syn)

        return result

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    def synonyms_for(self, term: str) -> Set[str]:
        """Return the synonym set for a single term (empty set if unknown)."""
        return set(self._map.get(term.lower(), set()))

    def known_terms(self) -> Set[str]:
        """Return all terms the expander knows about."""
        return set(self._map.keys())
