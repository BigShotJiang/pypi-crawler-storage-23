"""
Tests for antaris-memory v4.5.0 — Layer 2: Category Auto-Tagger.

Coverage:
- CategoryTagger.tag() for individual and overlapping categories
- CategoryTagger.primary_category() dominance resolution
- Financial special-case: dollar-sign detection
- Multi-category entries
- Auto-tagging integration via MemorySystem.ingest()
- Category boost in SearchEngine._score_entry()
"""

import pytest
import sys
import os

# Ensure the package is importable from tests/
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from antaris_memory.category_tagger import CategoryTagger


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tagger():
    return CategoryTagger()


# ---------------------------------------------------------------------------
# 1. tag() — individual categories
# ---------------------------------------------------------------------------

class TestTagSingleCategory:
    def test_financial_dollar_sign(self, tagger):
        tags = tagger.tag("gym membership renews $49.99 monthly")
        assert "financial" in tags

    def test_financial_keywords(self, tagger):
        tags = tagger.tag("the AWS bill this month is huge")
        assert "financial" in tags

    def test_financial_spend(self, tagger):
        tags = tagger.tag("how much are we spending on infrastructure?")
        assert "financial" in tags

    def test_medical_doctor(self, tagger):
        tags = tagger.tag("dentist appointment next Tuesday at 2pm")
        assert "medical" in tags

    def test_medical_prescription(self, tagger):
        tags = tagger.tag("picked up prescription from the clinic")
        assert "medical" in tags

    def test_technical_api(self, tagger):
        tags = tagger.tag("the api endpoint is returning 500 errors")
        assert "technical" in tags

    def test_technical_kubernetes(self, tagger):
        tags = tagger.tag("deployed new docker image to kubernetes cluster")
        assert "technical" in tags

    def test_security_cve(self, tagger):
        tags = tagger.tag("CVE-2024-1234 critical vulnerability patched")
        assert "security" in tags

    def test_security_password(self, tagger):
        tags = tagger.tag("rotate all API credentials and tokens immediately")
        assert "security" in tags

    def test_travel_flight(self, tagger):
        tags = tagger.tag("flight to NYC departs at 6am from SFO airport")
        assert "travel" in tags

    def test_travel_hotel(self, tagger):
        tags = tagger.tag("hotel booking confirmed for 3 nights")
        assert "travel" in tags

    def test_work_meeting(self, tagger):
        tags = tagger.tag("sprint planning meeting tomorrow at 10am")
        assert "work" in tags

    def test_incident_outage(self, tagger):
        tags = tagger.tag("production outage — database server is down")
        assert "incident" in tags

    def test_legal_contract(self, tagger):
        tags = tagger.tag("NDA contract needs to be signed before kickoff")
        assert "legal" in tags

    def test_food_restaurant(self, tagger):
        tags = tagger.tag("trying that new restaurant downtown for dinner")
        assert "food" in tags

    def test_fitness_gym(self, tagger):
        tags = tagger.tag("gym workout today: chest and triceps")
        assert "fitness" in tags

    def test_education_course(self, tagger):
        tags = tagger.tag("enrolled in a machine learning course online")
        assert "education" in tags

    def test_ai_ml_llm(self, tagger):
        tags = tagger.tag("fine-tuning the LLM on our custom dataset")
        assert "ai_ml" in tags

    def test_devops_pipeline(self, tagger):
        tags = tagger.tag("CI/CD pipeline failed on the deploy step")
        assert "devops" in tags

    def test_shopping_order(self, tagger):
        tags = tagger.tag("Amazon order delivered today, return window 30 days")
        assert "shopping" in tags


# ---------------------------------------------------------------------------
# 2. tag() — no match returns empty list
# ---------------------------------------------------------------------------

class TestTagNoMatch:
    def test_empty_string(self, tagger):
        assert tagger.tag("") == []

    def test_unrelated_text(self, tagger):
        # Very generic text unlikely to match any category
        result = tagger.tag("the blue sky today was nice")
        # "food" might match "eat" accidentally — just verify it's a list
        assert isinstance(result, list)

    def test_returns_list(self, tagger):
        result = tagger.tag("some random text")
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# 3. tag() — multi-category entries
# ---------------------------------------------------------------------------

class TestTagMultiCategory:
    def test_financial_and_fitness(self, tagger):
        tags = tagger.tag("gym membership renews $49.99 monthly")
        assert "financial" in tags
        assert "fitness" in tags

    def test_technical_and_incident(self, tagger):
        tags = tagger.tag("database server crash caused production outage")
        assert "incident" in tags
        # technical or devops should also match
        has_technical = "technical" in tags or "devops" in tags
        assert has_technical

    def test_security_and_technical(self, tagger):
        tags = tagger.tag("API token credential breach in the server environment")
        assert "security" in tags
        assert "technical" in tags

    def test_work_and_legal(self, tagger):
        tags = tagger.tag("team meeting to review compliance audit findings")
        assert "work" in tags
        assert "legal" in tags


# ---------------------------------------------------------------------------
# 4. primary_category()
# ---------------------------------------------------------------------------

class TestPrimaryCategory:
    def test_financial_dominant(self, tagger):
        text = "invoice $4300 payment due, fee waived, budget approved"
        result = tagger.primary_category(text)
        assert result == "financial"

    def test_medical_dominant(self, tagger):
        text = "doctor appointment, prescription refill, clinic visit"
        result = tagger.primary_category(text)
        assert result == "medical"

    def test_general_on_no_match(self, tagger):
        result = tagger.primary_category("")
        assert result == "general"

    def test_general_on_unknown_text(self, tagger):
        # Very neutral text
        result = tagger.primary_category("xyzzy quux blorple frobnicator")
        assert result == "general"

    def test_returns_string(self, tagger):
        result = tagger.primary_category("any text here")
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# 5. Integration: MemorySystem auto-tagging on ingest
# ---------------------------------------------------------------------------

class TestIngestAutoTagging:
    def test_financial_entry_gets_category_tag(self):
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_ingest")
        ms.ingest("AWS bill $4,300 due end of month", source="test")
        entry = ms.memories[-1]
        assert "financial" in entry.tags

    def test_financial_entry_gets_category_set(self):
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_ingest2")
        ms.ingest("invoice $4,300 payment subscription fee", source="test")
        entry = ms.memories[-1]
        assert entry.category == "financial"

    def test_category_not_overwritten_if_set(self):
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_ingest3")
        ms.ingest("doctor appointment tomorrow", source="test", category="strategic")
        entry = ms.memories[-1]
        # category should NOT be overwritten when explicitly set to non-general
        assert entry.category == "strategic"

    def test_general_overwritten_by_tagger(self):
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_ingest4")
        ms.ingest("gym membership renews $49.99 monthly", source="test", category="general")
        entry = ms.memories[-1]
        # category should be auto-set (no longer "general" for financial/fitness match)
        assert entry.category != "general" or "financial" in entry.tags or "fitness" in entry.tags


# ---------------------------------------------------------------------------
# 6. Search: category boost improves recall for semantic queries
# ---------------------------------------------------------------------------

class TestCategoryBoostSearch:
    def _make_system(self):
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_search")
        ms.ingest("gym membership renews $49.99 monthly", source="test")
        ms.ingest("AWS bill $4,300 due this Friday", source="test")
        ms.ingest("the weather is nice today outside", source="test")
        return ms

    def test_spending_query_finds_financial_entries(self):
        ms = self._make_system()
        results = ms.search("how much are we spending", session_id="*")
        # Should find financial entries even without direct keyword overlap
        contents = [r.content for r in results]
        assert any("$" in c for c in contents), \
            f"Expected financial entries in results, got: {contents}"

    def test_budget_query_boosts_financial(self):
        ms = self._make_system()
        results = ms.search("budget expense", session_id="*")
        assert len(results) > 0

    def test_category_boost_applied(self):
        """Verify category_boost marker appears in explanation for matching entries."""
        from antaris_memory.core import MemorySystem
        ms = MemorySystem(workspace="/tmp/test_catag_boost")
        ms.ingest("AWS bill $4,300 due this Friday", source="test")
        results = ms.search("spending budget fee", session_id="*", explain=True)
        if results:
            # At least one result should have the category_boost in explanation
            explanations = [r.explanation for r in results]
            assert any("category_boost" in e for e in explanations), \
                f"Expected category_boost in explanations: {explanations}"


# ---------------------------------------------------------------------------
# 7. tag_with_counts() debugging helper
# ---------------------------------------------------------------------------

class TestTagWithCounts:
    def test_returns_dict(self, tagger):
        result = tagger.tag_with_counts("doctor appointment $200 copay")
        assert isinstance(result, dict)

    def test_counts_are_positive(self, tagger):
        result = tagger.tag_with_counts("doctor appointment $200 copay")
        for cat, count in result.items():
            assert count > 0

    def test_financial_count_for_dollar(self, tagger):
        result = tagger.tag_with_counts("total cost $500")
        assert "financial" in result
        assert result["financial"] >= 2  # "$" + "cost" = 2 hits
