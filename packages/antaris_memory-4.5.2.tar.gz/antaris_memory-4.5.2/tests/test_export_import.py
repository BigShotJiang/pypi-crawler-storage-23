"""Tests for MemorySystem.export() / import_from() and GCSMemoryBackend stub (v4.2.0)."""

import json
import os
import tempfile
import pytest

from antaris_memory import MemorySystem, GCSMemoryBackend


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mem(tmp_path: str) -> MemorySystem:
    mem = MemorySystem(workspace=tmp_path, use_sharding=False, enable_read_cache=False)
    mem.ingest("The project deadline is end of Q2 2026", source="meeting", category="strategic")
    mem.ingest("Always use atomic writes to avoid partial-file corruption", source="lessons", category="operational")
    mem.ingest("Production deployment requires two-person approval from the ops team", source="policy", category="strategic")
    return mem


# ---------------------------------------------------------------------------
# export() tests
# ---------------------------------------------------------------------------

class TestExport:
    def test_export_returns_count(self, tmp_path):
        mem = _make_mem(str(tmp_path))
        out = str(tmp_path / "export.json")
        count = mem.export(out)
        assert count == 3

    def test_export_creates_file(self, tmp_path):
        mem = _make_mem(str(tmp_path))
        out = str(tmp_path / "export.json")
        mem.export(out)
        assert os.path.exists(out)

    def test_export_format_with_metadata(self, tmp_path):
        mem = _make_mem(str(tmp_path))
        out = str(tmp_path / "export.json")
        mem.export(out, include_metadata=True)
        with open(out) as f:
            data = json.load(f)
        assert data["version"] == "4.2"
        assert "exported_at" in data
        assert "workspace" in data
        assert "entries" in data
        assert len(data["entries"]) == 3

    def test_export_format_without_metadata(self, tmp_path):
        mem = _make_mem(str(tmp_path))
        out = str(tmp_path / "export.json")
        mem.export(out, include_metadata=False)
        with open(out) as f:
            data = json.load(f)
        assert "entries" in data
        # Should not have top-level metadata keys
        assert "version" not in data
        assert "workspace" not in data

    def test_export_entry_fields(self, tmp_path):
        mem = _make_mem(str(tmp_path))
        out = str(tmp_path / "export.json")
        mem.export(out)
        with open(out) as f:
            data = json.load(f)
        entry = data["entries"][0]
        for field in ("content", "source", "category", "memory_type", "timestamp", "score"):
            assert field in entry, f"Missing field: {field}"
        assert isinstance(entry["score"], float)
        assert entry["score"] >= 0.0

    def test_export_empty_memory(self, tmp_path):
        mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
        out = str(tmp_path / "empty.json")
        count = mem.export(out)
        assert count == 0
        with open(out) as f:
            data = json.load(f)
        assert data["entries"] == []


# ---------------------------------------------------------------------------
# import_from() tests
# ---------------------------------------------------------------------------

class TestImportFrom:
    def test_round_trip(self, tmp_path):
        """Export then import should restore all memories."""
        src = MemorySystem(workspace=str(tmp_path / "src"), use_sharding=False, enable_read_cache=False)
        src.ingest("Decision: use PostgreSQL for all relational data", source="arch", category="strategic")
        src.ingest("Lesson learned: always add indexes before going to production", source="ops", category="operational")
        out = str(tmp_path / "dump.json")
        exported = src.export(out)

        dst = MemorySystem(workspace=str(tmp_path / "dst"), use_sharding=False, enable_read_cache=False)
        imported = dst.import_from(out, merge=True)

        assert imported == exported
        assert len(dst.memories) == exported

    def test_merge_true_deduplication(self, tmp_path):
        """Re-importing the same file should not add duplicate entries."""
        mem = _make_mem(str(tmp_path / "ws"))
        out = str(tmp_path / "dump.json")
        mem.export(out)

        initial_count = len(mem.memories)
        # Import into same system — should deduplicate by content hash
        added = mem.import_from(out, merge=True)
        assert added == 0, "Re-import should deduplicate everything"
        assert len(mem.memories) == initial_count

    def test_merge_true_adds_new_entries(self, tmp_path):
        """Import from a different file should add entries."""
        mem_a = MemorySystem(workspace=str(tmp_path / "a"), use_sharding=False, enable_read_cache=False)
        mem_a.ingest("Alpha team uses Slack for communication", source="team", category="operational")
        out_a = str(tmp_path / "a.json")
        mem_a.export(out_a)

        mem_b = MemorySystem(workspace=str(tmp_path / "b"), use_sharding=False, enable_read_cache=False)
        mem_b.ingest("Beta team uses Teams for communication", source="team", category="operational")

        before = len(mem_b.memories)
        added = mem_b.import_from(out_a, merge=True)
        assert added == 1
        assert len(mem_b.memories) == before + 1

    def test_merge_false_replaces_store(self, tmp_path):
        """merge=False should wipe existing memories and replace with imported ones."""
        # Source has 2 unique memories
        src = MemorySystem(workspace=str(tmp_path / "src"), use_sharding=False, enable_read_cache=False)
        src.ingest("Source memory alpha: critical deployment note from ops team", source="src", category="strategic")
        src.ingest("Source memory beta: review all PRs before Friday's release", source="src", category="operational")
        out = str(tmp_path / "src.json")
        src.export(out)

        # Destination starts with different memories
        dst = MemorySystem(workspace=str(tmp_path / "dst"), use_sharding=False, enable_read_cache=False)
        dst.ingest("Destination-only memory: quarterly goals for engineering", source="dst", category="strategic")
        assert len(dst.memories) == 1

        imported = dst.import_from(out, merge=False)
        assert imported == 2
        assert len(dst.memories) == 2
        # Confirm destination-only memory is gone
        contents = [m.content for m in dst.memories]
        assert all("Destination" not in c for c in contents)

    def test_import_from_preserves_timestamps(self, tmp_path):
        """Imported entries should have their original timestamps restored."""
        src = MemorySystem(workspace=str(tmp_path / "src"), use_sharding=False, enable_read_cache=False)
        src.ingest("The architecture review meeting concluded successfully last week", source="mtg", category="strategic")
        original_ts = src.memories[0].created
        out = str(tmp_path / "dump.json")
        src.export(out)

        dst = MemorySystem(workspace=str(tmp_path / "dst"), use_sharding=False, enable_read_cache=False)
        dst.import_from(out)
        assert dst.memories[0].created == original_ts


# ---------------------------------------------------------------------------
# GCSMemoryBackend stub tests
# ---------------------------------------------------------------------------

class TestGCSMemoryBackend:
    def test_instantiation(self):
        backend = GCSMemoryBackend(bucket="my-test-bucket", prefix="agents/")
        assert backend.bucket == "my-test-bucket"
        assert backend.prefix == "agents/"

    def test_is_available_returns_bool(self):
        backend = GCSMemoryBackend(bucket="test-bucket")
        # google-cloud-storage is not installed in this env → False
        result = backend.is_available()
        assert isinstance(result, bool)
        # Since google-cloud-storage is an optional dep not installed in tests:
        assert result is False

    def test_read_file_raises_not_implemented(self):
        backend = GCSMemoryBackend(bucket="test-bucket")
        with pytest.raises(NotImplementedError) as exc_info:
            backend.read_file("some/path.json")
        assert "v4.3.0" in str(exc_info.value)

    def test_write_file_raises_not_implemented(self):
        backend = GCSMemoryBackend(bucket="test-bucket")
        with pytest.raises(NotImplementedError):
            backend.write_file("some/path.json", "content")

    def test_list_files_raises_not_implemented(self):
        backend = GCSMemoryBackend(bucket="test-bucket")
        with pytest.raises(NotImplementedError):
            backend.list_files("prefix/")

    def test_delete_file_raises_not_implemented(self):
        backend = GCSMemoryBackend(bucket="test-bucket")
        with pytest.raises(NotImplementedError):
            backend.delete_file("some/path.json")

    def test_import_from_top_level(self):
        """GCSMemoryBackend should be importable from the top-level package."""
        from antaris_memory import GCSMemoryBackend as _GCS
        assert _GCS is GCSMemoryBackend
