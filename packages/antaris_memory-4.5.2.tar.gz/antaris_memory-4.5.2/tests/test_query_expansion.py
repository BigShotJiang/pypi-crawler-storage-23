"""
Tests for antaris_memory.query_expansion — Layer 1: Query Expansion.
Run: cd .../antaris-memory && python3 -m pytest tests/test_query_expansion.py -v
"""

import unittest
from antaris_memory.query_expansion import QueryExpander, _SYNONYM_MAP, _SYNONYM_GROUPS


class TestSynonymMapBidirectional(unittest.TestCase):
    """Verify the synonym map is truly bidirectional."""

    def setUp(self):
        self.expander = QueryExpander()

    def test_financial_bidirectional_spending_cost(self):
        """If 'spending' → 'cost', then 'cost' → 'spending'."""
        self.assertIn("cost", self.expander.synonyms_for("spending"))
        self.assertIn("spending", self.expander.synonyms_for("cost"))

    def test_financial_bidirectional_budget_expense(self):
        self.assertIn("expense", self.expander.synonyms_for("budget"))
        self.assertIn("budget", self.expander.synonyms_for("expense"))

    def test_medical_bidirectional_doctor_health(self):
        self.assertIn("health", self.expander.synonyms_for("doctor"))
        self.assertIn("doctor", self.expander.synonyms_for("health"))

    def test_technical_bidirectional_server_api(self):
        self.assertIn("api", self.expander.synonyms_for("server"))
        self.assertIn("server", self.expander.synonyms_for("api"))

    def test_incident_bidirectional_outage_crash(self):
        self.assertIn("crash", self.expander.synonyms_for("outage"))
        self.assertIn("outage", self.expander.synonyms_for("crash"))

    def test_security_bidirectional_vulnerability_bug(self):
        self.assertIn("bug", self.expander.synonyms_for("vulnerability"))
        self.assertIn("vulnerability", self.expander.synonyms_for("bug"))

    def test_travel_bidirectional_flight_trip(self):
        self.assertIn("trip", self.expander.synonyms_for("flight"))
        self.assertIn("flight", self.expander.synonyms_for("trip"))

    def test_team_bidirectional_colleague_employee(self):
        self.assertIn("employee", self.expander.synonyms_for("colleague"))
        self.assertIn("colleague", self.expander.synonyms_for("employee"))


class TestExpandMethod(unittest.TestCase):
    """Tests for QueryExpander.expand(query) -> str."""

    def setUp(self):
        self.expander = QueryExpander()

    def test_expand_returns_string(self):
        result = self.expander.expand("what is the cost?")
        self.assertIsInstance(result, str)

    def test_expand_preserves_original_query(self):
        query = "how much are we spending?"
        result = self.expander.expand(query)
        self.assertTrue(result.startswith(query))

    def test_expand_financial_query_adds_synonyms(self):
        """'spending' query should gain 'cost', 'budget', 'expense', 'price'."""
        result = self.expander.expand("spending")
        tokens = result.lower().split()
        for expected in ["cost", "budget", "expense", "price"]:
            self.assertIn(expected, tokens, f"Expected '{expected}' in expanded: {result}")

    def test_expand_no_duplicates(self):
        """Expanded output must not contain duplicate tokens."""
        result = self.expander.expand("spending cost budget")
        tokens = result.lower().split()
        self.assertEqual(len(tokens), len(set(tokens)), f"Duplicates found in: {result}")

    def test_expand_empty_query(self):
        """Empty query returns empty string."""
        result = self.expander.expand("")
        self.assertEqual(result, "")

    def test_expand_stopwords_not_added(self):
        """Stopwords should not appear as expanded additions."""
        result = self.expander.expand("spending")
        # 'the', 'a', 'and' are stopwords — they should not be appended
        appended_part = result[len("spending"):].split()
        for sw in ("the", "a", "and", "is", "or"):
            self.assertNotIn(sw, appended_part, f"Stopword '{sw}' appeared in expansion: {result}")

    def test_expand_unknown_term_no_crash(self):
        """An unknown term should not crash — just return the original."""
        result = self.expander.expand("xyzzyfrumious")
        self.assertEqual(result.strip(), "xyzzyfrumious")

    def test_expand_medical_query(self):
        """'doctor' should expand to include 'health', 'clinic', 'prescription'."""
        result = self.expander.expand("doctor")
        tokens = result.lower().split()
        for expected in ["health", "clinic", "prescription"]:
            self.assertIn(expected, tokens, f"Expected '{expected}' in expanded: {result}")

    def test_expand_technical_query(self):
        """'server' should expand to include 'api', 'backend', 'deployment'."""
        result = self.expander.expand("server")
        tokens = result.lower().split()
        for expected in ["api", "backend", "deployment"]:
            self.assertIn(expected, tokens, f"Expected '{expected}' in expanded: {result}")

    def test_expand_incident_query(self):
        """'outage' should expand to include 'downtime', 'failure', 'crash'."""
        result = self.expander.expand("outage")
        tokens = result.lower().split()
        for expected in ["downtime", "failure", "crash"]:
            self.assertIn(expected, tokens, f"Expected '{expected}' in expanded: {result}")

    def test_expand_meeting_query(self):
        """'meeting' should expand to include 'schedule', 'calendar', 'session'."""
        result = self.expander.expand("meeting")
        tokens = result.lower().split()
        for expected in ["schedule", "calendar", "session"]:
            self.assertIn(expected, tokens, f"Expected '{expected}' in expanded: {result}")


class TestExpandTokensMethod(unittest.TestCase):
    """Tests for QueryExpander.expand_tokens(tokens) -> List[str]."""

    def setUp(self):
        self.expander = QueryExpander()

    def test_expand_tokens_returns_list(self):
        result = self.expander.expand_tokens(["spending"])
        self.assertIsInstance(result, list)

    def test_expand_tokens_preserves_original_first(self):
        """Original token must appear before its synonyms."""
        tokens = self.expander.expand_tokens(["spending"])
        self.assertEqual(tokens[0], "spending")

    def test_expand_tokens_no_duplicates(self):
        result = self.expander.expand_tokens(["cost", "budget", "spending"])
        self.assertEqual(len(result), len(set(result)))

    def test_expand_tokens_empty_input(self):
        result = self.expander.expand_tokens([])
        self.assertEqual(result, [])

    def test_expand_tokens_unknown_term_passthrough(self):
        """Unknown tokens pass through unchanged."""
        result = self.expander.expand_tokens(["xyzzy"])
        self.assertEqual(result, ["xyzzy"])

    def test_expand_tokens_multiple_groups(self):
        """Tokens from different groups each contribute their synonyms."""
        result = self.expander.expand_tokens(["spending", "outage"])
        result_set = set(result)
        # Financial synonyms
        self.assertIn("cost", result_set)
        self.assertIn("budget", result_set)
        # Incident synonyms
        self.assertIn("downtime", result_set)
        self.assertIn("failure", result_set)

    def test_expand_tokens_security_group(self):
        result = self.expander.expand_tokens(["vulnerability"])
        result_set = set(result)
        self.assertIn("bug", result_set)
        self.assertIn("risk", result_set)
        self.assertIn("exploit", result_set)

    def test_expand_tokens_travel_group(self):
        result = self.expander.expand_tokens(["travel"])
        result_set = set(result)
        self.assertIn("flight", result_set)
        self.assertIn("hotel", result_set)
        self.assertIn("itinerary", result_set)

    def test_expand_tokens_team_group(self):
        result = self.expander.expand_tokens(["team"])
        result_set = set(result)
        self.assertIn("colleague", result_set)
        self.assertIn("employee", result_set)
        self.assertIn("staff", result_set)

    def test_expand_tokens_personal_group(self):
        result = self.expander.expand_tokens(["preference"])
        result_set = set(result)
        self.assertIn("like", result_set)
        self.assertIn("enjoy", result_set)
        self.assertIn("favorite", result_set)


class TestExtraCustomSynonyms(unittest.TestCase):
    """Verify user-supplied extra_synonyms are merged correctly."""

    def test_custom_synonym_bidirectional(self):
        expander = QueryExpander(extra_synonyms={"widget": ["gadget", "gizmo"]})
        self.assertIn("gadget", expander.synonyms_for("widget"))
        self.assertIn("widget", expander.synonyms_for("gadget"))
        self.assertIn("widget", expander.synonyms_for("gizmo"))

    def test_custom_synonym_expand(self):
        expander = QueryExpander(extra_synonyms={"widget": ["gadget", "gizmo"]})
        result = expander.expand("widget")
        tokens = result.lower().split()
        self.assertIn("gadget", tokens)
        self.assertIn("gizmo", tokens)


class TestSynonymMapCoverage(unittest.TestCase):
    """Sanity checks on the module-level synonym map."""

    def test_at_least_30_groups(self):
        self.assertGreaterEqual(len(_SYNONYM_GROUPS), 30)

    def test_map_has_required_financial_terms(self):
        for term in ("spending", "cost", "budget", "expense", "price",
                     "payment", "fee", "bill", "charge", "invoice", "subscription"):
            self.assertIn(term, _SYNONYM_MAP, f"'{term}' missing from synonym map")

    def test_map_has_required_medical_terms(self):
        for term in ("medical", "health", "doctor", "dentist",
                     "prescription", "clinic"):
            self.assertIn(term, _SYNONYM_MAP, f"'{term}' missing from synonym map")

    def test_known_terms_covers_all_groups(self):
        expander = QueryExpander()
        known = expander.known_terms()
        for group in _SYNONYM_GROUPS:
            for term in group:
                self.assertIn(term, known)


if __name__ == "__main__":
    unittest.main()
