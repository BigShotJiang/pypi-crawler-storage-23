# PM-Agent 项目管理系统

**版本**: v1.3.0  
**状态**: 已发布

---

## 一、项目定位

PM-Agent是基于oc-collab L3架构的项目管理Agent系统。

### 1.1 核心能力

| 能力 | 说明 |
|------|------|
| 信息接入 | 接收微信/邮件/聊天等任意信息 |
| 项目识别 | 自动识别信息归属项目 |
| 类型分类 | 自动分类需求/BUG/会议等 |
| Git分析 | 从Git读取进度 |
| 进度报告 | 自动生成项目报告 |

### 1.2 技术架构

| 组件 | 技术 |
|------|------|
| 前端 | Vue.js |
| 后端 | FastAPI |
| 数据库 | SQLite |

### 1.3 架构分层

```
L1: oc-collab-core (CLI开发框架)
L2: 接口/编排层
L3: PM-Agent (本项目)
```

---

## 二、目录结构

```
pm-agent/
├── frontend/        # Vue.js前端
│   └── src/
├── backend/         # FastAPI后端
│   └── src/
├── docs/            # 项目文档
│   ├── 01-requirements/
│   ├── 02-design/
│   └── 04-proposals/
└── config/         # 配置文件
```

---

## 三、快速开始

### 3.1 本地开发

```bash
# 克隆项目
git clone https://gitee.com/zhang-xiuqin01/pm-agent.git
cd pm-agent

# 启动后端
cd backend
pip install -r requirements.txt
uvicorn src.main:app --reload

# 启动前端
cd frontend
npm install
npm run dev
```

---

## 四、相关文档

- 需求文档: `docs/01-requirements/`
- 设计文档: `docs/02-design/`
- 技术提案: `docs/04-proposals/`
- 路线图: `docs/06-roadmap/ROADMAP_pm_agent.md`
- oc-collab主项目: `../dual-agent-collaboration-system`

---

**作者**: oc-collab团队  
**创建日期**: 2026-02-17
