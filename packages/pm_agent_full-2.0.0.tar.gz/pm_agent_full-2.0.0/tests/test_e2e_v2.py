"""
PM-Agent v2.0 E2E测试用例 (最终修订版)
修复测试执行问题
"""
import pytest
import sys
from pathlib import Path


class MockConfManProvider:
    """Mock ConfManProvider for testing"""
    
    def __init__(self):
        self._data_dir = "/mock/data"
        self._config_dir = "/mock/config"
        self._log_dir = "/mock/log"
        self._temp_dir = "/mock/temp"
        self._todo_db = "/mock/state/todos.db"
        self._state_file = "/mock/state/project_state.yaml"
        self._version = "v1.0.0"
    
    def get_data_dir(self) -> str:
        return self._data_dir
    
    def get_config_dir(self) -> str:
        return self._config_dir
    
    def get_log_dir(self) -> str:
        return self._log_dir
    
    def get_temp_dir(self) -> str:
        return self._temp_dir
    
    def get_todo_db_path(self) -> str:
        return self._todo_db
    
    def get_state_file_path(self) -> str:
        return self._state_file
    
    def get_lock_file_path(self, name: str) -> str:
        return f"/mock/locks/{name}"
    
    def get_agent_status_db_path(self) -> str:
        return "/mock/state/agent_status.db"
    
    def get_session_dir(self) -> str:
        return "/mock/sessions"
    
    def get_adhoc_todos_path(self) -> str:
        return "/mock/state/adhoc_todos.yaml"
    
    def get_identity_file_path(self) -> str:
        return "/mock/identity.yaml"
    
    def get_pid_file_path(self) -> str:
        return "/mock/pm-agent.pid"
    
    def get_opencode_db_path(self) -> str:
        return "/mock/opencode.db"
    
    def get_agents_config_path(self) -> str:
        return "/mock/config/agents.yaml"
    
    def get_git_sync_config_path(self) -> str:
        return "/mock/config/git_sync.yaml"
    
    def get_notification_config_path(self) -> str:
        return "/mock/config/notifications.yaml"
    
    def get_skill_index_path(self) -> str:
        return "/mock/skills/index.yaml"
    
    def get_file_owners_path(self) -> str:
        return "/mock/config/file_owners.yaml"
    
    def get_full_path(self, relative_path: str) -> Path:
        return Path(self._data_dir) / relative_path
    
    def get_version(self) -> str:
        return self._version


class MockEnvironmentConfig:
    """Mock EnvironmentConfig for testing"""
    
    def __init__(self):
        self._env = "test"
        self._test_mode = True
    
    def get_environment(self) -> str:
        return self._env
    
    def is_test_mode(self) -> bool:
        return self._test_mode


@pytest.fixture
def with_conf_man_mock():
    """按需使用mock"""
    from backend.integrations.conf_man_client import _set_conf_man_classes
    _set_conf_man_classes(MockConfManProvider, MockEnvironmentConfig)
    yield
    _set_conf_man_classes(None, None)


class TestConfManConfigE2E:
    """E2E-001: ConfManClient配置接口测试"""
    
    def test_get_data_dir_flow(self, with_conf_man_mock):
        """E2E-001-01: 获取数据目录"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_data_dir()
        assert result == "/mock/data"
    
    def test_get_config_dir_flow(self, with_conf_man_mock):
        """E2E-001-02: 获取配置目录"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_config_dir()
        assert result == "/mock/config"
    
    def test_get_todo_db_path_flow(self, with_conf_man_mock):
        """E2E-001-03: 获取TODO数据库路径"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_todo_db_path()
        assert result == "/mock/state/todos.db"
    
    def test_get_environment_flow(self, with_conf_man_mock):
        """E2E-001-04: 获取环境信息"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_environment()
        assert result == "test"
    
    def test_is_test_mode_flow(self, with_conf_man_mock):
        """E2E-001-05: 检查测试模式"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.is_test_mode()
        assert result is True
    
    def test_is_available_flow(self, with_conf_man_mock):
        """E2E-001-06: 检查可用性"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.is_available()
        assert result is True
    
    def test_get_version_flow(self, with_conf_man_mock):
        """E2E-001-07: 获取版本"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_version()
        assert result == "v1.0.0"
    
    def test_get_lock_file_path_with_name(self, with_conf_man_mock):
        """E2E-001-08: 获取锁文件路径"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_lock_file_path("test_lock")
        assert result == "/mock/locks/test_lock"
    
    def test_get_full_path_flow(self, with_conf_man_mock):
        """E2E-001-09: 获取完整路径"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_full_path("subdir/file.txt")
        assert "subdir" in str(result)
        assert "file.txt" in str(result)
    
    def test_get_log_dir_flow(self, with_conf_man_mock):
        """E2E-001-10: 获取日志目录"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        result = client.get_log_dir()
        assert result == "/mock/log"


class TestConfManErrorHandling:
    """E2E-002: 错误处理测试"""
    
    def test_import_error_handling_without_provider(self, with_conf_man_mock):
        """E2E-002-01: 验证无provider时返回False"""
        from backend.integrations.conf_man_client import _set_conf_man_classes
        from backend.integrations.conf_man_client import ConfManClient
        
        _set_conf_man_classes(None, None)
        client = ConfManClient()
        
        result = client.is_available()
        assert result is False
    
    def test_check_available_raises_when_provider_none(self, with_conf_man_mock):
        """E2E-002-02: 验证provider为None时抛出ImportError"""
        from backend.integrations.conf_man_client import _set_conf_man_classes
        from backend.integrations.conf_man_client import ConfManClient
        
        _set_conf_man_classes(None, None)
        client = ConfManClient()
        
        with pytest.raises(ImportError, match="conf-man not available"):
            client._check_available()


class TestVersionClientE2E:
    """E2E-003: VersionClient测试"""
    
    @pytest.mark.xfail(reason="conf-man CLI not available in test environment", strict=False)
    def test_version_client_list_versions(self):
        """E2E-003-01: 列出版本"""
        from backend.services.version_service import VersionClient
        client = VersionClient()
        
        versions = client.list_versions()
        assert isinstance(versions, list)
    
    @pytest.mark.xfail(reason="conf-man CLI not available in test environment", strict=False)
    def test_version_client_show_version(self):
        """E2E-003-02: 显示版本详情"""
        from backend.services.version_service import VersionClient
        client = VersionClient()
        
        version = client.show_version("v1.0.0")
        assert version is not None


class TestIntegrationScenarios:
    """E2E-004: 集成场景测试"""
    
    def test_conf_man_initialization_flow(self, with_conf_man_mock):
        """E2E-004-01: 完整初始化流程"""
        from backend.integrations.conf_man_client import ConfManClient
        
        client = ConfManClient()
        
        assert client.is_available() is True
        assert client.get_data_dir() == "/mock/data"
        assert client.get_config_dir() == "/mock/config"
        assert client.get_environment() == "test"
        assert client.is_test_mode() is True
    
    def test_path_resolution_flow(self, with_conf_man_mock):
        """E2E-004-02: 路径解析流程"""
        from backend.integrations.conf_man_client import ConfManClient
        client = ConfManClient()
        
        full_path = client.get_full_path("docs/readme.md")
        assert "readme.md" in str(full_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
