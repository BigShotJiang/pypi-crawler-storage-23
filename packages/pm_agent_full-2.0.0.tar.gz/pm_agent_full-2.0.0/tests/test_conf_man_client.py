"""
ConfManClient 单元测试
PM-Agent v2.0 - F-031

测试用例: 15个
"""
import pytest
import sys
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))


class TestConfManClientInit:
    """测试ConfManClient初始化"""

    def test_init_with_mock_provider(self):
        """TC-001: 测试使用mock模块初始化"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            assert client._provider is not None
            assert client._env_config is not None
        finally:
            _set_conf_man_classes(None, None)

    def test_init_without_provider(self):
        """TC-002: 测试无provider时初始化"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        _set_conf_man_classes(None, None)
        
        with patch('builtins.__import__', side_effect=ImportError("Mock error")):
            client = ConfManClient()
            assert client._provider is None

    def test_lazy_load_module(self):
        """TC-003: 测试延迟加载模块"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            assert client._provider is not None
        finally:
            _set_conf_man_classes(None, None)

    def test_mock_module_injection(self):
        """TC-004: 测试mock模块注入"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            assert client.is_available() is True
        finally:
            _set_conf_man_classes(None, None)


class TestConfManClientPaths:
    """测试路径获取方法"""

    def test_get_data_dir_success(self):
        """TC-005: 测试获取数据目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_data_dir.return_value = "/data"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_data_dir()
            assert result == "/data"
        finally:
            _set_conf_man_classes(None, None)

    def test_get_config_dir_success(self):
        """TC-006: 测试获取配置目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_config_dir.return_value = "/config"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_config_dir()
            assert result == "/config"
        finally:
            _set_conf_man_classes(None, None)

    def test_get_log_dir_success(self):
        """TC-007: 测试获取日志目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_log_dir.return_value = "/log"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_log_dir()
            assert result == "/log"
        finally:
            _set_conf_man_classes(None, None)

    def test_get_temp_dir_success(self):
        """TC-008: 测试获取临时目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_temp_dir.return_value = "/temp"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_temp_dir()
            assert result == "/temp"
        finally:
            _set_conf_man_classes(None, None)

    def test_get_todo_db_path_success(self):
        """TC-009: 测试获取TODO数据库路径成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_todo_db_path.return_value = "/data/todos.db"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_todo_db_path()
            assert result == "/data/todos.db"
        finally:
            _set_conf_man_classes(None, None)

    def test_get_lock_file_path_success(self):
        """TC-010: 测试获取锁文件路径成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_provider.get_lock_file_path.return_value = "/locks/test.lock"
        mock_env = Mock()
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_lock_file_path("test")
            assert result == "/locks/test.lock"
        finally:
            _set_conf_man_classes(None, None)


class TestConfManClientEnvironment:
    """测试环境查询方法"""

    def test_get_environment_success(self):
        """TC-011: 测试获取环境信息成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        mock_env.get_environment.return_value = "production"
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.get_environment()
            assert result == "production"
        finally:
            _set_conf_man_classes(None, None)

    def test_is_test_mode_true(self):
        """TC-012: 测试测试模式启用"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        mock_env.is_test_mode.return_value = True
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.is_test_mode()
            assert result is True
        finally:
            _set_conf_man_classes(None, None)

    def test_is_test_mode_false(self):
        """TC-013: 测试测试模式未启用"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider = Mock()
        mock_env = Mock()
        mock_env.is_test_mode.return_value = False
        _set_conf_man_classes(mock_provider, mock_env)
        
        try:
            client = ConfManClient()
            result = client.is_test_mode()
            assert result is False
        finally:
            _set_conf_man_classes(None, None)


class TestConfManClientErrors:
    """测试错误处理"""

    def test_module_not_found(self):
        """TC-014: 测试模块未找到异常"""
        from backend.integrations.conf_man_client import ConfManClient, ConfManError
        
        with patch('builtins.__import__', side_effect=ImportError("Module not found")):
            client = ConfManClient()
            with pytest.raises((ImportError, ConfManError)):
                client.get_data_dir()

    def test_check_available_raises(self):
        """TC-015: 测试_check_available抛出异常"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        _set_conf_man_classes(None, None)
        
        client = ConfManClient()
        with pytest.raises(ImportError, match="conf-man not available"):
            client._check_available()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
