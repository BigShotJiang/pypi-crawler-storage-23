"""
VersionClient - 版本管理客户端
PM-Agent v2.0 - F-032

功能: 封装conf-man版本管理功能（HTTP API方式）
"""
import logging
from typing import List, Dict, Optional, Any

from backend.integrations.version_api_client import (
    VersionAPIClient,
    VersionAPIClientError,
    get_version_api_client,
    set_version_api_client
)

logger = logging.getLogger(__name__)


class VersionClient:
    """版本管理客户端"""
    
    def __init__(self, timeout: int = 30):
        """初始化VersionClient"""
        self.timeout = timeout
        self._client = None
    
    def _get_client(self) -> VersionAPIClient:
        """获取HTTP API客户端"""
        if self._client is None:
            self._client = get_version_api_client()
        return self._client
    
    def _check_available(self):
        """检查API是否可用"""
        client = self._get_client()
        client._check_available()
    
    def list_versions(self, status: Optional[str] = None, project: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        列出版本
        
        Args:
            status: 过滤状态 (draft/released/deprecated)
            project: 项目名称
        
        Returns:
            版本列表
        """
        client = self._get_client()
        return client.list_versions(status=status, project=project)
    
    def show_version(self, version: str) -> Dict[str, Any]:
        """
        获取版本详情
        
        Args:
            version: 版本号
        
        Returns:
            版本详情
        """
        client = self._get_client()
        return client.show_version(version)
    
    def register_version(
        self,
        version: str,
        manifest_path: Optional[str] = None,
        test_report_path: Optional[str] = None,
        project: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        登记新版本
        
        Args:
            version: 版本号
            manifest_path: 版本清单文件路径
            test_report_path: 测试报告文件路径
            project: 项目名称
        
        Returns:
            登记结果
        """
        client = self._get_client()
        return client.register_version(
            version=version,
            manifest_path=manifest_path,
            test_report_path=test_report_path,
            project=project
        )
    
    def release_version(self, version: str) -> Dict[str, Any]:
        """
        发布版本
        
        Args:
            version: 版本号
        
        Returns:
            发布结果
        """
        client = self._get_client()
        return client.release_version(version)
    
    def rollback_version(self, version: str) -> Dict[str, Any]:
        """
        回滚版本
        
        Args:
            version: 版本号
        
        Returns:
            回滚结果
        """
        client = self._get_client()
        return client.rollback_version(version)
    
    def get_dependencies(self, version: str) -> List[Dict[str, Any]]:
        """
        获取版本依赖
        
        Args:
            version: 版本号
        
        Returns:
            依赖列表
        """
        client = self._get_client()
        return client.get_dependencies(version)
    
    def list_projects(self) -> List[Dict[str, Any]]:
        """
        列出项目
        
        Returns:
            项目列表
        """
        client = self._get_client()
        return client.list_projects()
    
    def show_project(self, name: str) -> Dict[str, Any]:
        """
        显示项目详情
        
        Args:
            name: 项目名称
        
        Returns:
            项目详情
        """
        client = self._get_client()
        return client.show_project(name)
    
    def export_manifest(self, version: str, output_path: str) -> Dict[str, Any]:
        """
        导出版本清单
        
        Args:
            version: 版本号
            output_path: 输出文件路径
        
        Returns:
            导出结果
        """
        client = self._get_client()
        return client.export_manifest(version, output_path)
    
    def import_manifest(self, input_path: str) -> Dict[str, Any]:
        """
        导入版本清单
        
        Args:
            input_path: 输入文件路径
        
        Returns:
            导入结果
        """
        client = self._get_client()
        return client.import_manifest(input_path)
    
    def get_current_version(self) -> Optional[str]:
        """
        获取当前版本
        
        Returns:
            当前版本号，如果没有则返回None
        """
        client = self._get_client()
        return client.get_current_version()
