"""
PM-Agent 后端服务入口
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.config import config
from backend.api.routes import main as routes
from backend.api.routes import materials, templates

app = FastAPI(
    title="PM-Agent API",
    description="PM-Agent - 项目管理助手API",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(routes.router)
app.include_router(materials.router, prefix="/api", tags=["materials"])
app.include_router(templates.router, prefix="/api", tags=["templates"])

# 初始化数据库
from backend.models.database import init_db
init_db()


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": "PM-Agent API",
        "version": "1.0.0",
        "status": "running"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=config.backend_host,
        port=config.backend_port,
        reload=config.get("backend.reload", True)
    )
