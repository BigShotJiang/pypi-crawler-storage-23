{%
   include-markdown "../guides/extensions.md"
   rewrite-relative-urls=false
%}
