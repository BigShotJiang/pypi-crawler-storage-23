{%
   include-markdown "../guides/performance.md"
   rewrite-relative-urls=false
%}

## Comparative Results: remote-store vs Raw SDK vs fsspec

{%
   include-markdown "../benchmarks/results/comparative.md"
   rewrite-relative-urls=false
%}
