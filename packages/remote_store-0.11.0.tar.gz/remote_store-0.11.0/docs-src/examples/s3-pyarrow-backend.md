# S3-PyArrow Backend

High-throughput S3 via PyArrow's C++ filesystem. Drop-in swap from the S3 backend.

```python
--8<-- "examples/backends/s3_pyarrow_backend.py"
```
