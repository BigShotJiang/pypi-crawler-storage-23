# Quickstart

Minimal config, write, and read.

```python
--8<-- "examples/quickstart.py"
```
