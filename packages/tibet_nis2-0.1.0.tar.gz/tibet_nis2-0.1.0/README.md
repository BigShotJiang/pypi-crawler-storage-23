# tibet-nis2 — NIS2 Directive Compliance Tool

**NIS2 (Directive 2022/2555) deadline has passed.** Every essential and important
entity in the EU must comply. No exceptions, no extensions, no excuses.

tibet-nis2 is a standalone compliance tool covering **all ten sub-articles of
NIS2 Article 21(2)** — from risk analysis to multi-factor authentication — with
a full TIBET audit trail for every assessment, decision, and incident.

## Why This Exists

The EU adopted NIS2 because cyber incidents keep escalating:

- **Odido hack (2024)** — Millions of customer records exposed. A telecom
  provider that should have had supply chain security and incident response
  in place. NIS2 Art. 21(2)(d) was written exactly for this.
- **Politie cookies hack** — Dutch police systems compromised through a
  trivial web vulnerability. Basic cyber hygiene (Art. 21(2)(g)) would have
  prevented it.
- **Ransomware across EU hospitals** — Patient data held hostage because
  backup and business continuity plans (Art. 21(2)(c)) were missing.

NIS2 is not bureaucracy. It is the minimum bar for operating critical
infrastructure in 2025.

## What It Covers

All ten cybersecurity risk-management measures from **NIS2 Art. 21(2)**:

| Sub-article | Requirement | tibet-nis2 |
|-------------|-------------|------------|
| (a) | Risk analysis & information system security policies | Asset inventory + risk assessment |
| (b) | Incident handling | 24h/72h/final report templates |
| (c) | Business continuity & crisis management | Continuity checks |
| (d) | Supply chain security | Dependency mapping + verification |
| (e) | Security in acquisition of network/information systems | Procurement checks |
| (f) | Assessing effectiveness of risk management | Scoring + gap analysis |
| (g) | Basic cyber hygiene & cybersecurity training | Hygiene checklist |
| (h) | Cryptography & encryption policies | Crypto audit |
| (i) | HR security, access control, asset management | Access + asset checks |
| (j) | Multi-factor authentication | MFA verification |

Every check produces a **TIBET token** — an immutable provenance record linking
the assessment to the asset, the auditor, and the NIS2 article.

## Installation

```bash
pip install tibet-nis2
```

Or from source:

```bash
git clone https://github.com/jaspertvdm/tibet-nis2.git
cd tibet-nis2
pip install -e .
```

## Quick Start

```python
from tibet_nis2 import NIS2Auditor, Asset

auditor = NIS2Auditor(organization="Acme BV", sector="essential")

# Register assets
auditor.add_asset(Asset(
    id="srv-prod-01",
    name="Production Database",
    category="ESSENTIAL",
    asset_type="database",
    owner="infra-team",
    criticality=5,
))

auditor.add_asset(Asset(
    id="fw-edge-01",
    name="Edge Firewall",
    category="ESSENTIAL",
    asset_type="network",
    owner="security-team",
    criticality=5,
    dependencies=["srv-prod-01"],
))

# Run full compliance check
report = auditor.check_compliance()
print(f"Score: {report.overall_score}/100")
print(f"Compliant: {report.compliant}")
print(f"Gaps: {len(report.gaps)}")

# Incident response
incident = auditor.incident_report(
    asset_id="srv-prod-01",
    incident_type="data_breach",
    description="Unauthorized access to customer database detected",
)
print(f"Early warning deadline: {incident.early_warning_deadline}")
print(f"Full report deadline: {incident.full_report_deadline}")
```

## CLI Commands

```bash
# NIS2 overview — what it is, who must comply, deadlines
tibet-nis2 info

# Run compliance check (demo mode with sample assets)
tibet-nis2 check

# Show asset inventory
tibet-nis2 assets

# Incident response demo (simulates Odido-style breach)
tibet-nis2 incident

# Full demo: assets → risks → compliance → incident → deadlines
tibet-nis2 demo

# Show all Art. 21(2) sub-articles and coverage status
tibet-nis2 articles

# JSON output (all commands)
tibet-nis2 check --json
tibet-nis2 assets --json
```

## TIBET Audit Trail

Every assessment produces provenance tokens with the TIBET structure:

- **ERIN** — What was assessed, what was found
- **ERAAN** — Related assets, dependencies, JIS identity
- **EROMHEEN** — Auditor node, timestamp, NIS2 article reference
- **ERACHTER** — The "why": which NIS2 article this satisfies

```python
auditor = NIS2Auditor(organization="Acme BV")
# ... add assets, run checks ...
chain = auditor.provenance.chain()
# Every token is linked, hashed, and traceable
```

## Part of the TIBET Ecosystem

tibet-nis2 is part of the TIBET protocol family:

- **tibet-core** — Provenance token engine
- **tibet-pol** — Policy enforcement (no action without proof)
- **tibet-twin** — Digital twin synchronicity guard
- **tibet-y2k38** — Y2038 time overflow protection
- **tibet-edge** — Edge device provenance
- **tibet-nis2** — NIS2 compliance (this package)

---

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025
