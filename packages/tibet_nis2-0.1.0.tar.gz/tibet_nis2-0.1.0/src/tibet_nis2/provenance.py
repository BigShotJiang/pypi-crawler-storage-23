"""
TIBET provenance for NIS2 compliance assessments.

Every compliance check, risk assessment, and incident report
is recorded as a TIBET token. The chain is the audit trail
that NIS2 Art. 21 requires you to have.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class NIS2Token:
    """Single TIBET provenance token for a NIS2 assessment event."""

    token_id: str
    timestamp: str
    token_type: str  # assessment, incident, compliance_check, supply_chain
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": self.token_type,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class NIS2Provenance:
    """
    Provenance chain for NIS2 compliance activities.

    Every assessment, incident report, and compliance decision is
    recorded as a TIBET token with full ERIN/ERAAN/EROMHEEN/ERACHTER
    metadata. The chain provides the immutable audit trail required
    by NIS2 Art. 21.
    """

    def __init__(self, actor: str = "tibet-nis2"):
        self.actor = actor
        self.tokens: list[NIS2Token] = []
        self._last_id: Optional[str] = None

    def create_token(
        self,
        token_type: str,
        asset_id: str,
        article: str,
        findings: dict,
        related_assets: list[str] | None = None,
        jis_identity: str | None = None,
    ) -> NIS2Token:
        """
        Create a TIBET token for a NIS2 assessment event.

        Args:
            token_type: assessment, incident, compliance_check, supply_chain
            asset_id: The asset being assessed.
            article: NIS2 article reference, e.g. "Art. 21(2)(a)".
            findings: Assessment findings dict.
            related_assets: Other assets linked to this assessment.
            jis_identity: JIS URI for the asset (auto-generated if absent).
        """
        now = datetime.now(timezone.utc).isoformat()
        jis = jis_identity or f"jis:{asset_id}"

        erin = {
            "assessment_type": token_type,
            "asset": asset_id,
            "article": article,
            "findings": findings,
        }

        eraan = {
            "related_assets": related_assets or [],
            "dependencies": findings.get("dependencies", []),
            "jis": jis,
        }

        eromheen = {
            "auditor_node": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
            "nis2_article": article,
        }

        erachter = {
            "intent": f"NIS2 {article} compliance check",
            "directive": "Directive 2022/2555",
            "reason": f"Verify compliance with NIS2 {article}",
        }

        content = json.dumps({"erin": erin}, sort_keys=True)
        token_id = hashlib.sha256(
            f"{asset_id}:{article}:{now}".encode()
        ).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = NIS2Token(
            token_id=token_id,
            timestamp=now,
            token_type=token_type,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )

        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        """Return full provenance chain as list of dicts."""
        return [t.to_dict() for t in self.tokens]

    def __len__(self) -> int:
        return len(self.tokens)
