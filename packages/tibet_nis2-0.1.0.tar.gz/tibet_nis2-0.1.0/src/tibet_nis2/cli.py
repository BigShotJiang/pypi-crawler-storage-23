"""
tibet-nis2 CLI — NIS2 Directive Compliance Tool.

Usage::

    tibet-nis2 info       NIS2 overview
    tibet-nis2 check      Run compliance check (demo)
    tibet-nis2 assets     Show asset inventory
    tibet-nis2 incident   Incident response demo
    tibet-nis2 demo       Full end-to-end demo
    tibet-nis2 articles   Show Art. 21(2) sub-articles
"""

import argparse
import json
import sys
from datetime import datetime, timezone

from .auditor import NIS2Auditor, Asset, NIS2_ARTICLES
from .incident import (
    create_early_warning,
    create_full_report,
    create_final_report,
)


# ---------------------------------------------------------------------------
# Sample assets for demo mode
# ---------------------------------------------------------------------------

def _demo_assets() -> list[Asset]:
    """Sample assets representing a typical EU organization."""
    return [
        Asset(
            id="db-prod-01",
            name="Production Database (PostgreSQL)",
            category="ESSENTIAL",
            asset_type="database",
            owner="data-team",
            ip="10.0.1.10",
            criticality=5,
            dependencies=["srv-app-01"],
        ),
        Asset(
            id="srv-app-01",
            name="Application Server",
            category="ESSENTIAL",
            asset_type="server",
            owner="platform-team",
            ip="10.0.1.20",
            criticality=5,
            dependencies=["fw-edge-01", "cloud-cdn-01"],
        ),
        Asset(
            id="fw-edge-01",
            name="Edge Firewall",
            category="ESSENTIAL",
            asset_type="network",
            owner="security-team",
            ip="10.0.0.1",
            criticality=5,
            dependencies=[],
        ),
        Asset(
            id="cloud-cdn-01",
            name="CDN Service (external)",
            category="IMPORTANT",
            asset_type="cloud",
            owner="infra-team",
            ip="",
            criticality=3,
            dependencies=[],
        ),
        Asset(
            id="iot-hvac-01",
            name="Building HVAC Controller",
            category="SUPPORTING",
            asset_type="iot",
            owner="facilities",
            ip="10.0.5.50",
            criticality=2,
            dependencies=[],
        ),
        Asset(
            id="app-crm-01",
            name="CRM Application",
            category="IMPORTANT",
            asset_type="application",
            owner="sales-ops",
            ip="10.0.2.30",
            criticality=4,
            dependencies=["db-prod-01", "srv-app-01"],
        ),
    ]


def _setup_auditor() -> NIS2Auditor:
    """Create a demo auditor with sample assets."""
    auditor = NIS2Auditor(organization="Demo BV", sector="essential")
    for asset in _demo_assets():
        auditor.add_asset(asset)
    return auditor


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  NIS2 DIRECTIVE (2022/2555) — Compliance Overview")
    print("=" * 64)
    print()
    print("  What is NIS2?")
    print("    The EU Network and Information Security Directive 2.")
    print("    Adopted 14 December 2022. Member state transposition")
    print("    deadline: 17 October 2024. It has passed.")
    print()
    print("  Who must comply?")
    print("    Essential entities:")
    print("      Energy, transport, banking, financial market,")
    print("      health, drinking water, waste water, digital")
    print("      infrastructure, ICT service management, public")
    print("      administration, space.")
    print("    Important entities:")
    print("      Postal services, waste management, chemicals,")
    print("      food, manufacturing, digital providers, research.")
    print()
    print("  What does it require?")
    print("    Article 21: Ten cybersecurity risk-management measures")
    print("    Article 23: Incident reporting (24h / 72h / 1 month)")
    print("    Article 7:  National cybersecurity strategy")
    print()
    print("  Penalties:")
    print("    Essential: up to EUR 10,000,000 or 2% global turnover")
    print("    Important: up to EUR  7,000,000 or 1.4% global turnover")
    print("    Management liability: personal accountability for directors")
    print()
    print("  Real incidents that prove NIS2 is needed:")
    print("    - Odido hack (2024): millions of customer records exposed")
    print("      Supply chain and incident response failures.")
    print("    - Politie cookies hack: Dutch police compromised via")
    print("      trivial web vulnerability. Basic hygiene was missing.")
    print("    - EU hospital ransomware: patient data held hostage")
    print("      because backup/continuity plans did not exist.")
    print()
    print("  tibet-nis2 checks all ten Art. 21(2) sub-articles and")
    print("  generates TIBET provenance tokens for the audit trail.")
    print()
    print("=" * 64)
    return 0


def cmd_articles(args: argparse.Namespace) -> int:
    if args.json:
        data = {}
        for key, spec in NIS2_ARTICLES.items():
            data[spec["ref"]] = {
                "title": spec["title"],
                "description": spec["description"],
                "recommendation": spec["recommendation"],
            }
        print(json.dumps(data, indent=2))
        return 0

    print()
    print("  NIS2 Article 21(2) — Cybersecurity Risk-Management Measures")
    print("  " + "-" * 60)
    print()
    for key, spec in NIS2_ARTICLES.items():
        ref = spec["ref"]
        title = spec["title"]
        print(f"  {ref}")
        print(f"    {title}")
        print(f"    {spec['description'][:80]}...")
        print()
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    auditor = _setup_auditor()
    auditor.assess_all()
    report = auditor.check_compliance()

    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
        return 0

    print()
    print("  NIS2 Compliance Check — Demo Mode")
    print("  " + "-" * 40)
    print(f"  Organization: {report.organization}")
    print(f"  Sector:       {report.sector}")
    print(f"  Timestamp:    {report.timestamp[:19]}Z")
    print()
    print(f"  Overall Score:  {report.overall_score}/100")
    print(f"  Compliant:      {'YES' if report.compliant else 'NO'}")
    print(f"  TIBET tokens:   {report.tibet_chain_length}")
    print()

    print("  Articles:")
    for ref, detail in report.articles_checked.items():
        status = "PASS" if detail["covered"] else "FAIL"
        marker = "[+]" if detail["covered"] else "[-]"
        print(f"    {marker} {ref}: {detail['title'][:50]}  ({status})")
    print()

    if report.gaps:
        print(f"  Gaps ({len(report.gaps)}):")
        for gap in report.gaps[:10]:
            print(f"    - {gap}")
        if len(report.gaps) > 10:
            print(f"    ... and {len(report.gaps) - 10} more")
        print()

    if report.recommendations:
        print(f"  Recommendations:")
        for rec in report.recommendations:
            print(f"    > {rec}")
        print()

    return 0


def cmd_assets(args: argparse.Namespace) -> int:
    auditor = _setup_auditor()
    inventory = auditor.get_inventory()

    if args.json:
        print(json.dumps(inventory.to_dict(), indent=2))
        return 0

    print()
    print("  NIS2 Asset Inventory — Demo Mode")
    print("  " + "-" * 40)
    print(f"  Total assets: {inventory.total}")
    print()

    print("  By category:")
    for cat, count in sorted(inventory.by_category.items()):
        print(f"    {cat:<12} {count}")
    print()

    print("  By risk level:")
    for risk, count in sorted(inventory.by_risk_level.items()):
        print(f"    {risk:<12} {count}")
    print()

    header = f"  {'ID':<16} {'Name':<35} {'Category':<12} {'Type':<12} {'Crit':>4}"
    print(header)
    print("  " + "-" * len(header.strip()))
    for asset in inventory.assets:
        print(
            f"  {asset.id:<16} {asset.name[:34]:<35} "
            f"{asset.category:<12} {asset.asset_type:<12} {asset.criticality:>4}"
        )
    print()
    return 0


def cmd_incident(args: argparse.Namespace) -> int:
    auditor = _setup_auditor()

    # Simulate an Odido-style data breach
    incident = auditor.incident_report(
        asset_id="db-prod-01",
        incident_type="data_breach",
        description=(
            "Unauthorized access to production database detected. "
            "Customer PII potentially exposed. Attack vector: compromised "
            "API credentials from third-party supplier (cf. Odido 2024)."
        ),
        severity="CRITICAL",
    )

    if args.json:
        early = create_early_warning(incident)
        full = create_full_report(incident)
        final = create_final_report(incident)
        print(json.dumps({
            "incident": incident.to_dict(),
            "early_warning": early,
            "full_report": full,
            "final_report": final,
        }, indent=2))
        return 0

    print()
    print("  NIS2 Incident Response Demo")
    print("  " + "-" * 40)
    print("  Scenario: Odido-style data breach")
    print()
    print(f"  Incident ID:   {incident.id}")
    print(f"  Asset:         jis:{incident.asset_id}")
    print(f"  Type:          {incident.incident_type.value}")
    print(f"  Severity:      {incident.severity.value}")
    print(f"  Detected:      {incident.detected_at[:19]}Z")
    print(f"  Status:        {incident.status.value}")
    print(f"  TIBET token:   {incident.tibet_token_id}")
    print()

    # Early warning
    early = create_early_warning(incident)
    print("  --- Art. 23(4)(a): Early Warning (24h) ---")
    print(f"  Deadline:          {incident.early_warning_deadline[:19]}Z")
    print(f"  Hours remaining:   {early['hours_remaining']}")
    print(f"  Suspected malicious: {early['suspected_malicious']}")
    print(f"  Cross-border:      {early['cross_border_impact']}")
    print()

    # Full report
    full = create_full_report(incident)
    print("  --- Art. 23(4)(b): Full Notification (72h) ---")
    print(f"  Deadline:          {incident.full_report_deadline[:19]}Z")
    print(f"  Hours remaining:   {full['hours_remaining']}")
    print(f"  Root cause:        {full['root_cause']}")
    print(f"  Mitigations:       {len(full['mitigation_measures'])} measures")
    print()

    # Final report
    final = create_final_report(incident)
    print("  --- Art. 23(4)(d): Final Report (1 month) ---")
    print(f"  Deadline:          {incident.final_report_deadline[:19]}Z")
    print(f"  Status:            {incident.status.value}")
    print(f"  Timeline events:   {len(final['full_timeline'])}")
    print()

    print(f"  Total TIBET tokens: {len(auditor.provenance)}")
    print()
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  tibet-nis2 Full Demo")
    print("=" * 64)

    # Step 1: Register assets
    print()
    print("  STEP 1: Register Assets")
    print("  " + "-" * 40)

    auditor = NIS2Auditor(organization="Demo BV", sector="essential")
    for asset in _demo_assets():
        auditor.add_asset(asset)
        print(f"    [+] {asset.id:<16} {asset.name} (jis:{asset.id})")

    inventory = auditor.get_inventory()
    print(f"\n    Total: {inventory.total} assets registered")
    print(f"    TIBET tokens: {len(auditor.provenance)}")

    # Step 2: Risk assessment
    print()
    print("  STEP 2: Risk Assessment (Art. 21.2.a)")
    print("  " + "-" * 40)

    assessments = auditor.assess_all()
    for ra in assessments:
        print(
            f"    [{ra.risk_level:<8}] jis:{ra.asset_id}  "
            f"threats={len(ra.threats)}, vulns={len(ra.vulnerabilities)}"
        )

    print(f"\n    TIBET tokens: {len(auditor.provenance)}")

    # Step 3: Compliance check
    print()
    print("  STEP 3: Compliance Check (Art. 21.2 a-j)")
    print("  " + "-" * 40)

    report = auditor.check_compliance()
    print(f"    Score:     {report.overall_score}/100")
    print(f"    Compliant: {'YES' if report.compliant else 'NO'}")
    print(f"    Gaps:      {len(report.gaps)}")
    print()
    for ref, detail in report.articles_checked.items():
        marker = "[+]" if detail["covered"] else "[-]"
        print(f"    {marker} {ref}")

    print(f"\n    TIBET tokens: {len(auditor.provenance)}")

    # Step 4: Supply chain check
    print()
    print("  STEP 4: Supply Chain Check (Art. 21.2.d)")
    print("  " + "-" * 40)

    sc = auditor.supply_chain_check()
    print(f"    Total dependencies: {sc['total_dependencies']}")
    print(f"    Verified:           {sc['verified']}")
    print(f"    Unverified:         {sc['unverified']}")
    print(f"    Compliant:          {'YES' if sc['compliant'] else 'NO'}")
    if sc["risks"]:
        print("    Risks:")
        for risk in sc["risks"][:5]:
            print(f"      - {risk['asset']} -> {risk['dependency']}: {risk['risk']}")

    print(f"\n    TIBET tokens: {len(auditor.provenance)}")

    # Step 5: Incident simulation
    print()
    print("  STEP 5: Incident Simulation (Art. 23)")
    print("  " + "-" * 40)
    print("  Simulating Odido-style data breach on db-prod-01...")
    print()

    incident = auditor.incident_report(
        asset_id="db-prod-01",
        incident_type="data_breach",
        description=(
            "Customer database breach via compromised supplier API key. "
            "PII of 2.3M customers potentially exposed."
        ),
        severity="CRITICAL",
    )

    print(f"    Incident: {incident.id}")
    print(f"    Severity: {incident.severity.value}")

    early = create_early_warning(incident)
    print(f"    24h early warning: {early['hours_remaining']}h remaining")

    full = create_full_report(incident)
    print(f"    72h full report:   {full['hours_remaining']}h remaining")

    create_final_report(incident)
    print(f"    Final report:      deadline {incident.final_report_deadline[:10]}")

    # Summary
    print()
    print("  " + "=" * 40)
    print(f"  DEMO COMPLETE")
    print(f"    Assets:        {inventory.total}")
    print(f"    Assessments:   {len(assessments)}")
    print(f"    Score:         {report.overall_score}/100")
    print(f"    Incidents:     {len(auditor.incidents)}")
    print(f"    TIBET tokens:  {len(auditor.provenance)}")
    print("  " + "=" * 40)

    if args.json:
        print()
        print(auditor.export_report(fmt="json"))

    print()
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-nis2",
        description="NIS2 Directive Compliance Tool with TIBET audit trail",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="NIS2 overview: what, who, deadlines")

    p_check = sub.add_parser("check", help="Run compliance check (demo)")
    p_check.add_argument("-j", "--json", action="store_true", help="JSON output")

    p_assets = sub.add_parser("assets", help="Show asset inventory")
    p_assets.add_argument("-j", "--json", action="store_true", help="JSON output")

    p_incident = sub.add_parser("incident", help="Incident response demo")
    p_incident.add_argument("-j", "--json", action="store_true", help="JSON output")

    p_demo = sub.add_parser("demo", help="Full end-to-end demo")
    p_demo.add_argument("-j", "--json", action="store_true", help="JSON output")

    p_articles = sub.add_parser("articles", help="Show Art. 21(2) sub-articles")
    p_articles.add_argument("-j", "--json", action="store_true", help="JSON output")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "check": cmd_check,
        "assets": cmd_assets,
        "incident": cmd_incident,
        "demo": cmd_demo,
        "articles": cmd_articles,
    }
    sys.exit(commands[args.command](args))
