"""
NIS2 Incident Response Module.

NIS2 Art. 23 mandates strict timelines for incident reporting:
- 24 hours: Early warning to CSIRT/competent authority
- 72 hours: Full incident notification
- 1 month:  Final report with root cause analysis

This module generates compliant reports and tracks deadlines.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Optional


class IncidentType(str, Enum):
    DATA_BREACH = "data_breach"
    RANSOMWARE = "ransomware"
    DDOS = "ddos"
    INSIDER_THREAT = "insider_threat"
    SUPPLY_CHAIN = "supply_chain"
    OTHER = "other"


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class IncidentStatus(str, Enum):
    DETECTED = "DETECTED"
    ANALYZING = "ANALYZING"
    MITIGATING = "MITIGATING"
    RESOLVED = "RESOLVED"


@dataclass
class TimelineEvent:
    """Single event in the incident timeline."""

    timestamp: str
    event: str
    actor: str = "tibet-nis2"


@dataclass
class IncidentReport:
    """
    NIS2 Art. 23 compliant incident report.

    Tracks the full lifecycle: detection, analysis, mitigation, resolution.
    Generates the three required reports: early warning (24h), full
    notification (72h), and final report (1 month).
    """

    id: str
    asset_id: str
    incident_type: IncidentType
    severity: Severity
    description: str
    detected_at: str
    reported_at: str
    status: IncidentStatus = IncidentStatus.DETECTED
    early_warning_deadline: str = ""
    full_report_deadline: str = ""
    final_report_deadline: str = ""
    timeline: list[TimelineEvent] = field(default_factory=list)
    tibet_token_id: str = ""

    def __post_init__(self) -> None:
        detected = datetime.fromisoformat(self.detected_at)
        if not self.early_warning_deadline:
            self.early_warning_deadline = (
                detected + timedelta(hours=24)
            ).isoformat()
        if not self.full_report_deadline:
            self.full_report_deadline = (
                detected + timedelta(hours=72)
            ).isoformat()
        if not self.final_report_deadline:
            self.final_report_deadline = (
                detected + timedelta(days=30)
            ).isoformat()
        if not self.timeline:
            self.timeline = [
                TimelineEvent(
                    timestamp=self.detected_at,
                    event=f"Incident detected: {self.incident_type.value}",
                )
            ]

    def hours_until_early_warning(self) -> float:
        """Hours remaining until the 24h early warning deadline."""
        now = datetime.now(timezone.utc)
        deadline = datetime.fromisoformat(self.early_warning_deadline)
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=timezone.utc)
        delta = (deadline - now).total_seconds() / 3600
        return round(max(0.0, delta), 2)

    def hours_until_full_report(self) -> float:
        """Hours remaining until the 72h full report deadline."""
        now = datetime.now(timezone.utc)
        deadline = datetime.fromisoformat(self.full_report_deadline)
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=timezone.utc)
        delta = (deadline - now).total_seconds() / 3600
        return round(max(0.0, delta), 2)

    def add_event(self, event: str, actor: str = "tibet-nis2") -> None:
        """Append an event to the incident timeline."""
        self.timeline.append(
            TimelineEvent(
                timestamp=datetime.now(timezone.utc).isoformat(),
                event=event,
                actor=actor,
            )
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "asset_id": self.asset_id,
            "incident_type": self.incident_type.value,
            "severity": self.severity.value,
            "description": self.description,
            "detected_at": self.detected_at,
            "reported_at": self.reported_at,
            "status": self.status.value,
            "early_warning_deadline": self.early_warning_deadline,
            "full_report_deadline": self.full_report_deadline,
            "final_report_deadline": self.final_report_deadline,
            "timeline": [
                {"timestamp": e.timestamp, "event": e.event, "actor": e.actor}
                for e in self.timeline
            ],
            "tibet_token_id": self.tibet_token_id,
        }


def create_incident(
    asset_id: str,
    incident_type: str,
    severity: str,
    description: str,
) -> IncidentReport:
    """Create a new incident report with auto-generated ID and timestamps."""
    now = datetime.now(timezone.utc).isoformat()
    return IncidentReport(
        id=f"NIS2-INC-{uuid.uuid4().hex[:8].upper()}",
        asset_id=asset_id,
        incident_type=IncidentType(incident_type),
        severity=Severity(severity),
        description=description,
        detected_at=now,
        reported_at=now,
    )


def create_early_warning(incident: IncidentReport) -> dict:
    """
    NIS2 Art. 23(4)(a): Early warning template.

    Must be submitted within 24 hours of detection. Indicates whether
    the incident is suspected to be caused by unlawful or malicious
    acts and whether it could have a cross-border impact.
    """
    incident.add_event("Early warning report generated (Art. 23.4a)")
    return {
        "report_type": "NIS2 Early Warning — Art. 23(4)(a)",
        "deadline": "24 hours from detection",
        "hours_remaining": incident.hours_until_early_warning(),
        "incident_id": incident.id,
        "reporting_entity": "Organization (fill in)",
        "csirt_recipient": "National CSIRT (fill in)",
        "detection_time": incident.detected_at,
        "incident_type": incident.incident_type.value,
        "severity": incident.severity.value,
        "initial_description": incident.description,
        "suspected_malicious": True if incident.incident_type in (
            IncidentType.RANSOMWARE,
            IncidentType.DATA_BREACH,
            IncidentType.INSIDER_THREAT,
        ) else "To be determined",
        "cross_border_impact": "To be assessed",
        "affected_asset": incident.asset_id,
        "immediate_actions_taken": "Incident response activated, asset isolated",
        "tibet_token_id": incident.tibet_token_id,
    }


def create_full_report(incident: IncidentReport) -> dict:
    """
    NIS2 Art. 23(4)(b): Full incident notification template.

    Must be submitted within 72 hours of detection. Updates the early
    warning with severity assessment, impact, and indicators of compromise.
    """
    incident.status = IncidentStatus.ANALYZING
    incident.add_event("Full incident report generated (Art. 23.4b)")
    return {
        "report_type": "NIS2 Incident Notification — Art. 23(4)(b)",
        "deadline": "72 hours from detection",
        "hours_remaining": incident.hours_until_full_report(),
        "incident_id": incident.id,
        "updates_early_warning": True,
        "reporting_entity": "Organization (fill in)",
        "csirt_recipient": "National CSIRT (fill in)",
        "detection_time": incident.detected_at,
        "incident_type": incident.incident_type.value,
        "severity_assessment": incident.severity.value,
        "description": incident.description,
        "affected_systems": [incident.asset_id],
        "impact_assessment": {
            "users_affected": "To be determined",
            "data_compromised": "To be determined",
            "services_disrupted": "To be determined",
            "financial_impact": "To be determined",
        },
        "indicators_of_compromise": [],
        "root_cause": "Under investigation",
        "mitigation_measures": [
            "Asset isolated from network",
            "Forensic analysis initiated",
            "Backup integrity verified",
        ],
        "cross_border_impact": "To be assessed based on analysis",
        "timeline": [
            {"timestamp": e.timestamp, "event": e.event}
            for e in incident.timeline
        ],
        "tibet_token_id": incident.tibet_token_id,
    }


def create_final_report(incident: IncidentReport) -> dict:
    """
    NIS2 Art. 23(4)(d): Final report template.

    Must be submitted within one month of the incident notification.
    Contains detailed root cause analysis, mitigation applied, and
    cross-border impact where applicable.
    """
    incident.status = IncidentStatus.RESOLVED
    incident.add_event("Final report generated (Art. 23.4d)")
    return {
        "report_type": "NIS2 Final Report — Art. 23(4)(d)",
        "deadline": "1 month from incident notification",
        "incident_id": incident.id,
        "reporting_entity": "Organization (fill in)",
        "csirt_recipient": "National CSIRT (fill in)",
        "incident_summary": {
            "type": incident.incident_type.value,
            "severity": incident.severity.value,
            "description": incident.description,
            "detected_at": incident.detected_at,
            "resolved_at": datetime.now(timezone.utc).isoformat(),
        },
        "root_cause_analysis": {
            "cause": "To be filled — detailed root cause",
            "attack_vector": "To be filled — how the attacker gained access",
            "vulnerabilities_exploited": [],
            "threat_actor": "Unknown / To be determined",
        },
        "impact_final": {
            "users_affected": "Final count",
            "data_compromised": "Final assessment",
            "services_disrupted": "Duration and scope",
            "financial_impact": "Estimated total",
        },
        "mitigation_applied": [
            "Vulnerability patched",
            "Access controls strengthened",
            "Monitoring enhanced",
            "Incident response procedures updated",
        ],
        "lessons_learned": [
            "To be filled — what was learned",
        ],
        "cross_border_impact": "Final assessment",
        "full_timeline": [
            {"timestamp": e.timestamp, "event": e.event, "actor": e.actor}
            for e in incident.timeline
        ],
        "tibet_audit_trail": {
            "token_id": incident.tibet_token_id,
            "chain_available": True,
            "provenance_protocol": "TIBET",
        },
    }
