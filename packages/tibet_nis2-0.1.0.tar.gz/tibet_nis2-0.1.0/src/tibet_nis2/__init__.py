"""
tibet-nis2 — NIS2 Directive Compliance Tool
============================================

Full coverage of NIS2 Article 21(2) sub-articles (a) through (j)
with TIBET audit trail for every assessment, decision, and incident.

NIS2 (Directive 2022/2555) deadline has passed. Every essential and
important entity in the EU must comply. tibet-nis2 checks, scores,
and proves it — or shows you exactly what is missing.

Usage::

    from tibet_nis2 import NIS2Auditor, Asset

    auditor = NIS2Auditor(organization="Acme BV", sector="essential")
    auditor.add_asset(Asset(id="db-01", name="Main DB", category="ESSENTIAL",
                            asset_type="database", owner="ops", criticality=5))
    report = auditor.check_compliance()
    print(f"Score: {report.overall_score}/100, Compliant: {report.compliant}")

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025
"""

from .auditor import (
    NIS2Auditor,
    Asset,
    AssetInventory,
    RiskAssessment,
    ComplianceReport,
)
from .incident import IncidentReport
from .provenance import NIS2Provenance

__version__ = "0.1.0"

__all__ = [
    "NIS2Auditor",
    "Asset",
    "AssetInventory",
    "RiskAssessment",
    "ComplianceReport",
    "IncidentReport",
    "NIS2Provenance",
]
