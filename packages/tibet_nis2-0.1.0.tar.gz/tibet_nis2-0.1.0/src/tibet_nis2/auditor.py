"""
NIS2 Auditor — Core compliance engine.

Covers all ten sub-articles of NIS2 Article 21(2):
  (a) risk analysis and information system security
  (b) incident handling
  (c) business continuity and crisis management
  (d) supply chain security
  (e) security in network/information systems acquisition
  (f) assessing effectiveness of cybersecurity risk management
  (g) basic cyber hygiene practices and cybersecurity training
  (h) cryptography and encryption policies
  (i) human resources security, access control, asset management
  (j) multi-factor authentication

Every check produces a TIBET token. The chain is the audit trail.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from .provenance import NIS2Provenance
from .incident import (
    IncidentReport,
    IncidentType,
    Severity as IncidentSeverity,
    create_incident,
    create_early_warning,
    create_full_report,
    create_final_report,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class AssetCategory(str, Enum):
    ESSENTIAL = "ESSENTIAL"
    IMPORTANT = "IMPORTANT"
    SUPPORTING = "SUPPORTING"


class AssetType(str, Enum):
    SERVER = "server"
    NETWORK = "network"
    IOT = "iot"
    DATABASE = "database"
    APPLICATION = "application"
    CLOUD = "cloud"


class RiskLevel(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Asset:
    """A system, device, or service in the asset inventory."""

    id: str
    name: str
    category: str  # ESSENTIAL / IMPORTANT / SUPPORTING
    asset_type: str  # server / network / iot / database / application / cloud
    owner: str = ""
    ip: str = ""
    criticality: int = 3  # 1 (low) to 5 (critical)
    dependencies: list[str] = field(default_factory=list)
    tibet_token_id: str = ""

    # Compliance properties — populated during checks
    has_risk_policy: bool = False
    has_incident_plan: bool = False
    has_continuity_plan: bool = False
    has_supply_chain_verification: bool = False
    has_secure_acquisition: bool = False
    has_effectiveness_review: bool = False
    has_cyber_hygiene: bool = False
    has_crypto_policy: bool = False
    has_access_control: bool = False
    has_mfa: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category,
            "asset_type": self.asset_type,
            "owner": self.owner,
            "ip": self.ip,
            "criticality": self.criticality,
            "dependencies": self.dependencies,
            "jis": f"jis:{self.id}",
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class AssetInventory:
    """NIS2 Art. 21(2)(i) — Asset inventory overview."""

    assets: list[Asset]
    total: int = 0
    by_category: dict[str, int] = field(default_factory=dict)
    by_risk_level: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "by_category": self.by_category,
            "by_risk_level": self.by_risk_level,
            "assets": [a.to_dict() for a in self.assets],
        }


@dataclass
class RiskAssessment:
    """Risk assessment result for a single asset."""

    asset_id: str
    risk_level: str  # CRITICAL / HIGH / MEDIUM / LOW
    threats: list[str] = field(default_factory=list)
    vulnerabilities: list[str] = field(default_factory=list)
    mitigations: list[str] = field(default_factory=list)
    residual_risk: str = "MEDIUM"
    assessed_at: str = ""
    tibet_token_id: str = ""

    def __post_init__(self) -> None:
        if not self.assessed_at:
            self.assessed_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return {
            "asset_id": self.asset_id,
            "jis": f"jis:{self.asset_id}",
            "risk_level": self.risk_level,
            "threats": self.threats,
            "vulnerabilities": self.vulnerabilities,
            "mitigations": self.mitigations,
            "residual_risk": self.residual_risk,
            "assessed_at": self.assessed_at,
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class ArticleCheck:
    """Result of checking one NIS2 Art. 21(2) sub-article."""

    article: str
    title: str
    covered: bool
    evidence: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)


@dataclass
class ComplianceReport:
    """Full NIS2 Art. 21 compliance report."""

    timestamp: str
    organization: str
    sector: str
    overall_score: int  # 0-100
    compliant: bool
    articles_checked: dict[str, dict] = field(default_factory=dict)
    gaps: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    tibet_chain_length: int = 0

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "organization": self.organization,
            "sector": self.sector,
            "overall_score": self.overall_score,
            "compliant": self.compliant,
            "articles_checked": self.articles_checked,
            "gaps": self.gaps,
            "recommendations": self.recommendations,
            "tibet_chain_length": self.tibet_chain_length,
        }


# ---------------------------------------------------------------------------
# NIS2 Article 21(2) definitions
# ---------------------------------------------------------------------------

NIS2_ARTICLES: dict[str, dict] = {
    "21.2.a": {
        "ref": "Art. 21(2)(a)",
        "title": "Risk analysis and information system security policies",
        "description": (
            "Policies on risk analysis and information system security, "
            "including risk assessments and security policies for information systems."
        ),
        "check_attr": "has_risk_policy",
        "gap_text": "No risk analysis policy documented for asset",
        "recommendation": "Create and document risk analysis policies for all essential assets",
    },
    "21.2.b": {
        "ref": "Art. 21(2)(b)",
        "title": "Incident handling",
        "description": (
            "Policies and procedures for handling incidents, including "
            "detection, analysis, containment, and recovery."
        ),
        "check_attr": "has_incident_plan",
        "gap_text": "No incident handling plan for asset",
        "recommendation": "Implement incident response procedures with 24h/72h NIS2 timelines",
    },
    "21.2.c": {
        "ref": "Art. 21(2)(c)",
        "title": "Business continuity and crisis management",
        "description": (
            "Business continuity, backup management, disaster recovery, "
            "and crisis management."
        ),
        "check_attr": "has_continuity_plan",
        "gap_text": "No business continuity plan for asset",
        "recommendation": "Develop BCP/DR plans with tested backup and recovery procedures",
    },
    "21.2.d": {
        "ref": "Art. 21(2)(d)",
        "title": "Supply chain security",
        "description": (
            "Supply chain security including security-related aspects of "
            "relationships between each entity and its direct suppliers or service providers."
        ),
        "check_attr": "has_supply_chain_verification",
        "gap_text": "No supply chain security verification for asset",
        "recommendation": "Map and verify supply chain dependencies, require security SLAs from suppliers",
    },
    "21.2.e": {
        "ref": "Art. 21(2)(e)",
        "title": "Security in acquisition, development and maintenance",
        "description": (
            "Security in network and information systems acquisition, development "
            "and maintenance, including vulnerability handling and disclosure."
        ),
        "check_attr": "has_secure_acquisition",
        "gap_text": "No secure acquisition/development policy for asset",
        "recommendation": "Implement secure SDLC and procurement security requirements",
    },
    "21.2.f": {
        "ref": "Art. 21(2)(f)",
        "title": "Assessing effectiveness of risk management measures",
        "description": (
            "Policies and procedures to assess the effectiveness of "
            "cybersecurity risk-management measures."
        ),
        "check_attr": "has_effectiveness_review",
        "gap_text": "No effectiveness review process for asset",
        "recommendation": "Schedule periodic security audits and penetration tests",
    },
    "21.2.g": {
        "ref": "Art. 21(2)(g)",
        "title": "Basic cyber hygiene practices and cybersecurity training",
        "description": (
            "Basic cyber hygiene practices and cybersecurity training for "
            "all staff, including awareness programs."
        ),
        "check_attr": "has_cyber_hygiene",
        "gap_text": "No cyber hygiene / training program covering asset",
        "recommendation": "Roll out cybersecurity awareness training and hygiene baselines",
    },
    "21.2.h": {
        "ref": "Art. 21(2)(h)",
        "title": "Policies on use of cryptography and encryption",
        "description": (
            "Policies and procedures regarding the use of cryptography "
            "and, where appropriate, encryption."
        ),
        "check_attr": "has_crypto_policy",
        "gap_text": "No cryptography/encryption policy for asset",
        "recommendation": "Define and enforce encryption standards (at rest, in transit, key management)",
    },
    "21.2.i": {
        "ref": "Art. 21(2)(i)",
        "title": "Human resources security, access control and asset management",
        "description": (
            "Human resources security, access control policies and asset management."
        ),
        "check_attr": "has_access_control",
        "gap_text": "No access control / HR security policy for asset",
        "recommendation": "Implement role-based access control, onboarding/offboarding procedures",
    },
    "21.2.j": {
        "ref": "Art. 21(2)(j)",
        "title": "Multi-factor authentication or continuous authentication",
        "description": (
            "The use of multi-factor authentication or continuous authentication "
            "solutions, secured voice, video and text communications, and secured "
            "emergency communication systems."
        ),
        "check_attr": "has_mfa",
        "gap_text": "No MFA requirement enforced for asset",
        "recommendation": "Enforce MFA on all administrative and remote access points",
    },
}


# ---------------------------------------------------------------------------
# Threat / vulnerability knowledge base (simplified)
# ---------------------------------------------------------------------------

_THREATS_BY_TYPE: dict[str, list[str]] = {
    "server": [
        "Unauthorized access via unpatched vulnerabilities",
        "Ransomware encryption of data and services",
        "Insider threat with privileged access",
    ],
    "network": [
        "DDoS attack on network infrastructure",
        "Man-in-the-middle interception",
        "Unauthorized network access via misconfigured firewall",
    ],
    "iot": [
        "Firmware exploitation via default credentials",
        "Botnet recruitment of IoT devices",
        "Physical tampering with device",
    ],
    "database": [
        "SQL injection leading to data exfiltration",
        "Unauthorized backup access",
        "Privilege escalation via misconfigured roles",
    ],
    "application": [
        "Cross-site scripting (XSS) attacks",
        "Authentication bypass",
        "Supply chain compromise via third-party dependencies",
    ],
    "cloud": [
        "Misconfigured storage bucket exposure",
        "API key leakage",
        "Account hijacking via credential stuffing",
    ],
}

_VULNS_BY_TYPE: dict[str, list[str]] = {
    "server": ["Unpatched OS", "Weak SSH configuration", "Open management ports"],
    "network": ["Default SNMP communities", "Unencrypted management plane", "No network segmentation"],
    "iot": ["Default credentials", "No firmware update mechanism", "Unencrypted communication"],
    "database": ["Weak authentication", "No encryption at rest", "Excessive privileges"],
    "application": ["No input validation", "Outdated dependencies", "Missing security headers"],
    "cloud": ["Overly permissive IAM", "No encryption in transit", "Missing logging"],
}

_MITIGATIONS_BY_TYPE: dict[str, list[str]] = {
    "server": ["Patch management program", "Harden SSH (key-only, no root)", "Network segmentation"],
    "network": ["Implement IDS/IPS", "Encrypt all management traffic", "Segment network zones"],
    "iot": ["Change default credentials", "Enable secure boot", "Isolate IoT VLAN"],
    "database": ["Enforce strong auth + MFA", "Enable TDE/encryption at rest", "Principle of least privilege"],
    "application": ["WAF + input validation", "Dependency scanning (SCA)", "Security headers + CSP"],
    "cloud": ["Least-privilege IAM policies", "Enable encryption everywhere", "Cloud audit logging"],
}


def _criticality_to_risk(criticality: int, category: str) -> str:
    """Map criticality score + category to risk level."""
    if criticality >= 5 or category == "ESSENTIAL":
        return RiskLevel.CRITICAL.value
    if criticality >= 4 or category == "IMPORTANT":
        return RiskLevel.HIGH.value
    if criticality >= 3:
        return RiskLevel.MEDIUM.value
    return RiskLevel.LOW.value


# ---------------------------------------------------------------------------
# NIS2Auditor
# ---------------------------------------------------------------------------

class NIS2Auditor:
    """
    Core NIS2 compliance auditor.

    Register assets, assess risks, check compliance against all ten
    Art. 21(2) sub-articles, generate incident reports, and export
    everything with a full TIBET provenance chain.
    """

    def __init__(
        self,
        organization: str = "Organization",
        sector: str = "essential",
    ):
        self.organization = organization
        self.sector = sector
        self.assets: dict[str, Asset] = {}
        self.risk_assessments: dict[str, RiskAssessment] = {}
        self.incidents: list[IncidentReport] = []
        self.provenance = NIS2Provenance(actor=f"tibet-nis2:{organization}")

    # -- Asset management ---------------------------------------------------

    def add_asset(self, asset: Asset) -> Asset:
        """Register an asset in the inventory."""
        self.assets[asset.id] = asset

        token = self.provenance.create_token(
            token_type="asset_registration",
            asset_id=asset.id,
            article="Art. 21(2)(i)",
            findings={
                "action": "register",
                "name": asset.name,
                "category": asset.category,
                "asset_type": asset.asset_type,
                "criticality": asset.criticality,
                "dependencies": asset.dependencies,
            },
            jis_identity=f"jis:{asset.id}",
        )
        asset.tibet_token_id = token.token_id
        return asset

    def get_inventory(self) -> AssetInventory:
        """Return current asset inventory with category/risk breakdown."""
        assets = list(self.assets.values())
        by_category: dict[str, int] = {}
        by_risk: dict[str, int] = {}

        for asset in assets:
            cat = asset.category
            by_category[cat] = by_category.get(cat, 0) + 1

            risk = _criticality_to_risk(asset.criticality, asset.category)
            by_risk[risk] = by_risk.get(risk, 0) + 1

        return AssetInventory(
            assets=assets,
            total=len(assets),
            by_category=by_category,
            by_risk_level=by_risk,
        )

    # -- Risk assessment ----------------------------------------------------

    def assess_risk(self, asset_id: str) -> RiskAssessment:
        """Perform risk assessment for a single asset."""
        asset = self.assets.get(asset_id)
        if asset is None:
            raise ValueError(f"Asset not found: {asset_id}")

        at = asset.asset_type
        risk_level = _criticality_to_risk(asset.criticality, asset.category)

        threats = list(_THREATS_BY_TYPE.get(at, ["Unknown threat"]))
        vulns = list(_VULNS_BY_TYPE.get(at, ["Unknown vulnerability"]))
        mitigations = list(_MITIGATIONS_BY_TYPE.get(at, ["General hardening"]))

        # Higher criticality = more specific threats
        if asset.criticality >= 4:
            threats.append("Targeted APT attack on high-value asset")
        if asset.dependencies:
            threats.append(f"Cascading failure via {len(asset.dependencies)} dependencies")

        # Residual risk assumes mitigations are in place
        residual = RiskLevel.LOW.value
        if risk_level == RiskLevel.CRITICAL.value:
            residual = RiskLevel.MEDIUM.value
        elif risk_level == RiskLevel.HIGH.value:
            residual = RiskLevel.LOW.value

        assessment = RiskAssessment(
            asset_id=asset_id,
            risk_level=risk_level,
            threats=threats,
            vulnerabilities=vulns,
            mitigations=mitigations,
            residual_risk=residual,
        )

        token = self.provenance.create_token(
            token_type="risk_assessment",
            asset_id=asset_id,
            article="Art. 21(2)(a)",
            findings={
                "risk_level": risk_level,
                "threat_count": len(threats),
                "vulnerability_count": len(vulns),
                "residual_risk": residual,
            },
            related_assets=asset.dependencies,
            jis_identity=f"jis:{asset_id}",
        )
        assessment.tibet_token_id = token.token_id

        self.risk_assessments[asset_id] = assessment
        return assessment

    def assess_all(self) -> list[RiskAssessment]:
        """Run risk assessment on every registered asset."""
        return [self.assess_risk(aid) for aid in self.assets]

    # -- Compliance check ---------------------------------------------------

    def _check_article(self, article_key: str) -> ArticleCheck:
        """Check one NIS2 Art. 21(2) sub-article across all assets."""
        spec = NIS2_ARTICLES[article_key]
        attr = spec["check_attr"]
        ref = spec["ref"]
        title = spec["title"]

        evidence: list[str] = []
        gaps: list[str] = []

        for asset in self.assets.values():
            if getattr(asset, attr, False):
                evidence.append(f"jis:{asset.id}")
            else:
                gaps.append(f"{spec['gap_text']}: jis:{asset.id}")

        covered = len(gaps) == 0 and len(self.assets) > 0

        self.provenance.create_token(
            token_type="compliance_check",
            asset_id=f"org:{self.organization}",
            article=ref,
            findings={
                "article": article_key,
                "title": title,
                "covered": covered,
                "evidence_count": len(evidence),
                "gap_count": len(gaps),
            },
        )

        return ArticleCheck(
            article=ref,
            title=title,
            covered=covered,
            evidence=evidence,
            gaps=gaps,
        )

    def check_compliance(self) -> ComplianceReport:
        """
        Run full NIS2 Art. 21 compliance check.

        Evaluates all ten sub-articles (a) through (j) against every
        registered asset. Returns a ComplianceReport with score, gaps,
        and recommendations.
        """
        if not self.assets:
            return ComplianceReport(
                timestamp=datetime.now(timezone.utc).isoformat(),
                organization=self.organization,
                sector=self.sector,
                overall_score=0,
                compliant=False,
                articles_checked={},
                gaps=["No assets registered — cannot assess compliance"],
                recommendations=["Register all essential and important assets first"],
                tibet_chain_length=len(self.provenance),
            )

        articles_checked: dict[str, dict] = {}
        all_gaps: list[str] = []
        all_recs: list[str] = []
        covered_count = 0

        for key, spec in NIS2_ARTICLES.items():
            check = self._check_article(key)
            articles_checked[check.article] = {
                "title": check.title,
                "covered": check.covered,
                "evidence": check.evidence,
                "gaps": check.gaps,
            }
            if check.covered:
                covered_count += 1
            else:
                all_gaps.extend(check.gaps)
                all_recs.append(spec["recommendation"])

        total_articles = len(NIS2_ARTICLES)
        score = int((covered_count / total_articles) * 100)
        compliant = score == 100

        return ComplianceReport(
            timestamp=datetime.now(timezone.utc).isoformat(),
            organization=self.organization,
            sector=self.sector,
            overall_score=score,
            compliant=compliant,
            articles_checked=articles_checked,
            gaps=all_gaps,
            recommendations=all_recs,
            tibet_chain_length=len(self.provenance),
        )

    # -- Incident response --------------------------------------------------

    def incident_report(
        self,
        asset_id: str,
        incident_type: str,
        description: str,
        severity: str = "HIGH",
    ) -> IncidentReport:
        """
        Generate a NIS2 Art. 23 incident report.

        Creates the incident record with 24h early warning and 72h
        full report deadlines. Records a TIBET provenance token.
        """
        incident = create_incident(
            asset_id=asset_id,
            incident_type=incident_type,
            severity=severity,
            description=description,
        )

        token = self.provenance.create_token(
            token_type="incident",
            asset_id=asset_id,
            article="Art. 23",
            findings={
                "incident_id": incident.id,
                "incident_type": incident_type,
                "severity": severity,
                "description": description,
            },
            jis_identity=f"jis:{asset_id}",
        )
        incident.tibet_token_id = token.token_id
        self.incidents.append(incident)
        return incident

    # -- Supply chain -------------------------------------------------------

    def supply_chain_check(self) -> dict:
        """
        NIS2 Art. 21(2)(d): Supply chain security check.

        Maps dependencies between assets and identifies supply chain
        risks. Every dependency link is a potential attack vector.
        """
        chain_risks: list[dict] = []
        total_deps = 0
        unverified = 0

        for asset in self.assets.values():
            for dep_id in asset.dependencies:
                total_deps += 1
                dep = self.assets.get(dep_id)
                if dep is None:
                    chain_risks.append({
                        "asset": f"jis:{asset.id}",
                        "dependency": dep_id,
                        "risk": "EXTERNAL — dependency not in inventory",
                        "action": "Register dependency or verify supplier security",
                    })
                    unverified += 1
                elif not dep.has_supply_chain_verification:
                    chain_risks.append({
                        "asset": f"jis:{asset.id}",
                        "dependency": f"jis:{dep_id}",
                        "risk": "UNVERIFIED — no supply chain verification",
                        "action": "Conduct supplier security assessment",
                    })
                    unverified += 1

        self.provenance.create_token(
            token_type="supply_chain",
            asset_id=f"org:{self.organization}",
            article="Art. 21(2)(d)",
            findings={
                "total_dependencies": total_deps,
                "unverified": unverified,
                "risks": len(chain_risks),
            },
        )

        return {
            "article": "Art. 21(2)(d) — Supply chain security",
            "organization": self.organization,
            "total_dependencies": total_deps,
            "verified": total_deps - unverified,
            "unverified": unverified,
            "compliant": unverified == 0 and total_deps > 0,
            "risks": chain_risks,
        }

    # -- Export -------------------------------------------------------------

    def export_report(self, fmt: str = "dict") -> dict | str:
        """
        Export full audit report.

        Args:
            fmt: "dict" for Python dict, "json" for JSON string.
        """
        inventory = self.get_inventory()
        report = {
            "tibet_nis2_report": {
                "organization": self.organization,
                "sector": self.sector,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "asset_inventory": inventory.to_dict(),
                "risk_assessments": {
                    aid: ra.to_dict() for aid, ra in self.risk_assessments.items()
                },
                "incidents": [inc.to_dict() for inc in self.incidents],
                "supply_chain": self.supply_chain_check(),
                "compliance": self.check_compliance().to_dict(),
            },
            "provenance": {
                "protocol": "TIBET",
                "chain_length": len(self.provenance),
                "tokens": self.provenance.chain(),
            },
            "metadata": {
                "tool": "tibet-nis2",
                "version": "0.1.0",
                "directive": "EU NIS2 Directive (2022/2555)",
                "tibet_protocol": "draft-vandemeent-tibet-provenance-00",
                "jis_protocol": "draft-vandemeent-jis-identity-00",
            },
        }

        if fmt == "json":
            return json.dumps(report, indent=2)
        return report
