"""Auen - Auto-generate FastAPI CRUD endpoints from SQLModel models."""

from importlib.metadata import PackageNotFoundError, version

from auen.config import (
    ALL_OPERATIONS,
    AuthConfig,
    FilterConfig,
    FilterFieldConfig,
    FilterOp,
    HooksConfig,
    NestedRelationConfig,
    NestedWriteConfig,
    Operation,
    PaginationConfig,
    SchemaConfig,
)
from auen.exceptions import (
    AuenError,
    ConfigurationError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
)
from auen.policy import AllowAll, CrudPolicy
from auen.repository import AsyncCrudRepository, AsyncSqlModelRepository
from auen.router import CrudRouterBuilder
from auen.schemas import SchemaContainer, derive_schema_container, derive_schemas

try:
    __version__ = version("auen")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "ALL_OPERATIONS",
    "AllowAll",
    "AsyncCrudRepository",
    "AsyncSqlModelRepository",
    "AuenError",
    "AuthConfig",
    "ConfigurationError",
    "ConflictError",
    "CrudPolicy",
    "CrudRouterBuilder",
    "FilterConfig",
    "FilterFieldConfig",
    "FilterOp",
    "ForbiddenError",
    "HooksConfig",
    "NestedRelationConfig",
    "NestedWriteConfig",
    "NotFoundError",
    "Operation",
    "PaginationConfig",
    "SchemaConfig",
    "SchemaContainer",
    "__version__",
    "derive_schema_container",
    "derive_schemas",
]
