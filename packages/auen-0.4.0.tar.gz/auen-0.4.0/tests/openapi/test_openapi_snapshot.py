"""OpenAPI snapshot test."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi import FastAPI

SNAPSHOT_DIR = Path(__file__).parent / "snapshots"


def test_openapi_snapshot(app: FastAPI) -> None:
    """OpenAPI schema should be stable."""
    schema = app.openapi()
    snapshot_path = SNAPSHOT_DIR / "openapi.json"

    if not snapshot_path.exists():
        SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        snapshot_path.write_text(json.dumps(schema, indent=2, sort_keys=True))
        pytest.skip("Snapshot created; re-run to verify.")

    expected = json.loads(snapshot_path.read_text())
    # Compare paths and schemas (stable subset)
    assert set(schema["paths"].keys()) == set(expected["paths"].keys())
    assert set(schema.get("components", {}).get("schemas", {}).keys()) == set(
        expected.get("components", {}).get("schemas", {}).keys()
    )
