"""CrudRouterBuilder multi-model tests."""

from __future__ import annotations

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlmodel import Field, SQLModel
from tests.conftest import Book, SessionFactory

from auen import CrudRouterBuilder, Operation


class Author(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str


async def test_build_registers_multiple_routers(get_session: SessionFactory) -> None:
    app = FastAPI()
    routers = (
        CrudRouterBuilder.for_model([Book, Author], get_session)
        .with_operations({Operation.LIST})
        .build_all()
    )
    for router in routers:
        app.include_router(router)

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/books/")
        assert resp.status_code == 200
        assert resp.json() == []

        resp = await client.get("/authors/")
        assert resp.status_code == 200
        assert resp.json() == []
