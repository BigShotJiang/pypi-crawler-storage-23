"""Exception type tests."""

from auen.exceptions import ConflictError


def test_conflict_error_default() -> None:
    err = ConflictError()
    assert err.status_code == 409
    assert err.detail == "Resource conflict"
