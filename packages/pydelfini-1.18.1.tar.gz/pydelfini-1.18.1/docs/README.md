# Documentation

To generate documentation from the source code:

```sh
make html
```
