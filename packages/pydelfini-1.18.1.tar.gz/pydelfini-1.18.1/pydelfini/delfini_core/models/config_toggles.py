from typing import Any
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union

from attrs import define as _attrs_define

from ..models.config_toggles_details import ConfigTogglesDetails
from ..types import UNSET
from ..types import Unset


T = TypeVar("T", bound="ConfigToggles")


@_attrs_define
class ConfigToggles:
    """ConfigToggles model

    Attributes:
        unique_user_email (bool):
        details (Union[Unset, ConfigTogglesDetails]):
    """

    unique_user_email: bool
    details: Union[Unset, "ConfigTogglesDetails"] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        unique_user_email = self.unique_user_email
        details: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.details, Unset):
            details = self.details.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "unique_user_email": unique_user_email,
            }
        )
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`ConfigToggles` from a dict"""
        d = src_dict.copy()
        unique_user_email = d.pop("unique_user_email")

        _details = d.pop("details", UNSET)
        details: Union[Unset, ConfigTogglesDetails]
        if isinstance(_details, Unset):
            details = UNSET
        else:
            details = ConfigTogglesDetails.from_dict(_details)

        config_toggles = cls(
            unique_user_email=unique_user_email,
            details=details,
        )

        return config_toggles
