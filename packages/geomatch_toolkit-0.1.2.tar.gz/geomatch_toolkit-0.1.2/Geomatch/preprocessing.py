"""
GeoMatch Preprocessing Module
=============================

Handles satellite NetCDF file reading and cleaning operations.
"""

import numpy as np
import xarray as xr
import os
from datetime import datetime


def missing2nan(data_values):
    nan_value = np.nan

    if data_values.ndim == 1:
        cleaned_values = [x if x != -2147483647 else nan_value for x in data_values]
    else:
        cleaned_values = np.where(
            data_values == -2147483647,
            nan_value,
            data_values
        )

    return np.array(cleaned_values)


def read_Tropomi_new(fname):

    if not os.path.exists(fname):
        raise FileNotFoundError(fname)

    xr_data_i = xr.open_dataset(fname, group='instrument', engine='netcdf4')
    xr_data_d = xr.open_dataset(fname, group='diagnostics', engine='netcdf4')
    xr_data_m = xr.open_dataset(fname, group='meteo', engine='netcdf4')

    longi = xr_data_i["longitude_center"].values
    lati = xr_data_i["latitude_center"].values
    pixel_id = xr_data_i["pixel_id"].values
    qa_value = xr_data_d['qa_value'].values
    surface_pressure = xr_data_m["surface_pressure"].values

    A_times = missing2nan(xr_data_i["time"][:, :].values)

    mask = np.array([False if x <= -9999 or x >= 9999 else True for x in longi])

    longi = longi[mask]
    lati = lati[mask]
    pixel_id = pixel_id[mask]
    qa_value = qa_value[mask]
    surface_pressure = surface_pressure[mask]
    A_times = A_times[mask]

    mask = qa_value == 1

    longi = longi[mask]
    lati = lati[mask]
    pixel_id = pixel_id[mask]
    surface_pressure = surface_pressure[mask]

    A_time = A_times[mask]
    qa_valuei = qa_value[mask]

    date_string = A_time[:, 0] * 1e4 + A_time[:, 1] * 1e2 + A_time[:, 2]
    time_string = 1e6 + A_time[:, 3] * 1e4 + A_time[:, 4] * 1e2 + A_time[:, 5]

    format_string = '%Y%m%dT%H%M%S'

    ntim1 = [
        datetime.strptime(
            str(int(date_string[x])) + "T" +
            str(int(time_string[x]))[1:7],
            format_string
        ) if not np.isnan(date_string[x]) else np.nan
        for x in range(len(date_string))
    ]

    fnames = [os.path.basename(fname) for _ in range(len(longi))]

    xr_data_i.close()
    xr_data_d.close()
    xr_data_m.close()

    return (
        longi.tolist(),
        lati.tolist(),
        pixel_id.tolist(),
        ntim1,
        surface_pressure.tolist(),
        fnames,
        qa_valuei.tolist()
    )


def read_IASI(fname):

    if not os.path.exists(fname):
        raise FileNotFoundError(fname)

    xr_data = xr.open_dataset(fname, engine="netcdf4")

    longitude = xr_data["lon"].values
    latitude = xr_data["lat"].values
    time = xr_data["time"].values
    ids = xr_data['observation_id'].values

    pressure_levs = xr_data['musica_pressure_levels'].values
    cloud_formation_qf = xr_data['eumetsat_cloud_summary_flag'].values
    fit_qf = xr_data["musica_fit_quality_flag"].values
    nol = xr_data["musica_nol"].values
    cloud_area_fraction = xr_data["eumetsat_cloud_area_fraction"].values

    surface_pressure = np.array([
        pressure_levs[i, int(nol[i]) - 1]
        for i in range(len(nol))
    ])

    xr_data.close()

    mask1 = (cloud_formation_qf == 2) & (
        (cloud_area_fraction == 0) |
        (np.isnan(cloud_area_fraction))
    )

    mask2 = cloud_formation_qf == 1
    mask3 = fit_qf == 3

    mask = (mask1 | mask2) & mask3

    lons = longitude[mask]
    lats = latitude[mask]
    time = time[mask]
    cloud_formation_qf = cloud_formation_qf[mask]
    cloud_area_fractions = cloud_area_fraction[mask]
    fit_qf = fit_qf[mask]
    ids = ids[mask]
    surface_pressure = surface_pressure[mask]

    idz = [str(i) for i in ids]

    fnames = [os.path.basename(fname) for _ in range(len(idz))]

    time = np.datetime_as_string(time, unit='s', timezone='UTC')

    return (
        lons.tolist(),
        lats.tolist(),
        time,
        idz,
        cloud_formation_qf.tolist(),
        fit_qf.tolist(),
        surface_pressure.tolist(),
        cloud_area_fractions.tolist(),
        fnames
    )