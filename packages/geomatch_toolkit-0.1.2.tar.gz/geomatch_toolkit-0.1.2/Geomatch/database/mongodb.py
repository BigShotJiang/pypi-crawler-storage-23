"""
MongoDB connection manager.
"""

import os
from pymongo import MongoClient


class MongoPipelineBase:

    def __init__(self, uri=None, db_name="GeoMatch"):

        self.uri = uri or os.getenv("MONGODB_URI")

        if not self.uri:
            raise ValueError("MongoDB URI missing")

        self.client = MongoClient(self.uri)
        self.db = self.client[db_name]

    def close(self):
        self.client.close()