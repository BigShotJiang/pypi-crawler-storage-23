"""
Satellite ingestion pipeline.
"""

import os
import glob
import numpy as np
from datetime import datetime
from pymongo import InsertOne

from Geomatch.preprocessing import read_Tropomi_new, read_IASI
from .mongodb import MongoPipelineBase


class SatelliteMongoWriter(MongoPipelineBase):

    def write_IASI(self, data_dir):

        collection = self.db["IASI"]

        files = glob.glob(os.path.join(data_dir, "*.nc"))

        for file_path in files:

            lon, lat, tim, dz, cloud_formation, fit_qf, surface_pressure, cloud_area_fraction, fnames = read_IASI(
                file_path
            )

            tim = [np.datetime64(dt).astype(datetime) for dt in tim]

            bulk_data = []

            for i in range(len(lon)):

                bulk_data.append({
                    "time": tim[i],
                    "loc": {"type": "Point", "coordinates": [lon[i], lat[i]]},
                    "id": dz[i],
                    "surface_pressure": surface_pressure[i],
                    "filename": fnames[i],
                    "cloud_summary_flag": cloud_formation[i],
                    "fit_value_flag": fit_qf[i],
                    "cloud_area_fraction": cloud_area_fraction[i],
                })

            if bulk_data:
                collection.insert_many(bulk_data)

    def write_TROPOMI(self, pattern):

        collection = self.db["TROPOMI"]

        files = glob.glob(pattern)

        for file_path in files:

            lon, lat, pixelid, tim, surpres, fnames, qa_value = read_Tropomi_new(
                file_path
            )

            tim = [np.datetime64(dt).astype(datetime) for dt in tim]

            bulk_data = []

            for i in range(len(lon)):

                bulk_data.append({
                    "time": tim[i],
                    "loc": {"type": "Point", "coordinates": [lon[i], lat[i]]},
                    "id": pixelid[i],
                    "surface_pressure": surpres[i],
                    "filename": fnames[i],
                    "qa_value": qa_value[i]
                })

            if bulk_data:
                collection.insert_many(bulk_data)