"""
GeoMatch Matching Postprocessing Extraction Module
==================================================

This module performs matched satellite observation data extraction
after geomatching optimization.

Workflow
--------
1. Reads matched observation indices from Optimal_Matches feather file
2. Loads corresponding satellite NetCDF datasets
3. Extracts scientific retrieval variables
4. Performs parallel processing using ProcessPoolExecutor
5. Saves matched results in serialized pickle format

Sensors Supported
-----------------
- IASI
- TROPOMI

Author: Kanwal Shahzadi
"""
import json
import concurrent.futures
import pandas as pd
import numpy as np
import xarray
from datetime import datetime

from concurrent.futures import ProcessPoolExecutor
import sys
import pickle
import gzip
from tqdm import tqdm
import argparse




def get_data_tropomi(path):
	 """
    Load TROPOMI satellite NetCDF grouped datasets.

    Parameters
    ----------
    path : str
        Directory path or file location of TROPOMI dataset.

    Returns
    -------
    tuple
        xarray dataset objects corresponding to target product,
        meteo, instrument, diagnostics, and side product groups.
    """
	with xarray.open_dataset("path/", group="target_product", engine='netcdf4', decode_coords=True) as x_array1, \
		 xarray.open_dataset("path/"+filename_1, group="meteo", engine='netcdf4', decode_coords=True) as x_array2, \
		 xarray.open_dataset("path/"+filename_1, group="instrument", engine='netcdf4', decode_coords=True) as x_array3, \
		 xarray.open_dataset("path/"+filename_1, group="diagnostics", engine='netcdf4', decode_coords=True) as x_array4, \
		 xarray.open_dataset("path/"+filename_1, group="side_product", engine='netcdf4', decode_coords=True) as x_array5:
		 return x_array1, x_array2, x_array3, x_array4, x_array5

def get_data_iasi(path):
	"""
    Load IASI satellite dataset.

    Parameters
    ----------
    path : str
        Path to IASI NetCDF file.

    Returns
    -------
    xarray.Dataset
        Loaded satellite observation dataset.
    """
	with xarray.open_dataset(path) as x_array:
		 return x_array


def get_data(args):
	 """
    Extract matched satellite observation variables.

    Parameters
    ----------
    args : tuple
        Contains matching indices, offset metrics, and dataset arrays.

    Returns
    -------
    list
        List of dictionaries containing extracted observation metadata
        for IASI and TROPOMI sensors.
    """
	iasiid, tropomiid,odx, odtime, data = args
	try:
		lon_values, lat_values, time_values, CH4_values, apriori_CH4_values, avk_rank_CH4_values, \
		avk_val_CH4_values, reg_CH4_values, lvec_CH4_values,rvect_CH4_values, musica_nol_values, \
		i_h2o_profile_values, pressure_level_values, altitude_levels_values,\
		altitude_tropopause_climatological_values,musica_ghg_error_values, eumetsat_cloud_area_fraction_values,\
		musica_fit_quality_flag_values,eumetsat_cloud_summary_flag_values,id_values, dp_values, dry_air_column_values, ch4_profile_apriori_values, xch4_values,\
		xch4_apriori_values, xch4_column_averaging_kernel_values,xch4_corrected_values, xch4_precision_values,\
		T_altitude_levels_values, surface_pressure_values, longitude_center_values, latitude_center_values,tropomi_time,\
		degrees_of_freedom_ch4_values,qa_values, tropomi_flag_glint_values,tropomi_landflag_values,\
		surface_albedo_nir_values, surface_albedo_swir_values, aerosol_altitude_values,aerosol_column_values,\
		aerosol_optical_thickness_swir_values,aerosol_size_values,oid_values,filename1,filename2 = data
		ind = iasiid #idi source
		ind2 = tropomiid #oid search
		results_dict_I = {
					"sensor_name":"IASI",
					"I_lon":lon_values[ind].tolist(),
					"I_lat":lat_values[ind].tolist(),
					"I_time":time_values[ind],
					"I_ch4_profile": CH4_values[ind][1][:].tolist(),
					"I_ch4_profile_apriori": apriori_CH4_values[ind][1][:].tolist(),
					"I_avk_rank": avk_rank_CH4_values[ind].tolist(),
					"I_avk_val": avk_val_CH4_values[ind][:].tolist(),
					"I_avk_lvec": lvec_CH4_values[:][ind][1][:][:][:].tolist(),
					"I_avk_rvec": rvect_CH4_values[ind][1][:][:].tolist(),
					"I_nol": musica_nol_values[ind].tolist(),
					"I_h2o_profile":i_h2o_profile_values[ind][0][:].tolist(),
					"I_pressure_levels":pressure_level_values[ind][:].tolist(),
					"I_reg":reg_CH4_values[ind,:,1,:].tolist(),
					"I_altitude_levels":altitude_levels_values[ind][:].tolist(),
					"I_altitude_tropopause_climatological":altitude_tropopause_climatological_values[ind].tolist(),
					"I_ch4_error":musica_ghg_error_values[ind][1][0][:].tolist(),
					"I_eumetsat_cloud_area_fraction":eumetsat_cloud_area_fraction_values[ind].tolist(),
					"I_fit_value_flag":musica_fit_quality_flag_values[ind].tolist(),
					"I_cloud_formation_flag":eumetsat_cloud_summary_flag_values[ind].tolist(),
					"dx":odx,
					"dtime":odtime,
					"I_id":id_values[ind].tolist(),
					"filename":filename1
					}

		results_dict_T={
					"sensor_name":"TROPOMI",
					"T_lon":longitude_center_values[ind2].tolist(),
					"T_lat":latitude_center_values[ind2].tolist(),
					"T_time":tropomi_time[ind2].tolist(),
					"T_nol":T_altitude_levels_values[ind2,:].tolist(),
					"T_dp":dp_values[ind2].tolist(),
					"T_dry_air_subcolumns":dry_air_column_values[ind2,:].tolist(),
					"T_CH4": xch4_values[ind2].tolist(),
					"T_ch4_profile_apriori": ch4_profile_apriori_values[ind2].tolist(),
					"T_xch4_apriori": xch4_apriori_values[ind2].tolist(),
					"T_xch4_column_averaging_kernel": xch4_column_averaging_kernel_values[ind2,:].tolist(),
					"T_xch4_corrected": xch4_corrected_values[ind2].tolist(),
					"T_xch4_precision": xch4_precision_values[ind2].tolist(),
					"T_altitude_levels": T_altitude_levels_values[ind2,:].tolist(),
					"T_surface_pressure": surface_pressure_values[ind2].tolist(),
					"T_degrees_of_freedom_ch4":degrees_of_freedom_ch4_values[ind2].tolist(),
					"T_flag_glint":tropomi_flag_glint_values[ind2].tolist(),
					"T_landflag":tropomi_landflag_values[ind2].tolist(),
					"T_surface_albedo_swir":surface_albedo_swir_values[ind2,1].tolist(),
					"T_surface_albedo_nir":surface_albedo_nir_values[ind2,0].tolist(),
					"T_aerosol_altitude":aerosol_altitude_values[ind2].tolist(),
					"T_aerosol_column":aerosol_column_values[ind2].tolist(),
					"T_aerosol_optical_thickness_swir":aerosol_optical_thickness_swir_values[ind2,1].tolist(),
					"T_aerosol_size":aerosol_size_values[ind2].tolist(),
					"T_id":oid_values[ind2].tolist(),
					"T_quality_flag":qa_values[ind2].tolist(),
					"dx":odx,
					"dtime":odtime,
					"filename":filename2,
					}
		return [results_dict_I, results_dict_T]
	except Exception as e:
		print(f"Error processing data for indices {odx} and {idx2}: {e}")
		return None
def processing(args1):
	"""
    Worker function for parallel geomatch extraction.

    Performs sensor-specific retrieval extraction for matched
    observation pairs.

    Uses multiprocessing compatible execution model.

    Parameters
    ----------
    args1 : tuple
        Processing arguments including observation indices,
        timing offsets, datasets, filenames, and sensor identifiers.

    Returns
    -------
    list or None
        Extracted matching observation records.
    """
				#print(args1)
				id1,id2,odx, odtime,x_array1, x_array2, x_array3, x_array4, x_array5, x_array, filename_1, filename_2,sensor1,sensor2=args1
				if sensor1 == "IASI":
						iasiid = id1
						tropomiid = id2
				else:
						tropomiid = id1
						iasiid = id2
				data_dict = {"sensors": [], "itr": []}
				itr = 0
				data =(x_array["lon"].values,
				x_array["lat"].values,
				x_array["time"].values,
				x_array["musica_ghg"].values,
				x_array["musica_ghg_apriori"].values,
				x_array["musica_ghg_avk_rank"].values,
				x_array["musica_ghg_avk_val"].values,
				x_array["musica_ghg_reg"].values,
				x_array["musica_ghg_avk_lvec"].values,
				x_array["musica_ghg_avk_rvec"].values,
				x_array["musica_nol"].values,
				x_array["musica_wv"].values,
				x_array["musica_pressure_levels"].values,
				x_array["musica_altitude_levels"].values,
				x_array["altitude_tropopause_climatological"].values,
				x_array["musica_ghg_error"].values, 
				x_array["eumetsat_cloud_area_fraction"].values,
				x_array["musica_fit_quality_flag"].values,
				x_array["eumetsat_cloud_summary_flag"].values,
				x_array["observation_id"].values,
				x_array2["dp"].values,
				x_array2["dry_air_subcolumns"].values,
				x_array1["ch4_profile_apriori"].values,
				x_array1["xch4"].values,
				x_array1["xch4_apriori"].values,
				x_array1["xch4_column_averaging_kernel"].values,
				x_array1["xch4_corrected"].values, 
				x_array1["xch4_precision"].values,
				x_array2["altitude_levels"].values,
				x_array2["surface_pressure"].values,
				x_array3["longitude_center"].values,
				x_array3["latitude_center"].values,
				x_array3["time"].values,
				x_array4["degrees_of_freedom_ch4"].values,
				x_array4["qa_value"].values,
				x_array3["glintflag"].values,
				x_array2["landflag"].values,
				x_array5["surface_albedo"].values,
				x_array5["surface_albedo"].values,
				x_array5["aerosol_altitude"].values,
				x_array5["aerosol_column"].values,
				x_array5["aerosol_optical_thickness"].values,
				x_array5["aerosol_size"].values,
				x_array3["pixel_id"].values,
				filename_1,
				filename_2)
				in_data = iasiid,tropomiid,odx, odtime,data
				return get_data(in_data)
def process_group(df, filename_1,folder,sensor1,sensor2):
	"""
    Process grouped geomatching results.

    Parameters
    ----------
    df : pandas.DataFrame group iterator
        Grouped matching dataframe.

    filename_1 : str
        Source dataset filename.

    folder : str
        Output folder for extracted pickle results.

    sensor1 : str
        Primary sensor name.

    sensor2 : str
        Secondary sensor name.

    Returns
    -------
    None
    """
		temp = 0
		group_df = df
		for group2, groupdf2 in group_df:
				filename_2 = group2
				idi = groupdf2["ids"].values
				oid = groupdf2["oid"].values
				odx = groupdf2["odifftime"].values
				odtime = groupdf2["odiffdist"].values
				#oqa = groupdf2["oqa"].values
				#filename_1 = groupdf2["fns"].values
				idi = [int(x)-1 for x in idi]
				oid = [int(x)-1 for x in oid]
				odiffdist = [x for x in odx]
				odtime = [x for x in odtime]
				#if IASI in TROPOMI then filename_2 otherwise filename_1
				if sensor1 =="IASI":
						year = filename_2[41:45]
				else: 
						year = filename_1[41:45]
				#oqa = [x for x in oqa]
				#filename_1 = filename_1[0]
				#print(groupdf2["lons"],groupdf2["olon"])
				uindex = groupdf2["index"].values
				if sensor1 == "IASI":
						x_array = get_data_iasi(filename_2,year) #here i have to check IASI oder TROPOMI
						x_array1, x_array2, x_array3, x_array4, x_array5 = get_data_tropomi(filename_1)
						
				else:
						x_array = get_data_iasi(filename_1,year) #here i have to check IASI oder TROPOMI
						x_array1, x_array2, x_array3, x_array4, x_array5 = get_data_tropomi(filename_2)
				
				input_data = [(oid[j], idi[j], odiffdist[j], odtime[j],x_array1, x_array2, x_array3, x_array4, x_array5, x_array, filename_2, filename_1,sensor1,sensor2) for j in range(len(oid))]
				result_col = {"data": []}
				file_idx = 0
				idx = 0
				for result in map(processing, input_data):
						if result:
								result_col["data"].append(result)
								#print(result_col)
								idx += 1
								if idx % 500 == 0:
										with open(folder+"/"+filename_1+"_"+filename_2+"_"+str(file_idx)+".pkl", 'wb') as pkl_file:
												#print("saving-------------")
												pickle.dump(result_col, pkl_file)
												result_col = {"data": []}
												file_idx += 1
				# Write the remaining results if any
				if result_col["data"]:
						with open(folder+"/"+filename_1+"_"+filename_2+"_"+str(file_idx)+".pkl", 'wb') as pkl_file:
								pickle.dump(result_col, pkl_file)

def main():
	"""
    Command-line interface entry point.

    Usage
    -----
    python script.py Optimal_Matches.feather output_folder sensor1 sensor2

    Performs parallel matched observation extraction.
    """
		parser = argparse.ArgumentParser(description="Process Optimal Matches feather file.")
		parser.add_argument("filepath", type=str, help="Path to the Optimal_Matches.feather file")
		parser.add_argument("folderpath", type=str, help="folder where extracting data will be..")
		parser.add_argument("sensor1",type=str,help="name of the first sensor")
		parser.add_argument("sensor2",type=str,help="name of the second sensor")
		args = parser.parse_args()
		file_path = args.filepath
		folder =  args.folderpath
		sensor1 = args.sensor1
		sensor2 = args.sensor2
		print(file_path)
		temp = 0
		dff = pd.read_feather(file_path)
		dff.reset_index(inplace=True)
		result_df_s = dff.groupby('fns') #source
		all_groups = []
		
		for group, group_df_c in result_df_s:
				current_time = datetime.now()
				print("Start Time:", current_time)
				filename_1 = group
				#print(filename_1)
				group_dfc = group_df_c.groupby("ofn")
				#print(group_df_c)
				print("-----------"+str(temp)+"--------------")
				all_groups.append((group_dfc, filename_1))
		#print(all_groups), x_array2, x_array3, x_array4, x_array5
		with ProcessPoolExecutor(max_workers=25) as executor:
				futures = [executor.submit(process_group, group, filename,folder,sensor1,sensor2) for group, filename in all_groups]
				
				# Manually update progress bar
				with tqdm(total=len(futures)) as pbar:
						for future in futures:
								future.result()
								pbar.update(1)

if __name__ == "__main__":
		main()
