"""
Core utility functions shared across the project.

This module provides common utilities to avoid code duplication.
"""

from django.http import HttpRequest


def get_client_ip(request: HttpRequest) -> str:
    """
    Extract client IP address from request, handling proxies and load balancers.

    Checks headers in order of priority:
    1. HTTP_X_FORWARDED_FOR (standard proxy header, takes first IP in chain)
    2. HTTP_X_REAL_IP (nginx/reverse proxy header)
    3. REMOTE_ADDR (direct connection)

    Args:
        request: Django HTTP request object

    Returns:
        Client IP address as a string, or empty string if unavailable.
    """
    # Check for forwarded IP (behind proxy/load balancer)
    x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded_for:
        return x_forwarded_for.split(",")[0].strip()

    # Check for real IP header (nginx)
    x_real_ip = request.META.get("HTTP_X_REAL_IP")
    if x_real_ip:
        return x_real_ip.strip()

    # Fallback to remote address
    return request.META.get("REMOTE_ADDR", "")
