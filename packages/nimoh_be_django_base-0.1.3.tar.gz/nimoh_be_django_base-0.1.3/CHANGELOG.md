# Changelog

All notable changes to `nimoh-be-django-base` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

_No unreleased changes._

---

## [0.1.3] — 2026-02-20

### Fixed

- **`get_base_apps()`** — renamed kwargs `monitoring=` / `privacy=` / `channels=` to
  `include_monitoring=` / `include_privacy=` (dropped non-existent `channels=` parameter).
  Template `config/settings/base.py.j2` updated to match.
- **`get_base_spectacular_settings()`** — added `title`, `description`, and `version` parameters
  (template was already passing them; method now accepts and uses them).
- **`get_base_logging()`** — added `log_level` parameter; returned dict now includes a `loggers`
  section with `nimoh_base` and `django` sub-loggers (required by generated `development.py`).
- **`nimoh_base_urlpatterns()`** — renamed kwargs `monitoring=` / `privacy=` / `api_docs=` to
  `include_monitoring=` / `include_privacy=` / `include_schema=`.
  Template `config/urls.py.j2` updated to match.
- **`conf/urls.py`** — fixed import of health check view: was
  `from nimoh_base.core.health import health_check_view` (non-existent); corrected to
  `from nimoh_base.monitoring.views import health_check`.
- **Jinja2 boolean rendering** — replaced `{{ var | lower }}` (renders Python `True` as JSON
  `true`) with `{{ 'True' if var else 'False' }}` in `base.py.j2` and `urls.py.j2`.
- **`AUTH_USER_MODEL` in template** — was `'{{ project_slug }}.User'`; corrected to
  `'nimoh_auth.User'` (custom User model lives in the package, not the consumer project).
- **`read_env()` path** — template now resolves the project root via
  `pathlib.Path(__file__).resolve().parent.parent.parent` and passes it explicitly to
  `environ.Env.read_env()`. Fixes `django-environ ≥0.9` behaviour where `read_env()` without
  arguments looks in the caller's directory (`config/settings/`) instead of the project root.
- **Default `DATABASE_URL` in template** — replaced invalid `django.db.backends.postgresql://…`
  scheme with the correct `postgresql://…` scheme.
- **Celery broker / result-backend URLs** — template default was `env('REDIS_URL') + '/N'`,
  producing a double-path URL (`redis://localhost:6379/0/1`). Replaced with
  `_REDIS_BASE = env('REDIS_URL').rsplit('/', 1)[0]` to obtain the base URL, then appended `/1`
  and `/2` separately.
- **`SecurityHeadersMiddleware._apply_core_headers()`** — replaced `response.pop("Server", None)`
  (dict method, not available on `HttpResponse`) with a `del response["Server"]` guarded by
  `try / except KeyError`. Fixes `AttributeError: 'JsonResponse' object has no attribute 'pop'`
  on every request through the middleware.

---

## [0.1.2] — 2026-02-20

### Fixed

- **`auth.admin`** — replaced module-level `from apps.profiles.models import UserProfileBasic`
  and `from apps.profiles.admin import UserProfileBasicAdminForm` with a `_get_configured_profile_model()`
  helper using `NIMOH_BASE['PROFILE_MODEL']`. The `UserProfileBasicInline` is only registered if
  a profile model is configured; otherwise it is skipped gracefully.
- **`auth.admin.create_missing_profiles`** — replaced hardcoded `UserProfileBasic.objects` with
  the configured `ProfileModel` resolved at call time.
- **`privacy.utils.gdpr`** — removed module-level `from apps.profiles.models import UserProfileBasic`;
  both `except UserProfileBasic.DoesNotExist` clauses replaced with the portable
  `except ObjectDoesNotExist` from `django.core.exceptions`.

---

## [0.1.1] — 2026-02-20

### Fixed

- **`privacy.services`** — replaced hardcoded `from apps.profiles.models import UserProfileBasic`
  with a configurable lookup via `NIMOH_BASE['PROFILE_MODEL']` (e.g. `'profiles.UserProfileBasic'`).
  Raises `ImproperlyConfigured` with a clear message if the setting is absent.
- **`privacy.tasks`** — corrected indentation inside `try:` block that caused
  `IndentationError` at import time in the 0.1.0 sdist.
- **Missing base dependencies** — added `Pillow>=9.0` and `user-agents>=2.2` to the
  package's required dependencies (both were hard imports but omitted from `pyproject.toml`).

---

## [0.1.0] — 2025-02-19

Initial alpha release.  Extracted from the `tast-be-app` internal backend over
seven phases of debranding, decoupling, scaffolding, testing, and documentation.

### Added

#### Core (`nimoh_base.core`)
- `TimeStampedModel` and `SoftDeleteModel` abstract base models
- `SecurityHeadersMiddleware` — configurable `Server:` header, HSTS, frame-options
- `PerformanceMonitoringMiddleware` — per-request HTTP/DB metrics with optional DB persistence
- SQL injection guard middleware
- Custom DRF throttle classes (burst + sustained)
- Standardised DRF exception handler returning consistent JSON error envelopes
- `NimohBaseSettings` — composable helpers for `INSTALLED_APPS`, `MIDDLEWARE`,
  `REST_FRAMEWORK`, `SIMPLE_JWT`, `CACHES`, `LOGGING`
- `validate_nimoh_base_settings()` — asserts required `NIMOH_BASE` keys at startup
- `nimoh_setting(key, default=…)` — safe accessor for `NIMOH_BASE` values

#### Auth (`nimoh_base.auth`)
- `AbstractNimohUser` — email-primary swappable user model with fields:
  `email`, `username`, `email_verified`, `email_verified_at`,
  `failed_login_attempts`, `locked_until`
- Account-lock helpers: `lock_account()`, `unlock_account()`,
  `record_failed_login()`, `record_successful_login()`, `is_account_locked()`
- JWT authentication (access + rotating refresh) via `djangorestframework-simplejwt`
- Device-session tracking with `User-Agent` parsing and mobile-client detection
- MFA (TOTP) registration, verify, and disable endpoints
- Email verification flow (send, confirm, resend)
- Password-reset flow (request, confirm)
- HIBP Pwned Passwords validator on registration and password change
- Audit log for login/logout/password-change events
- Registration, login, refresh, logout, user-detail REST endpoints

#### Monitoring (`nimoh_base.monitoring`)
- HTTP performance metrics model and API endpoint
- DB query-count per-request tracking
- Liveness (`/health/`) and readiness (`/health/ready/`) health-check endpoints
- K8s / Docker-compatible JSON health responses

#### Privacy (`nimoh_base.privacy`)
- `PrivacyProfile` model (one-per-user) with consent and visibility fields
- Consent records and data-processing log endpoints
- GDPR data-export endpoint (async, emailed to user)
- Data-deletion confirmation flow

#### Config (`nimoh_base.conf`)
- `nimoh_base_urlpatterns(api_prefix, *, include_auth, include_monitoring,
  include_privacy, include_schema, include_health)` — one-call URL registration
- `make_celery(settings_module=None)` — Celery app factory
- `NIMOH_BASE_SCHEMA`, `NIMOH_BASE_DEFAULTS`, `NIMOH_BASE_REQUIRED_KEYS`

#### CLI (`nimoh_base.cli`) — requires `[cli]` extra
- `nimoh-base init` — interactive project scaffolding with Jinja2 templates
- `nimoh-base check` — pre-flight `NIMOH_BASE` validation
- `nimoh-base config-template` — prints a ready-to-edit `NIMOH_BASE` snippet

#### Testing utilities
- `pytest-django` integration; `conftest.py` with session-scoped DB fixtures
- `UserFactory` and `create_user_with_profile` helpers
- Full test suite: 119 tests across Python 3.12 + 3.13 / Django 5.1 matrix
- `tox.ini` + GitHub Actions CI workflow

#### Documentation
- Comprehensive `README.md` with Quick Start, CLI walkthrough, URL reference
- `docs/SETTINGS.md` — full `NIMOH_BASE` key reference
- `docs/EXTENDING.md` — user-model subclassing, template/view/middleware overrides
- `docs/MIGRATION_GUIDE.md` — step-by-step for new and existing projects

### App label changes (from internal tast-be-app)

| Old label | New label |
|-----------|-----------|
| `core` (`apps.core`) | `nimoh_core` |
| `authentication` (`apps.authentication`) | `nimoh_auth` |
| `monitoring` (`apps.monitoring`) | `nimoh_monitoring` |
| `privacy` (`apps.privacy`) | `nimoh_privacy` |

> See [docs/MIGRATION_GUIDE.md](docs/MIGRATION_GUIDE.md) for full migration instructions.

---

[Unreleased]: https://github.com/ThriledLokki983/nimoh-be-django-base/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ThriledLokki983/nimoh-be-django-base/releases/tag/v0.1.0
