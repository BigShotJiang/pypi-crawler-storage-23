"""etcdrpc package - uses pre-generated protobuf files."""

# 简单的检查，如果文件不存在则报错提示（防御性编程）
from pathlib import Path

_current_dir = Path(__file__).parent
if not (_current_dir / "rpc_pb2.py").exists():
    raise ImportError(
        "Protobuf modules not found. This package might be incorrectly installed."
    )

# 扁平化导出
from etcdrpc.rpc_pb2 import *
from etcdrpc.rpc_pb2_grpc import *

# 获取所有非私有成员
__all__ = [name for name in globals().keys() if not name.startswith("_")]
