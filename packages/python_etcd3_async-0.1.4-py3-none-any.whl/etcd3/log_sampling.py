"""Log sampling utilities for etcd3 client.

This module provides sampling strategies to control log volume in high-throughput
scenarios, ensuring that important logs are always captured while reducing noise.
"""

import logging
import random
import time
from contextvars import ContextVar
from enum import Enum, auto
from typing import Optional


class SamplingStrategy(Enum):
    """Log sampling strategies.

    - ALWAYS: Always log (no sampling)
    - RATE: Sample at a fixed rate (e.g., 10%)
    - DYNAMIC: Adjust sampling rate based on log volume
    - LEVEL_BASED: Different sampling by log level
    """

    ALWAYS = auto()
    RATE = auto()
    DYNAMIC = auto()
    LEVEL_BASED = auto()


class LogSampler:
    """Log sampler with multiple strategies.

    Controls log volume by sampling non-critical logs based on configured
    strategy. Error logs are always emitted regardless of sampling.

    Example:
        >>> sampler = LogSampler(strategy=SamplingStrategy.RATE, rate=0.1)
        >>> if sampler.should_log(logging.INFO, "kv.get"):
        ...     logger.info("Operation completed")
    """

    def __init__(
        self,
        strategy: SamplingStrategy = SamplingStrategy.ALWAYS,
        rate: float = 1.0,
        burst: int = 100,
        min_interval: float = 0.0,
        level_rates: Optional[dict] = None,
    ):
        """Initialize log sampler.

        :param strategy: Sampling strategy to use
        :param rate: Sampling rate (0.0-1.0), 1.0 = always
        :param burst: Maximum burst size for dynamic sampling
        :param min_interval: Minimum interval between logs of same type (seconds)
        :param level_rates: Per-level rates for LEVEL_BASED strategy
        """
        self.strategy = strategy
        self.rate = max(0.0, min(1.0, rate))
        self.burst = burst
        self.min_interval = min_interval
        self.level_rates = level_rates or {
            logging.DEBUG: 0.1,
            logging.INFO: 0.5,
            logging.WARNING: 1.0,
        }

        # Context-local state for dynamic sampling
        self._counters: ContextVar[dict] = ContextVar("sampler_counters", default={})
        self._timestamps: ContextVar[dict] = ContextVar(
            "sampler_timestamps", default={}
        )

    def should_log(
        self,
        level: int,
        operation: Optional[str] = None,
    ) -> bool:
        """Determine if a log should be emitted.

        :param level: Log level (from logging module)
        :param operation: Operation identifier for per-operation sampling
        :returns: True if log should be emitted
        """
        # Errors are always logged
        if level >= logging.ERROR:
            return True

        # Apply strategy
        if self.strategy == SamplingStrategy.ALWAYS:
            return True

        if self.strategy == SamplingStrategy.RATE:
            return random.random() < self.rate

        if self.strategy == SamplingStrategy.LEVEL_BASED:
            level_rate = self.level_rates.get(level, 1.0)
            return random.random() < level_rate

        if self.strategy == SamplingStrategy.DYNAMIC:
            return self._dynamic_sample(operation)

        return True

    def _dynamic_sample(self, operation: Optional[str]) -> bool:
        """Dynamic sampling based on token bucket algorithm.

        :param operation: Operation identifier
        :returns: True if should log
        """
        key = operation or "default"
        current_time = time.time()

        # Check minimum interval
        if self.min_interval > 0:
            timestamps = self._timestamps.get()
            last_time = timestamps.get(key, 0)
            if current_time - last_time < self.min_interval:
                return False

        # Token bucket: allow burst, then sample
        counters = self._counters.get()
        count = counters.get(key, 0)

        if count < self.burst:
            # Within burst allowance
            counters[key] = count + 1
            timestamps = self._timestamps.get()
            timestamps[key] = current_time
            return True

        # Beyond burst, sample at rate
        if random.random() < self.rate:
            timestamps = self._timestamps.get()
            timestamps[key] = current_time
            return True

        return False

    def reset(self):
        """Reset sampler state.

        Clears all counters and timestamps. Useful for testing or when
        log volume characteristics change significantly.
        """
        self._counters.set({})
        self._timestamps.set({})


# Global sampler instance
_default_sampler: Optional[LogSampler] = None


def get_sampler() -> LogSampler:
    """Get the global log sampler instance.

    Creates a default sampler if none exists.

    :returns: Global LogSampler instance
    """
    global _default_sampler
    if _default_sampler is None:
        _default_sampler = LogSampler()
    return _default_sampler


def set_sampler(sampler: LogSampler):
    """Set the global log sampler instance.

    :param sampler: LogSampler instance to use globally

    Example:
        >>> new_sampler = LogSampler(strategy=SamplingStrategy.RATE, rate=0.5)
        >>> set_sampler(new_sampler)
    """
    global _default_sampler
    _default_sampler = sampler


def should_log(
    level: int,
    operation: Optional[str] = None,
) -> bool:
    """Convenience function to check if should log using global sampler.

    :param level: Log level
    :param operation: Operation identifier
    :returns: True if should log
    """
    return get_sampler().should_log(level, operation)


def configure_from_env() -> LogSampler:
    """Configure sampler from environment variables.

    Environment variables (unified with ETCD_OBS_ prefix):
    - ETCD_OBS_LOG_SAMPLE_STRATEGY: "always", "rate", "dynamic", "level_based"
    - ETCD_OBS_LOG_SAMPLE_RATE: Float between 0.0 and 1.0
    - ETCD_OBS_LOG_SAMPLE_BURST: Integer burst size for dynamic sampling

    :returns: Configured LogSampler
    """
    import os

    ENV_PREFIX = "ETCD_OBS_"

    strategy_str = os.environ.get(f"{ENV_PREFIX}LOG_SAMPLE_STRATEGY", "always").upper()
    strategy_map = {
        "ALWAYS": SamplingStrategy.ALWAYS,
        "RATE": SamplingStrategy.RATE,
        "DYNAMIC": SamplingStrategy.DYNAMIC,
        "LEVEL_BASED": SamplingStrategy.LEVEL_BASED,
    }
    strategy = strategy_map.get(strategy_str, SamplingStrategy.ALWAYS)

    rate = float(os.environ.get(f"{ENV_PREFIX}LOG_SAMPLE_RATE", "1.0"))
    burst = int(os.environ.get(f"{ENV_PREFIX}LOG_SAMPLE_BURST", "100"))

    sampler = LogSampler(strategy=strategy, rate=rate, burst=burst)
    set_sampler(sampler)
    return sampler
