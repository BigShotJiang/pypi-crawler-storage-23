"""Monitoring utilities for etcd3 async client.

.. deprecated::
    Use etcd3.exporters.prometheus instead for metrics collection.

This module provides monitoring functionality for the etcd3 async client,
including metrics collection and logging utilities.
"""

# Re-export from prometheus exporter
from etcd3.exporters.prometheus import (
    get_metrics_interface as get_monitor,
    monitor_request,
)

__all__ = ["get_monitor", "monitor_request"]
