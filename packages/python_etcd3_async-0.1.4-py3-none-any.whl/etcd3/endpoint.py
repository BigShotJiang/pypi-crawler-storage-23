"""Base endpoint implementation for etcd3 client.

This module provides the BaseEndpoint class that contains shared logic
for both synchronous and asynchronous endpoints.
"""

import grpc
import time


class BaseEndpoint:
    """Base endpoint with shared logic.

    :param str host: Endpoint host
    :param int port: Endpoint port
    :param bool secure: Use secure channel, default True
    :param creds: Credentials to use for secure channel, required if
                  secure=True
    :type creds: grpc.ChannelCredentials, optional
    :param time_retry: Seconds to wait before retrying this endpoint after
                       failure, default 300.0
    :type time_retry: int or float
    :param opts: Additional gRPC options
    :type opts: dict, optional
    """

    def __init__(
        self, host, port, secure=True, creds=None, time_retry=300.0, opts=None
    ):
        self.host = host
        self.netloc = f"{host}:{port}"
        self.secure = secure
        self.protocol = "https" if secure else "http"
        if self.secure and creds is None:
            raise ValueError("Please set TLS credentials for secure connections")
        self.credentials = creds
        self.time_retry = time_retry
        self.opts = opts
        self.in_use = False
        self.last_failed = 0
        self.channel = None  # To be set by subclasses

    def fail(self):
        """Transition the endpoint to a failed state."""
        self.in_use = False
        self.last_failed = time.time()

    def use(self):
        """Transition the endpoint to an active state."""
        if self.is_failed():
            raise ValueError("Trying to use a failed node")
        self.in_use = True
        self.last_failed = 0
        return self.channel

    def is_failed(self):
        """Check if the current endpoint is failed."""
        return (time.time() - self.last_failed) < self.time_retry

    def is_healthy(self):
        """Check if the endpoint is healthy.

        Only READY state is considered healthy. CONNECTING state is excluded
        to ensure the connection is fully established before use.

        :returns: True if the endpoint is healthy (READY state)
        :rtype: bool
        """
        if self.channel is None:
            return False
        try:
            state = self.channel.get_state()
            # Only READY is considered healthy, not CONNECTING
            return state == grpc.ChannelConnectivity.READY
        except Exception:
            return False

    def __str__(self):
        return f"Endpoint({self.protocol}://{self.netloc})"
