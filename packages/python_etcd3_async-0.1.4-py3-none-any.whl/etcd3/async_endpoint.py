"""Async endpoint implementation for etcd3 client.

This module provides the AsyncEndpoint class for managing etcd cluster endpoints
in async operations.
"""

import asyncio

import grpc

from etcd3.endpoint import BaseEndpoint


class AsyncEndpointConfig:
    """Configuration for AsyncEndpoint creation.

    :param str host: Endpoint host
    :param int port: Endpoint port
    :param bool secure: Use secure channel, default True
    :param creds: Credentials to use for secure channel, required if
                  secure=True
    :type creds: grpc.ChannelCredentials, optional
    :param time_retry: Seconds to wait before retrying this endpoint after
                       failure, default 300.0
    :type time_retry: int or float
    :param opts: Additional gRPC options
    :type opts: dict, optional
    """

    def __init__(
        self, host, port, secure=True, creds=None, time_retry=300.0, opts=None
    ):
        self.host = host
        self.port = port
        self.secure = secure
        self.creds = creds
        self.time_retry = time_retry
        self.opts = opts


class AsyncEndpoint(BaseEndpoint):
    """Represents an etcd cluster endpoint for async operations.

    :param config: AsyncEndpointConfig object with endpoint configuration
    :param str host: Endpoint host (ignored if config is provided)
    :param int port: Endpoint port (ignored if config is provided)
    :param bool secure: Use secure channel, default True (ignored if config is provided)
    :param creds: Credentials to use for secure channel, required if
                  secure=True (ignored if config is provided)
    :type creds: grpc.ChannelCredentials, optional
    :param time_retry: Seconds to wait before retrying this endpoint after
                       failure, default 300.0 (ignored if config is provided)
    :type time_retry: int or float
    :param opts: Additional gRPC options (ignored if config is provided)
    :type opts: dict, optional
    """

    def __init__(
        self,
        config=None,
        host=None,
        port=None,
        secure=True,
        creds=None,
        time_retry=300.0,
        opts=None,
    ):
        # Use config object if provided, otherwise use individual parameters
        if config is not None:
            host = config.host
            port = config.port
            secure = config.secure
            creds = config.creds
            time_retry = config.time_retry
            opts = config.opts

        if host is None or port is None:
            raise ValueError("Host and port must be provided")

        super().__init__(host, port, secure, creds, time_retry, opts)
        self.channel = self._mkchannel(opts)

    def is_healthy(self):
        """Check if the endpoint is healthy.

        Only READY state is considered healthy. CONNECTING state is excluded
        to ensure the connection is fully established before use.

        :returns: True if the endpoint is healthy (READY state)
        :rtype: bool
        """
        try:
            state = self.channel.get_state()
            # Only READY is considered healthy, not CONNECTING
            return state == grpc.ChannelConnectivity.READY
        except Exception:
            return False

    async def health_check_async(self):
        """Perform an asynchronous health check using gRPC status check.

        This method uses the channel's await_ready() for a more robust
        connectivity check.

        :returns: True if the endpoint is healthy
        :rtype: bool
        """
        try:
            await asyncio.wait_for(self.channel.healthy(), timeout=2.0)
            return True
        except asyncio.TimeoutError:
            return False
        except Exception:
            return False

    async def rebuild_channel(self):
        """Rebuild the gRPC channel.

        This method closes the existing channel and creates a new one,
        which is useful when the connection has become stale (e.g., after
        etcd server restart).
        """
        try:
            await self.channel.close()
        except Exception:
            pass  # Ignore close errors

        self.channel = self._mkchannel(self.opts)

    async def close(self):
        """Close the gRPC channel."""
        try:
            await self.channel.close()
        except Exception:
            pass  # Ignore close errors

    def _mkchannel(self, opts):
        if self.secure:
            return grpc.aio.secure_channel(self.netloc, self.credentials, options=opts)
        return grpc.aio.insecure_channel(self.netloc, options=opts)
