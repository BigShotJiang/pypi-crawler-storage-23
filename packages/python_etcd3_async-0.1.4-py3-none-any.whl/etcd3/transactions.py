"""Transaction operations for etcd3.

This module defines classes for building etcd transactions with
comparison operations and conditional mutations.
"""

from typing import Any, Optional

import etcdrpc
import etcd3.utils as utils


_OPERATORS = {
    etcdrpc.Compare.EQUAL: "==",
    etcdrpc.Compare.NOT_EQUAL: "!=",
    etcdrpc.Compare.LESS: "<",
    etcdrpc.Compare.GREATER: ">",
}


class BaseCompare:
    """Base class for transaction comparison operations.

    :param key: The key to compare
    :type key: str or bytes
    :param range_end: End of key range for range comparisons
    :type range_end: str or bytes, optional
    """

    key: Any
    range_end: Optional[Any]
    value: Any
    op: Optional[Any]

    def __init__(self, key: Any, range_end: Optional[Any] = None) -> None:
        self.key = key
        self.range_end = range_end
        self.value = None
        self.op = None

    def __eq__(self, other: Any) -> "BaseCompare":
        """Set comparison to equal."""
        self.value = other
        self.op = etcdrpc.Compare.EQUAL
        return self

    def __ne__(self, other: Any) -> "BaseCompare":
        """Set comparison to not equal."""
        self.value = other
        self.op = etcdrpc.Compare.NOT_EQUAL
        return self

    def __lt__(self, other: Any) -> "BaseCompare":
        """Set comparison to less than."""
        self.value = other
        self.op = etcdrpc.Compare.LESS
        return self

    def __gt__(self, other: Any) -> "BaseCompare":
        """Set comparison to greater than."""
        self.value = other
        self.op = etcdrpc.Compare.GREATER
        return self

    def __repr__(self) -> str:
        """Return string representation of the comparison."""
        if self.range_end is None:
            keys = self.key
        else:
            keys = "[{}, {})".format(self.key, self.range_end)
        return "{}: {} {} '{}'".format(
            self.__class__, keys, _OPERATORS.get(self.op), self.value
        )

    def build_message(self) -> etcdrpc.Compare:
        """Build the gRPC Compare message.

        :returns: Compare message for the transaction
        :rtype: etcdrpc.Compare
        """
        compare = etcdrpc.Compare()
        compare.key = utils.to_bytes(self.key)
        if self.range_end is not None:
            compare.range_end = utils.to_bytes(self.range_end)

        if self.op is None:
            raise ValueError("op must be one of =, !=, < or >")

        compare.result = self.op

        self.build_compare(compare)
        return compare

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build the target-specific comparison.

        Override in subclasses to set the appropriate comparison target.

        :param compare: The Compare message to populate
        :type compare: etcdrpc.Compare
        """
        raise NotImplementedError


class Value(BaseCompare):
    """Compare the value of a key.

    Example:
        >>> transactions.Value('/key') == b'value'
    """

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build a value comparison."""
        compare.target = etcdrpc.Compare.VALUE
        compare.value = utils.to_bytes(self.value)


class Version(BaseCompare):
    """Compare the version of a key.

    Example:
        >>> transactions.Version('/key') > 0
    """

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build a version comparison."""
        compare.target = etcdrpc.Compare.VERSION
        compare.version = int(self.value)


class Create(BaseCompare):
    """Compare the creation revision of a key.

    Example:
        >>> transactions.Create('/key') == 0
    """

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build a creation revision comparison."""
        compare.target = etcdrpc.Compare.CREATE
        compare.create_revision = int(self.value)


class Mod(BaseCompare):
    """Compare the modification revision of a key.

    Example:
        >>> transactions.Mod('/key') > 100
    """

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build a modification revision comparison."""
        compare.target = etcdrpc.Compare.MOD
        compare.mod_revision = int(self.value)


class Lease(BaseCompare):
    """Compare the lease ID attached to a key.

    Example:
        >>> transactions.Lease('/key') == lease_id
    """

    def build_compare(self, compare: etcdrpc.Compare) -> None:
        """Build a lease comparison."""
        compare.target = etcdrpc.Compare.LEASE
        compare.lease = int(self.value)


class Put:
    """A put operation for use in transactions.

    :param key: The key to set
    :type key: str or bytes
    :param value: The value to set
    :type value: str or bytes, optional
    :param lease: Lease ID to associate with the key
    :type lease: int, optional
    :param prev_kv: Whether to return the previous key-value pair
    :type prev_kv: bool
    :param ignore_value: Whether to ignore the value field
    :type ignore_value: bool
    :param ignore_lease: Whether to ignore the lease field
    :type ignore_lease: bool
    """

    key: Any
    value: Optional[Any]
    lease: Optional[int]
    prev_kv: bool
    ignore_value: bool
    ignore_lease: bool

    def __init__(
        self,
        key: Any,
        value: Optional[Any] = None,
        lease: Optional[int] = None,
        prev_kv: bool = False,
        ignore_value: bool = False,
        ignore_lease: bool = False,
    ) -> None:
        self.key = key
        self.value = value
        self.lease = lease
        self.prev_kv = prev_kv
        self.ignore_value = ignore_value
        self.ignore_lease = ignore_lease


class Get:
    """A get operation for use in transactions.

    :param key: The key to get
    :type key: str or bytes
    :param range_end: End of key range for prefix queries
    :type range_end: str or bytes, optional
    """

    key: Any
    range_end: Optional[Any]

    def __init__(self, key: Any, range_end: Optional[Any] = None) -> None:
        self.key = key
        self.range_end = range_end


class Delete:
    """A delete operation for use in transactions.

    :param key: The key to delete
    :type key: str or bytes
    :param range_end: End of key range for range deletes
    :type range_end: str or bytes, optional
    :param prev_kv: Whether to return the deleted key-value pairs
    :type prev_kv: bool
    """

    key: Any
    range_end: Optional[Any]
    prev_kv: bool

    def __init__(
        self,
        key: Any,
        range_end: Optional[Any] = None,
        prev_kv: bool = False,
    ) -> None:
        self.key = key
        self.range_end = range_end
        self.prev_kv = prev_kv


class Txn:
    """A transaction with conditional operations.

    Transactions allow atomic execution of a compare sequence
    followed by success/failure operation lists.

    :param compare: List of comparison operations
    :type compare: list of BaseCompare
    :param success: List of operations if all comparisons succeed
    :type success: list of Put, Get, Delete, or Txn, optional
    :param failure: List of operations if any comparison fails
    :type failure: list of Put, Get, Delete, or Txn, optional
    """

    compare: list
    success: Optional[list]
    failure: Optional[list]

    def __init__(
        self,
        compare: list,
        success: Optional[list] = None,
        failure: Optional[list] = None,
    ) -> None:
        self.compare = compare
        self.success = success
        self.failure = failure
