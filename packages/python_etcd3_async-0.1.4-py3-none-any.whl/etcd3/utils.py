"""Utility functions for etcd3 operations."""

from enum import Enum
from typing import Any, AsyncIterator, Iterator, Union

import grpc


# Watch filter types - matching etcd protobuf FilterType
# Use these constants with the filters parameter in watch operations
#
# Example usage:
#     events, cancel = await etcd.watch('/key', filters=[FILTER_DELETE])
#     # Only PUT events will be received, DELETE events are filtered out
#
FILTER_PUT = 0  # Filter out PUT events (only DELETE events will be received)
FILTER_DELETE = 1  # Filter out DELETE events (only PUT events will be received)
FILTER_COMMIT = 2  # Filter out all events (no events will be received)


class LoadBalancerStrategy(Enum):
    """Load balancing strategies for multi-endpoint clients.

    Attributes:
        PRIORITY: Priority-based routing - prefer healthy nodes, failover on failure
        ROUND_ROBIN: Round-robin - cycle through endpoints sequentially
        RANDOM: Random - select random healthy endpoint
        STICKY: Sticky - maintain connection to the same endpoint
    """

    PRIORITY = "priority"
    ROUND_ROBIN = "round_robin"
    RANDOM = "random"
    STICKY = "sticky"


def is_connection_canceled(error: grpc.RpcError) -> bool:
    """Check if a connection error indicates the connection was canceled.

    This is similar to Go's clientv3.IsConnCanceled function.

    :param error: The gRPC error to check
    :type error: grpc.RpcError
    :returns: True if the connection was canceled
    :rtype: bool
    """
    code = error.code()
    if code == grpc.StatusCode.UNAVAILABLE:
        return True
    if code == grpc.StatusCode.INTERNAL:
        return True
    return False


def is_channel_ready(channel) -> bool:
    """Check if a gRPC channel is ready.

    :param channel: The gRPC channel to check
    :type channel: grpc.aio.Channel
    :returns: True if the channel is ready
    :rtype: bool
    """
    try:
        state = channel.get_state()
        return state == grpc.ChannelConnectivity.READY
    except Exception:
        return False


def prefix_range_end(prefix: bytes) -> bytes:
    """Create a bytestring that can be used as a range_end for a prefix query.

    This function calculates the end of a key range that includes all keys
    starting with the given prefix.

    :param prefix: The key prefix to match
    :type prefix: bytes
    :returns: The range end bytes for prefix matching
    :rtype: bytes

    Example:
        >>> prefix_range_end(b'/foo/')
        b'/foo0'  # All keys starting with /foo/ will match
    """
    if not prefix:
        # Empty prefix returns empty range_end (matches nothing)
        return b""
    s = bytearray(prefix)
    for i in reversed(range(len(s))):
        if s[i] < 0xFF:
            s[i] = s[i] + 1
            break
    return bytes(s)


def to_bytes(maybe_bytestring: Union[str, bytes]) -> bytes:
    """Encode string to bytes.

    Convenience function to do a simple encode('utf-8') if the input is not
    already bytes. Returns the data unmodified if the input is bytes.

    :param maybe_bytestring: The string or bytes to convert
    :type maybe_bytestring: str or bytes
    :returns: The input encoded as bytes
    :rtype: bytes
    """
    if isinstance(maybe_bytestring, bytes):
        return maybe_bytestring
    else:
        return maybe_bytestring.encode("utf-8")


def lease_to_id(lease: Any) -> int:
    """Extract lease ID from a Lease object or return the ID directly.

    :param lease: A Lease object with an 'id' attribute, or a lease ID
    :type lease: Any (with 'id' attribute) or int
    :returns: The lease ID as an integer
    :rtype: int

    Example:
        >>> lease_to_id(my_lease)  # Lease object
        12345
        >>> lease_to_id(12345)  # Direct ID
        12345
    """
    lease_id = 0
    if hasattr(lease, "id"):
        lease_id = lease.id
    else:
        try:
            lease_id = int(lease)
        except TypeError:
            pass
    return lease_id


def response_to_event_iterator(response_iterator: Iterator[Any]) -> Iterator[Any]:
    """Convert a watch response iterator to an event iterator.

    :param response_iterator: Iterator of watch responses
    :type response_iterator: Iterator
    :yields: Individual events from the watch responses
    :rtype: Any
    """
    for response in response_iterator:
        for event in response.events:
            yield event


async def async_response_to_event_iterator(response_iterator) -> AsyncIterator[Any]:
    """Convert an async watch response iterator to an async event iterator.

    :param response_iterator: Async iterator of watch responses
    :yields: Individual events from the watch responses
    """
    async for response in response_iterator:
        for event in response.events:
            yield event
