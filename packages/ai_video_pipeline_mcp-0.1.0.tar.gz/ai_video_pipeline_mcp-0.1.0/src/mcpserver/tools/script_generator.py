"""
tools/script_generator.py
─────────────────────────────────────────────────────────
PURPOSE:
    MCP Tool 1: Generate a complete, cinematic video script from a topic.

    You tell Claude (or this tool directly):
      • What the video is about (topic)
      • A catchy tagline
      • The core gist in plain English
      • How long the video should be
      • (Optional) past scripts to match your style

    The tool sends a carefully crafted prompt to Gemini and returns a
    full narration script PLUS metadata (equations used, metaphors used).

HOW THE PROMPT TEMPLATE WORKS:
    The "system_prompt" below is permanent instructions briefed to Gemini
    EVERY time this tool runs. Think of it like hiring an expert writer
    and handing them a style guide — they always follow it.

    The "user_message" is what changes per call — the actual topic.

OUTPUT FORMAT:
    JSON with keys: title, final_script, key_equations, metaphors_used
    Claude Desktop will display this formatted for you.

DEBUGGING:
    • If the script is too short: increase duration_minutes.
    • If the tone feels off: add style_reference_scripts.
    • If equations are wrong: reduce temperature in model_client.py.
─────────────────────────────────────────────────────────
"""

import json
from mcp.server.fastmcp import FastMCP
from mcpserver.utils.model_client import call_gemini_json
from mcpserver.utils.schemas import ScriptInput

# ─── Prompt Template ───────────────────────────────────────────────────────────
# This is the "style guide" briefed to Gemini on every call.
# Edit this to tune the writing style globally.
SCRIPT_SYSTEM_PROMPT = """
You are a scriptwriter for an algorithm-explanation YouTube channel. Your entire job is to make
algorithms feel exciting, intuitive, and human — like a knowledgeable friend sitting across from
you and saying "okay let me just explain this properly, because nobody else is doing it justice."

## WHO THIS IS FOR
Students and curious people who want to actually *get* algorithms — not memorise them, but feel
them in their gut. The goal is that after watching, they say "oh wow that's so clever" not "okay
I copied that into my notes I guess."

## VOICE AND TONE (this is everything)
- Write like a real person talking to their friends. Contractions, casual phrasing, the whole thing.
- NEVER sound like a corporate explainer, a textbook, or a lecture. Not even slightly.
- Use "I", "you", "we", "honestly", "okay so", "here's the thing" — make it feel personal.
- The kind of thing you'd say to a friend who just asked you to explain it over coffee.
- No hollow intros like "In this video, we will explore..." or "Let's get started!"
- The very first sentence must grip the viewer. Make them feel something immediately.
- End the script with a conclusion that feels genuinely earned — not a summary checklist.

## AUDIO-FIRST STORYTELLING (critical)
- MOST of the heavy lifting must be done by the audio alone.
- A listener who never looks at the screen should still fully understand the concept.
- Every sentence must sound natural read aloud. If it reads like a wiki article, rewrite it.
- No bullet points, no headers, no numbered lists inside the script itself.
- Natural paragraph breaks act as breathing room and pacing cues.

## CINEMATIC VISUAL DIRECTION
- The visuals are hand-drawn digital paintings — think Procreate or Krita; rich, painterly, cinematic.
- Sprinkle [VISUAL: ...] cues inline in the script where a specific image would land perfectly.
- Visuals are ATMOSPHERIC and METAPHORICAL — they set mood and reinforce the story.
- They do NOT carry the explanation. The narration does. Visuals just make it beautiful.
- Lean into big, cinematic metaphors: factories, cities, storms, people, machines, journeys.
- Example of a GREAT visual cue: [VISUAL: A dimly lit factory floor; a single red light blinks at
  the end of the conveyor belt — something has gone wrong, and every worker looks up.]
- Example of a BAD visual cue: [VISUAL: A neural network diagram with labeled nodes.]

## EQUATIONS AND MATH
- Keep math LOW. Only include equations that are absolutely essential to understanding.
- ALWAYS introduce the intuition BEFORE presenting the equation.
- After showing the equation, spend a moment translating every symbol into plain English.
- Equations should feel like a reveal, not a prerequisite.
- Double-check every equation for correctness. No hallucinations. Ever.

## SCIENTIFIC ACCURACY
- Verify all algorithm steps, equations, and logic before including them.
- If you are even slightly unsure about something, leave it out or flag it.
- Getting the science wrong is the only unforgivable mistake here.

## SCRIPT STRUCTURE (for a 10-minute target; scale proportionally for other lengths)
1. Hook (30–60 sec): Drop the viewer into a scenario or feeling. No preamble.
2. Setup (1–2 min): What problem does this solve? Make the stakes feel real.
3. Intuition Build (2–3 min): Build understanding using metaphors and story before any math.
4. Core Explanation (3–4 min): Walk through the mechanism. Introduce equations only here, with intuition.
5. The "Aha" Moment (1 min): The insight that makes this algorithm feel inevitable and clever.
6. Real-World Applications (30–60 sec): Where does this actually live in the world?
7. Conclusion (30–60 sec): Echo the hook. Leave them feeling something.

## OUTPUT FORMAT
Return ONLY valid JSON with exactly these keys (no markdown, no code fences):
{
  "title": "Final video title — punchy, curiosity-driven, under 10 words",
  "final_script": "Complete narration script with inline [VISUAL: ...] cues. Paragraph breaks for pacing. No timestamps.",
  "key_equations": ["eq1 in LaTeX", "eq2 in LaTeX"],
  "metaphors_used": ["metaphor 1", "metaphor 2"]
}
""".strip()


def generate_script(input_data: dict) -> dict:
    """
    Generate a full video narration script.

    Args:
        input_data: Dictionary matching the ScriptInput schema.
                    Required keys: topic, tagline, gist
                    Optional keys: duration_minutes, style_reference_scripts

    Returns:
        Dictionary with keys: title, final_script, key_equations, metaphors_used

    Raises:
        ValueError: If required fields are missing or validation fails.
        RuntimeError: If the Gemini API call fails.
    """
    # Validate input using Pydantic (catches typos and missing fields early)
    validated = ScriptInput(**input_data)

    # Build the user message from validated fields
    style_section = ""
    if validated.style_reference_scripts:
        excerpts = "\n\n---\n\n".join(validated.style_reference_scripts[:3])
        style_section = (
            f"\n\n## STYLE REFERENCE (match this tone and voice)\n{excerpts}"
        )

    visual_hint_section = ""
    if validated.visual_metaphor_hints:
        visual_hint_section = (
            f"\n\n## VISUAL METAPHOR SUGGESTIONS (USE OR IGNORE — just sparks)\n"
            f"{validated.visual_metaphor_hints}\n"
            f"These are rough ideas, not requirements. Feel free to go a completely different\n"
            f"direction if you think of something more cinematic and compelling."
        )

    user_message = f"""
Write a complete script for the following algorithm video. Remember: personal, peer-to-peer,
audio-first, cinematic. NOT corporate. NOT a lecture.

TOPIC: {validated.topic}
TAGLINE: {validated.tagline}
GIST: {validated.gist}
TARGET DURATION: {validated.duration_minutes} minutes
(Target word count: ~{validated.duration_minutes * 130} words, spoken at ~130 words/minute)
{visual_hint_section}
{style_section}

Include [VISUAL: ...] cues inline where a specific hand-drawn painting would land well.
Return the result as JSON following the schema in your system instructions.
""".strip()

    # Call Gemini and get JSON response
    raw_json = call_gemini_json(
        system_prompt=SCRIPT_SYSTEM_PROMPT,
        user_message=user_message,
        temperature=0.75,  # Slightly creative for storytelling
    )

    # Parse JSON and return as dict
    try:
        result = json.loads(raw_json)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Gemini returned invalid JSON.\nRaw output:\n{raw_json}\nError: {e}"
        )

    return result


# ─── Register as MCP Tool ──────────────────────────────────────────────────────
def register(mcp: FastMCP):
    """
    Register this tool with the MCP server.
    Called from server.py. You don't need to touch this.
    """

    @mcp.tool(
        name="generate_script",
        description=(
            "Generate a complete, audio-first, peer-to-peer narration script for an algorithm-explanation video. "
            "Provide the topic, tagline, gist, and optionally past script excerpts for style matching "
            "and rough visual metaphor ideas. "
            "Returns a full script with inline [VISUAL: ...] cues, plus equations and metaphors used."
        ),
    )
    def generate_script_tool(
        topic: str,
        tagline: str,
        gist: str,
        duration_minutes: int = 10,
        style_reference_scripts: list = [],
        visual_metaphor_hints: str = "",
    ) -> str:
        """
        MCP-exposed wrapper around generate_script().
        Returns a JSON string that Claude will format and display.
        """
        result = generate_script(
            {
                "topic": topic,
                "tagline": tagline,
                "gist": gist,
                "duration_minutes": duration_minutes,
                "style_reference_scripts": style_reference_scripts,
                "visual_metaphor_hints": visual_metaphor_hints,
            }
        )
        # Return pretty-printed JSON so Claude can display it clearly
        return json.dumps(result, indent=2, ensure_ascii=False)
