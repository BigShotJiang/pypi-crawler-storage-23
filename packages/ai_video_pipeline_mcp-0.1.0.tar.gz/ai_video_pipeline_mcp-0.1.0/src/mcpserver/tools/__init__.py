# tools/__init__.py
# Makes the 'tools' folder a Python package.
# Each tool lives in its own file here and gets registered in server.py.
