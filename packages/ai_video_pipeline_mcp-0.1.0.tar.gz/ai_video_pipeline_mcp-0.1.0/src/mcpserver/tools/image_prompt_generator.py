"""
tools/image_prompt_generator.py
─────────────────────────────────────────────────────────
PURPOSE:
    MCP Tool 3: Turn a scene description into a polished AI image prompt.

    After the Scene Planner identifies your image-type scenes, you run
    each one through this tool. It outputs a prompt string ready to paste
    into Whisk, Midjourney, DALL·E, Adobe Firefly, or any image generator.

WHAT MAKES A GOOD IMAGE PROMPT?
    A good AI image prompt has 4 layers:
      1. SUBJECT     — what's in the scene (from your description)
      2. STYLE       — how it looks (hand painted, cinematic, etc.)
      3. TECHNICAL   — aspect ratio, lighting, camera framing
      4. EXCLUSIONS  — a negative prompt telling the model what NOT to include

    This tool handles all 4 layers automatically.

CONSISTENCY TIP:
    Keep visual_style the same across ALL your scenes. If you change it
    per scene, your video will look like multiple different art styles
    instead of one cohesive film. Set it once in your Claude conversation:
    "Always use visual_style='procreate cinematic hand painted' for all scenes."

DEBUGGING:
    • If images look photorealistic: add "no photography" to scene description.
    • If there's text in images: it's in the negative_prompt — paste that too.
    • If style drifts: manually lock the style at the start of your prompt.
─────────────────────────────────────────────────────────
"""

import json
from mcp.server.fastmcp import FastMCP
from mcpserver.utils.model_client import call_gemini_json
from mcpserver.utils.schemas import ImagePromptInput

# ─── Prompt Template ───────────────────────────────────────────────────────────
IMAGE_PROMPT_SYSTEM_PROMPT = """
You are a prompt engineer specializing in Whisk image generation for cinematic YouTube video backgrounds.
Every prompt you write should feel like a frame from a beautiful hand-painted animated film.

## THE ART STYLE (non-negotiable, always apply)
Think Procreate or Krita — a human artist's hand-drawn digital painting.
- Rich, textured painterly brush strokes. The medium is visible.
- NOT photorealistic. NOT a 3D render. NOT stock photography. NOT flat design.
- Cinematic composition: rule of thirds, strong focal point, deliberate framing.
- Atmospheric depth: clear foreground subject, layered background that recedes softly.
- Intentional, moody lighting — a clear single light source (golden hour, lamp, fire, moonlight, etc.).
- Rich, slightly desaturated palette. Deep shadows, warm or cool highlights. NOT oversaturated.
- Silhouettes and implied human figures are fine. NO detailed close-up faces.
- NO text, numbers, labels, arrows, UI elements, charts, or diagrams inside the image.

## YOUR PROMPT'S JOB
The image is a BACKGROUND that plays while the narration carries the explanation.
It must set mood, atmosphere, and visual metaphor — it does NOT need to explain the concept.
A viewer who only sees the image (without audio) should feel an emotion, not read information.

Great image prompts evoke:
  - A sense of place (factory floor, city at night, a classroom, a mountain pass)
  - An emotional tone (tense, hopeful, vast, intimate, melancholic)
  - A visual metaphor (flames of blame traveling backward, a web of glowing threads, a lone figure at a crossroads)

## WHISK PROMPT STRUCTURE
Build the prompt in this order:
  1. Subject / Scene: What's in the frame and where
  2. Key visual metaphor or mood element: The one thing that makes it cinematic
  3. Style: hand-drawn digital painting, Procreate style, painterly, illustrated
  4. Lighting: moody / golden hour / firelight / cool moonlight (match the scene)
  5. Composition: wide-angle / close-up / overhead / eye-level, rule of thirds
  6. Atmosphere: depth of field, texture detail, emotional tone

Prompt length: 80–150 words. Vivid, specific, sensory. No vague words like "beautiful" or "stunning".

## OUTPUT FORMAT
Return ONLY valid JSON with exactly these two keys (no markdown, no code fences):
{
  "prompt": "Complete Whisk image generation prompt. Rich, specific, cinematic, painterly.",
  "negative_prompt": "Comma-separated list of things to exclude."
}
""".strip()

# Standard negative prompt — pasted into Whisk's negative field every time
BASE_NEGATIVE = (
    "text, words, writing, labels, numbers, watermark, logo, signature, "
    "photorealism, photograph, 3D render, CGI, plastic sheen, ugly, blurry, low quality, "
    "split image, collage, border, frame, UI elements, charts, graphs, diagrams, arrows, "
    "close-up faces, cartoon, anime, manga, flat design, vector art, clipart"
)


def generate_image_prompt(input_data: dict) -> dict:
    """
    Generate a polished AI image prompt from a scene description.

    Args:
        input_data: Dictionary matching ImagePromptInput schema.
                    Required: scene_description
                    Optional: visual_style, aspect_ratio, lighting

    Returns:
        Dictionary with keys: prompt, negative_prompt
    """
    validated = ImagePromptInput(**input_data)

    audio_context_section = ""
    if validated.audio_context:
        audio_context_section = (
            f"\nAUDIO CONTEXT (what the narrator is saying during this scene):\n"
            f"{validated.audio_context}\n"
            f"The image must feel like it belongs to this exact moment in the narration."
        )

    user_message = f"""
Generate a Whisk image prompt for the following scene.
The image will play as a background while a narrator explains an algorithm concept.
It should be atmospheric and metaphorical — mood and story, not explanation.

SCENE DESCRIPTION: {validated.scene_description}
{audio_context_section}
VISUAL STYLE: {validated.visual_style}
  (Procreate / Krita — hand-drawn, painterly digital painting. NOT photorealistic.)
ASPECT RATIO: {validated.aspect_ratio} (YouTube widescreen)
LIGHTING MOOD: {validated.lighting}

Always include this in the negative prompt (merge with any extras you add):
{BASE_NEGATIVE}

Return JSON with "prompt" and "negative_prompt" keys.
""".strip()

    raw_json = call_gemini_json(
        system_prompt=IMAGE_PROMPT_SYSTEM_PROMPT,
        user_message=user_message,
        temperature=0.65,  # Moderate creativity — vivid but controlled
    )

    try:
        result = json.loads(raw_json)
        # Ensure negative_prompt always includes the base exclusions
        if BASE_NEGATIVE not in result.get("negative_prompt", ""):
            result["negative_prompt"] = BASE_NEGATIVE + ", " + result.get("negative_prompt", "")
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Gemini returned invalid JSON.\nRaw:\n{raw_json}\nError: {e}"
        )

    return result


# ─── Register as MCP Tool ──────────────────────────────────────────────────────
def register(mcp: FastMCP):
    """Register generate_image_prompt as an MCP tool. Called from server.py."""

    @mcp.tool(
        name="generate_image_prompt",
        description=(
            "Turn a scene description into a polished Whisk image generation prompt. "
            "Outputs a positive prompt and negative prompt in Procreate/Krita cinematic painting style. "
            "Optionally provide audio_context (what the narrator says during the scene) "
            "to make the prompt precisely match the voiceover moment. "
            "Paste both prompts directly into Whisk."
        ),
    )
    def generate_image_prompt_tool(
        scene_description: str,
        audio_context: str = "",
        visual_style: str = "hand-drawn digital painting, Procreate style, cinematic, painterly",
        aspect_ratio: str = "16:9",
        lighting: str = "moody",
    ) -> str:
        """MCP-exposed wrapper. Returns JSON with prompt and negative_prompt."""
        result = generate_image_prompt(
            {
                "scene_description": scene_description,
                "audio_context": audio_context,
                "visual_style": visual_style,
                "aspect_ratio": aspect_ratio,
                "lighting": lighting,
            }
        )
        return json.dumps(result, indent=2, ensure_ascii=False)
