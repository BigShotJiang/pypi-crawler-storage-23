"""
utils/model_client.py
─────────────────────────────────────────────────────────
PURPOSE:
    Shared wrapper around the Google Gemini API.
    Every MCP tool calls this single function instead of
    duplicating API setup code. This makes it easy to swap
    models later — you only need to change ONE file.

FREE MODEL USED:
    gemini-2.0-flash  (Google AI Studio free tier)
    ➜ Limits: 15 requests/minute, 1 million tokens/day
    ➜ No credit card needed
    ➜ Get your key: https://aistudio.google.com/apikey

HOW IT WORKS:
    1. Reads your GEMINI_API_KEY from the .env file.
    2. Sends a prompt (system instructions + user message) to Gemini.
    3. Returns the model's raw text response as a Python string.

DEBUGGING TIPS:
    • If you get "API key not valid", check your .env file.
    • If you get a 429 error, you've hit the rate limit — wait 60 seconds.
    • Set GEMINI_MODEL in .env to override the model (e.g. gemini-1.5-flash).
─────────────────────────────────────────────────────────
"""

import os
from dotenv import load_dotenv
import google.generativeai as genai

# Load environment variables from the .env file in the project root.
# This must be called before trying to read GEMINI_API_KEY.
load_dotenv()


def call_gemini(
    system_prompt: str,
    user_message: str,
    model_name: str = None,
    temperature: float = 0.7,
) -> str:
    """
    Send a prompt to Gemini and return the text response.

    Args:
        system_prompt   : The "instructions" that shape how the model behaves.
                          Think of this as a briefing given to an expert before
                          they answer your question.
        user_message    : The actual input/question the model should respond to.
        model_name      : Gemini model to use. Defaults to env var GEMINI_MODEL
                          or 'gemini-2.0-flash' if not set.
        temperature     : Creativity level (0.0 = deterministic, 1.0 = creative).
                          0.7 is a good balance for structured creative writing.

    Returns:
        str: The model's response text. May contain JSON depending on the tool.

    Raises:
        ValueError : If GEMINI_API_KEY is missing from .env
        RuntimeError: If the Gemini API call fails
    """
    # Grab the API key from environment
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY is not set!\n"
            "Fix: Copy .env.example to .env and paste your free key from "
            "https://aistudio.google.com/apikey"
        )

    # Allow model override from environment (useful for testing)
    if model_name is None:
        model_name = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    # Configure the SDK with our key
    genai.configure(api_key=api_key)

    # Build the model object with our system instructions baked in
    model = genai.GenerativeModel(
        model_name=model_name,
        system_instruction=system_prompt,
        generation_config=genai.GenerationConfig(
            temperature=temperature,
            # Ask Gemini to return clean JSON when tools need it.
            # Tools that need JSON set response_mime_type themselves via kwargs.
        ),
    )

    try:
        response = model.generate_content(user_message)
        return response.text.strip()
    except Exception as exc:
        raise RuntimeError(
            f"Gemini API call failed: {exc}\n"
            "Check your API key and internet connection."
        ) from exc


def call_gemini_json(
    system_prompt: str,
    user_message: str,
    model_name: str = None,
    temperature: float = 0.4,
) -> str:
    """
    Same as call_gemini() but instructs Gemini to return valid JSON.
    Lower temperature (0.4) for more predictable structured output.

    Use this for tools that need to parse the response as JSON.
    """
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY is not set! See .env.example for instructions."
        )

    if model_name is None:
        model_name = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    genai.configure(api_key=api_key)

    model = genai.GenerativeModel(
        model_name=model_name,
        system_instruction=system_prompt,
        generation_config=genai.GenerationConfig(
            temperature=temperature,
            response_mime_type="application/json",  # Forces valid JSON output
        ),
    )

    try:
        response = model.generate_content(user_message)
        return response.text.strip()
    except Exception as exc:
        raise RuntimeError(f"Gemini JSON call failed: {exc}") from exc
