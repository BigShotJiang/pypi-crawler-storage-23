# utils/__init__.py
# Makes the 'utils' folder a Python package.
# You can import from it like: from utils.model_client import call_gemini
