# AI Video Pipeline MCP Server

A powerful Model Context Protocol (MCP) server that orchestrates an AI video production pipeline. This server provides tools for script generation, scene planning, image prompting, and video composition.

## Features

- **Script Generation**: Generate complete, cinematic video scripts from a topic.
- **Scene Planning**: Convert timestamped transcripts into structured visual scene plans.
- **Image Prompting**: Turn scene descriptions into polished AI image prompts (optimized for Whisk/Midjourney).
- **Video Composition**: Generate Python scripts to assemble images and audio into a final cinematic video.

## Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/ai-video-pipeline-mcp.git
   cd ai-video-pipeline-mcp
   ```

2. **Install dependencies**:
   Using `uv` (recommended):
   ```bash
   uv sync
   ```
   Or using `pip`:
   ```bash
   pip install .
   ```

3. **Configure Environment Variables**:
   Create a `.env` file in the root directory:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```

## Usage with Claude Desktop

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ai-video-pipeline": {
      "command": "uv",
      "args": [
        "--directory",
        "C:/Proj/DD/mcp_deployment",
        "run",
        "ai-video-mcp"
      ]
    }
  }
}
```

(Adjust the path to match your local installation.)

## Tools

- `generate_script`: Create a narration script.
- `plan_scenes`: Create a storyboard from a transcript.
- `generate_image_prompt`: Create prompts for AI images.
- `generate_video_compositor`: Create the final assembly script.

## License

MIT
