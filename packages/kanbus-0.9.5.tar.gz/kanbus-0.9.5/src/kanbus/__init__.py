"""
Kanbus Python package.

:module: kanbus
"""

__version__ = "0.9.0"
