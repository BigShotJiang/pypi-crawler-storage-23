# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

# configs
QUANTIZATION_CONFIG_NAME = "quantization_config"
SPARSITY_CONFIG_NAME = "sparsity_config"
TRANSFORM_CONFIG_NAME = "transform_config"

# required fields
COMPRESSION_VERSION_NAME = "version"
QUANTIZATION_METHOD_NAME = "quant_method"
