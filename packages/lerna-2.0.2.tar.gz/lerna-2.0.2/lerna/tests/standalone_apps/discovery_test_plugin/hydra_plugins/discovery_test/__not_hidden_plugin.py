# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
from lerna.plugins.plugin import Plugin


class NotHiddenTestPlugin(Plugin): ...
