# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
def a_function() -> None:
    pass
