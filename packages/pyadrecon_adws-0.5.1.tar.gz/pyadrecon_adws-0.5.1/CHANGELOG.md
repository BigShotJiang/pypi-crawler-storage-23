## [0.5.1](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.5.0...v0.5.1) (2026-02-22)


### Bug Fixes

* add delegation findings ([44abad0](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/44abad00ff1715cf984925e085034afcbd7aea8f))

## [0.5.0](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.14...v0.5.0) (2026-02-22)


### Features

* paginated dashboard, fixed logging ([fbcd8d8](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/fbcd8d80d09c5efb727ab53d36dde465ea73b107))

## [0.4.14](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.13...v0.4.14) (2026-02-22)


### Bug Fixes

* rename finding ([e09d60f](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/e09d60f8112b7ad2568af288deaeacfe5cba5a6d))

## [0.4.13](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.12...v0.4.13) (2026-02-22)


### Bug Fixes

* rework protected users group ([0e850bd](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/0e850bdf0a30bf22f3f11ad60c87c8dc4f955b96))

## [0.4.12](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.11...v0.4.12) (2026-02-21)


### Bug Fixes

* add support for --generate-dashboard-from ([7e6eb2b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/7e6eb2b35dca62a0832a537f394d8dad42ed374f))

