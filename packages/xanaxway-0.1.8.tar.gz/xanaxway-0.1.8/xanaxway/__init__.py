from xanaxway.aiClient import aiClient

__all__ = ["aiClient"]
