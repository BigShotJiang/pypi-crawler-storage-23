__version__ = "0.1.19"
__app_name__ = "devmemory"
