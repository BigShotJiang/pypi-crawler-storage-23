"""Passage scraping and processing for CogBench."""
