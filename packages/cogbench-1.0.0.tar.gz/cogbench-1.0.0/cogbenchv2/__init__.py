"""CogBench — Verifiable Cognitive Constraint Benchmark."""

__version__ = "1.0.0"
