# openai_embedder

Requires openai package and OPENAI_API_KEY

Run:

```bash
OPENAI_API_KEY=... python3 examples/openai_embedder/run.py ./workspace
```
