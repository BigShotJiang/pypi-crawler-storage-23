# hash_embedder

Zero deps, works offline.

Run:

```bash
python3 examples/hash_embedder/run.py ./workspace
```
