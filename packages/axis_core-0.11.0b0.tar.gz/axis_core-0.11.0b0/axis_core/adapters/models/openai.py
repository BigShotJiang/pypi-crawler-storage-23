"""OpenAI model adapter implementation.

This module provides the OpenAIModel adapter for GPT models via the OpenAI API.
Requires the 'openai' package: pip install axis-core[openai]
"""

import json
import os
import re
from collections.abc import AsyncIterator
from typing import Any, cast

# Conditional import per AD-040
try:
    import openai
    from openai import AsyncOpenAI
    from openai.types.chat import ChatCompletionChunk
except ImportError as e:
    raise ImportError(
        "OpenAIModel requires the openai package. "
        "Install with: pip install axis-core[openai]"
    ) from e

from axis_core.errors import ModelError
from axis_core.protocols.model import ModelChunk, ModelResponse, NormalizedUsage, ToolCall
from axis_core.tool import ToolManifest

# Pricing table for cost estimation (per million tokens)
# Source: https://platform.openai.com/docs/pricing (standard pricing, as of 2026-02)
MODEL_PRICING: dict[str, dict[str, float]] = {
    # GPT-5 series
    "gpt-5.2": {"input_per_mtok": 1.75, "output_per_mtok": 14.00},
    "gpt-5.1": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5-mini": {"input_per_mtok": 0.25, "output_per_mtok": 2.00},
    "gpt-5-nano": {"input_per_mtok": 0.05, "output_per_mtok": 0.40},
    "gpt-5.2-chat-latest": {"input_per_mtok": 1.75, "output_per_mtok": 14.00},
    "gpt-5.1-chat-latest": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5-chat-latest": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5.2-pro": {"input_per_mtok": 21.00, "output_per_mtok": 168.00},
    "gpt-5-pro": {"input_per_mtok": 15.00, "output_per_mtok": 120.00},
    # GPT-5 codex/search series (Responses API)
    "gpt-5.2-codex": {"input_per_mtok": 1.75, "output_per_mtok": 14.00},
    "gpt-5.1-codex-max": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5.1-codex": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5-codex": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5.1-codex-mini": {"input_per_mtok": 0.25, "output_per_mtok": 2.00},
    "codex-mini-latest": {"input_per_mtok": 1.50, "output_per_mtok": 6.00},
    "gpt-5-search": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-5-search-api": {"input_per_mtok": 1.25, "output_per_mtok": 10.00},
    "gpt-4o-search-preview": {"input_per_mtok": 2.50, "output_per_mtok": 10.00},
    "gpt-4o-mini-search-preview": {"input_per_mtok": 0.15, "output_per_mtok": 0.60},
    # GPT-4.1 series
    "gpt-4.1": {"input_per_mtok": 2.00, "output_per_mtok": 8.00},
    "gpt-4.1-mini": {"input_per_mtok": 0.40, "output_per_mtok": 1.60},
    "gpt-4.1-nano": {"input_per_mtok": 0.10, "output_per_mtok": 0.40},
    # GPT-4o series
    "gpt-4o": {"input_per_mtok": 2.50, "output_per_mtok": 10.00},
    "gpt-4o-2024-05-13": {"input_per_mtok": 5.00, "output_per_mtok": 15.00},
    "gpt-4o-mini": {"input_per_mtok": 0.15, "output_per_mtok": 0.60},
    # O-series reasoning models
    "o1": {"input_per_mtok": 15.00, "output_per_mtok": 60.00},
    "o1-pro": {"input_per_mtok": 150.00, "output_per_mtok": 600.00},
    "o1-mini": {"input_per_mtok": 1.10, "output_per_mtok": 4.40},
    "o3": {"input_per_mtok": 2.00, "output_per_mtok": 8.00},
    "o3-pro": {"input_per_mtok": 20.00, "output_per_mtok": 80.00},
    "o3-mini": {"input_per_mtok": 1.10, "output_per_mtok": 4.40},
    "o4-mini": {"input_per_mtok": 1.10, "output_per_mtok": 4.40},
    # Deep research / computer use (Responses API)
    "o3-deep-research": {"input_per_mtok": 10.00, "output_per_mtok": 40.00},
    "o4-mini-deep-research": {"input_per_mtok": 2.00, "output_per_mtok": 8.00},
    "computer-use-preview": {"input_per_mtok": 3.00, "output_per_mtok": 12.00},
}



class OpenAIModel:
    """OpenAI GPT model adapter.

    Provides access to GPT models through the OpenAI Chat Completions API.
    Supports streaming, function calling, and cost tracking.

    Args:
        model_id: Model identifier (e.g., 'gpt-4', 'gpt-4o', 'gpt-3.5-turbo')
        api_key: OpenAI API key (defaults to OPENAI_API_KEY env var)
        temperature: Sampling temperature (0.0-2.0, default 1.0)
        max_tokens: Maximum tokens to generate (default 4096)

    Example:
        >>> model = OpenAIModel(model_id="gpt-4")
        >>> response = await model.complete(
        ...     messages=[{"role": "user", "content": "Hello"}],
        ...     system="You are a helpful assistant."
        ... )
        >>> print(response.content)
        Hello! How can I help you today?
    """

    # Models that use max_completion_tokens instead of max_tokens
    _COMPLETION_TOKENS_MODELS = {
        "gpt-5.2",
        "gpt-5.1",
        "gpt-5",
        "gpt-5-mini",
        "gpt-5-nano",
        "gpt-5.2-chat-latest",
        "gpt-5.1-chat-latest",
        "gpt-5-chat-latest",
        "gpt-5.2-codex",
        "gpt-5.1-codex-max",
        "gpt-5.1-codex",
        "gpt-5-codex",
        "gpt-5.1-codex-mini",
        "codex-mini-latest",
        "gpt-5.2-pro",
        "gpt-5-pro",
        "gpt-4.1",
        "gpt-4.1-mini",
        "gpt-4.1-nano",
        "o1",
        "o1-pro",
        "o1-mini",
        "o3",
        "o3-pro",
        "o3-mini",
        "o3-deep-research",
        "o4-mini",
        "o4-mini-deep-research",
        "gpt-5-search-api",
    }

    # Models that should route through the OpenAI Responses API
    _RESPONSES_API_MODELS = {
        # Codex
        "gpt-5.2-codex",
        "gpt-5.1-codex-max",
        "gpt-5.1-codex",
        "gpt-5-codex",
        "gpt-5.1-codex-mini",
        "codex-mini-latest",
        # Search
        "gpt-5-search",
        "gpt-5-search-api",
        "gpt-4o-search-preview",
        "gpt-4o-mini-search-preview",
        # Deep research
        "o3-deep-research",
        "o4-mini-deep-research",
        # Computer use
        "computer-use-preview",
    }
    _TOOL_CALL_ID_MAX_LEN = 64
    _TOOL_CALL_ID_PREFIX = "call"
    _TOOL_CALL_ID_INVALID_CHARS = re.compile(r"[^A-Za-z0-9_-]+")
    _SCHEMA_FIELDS_TO_STRIP = frozenset(
        {
            "$schema",
            "$id",
            "title",
            "default",
            "examples",
        }
    )

    def __init__(
        self,
        model_id: str,
        api_key: str | None = None,
        temperature: float = 1.0,
        max_tokens: int = 4096,
    ) -> None:
        """Initialize the OpenAI model adapter.

        Args:
            model_id: Model identifier
            api_key: API key (defaults to OPENAI_API_KEY env var)
            temperature: Default temperature for completions
            max_tokens: Default max tokens for completions

        Raises:
            ValueError: If api_key is not provided and OPENAI_API_KEY is not set
        """
        self._model_id = model_id
        self._temperature = temperature
        self._max_tokens = max_tokens

        # Get API key from parameter or environment
        self._api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self._api_key:
            raise ValueError(
                "OpenAI API key is required. "
                "Provide it via api_key parameter or set OPENAI_API_KEY environment variable."
            )

        self._responses_model: Any | None = None
        self._client: AsyncOpenAI | None = None

        if self._uses_responses_api():
            from axis_core.adapters.models.openai_responses import OpenAIResponsesModel

            self._responses_model = OpenAIResponsesModel(
                model_id=model_id,
                api_key=self._api_key,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return

        # Initialize OpenAI client for Chat Completions API
        self._client = AsyncOpenAI(api_key=self._api_key)

    def _uses_completion_tokens(self) -> bool:
        """Check if this model uses max_completion_tokens instead of max_tokens."""
        return self._model_id in self._COMPLETION_TOKENS_MODELS

    def _uses_responses_api(self) -> bool:
        """Check if this model should use the OpenAI Responses API backend."""
        return self._model_id in self._RESPONSES_API_MODELS

    @property
    def model_id(self) -> str:
        """Return the model identifier."""
        return self._model_id

    @staticmethod
    def _extract_status_code(error: Exception) -> int | None:
        """Extract status code from OpenAI SDK exception objects."""
        status_code = getattr(error, "status_code", None)
        if isinstance(status_code, int):
            return status_code

        response = getattr(error, "response", None)
        response_status = getattr(response, "status_code", None)
        if isinstance(response_status, int):
            return response_status

        return None

    @staticmethod
    def _extract_provider_code(error: Exception) -> str | None:
        """Extract provider error code from OpenAI exception payload."""
        direct_code = getattr(error, "code", None)
        if isinstance(direct_code, str) and direct_code:
            return direct_code

        body = getattr(error, "body", None)
        if isinstance(body, dict):
            top_code = body.get("code")
            if isinstance(top_code, str) and top_code:
                return top_code
            nested = body.get("error")
            if isinstance(nested, dict):
                nested_code = nested.get("code")
                if isinstance(nested_code, str) and nested_code:
                    return nested_code

        return None

    @classmethod
    def _map_openai_error(
        cls,
        error: Exception,
    ) -> tuple[str, bool, int | None, str | None]:
        """Normalize OpenAI SDK exceptions into reason-coded fallback metadata."""
        status_code = cls._extract_status_code(error)
        provider_code = cls._extract_provider_code(error)

        permission_error = getattr(openai, "PermissionDeniedError", ())
        unprocessable_error = getattr(openai, "UnprocessableEntityError", ())
        bad_request_types = tuple(
            t for t in (openai.BadRequestError, unprocessable_error) if t
        )
        auth_types = tuple(
            t for t in (openai.AuthenticationError, permission_error) if t
        )

        if isinstance(error, openai.RateLimitError):
            reason = "rate_limit"
        elif isinstance(error, openai.APITimeoutError):
            reason = "timeout"
        elif isinstance(error, openai.APIConnectionError):
            reason = "connection_error"
        elif auth_types and isinstance(error, auth_types):
            reason = "authentication"
        elif bad_request_types and isinstance(error, bad_request_types):
            reason = "invalid_request"
        elif isinstance(error, openai.APIStatusError):
            reason = ModelError.reason_from_status_code(status_code) or "provider_error"
        elif isinstance(error, openai.APIError):
            reason = ModelError.reason_from_status_code(status_code) or "provider_error"
        else:
            reason = ModelError.reason_from_status_code(status_code) or "unknown"

        return (
            reason,
            ModelError.is_reason_recoverable(reason),
            status_code,
            provider_code,
        )

    @staticmethod
    def _convert_tool_manifest_to_openai(manifest: ToolManifest) -> dict[str, Any]:
        """Convert a ToolManifest to OpenAI's function calling format.

        Args:
            manifest: Tool manifest from the protocol layer

        Returns:
            Dict in OpenAI's function calling format

        Example:
            >>> manifest = ToolManifest(
            ...     name="get_weather",
            ...     description="Get weather",
            ...     input_schema={"type": "object", "properties": {...}},
            ...     ...
            ... )
            >>> schema = OpenAIModel._convert_tool_manifest_to_openai(manifest)
            >>> schema["type"]
            "function"
        """
        parameters = OpenAIModel._sanitize_tool_schema_for_provider(manifest.input_schema)
        return {
            "type": "function",
            "function": {
                "name": manifest.name,
                "description": manifest.description,
                "parameters": parameters,
            },
        }

    @classmethod
    def _sanitize_schema_node(cls, value: Any) -> Any:
        """Recursively strip schema fields that frequently trigger provider rejections."""
        if isinstance(value, dict):
            sanitized: dict[str, Any] = {}
            for key, raw in value.items():
                if key in cls._SCHEMA_FIELDS_TO_STRIP or raw is None:
                    continue
                sanitized[key] = cls._sanitize_schema_node(raw)

            properties = sanitized.get("properties")
            required = sanitized.get("required")
            if isinstance(properties, dict) and isinstance(required, list):
                allowed = set(properties.keys())
                sanitized["required"] = [
                    item for item in required if isinstance(item, str) and item in allowed
                ]

            return sanitized

        if isinstance(value, list):
            return [cls._sanitize_schema_node(item) for item in value]

        return value

    @classmethod
    def _sanitize_tool_schema_for_provider(cls, schema: Any) -> dict[str, Any]:
        """Sanitize schema for OpenAI function/tool compatibility."""
        if not isinstance(schema, dict):
            return {"type": "object", "properties": {}}

        sanitized = cls._sanitize_schema_node(schema)
        if not isinstance(sanitized, dict):
            return {"type": "object", "properties": {}}

        if "type" not in sanitized:
            sanitized["type"] = "object"

        properties = sanitized.get("properties")
        if not isinstance(properties, dict):
            sanitized["properties"] = {}

        required = sanitized.get("required")
        if not isinstance(required, list):
            sanitized.pop("required", None)

        return sanitized

    @classmethod
    def _normalize_tool_call_id(
        cls,
        raw_id: Any,
        *,
        next_index: int,
        id_map: dict[str, str],
        used_ids: set[str],
    ) -> str:
        """Normalize tool call IDs to provider-safe format and maintain stable mapping."""
        raw_text = str(raw_id).strip() if raw_id is not None else ""
        if raw_text and raw_text in id_map:
            return id_map[raw_text]

        if (
            raw_text
            and not cls._TOOL_CALL_ID_INVALID_CHARS.search(raw_text)
            and len(raw_text) <= cls._TOOL_CALL_ID_MAX_LEN
        ):
            candidate = raw_text
        else:
            base = cls._TOOL_CALL_ID_INVALID_CHARS.sub("_", raw_text).strip("_")
            if not base:
                base = f"{cls._TOOL_CALL_ID_PREFIX}_{next_index}"
            elif not base.startswith(f"{cls._TOOL_CALL_ID_PREFIX}_"):
                base = f"{cls._TOOL_CALL_ID_PREFIX}_{base}"

            candidate = base[: cls._TOOL_CALL_ID_MAX_LEN].rstrip("_")
            if not candidate:
                candidate = f"{cls._TOOL_CALL_ID_PREFIX}_{next_index}"

        suffix = 1
        unique_candidate = candidate
        while unique_candidate in used_ids:
            suffix_text = f"_{suffix}"
            max_base_len = cls._TOOL_CALL_ID_MAX_LEN - len(suffix_text)
            unique_candidate = f"{candidate[:max_base_len]}{suffix_text}"
            suffix += 1

        used_ids.add(unique_candidate)
        if raw_text:
            id_map[raw_text] = unique_candidate
        return unique_candidate

    @classmethod
    def _convert_messages_to_openai(cls, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert messages from internal format to OpenAI's API format.

        Ensures that tool_calls in assistant messages have the required 'type' field.

        Args:
            messages: List of messages in internal format

        Returns:
            List of messages in OpenAI's API format
        """
        converted: list[dict[str, Any]] = []
        tool_call_id_map: dict[str, str] = {}
        used_tool_call_ids: set[str] = set()
        generated_id_index = 1

        for msg in messages:
            role = msg.get("role", "")

            # If assistant message has tool_calls, ensure they have type field
            if role == "assistant" and "tool_calls" in msg:
                tool_calls = msg.get("tool_calls", [])
                if tool_calls:
                    # Ensure each tool_call has the required 'type' field
                    formatted_calls: list[dict[str, Any]] = []
                    for tc in tool_calls:
                        if not isinstance(tc, dict):
                            continue

                        normalized_id = cls._normalize_tool_call_id(
                            tc.get("id"),
                            next_index=generated_id_index,
                            id_map=tool_call_id_map,
                            used_ids=used_tool_call_ids,
                        )
                        generated_id_index += 1

                        raw_function = tc.get("function")
                        raw_name = tc.get("name", "")
                        raw_arguments: Any = tc.get("arguments", {})
                        if isinstance(raw_function, dict):
                            raw_name = raw_function.get("name", raw_name)
                            raw_arguments = raw_function.get("arguments", raw_arguments)

                        function_name = raw_name if isinstance(raw_name, str) else str(raw_name)
                        if isinstance(raw_arguments, (dict, list)):
                            arguments_payload = json.dumps(raw_arguments)
                        elif isinstance(raw_arguments, str):
                            arguments_payload = raw_arguments
                        else:
                            arguments_payload = "{}"

                        formatted_calls.append(
                            {
                                "id": normalized_id,
                                "type": "function",
                                "function": {
                                    "name": function_name,
                                    "arguments": arguments_payload,
                                },
                            }
                        )

                    # Create converted message with formatted tool_calls
                    converted_msg = {
                        "role": "assistant",
                        "content": msg.get("content", ""),
                        "tool_calls": formatted_calls,
                    }
                    converted.append(converted_msg)
                else:
                    # No tool_calls, pass through
                    converted.append(msg)
            elif role == "tool":
                converted_tool = dict(msg)
                converted_tool["tool_call_id"] = cls._normalize_tool_call_id(
                    msg.get("tool_call_id"),
                    next_index=generated_id_index,
                    id_map=tool_call_id_map,
                    used_ids=used_tool_call_ids,
                )
                generated_id_index += 1
                converted.append(converted_tool)
            else:
                # Pass through non-assistant messages or assistant without tool_calls
                converted.append(msg)

        return converted

    @staticmethod
    def _convert_tools_to_openai(tools: Any) -> list[dict[str, Any]] | None:
        """Convert tools parameter to OpenAI format.

        Handles both ToolManifest objects (protocol layer) and raw dicts
        (for backward compatibility or direct API usage).

        Args:
            tools: List of ToolManifest objects, list of dicts, or None

        Returns:
            List of tool dicts in OpenAI format, or None if no tools
        """
        if tools is None:
            return None

        if not tools:
            return None

        # Check if tools are ToolManifest objects
        if isinstance(tools, list) and tools:
            first_tool = tools[0]

            # If already dicts, pass through (backward compatibility)
            if isinstance(first_tool, dict):
                tool_dicts: list[dict[str, Any]] = tools
                return tool_dicts

            # If ToolManifest objects, convert them
            if isinstance(first_tool, ToolManifest):
                return [
                    OpenAIModel._convert_tool_manifest_to_openai(manifest) for manifest in tools
                ]

        # Shouldn't reach here with proper input types
        return None

    async def complete(
        self,
        messages: Any,
        system: str | None = None,
        tools: Any | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop_sequences: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ModelResponse:
        """Complete a prompt with the model (non-streaming).

        Args:
            messages: List of message dicts with 'role' and 'content'
            system: System prompt/instructions
            tools: Available tools (ToolManifest objects or dicts)
            temperature: Sampling temperature (overrides default)
            max_tokens: Maximum tokens to generate (overrides default)
            stop_sequences: Sequences that stop generation
            metadata: Additional metadata (not used by OpenAI API)

        Returns:
            ModelResponse with content, tool calls, usage, and cost

        Raises:
            ModelError: If the API call fails
        """
        if self._responses_model is not None:
            return cast(
                ModelResponse,
                await self._responses_model.complete(
                    messages=messages,
                    system=system,
                    tools=tools,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stop_sequences=stop_sequences,
                    metadata=metadata,
                ),
            )

        client = self._client
        assert client is not None

        try:
            # Convert messages from internal format to OpenAI format
            openai_messages = self._convert_messages_to_openai(messages)

            # Build messages list - prepend system message if provided
            api_messages = []
            if system is not None:
                api_messages.append({"role": "system", "content": system})
            api_messages.extend(openai_messages)

            # Build request parameters
            kwargs: dict[str, Any] = {
                "model": self._model_id,
                "messages": api_messages,
                "temperature": temperature if temperature is not None else self._temperature,
            }

            # Use max_completion_tokens for newer models, max_tokens for older ones
            if max_tokens is not None or self._max_tokens is not None:
                tokens_value = max_tokens if max_tokens is not None else self._max_tokens
                if self._uses_completion_tokens():
                    kwargs["max_completion_tokens"] = tokens_value
                else:
                    kwargs["max_tokens"] = tokens_value

            # Convert tools to OpenAI format (handles ToolManifest objects)
            if tools is not None:
                openai_tools = self._convert_tools_to_openai(tools)
                if openai_tools is not None:
                    kwargs["tools"] = openai_tools

            if stop_sequences is not None:
                kwargs["stop"] = stop_sequences

            # Call OpenAI API
            response = await client.chat.completions.create(**kwargs)

            # Extract content and tool calls
            message = response.choices[0].message
            content_text = message.content or ""
            tool_calls_list: list[ToolCall] = []

            if message.tool_calls:
                for tc in message.tool_calls:
                    # Parse arguments from JSON string
                    try:
                        arguments = json.loads(tc.function.arguments)
                    except json.JSONDecodeError:
                        # Fallback to empty dict if arguments are invalid JSON
                        arguments = {}

                    tool_calls_list.append(
                        ToolCall(
                            id=tc.id,
                            name=tc.function.name,
                            arguments=arguments,
                        )
                    )

            # Extract exact token counts from response
            usage = NormalizedUsage.from_openai(getattr(response, "usage", None))

            # Calculate cost
            cost = self.estimate_cost(usage.input_tokens, usage.output_tokens)

            return ModelResponse(
                content=content_text,
                tool_calls=tuple(tool_calls_list) if tool_calls_list else None,
                usage=usage,
                cost_usd=cost,
            )

        except Exception as e:
            reason, recoverable, status_code, provider_code = self._map_openai_error(e)
            raise ModelError(
                message=f"OpenAI error for {self._model_id}: {e}",
                model_id=self._model_id,
                reason=reason,
                recoverable=recoverable,
                status_code=status_code,
                provider_code=provider_code,
                details={"error_type": reason},
                cause=e,
            ) from e

    async def stream(
        self,
        messages: Any,
        system: str | None = None,
        tools: Any | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop_sequences: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AsyncIterator[ModelChunk]:
        """Stream a completion from the model.

        Args:
            messages: List of message dicts with 'role' and 'content'
            system: System prompt/instructions
            tools: Available tools for the model to use
            temperature: Sampling temperature (overrides default)
            max_tokens: Maximum tokens to generate (overrides default)
            stop_sequences: Sequences that stop generation
            metadata: Additional metadata (not used by OpenAI API)

        Yields:
            ModelChunk instances with incremental content/tool calls

        Raises:
            ModelError: If the API call fails
        """
        if self._responses_model is not None:
            async for chunk in self._responses_model.stream(
                messages=messages,
                system=system,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                stop_sequences=stop_sequences,
                metadata=metadata,
            ):
                yield chunk
            return

        client = self._client
        assert client is not None

        try:
            # Convert messages from internal format to OpenAI format
            openai_messages = self._convert_messages_to_openai(messages)

            # Build messages list - prepend system message if provided
            api_messages = []
            if system is not None:
                api_messages.append({"role": "system", "content": system})
            api_messages.extend(openai_messages)

            # Build request parameters
            kwargs: dict[str, Any] = {
                "model": self._model_id,
                "messages": api_messages,
                "temperature": temperature if temperature is not None else self._temperature,
                "stream": True,
            }

            # Use max_completion_tokens for newer models, max_tokens for older ones
            if max_tokens is not None or self._max_tokens is not None:
                tokens_value = max_tokens if max_tokens is not None else self._max_tokens
                if self._uses_completion_tokens():
                    kwargs["max_completion_tokens"] = tokens_value
                else:
                    kwargs["max_tokens"] = tokens_value

            # Convert tools to OpenAI format
            if tools is not None:
                openai_tools = self._convert_tools_to_openai(tools)
                if openai_tools is not None:
                    kwargs["tools"] = openai_tools

            if stop_sequences is not None:
                kwargs["stop"] = stop_sequences

            # Stream from OpenAI API
            # cast() is needed because mypy can't resolve the create() overload
            # when stream=True is passed via **kwargs (the SDK uses Literal[True]
            # in its overload signatures, which requires a static keyword).
            stream = cast(
                AsyncIterator[ChatCompletionChunk],
                client.chat.completions.create(**kwargs),
            )
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta

                    # Check if this is content delta
                    if delta.content is not None:
                        yield ModelChunk(
                            content=delta.content,
                            tool_call_delta=None,
                            is_final=False,
                        )

                    # Check if this is tool call delta
                    elif delta.tool_calls is not None:
                        # Tool calls are being streamed
                        for tc_delta in delta.tool_calls:
                            tool_delta: dict[str, Any] = {
                                "index": tc_delta.index,
                            }
                            if hasattr(tc_delta, "id") and tc_delta.id:
                                tool_delta["id"] = tc_delta.id
                            if hasattr(tc_delta, "function") and tc_delta.function:
                                tool_delta["function"] = {
                                    "name": tc_delta.function.name,
                                    "arguments": tc_delta.function.arguments,
                                }

                            yield ModelChunk(
                                content="",
                                tool_call_delta=tool_delta,
                                is_final=False,
                            )

                # Check for stream end
                if chunk.choices and chunk.choices[0].finish_reason is not None:
                    yield ModelChunk(
                        content="",
                        tool_call_delta=None,
                        is_final=True,
                    )

        except Exception as e:
            reason, recoverable, status_code, provider_code = self._map_openai_error(e)
            raise ModelError(
                message=f"OpenAI error for {self._model_id}: {e}",
                model_id=self._model_id,
                reason=reason,
                recoverable=recoverable,
                status_code=status_code,
                provider_code=provider_code,
                details={"error_type": reason},
                cause=e,
            ) from e

    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Uses a simple character-based estimation as a fallback.
        For production use, consider using the tiktoken library.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count (roughly 1 token per 4 characters)
        """
        if self._responses_model is not None:
            return int(self._responses_model.estimate_tokens(text))

        if not text:
            return 0

        # Simple estimation: ~4 characters per token
        # This is a rough approximation - actual tokenization varies
        return max(1, len(text) // 4)

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost in USD for token usage.

        Uses the MODEL_PRICING table for known models. Returns 0.0 for unknown models.

        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Estimated cost in USD
        """
        if self._responses_model is not None:
            return float(self._responses_model.estimate_cost(input_tokens, output_tokens))

        pricing = MODEL_PRICING.get(self._model_id, {})

        if not pricing:
            # Unknown model - return 0 cost
            return 0.0

        input_cost = (input_tokens / 1_000_000) * pricing.get("input_per_mtok", 0)
        output_cost = (output_tokens / 1_000_000) * pricing.get("output_per_mtok", 0)

        return input_cost + output_cost
