## Fixed
- **UI**: Fixed an issue where wide reports were cut off on the left side due to an incorrect CSS justification on the wireframe canvas container, ensuring a scrollable, centered view at 100% zoom.
