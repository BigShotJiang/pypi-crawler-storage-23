"""Test against fingerprint-scan.com and CreepJS.

Tests the specific headless detection signals flagged by the community:
- noTaskbar, noContentIndex, noContactsManager, noDownlinkMax
- Bot risk score (fingerprint-scan.com)
- Headless/stealth percentages (CreepJS)

Usage:
    python examples/fingerprint_scan_test.py
    python examples/fingerprint_scan_test.py --proxy http://10.50.96.5:8888
    python examples/fingerprint_scan_test.py --headed
"""

import json
import sys
import time

from cloakbrowser import launch

HEADED = "--headed" in sys.argv
PROXY = None
for i, arg in enumerate(sys.argv):
    if arg == "--proxy" and i + 1 < len(sys.argv):
        PROXY = sys.argv[i + 1]


def test_fingerprint_scan(page):
    """fingerprint-scan.com — bot risk score + headless detection signals."""
    print("=== fingerprint-scan.com ===")
    page.goto("https://fingerprint-scan.com/", wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(20000)  # Castle.js needs time to compute score

    # Check bot risk score
    score = page.evaluate(
        'document.getElementById("fingerprintScore")?.textContent || "Score not rendered"'
    )
    print(f"Bot Risk Score: {score}")

    # Check the 4 headless signals flagged by community
    apis = page.evaluate("""() => ({
        noTaskbar: screen.height === screen.availHeight,
        taskbarSize: screen.height - screen.availHeight,
        noContentIndex: typeof window.ContentIndex === "undefined",
        noContactsManager: !("contacts" in navigator),
        noDownlinkMax: !("downlinkMax" in (navigator.connection || {})),
        downlinkMax: navigator.connection?.downlinkMax ?? null,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        webdriver: navigator.webdriver,
        cdpCheck: (() => { try { const e = Error.prepareStackTrace; Error.prepareStackTrace = () => true; const err = new Error(); const r = err.stack; Error.prepareStackTrace = e; return r === true; } catch { return false; } })(),
        isPlaywright: "__pwInitScripts" in window || "__playwright__binding__" in window,
        webgpu: typeof navigator.gpu !== "undefined" ? "available" : "NOT_AVAILABLE",
        scrollbarWidth: (() => { const d = document.createElement("div"); d.style.cssText = "overflow:scroll;width:100px;height:100px;position:absolute;top:-999px"; document.body.appendChild(d); const w = d.offsetWidth - d.clientWidth; d.remove(); return w; })()
    })""")

    print("\nHeadless detection signals:")
    headless_fails = 0
    for k, v in apis.items():
        is_fail = k.startswith("no") and v is True
        if is_fail:
            headless_fails += 1
        flag = "FAIL" if is_fail else ""
        print(f"  {k}: {v}  {flag}")

    # Extract bot test results from page
    bot_tests = page.evaluate("""() => {
        const text = document.body.innerText;
        const tests = {};
        for (const key of ['WebDriver', 'Is Selenium Chrome', 'CDP Check', 'Is Playwright']) {
            const match = text.match(new RegExp(key + '\\\\s+(true|false)'));
            if (match) tests[key] = match[1];
        }
        return tests;
    }""")
    print("\nGeneric Bot Tests:")
    for k, v in bot_tests.items():
        status = "PASS" if v == "false" else "FAIL"
        print(f"  {k}: {v}  [{status}]")

    page.screenshot(path="/results/fingerprint-scan.png", full_page=True)
    print("\nScreenshot: /results/fingerprint-scan.png")

    return {
        "score": score,
        "headless_fails": headless_fails,
        "apis": apis,
        "bot_tests": bot_tests,
    }


def test_creepjs(page):
    """abrahamjuliot.github.io/creepjs — comprehensive fingerprint analysis."""
    print("\n=== CreepJS ===")
    page.goto(
        "https://abrahamjuliot.github.io/creepjs/", wait_until="domcontentloaded", timeout=30000
    )
    print("Waiting 30s for CreepJS analysis...")
    page.wait_for_timeout(30000)

    # Use same extraction logic as test-infra/matrix_tests/group3_bot_detection.py
    results = page.evaluate("""() => {
        const text = document.body.innerText;
        const likeMatch = text.match(/(\\d+)%\\s*like headless/i);
        const headlessMatch = text.match(/(\\d+)%\\s*headless:/i);
        const stealthMatch = text.match(/(\\d+)%\\s*stealth:/i);
        return {
            likeHeadlessPct: likeMatch ? parseInt(likeMatch[1]) : null,
            headlessPct: headlessMatch ? parseInt(headlessMatch[1]) : null,
            stealthPct: stealthMatch ? parseInt(stealthMatch[1]) : null,
        };
    }""")

    print(f"Like-headless: {results['likeHeadlessPct']}%")
    print(f"Headless: {results['headlessPct']}%")
    print(f"Stealth: {results['stealthPct']}%")

    passed = (
        results["headlessPct"] is not None
        and results["headlessPct"] <= 30
        and results["stealthPct"] is not None
        and results["stealthPct"] <= 30
    )
    print(f"Verdict: {'PASS' if passed else 'FAIL'} (<=30% headless, <=30% stealth)")

    page.screenshot(path="/results/creepjs.png", full_page=True)
    print("Screenshot: /results/creepjs.png")

    return results


def main():
    print("=" * 60)
    print("CloakBrowser — Fingerprint & Headless Detection Tests")
    print("=" * 60)
    print(f"Mode: {'headed' if HEADED else 'headless'}")
    print(f"Proxy: {PROXY or 'none'}")
    print()

    browser = launch(
        headless=not HEADED,
        proxy=PROXY,
        args=[
            "--fingerprint-screen-width=1920",
            "--fingerprint-screen-height=1080",
            "--timezone=Asia/Jerusalem",
        ],
    )
    page = browser.new_page()

    try:
        fp_result = test_fingerprint_scan(page)
        creep_result = test_creepjs(page)
    finally:
        browser.close()

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"fingerprint-scan.com: {fp_result['score']}")
    print(f"  Headless signal fails: {fp_result['headless_fails']}/4")
    print(f"CreepJS: like-headless={creep_result['likeHeadlessPct']}%, headless={creep_result['headlessPct']}%, stealth={creep_result['stealthPct']}%")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
