Extend period and comparison period options for the date and datetime
fields filted menu adding a new option called "Custom Period".
