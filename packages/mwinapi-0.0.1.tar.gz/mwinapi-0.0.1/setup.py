from setuptools import setup, find_packages

setup(
    name="mwinapi",
    version="0.0.1",
    packages=find_packages(),
    description="My own winapi",
    long_description=open("README.md", encoding="UTF-8").read(),
    long_description_content_type="text/markdown",
    author="Negative Acknowledge",
    author_email="18114055256@163.com",
    url="https://github.com/JimmyJimmy666/mwinapi",
    license="MIT",
    install_requires=[],
    package_data={'': ['*.dll']},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)