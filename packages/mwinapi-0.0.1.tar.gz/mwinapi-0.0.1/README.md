# Description

**mwinapi** is my own **winapi** lib  
It includes some useful functions

# Download
Github repository page `https://github.com/JimmyJimmy666/mwinapi.git`

Github cmdline `git clone https://github.com/JimmyJimmy666/mwinapi.git`

System cmdline `https://codeload.github.com/JimmyJimmy666/mwinapi/zip/refs/heads/main`