import ctypes
from .__def import *

def free(c_var) -> None:
    mwinapi.__free(c_var)

def cast(c_data: c_t, c_type: c_t) -> c_t:
    return ctypes.cast(c_data, ctypes.POINTER(c_type))