import pathlib
import ctypes

class c_t(ctypes.c_bool): ...

there: pathlib.Path = pathlib.Path(__file__).parent.resolve()
mwinapi: ctypes.CDLL = ctypes.CDLL(there / "mwinapi.dll")

mwinapi.__free.argtypes = [ctypes.c_void_p]
mwinapi.__free.restype = None

mwinapi.curpos.argtypes = []
mwinapi.curpos.restype = ctypes.c_void_p

mwinapi.scrsize.argtypes = []
mwinapi.scrsize.restype = ctypes.c_void_p

mwinapi.scrscale.argtypes = []
mwinapi.scrscale.restype = ctypes.c_double

mwinapi.curset.argtypes = [ctypes.c_size_t, ctypes.c_size_t]
mwinapi.curset.restype = None

mwinapi.iskeyd.argtypes = [ctypes.c_int]
mwinapi.iskeyd.restype = ctypes.c_bool

mwinapi.iskeyu.argtypes = [ctypes.c_int]
mwinapi.iskeyu.restype = ctypes.c_bool

mwinapi.keyd.argtypes = [ctypes.c_int]
mwinapi.keyd.restype = None

mwinapi.keyu.argtypes = [ctypes.c_int]
mwinapi.keyu.restype = None

mwinapi.keyp.argtypes = [ctypes.c_int]
mwinapi.keyp.restype = None