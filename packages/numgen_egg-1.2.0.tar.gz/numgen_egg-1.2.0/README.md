# Numgen

A simple Python library that you can use to generate a number I invented (probably)

This is my second python library :D

Commands:
numgen.gen(0) # Replace 0 with any number, it's recomended not to use a number lower than 3 and higher than 15.

!NB!
Use: pip install numgen-egg

Import it to python: import numgen
