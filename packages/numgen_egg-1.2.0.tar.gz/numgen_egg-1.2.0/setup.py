from setuptools import setup, find_packages

setup(
    name="gen",
    version="1.2.0",
    packages=find_packages(),
    description="A simple library that generates a number.",
    author="",
    python_requires=">=3.7",
)
