# gxl-papers

Browse 450,000+ bioRxiv/medRxiv papers from the command line.

Works on macOS, Linux, and Windows. No kernel extensions, no FUSE, no root access.

## Install

```bash
pip install gxl-papers
```

## Setup

```bash
gxl login    # paste your API key
```

## Usage

```bash
# Search for papers
gxl search "CRISPR base editing"
gxl search "COVID long covid" --mode all --source medrxiv

# List papers
gxl ls /papers/
gxl ls /papers/{uuid}/
gxl ls /papers/{uuid}/sections/

# Read paper content
gxl cat /papers/{uuid}/meta.json
gxl cat /papers/{uuid}/content.lines
gxl head -n 30 /papers/{uuid}/content.lines
gxl tail -n 20 /papers/{uuid}/content.lines

# Search within papers
gxl grep "kinase" /papers/{uuid}/content.lines
gxl grep "p53" --limit 100

# Get citation info
gxl cite {uuid} 42
```

## Paper structure

Each paper is a directory at `/papers/{uuid}/` containing:

```
meta.json           Title, DOI, authors, abstract
content.lines       Full text (line-numbered)
sections/
  Abstract.lines
  Introduction.lines
  Methods.lines
  Results.lines
  Discussion.lines
supplements/
  file01.docx.md.lines
  data.csv
figures/
  fig1
  fig2
```

## Environment variables

| Variable | Description |
|---|---|
| `GXL_PAPERS_API_KEY` | API key (alternative to `gxl login`) |
| `GXL_PAPERS_API_URL` | API base URL (for self-hosted deployments) |
