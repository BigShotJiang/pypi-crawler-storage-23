#!/usr/bin/env bash
set -euo pipefail
#
# gxl-papers installer
# Usage: curl -sSL https://papers-api.gxl.dev/install | bash
#

echo "==> Installing gxl-papers..."

if command -v uv &>/dev/null; then
    uv tool install gxl-papers
elif command -v pip3 &>/dev/null; then
    pip3 install gxl-papers
elif command -v pip &>/dev/null; then
    pip install gxl-papers
else
    echo "==> No pip found — installing uv first..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="${HOME}/.local/bin:${PATH}"
    uv tool install gxl-papers
fi

echo ""
echo "==> Done! Setup:"
echo "    gxl login"
echo "    gxl search \"CRISPR base editing\""
echo "    gxl ls /papers/"
