"""gxl-papers — Browse bioRxiv/medRxiv papers from the command line."""

__version__ = "0.2.0"
