"""HTTP client for the Papers API with caching and retries."""

import json
import logging
import re
import time

import requests
from cachetools import TTLCache

logger = logging.getLogger(__name__)


class PapersAPIClient:
    """Thin HTTP client that wraps the papers-api REST endpoints."""

    def __init__(self, base_url: str, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        if api_key:
            self._session.headers["Authorization"] = f"Bearer {api_key}"
        self._session.headers["Accept"] = "application/json"

        self._dir_cache: TTLCache = TTLCache(maxsize=500, ttl=60)
        self._content_cache: TTLCache = TTLCache(maxsize=200, ttl=300)

    def _get(self, endpoint: str, params: dict | None = None, timeout: int = 30) -> dict:
        url = f"{self.base_url}{endpoint}"
        for attempt in range(3):
            try:
                resp = self._session.get(url, params=params, timeout=timeout)
                if resp.status_code == 404:
                    return {"_error": "not_found", "_detail": resp.text}
                if resp.status_code == 403:
                    return {"_error": "forbidden", "_detail": "Invalid API key"}
                if resp.status_code == 429:
                    return {"_error": "rate_limited", "_detail": "Rate limit exceeded"}
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.ConnectionError:
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                raise
        return {"_error": "max_retries"}

    def _check_error(self, result: dict) -> str | None:
        if "_error" in result:
            return result.get("_detail", result["_error"])
        return None

    def readdir(self, path: str, limit: int = 200) -> list[dict] | None:
        cache_key = f"{path}:{limit}"
        if cache_key in self._dir_cache:
            return self._dir_cache[cache_key]
        result = self._get("/v1/readdir", {"path": path, "limit": limit})
        err = self._check_error(result)
        if err:
            return None
        entries = result.get("entries", [])
        self._dir_cache[cache_key] = entries
        return entries

    def read(self, path: str, offset: int = 0, limit: int = 0) -> dict | None:
        """Read file content. Returns raw API response."""
        params: dict = {"path": path}
        if offset:
            params["offset"] = offset
        if limit:
            params["limit"] = limit
        result = self._get("/v1/read", params)
        if self._check_error(result):
            return None
        return result

    def read_text(self, path: str) -> str | None:
        """Read file content as formatted plain text (cached)."""
        if path in self._content_cache:
            return self._content_cache[path]
        result = self.read(path)
        if result is None:
            return None
        text = self._format_content(result)
        self._content_cache[path] = text
        return text

    def search(self, query: str, n: int = 25, mode: str = "any",
               source: str | None = None) -> dict:
        params: dict = {"q": query, "n": n, "mode": mode}
        if source:
            params["source"] = source
        return self._get("/v1/search", params)

    def grep(self, pattern: str, doc_ids: list[str] | None = None,
             section: str | None = None, limit: int = 50) -> dict:
        params: dict = {"pattern": pattern, "limit": limit}
        if doc_ids:
            params["doc_ids"] = ",".join(doc_ids)
        if section:
            params["section"] = section
        return self._get("/v1/grep", params)

    def citation(self, document_id: str, line_number: int,
                 supplement: str | None = None) -> dict:
        params: dict = {"document_id": document_id, "line_number": line_number}
        if supplement:
            params["supplement"] = supplement
        return self._get("/v1/citation", params)

    def health(self) -> dict:
        return self._get("/health")

    @staticmethod
    def _format_content(result: dict) -> str:
        content_type = result.get("type", "")
        if content_type == "json":
            return json.dumps(result["content"], indent=2)
        if content_type == "lines":
            lines = result.get("lines", [])
            return "\n".join(
                f"L{ln['line_number']} : {ln['content']}" for ln in lines
            )
        return json.dumps(result, indent=2)
