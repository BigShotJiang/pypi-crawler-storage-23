"""CLI for gxl-papers: Unix-like commands over the Papers API.

Usage:
    gxl ls /papers/
    gxl ls /papers/{uuid}/
    gxl cat /papers/{uuid}/meta.json
    gxl cat /papers/{uuid}/content.lines
    gxl head -n 20 /papers/{uuid}/content.lines
    gxl tail -n 20 /papers/{uuid}/content.lines
    gxl grep "CRISPR" /papers/{uuid}/content.lines
    gxl search "protein folding"
    gxl cite {uuid} 42
    gxl login
    gxl status
"""

import json
import logging
import os
import sys
from pathlib import Path

import click

from .api_client import PapersAPIClient

CONFIG_DIR = Path.home() / ".config" / "gxl-papers"
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULT_API_URL = "https://papers-api-566313044696.us-central1.run.app"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _save_config(cfg: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def _get_client() -> PapersAPIClient:
    cfg = _load_config()
    api_key = cfg.get("api_key")
    api_url = cfg.get("api_url", DEFAULT_API_URL)
    if not api_key:
        click.echo("No API key configured. Run: gxl login", err=True)
        sys.exit(1)
    return PapersAPIClient(api_url, api_key)


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------

@click.group()
@click.option("--debug", is_flag=True, help="Enable debug logging")
def main(debug: bool):
    """gxl — Browse 450K+ bioRxiv/medRxiv papers from the command line."""
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------

@main.command()
@click.option("--api-key", envvar="GXL_PAPERS_API_KEY", help="API key")
@click.option("--api-url", envvar="GXL_PAPERS_API_URL", help="API base URL")
def login(api_key: str | None, api_url: str | None):
    """Save API credentials."""
    cfg = _load_config()
    if not api_key:
        api_key = click.prompt("API key", hide_input=True)
    cfg["api_key"] = api_key
    if api_url:
        cfg["api_url"] = api_url
    _save_config(cfg)
    click.echo("Saved to ~/.config/gxl-papers/config.json")


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

@main.command()
def status():
    """Check API connectivity."""
    cfg = _load_config()
    api_url = cfg.get("api_url", DEFAULT_API_URL)
    api_key = cfg.get("api_key")

    click.echo(f"API:  {api_url}")
    click.echo(f"Auth: {'configured' if api_key else 'not configured'}")

    if api_key:
        try:
            client = PapersAPIClient(api_url, api_key)
            health = client.health()
            click.echo(f"Health: {health.get('status', 'unknown')}")
            if health.get("db"):
                click.echo(f"DB: {health['db']}")
        except Exception as e:
            click.echo(f"Health: error ({e})")


# ---------------------------------------------------------------------------
# ls
# ---------------------------------------------------------------------------

@main.command()
@click.argument("path", default="/papers/")
@click.option("-n", "--limit", default=50, help="Max entries to show")
@click.option("-l", "--long", "long_fmt", is_flag=True, help="Long format with details")
def ls(path: str, limit: int, long_fmt: bool):
    """List papers or directory contents."""
    client = _get_client()
    entries = client.readdir(path, limit=limit)

    if entries is None:
        click.echo(f"gxl ls: cannot access '{path}': No such directory", err=True)
        sys.exit(1)

    if not entries:
        return

    if long_fmt:
        for e in entries:
            name = e["name"] if isinstance(e, dict) else e
            kind = e.get("type", "?") if isinstance(e, dict) else "?"
            suffix = "/" if kind == "dir" else ""
            click.echo(f"{'d' if kind == 'dir' else '-'}r--r--r--  {name}{suffix}")
    else:
        names = []
        for e in entries:
            name = e["name"] if isinstance(e, dict) else e
            kind = e.get("type", "") if isinstance(e, dict) else ""
            names.append(f"{name}/" if kind == "dir" else name)

        try:
            term_width = os.get_terminal_size().columns
        except OSError:
            term_width = 80
        _columnize(names, term_width)


def _columnize(items: list[str], width: int):
    """Print items in columns like ls."""
    if not items:
        return
    max_len = max(len(s) for s in items) + 2
    cols = max(1, width // max_len)
    for i, item in enumerate(items):
        end = "\n" if (i + 1) % cols == 0 or i == len(items) - 1 else ""
        click.echo(f"{item:<{max_len}}", nl=False)
        if end:
            click.echo()


# ---------------------------------------------------------------------------
# cat
# ---------------------------------------------------------------------------

@main.command()
@click.argument("path")
def cat(path: str):
    """Read file contents."""
    client = _get_client()
    text = client.read_text(path)
    if text is None:
        click.echo(f"gxl cat: {path}: No such file", err=True)
        sys.exit(1)
    click.echo(text)


# ---------------------------------------------------------------------------
# head
# ---------------------------------------------------------------------------

@main.command()
@click.argument("path")
@click.option("-n", "--lines", default=20, help="Number of lines")
def head(path: str, lines: int):
    """Show first N lines of a file."""
    client = _get_client()
    result = client.read(path, limit=lines)
    if result is None:
        click.echo(f"gxl head: {path}: No such file", err=True)
        sys.exit(1)
    click.echo(PapersAPIClient._format_content(result))


# ---------------------------------------------------------------------------
# tail
# ---------------------------------------------------------------------------

@main.command()
@click.argument("path")
@click.option("-n", "--lines", default=20, help="Number of lines")
def tail(path: str, lines: int):
    """Show last N lines of a file."""
    client = _get_client()
    result = client.read(path)
    if result is None:
        click.echo(f"gxl tail: {path}: No such file", err=True)
        sys.exit(1)

    if result.get("type") == "lines":
        all_lines = result.get("lines", [])
        result["lines"] = all_lines[-lines:]

    click.echo(PapersAPIClient._format_content(result))


# ---------------------------------------------------------------------------
# grep
# ---------------------------------------------------------------------------

@main.command()
@click.argument("pattern")
@click.argument("path", required=False)
@click.option("-n", "--limit", default=50, help="Max results")
@click.option("-i", "--ignore-case", is_flag=True, help="Case insensitive (default)")
def grep(pattern: str, path: str | None, limit: int, ignore_case: bool):
    """Search for a pattern within paper content.

    \b
    Examples:
        gxl grep "CRISPR" /papers/{uuid}/content.lines
        gxl grep "kinase" --limit 100
    """
    client = _get_client()

    doc_ids = None
    if path:
        parts = [p for p in path.strip("/").split("/") if p]
        if len(parts) >= 2 and parts[0] == "papers":
            doc_ids = [parts[1]]

    result = client.grep(pattern, doc_ids=doc_ids, limit=limit)
    err = result.get("_error")
    if err:
        click.echo(f"gxl grep: {result.get('_detail', err)}", err=True)
        sys.exit(1)

    matches = result.get("results", [])
    if not matches:
        click.echo("(no matches)")
        return

    for m in matches:
        doc_id = m["document_id"]
        line_num = m["line_number"]
        content = m["content"]
        section = m.get("section", "")
        prefix = f"/papers/{doc_id}/content.lines:L{line_num}"
        if section:
            prefix += f" [{section}]"
        click.echo(f"{prefix}: {content}")


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------

@main.command()
@click.argument("query")
@click.option("-n", "--limit", default=25, help="Max results")
@click.option("-m", "--mode", default="any",
              type=click.Choice(["any", "all", "phrase"]),
              help="Search mode")
@click.option("-s", "--source",
              type=click.Choice(["biorxiv", "medrxiv"]),
              help="Filter by source")
def search(query: str, limit: int, mode: str, source: str | None):
    """Search for papers by keyword.

    \b
    Examples:
        gxl search "CRISPR base editing"
        gxl search "COVID long covid" --mode all --source medrxiv
        gxl search "protein folding" -n 50
    """
    client = _get_client()
    result = client.search(query, n=limit, mode=mode, source=source)

    err = result.get("_error")
    if err:
        click.echo(f"gxl search: {result.get('_detail', err)}", err=True)
        sys.exit(1)

    papers = result.get("results", [])
    count = result.get("count", len(papers))
    click.echo(f"Found {count} papers:\n")

    for i, p in enumerate(papers, 1):
        title = p.get("title", "Untitled")
        doc_id = p.get("document_id", "?")
        doi = p.get("doi", "")
        authors = p.get("authors", "")
        source_str = p.get("source", "")
        month = p.get("month_year", "")

        click.echo(f"  {i}. {title}")
        click.echo(f"     {doc_id}  [{source_str}] {month}")
        if authors:
            author_short = authors[:80] + ("..." if len(authors) > 80 else "")
            click.echo(f"     {author_short}")
        if doi:
            click.echo(f"     doi:{doi}")
        click.echo()


# ---------------------------------------------------------------------------
# cite
# ---------------------------------------------------------------------------

@main.command()
@click.argument("document_id")
@click.argument("line_number", type=int)
@click.option("--supplement", "-s", help="Supplement filename")
def cite(document_id: str, line_number: int, supplement: str | None):
    """Get citation info for a specific line in a paper.

    \b
    Examples:
        gxl cite abc123-uuid 42
        gxl cite abc123-uuid 5 --supplement "file03.content.md.lines"
    """
    client = _get_client()
    result = client.citation(document_id, line_number, supplement)

    err = result.get("_error")
    if err:
        click.echo(f"gxl cite: {result.get('_detail', err)}", err=True)
        sys.exit(1)

    click.echo(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
