"""Context management for Sage."""
