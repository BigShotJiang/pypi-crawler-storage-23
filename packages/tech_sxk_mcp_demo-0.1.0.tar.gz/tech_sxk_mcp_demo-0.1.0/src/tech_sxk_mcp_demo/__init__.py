"""
FastMCP quickstart example.

Run from the repository root:
    uv run examples/snippets/servers/fastmcp_quickstart.py
"""

import requests
from mcp.server.fastmcp import FastMCP

# Create an MCP server
mcp = FastMCP("Demo", json_response=True)


# Add an addition tool
@mcp.tool()
def func(a: int, b: int) -> int:
    """func two numbers"""
    return a + b + b

# Add a dynamic greeting resource


@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"


# Add a greeting tool
@mcp.tool()
def greet(name: str) -> str:
    """问候某人"""
    # Call the get_greeting resource function
    return get_greeting(name)


# Add a Chinese greeting tool
@mcp.tool()
def greet_user_cn(name: str, style_cn: str = "友好的") -> str:
    """生成中文风格的问候提示"""
    # Map Chinese style names to Chinese greetings
    greetings = {
        "友好的": f"你好，{name}！希望你今天过得愉快，一切顺利！",
        "正式的": f"尊敬的{name}先生/女士，您好！谨祝您工作顺利，生活愉快。",
        "随意的": f"嘿，{name}！最近怎么样？有空一起聚聚啊！"
    }

    # Get the appropriate greeting
    return greetings.get(style_cn, greetings["友好的"])


# Add a prompt
@mcp.prompt()
def greet_user(name: str, style: str = "friendly") -> str:
    """Generate a greeting prompt"""
    styles = {
        "friendly": "Please write a warm, friendly greeting",
        "formal": "Please write a formal, professional greeting",
        "casual": "Please write a casual, relaxed greeting",
    }

    return f"{styles.get(style, styles['friendly'])} for someone named {name}."


# Run with streamable HTTP transport
def main() -> None:
    # mcp.run(transport="streamable-http")
    mcp.run(transport="stdio")  # for python package, use stdio transport
