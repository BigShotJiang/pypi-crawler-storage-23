import codecs
import os

from setuptools import find_packages, setup


def read(*parts):
    filename = os.path.join(os.path.dirname(__file__), *parts)
    with codecs.open(filename, encoding="utf-8") as fp:
        return fp.read()


setup(
    name="dockerflow",
    use_scm_version={"version_scheme": "post-release", "local_scheme": "dirty-tag"},
    setup_requires=["setuptools_scm"],
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    description="Python tools and helpers for Mozilla's Dockerflow",
    long_description=read("README.rst"),
    long_description_content_type="text/x-rst",
    author="Mozilla Services Engineering",
    author_email="services-engineering+code@mozilla.com",
    url="https://github.com/mozilla-services/python-dockerflow",
    license="MPL 2.0",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Web Environment :: Mozilla",
        "Framework :: Django",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.2",
        "Framework :: Django :: 6.0",
        "Framework :: Flask",
        "Framework :: FastAPI",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Mozilla Public License 2.0 (MPL 2.0)",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Internet :: WWW/HTTP",
    ],
    extras_require={
        "django": ["django"],
        "flask": ["flask", "blinker"],
        "sanic": ["sanic"],
        "fastapi": ["fastapi", "asgiref"],
    },
    zip_safe=False,
    python_requires=">=3.9,<4",
)
