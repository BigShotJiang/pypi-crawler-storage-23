env=$1

./deployment/aws/deploy_stack.sh ezrules_app_stack ${env}