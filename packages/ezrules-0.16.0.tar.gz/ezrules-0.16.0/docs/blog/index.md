# Blog

Short practical writeups on using ezrules in real workflows.

## Posts

- [From Zero to Live Rule Evaluation in 10 Minutes with ezrules](zero-to-live-rule-evaluation.md)
- [Automatic Field Type Management](field-type-management.md)
- [Shipping Rule Changes with Less Guesswork: Shadow Deployment in ezrules](shadow-deployment.md)
