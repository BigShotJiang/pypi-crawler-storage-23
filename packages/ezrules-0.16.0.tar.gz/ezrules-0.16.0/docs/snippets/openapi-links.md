- Swagger UI: `http://localhost:8888/docs`
- ReDoc: `http://localhost:8888/redoc`
- OpenAPI JSON: `http://localhost:8888/openapi.json`

