"""Кастомные исключения UI Router.

Иерархия:
    UIRouterError
    ├── ConfigurationError
    │   ├── SchemaValidationError
    │   └── RegistryError
    ├── ActionError
    │   ├── MissingActionFieldError
    │   └── UnknownActionTypeError
    ├── NavigationError
    │   └── SceneNotFoundError
    ├── CallbackDataError
    │   ├── CallbackDecodeError
    │   └── CallbackExpiredError
    ├── KeyboardRenderError
    ├── EventError
    │   ├── EventSchedulingError
    │   └── EventSyncError
    ├── ContentError
    └── RuleEngineError
"""

from __future__ import annotations


class UIRouterError(Exception):
    """Базовое исключение UI Router. Все ошибки фреймворка наследуются от него."""


# === Configuration ===


class ConfigurationError(UIRouterError):
    """Ошибка конфигурации (схема, registry, адаптер)."""


class SchemaValidationError(ConfigurationError):
    """Невалидная схема (initial_scene не найдена, ссылки на несуществующие сцены и т.п.)."""


class RegistryError(ConfigurationError):
    """Функция/действие не зарегистрированы в registry."""

    def __init__(self, name: str, registry_type: str = "function") -> None:
        self.name = name
        self.registry_type = registry_type
        super().__init__(f"{registry_type} '{name}' not registered")


# === Actions ===


class ActionError(UIRouterError):
    """Ошибка выполнения action."""

    def __init__(self, action_type: str, message: str) -> None:
        self.action_type = action_type
        super().__init__(f"[{action_type}] {message}")


class MissingActionFieldError(ActionError):
    """Обязательное поле action не заполнено."""

    def __init__(self, action_type: str, field: str) -> None:
        self.field = field
        super().__init__(action_type, f"required field '{field}' is missing")


class UnknownActionTypeError(ActionError):
    """Неизвестный тип action."""

    def __init__(self, action_type: str) -> None:
        super().__init__(action_type, "unknown action type")


# === Navigation ===


class NavigationError(UIRouterError):
    """Ошибка навигации между сценами."""


class SceneNotFoundError(NavigationError):
    """Сцена не найдена в схеме."""

    def __init__(self, scene_id: str) -> None:
        self.scene_id = scene_id
        super().__init__(f"Scene '{scene_id}' not found")


# === Callback Data ===


class CallbackDataError(UIRouterError):
    """Ошибка работы с callback_data."""


class CallbackDecodeError(CallbackDataError):
    """Невалидный формат callback_data."""

    def __init__(self, callback_data: str) -> None:
        self.callback_data = callback_data
        super().__init__(f"Invalid callback_data format: {callback_data}")


class CallbackExpiredError(CallbackDataError):
    """Callback data истекла или не найдена в кеше."""

    def __init__(self, callback_data: str) -> None:
        self.callback_data = callback_data
        super().__init__(f"Callback data expired or not found: {callback_data}")


# === Keyboard ===


class KeyboardRenderError(UIRouterError):
    """Ошибка рендеринга клавиатуры (dynamic keyboard, layout)."""


# === Events ===


class EventError(UIRouterError):
    """Ошибка системы событий."""


class EventSchedulingError(EventError):
    """Ошибка планирования события."""


class EventSyncError(EventError):
    """Ошибка синхронизации событий при смене схемы."""


# === Content ===


class ContentError(UIRouterError):
    """Ошибка работы с контентом сообщений (edit, render)."""


# === Rule Engine ===


class RuleEngineError(UIRouterError):
    """Ошибка вычисления условий/правил."""
