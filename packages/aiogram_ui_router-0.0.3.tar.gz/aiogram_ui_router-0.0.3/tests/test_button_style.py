"""Тесты для поддержки стилей кнопок (aiogram 3.25+)."""

import pytest
from pydantic import ValidationError

from ui_router.schema import Button, ButtonTemplate


class TestButtonStyle:
    def test_button_style_default_none(self):
        btn = Button(text="Test", callback_action="act")
        assert btn.style is None
        assert btn.icon_custom_emoji_id is None

    def test_button_accepts_valid_styles(self):
        for style in ("danger", "success", "primary"):
            btn = Button(text="Test", callback_action="act", style=style)
            assert btn.style == style

    def test_button_rejects_invalid_style(self):
        with pytest.raises(ValidationError):
            Button(text="Test", callback_action="act", style="invalid")

    def test_button_accepts_icon_custom_emoji_id(self):
        btn = Button(text="Test", callback_action="act", icon_custom_emoji_id="5368324170671202286")
        assert btn.icon_custom_emoji_id == "5368324170671202286"


class TestButtonTemplateStyle:
    def test_template_style_default_none(self):
        tmpl = ButtonTemplate(text="{name}", callback_action="act")
        assert tmpl.style is None
        assert tmpl.icon_custom_emoji_id is None

    def test_template_accepts_valid_styles(self):
        for style in ("danger", "success", "primary"):
            tmpl = ButtonTemplate(text="{name}", callback_action="act", style=style)
            assert tmpl.style == style

    def test_template_rejects_invalid_style(self):
        with pytest.raises(ValidationError):
            ButtonTemplate(text="{name}", callback_action="act", style="blue")

    def test_template_accepts_icon_custom_emoji_id(self):
        tmpl = ButtonTemplate(text="{name}", callback_action="act", icon_custom_emoji_id="123")
        assert tmpl.icon_custom_emoji_id == "123"
