"""GreatSky Metaflow extension package.

Config injection is handled by the config/ subpackage, which Metaflow's
extension loader discovers and processes inside metaflow_config.py.
"""
