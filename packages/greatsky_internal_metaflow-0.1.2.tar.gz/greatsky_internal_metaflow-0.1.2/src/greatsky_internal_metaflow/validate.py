"""Connectivity and auth validation checks."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

from greatsky_internal_metaflow import settings


@dataclass
class ValidationResult:
    auth_api_ok: bool
    metadata_api_ok: bool
    api_key_valid: bool
    auth_user: str | None = None
    error: str | None = None


def validate(api_key: str) -> ValidationResult:
    """Run a full connectivity check against the platform."""
    result = ValidationResult(
        auth_api_ok=False,
        metadata_api_ok=False,
        api_key_valid=False,
    )

    # 1. Auth API reachable?
    try:
        resp = httpx.get(settings.BOOTSTRAP_ENDPOINT, timeout=10)
        result.auth_api_ok = resp.status_code == 200
    except httpx.HTTPError:
        result.error = "Cannot reach auth API"
        return result

    # 2. Validate the API key
    try:
        resp = httpx.get(
            f"{settings.AUTH_API_BASE}/auth/validate-key",
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        result.api_key_valid = resp.status_code == 200
        if result.api_key_valid:
            result.auth_user = resp.headers.get("x-auth-user")
        else:
            result.error = "API key is invalid or expired — run: gsm login"
    except httpx.HTTPError:
        result.error = "Cannot reach auth API for key validation"
        return result

    # 3. Metadata service reachable via the API key?
    metadata_url = ""
    try:
        resp = httpx.get(
            settings.CONFIG_ENDPOINT,
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        if resp.status_code == 200:
            mf_config = resp.json().get("metaflow_config", {})
            metadata_url = mf_config.get("METAFLOW_SERVICE_URL", "")
    except httpx.HTTPError:
        pass

    if metadata_url:
        try:
            resp = httpx.get(
                f"{metadata_url.rstrip('/')}/ping",
                headers={"X-Api-Key": api_key},
                timeout=10,
            )
            result.metadata_api_ok = resp.status_code == 200
        except httpx.HTTPError:
            pass

    return result
