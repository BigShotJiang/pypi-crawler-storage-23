"""Platform constants.

The only hardcoded value is the auth API base URL. Everything else
(GitHub client ID, org name, metadata URL, etc.) is fetched at runtime
from the /auth/bootstrap discovery endpoint.
"""

AUTH_API_BASE = "https://auth.gr8sky.dev"
BOOTSTRAP_ENDPOINT = f"{AUTH_API_BASE}/auth/bootstrap"
CONFIG_ENDPOINT = f"{AUTH_API_BASE}/auth/client-config"
TOKEN_EXCHANGE_ENDPOINT = f"{AUTH_API_BASE}/auth/token-exchange"
REVOKE_KEY_ENDPOINT = f"{AUTH_API_BASE}/auth/revoke-my-key"
ADMIN_INVITE_ENDPOINT = f"{AUTH_API_BASE}/admin/invite"
ADMIN_REVOKE_KEYS_ENDPOINT = f"{AUTH_API_BASE}/admin/revoke-keys"
ADMIN_GUESTS_ENDPOINT = f"{AUTH_API_BASE}/admin/guests"
SERVICE_KEYS_ENDPOINT = f"{AUTH_API_BASE}/api/service-keys"
ADMIN_SERVICE_KEYS_ENDPOINT = f"{AUTH_API_BASE}/admin/service-keys"

GITHUB_DEVICE_CODE_URL = "https://github.com/login/device/code"
GITHUB_DEVICE_POLL_URL = "https://github.com/login/oauth/access_token"
GITHUB_DEVICE_VERIFY_URL = "https://github.com/login/device"
