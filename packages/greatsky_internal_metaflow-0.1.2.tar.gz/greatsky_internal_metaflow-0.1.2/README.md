# greatsky-internal-metaflow

CLI for authenticating with the GreatSky Metaflow platform.

## Install

```bash
pip install greatsky-internal-metaflow
```

## Quick Start

```bash
# Authenticate (opens GitHub in your browser)
gsm login

# Verify everything is working
gsm validate

# Run Metaflow flows — no further config needed
python my_flow.py run
```

## Commands

| Command | Description |
|---------|-------------|
| `gsm login` | Authenticate via GitHub Device Flow and configure Metaflow |
| `gsm logout` | Remove local credentials and config |
| `gsm status` | Show current authentication state |
| `gsm validate` | Check auth and platform connectivity |
| `gsm admin invite <user> [--expires 90d]` | Invite a GitHub user as guest |
| `gsm admin revoke <user>` | Remove a guest's access |
| `gsm admin guests` | List all invited guests |

## How It Works

1. `gsm login` starts a [GitHub Device Flow](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps#device-flow) — you get a code to enter at github.com/login/device
2. Once authorized, the CLI exchanges the GitHub token with the GreatSky auth API for a platform API key
3. The API key and full Metaflow config are written to `~/.metaflowconfig/config.json`
4. Metaflow reads that config natively — no wrappers or env vars needed

API keys are valid for 14 days and are automatically revoked if you leave the GitHub org.

## Development

```bash
git clone https://github.com/greatsky-ai/greatsky-internal-metaflow.git
cd greatsky-internal-metaflow
pip install -e ".[dev]"
pytest
```
