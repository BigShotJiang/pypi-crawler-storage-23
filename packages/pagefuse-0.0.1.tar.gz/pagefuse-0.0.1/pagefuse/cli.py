def main():
    print("PageFuse — coming soon. Visit https://pagefuse.net")
