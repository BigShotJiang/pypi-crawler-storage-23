from .path import get_path, valid_project
import subprocess
from pyxora.utils import platform


def explore(args):
    """Open a project."""
    path = get_path(args.name)
    if not valid_project(args.name):
        print(f"No project found with name '{args.name}'")
        return

    if platform.is_windows():
        cmd = ["explorer", str(path)]
    elif platform.is_linux():
        cmd = ["xdg-open", str(path)]
    else:
        cmd = ["open", str(path)]

    try:
        subprocess.run(
            cmd,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as exc:
        print(f"Failed to open project '{name}': {exc}")
        return None
    return path
