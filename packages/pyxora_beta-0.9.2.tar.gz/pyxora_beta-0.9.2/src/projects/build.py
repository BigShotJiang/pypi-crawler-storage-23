import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import urllib.request
import json
from importlib.metadata import requires
from time import perf_counter as time

from .info import info
from .path import get_path, valid_project


def _get_installed_version(package_name: str, pypi_name: str) -> str:
    from importlib.metadata import version, PackageNotFoundError

    # Try different naming conventions
    possible_names = [package_name, pypi_name, pypi_name.replace("-", "_")]

    for name in possible_names:
        try:
            return version(name)
        except (PackageNotFoundError, Exception):
            continue
        return None


def _collect_licenses(includes: list[str], output: str) -> int:
    os.makedirs(output, exist_ok=True)

    licenses_collected = 0

    print(f"\tFetching license info for {len(includes)} dependencies...")

    includes[includes.index("pygame")] = "pygame-ce"
    includes[includes.index("pyxora")] = "pyxora-beta"
    for package_name in includes:
        # Try different name variations
        pypi_name = package_name.replace("_", "-")
        installed_version = _get_installed_version(package_name, pypi_name)

        if not installed_version:
            print(f"\t! Warning: Could not determine version for {pypi_name}")
            installed_version = "unknown"

        if installed_version != "unknown":
            pypi_url = f"https://pypi.org/pypi/{pypi_name}/{installed_version}/json"
        else:
            pypi_url = f"https://pypi.org/pypi/{pypi_name}/json"

        try:
            with urllib.request.urlopen(pypi_url, timeout=5) as response:
                data = json.loads(response.read().decode())

                # Get metadata
                info_data = data.get("info", {})
                license_text = info_data.get("license", "Not specified")
                author = info_data.get("author", "Unknown")
                version = info_data.get("version", installed_version)
                home_page = info_data.get("home_page", "")
                project_url = info_data.get(
                    "project_url", f"https://pypi.org/project/{pypi_name}/{version}/"
                )

                # Get classifiers for additional license info
                classifiers = info_data.get("classifiers", [])
                license_classifiers = [
                    c for c in classifiers if c.startswith("License ::  ")
                ]

                # Create license file with version in filename
                license_file_path = os.path.join(
                    output, f"{pypi_name}_{version}_LICENSE.txt"
                )

                if not license_text or license_text == "Not specified":
                    print(f"\t! Warning: Could not determine the {pypi_name} license")

                with open(license_file_path, "w", encoding="utf-8") as f:
                    f.write(f"Package: {pypi_name}\n")
                    f.write(f"Version: {version}\n")
                    f.write(f"Author: {author}\n")
                    if home_page:
                        f.write(f"Site: {home_page}\n")
                    f.write("=" * 70 + "\n\n")

                    if license_text and license_text != "Not specified":
                        f.write(f"License: {license_text}\n\n")

                    if license_classifiers:
                        f.write("License Classifiers:\n")
                        for classifier in license_classifiers:
                            f.write(f"  - {classifier}\n")
                        f.write("\n")

                    f.write("-" * 70 + "\n")
                    f.write("For the full license text, please visit:\n")
                    f.write(f"{project_url}\n")

                licenses_collected += 1

        except Exception as e:
            print(f"\tFailed to fetch license for {pypi_name}: {str(e)[:50]}")

    # Create a small README
    readme_path = os.path.join(output, "README.txt")
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write("THIRD-PARTY LICENSES\n")
        f.write("=" * 70 + "\n\n")
        f.write("This directory contains license information for all third-party\n")
        f.write("libraries included in this application.\n\n")
        f.write("All license information was retrieved from PyPI.\n\n")
        f.write("=" * 70 + "\n\n")

    return licenses_collected


def local_build(args):
    x1 = time()
    name = args.name
    if not valid_project(name):
        print(f"No project found with name '{name}'")
        return

    project_path = get_path(name)
    main_script = os.path.join(project_path, "main.py")

    print("Build metadata: ")
    metadata = info(args)
    app_name = metadata["name"]
    app_version = metadata["version"]

    build_dir = os.path.abspath("build")  # everything goes here

    # remove previous build
    if os.path.exists(build_dir):
        print(f"Removing existing build directory at {build_dir} ...")
        try:
            shutil.rmtree(build_dir)
        except Exception as e:
            print(f"Error removing build directory: {e}")
            return

    os.makedirs(build_dir, exist_ok=True)

    includes = [
        dep.split("==")[0]
        .split(">=")[0]
        .split(">")[0]
        .split("<")[0]
        .split("[")[0]
        .replace("-", "_")
        for dep in requires("pyxora-beta")
    ]

    # add the main engine
    includes.append("pyxora")

    # the pypi package name is 'pygame-ce', but the pacakge import is 'pygame'
    # so we include 'pygame' and remove 'pygame_ce'
    includes.append("pygame")
    includes.remove("pygame_ce")

    # these are not needed in the final build executable
    includes.remove("pygbag")  # web builds
    includes.remove("cx_Freeze")  # local builds
    includes.remove("pdoc")  # docs generator
    includes.remove("pillow")  # images

    # exec type base in platform
    if sys.platform == "win32":
        base = repr("Win32GUI")
        target_name = f"{app_name}.exe"
    else:
        base = None
        target_name = app_name

    # cx_Freeze setup script
    setup_code = textwrap.dedent(f"""\
        from cx_Freeze import setup, Executable

        includes = {includes!r}

        setup(
            name="{app_name}",
            version="1.0",
            description="{app_name} Build",
            executables=[Executable(r"{main_script}", target_name="{target_name}", base={base})],
            options={{
                "build_exe": {{
                    "build_exe": r"{build_dir}",
                    "includes": includes,
                    "include_files": [],
                }}
            }}
        )
    """)

    # create temp script file for the cx_freeze
    with tempfile.TemporaryDirectory() as temp_dir:
        setup_script_path = os.path.join(temp_dir, "setup_cxfreeze.py")
        with open(setup_script_path, "w") as f:
            f.write(setup_code)

        print("Running cx_Freeze...")
        try:
            subprocess.run(
                [sys.executable, setup_script_path, "build"],
                check=True,
                cwd=temp_dir,
                stdout=subprocess.DEVNULL,  # suppress output
                # stderr=subprocess.DEVNULL,  # suppress errors
            )
        except subprocess.CalledProcessError as e:
            print(f"Error during cx_Freeze build: {e}")
            return

    print("Copying project files into the build directory...")
    for item in os.listdir(project_path):
        src = os.path.join(project_path, item)
        dst = os.path.join(build_dir, item)
        if item in (
            "build",
            "__pycache__",
            "main.py",
            "metadata.json",
        ):  # skip this folders/files
            continue

        if item[0] == ".":
            continue

        try:
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)
        except Exception as e:
            print(f"Error copying {src} to {dst}: {e}")
            return

    licenses_dir = os.path.join(build_dir, "lib", "licenses")
    licenses_count = _collect_licenses(includes, licenses_dir)
    if licenses_count > 0:
        print(f"Collected {licenses_count + 1} license files")
    else:
        print(f"No license files found")

    print(f"Build completed successfully. Executable and files are in: {build_dir}")

    x2 = time()

    print(f"Build time: {x2 - x1:.2f} seconds")


def web_build(args):
    x1 = time()
    name = args.name
    if not valid_project(name):
        print(f"No project found with name '{name}'")
        return

    build_dir = os.path.abspath("build")
    project_path = get_path(name)

    base = os.path.dirname(os.path.dirname(__file__))
    template = os.path.normpath(os.path.join(base, "data", "pygbag.tmpl"))
    # remove previous build
    if os.path.exists(build_dir):
        print(f"Removing existing build directory at {build_dir} ...")
        try:
            shutil.rmtree(build_dir)
        except Exception as e:
            print(f"Error removing build directory: {e}")
            return

    os.makedirs(build_dir, exist_ok=True)

    try:
        print("Running pygbag ...")
        cmd = [sys.executable, "-m", "pygbag"]
        cmd.extend(["--template", str(template)])
        cmd.extend(["--archive"])
        cmd.append("main.py")
        subprocess.run(
            cmd,
            check=True,
            cwd=project_path,
            stdout=subprocess.DEVNULL,  # suppress output
            stderr=subprocess.DEVNULL,  # suppress errors
        )
    except subprocess.CalledProcessError as e:
        print(f"pygbag build failed with exit code {e.returncode}")
        return
    except FileNotFoundError:
        print(
            "pygbag command not found. Please ensure pygbag is installed and in your PATH."
        )
        return

    # move build from the project to current directory
    pygbag_output_dir = os.path.join(project_path, "build")
    try:
        shutil.rmtree(build_dir)
        shutil.move(pygbag_output_dir, build_dir)
    except Exception:
        print(f"Error moving {pygbag_output_dir} to {build_dir}")
        try:
            shutil.rmtree(
                pygbag_output_dir
            )  # try to remove the tmp pygbag build files if move fails
        except Exception:
            print("Error deleting pygbag tmp files")
        return

    print(f"Web build completed successfully. Files are in: {build_dir}")
    x2 = time()
    print(f"Build time: {x2 - x1:.2f} seconds")


def build_project(args):
    """Build a project"""
    if args.web:
        web_build(args)
    else:
        local_build(args)
