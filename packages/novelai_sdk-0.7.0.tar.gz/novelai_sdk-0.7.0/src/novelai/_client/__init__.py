"""High-level NovelAI API client"""
