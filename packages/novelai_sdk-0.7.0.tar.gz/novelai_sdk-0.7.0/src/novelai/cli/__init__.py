"""CLI package for NovelAI SDK."""

from .app import main

__all__ = ["main"]
