#! /usr/bin/env python
# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name='nextpcg',
    author='GenesisGroup',
    version='1.0.6',
    license='MIT',

    description='NextPCG Python SDK — Dson plugin framework and Houdini HAPI wrapper for procedural game content generation',
    long_description='''# nextpcg

**nextpcg** is the Python SDK for the NextPCG procedural game content generation platform.
It provides the core framework and toolsets for building Dson plugins and integrating with Houdini Engine.

## Modules

| Module | Description |
|---|---|
| `nextpcg.common` | General-purpose utility library: path handling, logging, file operations |
| `nextpcg.pyhapi` | Houdini Engine API (HAPI) Python wrapper: node management, geometry I/O, cook control |
| `nextpcg.pypapi` | Dson plugin framework: `DsonBase`, `DsonMeta`, `Dispatcher`, `DsonPool`, field types, CLI |
| `nextpcg.pypapi.mcp` | MCP tool development public API: `MCPToolBase`, `expose_as_mcp` |
| `nextpcg.pypapi.testing` | Testing framework for external Dson plugin developers |
| `nextpcg.pypapi.pantry` | Pre-built Dson configuration templates (`.yaml`) |

## Installation

```bash
pip install nextpcg
```

## Quick Start

```python
from nextpcg.pypapi.dson import DsonBase
from nextpcg.pypapi.dson_field import String, Float3

class MyPlugin(DsonBase):
    name = String(default="my_plugin")
    position = Float3(default=(0.0, 0.0, 0.0))
```

## Documentation

Full documentation is available at:
https://nextpcg.notion.site/Wiki-384dc1d9d9f64306bd8774ff1138f618
''',
    long_description_content_type='text/markdown',
    author_email='cheneyshen@tencent.com',
    url='https://nextpcg.notion.site/Wiki-384dc1d9d9f64306bd8774ff1138f618?pvs=4',

    include_package_data=True,

    # PythonPackage/nextpcg/ is the package root (contains __init__.py).
    # We explicitly list all public sub-packages to avoid accidentally including
    # private or maintainer-only modules (e.g. tools/).
    packages=[
        'nextpcg',
        'nextpcg.common',
        'nextpcg.pyhapi',
        'nextpcg.pyhapi.compat',
        'nextpcg.pypapi',
        'nextpcg.pypapi.mcp',
        'nextpcg.pypapi.pantry',
    ],
    package_dir={
        'nextpcg': 'nextpcg',                         # PythonPackage/nextpcg/ is the package root
        'nextpcg.common': 'nextpcg/common',
        'nextpcg.pyhapi': 'nextpcg/pyhapi',
        'nextpcg.pyhapi.compat': 'nextpcg/pyhapi/compat',
        'nextpcg.pypapi': 'nextpcg/pypapi',
        'nextpcg.pypapi.mcp': 'nextpcg/pypapi/mcp',
        'nextpcg.pypapi.pantry': 'nextpcg/pypapi/pantry',
    },

    package_data={
        'nextpcg.pypapi.pantry': ['*.yaml', '*.py'],
    },

    entry_points={
        'console_scripts': [
            'nextpcg = nextpcg.pypapi.__main__:entry'
        ]
    },
    install_requires=[
        "numpy",
        "pillow",
        "requests",
        "pyyaml",
        "importlib_resources"
    ],

    classifiers=[
        #   3 - Alpha
        #   4 - Beta
        #   5 - Production/Stable
        'Development Status :: 5 - Production/Stable',

        'Intended Audience :: Developers',

        'License :: OSI Approved :: MIT License',

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',

        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Games/Entertainment',
        'Topic :: Multimedia :: Graphics :: 3D Modeling',
    ],

    python_requires=">=3.6",
    zip_safe=True,
)