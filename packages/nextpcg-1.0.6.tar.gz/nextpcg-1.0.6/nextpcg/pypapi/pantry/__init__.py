# -*- coding: utf-8 -*-
"""
NextPCG 插件模板包

包含初始化插件工程所需的模板文件：
- dson_config.yaml: 配置文件模板
- dson_generator.py: DSON 生成器脚本模板
"""
