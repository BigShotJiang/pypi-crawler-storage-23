"""nextpcg - NextPCG public Python package.

This is the top-level package for the nextpcg PyPI distribution.
All public modules are accessible via:
    from nextpcg.pypapi import ...
    from nextpcg.common import ...
    from nextpcg.pyhapi import ...
"""

import re as _re
from pathlib import Path as _Path

def _read_version() -> str:
    """Read version from setup.py at package build time."""
    try:
        setup_py = _Path(__file__).parent.parent / "setup.py"
        content = setup_py.read_text(encoding="utf-8")
        match = _re.search(r"version\s*=\s*['\"]([^'\"]+)['\"]", content)
        if match:
            return match.group(1)
    except Exception:
        pass
    return "0.0.0"

__version__ = _read_version()
