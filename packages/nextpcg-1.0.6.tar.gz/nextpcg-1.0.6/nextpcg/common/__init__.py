# -*- coding: utf-8 -*-
"""a demo to run cloud server
Author  : Cheneyshen
Email   : cheneyshen@tencent.com
"""





