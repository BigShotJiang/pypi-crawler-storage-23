# -*- coding: utf-8 -*-
"""
pyhapi compatibility layer

Provides cross-version compatibility support for Houdini (19.5 ~ 21+)

Main features:
- Version detection and querying
- Automatic API adaptation
- Feature detection
- Error handling

Usage:
    from pyhapi.compat import get_houdini_version, has_feature, get_adapter
    
    # Check version
    version = get_houdini_version()
    
    # Check feature
    if has_feature('async_attributes'):
        # Use async API
        pass
    
    # Use adapter
    adapter = get_adapter()
    result, node_id = adapter.create_input_node(session, name="input")
"""

# Version detection
from .version_detector import (
    get_houdini_version,
    get_version_info,
    has_feature,
    require_feature,
    get_diagnostic_info,
    reset_version_cache,
    VersionInfo,
    UnsupportedVersionError,
    FeatureNotAvailableError,
    FEATURE_REQUIREMENTS,
    MIN_SUPPORTED_VERSION,
    MAX_TESTED_VERSION,
)

# API adapter
from .adapter import (
    get_adapter,
    reset_adapter,
    VersionAdapter,
    APINotAvailableError,
    require_version,
    fallback_on_error,
)

__all__ = [
    # Version detection
    'get_houdini_version',
    'get_version_info',
    'has_feature',
    'require_feature',
    'get_diagnostic_info',
    'reset_version_cache',
    'VersionInfo',
    'UnsupportedVersionError',
    'FeatureNotAvailableError',
    'FEATURE_REQUIREMENTS',
    'MIN_SUPPORTED_VERSION',
    'MAX_TESTED_VERSION',
    
    # API adapter
    'get_adapter',
    'reset_adapter',
    'VersionAdapter',
    'APINotAvailableError',
    'require_version',
    'fallback_on_error',
]
