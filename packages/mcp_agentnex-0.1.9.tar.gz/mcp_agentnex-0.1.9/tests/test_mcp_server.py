#!/usr/bin/env python3
"""
Test script for AgentNEX MCP Server
Tests basic MCP functionality without requiring NEXA connection
"""

import asyncio
import json
import sys
import os

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.mcp_server import app, list_tools, list_resources


async def test_mcp_server():
    """Test MCP server functionality"""
    
    print("Testing AgentNEX MCP Server...")
    print("=" * 50)
    
    try:
        # Test 1: List Tools
        print("\n1. Testing tool discovery...")
        tools = await list_tools()
        print(f"Found {len(tools)} tools:")
        for tool in tools:
            print(f"   - {tool.name}: {tool.description[:80]}...")
        
        # Test 2: List Resources  
        print("\n2. Testing resource discovery...")
        resources = await list_resources()
        print(f"Found {len(resources)} resources:")
        for resource in resources:
            print(f"   - {resource.uri}: {resource.name}")
        
        # Test 3: Test tool parameter validation
        print("\n3. Testing tool schemas...")
        for tool in tools:
            schema = tool.inputSchema
            required_params = schema.get("required", [])
            properties = schema.get("properties", {})
            print(f"   - {tool.name}: requires {required_params}")
        
        print("\nAll basic MCP tests passed!")
        print("\nNext Steps:")
        print("   1. Set environment variables (AGENTNEX_BACKEND_URL, AGENTNEX_API_KEY)")
        print("   2. Test with real backend connection")
        print("   3. Register with NEXA platform")
        
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_mcp_server())
