#!/usr/bin/env python3
"""Simple test for API key authentication"""

import asyncio
import sys
import os

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.client.backend_client import BackendClient
from app.core.config import settings


async def test_api_key():
    """Test API key authentication with backend"""
    print(f"Backend URL: {settings.agentnex_backend_url}")
    print(f"API Key: {settings.agentnex_api_key[:15]}...")

    client = BackendClient()
    
    # Test health
    healthy = await client.health_check()
    print(f"Health check: {healthy}")
    
    # Test device list
    try:
        devices = await client.get_devices()
        print(f"Devices found: {len(devices)}")
        if devices:
            print(f"First device ID: {devices[0].get('id', 'N/A')}")
    except Exception as e:
        print(f"Device list error: {e}")


if __name__ == "__main__":
    asyncio.run(test_api_key())
