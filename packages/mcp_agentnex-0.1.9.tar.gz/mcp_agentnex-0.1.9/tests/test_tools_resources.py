#!/usr/bin/env python3
"""Test script to verify tools and resources load correctly."""

from app.tools import (
    GetDeviceTelemetryTool,
    GetDeviceProcessesTool,
    RestartProcessTool,
    KillProcessTool,
    ClearCacheTool,
    FlushDnsTool,
    RestartServiceTool
)
from app.resources import (
    AllDevicesResource,
    DeviceStatusResource,
    DeviceTelemetryResource
)

print("=" * 60)
print("AGENTNEX MCP SERVER - TOOLS & RESOURCES TEST")
print("=" * 60)

# Create instances
tools = [
    GetDeviceTelemetryTool(),
    GetDeviceProcessesTool(),
    RestartProcessTool(),
    KillProcessTool(),
    ClearCacheTool(),
    FlushDnsTool(),
    RestartServiceTool()
]

resources = [
    AllDevicesResource(),
    DeviceStatusResource(),
    DeviceTelemetryResource()
]

print(f"\nTools count: {len(tools)}")
print(f"Resources count: {len(resources)}")

print("\nTOOLS:")
for i, t in enumerate(tools, 1):
    print(f"  {i}. {t.name}")
    print(f"     Description: {t.description}")
    print()

print("RESOURCES:")
for i, r in enumerate(resources, 1):
    print(f"  {i}. URI: {r.uri}")
    print(f"     Name: {r.name}")
    print(f"     Description: {r.description}")
    print()

print("=" * 60)
print("SUCCESS: All 7 tools and 3 resources loaded correctly!")
print("=" * 60)
