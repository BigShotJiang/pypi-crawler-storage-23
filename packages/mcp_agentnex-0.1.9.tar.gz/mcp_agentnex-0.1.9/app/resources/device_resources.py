"""
MCP resources for device data access
"""

import json
from typing import List, Optional
from app.resources.base import BaseResource
from app.client.backend_client import BackendClient


class AllDevicesResource(BaseResource):
    """Resource for accessing all devices in organization"""
    
    @property
    def uri(self) -> str:
        return "agentnex://devices/all"
    
    @property
    def name(self) -> str:
        return "All Devices"
    
    @property
    def description(self) -> str:
        return "Complete list of devices in the organization with status information"
    
    async def read(self, uri: str, backend_client: Optional[BackendClient] = None) -> str:
        """Read all devices data"""
        client = self.get_client(backend_client)
        devices = await client.get_devices()
        return json.dumps(devices, indent=2)


class DeviceStatusResource(BaseResource):
    """Resource for accessing device status"""
    
    @property
    def uri(self) -> str:
        return "agentnex://device/{device_id}/status"
    
    @property
    def name(self) -> str:
        return "Device Status"
    
    @property
    def description(self) -> str:
        return "Current connection status and health of a specific device"
    
    async def read(self, uri: str, backend_client: Optional[BackendClient] = None) -> str:
        """Read device status data"""
        uri = str(uri)  # may be AnyUrl from MCP
        # Extract device_id from URI: agentnex://device/{device_id}/status
        device_id = uri.split("/")[3]
        if device_id == "{device_id}":
            return json.dumps({
                "error": "Use a real device ID in the URI, not the placeholder.",
                "hint": "Call the list_devices tool to get device IDs, then use agentnex://device/<device_id>/status",
                "example": "agentnex://device/your-actual-device-uuid/status",
            }, indent=2)
        client = self.get_client(backend_client)
        status = await client.get_device_status(device_id)
        return json.dumps(status, indent=2)


class DeviceTelemetryResource(BaseResource):
    """Resource for accessing device telemetry"""
    
    @property
    def uri(self) -> str:
        return "agentnex://device/{device_id}/telemetry"
    
    @property
    def name(self) -> str:
        return "Device Telemetry"
    
    @property
    def description(self) -> str:
        return "Current system metrics (CPU, memory, disk) for a specific device"
    
    async def read(self, uri: str, backend_client: Optional[BackendClient] = None) -> str:
        """Read device telemetry data"""
        uri = str(uri)  # may be AnyUrl from MCP
        # Extract device_id from URI: agentnex://device/{device_id}/telemetry
        device_id = uri.split("/")[3]
        if device_id == "{device_id}":
            return json.dumps({
                "error": "Use a real device ID in the URI, not the placeholder.",
                "hint": "Call the list_devices tool to get device IDs, then use agentnex://device/<device_id>/telemetry",
                "example": "agentnex://device/your-actual-device-uuid/telemetry",
            }, indent=2)
        client = self.get_client(backend_client)
        telemetry = await client.get_device_telemetry(device_id)
        return json.dumps(telemetry, indent=2)