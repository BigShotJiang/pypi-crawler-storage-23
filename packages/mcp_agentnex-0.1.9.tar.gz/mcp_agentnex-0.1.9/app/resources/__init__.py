# MCP resources implementation

from app.resources.device_resources import (
    AllDevicesResource,
    DeviceStatusResource,
    DeviceTelemetryResource
)

__all__ = [
    "AllDevicesResource",
    "DeviceStatusResource", 
    "DeviceTelemetryResource"
]