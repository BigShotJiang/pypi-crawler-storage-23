"""
Base classes for MCP tools
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Sequence, Union
from mcp.types import Tool, TextContent

from app.client.backend_client import BackendClient


class BaseTool(ABC):
    """Base class for all MCP tools"""
    
    def __init__(self, backend_client: Optional[BackendClient] = None):
        self._backend_client = backend_client
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Tool name"""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description for AI"""
        pass
    
    @property
    @abstractmethod
    def input_schema(self) -> Dict[str, Any]:
        """Tool input schema"""
        pass
    
    @abstractmethod
    async def execute(self, arguments: Dict[str, Any], backend_client: Optional[BackendClient] = None) -> str:
        """
        Execute the tool with given arguments.
        
        Args:
            arguments: Tool arguments
            backend_client: Optional backend client (uses self._backend_client if not provided)
            
        Returns:
            Formatted string result for AI consumption
        """
        pass
    
    def get_client(self, backend_client: Optional[BackendClient] = None) -> BackendClient:
        """Get the backend client to use"""
        client = backend_client or self._backend_client
        if not client:
            raise ValueError("No backend client available")
        return client
    
    def to_mcp_tool(self) -> Tool:
        """Convert to MCP Tool object"""
        return Tool(
            name=self.name,
            description=self.description,
            inputSchema=self.input_schema
        )