"""Custom exceptions for MCP server"""


class MCPServerError(Exception):
    """Base exception for MCP server errors"""
    pass


class BackendConnectionError(MCPServerError):
    """Backend connection failed"""
    pass


class AuthenticationError(MCPServerError):
    """API key authentication failed"""
    pass


class DeviceNotFoundError(MCPServerError):
    """Device not found or offline"""
    pass


class ActionValidationError(MCPServerError):
    """Action parameters invalid"""
    pass


class ToolExecutionError(MCPServerError):
    """Tool execution failed"""
    pass


class ResourceNotFoundError(MCPServerError):
    """Resource not found"""
    pass