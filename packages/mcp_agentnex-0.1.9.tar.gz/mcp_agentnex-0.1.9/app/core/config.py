from pydantic_settings import BaseSettings
from pydantic import ConfigDict


class Settings(BaseSettings):
    model_config = ConfigDict(
        extra="ignore",  # Ignore env vars from NEXA/K8s (postgres_*, openai_api_key, etc.)
        env_file=".env",
        case_sensitive=False,
    )

    # Backend Configuration
    # AGENTNEX_BACKEND_URL must be the backend origin only (no path). Paths /api/health, /api/internal/* are appended by the client.
    agentnex_backend_url: str = "https://agentnex-cursorback-qa1-708341704774.us-central1.run.app"
    
    # User API Token for authentication
    # This is a user-scoped token created via /api/auth/api-tokens/
    # The token determines which devices are visible (filtered by user's role/assignments)
    # Format: agentnex_<random-string>
    agentnex_api_key: str = "test-api-key"  # Replace with actual user API token

    # MCP Server Configuration
    agentnex_mcp_server_name: str = "agentnex-mcp-server"
    agentnex_mcp_server_version: str = "1.0.0"
    agentnex_mcp_server_port: int = 8001

    # Logging Configuration
    agentnex_log_level: str = "INFO"
    agentnex_log_format: str = "json"

    # HTTP Client Configuration
    agentnex_backend_timeout: float = 30.0
    agentnex_backend_retry_attempts: int = 3
    agentnex_backend_retry_delay: float = 1.0


settings = Settings()