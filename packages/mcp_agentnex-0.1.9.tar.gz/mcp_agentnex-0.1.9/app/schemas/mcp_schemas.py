"""
Pydantic schemas for MCP protocol requests and responses
"""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field


class MCPRequest(BaseModel):
    """Base MCP request"""
    jsonrpc: str = "2.0"
    method: str
    params: Optional[Dict[str, Any]] = None
    id: Optional[Union[str, int]] = None


class MCPResponse(BaseModel):
    """Base MCP response"""
    jsonrpc: str = "2.0"
    id: Optional[Union[str, int]] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None


class MCPError(BaseModel):
    """MCP error object"""
    code: int
    message: str
    data: Optional[Dict[str, Any]] = None


class ToolDefinition(BaseModel):
    """MCP tool definition"""
    name: str
    description: str
    parameters: Dict[str, Any]


class ResourceDefinition(BaseModel):
    """MCP resource definition"""
    uri: str
    name: str
    description: str
    mimeType: str = "application/json"


class ToolCallRequest(BaseModel):
    """Tool call request parameters"""
    name: str
    arguments: Dict[str, Any]


class ToolCallResponse(BaseModel):
    """Tool call response"""
    content: List[Dict[str, Any]]
    isError: bool = False


class ResourceReadRequest(BaseModel):
    """Resource read request parameters"""
    uri: str


class ResourceReadResponse(BaseModel):
    """Resource read response"""
    contents: List[Dict[str, Any]]


class InitializeRequest(BaseModel):
    """Initialize request parameters"""
    protocolVersion: str
    capabilities: Dict[str, Any]
    clientInfo: Dict[str, str]


class InitializeResponse(BaseModel):
    """Initialize response"""
    protocolVersion: str = "2024-11-05"
    capabilities: Dict[str, Any]
    serverInfo: Dict[str, str]


# MCP Error Codes
class MCPErrorCodes:
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    
    # Custom error codes
    TOOL_NOT_FOUND = -32000
    RESOURCE_NOT_FOUND = -32001
    DEVICE_OFFLINE = -32002
    ACTION_BLOCKED = -32003
    AUTHENTICATION_FAILED = -32004