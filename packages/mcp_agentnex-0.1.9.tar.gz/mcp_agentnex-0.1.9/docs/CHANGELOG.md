# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-01-27

### Added
- Initial release of AgentNEX MCP Server
- 7 MCP tools for device management:
  - `get_device_telemetry` - Get real-time CPU, memory, disk, and network metrics
  - `get_device_processes` - List running processes with resource usage
  - `restart_process` - Restart a specific process by name
  - `kill_process` - Terminate a process by name or PID
  - `clear_cache` - Clear application cache (Chrome, Edge, Teams, etc.)
  - `flush_dns` - Flush DNS resolver cache
  - `restart_service` - Restart a Windows service
- 3 MCP resources for device information:
  - `agentnex://devices/all` - List of all registered devices
  - `agentnex://devices/{id}/status` - Device connection status
  - `agentnex://devices/{id}/telemetry` - Latest device telemetry data
- HTTP REST API support for NEXA platform integration
- stdio (JSON-RPC) support for local MCP clients (Claude Desktop)
- Backend client with API key authentication
- Structured logging with configurable levels
- Telemetry and action formatters for AI-friendly output
- Comprehensive error handling and exception management
- Docker support with multi-stage builds
- Health check endpoint for monitoring
- PyPI package distribution support

### Documentation
- Comprehensive README with installation and usage instructions
- Architecture documentation
- NEXA platform integration guide
- API endpoint documentation
- Environment variable configuration guide

### Security
- API key authentication for backend requests
- CORS support for cross-origin requests
- HTTPS support for production deployment
- Non-root container execution
- No sensitive data logging

## [0.1.2] - 2026-02-10

### Fixed
- **Kubernetes/NEXA shared env**: Settings now use `extra="ignore"` so the MCP server starts when running in the same pod as NEXA (avoids "Extra inputs are not permitted" for NEXA env vars like `postgres_*`, `openai_api_key`, `backend_base_url`, etc.).
- **Stdio test from source**: Script `scripts/test_stdio_health_and_tools.py` now runs the MCP server correctly from source using `python -m app.mcp_server` and sets `PYTHONPATH` so the server starts; previously `python -m mcp_agentnex` failed (no such module) and the test reported an empty response.

### Changed
- **Config env names**: Optional settings use an `AGENTNEX_` prefix to avoid clashes in shared environments:
  - `MCP_SERVER_*` → `AGENTNEX_MCP_SERVER_*` (name, version, port)
  - `LOG_LEVEL` / `LOG_FORMAT` → `AGENTNEX_LOG_LEVEL` / `AGENTNEX_LOG_FORMAT`
  - `BACKEND_TIMEOUT` / `BACKEND_RETRY_*` → `AGENTNEX_BACKEND_TIMEOUT` / `AGENTNEX_BACKEND_RETRY_*`
- Pydantic config updated to v2 style (`model_config = ConfigDict(...)`).

### Added
- **`list_devices`** MCP tool to list all registered devices for the account.
- Script `scripts/test_stdio_health_and_tools.py` for stdio-only testing: initialize (health), `tools/list`, and `tools/call` for `list_devices`; README section and optional step in Publishing.
- Test `tests/test_config_extra_env.py` for config load with NEXA-like extra env vars.
- Script `scripts/test_local_before_pypi.py` and README section for local pre-PyPI testing.

## [0.1.3] - 2026-02-10

### Fixed
- **Stdio test from source**: Script `scripts/test_stdio_health_and_tools.py` now runs the MCP server correctly from source using `python -m app.mcp_server` and sets `PYTHONPATH`; previously `python -m mcp_agentnex` failed (no such module).

### Added
- **`list_devices`** MCP tool documented in README (8 tools).
- Script `scripts/test_stdio_health_and_tools.py` and README section for stdio testing (initialize, tools/list, tools/call list_devices); optional step in Publishing.

### Documentation
- README: tools table and architecture diagram updated to 8 tools; "Test stdio" subsection and Publishing steps clarified.

## [0.1.4] - 2026-02-10

### Fixed
- **Resources in Inspector**: Resource read no longer fails with `'AnyUrl' object has no attribute 'split'`. URI is coerced to string in `read_resource` and in device resources when MCP/Inspector passes an `AnyUrl`.

### Added
- **Resource placeholder hint**: When reading device status or telemetry with the literal URI placeholder `{device_id}`, the server returns a JSON hint to use a real device ID and call `list_devices` first.
- **README**: "Debugging resources in Inspector" (get device ID from list_devices, use concrete URIs).
- **README**: "Stdio without script" and "Test with curl" under Alternate ways to test, with existing backend and API key examples (pipe JSON-RPC for stdio; run HTTP server then curl for HTTP).

### Documentation
- README: Alternate ways to test expanded with stdio pipe commands (single and two-request), curl against HTTP server, and note that curl cannot test stdio. Publishing twine example updated for 0.1.4.
- README: **How to test in MCP Inspector** — install Inspector, run with `mcp-agentnex`, test tools (initialize, tools/list, tools/call) and resources (resources/list, read with real device ID); link to PyPI 0.1.4.

## [0.1.5] - 2026-02-10

### Changed
- **Authentication**: Backend client now uses **user API tokens** (Bearer) from `AGENTNEX_API_KEY`. Tokens are user-scoped (created via backend `/api/auth/api-tokens/`); devices are filtered by the user's role and assignments.
- **Config**: `agentnex_api_key` / `AGENTNEX_API_KEY` documented as user API token (format `agentnex_<random-string>`). Default remains for local testing; set env for production.
- **Backend client**: All requests use `Authorization: Bearer <token>`; user-scoped access and audit trail on backend.

### Documentation
- README and `.env.example` updated for user API token (AGENTNEX_API_KEY) and backend URL (AGENTNEX_BACKEND_URL). Claude Desktop MCP config example (valid JSON, no `cwd` on Windows).

[0.1.5]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.5
[0.1.4]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.4
[0.1.3]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.3
[0.1.2]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.2
[0.1.0]: https://github.com/ivedha-tech/agentnex-mcpserver/releases/tag/v0.1.0
