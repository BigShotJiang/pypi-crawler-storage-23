"""Tests for the skill install command."""

from __future__ import annotations

import importlib.resources
from pathlib import Path

from druids.commands.skill import SKILLS
from druids.main import app
from typer.testing import CliRunner


runner = CliRunner()


def _expected_content() -> str:
    return importlib.resources.files("druids.skills").joinpath(SKILLS["druids-driver"]).read_text(encoding="utf-8")


def test_install_creates_skill_file(tmp_path: Path):
    """Install should create SKILL.md in the target directory."""
    result = runner.invoke(app, ["skill", "install", "--target-dir", str(tmp_path)])

    assert result.exit_code == 0
    skill_path = tmp_path / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    assert skill_path.exists()
    assert skill_path.read_text(encoding="utf-8") == _expected_content()


def test_install_twice_succeeds(tmp_path: Path):
    """Running install twice should succeed (overwrite)."""
    result1 = runner.invoke(app, ["skill", "install", "--target-dir", str(tmp_path)])
    assert result1.exit_code == 0

    result2 = runner.invoke(app, ["skill", "install", "--target-dir", str(tmp_path)])
    assert result2.exit_code == 0

    skill_path = tmp_path / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    assert skill_path.exists()


def test_install_default_target_dir(monkeypatch, tmp_path: Path):
    """Install with no flags should use current working directory."""
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["skill", "install"])

    assert result.exit_code == 0
    skill_path = tmp_path / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    assert skill_path.exists()


def test_install_global(monkeypatch, tmp_path: Path):
    """Install with --global should write to ~/.claude."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))

    result = runner.invoke(app, ["skill", "install", "--global"])

    assert result.exit_code == 0
    skill_path = tmp_path / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    assert skill_path.exists()
    assert skill_path.read_text(encoding="utf-8") == _expected_content()


def test_install_global_short_flag(monkeypatch, tmp_path: Path):
    """Install with -g should behave the same as --global."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))

    result = runner.invoke(app, ["skill", "install", "-g"])

    assert result.exit_code == 0
    skill_path = tmp_path / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    assert skill_path.exists()


def test_target_dir_overrides_global(monkeypatch, tmp_path: Path):
    """--target-dir should take precedence over --global."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", staticmethod(lambda: fake_home))

    target = tmp_path / "custom"
    target.mkdir()

    result = runner.invoke(app, ["skill", "install", "--global", "--target-dir", str(target)])

    assert result.exit_code == 0
    assert (target / ".claude" / "skills" / "druids-driver" / "SKILL.md").exists()
    assert not (fake_home / ".claude" / "skills" / "druids-driver" / "SKILL.md").exists()
