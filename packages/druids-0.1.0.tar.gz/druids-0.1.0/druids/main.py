"""Druids CLI entry point."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

import typer

from druids.client import APIError, NotFoundError, DruidsClient
from druids.commands.auth import auth
from druids.commands.secret import secret
from druids.commands.skill import skill
from druids.config import get_config
from druids.display import console, print_error, print_success
from druids.git import get_repo_from_cwd


app = typer.Typer(name="druids", help="Run programs on remote sandboxes.", no_args_is_help=True)
app.add_typer(auth, name="auth")
app.add_typer(secret, name="secret")
app.add_typer(skill, name="skill")


def get_authenticated_client() -> DruidsClient:
    """Get an authenticated client or exit with error."""
    config = get_config()
    if not config.user_access_token:
        print_error("Not authenticated. Run 'druids auth set-key <key>' first.")
        raise typer.Exit(1)
    return DruidsClient(config)


setup_app = typer.Typer(name="setup", help="Set up devbox environments.", no_args_is_help=True)
app.add_typer(setup_app, name="setup")


@setup_app.command()
def start(
    name: str | None = typer.Option(None, "--name", "-n", help="Devbox name (default: repo name or 'default')"),
    repo: str | None = typer.Option(None, "--repo", "-r", help="GitHub repo (owner/repo) to clone into the devbox"),
    public: bool = typer.Option(False, "--public", help="Make this devbox usable by other users on the same repo"),
):
    """Start devbox setup by provisioning a sandbox.

    Creates a sandbox, optionally clones a repo, and prints SSH credentials
    so you can configure the environment interactively. The sandbox stays
    running until you call `druids setup finish`.
    """
    client = get_authenticated_client()

    repo_full_name = repo or (get_repo_from_cwd() if not name else None)

    if not repo_full_name and not name:
        print_error("Provide --name or --repo (or run from inside a git repo).")
        raise typer.Exit(1)

    label = name or repo_full_name or "default"
    typer.echo(f"Provisioning devbox '{label}'...")
    if repo_full_name:
        typer.echo(f"  Repo: {repo_full_name}")

    try:
        data = client.setup_start(name=name, repo_full_name=repo_full_name, public=public)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    ssh = data["ssh"]
    devbox_name = data["name"]
    port = ssh.get("port", 22)

    # Write private key to a persistent file so the user can SSH in
    key_dir = Path.home() / ".druids"
    key_dir.mkdir(parents=True, exist_ok=True)
    safe_name = devbox_name.replace("/", "--")
    key_path = key_dir / f"devbox-{safe_name}.pem"
    key_path.write_text(ssh["private_key"])
    key_path.chmod(0o600)

    console.print(f"\n[bold]Devbox:[/bold] {devbox_name}")
    console.print(f"[bold]Instance:[/bold] {data['instance_id']}")
    if ssh.get("password"):
        console.print(f"[bold]Password:[/bold] {ssh['password']}")
    console.print("\nConnect with:")
    console.print(f"  ssh -i {key_path} -o StrictHostKeyChecking=no -p {port} {ssh['username']}@{ssh['host']}")
    console.print(f"\nWhen done, run: [bold]druids setup finish --name {devbox_name}[/bold]")


@setup_app.command()
def finish(
    name: str | None = typer.Option(None, "--name", "-n", help="Devbox name"),
    repo: str | None = typer.Option(None, "--repo", "-r", help="GitHub repo (owner/repo)"),
):
    """Finish devbox setup by snapshotting and stopping the sandbox.

    Snapshots the running sandbox, stops it, and stores the snapshot ID
    so the devbox can be used for executions.
    """
    client = get_authenticated_client()

    repo_full_name = repo or (get_repo_from_cwd() if not name else None)

    if not repo_full_name and not name:
        print_error("Provide --name or --repo (or run from inside a git repo).")
        raise typer.Exit(1)

    label = name or repo_full_name
    typer.echo(f"Finishing setup for '{label}'...")

    try:
        data = client.setup_finish(name=name, repo_full_name=repo_full_name)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    print_success(f"Devbox ready: [bold]{data['name']}[/bold] (snapshot {data['snapshot_id']})")


@app.command(context_settings={"allow_extra_args": True, "allow_interspersed_args": True})
def exec(
    ctx: typer.Context,
    program_file: Path = typer.Argument(..., help="Path to program.py file"),
    devbox: str | None = typer.Option(None, "--devbox", "-d", help="Devbox name (default: devbox for current repo)"),
    branch: str | None = typer.Option(None, "--branch", "-b", help="Git branch to checkout"),
):
    """Run a program on a remote sandbox.

    Resolves the devbox by name, or by detecting the current git repo. The
    devbox already knows whether it has a repo associated.

    Extra arguments are passed as key=value pairs to the program function.
    Example: druids exec program.py spec="build a feature"
    """
    client = get_authenticated_client()

    if not program_file.exists():
        print_error(f"Program file not found: {program_file}")
        raise typer.Exit(1)

    # Resolve devbox: explicit name, or look up by current repo
    devbox_name = devbox
    repo_full_name = None
    if not devbox_name:
        repo_full_name = get_repo_from_cwd()
        if not repo_full_name:
            print_error("Provide --devbox or run from inside a git repo.")
            raise typer.Exit(1)

    program_source = program_file.read_text()

    # Parse extra args as key=value pairs
    args: dict[str, str] = {}
    for arg in ctx.args:
        if "=" not in arg:
            print_error(f"Invalid argument '{arg}'. Expected key=value format.")
            raise typer.Exit(1)
        key, value = arg.split("=", 1)
        args[key] = value

    label = devbox_name or repo_full_name
    typer.echo(f"Running {program_file.name} (devbox: {label})")

    try:
        data = client.create_execution(
            program_source, devbox_name=devbox_name, repo_full_name=repo_full_name, args=args or None,
            git_branch=branch,
        )
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    slug = data["execution_slug"]
    print_success(f"Execution started: [bold]{slug}[/bold]")
    console.print(f"  Run 'druids status {slug}' to check progress.")


@app.command()
def status(
    slug: str = typer.Argument(..., help="Execution slug"),
):
    """Check status of an execution."""
    client = get_authenticated_client()

    try:
        data = client.get_execution(slug)
    except NotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    status_color = "green" if data["status"] == "running" else "yellow" if data["status"] == "completed" else "red"
    console.print(f"[bold]Execution:[/bold] {data['execution_slug']}")
    console.print(f"[bold]Status:[/bold] [{status_color}]{data['status']}[/{status_color}]")
    if data.get("repo_full_name"):
        console.print(f"[bold]Repo:[/bold] {data['repo_full_name']}")
    if data.get("branch_name"):
        console.print(f"[bold]Branch:[/bold] {data['branch_name']}")
    if data.get("pr_url"):
        console.print(f"[bold]PR:[/bold] {data['pr_url']}")
    if data.get("agents"):
        console.print(f"[bold]Agents:[/bold] {', '.join(data['agents'])}")
    if data.get("connections"):
        console.print(f"[bold]Connected:[/bold] {', '.join(data['connections'])}")
    for svc in data.get("exposed_services", []):
        console.print(f"  {svc['service_name']} -> {svc['url']}")


@app.command()
def stop(
    slug: str = typer.Argument(..., help="Execution slug"),
):
    """Stop an execution."""
    client = get_authenticated_client()

    try:
        data = client.stop_execution(slug)
    except NotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    print_success(f"Execution {data['execution_slug']} stopped")


def _resolve_agent_context() -> tuple[str, str]:
    """Get execution_slug and agent_name from config. Used by agents on the VM."""
    config = get_config()
    if not config.execution_slug or not config.agent_name:
        print_error("Not running inside an agent VM. execution_slug and agent_name not set.")
        raise typer.Exit(1)
    return config.execution_slug, config.agent_name


@app.command()
def tools():
    """List tools available to this agent. Run from inside an agent VM."""
    client = get_authenticated_client()
    slug, agent_name = _resolve_agent_context()

    try:
        tool_list = client.list_tools(slug, agent_name)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    if not tool_list:
        typer.echo("No tools registered")
        return

    for name in tool_list:
        typer.echo(name)


@app.command(name="tool", context_settings={"allow_extra_args": True, "allow_interspersed_args": True})
def tool_call(
    ctx: typer.Context,
    tool_name: str = typer.Argument(..., help="Tool name to call"),
):
    """Call a registered tool. Run from inside an agent VM.

    Extra arguments are passed as key=value pairs.
    Example: druids tool submit diff="..." summary="..."
    """
    client = get_authenticated_client()
    slug, agent_name = _resolve_agent_context()

    args: dict[str, str] = {}
    for arg in ctx.args:
        if "=" not in arg:
            print_error(f"Invalid argument '{arg}'. Expected key=value format.")
            raise typer.Exit(1)
        key, value = arg.split("=", 1)
        args[key] = value

    try:
        result = client.call_tool(slug, agent_name, tool_name, args)
    except NotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    if result is not None:
        typer.echo(json.dumps(result) if isinstance(result, (dict, list)) else str(result))


@app.command()
def connect(
    execution_slug: str = typer.Argument(..., help="Execution slug"),
    agent: str | None = typer.Option(None, "--agent", "-a", help="Agent name (default: root instance)"),
):
    """SSH into an execution's VM as the agent user."""
    client = get_authenticated_client()

    try:
        creds = client.get_execution_ssh(execution_slug, agent=agent)
    except NotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    host = creds["host"]
    username = creds["username"]
    private_key = creds["private_key"]
    password = creds.get("password", "")

    # Write private key to a temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
        f.write(private_key)
        key_path = f.name
    os.chmod(key_path, 0o600)

    target = agent or "root"
    console.print(f"Connecting to [bold]{execution_slug}[/bold] ({target}: {username})...")
    console.print(f"[dim]Password (if prompted): {password}[/dim]")

    try:
        subprocess.run(
            [
                "ssh",
                "-i",
                key_path,
                "-o",
                "StrictHostKeyChecking=no",
                "-o",
                "UserKnownHostsFile=/dev/null",
                "-t",
                f"{username}@{host}",
                "sudo -iu agent",
            ],
        )
    finally:
        os.unlink(key_path)


@app.command(name="ls")
def list_executions(
    all_executions: bool = typer.Option(False, "--all", "-a", help="Include stopped executions"),
):
    """List executions."""
    client = get_authenticated_client()

    try:
        items = client.list_executions(active_only=not all_executions)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    if not items:
        typer.echo("No executions found")
        return

    for ex in items:
        status_color = "green" if ex["status"] == "running" else "yellow" if ex["status"] == "completed" else "dim"
        pr = f" -> {ex['pr_url']}" if ex.get("pr_url") else ""
        console.print(f"[{status_color}]{ex['slug']}[/{status_color}] [{ex['status']}] {ex.get('repo_full_name', '')}{pr}")


@app.command(hidden=True)
def apply(
    execution_slug: str = typer.Argument(..., help="Execution slug"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
):
    """Apply diff from an execution's VM to local repo."""
    client = get_authenticated_client()

    try:
        diff = client.get_execution_diff(execution_slug)
    except NotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Error: {e}")
        raise typer.Exit(1)

    if not diff.strip():
        typer.echo("No changes to apply")
        raise typer.Exit(0)

    typer.echo(diff)
    typer.echo()

    # Find repo root
    repo_root_result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if repo_root_result.returncode != 0:
        print_error("Not in a git repository")
        raise typer.Exit(1)
    repo_root = repo_root_result.stdout.strip()

    apply_args = ["git", "apply", "-v"]
    if force:
        apply_args.append("--reject")

    if not force:
        result = subprocess.run(
            ["git", "apply", "--check"],
            input=diff,
            text=True,
            capture_output=True,
            cwd=repo_root,
        )
        if result.returncode != 0:
            print_error(f"Diff cannot be applied cleanly:\n{result.stderr}")
            print_error("Use --force to apply anyway")
            raise typer.Exit(1)

    result = subprocess.run(
        apply_args,
        input=diff,
        text=True,
        capture_output=True,
        cwd=repo_root,
    )

    if result.returncode != 0:
        print_error(f"Failed to apply diff:\n{result.stderr}")
        raise typer.Exit(1)

    if result.stderr:
        typer.echo(result.stderr)
    print_success("Changes applied")


@app.command(name="mcp-config")
def mcp_config():
    """Print MCP server configuration for Claude Code or Claude Desktop."""
    config = get_config()

    if not config.user_access_token:
        print_error("Not authenticated. Run 'druids auth set-key <key>' first.")
        raise typer.Exit(1)

    base_url = str(config.base_url).rstrip("/")
    mcp_block = {
        "mcpServers": {
            "druids": {
                "type": "http",
                "url": f"{base_url}/mcp/",
                "headers": {
                    "Authorization": f"Bearer {config.user_access_token}",
                },
            }
        }
    }

    console.print("Add this to your [bold].mcp.json[/bold] (or claude_desktop_config.json):\n")
    typer.echo(json.dumps(mcp_block, indent=2))


if __name__ == "__main__":
    app()
