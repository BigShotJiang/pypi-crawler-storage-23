"""Skill management commands."""

from __future__ import annotations

import importlib.resources
from pathlib import Path

import typer
from druids.display import print_success


skill = typer.Typer(help="Manage Claude Code skills.", no_args_is_help=True)

SKILLS = {
    "druids-driver": "SKILL.md",
}


def _read_bundled_skill(filename: str) -> str:
    """Read a bundled skill file from the druids.skills package."""
    return importlib.resources.files("druids.skills").joinpath(filename).read_text(encoding="utf-8")


@skill.command()
def install(
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Install globally to ~/.claude (applies to all repos)"
    ),
    target_dir: Path | None = typer.Option(
        None, "--target-dir", "-t", help="Override install directory (for testing or custom paths)"
    ),
):
    """Install the druids-driver skill into a target codebase.

    Creates .claude/skills/druids-driver/SKILL.md so Claude Code
    loads the Druids driver reference automatically.

    By default, installs relative to the current working directory.
    Use --global to install to ~/.claude instead.
    """
    if target_dir is not None:
        base = target_dir
    elif global_install:
        base = Path.home()
    else:
        base = Path.cwd()

    dest = base / ".claude" / "skills" / "druids-driver" / "SKILL.md"
    dest.parent.mkdir(parents=True, exist_ok=True)

    content = _read_bundled_skill(SKILLS["druids-driver"])
    dest.write_text(content, encoding="utf-8")

    print_success(f"Installed druids-driver skill to {dest}")
