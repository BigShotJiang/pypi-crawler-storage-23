---
name: druids-driver
description: >
  Reference for all Druids MCP tools, concepts, and workflows.
  Loaded automatically so Claude Code always knows how to drive Druids.
user-invocable: false
---

# Druids Driver Reference

Druids runs coding agents on remote VMs provisioned by MorphCloud. You interact with it through MCP tools. Your job is to translate the user's intent into programs, launch executions, monitor agents as they work, and review the results.

## MCP tools

These are the tools exposed by the Druids server via MCP. All are tagged `mcp-driver`.

### Creating work

- `create_execution` -- Create and start an execution. Required: `program_source` (string, Python source defining `async def program(ctx, ...)`). Optional: `devbox_name` (string), `repo_full_name` (string, used to find the devbox when `devbox_name` is not set), `git_branch` (string), `args` (dict of string key-value pairs passed to the program function). Returns `execution_slug` and `execution_id`.

### Monitoring

- `list_executions` -- List executions. Pass `active_only=false` to include stopped executions.
- `get_execution` -- Get execution by slug. Returns status, agents, connections, branch name, PR URL, exposed services, and client events.
- `get_execution_activity` -- Get recent trace events for an execution slug. Optional: `n` (number of events, default 50), `compact` (bool, default true). Returns agent names, event count, and recent activity.
- `get_execution_diff` -- Get git diff from an execution's VM. Optional: `agent` (string, specific agent name; default picks the first agent with a machine).

### Interacting with agents

- `send_message` -- Send a message to a running agent. Required: `receiver` (agent name), `message` (string). Set `sender` to `"driver"` for external callers. `execution_slug` identifies the execution.
- `remote_exec` -- Run a shell command on a VM. Target by `repo` (devbox) or `execution_slug` + `agent_name` (agent VM). Required: `command` (string). Returns `stdout`, `stderr`, `exit_code`.
- `stop_agent` -- Stop a specific agent. Required: `agent_name`, `execution_slug`.
- `get_agent_ssh` -- Get SSH credentials for an agent's VM. Required: `agent_name`, `execution_slug`. Returns host, port, username, private_key, password.

### Stopping work

- `update_execution` -- Stop a running execution by setting `status` to `"stopped"`. Also used to mark executions as `"completed"` or `"failed"`.

## Concepts

An **execution** is the unit of work. Created by sending program source code to `create_execution`. Gets a slug like `gentle-nocturne`. When agents finish, they typically push a branch and open a PR.

A **program** is a Python source file that defines `async def program(ctx, ...)`. The driver reads the file and sends its source as `program_source` to `create_execution`. Programs live in `.druids/` in the repo. The server evaluates the source and calls `program(ctx, **args)`.

Programs create **agents** via `ctx.agent(name, ...)`. Each agent runs on a VM with a bridge process connecting it to the server. Agents can have tools registered via `@agent.on("tool_name")` -- these become callable by the agent through `druids tool <tool_name>` on the VM.

A **devbox** is a VM snapshot with the user's repo cloned and dependencies installed. Created via `druids setup start` and `druids setup finish`. Executions fork from the devbox snapshot so each agent starts with a working environment.

## Programs in `.druids/`

- **main.py**: Spawns a Claude agent and a Codex agent in parallel on the same spec. Both implement independently, both call `submit` when done. Good for comparing two models on the same task.
- **review.py**: Demo-reviews a pull request. A demo agent runs the system and tests every changed behavior from the outside (HTTP requests, CLI commands, not code reading). A Sonnet monitor watches for lazy behavior and nudges when needed. Takes `pr_number`, `pr_title`, `pr_body`, `repo_full_name` as args.
- **basher.py**: Background task finder and implementor. Has two modes:
  - Direct mode: pass `task_name` and `task_spec` to skip the finder and spawn an implementor+reviewer pair directly. The implementor implements on a feature branch, the reviewer demos the change and creates a PR if it works (up to 3 review rounds).
  - Full mode: a finder agent scans GitHub (and optionally Slack) for actionable work and spawns implementor+reviewer pairs for well-scoped tasks.

## CLI commands

The `druids` CLI is used from the driver's local machine:

- `druids exec program.py [--devbox NAME] [--branch BRANCH] [key=value ...]` -- Run a program. Reads the file, sends source to the server. Extra args are passed to the program function.
- `druids ls [--all]` -- List executions.
- `druids status SLUG` -- Check execution status.
- `druids stop SLUG` -- Stop an execution.
- `druids connect SLUG [--agent NAME]` -- SSH into an execution's VM.
- `druids setup start [--name NAME] [--repo OWNER/REPO]` -- Provision a devbox.
- `druids setup finish [--name NAME] [--repo OWNER/REPO]` -- Snapshot and save the devbox.
- `druids mcp-config` -- Print MCP server config for Claude Code.
- `druids auth set-key KEY` -- Set authentication key.
- `druids secret ...` -- Manage devbox secrets.

## Typical workflow

1. User asks you to build something.
2. Explore the codebase. Understand conventions, test structure, relevant files.
3. Write a spec describing what needs to change (use the `write-spec` skill if needed).
4. Choose a program from `.druids/`. For a single implementation task with review, use `basher.py` in direct mode. For comparing models, use `main.py`. For reviewing an existing PR, use `review.py`.
5. Read the program source and call `create_execution` with `program_source` set to the file contents and `args` containing the spec and other parameters the program expects.
6. Poll `get_execution` with the execution slug. Check status, agents, connections.
7. When `pr_url` appears, call `get_execution_diff` to review the agent's work.
8. Report to the user: link to PR, summary of changes, any concerns.

If an agent is stuck (check `get_execution_activity`), send guidance via `send_message` with `sender="driver"`.

## Things to know

- Execution status values: `created`, `running`, `completed`, `stopped`, `failed`.
- You do not need a git repo to use Druids. The CLI can target any devbox by name.
- The `remote_exec` tool can target a devbox directly (pass `repo`) without needing a running execution. Use this for setup tasks, debugging, or ad-hoc commands on the devbox.
- Agents on the VM call tools via `druids tool <tool_name> key=value`. The tools are defined by `@agent.on("tool_name")` in the program source.
- Built-in agent tools (available to every agent): `expose` (expose a port as public HTTPS URL), `message` (send message to another agent), `list_agents` (list all agents in the execution).
- Programs can use `share_machine_with=other_agent` to run two agents on the same VM (e.g., implementor and reviewer sharing a machine).
