# figpack_spike_sorting

Spike Sorting visualization extension for figpack.

## Build

```bash
npm install
npm run build
pip install -e .
```