from __future__ import annotations

import re

from .registry import get_config, _RESERVED_KEYS
from ..constants.tailwind import (
    _BORDER_SIDES, _BORDER_STYLES, _BORDER_COLLAPSE, _ROUNDED_SIDES,
    _FONT_FAMILIES, _FONT_WEIGHTS, _FONT_STRETCHES,
    _TEXT_ALIGNS, _TEXT_SIZES, _TEXT_DECORATIONS, _TEXT_TRANSFORMS, _TEXT_OVERFLOWS, _TEXT_WRAPS,
    _BG_ATTACHMENT, _BG_REPEAT, _BG_SIZE, _BG_POSITION,
    _SHADOW_SIZES, _DROP_SHADOW_SIZES,
    _OBJECT_FITS, _LIST_POSITIONS,
    _SNAP_ALIGNS, _SNAP_STOPS, _SNAP_TYPES,
)


def _get_class_prefix(cls: str) -> str:
    if not cls:
        return cls

    modifier = ""
    rest = cls
    # Handle responsive/state modifiers (e.g. "hover:", "md:", "dark:")
    if ":" in cls:
        modifier, rest = cls.split(":", 1)
        modifier = modifier + ":"

    # Arbitrary values — unique, never deduplicated
    if rest.startswith("["):
        return cls

    # Strip trailing "!" (v4 important modifier: "flex!", "bg-red-500!")
    bare = rest.rstrip("!")
    parts = bare.split("-")

    if len(parts) == 1:
        return modifier + bare

    root = parts[0]
    second = parts[1] if len(parts) > 1 else ""

    # --- Flexbox ---
    if root == "flex":
        if second in ("col", "row"):
            return modifier + "flex-direction"
        if second in ("wrap", "nowrap"):
            return modifier + "flex-wrap"
        if second == "grow":
            return modifier + "flex-grow"
        if second == "shrink":
            return modifier + "flex-shrink"
        return modifier + "flex-shorthand"

    if root == "basis":
        return modifier + "flex-basis"
    if root == "grow":
        return modifier + "flex-grow"
    if root == "shrink":
        return modifier + "flex-shrink"

    # --- Grid ---
    if root == "grid":
        if second == "cols":
            return modifier + "grid-template-columns"
        if second == "rows":
            return modifier + "grid-template-rows"
        if second == "flow":
            return modifier + "grid-auto-flow"
        return modifier + rest

    if root == "auto":
        if second == "cols":
            return modifier + "grid-auto-columns"
        if second == "rows":
            return modifier + "grid-auto-rows"
        return modifier + rest

    if root == "col":
        if second == "span":
            return modifier + "grid-column-span"
        if second == "start":
            return modifier + "grid-column-start"
        if second == "end":
            return modifier + "grid-column-end"
        return modifier + rest
    if root == "row":
        if second == "span":
            return modifier + "grid-row-span"
        if second == "start":
            return modifier + "grid-row-start"
        if second == "end":
            return modifier + "grid-row-end"
        return modifier + rest

    # --- Gap / Space ---
    if root == "gap":
        if second == "x":
            return modifier + "column-gap"
        if second == "y":
            return modifier + "row-gap"
        return modifier + "gap"

    if root == "space":
        if second == "x":
            return modifier + "space-x"
        if second == "y":
            return modifier + "space-y"
        return modifier + rest

    # --- Alignment ---
    if root == "justify":
        if second == "items":
            return modifier + "justify-items"
        if second == "self":
            return modifier + "justify-self"
        return modifier + "justify-content"

    if root == "items":
        return modifier + "align-items"
    if root == "self":
        return modifier + "align-self"
    if root == "content":
        return modifier + "align-content"

    if root == "place":
        if second == "content":
            return modifier + "place-content"
        if second == "items":
            return modifier + "place-items"
        if second == "self":
            return modifier + "place-self"
        return modifier + rest

    # --- Sizing ---
    if root == "size":
        return modifier + "size"
    if root == "w":
        return modifier + "width"
    if root == "h":
        return modifier + "height"
    if root == "min":
        if second == "w":
            return modifier + "min-width"
        if second == "h":
            return modifier + "min-height"
        return modifier + rest
    if root == "max":
        if second == "w":
            return modifier + "max-width"
        if second == "h":
            return modifier + "max-height"
        return modifier + rest

    # --- Spacing (padding/margin) ---
    if root == "p":
        return modifier + "padding"
    if root in ("px", "py", "ps", "pe", "pt", "pr", "pb", "pl"):
        return modifier + f"padding-{root[1:]}"
    if root == "m":
        return modifier + "margin"
    if root in ("mx", "my", "ms", "me", "mt", "mr", "mb", "ml"):
        return modifier + f"margin-{root[1:]}"

    # --- Positioning ---
    if root == "inset":
        if second == "x":
            return modifier + "inset-x"
        if second == "y":
            return modifier + "inset-y"
        return modifier + "inset"
    if root in ("top", "right", "bottom", "left", "start", "end"):
        return modifier + root
    if root == "z":
        return modifier + "z-index"

    # --- Overflow ---
    if root == "overflow":
        if second == "x":
            return modifier + "overflow-x"
        if second == "y":
            return modifier + "overflow-y"
        return modifier + "overflow"
    if root == "overscroll":
        if second == "x":
            return modifier + "overscroll-x"
        if second == "y":
            return modifier + "overscroll-y"
        return modifier + "overscroll"

    # --- Border ---
    if root == "border":
        if second == "spacing":
            if len(parts) > 2 and parts[2] == "x":
                return modifier + "border-spacing-x"
            if len(parts) > 2 and parts[2] == "y":
                return modifier + "border-spacing-y"
            return modifier + "border-spacing"
        if second in _BORDER_SIDES:
            side = second
            if len(parts) == 2:
                return modifier + f"border-{side}-width"
            third = parts[2]
            if third.isdigit() or third == "0":
                return modifier + f"border-{side}-width"
            elif third in _BORDER_STYLES:
                return modifier + f"border-{side}-style"
            else:
                return modifier + f"border-{side}-color"
        if second in _BORDER_STYLES:
            return modifier + "border-style"
        if second in _BORDER_COLLAPSE:
            return modifier + "border-collapse"
        if second.isdigit() or second == "0":
            return modifier + "border-width"
        return modifier + "border-color"

    if root == "rounded":
        if second in _ROUNDED_SIDES:
            return modifier + f"rounded-{second}"
        return modifier + "rounded"

    if root == "divide":
        if second == "x":
            return modifier + "divide-x"
        if second == "y":
            return modifier + "divide-y"
        if second in _BORDER_STYLES:
            return modifier + "divide-style"
        return modifier + "divide-color"

    # --- Ring ---
    if root == "ring":
        if second == "offset":
            if len(parts) == 2:
                return modifier + "ring-offset-width"
            third = parts[2]
            if third.isdigit() or third == "0":
                return modifier + "ring-offset-width"
            return modifier + "ring-offset-color"
        if second == "inset":
            return modifier + "ring-inset"
        if second.isdigit() or second == "0":
            return modifier + "ring-width"
        return modifier + "ring-color"

    # --- Outline ---
    if root == "outline":
        if second == "offset":
            return modifier + "outline-offset"
        if second in _BORDER_STYLES:
            return modifier + "outline-style"
        if second.isdigit() or second == "0" or second == "none":
            return modifier + "outline-width"
        return modifier + "outline-color"

    # --- Shadow ---
    if root == "shadow":
        if second in _SHADOW_SIZES or len(parts) == 1:
            return modifier + "shadow-size"
        return modifier + "shadow-color"

    # --- Typography ---
    if root == "font":
        if second in _FONT_FAMILIES:
            return modifier + "font-family"
        if second in _FONT_WEIGHTS:
            return modifier + "font-weight"
        if second == "stretch":
            return modifier + "font-stretch"
        return modifier + rest

    if root == "text":
        if second in _TEXT_ALIGNS:
            return modifier + "text-align"
        if second.startswith("["):
            inner = second[1:].rstrip("]").lower()
            if inner.startswith(("#", "rgb", "hsl")) or inner in ("transparent", "current", "inherit"):
                return modifier + "text-color"
            return modifier + "text-size"
        if len(parts) == 2:
            if second in _TEXT_SIZES:
                return modifier + "text-size"
            return modifier + "text-color"
        return modifier + "text-color"

    if root == "tracking":
        return modifier + "letter-spacing"
    if root == "leading":
        return modifier + "line-height"
    if root == "line":
        if second == "clamp":
            return modifier + "line-clamp"
        return modifier + rest
    if root == "indent":
        return modifier + "text-indent"

    if root == "decoration":
        if second in _BORDER_STYLES:
            return modifier + "text-decoration-style"
        if second.isdigit() or second == "0" or second == "auto" or second == "from":
            return modifier + "text-decoration-thickness"
        return modifier + "text-decoration-color"
    if root == "underline":
        if second == "offset":
            return modifier + "underline-offset"
        return modifier + rest

    if root == "list":
        if second in _LIST_POSITIONS:
            return modifier + "list-style-position"
        return modifier + "list-style-type"

    if root == "whitespace":
        return modifier + "white-space"
    if root == "break":
        if second in ("before", "after", "inside"):
            return modifier + f"break-{second}"
        return modifier + "word-break"
    if root == "hyphens":
        return modifier + "hyphens"

    # --- Backgrounds ---
    if root == "bg":
        if second in _BG_ATTACHMENT:
            return modifier + "bg-attachment"
        if second == "clip":
            return modifier + "bg-clip"
        if second == "origin":
            return modifier + "bg-origin"
        if second in _BG_REPEAT or (second == "no" and len(parts) > 2 and parts[2] == "repeat"):
            return modifier + "bg-repeat"
        if second in _BG_SIZE:
            return modifier + "bg-size"
        if second in _BG_POSITION or (second in ("left", "right") and len(parts) > 2):
            return modifier + "bg-position"
        if second in ("none", "gradient", "linear", "radial", "conic"):
            return modifier + "bg-image"
        if second == "blend":
            return modifier + "bg-blend-mode"
        return modifier + "bg-color"

    if root == "from":
        return modifier + "gradient-from"
    if root == "via":
        return modifier + "gradient-via"
    if root == "to":
        return modifier + "gradient-to"

    # --- Effects / Filters ---
    if root == "opacity":
        return modifier + "opacity"
    if root == "mix":
        return modifier + "mix-blend-mode"

    if root == "drop":
        # drop-shadow-*
        if second == "shadow":
            if len(parts) > 2 and parts[2] in _DROP_SHADOW_SIZES:
                return modifier + "drop-shadow-size"
            if len(parts) == 2:
                return modifier + "drop-shadow-size"
            return modifier + "drop-shadow-color"
        return modifier + rest

    if root == "blur":
        return modifier + "blur"
    if root == "brightness":
        return modifier + "brightness"
    if root == "contrast":
        return modifier + "contrast"
    if root == "grayscale":
        return modifier + "grayscale"
    if root == "hue":
        return modifier + "hue-rotate"
    if root == "invert":
        return modifier + "invert"
    if root == "saturate":
        return modifier + "saturate"
    if root == "sepia":
        return modifier + "sepia"

    if root == "backdrop":
        # backdrop-blur-*, backdrop-brightness-*, etc.
        return modifier + f"backdrop-{second}"

    # --- Transforms ---
    if root == "scale":
        if second == "x":
            return modifier + "scale-x"
        if second == "y":
            return modifier + "scale-y"
        if second == "z":
            return modifier + "scale-z"
        return modifier + "scale"
    if root == "rotate":
        if second == "x":
            return modifier + "rotate-x"
        if second == "y":
            return modifier + "rotate-y"
        return modifier + "rotate"
    if root == "translate":
        if second == "x":
            return modifier + "translate-x"
        if second == "y":
            return modifier + "translate-y"
        if second == "z":
            return modifier + "translate-z"
        return modifier + rest
    if root == "skew":
        if second == "x":
            return modifier + "skew-x"
        if second == "y":
            return modifier + "skew-y"
        return modifier + rest
    if root == "origin":
        return modifier + "transform-origin"
    if root == "perspective":
        return modifier + "perspective"
    if root == "backface":
        return modifier + "backface-visibility"

    # --- Transitions / Animation ---
    if root == "transition":
        return modifier + "transition-property"
    if root == "duration":
        return modifier + "transition-duration"
    if root == "delay":
        return modifier + "transition-delay"
    if root == "ease":
        return modifier + "transition-timing-function"
    if root == "animate":
        return modifier + "animation"

    # --- SVG ---
    if root == "fill":
        return modifier + "fill"
    if root == "stroke":
        if second.isdigit():
            return modifier + "stroke-width"
        return modifier + "stroke-color"

    # --- Interactivity ---
    if root == "cursor":
        return modifier + "cursor"
    if root == "caret":
        return modifier + "caret-color"
    if root == "accent":
        return modifier + "accent-color"
    if root == "pointer":
        return modifier + "pointer-events"
    if root == "select":
        return modifier + "user-select"
    if root == "resize":
        return modifier + "resize"
    if root == "touch":
        return modifier + "touch-action"
    if root == "will":
        return modifier + "will-change"
    if root == "appearance":
        return modifier + "appearance"
    if root == "field":
        return modifier + "field-sizing"
    if root == "color":
        if second == "scheme":
            return modifier + "color-scheme"
        return modifier + rest

    # --- Scroll ---
    if root == "scroll":
        if second == "m":
            if len(parts) > 2 and parts[2] in ("x", "y", "t", "r", "b", "l", "s", "e"):
                return modifier + f"scroll-margin-{parts[2]}"
            return modifier + "scroll-margin"
        if second == "p":
            if len(parts) > 2 and parts[2] in ("x", "y", "t", "r", "b", "l", "s", "e"):
                return modifier + f"scroll-padding-{parts[2]}"
            return modifier + "scroll-padding"
        if second in ("mx", "my", "ms", "me", "mt", "mr", "mb", "ml"):
            return modifier + f"scroll-margin-{second[1:]}"
        if second in ("px", "py", "ps", "pe", "pt", "pr", "pb", "pl"):
            return modifier + f"scroll-padding-{second[1:]}"
        return modifier + "scroll-behavior"
    if root == "snap":
        if second in _SNAP_TYPES:
            return modifier + "snap-type"
        if second in _SNAP_ALIGNS:
            return modifier + "snap-align"
        if second in _SNAP_STOPS:
            return modifier + "snap-stop"
        return modifier + rest

    # --- Layout ---
    if root == "aspect":
        return modifier + "aspect-ratio"
    if root == "columns":
        return modifier + "columns"
    if root == "object":
        if second in _OBJECT_FITS:
            return modifier + "object-fit"
        return modifier + "object-position"
    if root == "float":
        return modifier + "float"
    if root == "clear":
        return modifier + "clear"
    if root == "order":
        return modifier + "order"

    # --- Table ---
    if root == "table":
        return modifier + "table-layout"
    if root == "caption":
        return modifier + "caption-side"

    # --- Accessibility ---
    if root == "sr":
        return modifier + "screen-reader"
    if root == "not":
        if second == "sr":
            return modifier + "screen-reader"
        return modifier + rest
    if root == "forced":
        return modifier + "forced-color-adjust"

    # --- Fallback: group by all-but-last segment ---
    return modifier + "-".join(parts[:-1])


def build_classes(component_name: str, props: dict) -> str:
    config = get_config(component_name)

    if not config:
        return component_name

    all_classes: list[str] = []

    base_class = config.get("class", "")
    if base_class:
        all_classes.extend(base_class.split())

    for key, group in config.items():
        if key in _RESERVED_KEYS or not isinstance(group, dict):
            continue
        chosen = props.get(key)
        if chosen and chosen in group and group[chosen]:
            all_classes.extend(str(group[chosen]).split())

    if "class" in props:
        custom_class = props["class"]
        if custom_class:
            all_classes.extend(str(custom_class).split())

    # Pass 1: for each Tailwind prefix, keep only the last class (last-wins override)
    prefix_to_class: dict[str, str] = {}
    for cls in all_classes:
        if cls:
            prefix = _get_class_prefix(cls)
            if prefix:
                prefix_to_class[prefix] = cls

    # Pass 2: iterate in original order, emit only the winning class per prefix (no duplicates)
    seen: set[str] = set()
    unique_classes: list[str] = []
    for cls in all_classes:
        if not cls or cls in seen:
            continue
        prefix = _get_class_prefix(cls)
        if not prefix or prefix_to_class.get(prefix) == cls:
            seen.add(cls)
            unique_classes.append(cls)

    return " ".join(unique_classes) if unique_classes else component_name


def build_classes_from_strings(base: str, override: str) -> str:
    """Merge two class strings using Tailwind-aware last-wins deduplication.
    Classes in override win over conflicting prefixes in base."""
    all_classes = base.split() + override.split()

    prefix_to_class: dict[str, str] = {}
    for cls in all_classes:
        if cls:
            prefix = _get_class_prefix(cls)
            if prefix:
                prefix_to_class[prefix] = cls

    seen: set[str] = set()
    unique_classes: list[str] = []
    for cls in all_classes:
        if not cls or cls in seen:
            continue
        prefix = _get_class_prefix(cls)
        if not prefix or prefix_to_class.get(prefix) == cls:
            seen.add(cls)
            unique_classes.append(cls)

    return " ".join(unique_classes)


def build_extra_attrs(props: dict, modifier_keys: set[str] | None = None) -> str:
    excluded = {"class", "variant", "children", "design", "template", "as", "list"}
    if modifier_keys:
        excluded = excluded | modifier_keys
    attrs = []
    for key, val in props.items():
        if key in excluded:
            continue
        if val is True:
            attrs.append(key)
        elif val:
            attrs.append(f'{key}="{val}"')
    return " " + " ".join(attrs) if attrs else ""


def build_config_attrs(config: dict) -> str:
    """Extract fixed HTML attributes defined in component YAML config.
    Keys that are not reserved and not modifier groups (not dict values) are
    treated as fixed attributes to inject into the root tag.
    Example: open: true → open, id: foo → id="foo"
    """
    attrs = []
    for key, val in config.items():
        if key in _RESERVED_KEYS or isinstance(val, dict):
            continue
        if val is True:
            attrs.append(key)
        elif val and val is not False:
            attrs.append(f'{key}="{val}"')
    return " " + " ".join(attrs) if attrs else ""


def _wrap_in_link_if_needed(html: str, props: dict, tag: str) -> str:
    href = props.get("href")
    if href and tag != "a":
        target = props.get("target")
        rel = props.get("rel", "noopener noreferrer")
        link_attrs = f'href="{href}"'
        if target:
            link_attrs += f' target="{target}"'
        if rel:
            link_attrs += f' rel="{rel}"'
        inner_html = re.sub(r'\s+href="[^"]*"', '', html)
        return f'<a {link_attrs}>{inner_html}</a>'
    return html
