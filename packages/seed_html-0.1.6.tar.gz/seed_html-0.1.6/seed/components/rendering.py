from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Callable

from ..nodes import Content, RawContent, Component as CompNode, VarRef
from ..constants.html_tags import _BODY_TAGS, _HEAD_TAGS, _PREFORMATTED_TAGS, _MARKDOWN_TAGS, _SELF_CLOSING_TAGS
from ..constants.errors import _ERR_SLOT_MISSING, _ERR_NO_SLOT, _ERR_HEAD_TAG, _ERR_UNKNOWN_TAG
from ..constants.components import _SLOT_RE

from .registry import (
    _template_cache,
    _template_file,
    get_config,
    get_template,
    has_template,
    is_registered,
    _extract_slots,
    get_modifier_keys,
)
from .classes import (
    build_classes,
    build_extra_attrs,
    build_config_attrs,
    _wrap_in_link_if_needed,
)

# Kept for API compatibility — no longer used for CSS injection
_has_errors: bool = False

# Recursion guard: set of component names currently being rendered via template
_rendering_stack: set[str] = set()

# Error template for recursive templates
_ERR_RECURSION = (
    '<div style="border:2px solid #dc2626;background:#fee2e2;color:#991b1b;'
    'padding:12px 16px;border-radius:8px;font-size:14px;margin:8px 0">'
    'ERRO<br>Recursão detectada: @{comp} usa a si mesmo no template</div>'
)


def _err(template: str, **kwargs) -> str:
    """Format an error template."""
    global _has_errors
    _has_errors = True
    return template.format(**kwargs)


def reset_error_state() -> None:
    """Call before each render to reset error tracking."""
    global _has_errors
    _has_errors = False
    _rendering_stack.clear()


_LIST_SEPARATOR_RE = re.compile(r'^---$', re.MULTILINE)


def _find_preformatted_slots(children: list, inside_pre: bool = False) -> set[str]:
    """Walk template AST and return slot names that live inside a @pre or @code node."""
    found: set[str] = set()
    for child in children:
        if isinstance(child, Content) and inside_pre:
            for m in _SLOT_RE.finditer(child.text):
                found.add(m.group(2))
        elif isinstance(child, CompNode):
            effective = child.props.get("as", child.name)
            is_pre = effective in _PREFORMATTED_TAGS
            found |= _find_preformatted_slots(child.children, inside_pre or is_pre)
    return found


def _serialize_nodes(nodes: list, indent: int = 0, vars: dict | None = None) -> str:
    """Serialize a list of Component/Content/VarRef nodes back to .seed syntax."""
    parts = []
    pad = "  " * indent
    for node in nodes:
        if isinstance(node, Content):
            for line in node.text.splitlines():
                parts.append(pad + line)
        elif isinstance(node, VarRef):
            # Expand var inline during serialization
            var_children = (vars or {}).get(node.name, [])
            if var_children:
                parts.append(_serialize_nodes(var_children, indent, vars))
        elif isinstance(node, CompNode):
            prop_parts = []
            for k, v in node.props.items():
                if v is True:
                    prop_parts.append(k)
                elif v:
                    prop_parts.append(f"{k}={v}")
            props_str = ", ".join(prop_parts)
            header = f"{pad}@{node.name}" + (f" {props_str}" if props_str else "")
            parts.append(header)
            if node.children:
                parts.append(_serialize_nodes(node.children, indent + 1, vars))
    return "\n".join(p for p in parts if p is not None)


def _split_list_items(children: list) -> list[list]:
    """Split children by '---' separator. Returns list of groups.

    The parser joins consecutive text lines into a single Content.text,
    so '---' will appear inside the text as 'line1\\n---\\nline2'.
    """
    groups: list[list] = [[]]
    for child in children:
        if isinstance(child, Content):
            parts = _LIST_SEPARATOR_RE.split(child.text)
            if len(parts) == 1:
                # No separator — add to current group
                if child.text.strip():
                    groups[-1].append(Content(text=child.text.strip(), line=child.line))
            else:
                for i, part in enumerate(parts):
                    if i > 0:
                        groups.append([])
                    part = part.strip()
                    if part:
                        groups[-1].append(Content(text=part, line=child.line))
        else:
            # CompNode — add to current group
            groups[-1].append(child)
    # Remove empty groups
    return [g for g in groups if g]


def _find_list_slot_in_children(children: list, rendered_slots: dict) -> tuple[str, list[str]] | None:
    """Find a slot placeholder in DIRECT children whose rendered value is a list (from list=True).
    Only checks immediate children — the recursion in _clone_and_substitute handles deeper levels.
    Returns (slot_name, list_of_html) or None."""
    for child in children:
        if isinstance(child, Content) and _SLOT_RE.search(child.text):
            for m in _SLOT_RE.finditer(child.text):
                name = m.group(2)
                value = rendered_slots.get(name)
                if isinstance(value, list):
                    return (name, value)
    return None


def render_component(component: CompNode, render_children: Callable, render_children_raw: Callable | None = None) -> str:
    """Render a component. Uses template if available, otherwise simple tag rendering."""
    if component.name in _MARKDOWN_TAGS:
        from ..markdown import render_markdown

        parts = []
        for child in component.children:
            if isinstance(child, Content):
                parts.append(render_markdown(child.text))
            else:
                parts.append(render_children([child]))
        return "".join(parts)

    # Prop "as=tag": escape valve to bypass component registry and render as plain HTML
    # @nav as=nav    → renders <nav> (bypass registry, use value as tag)
    # @div as=section → renders <section>
    as_tag = component.props.get("as")
    if as_tag:
        tag = as_tag
        if tag in _PREFORMATTED_TAGS and render_children_raw is not None:
            children_html = render_children_raw(component.children)
        else:
            children_html = render_children(component.children)
        cls = component.props.get("class", "")
        extra_attrs = build_extra_attrs(component.props)
        if cls:
            html = f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'
        else:
            html = f'<{tag}{extra_attrs}>{children_html}</{tag}>'
        return _wrap_in_link_if_needed(html, component.props, tag)

    if has_template(component.name):
        return _render_with_template(component, render_children, render_children_raw)

    config = get_config(component.name)

    effective_tag = config.get("tag", component.name) if config else component.name
    if effective_tag in _PREFORMATTED_TAGS and render_children_raw is not None:
        children_html = render_children_raw(component.children)
    else:
        children_html = render_children(component.children)

    if config:
        cls = build_classes(component.name, component.props)
        tag = effective_tag
        extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))
        config_attrs = build_config_attrs(config)

        if tag in _SELF_CLOSING_TAGS:
            html = f'<{tag} class="{cls}"{config_attrs}{extra_attrs} />'
            return _wrap_in_link_if_needed(html, component.props, tag)

        html = f'<{tag} class="{cls}"{config_attrs}{extra_attrs}>{children_html}</{tag}>'
        return _wrap_in_link_if_needed(html, component.props, tag)

    # Not registered — check tag category
    tag = component.name

    if tag in _HEAD_TAGS:
        return _err(_ERR_HEAD_TAG, tag=tag)

    if tag not in _BODY_TAGS:
        return _err(_ERR_UNKNOWN_TAG, tag=tag)

    # Valid body tag — render as generic HTML
    cls = component.props.get("class", "")
    extra_attrs = build_extra_attrs(component.props)
    if cls:
        html = f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'
    else:
        html = f'<{tag}{extra_attrs}>{children_html}</{tag}>'
    return _wrap_in_link_if_needed(html, component.props, tag)


def _render_with_template(component: CompNode, render_children: Callable, render_children_raw: Callable | None = None) -> str:
    """Render a component using its template. Template is the contract."""

    # Recursion guard
    if component.name in _rendering_stack:
        return _ERR_RECURSION.format(comp=component.name)

    # Determine which template variant to use
    explicit_template = component.props.get("template")
    variant = component.props.get("variant", "default")

    if explicit_template:
        template = _resolve_alt_template(explicit_template, component.name)
        if template is None:
            return _err(_ERR_NO_SLOT,
                content=f"template '{explicit_template}' não encontrado",
                comp=component.name,
            )
    else:
        template = get_template(component.name, variant) or get_template(component.name, "default")

    if not template:
        # Shouldn't happen since has_template passed, but safety fallback
        config = get_config(component.name)
        if config:
            cls = build_classes(component.name, component.props)
            tag = config.get("tag", component.name)
            extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))
            children_html = render_children(component.children)
            return f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'
        return render_children(component.children)

    # Extract slots from template: list of (name, is_optional)
    slot_defs = _extract_slots(template)
    slot_names = {name for name, _ in slot_defs}

    # Map children to slots (by component name matching slot name)
    # {?children} is a special catch-all: unmatched content goes there if declared
    has_children_slot = "children" in slot_names
    slots: dict[str, list] = {}
    slot_props: dict[str, dict] = {}
    unmatched: list = []  # children not matching any named slot

    list_slots: set[str] = set()  # slots marked with list=True

    for child in component.children:
        if isinstance(child, CompNode) and child.name in slot_names and child.name != "children":
            if child.props.get("list"):
                list_slots.add(child.name)
                slots[child.name] = _split_list_items(child.children) if child.children else []
            else:
                slots[child.name] = child.children if child.children else []
            slot_props[child.name] = child.props
        else:
            unmatched.append(child)

    tpl_file = _template_file.get(component.name, "")

    # Find slots that live inside @pre/@code in the template — these must be serialized, not rendered
    pre_slots = _find_preformatted_slots(template.children)

    # Render slots to HTML
    rendered_slots: dict[str, str | list[str]] = {}
    for name, optional in slot_defs:
        if name == "children":
            rendered_slots["children"] = render_children(unmatched)
            unmatched = []  # consumed
        elif name in slots:
            if name in list_slots:
                # list=True: render each group separately → list[str]
                rendered_slots[name] = [render_children(group) for group in slots[name]]
            elif name in pre_slots and render_children_raw is not None:
                # Slot inside @pre/@code: serialize back to .seed text via render_children_raw
                rendered_slots[name] = render_children_raw(slots[name])
            else:
                slot_html = render_children(slots[name])
                s_props = slot_props.get(name, {})
                if s_props.get("href") and not slot_html.lstrip().startswith("<a"):
                    slot_html = _wrap_in_link_if_needed(slot_html, s_props, "")
                rendered_slots[name] = slot_html
            # Expose slot props as {slot-propname}
            s_props = slot_props.get(name, {})
            for pk, pv in s_props.items():
                rendered_slots[f"{name}-{pk}"] = pv if isinstance(pv, str) else ""
        else:
            if optional:
                rendered_slots[name] = ""
            else:
                rendered_slots[name] = _err(_ERR_SLOT_MISSING,
                    slot=name, comp=component.name, template_file=tpl_file)

    # Expose component-level props as slots (e.g. {?href}, {?class})
    for pk, pv in component.props.items():
        if pk not in rendered_slots and isinstance(pv, str):
            rendered_slots[pk] = pv

    # Clone the template AST and substitute slots with RawContent
    cloned_children = _clone_and_substitute(template.children, rendered_slots)

    # Render cloned AST through the normal pipeline
    _rendering_stack.add(component.name)
    try:
        inner_html = render_children(cloned_children)
    finally:
        _rendering_stack.discard(component.name)

    # Unmatched children: render error blocks inline
    if unmatched:
        error_parts = []
        for child in unmatched:
            if isinstance(child, Content) and child.text.strip():
                error_parts.append(_err(_ERR_NO_SLOT,
                    content=child.text.strip()[:40],
                    comp=component.name,
                    template_file=tpl_file,
                ))
            elif isinstance(child, CompNode):
                error_parts.append(_err(_ERR_NO_SLOT,
                    content=f"@{child.name}",
                    comp=component.name,
                    template_file=tpl_file,
                ))
        if error_parts:
            inner_html = "".join(error_parts) + inner_html

    # Wrap in container from YAML config
    config = get_config(component.name)
    if config:
        cls = build_classes(component.name, component.props)
        tag = config.get("tag", component.name)
        extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))
        config_attrs = build_config_attrs(config)
        has_real_class = cls and cls != component.name
        class_attr = f' class="{cls}"' if has_real_class else ""
        html = f'<{tag}{class_attr}{config_attrs}{extra_attrs}>{inner_html}</{tag}>'
        return html

    cls = component.name
    extra_attrs = build_extra_attrs(component.props)
    return f'<div class="{cls}"{extra_attrs}>{inner_html}</div>'


def _clone_and_substitute(children: list, rendered_slots: dict) -> list:
    """Clone the template AST, substituting slot placeholders with RawContent
    and resolving slot placeholders in props. Omits containers whose optional
    slots are all empty."""
    result = []

    for child in children:
        if isinstance(child, Content):
            text = child.text
            # Check if text contains slot placeholders
            if _SLOT_RE.search(text):
                resolved = _SLOT_RE.sub(
                    lambda m: _resolve_slot_value(rendered_slots, m),
                    text
                )
                if resolved.strip():
                    result.append(RawContent(html=resolved.strip()))
            else:
                # Plain text in template — keep as Content
                if text.strip():
                    result.append(Content(text=text.strip(), line=child.line))

        elif isinstance(child, CompNode):
            # Check if any child contains a list slot — if so, duplicate this node per item
            list_slot = _find_list_slot_in_children(child.children, rendered_slots)
            if list_slot:
                slot_name, items = list_slot
                for item_html in items:
                    item_rendered = {**rendered_slots, slot_name: item_html}
                    cloned = _clone_single_comp(child, item_rendered)
                    if cloned:
                        result.append(cloned)
                continue

            # Check if this element should be omitted (all slots optional and empty)
            if _has_any_slot(child.children) and _all_slots_optional_and_empty(child.children, rendered_slots):
                props_have_slots = any(
                    isinstance(v, str) and _SLOT_RE.search(v)
                    for v in child.props.values()
                )
                if not props_have_slots:
                    continue

            # Resolve slot placeholders in props
            has_empty_required_prop = False
            resolved_props = {}
            for k, v in child.props.items():
                if isinstance(v, str) and _SLOT_RE.search(v):
                    resolved = _SLOT_RE.sub(lambda m: _resolve_slot_value(rendered_slots, m), v)
                    if not resolved:
                        for m in _SLOT_RE.finditer(v):
                            optional = bool(m.group(1))
                            name = m.group(2)
                            if not optional and not rendered_slots.get(name):
                                has_empty_required_prop = True
                                break
                    resolved_props[k] = resolved
                else:
                    resolved_props[k] = v

            # Omit element if a required prop slot resolved to empty
            if has_empty_required_prop:
                continue

            # Merge slot-class into element's class
            for child_node in child.children:
                if isinstance(child_node, Content):
                    for m in _SLOT_RE.finditer(child_node.text):
                        slot_name = m.group(2)
                        slot_extra_class = rendered_slots.get(f"{slot_name}-class", "")
                        if slot_extra_class:
                            existing = resolved_props.get("class", "")
                            resolved_props["class"] = (existing + " " + slot_extra_class).strip()

            # Recursively clone children
            cloned_children = _clone_and_substitute(child.children, rendered_slots)

            # Create new CompNode with resolved props and substituted children
            new_node = CompNode(
                name=child.name,
                props=resolved_props,
                children=cloned_children,
                line=child.line,
            )
            result.append(new_node)

    return result


def _resolve_slot_value(rendered_slots: dict, m: re.Match) -> str:
    """Get slot value as string, handling list slots by joining."""
    val = rendered_slots.get(m.group(2), "")
    if isinstance(val, list):
        return "".join(val)
    return val


def _clone_single_comp(child: CompNode, rendered_slots: dict) -> CompNode | None:
    """Clone a single CompNode resolving props and children against rendered_slots.
    Returns None if a required prop slot resolved to empty."""
    has_empty_required_prop = False
    resolved_props = {}
    for k, v in child.props.items():
        if isinstance(v, str) and _SLOT_RE.search(v):
            resolved = _SLOT_RE.sub(lambda m: _resolve_slot_value(rendered_slots, m), v)
            if not resolved:
                for m in _SLOT_RE.finditer(v):
                    optional = bool(m.group(1))
                    name = m.group(2)
                    if not optional and not rendered_slots.get(name):
                        has_empty_required_prop = True
                        break
            resolved_props[k] = resolved
        else:
            resolved_props[k] = v

    if has_empty_required_prop:
        return None

    # Merge slot-class into element's class
    for child_node in child.children:
        if isinstance(child_node, Content):
            for m in _SLOT_RE.finditer(child_node.text):
                slot_name = m.group(2)
                slot_extra_class = rendered_slots.get(f"{slot_name}-class", "")
                if slot_extra_class:
                    existing = resolved_props.get("class", "")
                    resolved_props["class"] = (existing + " " + slot_extra_class).strip()

    cloned_children = _clone_and_substitute(child.children, rendered_slots)
    return CompNode(
        name=child.name,
        props=resolved_props,
        children=cloned_children,
        line=child.line,
    )


def _resolve_alt_template(template_path: str, component_name: str):
    """Resolve a template= path to an AST. Looks in __alt__ cache."""
    # Normalize the path to key format
    key = f"__alt__{template_path.replace('/', '_').replace('.', '_')}"
    entry = _template_cache.get(key, {}).get("default")
    if entry:
        return entry["ast"] if isinstance(entry, dict) else entry

    # Also try looking by the last segment
    stem = Path(template_path).stem
    key2 = f"__alt__{stem}"
    entry2 = _template_cache.get(key2, {}).get("default")
    if entry2:
        return entry2["ast"] if isinstance(entry2, dict) else entry2

    return None


def _all_slots_optional_and_empty(children: list, rendered_slots: dict) -> bool:
    """Return True if all slots in children are optional and all resolved to empty."""
    for child in children:
        if isinstance(child, Content):
            for m in _SLOT_RE.finditer(child.text):
                optional = bool(m.group(1))
                name = m.group(2)
                value = rendered_slots.get(name, "")
                if not optional:
                    return False
                if value:
                    return False
        elif isinstance(child, CompNode):
            # Check props for slot placeholders
            for v in child.props.values():
                if isinstance(v, str):
                    for m in _SLOT_RE.finditer(v):
                        optional = bool(m.group(1))
                        name = m.group(2)
                        value = rendered_slots.get(name, "")
                        if not optional:
                            return False
                        if value:
                            return False
            if not _all_slots_optional_and_empty(child.children, rendered_slots):
                return False
    return True


def _has_any_slot(children: list) -> bool:
    """Return True if children contain any slot placeholder."""
    for child in children:
        if isinstance(child, Content) and _SLOT_RE.search(child.text):
            return True
        if isinstance(child, CompNode):
            if any(isinstance(v, str) and _SLOT_RE.search(v) for v in child.props.values()):
                return True
            if _has_any_slot(child.children):
                return True
    return False
