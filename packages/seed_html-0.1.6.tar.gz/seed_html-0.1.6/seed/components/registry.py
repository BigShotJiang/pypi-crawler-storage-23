from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from ..nodes import Content, Component as CompNode
from ..parser import parse
from ..constants.components import _RESERVED_KEYS, _SLOT_RE
from ..constants.html_tags import _SELF_CLOSING_TAGS

# ---------------------------------------------------------------------------
# Global state
# ---------------------------------------------------------------------------

# Registry: {component_name: {tag, class, variants, ...}}
_registry: dict[str, dict[str, Any]] = {}
# Source file for each registered component: {name: filepath_str}
_registry_source: dict[str, str] = {}
# Layer for each registered component: {name: "lib" | "project"}
_registry_layer: dict[str, str] = {}

# Template cache: {component_name: {variant_name: {"ast": Page, "source": str}}}
_template_cache: dict[str, dict[str, Any]] = {}
# Template source file: {component_name: filepath_str}
_template_file: dict[str, str] = {}

# Script cache: {component_name: js_source_str}
_script_cache: dict[str, str] = {}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(name: str, config: dict[str, Any], source_file: str = "", layer: str = "lib"):
    """Register a component.
    - Same layer duplicate → ERRO
    - Cross layer (project over lib) → sobrescreve silenciosamente
    """
    if name in _registry:
        existing_layer = _registry_layer.get(name, "lib")
        if existing_layer == layer:
            existing_src = _registry_source.get(name, "?")
            raise ValueError(
                f"Componente duplicado: '{name}' já registrado em '{existing_src}'"
                + (f", conflito com '{source_file}'" if source_file else "")
            )
        # Cross-layer: project overrides lib — just replace
    _registry[name] = config
    if source_file:
        _registry_source[name] = source_file
    _registry_layer[name] = layer


def get_config(name: str) -> dict[str, Any] | None:
    return _registry.get(name)


def is_registered(name: str) -> bool:
    return name in _registry


# ---------------------------------------------------------------------------
# YAML / Template loading
# ---------------------------------------------------------------------------

def _normalize_config(config: dict) -> dict:
    result = {}
    for k, v in config.items():
        if isinstance(v, dict):
            result[k] = {str(gk): gv for gk, gv in v.items()}
        else:
            result[k] = v
    return result


def _load_yaml_file(path: Path, layer: str = "lib") -> set[str]:
    """Load component configs from a YAML file. layer is 'lib' or 'project'.
    Returns the set of component names defined in this file."""
    with open(path, encoding="utf-8") as f:
        components = yaml.safe_load(f) or {}

    names: set[str] = set()
    for name, config in components.items():
        names.add(name)
        config = _normalize_config(config)
        # inline template in YAML (template: |...) - kept for backward compat
        template_value = config.pop("template", None)
        register(name, config, source_file=str(path), layer=layer)
        if isinstance(template_value, str):
            _load_template_source(name, "default", template_value)
        elif isinstance(template_value, dict):
            for variant_name, variant_source in template_value.items():
                if isinstance(variant_source, str):
                    _load_template_source(name, str(variant_name), variant_source)
    return names


def _load_template_source(component_name: str, variant_name: str, source: str):
    page = parse(source)
    if component_name not in _template_cache:
        _template_cache[component_name] = {}
    _template_cache[component_name][variant_name] = {"ast": page, "source": source}


def _load_template_file(component_name: str, variant_name: str, path: Path):
    source = path.read_text(encoding="utf-8")
    _load_template_source(component_name, variant_name, source)
    _template_file[component_name] = str(path)


def _load_yaml_directory(directory: Path, layer: str = "lib"):
    """Load .yaml files from directory root, then recurse into subdirectories.
    Auto-discover .template files alongside their .yaml files.
    """
    # 1. Load root-level yaml files and collect component names in one pass
    local_components: set[str] = set()
    for yaml_file in sorted(directory.glob("*.yaml")):
        local_components.update(_load_yaml_file(yaml_file, layer=layer))

    # 2. Auto-discover root-level .template and .js files
    for template_file in sorted(directory.glob("*.template")):
        _register_template_file(template_file, local_components)
    for js_file in sorted(directory.glob("*.js")):
        if js_file.stem in local_components:
            _script_cache[js_file.stem] = js_file.read_text(encoding="utf-8")

    # 3. Recurse into subdirectories
    for subdir in sorted(d for d in directory.iterdir() if d.is_dir() and not d.name.startswith(("__", ".", "apagar"))):
        _load_yaml_directory(subdir, layer=layer)


def _register_template_file(template_file: Path, local_components: set[str] | None = None):
    """Register a .template file, checking for self-closing tag conflicts.
    Only associates with a registered component if it was defined in the same directory.
    """
    component_name = template_file.stem
    is_local = local_components is not None and component_name in local_components
    if is_local and component_name in _registry:
        config = _registry.get(component_name, {})
        tag = config.get("tag", component_name)
        if tag in _SELF_CLOSING_TAGS:
            raise ValueError(
                f"Componente '{component_name}': tag self-closing '{tag}' "
                f"não pode ter template ({template_file})"
            )
        _load_template_file(component_name, "default", template_file)
    else:
        # Alternate template (e.g. compact.template used via template=compact)
        _load_template_file(f"__alt__{component_name}", "default", template_file)


def load_project_components(project_dir: Path, layer: str = "lib"):
    """Load all component YAML files recursively from a directory."""
    if not project_dir.exists():
        return
    _load_yaml_directory(project_dir, layer=layer)


def reload_components_yaml(
    components_dir: Path | None = None,
    theme_dir: Path | None = None,
):
    """Reload all components in priority order: lib → project."""
    _registry.clear()
    _registry_source.clear()
    _registry_layer.clear()
    _template_cache.clear()
    _template_file.clear()
    _script_cache.clear()

    if theme_dir:
        lib_components = theme_dir / "components"
        if lib_components.is_dir():
            load_project_components(lib_components, layer="lib")

    if components_dir and components_dir.exists():
        load_project_components(components_dir, layer="project")


# ---------------------------------------------------------------------------
# Template / Script access
# ---------------------------------------------------------------------------

def get_component_scripts(component_names: set[str]) -> list[str]:
    """Return JS source strings for each component that has a .js file."""
    return [_script_cache[name] for name in component_names if name in _script_cache]


def has_template(name: str) -> bool:
    return name in _template_cache


def get_template(name: str, variant: str = "default"):
    """Get template AST. Falls back to 'default' if variant not found."""
    designs = _template_cache.get(name)
    if not designs:
        return None
    entry = designs.get(variant) or designs.get("default")
    if entry is None:
        return None
    return entry["ast"] if isinstance(entry, dict) else entry


def get_template_source(name: str, variant: str = "default") -> str:
    designs = _template_cache.get(name)
    if not designs:
        return ""
    entry = designs.get(variant) or designs.get("default")
    if not entry:
        return ""
    return entry["source"] if isinstance(entry, dict) else ""


def get_template_slot_names(name: str, variant: str = "default") -> list[tuple[str, bool]]:
    """Return list of (slot_name, is_optional) from a template."""
    template = get_template(name, variant)
    if not template:
        return []
    return _extract_slots(template)


# ---------------------------------------------------------------------------
# Slot extraction
# ---------------------------------------------------------------------------

def _extract_slots(page) -> list[tuple[str, bool]]:
    """Return list of (name, is_optional) from a template AST."""
    slots: list[tuple[str, bool]] = []
    seen: set[str] = set()

    def walk(children):
        for child in children:
            if isinstance(child, Content):
                for m in _SLOT_RE.finditer(child.text):
                    optional = bool(m.group(1))  # "?" present → optional
                    name = m.group(2)
                    if name not in seen:
                        seen.add(name)
                        slots.append((name, optional))
            elif isinstance(child, CompNode) and child.children:
                walk(child.children)

    walk(page.children)
    return slots


def get_modifier_keys(component_name: str) -> set[str]:
    config = get_config(component_name)
    if not config:
        return set()
    return {k for k, v in config.items() if k not in _RESERVED_KEYS and isinstance(v, dict)}
