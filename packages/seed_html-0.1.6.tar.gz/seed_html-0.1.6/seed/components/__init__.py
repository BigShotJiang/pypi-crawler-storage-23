"""Component system: registry, Tailwind class building, and rendering."""
from .registry import (
    _registry,
    _registry_source,
    _registry_layer,
    _RESERVED_KEYS,
    _template_cache,
    _template_file,
    _script_cache,
    _SLOT_RE,
    register,
    get_config,
    is_registered,
    reload_components_yaml,
    load_project_components,
    get_component_scripts,
    has_template,
    get_template,
    get_template_source,
    get_template_slot_names,
    get_modifier_keys,
    _extract_slots,
    _load_yaml_directory,
)

from .classes import (
    build_classes,
    build_classes_from_strings,
    build_extra_attrs,
    build_config_attrs,
    _wrap_in_link_if_needed,
    _get_class_prefix,
)

from .rendering import render_component, reset_error_state
from ..constants.html_tags import _BODY_TAGS, _HEAD_TAGS, _PREFORMATTED_TAGS, _MARKDOWN_TAGS, _SELF_CLOSING_TAGS

__all__ = [
    "register",
    "get_config",
    "is_registered",
    "reload_components_yaml",
    "load_project_components",
    "get_component_scripts",
    "has_template",
    "get_template",
    "get_template_source",
    "get_template_slot_names",
    "get_modifier_keys",
    "build_classes",
    "build_extra_attrs",
    "build_config_attrs",
    "render_component",
]
