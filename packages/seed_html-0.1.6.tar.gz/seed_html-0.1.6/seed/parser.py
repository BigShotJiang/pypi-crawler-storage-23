from __future__ import annotations

import yaml

from .errors import SeedError
from .lexer import Token, TokenType, tokenize
from .nodes import Component, Content, Include, Page, VarRef


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]

    def advance(self) -> Token:
        tok = self.current()
        self.pos += 1
        return tok

    def expect(self, tt: TokenType) -> Token:
        tok = self.current()
        if tok.type != tt:
            raise SeedError(f"Expected {tt.name}, got {tok.type.name}", line=tok.line)
        return self.advance()

    def parse(self) -> Page:
        meta = {}
        if self.current().type == TokenType.HEADER:
            tok = self.advance()
            meta = yaml.safe_load(tok.value) or {}

        self._vars: dict[str, list] = {}  # name → children nodes
        children = self._parse_children()
        return Page(meta=meta, children=children, vars=self._vars)

    def _parse_children(self) -> list:
        children = []
        content_lines = []

        def flush_content():
            if content_lines:
                children.append(Content(text="\n".join(content_lines)))
                content_lines.clear()

        while self.current().type not in (TokenType.EOF, TokenType.DEDENT):
            tok = self.current()

            if tok.type == TokenType.COMPONENT:
                flush_content()
                node = self._parse_component()
                children.append(node)

            elif tok.type == TokenType.CONTENT:
                tok = self.advance()
                content_lines.append(tok.value)

            elif tok.type == TokenType.INDENT:
                self.advance()
                nested = self._parse_children()
                if children and isinstance(children[-1], Component) and children[-1].name.startswith("@@"):
                    # @@varname with children = definition: register and remove from output
                    var_node = children.pop()
                    self._vars[var_node.name[2:]] = nested
                elif children and isinstance(children[-1], Component):
                    children[-1].children.extend(nested)
                else:
                    for item in nested:
                        if isinstance(item, Content):
                            content_lines.append(item.text)
                        else:
                            flush_content()
                            children.append(item)
                if self.current().type == TokenType.DEDENT:
                    self.advance()

            else:
                break

        flush_content()
        # Convert @@varname Component nodes without children to VarRef
        result = []
        for node in children:
            if isinstance(node, Component) and node.name.startswith("@@"):
                result.append(VarRef(name=node.name[2:], line=node.line))
            else:
                result.append(node)
        return result

    def _parse_component(self) -> Component | Include | VarRef:
        tok = self.advance()
        name = tok.name
        props = tok.props or {}
        line = tok.line

        if name == "include":
            # Support: @include path=file, @include file, @include: file
            path = props.get("path", "")
            if not path:
                # Treat first flag key as the path (e.g. @include _sidebar → {"_sidebar": True})
                for k, v in props.items():
                    if v is True:
                        path = k
                        break
            return Include(path=path, line=line)

        if name.startswith("@@"):
            var_name = name[2:]
            node = VarRef(name=var_name, line=line)
            # Children will be attached by _parse_children via the INDENT logic.
            # We return a sentinel Component that _parse_children will later convert.
            # Simpler: return a Component with name="@@var_name" — _parse_children
            # handles indentation generically, then renderer checks for @@.
            return Component(name=name, props={}, line=line)

        return Component(name=name, props=props, line=line)


def parse(source: str) -> Page:
    tokens = tokenize(source)
    return Parser(tokens).parse()
