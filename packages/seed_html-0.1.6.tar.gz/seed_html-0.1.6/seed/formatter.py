"""Seed formatter — pretty-printer for .seed files.

Usage:
    from seed.formatter import format_source
    formatted = format_source(source_text)
"""
from __future__ import annotations

from .nodes import Component, Content, Include

# Components that use positional args (path/value is the key, True as value)
_PROP_ARG_COMPONENTS = frozenset(["include", "block"])


def format_props(props: dict) -> str:
    """Reconstruct a props string from a parsed dict."""
    parts = []
    for k, v in props.items():
        if v is True:
            parts.append(k)
        elif " " in str(v):
            parts.append(f'{k}="{v}"')
        else:
            parts.append(f"{k}={v}")
    return ", ".join(parts)


def format_component_line(comp: Component) -> str:
    """Format a component node into its @name: props line."""
    if comp.name in _PROP_ARG_COMPONENTS:
        # Positional arg: first key with True value is the path
        path = next((k for k, v in comp.props.items() if v is True), "")
        if path:
            return f"@{comp.name} {path}"
        # Fallback: use format_props if no positional found
        props_str = format_props(comp.props)
        return f"@{comp.name} {props_str}" if props_str else f"@{comp.name}"

    props_str = format_props(comp.props)
    if props_str:
        return f"@{comp.name}: {props_str}"
    return f"@{comp.name}"


def extract_comments(source_lines: list[str], from_line: int, to_line: int) -> list[str]:
    """Extract only comment lines (not blanks) between from_line and to_line (1-indexed).

    from_line: the line of the previous sibling (1-indexed)
    to_line: the line of the next sibling (1-indexed)
    """
    result = []
    for i in range(from_line, to_line - 1):
        if i >= len(source_lines):
            break
        stripped = source_lines[i].strip()
        if stripped.startswith("//") or stripped.startswith("/*"):
            result.append(stripped)
    return result


def format_source(source: str) -> str:
    """Format a .seed source string. Returns the formatted string."""
    from .parser import parse

    source_lines = source.splitlines()
    page = parse(source)
    out: list[str] = []

    # 1. Front matter — preserve YAML as-is (don't re-serialize)
    header_end_line = 0
    if source_lines and source_lines[0].strip() == "---":
        out.append("---")
        i = 1
        while i < len(source_lines) and source_lines[i].strip() != "---":
            out.append(source_lines[i].rstrip())
            i += 1
        out.append("---")
        header_end_line = i + 1  # 1-indexed line after closing "---"

    # 2. Body — format children recursively
    body_lines = _format_children(
        page.children,
        source_lines,
        prev_line=header_end_line,
        indent=0,
        top_level=True,
    )
    out.extend(body_lines)

    result = "\n".join(out)
    if result and not result.endswith("\n"):
        result += "\n"
    return result


def _format_children(
    nodes: list,
    source_lines: list[str],
    prev_line: int,
    indent: int,
    top_level: bool = False,
) -> list[str]:
    """Recursively format a list of AST nodes into lines."""
    out: list[str] = []
    prefix = "  " * indent

    current_prev = prev_line

    for node in nodes:
        node_line = getattr(node, "line", 0) or 0

        if isinstance(node, (Component, Include)):
            if top_level and out:
                # Exactly one blank line between top-level siblings.
                # Extract any comments in the gap and emit them after the blank.
                comments = []
                if node_line and current_prev:
                    comments = extract_comments(source_lines, current_prev, node_line)
                out.append("")
                for c in comments:
                    out.append(c)
            elif not top_level and node_line and current_prev:
                # For nested siblings, preserve comments but no blank lines
                comments = extract_comments(source_lines, current_prev, node_line)
                for c in comments:
                    out.append(prefix + c)

            if isinstance(node, Include):
                out.append(prefix + f"@include {node.path}")
            else:
                out.append(prefix + format_component_line(node))

                if node.children:
                    child_lines = _format_children(
                        node.children,
                        source_lines,
                        prev_line=node_line,
                        indent=indent + 1,
                        top_level=False,
                    )
                    out.extend(child_lines)

            if node_line:
                current_prev = node_line

        elif isinstance(node, Content):
            # Emit each line of text content with proper indentation
            for text_line in node.text.splitlines():
                stripped_text = text_line.rstrip()
                if stripped_text:
                    out.append(prefix + stripped_text)
                else:
                    out.append("")
            # Content.line == 0, don't update current_prev

    return out
