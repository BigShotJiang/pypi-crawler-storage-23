from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .errors import SeedError
from .nodes import Component, Content, Include
from .parser import parse
from .components import (
    get_config,
    get_modifier_keys,
    get_template_slot_names,
    has_template,
    is_registered,
)
from .constants.html_tags import _BODY_TAGS, _HEAD_TAGS, _MARKDOWN_TAGS
from .constants.components import _RESERVED_KEYS


@dataclass
class Diagnostic:
    file: str
    line: int
    message: str

    def __str__(self) -> str:
        return f"{self.file}:{self.line}: {self.message}"


def lint_file(path: Path) -> list[Diagnostic]:
    """Linta um arquivo .seed. Retorna lista de Diagnostic."""
    source = path.read_text(encoding="utf-8")
    diags: list[Diagnostic] = []

    # Camada 1: sintaxe (lexer/parser)
    try:
        page = parse(source)
    except SeedError as e:
        msg = e.args[0].split("] ", 1)[-1]
        diags.append(Diagnostic(str(path), e.line, msg))
        return diags

    # Camada 2: semântica (walk do AST)
    _walk(page.children, path, diags)
    return diags


def _slot_names(component_name: str) -> set[str] | None:
    """Return the set of slot names for a templated component, or None if it has no template."""
    if not has_template(component_name):
        return None
    return {name for name, _ in get_template_slot_names(component_name)}


def _walk(nodes: list, path: Path, diags: list[Diagnostic], parent_slot_names: set[str] | None = None) -> None:
    for node in nodes:
        if isinstance(node, Component):
            is_slot = parent_slot_names is not None and node.name in parent_slot_names
            if is_slot:
                # Este nó é um slot nomeado — não validar como componente.
                # Se ele mesmo tem template, seus filhos também são slots nomeados.
                child_slots = _slot_names(node.name)
                _walk(node.children, path, diags, parent_slot_names=child_slots)
            else:
                _check_component(node, path, diags)
                # Filhos diretos de componente com template são possíveis slots nomeados
                child_slots = _slot_names(node.name)
                _walk(node.children, path, diags, parent_slot_names=child_slots)


def _check_component(comp: Component, path: Path, diags: list[Diagnostic]) -> None:
    name = comp.name
    line = comp.line

    # Tags especiais — sem validação adicional
    if name in _MARKDOWN_TAGS or name in {"include", "block"}:
        return

    # 1. Componente não registrado / tag inválida
    if not is_registered(name):
        if name in _HEAD_TAGS:
            diags.append(Diagnostic(str(path), line,
                f"tag reservada para <head>: @{name}"))
        elif name not in _BODY_TAGS:
            diags.append(Diagnostic(str(path), line,
                f"componente não registrado: @{name}"))
        return  # tag HTML válida — sem mais validações semânticas

    # 2. Modifier/variante inválido
    config = get_config(name)
    modifier_keys = get_modifier_keys(name)
    for prop_key, prop_val in comp.props.items():
        if prop_key in _RESERVED_KEYS:
            continue
        if prop_key in modifier_keys and prop_val is not True:
            valid = set(config[prop_key].keys())
            if prop_val not in valid:
                diags.append(Diagnostic(str(path), line,
                    f"@{name}: valor inválido '{prop_val}' para '{prop_key}' "
                    f"(válidos: {', '.join(sorted(valid))})"))

    # 3. Slot required não preenchido
    if has_template(name):
        slots = get_template_slot_names(name)
        child_names = {c.name for c in comp.children if isinstance(c, Component)}
        for slot_name, optional in slots:
            if not optional and slot_name not in child_names:
                diags.append(Diagnostic(str(path), line,
                    f"@{name}: slot obrigatório '{{{slot_name}}}' não preenchido"))
