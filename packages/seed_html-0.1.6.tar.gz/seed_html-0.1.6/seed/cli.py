#!/usr/bin/env python3
"""Seed CLI — init / dev / build / theme-install / theme-update"""

import html as html_mod
import mimetypes
import os
import select
import shutil
import sys
import threading
import time
import urllib.parse
import webbrowser
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path


# ─── Helpers ────────────────────────────────────────────────────────────────

SEED_ENGINE_DIR = Path(__file__).parent

RELOAD_SNIPPET = (
    b'<script>(function(){'
    b'var KEY="__seedReloadSSE";'
    b'var state=window[KEY]||{es:null,retry:null};'
    b'window[KEY]=state;'
    b'function cleanup(){'
    b'if(state.retry){clearTimeout(state.retry);state.retry=null;}'
    b'if(state.es){try{state.es.close();}catch(_){}state.es=null;}'
    b'}'
    b'function connect(){'
    b'if(state.es&&state.es.readyState!==EventSource.CLOSED)return;'
    b'var es=new EventSource("/__reload");'
    b'state.es=es;'
    b'es.addEventListener("reload",function(){location.reload();});'
    b'es.addEventListener("css",function(e){'
    b'document.querySelectorAll("link[rel=stylesheet]").forEach(function(l){'
    b'var u=new URL(l.href);'
    b'if(u.pathname===e.data){l.href=e.data+"?v="+Date.now();}'
    b'});});'
    b'es.addEventListener("help",function(){window.dispatchEvent(new CustomEvent("seed:help"));});'
    b'es.onerror=function(){'
    b'try{es.close();}catch(_){}'
    b'if(state.es===es)state.es=null;'
    b'if(state.retry)clearTimeout(state.retry);'
    b'state.retry=setTimeout(function(){state.retry=null;connect();},1000);'
    b'};'
    b'}'
    b'window.addEventListener("pagehide",cleanup);'
    b'window.addEventListener("beforeunload",cleanup);'
    b'connect();'
    b'})()</script>'
)
HELP_SNIPPET = (
    b'<script src="/__help/explorer.template.js"></script>'
    b'<script src="/__help/explorer.js"></script>'
    b'<a href="/__explorer" target="_blank" title="Open component explorer" '
    b'style="position:fixed;bottom:16px;right:16px;z-index:99998;'
    b'background:#1e1b4b;color:#a5b4fc;border:1px solid #4f46e5;'
    b'border-radius:9999px;padding:6px 12px;font-size:0.75rem;font-family:monospace;'
    b'text-decoration:none;opacity:0.7;transition:opacity 0.2s" '
    b'onmouseover="this.style.opacity=\'1\'" onmouseout="this.style.opacity=\'0.7\'">'
    b'@? components</a>'
)

reload_version = 0
reload_lock = threading.Condition()
reload_message = b""   # raw SSE message to send (set before notify)
python_restart_event = threading.Event()
_raw_mode = False  # True while terminal is in raw mode


def _load_seed_class():
    """Load Seed class in both package and direct-script execution modes."""
    try:
        from . import Seed
        return Seed
    except ImportError:
        pass

    try:
        from seed import Seed
        return Seed
    except ModuleNotFoundError:
        repo_root = Path(__file__).resolve().parent.parent
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))
        from seed import Seed
        return Seed


def dev_print(msg=""):
    """Print respeitando modo raw do terminal (emite \\r\\n em vez de só \\n)."""
    if _raw_mode:
        sys.stdout.write(msg + "\r\n")
        sys.stdout.flush()
    else:
        print(msg)


def notify_reload():
    global reload_version, reload_message
    with reload_lock:
        reload_message = b"event: reload\ndata: reload\n\n"
        reload_version += 1
        reload_lock.notify_all()


def notify_css(path: str):
    global reload_version, reload_message
    with reload_lock:
        reload_message = f"event: css\ndata: {path}\n\n".encode()
        reload_version += 1
        reload_lock.notify_all()


def notify_help():
    global reload_version, reload_message
    with reload_lock:
        reload_message = b"event: help\ndata: open\n\n"
        reload_version += 1
        reload_lock.notify_all()


def find_seed_files(src_dir: Path):
    return sorted(src_dir.rglob("*.seed"))


def build_file(seed_instance, seed_file: Path, src_dir: Path, dist_dir: Path):
    """Build a single .seed file. src/blog/post.seed → dist/blog/post.html"""
    rel = seed_file.relative_to(src_dir)
    out = dist_dir / rel.with_suffix(".html")
    out.parent.mkdir(parents=True, exist_ok=True)
    html = seed_instance.render_file(seed_file, full_page=True)
    out.write_text(html, encoding="utf-8")
    return rel


def build_all(seed_instance, src_dir: Path, dist_dir: Path):
    for f in find_seed_files(src_dir):
        try:
            rel = build_file(seed_instance, f, src_dir, dist_dir)
            dev_print(f"  built {rel}")
        except Exception as e:
            print(f"  error: {e}")



def copy_static_layered(
    dist_dir: Path,
    project_static: Path,
    lib_static: Path | None = None,
):
    """Copy static files in layers: lib first, then project (project wins).

    This function only populates dist/static/.
    Missing directories are skipped silently.
    """
    dest = dist_dir / "static"
    if lib_static and lib_static.is_dir():
        shutil.copytree(lib_static, dest, dirs_exist_ok=True)
    if project_static.is_dir() and any(project_static.iterdir()):
        shutil.copytree(project_static, dest, dirs_exist_ok=True)


# ─── Favicon ─────────────────────────────────────────────────────────────────

def _ensure_favicon(dist_dir: Path):
    """Copy default favicon to dist/static/ if none exists, and inject a relative
    <link rel="icon"> into every HTML page that doesn't already have one.
    """
    favicon_dest = dist_dir / "static" / "favicon.ico"

    # Copy default favicon if project didn't provide one
    if not favicon_dest.exists():
        default_favicon = SEED_ENGINE_DIR / "page" / "favicon.ico"
        if default_favicon.exists():
            favicon_dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(default_favicon, favicon_dest)

    if not favicon_dest.exists():
        return

    # Inject <link rel="icon"> into pages that don't already have one
    for html_file in dist_dir.rglob("*.html"):
        html = html_file.read_text(encoding="utf-8")
        if 'rel="icon"' in html or "rel=icon" in html:
            continue
        rel_path = favicon_dest.relative_to(html_file.parent, walk_up=True).as_posix()
        favicon_tag = f'<link rel="icon" href="{rel_path}">'
        # Insert after <title>...</title>
        import re as _re
        html = _re.sub(r'(<title>[^<]*</title>)', rf'\1{favicon_tag}', html, count=1)
        html_file.write_text(html, encoding="utf-8")


# ─── Tailwind build ──────────────────────────────────────────────────────────

def _run_tailwind_build(dist_dir: Path, css_mode: str):
    """Run npx tailwindcss against dist/ HTML files and replace the CDN script tag.

    Tailwind v4 automatically scans files in the working directory (cwd).
    We run it with cwd=dist_dir and an empty input so it picks up all HTML files.

    - Generates dist/static/tailwind.css from all classes found in dist/**/*.html
    - Removes the Tailwind CDN <script> from every HTML file
    - Injects the generated CSS as <style> (inline) or <link> (file) per css_mode
    """
    import subprocess

    CDN_TAG_QUOTED = '<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>'
    CDN_TAG_UNQUOTED = '<script src=https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4></script>'

    html_files = list(dist_dir.rglob("*.html"))
    if not html_files:
        return

    static_dir = dist_dir / "static"
    static_dir.mkdir(parents=True, exist_ok=True)
    css_out = static_dir / "tailwind.css"

    # Temporary input file inside dist/ — Tailwind v4 resolves @import and scans
    # files relative to the input file location
    input_css = dist_dir / "_tw_input.css"
    input_css.write_text('@import "tailwindcss";\n', encoding="utf-8")

    try:
        result = subprocess.run(
            [
                "npx", "@tailwindcss/cli",
                "-i", str(input_css),
                "-o", str(css_out),
                "--minify",
            ],
            capture_output=True,
            text=True,
            cwd=dist_dir,
        )
    finally:
        input_css.unlink(missing_ok=True)

    if result.returncode != 0:
        print(f"  warning: tailwindcss failed — CSS not optimized\n{result.stderr.strip()}")
        return

    css_content = css_out.read_text(encoding="utf-8")

    replaced = 0
    for html_file in html_files:
        html = html_file.read_text(encoding="utf-8")
        cdn_tag = None
        if CDN_TAG_QUOTED in html:
            cdn_tag = CDN_TAG_QUOTED
        elif CDN_TAG_UNQUOTED in html:
            cdn_tag = CDN_TAG_UNQUOTED
        if not cdn_tag:
            continue
        if css_mode == "inline":
            replacement = f"<style>{css_content}</style>"
        else:
            rel_path = Path(css_out).relative_to(html_file.parent, walk_up=True).as_posix()
            replacement = f'<link rel="stylesheet" href="{rel_path}">'
        html = html.replace(cdn_tag, replacement)
        html_file.write_text(html, encoding="utf-8")
        replaced += 1

    if css_mode != "inline":
        print(f"  tailwind: generated dist/static/tailwind.css ({replaced} file(s) updated)")
    else:
        css_out.unlink(missing_ok=True)
        print(f"  tailwind: CSS inlined into {replaced} file(s)")


# ─── seed.yaml helpers ───────────────────────────────────────────────────────

def _read_seed_yaml(folder: Path) -> dict:
    """Read and parse seed.yaml. Returns empty dict if file doesn't exist."""
    import yaml
    seed_yaml = folder / "seed.yaml"
    if not seed_yaml.is_file():
        return {}
    try:
        config = yaml.safe_load(seed_yaml.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"seed.yaml: erro de sintaxe YAML — {e}") from e
    if not isinstance(config, dict):
        raise ValueError("seed.yaml inválido: esperado mapeamento YAML (chave: valor)")
    return config


def _write_seed_yaml(folder: Path, config: dict):
    """Write seed.yaml preserving key order."""
    import yaml
    seed_yaml = folder / "seed.yaml"
    seed_yaml.write_text(yaml.dump(config, allow_unicode=True, default_flow_style=False), encoding="utf-8")


def _validate_lib_name(name: str, key: str):
    """Validate that a lib name is simple (no path separators) or absolute path.
    Rejects path traversal attempts.
    """
    p = Path(name)
    if p.is_absolute():
        return
    if p.parts != (name,):
        raise ValueError(
            f"seed.yaml: {key} '{name}' inválido — use nome simples (ex: seed-blog-theme) "
            f"ou caminho absoluto. Caminhos relativos com separador não são permitidos."
        )


def _resolve_theme_dir(folder: Path, name: str) -> Path | None:
    """Resolve themes/<name> directory. Returns None if name not set."""
    if not name:
        return None
    _validate_lib_name(name, "theme")
    p = Path(name)
    theme_dir = p if p.is_absolute() else folder / "themes" / name
    if not theme_dir.is_dir():
        raise FileNotFoundError(
            f"'{name}' não encontrado em: {theme_dir}\n"
            f"Use 'seed theme-install' para instalar."
        )
    return theme_dir


def _load_project_config(folder: Path) -> tuple[Path | None, str, str, bool, bool]:
    """Read seed.yaml and resolve theme_lib_dir, inline modes, minify and optimize-css flags.

    Returns:
        (theme_lib_dir, js_mode, css_mode, minify, optimize_css)
    """
    config = _read_seed_yaml(folder)
    theme_lib_dir = _resolve_theme_dir(folder, config.get("theme") or "")
    js_mode = config.get("js", "file")
    css_mode = config.get("css", "file")
    minify = bool(config.get("minify", False))
    optimize_css = bool(config.get("optimize-css", True))
    return theme_lib_dir, js_mode, css_mode, minify, optimize_css


# ─── Install helpers ─────────────────────────────────────────────────────────

def _install_from_source(source: str, dest: Path):
    """Install a lib from a local path or GitHub URL into dest/.

    Supported sources:
    - Local absolute path: /Users/me/libs/seed-blog-theme
    - GitHub URL: https://github.com/user/repo
    """
    src_path = Path(source)

    if src_path.is_absolute() or (not source.startswith("http") and Path(source).exists()):
        # Local path
        src_path = Path(source).resolve()
        if not src_path.is_dir():
            raise FileNotFoundError(f"Caminho não encontrado: {src_path}")
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src_path, dest)
        return src_path.name

    if "github.com" in source:
        return _install_from_github(source, dest)

    raise ValueError(
        f"Fonte inválida: '{source}'\n"
        f"Use um caminho absoluto ou URL do GitHub (https://github.com/user/repo)"
    )


def _install_from_github(url: str, dest: Path):
    """Download and extract a GitHub repository as ZIP into dest/."""
    import urllib.request
    import zipfile
    import tempfile

    # Normalize URL: strip trailing slash and .git
    url = url.rstrip("/").removesuffix(".git")

    # Extract user/repo from URL
    parts = url.replace("https://github.com/", "").replace("http://github.com/", "").split("/")
    if len(parts) < 2:
        raise ValueError(f"URL do GitHub inválida: {url}")
    repo_name = parts[1]

    zip_url = f"{url}/archive/refs/heads/main.zip"
    print(f"  downloading {zip_url}...")

    with tempfile.TemporaryDirectory() as tmp:
        zip_path = Path(tmp) / "repo.zip"
        try:
            urllib.request.urlretrieve(zip_url, zip_path)
        except Exception:
            # Try 'master' branch as fallback
            zip_url = f"{url}/archive/refs/heads/master.zip"
            print(f"  retrying with master branch...")
            urllib.request.urlretrieve(zip_url, zip_path)

        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(tmp)

        # Find extracted directory (typically repo-main/ or repo-master/)
        extracted = [p for p in Path(tmp).iterdir() if p.is_dir()]
        if not extracted:
            raise RuntimeError("ZIP do GitHub não contém diretório raiz esperado")
        extracted_dir = extracted[0]

        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(extracted_dir, dest)

    return repo_name


def _ask_yes_no(question: str, default: bool = False) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    try:
        answer = input(f"{question} {hint} ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    if not answer:
        return default
    return answer in ("y", "yes", "s", "sim")


# ─── Component Explorer ──────────────────────────────────────────────────────

def build_components_json() -> bytes:
    """Return explorer JSON payload."""
    from seed.help.catalog import build_components_json as _build

    return _build()


def _build_explorer_page_html() -> bytes:
    """Return a standalone HTML page for the component explorer (/__explorer)."""
    explorer_js = (SEED_ENGINE_DIR / "help" / "explorer.js").read_text(encoding="utf-8")
    template_js = (SEED_ENGINE_DIR / "help" / "explorer.template.js").read_text(encoding="utf-8")
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Seed — Component Explorer</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500&family=JetBrains+Mono:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>*{{box-sizing:border-box}}html,body{{height:100%;margin:0;padding:0;background:#0f1117}}</style>
</head>
<body>
<script>window.__SEED_EXPLORER_PAGE=true;</script>
<script>{template_js}</script>
<script>{explorer_js}</script>
</body>
</html>"""
    return html.encode("utf-8")


def build_preview_html(seed_code: str, state: dict) -> bytes:
    """Render a seed snippet as a full HTML page for preview."""
    try:
        seed_instance = state["seed"]
        rendered = seed_instance.render_string(seed_code, full_page=True)
    except Exception as exc:
        escaped = html_mod.escape(str(exc))
        rendered = f"""<!DOCTYPE html><html><body style="font-family:monospace;padding:2rem;color:#ef4444">
        <strong>Render error:</strong><pre>{escaped}</pre></body></html>"""
    return rendered.encode("utf-8")


# ─── HTTP Handler ────────────────────────────────────────────────────────────

class SeedDevHandler(SimpleHTTPRequestHandler):
    """HTTP handler that:
    - Serves /static/* in layers: theme assets/ → project assets/ (no copy)
    - Injects live-reload SSE snippet into HTML responses
    - Serves everything else from dist/
    """

    static_dir: Path = None        # project src/assets/ dir
    lib_static_dir: Path = None    # theme assets/ dir (optional, lower priority)
    dev_state: dict = None         # mutable state dict shared with watcher
    protocol_version = "HTTP/1.1"

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, OSError):
            pass

    def do_GET(self):
        path = self.path.split("?")[0]

        # SSE endpoint for live reload
        if path == "/__reload":
            self._serve_reload_sse()
            return

        # Serve help JS files
        if path in ("/__help/explorer.js", "/__help/explorer.template.js"):
            js_path = SEED_ENGINE_DIR / "help" / Path(path).name
            if js_path.is_file():
                data = js_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_error(404, f"{js_path.name} not found")
            return

        # Component explorer — standalone page
        if path == "/__explorer":
            data = _build_explorer_page_html()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # Component explorer — returns JSON
        if path == "/__components":
            data = build_components_json()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # Component preview (renders a seed snippet)
        if path == "/__preview":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            code = qs.get("code", [""])[0]
            data = build_preview_html(code, self.dev_state or {})
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # Serve user assets directly (no copy to dist)
        # Priority: project assets/ > theme assets/
        if path.startswith("/static/"):
            rel = path[len("/static/"):]
            static_file = self.static_dir / rel if self.static_dir else None
            lib_file = self.lib_static_dir / rel if self.lib_static_dir else None
            if static_file and static_file.is_file():
                self._serve_static_file(static_file)
            elif lib_file and lib_file.is_file():
                self._serve_static_file(lib_file)
            else:
                self.send_error(404, f"Static file not found: {rel}")
            return

        # Serve HTML from dist/
        translated = Path(self.translate_path(path))
        if translated.is_dir():
            translated = translated / "index.html"
        if translated.is_file() and translated.suffix == ".html":
            self._serve_html(translated)
        elif path.endswith("favicon.ico") and not translated.is_file():
            default_favicon = SEED_ENGINE_DIR / "page" / "favicon.ico"
            self._serve_static_file(default_favicon)
        else:
            super().do_GET()

    def _is_disconnected(self) -> bool:
        """Check if the client disconnected using select(). Non-blocking."""
        try:
            r, _, _ = select.select([self.request], [], [], 0)
            if r:
                # Data readable on a connection we're not reading from = closed
                return True
        except Exception:
            return True
        return False

    def _serve_reload_sse(self):
        """Serve SSE for live reload. Uses select() to detect disconnection fast."""
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            last = reload_version
            last_ping = time.monotonic()
            while not self._is_disconnected():
                with reload_lock:
                    reload_lock.wait(timeout=1)
                    current_version = reload_version
                    current_message = reload_message
                if current_version != last:
                    last = current_version
                    self.wfile.write(current_message)
                    self.wfile.flush()
                    last_ping = time.monotonic()
                elif time.monotonic() - last_ping >= 5:
                    # Keep a heartbeat so stale connections are detected/closed quickly.
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    last_ping = time.monotonic()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            return

    def _serve_html(self, filepath: Path):
        data = filepath.read_bytes()
        inject = RELOAD_SNIPPET + b"\n" + HELP_SNIPPET + b"\n"
        # minify-html removes optional closing tags — try </body> then </html>
        if b"</body>" in data:
            data = data.replace(b"</body>", inject + b"</body>")
        elif b"</html>" in data:
            data = data.replace(b"</html>", inject + b"</html>")
        else:
            data = data + inject
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_static_file(self, filepath: Path):
        mime_type, _ = mimetypes.guess_type(str(filepath))
        mime_type = mime_type or "application/octet-stream"
        data = filepath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_request(self, code="-", size="-"):
        if self.path.split("?")[0] == "/__reload":
            return
        now = time.strftime("%H:%M:%S")
        dev_print(f"  {now}  {code}  {self.path}")

    def log_error(self, format, *args):
        pass

    def log_message(self, format, *args):
        pass


# ─── File Watcher ────────────────────────────────────────────────────────────

_last_rebuild_time: dict = {}
_REBUILD_COOLDOWN = 1.0


def _debounce(key: str) -> bool:
    """Returns True if we should skip (too soon since last rebuild)."""
    now = time.time()
    if now - _last_rebuild_time.get(key, 0) < _REBUILD_COOLDOWN:
        return True
    _last_rebuild_time[key] = now
    return False


def _rebuild_full(state: dict, src_dir: Path, dist_dir: Path):
    """Clear include cache and rebuild all files. Uses current state['seed']."""
    state["seed"].renderer.clear_includes()
    build_all(state["seed"], src_dir, dist_dir)


def _make_seed_instance(folder: Path, theme_lib_dir: Path | None, js_mode: str = "file", css_mode: str = "file", minify: bool = False):
    """Create a fresh Seed instance with the current config."""
    Seed = _load_seed_class()
    src_components = folder / "src" / "components"
    return Seed(
        project_dir=folder,
        components_dir=src_components if src_components.exists() else None,
        theme_dir=theme_lib_dir,
        js_mode=js_mode,
        css_mode=css_mode,
        minify=minify,
    )


def _handle_static_change(src_path: Path, project_dir: Path, state: dict, src_dir: Path, dist_dir: Path):
    """Hot-swap CSS or trigger full reload for other assets.
    When js/css mode is inline, rebuilds HTML before reloading.
    """
    project_assets = project_dir / "src" / "assets"
    rel = src_path.relative_to(project_assets)
    web_path = f"/static/{rel.as_posix()}"
    seed = state.get("seed")
    if src_path.suffix == ".css":
        dev_print(f"  css changed: {rel}")
        if seed and seed.renderer.css_mode == "inline":
            try:
                _rebuild_full(state, src_dir, dist_dir)
                dev_print("  rebuilt all")
            except Exception as e:
                dev_print(f"  error: {e}")
        notify_css(web_path)
    elif src_path.suffix == ".js":
        dev_print(f"  js changed: {rel}")
        if seed and seed.renderer.js_mode == "inline":
            try:
                _rebuild_full(state, src_dir, dist_dir)
                dev_print("  rebuilt all")
            except Exception as e:
                dev_print(f"  error: {e}")
        notify_reload()
    else:
        dev_print(f"  assets changed: {rel}")
        notify_reload()


def make_change_handler(state: dict, src_dir: Path, dist_dir: Path, project_dir: Path, observer_ref: list):
    """Create file change handler. state is a mutable dict with keys:
        'seed'          : current Seed instance
        'theme_lib_dir' : current active theme lib dir (Path | None)
    observer_ref is a list holding the current Observer so it can be replaced on config change.
    """
    from watchdog.events import FileSystemEventHandler

    src_components = project_dir / "src" / "components"

    class ChangeHandler(FileSystemEventHandler):
        def _handle(self, event):
            if event.is_directory:
                return
            src_path = Path(event.src_path)
            if _debounce(str(src_path)):
                return

            # seed.yaml changed → recalculate config, recreate Seed, restart watchers
            if src_path.name == "seed.yaml" and src_path.parent == project_dir:
                dev_print("  seed.yaml changed — reloading config...")
                try:
                    new_theme_lib_dir, new_js_mode, new_css_mode, new_minify, _ = _load_project_config(project_dir)
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=src_components if src_components.exists() else None,
                        theme_dir=new_theme_lib_dir,
                    )
                    old_theme_lib_dir = state["theme_lib_dir"]
                    state["theme_lib_dir"] = new_theme_lib_dir
                    state["seed"] = _make_seed_instance(project_dir, new_theme_lib_dir, new_js_mode, new_css_mode, new_minify)
                    _restart_lib_watches(observer_ref, handler,
                                        old_theme_lib_dir, new_theme_lib_dir)
                    _rebuild_full(state, src_dir, dist_dir)
                    label = f"theme: {new_theme_lib_dir.name}" if new_theme_lib_dir else "no theme"
                    dev_print(f"  rebuilt all ({label})")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error reloading config: {e}")
                return

            if src_path.suffix == ".layout" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                dev_print(f"  layout changed: {rel}")
                try:
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".seed" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                # Includes (_*.seed) may be used by many pages — rebuild all
                if src_path.stem.startswith("_"):
                    dev_print(f"  include changed: {rel}")
                    try:
                        _rebuild_full(state, src_dir, dist_dir)
                        dev_print("  rebuilt all")
                        notify_reload()
                    except Exception as e:
                        dev_print(f"  error: {e}")
                else:
                    dev_print(f"  changed {rel}")
                    try:
                        state["seed"].renderer.clear_includes()
                        build_file(state["seed"], src_path, src_dir, dist_dir)
                        dev_print(f"  rebuilt {rel}")
                        notify_reload()
                    except Exception as e:
                        dev_print(f"  error: {e}")

            elif src_path.suffix in (".yaml", ".template"):
                dev_print(f"  component changed: {src_path.name}")
                try:
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=src_components if src_components.exists() else None,
                        theme_dir=state["theme_lib_dir"],
                    )
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.is_relative_to(project_dir / "src" / "assets"):
                _handle_static_change(src_path, project_dir, state, src_dir, dist_dir)

            elif src_path.suffix == ".py":
                dev_print(f"  Python changed: {src_path.name} — restart required")
                python_restart_event.set()

        def on_modified(self, event):
            self._handle(event)

        def on_created(self, event):
            self._handle(event)

    handler = ChangeHandler()
    return handler


def _restart_lib_watches(
    observer_ref: list,
    handler,
    old_theme_lib_dir: Path | None,
    new_theme_lib_dir: Path | None,
):
    """Update theme watches on the existing observer (add/unschedule as needed)."""
    if old_theme_lib_dir == new_theme_lib_dir:
        return

    observer = observer_ref[0]

    # Unschedule old theme watch if it existed
    if old_theme_lib_dir:
        old_path = str(old_theme_lib_dir)
        for watch in list(getattr(observer, '_watches', set())):
            if watch.path == old_path:
                try:
                    observer.unschedule(watch)
                except Exception:
                    pass

    # Schedule new theme watch if needed
    if new_theme_lib_dir and new_theme_lib_dir.exists():
        observer.schedule(handler, str(new_theme_lib_dir), recursive=True)


def watch(state: dict, src_dir: Path, dist_dir: Path, project_dir: Path):
    from watchdog.observers import Observer

    persistent_watches = []
    if src_dir.exists():
        persistent_watches.append((str(src_dir), True))
    src_components = project_dir / "src" / "components"
    if src_components.exists():
        persistent_watches.append((str(src_components), True))
    if SEED_ENGINE_DIR.exists():
        persistent_watches.append((str(SEED_ENGINE_DIR), True))
    # Watch project root for seed.yaml changes (non-recursive to avoid watching themes/)
    persistent_watches.append((str(project_dir), False))

    observer = Observer()
    observer_ref = [observer, persistent_watches]

    handler = make_change_handler(state, src_dir, dist_dir, project_dir, observer_ref)

    for path, recursive in persistent_watches:
        observer.schedule(handler, path, recursive=recursive)

    # Watch active theme
    if state.get("theme_lib_dir") and state["theme_lib_dir"].exists():
        observer.schedule(handler, str(state["theme_lib_dir"]), recursive=True)

    observer.start()
    try:
        while not python_restart_event.is_set():
            time.sleep(0.5)
    finally:
        observer_ref[0].stop()
        observer_ref[0].join()


# ─── Commands ────────────────────────────────────────────────────────────────

INDEX_SEED_TEMPLATE = """\
---
title: Home
---
@h1
  Hello, World!

Welcome to your new Seed project.
"""

DEFAULT_LAYOUT_TEMPLATE = """\
---
title: My Site
---
@div: class=min-h-screen flex flex-col
  {content}
"""


def _parse_init_args(args):
    """Parse init args: <name> [--components <src>]
    Returns (name, components_source).
    """
    if not args:
        return None, None
    name = args[0]
    components_source = None
    i = 1
    while i < len(args):
        if args[i] in ("--components", "-c") and i + 1 < len(args):
            components_source = args[i + 1]
            i += 2
        else:
            i += 1
    return name, components_source


def cmd_init(args):
    name, components_source = _parse_init_args(args)
    if not name:
        print("Usage: seed init <project-name> [--components <path|github-url>]")
        sys.exit(1)

    project_dir = Path(name)

    if project_dir.exists():
        print(f"Error: '{name}' already exists.")
        sys.exit(1)

    # Project structure
    (project_dir / "src").mkdir(parents=True)
    (project_dir / "src" / "components").mkdir()
    (project_dir / "src" / "assets").mkdir()
    (project_dir / "themes").mkdir(parents=True)

    # Starter files
    (project_dir / "src" / "default.layout").write_text(DEFAULT_LAYOUT_TEMPLATE, encoding="utf-8")
    (project_dir / "src" / "index.seed").write_text(INDEX_SEED_TEMPLATE, encoding="utf-8")

    # seed.yaml: start empty, populate after installs
    seed_config = {}

    print(f"Created project '{name}'")

    # Install theme if requested
    theme_installed = None
    if components_source:
        themes_dir = project_dir / "themes"
        src_path = Path(components_source)
        dest_name = src_path.name if src_path.is_absolute() else components_source.split("/")[-1].removesuffix(".git")
        print(f"Installing theme from '{components_source}'...")
        try:
            theme_installed = _install_from_source(components_source, themes_dir / dest_name)
            seed_config["theme"] = theme_installed
            print(f"  installed → themes/{theme_installed}/")
        except Exception as e:
            print(f"  Error installing theme: {e}")

    # Auto-install seed-ui if --components was not passed
    if not components_source:
        themes_dir = project_dir / "themes"
        seed_ui_url = "https://github.com/ssjunior/seed-ui"
        print(f"Installing seed-ui component library...")
        try:
            name_ui = _install_from_source(seed_ui_url, themes_dir / "seed-ui")
            seed_config["theme"] = name_ui
            print(f"  installed → themes/{name_ui}/")
        except Exception as e:
            print(f"  Warning: could not install seed-ui ({e})")
            print(f"  You can install it later with: seed theme-install {name} {seed_ui_url}")
            if _ask_yes_no("  Continue without theme?", default=True):
                pass
            else:
                print("  Aborted. Removing project directory.")
                import shutil as _shutil
                _shutil.rmtree(project_dir, ignore_errors=True)
                sys.exit(1)

    # Write seed.yaml
    if seed_config:
        _write_seed_yaml(project_dir, seed_config)
    else:
        (project_dir / "seed.yaml").write_text("# theme: <name>\n", encoding="utf-8")

    print()
    print("  seed.yaml              — config do projeto")
    print("  src/index.seed         — página inicial")
    print("  src/default.layout     — layout padrão")
    print("  src/components/        — componentes do projeto")
    print("  src/assets/            — assets do projeto")
    print("  themes/                — themes instalados")
    print()
    print("Next steps:")
    print(f"  seed dev {name}")


def cmd_theme_install(args):
    if len(args) < 2:
        print("Usage: seed theme-install <project> <path|github-url>")
        sys.exit(1)

    project_dir = Path(args[0]).resolve()
    source = args[1]

    if not (project_dir / "src").is_dir():
        print(f"Error: '{project_dir}' não é um projeto Seed válido (sem src/)")
        sys.exit(1)

    themes_dir = project_dir / "themes"
    themes_dir.mkdir(parents=True, exist_ok=True)
    src_path = Path(source)
    dest_name = src_path.name if src_path.is_absolute() else source.split("/")[-1].removesuffix(".git")
    dest = themes_dir / dest_name
    if dest.exists():
        if not _ask_yes_no(f"  '{dest_name}' already installed. Update?", default=False):
            print("  Cancelled.")
            return
    print(f"  Installing from '{source}'...")
    try:
        name = _install_from_source(source, dest)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    if name:
        config = _read_seed_yaml(project_dir)
        config["theme"] = name
        _write_seed_yaml(project_dir, config)
        print(f"  installed → themes/{name}/")
        print(f"  updated seed.yaml: theme: {name}")


def cmd_theme_update(args):
    if len(args) < 2:
        print("Usage: seed theme-update <project> <path|github-url>")
        sys.exit(1)

    project_dir = Path(args[0]).resolve()
    source = args[1]

    if not (project_dir / "src").is_dir():
        print(f"Error: '{project_dir}' não é um projeto Seed válido (sem src/)")
        sys.exit(1)

    config = _read_seed_yaml(project_dir)
    theme_name = config.get("theme")
    if not theme_name:
        print("Error: No theme configured in seed.yaml")
        sys.exit(1)

    theme_dir = project_dir / "themes" / theme_name
    if not theme_dir.is_dir():
        if not _ask_yes_no(f"  '{theme_name}' not found locally. Install it?", default=True):
            return

    print(f"Updating theme '{theme_name}' from '{source}'...")
    try:
        _install_from_source(source, theme_dir)
        print(f"  Updated → themes/{theme_name}/")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def cmd_dev(args):
    if not args:
        print("Usage: seed dev <folder> [port]")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    port = int(args[1]) if len(args) > 1 else 8000

    src_dir = folder / "src"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project? (expected src/ folder)")
        sys.exit(1)

    try:
        theme_lib_dir, js_mode, css_mode, minify, _ = _load_project_config(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    dist_dir.mkdir(parents=True, exist_ok=True)

    seed_instance = _make_seed_instance(folder, theme_lib_dir, js_mode, css_mode, minify)

    # Mutable state shared with watcher
    state = {
        "seed": seed_instance,
        "theme_lib_dir": theme_lib_dir,
    }

    print(f"Building {folder.name}...")
    if theme_lib_dir:
        print(f"  theme: {theme_lib_dir.name}")
    _rebuild_full(state, src_dir, dist_dir)
    print("Build complete.")
    print()

    # Build handler class with assets dirs bound
    lib_static = theme_lib_dir / "assets" if theme_lib_dir else None
    project_static = folder / "src" / "assets"

    class Handler(SeedDevHandler):
        pass
    Handler.static_dir = project_static
    Handler.lib_static_dir = lib_static
    Handler.dev_state = state

    handler_factory = partial(Handler, directory=str(dist_dir))
    server = ThreadingHTTPServer(("0.0.0.0", port), handler_factory)
    server.daemon_threads = True

    watcher_thread = threading.Thread(
        target=watch,
        args=(state, src_dir, dist_dir, folder),
        daemon=True,
    )
    watcher_thread.start()

    import socket
    url = f"http://localhost:{port}"
    print(f"Serving at:")
    print(f"  Local:   {url}")
    try:
        local_ip = socket.gethostbyname(socket.gethostname())
        if local_ip and local_ip != "127.0.0.1":
            print(f"  Network: http://{local_ip}:{port}")
    except Exception:
        pass
    print("Press o to open, b to build, h to toggle component explorer, r to restart, q to quit")

    def handle_input():
        global _raw_mode
        import tty
        import termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            _raw_mode = True
            while True:
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    key = sys.stdin.read(1).lower()
                    if key == "o":
                        try:
                            import subprocess
                            subprocess.run(["open", "-g", url], check=True)
                        except Exception:
                            webbrowser.open(url)
                    elif key == "b":
                        from seed.components import reload_components_yaml
                        src_components = folder / "src" / "components"
                        reload_components_yaml(
                            components_dir=src_components if src_components.exists() else None,
                            theme_dir=state["theme_lib_dir"],
                        )
                        _rebuild_full(state, src_dir, dist_dir)
                        dev_print("  Built all.")
                        notify_reload()
                    elif key == "h":
                        dev_print("  Component explorer toggled.")
                        notify_help()
                    elif key == "r":
                        dev_print("  Restarting...")
                        _raw_mode = False
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        env = os.environ.copy()
                        seed_cli_dir = str(Path(__file__).resolve().parent.parent)
                        existing = env.get("PYTHONPATH", "")
                        env["PYTHONPATH"] = f"{seed_cli_dir}:{existing}" if existing else seed_cli_dir
                        os.execve(sys.executable, [sys.executable] + sys.argv, env)
                    elif key in ("q", "\x03"):  # q or Ctrl+C
                        server.shutdown()
                        break
        finally:
            _raw_mode = False
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    input_thread = threading.Thread(target=handle_input, daemon=True)
    input_thread.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


def cmd_build(args):
    if not args:
        print("Usage: seed build <folder>")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    src_dir = folder / "src"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project?")
        sys.exit(1)

    try:
        theme_lib_dir, js_mode, css_mode, minify, optimize_css = _load_project_config(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Clean dist/
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    dist_dir.mkdir(parents=True)

    seed_instance = _make_seed_instance(folder, theme_lib_dir, js_mode, css_mode, minify)

    print(f"Building {folder.name}...")
    if theme_lib_dir:
        print(f"  theme: {theme_lib_dir.name}")
    build_all(seed_instance, src_dir, dist_dir)

    # Copy assets in layers: theme → project → dist/static/
    lib_static = theme_lib_dir / "assets" if theme_lib_dir else None
    project_static = folder / "src" / "assets"
    copy_static_layered(dist_dir, project_static, lib_static)
    if lib_static and lib_static.is_dir():
        print(f"  copied themes/{theme_lib_dir.name}/assets/ → dist/static/")
    if project_static.is_dir() and any(project_static.iterdir()):
        print(f"  copied src/assets/ → dist/static/")

    # Ensure favicon exists in dist/static/ — copy default if not provided
    _ensure_favicon(dist_dir)

    # Optimize CSS: replace Tailwind CDN with generated CSS
    if optimize_css:
        _run_tailwind_build(dist_dir, css_mode)

    # Summary
    html_files = list(dist_dir.rglob("*.html"))
    total_size = sum(f.stat().st_size for f in dist_dir.rglob("*") if f.is_file())
    print()
    print(f"Build complete: {len(html_files)} HTML file(s), {total_size // 1024} KB total → dist/")


# ─── Format ──────────────────────────────────────────────────────────────────

def cmd_fmt(args):
    if not args:
        print("Usage: seed fmt <file.seed|folder> [--write] [--check]")
        sys.exit(1)

    write_mode = "--write" in args
    check_mode = "--check" in args
    targets = [a for a in args if not a.startswith("--")]

    if not targets:
        print("Usage: seed fmt <file.seed|folder> [--write] [--check]")
        sys.exit(1)

    target = Path(targets[0]).resolve()

    if not target.exists():
        print(f"Error: '{target}' não encontrado.")
        sys.exit(1)

    if target.is_file():
        files = [target]
    else:
        files = sorted(list(target.rglob("*.seed")) + list(target.rglob("*.layout")))

    from .formatter import format_source

    needs_format = []
    for f in files:
        original = f.read_text(encoding="utf-8")
        try:
            formatted = format_source(original)
        except Exception as e:
            print(f"{f}: erro ao formatar — {e}")
            continue

        if check_mode:
            if formatted != original:
                needs_format.append(f)
                print(f"{f}: não formatado")
        elif write_mode:
            if formatted != original:
                f.write_text(formatted, encoding="utf-8")
                print(f"{f}: formatado")
        else:
            print(formatted, end="")

    if check_mode and needs_format:
        sys.exit(1)


# ─── Lint ────────────────────────────────────────────────────────────────────

def _find_project_dir(start: Path) -> Path | None:
    """Walk-up procurando seed.yaml. Retorna o diretório ou None."""
    current = start if start.is_dir() else start.parent
    for parent in [current, *current.parents]:
        if (parent / "seed.yaml").exists():
            return parent
        if parent == parent.parent:
            break
    return None


def cmd_lint(args):
    if not args:
        print("Usage: seed lint <file.seed|folder>")
        sys.exit(1)

    target = Path(args[0]).resolve()

    if not target.exists():
        print(f"Error: '{target}' não encontrado.")
        sys.exit(1)

    project_dir = _find_project_dir(target)
    if not project_dir:
        print(f"Error: seed.yaml não encontrado em '{target}' ou diretórios acima.")
        sys.exit(1)

    try:
        theme_lib_dir, _, _, _, _ = _load_project_config(project_dir)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    from .components import reload_components_yaml
    src_components = project_dir / "src" / "components"
    reload_components_yaml(
        components_dir=src_components if src_components.exists() else None,
        theme_dir=theme_lib_dir,
    )

    from .linter import lint_file

    files = [target] if target.is_file() else sorted(target.rglob("*.seed"))

    all_diags = []
    for f in files:
        all_diags.extend(lint_file(f))

    for d in all_diags:
        print(d)

    if all_diags:
        sys.exit(1)


# ─── Entry point ─────────────────────────────────────────────────────────────

COMMANDS = {
    "init": cmd_init,
    "dev": cmd_dev,
    "build": cmd_build,
    "lint": cmd_lint,
    "fmt": cmd_fmt,
    "theme-install": cmd_theme_install,
    "theme-update": cmd_theme_update,
}


def main(argv: list[str] | None = None):
    args = argv if argv is not None else sys.argv[1:]
    cmd = args[0] if args else None
    if cmd not in COMMANDS:
        print("Usage: seed <command> [args]")
        print()
        print("  init <name> [--components <src>]   Create a new Seed project")
        print("  dev  <folder>                      Start dev server with live reload")
        print("  build <folder>                     Build for production")
        print("  lint <file.seed|folder>            Lint .seed files")
        print("  fmt  <file.seed|folder>            Format .seed files")
        print("  theme-install <project> <src>      Install a theme")
        print("  theme-update  <project> <src>      Update installed theme from source")
        sys.exit(1)
    COMMANDS[cmd](args[1:])


if __name__ == "__main__":
    main()
