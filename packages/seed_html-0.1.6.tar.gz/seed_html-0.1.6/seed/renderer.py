from __future__ import annotations

from pathlib import Path

from .markdown import render_markdown, render_inline, escape_html
from .nodes import Component, Content, Include, Page, RawContent, VarRef
from .components import render_component, get_component_scripts, reset_error_state  # noqa: E402
from .components.rendering import _serialize_nodes
from .parser import parse

_PAGE_DIR = Path(__file__).parent / "page"
_PAGE_TEMPLATE = (_PAGE_DIR / "base.html").read_text(encoding="utf-8")


def render_plain(text: str) -> str:
    """Render content as inline-processed text: escapes HTML and handles
    backtick code, bold, italic and links — but does NOT wrap in <p>.
    Trailing space is preserved to allow spacing before sibling components."""
    trailing = " " if text.endswith(" ") else ""
    return render_inline(text.strip()) + trailing


def render_preformatted(text: str) -> str:
    """Render content preserving whitespace exactly (for @pre/@code blocks).
    Escapes HTML entities so literal tags display as text."""
    return escape_html(text)


def _serialize_props(props: dict) -> str:
    """Serialize a props dict back to .seed prop string."""
    parts = []
    for k, v in props.items():
        if v is True:
            parts.append(k)
        elif v:
            parts.append(f"{k}={v}")
    return ", ".join(parts)


def _serialize_node(node, indent: int) -> str:
    """Serialize a Component or Content node back to .seed syntax."""
    pad = "  " * indent
    if isinstance(node, Content):
        return "\n".join(pad + line for line in node.text.splitlines())
    if isinstance(node, Component):
        props_str = _serialize_props(node.props)
        header = f"{pad}@{node.name}" + (f": {props_str}" if props_str else "")
        if not node.children:
            return header
        child_lines = []
        for child in node.children:
            child_lines.append(_serialize_node(child, indent + 1))
        return header + "\n" + "\n".join(child_lines)
    return ""


class Renderer:
    def __init__(self, js_mode: str = "file", css_mode: str = "file", minify: bool = False):
        self.includes: dict[str, str] = {}      # resolved_path → rendered HTML
        self._include_paths: dict[str, str] = {}  # include_path → resolved_path
        self._used_components: set[str] = set()  # component names used during render
        self._vars: dict[str, list] = {}         # @@name → AST children nodes
        self.js_mode = js_mode
        self.css_mode = css_mode
        self.minify = minify
        self._static_dirs: list[Path] = []      # dirs to search for asset files (theme → project)

    def clear_includes(self):
        """Clear include cache. Call before each full rebuild to avoid stale entries."""
        self.includes.clear()
        self._include_paths.clear()

    def render(self, page: Page) -> str:
        reset_error_state()
        self._vars = page.vars
        return self.render_children(page.children)

    def _build_body_class(self, meta: dict) -> str:
        """Build body class string from body-class in meta."""
        value = meta.get("body-class", "")
        return str(value).strip() if value else ""

    def _merge_body_class(self, layout_class: str, page_class: str) -> str:
        """Merge body-class from layout and page using Tailwind-aware deduplication."""
        from .components.classes import build_classes_from_strings
        if not layout_class:
            return page_class
        if not page_class:
            return layout_class
        return build_classes_from_strings(layout_class, page_class)

    def render_page(self, page: Page) -> str:
        self._used_components.clear()
        reset_error_state()
        self._vars = page.vars
        body = self.render_children(page.children)
        meta = page.meta

        def _to_list(val) -> list:
            if not val:
                return []
            return [val] if isinstance(val, str) else list(val)

        css_files = _to_list(meta.get("css"))
        js_files = _to_list(meta.get("js"))

        template = _PAGE_TEMPLATE

        # Build body class from meta (properties starting with 'body-')
        body_class = self._build_body_class(meta)
        body_attrs = f' class="{body_class}"' if body_class else ""

        css_links = ""
        for f in css_files:
            if not f:
                continue
            if self.css_mode == "inline":
                source = self._read_static_file(f)
                if source is not None:
                    css_links += f"<style>{source}</style>\n        "
                else:
                    css_links += f'<link rel="stylesheet" href="{f}">\n        '
            else:
                css_links += f'<link rel="stylesheet" href="{f}">\n        '

        js_scripts = ""
        for f in js_files:
            if not f:
                continue
            if self.js_mode == "inline":
                source = self._read_static_file(f)
                if source is not None:
                    js_scripts += f"<script>{source}</script>\n        "
                else:
                    js_scripts += f'<script src="{f}"></script>\n        '
            else:
                js_scripts += f'<script src="{f}"></script>\n        '

        component_scripts = ""
        if self._used_components:
            scripts = get_component_scripts(self._used_components)
            if scripts:
                component_scripts = "\n        ".join(
                    f"<script>{s}</script>" for s in scripts
                )

        description = meta.get("description", "")
        description_meta = f'<meta name="description" content="{description}">' if description else ""

        favicon = meta.get("favicon", "")
        favicon_link = f'<link rel="icon" href="{favicon}">\n        ' if favicon else ""

        html = template.format(
            lang=meta.get("lang", "en"),
            title=meta.get("title", ""),
            favicon_link=favicon_link,
            description_meta=description_meta,
            css_links=css_links,
            js_scripts=js_scripts,
            component_scripts=component_scripts,
            body=body,
            body_attrs=body_attrs,
            body_class=body_class,
        )

        if self.minify:
            import minify_html
            html = minify_html.minify(html, minify_js=True, minify_css=True)

        return html

    def resolve_includes(
        self,
        page: Page,
        base_dir: Path,
        templates_dir: Path | None = None,
    ):
        self._resolve_includes_recursive(page.children, base_dir, templates_dir)

    def _resolve_includes_recursive(
        self,
        children: list,
        base_dir: Path,
        templates_dir: Path | None,
    ):
        for child in children:
            if isinstance(child, Include) and child.path not in self._include_paths:
                self._resolve_include(child.path, base_dir, templates_dir)
            elif isinstance(child, Component) and child.children:
                self._resolve_includes_recursive(child.children, base_dir, templates_dir)

    def _resolve_include(
        self,
        include_path: str,
        base_dir: Path,
        templates_dir: Path | None,
    ):
        candidates = [base_dir / f"{include_path}.seed", base_dir / include_path]
        if templates_dir:
            candidates.extend([templates_dir / f"{include_path}.seed", templates_dir / include_path])

        for candidate in candidates:
            if candidate.is_file():
                resolved_key = str(candidate.resolve())
                self._include_paths[include_path] = resolved_key
                if resolved_key not in self.includes:
                    source = candidate.read_text(encoding="utf-8")
                    included_page = parse(source)
                    self.includes[resolved_key] = self.render_children(included_page.children)
                return

    def render_children(self, children: list, use_markdown: bool = False) -> str:
        """Render children. If use_markdown=True, process as markdown. Otherwise, render as plain text."""
        render_fn = render_markdown if use_markdown else render_plain
        parts = []
        for child in children:
            if isinstance(child, Component):
                self._used_components.add(child.name)
                parts.append(render_component(child, self.render_children, self.render_children_pre))
            elif isinstance(child, VarRef):
                var_children = self._vars.get(child.name, [])
                parts.append(self.render_children(var_children))
            elif isinstance(child, RawContent):
                parts.append(child.html)
            elif isinstance(child, Content):
                parts.append(render_fn(child.text))
            elif isinstance(child, Include):
                resolved_key = self._include_paths.get(child.path)
                parts.append(
                    self.includes.get(resolved_key, f"<!-- include: {child.path} -->")
                    if resolved_key else f"<!-- include: {child.path} -->"
                )
        return "".join(parts)

    def render_children_pre(self, children: list) -> str:
        """Render children for @pre/@code: everything is treated as raw text.
        - Content → escaped as-is, but @@varname lines expand the var as serialized .seed
        - Component → serialized back to .seed syntax (escaped)
        - VarRef → children serialized back to .seed syntax (escaped)
        - RawContent → already-rendered HTML, escaped so tags show as text
        """
        import re as _re
        _VAR_LINE_RE = _re.compile(r"^@@([\w-]+)$")
        parts = []
        for child in children:
            if isinstance(child, Content):
                # Check each line for @@varname references
                lines = child.text.splitlines()
                resolved_lines = []
                for line in lines:
                    m = _VAR_LINE_RE.match(line.strip())
                    if m and m.group(1) in self._vars:
                        var_children = self._vars[m.group(1)]
                        resolved_lines.append(_serialize_nodes(var_children, vars=self._vars))
                    else:
                        resolved_lines.append(render_preformatted(line))
                parts.append("\n".join(resolved_lines))
            elif isinstance(child, RawContent):
                parts.append(escape_html(child.html))
            elif isinstance(child, Component):
                parts.append(render_preformatted(_serialize_node(child, indent=0)))
            elif isinstance(child, VarRef):
                var_children = self._vars.get(child.name, [])
                parts.append(render_preformatted(_serialize_nodes(var_children, vars=self._vars)))
        return "\n".join(parts)

    def _read_static_file(self, href: str) -> str | None:
        """Try to read a static file by its href path from known static dirs.
        Returns file contents or None if not found.
        """
        # Strip leading slash or 'static/'/'assets/' prefix to get relative filename
        rel = href.lstrip("/")
        if rel.startswith("static/"):
            rel = rel[len("static/"):]
        elif rel.startswith("assets/"):
            rel = rel[len("assets/"):]
        for static_dir in self._static_dirs:
            candidate = static_dir / rel
            if candidate.is_file():
                return candidate.read_text(encoding="utf-8")
        return None
