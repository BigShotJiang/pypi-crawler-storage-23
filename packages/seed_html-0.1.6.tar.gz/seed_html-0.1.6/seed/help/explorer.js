/**
 * Seed Component Explorer controller.
 * View/HTML lives in explorer.template.js.
 */
(function () {
  'use strict';

  const T = window.SeedExplorerTemplates;
  if (!T) return;

  const PAGE_MODE = !!window.__SEED_EXPLORER_PAGE;

  let overlay = null;
  let components = [];
  let searchQuery = '';
  let layerFilter = 'all';
  let activeSectionId = '';

  if (PAGE_MODE) {
    // Standalone page: render immediately into body, no overlay mechanics
    initPageMode();
  } else {
    window.addEventListener('seed:help', () => toggleOverlay());

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && overlay) {
        closeOverlay();
        return;
      }
      if (e.key === 'h' || e.key === 'H') {
        const tag = document.activeElement?.tagName?.toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
        if (document.activeElement?.isContentEditable) return;
        toggleOverlay();
      }
    });
  }

  function toggleOverlay() {
    if (overlay) closeOverlay();
    else openOverlay();
  }

  function closeOverlay() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    document.body.style.overflow = '';
  }

  async function openOverlay() {
    if (overlay) return;
    buildOverlay();
    document.body.style.overflow = 'hidden';

    try {
      const res = await fetch('/__components');
      const data = await res.json();
      components = Array.isArray(data.components) ? data.components : [];
      components.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    } catch (_) {
      components = [];
    }

    renderAll();
  }

  async function initPageMode() {
    document.documentElement.style.cssText = 'height:100%;margin:0;padding:0;background:#0f1117';
    document.body.style.cssText = 'height:100%;margin:0;padding:0;background:#0f1117;display:flex;flex-direction:column';

    overlay = document.createElement('div');
    overlay.id = 'seed-explorer-overlay';
    overlay.style.cssText = 'flex:1;display:flex;flex-direction:column;min-height:0';
    overlay.innerHTML = T.overlayShell(true);
    document.body.appendChild(overlay);

    try {
      const res = await fetch('/__components');
      const data = await res.json();
      components = Array.isArray(data.components) ? data.components : [];
      components.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
    } catch (_) {
      components = [];
    }

    renderAll();
  }

  function buildOverlay() {
    overlay = document.createElement('div');
    overlay.id = 'seed-explorer-overlay';
    overlay.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:99999',
      'display:flex', 'flex-direction:column',
      'background:rgba(0,0,0,0.6)',
      'backdrop-filter:blur(2px)',
    ].join(';');

    overlay.innerHTML = T.overlayShell(false);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeOverlay();
    });

    const closeBtn = overlay.querySelector('#se-close');
    if (closeBtn) closeBtn.addEventListener('click', closeOverlay);

    document.body.appendChild(overlay);
  }

  function renderAll() {
    if (!overlay) return;

    const sidebar = overlay.querySelector('#se-sidebar-list');
    const content = overlay.querySelector('#se-content-list');
    const count = overlay.querySelector('#se-count');

    if (!sidebar || !content) return;

    const filtered = getFilteredComponents();
    if (count) {
      count.textContent = (searchQuery || layerFilter !== 'all')
        ? `${filtered.length} of ${components.length}`
        : `${components.length} components`;
    }
    bindSearchInput();

    if (filtered.length === 0) {
      sidebar.innerHTML = '<div style="color:#64748b;font-size:0.75rem">No components</div>';
      content.innerHTML = '<div style="color:#64748b;font-size:0.85rem">No components found.</div>';
      return;
    }

    sidebar.innerHTML = filtered.map((c) => T.sidebarItem(c)).join('');
    content.innerHTML = filtered.map((c) => T.contentSection(c)).join('');

    bindSidebarNavigation();
    bindSectionToggle();
    bindCopyButtons();

    // Keep last user selection if still visible; otherwise fallback to first.
    const visibleIds = new Set(filtered.map((c) => T.sectionId(c.name)));
    if (!activeSectionId || !visibleIds.has(activeSectionId)) {
      const first = filtered[0];
      activeSectionId = first ? T.sectionId(first.name) : '';
    }
    if (activeSectionId) setActiveSection(activeSectionId);
  }

  function getFilteredComponents() {
    const q = searchQuery.trim().toLowerCase();
    return components.filter((c) => {
      if (layerFilter !== 'all' && (c.source_layer || 'lib') !== layerFilter) {
        return false;
      }
      if (!q) return true;
      const modifierGroups = Object.keys(c.modifiers || {});
      const modifierValues = Object.values(c.modifiers || {}).flat();
      const slotNames = (c.slots || []).map((slot) => slot.name);
      const hay = [
        c.name,
        c.tag,
        c.description || '',
        ...modifierGroups,
        ...modifierValues,
        ...(c.template_variants || []),
        ...slotNames,
      ].join(' ').toLowerCase();
      return hay.includes(q);
    });
  }

  function bindSearchInput() {
    if (!overlay) return;
    const input = overlay.querySelector('#se-search');
    const layerButtons = Array.from(overlay.querySelectorAll('.se-layer-btn'));
    if (!input) return;
    if (input.dataset.bound === '1') return;
    input.dataset.bound = '1';
    input.value = searchQuery;
    applyLayerButtonState(layerButtons);
    input.addEventListener('input', () => {
      searchQuery = input.value || '';
      renderAll();
    });
    layerButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        layerFilter = btn.getAttribute('data-layer') || 'all';
        applyLayerButtonState(layerButtons);
        renderAll();
      });
    });
  }

  function applyLayerButtonState(buttons) {
    buttons.forEach((btn) => {
      const active = (btn.getAttribute('data-layer') || 'all') === layerFilter;
      btn.style.background = active ? '#1e293b' : 'transparent';
      btn.style.color = active ? '#e2e8f0' : '#94a3b8';
    });
  }

  function bindSidebarNavigation() {
    if (!overlay) return;
    const sidebar = overlay.querySelector('#se-sidebar-list');
    const content = overlay.querySelector('#se-content-list');
    if (!sidebar || !content) return;

    sidebar.querySelectorAll('.se-sidebar-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-target');
        if (!targetId) return;
        const section = content.querySelector(`section[data-section-id="${targetId}"]`);
        if (!section) return;
        setSectionOpen(section, true, true);
        const header = overlay.querySelector('#seed-explorer-panel > section > div');
        const headerHeight = header ? header.offsetHeight : 0;
        const top = Math.max(0, section.offsetTop - headerHeight - 6);
        content.scrollTop = top;
        activeSectionId = targetId;
        setActiveSection(activeSectionId);
      });
    });
  }

  function bindSectionToggle() {
    if (!overlay) return;
    const content = overlay.querySelector('#se-content-list');
    if (!content) return;

    content.querySelectorAll('section[data-section-id]').forEach((section) => {
      const summary = section.querySelector('.se-section-summary');
      const details = section.querySelector('.se-section-details');
      if (!summary || !details) return;

      summary.addEventListener('click', (e) => {
        if (e.target.closest('.se-copy-btn, a')) return;
        const open = details.style.display !== 'none';
        setSectionOpen(section, !open, !open);
      });
    });
  }

  function setSectionOpen(section, open, closeOthers) {
    if (!overlay) return;
    const content = overlay.querySelector('#se-content-list');
    if (!content) return;

    if (closeOthers) {
      content.querySelectorAll('section[data-section-id]').forEach((sec) => {
        const node = sec.querySelector('.se-section-details');
        if (node) node.style.display = 'none';
        sec.style.background = '#151924';
        sec.style.borderColor = '#2d3148';
        sec.style.boxShadow = 'none';
      });
    }

    const details = section.querySelector('.se-section-details');
    if (!details) return;
    const summary = section.querySelector('.se-section-summary');
    const summaryExtra = section.querySelector('.se-summary-extra');
    details.style.display = open ? 'block' : 'none';
    section.style.background = '#151924';
    section.style.borderColor = open ? '#4f46e5' : '#2d3148';
    section.style.boxShadow = open ? 'inset 0 0 0 1px #4f46e5' : 'none';
    if (summary) {
      summary.style.borderBottom = 'none';
    }
    if (summaryExtra) {
      summaryExtra.style.display = open ? 'none' : 'block';
    }
  }

  function bindCopyButtons() {
    if (!overlay) return;
    overlay.querySelectorAll('.se-copy-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const code = btn.getAttribute('data-code') || '';
        navigator.clipboard.writeText(code).then(() => {
          const oldText = btn.textContent;
          btn.textContent = 'Copied!';
          btn.style.color = '#22c55e';
          btn.style.borderColor = '#22c55e';
          setTimeout(() => {
            btn.textContent = oldText || 'Copy';
            btn.style.color = '';
            btn.style.borderColor = '';
          }, 1400);
        }).catch(() => {
          // no-op
        });
      });
    });
  }

  function setActiveSection(sectionId) {
    if (!overlay) return;
    const sidebar = overlay.querySelector('#se-sidebar-list');
    if (!sidebar) return;

    sidebar.querySelectorAll('.se-sidebar-item').forEach((btn) => {
      const active = btn.getAttribute('data-target') === sectionId;
      btn.style.background = active ? '#1e293b' : 'transparent';
      btn.style.color = active ? '#e2e8f0' : '#cbd5e1';
    });
  }
})();
