/**
 * Seed Component Explorer Templates
 * HTML/view-only layer used by explorer.js controller.
 */
(function () {
  'use strict';

  function esc(str, attr) {
    const s = String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    if (attr) return s.replace(/"/g, '&quot;');
    return s;
  }

  function sectionId(name) {
    return `se-section-${String(name || '').toLowerCase().replace(/[^a-z0-9_-]+/g, '-')}`;
  }

  function typeBadge(component) {
    if (!component.has_template) return '';
    return '<span style="font-size:0.7rem;padding:1px 7px;border-radius:9999px;font-weight:700;background:#1c1340;color:#c4b5fd;border:1px solid #4c1d95">template-based</span>';
  }

  function quickFacts(component) {
    const parts = [];
    const modifiers = Number(component.modifiers_count ?? 0);
    const templates = Number(component.templates_count ?? 0);
    const slots = Number(component.slots_count ?? 0);

    if (modifiers > 0) {
      parts.push(`<span style="font-size:0.72rem;background:#1f2937;color:#93c5fd;border:1px solid #374151;padding:1px 7px;border-radius:9999px;font-family:monospace">Modifiers: ${modifiers}</span>`);
    }
    if (templates > 0) {
      parts.push(`<span style="font-size:0.72rem;background:#1a1040;color:#c4b5fd;border:1px solid #3b1f8c;padding:1px 7px;border-radius:9999px;font-family:monospace">Templates: ${templates}</span>`);
    }
    if (slots > 0) {
      parts.push(`<span style="font-size:0.72rem;background:#0f2a22;color:#6ee7b7;border:1px solid #14532d;padding:1px 7px;border-radius:9999px;font-family:monospace">Slots: ${slots}</span>`);
    }
    if (parts.length === 0) return '';
    return `<div style="display:flex;flex-wrap:wrap;gap:4px">${parts.join('')}</div>`;
  }

  function modifierSummary(component) {
    const modifiers = component.modifiers || {};
    const parts = Object.keys(modifiers).map((group) => `${group}(${(modifiers[group] || []).length})`);
    if (parts.length === 0) return '';
    return parts.map((part) => `<span style="font-family:monospace">${esc(part)}</span>`).join('<span style="opacity:.5"> · </span>');
  }

  function modifierDetails(component) {
    const modifiers = component.modifiers || {};
    const groups = Object.keys(modifiers);
    if (groups.length === 0) {
      return '<div style="font-size:0.84rem;color:#64748b">No modifiers</div>';
    }
    return groups.map((group) => {
      const values = modifiers[group] || [];
      const badges = values.map((value) =>
        `<span style="font-size:0.74rem;background:#1e2937;color:#38bdf8;border:1px solid #1e3a4a;padding:1px 7px;border-radius:9999px;font-family:monospace">${esc(value)}</span>`
      ).join('');
      return `
        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin-top:4px">
          <span style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700;margin-right:2px">${esc(group)}</span>
          <span style="font-size:0.74rem;color:#64748b;font-family:monospace">:</span>
          ${badges || '<span style="font-size:0.74rem;color:#64748b;font-family:monospace">-</span>'}
        </div>
      `;
    }).join('');
  }

  function templatesDetails(component) {
    const names = [];
    if (component.has_template) names.push('default');
    names.push(...(component.template_variants || []));
    if (names.length === 0) return '<div style="font-size:0.84rem;color:#64748b">No templates</div>';
    return names.map((name) =>
      `<span style="font-size:0.74rem;background:#1a1040;color:#c4b5fd;border:1px solid #3b1f8c;padding:1px 7px;border-radius:9999px;font-family:monospace">${esc(name)}</span>`
    ).join('');
  }

  function slotsDetails(component) {
    const slots = component.slots || [];
    if (slots.length === 0) return '<div style="font-size:0.84rem;color:#64748b">No slots</div>';
    return slots.map((slot) => {
      const tone = slot.optional
        ? 'background:#122033;color:#93c5fd;border:1px solid #1e3a8a'
        : 'background:#2a1a0f;color:#fdba74;border:1px solid #7c2d12';
      const prefix = slot.optional ? '?' : '';
      return `<span style="font-size:0.74rem;${tone};padding:1px 7px;border-radius:9999px;font-family:monospace">${prefix}${esc(slot.name)}</span>`;
    }).join('');
  }

  function autoExample(component) {
    return `@${component.name}\n  Content here`;
  }

  function overlayShell(isPage) {
    const panelStyle = isPage
      ? 'flex:1;display:flex;overflow:hidden;background:#0f1117;color:#e2e8f0;min-height:0'
      : 'position:absolute;inset:2%;border-radius:12px;background:#0f1117;color:#e2e8f0;display:flex;overflow:hidden;box-shadow:0 25px 60px rgba(0,0,0,0.7);border:1px solid #2d3148';
    return `
      <div id="seed-explorer-panel" style="${panelStyle}">

        <aside style="width:260px;flex:0 0 260px;border-right:1px solid #2d3148;background:#141925;display:flex;flex-direction:column;min-width:0;min-height:0">
          <div style="padding:10px 14px;min-height:56px;box-sizing:border-box;display:flex;align-items:center;border-bottom:1px solid #2d3148;background:#1a1d27">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
              <span style="font-size:0.9rem;font-weight:700;color:#a5b4fc">Components</span>
              <span id="se-count"
                    style="font-size:0.72rem;color:#64748b;background:#1e2235;border:1px solid #2d3148;padding:2px 8px;border-radius:9999px">
                loading…
              </span>
            </div>
          </div>
          <div id="se-sidebar-list" style="padding:8px;overflow:auto;overscroll-behavior:contain;display:flex;flex-direction:column;gap:2px;min-height:0;flex:1"></div>
          <div style="padding:8px 12px;border-top:1px solid #2d3148;display:flex;gap:10px;flex-shrink:0">
            <span style="display:inline-flex;align-items:center;gap:5px;font-size:0.7rem;color:#64748b">
              <span style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:9999px;font-size:0.62rem;font-weight:600;background:#1f3d78;color:#6ea2ff;border:1px solid #6ea2ff">T</span>
              Theme
            </span>
            <span style="display:inline-flex;align-items:center;gap:5px;font-size:0.7rem;color:#64748b">
              <span style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:9999px;font-size:0.62rem;font-weight:600;background:#1a5a33;color:#4cc27a;border:1px solid #4cc27a">P</span>
              Project
            </span>
          </div>
        </aside>

        <section style="flex:1;display:flex;flex-direction:column;min-width:0;min-height:0">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 14px;min-height:56px;box-sizing:border-box;border-bottom:1px solid #2d3148;background:#1a1d27">
            <span style="font-size:0.86rem;color:#94a3b8;white-space:nowrap">Explorer</span>
            <div style="display:flex;align-items:center;gap:8px;min-width:0;flex:1;justify-content:flex-end">
              <div id="se-layer-filter"
                   style="display:flex;gap:4px;background:#0f1420;border:1px solid #2d3148;border-radius:8px;padding:3px">
                <button class="se-layer-btn" data-layer="all"
                        style="background:#1e293b;color:#e2e8f0;border:none;border-radius:6px;padding:5px 8px;font-size:0.74rem;cursor:pointer">
                  All
                </button>
                <button class="se-layer-btn" data-layer="project"
                        style="background:transparent;color:#94a3b8;border:none;border-radius:6px;padding:5px 8px;font-size:0.74rem;cursor:pointer">
                  <span style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:9999px;font-size:0.62rem;line-height:1;font-weight:600;background:#1a5a33;color:#4cc27a;border:1px solid #4cc27a;margin-right:4px">P</span>Project
                </button>
                <button class="se-layer-btn" data-layer="lib"
                        style="background:transparent;color:#94a3b8;border:none;border-radius:6px;padding:5px 8px;font-size:0.74rem;cursor:pointer">
                  <span style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:9999px;font-size:0.62rem;line-height:1;font-weight:600;background:#1f3d78;color:#6ea2ff;border:1px solid #6ea2ff;margin-right:4px">T</span>Theme
                </button>
              </div>
              <input id="se-search"
                     type="text"
                     placeholder="Search components"
                     style="width:340px;max-width:100%;box-sizing:border-box;background:#0f1420;color:#cbd5e1;
                            border:1px solid #2d3148;border-radius:8px;padding:7px 8px;font-size:0.78rem;
                            outline:none" />
              ${isPage ? '' : '<button id="se-close" style="background:#111827;color:#94a3b8;border:1px solid #374151;border-radius:8px;padding:4px 10px;font-size:0.82rem;cursor:pointer">Close</button>'}
            </div>
          </div>
          <div id="se-content-list" style="padding:10px 14px;overflow:auto;overscroll-behavior:contain;display:flex;flex-direction:column;gap:8px;min-height:0;flex:1"></div>
        </section>
      </div>
    `;
  }

  function sidebarItem(component) {
    const target = sectionId(component.name);
    const isProject = (component.source_layer || 'lib') === 'project';
    const originLabel = isProject ? 'P' : 'T';
    const originStyle = isProject
      ? 'background:#1a5a33;color:#4cc27a;border:1px solid #4cc27a'
      : 'background:#1f3d78;color:#6ea2ff;border:1px solid #6ea2ff';
    return `
      <button class="se-sidebar-item" data-target="${esc(target, true)}"
              style="text-align:left;background:transparent;color:#cbd5e1;border:none;border-radius:8px;
                     padding:7px 8px;cursor:pointer;display:flex;flex-direction:column;gap:3px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <div style="display:flex;align-items:center;gap:6px;min-width:0">
            <span style="font-family:'Fira Code','JetBrains Mono',monospace;font-size:0.88rem;color:#a5b4fc">@${esc(component.name)}</span>
            <span title="${isProject ? 'Project component' : 'Theme component'}"
                  style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:9999px;font-size:0.62rem;line-height:1;font-weight:600;${originStyle}">
              ${originLabel}
            </span>
          </div>
          <span style="font-size:0.78rem;color:#64748b;font-family:monospace">&lt;${esc(component.tag)}&gt;</span>
        </div>
      </button>
    `;
  }

  function contentSection(component) {
    const id = sectionId(component.name);
    const summary = modifierSummary(component);
    const hasModifiers = Number(component.modifiers_count ?? 0) > 0;
    const hasTemplates = Number(component.templates_count ?? 0) > 0;
    const hasSlots = Number(component.slots_count ?? 0) > 0;
    const desc = component.description
      ? `<div style="font-size:0.84rem;color:#94a3b8;line-height:1.45;margin-top:4px">${esc(component.description)}</div>`
      : '';
    const example = component.example || autoExample(component);
    return `
      <section id="${esc(id, true)}"
               data-section-id="${esc(id, true)}"
               style="display:flex;flex-direction:column;align-items:stretch;height:fit-content;min-height:auto;background:#151924;border:1px solid #2d3148;border-radius:10px">
        <div class="se-section-summary"
             style="padding:9px 11px;cursor:pointer">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <span style="font-family:'Fira Code','JetBrains Mono',monospace;font-size:0.92rem;font-weight:700;color:#a5b4fc">@${esc(component.name)}</span>
              <span style="font-size:0.72rem;color:#64748b;font-family:monospace">&lt;${esc(component.tag)}&gt;</span>
              ${typeBadge(component)}
            </div>
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <button class="se-copy-btn" data-code="${esc(example, true)}"
                      style="background:#111827;color:#94a3b8;border:1px solid #374151;border-radius:6px;padding:2px 9px;font-size:0.78rem;cursor:pointer">
                Copy
              </button>
            </div>
          </div>
          <div class="se-summary-extra">
            ${desc}
            <div style="margin-top:6px">${quickFacts(component)}</div>
            ${hasModifiers ? `<div style="margin-top:6px;font-size:0.82rem;color:#9ca3af"><span style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700;margin-right:6px">modifiers</span>${summary}</div>` : ''}
          </div>
        </div>

        <div class="se-section-details" style="display:none;padding:10px 12px">
          ${hasModifiers ? `<div style="padding-left:6px">
            <div style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700">modifiers</div>
            <div style="margin-top:6px;padding-left:8px">${modifierDetails(component)}</div>
          </div>` : ''}

          ${hasTemplates ? `<div style="margin-top:10px;padding-top:10px;border-top:1px solid #1f2937;padding-left:6px">
            <div style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700">templates</div>
            <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;padding-left:8px">${templatesDetails(component)}</div>
          </div>` : ''}

          ${hasSlots ? `<div style="margin-top:10px;padding-top:10px;border-top:1px solid #1f2937;padding-left:6px">
            <div style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700">slots</div>
            <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;padding-left:8px">${slotsDetails(component)}</div>
          </div>` : ''}

          <div style="margin-top:10px;padding-top:10px;border-top:1px solid #1f2937;padding-left:6px">
            <div style="font-size:0.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:700">snippet</div>
            <pre style="margin:6px 0 0;background:#0b1019;border:1px solid #1f2937;border-radius:7px;padding:8px 10px;font-size:0.92rem;font-family:'Fira Code','JetBrains Mono',monospace;color:#c9d1d9;line-height:1.55">${esc(example)}</pre>
          </div>
        </div>
      </section>
    `;
  }

  window.SeedExplorerTemplates = {
    overlayShell,
    sidebarItem,
    contentSection,
    sectionId,
  };
})();
