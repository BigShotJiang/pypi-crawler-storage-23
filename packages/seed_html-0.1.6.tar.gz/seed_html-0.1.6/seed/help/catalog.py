from __future__ import annotations

import json


_EXPLORER_PROPRIETARY_KEYS = {
    "tag",
    "class",
    "template",
    "description",
    "example",
    "alias",
}


def _modifiers(config: dict) -> dict[str, list[str]]:
    groups: dict[str, list[str]] = {}
    for key, value in config.items():
        if key in _EXPLORER_PROPRIETARY_KEYS:
            continue
        if isinstance(value, dict):
            groups[key] = [str(option) for option in value.keys()]
    return groups


def build_components_payload() -> dict:
    """Return explorer payload listing top-level registered components."""
    from seed import components as comp_mod

    registry: dict = comp_mod._registry
    template_cache: dict = comp_mod._template_cache
    registry_layer: dict = comp_mod._registry_layer

    components = []
    for name in sorted(registry):
        cfg = registry[name]
        if not isinstance(cfg, dict):
            continue
        if name.startswith("__alt__"):
            continue

        has_template = name in template_cache
        template_variants = [variant for variant in template_cache.get(name, {}) if variant != "default"]
        template_count = len(template_cache.get(name, {})) if has_template else 0

        slots: list[tuple[str, bool]] = comp_mod.get_template_slot_names(name) if has_template else []
        modifiers = _modifiers(cfg)
        modifier_groups = list(modifiers.keys())

        example = cfg.get("example", "")
        if not example and has_template:
            example = comp_mod.get_template_source(name)

        components.append(
            {
                "name": name,
                "tag": cfg.get("tag", name),
                "has_template": has_template,
                "template_variants": template_variants,
                "description": cfg.get("description", ""),
                "example": example,
                "modifier_groups": modifier_groups,
                "modifiers": modifiers,
                "modifiers_count": len(modifier_groups),
                "templates_count": template_count,
                "slots_count": len(slots),
                "slots": [{"name": slot_name, "optional": is_optional} for slot_name, is_optional in slots],
                "source_layer": registry_layer.get(name, "lib"),
            }
        )

    return {"components": components}


def build_components_json() -> bytes:
    return json.dumps(build_components_payload()).encode()
