# Tags HTML válidas para uso no <body>
_BODY_TAGS = frozenset({
    "a", "abbr", "address", "article", "aside", "audio",
    "b", "bdi", "bdo", "blockquote", "br", "button",
    "canvas", "caption", "cite", "code", "col", "colgroup",
    "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt",
    "em",
    "fieldset", "figcaption", "figure", "footer", "form",
    "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr",
    "i", "iframe", "img", "input", "ins",
    "kbd",
    "label", "legend", "li",
    "main", "map", "mark", "menu", "meter",
    "nav",
    "object", "ol", "optgroup", "option", "output",
    "p", "picture", "pre", "progress",
    "q",
    "rp", "rt", "ruby",
    "s", "samp", "search", "section", "select", "small", "source", "span",
    "strong", "sub", "summary", "sup",
    "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead",
    "time", "tr", "track",
    "u", "ul",
    "var", "video",
    "wbr",
    # SVG
    "svg", "path", "circle", "rect", "line", "polyline", "polygon",
    "ellipse", "g", "defs", "use", "symbol", "text", "tspan",
    "animate", "animateTransform", "clipPath", "linearGradient",
    "radialGradient", "stop", "mask", "pattern", "filter",
    "feBlend", "feColorMatrix", "feComposite", "feGaussianBlur",
    "feMerge", "feMergeNode", "feTurbulence",
})

# Tags HTML válidas mas reservadas para <head>
_HEAD_TAGS = frozenset({
    "title", "head", "meta", "link", "base", "style", "script", "noscript",
})

# Tags que renderizam conteúdo preformatado (preservam whitespace)
_PREFORMATTED_TAGS = frozenset({"pre", "code"})

# Tags reservadas para renderização de markdown completo (sem wrapper)
_MARKDOWN_TAGS = frozenset({"markdown", "md"})

# Tags self-closing (não podem ter template)
_SELF_CLOSING_TAGS = frozenset({"img", "input", "br", "hr"})
