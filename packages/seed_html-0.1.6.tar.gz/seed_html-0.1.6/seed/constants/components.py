import re

# Keys that are NOT modifier groups in component YAML — they have special meaning
_RESERVED_KEYS = frozenset({"tag", "class", "template"})

# Regex for finding slot placeholders in templates:
# {name} = required slot, {?name} = optional slot
_SLOT_RE = re.compile(r"\{(\??)(\w[\w-]*)\}")
