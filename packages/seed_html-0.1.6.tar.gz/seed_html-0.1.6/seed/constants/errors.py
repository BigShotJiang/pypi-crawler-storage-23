# Inline error blocks rendered directly in the output.
# Each error is a styled <div> with rounded corners, visible in dev/build output.
# Format: ERRO / CAMINHO / MENSAGEM (each on its own line via <br>)

_STYLE = (
    'display:inline-block;background:{bg};border:1px solid {border};'
    'border-radius:6px;padding:6px 12px;font-family:monospace;font-size:12px;'
    'color:{color};margin:2px;line-height:1.6'
)
_WARN = _STYLE.format(bg="#fef3c7", border="#f59e0b", color="#92400e")
_ERR  = _STYLE.format(bg="#fee2e2", border="#ef4444", color="#991b1b")

# Yellow block — missing required slot
_ERR_SLOT_MISSING = (
    '<div style="' + _WARN + '">'
    "⚠️ slot não preenchido: <b>{slot}</b><br>"
    "{template_file}<br>"
    "componente: {comp}"
    "</div>"
)

# Red block — content/tag with no matching slot in template
_ERR_NO_SLOT = (
    '<div style="' + _ERR + '">'
    "🚫 sem slot para: <b>{content}</b><br>"
    "{template_file}<br>"
    "componente: {comp}"
    "</div>"
)

# Red block — head-only tag used in body
_ERR_HEAD_TAG = (
    '<div style="' + _ERR + '">'
    "🚫 tag reservada: <b>&lt;{tag}&gt;</b><br>"
    "use css: ou js: no front matter"
    "</div>"
)

# Red block — unknown/unregistered component
_ERR_UNKNOWN_TAG = (
    '<div style="' + _ERR + '">'
    "🚫 componente não registrado: <b>@{tag}</b><br>"
    "registre em um .yaml ou use uma tag HTML válida"
    "</div>"
)
