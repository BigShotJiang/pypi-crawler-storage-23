# Tailwind v4 class-prefix lookup tables
# Used by _get_class_prefix() in seed/components/classes.py for Tailwind-aware
# class deduplication (last-wins per CSS property).

# --- Border ---
_BORDER_SIDES = frozenset({"t", "r", "b", "l", "x", "y", "s", "e"})
_BORDER_STYLES = frozenset({"solid", "dashed", "dotted", "double", "hidden", "none"})
_BORDER_COLLAPSE = frozenset({"collapse", "separate"})
_ROUNDED_SIDES = frozenset({"t", "r", "b", "l", "tl", "tr", "bl", "br", "s", "e", "ss", "se", "es", "ee"})

# --- Font ---
_FONT_FAMILIES = frozenset({"sans", "serif", "mono"})
_FONT_WEIGHTS = frozenset({"thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"})
_FONT_STRETCHES = frozenset({
    "ultra-condensed", "extra-condensed", "condensed", "semi-condensed",
    "semi-expanded", "expanded", "extra-expanded", "ultra-expanded",
})

# --- Text ---
_TEXT_ALIGNS = frozenset({"left", "center", "right", "justify", "start", "end"})
_TEXT_SIZES = frozenset({"3xs", "2xs", "xs", "sm", "base", "lg", "xl", "2xl", "3xl", "4xl", "5xl", "6xl", "7xl", "8xl", "9xl"})
_TEXT_DECORATIONS = frozenset({"underline", "overline", "line-through", "no-underline"})
_TEXT_TRANSFORMS = frozenset({"uppercase", "lowercase", "capitalize", "normal-case"})
_TEXT_OVERFLOWS = frozenset({"truncate", "ellipsis", "clip"})
_TEXT_WRAPS = frozenset({"wrap", "nowrap", "balance", "pretty"})

# --- Background ---
_BG_ATTACHMENT = frozenset({"fixed", "local", "scroll"})
_BG_REPEAT = frozenset({"repeat", "no", "repeat-x", "repeat-y", "round", "space"})
_BG_SIZE = frozenset({"auto", "cover", "contain"})
_BG_POSITION = frozenset({"center", "top", "bottom", "left", "right"})

# --- Shadow / Effects ---
_SHADOW_SIZES = frozenset({"xs", "sm", "md", "lg", "xl", "2xl", "3xl", "inner", "none"})
_DROP_SHADOW_SIZES = frozenset({"xs", "sm", "md", "lg", "xl", "2xl", "none"})

# --- Layout ---
_OBJECT_FITS = frozenset({"contain", "cover", "fill", "none", "scale-down"})

# --- List ---
_LIST_POSITIONS = frozenset({"inside", "outside"})

# --- Scroll snap ---
_SNAP_ALIGNS = frozenset({"start", "end", "center", "none"})
_SNAP_STOPS = frozenset({"normal", "always"})
_SNAP_TYPES = frozenset({"none", "x", "y", "both", "mandatory", "proximity"})
