"""Tests for the template system (component folders with .template files)"""
from pathlib import Path

import pytest

from seed import Seed
from seed.components import (
    _template_cache,
    _registry,
    _extract_slots,
    get_template,
    get_template_slot_names,
    has_template,
    reload_components_yaml,
    _load_yaml_directory,
)


def _make_component_dir(tmp_path, yaml_files: dict[str, str], template_files: dict[str, str]):
    """Helper: create a components directory with yaml and .template files"""
    comp_dir = tmp_path / "components"
    comp_dir.mkdir()
    for name, content in yaml_files.items():
        (comp_dir / name).write_text(content, encoding="utf-8")
    for name, content in template_files.items():
        (comp_dir / name).write_text(content, encoding="utf-8")
    return comp_dir


class TestTemplateLoading:
    def test_load_yaml_and_template_auto_discovery(self, tmp_path):
        """Auto-discovery: card.template alongside card.yaml is loaded automatically"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card-base\n"},
            template_files={"card.template": "@div class=inner\n  {title}\n"},
        )
        reload_components_yaml(components_dir=comp_dir)

        assert "card" in _registry
        assert has_template("card")
        assert get_template("card", "default") is not None

    def test_no_template_file_means_simple_component(self, tmp_path):
        """Component with no .template file is a simple component"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"button.yaml": "button:\n  tag: button\n  class: btn\n"},
            template_files={},
        )
        reload_components_yaml(components_dir=comp_dir)

        assert "button" in _registry
        assert not has_template("button")

    def test_duplicate_in_same_layer_raises(self, tmp_path):
        """Registering the same component name twice in the same layer raises ValueError"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={
                "a.yaml": "card:\n  tag: div\n  class: a\n",
                "b.yaml": "card:\n  tag: div\n  class: b\n",
            },
            template_files={},
        )
        with pytest.raises(ValueError, match="duplicado"):
            reload_components_yaml(components_dir=comp_dir)

    def teardown_method(self):
        reload_components_yaml()


class TestSlotExtraction:
    def test_required_and_optional_slots(self, tmp_path):
        """Slots: {name} is required, {?name} is optional"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={"card.template": "@div\n  {title}\n  {?description}\n"},
        )
        reload_components_yaml(components_dir=comp_dir)

        slots = get_template_slot_names("card")
        slot_dict = dict(slots)
        assert "title" in slot_dict
        assert slot_dict["title"] is False  # required
        assert "description" in slot_dict
        assert slot_dict["description"] is True  # optional

    def teardown_method(self):
        reload_components_yaml()


class TestTemplateRendering:
    def test_render_with_template(self, tmp_path):
        """Component with template renders container + template interior"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card-wrapper\n"},
            template_files={"card.template": "@div class=card-inner\n  {title}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n  @title\n    Hello\n")

        assert "card-wrapper" in html
        assert "card-inner" in html
        assert "Hello" in html

    def test_required_slot_missing_shows_error(self, tmp_path):
        """Required slot not filled generates visible error"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={"card.template": "@div\n  {title}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n")

        assert "border-radius" in html
        assert "title" in html

    def test_optional_slot_missing_omits_silently(self, tmp_path):
        """Optional slot not filled produces no output and no error"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={"card.template": "@div\n  {?description}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n")

        assert "border-radius" not in html
        assert "{?description}" not in html

    def test_optional_wrapper_omitted_when_slot_empty(self, tmp_path):
        """Wrapper element with only optional slots is omitted when empty"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={
                "card.template": (
                    "@div class=icon-wrapper\n"
                    "  {?icon}\n"
                    "@div class=content\n"
                    "  {title}\n"
                )
            },
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n  @title\n    Title\n")

        assert "icon-wrapper" not in html
        assert "content" in html
        assert "Title" in html

    def test_unmatched_content_shows_error(self, tmp_path):
        """Content without matching slot generates visible error"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={"card.template": "@div\n  {title}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n  @title\n    Title\n  Texto solto\n")

        assert "border-radius" in html
        assert "Texto solto" in html

    def test_unmatched_tag_shows_error(self, tmp_path):
        """Tag not matching any slot generates visible error"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={"card.template": "@div\n  {title}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n  @title\n    Title\n  @extra\n    Extra\n")

        assert "border-radius" in html
        assert "@extra" in html

    def test_template_order_follows_template_not_seed(self, tmp_path):
        """Output order follows template definition, not .seed order"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={
                "card.template": (
                    "@div class=a\n  {first}\n"
                    "@div class=b\n  {second}\n"
                )
            },
        )
        seed = Seed(components_dir=comp_dir)
        # Intentionally reversed order in .seed
        html = seed.render_string("@card\n  @second\n    B\n  @first\n    A\n")

        pos_a = html.index("class=\"a\"")
        pos_b = html.index("class=\"b\"")
        assert pos_a < pos_b  # template order wins

    def test_duplicate_slot_in_template(self, tmp_path):
        """Same slot used twice in template renders in both places"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"card.yaml": "card:\n  tag: div\n  class: card\n"},
            template_files={
                "card.template": (
                    "@div class=mobile\n  {title}\n"
                    "@div class=desktop\n  {title}\n"
                )
            },
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card\n  @title\n    MyTitle\n")

        assert html.count("MyTitle") == 2

    def test_variant_applies_classes(self, tmp_path):
        """variant= prop applies modifier group classes to container"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={
                "card.yaml": (
                    "card:\n"
                    "  tag: div\n"
                    "  class: card-base\n"
                    "  variant:\n"
                    "    dark: bg-gray-900 text-white\n"
                )
            },
            template_files={"card.template": "@div class=inner\n  {title}\n"},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@card variant=dark\n  @title\n    Title\n")

        assert "bg-gray-900" in html
        assert "text-white" in html
        assert "card-base" in html

    def teardown_method(self):
        reload_components_yaml()


class TestSelfClosingTagWithTemplate:
    def test_self_closing_tag_with_template_raises(self, tmp_path):
        """self-closing tag + .template file = error at load time"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"image.yaml": "image:\n  tag: img\n  class: img-base\n"},
            template_files={"image.template": "@div\n  {src}\n"},
        )
        with pytest.raises(ValueError, match="self-closing"):
            reload_components_yaml(components_dir=comp_dir)

    def teardown_method(self):
        reload_components_yaml()


class TestSimpleComponentUnchanged:
    def test_simple_component_renders_as_tag(self, tmp_path):
        """Component without template renders as simple tag (no change)"""
        comp_dir = _make_component_dir(
            tmp_path,
            yaml_files={"h1.yaml": "h1:\n  tag: h1\n  class: text-3xl font-bold\n"},
            template_files={},
        )
        seed = Seed(components_dir=comp_dir)
        html = seed.render_string("@h1\n  Título\n")

        assert "<h1" in html
        assert "text-3xl" in html
        assert "Título" in html

    def teardown_method(self):
        reload_components_yaml()
