"""Tests for @@varname — page-level variable definitions and references."""
import pytest
from seed import Seed
from seed.parser import parse
from seed.nodes import VarRef, Component, Content


class TestLexerAndParser:
    """Parsing: definition removes from AST, use emits VarRef, vars stored in Page."""

    def test_definition_not_in_children(self):
        source = "@@foo\n  @h1\n    Oi"
        page = parse(source)
        assert len(page.children) == 0

    def test_definition_stored_in_page_vars(self):
        source = "@@foo\n  @h1\n    Oi"
        page = parse(source)
        assert "foo" in page.vars
        assert len(page.vars["foo"]) == 1
        assert isinstance(page.vars["foo"][0], Component)
        assert page.vars["foo"][0].name == "h1"

    def test_use_emits_varref(self):
        source = "@@foo\n  @h1\n    Oi\n@@foo"
        page = parse(source)
        assert len(page.children) == 1
        assert isinstance(page.children[0], VarRef)
        assert page.children[0].name == "foo"

    def test_definition_with_multiple_children(self):
        source = "@@bloco\n  @h1\n    Título\n  @p\n    Parágrafo"
        page = parse(source)
        assert "bloco" in page.vars
        assert len(page.vars["bloco"]) == 2

    def test_definition_with_text_content(self):
        source = "@@texto\n  Olá mundo"
        page = parse(source)
        assert "texto" in page.vars
        assert isinstance(page.vars["texto"][0], Content)
        assert "Olá mundo" in page.vars["texto"][0].text

    def test_multiple_definitions(self):
        source = "@@a\n  @p\n    A\n@@b\n  @p\n    B"
        page = parse(source)
        assert "a" in page.vars
        assert "b" in page.vars
        assert len(page.children) == 0

    def test_use_without_definition_emits_varref(self):
        """Using @@undefined still emits VarRef — renderer handles gracefully."""
        source = "@@nao-existe"
        page = parse(source)
        assert len(page.children) == 1
        assert isinstance(page.children[0], VarRef)
        assert page.children[0].name == "nao-existe"

    def test_definition_and_multiple_uses(self):
        source = "@@item\n  @p\n    X\n@@item\n@@item"
        page = parse(source)
        assert len(page.children) == 2
        assert all(isinstance(c, VarRef) for c in page.children)


class TestRendering:
    """Rendering: VarRef expands to HTML."""

    def setup_method(self):
        self.seed = Seed()

    def test_var_renders_children(self):
        source = "@@foo\n  @div\n    Conteúdo\n@@foo"
        html = self.seed.render_string(source)
        assert "<div>" in html
        assert "Conteúdo" in html

    def test_var_renders_twice(self):
        source = "@@foo\n  @p\n    Texto\n@@foo\n@@foo"
        html = self.seed.render_string(source)
        assert html.count("<p>") == 2
        assert html.count("Texto") == 2

    def test_undefined_var_renders_empty(self):
        source = "@@nao-existe"
        html = self.seed.render_string(source)
        assert html.strip() == ""

    def test_var_with_nested_components(self):
        source = "@@card\n  @div\n    @p\n      Dentro\n@@card"
        html = self.seed.render_string(source)
        assert "<div>" in html
        assert "<p>" in html
        assert "Dentro" in html

    def test_var_with_text_content(self):
        source = "@@frase\n  Olá mundo\n@@frase"
        html = self.seed.render_string(source)
        assert "Olá mundo" in html

    def test_definition_not_rendered(self):
        """The definition block itself produces no output."""
        source = "@@foo\n  @p\n    X\n@div\n  After"
        html = self.seed.render_string(source)
        assert html.count("<p>") == 0
        assert "After" in html

    def test_var_inside_component(self):
        source = "@@btn\n  @p\n    Clique\n@div\n  @@btn"
        html = self.seed.render_string(source)
        assert "<p>" in html
        assert "Clique" in html


class TestPreSerialization:
    """Inside @pre, @@var serializes back to .seed syntax instead of rendering."""

    def setup_method(self):
        self.seed = Seed()

    def _pre_content(self, source):
        html = self.seed.render_string(source)
        import re
        m = re.search(r"<pre[^>]*>(.*?)</pre>", html, re.DOTALL)
        return m.group(1) if m else None

    def test_var_in_pre_serializes(self):
        source = "@@ex\n  @h1\n    Título\n@pre\n  @@ex"
        content = self._pre_content(source)
        assert content is not None
        assert "@h1" in content
        assert "Título" in content

    def test_var_in_pre_does_not_render_html_tags(self):
        source = "@@ex\n  @h1\n    Título\n@pre\n  @@ex"
        content = self._pre_content(source)
        assert "<h1" not in content

    def test_undefined_var_in_pre_shows_literal_text(self):
        """@@varname inside @pre, with no definition, shows as literal text."""
        source = "@pre\n  @@minha-var\n    @h1\n      Título"
        content = self._pre_content(source)
        assert content is not None
        assert "@@minha-var" in content
        assert "@h1" in content

    def test_var_in_pre_preserves_props(self):
        source = "@@ex\n  @h1 variant=muted\n    Título\n@pre\n  @@ex"
        content = self._pre_content(source)
        assert "variant=muted" in content

    def test_var_in_pre_preserves_multiple_props(self):
        source = "@@ex\n  @button variant=primary, size=lg\n    OK\n@pre\n  @@ex"
        content = self._pre_content(source)
        assert "variant=primary" in content
        assert "size=lg" in content

    def test_var_in_pre_serializes_indented_children(self):
        source = "@@ex\n  @div\n    @p\n      Texto\n@pre\n  @@ex"
        content = self._pre_content(source)
        assert "@div" in content
        assert "@p" in content
        assert "Texto" in content

    def test_var_in_pre_escapes_special_chars(self):
        """If var children have text with <, >, &, they are escaped in pre."""
        source = "@@ex\n  @p\n    a < b\n@pre\n  @@ex"
        content = self._pre_content(source)
        # The @p header appears unescaped, but text content is escaped
        assert "&lt;" in content or "a < b" in content  # either escaped or literal

    def test_same_var_pre_and_render(self):
        """Same @@var: code in pre AND rendered as HTML on the page."""
        source = "@@ex\n  @p\n    Texto\n@pre\n  @@ex\n@@ex"
        html = self.seed.render_string(source)
        import re
        pre_content = re.search(r"<pre[^>]*>(.*?)</pre>", html, re.DOTALL)
        assert pre_content is not None
        assert "@p" in pre_content.group(1)
        assert "<h1" not in pre_content.group(1)
        assert html.count("<p>") >= 1


class TestPreSerializationInTemplate:
    """@@var inside a slot that maps to a @pre in a component template."""

    def _make_seed(self, tmp_path, template_str):
        from seed.components import reload_components_yaml
        comp_dir = tmp_path / "components"
        comp_dir.mkdir()
        (comp_dir / "showcase.yaml").write_text(
            "showcase:\n  tag: div\n  template: |\n" +
            "\n".join("    " + line for line in template_str.splitlines()) + "\n",
            encoding="utf-8",
        )
        reload_components_yaml(components_dir=comp_dir)
        return Seed(components_dir=comp_dir)

    def test_var_in_template_pre_slot_serializes(self, tmp_path):
        template = "@pre\n  {code}"
        s = self._make_seed(tmp_path, template)
        source = "@@ex\n  @h1\n    Título\n@showcase\n  @code\n    @@ex"
        html = s.render_string(source)
        import re
        pre = re.search(r"<pre[^>]*>(.*?)</pre>", html, re.DOTALL)
        assert pre is not None
        assert "@h1" in pre.group(1)
        assert "<h1" not in pre.group(1)

    def test_var_in_template_pre_slot_and_normal_render(self, tmp_path):
        """Same @@var used in template pre slot AND rendered normally elsewhere."""
        template = "@div\n  @pre\n    {code}\n  {?preview}"
        s = self._make_seed(tmp_path, template)
        source = "@@ex\n  @p\n    Olá\n@showcase\n  @code\n    @@ex\n  @preview\n    @@ex"
        html = s.render_string(source)
        import re
        pre = re.search(r"<pre[^>]*>(.*?)</pre>", html, re.DOTALL)
        assert pre is not None
        assert "@p" in pre.group(1)
        assert "<p>" in html
