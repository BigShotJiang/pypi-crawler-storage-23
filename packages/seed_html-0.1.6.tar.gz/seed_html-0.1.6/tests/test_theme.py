"""Tests for the components lib system."""
from pathlib import Path

import pytest

from seed import Seed
from seed.components import reload_components_yaml, _registry, _template_cache
from seed.cli import _load_project_config, copy_static_layered


# ─── Fixtures ────────────────────────────────────────────────────────────────

def _make_project(tmp_path: Path, with_src_layout=True) -> Path:
    """Create a minimal project structure."""
    project = tmp_path / "project"
    (project / "src" / "components").mkdir(parents=True)
    (project / "src" / "assets").mkdir()
    (project / "themes").mkdir(parents=True)
    if with_src_layout:
        (project / "src" / "default.layout").write_text(
            "---\ntitle: Test\n---\n@div\n  {content}\n", encoding="utf-8"
        )
    (project / "src" / "index.seed").write_text(
        "---\ntitle: Home\n---\nHello from index.\n", encoding="utf-8"
    )
    return project


def _make_components_lib(project: Path, name="seed-ui") -> Path:
    """Create a minimal component lib inside project/themes/<name>/."""
    lib = project / "themes" / name
    (lib / "components").mkdir(parents=True)
    (lib / "assets").mkdir()
    (lib / "components" / "libbutton.yaml").write_text(
        "libbutton:\n  tag: button\n  class: lib-button\n", encoding="utf-8"
    )
    return lib


def _write_seed_yaml(project: Path, **kwargs):
    import yaml
    (project / "seed.yaml").write_text(
        yaml.dump(kwargs, allow_unicode=True), encoding="utf-8"
    )


@pytest.fixture(autouse=True)
def reset_components():
    """Reset component registry before each test."""
    reload_components_yaml()
    yield
    reload_components_yaml()


# ─── 1. Sem libs — regressão ─────────────────────────────────────────────────

class TestNoLib:
    def test_render_without_lib(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "Hello from index." in html

    def test_layout_walkup_finds_src_layout(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "Hello from index." in html

    def test_no_theme_dir_attribute(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        assert seed.theme_dir is None


# ─── 2. Com lib de componentes ───────────────────────────────────────────────

class TestWithComponentsLib:
    def test_components_lib_loaded(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        lib = _make_components_lib(project)
        (project / "src" / "index.seed").write_text(
            "@libbutton\n  Click\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=lib)
        html = seed.render_file(project / "src" / "index.seed")
        assert "lib-button" in html

    def test_project_component_overrides_lib(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        lib = _make_components_lib(project)
        (project / "src" / "components" / "libbutton.yaml").write_text(
            "libbutton:\n  tag: a\n  class: project-button\n", encoding="utf-8"
        )
        (project / "src" / "index.seed").write_text(
            "@libbutton\n  Click\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=lib)
        html = seed.render_file(project / "src" / "index.seed")
        assert "project-button" in html


# ─── 3. Walk-up limitado ao src_dir ──────────────────────────────────────────

class TestWalkupLimited:
    def test_layout_outside_src_not_captured(self, tmp_path):
        """Layout in project root (outside src/) is not captured by walk-up."""
        project = _make_project(tmp_path, with_src_layout=False)
        (project / "default.layout").write_text(
            "---\ntitle: Outer\n---\n@div: class=outer-layout\n  {content}\n",
            encoding="utf-8",
        )
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=False)
        assert "outer-layout" not in html


# ─── 4. Cache de includes ────────────────────────────────────────────────────

class TestIncludeCache:
    def test_includes_cleared_between_renders(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        (project / "src" / "_header.seed").write_text(
            "@header: class=proj-header\n  Header\n", encoding="utf-8"
        )
        (project / "src" / "index.seed").write_text(
            "@include _header\nHello.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project)
        seed.render_file(project / "src" / "index.seed")
        assert len(seed.renderer.includes) > 0

        seed.renderer.clear_includes()
        assert len(seed.renderer.includes) == 0
        assert len(seed.renderer._include_paths) == 0

    def test_same_include_name_resolves_correctly(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        (project / "src" / "_header.seed").write_text(
            "@span: class=proj-hdr\n  ProjectHeader\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project)
        (project / "src" / "index.seed").write_text("@include _header\n", encoding="utf-8")
        html = seed.render_file(project / "src" / "index.seed")
        assert "proj-hdr" in html


# ─── 5. Troca de lib de componentes ──────────────────────────────────────────

class TestLibSwitch:
    def test_reload_components_clears_old_lib(self, tmp_path):
        lib_a = tmp_path / "lib_a"
        (lib_a / "components").mkdir(parents=True)
        (lib_a / "components" / "compA.yaml").write_text(
            "compA:\n  tag: div\n  class: comp-a\n", encoding="utf-8"
        )
        lib_b = tmp_path / "lib_b"
        (lib_b / "components").mkdir(parents=True)
        (lib_b / "components" / "compB.yaml").write_text(
            "compB:\n  tag: div\n  class: comp-b\n", encoding="utf-8"
        )

        reload_components_yaml(theme_dir=lib_a)
        assert "compA" in _registry
        assert "compB" not in _registry

        reload_components_yaml(theme_dir=lib_b)
        assert "compB" in _registry
        assert "compA" not in _registry


# ─── 6. Erros amigáveis ──────────────────────────────────────────────────────

class TestErrors:
    def test_seed_yaml_invalid_not_a_dict(self, tmp_path):
        project = _make_project(tmp_path)
        (project / "seed.yaml").write_text("- item1\n- item2\n", encoding="utf-8")
        with pytest.raises(ValueError, match="mapeamento YAML"):
            _load_project_config(project)

    def test_seed_yaml_theme_not_found(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="nonexistent")
        with pytest.raises(FileNotFoundError, match="nonexistent"):
            _load_project_config(project)

    def test_seed_yaml_path_traversal_rejected(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="../escape")
        with pytest.raises(ValueError, match="inválido"):
            _load_project_config(project)

    def test_seed_yaml_relative_path_with_separator_rejected(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="sub/mylib")
        with pytest.raises(ValueError, match="inválido"):
            _load_project_config(project)

    def test_no_seed_yaml_returns_none(self, tmp_path):
        project = _make_project(tmp_path)
        theme_lib_dir, js_mode, css_mode, minify, optimize_css = _load_project_config(project)
        assert theme_lib_dir is None
        assert js_mode == "file"
        assert css_mode == "file"
        assert minify is False
        assert optimize_css is True

    def test_seed_yaml_no_theme_key_returns_none(self, tmp_path):
        project = _make_project(tmp_path)
        (project / "seed.yaml").write_text("other_key: value\n", encoding="utf-8")
        theme_lib_dir, js_mode, css_mode, minify, optimize_css = _load_project_config(project)
        assert theme_lib_dir is None


# ─── 7. Static layered ───────────────────────────────────────────────────────

class TestStaticLayered:
    def test_no_lib_static_no_error(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        lib_static = tmp_path / "lib_static_nonexistent"
        copy_static_layered(dist, project_static, lib_static)

    def test_lib_static_copied_to_dist(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        lib_static = tmp_path / "lib_static"
        lib_static.mkdir()
        (lib_static / "lib.css").write_text("/* lib */", encoding="utf-8")

        copy_static_layered(dist, project_static, lib_static)
        assert (dist / "static" / "lib.css").is_file()

    def test_project_static_overrides_lib(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        lib_static = tmp_path / "lib_static"
        lib_static.mkdir()
        (lib_static / "style.css").write_text("/* lib */", encoding="utf-8")
        project_static = tmp_path / "static"
        project_static.mkdir()
        (project_static / "style.css").write_text("/* project */", encoding="utf-8")

        copy_static_layered(dist, project_static, lib_static)
        content = (dist / "static" / "style.css").read_text()
        assert "/* project */" in content

    def test_both_missing_no_dist_static_created(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        lib_static = tmp_path / "lib_no_static"

        copy_static_layered(dist, project_static, lib_static)
        assert not (dist / "static").exists()
