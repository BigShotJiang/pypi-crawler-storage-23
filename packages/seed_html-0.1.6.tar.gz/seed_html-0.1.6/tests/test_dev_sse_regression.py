from pathlib import Path

from seed import cli


def test_notify_help_uses_main_reload_stream():
    before = cli.reload_version
    cli.notify_help()
    assert cli.reload_version == before + 1
    assert cli.reload_message == b"event: help\ndata: open\n\n"


def test_reload_snippet_has_single_sse_channel():
    snippet = cli.RELOAD_SNIPPET
    assert b'new EventSource("/__reload")' in snippet
    assert b'EventSource("/__help")' not in snippet
    assert b'event: help' not in snippet
    assert b'CustomEvent("seed:help")' in snippet


def test_explorer_uses_window_event_instead_of_help_sse():
    explorer_js = (Path(cli.SEED_ENGINE_DIR) / "help" / "explorer.js").read_text(encoding="utf-8")
    assert "window.addEventListener('seed:help'" in explorer_js
    assert "new EventSource('/__help')" not in explorer_js
