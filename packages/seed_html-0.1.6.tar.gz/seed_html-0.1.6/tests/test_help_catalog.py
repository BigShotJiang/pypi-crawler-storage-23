from seed.components import reload_components_yaml
from seed.help.catalog import build_components_payload


def test_catalog_payload_includes_modifier_template_and_slot_counts(tmp_path):
    components_dir = tmp_path / "components"
    components_dir.mkdir()

    (components_dir / "button.yaml").write_text(
        "button:\n"
        "  tag: button\n"
        "  class: btn\n"
        "  variant:\n"
        "    solid: bg-blue-600\n"
        "    ghost: bg-transparent\n"
        "  size:\n"
        "    sm: text-sm\n"
        "    lg: text-lg\n",
        encoding="utf-8",
    )
    (components_dir / "card.yaml").write_text(
        "card:\n"
        "  tag: div\n"
        "  class: card\n"
        "  variant:\n"
        "    default: bg-white\n",
        encoding="utf-8",
    )
    (components_dir / "card.template").write_text(
        "@div\n"
        "  {title}\n"
        "  {?subtitle}\n",
        encoding="utf-8",
    )

    try:
        reload_components_yaml(components_dir=components_dir)
        payload = build_components_payload()
    finally:
        reload_components_yaml()

    items = {item["name"]: item for item in payload["components"]}

    button = items["button"]
    assert button["source_layer"] == "project"
    assert button["modifiers_count"] == 2
    assert set(button["modifier_groups"]) == {"variant", "size"}
    assert button["modifiers"] == {
        "variant": ["solid", "ghost"],
        "size": ["sm", "lg"],
    }
    assert button["templates_count"] == 0
    assert button["slots_count"] == 0

    card = items["card"]
    assert card["source_layer"] == "project"
    assert card["modifiers_count"] == 1
    assert card["modifier_groups"] == ["variant"]
    assert card["modifiers"] == {"variant": ["default"]}
    assert card["templates_count"] == 1
    assert card["slots_count"] == 2
    assert card["slots"] == [
        {"name": "title", "optional": False},
        {"name": "subtitle", "optional": True},
    ]
