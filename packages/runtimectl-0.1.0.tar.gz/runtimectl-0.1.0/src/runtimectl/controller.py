import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Generic, TypeVar, TypedDict


CtxT = TypeVar("CtxT")


class Command(TypedDict):
    id: str
    ts: float
    op: str
    path: str
    args: list[Any]
    kwargs: dict[str, Any]


class Ack(TypedDict, total=False):
    id: str
    ts: float
    op: str
    path: str
    status: str
    args: list[Any]
    kwargs: dict[str, Any]
    error: str


@dataclass
class _Control:
    apply_fn: Callable[..., None]
    validate_fn: Callable[[list[Any], dict[str, Any]], tuple[list[Any], dict[str, Any]]] | None = None


class RuntimeController(Generic[CtxT]):
    def __init__(self, queue_dir: str | None = None, *, ddp: bool = False):
        self.queue_dir: Path | None = None
        self.commands_path: Path | None = None
        self.acks_path: Path | None = None
        self.configured = False

        self._controls: dict[str, _Control] = {}
        self._last_poll_ts = 0.0
        self._read_offset = 0

        self.ddp = ddp

        if queue_dir is not None:
            self.configure(queue_dir)

    def configure(self, queue_dir: str) -> None:
        if self.configured:
            if self.queue_dir == Path(queue_dir):
                return
            raise ValueError(
                f"RuntimeController already configured with {self.queue_dir}"
            )
        q = Path(queue_dir)
        q.mkdir(parents=True, exist_ok=True)
        self.queue_dir = q
        self.commands_path = q / "commands.jsonl"
        self.acks_path = q / "acks.jsonl"
        self.commands_path.touch(exist_ok=True)
        self.acks_path.touch(exist_ok=True)
        self.configured = True


    def register(
        self,
        path: str,
        apply_fn: Callable[..., None],
        validate_fn: Callable[[list[Any], dict[str, Any]], tuple[list[Any], dict[str, Any]]] | None = None,
        *,
        overwrite: bool = False,
    ) -> None:
        if not path or not isinstance(path, str):
            raise ValueError("path must be a non-empty string")
        if path in self._controls and not overwrite:
            return
        self._controls[path] = _Control(apply_fn=apply_fn, validate_fn=validate_fn)

    def poll_and_apply(
        self, ctx: CtxT | None = None, every_s: float = 2.0
    ) -> list[Ack]:
        self._ensure_queue_ready()

        if self._is_ddp_active():
            # In DDP, every rank must enter the same collective each call.
            # Throttling is handled on rank 0 and the result is broadcast.
            instructions = self._ddp_collect_and_broadcast(every_s=every_s)
        else:
            now = time.time()
            if every_s > 0 and (now - self._last_poll_ts) < every_s:
                return []
            self._last_poll_ts = now
            instructions = self._read_new_commands_local()

        applied = []
        for cmd in instructions:
            result = self._apply_command(cmd, ctx)
            applied.append(result)
            if self._should_append_ack():
                self._append_ack(result)
        return applied

    def _ensure_queue_ready(self) -> None:
        if not self.configured or self.commands_path is None or self.acks_path is None:
            raise RuntimeError(
                "queue_dir is not set. Call configure(...) before poll_and_apply()."
            )

    def _is_ddp_active(self) -> bool:
        if not self.ddp:
            return False
        try:
            import torch.distributed as dist  # type: ignore

            return bool(dist.is_available() and dist.is_initialized())
        except Exception:
            return False

    def _ddp_collect_and_broadcast(self, every_s: float) -> list[Command]:
        import torch.distributed as dist  # type: ignore

        rank = dist.get_rank()
        payload: list[list[Command] | None] = [None]
        if rank == 0:
            now = time.time()
            if every_s > 0 and (now - self._last_poll_ts) < every_s:
                payload[0] = []
            else:
                self._last_poll_ts = now
                payload[0] = self._read_new_commands_local()
        dist.broadcast_object_list(payload, src=0)
        return payload[0] or []

    def _should_append_ack(self) -> bool:
        if not self._is_ddp_active():
            return True
        try:
            import torch.distributed as dist  # type: ignore

            return dist.get_rank() == 0
        except Exception:
            return True

    def _read_new_commands_local(self) -> list[Command]:
        self._ensure_queue_ready()
        assert self.commands_path is not None
        size = self.commands_path.stat().st_size
        if self._read_offset > size:
            self._read_offset = 0

        with self.commands_path.open("r", encoding="utf-8") as f:
            f.seek(self._read_offset)
            data = f.read()
            self._read_offset = f.tell()

        if not data:
            return []

        new_lines = data.splitlines()
        out = []
        for ln in new_lines:
            ln = ln.strip()
            if not ln:
                continue
            try:
                out.append(json.loads(ln))
            except json.JSONDecodeError:
                out.append(
                    {
                        "id": str(uuid.uuid4()),
                        "ts": time.time(),
                        "op": "invalid",
                        "path": "",
                        "value": None,
                        "_raw": ln,
                    }
                )
        return out

    def _apply_command(self, cmd: Command, ctx: CtxT | None) -> Ack:
        cmd_id = cmd.get("id") or str(uuid.uuid4())
        op = cmd.get("op", "set")
        path = cmd.get("path")
        args = cmd.get("args", [])
        kwargs = cmd.get("kwargs", {})

        base: Ack = {"id": cmd_id, "ts": time.time(), "path": path, "op": op}

        if not isinstance(args, list):
            return {**base, "status": "rejected", "error": "command args must be a list"}
        if not isinstance(kwargs, dict):
            return {**base, "status": "rejected", "error": "command kwargs must be an object"}

        if op != "set":
            return {**base, "status": "rejected", "error": f"unsupported op: {op}"}

        control = self._controls.get(path)
        if control is None:
            return {**base, "status": "rejected", "error": f"unknown path: {path}"}

        try:
            if control.validate_fn is not None:
                args, kwargs = control.validate_fn(args, kwargs)
            control.apply_fn(ctx, *args, **kwargs)
            return {**base, "status": "applied", "args": args, "kwargs": kwargs}
        except Exception as e:
            return {**base, "status": "failed", "error": str(e)}

    def _append_ack(self, ack: Ack) -> None:
        self._ensure_queue_ready()
        assert self.acks_path is not None
        with self.acks_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ack, ensure_ascii=False) + "\n")

    @staticmethod
    def enqueue(
        queue_dir: str,
        path: str,
        args: list[Any] | None = None,
        kwargs: dict[str, Any] | None = None,
        op: str = "set",
    ) -> Command:
        if args is not None and not isinstance(args, list):
            raise TypeError("args must be a list")
        if kwargs is not None and not isinstance(kwargs, dict):
            raise TypeError("kwargs must be a dict")

        qdir = Path(queue_dir)
        qdir.mkdir(parents=True, exist_ok=True)
        cmd: Command = {
            "id": str(uuid.uuid4()),
            "ts": time.time(),
            "op": op,
            "path": path,
            "args": args or [],
            "kwargs": kwargs or {},
        }
        commands_path = qdir / "commands.jsonl"
        with commands_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(cmd, ensure_ascii=False) + "\n")
        return cmd
