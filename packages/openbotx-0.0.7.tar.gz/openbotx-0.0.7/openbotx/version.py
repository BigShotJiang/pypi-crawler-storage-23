__version__ = "0.0.7"
__version_info__ = tuple(int(x) for x in __version__.split("-")[0].split("."))
