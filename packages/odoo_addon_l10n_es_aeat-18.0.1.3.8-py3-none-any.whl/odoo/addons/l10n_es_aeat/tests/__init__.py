from . import test_l10n_es_aeat
from . import test_l10n_es_aeat_certificate
from . import test_l10n_es_aeat_map_tax
from . import test_l10n_es_aeat_report
from . import test_l10n_es_aeat_export_config
from . import test_l10n_es_aeat_taxinfo
