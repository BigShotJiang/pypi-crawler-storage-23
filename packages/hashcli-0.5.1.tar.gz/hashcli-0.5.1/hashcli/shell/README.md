# Hashcli shell integration
