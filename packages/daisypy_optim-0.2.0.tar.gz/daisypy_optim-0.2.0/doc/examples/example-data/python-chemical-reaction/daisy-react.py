def charles(z, Theta, NO3, clay, below50):
    # param optimum at 0.1
    react = {param} * NO3
    return {{ "NO3" : -react, "CO2" : Theta }}
