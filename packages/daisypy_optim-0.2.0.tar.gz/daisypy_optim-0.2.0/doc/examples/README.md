# Optimization examples

* [Single objective with two parameters using CMA](single_objective_two_parameters_cma.py)
* [Single objective with python](single_objective_with_python.py)
