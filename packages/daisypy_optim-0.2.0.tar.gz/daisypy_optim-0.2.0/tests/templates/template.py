def linear(x):
    return {a} * x + {b}
