
import requests
def test_forward():
    proxies = {
        "http": "http://127.0.0.1:8080",
        # "https": "http://127.0.0.1:8081",
    }

    url = "http://127.0.0.1:8080/cam/api/ajax"
    r = requests.post(url,json={"which":"af"}).json()
    print (r)
    url = "http://127.0.0.1:8080/cam/api/test"
    r = requests.get(url).text
    print (r)
if __name__ == '__main__':
    test_forward()
