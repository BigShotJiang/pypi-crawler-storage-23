# reverse_proxy.py
from aiohttp import web, ClientSession, ClientTimeout
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import asyncio
import random
from typing import Callable


class ReverseProxy:
    """Reverse proxy with load balancing and health checking"""

    def __init__(self, router):
        self.router = router
        self.timeout = ClientTimeout(total=30)
        self.session: ClientSession = None

    async def start(self, app: web.Application) -> None:
        self.session = ClientSession(timeout=self.timeout)

    async def stop(self, app: web.Application) -> None:
        if self.session:
            await self.session.close()

    async def handle_request(self, request: web.Request) -> web.Response:
        """Forward request to a backend server"""
        # Build target URL

        backend = self.router(request.path)
        target_url = f"{backend}{request.path}"
        if request.query_string:
            target_url += f"?{request.query_string}"

        # Filter headers
        headers = {
            key: value
            for key, value in request.headers.items()
            if key.lower() not in HOP_BY_HOP_HEADERS
        }
        # Add forwarding headers
        headers['X-Forwarded-For'] = request.remote or ''
        headers['X-Forwarded-Proto'] = request.scheme
        headers['X-Forwarded-Host'] = request.host

        body = await request.read() if request.body_exists else None

        try:
            async with self.session.request(
                    method=request.method,
                    url=target_url,
                    headers=headers,
                    data=body,
                    allow_redirects=False
            ) as response:

                response_headers = {
                    key: value
                    for key, value in response.headers.items()
                    if key.lower() not in HOP_BY_HOP_HEADERS
                }
                response_body = await response.read()

                return web.Response(
                    status=response.status,
                    headers=response_headers,
                    body=response_body
                )

        except Exception as e:
            return web.json_response(
                {'error': 'Backend unavailable'},
                status=502
            )


HOP_BY_HOP_HEADERS = {
    'connection', 'keep-alive', 'proxy-authenticate',
    'proxy-authorization', 'te', 'trailers',
    'transfer-encoding', 'upgrade'
}


def create_reverse_proxy(router: Callable[[str], str]) -> web.Application:
    """Create reverse proxy application"""
    proxy = ReverseProxy(router)

    app = web.Application()
    app.on_startup.append(proxy.start)
    app.on_cleanup.append(proxy.stop)
    app.router.add_route('*', '/{path:.*}', proxy.handle_request)
    return app


def router(path: str) -> str:
    if path.startswith('/cam'):
        return "http://127.0.0.1:9011"
    else:
        return "http://127.0.0.1:9011"


if __name__ == '__main__':
    app = create_reverse_proxy(router)
    web.run_app(app, host='0.0.0.0', port=8080)
