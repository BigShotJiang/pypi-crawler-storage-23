import jinja2, os,base64,struct, glob, arrow, uuid, hashlib
from remote_run_everything.tools.crc16 import *

class Common1:

    def clear_by_days(self, root, n):
        files = glob.glob(f"{root}/*/*.*", recursive=True)
        now = arrow.now()
        for f in files:
            info = os.stat(f).st_mtime
            dif = now - arrow.get(info)
            if dif.days > n:
                os.remove(f)

    def str2uuid(self, s):
        hex_string = hashlib.md5(s.encode("UTF-8")).hexdigest()
        return str(uuid.UUID(hex=hex_string))

    def add_crc16(self,package: bytes) -> bytes:
        return add_crc16(package)

    def check_crc16(self,package: bytes) -> bool:
        return check_crc16(package)
    def is_in_poly(self,poly,p):
        # poly is list of point(x,y)
        px, py = p
        is_in = False
        for i, corner in enumerate(poly):
            next_i = i + 1 if i + 1 < len(poly) else 0
            x1, y1 = corner
            x2, y2 = poly[next_i]
            if (x1 == px and y1 == py) or (x2 == px and y2 == py):  # if point is on vertex
                is_in = True
                break
            if min(y1, y2) < py <= max(y1, y2):  # find horizontal edges of polygon
                x = x1 + (py - y1) * (x2 - x1) / (y2 - y1)
                if x == px:  # if point is on edge
                    is_in = True
                    break
                elif x > px:  # if point is on left-side of line
                    is_in = not is_in
        return is_in


if __name__ == '__main__':
    g = Common1()
