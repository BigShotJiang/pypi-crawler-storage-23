# mcpzoo-file-write

> 文件写入 — 将文本内容写入指定路径的文件

## Installation

```bash
uvx mcpzoo-file-write
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-write": {
      "args": ["mcpzoo-file-write"],
      "command": "uvx"
    }
  }
}
```
