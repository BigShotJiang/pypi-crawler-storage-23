"""Main entry point for barangay CLI."""

from barangay.cli import app

if __name__ == "__main__":
    app()
