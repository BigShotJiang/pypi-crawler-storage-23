Custom Matching
===============

This guide provides practical how-to instructions for customizing fuzzy matching behavior in the barangay package.

Matching Strategies
-------------------

The barangay package supports four matching strategies based on the combination of administrative levels.

Barangay Only (B)
~~~~~~~~~~~~~~~~~

Match against barangay names only:

.. code-block:: python

    from barangay import search

    # Match against barangay names only
    results = search(
        "Tongmageng",
        match_hooks=["barangay"],
        n=5
    )

    for result in results:
        print(f"{result['barangay']} (score: {result['f_000b_ratio_score']:.1f})")

Use cases:

* Searching when you only know the barangay name
* Finding barangays with similar names across different locations
* Quick searches when context is less important

Province + Barangay (PB)
~~~~~~~~~~~~~~~~~~~~~~~~

Match against province and barangay names:

.. code-block:: python

    from barangay import search

    # Match against province and barangay
    results = search(
        "Tongmageng, Tawi-Tawi",
        match_hooks=["province", "barangay"],
        n=5
    )

    for result in results:
        print(f"{result['barangay']}, {result['province_or_huc']} "
              f"(score: {result['f_0p0b_ratio_score']:.1f})")

Use cases:

* Searching with province context
* Disambiguating barangays with the same name
* When municipality information is missing

Municipality + Barangay (MB)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Match against municipality and barangay names:

.. code-block:: python

    from barangay import search

    # Match against municipality and barangay
    results = search(
        "Tongmageng, Sitangkai",
        match_hooks=["municipality", "barangay"],
        n=5
    )

    for result in results:
        print(f"{result['barangay']}, {result['municipality_or_city']} "
              f"(score: {result['f_00mb_ratio_score']:.1f})")

Use cases:

* Searching with municipality context
* When province information is not needed
* More specific than barangay-only, less specific than full address

Province + Municipality + Barangay (PMB)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Match against all three administrative levels:

.. code-block:: python

    from barangay import search

    # Match against all three levels (default)
    results = search(
        "Tongmageng, Sitangkai, Tawi-Tawi",
        match_hooks=["province", "municipality", "barangay"],
        n=5
    )

    for result in results:
        print(f"{result['barangay']}, {result['municipality_or_city']}, "
              f"{result['province_or_huc']} (score: {result['f_0pmb_ratio_score']:.1f})")

Use cases:

* Most specific matching
* When you have complete address information
* Highest accuracy for well-formed addresses

Custom Matching Strategies
--------------------------

Creating Custom Match Hooks
~~~~~~~~~~~~~~~~~~~~~~~~~~~

You can create custom matching strategies by combining different administrative levels:

.. code-block:: python

    from barangay import search

    # Create a custom matching strategy
    def custom_search(
        search_string: str,
        include_province: bool = True,
        include_municipality: bool = True,
        include_barangay: bool = True,
        **kwargs
    ):
        """Search with custom matching strategy.

        Args:
            search_string: String to search for
            include_province: Whether to include province in matching
            include_municipality: Whether to include municipality in matching
            include_barangay: Whether to include barangay in matching
            **kwargs: Additional arguments for search()
        """
        match_hooks = []
        if include_province:
            match_hooks.append("province")
        if include_municipality:
            match_hooks.append("municipality")
        if include_barangay:
            match_hooks.append("barangay")

        return search(search_string, match_hooks=match_hooks, **kwargs)

    # Example: Search with only municipality and barangay
    results = custom_search(
        "Tongmageng, Sitangkai",
        include_province=False,
        include_municipality=True,
        include_barangay=True,
        n=5
    )

    for result in results:
        # Get the maximum score from active matching strategies
        scores = [
            result.get('f_000b_ratio_score', 0),
            result.get('f_0p0b_ratio_score', 0),
            result.get('f_00mb_ratio_score', 0),
            result.get('f_0pmb_ratio_score', 0)
        ]
        score = max(scores)
        print(f"{result['barangay']}, {result['municipality_or_city']} "
              f"(score: {score:.1f})")

Weighted Matching
~~~~~~~~~~~~~~~~~

Implement weighted matching to prioritize certain administrative levels:

.. code-block:: python

    from barangay import search

    def weighted_search(
        search_string: str,
        province_weight: float = 1.0,
        municipality_weight: float = 1.0,
        barangay_weight: float = 1.0,
        n: int = 5
    ) -> list:
        """Search with weighted matching scores.

        Args:
            search_string: String to search for
            province_weight: Weight for province matching
            municipality_weight: Weight for municipality matching
            barangay_weight: Weight for barangay matching
            n: Number of results to return

        Returns:
            List of results with weighted scores
        """
        # Get results with all match hooks
        results = search(
            search_string,
            match_hooks=["province", "municipality", "barangay"],
            n=100,  # Get more results for better weighting
            threshold=0.0  # No threshold to get all results
        )

        # Calculate weighted scores
        for result in results:
            weighted_score = 0.0
            total_weight = 0.0

            if 'f_000b_ratio_score' in result:
                weighted_score += result['f_000b_ratio_score'] * barangay_weight
                total_weight += barangay_weight

            if 'f_0p0b_ratio_score' in result:
                weighted_score += result['f_0p0b_ratio_score'] * province_weight * barangay_weight
                total_weight += province_weight * barangay_weight

            if 'f_00mb_ratio_score' in result:
                weighted_score += result['f_00mb_ratio_score'] * municipality_weight * barangay_weight
                total_weight += municipality_weight * barangay_weight

            if 'f_0pmb_ratio_score' in result:
                weighted_score += result['f_0pmb_ratio_score'] * province_weight * municipality_weight * barangay_weight
                total_weight += province_weight * municipality_weight * barangay_weight

            result['weighted_score'] = weighted_score / total_weight if total_weight > 0 else 0.0

        # Sort by weighted score and return top n
        results.sort(key=lambda x: x['weighted_score'], reverse=True)
        return results[:n]

    # Example: Prioritize barangay matching
    results = weighted_search(
        "Tongmageng",
        province_weight=0.5,
        municipality_weight=0.5,
        barangay_weight=2.0,
        n=5
    )

    for result in results:
        print(f"{result['barangay']} (weighted score: {result['weighted_score']:.1f})")

Benchmarking and Comparison
---------------------------

Benchmarking Search Performance
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Compare performance of different search approaches:

.. code-block:: python

    import time
    from barangay import search, create_fuzz_base

    def benchmark_search(
        search_string: str,
        iterations: int = 100
    ) -> dict:
        """Benchmark search performance.

        Args:
            search_string: String to search for
            iterations: Number of iterations

        Returns:
            Dictionary with benchmark results
        """
        results = {}

        # Benchmark 1: Without pre-computation
        start_time = time.time()
        for _ in range(iterations):
            search(search_string, fuzz_base=None)
        time_without_precomp = (time.time() - start_time) / iterations
        results['without_precomputation'] = time_without_precomp

        # Benchmark 2: With pre-computation
        fuzz_base = create_fuzz_base()
        start_time = time.time()
        for _ in range(iterations):
            search(search_string, fuzz_base=fuzz_base)
        time_with_precomp = (time.time() - start_time) / iterations
        results['with_precomputation'] = time_with_precomp

        # Calculate speedup
        speedup = time_without_precomp / time_with_precomp
        results['speedup'] = speedup

        return results

    # Run benchmark
    benchmark = benchmark_search("Tongmageng, Tawi-Tawi", iterations=100)

    print("Benchmark Results:")
    print(f"  Without pre-computation: {benchmark['without_precomputation']*1000:.2f} ms")
    print(f"  With pre-computation: {benchmark['with_precomputation']*1000:.2f} ms")
    print(f"  Speedup: {benchmark['speedup']:.1f}x")

Comparing Matching Strategies
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Compare accuracy of different matching strategies:

.. code-block:: python

    from barangay import search

    def compare_strategies(
        search_string: str,
        expected_barangay: str
    ) -> dict:
        """Compare different matching strategies.

        Args:
            search_string: String to search for
            expected_barangay: Expected barangay name

        Returns:
            Dictionary with comparison results
        """
        strategies = {
            'B (Barangay only)': ["barangay"],
            'PB (Province + Barangay)': ["province", "barangay"],
            'MB (Municipality + Barangay)': ["municipality", "barangay"],
            'PMB (All three)': ["province", "municipality", "barangay"]
        }

        results = {}
        for name, hooks in strategies.items():
            matches = search(search_string, match_hooks=hooks, n=1)
            if matches:
                is_correct = matches[0]['barangay'] == expected_barangay
                # Get the maximum score from active matching strategies
                scores = [
                    matches[0].get('f_000b_ratio_score', 0),
                    matches[0].get('f_0p0b_ratio_score', 0),
                    matches[0].get('f_00mb_ratio_score', 0),
                    matches[0].get('f_0pmb_ratio_score', 0)
                ]
                score = max(scores)
                results[name] = {
                    'found': True,
                    'is_correct': is_correct,
                    'score': score,
                    'matched_barangay': matches[0]['barangay']
                }
            else:
                results[name] = {
                    'found': False,
                    'is_correct': False,
                    'score': None,
                    'matched_barangay': None
                }

        return results

    # Compare strategies
    comparison = compare_strategies("Tongmageng, Tawi-Tawi", "Tongmageng")

    print("Matching Strategy Comparison:")
    for strategy, result in comparison.items():
        status = "✓" if result['is_correct'] else "✗"
        print(f"  {status} {strategy}:")
        print(f"      Score: {result['score']:.1f}" if result['score'] else "      Score: N/A")
        print(f"      Matched: {result['matched_barangay']}" if result['matched_barangay'] else "      Matched: None")