"""
ForgeMemoryPlugin — Demonstration HookPlugin for the Forge integration pattern.

Shows how a plugin wires antaris-guard (threat screening) and antaris-memory
(session recall / persistence) into the pipeline lifecycle using HookPlugin.

Both antaris-guard and antaris-memory are optional dependencies.  If either is
absent, the relevant step is skipped with a log warning so the plugin is always
safe to install regardless of environment.
"""

from __future__ import annotations

import gc
import logging
import time
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from .hooks import HookPhase, HookContext, HookResult, HookPlugin

if TYPE_CHECKING:
    from .hooks import PipelineHooks

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional dependency guards
# ---------------------------------------------------------------------------

try:
    from antaris_guard import PromptGuard, GuardResult  # type: ignore[import]
    _GUARD_AVAILABLE = True
except ImportError:
    _GUARD_AVAILABLE = False
    logger.warning(
        "antaris-guard not installed — ForgeMemoryPlugin will skip Guard screening. "
        "Install antaris-guard to enable threat detection."
    )

try:
    import antaris_memory  # type: ignore[import]
    _MEMORY_AVAILABLE = True
except ImportError:
    _MEMORY_AVAILABLE = False
    logger.warning(
        "antaris-memory not installed — ForgeMemoryPlugin will skip memory recall/save. "
        "Install antaris-memory to enable session persistence."
    )


# ---------------------------------------------------------------------------
# ForgeMemoryPlugin
# ---------------------------------------------------------------------------

class ForgeMemoryPlugin(HookPlugin):
    """Demonstrates the Forge integration pattern using HookPlugin.

    Lifecycle:
    * SESSION_START  — initializes memory recall for the session
    * BEFORE_LLM     — runs Guard screening + injects recalled context
    * SESSION_END    — saves memory, triggers GC

    Usage::

        from antaris_pipeline.forge_plugin import ForgeMemoryPlugin
        from antaris_pipeline.hooks import PipelineHooks

        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin(agent_id="forge-user-42")
        hooks.register_plugin(plugin)

        # Later, to clean up:
        hooks.unregister_plugin(plugin)
    """

    def __init__(
        self,
        agent_id: str = "",
        guard_config: Optional[Dict[str, Any]] = None,
        memory_config: Optional[Dict[str, Any]] = None,
        max_sessions: int = 1000,
        session_ttl_seconds: float = 86400.0,  # 24 hours
    ) -> None:
        self._agent_id = agent_id
        self._guard_config: Dict[str, Any] = guard_config or {}
        self._memory_config: Dict[str, Any] = memory_config or {}
        self._max_sessions = max_sessions
        self._session_ttl = session_ttl_seconds

        # D-1: Store (memories, timestamp) tuples so stale sessions can be pruned.
        # Without TTL, crash/timeout sessions that never receive SESSION_END would
        # accumulate indefinitely in long-running Forge deployments.
        self._session_memories: Dict[str, Tuple[Any, float]] = {}

        # Build guard instance once if available
        self._guard: Optional[Any] = None
        if _GUARD_AVAILABLE:
            try:
                self._guard = PromptGuard(**self._guard_config)  # type: ignore[call-arg]
            except Exception as exc:
                logger.warning("ForgeMemoryPlugin: could not initialise PromptGuard: %s", exc)

    # ------------------------------------------------------------------
    # HookPlugin API
    # ------------------------------------------------------------------

    def install(self, hooks: "PipelineHooks") -> None:
        """Register all hooks in one call."""
        hooks.register(
            HookPhase.SESSION_START,
            self._on_session_start,
            name=f"{self.name}.session_start",
            priority=10,
        )
        hooks.register(
            HookPhase.BEFORE_LLM,
            self._on_before_llm,
            name=f"{self.name}.before_llm",
            priority=10,
        )
        hooks.register(
            HookPhase.SESSION_END,
            self._on_session_end,
            name=f"{self.name}.session_end",
            priority=90,  # late — let other hooks run first
        )
        logger.debug("ForgeMemoryPlugin installed (guard=%s, memory=%s)", _GUARD_AVAILABLE, _MEMORY_AVAILABLE)

    def uninstall(self, hooks: "PipelineHooks") -> None:
        """Remove all registered hooks."""
        for phase, suffix in (
            (HookPhase.SESSION_START, "session_start"),
            (HookPhase.BEFORE_LLM, "before_llm"),
            (HookPhase.SESSION_END, "session_end"),
        ):
            hooks.unregister(phase, f"{self.name}.{suffix}")
        logger.debug("ForgeMemoryPlugin uninstalled")

    # ------------------------------------------------------------------
    # Hook callbacks
    # ------------------------------------------------------------------

    def _prune_stale_sessions(self) -> None:
        """D-1: Evict sessions that exceeded TTL or breach the max_sessions cap."""
        now = time.time()
        # Evict by TTL first
        stale = [sid for sid, (_, ts) in self._session_memories.items()
                 if now - ts > self._session_ttl]
        for sid in stale:
            del self._session_memories[sid]
            logger.debug("ForgeMemoryPlugin: pruned stale session %s", sid)
        # Evict oldest if still over cap
        while len(self._session_memories) >= self._max_sessions:
            oldest = min(self._session_memories, key=lambda sid: self._session_memories[sid][1])
            del self._session_memories[oldest]
            logger.warning("ForgeMemoryPlugin: max_sessions cap hit, evicted session %s", oldest)

    def _on_session_start(self, ctx: HookContext) -> HookResult:
        """SESSION_START — initialise memory recall for this session."""
        session_id = ctx.session_id
        recalled: Dict[str, Any] = {}

        # D-1: Prune stale sessions before adding a new one
        self._prune_stale_sessions()

        if _MEMORY_AVAILABLE:
            try:
                recalled = antaris_memory.recall(  # type: ignore[attr-defined]
                    session_id=session_id,
                    agent_id=self._agent_id or ctx.agent_id,
                    **self._memory_config,
                )
                self._session_memories[session_id] = (recalled, time.time())
                logger.debug("Memory recalled for session %s: %d entries", session_id, len(recalled))
            except Exception as exc:
                logger.warning("ForgeMemoryPlugin: memory recall failed for %s: %s", session_id, exc)
        else:
            logger.debug("ForgeMemoryPlugin: antaris-memory unavailable, skipping recall")

        return HookResult(success=True, data={"memories": recalled})

    def _on_before_llm(self, ctx: HookContext) -> HookResult:
        """BEFORE_LLM — Guard screening + context injection."""
        query = ctx.data.get("query", "")
        injected_context: Dict[str, Any] = {}
        blocked = False
        guard_message = ""

        # --- Guard screening ---
        if self._guard is not None:
            try:
                guard_result = self._guard.analyze(query)
                if guard_result.is_blocked:
                    blocked = True
                    guard_message = guard_result.message
                    logger.warning(
                        "ForgeMemoryPlugin: Guard blocked query for session %s: %s",
                        ctx.session_id,
                        guard_message,
                    )
            except Exception as exc:
                logger.warning("ForgeMemoryPlugin: Guard screening error: %s", exc)
        elif not _GUARD_AVAILABLE:
            logger.debug("ForgeMemoryPlugin: antaris-guard unavailable, skipping screening")

        if blocked:
            return HookResult(
                success=False,
                error=guard_message,
                abort=True,
                data={"blocked": True, "reason": guard_message},
            )

        # --- Context injection from recalled memories ---
        session_entry = self._session_memories.get(ctx.session_id)
        session_memories = session_entry[0] if session_entry else {}
        if session_memories:
            injected_context["recalled_memories"] = session_memories

        return HookResult(success=True, data={"injected_context": injected_context, "blocked": False})

    def _on_session_end(self, ctx: HookContext) -> HookResult:
        """SESSION_END — persist memory + trigger GC."""
        session_id = ctx.session_id

        # --- Save memory ---
        if _MEMORY_AVAILABLE:
            entry = self._session_memories.pop(session_id, None)
            memories_to_save = entry[0] if entry else {}
            try:
                antaris_memory.save(  # type: ignore[attr-defined]
                    session_id=session_id,
                    agent_id=self._agent_id or ctx.agent_id,
                    data=memories_to_save,
                    **self._memory_config,
                )
                logger.debug("Memory saved for session %s", session_id)
            except Exception as exc:
                logger.warning("ForgeMemoryPlugin: memory save failed for %s: %s", session_id, exc)
        else:
            self._session_memories.pop(session_id, None)
            logger.debug("ForgeMemoryPlugin: antaris-memory unavailable, skipping save")

        # --- Garbage collect ---
        gc.collect()
        logger.debug("ForgeMemoryPlugin: GC triggered for session %s", session_id)

        return HookResult(success=True, data={"session_id": session_id})
