"""Tests for PipelineTelemetry dataclass (v4.2.0)."""

import time
import pytest
from antaris_pipeline import PipelineTelemetry
from antaris_pipeline.telemetry import PipelineTelemetry as _TelDirect


# ---------------------------------------------------------------------------
# Basic construction
# ---------------------------------------------------------------------------

class TestPipelineTelemetryConstruction:
    def test_importable_from_top_level(self):
        assert PipelineTelemetry is _TelDirect

    def test_basic_construction(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="test-run-1",
            started_at=now,
            finished_at=now + 0.145,
            total_ms=145.0,
            stage_timings={"recall": 12.3, "guard_input": 5.1},
            tokens_used=342,
            cost_usd=0.001,
            blocked=False,
            error=None,
        )
        assert tel.run_id == "test-run-1"
        assert tel.total_ms == 145.0
        assert tel.tokens_used == 342
        assert tel.cost_usd == 0.001
        assert tel.blocked is False
        assert tel.error is None

    def test_defaults(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="x",
            started_at=now,
            finished_at=now + 0.1,
            total_ms=100.0,
        )
        assert tel.stage_timings == {}
        assert tel.tokens_used == 0
        assert tel.cost_usd == 0.0
        assert tel.blocked is False
        assert tel.error is None

    def test_with_error(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="err-run",
            started_at=now,
            finished_at=now + 0.05,
            total_ms=50.0,
            error="Something went wrong",
        )
        assert tel.error == "Something went wrong"

    def test_blocked_flag(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="blocked-run",
            started_at=now,
            finished_at=now + 0.01,
            total_ms=10.0,
            blocked=True,
        )
        assert tel.blocked is True


# ---------------------------------------------------------------------------
# slowest_stage()
# ---------------------------------------------------------------------------

class TestSlowestStage:
    def test_returns_tuple(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.1,
            total_ms=100.0,
            stage_timings={"recall": 50.0, "guard_input": 5.0, "context": 30.0},
        )
        result = tel.slowest_stage()
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_returns_correct_slowest(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.1,
            total_ms=100.0,
            stage_timings={"recall": 50.0, "guard_input": 5.0, "context": 30.0},
        )
        name, ms = tel.slowest_stage()
        assert name == "recall"
        assert ms == 50.0

    def test_single_stage(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.02,
            total_ms=20.0,
            stage_timings={"ingest": 20.0},
        )
        name, ms = tel.slowest_stage()
        assert name == "ingest"
        assert ms == 20.0

    def test_empty_stage_timings(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.005,
            total_ms=5.0,
        )
        name, ms = tel.slowest_stage()
        assert name == ""
        assert ms == 0.0

    def test_all_same_duration(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.05,
            total_ms=50.0,
            stage_timings={"a": 10.0, "b": 10.0, "c": 10.0},
        )
        name, ms = tel.slowest_stage()
        assert ms == 10.0
        assert name in ("a", "b", "c")


# ---------------------------------------------------------------------------
# summary()
# ---------------------------------------------------------------------------

class TestSummary:
    def test_returns_string(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.145,
            total_ms=145.0,
            stage_timings={"recall": 12.3, "guard_input": 5.1},
            tokens_used=342,
        )
        result = tel.summary()
        assert isinstance(result, str)

    def test_contains_total_ms(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.145,
            total_ms=145.0,
            stage_timings={"recall": 12.3},
            tokens_used=100,
        )
        summary = tel.summary()
        assert "145" in summary

    def test_contains_token_count(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.1,
            total_ms=100.0,
            tokens_used=342,
        )
        summary = tel.summary()
        assert "342" in summary

    def test_contains_stage_names(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.1,
            total_ms=100.0,
            stage_timings={"recall": 12.3, "guard_input": 5.1},
            tokens_used=0,
        )
        summary = tel.summary()
        assert "recall" in summary
        assert "guard_input" in summary

    def test_single_line(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="r",
            started_at=now,
            finished_at=now + 0.05,
            total_ms=50.0,
            stage_timings={"ingest": 10.0},
            tokens_used=100,
        )
        summary = tel.summary()
        assert "\n" not in summary


# ---------------------------------------------------------------------------
# Stage timings keys — must match expected stage names
# ---------------------------------------------------------------------------

class TestStageTimingKeys:
    """Verify that stage_timings produced by AgentPipeline use the canonical names."""

    EXPECTED_PRE_TURN_STAGES = {"guard_input", "recall", "context", "routing"}
    EXPECTED_POST_TURN_STAGES = {"guard_output", "ingest"}

    def test_pre_turn_stage_keys_are_known(self):
        """Stage timings from pre_turn should only include known stage names."""
        now = time.time()
        # Simulate what AgentPipeline would produce for a typical pre-turn
        tel = PipelineTelemetry(
            run_id="sim",
            started_at=now,
            finished_at=now + 0.05,
            total_ms=50.0,
            stage_timings={"guard_input": 2.1, "recall": 12.3, "context": 5.0, "routing": 1.5},
        )
        for key in tel.stage_timings:
            assert key in self.EXPECTED_PRE_TURN_STAGES, f"Unexpected stage key: {key}"

    def test_post_turn_stage_keys_are_known(self):
        """Stage timings from post_turn should only include known stage names."""
        now = time.time()
        tel = PipelineTelemetry(
            run_id="sim2",
            started_at=now,
            finished_at=now + 0.02,
            total_ms=20.0,
            stage_timings={"guard_output": 1.9, "ingest": 8.4},
        )
        for key in tel.stage_timings:
            assert key in self.EXPECTED_POST_TURN_STAGES, f"Unexpected stage key: {key}"

    def test_stage_timings_are_floats(self):
        now = time.time()
        tel = PipelineTelemetry(
            run_id="sim3",
            started_at=now,
            finished_at=now + 0.05,
            total_ms=50.0,
            stage_timings={"recall": 12.3, "context": 5.0},
        )
        for key, val in tel.stage_timings.items():
            assert isinstance(val, (int, float)), f"Stage timing for {key} should be numeric"
            assert val >= 0.0, f"Stage timing for {key} should be non-negative"
