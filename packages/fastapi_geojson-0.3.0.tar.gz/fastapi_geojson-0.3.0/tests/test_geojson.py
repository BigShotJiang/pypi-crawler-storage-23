from fastapi.testclient import TestClient
from examples.geojson_example import app

client = TestClient(app)

def test_points_geojson():
    response = client.get("/geojson/points")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/geo+json"
    data = response.json()
    assert data["type"] == "FeatureCollection"
    assert len(data["features"]) > 0
    assert data["features"][0]["geometry"]["type"] == "Point"

def test_lines_geojson():
    response = client.get("/geojson/lines")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/geo+json"
    data = response.json()
    assert data["features"][0]["geometry"]["type"] == "LineString"

def test_polygons_geojson():
    response = client.get("/geojson/polygons")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/geo+json"
    data = response.json()
    assert data["features"][0]["geometry"]["type"] == "Polygon"