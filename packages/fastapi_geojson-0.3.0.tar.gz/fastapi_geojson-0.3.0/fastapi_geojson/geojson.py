from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator
from typing import Any, Dict, List, Literal, Union, Optional

class GeoJSONResponse(JSONResponse):
    """
    GeoJSON response class.
    Sets the Content-Type header to 'application/geo+json'.
    """
    media_type = "application/geo+json"

class GeometryBase(BaseModel):
    type: str

class PointModel(GeometryBase):
    type: Literal["Point"] = "Point"
    coordinates: List[float]

    @field_validator("coordinates")
    @classmethod
    def validate_coordinates(cls, v):
        if len(v) not in (2, 3):
            raise ValueError("Point coordinates must have 2 or 3 values [lon, lat] or [lon, lat, altitude]")
        return v

class LineStringModel(GeometryBase):
    type: Literal["LineString"] = "LineString"
    coordinates: List[List[float]]

class PolygonModel(GeometryBase):
    type: Literal["Polygon"] = "Polygon"
    coordinates: List[List[List[float]]]

class GeometryCollectionModel(GeometryBase):
    type: Literal["GeometryCollection"] = "GeometryCollection"
    geometries: List[Union[PointModel, LineStringModel, PolygonModel]]

GeometryType = Union[PointModel, LineStringModel, PolygonModel, GeometryCollectionModel]

class FeatureModel(BaseModel):
    type: Literal["Feature"] = "Feature"
    id: Optional[Union[str, float]] = None
    geometry: Optional[GeometryType] = None
    properties: Dict[str, Any] = Field(default_factory=dict)

class FeatureCollectionModel(BaseModel):
    type: Literal["FeatureCollection"] = "FeatureCollection"
    features: List[FeatureModel]

def feature_from_point(lat: float, lon: float, properties: Optional[Dict[str, Any]] = None) -> FeatureModel:
    """Create a GeoJSON Feature from lat/lon. Note: stored internally as [lon, lat] per GeoJSON spec."""
    return FeatureModel(
        geometry=PointModel(coordinates=[lon, lat]),
        properties=properties or {}
    )

def feature_from_linestring(coords: List[List[float]], properties: Optional[Dict[str, Any]] = None) -> FeatureModel:
    return FeatureModel(
        geometry=LineStringModel(coordinates=coords),
        properties=properties or {}
    )

def feature_from_polygon(coords: List[List[List[float]]], properties: Optional[Dict[str, Any]] = None) -> FeatureModel:
    return FeatureModel(
        geometry=PolygonModel(coordinates=coords),
        properties=properties or {}
    )