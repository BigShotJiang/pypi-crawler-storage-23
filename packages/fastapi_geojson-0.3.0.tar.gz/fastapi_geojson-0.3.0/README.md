# FastAPI GeoJSON

A lightweight Python package to generate **GeoJSON responses** easily in **FastAPI** applications.

---

## Features

- `GeoJSONResponse` for FastAPI endpoints
- Create GeoJSON Features:
  - `feature_from_point`
  - `feature_from_linestring`
  - `feature_from_polygon`
- Supports **FeatureCollection** out-of-the-box
- Fully compatible with FastAPI response models

---

## Installation
```bash
pip install fastapi-geojson
```

---

## Usage

### Points
```python
from fastapi import FastAPI
from fastapi_geojson import (
    GeoJSONResponse,
    FeatureCollectionModel,
    feature_from_point,
)

app = FastAPI()

locations = [
    {"name": "Cairo", "lat": 30.0444, "lon": 31.2357},
    {"name": "Alexandria", "lat": 31.2001, "lon": 29.9187},
]

@app.get("/geojson/points", response_class=GeoJSONResponse)
def get_points():
    features = [
        feature_from_point(loc["lat"], loc["lon"], {"name": loc["name"]})
        for loc in locations
    ]
    return FeatureCollectionModel(features=features).model_dump()
```

### Lines
```python
from fastapi_geojson import GeoJSONResponse, FeatureCollectionModel, feature_from_linestring

roads = [
    {"name": "Road 1", "coords": [[31.2357, 30.0444], [31.2400, 30.0500]]},
    {"name": "Road 2", "coords": [[29.9187, 31.2001], [29.9250, 31.2100]]},
]

@app.get("/geojson/lines", response_class=GeoJSONResponse)
def get_lines():
    features = [
        feature_from_linestring(road["coords"], {"name": road["name"]})
        for road in roads
    ]
    return FeatureCollectionModel(features=features).model_dump()
```

### Polygons
```python
from fastapi_geojson import GeoJSONResponse, FeatureCollectionModel, feature_from_polygon

areas = [
    {
        "name": "Park",
        "coords": [[[31.2300, 30.0400], [31.2350, 30.0400], [31.2350, 30.0450], [31.2300, 30.0450], [31.2300, 30.0400]]],
    }
]

@app.get("/geojson/polygons", response_class=GeoJSONResponse)
def get_polygons():
    features = [
        feature_from_polygon(area["coords"], {"name": area["name"]})
        for area in areas
    ]
    return FeatureCollectionModel(features=features).model_dump()
```

---

## Response Format

All endpoints return a valid GeoJSON `FeatureCollection` with `Content-Type: application/geo+json`:
```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [31.2357, 30.0444]
      },
      "properties": {
        "name": "Cairo"
      }
    }
  ]
}
```

---

## License

MIT