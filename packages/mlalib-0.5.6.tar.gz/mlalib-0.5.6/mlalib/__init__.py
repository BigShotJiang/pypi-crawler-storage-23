"""
For the love of exploring intelligence.
"""

from . import utils
from . import tabular

__version__ = "0.5.6"
__author__ = "MLA"

__all__ = ["tabular", "utils"]
