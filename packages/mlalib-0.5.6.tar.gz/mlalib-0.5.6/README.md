# mlalib

A research-oriented PyTorch companion for rapidly experimenting with ideas in machine learning.

## Installation

```bash
pip install mlalib