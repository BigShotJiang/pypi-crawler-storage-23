from .viewer import GameViewer, show_replay

# Backwards compatibility alias
Replay = GameViewer

__all__ = ["show_replay", "GameViewer", "Replay"]
