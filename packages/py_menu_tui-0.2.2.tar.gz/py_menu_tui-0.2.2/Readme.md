# py_menu_tui

`py_menu_tui` is a lightweight **terminal user interface (TUI) navigation framework** for Python.  
It allows developers to quickly build interactive command-line menus with keyboard navigation and nested subsections.

The interface is controlled using simple keys and is designed for **Windows terminals** using `msvcrt`.

---

# Features

- Keyboard navigation (`w` / `s`)
- Nested menu sections
- Simple function binding to menu entries
- Scrollable menus
- Progress bar utility
- Confirmation prompts
- No external dependencies

---

# Installation

Currently the package can be installed with:

```bash
pip install py_menu_tui

Controls
Key	Action
w	Move up
s	Move down
Enter	Select option
Esc	Go back
Ctrl+C	Exit program
```
```python
Example
from py_menu-tui import UserInterface

def hello():
    print("Hello World")

ui = UserInterface(10)

ui.setup(
    ["Say Hello"],
    [hello]
)

ui.begin()
Creating Subsections
ui.add_sub_section(
    ["Option 1", "Option 2"],
    [func1, func2],
    section="Settings"
)
Utilities
Progress Bar
from win_nav_tui import progressbar

progressbar(50)
Clear Terminal
from win_nav_tui import clear
Confirmation Prompt
from win_nav_tui import confirm

if confirm("Continue?"):
    print("Confirmed")
``` 

## Requirements

- Python 3+
- Windows terminal (uses `msvcrt`)
- No external dependencies

## License

This project is licensed under the **MIT License**.