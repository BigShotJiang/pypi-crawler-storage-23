"""
Layer 4: TF-IDF Rare Term Boost — test suite.

Covers:
- _rarity_boost() tiers (empty index, unknown term, 1%, 5%, 15%, >15%)
- _is_proper_noun() heuristic (capitalized_terms detection)
- Proper-noun boost integration in search() ranking
- Rare-term boost integration in search() ranking
- capitalized_terms extraction from query
- Combined rarity + proper-noun boost
- Edge cases (single doc, all docs, case sensitivity, punctuation in query)
"""

import unittest
from collections import Counter

from antaris_memory import SearchEngine
from antaris_memory.entry import MemoryEntry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_engine(memories):
    """Build and return a SearchEngine with index built over *memories*."""
    eng = SearchEngine()
    eng.build_index(memories)
    return eng


def make_memory(content, source="test", confidence=1, category="general"):
    return MemoryEntry(content, source, confidence, category)


# ---------------------------------------------------------------------------
# 1. _rarity_boost() — unit tests
# ---------------------------------------------------------------------------

class TestRarityBoostUnit(unittest.TestCase):

    def _engine_with_docs(self, n_docs, term_in_k_docs, term="alpha"):
        """Build a tiny SearchEngine where *term* appears in exactly k docs."""
        memories = []
        for i in range(n_docs):
            if i < term_in_k_docs:
                memories.append(make_memory(f"{term} document content word"))
            else:
                memories.append(make_memory(f"other document content here"))
        return make_engine(memories), term

    def test_empty_index_returns_1(self):
        """_rarity_boost on an empty index should default to 1.0."""
        eng = SearchEngine()
        # No build_index called → _doc_count == 0
        self.assertEqual(eng._rarity_boost("anything"), 1.0)

    def test_unknown_term_returns_max_boost(self):
        """A term not in corpus at all is treated as maximally rare → 2.0."""
        memories = [make_memory("hello world example")]
        eng = make_engine(memories)
        # "zzz" definitely not in corpus
        self.assertEqual(eng._rarity_boost("zzz"), 2.0)

    def test_tier_very_rare_1_percent(self):
        """Term in ≤1% of docs → boost 2.0."""
        # 200 docs, term in 1 → 0.5%
        eng, term = self._engine_with_docs(200, 1)
        self.assertEqual(eng._rarity_boost(term), 2.0)

    def test_tier_rare_5_percent(self):
        """Term in 1–5% of docs → boost 1.5."""
        # 100 docs, term in 3 → 3%
        eng, term = self._engine_with_docs(100, 3)
        self.assertEqual(eng._rarity_boost(term), 1.5)

    def test_tier_moderate_15_percent(self):
        """Term in 5–15% of docs → boost 1.2."""
        # 100 docs, term in 10 → 10%
        eng, term = self._engine_with_docs(100, 10)
        self.assertEqual(eng._rarity_boost(term), 1.2)

    def test_tier_common_over_15_percent(self):
        """Term in >15% of docs → boost 1.0 (no boost)."""
        # 100 docs, term in 50 → 50%
        eng, term = self._engine_with_docs(100, 50)
        self.assertEqual(eng._rarity_boost(term), 1.0)

    def test_exact_1_percent_boundary(self):
        """Exactly 1% (≤0.01) → boost 2.0."""
        # 100 docs, term in 1 → exactly 1%
        eng, term = self._engine_with_docs(100, 1)
        self.assertEqual(eng._rarity_boost(term), 2.0)

    def test_exact_5_percent_boundary(self):
        """Exactly 5% → boost 1.5 (ratio == 0.05, ≤0.05 branch)."""
        # 100 docs, term in 5 → exactly 5%
        eng, term = self._engine_with_docs(100, 5)
        self.assertEqual(eng._rarity_boost(term), 1.5)

    def test_exact_15_percent_boundary(self):
        """Exactly 15% → boost 1.2 (ratio == 0.15, ≤0.15 branch)."""
        # 100 docs, term in 15 → exactly 15%
        eng, term = self._engine_with_docs(100, 15)
        self.assertEqual(eng._rarity_boost(term), 1.2)

    def test_term_in_all_docs_returns_1(self):
        """Term present in every document → ratio 1.0 → boost 1.0."""
        memories = [make_memory("common word everywhere") for _ in range(10)]
        eng = make_engine(memories)
        # "common" appears in every doc
        self.assertEqual(eng._rarity_boost("common"), 1.0)


# ---------------------------------------------------------------------------
# 2. _is_proper_noun() — unit tests
# ---------------------------------------------------------------------------

class TestIsProperNoun(unittest.TestCase):

    def test_known_capitalized_term(self):
        """Term in capitalized_terms set → True."""
        caps = {"sarah", "olympus"}
        self.assertTrue(SearchEngine._is_proper_noun("sarah", caps))
        self.assertTrue(SearchEngine._is_proper_noun("olympus", caps))

    def test_unknown_term_returns_false(self):
        """Term NOT in capitalized_terms → False."""
        caps = {"sarah"}
        self.assertFalse(SearchEngine._is_proper_noun("devops", caps))

    def test_empty_set_always_false(self):
        self.assertFalse(SearchEngine._is_proper_noun("anything", set()))

    def test_case_sensitive_lookup(self):
        """capitalized_terms stores lower-cased versions; lookup must use lower."""
        # The set stores lowercased versions of the capitalized words
        caps = {"devops"}  # stored as lowercase
        self.assertTrue(SearchEngine._is_proper_noun("devops", caps))


# ---------------------------------------------------------------------------
# 3. capitalized_terms extraction inside search()
# ---------------------------------------------------------------------------

class TestCapitalizedTermsExtraction(unittest.TestCase):
    """Verify that search() correctly identifies mid-sentence capital words."""

    def setUp(self):
        # Small corpus so the engine is valid
        self.memories = [
            make_memory("Sarah leads the project Olympus initiative"),
            make_memory("devops pipeline deployed to staging environment"),
            make_memory("generic information about the system"),
        ]
        self.engine = SearchEngine()
        self.engine.build_index(self.memories)

    def test_first_word_not_treated_as_proper_noun(self):
        """The first word of the query is skipped (sentence-start convention)."""
        # "Sarah" is the first word → should NOT be in capitalized_terms
        # We verify indirectly: "sarah" proper-noun boost should NOT raise score
        # unreasonably vs a query where it's mid-sentence.
        results_first = self.engine.search("Sarah project", self.memories)
        results_mid = self.engine.search("find Sarah project", self.memories)
        # Both should return results; mid-sentence Sarah gets a proper-noun boost
        self.assertTrue(len(results_first) > 0)
        self.assertTrue(len(results_mid) > 0)

    def test_mid_sentence_capital_detected(self):
        """Capital word mid-sentence boosts matching memory."""
        # "Olympus" is mid-sentence in query "find Olympus"
        results_cap = self.engine.search("find Olympus", self.memories)
        results_low = self.engine.search("find olympus", self.memories)
        self.assertTrue(len(results_cap) > 0)
        self.assertTrue(len(results_low) > 0)
        # With proper-noun boost, capitalized query should score >= lowercase
        self.assertGreaterEqual(results_cap[0].score, results_low[0].score)

    def test_punctuation_stripped_from_query_word(self):
        """Punctuation around a capitalized word is stripped before checking."""
        # "DevOps," with trailing comma
        results = self.engine.search("about DevOps, pipeline", self.memories)
        # Should still find the devops memory
        self.assertTrue(len(results) > 0)


# ---------------------------------------------------------------------------
# 4. Integration: rarity boost improves ranking
# ---------------------------------------------------------------------------

class TestRarityBoostIntegration(unittest.TestCase):
    """Ensure rare terms cause matching memories to rank higher."""

    def setUp(self):
        # "common" appears in many docs; "zephyr" appears in only 1
        common_mems = [make_memory(f"common topic discussed here doc {i}") for i in range(50)]
        rare_mem = make_memory("zephyr wind algorithm optimised performance here")
        self.memories = common_mems + [rare_mem]
        self.engine = SearchEngine()
        self.engine.build_index(self.memories)

    def test_rare_term_memory_ranks_first(self):
        """Memory with rare term 'zephyr' should be top result."""
        results = self.engine.search("zephyr", self.memories)
        self.assertTrue(len(results) > 0)
        self.assertIn("zephyr", results[0].content)

    def test_rare_term_score_higher_than_common(self):
        """Score for a rare-term match should exceed score for common-term match."""
        results_rare = self.engine.search("zephyr", self.memories)
        results_common = self.engine.search("common", self.memories)
        self.assertTrue(len(results_rare) > 0)
        self.assertTrue(len(results_common) > 0)
        # Rare term should produce a higher raw score (rarity_boost 2.0 vs 1.0)
        self.assertGreater(results_rare[0].score, results_common[0].score)


# ---------------------------------------------------------------------------
# 5. Integration: proper-noun boost improves ranking
# ---------------------------------------------------------------------------

class TestProperNounBoostIntegration(unittest.TestCase):

    def setUp(self):
        self.memories = [
            make_memory("Sarah runs the marketing team and drives growth"),
            make_memory("sarah is mentioned in passing for context purposes"),
            make_memory("generic quarterly results discussed with the board"),
        ]
        self.engine = SearchEngine()
        self.engine.build_index(self.memories)

    def test_proper_noun_query_boosts_score(self):
        """Querying 'about Sarah' (capitalized mid-sentence) should rank Sarah mem first."""
        results = self.engine.search("about Sarah marketing", self.memories)
        self.assertTrue(len(results) > 0)
        self.assertIn("sarah", results[0].content.lower())

    def test_capitalized_vs_lowercase_query_score_ratio(self):
        """Proper-noun query scores >= lowercase query scores for the same memory."""
        results_cap = self.engine.search("team Sarah growth", self.memories)
        results_low = self.engine.search("team sarah growth", self.memories)
        if results_cap and results_low:
            self.assertGreaterEqual(results_cap[0].score, results_low[0].score)


# ---------------------------------------------------------------------------
# 6. Combined rarity + proper-noun edge cases
# ---------------------------------------------------------------------------

class TestCombinedBoosts(unittest.TestCase):

    def setUp(self):
        # Build a corpus with a very rare proper noun "Arkonyx"
        filler = [make_memory(f"generic content with no specifics number {i}") for i in range(80)]
        specific = make_memory("Arkonyx system launched in Q3 for the DevOps team")
        self.memories = filler + [specific]
        self.engine = SearchEngine()
        self.engine.build_index(self.memories)

    def test_rare_proper_noun_ranks_first(self):
        """A rare proper noun 'Arkonyx' mid-query should surface its memory top."""
        results = self.engine.search("find Arkonyx system", self.memories)
        self.assertTrue(len(results) > 0)
        self.assertIn("arkonyx", results[0].content.lower())

    def test_combined_boost_multipliers_applied(self):
        """Verify combined boost gives score > plain BM25 for the same term."""
        # Plain query: no capitalization → only rarity boost
        results_plain = self.engine.search("arkonyx system", self.memories)
        # Capitalized mid-sentence → rarity + proper-noun boost
        results_boosted = self.engine.search("find Arkonyx system", self.memories)
        if results_plain and results_boosted:
            # "find" is a stopword/low-value word; "arkonyx" gets extra 1.5× proper-noun boost
            # when capitalized → boosted score should be >= plain
            self.assertGreaterEqual(results_boosted[0].score, results_plain[0].score)

    def test_no_false_proper_noun_for_first_word(self):
        """First query word 'Arkonyx' is NOT a proper noun (sentence-start skip)."""
        # If first word is skipped, this query has no proper-noun boost
        results_first = self.engine.search("Arkonyx system", self.memories)
        results_mid = self.engine.search("find Arkonyx system", self.memories)
        # Both should find results; mid-sentence version may score higher
        self.assertTrue(len(results_first) > 0)
        self.assertTrue(len(results_mid) > 0)


if __name__ == "__main__":
    unittest.main()
