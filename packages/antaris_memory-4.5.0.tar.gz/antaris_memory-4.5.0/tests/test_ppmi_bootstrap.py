"""
Tests for PPMIBootstrap (Layer 6 — Bootstrapped Static PPMI Synonym Dictionary).
antaris-memory v4.5.0
"""

import pytest
from antaris_memory.ppmi_bootstrap import PPMIBootstrap


@pytest.fixture
def ppmi():
    return PPMIBootstrap()


# ── Test 1: related() returns a list for a known word ─────────────────────────
def test_related_returns_list_for_known_word(ppmi):
    result = ppmi.related("budget")
    assert isinstance(result, list)
    assert len(result) > 0


# ── Test 2: related() returns empty list for unknown word ─────────────────────
def test_related_returns_empty_for_unknown_word(ppmi):
    result = ppmi.related("zzzzunknownwordxxx")
    assert result == []


# ── Test 3: related() respects the threshold filter ───────────────────────────
def test_related_threshold_filter(ppmi):
    low = ppmi.related("budget", threshold=0.3)
    high = ppmi.related("budget", threshold=0.9)
    # High threshold should return fewer (or equal) results
    assert len(high) <= len(low)
    # High threshold results should all be in low threshold results
    assert all(w in low for w in high)


# ── Test 4: related() is sorted by strength descending ────────────────────────
def test_related_sorted_descending(ppmi):
    # "error" has multiple entries — verify they come back in desc strength order
    result = ppmi.related("error", threshold=0.0)
    assert len(result) >= 2  # must have at least 2 to verify ordering
    # Re-derive strengths from the raw dict to check order
    raw = ppmi._dict["error"]
    strength_map = dict(raw)
    for i in range(len(result) - 1):
        s_curr = strength_map.get(result[i], 0.0)
        s_next = strength_map.get(result[i + 1], 0.0)
        assert s_curr >= s_next, f"Not sorted: {result[i]}({s_curr}) before {result[i+1]}({s_next})"


# ── Test 5: related() is case-insensitive ─────────────────────────────────────
def test_related_case_insensitive(ppmi):
    lower = ppmi.related("budget")
    upper = ppmi.related("BUDGET")
    mixed = ppmi.related("Budget")
    assert lower == upper == mixed


# ── Test 6: expand_query() returns the original query + extras ────────────────
def test_expand_query_contains_original(ppmi):
    query = "server error"
    expanded = ppmi.expand_query(query)
    assert expanded.startswith(query)
    # And extra terms should have been appended
    assert len(expanded) > len(query)


# ── Test 7: expand_query() produces no duplicate terms ───────────────────────
def test_expand_query_no_duplicates(ppmi):
    expanded = ppmi.expand_query("database bug error")
    tokens = expanded.split()
    assert len(tokens) == len(set(tokens)), f"Duplicates found in: {expanded}"


# ── Test 8: expand_query() respects max_per_word ─────────────────────────────
def test_expand_query_max_per_word(ppmi):
    # With a single known word and max_per_word=2, at most 2 extra terms added
    expanded = ppmi.expand_query("budget", max_per_word=2)
    original_tokens = {"budget"}
    added_tokens = [t for t in expanded.split() if t not in original_tokens]
    assert len(added_tokens) <= 2


# ── Test 9: expand_query() on unknown-only query returns original unchanged ───
def test_expand_query_unknown_word_unchanged(ppmi):
    query = "zzzzunknownwordxxx"
    result = ppmi.expand_query(query)
    assert result == query


# ── Test 10: entry_count() returns 200+ entries ───────────────────────────────
def test_entry_count_over_200(ppmi):
    count = ppmi.entry_count()
    assert count >= 200, f"Expected 200+ entries, got {count}"


# ── Test 11: known_words() includes key domain words ─────────────────────────
def test_known_words_covers_domains(ppmi):
    known = ppmi.known_words()
    # Financial
    assert "budget" in known
    assert "invoice" in known
    # Technical
    assert "server" in known
    assert "database" in known
    assert "api" in known
    # Health
    assert "doctor" in known
    assert "medication" in known
    # Time
    assert "deadline" in known
    assert "meeting" in known
    # People
    assert "team" in known
    assert "manager" in known
    # Projects
    assert "project" in known
    assert "sprint" in known
    # Personal assistant
    assert "note" in known
    assert "search" in known
    assert "summary" in known


# ── Test 12: expand_query() expands a realistic query ─────────────────────────
def test_expand_query_realistic(ppmi):
    query = "team budget review"
    expanded = ppmi.expand_query(query)
    expanded_lower = expanded.lower()
    # Should contain at least some related terms from each domain
    # budget → spending / cost / allocation
    # team → group / squad / staff
    # review → audit / assessment / evaluation
    has_budget_related = any(w in expanded_lower for w in ["spending", "cost", "allocation", "expense"])
    has_team_related = any(w in expanded_lower for w in ["group", "squad", "staff", "members"])
    has_review_related = any(w in expanded_lower for w in ["audit", "assessment", "evaluation", "feedback"])
    assert has_budget_related, f"Expected budget-related term in: {expanded}"
    assert has_team_related, f"Expected team-related term in: {expanded}"
    assert has_review_related, f"Expected review-related term in: {expanded}"
