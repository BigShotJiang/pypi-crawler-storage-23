"""
XCCY Python SDK - Interest Rate Swap AMM on Polygon and Arbitrum.

This SDK provides a user-friendly interface to interact with the XCCY Protocol,
enabling margin management, trading (swaps and LP), position monitoring, and oracle queries.

Example:
    >>> from xccy import XccyClient, parse_amount, format_amount
    >>> from xccy.tokens import PolygonTokens, ArbitrumTokens
    >>> 
    >>> # Polygon client
    >>> client = XccyClient(rpc_url="https://polygon-rpc.com")
    >>> 
    >>> # Arbitrum client
    >>> client = XccyClient(rpc_url="https://arb1.arbitrum.io/rpc", network="arbitrum")
    >>> 
    >>> # Deposit 100 USDC
    >>> client.margin.deposit(account, ArbitrumTokens.USDC, parse_amount(100, "USDC"))
"""

from xccy.client import XccyClient
from xccy.constants import POLYGON_CONFIG, ARBITRUM_CONFIG
from xccy.types import AccountId, PoolKey, SwapParams, SwapResult, PositionInfo, TradeEvent
from xccy.trading import MintResult, BurnResult
from xccy.backend import UserPosition, SubAccount, SettlementRecord, PoolSummary, TradeRecord, CollateralInfo
from xccy.tokens import (
    parse_amount, format_amount, get_decimals,
    PolygonTokens, ArbitrumTokens, Tokens, TokenInfo,
)
from xccy.exceptions import (
    XccyError,
    InsufficientMarginError,
    PoolNotFoundError,
    TransactionFailedError,
)

__version__ = "0.3.3"
__all__ = [
    # Client
    "XccyClient",
    # Network configs
    "POLYGON_CONFIG",
    "ARBITRUM_CONFIG",
    # Types
    "AccountId",
    "PoolKey",
    "SwapParams",
    "SwapResult",
    "MintResult",
    "BurnResult",
    "PositionInfo",
    "TradeEvent",
    "TradeRecord",
    # Backend types
    "UserPosition",
    "SubAccount",
    "SettlementRecord",
    "PoolSummary",
    "CollateralInfo",
    # Token utilities
    "parse_amount",
    "format_amount",
    "get_decimals",
    "PolygonTokens",
    "ArbitrumTokens",
    "Tokens",
    "TokenInfo",
    # Exceptions
    "XccyError",
    "InsufficientMarginError",
    "PoolNotFoundError",
    "TransactionFailedError",
]
