from tg_signer.webui.app import main

if __name__ == "__main__":
    main()
