def test_can_import_breinbaas():
    import breinbaas

    assert breinbaas is not None
