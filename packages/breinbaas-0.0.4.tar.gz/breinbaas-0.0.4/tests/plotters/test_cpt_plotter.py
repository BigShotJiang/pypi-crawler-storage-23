from breinbaas.plotters.cpt_plotter import CptPlotter
from breinbaas.objects.cpt import Cpt


import pytest
import os


class TestCptPlotter:
    def setup_method(self):
        self.cpt = Cpt.from_xml("tests/testdata/cpts/CPT000000074504.xml")
        self.cpt_plotter = CptPlotter(self.cpt)

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_cpt_plotter(self):
        self.cpt_plotter.plot(
            to_file="tests/testdata/output/plots/CPT000000074504.png",
            show_robertson=True,
            show_nl_rf=True,
            show_three_type_rule=True,
        )
