from breinbaas.objects.soil_collection import SoilCollection
from breinbaas.objects.borehole import Borehole
from breinbaas.plotters.borehole_plotter import BoreholePlotter


import pytest
import os


class TestBoreholePlotter:
    def setup_method(self):
        self.borehole = Borehole.from_xml(
            "tests/testdata/boreholes/BHR000000354228.xml"
        )
        self.borehole_plotter = BoreholePlotter(self.borehole)

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_default_soil_collection(self):
        self.borehole_plotter.plot(
            to_file="tests/testdata/output/plots/BHR000000354228.png"
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_custom_soil_collection(self):
        soil_collection = SoilCollection()
        soil_collection.add_soil(code="siltigZand", color="#e6e876")
        soil_collection.add_soil(code="veen", color="#786926")
        soil_collection.add_soil(code="kleiigeHumus", color="#a3de2f")
        self.borehole_plotter.plot(
            soil_collection=soil_collection,
            to_file="tests/testdata/output/plots/BHR000000354228_custom.png",
        )
