from breinbaas.objects.geotechnical_profile import GeotechnicalProfile
from breinbaas.databases.cpt_database import CptDatabase
from breinbaas.objects.reference_line import ReferenceLine
from breinbaas.plotters.geotechnical_profile_plotter import GeotechnicalProfilePlotter


import pytest
import os


@pytest.mark.skipif(
    os.environ.get("GITHUB_ACTIONS") == "true",
    reason="Tests using local CptDatabase skipped in CI",
)
class TestGeotechnicalProfilePlotter:

    def setup_method(self):
        self.reference_line = ReferenceLine.from_xy_points(
            name="test",
            xy_points=[
                [113202, 471163],
                [113236, 471224],
                [113294, 471250],
                [113364, 471264],
            ],
            grid_distance=10,
        )
        self.cpt_database = CptDatabase()
        self.geotechnical_profile = GeotechnicalProfile.from_reference_line(
            self.reference_line.name,
            self.reference_line,
            max_cpt_distance=10.0,
            cpt_database=self.cpt_database,
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_with_object_or_cutoff(self):
        plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
        plotter.plot_with_object_or_cutoff(
            object_line=[[0, -5.5], [50, -5.5], [150, -7.2], [180, -3.2], [200, -3.2]],
            to_file="tests/testdata/output/plots/geotechnical_profile_with_object_or_cutoff.png",
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_1d(self):
        plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
        plotter.plot(
            to_file="tests/testdata/output/plots/geotechnical_profile_1d.png",
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_1d_with_distance_risk(self):
        plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
        plotter.plot(
            to_file="tests/testdata/output/plots/geotechnical_profile_1d_with_distance_risk.png",
            plot_distance_risk=True,
            safe_distance=10.0,
            unsafe_distance=50.0,
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_2d(self):
        self.geotechnical_profile.set_cpt_locations_by_zmin_crest(crest_zmin=-1.2)
        plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
        plotter.plot(
            to_file="tests/testdata/output/plots/geotechnical_profile_2d.png",
        )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_2d_with_distance_risk_raises(self):
        with pytest.raises(ValueError):
            plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
            plotter.plot(
                to_file=None,
                plot_distance_risk=True,
            )

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_plot_2d_with_distance_risk(self):
        self.geotechnical_profile.set_cpt_locations_by_zmin_crest(crest_zmin=-1.2)
        plotter = GeotechnicalProfilePlotter(self.geotechnical_profile)
        plotter.plot(
            to_file="tests/testdata/output/plots/geotechnical_profile_2d_with_distance_risk.png",
            plot_distance_risk=True,
            safe_distance=10.0,
            unsafe_distance=50.0,
        )
