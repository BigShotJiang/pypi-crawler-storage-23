import pytest
import os
from shapely.geometry import Polygon

from breinbaas.objects.reference_line import ReferenceLine
from breinbaas.databases.cpt_database import CptDatabase
from breinbaas.objects.geotechnical_profile import GeotechnicalProfile


@pytest.mark.skipif(
    os.environ.get("GITHUB_ACTIONS") == "true",
    reason="Tests using local CptDatabase skipped in CI",
)
class TestCptFiltering:
    def setup_method(self):
        # A simple straight reference line
        self.reference_line = ReferenceLine.from_xy_points(
            name="test_line",
            xy_points=[
                (114960, 482080),
                (114970, 482090),
            ],  # Slight diagonal near the CPT used in other tests
            grid_distance=5,
        )
        self.cpt_database = CptDatabase()

    def test_reference_line_buffer(self):
        distance = 10.0
        polygon = self.reference_line.buffer(distance)
        assert isinstance(polygon, Polygon)
        assert polygon.is_valid
        # The area should be somewhat related to length * width
        # Length approx 14.14, width 20. Area approx 280 + ends.
        assert polygon.area > 200

    def test_get_cpts_in_polygon(self):
        # Create a polygon that we know should contain CPT000000076079 (x=114963, y=482087)
        # The line is close to this point.
        distance = 20.0
        polygon = self.reference_line.buffer(distance)

        cpts = self.cpt_database.get_cpts_in_polygon(polygon)

        # We expect at least one CPT (CPT000000076079) if the database has it
        # Based on previous tests, CPT000000076079 is at 114963, 482087

        found_cpt = False
        for cpt in cpts:
            if cpt.name == "CPT000000076079":
                found_cpt = True
                break

        assert found_cpt, "Expected CPT000000076079 to be found in the polygon"

    def test_geotechnical_profile_filtering(self):
        max_distance = 20.0
        profile = GeotechnicalProfile.from_reference_line(
            name="test",
            reference_line=self.reference_line,
            max_cpt_distance=max_distance,
            cpt_database=self.cpt_database,
        )

        assert len(profile.profile_cpts) > 0

        # Verify that CPTs are within limits (though the method guarantees it by logic, good to check)
        # And check if chainage/distance are calculated
        for geo_cpt in profile.profile_cpts:
            assert hasattr(geo_cpt, "chainage")
            assert hasattr(geo_cpt, "distance")
            assert geo_cpt.distance <= max_distance

    def teardown_method(self):
        self.cpt_database.close()
