from breinbaas.objects.reference_line import ReferenceLine


class TestReferenceLine:
    def setup_method(self):
        self.reference_line = ReferenceLine.from_xy_points(
            name="test",
            xy_points=[(0, 0), (10, 0), (10, 10), (0, 10)],
            grid_distance=5,
        )

    def test_from_xy_points(self):
        assert self.reference_line.cxy_points == [
            (0.0, 0.0, 0.0),
            (5.0, 5.0, 0.0),
            (10.0, 10.0, 0.0),
            (15.0, 10.0, 5.0),
            (20.0, 10.0, 10.0),
            (25.0, 5.0, 10.0),
            (30.0, 0.0, 10.0),
        ]

    def test_closest_point_to_xy(self):
        assert self.reference_line.closest_point_to_xy(0, 0) == (0.0, 0.0, 0.0)
        assert self.reference_line.closest_point_to_xy(-1, -1) == (0.0, 0.0, 0.0)
        assert self.reference_line.closest_point_to_xy(-1, -1, max_distance=1.0) is None
