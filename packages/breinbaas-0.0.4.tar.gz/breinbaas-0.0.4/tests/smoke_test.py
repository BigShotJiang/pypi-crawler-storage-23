import breinbaas

print("Successfully imported breinbaas version:", breinbaas.__version__)
