import pytest
from breinbaas.objects.soil_profile import SoilProfile
from breinbaas.objects.soil_layer import SoilLayer
from breinbaas.voxels.kriging import generate_voxel_model, generate_2d_voxel_model


class TestVoxels2d:

    def setup_method(self):
        # Create simple profiles
        p1 = SoilProfile(
            x=0,
            y=0,
            soil_layers=[
                SoilLayer(top=-2, bottom=-3, soil_code="SAND"),
                SoilLayer(top=-3, bottom=-10, soil_code="CLAY"),
            ],
        )
        p2 = SoilProfile(
            x=10,
            y=0,
            soil_layers=[
                SoilLayer(top=0, bottom=-6, soil_code="SAND"),
                SoilLayer(top=-6, bottom=-8, soil_code="CLAY"),
            ],
        )

        profiles = [p1, p2]

        # Generate model for a point in between
        self.model = generate_2d_voxel_model(
            profiles,
            x_min=0,
            x_max=10,
            dx=1.0,
            z_min=-10,
            z_max=0,
            dz=1.0,
        )

    def test_to_obj(self):
        soil_colors = {
            0: "#55aa3c",
            1: "#f8dda6",
        }
        self.model.to_obj(
            "tests/testdata/output/voxels/voxel_model_2d.obj", soil_colors=soil_colors
        )


class TestVoxels3d:

    def setup_method(self):
        # Create simple profiles
        p1 = SoilProfile(
            x=0,
            y=0,
            soil_layers=[
                SoilLayer(top=0, bottom=-5, soil_code="SAND"),
                SoilLayer(top=-5, bottom=-10, soil_code="CLAY"),
            ],
        )
        p2 = SoilProfile(
            x=10,
            y=0,
            soil_layers=[
                SoilLayer(top=0, bottom=-8, soil_code="SAND"),
                SoilLayer(top=-8, bottom=-10, soil_code="CLAY"),
            ],
        )

        profiles = [p1, p2]

        # Generate model for a point in between
        self.model = generate_voxel_model(
            profiles,
            x_min=0,
            x_max=10,
            dx=1.0,
            y_min=0,
            y_max=10,
            dy=1.0,
            z_min=-10,
            z_max=0,
            dz=1.0,
        )

    def test_generate_voxel_model(self):
        assert len(self.model.voxels) > 0

        # Check a voxel at the top of the first profile (should be SAND)
        top_voxels = [v for v in self.model.voxels if v["z"] > -5 and v["x"] == 0.5]
        for v in top_voxels:
            assert self.model.int_to_code[v["c"]] == "SAND"

        # Check a voxel at the bottom of the first profile (should be CLAY)
        bottom_voxels = [v for v in self.model.voxels if v["z"] < -5 and v["x"] == 0.5]
        for v in bottom_voxels:
            assert self.model.int_to_code[v["c"]] == "CLAY"

    def test_to_obj(self):
        soil_colors = {
            0: "#55aa3c",
            1: "#f8dda6",
        }
        self.model.to_obj(
            "tests/testdata/output/voxels/voxel_model_3d.obj", soil_colors=soil_colors
        )
