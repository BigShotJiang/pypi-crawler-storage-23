* top van de sondering gelijk zetten aan de offset, niet aan de eerste gemeten waarde want die kan door NAN ongeldig zijn

START MET GIT FLOW FEATURE NU