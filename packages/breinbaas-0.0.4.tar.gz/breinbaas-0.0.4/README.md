## Setup databases

Fill in the correct paths in the following files:

* src/breinbaas/databases/cpt_database.py
* src/breinbaas/databases/borehole_database.py

Run the following scripts to create the databases:

* scripts/create_cpt_database.py
* scripts/create_borehole_database.py

## Werkwijze nieuwe tag

* git tag v0.1.0 && git push origin v0.1.0

## Werkwijze bestaande tag

* git tag -f v0.1.0 && git push origin v0.1.0 -f
