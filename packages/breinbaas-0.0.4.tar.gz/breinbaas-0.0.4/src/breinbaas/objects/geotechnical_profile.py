from enum import Enum
from shapely import Point
from typing import List, Optional, Tuple
import math
from pydantic import BaseModel
import folium
import tempfile
import shutil

from .reference_line import ReferenceLine
from .cpt import Cpt
from ..databases.cpt_database import CptDatabase
from ..helpers.coordinate_conversion import xy_to_lat_lon


class GeoprofileCptLocation(Enum):
    CREST = "crest"
    TOE = "toe"


class GeotechnicalProfileCpt(BaseModel):
    cpt: Cpt
    distance: float
    chainage: float
    location: GeoprofileCptLocation

    @classmethod
    def from_cpt(
        cls,
        cpt: Cpt,
        distance: float,
        chainage: float,
        location: GeoprofileCptLocation = GeoprofileCptLocation.CREST,
    ):
        return cls(
            cpt=cpt,
            distance=distance,
            chainage=chainage,
            location=location,
        )


class GeotechnicalProfile(BaseModel):
    name: str = ""
    reference_line: ReferenceLine = None
    profile_cpts: List[GeotechnicalProfileCpt] = []

    @classmethod
    def from_reference_line(
        cls,
        name: str,
        reference_line: ReferenceLine,
        cpt_database: Optional[CptDatabase] = None,
        cpt_files: Optional[List[str]] = None,
        cpts: Optional[List[Cpt]] = None,
        cpt_ids: Optional[List[str]] = None,
        max_cpt_distance: float = 100,
        crest_range_zmin: float = None,
    ):
        """Create a geotechnical profile from a reference line and CPTs.

        There are 4 options to provide CPTs:
        1. CPT database, you will need to provide a CPT database object
        2. CPT files, you will need to provide a list of CPT files
        3. CPT IDs, you will need to provide a list of CPT IDs
        4. CPT objects, you will need to provide a list of CPT objects

        The first option that is not None will be used.

        Args:
            name (str): Name of the geotechnical profile.
            reference_line (ReferenceLine): Reference line of the geotechnical profile.
            cpt_database (Optional[CptDatabase]): CPT database to use.
            cpt_files (Optional[List[str]]): List of CPT files to use.
            cpts (Optional[List[Cpt]]): List of CPTs to use.
            cpt_ids (Optional[List[str]]): List of CPT IDs to use.
            max_cpt_distance (float): Maximum distance of CPTs from the reference line.
            crest_range_zmin (float): Z-minimum for the crest range.

        Returns:
            GeotechnicalProfile: Geotechnical profile.
        """
        if (
            cpt_database is None
            and cpt_files is None
            and cpts is None
            and cpt_ids is None
        ):
            raise ValueError("No CPTs provided")

        filtered_cpts = []
        geotechnical_profile = cls(name=name, reference_line=reference_line)

        polygon = reference_line.buffer(max_cpt_distance)

        if cpt_database:
            filtered_cpts = cpt_database.get_cpts_in_polygon(polygon)
        elif cpt_files:
            for cpt_file in cpt_files:
                cpt = Cpt.from_xml(cpt_file)
                if polygon.contains(Point(cpt.x, cpt.y)):
                    filtered_cpts.append(cpt)
        elif cpt_ids:
            try:
                temp_dir = tempfile.mkdtemp()
                for cpt_id in cpt_ids:
                    cpt = Cpt.from_bro_id(cpt_id, temp_dir)
                    if polygon.contains(Point(cpt.x, cpt.y)):
                        filtered_cpts.append(cpt)
            finally:
                shutil.rmtree(temp_dir, ignore_errors=True)
        elif cpts:
            for cpt in cpts:
                if polygon.contains(Point(cpt.x, cpt.y)):
                    filtered_cpts.append(cpt)

        for cpt in filtered_cpts:
            closest_point = reference_line.closest_point_to_xy(cpt.x, cpt.y)

            if closest_point:
                closest_chainage, closest_x, closest_y = closest_point
                distance = math.sqrt(
                    (cpt.x - closest_x) ** 2 + (cpt.y - closest_y) ** 2
                )

                geotechnical_profile.profile_cpts.append(
                    GeotechnicalProfileCpt.from_cpt(
                        cpt,
                        distance=distance,
                        chainage=closest_chainage,
                        location=GeoprofileCptLocation.CREST,
                    )
                )

        geotechnical_profile.profile_cpts.sort(key=lambda x: x.chainage)

        if crest_range_zmin:
            geotechnical_profile.set_cpt_locations_by_zmin_crest(crest_range_zmin)

        return geotechnical_profile

    @property
    def metadata(self):
        profile_cpt_metadata = []
        for profile_cpt in self.profile_cpts:
            profile_cpt_metadata.append(
                {
                    profile_cpt.cpt.name: {
                        "top": profile_cpt.cpt.top,
                        "bottom": profile_cpt.cpt.bottom,
                    }
                }
            )
        return {
            "length": self.reference_line.length,
            "cpts": profile_cpt_metadata,
            "cpt_zmax": max([profile_cpt.cpt.top for profile_cpt in self.profile_cpts]),
            "cpt_zmin": min(
                [profile_cpt.cpt.bottom for profile_cpt in self.profile_cpts]
            ),
        }

    @property
    def length(self):
        return self.reference_line.length

    @property
    def is_2d(self) -> bool:
        """Is this geotechnical profile 2D (crest and toe). This is the case if one of the cpts is
        located at the toe because default all cpts will be added to the crest.

        Returns:
            bool: True is we have toe and crest cpts
        """
        for profile_cpt in self.profile_cpts:
            if profile_cpt.location == GeoprofileCptLocation.TOE:
                return True
        return False

    @property
    def crest_zmin(self):
        return min([profile_cpt.cpt.top for profile_cpt in self.profile_cpts])

    @property
    def toe_zmin(self):
        return min([profile_cpt.cpt.bottom for profile_cpt in self.profile_cpts])

    def get_crest_cpts(self) -> List[GeotechnicalProfileCpt]:
        return [
            profile_cpt
            for profile_cpt in self.profile_cpts
            if profile_cpt.location == GeoprofileCptLocation.CREST
        ]

    def get_toe_cpts(self) -> List[GeotechnicalProfileCpt]:
        return [
            profile_cpt
            for profile_cpt in self.profile_cpts
            if profile_cpt.location == GeoprofileCptLocation.TOE
        ]

    def set_cpt_locations(
        self, cpt_names: List[str], locations: List[GeoprofileCptLocation]
    ):
        if len(cpt_names) != len(locations):
            raise ValueError(
                f"The number of CPT IDs ({len(cpt_names)}) must match the number of locations ({len(locations)})."
            )
        for i, profile_cpt in enumerate(self.profile_cpts):
            if profile_cpt.cpt.name in cpt_names:
                self.profile_cpts[i].location = locations[
                    cpt_names.index(profile_cpt.cpt.name)
                ]

    def set_cpt_locations_by_zmin_crest(self, crest_zmin: float):
        for i, profile_cpt in enumerate(self.profile_cpts):
            if profile_cpt.cpt.top < crest_zmin:
                self.profile_cpts[i].location = GeoprofileCptLocation.TOE
            else:
                self.profile_cpts[i].location = GeoprofileCptLocation.CREST

    def to_folium(self, to_html_file: str = None):
        xmin, xmax, ymin, ymax = self.reference_line.limits(margin=50)
        p1, p2 = xy_to_lat_lon([(xmin, ymax), (xmax, ymin)])

        lat_mid = (p1[0] + p2[0]) / 2.0
        lon_mid = (p1[1] + p2[1]) / 2.0

        m = folium.Map(location=(lat_mid, lon_mid))
        m.fit_bounds([[p1[0], p1[1]], [p2[0], p2[1]]])

        for profile_cpt in self.profile_cpts:
            lat, lon = xy_to_lat_lon([(profile_cpt.cpt.x, profile_cpt.cpt.y)])[0]
            folium.CircleMarker(
                location=(lat, lon),
                radius=5,
                color="red",
                fill=True,
                fill_color="red",
                tooltip=profile_cpt.cpt.name,
            ).add_to(m)

        latlon_reference_line = xy_to_lat_lon(self.reference_line.xy_points)
        folium.PolyLine(
            latlon_reference_line,
            color="blue",
            weight=2,
            opacity=1,
        ).add_to(m)

        if to_html_file:
            m.save(to_html_file)

    def get_closest_profile_cpt(
        self,
        x: float,
        y: float,
        geoprofile_cpt_location: GeoprofileCptLocation = GeoprofileCptLocation.CREST,
    ) -> Optional[GeotechnicalProfileCpt]:
        """Get the closest profile cpt to a given point."""
        closest_profile_cpt = None
        min_distance = float("inf")
        for profile_cpt in self.profile_cpts:
            if profile_cpt.location != geoprofile_cpt_location:
                continue
            distance = math.hypot(x - profile_cpt.cpt.x, y - profile_cpt.cpt.y)
            if distance < min_distance:
                min_distance = distance
                closest_profile_cpt = profile_cpt
        return closest_profile_cpt

    def generate_distance_risk(
        self,
        geoprofile_cpt_location: GeoprofileCptLocation = GeoprofileCptLocation.CREST,
    ) -> List[Tuple[float, float]]:
        """Generate a distance risk assessment for the geotechnical profile."""
        risk_points = []
        for c, x, y in self.reference_line.cxy_points:
            closest_profile_cpt = self.get_closest_profile_cpt(
                x, y, geoprofile_cpt_location
            )
            if closest_profile_cpt is None:
                distance = float("inf")
            else:
                distance = math.hypot(
                    x - closest_profile_cpt.cpt.x, y - closest_profile_cpt.cpt.y
                )
            risk_points.append((c, distance))

        return risk_points
