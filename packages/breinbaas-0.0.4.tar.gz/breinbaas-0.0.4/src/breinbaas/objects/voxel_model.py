from pydantic import BaseModel
from typing import List, Dict, Any, Optional


class VoxelModel(BaseModel):
    voxels: List[Dict[str, Any]]
    int_to_code: Dict[int, str]

    @property
    def codes(self) -> List[str]:
        return list(self.int_to_code.values())

    def get_voxel_code(self, voxel_index: int) -> str:
        code_int = self.voxels[voxel_index].get("c")
        return self.int_to_code.get(code_int, "UNKNOWN")

    def to_obj(
        self,
        filename: str,
        voxel_size: float = 1.0,
        soil_colors: Optional[Dict[int, str]] = None,
    ) -> None:
        """
        Export the voxel model to a Wavefront OBJ file with materials.
        Each voxel is represented as a cube.
        """
        import os

        # Determine colors
        if soil_colors is None:
            raise ValueError("No soil colors provided.")
            # # Simple default color generation mimicking plotter if matplotlib is available
            # # otherwise fall back to random/fixed
            # try:
            #     import matplotlib.pyplot as plt

            #     unique_codes = self.int_to_code.keys()
            #     # Sort for stability
            #     unique_codes_list = sorted(list(unique_codes))
            #     cmap = plt.cm.get_cmap("tab20", len(unique_codes_list))
            #     soil_colors = {
            #         code: "#%02x%02x%02x"
            #         % (int(c[0] * 255), int(c[1] * 255), int(c[2] * 255))
            #         for i, code in enumerate(unique_codes_list)
            #         for c in [cmap(i)]
            #     }
            # except ImportError:
            #     # Fallback if no matplotlib
            #     soil_colors = {code: "#cccccc" for code in self.int_to_code}

        # Material file handling
        mtl_filename = filename.replace(".obj", ".mtl")
        if mtl_filename == filename:
            mtl_filename = filename + ".mtl"

        mtl_basename = os.path.basename(mtl_filename)

        # Write Material File
        with open(mtl_filename, "w") as mtl:
            for code, hex_color in soil_colors.items():
                # Convert hex to float rgb
                hex_color = hex_color.lstrip("#")
                if len(hex_color) == 6:
                    r = int(hex_color[0:2], 16) / 255.0
                    g = int(hex_color[2:4], 16) / 255.0
                    b = int(hex_color[4:6], 16) / 255.0
                else:
                    r, g, b = 0.5, 0.5, 0.5  # Fallback

                material_name = self.int_to_code.get(code, f"mat_{code}")
                # Clean name for OBJ
                material_name = material_name.replace(" ", "_").replace(".", "_")

                mtl.write(f"newmtl {material_name}\n")
                mtl.write(f"Kd {r:.4f} {g:.4f} {b:.4f}\n")  # Diffuse color
                mtl.write("d 0.7\n")  # 30% transparent
                mtl.write("illum 2\n\n")

        # Write OBJ File
        with open(filename, "w") as f:
            f.write(f"# Voxel Model Export\n")
            f.write(f"mtllib {mtl_basename}\n")

            vertex_count = 1
            hs = voxel_size / 3.0

            offsets = [
                (-hs, -hs, -hs),
                (hs, -hs, -hs),
                (hs, hs, -hs),
                (-hs, hs, -hs),
                (-hs, -hs, hs),
                (hs, -hs, hs),
                (hs, hs, hs),
                (-hs, hs, hs),
            ]

            faces = [
                (0, 3, 2, 1),
                (4, 5, 6, 7),
                (0, 1, 5, 4),
                (1, 2, 6, 5),
                (2, 3, 7, 6),
                (3, 0, 4, 7),
            ]

            # Group voxels by code to minimize usemtl switches
            sorted_voxels = sorted(self.voxels, key=lambda v: v["c"])

            current_code = -9999

            for voxel in sorted_voxels:
                code = voxel["c"]
                if code == -1:
                    continue

                if code != current_code:
                    material_name = self.int_to_code.get(code, f"mat_{code}")
                    material_name = material_name.replace(" ", "_").replace(".", "_")
                    f.write(f"usemtl {material_name}\n")
                    current_code = code

                x, y, z = voxel["x"], voxel["y"], voxel["z"]

                # Write vertices
                for ox, oy, oz in offsets:
                    f.write(f"v {x + ox} {y + oy} {z + oz}\n")

                # Write faces
                for v1, v2, v3, v4 in faces:
                    f.write(
                        f"f {vertex_count + v1} {vertex_count + v2} {vertex_count + v3} {vertex_count + v4}\n"
                    )

                vertex_count += 8
