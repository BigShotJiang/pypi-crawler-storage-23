from pydantic import BaseModel
from typing import List, Dict

from .soil import Soil


class SoilCollection(BaseModel):
    soils: List[Soil] = []

    @classmethod
    def default(cls):
        return cls(
            soils=[
                Soil(
                    code="preexcavated",
                    color="#54575c",
                    yd=14.0,
                    ys=14.0,
                ),
                Soil(
                    code="unknown",
                    color="#696969",
                    yd=14.0,
                    ys=14.0,
                ),
                Soil(
                    code="top_material",
                    color="#696969",
                    yd=15.0,
                    ys=15.0,
                ),
                Soil(
                    code="bottom_material",
                    color="#808080",
                    yd=17.0,
                    ys=19.0,
                ),  # NL_RF (NEN5104)
                Soil(
                    code="nl_veen",
                    color="#786926",
                    yd=10.0,
                    ys=10.0,
                ),
                Soil(
                    code="nl_grof_zand",
                    color="#faff00",
                    yd=19.0,
                    ys=21.0,
                ),
                Soil(
                    code="nl_middelgrof_zand",
                    color="#e0e342",
                    yd=18.0,
                    ys=20.0,
                ),
                Soil(
                    code="nl_fijn_zand",
                    color="#e6e876",
                    yd=17.0,
                    ys=19.0,
                ),
                Soil(
                    code="nl_kleiig_zand",
                    color="#9fa12d",
                    yd=16.0,
                    ys=18.0,
                ),
                Soil(
                    code="nl_siltig_zand",
                    color="#596b15",
                    yd=16.0,
                    ys=17.0,
                    c=2.0,
                    phi=27.5,
                ),
                Soil(
                    code="nl_zandige_klei",
                    color="#596b15",
                    yd=16.0,
                    ys=16.0,
                ),
                Soil(
                    code="nl_siltige_klei",
                    color="#3c6318",
                    yd=15.0,
                    ys=15.0,
                ),
                Soil(
                    code="nl_klei",
                    color="#39bf1b",
                    yd=15.0,
                    ys=15.0,
                ),
                Soil(
                    code="nl_venige_klei",
                    color="#7d6b0f",
                    yd=14.0,
                    ys=14.0,
                ),
                Soil(
                    code="nl_humeuze_klei",
                    color="#7d6b0f",
                    yd=14.0,
                    ys=14.0,
                ),
                Soil(
                    code="peat",
                    color="#786926",
                    yd=10.0,
                    ys=10.0,
                ),
                Soil(
                    code="organic_clay",
                    color="#a3de2f",
                    yd=14.0,
                    ys=14.0,
                ),
                Soil(
                    code="clay",
                    color="#3c6318",
                    yd=15.0,
                    ys=15.0,
                ),
                Soil(
                    code="silty_clay",
                    color="#596b15",
                    yd=15.0,
                    ys=15.0,
                ),
                Soil(
                    code="silty_sand",
                    color="#9fa12d",
                    yd=16.0,
                    ys=18.0,
                ),
                Soil(
                    code="sand",
                    color="#e6e876",
                    yd=17.0,
                    ys=19.0,
                ),
                Soil(
                    code="dense_sand",
                    color="#fcf403",
                    yd=19.0,
                    ys=21.0,
                ),
            ]
        )

    @property
    def color_dict(self) -> Dict[str, str]:
        return {soil.code: soil.color for soil in self.soils}

    def add_soil(self, code: str, color: str, yd: float = 0.0, ys: float = 0.0):
        self.soils.append(Soil(code=code, color=color, yd=yd, ys=ys))
