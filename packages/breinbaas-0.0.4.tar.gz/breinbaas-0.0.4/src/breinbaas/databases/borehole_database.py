from typing import Tuple, List
import csv
from shapely.geometry import Polygon, Point
from typing import Optional
import sqlite3
import glob
import os
from pathlib import Path
import brodata
from tqdm import tqdm

from ..objects.borehole import Borehole

BOREHOLE_FILES_LOCATION = "/home/breinbaas/Documents/Breinbaas/boringen/data"
BOREHOLE_DATABASE = (
    "/home/breinbaas/Documents/Breinbaas/boringen/borehole_database.db"
)
BOREHOLE_MINI_DATABASE = (
    "/home/breinbaas/Documents/Breinbaas/boringen/borehole_mini_database.db"
)
BOREHOLE_DATABASE_CSV = (
    "/home/breinbaas/Documents/Breinbaas/boringen/borehole_database.csv"
)
DEFAULT_MAX_BOREHOLE_DISTANCE = 100  # m


class NoBoreholeFoundError(Exception):
    pass


class BoreholeDatabase:

    def __init__(self, db_path=BOREHOLE_DATABASE):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS borehole_files (
                id TEXT PRIMARY KEY,
                x REAL,
                y REAL,
                z REAL,
                date TEXT,
                length REAL,
                groundwater_level REAL,
                file_path TEXT
            )
        """
        )
        self.conn.commit()

    def add_from_directory(self, directory: str, new_database: bool = False):
        """
        Finds all xml files in the given directory using glob and adds them to the database.
        """
        # Finds all xml files in the directory
        xml_files = glob.glob(os.path.join(directory, "*.xml"))

        if Path(self.db_path).exists() and new_database:
            os.remove(self.db_path)
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            self._create_table()

        for xml_file in tqdm(xml_files):
            # Add to database if not check is handled here
            if not self._file_exists(xml_file):
                try:
                    # User to implement extraction logic here
                    file_id, x, y, z, date, borehole_length, groundwater_level = (
                        self._extract_info(xml_file)
                    )

                    self._insert_record(
                        file_id,
                        x,
                        y,
                        z,
                        date,
                        borehole_length,
                        groundwater_level,
                        xml_file,
                    )
                    # print(f"Added {xml_file} to database.")
                except Exception as e:
                    print(f"Error processing {xml_file}: {e}")
            else:
                # print(f"File {xml_file} already exists in database.")
                pass

    def _file_exists(self, file_path):
        self.cursor.execute(
            "SELECT 1 FROM borehole_files WHERE file_path = ?", (file_path,)
        )
        return self.cursor.fetchone() is not None

    def _insert_record(
        self, file_id, x, y, z, date, borehole_length, groundwater_level, file_path
    ):
        self.cursor.execute(
            """
            INSERT INTO borehole_files (id, x, y, z, date, length, groundwater_level, file_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (file_id, x, y, z, date, borehole_length, groundwater_level, file_path),
        )
        self.conn.commit()

    def _extract_info(self, file_path):
        """
        Extracts id, x, y, z, date, length and groundwater level from the xml file.
        """
        bro_borehole = brodata.bhr.GeotechnicalBoreholeResearch(file_path)

        dt = bro_borehole.boringStartDate
        date_string = dt.strftime("%Y-%m-%d")

        try:
            groundwater_level = float(bro_borehole.groundwaterLevel)
        except:
            groundwater_level = None

        return (
            bro_borehole.broId,
            bro_borehole.deliveredLocation.x,
            bro_borehole.deliveredLocation.y,
            float(bro_borehole.offset),
            date_string,
            float(bro_borehole.finalDepthBoring),
            groundwater_level,
        )

    def close(self):
        self.conn.close()

    def get_by_id(self, id: str) -> Borehole:
        self.cursor.execute("SELECT file_path FROM borehole_files WHERE id = ?", (id,))
        result = self.cursor.fetchone()

        if result is None:
            raise NoBoreholeFoundError(f"No Borehole found with id {id}")

        file_path = result[0]
        if Path(file_path).exists():
            return Borehole.from_xml(file_path)
        else:
            raise NoCptFoundError(f"File {file_path} does not exist.")

    def get_closest_borehole(
        self, x: float, y: float, max_distance: float = DEFAULT_MAX_BOREHOLE_DISTANCE
    ) -> Tuple[Borehole, float]:
        # create a selection within a box of max_distance around x, y
        x_min = x - max_distance
        x_max = x + max_distance
        y_min = y - max_distance
        y_max = y + max_distance

        self.cursor.execute(
            """
            SELECT * FROM borehole_files 
            WHERE x >= ? AND x <= ? AND y >= ? AND y <= ? 
            ORDER BY (x - ?) * (x - ?) + (y - ?) * (y - ?) ASC 
            LIMIT 1
            """,
            (x_min, x_max, y_min, y_max, x, x, y, y),
        )
        result = self.cursor.fetchone()

        if result is None:
            raise NoBoreholeFoundError(
                f"No Borehole found closest to x={x} and y={y} and max_distance={max_distance}"
            )

        x_borehole = result[1]
        y_borehole = result[2]
        distance = ((x - x_borehole) ** 2 + (y - y_borehole) ** 2) ** 0.5
        file_path = result[6]
        if Path(file_path).exists():
            return Borehole.from_xml(file_path), distance
        else:
            raise FileNotFoundError(f"File {file_path} does not exist.")

    def to_csv(self, file_path: str):
        self.cursor.execute(
            "SELECT id, x, y, z, date, length, groundwater_level FROM borehole_files"
        )
        results = self.cursor.fetchall()
        with open(file_path, "w") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["id", "x", "y", "z", "date", "length", "groundwater_level"]
            )
            writer.writerows(results)

    def to_mini_database(self, file_path: str):
        self.cursor.execute("SELECT id, x, y FROM borehole_files")
        results = self.cursor.fetchall()
        with open(file_path, "w") as f:
            conn = sqlite3.connect(file_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                CREATE TABLE borehole_files (
                    id TEXT PRIMARY KEY,
                    x REAL,
                    y REAL
                )
                """
            )
            cursor.executemany(
                """
                INSERT INTO borehole_files (id, x, y)
                VALUES (?, ?, ?)
                """,
                results,
            )
            conn.commit()
            conn.close()

    def get_boreholes_in_polygon(self, polygon: Polygon) -> List[Borehole]:
        x_min, y_min, x_max, y_max = polygon.bounds
        self.cursor.execute(
            """
            SELECT * FROM borehole_files 
            WHERE x >= ? AND x <= ? AND y >= ? AND y <= ?
            """,
            (x_min, x_max, y_min, y_max),
        )
        results = self.cursor.fetchall()

        boreholes = []
        for result in results:
            x_borehole = result[1]
            y_borehole = result[2]
            if polygon.contains(Point(x_borehole, y_borehole)):
                file_path = result[6]
                if Path(file_path).exists():
                    boreholes.append(Borehole.from_xml(file_path))
                else:
                    # Log or handle missing file
                    pass
        return boreholes
