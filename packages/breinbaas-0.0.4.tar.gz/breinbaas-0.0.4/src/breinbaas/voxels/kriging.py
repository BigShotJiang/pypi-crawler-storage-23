from typing import List, Dict, Any, Union
from breinbaas.objects.soil_profile import SoilProfile
from breinbaas.objects.voxel_model import VoxelModel
from breinbaas.voxels._voxels import VoxelModeler
import numpy as np


# Helper class to mimic the object structure expected by C++ if it doesn't match exactly
class IntSoilLayer:
    def __init__(self, top: float, bottom: float, soil_code: int):
        self.top = top
        self.bottom = bottom
        self.soil_code = soil_code


class IntSoilProfile:
    def __init__(self, x: float, y: float, layers: List[IntSoilLayer]):
        self.x = x
        self.y = y
        self.soil_layers = layers


def generate_voxel_model(
    profiles: List[SoilProfile],
    x_min: float,
    x_max: float,
    dx: float,
    y_min: float,
    y_max: float,
    dy: float,
    z_min: float,
    z_max: float,
    dz: float,
    anisotropy_ratio: float = 50.0,
    step_size: float = 0.5,
) -> VoxelModel:
    """
    Generate a voxel model using Indicator Kriging (VoxelModeler).

    Args:
        profiles: List of SoilProfile objects.
        x_min, x_max, dx: X-axis bounds and step.
        y_min, y_max, dy: Y-axis bounds and step.
        z_min, z_max, dz: Z-axis bounds and step.
        range_: Kriging range parameter (currently unused/hardcoded in C++ demo, kept for API compat).
        sill: Kriging sill parameter.
        nugget: Kriging nugget parameter.
        anisotropy_ratio: Vertical anisotropy ratio.
        step_size: Vertical step size for discretizing soil layers into points.

    Returns:
        VoxelModel object containing voxel data and metadata.
    """

    # Validation
    if not profiles:
        return []

    # Map string codes to ints
    unique_codes = set()
    for p in profiles:
        for l in p.soil_layers:
            unique_codes.add(l.soil_code)

    sorted_codes = sorted(list(unique_codes))
    code_to_int = {code: i for i, code in enumerate(sorted_codes)}
    int_to_code = {i: code for code, i in code_to_int.items()}
    int_to_code[-1] = "UNKNOWN"

    # Prepare data for C++
    cpp_profiles = []
    for p in profiles:
        layers = []
        for l in p.soil_layers:
            if l.soil_code in code_to_int:
                layers.append(IntSoilLayer(l.top, l.bottom, code_to_int[l.soil_code]))
        cpp_profiles.append(IntSoilProfile(p.x, p.y, layers))

    # Instantiate and use VoxelModeler
    modeler = VoxelModeler()
    modeler.set_anisotropy(anisotropy_ratio)
    modeler.add_profiles(cpp_profiles, step_size)
    modeler.build()

    # Generate grid (returns flat numpy array of ints)
    flat_indices = modeler.generate(
        x_min, x_max, y_min, y_max, z_min, z_max, dx, dy, dz
    )

    # Convert flat array back to structured voxels
    nx = int((x_max - x_min) / dx)
    ny = int((y_max - y_min) / dy)
    nz = int((z_max - z_min) / dz)

    voxels = []
    for idx, code_int in enumerate(flat_indices):
        if code_int == -1:
            continue

        # Calculate coordinates (matching C++ logic)
        iz = idx % nz
        iy = (idx // nz) % ny
        ix = idx // (ny * nz)

        cx = x_min + ix * dx + dx / 2.0
        cy = y_min + iy * dy + dy / 2.0
        cz = z_min + iz * dz + dz / 2.0

        voxels.append(
            {
                "x": cx,
                "y": cy,
                "z": cz,
                "c": code_int,
            }
        )

    return VoxelModel(voxels=voxels, int_to_code=int_to_code)


def generate_2d_voxel_model(
    profiles: List[SoilProfile],
    x_min: float,
    x_max: float,
    dx: float,
    z_min: float,
    z_max: float,
    dz: float,
    anisotropy_ratio: float = 50.0,
    step_size: float = 0.5,
) -> VoxelModel:
    """
    Generate a 2D voxel model (x-z plane) using Indicator Kriging (VoxelModeler).

    Args:
        profiles: List of SoilProfile objects.
        x_min, x_max, dx: X-axis bounds and step.
        z_min, z_max, dz: Z-axis bounds and step.
        anisotropy_ratio: Vertical anisotropy ratio.
        step_size: Vertical step size for discretizing soil layers into points.

    Returns:
        VoxelModel object containing voxel data and metadata.
    """
    if not profiles:
        return VoxelModel(voxels=[], int_to_code={-1: "UNKNOWN"})

    # Map string codes to ints
    unique_codes = set()
    for p in profiles:
        for l in p.soil_layers:
            unique_codes.add(l.soil_code)

    sorted_codes = sorted(list(unique_codes))
    code_to_int = {code: i for i, code in enumerate(sorted_codes)}
    int_to_code = {i: code for code, i in code_to_int.items()}
    int_to_code[-1] = "UNKNOWN"

    # Prepare data for C++ (Force Y to 0 for 2D)
    cpp_profiles = []
    for p in profiles:
        layers = []
        for l in p.soil_layers:
            if l.soil_code in code_to_int:
                layers.append(IntSoilLayer(l.top, l.bottom, code_to_int[l.soil_code]))
        cpp_profiles.append(IntSoilProfile(p.x, 0.0, layers))

    # Instantiate and use VoxelModeler
    modeler = VoxelModeler()
    modeler.set_anisotropy(anisotropy_ratio)
    modeler.add_profiles(cpp_profiles, step_size)
    modeler.build()

    # Generate grid for 2D (y_min=-dx/2, y_max=dx/2, dy=dx to get exactly 1 cell in y, centered at 0)
    dy = dx if dx > 0 else 1.0
    y_min = -dy / 2.0
    y_max = dy / 2.0

    # Generate grid (returns flat numpy array of ints)
    flat_indices = modeler.generate(
        x_min, x_max, y_min, y_max, z_min, z_max, dx, dy, dz
    )

    # Convert flat array back to structured voxels
    nx = int((x_max - x_min) / dx)
    ny = int((y_max - y_min) / dy)
    nz = int((z_max - z_min) / dz)

    voxels = []
    for idx, code_int in enumerate(flat_indices):
        if code_int == -1:
            continue

        # Calculate coordinates
        iz = idx % nz
        iy = (idx // nz) % ny
        ix = idx // (ny * nz)

        cx = x_min + ix * dx + dx / 2.0
        cy = y_min + iy * dy + dy / 2.0
        cz = z_min + iz * dz + dz / 2.0

        voxels.append(
            {
                "x": cx,
                "y": cy,
                "z": cz,
                "c": code_int,
            }
        )

    return VoxelModel(voxels=voxels, int_to_code=int_to_code)
