# Indicator Kriging Implementation Details

This document explains the C++ implementation of the **Indicator Kriging** algorithm used in `voxel_modeler.cpp`. The module generates a 3D voxel model from scattered soil profile data by interpolating the probability of each soil type at every grid point.

## 1. Overview

The implementation uses **Ordinary Kriging** applied to **Indicator Variables**. 

- **Indicator Variable**: For a specific soil type $k$, the variable $I(x)$ is 1 if the soil at location $x$ is type $k$, and 0 otherwise.
- **Ordinary Kriging**: An interpolation method that assumes the mean is constant but unknown, providing the "Best Linear Unbiased Estimator" (BLUE).

### Key Technologies
- **Eigen**: A high-performance linear algebra library used to solve the Kriging system ($Ax=b$).
- **Nanoflann**: A fast KD-Tree library used to find the $N$ nearest neighbors for each voxel.
- **OpenMP**: Used to parallelize the loop over millions of voxels.

## 2. The Algorithm

For each voxel in the grid:

### Step 1: Neighbor Search
We find the $N$ nearest data points (discretized soil layers) to the voxel center.
To account for geological stratification (layers are horizontal), we apply **Geometric Anisotropy**:
- The $Z$ coordinates are scaled by an `anisotropy_ratio` (e.g., 50.0) before calculating distances.
- This effective "stretches" space vertically, making neighbors in the same horizontal plane appear closer than those above or below.

### Step 2: Ordinary Kriging System
For a specific soil type, we want to find weights $w_i$ such that the estimate $Z^* = \sum w_i Z(x_i)$ is unbiased and has minimum variance. This leads to the following linear system:

$$
\begin{bmatrix}
\gamma(h_{11}) & \dots & \gamma(h_{1n}) & 1 \\
\vdots & \ddots & \vdots & \vdots \\
\gamma(h_{n1}) & \dots & \gamma(h_{nn}) & 1 \\
1 & \dots & 1 & 0
\end{bmatrix}
\begin{bmatrix}
w_1 \\
\vdots \\
w_n \\
\mu
\end{bmatrix}
=
\begin{bmatrix}
\gamma(h_{10}) \\
\vdots \\
\gamma(h_{n0}) \\
1
\end{bmatrix}
$$

Where:
- $\gamma(h)$ is the **Variogram** function (describing spatial continuity).
- $h_{ij}$ is the distance between neighbor $i$ and neighbor $j$.
- $h_{i0}$ is the distance between neighbor $i$ and the target voxel.
- $\mu$ is the Lagrange multiplier (enforcing $\sum w_i = 1$).

### Step 3: Solving the System
We construct the matrix $\mathbf{A}$ and vector $\mathbf{b}$ using the variogram model:
```cpp
double cov = sill - variogram(dist);
```
(Note: The code currently uses Covariance $C(h) = Sill - \gamma(h)$ formulation, which is equivalent).

We solve $\mathbf{A}\mathbf{x} = \mathbf{b}$ using `Eigen::PartialPivLU`. This solver is chosen because the Kriging matrix with Lagrange multipliers is symmetric but **indefinite** (has both positive and negative eigenvalues), so standard Cholesky decomposition would fail.

### Step 4: Probability Estimation
The weights $w_i$ obtained are independent of the data values (soil codes). They depend only on the geometry.
We estimate the probability for *each* unique soil type found in the neighborhood:

$$ P(\text{Soil} = k) = \sum_{i=1}^{N} w_i \cdot I(x_i = k) $$

Where $I(x_i=k)$ is 1 if neighbor $i$ is soil type $k$, else 0.

### Step 5: Classification
The soil type with the highest estimated probability is assigned to the voxel.

## 3. Code Structure

### `VoxelModeler` Class
- **`add_profiles`**: Discretizes `SoilProfile` objects into a point cloud.
- **`build`**: Constructs the KD-Tree index.
- **`generate`**: Main generation loop.
    - **OpenMP** (`#pragma omp parallel for`) distributes voxel computations across CPU cores.
    - **Optimization**: The covariance matrix $\mathbf{A}$ depends only on relative neighbor positions. (Future optimization: if neighbor configuration is identical, $\mathbf{A}$ could be reused, though currently it's rebuilt per voxel for simplicity).

### Python Bindings (`PYBIND11_MODULE`)
Exposes the C++ class to Python, allowing efficient data transfer using `pybind11::numpy` and `pybind11::stl`.
