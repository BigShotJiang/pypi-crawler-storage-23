from typing import Optional
import matplotlib.pyplot as plt

from ..objects.cpt import Cpt
from ..conversions.cpt_interpretor import (
    CptInterpretor,
    CptInterpretationMethod,
)
from ..objects.soil_collection import SoilCollection
from ..constants import DEFAULT_CPT_INTERPRETATION_PEAT_FRICTION_RATIO


class CptPlotter:
    def __init__(self, cpt: Cpt):
        self.cpt = cpt
        self.peat_friction_ratio = DEFAULT_CPT_INTERPRETATION_PEAT_FRICTION_RATIO
        self.minimum_layerheight = 0.1
        self.soil_collection = SoilCollection.default()

    def plot(
        self,
        show_robertson: bool = True,
        show_nl_rf: bool = False,
        show_three_type_rule: bool = False,
        to_file: Optional[str] = None,
    ):
        num_plots = 3 + show_robertson + show_nl_rf + show_three_type_rule

        plot_titles = ["qc", "fs", "fr"]
        if show_robertson:
            plot_titles.append("robertson")
        if show_nl_rf:
            plot_titles.append("nl_rf")
        if show_three_type_rule:
            plot_titles.append("three_type_rule")

        width_ratios = [3, 1, 1] + [1] * (num_plots - 3)

        fig, axs = plt.subplots(
            1, num_plots, sharey=True, width_ratios=width_ratios, figsize=(16, 9)
        )

        axs[0].plot(self.cpt.qc, self.cpt.z)
        axs[0].set_ylabel("diepte")
        axs[0].set_title("qc [MPa]")
        axs[1].plot(self.cpt.fs, self.cpt.z)
        axs[1].set_title("fs [MPa]")
        axs[2].plot(self.cpt.fr, self.cpt.z)
        axs[2].set_title("fr [%]")

        axs[0].grid(visible=True, which="both", color="gray", linestyle="--")
        axs[1].grid(visible=True, which="both", color="gray", linestyle="--")
        axs[2].grid(visible=True, which="both", color="gray", linestyle="--")

        axs[0].set_xlim([0, 30])
        axs[1].set_xlim([0, 0.2])
        axs[2].set_xlim([0, 10])

        if show_nl_rf or show_robertson or show_three_type_rule:
            interpretor = CptInterpretor(self.cpt)

        current_plot = 3

        if show_robertson:
            soil_profile = interpretor.to_soil_profile(
                method=CptInterpretationMethod.ROBERTSON,
                minimum_layerheight=self.minimum_layerheight,
                peat_friction_ratio=self.peat_friction_ratio,
            )
            for soil_layer in soil_profile.soil_layers:
                axs[current_plot].fill_between(
                    x=[0, 1],
                    y1=soil_layer.top,
                    y2=soil_layer.bottom,
                    color=self.soil_collection.color_dict[soil_layer.soil_code],
                )
            axs[current_plot].grid(
                visible=True, which="both", color="gray", linestyle="--"
            )
            axs[current_plot].set_title("Robertson")
            current_plot += 1

        if show_nl_rf:
            soil_profile = interpretor.to_soil_profile(
                method=CptInterpretationMethod.NL_RF,
                minimum_layerheight=self.minimum_layerheight,
                peat_friction_ratio=self.peat_friction_ratio,
            )
            for soil_layer in soil_profile.soil_layers:
                axs[current_plot].fill_between(
                    x=[0, 1],
                    y1=soil_layer.top,
                    y2=soil_layer.bottom,
                    color=self.soil_collection.color_dict[soil_layer.soil_code],
                )
            axs[current_plot].grid(
                visible=True, which="both", color="gray", linestyle="--"
            )
            axs[current_plot].set_title("CUR162")
            current_plot += 1

        if show_three_type_rule:
            soil_profile = interpretor.to_soil_profile(
                method=CptInterpretationMethod.THREE_TYPE_RULE,
                minimum_layerheight=self.minimum_layerheight,
                peat_friction_ratio=self.peat_friction_ratio,
            )
            for soil_layer in soil_profile.soil_layers:
                axs[current_plot].fill_between(
                    x=[0, 1],
                    y1=soil_layer.top,
                    y2=soil_layer.bottom,
                    color=self.soil_collection.color_dict[soil_layer.soil_code],
                )
            axs[current_plot].grid(
                visible=True, which="both", color="gray", linestyle="--"
            )
            axs[current_plot].set_title("3type rule")

        plt.suptitle(
            f"{self.cpt.name} (x={self.cpt.x}, y={self.cpt.y}, z={self.cpt.top})"
        )

        if to_file is not None:
            plt.savefig(to_file)

        return fig
