import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from typing import Dict, Optional, List
import numpy as np
from breinbaas.objects.voxel_model import VoxelModel


class VoxelModelPlotter:
    def __init__(
        self, voxel_model: VoxelModel, soil_colors: Optional[Dict[int, str]] = None
    ):
        self.voxel_model = voxel_model
        # If soil_colors is not provided, generate a default color map using unique soil codes
        self.soil_colors = soil_colors or self._generate_default_colors()

    def _generate_default_colors(self) -> Dict[int, str]:
        # Simple default color generation if not provided
        # This is a fallback and might not be pretty for many soil types
        unique_codes = self.voxel_model.int_to_code.keys()
        colors = plt.cm.get_cmap("tab20", len(unique_codes))
        return {code: colors(i) for i, code in enumerate(unique_codes)}

    def plot(
        self,
        show: bool = True,
        title: str = "Voxel Model",
        to_file: str = None,
    ):
        """
        Plots the voxel model in 3D using matplotlib scatter plot.
        Attempts to be somewhat efficient by only plotting known points.
        """
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection="3d")

        # Prepare data for scatter plot
        xs = []
        ys = []
        zs = []
        cs = []

        for voxel in self.voxel_model.voxels:
            code = voxel["c"]
            # Skip voxels with code -1 (UNKNOWN) or if not in color map
            if code == -1:
                continue

            color = self.soil_colors.get(code)
            if color:
                xs.append(voxel["x"])
                ys.append(voxel["y"])
                zs.append(voxel["z"])
                cs.append(color)

        if not xs:
            print("No voxels to plot.")
            return

        ax.scatter(xs, ys, zs, c=cs, marker="s", s=40)  # 's' for square, size 10

        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_zlabel("Z")
        ax.set_title(title)

        # Create a legend
        legend_elements = []
        for code, color in self.soil_colors.items():
            soil_name = self.voxel_model.int_to_code.get(code, f"Code {code}")
            legend_elements.append(
                plt.Line2D(
                    [0],
                    [0],
                    marker="s",
                    color="w",
                    label=soil_name,
                    markerfacecolor=color,
                    markersize=10,
                )
            )

        ax.legend(handles=legend_elements, loc="upper left", bbox_to_anchor=(1.05, 1))

        if show:
            plt.show()

        if to_file:
            fig.savefig(to_file)

        return fig
