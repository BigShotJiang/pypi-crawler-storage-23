from matplotlib.patches import Polygon
import matplotlib.pyplot as plt
from typing import List, Tuple

from ..conversions.cpt_interpretor import CptInterpretor, CptInterpretationMethod
from ..objects.geotechnical_profile import GeotechnicalProfile, GeoprofileCptLocation
from ..objects.soil_collection import SoilCollection

from ..constants import (
    DEFAULT_CPT_INTERPRETATION_MIN_LAYERHEIGHT,
    DEFAULT_CPT_INTERPRETATION_PEAT_FRICTION_RATIO,
    A4_SIZE_LANDSCAPE,
    DEFAULT_CHAINAGE_LENGTH_PER_PLOT,
    PLOT_WIDTH_FACTOR,
    PLOT_QC_MAX,
)


def get_color_transition(value):
    """
    Returns a color transitioning from Green (0) to Red (1).
    """
    # Ensure the value is clamped between 0 and 1
    value = max(0.0, min(1.0, value))

    # Calculate RGB components (0-255 scale)
    # As value increases, red goes up and green goes down.
    red = int(value * 255)
    green = int((1.0 - value) * 255)
    blue = 0

    # Format as a Hex string (e.g., #00ff00 for green)
    return f"#{red:02x}{green:02x}{blue:02x}"


class GeotechnicalProfilePlotter:
    def __init__(
        self,
        geotechnical_profile: GeotechnicalProfile,
        peat_friction_ratio: float = DEFAULT_CPT_INTERPRETATION_PEAT_FRICTION_RATIO,
        minimum_layerheight: float = DEFAULT_CPT_INTERPRETATION_MIN_LAYERHEIGHT,
        soil_collection: SoilCollection = SoilCollection.default(),
        chainage_length_per_plot: int = DEFAULT_CHAINAGE_LENGTH_PER_PLOT,
    ):
        self.geotechnical_profile = geotechnical_profile
        self.peat_friction_ratio = peat_friction_ratio
        self.minimum_layerheight = minimum_layerheight
        self.soil_collection = soil_collection
        self.chainage_length_per_plot = chainage_length_per_plot

    def _plot_cpts(self, ax, profile_cpts, zmin, zmax):
        ax.set_xlim(0, self.geotechnical_profile.length * 1.2)
        ax.set_ylim(zmin - 1.0, zmax + 7.0)

        soil_colors = self.soil_collection.color_dict

        for pcpt in profile_cpts:
            xleft = pcpt.chainage
            xright = (
                pcpt.chainage + PLOT_WIDTH_FACTOR * self.geotechnical_profile.length
            )

            cpt_interpretor = CptInterpretor(pcpt.cpt)

            soilprofile = cpt_interpretor.to_soil_profile(
                method=CptInterpretationMethod.NL_RF,
                peat_friction_ratio=self.peat_friction_ratio,
                minimum_layerheight=self.minimum_layerheight,
            )
            for layer in soilprofile.soil_layers:
                ax.add_patch(
                    plt.Rectangle(
                        (xleft, layer.bottom),
                        (xright - xleft),
                        layer.height,
                        color=soil_colors[layer.soil_code],
                        alpha=0.7,
                    )
                )

            for i in [0, 5, 10, 15, 20]:
                x = (
                    pcpt.chainage
                    + i
                    / PLOT_QC_MAX
                    * PLOT_WIDTH_FACTOR
                    * self.geotechnical_profile.length
                )
                xs = [x, x]
                zs = [zmin, zmax]
                ax.plot(xs, zs, color="gray", linestyle="--")

            x = [
                pcpt.chainage
                + min(qc, PLOT_QC_MAX)
                / PLOT_QC_MAX
                * PLOT_WIDTH_FACTOR
                * self.geotechnical_profile.length
                for qc in pcpt.cpt.qc
            ]
            z = pcpt.cpt.z
            ax.plot(x, z, "k")
            ax.text(xleft, zmax + 0.5, f"{pcpt.cpt.name}", rotation=60)

    def plot(
        self,
        to_file: str = None,
        plot_distance_risk: bool = False,
        safe_distance: float = None,
        unsafe_distance: float = None,
    ):
        if plot_distance_risk:
            if safe_distance is None:
                raise ValueError(
                    "safe_distance must be provided when plot_distance_risk is True"
                )
            if unsafe_distance is None:
                raise ValueError(
                    "unsafe_distance must be provided when plot_distance_risk is True"
                )

        zmin = min(pcpt.cpt.bottom for pcpt in self.geotechnical_profile.profile_cpts)
        zmax = max(pcpt.cpt.top for pcpt in self.geotechnical_profile.profile_cpts)
        if self.geotechnical_profile.is_2d:
            if plot_distance_risk:
                height_ratios = [48, 2, 48, 2]
                fig, axs = plt.subplots(
                    4,
                    1,
                    figsize=A4_SIZE_LANDSCAPE,
                    gridspec_kw={"height_ratios": height_ratios},
                )
                self._plot_cpts(
                    axs[0], self.geotechnical_profile.get_crest_cpts(), zmin, zmax
                )
                self._plot_cpts(
                    axs[2], self.geotechnical_profile.get_toe_cpts(), zmin, zmax
                )
                axs[0].grid(visible=True, which="both", color="gray", linestyle="--")
                axs[0].set_xlabel("Chainage (m)")
                axs[0].set_ylabel("Depth (m)")
                axs[0].set_title("Crest")
                axs[2].grid(visible=True, which="both", color="gray", linestyle="--")
                axs[2].set_xlabel("Chainage (m)")
                axs[2].set_ylabel("Depth (m)")
                axs[2].set_title("Toe")
                axs[1].set_xlim(0, self.geotechnical_profile.length * 1.2)
                axs[1].set_ylim(0, 1)
                axs[3].set_xlim(0, self.geotechnical_profile.length * 1.2)
                axs[3].set_ylim(0, 1)

                distance_risk_crest = self.geotechnical_profile.generate_distance_risk(
                    GeoprofileCptLocation.CREST
                )
                distance_risk_toe = self.geotechnical_profile.generate_distance_risk(
                    GeoprofileCptLocation.TOE
                )

                for i in range(1, len(distance_risk_crest)):
                    c1, r1 = distance_risk_crest[i - 1]
                    c2, r2 = distance_risk_crest[i]
                    r = (r1 + r2) / 2.0
                    r = max(r, safe_distance)
                    r = min(r, unsafe_distance)
                    r = (r - safe_distance) / (unsafe_distance - safe_distance)
                    color = get_color_transition(r)
                    axs[1].add_patch(
                        plt.Rectangle((c1, 0), c2 - c1, 1.0, color=color, alpha=0.7)
                    )

                for i in range(1, len(distance_risk_toe)):
                    c1, r1 = distance_risk_toe[i - 1]
                    c2, r2 = distance_risk_toe[i]
                    r = (r1 + r2) / 2.0
                    r = max(r, safe_distance)
                    r = min(r, unsafe_distance)
                    r = (r - safe_distance) / (unsafe_distance - safe_distance)
                    color = get_color_transition(r)
                    axs[3].add_patch(
                        plt.Rectangle((c1, 0), c2 - c1, 1.0, color=color, alpha=0.7)
                    )
            else:
                fig, axs = plt.subplots(2, 1, figsize=A4_SIZE_LANDSCAPE)
                self._plot_cpts(
                    axs[0], self.geotechnical_profile.get_crest_cpts(), zmin, zmax
                )
                self._plot_cpts(
                    axs[1], self.geotechnical_profile.get_toe_cpts(), zmin, zmax
                )
                axs[0].grid(visible=True, which="both", color="gray", linestyle="--")
                axs[0].set_xlabel("Chainage (m)")
                axs[0].set_ylabel("Depth (m)")
                axs[0].set_title("Crest")
                axs[1].grid(visible=True, which="both", color="gray", linestyle="--")
                axs[1].set_xlabel("Chainage (m)")
                axs[1].set_ylabel("Depth (m)")
                axs[1].set_title("Toe")

            plt.suptitle(self.geotechnical_profile.name)
        else:
            if plot_distance_risk:
                fig, axs = plt.subplots(
                    2,
                    1,
                    figsize=A4_SIZE_LANDSCAPE,
                    gridspec_kw={"height_ratios": [95, 5]},
                )
                self._plot_cpts(
                    axs[0], self.geotechnical_profile.profile_cpts, zmin, zmax
                )
                axs[0].grid(visible=True, which="both", color="gray", linestyle="--")
                axs[0].set_xlabel("Chainage (m)")
                axs[0].set_ylabel("Depth (m)")
                axs[0].set_xlim(0, self.geotechnical_profile.length * 1.2)

                distance_risk = self.geotechnical_profile.generate_distance_risk()
                for i in range(1, len(distance_risk)):
                    c1, r1 = distance_risk[i - 1]
                    c2, r2 = distance_risk[i]
                    r = (r1 + r2) / 2.0
                    r = max(r, safe_distance)
                    r = min(r, unsafe_distance)
                    r = (r - safe_distance) / (unsafe_distance - safe_distance)
                    color = get_color_transition(r)
                    axs[1].add_patch(
                        plt.Rectangle((c1, 0), c2 - c1, 1.0, color=color, alpha=0.7)
                    )
                axs[1].set_xlim(0, self.geotechnical_profile.length * 1.2)

                plt.suptitle(self.geotechnical_profile.name)
            else:
                fig, axs = plt.subplots(1, 1, figsize=A4_SIZE_LANDSCAPE)
                self._plot_cpts(axs, self.geotechnical_profile.profile_cpts, zmin, zmax)
                axs.grid(visible=True, which="both", color="gray", linestyle="--")

                axs.set_xlabel("Chainage (m)")
                axs.set_ylabel("Depth (m)")
                plt.title(self.geotechnical_profile.name)

        plt.tight_layout()

        if to_file is not None:
            plt.savefig(to_file)
        return fig

    def plot_with_object_or_cutoff(
        self,
        plot_cpts: bool = True,
        plot_boreholes: bool = False,
        object_line: List[Tuple[float, float]] = None,
        cut_off_line: List[Tuple[float, float]] = None,
        cut_off_below_object_line: bool = False,
        safe_distance: float = 10,
        unsafe_distance: float = 50,
        to_file: str = None,
    ):
        if len(self.geotechnical_profile.profile_cpts) == 0:
            raise ValueError("No CPTs in the geotechnical profile.")

        fig, axs = plt.subplots(
            2,
            1,
            figsize=A4_SIZE_LANDSCAPE,
            gridspec_kw={"height_ratios": [95, 5]},
        )

        zmin = min(pcpt.cpt.bottom for pcpt in self.geotechnical_profile.profile_cpts)
        zmax = max(pcpt.cpt.top for pcpt in self.geotechnical_profile.profile_cpts)
        if object_line is not None:
            zmin = min(zmin, min(p[1] for p in object_line))
            zmax = max(zmax, max(p[1] for p in object_line))

        axs[0].set_xlim(0, self.geotechnical_profile.length * 1.2)
        axs[0].set_ylim(zmin - 1.0, zmax + 7.0)

        soil_colors = self.soil_collection.color_dict

        if plot_cpts:
            for pcpt in self.geotechnical_profile.profile_cpts:
                xleft = pcpt.chainage
                xright = (
                    pcpt.chainage + PLOT_WIDTH_FACTOR * self.geotechnical_profile.length
                )

                cpt_interpretor = CptInterpretor(pcpt.cpt)

                soilprofile = cpt_interpretor.to_soil_profile(
                    method=CptInterpretationMethod.NL_RF,
                    peat_friction_ratio=self.peat_friction_ratio,
                    minimum_layerheight=self.minimum_layerheight,
                )
                for layer in soilprofile.soil_layers:
                    axs[0].add_patch(
                        plt.Rectangle(
                            (xleft, layer.bottom),
                            (xright - xleft),
                            layer.height,
                            color=soil_colors[layer.soil_code],
                            alpha=0.7,
                        )
                    )

                for i in [0, 5, 10, 15, 20]:
                    x = (
                        pcpt.chainage
                        + i
                        / PLOT_QC_MAX
                        * PLOT_WIDTH_FACTOR
                        * self.geotechnical_profile.length
                    )
                    xs = [x, x]
                    zs = [zmin, zmax]
                    axs[0].plot(xs, zs, color="gray", linestyle="--")

                x = [
                    pcpt.chainage
                    + min(qc, PLOT_QC_MAX)
                    / PLOT_QC_MAX
                    * PLOT_WIDTH_FACTOR
                    * self.geotechnical_profile.length
                    for qc in pcpt.cpt.qc
                ]
                z = pcpt.cpt.z
                axs[0].plot(x, z, "k")
                axs[0].text(xleft, zmax + 0.5, f"{pcpt.cpt.name}", rotation=60)

        # if plot_boreholes:
        #     for pborehole in self.profile_boreholes:
        #         xleft = pborehole.chainage
        #         xright = pborehole.chainage + PLOT_WIDTH_FACTOR * self.length

        #         for layer in pborehole.borehole.soil_profile.soillayers:
        #             ax.add_patch(
        #                 plt.Rectangle(
        #                     (xleft, layer.bottom),
        #                     (xright - xleft),
        #                     layer.height,
        #                     color=soil_colors[layer.soilcode],
        #                 )
        #             )

        #         ax.text(xleft, zmax + 0.5, f"{pborehole.borehole.name}", rotation=60)

        if object_line is not None:
            axs[0].plot(
                [p[0] for p in object_line],
                [p[1] for p in object_line],
                color="black",
                linestyle="-",
            )

        if cut_off_below_object_line and cut_off_line is not None:
            axs[0].plot(
                [p[0] for p in cut_off_line],
                [p[1] for p in cut_off_line],
                color="black",
                linestyle="--",
            )

            cut_off_line[-1][0] = self.geotechnical_profile.length * 1.2
            axs[0].add_patch(
                Polygon(
                    cut_off_line
                    + [[cut_off_line[-1][0], zmax], [cut_off_line[0][0], zmax]],
                    closed=True,
                    facecolor="white",
                    alpha=0.7,
                )
            )

        # if len(self.gas_pipeline) > 0:
        #     dl = 0
        #     gasline_plot_points = [(dl, self.gas_pipeline[0][2])]
        #     for i in range(len(self.gas_pipeline) - 1):
        #         p1 = self.gas_pipeline[i]
        #         p2 = self.gas_pipeline[i + 1]
        #         dl += hypot(p2[0] - p1[0], p2[1] - p1[1])
        #         gasline_plot_points.append((dl, p2[2]))
        #     ax.plot(
        #         [p[0] for p in gasline_plot_points],
        #         [p[1] for p in gasline_plot_points],
        #         color="red",
        #     )

        axs[0].grid(visible=True, which="both", color="gray", linestyle="--")
        axs[0].set_xlabel("Chainage (m)")
        axs[0].set_ylabel("Depth (m)")

        distance_risk = self.geotechnical_profile.generate_distance_risk()
        for i in range(1, len(distance_risk)):
            c1, r1 = distance_risk[i - 1]
            c2, r2 = distance_risk[i]
            r = (r1 + r2) / 2.0
            r = max(r, safe_distance)
            r = min(r, unsafe_distance)
            r = (r - safe_distance) / (unsafe_distance - safe_distance)
            color = get_color_transition(r)
            axs[1].add_patch(
                plt.Rectangle((c1, 0), c2 - c1, 1.0, color=color, alpha=0.7)
            )
        axs[1].set_xlim(0, self.geotechnical_profile.length * 1.2)

        plt.suptitle(self.geotechnical_profile.name)
        plt.tight_layout()

        if to_file is not None:
            plt.savefig(to_file)
        return fig
