import time
import brodata
from glob import glob
from pathlib import Path
from tqdm import tqdm

from bro_api import BROAPI

from breinbaas.databases.cpt_database import CPT_FILES_LOCATION


api = BROAPI()

xmin = 10
xmax = 280
ymin = 300
ymax = 620
dx = dy = 2

num = 0
handled_xy = []

# check if there is a file with the already handled x, y coordinates
if Path("handled_cpt_xy.txt").exists():
    with open("handled_cpt_xy.txt", "r") as f:
        for line in f.readlines():
            args = [int(a) for a in line.strip().split(",")]
            handled_xy.append(args)
else:
    handled_xy = []

# rewrite the handled_xy.txt file
f = open("handled_cpt_xy.txt", "w")
for x, y in handled_xy:
    f.write(f"{x},{y}\n")
f.close()


cpt_files = glob(f"{CPT_FILES_LOCATION}/*.xml")
downloaded_cpt_ids = [Path(f).stem for f in cpt_files]

for x in range(xmin, xmax, dx):
    for y in range(ymin, ymax, dy):
        if [x, y] in handled_xy:
            continue
        print(f"Processing {x}, {y}")
        left = x
        right = x + dx
        bottom = y
        top = y + dy

        try:
            # TODO > CPT_C ? ik zie soms CPT_O, worden deze overgeslagen?
            cpt_bro_ids = api.get_cpts_meta_data_by_bounds_rd(
                left=left * 1000,
                right=right * 1000,
                bottom=bottom * 1000,
                top=top * 1000,
            )
            print(f"Downloading {len(cpt_bro_ids)} CPTs...")
            for cpt_bro_id in tqdm(cpt_bro_ids):
                if cpt_bro_id in downloaded_cpt_ids:
                    continue
                num += 1
                to_path = f"{CPT_FILES_LOCATION}/{cpt_bro_id}.xml"
                try:
                    bro_cpt = brodata.cpt.ConePenetrationTest.from_bro_id(
                        cpt_bro_id, to_file=to_path
                    )
                except Exception as e:
                    print(f"Error downloading {cpt_bro_id}: {e}")
                    continue
            f = open("handled_cpt_xy.txt", "a")
            f.write(f"{x},{y}\n")
            f.close()
        except ValueError as e:
            if "No available objects have been found in given" in str(e):
                f = open("handled_cpt_xy.txt", "a")
                f.write(f"{x},{y}\n")
                f.close()
                continue
            continue
        except Exception as e:
            print(f"Error processing {x}, {y}: {e}")
            continue

        time.sleep(1.0)

print(f"Downloaded {num} CPTs")
