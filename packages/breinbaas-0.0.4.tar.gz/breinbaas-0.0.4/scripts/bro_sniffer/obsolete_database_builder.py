import sqlite3
import glob
import os
import brodata
from tqdm import tqdm

CPT_FILES_PATH = "/home/breinbaas/Development/Python/bro_sniffer/data/cpts"
CPT_DATABASE_PATH = (
    "/home/breinbaas/Development/Python/bro_sniffer/data/cpt_database.db"
)


class DatabaseBuilder:

    def __init__(self, db_path=CPT_DATABASE_PATH):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS xml_files (
                id TEXT PRIMARY KEY,
                x REAL,
                y REAL,
                z REAL,
                date TEXT,
                cpt_length REAL,
                xml_path TEXT UNIQUE
            )
        """
        )
        self.conn.commit()

    def add_from_directory(self, directory):
        """
        Finds all xml files in the given directory using glob and adds them to the database.
        """
        # Finds all xml files in the directory
        xml_files = glob.glob(os.path.join(directory, "*.xml"))

        for xml_file in tqdm(xml_files):
            # Add to database if not check is handled here
            if not self._file_exists(xml_file):
                try:
                    # User to implement extraction logic here
                    file_id, x, y, date, cpt_length = self._extract_info(xml_file)

                    self._insert_record(
                        file_id, x, y, date, float(cpt_length), xml_file
                    )
                    # print(f"Added {xml_file} to database.")
                except Exception as e:
                    print(f"Error processing {xml_file}: {e}")
            else:
                # print(f"File {xml_file} already exists in database.")
                pass

    def _file_exists(self, xml_path):
        self.cursor.execute("SELECT 1 FROM xml_files WHERE xml_path = ?", (xml_path,))
        return self.cursor.fetchone() is not None

    def _insert_record(self, file_id, x, y, date, cpt_length, xml_path):
        self.cursor.execute(
            """
            INSERT INTO xml_files (id, x, y, date, cpt_length, xml_path)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            (file_id, x, y, date, cpt_length, xml_path),
        )
        self.conn.commit()

    def _extract_info(self, xml_path):
        """
        Extracts id, x, and y from the xml file.
        """
        bro_cpt = brodata.cpt.ConePenetrationTest(xml_path)

        dt = bro_cpt.conePenetrationTest_phenomenonTime
        date_string = dt.strftime("%Y-%m-%d")
        return (
            bro_cpt.broId,
            bro_cpt.deliveredLocation.x,
            bro_cpt.deliveredLocation.y,
            date_string,
            bro_cpt.finalDepth,
        )

    def close(self):
        self.conn.close()


if __name__ == "__main__":
    builder = DatabaseBuilder()
    builder.add_from_directory(CPT_FILES_PATH)
    builder.close()
