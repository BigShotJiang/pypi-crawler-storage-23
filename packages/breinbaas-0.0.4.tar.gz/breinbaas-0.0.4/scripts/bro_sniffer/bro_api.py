from pydantic import BaseModel
import requests
import xmltodict
from typing import List, Tuple
from pyproj import Transformer

from bro_objects import Envelope, Point

BRO_CPT_DOWNLOAD_URL = "https://publiek.broservices.nl/sr/cpt/v1/objects"
BRO_CPT_CHARACTERISTICS_URL = (
    "https://publiek.broservices.nl/sr/cpt/v1/characteristics/searches"
)
BRO_BOREHOLE_CHARACTERISTICS_URL = (
    "https://publiek.broservices.nl/sr/bhrgt/v2/characteristics/searches"
)

BRO_API_REQUEST_LINE_DISTANCE = 1000  # the line length that is used per BRO call if you request data along a polyline


def xy_to_latlon(x: float, y: float, epsg: int = 28992) -> Tuple[float, float]:
    """Convert coordinates from the given epsg to latitude longitude coordinate

    Arguments:
        x (float): x coordinate
        y (float): y coordinate
        epsg (int): EPSG according to https://epsg.io/, defaults to 28992 (Rijksdriehoek coordinaten)

    Returns:
         Tuple[float, float]: latitude, longitude rounded to 6 decimals
    """
    if epsg == 4326:
        return x, y

    try:
        transformer = Transformer.from_crs(epsg, 4326)
        lat, lon = transformer.transform(x, y)
    except Exception as e:
        raise e

    return (round(lat, 7), round(lon, 7))


class BROAPI(BaseModel):

    def _get_boreholes_metadata_by_bounds(
        self,
        left: float,
        top: float,
        right: float,
        bottom: float,
    ):
        envelope = Envelope(
            lower_corner=Point(lat=left, lon=bottom),
            upper_corner=Point(lat=right, lon=top),
        )

        headers = {
            "accept": "application/xml",
            "Content-Type": "application/json",
        }

        json = {"area": envelope.bro_json}

        response = requests.post(
            BRO_BOREHOLE_CHARACTERISTICS_URL, headers=headers, json=json, timeout=10
        )

        bro_ids = []

        # TODO: Check status codes in BRO REST API documentation.
        if response.status_code == 200:
            parsed = xmltodict.parse(
                response.content, attr_prefix="", cdata_key="value"
            )
            rejection_reason = parsed["dispatchCharacteristicsResponse"].get(
                "brocom:rejectionReason"
            )
            if rejection_reason:
                raise ValueError(f"{rejection_reason}")

            nr_of_documents = int(
                parsed["dispatchCharacteristicsResponse"].get("numberOfDocuments")
            )
            if nr_of_documents is None or nr_of_documents == 0:
                raise ValueError(
                    "No available objects have been found in given date + area range. Retry with different parameters."
                )

            if nr_of_documents == 1:
                documents = [
                    parsed["dispatchCharacteristicsResponse"]["dispatchDocument"]
                ]
            else:
                documents = parsed["dispatchCharacteristicsResponse"][
                    "dispatchDocument"
                ]

            for document in documents:
                # ToDO, ook andere keys mogelijk?
                if "BHR_GT_C" not in document.keys():
                    continue

                bro_ids.append(f"{document['BHR_GT_C']['brocom:broId']}")

            return bro_ids

        response.raise_for_status()

    def _get_cpt_metadata_by_bounds(
        self,
        left: float,
        top: float,
        right: float,
        bottom: float,
    ):
        envelope = Envelope(
            lower_corner=Point(lat=left, lon=bottom),
            upper_corner=Point(lat=right, lon=top),
        )

        headers = {
            "accept": "application/xml",
            "Content-Type": "application/json",
        }

        json = {"area": envelope.bro_json}

        response = requests.post(
            BRO_CPT_CHARACTERISTICS_URL, headers=headers, json=json, timeout=10
        )

        bro_ids = []

        # TODO: Check status codes in BRO REST API documentation.
        if response.status_code == 200:
            parsed = xmltodict.parse(
                response.content, attr_prefix="", cdata_key="value"
            )
            rejection_reason = parsed["dispatchCharacteristicsResponse"].get(
                "brocom:rejectionReason"
            )
            if rejection_reason:
                raise ValueError(f"{rejection_reason}")

            nr_of_documents = int(
                parsed["dispatchCharacteristicsResponse"].get("numberOfDocuments")
            )
            if nr_of_documents is None or nr_of_documents == 0:
                raise ValueError(
                    "No available objects have been found in given date + area range. Retry with different parameters."
                )

            if nr_of_documents == 1:
                documents = [
                    parsed["dispatchCharacteristicsResponse"]["dispatchDocument"]
                ]
            else:
                documents = parsed["dispatchCharacteristicsResponse"][
                    "dispatchDocument"
                ]

            for document in documents:
                if "CPT_C" not in document.keys():
                    continue

                bro_ids.append(f"{document['CPT_C']['brocom:broId']}")

            return bro_ids

        response.raise_for_status()

    def get_cpts_meta_data_by_bounds_rd(
        self,
        left: float,
        right: float,
        top: float,
        bottom: float,
    ):
        lat1, lon1 = xy_to_latlon(left, bottom)
        lat2, lon2 = xy_to_latlon(right, top)

        cpt_bro_ids = self._get_cpt_metadata_by_bounds(
            left=lat1,
            top=lon2,
            right=lat2,
            bottom=lon1,
        )

        return cpt_bro_ids

    def get_boreholes_meta_data_by_bounds_rd(
        self,
        left: float,
        right: float,
        top: float,
        bottom: float,
    ):
        lat1, lon1 = xy_to_latlon(left, bottom)
        lat2, lon2 = xy_to_latlon(right, top)

        borehole_bro_ids = self._get_boreholes_metadata_by_bounds(
            left=lat1,
            top=lon2,
            right=lat2,
            bottom=lon1,
        )

        return borehole_bro_ids
