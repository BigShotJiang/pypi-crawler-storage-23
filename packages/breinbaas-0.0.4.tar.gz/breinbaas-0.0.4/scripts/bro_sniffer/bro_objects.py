from pyproj import Transformer
from pydantic import BaseModel
from typing import Optional


def _str2bool(s) -> bool:
    """
    converts a value to bool based on certain
    :param s: int, str, float
    :return: bool
    """
    return str(s).lower() in ("ja", "yes", "true", "t", "1")


class Point(BaseModel):
    lat: float
    lon: float

    def from_wgs84_to_rd(self) -> "RDPoint":
        transformer = Transformer.from_crs(4326, 28992)
        rd_x, rd_y = transformer.transform(self.lat, self.lon)
        return RDPoint(x=rd_x, y=rd_y)


class RDPoint(BaseModel):
    x: float
    y: float

    def from_rd_to_wgs84(self) -> "Point":
        transformer = Transformer.from_crs(28992, 4326)
        lat, lon = transformer.transform(self.x, self.y)
        return Point(lat=lat, lon=lon)


class Envelope(BaseModel):
    lower_corner: Point
    upper_corner: Point

    @property
    def bro_json(self):
        return {
            "boundingBox": {
                "lowerCorner": {
                    "lat": self.lower_corner.lat,
                    "lon": self.lower_corner.lon,
                },
                "upperCorner": {
                    "lat": self.upper_corner.lat,
                    "lon": self.upper_corner.lon,
                },
            }
        }

    @property
    def to_geojson_feature(self) -> dict:
        return {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [self.lower_corner.lon, self.lower_corner.lat],
                        [self.upper_corner.lon, self.lower_corner.lat],
                        [self.upper_corner.lon, self.upper_corner.lat],
                        [self.lower_corner.lon, self.upper_corner.lat],
                        [self.lower_corner.lon, self.lower_corner.lat],
                    ]
                ],
            },
            "properties": {"description": "Requested area"},
        }


class BroIdentifier:
    def __init__(self, parsed_dispatch_document: dict):
        self.id: str = parsed_dispatch_document["brocom:broId"]
