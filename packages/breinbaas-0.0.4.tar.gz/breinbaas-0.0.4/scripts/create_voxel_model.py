from breinbaas.objects.soil_profile import SoilProfile
from breinbaas.objects.soil_layer import SoilLayer
from breinbaas.voxels.kriging import generate_voxel_model
from breinbaas.plotters.voxel_model_plotter import VoxelModelPlotter

p1 = SoilProfile(
    x=0,
    y=0,
    soil_layers=[
        SoilLayer(top=-2, bottom=-5, soil_code="CLAY"),
        SoilLayer(top=-5, bottom=-7, soil_code="PEAT"),
        SoilLayer(top=-7, bottom=-9, soil_code="SAND"),
    ],
)
p2 = SoilProfile(
    x=10,
    y=10,
    soil_layers=[
        SoilLayer(top=0, bottom=-4, soil_code="CLAY"),
        SoilLayer(top=-4, bottom=-6, soil_code="PEAT"),
        SoilLayer(top=-6, bottom=-10, soil_code="SAND"),
    ],
)

p3 = SoilProfile(
    x=3,
    y=3,
    soil_layers=[
        SoilLayer(top=-3, bottom=-6, soil_code="CLAY"),
        SoilLayer(top=-6, bottom=-10, soil_code="SAND"),
    ],
)


profiles = [p1, p2, p3]

# Generate model for a point in between
model = generate_voxel_model(
    profiles,
    x_min=0,
    x_max=10,
    dx=1.0,
    y_min=0,
    y_max=10,
    dy=1.0,
    z_min=-10,
    z_max=0,
    dz=1.0,
)

soil_colors = {0: "#55aa3c", 1: "#BC641E", 2: "#f8dda6"}

plotter = VoxelModelPlotter(model, soil_colors)
plotter.plot(to_file="tests/testdata/output/plots/voxel_model_complex.png")

model.to_obj("tests/testdata/output/voxels/voxel_model_complex.obj", soil_colors=soil_colors)
