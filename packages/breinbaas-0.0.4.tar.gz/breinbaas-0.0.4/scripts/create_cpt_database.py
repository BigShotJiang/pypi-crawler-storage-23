# Werkwijze
#
# Kopieer de beschikbare CPTs naar de map /home/breinbaas/Documents/Breinbaas/sonderingen/data
# Pas het pad aan in cpt_database.py zodat het wijst naar de juiste mappen
# Voer dit script uit

from breinbaas.databases.cpt_database import (
    CptDatabase,
    CPT_FILES_LOCATION,
    CPT_DATABASE_CSV,
    CPT_MINI_DATABASE
)

cpt_database = CptDatabase()
cpt_database.add_from_directory(CPT_FILES_LOCATION, new_database=False)
cpt_database.to_csv(CPT_DATABASE_CSV)
cpt_database.to_mini_database(CPT_MINI_DATABASE)
cpt_database.close()




