from breinbaas.databases.borehole_database import (
    BoreholeDatabase,
    BOREHOLE_FILES_LOCATION,
    BOREHOLE_DATABASE_CSV,
    BOREHOLE_MINI_DATABASE
)

borehole_database = BoreholeDatabase()
borehole_database.add_from_directory(BOREHOLE_FILES_LOCATION, new_database=False)
borehole_database.to_csv(BOREHOLE_DATABASE_CSV)
borehole_database.to_mini_database(BOREHOLE_MINI_DATABASE)
borehole_database.close()
