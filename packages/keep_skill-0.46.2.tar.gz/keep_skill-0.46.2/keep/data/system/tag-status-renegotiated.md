---
tags:
  category: system
  context: tag-value
---
# status: `renegotiated`

Terms changed — a new commitment, request, or offer replaces this one. The original is closed; the replacement should be linked or referenced. Terminal state for the original.
