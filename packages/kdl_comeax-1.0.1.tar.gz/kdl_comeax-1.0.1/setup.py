from setuptools import setup, find_packages

setup(
    name="kdl-comeax",
    version="1.0.1",
    packages=["kdl"],
    package_dir={"kdl": "."},
    install_requires=["requests"],
)
