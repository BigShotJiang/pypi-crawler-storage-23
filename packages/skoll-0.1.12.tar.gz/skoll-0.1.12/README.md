# Skoll

A simple package that provide a basic API python framework based on starlette and some domain driven design concepts.

## Installation

```bash
pip install skoll
```

## Usage

Comming soon...

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
