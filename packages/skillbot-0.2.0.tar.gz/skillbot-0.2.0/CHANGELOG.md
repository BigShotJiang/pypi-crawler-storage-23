## v0.2.0 (2026-02-23)

### Feat

- skillbot repo setup (#1)
