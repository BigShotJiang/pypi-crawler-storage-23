# vzdump - Backup Utility

*[Chapter Index](_index.md) | [Main Index](../SKILL.md)*

A.16


```
vzdump - Backup Utility for VMs and Containers
```


```
vzdump help
```


```
vzdump {<vmid>} [OPTIONS]
```

Create backup.

<vmid>: <string>
The ID of the guest system you want to backup.

- `--all` <boolean> (default = 0)
Backup all known guest systems on this host.

- `--bwlimit` <integer> (0 - N) (default = 0)
Limit I/O bandwidth (in KiB/s).

- `--compress` <0 | 1 | gzip | lzo | zstd> (default = 0)
Compress dump file.

- `--dumpdir` <string>
Store resulting files to specified directory.

- `--exclude` <string>
Exclude specified guest systems (assumes --all)

- `--exclude-path` <array>
Exclude certain files/directories (shell globs). Paths starting with / are anchored to the container’s
root, other paths match relative to each subdirectory.

- `--fleecing` [[enabled=]<1|0>] [,storage=<storage ID>]
Options for backup fleecing (VM only).

- `--ionice` <integer> (0 - 8) (default = 7)
Set IO priority when using the BFQ scheduler. For snapshot and suspend mode backups of VMs, this
only affects the compressor. A value of 8 means the idle priority is used, otherwise the best-effort
priority is used with the specified value.

- `--job-id` \S+
The ID of the backup job. If set, the backup-job metadata field of the backup notification will be set to
this value. Only root@pam can set this parameter.

- `--lockwait` <integer> (0 - N) (default = 180)
Maximal time to wait for the global lock (minutes).

- `--mailnotification` <always | failure> (default = always)
Deprecated: use notification targets/matchers instead. Specify when to send a notification mail


- `--mailto` <string>
Deprecated: Use notification targets/matchers instead. Comma-separated list of email addresses or
users that should receive email notifications.

- `--maxfiles` <integer> (1 - N)
Deprecated: use prune-backups instead. Maximal number of backup files per guest system.

- `--mode` <snapshot | stop | suspend> (default = snapshot)
Backup mode.

- `--node` <string>
Only run if executed on this node.

- `--notes-template` <string>
Template string for generating notes for the backup(s). It can contain variables which will be replaced
by their values. Currently supported are {\{\cluster}}, {\{\guestname}}, {\{\node}}, and {\{\vmid}}, but
more might be added in the future. Needs to be a single line, newline and backslash need to be
escaped as \n and \\ respectively.

> **Note:**
> Requires option(s): storage


- `--notification-mode` <auto | legacy-sendmail | notification-system>
(default = auto)
Determine which notification system to use. If set to legacy-sendmail, vzdump will consider the mailto/mailnotification parameters and send emails to the specified address(es) via the sendmail command.
If set to notification-system, a notification will be sent via PVE’s notification system, and the mailto and
mailnotification will be ignored. If set to auto (default setting), an email will be sent if mailto is set, and
the notification system will be used if not.

- `--pbs-change-detection-mode` <data | legacy | metadata>
PBS mode used to detect file changes and switch encoding format for container backups.

- `--performance` [max-workers=<integer>] [,pbs-entries-max=<integer>]
Other performance-related settings.

- `--pigz` <integer> (default = 0)
Use pigz instead of gzip when N>0. N=1 uses half of cores, N>1 uses N as thread count.

- `--pool` <string>
Backup all known guest systems included in the specified pool.

- `--protected` <boolean>
If true, mark backup(s) as protected.


> **Note:**
> Requires option(s): storage


- `--prune-backups` [keep-all=<1|0>] [,keep-daily=<N>]
[,keep-hourly=<N>] [,keep-last=<N>] [,keep-monthly=<N>]
[,keep-weekly=<N>] [,keep-yearly=<N>] (default = keep-all=1)
Use these retention options instead of those from the storage configuration.

- `--quiet` <boolean> (default = 0)
Be quiet.

- `--remove` <boolean> (default = 1)
Prune older backups according to prune-backups.

- `--script` <string>
Use specified hook script.

- `--stdexcludes` <boolean> (default = 1)
Exclude temporary files and logs.

- `--stdout` <boolean>
Write tar to stdout, not to a file.

- `--stop` <boolean> (default = 0)
Stop running backup jobs on this host.

- `--stopwait` <integer> (0 - N) (default = 10)
Maximal time to wait until a guest system is stopped (minutes).

- `--storage` <storage ID>
Store resulting file to this storage.

- `--tmpdir` <string>
Store temporary files to specified directory.

- `--zstd` <integer> (default = 1)
Zstd threads. N=0 uses half of the available cores, if N is set to a value bigger than 0, N is used as
thread count.

A.17


```
ha-manager - Proxmox VE HA Manager
```


```
ha-manager <COMMAND> [ARGS] [OPTIONS]
```


```
ha-manager add <sid> [OPTIONS]
```

Create a new HA resource.


<sid>: <type>:<name>
HA resource ID. This consists of a resource type followed by a resource specific name, separated with
colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or
CT id as a shortcut (example: 100).

- `--comment` <string>
Description.

- `--failback` <boolean> (default = 1)
Automatically migrate HA resource to the node with the highest priority according to their node affinity
rules, if a node with a higher priority than the current node comes online.

- `--group` <string>
The HA group identifier.

- `--max_relocate` <integer> (0 - N) (default = 1)
Maximal number of service relocate tries when a service failes to start.

- `--max_restart` <integer> (0 - N) (default = 1)
Maximal number of tries to restart the service on a node after its start failed.

- `--state` <disabled | enabled | ignored | started | stopped> (default =
started)
Requested resource state.

- `--type` <ct | vm>
Resource type.

```
ha-manager config [OPTIONS]
```

List HA resources.

- `--type` <ct | vm>
Only list resources of specific type

```
ha-manager crm-command migrate <sid> <node>
```

Request resource migration (online) to another node.

<sid>: <type>:<name>
HA resource ID. This consists of a resource type followed by a resource specific name, separated with
colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or
CT id as a shortcut (example: 100).

<node>: <string>
Target node.

## See also

- [Backup and Restore](../ch16-backup-restore/_index.md)

