# Roadmap

We ([textualize.io](https://www.textualize.io/)) are actively building and maintaining Textual.

We have many new features in the pipeline. This page will keep track of that work.

## Features

High-level features we plan on implementing.

- [ ] Accessibility
    * [ ] Integration with screen readers
    * [x] Monochrome mode
    * [ ] High contrast theme
    * [ ] Color-blind themes
- [X] Command palette
    * [X] Fuzzy search
- [ ] Configuration (.toml based extensible configuration format)
- [x] Console
- [ ] Devtools
    * [ ] Integrated log
    * [ ] DOM tree view
    * [ ] REPL
- [ ] Reactive state abstraction
- [x] Themes
    * [ ] Customize via config
    * [ ] Builtin theme editor

## Widgets

Widgets are key to making user-friendly interfaces. The builtin widgets should cover many common (and some uncommon) use-cases. The following is a list of the widgets we have built or are planning to build.

- [x] Buttons
    * [x] Error / warning variants
- [ ] Color picker
- [X] Checkbox
- [X] Content switcher
- [x] DataTable
    * [x] Cell select
    * [x] Row / Column select
    * [x] API to update cells / rows
    * [ ] Lazy loading API
- [ ] Date picker
- [ ] Drop-down menus
- [ ] Form Widget
    * [ ] Serialization / Deserialization
    * [ ] Export to `attrs` objects
    * [ ] Export to `PyDantic` objects
- [ ] Image support
    * [ ] Half block
    * [ ] Braille
    * [ ] Sixels, and other image extensions
- [x] Input
    * [x] Validation
    * [ ] Error / warning states
    * [ ] Template types: IP address, physical units (weight, volume), currency, credit card etc
- [X] Select control (pull-down)
- [X] Markdown viewer
    * [ ] Collapsible sections
    * [ ] Custom widgets
- [ ] Plots
    * [ ] bar chart
    * [ ] line chart
    * [ ] Candlestick chars
- [X] Progress bars
    * [ ] Style variants (solid, thin etc)
- [X] Radio boxes
- [X] Spark-lines
- [X] Switch
- [X] Tabs
- [X] TextArea (multi-line input)
    * [X] Basic controls
    * [ ] Indentation guides
    * [ ] Smart features for various languages
    * [X] Syntax highlighting

---

**See also**

- [Widget Gallery](./widget_gallery.md) - Visual overview of currently available widgets
- [Help](./help.md) - Report bugs or request features
- [Getting Started](./getting_started.md) - Get started with Textual
