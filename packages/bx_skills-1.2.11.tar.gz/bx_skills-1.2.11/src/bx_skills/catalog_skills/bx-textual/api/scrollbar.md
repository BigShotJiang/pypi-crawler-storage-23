*API reference: `textual.scrollbar`*
