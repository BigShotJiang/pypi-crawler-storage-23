*API reference: `textual.lazy`*
