*API reference: `textual.suggester`*
