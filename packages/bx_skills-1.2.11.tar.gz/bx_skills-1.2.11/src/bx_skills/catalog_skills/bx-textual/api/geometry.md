*API reference: `textual.geometry`*
