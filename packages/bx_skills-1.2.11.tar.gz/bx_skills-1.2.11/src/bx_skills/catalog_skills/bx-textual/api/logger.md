*API reference: `textual`*
