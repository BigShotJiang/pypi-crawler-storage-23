# email-mcp

[![Release](https://img.shields.io/github/v/release/flora535/email-mcp)](https://img.shields.io/github/v/release/flora535/email-mcp)
[![Build status](https://img.shields.io/github/actions/workflow/status/flora535/email-mcp/main.yml?branch=main)](https://github.com/flora535/email-mcp/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/flora535/email-mcp)](https://img.shields.io/github/commit-activity/m/flora535/email-mcp)
[![License](https://img.shields.io/github/license/flora535/email-mcp)](https://img.shields.io/github/license/flora535/email-mcp)

IMAP and SMTP via MCP Server
