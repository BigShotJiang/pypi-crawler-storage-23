# don't modify this file
from collections.abc import Generator
from enum import Enum
from itertools import combinations

from lxml import etree as ET
from pydantic import BaseModel

from pantoqa_bridge.server_synced_models.data_models.misc import BoxCoord


class ElementType(str, Enum):
  Button = "Button"
  TextView = "TextView"
  ImageView = "ImageView"
  Element = "Element"

  def __str__(self):
    return self.value


class NodeElement(BaseModel):
  tag: str | None = None
  text: str | None = None
  resource_id: str | None = None
  content_desc: str | None = None
  classname: str | None = None
  bounds: str | None = None
  _node: ET._Element | None = None
  _cached_bounds: str | None = None
  _cached_coords: BoxCoord | None = None

  def get_any_text(self):
    return self.text or self.content_desc

  def _validate_bounds_cache(self):
    if self.bounds and self._cached_bounds == self.bounds:
      return

    if not self.bounds:
      raise KeyError("Failed to parse: Bounds is empty")

    b = self.bounds.replace("][", ",").replace("[", "").replace("]", "")

    x1, y1, x2, y2 = map(int, b.split(","))
    # normalize to x1<=x2, y1<=y2
    if x2 < x1:
      x1, x2 = x2, x1
    if y2 < y1:
      y1, y2 = y2, y1

    self._cached_bounds = self.bounds
    self._cached_coords = BoxCoord(
      x1=x1,
      y1=y1,
      x2=x2,
      y2=y2,
    )

  @property
  def parsed_bounds(self) -> tuple[int, int, int, int]:
    self._validate_bounds_cache()
    assert self._cached_coords, "Failed to parse: Bounds is empty"
    return self._cached_coords.x1, self._cached_coords.y1, \
      self._cached_coords.x2, self._cached_coords.y2

  @property
  def coord(self) -> BoxCoord:
    self._validate_bounds_cache()
    assert self._cached_coords, "Failed to parse: Bounds is empty"
    return self._cached_coords

  def get_area(self):
    pb = self.parsed_bounds
    return (pb[2] - pb[0]) * (pb[3] - pb[1])

  def get_element_type(self) -> ElementType:
    classname = self.classname
    if not classname:
      return ElementType.Element
    classname = classname.lower()
    button_type_class_kw = [
      "button",
    ]
    text_view_type_class_kw = [
      "textview",
      "edittext",
      "textarea",
    ]
    image_view_type_class_kw = [
      "imageview",
    ]

    for kw in button_type_class_kw:
      if kw in classname:
        return ElementType.Button
    for kw in text_view_type_class_kw:
      if kw in classname:
        return ElementType.TextView
    for kw in image_view_type_class_kw:
      if kw in classname:
        return ElementType.ImageView

    return ElementType.Element

  @staticmethod
  def from_xml_node(node: ET._Element) -> "NodeElement":

    rid = node.attrib.get("resource-id")
    if rid and " " in rid:
      rid = None

    elem = NodeElement(
      tag=node.tag,
      text=node.attrib.get("text"),
      resource_id=rid,
      content_desc=node.attrib.get("content-desc") or "",
      classname=node.attrib.get("class") or "",
      bounds=node.attrib.get("bounds"),
    )
    elem._node = node
    return elem

  def get_xpath(
    self,
    depth: int | None = None,
    include_text: bool = True,
    include_content_desc: bool = True,
  ) -> str | None:
    xpath = self._get_parent_based_xpath(
      depth=depth if depth is not None else 50,
      include_text=include_text,
      include_content_desc=include_content_desc,
    )
    return xpath or self._get_index_based_xpath(
      include_text=include_text,
      include_content_desc=include_content_desc,
    )

  def _get_index_based_xpath(self, include_text: bool, include_content_desc: bool) -> str | None:
    if self._node is None:
      raise ValueError("Node is None")

    all_possible_xpaths = self._get_all_possible_xpaths(include_text=include_text,
                                                        include_content_desc=include_content_desc)
    root = self._node.getroottree().getroot()

    for xpath in all_possible_xpaths:
      matches = root.xpath(xpath)
      if not isinstance(matches, list):
        continue
      _matches = list(matches)
      count = len(_matches)
      if count == 0:
        continue
      if count == 1:
        return xpath
      for index, match in enumerate(_matches):
        if match == self._node:
          return f"({xpath})[{index + 1}]"

    return None

  def _get_parent_based_xpath(self,
                              depth=3,
                              include_text: bool = True,
                              include_content_desc: bool = True) -> str | None:
    if self._node is None:
      raise ValueError("Node is None")

    all_possible_xpaths = self._get_all_possible_xpaths(include_text=include_text,
                                                        include_content_desc=include_content_desc)

    for xpath in all_possible_xpaths:
      if self._is_unique_xpath(xpath):
        return xpath

    parent = self.get_parent()

    if parent is None:
      return None
    assert parent._node is not None, "Parent node is None"

    child_index = parent._node.index(self._node)

    parent_xpath = parent._get_parent_based_xpath(
      depth=depth - 1, include_text=include_text,
      include_content_desc=include_content_desc) if depth > 0 else None
    if not parent_xpath:
      return None

    # try with parent xpath
    for xpath in all_possible_xpaths:
      candidate = f"{parent_xpath}{xpath[1:]}"
      if self._is_unique_xpath(candidate):
        return candidate

    # include sibling index with parent xpath
    for xpath in all_possible_xpaths:
      candidate = f"{parent_xpath}{xpath[1:]}[{child_index + 1}]"
      if self._is_unique_xpath(candidate):
        return candidate

    return None

  def get_parent(self) -> "NodeElement | None":
    if self._node is None:
      return None
    parent_node = self._node.getparent()
    if parent_node is None:
      return None
    return NodeElement.from_xml_node(parent_node)

  def get_iter(self) -> "Generator[NodeElement, None, None]":
    if self._node is not None:
      for child in self._node.iter():
        yield NodeElement.from_xml_node(child)

  def get_unique_selectors(
    self,
    include_text: bool,
    include_content_desc: bool,
  ) -> tuple[str | None, str | None]:
    if self._node is None:
      return None, None

    if self.resource_id:
      rid_xpath = f'//*[@resource-id="{self.resource_id}"]'
      if self._is_unique_xpath(rid_xpath):
        return self.resource_id, rid_xpath

    return None, self.get_xpath(
      include_text=include_text,
      include_content_desc=include_content_desc,
    )

  def _is_unique_xpath(self, xpath: str) -> bool:
    if self._node is None:
      raise ValueError("Node is None")
    root = self._node.getroottree().getroot()
    return is_xpath_unique(root, xpath)

  def _get_all_possible_xpaths(self, include_text: bool, include_content_desc: bool) -> list[str]:
    predicates = []

    tag = self.tag or "*"
    if tag == 'node':
      tag = '*'

    if self.resource_id:
      predicates.append(f'@resource-id="{_clean(self.resource_id)}"')

    if include_text and self.text:
      predicates.append(f'@text="{_clean(self.text)}"')

    if include_content_desc and self.content_desc:
      predicates.append(f'@content-desc="{_clean(self.content_desc)}"')

    if self.classname and self.tag != self.classname:
      predicates.append(f'@class="{_clean(self.classname)}"')

    composite_xpaths = []
    for i in range(1, len(predicates) + 1):
      for combo in combinations(predicates, i):
        composite = " and ".join(combo)
        composite_xpaths.append(f"//{tag}[{composite}]")

    all_xpaths = []
    for predicate in predicates:
      if predicate.startswith("@"):
        predicate = predicate[1:]
      all_xpaths.append(f"//{tag}[@{predicate}]")
    all_xpaths.extend(composite_xpaths)

    if len(all_xpaths) == 0 and self.tag != 'node':
      all_xpaths.append(f"//{tag}")

    return all_xpaths


NodeElements = list[NodeElement]


def get_xpath_match_count(
  xml_root: ET._Element,
  xpath: str,
) -> int:
  try:
    matches = xml_root.xpath(xpath)
    return len(matches) if isinstance(matches, list) else 0
  except Exception:
    return 0


def is_xpath_unique(
  xml_root: ET._Element,
  xpath: str,
) -> bool:
  """True if exactly one node matches the xpath; False otherwise."""
  count = get_xpath_match_count(xml_root, xpath)
  return count == 1


def _clean(val: str | None) -> str:
  if not val:
    return ""
  return val.replace("'", "&apos;").replace('"', "&quot;")
