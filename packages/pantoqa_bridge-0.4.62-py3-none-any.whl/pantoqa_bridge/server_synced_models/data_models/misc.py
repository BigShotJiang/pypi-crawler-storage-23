from pydantic import BaseModel


class BoxCoord(BaseModel):
  x1: int
  y1: int
  x2: int
  y2: int


class Coord(BaseModel):
  x: int
  y: int
