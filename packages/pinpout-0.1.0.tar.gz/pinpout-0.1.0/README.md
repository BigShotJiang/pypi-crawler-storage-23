# Pinpout Python SDK

Python SDK for the [Pinpout](https://pinpout.dev) Prompt Injection Detection API.

## Installation

```bash
pip install pinpout
```

## Quick Start

```python
import pinpout

# Uses PINPOUT_API_KEY environment variable
result = pinpout.scan("What is the capital of France?")

if result.is_safe:
    print("Safe to pass to LLM")
else:
    print(f"Injection detected (confidence: {result.confidence})")
```

## Explicit Client

```python
from pinpout import Pinpout

client = Pinpout("pp_live_your_key_here")
result = client.scan("Hello world")

print(result.is_safe)       # True
print(result.confidence)    # 0.98
print(result.scan_id)       # "scan_abc123"
```

## Async

```python
from pinpout import AsyncPinpout

async with AsyncPinpout("pp_live_your_key_here") as client:
    result = await client.scan("Hello world")
```

## Normalized Text

```python
result = client.scan("h3ll0 w0rld", return_normalized=True)
print(result.normalized_text)  # "hello world"
```

## Error Handling

```python
from pinpout import Pinpout, AuthenticationError, RateLimitError

client = Pinpout("pp_live_your_key_here")

try:
    result = client.scan("test")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited, retry after {e.retry_after}s")
```

## Configuration

| Parameter | Env Variable | Default |
|-----------|-------------|---------|
| `api_key` | `PINPOUT_API_KEY` | — (required) |
| `base_url` | `PINPOUT_BASE_URL` | `https://api.pinpout.dev` |
| `timeout` | — | `30.0` |

## License

MIT
