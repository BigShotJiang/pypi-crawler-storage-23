"""Pinpout — Prompt Injection Detection SDK."""

from ._client import AsyncPinpout, Pinpout
from ._exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConnectionError,
    PinpoutError,
    QuotaExceededError,
    RateLimitError,
    TimeoutError,
)
from ._models import ScanResult
from ._version import __version__

__all__ = [
    "__version__",
    "APIError",
    "AsyncPinpout",
    "AuthenticationError",
    "BadRequestError",
    "ConnectionError",
    "Pinpout",
    "PinpoutError",
    "QuotaExceededError",
    "RateLimitError",
    "scan",
    "ScanResult",
    "TimeoutError",
]

_default_client: Pinpout | None = None


def scan(text: str, *, return_normalized: bool = False) -> ScanResult:
    """Scan text for prompt injection using a module-level default client.

    Reads the API key from the PINPOUT_API_KEY environment variable.
    """
    global _default_client
    if _default_client is None:
        _default_client = Pinpout()
    return _default_client.scan(text, return_normalized=return_normalized)
