from __future__ import annotations

from pydantic import BaseModel


class ScanResult(BaseModel):
    """Result of a prompt injection scan."""

    is_safe: bool
    confidence: float
    scan_id: str
    normalized_text: str | None = None
