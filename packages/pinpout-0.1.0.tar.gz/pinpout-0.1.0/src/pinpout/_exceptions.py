from __future__ import annotations


class PinpoutError(Exception):
    """Base exception for all Pinpout SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class AuthenticationError(PinpoutError):
    """Invalid or missing API key (HTTP 401)."""


class RateLimitError(PinpoutError):
    """Too many requests (HTTP 429)."""

    def __init__(self, message: str, retry_after: float | None = None) -> None:
        self.retry_after = retry_after
        super().__init__(message)


class QuotaExceededError(PinpoutError):
    """Usage quota exceeded (HTTP 403)."""


class BadRequestError(PinpoutError):
    """Invalid request payload (HTTP 400)."""


class APIError(PinpoutError):
    """Unexpected server error (HTTP 5xx)."""

    def __init__(self, message: str, status_code: int) -> None:
        self.status_code = status_code
        super().__init__(message)


class ConnectionError(PinpoutError):
    """Failed to connect to Pinpout API."""


class TimeoutError(PinpoutError):
    """Request to Pinpout API timed out."""
