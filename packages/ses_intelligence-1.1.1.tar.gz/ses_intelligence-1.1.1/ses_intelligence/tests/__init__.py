"""
Test suite for ses_intelligence package.
"""
