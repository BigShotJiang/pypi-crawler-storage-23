#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from .guifunc import gui
from .BCIbox import simulateVV
from .BCIbox import plotKonrads
from .BCIbox import fit
