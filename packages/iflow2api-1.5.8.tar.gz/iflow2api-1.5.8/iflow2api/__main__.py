"""iflow2api 命令行入口"""

from .app import main

if __name__ == "__main__":
    main()
