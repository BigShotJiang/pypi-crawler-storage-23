from strictdoc.core.environment import SDocRuntimeEnvironment

__version__ = "0.18.1"


environment = SDocRuntimeEnvironment(__file__)
