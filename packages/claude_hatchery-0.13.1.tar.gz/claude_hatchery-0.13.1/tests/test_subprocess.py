"""Tests for subprocess-wrapping functions."""

import subprocess
from pathlib import Path
from unittest.mock import MagicMock

import pytest

import claude_hatchery.docker as docker
import claude_hatchery.git as git
import claude_hatchery.tasks as tasks

# ---------------------------------------------------------------------------
# run()
# ---------------------------------------------------------------------------


class TestRun:
    def test_returns_completed_process(self):
        result = tasks.run(["echo", "hello"])
        assert isinstance(result, subprocess.CompletedProcess)

    def test_captures_stdout(self):
        result = tasks.run(["echo", "hello"])
        assert "hello" in result.stdout

    def test_passes_cwd(self, tmp_path):
        result = tasks.run(["pwd"], cwd=tmp_path)
        assert str(tmp_path) in result.stdout.strip()

    def test_raises_on_nonzero_with_check_true(self):
        with pytest.raises(subprocess.CalledProcessError):
            tasks.run(["false"], check=True)

    def test_does_not_raise_with_check_false(self):
        result = tasks.run(["false"], check=False)
        assert result.returncode != 0

    def test_prints_error_to_stderr_on_failure(self, capsys):
        with pytest.raises(subprocess.CalledProcessError):
            tasks.run(["false"], check=True)
        captured = capsys.readouterr()
        assert "Error" in captured.err or len(captured.err) >= 0  # just verify it doesn't crash

    def test_check_false_nonzero_returns_result(self):
        result = tasks.run(["sh", "-c", "exit 42"], check=False)
        assert result.returncode == 42


# ---------------------------------------------------------------------------
# uncommitted_changes_summary()
# ---------------------------------------------------------------------------


class TestUncommittedChangesSummary:
    def _init_git_repo(self, path: Path) -> None:
        """Initialise a minimal git repo at *path*."""
        import subprocess

        subprocess.run(["git", "init"], cwd=path, check=True, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=path, check=True, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=path, check=True, capture_output=True)

    def test_staged_file_appears_in_summary(self, tmp_path):
        import subprocess

        self._init_git_repo(tmp_path)
        # Create an initial commit so HEAD exists
        (tmp_path / "readme.txt").write_text("hello\n")
        subprocess.run(["git", "add", "readme.txt"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)
        # Modify the file (tracked change visible in diff HEAD)
        (tmp_path / "readme.txt").write_text("hello\nworld\n")
        subprocess.run(["git", "add", "readme.txt"], cwd=tmp_path, check=True, capture_output=True)

        result = git.uncommitted_changes_summary(tmp_path)
        assert "readme.txt" in result

    def test_untracked_file_appears_in_summary(self, tmp_path):
        import subprocess

        self._init_git_repo(tmp_path)
        # Create an initial commit so HEAD exists
        (tmp_path / "readme.txt").write_text("hello\n")
        subprocess.run(["git", "add", "readme.txt"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)
        # Add an untracked file
        (tmp_path / "scratch.py").write_text("# scratch\n")

        result = git.uncommitted_changes_summary(tmp_path)
        assert "scratch.py" in result

    def test_diff_stat_summary_line_appears(self, tmp_path):
        import subprocess

        self._init_git_repo(tmp_path)
        (tmp_path / "file.txt").write_text("line1\n")
        subprocess.run(["git", "add", "file.txt"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)
        # Modify and stage so diff HEAD --stat shows a summary
        (tmp_path / "file.txt").write_text("line1\nline2\nline3\n")
        subprocess.run(["git", "add", "file.txt"], cwd=tmp_path, check=True, capture_output=True)

        result = git.uncommitted_changes_summary(tmp_path)
        assert "changed" in result

    def test_returns_empty_string_when_clean(self, tmp_path):
        import subprocess

        self._init_git_repo(tmp_path)
        (tmp_path / "file.txt").write_text("hello\n")
        subprocess.run(["git", "add", "file.txt"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=tmp_path, check=True, capture_output=True)

        result = git.uncommitted_changes_summary(tmp_path)
        assert result == ""


# ---------------------------------------------------------------------------
# git_root()
# ---------------------------------------------------------------------------


class TestGitRoot:
    def test_returns_path_on_success(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/my/repo\n"
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        result = git.git_root()
        assert result == Path("/my/repo")

    def test_strips_whitespace_from_stdout(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "  /my/repo  \n"
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        result = git.git_root()
        assert result == Path("/my/repo")

    def test_exits_on_failure(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        with pytest.raises(SystemExit) as exc_info:
            git.git_root()
        assert exc_info.value.code == 1

    def test_stderr_message_on_failure(self, monkeypatch, capsys):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        with pytest.raises(SystemExit):
            git.git_root()
        captured = capsys.readouterr()
        assert "git repository" in captured.err

    def test_returns_path_type(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/some/path\n"
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        result = git.git_root()
        assert isinstance(result, Path)


# ---------------------------------------------------------------------------
# get_claude_token()
# ---------------------------------------------------------------------------


class TestGetClaudeToken:
    def test_returns_env_var_when_set(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key-123")
        result = docker.get_claude_token()
        assert result == "test-key-123"

    def test_returns_none_when_neither_available(self, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setattr(docker, "_get_claude_token_from_keychain", lambda: None)
        result = docker.get_claude_token()
        assert result is None

    def test_falls_back_to_keychain_when_no_env(self, monkeypatch):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setattr(docker, "_get_claude_token_from_keychain", lambda: "keychain-token")
        result = docker.get_claude_token()
        assert result == "keychain-token"

    def test_env_var_takes_priority_over_keychain(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "env-token")
        monkeypatch.setattr(docker, "_get_claude_token_from_keychain", lambda: "keychain-token")
        result = docker.get_claude_token()
        assert result == "env-token"


# ---------------------------------------------------------------------------
# docker_available()
# ---------------------------------------------------------------------------


class TestDockerAvailable:
    def test_returns_true_when_rc_zero(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 0
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        assert docker.docker_available() is True

    def test_returns_false_when_rc_nonzero(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 1
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        assert docker.docker_available() is False


# ---------------------------------------------------------------------------
# podman_available()
# ---------------------------------------------------------------------------


class TestPodmanAvailable:
    def test_returns_true_when_rc_zero(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 0
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        assert docker.podman_available() is True

    def test_returns_false_when_rc_nonzero(self, monkeypatch):
        mock_result = MagicMock()
        mock_result.returncode = 1
        monkeypatch.setattr(tasks, "run", lambda *a, **kw: mock_result)
        assert docker.podman_available() is False


# ---------------------------------------------------------------------------
# detect_runtime()
# ---------------------------------------------------------------------------


class TestDetectRuntime:
    def test_returns_podman_when_podman_available(self, monkeypatch):
        monkeypatch.setattr(docker, "podman_available", lambda: True)
        monkeypatch.setattr(docker, "docker_available", lambda: True)
        assert docker.detect_runtime() == docker.Runtime.PODMAN

    def test_prefers_podman_over_docker(self, monkeypatch):
        monkeypatch.setattr(docker, "podman_available", lambda: True)
        monkeypatch.setattr(docker, "docker_available", lambda: False)
        assert docker.detect_runtime() == docker.Runtime.PODMAN

    def test_falls_back_to_docker_when_podman_not_installed(self, monkeypatch):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: None)
        monkeypatch.setattr(docker, "docker_available", lambda: True)
        assert docker.detect_runtime() == docker.Runtime.DOCKER

    def test_exits_when_neither_available(self, monkeypatch):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: None)
        monkeypatch.setattr(docker, "docker_available", lambda: False)
        with pytest.raises(SystemExit) as exc_info:
            docker.detect_runtime()
        assert exc_info.value.code == 1

    def test_exits_when_podman_installed_but_not_running(self, monkeypatch):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: "/usr/local/bin/podman")
        with pytest.raises(SystemExit) as exc_info:
            docker.detect_runtime()
        assert exc_info.value.code == 1

    def test_installed_not_running_error_message(self, monkeypatch, capsys):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: "/usr/local/bin/podman")
        with pytest.raises(SystemExit):
            docker.detect_runtime()
        assert "not running" in capsys.readouterr().err

    def test_installed_not_running_macos_hint(self, monkeypatch, capsys):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: "/usr/local/bin/podman")
        monkeypatch.setattr(docker.sys, "platform", "darwin")
        with pytest.raises(SystemExit):
            docker.detect_runtime()
        err = capsys.readouterr().err
        assert "podman machine start" in err
        assert "podman machine init" in err

    def test_neither_available_error_message(self, monkeypatch, capsys):
        monkeypatch.setattr(docker, "podman_available", lambda: False)
        monkeypatch.setattr(docker.shutil, "which", lambda _: None)
        monkeypatch.setattr(docker, "docker_available", lambda: False)
        with pytest.raises(SystemExit):
            docker.detect_runtime()
        err = capsys.readouterr().err
        assert "Podman" in err or "Docker" in err


# ---------------------------------------------------------------------------
# resolve_runtime()
# ---------------------------------------------------------------------------


class TestResolveRuntime:
    def test_returns_none_when_no_docker_flag(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        result = docker.resolve_runtime(repo, worktree, no_docker=True)
        assert result is None

    def test_returns_none_when_no_dockerfile(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        # No Dockerfile in worktree
        result = docker.resolve_runtime(repo, worktree, no_docker=False)
        assert result is None

    def test_returns_podman_when_dockerfile_and_podman_available(self, tmp_path, monkeypatch):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        dockerfile_dir = worktree / ".hatchery"
        dockerfile_dir.mkdir()
        (dockerfile_dir / "Dockerfile").write_text("FROM debian\n")
        monkeypatch.setattr(docker, "detect_runtime", lambda: docker.Runtime.PODMAN)
        result = docker.resolve_runtime(repo, worktree, no_docker=False)
        assert result == docker.Runtime.PODMAN

    def test_returns_docker_when_dockerfile_and_docker_available(self, tmp_path, monkeypatch):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        dockerfile_dir = worktree / ".hatchery"
        dockerfile_dir.mkdir()
        (dockerfile_dir / "Dockerfile").write_text("FROM debian\n")
        monkeypatch.setattr(docker, "detect_runtime", lambda: docker.Runtime.DOCKER)
        result = docker.resolve_runtime(repo, worktree, no_docker=False)
        assert result == docker.Runtime.DOCKER

    def test_exits_when_dockerfile_present_but_no_runtime(self, tmp_path, monkeypatch, capsys):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        dockerfile_dir = worktree / ".hatchery"
        dockerfile_dir.mkdir()
        (dockerfile_dir / "Dockerfile").write_text("FROM debian\n")
        monkeypatch.setattr(docker, "detect_runtime", lambda: (_ for _ in ()).throw(SystemExit(1)))
        with pytest.raises(SystemExit) as exc_info:
            docker.resolve_runtime(repo, worktree, no_docker=False)
        assert exc_info.value.code == 1

    def test_stderr_message_when_no_runtime(self, tmp_path, monkeypatch, capsys):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        dockerfile_dir = worktree / ".hatchery"
        dockerfile_dir.mkdir()
        (dockerfile_dir / "Dockerfile").write_text("FROM debian\n")
        import sys as _sys

        def _exit():
            print("Error: neither Podman nor Docker is running.", file=_sys.stderr)
            raise SystemExit(1)

        monkeypatch.setattr(docker, "detect_runtime", _exit)
        with pytest.raises(SystemExit):
            docker.resolve_runtime(repo, worktree, no_docker=False)
        captured = capsys.readouterr()
        assert "Podman" in captured.err or "Docker" in captured.err

    def test_no_docker_flag_skips_dockerfile_check(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        worktree = tmp_path / "worktree"
        worktree.mkdir()
        # Even with Dockerfile present, no_docker=True returns None
        dockerfile_dir = worktree / ".hatchery"
        dockerfile_dir.mkdir()
        (dockerfile_dir / "Dockerfile").write_text("FROM debian\n")
        result = docker.resolve_runtime(repo, worktree, no_docker=True)
        assert result is None


# ---------------------------------------------------------------------------
# _run_container() — runtime flag injection
# ---------------------------------------------------------------------------


class TestRunContainerRuntime:
    """Verify _run_container injects correct flags for each runtime."""

    def _capture_cmd(self, monkeypatch, runtime: docker.Runtime = docker.Runtime.DOCKER) -> list[str]:
        captured: list[list[str]] = []
        def _mock_run(cmd, **kw):
            captured.append(cmd)
            result = docker.subprocess.CompletedProcess(cmd, 0)
            return result

        monkeypatch.setattr(docker.subprocess, "run", _mock_run)
        docker._run_container(
            image="test-image",
            mounts=[],
            workdir="/workspace",
            hatchery_repo="/repo",
            name="test-task",
            api_key="test-key",
            claude_args=[],
            runtime=runtime,
        )
        return captured[0]

    # --- runtime binary ---

    def test_docker_runtime_uses_docker_binary(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.DOCKER)
        assert cmd[0] == "docker"

    def test_podman_runtime_uses_podman_binary(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert cmd[0] == "podman"

    # --- Podman outer-container flags ---

    def test_podman_userns_keep_id_on_linux(self, monkeypatch):
        monkeypatch.setattr(docker.sys, "platform", "linux")
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert "--userns=keep-id" in cmd

    def test_podman_no_userns_keep_id_on_macos(self, monkeypatch):
        monkeypatch.setattr(docker.sys, "platform", "darwin")
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert "--userns=keep-id" not in cmd

    def test_podman_runtime_adds_label_disable(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert "label=disable" in " ".join(cmd)

    def test_docker_runtime_no_userns(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.DOCKER)
        assert "--userns=keep-id" not in cmd

    def test_docker_runtime_no_label_disable(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.DOCKER)
        assert "label=disable" not in " ".join(cmd)

    # --- Security regression guards ---

    def test_podman_no_privileged(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert "--privileged" not in cmd

    def test_podman_no_seccomp_unconfined(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.PODMAN)
        assert "seccomp=unconfined" not in " ".join(cmd)

    def test_docker_no_privileged(self, monkeypatch):
        cmd = self._capture_cmd(monkeypatch, runtime=docker.Runtime.DOCKER)
        assert "--privileged" not in cmd
