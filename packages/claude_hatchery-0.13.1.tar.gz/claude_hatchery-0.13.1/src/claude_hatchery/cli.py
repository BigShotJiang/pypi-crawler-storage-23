"""Click CLI entry point — group + all 7 commands."""

import importlib.metadata
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

import click

import claude_hatchery.docker as docker
import claude_hatchery.git as git
import claude_hatchery.tasks as tasks

logger = logging.getLogger("claude-hatchery")


def configure_logging(level: str, log_file: str | None = None) -> None:
    numeric = getattr(logging, level.upper(), logging.WARNING)
    fmt = logging.Formatter("%(asctime)s  %(levelname)s  %(name)s: %(message)s")

    handler: logging.Handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(fmt)
    logger.addHandler(handler)

    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    logger.setLevel(numeric)


try:
    _version = importlib.metadata.version("claude-hatchery")
except importlib.metadata.PackageNotFoundError:
    _version = "0.0.0+dev"


# ---------------------------------------------------------------------------
# Update check
# ---------------------------------------------------------------------------

_UPDATE_CHECK_CACHE = Path.home() / ".hatchery" / "update-check.json"
_UPDATE_CHECK_TTL_SECONDS = 86400  # 24 hours (successful fetch)
_UPDATE_CHECK_RETRY_SECONDS = 3600  # 1 hour (failed fetch / server unreachable)
_SIMPLE_URL = "https://pypi.org/simple/claude-hatchery/"


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse 'X.Y.Z' (or 'X.Y.Z.devN') into a sortable integer tuple."""
    return tuple(int(x) for x in v.split(".")[:3] if x.isdigit())


def _fetch_latest_pypi_version() -> str | None:
    """Return the latest claude-hatchery version from the PyPI simple index."""
    try:
        with urllib.request.urlopen(_SIMPLE_URL, timeout=3) as resp:  # noqa: S310
            content = resp.read().decode()
        versions = re.findall(r"claude.hatchery-([0-9]+\.[0-9]+\.[0-9]+)", content)
        if not versions:
            return None
        return max(set(versions), key=_parse_version)
    except Exception:
        return None


def _check_for_update() -> tuple[str, str] | None:
    """Return (latest, current) if an update is available, else None.

    Uses a 24-hour on-disk cache to avoid hitting the registry on every
    invocation. Failed fetches (e.g. off VPN) are also cached so that a
    single unreachable server doesn't add a timeout delay to every command.
    All errors are silently swallowed so the CLI never fails due to this check.
    """
    try:
        now = datetime.now(tz=timezone.utc)

        # Read cache — a fresh entry suppresses the network fetch even if
        # latest_version is None (meaning the last fetch failed).
        needs_fetch = True
        latest: str | None = None
        if _UPDATE_CHECK_CACHE.exists():
            try:
                cached = json.loads(_UPDATE_CHECK_CACHE.read_text())
                checked_at = datetime.fromisoformat(cached["checked_at"])
                latest = cached.get("latest_version")
                ttl = _UPDATE_CHECK_TTL_SECONDS if latest else _UPDATE_CHECK_RETRY_SECONDS
                if (now - checked_at).total_seconds() < ttl:
                    needs_fetch = False
            except Exception:
                pass  # corrupt cache — fall through to a fresh fetch

        if needs_fetch:
            latest = _fetch_latest_pypi_version()
            try:
                _UPDATE_CHECK_CACHE.parent.mkdir(parents=True, exist_ok=True)
                _UPDATE_CHECK_CACHE.write_text(json.dumps({"checked_at": now.isoformat(), "latest_version": latest}))
            except Exception:
                pass  # non-fatal if we can't write the cache

        if latest and _parse_version(latest) > _parse_version(_version):
            return (latest, _version)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Launch helpers
# ---------------------------------------------------------------------------

_BANNER_WIDTH = 49


def _print_banner(name: str, repo: Path) -> None:
    bar = "━" * _BANNER_WIDTH
    print(f"{bar}")
    print(f"  Task:    {name}")
    print(f"  Repo:    {repo}")
    print(f"  Version: {_version}")
    print(f"{bar}")


def _is_task_complete(content: str) -> bool:
    return bool(re.search(r"^\*\*Status\*\*:\s*complete", content, re.MULTILINE))


def _do_mark_done(name: str, repo: Path, worktree: Path) -> None:
    meta = tasks.load_task(repo, name)
    no_worktree = meta.get("no_worktree", False)

    if not no_worktree:
        if worktree.exists():
            task_path = tasks.find_task_file(worktree, name)
            if task_path and task_path.exists():
                content = task_path.read_text()
                if "## Summary" not in content:
                    msg = "task file has no ## Summary section — agent may not have completed cleanly."
                    logger.warning(msg)
                    print(f"Warning: {msg}")

            if git.has_uncommitted_changes(worktree):
                msg = "worktree has uncommitted changes."
                logger.warning(msg)
                print(f"Warning: {msg}")
                print(git.uncommitted_changes_summary(worktree))
                answer = input("Commit them as a final checkpoint before removing? [Y/n] ").strip().lower()
                if answer != "n":
                    tasks.run(["git", "add", "-A"], cwd=worktree)
                    tasks.run(["git", "commit", "-m", f"task({name}): final checkpoint"], cwd=worktree)

            logger.info("Removing worktree %s", worktree)
            git.remove_worktree(repo, worktree)
            print(f"Worktree removed: {worktree}")
        else:
            print(f"Worktree already gone: {worktree}")

    meta["status"] = "complete"
    meta["completed"] = datetime.now().isoformat()
    tasks.save_task(meta)
    logger.info("Task '%s' marked complete", name)

    if not no_worktree:
        print(f"Branch retained: {meta['branch']}")
    print(f"Task '{name}' marked complete.")


_WRAP_UP_PROMPT = (
    "The user has indicated they believe this task is complete. "
    "Please review the task file and assess whether the work is actually done. "
    "If it is complete, update the task file: set **Status** to `complete`, "
    "fill in the `## Summary` section documenting key decisions, patterns "
    "established, gotchas, and anything a future agent should know, then remove "
    "the `## Agreed Plan` and `## Progress Log` sections — they are working "
    "scaffolding, not permanent record. The final file should read as a clean "
    "ADR: Status/Branch/Created → Objective → Context → Summary. "
    "If work remains unfinished, tell the user what is still outstanding and ask "
    "whether they want to continue working or close the task out anyway."
)


def _do_delete(name: str, repo: Path, worktree: Path, meta: dict) -> None:
    branch = meta["branch"]
    no_worktree = meta.get("no_worktree", False)

    if not no_worktree:
        if worktree.exists():
            if git.has_uncommitted_changes(worktree):
                print("Warning: there are uncommitted changes in the worktree.")
            answer = input(f"Delete task '{name}' (worktree + branch + metadata)? [y/N] ").strip().lower()
            if answer != "y":
                print("Aborted.")
                return
            git.remove_worktree(repo, worktree, force=True)
        else:
            answer = input(f"Delete task '{name}' (branch + metadata)? [y/N] ").strip().lower()
            if answer != "y":
                print("Aborted.")
                return
        if git.delete_branch(repo, branch):
            print(f"Branch deleted: {branch}")
        else:
            print(f"Could not delete branch {branch} (may already be gone)")
    else:
        answer = input(f"Delete task '{name}' (metadata only)? [y/N] ").strip().lower()
        if answer != "y":
            print("Aborted.")
            return

    tasks.task_db_path(repo, name).unlink(missing_ok=True)
    print(f"Task '{name}' deleted.")


def _launch_claude_finalize(
    repo: Path,
    worktree: Path,
    name: str,
    session_id: str,
    runtime: docker.Runtime | None,
    branch: str,
    main_branch: str,
    no_worktree: bool = False,
) -> None:
    env_ctx = tasks.sandbox_context(name, branch, worktree, repo, main_branch, runtime is not None, no_worktree)
    system_prompt = tasks.SESSION_SYSTEM + "\n" + env_ctx
    claude_args = [
        f"--append-system-prompt={system_prompt}",
        f"--resume={session_id}",
        _WRAP_UP_PROMPT,
    ]
    _print_banner(name, repo)
    if runtime is not None:
        if no_worktree:
            docker.launch_docker_no_worktree(worktree, name, claude_args, runtime)
        else:
            docker.launch_docker(repo, worktree, name, claude_args, runtime)
    else:
        os.chdir(worktree)
        subprocess.run(["claude"] + claude_args, env=_session_env(name, repo))
    _post_exit_check(name, repo, worktree, no_worktree)


def _post_exit_check(name: str, repo: Path, worktree: Path, no_worktree: bool = False) -> None:
    bar = "━" * _BANNER_WIDTH
    task_path = tasks.find_task_file(worktree, name)
    if task_path and task_path.exists():
        content = task_path.read_text()
        if _is_task_complete(content):
            print(f"\n{bar}")
            print("  Task appears complete.")
            print(f"{bar}")
            answer = input(f"Mark task '{name}' as done? [Y/n] ").strip().lower()
            if answer != "n":
                _do_mark_done(name, repo, worktree)
            else:
                print(f"Use `claude-hatchery done {name}` to mark complete later.")
            return
    # Not complete (or file not found)
    print(f"\n{bar}")
    print("  Task is not complete.")
    print(f"{bar}")
    print()
    print("  w) Wrap up         — relaunch Claude to finalize the task file")
    print("  x) Delete          — remove this task permanently")
    print(f"  l) Leave for later — exit now; resume with `claude-hatchery resume {name}`")
    print()
    choice = input("Choice [w/x/l, Enter = leave for later]: ").strip().lower()
    if choice == "w":
        meta = tasks.load_task(repo, name)
        session_id = meta.get("session_id")
        if not session_id:
            print("Error: no session ID found. Cannot relaunch.", file=sys.stderr)
            return
        runtime = docker.resolve_runtime(repo, worktree, no_docker=False)
        main_branch = git.get_default_branch(repo)
        _launch_claude_finalize(repo, worktree, name, session_id, runtime, meta["branch"], main_branch, no_worktree)
    elif choice == "x":
        meta = tasks.load_task(repo, name)
        _do_delete(name, repo, worktree, meta)
    else:
        print(f"Use `claude-hatchery resume {name}` to continue.")


def _prompt_objective() -> str:
    """Rich multi-line prompt for the task description (prompt_toolkit)."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.input.ansi_escape_sequences import ANSI_SEQUENCES
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.keys import Keys

    # Shift+Enter sequences are in the ANSI table but mapped to ControlM (same
    # as plain Enter), making them indistinguishable.  Remap them to ControlJ
    # so we can bind them to "insert newline" instead of "submit".
    #   \x1b[27;2;13~  — xterm modifyOtherKeys (iTerm2, xterm, etc.)
    #   \x1b[13;2u     — kitty keyboard protocol
    ANSI_SEQUENCES["\x1b[27;2;13~"] = Keys.ControlJ
    ANSI_SEQUENCES["\x1b[13;2u"] = Keys.ControlJ

    kb = KeyBindings()

    @kb.add("c-j")  # shift+enter (remapped above)
    @kb.add("escape", "enter")  # alt+enter fallback
    def _(event) -> None:
        event.current_buffer.insert_text("\n")

    @kb.add("enter")
    def _(event) -> None:
        event.current_buffer.validate_and_handle()

    print("\nDescribe the task:\n")
    session: PromptSession[str] = PromptSession(key_bindings=kb, multiline=True)
    return session.prompt("> ").strip()


def _session_env(name: str, repo: Path) -> dict[str, str]:
    """Env vars that identify the hatchery session to child processes (e.g. statusline scripts)."""
    return {**os.environ, "HATCHERY_TASK": name, "HATCHERY_REPO": str(repo)}


def _launch_claude_new(
    repo: Path,
    worktree: Path,
    name: str,
    session_id: str,
    runtime: docker.Runtime | None,
    branch: str,
    main_branch: str,
    no_worktree: bool = False,
) -> None:
    tasks.write_skills(worktree)
    env_ctx = tasks.sandbox_context(name, branch, worktree, repo, main_branch, runtime is not None, no_worktree)
    system_prompt = tasks.SESSION_SYSTEM + "\n" + env_ctx
    claude_args = [
        "--permission-mode=plan",
        f"--append-system-prompt={system_prompt}",
        f"--session-id={session_id}",
        tasks.session_prompt(name, worktree),
    ]
    _print_banner(name, repo)
    if runtime is not None:
        if no_worktree:
            docker.launch_docker_no_worktree(worktree, name, claude_args, runtime)
        else:
            docker.launch_docker(repo, worktree, name, claude_args, runtime)
    else:
        os.chdir(worktree)
        subprocess.run(["claude"] + claude_args, env=_session_env(name, repo))
    _post_exit_check(name, repo, worktree, no_worktree)


def _launch_claude_resume(
    repo: Path,
    worktree: Path,
    name: str,
    session_id: str,
    runtime: docker.Runtime | None,
    branch: str,
    main_branch: str,
    no_worktree: bool = False,
) -> None:
    tasks.write_skills(worktree)
    env_ctx = tasks.sandbox_context(name, branch, worktree, repo, main_branch, runtime is not None, no_worktree)
    system_prompt = tasks.SESSION_SYSTEM + "\n" + env_ctx
    claude_args = [
        "--permission-mode=plan",
        f"--append-system-prompt={system_prompt}",
        f"--resume={session_id}",
    ]
    _print_banner(name, repo)
    if runtime is not None:
        if no_worktree:
            docker.launch_docker_no_worktree(worktree, name, claude_args, runtime)
        else:
            docker.launch_docker(repo, worktree, name, claude_args, runtime)
    else:
        os.chdir(worktree)
        subprocess.run(["claude"] + claude_args, env=_session_env(name, repo))
    _post_exit_check(name, repo, worktree, no_worktree)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=_version, prog_name="claude-hatchery")
@click.option(
    "--log-level",
    default="WARNING",
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"]),
    help="Set log verbosity (default: WARNING)",
)
@click.option("--log-file", type=click.Path(), default=None, help="Also write logs to this file")
def cli(log_level: str, log_file: str | None) -> None:
    """Claude Code task orchestration."""
    configure_logging(log_level, log_file)
    update = _check_for_update()
    if update:
        latest, current = update
        click.echo(
            click.style(
                f"Note: claude-hatchery {latest} is available (you have {current}). Run: claude-hatchery self update",
                fg="yellow",
                bold=True,
            ),
            err=True,
        )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@cli.command("new")
@click.argument("name")
@click.option(
    "--from",
    "base",
    default=tasks.DEFAULT_BASE,
    metavar="REF",
    help=f"Branch or commit to fork from (default: {tasks.DEFAULT_BASE})",
)
@click.option("--no-docker", is_flag=True, help="Run Claude directly, even if a Dockerfile is present")
@click.option(
    "--no-worktree",
    is_flag=True,
    help="Work directly in the current directory; skip worktree and branch creation",
)
@click.option("--no-editor", is_flag=True, help="Skip opening $EDITOR for the task file")
def cmd_new(name: str, base: str, no_docker: bool, no_worktree: bool, no_editor: bool) -> None:
    """Start a new task."""
    repo, in_repo = git.git_root_or_cwd()
    if not in_repo:
        no_worktree = True
        print("Note: not in a git repository — running without worktree isolation.")

    tasks.ensure_claude_tasks_dir(repo)
    if in_repo:
        tasks.ensure_gitignore(repo)
        df_created = docker.ensure_dockerfile(repo)
        dc_created = docker.ensure_docker_config(repo)
        if df_created or dc_created:
            print("  Committing...")
            tasks.run(
                ["git", "add", str(tasks.DOCKERFILE), str(tasks.DOCKER_CONFIG)],
                cwd=repo,
            )
            tasks.run(
                ["git", "commit", "-m", "chore: add hatchery Docker configuration"],
                cwd=repo,
            )

    name = tasks.to_name(name)
    db_path = tasks.task_db_path(repo, name)
    if db_path.exists():
        existing = json.loads(db_path.read_text())
        if existing.get("status") == "in-progress":
            click.echo(f"Error: task '{name}' is already in-progress. Choose a different name.", err=True)
            sys.exit(1)
        # completed/aborted → allow overwrite (git task file is permanent record)

    session_id = str(uuid.uuid4())

    if no_worktree:
        worktree = repo
        branch = ""
        logger.info("Creating task '%s' (no-worktree mode)", name)
        print(f"Creating task: {name}")
        print(f"  Directory: {worktree}")
    else:
        branch = f"hatchery/{name}"
        worktree = tasks.worktrees_dir(repo) / name
        logger.info("Creating task '%s' on branch '%s' from '%s'", name, branch, base)
        print(f"Creating task: {name}")
        print(f"  Base:     {base}")
        print(f"  Branch:   {branch}")
        print(f"  Worktree: {worktree}")
        git.create_worktree(repo, branch, worktree, base)

    if no_editor:
        objective = _prompt_objective()
        task_path = tasks.write_task_file(worktree, name, branch, objective=objective)
    else:
        task_path = tasks.write_task_file(worktree, name, branch)
        print("\nOpening task file for editing...")
        tasks.open_for_editing(task_path)

    if in_repo:
        tasks.run(["git", "add", ".hatchery/"], cwd=worktree)
        tasks.run(["git", "commit", "-m", f"task({name}): add task file"], cwd=worktree)

    meta = {
        "name": name,
        "branch": branch,
        "worktree": str(worktree),
        "repo": str(repo),
        "status": "in-progress",
        "created": datetime.now().isoformat(),
        "session_id": session_id,  # internal only, not shown in normal output
        "no_worktree": no_worktree,
    }
    tasks.save_task(meta)

    runtime = docker.resolve_runtime(repo, worktree, no_docker)
    if runtime is not None:
        print("\nStarting Claude session (Docker sandbox)...\n")
    else:
        print("\nStarting Claude session...\n")

    main_branch = git.get_default_branch(repo)
    _launch_claude_new(repo, worktree, name, session_id, runtime, branch, main_branch, no_worktree)


@cli.command("resume")
@click.argument("name")
@click.option("--no-docker", is_flag=True, help="Run Claude directly, even if a Dockerfile is present")
def cmd_resume(name: str, no_docker: bool) -> None:
    """Resume exactly where you left off."""
    repo, _ = git.git_root_or_cwd()
    meta = tasks.load_task(repo, name)
    worktree = Path(meta["worktree"])
    repo = Path(meta["repo"])
    no_worktree = meta.get("no_worktree", False)

    if not no_worktree and not worktree.exists():
        if meta.get("status") == "archived":
            print(f"Re-creating worktree for archived task '{name}'...")
            git.create_worktree(repo, meta["branch"], worktree, meta["branch"])
            meta["status"] = "in-progress"
            tasks.save_task(meta)
            print(f"Worktree restored: {worktree}")
        else:
            click.echo(f"Error: worktree {worktree} does not exist. Has this task been completed?", err=True)
            sys.exit(1)

    session_id = meta.get("session_id")
    if not session_id:
        click.echo("Error: no session ID found for this task. Cannot resume.", err=True)
        sys.exit(1)

    logger.info("Resuming task '%s' (session %s)", name, session_id)
    runtime = docker.resolve_runtime(repo, worktree, no_docker)
    if runtime is not None:
        print(f"Resuming '{name}' (Docker sandbox)...\n")
    else:
        print(f"Resuming '{name}'...\n")

    main_branch = git.get_default_branch(repo)
    _launch_claude_resume(repo, worktree, name, session_id, runtime, meta["branch"], main_branch, no_worktree)


@cli.command("done")
@click.argument("name")
def cmd_done(name: str) -> None:
    """Mark complete and remove worktree."""
    repo, _ = git.git_root_or_cwd()
    meta = tasks.load_task(repo, name)
    worktree = Path(meta["worktree"])
    _do_mark_done(meta["name"], Path(meta["repo"]), worktree)


@cli.command("abort", hidden=True)
@click.argument("name")
def cmd_abort(name: str) -> None:
    """Removed: use `archive` instead."""
    click.echo("Error: 'abort' has been replaced by 'archive'. Use: claude-hatchery archive <name>", err=True)
    sys.exit(1)


@cli.command("archive")
@click.argument("name")
def cmd_archive(name: str) -> None:
    """Park a task: remove worktree, keep branch for later resumption."""
    repo, _ = git.git_root_or_cwd()
    meta = tasks.load_task(repo, name)
    worktree = Path(meta["worktree"])
    repo = Path(meta["repo"])
    no_worktree = meta.get("no_worktree", False)

    if no_worktree:
        print("Note: no-worktree task — no worktree or branch to remove.")
    else:
        if worktree.exists():
            if git.has_uncommitted_changes(worktree):
                print("Warning: there are uncommitted changes in the worktree.")
                print(git.uncommitted_changes_summary(worktree))
                answer = input("Commit them as a checkpoint before archiving? [Y/n] ").strip().lower()
                if answer != "n":
                    tasks.run(["git", "add", "-A"], cwd=worktree)
                    tasks.run(["git", "commit", "-m", f"task({name}): checkpoint before archive"], cwd=worktree)
            git.remove_worktree(repo, worktree)
            print(f"Worktree removed: {worktree}")
        else:
            print("Worktree not found (may already be removed).")
        print(f"Branch retained: {meta['branch']}")

    meta["status"] = "archived"
    tasks.save_task(meta)
    logger.info("Task '%s' archived", meta["name"])
    print(f"Task '{name}' archived. Resume with: claude-hatchery resume {name}")


@cli.command("delete")
@click.argument("name")
def cmd_delete(name: str) -> None:
    """Delete task, branch, and all metadata."""
    repo, _ = git.git_root_or_cwd()
    meta = tasks.load_task(repo, name)
    worktree = Path(meta["worktree"])
    _do_delete(meta["name"], repo, worktree, meta)


@cli.command("list")
@click.option("--all", "show_all", is_flag=True, help="Show all tasks, including completed and aborted")
def cmd_list(show_all: bool) -> None:
    """List tasks for current repo."""
    repo, _ = git.git_root_or_cwd()
    task_list = tasks.repo_tasks_for_current_repo(repo)

    archived_count = 0
    if not show_all:
        archived_count = sum(1 for t in task_list if t.get("status") == "archived")
        task_list = [t for t in task_list if t.get("status") == "in-progress"]

    if not task_list:
        if show_all:
            print("No tasks found for this repository.")
        else:
            print("No in-progress tasks found. Use --all to see all tasks.")
        if archived_count:
            print(f"+ {archived_count} archived task{'s' if archived_count != 1 else ''}.")
        return

    name_w = max(len(t["name"]) for t in task_list)
    st_w = max(len(t["status"]) for t in task_list)
    header = f"{'NAME':<{name_w}}  {'STATUS':<{st_w}}  CREATED"
    print(header)
    print("-" * (len(header) + 10))
    for t in task_list:
        created = t.get("created", "")[:10]
        print(f"{t['name']:<{name_w}}  {t['status']:<{st_w}}  {created}")
    if archived_count:
        print(f"\n+ {archived_count} archived task{'s' if archived_count != 1 else ''}. Use --all to see them.")


@cli.command("status")
@click.argument("name")
def cmd_status(name: str) -> None:
    """Show task file and metadata."""
    repo, _ = git.git_root_or_cwd()
    meta = tasks.load_task(repo, name)
    worktree = Path(meta["worktree"])
    task_path = tasks.find_task_file(worktree, name)

    print(f"Name:     {meta['name']}")
    print(f"Status:   {meta['status']}")
    print(f"Branch:   {meta['branch']}")
    print(f"Worktree: {meta['worktree']}")
    print(f"Created:  {meta.get('created', 'unknown')[:16]}")
    if meta.get("completed"):
        print(f"Completed:{meta['completed'][:16]}")
    # Session ID shown here for debugging, kept out of normal workflow
    print(f"Session:  {meta.get('session_id', 'none')}")

    if task_path and task_path.exists():
        print("\n" + "─" * 60)
        print(task_path.read_text())
    else:
        print("\n(Task file not accessible — worktree may have been removed)")


# ---------------------------------------------------------------------------
# Self command group
# ---------------------------------------------------------------------------


@cli.group("self")
def cmd_self() -> None:
    """Manage the claude-hatchery installation."""


@cmd_self.command("update")
def cmd_self_update() -> None:
    """Upgrade claude-hatchery to the latest release."""
    uv_receipt = Path.home() / ".local/share/uv/tools/claude-hatchery/uv-receipt.toml"
    if uv_receipt.exists() and shutil.which("uv"):
        result = subprocess.run(["uv", "tool", "upgrade", "claude-hatchery"])
        sys.exit(result.returncode)
    print("Could not detect uv tool installation.", file=sys.stderr)
    print("Run manually: uv tool upgrade claude-hatchery", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
