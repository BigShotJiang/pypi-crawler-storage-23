# Task: chore-better-readme

**Status**: complete
**Branch**: hatchery/chore-better-readme
**Created**: 2026-02-24 09:04

## Objective

The README could use some work. Please inspect it and propose updates that will make it easier for new users to immediately get a sense of the repo

- We should probably start with a short bullet point list describing the key features and challenges that hatchery addresses
- Ensure sections are ordered logically, and contents is good
- Propose any other changes as you see fit

Note: some emojis in the readme are OK, but please keep it minimal. Emojis must _add_ to the README, not distract.

## Summary

**File changed**: `README.md` only.

**Changes made**:

1. **Added a features bullet list** immediately after the opening tagline — five bullets covering isolation, Docker sandbox, structured workflow, resumability, and task-file-as-ADR. These give new users the "why" before they hit installation steps.

2. **Reordered sections** to follow a logical user journey: Features → Installation → Quick start → How it works → Task workflow → Commands → Docker → Session environment → Storage layout → Development → Contributing. The old order put "How it works" before installation.

3. **Added `self update` to the Commands table** — this subcommand was present in the CLI but absent from the docs.

4. **Documented `--no-worktree` flag** alongside the existing `--no-docker` note under the Commands table.

5. **Trimmed the "How it works" paragraph** — removed the Docker sentence (Docker section covers it in detail below) to avoid duplication.

**Decisions**:
- No emojis added; the existing `⬡` in the statusline example was preserved.
- No content was dropped; all existing sections are present, just reordered and supplemented.
