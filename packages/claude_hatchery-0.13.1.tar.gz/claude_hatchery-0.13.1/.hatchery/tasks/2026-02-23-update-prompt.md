# Task: update-prompt

**Status**: complete
**Branch**: hatchery/update-prompt
**Created**: 2026-02-23 08:57

## Objective

Add update detection to `claude-hatchery`: detect if a newer version is available on PyPI and print a notice prompting the user to run `self update`.

## Summary

**Approach:** On every CLI invocation, `_check_for_update()` is called from the `cli()` group callback. It fetches the latest version from `https://pypi.org/pypi/claude-hatchery/json` and compares against the installed version. Results are cached in `~/.hatchery/update-check.json` with a 24-hour TTL so PyPI is hit at most once per day.

**Key decisions:**
- Cache path `~/.hatchery/update-check.json` mirrors the existing `~/.hatchery/` convention.
- Version comparison uses `_parse_version()` — splits on `.`, takes up to 3 leading digit-only segments, returns an integer tuple. This correctly handles dev/post suffixes like `0.5.1.post1.dev0+02ab04b` → `(0, 5, 1)` while keeping stdlib-only.
- All errors (network failures, corrupt cache, parse errors) are silently swallowed; the check never blocks or fails the CLI.
- Notice is printed to stderr to avoid polluting piped stdout.

**Files changed:** `src/claude_hatchery/cli.py` — added `_UPDATE_CHECK_CACHE`, `_UPDATE_CHECK_TTL_SECONDS`, `_PYPI_URL` constants and three helpers (`_parse_version`, `_fetch_latest_pypi_version`, `_check_for_update`), plus wired into `cli()`.

**Gotcha:** `urllib.request.urlopen` triggers ruff's `S310` (suspicious URL open) rule. Added a `# noqa: S310` comment since the URL is a hardcoded PyPI constant, not user-supplied input.
