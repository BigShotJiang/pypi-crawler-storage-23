# Task: fix-task-startup

**Status**: complete
**Branch**: hatchery/fix-task-startup
**Created**: 2026-02-23 09:26

## Objective

Restore plan mode for Docker-sandboxed Claude sessions. Commit `433dc53` switched
to `--dangerously-skip-permissions` to suppress the startup trust prompt, but that
flag hard-sets bypass mode and overrides `--permission-mode=plan`.

## Context

The correct flag is `--allow-dangerously-skip-permissions`, which preserves plan
mode but shows a "Do you trust this folder?" interactive prompt on startup.

First attempt used a PTY relay (`_launch_with_initial_input`) to inject a keystroke
when the trust prompt was detected. The relay correctly identified the prompt in the
ANSI-stripped buffer but the injection never dismissed it — Ink/React's virtual DOM
model doesn't accept raw PTY writes as input selection events in all cases.

Root cause of the trust prompt: Claude reads `~/.claude.json` at startup to check
`trustedFolders` **before** any `--settings` override is applied. We already mount a
per-task copy of `~/.claude.json` as `/home/claude/.claude.json` in the container, so
writing `trustedFolders` into that file before Docker launches suppresses the prompt
without any PTY interaction.

## Summary

### Key decisions

- **Pre-populate `trustedFolders` in the per-task `claude.json`**: After
  `prepare_task_claude_json()` returns the path, parse the JSON, append
  `container_worktree` to `trustedFolders` if absent, and write it back.
  This is the only reliable way to suppress the startup trust prompt — Claude
  checks this file before any runtime `--settings` override.

- **Drop PTY relay entirely**: With no trust prompt, `subprocess.run(cmd)` is all
  that's needed. Docker's own `-it` flag connects the container TTY directly to the
  host terminal.

- **`skipDangerousModePermissionPrompt: True` and `trustedFolders` kept in
  `--settings`**: Still present as belt-and-suspenders for in-session permission
  dialogs; harmless to leave.

### Files changed

- `src/claude_hatchery/docker.py`
  - Removed: `_launch_with_initial_input()`, `_TRUST_PROMPT_MARKER`,
    `_ANSI_CUF_RE`, `_ANSI_OTHER_RE`, `_TIOCGWINSZ`, `_TIOCSWINSZ`
  - Removed unused imports: `fcntl`, `pty`, `re`, `select`, `signal`, `termios`, `tty`
  - Added: `trustedFolders` pre-population block in `launch_docker()` after
    `prepare_task_claude_json()` returns
  - Changed: `_launch_with_initial_input(cmd, b"1\r")` → `subprocess.run(cmd)`

### Gotchas

- `claude_json` can be `None` for API-key-only users (no `~/.claude.json` on host).
  The `trustedFolders` block is guarded by `if claude_json is not None`.
- `trustedFolders` must use the **container** path (`/repo/.hatchery/worktrees/<n>`),
  not the host path — Claude reads this file from inside the container.
- The `trustedFolders` write is idempotent: it only appends if the path is not
  already present, so re-launching an existing task session is safe.
