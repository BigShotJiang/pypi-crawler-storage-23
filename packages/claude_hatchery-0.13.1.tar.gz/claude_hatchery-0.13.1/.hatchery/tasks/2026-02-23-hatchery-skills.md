# Task: hatchery-skills

**Status**: in-progress
**Branch**: hatchery/hatchery-skills
**Created**: 2026-02-23 09:03

## Objective

Investigate if we can inject claude skills for common hatchery tasks

## Context

It would be great if the user could do something like /hatchery done at the end of a task to mark a task as done, which would instruct claude to 

- check if the task is marked as complete
- ensure the task isupdated to ADR format
- exit after complete

## Agreed Plan

1. Add `SKILL_HATCHERY_DONE` constant and `write_skills(worktree: Path) -> None` to `tasks.py`
2. Call `tasks.write_skills(worktree)` in `_launch_claude_new()` and `_launch_claude_resume()` in `cli.py`
3. Create `.claude/skills/hatchery-done/SKILL.md` as static file in the worktree repo
4. Run `ruff check`, `ruff format`, and `pytest` to verify correctness

## Progress Log

- [x] Add `SKILL_HATCHERY_DONE` + `write_skills()` to `tasks.py`
- [x] Update `cli.py` launch functions to call `write_skills()`
- [x] Create static `.claude/skills/hatchery-done/SKILL.md`
- [x] Lint + test pass (163 tests)

## Summary

*(Fill in on completion — then remove Agreed Plan and Progress Log above.
Cover: key decisions made, patterns established, files changed, gotchas,
and anything a future agent working in this repo should know.)*
