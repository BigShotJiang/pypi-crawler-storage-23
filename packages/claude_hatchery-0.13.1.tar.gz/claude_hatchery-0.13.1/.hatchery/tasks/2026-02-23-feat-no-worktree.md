# Task: feat-no-worktree

**Status**: complete
**Branch**: hatchery/feat-no-worktree
**Created**: 2026-02-23 10:15

## Objective

Add a `--no-worktree` option so Claude can work directly in the current directory without
creating a branch or worktree. Auto-enable when running from a non-git-repo directory.

## Context

claude-hatchery previously required a git repository and always created an isolated git
worktree for every task. The "create worktrees in each child repo" alternative was
investigated and rejected: too complex (which repos? what depth?), multi-root Docker mounts,
undefined cross-repo commit coordination. The simple no-worktree mode cleanly solves
"Claude can read from multiple repos" without any of that complexity.

## Summary

### Key decisions

**`--no-worktree` semantics:**
- No git branch or worktree created; Claude works in `cwd` directly
- Task file written to `<cwd>/.hatchery/tasks/`
- If in a git repo: git-commit the task file to the current branch; else skip
- Docker: still fully supported — simplified mount: `cwd` → `/workspace` (read-write)
- `done`/`abort`/`delete`: skip worktree removal and branch deletion

**Auto-enable rule:** when `git rev-parse --show-toplevel` fails → `no_worktree=True` + print a note.

**`ensure_gitignore` / `ensure_dockerfile`:** only called when `in_repo=True` (both require git).

**Empty branch:** stored as `""` in metadata; `write_task_file` renders `(none — no-worktree mode)`;
`sandbox_context` omits branch/PR lines when branch is empty.

### Files changed

| File | Change |
|------|--------|
| `src/claude_hatchery/git.py` | Added `git_root_or_cwd() -> tuple[Path, bool]` |
| `src/claude_hatchery/tasks.py` | Extended `sandbox_context()` with `no_worktree: bool = False`; handle empty branch in `write_task_file` |
| `src/claude_hatchery/docker.py` | Added `docker_mounts_no_worktree()` and `launch_docker_no_worktree()` |
| `src/claude_hatchery/cli.py` | `--no-worktree` flag on `cmd_new`; all commands use `git_root_or_cwd()`; guards in `_do_mark_done`, `_do_delete`, `cmd_abort`; `no_worktree` param threaded through all `_launch_claude_*` helpers |
| `tests/test_pure.py` | Added `TestSandboxContextNoWorktree` (14 tests) |
| `tests/test_cli.py` | Added `test_new_help_shows_no_worktree_option`, `TestCliNoWorktree` (6 tests); updated all `git_root` patches → `git_root_or_cwd` |

### Patterns established

- `git_root_or_cwd()` is now the standard entry point for all CLI commands — never call `git_root()` from commands (it exits on failure)
- `no_worktree` is stored in task metadata JSON and read back by all lifecycle commands
- Docker no-worktree: image built from `cwd/.hatchery/Dockerfile` with `build_docker_image(cwd, cwd, name)` — same image builder, different context

### Gotchas

- `_post_exit_check` takes a `no_worktree` param and threads it into `_launch_claude_finalize`; the "wrap up" path inside `_post_exit_check` re-resolves `use_docker` via `resolve_docker(repo, worktree, no_docker=False)` — in no-worktree mode `worktree==cwd`, so it correctly finds (or doesn't find) `cwd/.hatchery/Dockerfile`
- `cmd_resume` skips the `worktree.exists()` check when `no_worktree=True` (there is no worktree to check)
- `_do_mark_done` skips the entire worktree block and "Branch retained" line in no-worktree mode
- `_do_delete` in no-worktree mode: prompts "metadata only?" and skips `remove_worktree`/`delete_branch`
- `get_default_branch` works correctly in non-repo dirs — git commands return non-zero, falls through to return `"main"`
