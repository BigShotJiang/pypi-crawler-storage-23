# Task: fix-delete

**Status**: complete
**Branch**: hatchery/fix-delete
**Created**: 2026-02-24 09:01

## Objective

When deleting a task, be robust to errors during the deletion process — specifically when the metadata JSON file or worktree directory has already been removed before `delete` runs.

## Context

`claude-hatchery delete test-task` crashed with `FileNotFoundError` when `~/.hatchery/tasks/<repo-id>/test-task.json` had already been deleted. The branch deletion already handled this gracefully (prints a warning and continues), but the metadata file deletion did not.

## Summary

### Files changed

- **`src/claude_hatchery/cli.py` line 214** — `_do_delete`: changed `.unlink()` to `.unlink(missing_ok=True)`. This mirrors the branch-deletion pattern: attempt, tolerate "already gone", print success regardless.

- **`src/claude_hatchery/git.py` line 60** — `remove_worktree`: changed `shutil.rmtree(worktree)` in the macOS ACL fallback path to `shutil.rmtree(worktree, ignore_errors=True)`. If the directory disappears between the `worktree.exists()` check and the rmtree retry, the error is silently suppressed instead of raising.

### Pattern

Both fixes follow the same principle already established for branch deletion: deletion operations in the `delete` command should be idempotent — if the resource is already gone, treat it as success and move on.
