# Task: fix-ci-release

**Status**: complete
**Branch**: hatchery/fix-ci-release
**Created**: 2026-02-24 08:21

## Objective

Fix the CI `compute-version` job so it cannot produce a spurious release when
a commit reaches `main` without a GitLab MR association, or when a commit title
uses an unrecognized conventional-commit type.

## Context

Commit `1ab6c8b` had title `task(feat-custom-mounts): mark complete, add summary`.
`task` is not a valid conventional commit type but hit the catch-all `else` branch
which treated anything unrecognized as `patch`, producing the unintended v0.8.7
tag and PyPI publish. Root cause: the MR lookup returned empty (no MR association),
and the fallback to the raw commit title let a non-conventional commit drive
version bumps.

## Summary

**Files changed**: `.gitlab/ci/setup.yml`

### Change 1 — Remove the MR-title fallback

When `curl | jq` returns empty for the commit's MR list, the job now writes
`SKIP_RELEASE=true` and `exit 0` immediately rather than falling back to
`$CI_COMMIT_TITLE`. A direct push or non-squash merge to main will never trigger
a release; the log message makes the reason obvious.

### Change 2 — Fix the catch-all bump rule (defence-in-depth)

Added an explicit `elif` for the known patch-bump types
(`chore|docs|style|refactor|test|build|ci|revert`) so they still receive a patch
bump. The `else` catch-all now sets `BUMP="none"` (skip release) instead of
`patch`, so any future unrecognized commit type is safe by default.

### Gotchas

- The MR-title fallback removal means that CI jobs replayed on old commits (via
  re-run without a live MR) will also skip release — acceptable behaviour.
- `NEXT_VERSION` is still written to `version.env` in the early-exit path so
  downstream jobs that consume the dotenv artifact don't fail on a missing var.
