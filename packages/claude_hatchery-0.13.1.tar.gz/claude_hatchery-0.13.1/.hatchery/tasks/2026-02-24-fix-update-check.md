# Task: fix-update-check

**Status**: complete
**Branch**: hatchery/fix-update-check
**Created**: 2026-02-24 09:38

## Objective

Update check is currently not working, it always returns null. Investigate and fix.

## Context

└ claude-hatchery (3538656 ●) » curl https://dev-nexus-01.cb.ntent.com/repository/ntent-pypi-releases/pypi/claude-hatchery/json                                           [9:38:22]

<!DOCTYPE html>
<html lang="en">
<head>
  <title>404 - Sonatype Nexus Repository</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>


  <link rel="icon" type="image/png" href="../../../../static/rapture/resources/safari-favicon-32x32.png?3.78.2-04" sizes="32x32">
  <link rel="mask-icon" href="../../../../static/rapture/resources/favicon-white.svg?3.78.2-04" color="#00bb6c">
  <link rel="icon" type="image/png" href="../../../../static/rapture/resources/favicon.svg?3.78.2-04" sizes="16x16">

  <link rel="stylesheet" type="text/css" href="../../../../static/css/nexus-content.css?3.78.2-04"/>
</head>
<body>
<div class="nexus-header">
  <a href="../../../..">
    <div class="product-logo">
      <img src="../../../../static/rapture/resources/nxrm-reverse-icon.png?3.78.2-04" alt="Product logo"/>
    </div>
    <div class="product-id">
      <div class="product-id__line-1">
        <span class="product-name">Sonatype Nexus Repository</span>
      </div>
      <div class="product-id__line-2">
        <span class="product-spec">3.78.2-04</span>
      </div>
    </div>
  </a>
</div>

<div class="nexus-body">
  <div class="content-header">
    <img src="../../../../static/rapture/resources/icons/x32/exclamation.png?3.78.2-04" alt="Exclamation point" aria-role="presentation"/>
    <span class="title">Error 404</span>
    <span class="description">Not Found</span>
  </div>
  <div class="content-body">
    <div class="content-section">
      Not Found
    </div>
  </div>
</div>
</body>
</html>

## Summary

**File changed**: `src/claude_hatchery/cli.py`

**Root cause**: `_PYPI_URL` pointed to the PyPI JSON API (`/pypi/<pkg>/json`) on Nexus, which returns HTTP 404 — Nexus doesn't implement that endpoint.

**Fix**: Switched to the PEP 503 simple index (`/simple/claude-hatchery/`), which Nexus does support. The function now:
1. Fetches the HTML listing from `_SIMPLE_URL`
2. Extracts version strings from href path segments with `re.findall(r"/packages/claude-hatchery/([^/]+)/", content)`
3. Returns `max(set(versions), key=_parse_version)` to handle duplicates (one per artifact per version) and pick the highest

**Gotcha**: If `~/.hatchery/update-check.json` exists with a cached-failure entry, it suppresses network fetches for up to 1 hour. Delete it to force an immediate re-check after deploying this fix.
