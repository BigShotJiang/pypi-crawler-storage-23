# Task: fix-limit-list

**Status**: complete
**Branch**: hatchery/fix-limit-list
**Created**: 2026-02-23 11:33

## Objective

The `list` command currently shows all tasks in a repo.

We should update it so it only shows in-progress tasks by default, with a flag to show all tasks.

## Summary

Added `--all` flag to `cmd_list` in `src/claude_hatchery/cli.py`. Without the flag the command filters to tasks with `status == "in-progress"` and prints a hint about `--all` when nothing is found. With `--all` the original behaviour is preserved.

Updated `tests/test_cli.py` (`TestCmdList`):
- Renamed `test_no_tasks_message` → two tests: `test_no_tasks_message_default` (checks hint text) and `test_no_tasks_message_all_flag` (checks generic "No tasks found" text).
- Renamed `test_multiple_tasks_all_shown` → `test_multiple_tasks_all_flag` (invokes with `--all`).
- Added `test_default_filters_to_in_progress` verifying completed tasks are hidden by default.
- Fixed `test_columns_present_in_header` to use `"in-progress"` status so it passes the default filter.
