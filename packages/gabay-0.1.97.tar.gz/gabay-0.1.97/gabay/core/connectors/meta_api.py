def get_unread_notifications(user_id: str) -> list[str]:
    # Placeholder for Meta Graph API call
    return ["You have a new friend request on Facebook", "Someone liked your Instagram post"]
