"""Tests for Auth101."""

import os
import tempfile

import pytest

from auth101 import Auth101
from auth101.core.security.tokens import verify_token


# ── sign_up ───────────────────────────────────────────────────────────────────

def test_sign_up_success():
    auth = Auth101(secret="test-secret-key-32bytes-padding!!")
    result = auth.sign_up("alice@example.com", "hunter2")

    assert "error" not in result
    assert result["user"]["email"] == "alice@example.com"
    assert "token" in result

    payload = verify_token(result["token"], "test-secret-key-32bytes-padding!!")
    assert payload is not None
    assert payload["email"] == "alice@example.com"


def test_sign_up_duplicate():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    auth.sign_up("a@b.com", "pass")
    result = auth.sign_up("a@b.com", "pass")

    assert "error" in result
    assert result["error"]["code"] == "USER_EXISTS"


def test_sign_up_missing_fields():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    assert auth.sign_up("", "pass")["error"]["code"] == "VALIDATION_ERROR"
    assert auth.sign_up("a@b.com", "")["error"]["code"] == "VALIDATION_ERROR"


def test_sign_up_email_is_normalised():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    result = auth.sign_up("  Alice@Example.COM  ", "pass")
    assert result["user"]["email"] == "alice@example.com"


# ── sign_in ───────────────────────────────────────────────────────────────────

def test_sign_in_success():
    auth = Auth101(secret="test-secret-key-32bytes-padding!!")
    auth.sign_up("bob@example.com", "s3cret")
    result = auth.sign_in("bob@example.com", "s3cret")

    assert "error" not in result
    assert result["user"]["email"] == "bob@example.com"
    assert "token" in result


def test_sign_in_wrong_password():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    auth.sign_up("c@d.com", "right")
    result = auth.sign_in("c@d.com", "wrong")

    assert result["error"]["code"] == "INVALID_CREDENTIALS"


def test_sign_in_unknown_user():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    result = auth.sign_in("nobody@example.com", "pass")
    assert result["error"]["code"] == "INVALID_CREDENTIALS"


# ── sign_out ──────────────────────────────────────────────────────────────────

def test_sign_out_valid_token():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    token = auth.sign_up("e@f.com", "pass")["token"]
    result = auth.sign_out(token)
    assert result == {"success": True}


def test_sign_out_invalid_token():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    result = auth.sign_out("not.a.valid.token")
    assert result["error"]["code"] == "INVALID_TOKEN"


# ── get_session ───────────────────────────────────────────────────────────────

def test_get_session_valid():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    token = auth.sign_up("g@h.com", "pass")["token"]
    result = auth.get_session(token)

    assert "error" not in result
    assert result["user"]["email"] == "g@h.com"


def test_get_session_invalid_token():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    result = auth.get_session("bad.token.here")
    assert result["error"]["code"] == "UNAUTHORIZED"


# ── verify_token ──────────────────────────────────────────────────────────────

def test_verify_token_returns_user():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    token = auth.sign_up("i@j.com", "pass")["token"]
    user = auth.verify_token(token)
    assert user is not None
    assert user.email == "i@j.com"


def test_verify_token_bad_returns_none():
    auth = Auth101(secret="secret-key-for-testing-purposes!!")
    assert auth.verify_token("garbage") is None


# ── SQLAlchemy db_url ──────────────────────────────────────────────────────────

def test_db_url_sqlite():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as tmp:
        db_path = tmp.name

    try:
        auth = Auth101(secret="secret-key-for-testing-purposes!!", db_url=f"sqlite:///{db_path}")

        result = auth.sign_up("sql@example.com", "pass123")
        assert result["user"]["email"] == "sql@example.com"

        result2 = auth.sign_in("sql@example.com", "pass123")
        assert "token" in result2

        auth._store.engine.dispose()

        # Persistence check — new instance, same file
        auth2 = Auth101(secret="secret-key-for-testing-purposes!!", db_url=f"sqlite:///{db_path}")
        assert auth2.sign_in("sql@example.com", "pass123")["user"]["email"] == "sql@example.com"
        auth2._store.engine.dispose()
    finally:
        if os.path.exists(db_path):
            try:
                os.unlink(db_path)
            except PermissionError:
                pass


# ── config validation ──────────────────────────────────────────────────────────

def test_secret_required():
    with pytest.raises(ValueError, match="secret"):
        Auth101(secret="")


def test_only_one_db_option():
    with pytest.raises(ValueError):
        Auth101(secret="secret-key-for-testing-purposes!!", db_url="sqlite:///x.db", django_model=object())
