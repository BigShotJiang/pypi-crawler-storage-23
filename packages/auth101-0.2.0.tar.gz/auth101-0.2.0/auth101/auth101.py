"""
Auth101 — Simple email/password authentication for Python.

Inspired by better-auth. Configure once, mount anywhere.

    auth = Auth101(secret="...", db_url="sqlite:///auth.db")

    # FastAPI
    app.include_router(auth.fastapi_router(), prefix="/auth")

    # Flask
    app.register_blueprint(auth.flask_blueprint(), url_prefix="/auth")

    # Django
    # urls.py  →  path("auth/", include(auth.django_urls()))
    # settings.py  →  MIDDLEWARE = [..., auth.get_django_middleware()]

Endpoints (relative to mount prefix):
    POST /sign-up/email   { email, password }  → { user, token }
    POST /sign-in/email   { email, password }  → { user, token }
    POST /sign-out        Bearer token          → { success }
    GET  /session         Bearer token          → { user }
"""

from typing import Any, Dict, Optional

from .core.models.models import User
from .core.persistence.base import MemoryUserStore, UserStore
from .core.security.hashing import DEFAULT_PWD_CTX, hash_password, verify_password
from .core.security.tokens import create_token
from .core.security.tokens import verify_token as _jwt_verify


class Auth101:
    def __init__(
        self,
        secret: str,
        db_url: Optional[str] = None,
        django_model: Optional[Any] = None,
        token_expires_in: int = 60 * 24 * 7,  # 7 days in minutes
    ) -> None:
        if not secret:
            raise ValueError("'secret' is required")

        if db_url is not None and django_model is not None:
            raise ValueError("Only one of 'db_url' or 'django_model' may be provided")

        if db_url:
            try:
                from sqlalchemy import create_engine

                from .core.persistence.sqlalchemy_store import SQLAlchemyUserStore
            except ImportError:
                raise ImportError("SQLAlchemy is required for db_url: pip install sqlalchemy")
            engine = create_engine(db_url)
            store: UserStore = SQLAlchemyUserStore(engine)
            store.create_tables()
        elif django_model is not None:
            from .core.persistence.django_store import DjangoUserStore

            store = DjangoUserStore(django_model)
        else:
            store = MemoryUserStore()

        self._store = store
        self._secret = secret
        self._token_expires_in = token_expires_in

    # ── Core auth methods ─────────────────────────────────────────────────────
    # These return plain dicts so they can be used independent of any framework.

    def sign_up(self, email: str, password: str) -> Dict[str, Any]:
        """Register a new user.

        Returns:
            ``{"user": {...}, "token": "..."}``  on success
            ``{"error": {"message": ..., "code": ...}}``  on failure
        """
        email = email.lower().strip() if email else ""
        if not email or not password:
            return _err("Email and password are required", "VALIDATION_ERROR")

        if self._store.get_user_by_email(email):
            return _err("User already exists", "USER_EXISTS")

        user = User(email=email, password_hash=hash_password(password, DEFAULT_PWD_CTX))
        user = self._store.create_user(user)
        return {"user": _user_dict(user), "token": self._issue_token(user)}

    def sign_in(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticate an existing user.

        Returns:
            ``{"user": {...}, "token": "..."}``  on success
            ``{"error": {...}}``  on failure
        """
        email = email.lower().strip() if email else ""
        user = self._store.get_user_by_email(email)
        if not user or not verify_password(password, user.password_hash, DEFAULT_PWD_CTX):
            return _err("Invalid email or password", "INVALID_CREDENTIALS")
        return {"user": _user_dict(user), "token": self._issue_token(user)}

    def sign_out(self, token: str) -> Dict[str, Any]:
        """Validate a token and acknowledge sign-out.

        JWT is stateless — the client is responsible for discarding the token.

        Returns:
            ``{"success": True}``  if the token is valid
            ``{"error": {...}}``  if the token is invalid/expired
        """
        if not _jwt_verify(token, self._secret):
            return _err("Invalid or expired token", "INVALID_TOKEN")
        return {"success": True}

    def get_session(self, token: str) -> Dict[str, Any]:
        """Return the user associated with a token.

        Returns:
            ``{"user": {...}}``  if valid
            ``{"error": {...}}``  if not
        """
        payload = _jwt_verify(token, self._secret)
        if not payload:
            return _err("Unauthorized", "UNAUTHORIZED")

        email = payload.get("email")
        if not email:
            return _err("Invalid token", "INVALID_TOKEN")

        user = self._store.get_user_by_email(email)
        if not user:
            return _err("User not found", "USER_NOT_FOUND")

        return {"user": _user_dict(user)}

    def verify_token(self, token: str) -> Optional[User]:
        """Verify a bearer token and return the corresponding User, or None."""
        payload = _jwt_verify(token, self._secret)
        if not payload:
            return None
        email = payload.get("email")
        if not email:
            return None
        return self._store.get_user_by_email(email)

    # ── Framework integrations ────────────────────────────────────────────────

    def fastapi_router(self):
        """Return a FastAPI ``APIRouter`` with all auth endpoints pre-wired."""
        from .integrations.fastapi import create_router

        return create_router(self)

    def flask_blueprint(self, name: str = "auth101"):
        """Return a Flask ``Blueprint`` with all auth endpoints pre-wired."""
        from .integrations.flask import create_blueprint

        return create_blueprint(self, name)

    def django_urls(self):
        """Return a list of Django ``path()`` entries for all auth endpoints."""
        from .integrations.django import create_url_patterns

        return create_url_patterns(self)

    def get_django_middleware(self):
        """Return a Django middleware *class* that attaches ``request.auth_user``.

        Usage in settings.py::

            from myapp.auth import auth          # your Auth101 instance
            Auth101Middleware = auth.get_django_middleware()

            MIDDLEWARE = [
                "myapp.auth.Auth101Middleware",   # dotted path to the class above
                ...
            ]
        """
        from .integrations.django import make_middleware

        return make_middleware(self)

    def django_login_required(self):
        """Return a Django view decorator that enforces authentication."""
        from .integrations.django import create_login_required_decorator

        return create_login_required_decorator(self)

    def fastapi_current_user(self):
        """Return a FastAPI dependency that resolves to the authenticated User."""
        from .integrations.fastapi import create_current_user_dependency

        return create_current_user_dependency(self)

    def flask_login_required(self):
        """Return a Flask route decorator that enforces authentication."""
        from .integrations.flask import create_login_required_decorator

        return create_login_required_decorator(self)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _issue_token(self, user: User) -> str:
        return create_token(
            user_id=user.id,
            secret_key=self._secret,
            expires_in_minutes=self._token_expires_in,
            email=user.email,
        )


# ── Module-level helpers ──────────────────────────────────────────────────────

def _err(message: str, code: str) -> Dict[str, Any]:
    return {"error": {"message": message, "code": code}}


def _user_dict(user: User) -> Dict[str, Any]:
    return {"id": user.id, "email": user.email, "is_active": user.is_active}
