"""auth101 — Simple email/password authentication for Python."""

from .auth101 import Auth101

__all__ = ["Auth101"]
