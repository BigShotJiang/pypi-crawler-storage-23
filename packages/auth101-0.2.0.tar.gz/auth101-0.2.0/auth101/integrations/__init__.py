# Framework integration helpers.
# Each sub-module is imported lazily to avoid hard dependencies.
