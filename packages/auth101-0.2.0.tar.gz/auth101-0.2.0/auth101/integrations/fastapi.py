"""FastAPI integration for Auth101.

Usage::

    from fastapi import FastAPI
    from auth101 import Auth101

    auth = Auth101(secret="...", db_url="sqlite:///auth.db")

    app = FastAPI()
    app.include_router(auth.fastapi_router(), prefix="/auth", tags=["auth"])

Endpoints:
    POST /auth/sign-up/email
    POST /auth/sign-in/email
    POST /auth/sign-out
    GET  /auth/session

To protect your own routes, use the provided dependency::

    from myapp.auth import auth          # your Auth101 instance

    CurrentUser = auth.fastapi_current_user()

    @app.get("/me")
    async def me(user = Depends(CurrentUser)):
        return {"email": user.email}
"""

# from __future__ import annotations

from typing import TYPE_CHECKING, Optional
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel


if TYPE_CHECKING:
    from ..auth101 import Auth101

class EmailPasswordBody(BaseModel):
    email: str
    password: str


def create_router(auth: "Auth101"):

    router = APIRouter()


    @router.post("/sign-up/email")
    async def sign_up(body: EmailPasswordBody):
        result = auth.sign_up(body.email, body.password)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result

    @router.post("/sign-in/email")
    async def sign_in(body: EmailPasswordBody):
        result = auth.sign_in(body.email, body.password)
        if "error" in result:
            code = result["error"]["code"]
            status = 401 if code == "INVALID_CREDENTIALS" else 400
            raise HTTPException(status_code=status, detail=result["error"])
        return result

    @router.post("/sign-out")
    async def sign_out(request: Request):
        token = _extract_token(request.headers.get("Authorization", ""))
        if not token:
            raise HTTPException(status_code=401, detail={"message": "No token provided", "code": "UNAUTHORIZED"})
        result = auth.sign_out(token)
        if "error" in result:
            raise HTTPException(status_code=401, detail=result["error"])
        return result

    @router.get("/session")
    async def get_session(request: Request):
        token = _extract_token(request.headers.get("Authorization", ""))
        if not token:
            raise HTTPException(status_code=401, detail={"message": "Unauthorized", "code": "UNAUTHORIZED"})
        result = auth.get_session(token)
        if "error" in result:
            raise HTTPException(status_code=401, detail=result["error"])
        return result

    return router


def create_current_user_dependency(auth: "Auth101"):
    """Return a FastAPI dependency that resolves to the authenticated User.

    Raises HTTP 401 if the token is missing or invalid.
    """
    try:
        from fastapi import Depends, HTTPException, Request
    except ImportError:
        raise ImportError("FastAPI is required: pip install fastapi")

    async def _get_current_user(request: Request):
        token = _extract_token(request.headers.get("Authorization", ""))
        if not token:
            raise HTTPException(
                status_code=401,
                detail={"message": "Unauthorized", "code": "UNAUTHORIZED"},
            )
        user = auth.verify_token(token)
        if not user:
            raise HTTPException(
                status_code=401,
                detail={"message": "Unauthorized", "code": "UNAUTHORIZED"},
            )
        return user

    return _get_current_user


def _extract_token(authorization: str) -> Optional[str]:
    if authorization.startswith("Bearer "):
        return authorization[7:]
    return None
