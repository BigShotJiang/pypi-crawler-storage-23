from dataclasses import dataclass, field
from typing import Any, Dict
import uuid


@dataclass
class User:
    """Default user model used by the package.

    Fields:
    - id: unique id (uuid4 string)
    - email: canonical email
    - password_hash: hashed password
    - is_active: active flag
    - extra: dict for arbitrary extra fields
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    email: str = ""
    password_hash: str = ""
    is_active: bool = True
    extra: Dict[str, Any] = field(default_factory=dict)
