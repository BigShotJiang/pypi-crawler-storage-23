from .base import UserStore, MemoryUserStore

# Optional imports - only available if dependencies are installed
try:
    from .sqlalchemy_store import SQLAlchemyUserStore, SQLAlchemyUser
    __all__ = ["UserStore", "MemoryUserStore", "SQLAlchemyUserStore", "SQLAlchemyUser"]
except ImportError:
    __all__ = ["UserStore", "MemoryUserStore"]

try:
    from .django_store import DjangoUserStore
    if "DjangoUserStore" not in __all__:
        __all__ = list(__all__) + ["DjangoUserStore"]
except ImportError:
    pass