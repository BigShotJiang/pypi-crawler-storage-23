"""Django ORM-based user store implementation."""
from typing import Optional
from .base import UserStore
from ..models.models import User


class DjangoUserStore(UserStore):
    """User store backed by Django ORM.
    
    Requirements:
        1. Create a Django model that has: id, email, password_hash, is_active
        2. Pass the model class to this store
    
    Example Django model:
        from django.db import models
        import uuid
        
        class AuthUser(models.Model):
            id = models.CharField(max_length=36, primary_key=True, default=lambda: str(uuid.uuid4()))
            email = models.EmailField(unique=True, db_index=True)
            password_hash = models.CharField(max_length=255)
            is_active = models.BooleanField(default=True)
            
            class Meta:
                db_table = 'auth_users'
    
    Usage:
        from myapp.models import AuthUser
        
        store = DjangoUserStore(AuthUser)
        auth = Authenticator(store=store)
    """

    def __init__(self, model_class):
        """Initialize store with Django model class.
        
        Args:
            model_class: Django model class with fields: id, email, password_hash, is_active
        """
        self.model = model_class

    def _to_model(self, db_user) -> User:
        """Convert Django model instance to User dataclass."""
        return User(
            id=str(db_user.id),
            email=db_user.email,
            password_hash=db_user.password_hash,
            is_active=db_user.is_active,
            extra={}
        )

    def _to_db(self, user: User):
        """Convert User dataclass to Django model instance."""
        return self.model(
            id=user.id,
            email=user.email,
            password_hash=user.password_hash,
            is_active=user.is_active
        )

    def create_user(self, user: User) -> User:
        """Create a new user in the database."""
        if self.model.objects.filter(email=user.email).exists():
            raise ValueError("user already exists")
        
        db_user = self._to_db(user)
        db_user.save()
        return self._to_model(db_user)

    def get_user_by_email(self, email: str) -> Optional[User]:
        """Retrieve user by email."""
        try:
            db_user = self.model.objects.get(email=email)
            return self._to_model(db_user)
        except self.model.DoesNotExist:
            return None

    def update_user(self, user: User) -> User:
        """Update an existing user."""
        try:
            db_user = self.model.objects.get(email=user.email)
            db_user.password_hash = user.password_hash
            db_user.is_active = user.is_active
            db_user.save()
            return self._to_model(db_user)
        except self.model.DoesNotExist:
            raise ValueError("user not found")
