from abc import ABC, abstractmethod
from typing import Optional
from ..models.models import User


class UserStore(ABC):
    """Abstract user store interface.

    Implementations must be synchronous and simple: create/get/update.
    """

    @abstractmethod
    def create_user(self, user: User) -> User:
        raise NotImplementedError()

    @abstractmethod
    def get_user_by_email(self, email: str) -> Optional[User]:
        raise NotImplementedError()

    @abstractmethod
    def update_user(self, user: User) -> User:
        raise NotImplementedError()


class MemoryUserStore(UserStore):
    """A tiny in-memory user store useful for tests and demos."""

    def __init__(self):
        self._by_email = {}

    def create_user(self, user: User) -> User:
        if user.email in self._by_email:
            raise ValueError("user already exists")
        self._by_email[user.email] = user
        return user

    def get_user_by_email(self, email: str) -> Optional[User]:
        return self._by_email.get(email)

    def update_user(self, user: User) -> User:
        self._by_email[user.email] = user
        return user
