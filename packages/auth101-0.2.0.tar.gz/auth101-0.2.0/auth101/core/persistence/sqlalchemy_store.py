"""SQLAlchemy-based user store implementation."""
from typing import Optional
from sqlalchemy import create_engine, Column, String, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from .base import UserStore
from ..models.models import User

Base = declarative_base()


class SQLAlchemyUser(Base):
    """SQLAlchemy User model for persistence."""
    __tablename__ = "users"

    id = Column(String, primary_key=True)
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)


class SQLAlchemyUserStore(UserStore):
    """User store backed by SQLAlchemy.
    
    Usage:
        # Create database connection
        engine = create_engine("sqlite:///auth.db")
        
        # Create store and tables
        store = SQLAlchemyUserStore(engine)
        store.create_tables()
        
        # Use with Authenticator
        auth = Authenticator(store=store)
    """

    def __init__(self, engine):
        """Initialize store with SQLAlchemy engine.
        
        Args:
            engine: SQLAlchemy engine instance (from create_engine)
        """
        self.engine = engine
        self.SessionLocal = sessionmaker(bind=engine)

    def create_tables(self):
        """Create database tables if they don't exist."""
        Base.metadata.create_all(self.engine)

    def _to_model(self, db_user: SQLAlchemyUser) -> User:
        """Convert SQLAlchemy model to User dataclass."""
        return User(
            id=db_user.id,
            email=db_user.email,
            password_hash=db_user.password_hash,
            is_active=db_user.is_active,
            extra={}
        )

    def _to_db(self, user: User) -> SQLAlchemyUser:
        """Convert User dataclass to SQLAlchemy model."""
        return SQLAlchemyUser(
            id=user.id,
            email=user.email,
            password_hash=user.password_hash,
            is_active=user.is_active
        )

    def create_user(self, user: User) -> User:
        """Create a new user in the database."""
        session: Session = self.SessionLocal()
        try:
            existing = session.query(SQLAlchemyUser).filter_by(email=user.email).first()
            if existing:
                raise ValueError("user already exists")
            
            db_user = self._to_db(user)
            session.add(db_user)
            session.commit()
            session.refresh(db_user)
            return self._to_model(db_user)
        finally:
            session.close()

    def get_user_by_email(self, email: str) -> Optional[User]:
        """Retrieve user by email."""
        session: Session = self.SessionLocal()
        try:
            db_user = session.query(SQLAlchemyUser).filter_by(email=email).first()
            if not db_user:
                return None
            return self._to_model(db_user)
        finally:
            session.close()

    def update_user(self, user: User) -> User:
        """Update an existing user."""
        session: Session = self.SessionLocal()
        try:
            db_user = session.query(SQLAlchemyUser).filter_by(email=user.email).first()
            if not db_user:
                raise ValueError("user not found")
            
            db_user.password_hash = user.password_hash
            db_user.is_active = user.is_active
            session.commit()
            session.refresh(db_user)
            return self._to_model(db_user)
        finally:
            session.close()
