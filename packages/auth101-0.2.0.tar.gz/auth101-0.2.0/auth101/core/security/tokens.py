"""JWT token creation and verification.

Provides simple functions to create and verify JWT tokens for authenticated users.
"""
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any


def create_token(
    user_id: str,
    secret_key: str,
    algorithm: str = "HS256",
    expires_in_minutes: int = 60,
    **extra_claims
) -> str:
    """Create a JWT token for a user.
    
    Args:
        user_id: The unique identifier for the user
        secret_key: Secret key used to sign the token
        algorithm: JWT algorithm (default: HS256)
        expires_in_minutes: Token expiration time in minutes (default: 60)
        **extra_claims: Additional claims to include in the token payload
    
    Returns:
        Encoded JWT token string
    """
    now = datetime.utcnow()
    expiration = now + timedelta(minutes=expires_in_minutes)
    
    payload = {
        "sub": user_id,  # subject - the user identifier
        "iat": now,  # issued at
        "exp": expiration,  # expiration time
        **extra_claims  # any additional claims
    }
    
    token = jwt.encode(payload, secret_key, algorithm=algorithm)
    return token


def verify_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256"
) -> Optional[Dict[str, Any]]:
    """Verify and decode a JWT token.
    
    Args:
        token: The JWT token string to verify
        secret_key: Secret key used to verify the token signature
        algorithm: JWT algorithm (default: HS256)
    
    Returns:
        Decoded token payload if valid, None if invalid or expired
    """
    try:
        payload = jwt.decode(token, secret_key, algorithms=[algorithm])
        return payload
    except jwt.ExpiredSignatureError:
        # Token has expired
        return None
    except jwt.InvalidTokenError:
        # Token is invalid (bad signature, malformed, etc.)
        return None


def get_user_id_from_token(
    token: str,
    secret_key: str,
    algorithm: str = "HS256"
) -> Optional[str]:
    """Extract user_id from a valid JWT token.
    
    Args:
        token: The JWT token string
        secret_key: Secret key used to verify the token
        algorithm: JWT algorithm (default: HS256)
    
    Returns:
        User ID if token is valid, None otherwise
    """
    payload = verify_token(token, secret_key, algorithm)
    if payload:
        return payload.get("sub")
    return None
