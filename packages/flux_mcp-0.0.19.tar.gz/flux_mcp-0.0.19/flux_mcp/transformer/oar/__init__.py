from .transform import OARTransformer as Transformer

assert Transformer
