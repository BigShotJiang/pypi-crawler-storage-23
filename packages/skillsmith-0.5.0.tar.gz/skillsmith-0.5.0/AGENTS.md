# AGENTS.md

> This file provides AI coding agents with context about this project.
> See: https://agents.md

## Project Overview
<!-- Brief description of what this project does -->

## Setup Commands
<!-- Commands to set up the development environment, e.g., uv sync, npm install -->

## Testing Workflows
<!-- How to run tests, e.g., pytest, npm test -->

## Coding Style
<!-- Project-specific conventions, e.g., Follow SOLID principles, use functional components -->

## Architecture Notes
<!-- Key architectural decisions, e.g., Using FastAPI for backend, React with Vite for frontend -->
