"""Tests for all lotos.transforms — every transform type."""

from __future__ import annotations

import polars as pl
import pytest

from lotos.core.exceptions import (
    SchemaValidationError,
    TransformConfigError,
)
from lotos.transforms.casting import CastTypesTransform
from lotos.transforms.columns import (
    DropColumnsTransform,
    RenameColumnsTransform,
    SelectColumnsTransform,
)
from lotos.transforms.computed import ComputedColumnsTransform
from lotos.transforms.custom import CustomTransform
from lotos.transforms.dedup import DeduplicateTransform
from lotos.transforms.filter import FilterRowsTransform
from lotos.transforms.flatten import FlattenTransform
from lotos.transforms.sql_transform import SqlTransform
from lotos.transforms.validation import ValidateSchemaTransform


# ═══════════════════════════════════════════════════════════════════════════
# SelectColumnsTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestSelectColumns:
    def test_select_subset(self, sample_df):
        t = SelectColumnsTransform(config={"columns": ["id", "name"]})
        result = t.apply(sample_df)
        assert result.columns == ["id", "name"]
        assert len(result) == 5

    def test_select_single_column(self, sample_df):
        t = SelectColumnsTransform(config={"columns": ["email"]})
        result = t.apply(sample_df)
        assert result.columns == ["email"]

    def test_preserves_order(self, sample_df):
        t = SelectColumnsTransform(config={"columns": ["email", "id", "name"]})
        result = t.apply(sample_df)
        assert result.columns == ["email", "id", "name"]

    def test_missing_column_raises(self, sample_df):
        t = SelectColumnsTransform(config={"columns": ["id", "nonexistent"]})
        with pytest.raises(TransformConfigError, match="not found"):
            t.apply(sample_df)

    def test_empty_columns_rejected(self):
        with pytest.raises(TransformConfigError):
            SelectColumnsTransform(config={"columns": []})

    def test_missing_config_rejected(self):
        with pytest.raises(TransformConfigError):
            SelectColumnsTransform(config={})


# ═══════════════════════════════════════════════════════════════════════════
# RenameColumnsTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestRenameColumns:
    def test_basic_rename(self, sample_df):
        t = RenameColumnsTransform(config={"mapping": {"name": "full_name", "email": "mail"}})
        result = t.apply(sample_df)
        assert "full_name" in result.columns
        assert "mail" in result.columns
        assert "name" not in result.columns

    def test_nonexistent_source_ignored(self, sample_df):
        t = RenameColumnsTransform(config={"mapping": {"nonexistent": "new_name"}})
        result = t.apply(sample_df)
        assert result.columns == sample_df.columns

    def test_empty_mapping_rejected(self):
        with pytest.raises(TransformConfigError):
            RenameColumnsTransform(config={"mapping": {}})


# ═══════════════════════════════════════════════════════════════════════════
# DropColumnsTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestDropColumns:
    def test_drop_existing(self, sample_df):
        t = DropColumnsTransform(config={"columns": ["score", "status"]})
        result = t.apply(sample_df)
        assert "score" not in result.columns
        assert "status" not in result.columns
        assert "id" in result.columns

    def test_drop_nonexistent_ignored(self, sample_df):
        t = DropColumnsTransform(config={"columns": ["nonexistent"]})
        result = t.apply(sample_df)
        assert len(result.columns) == len(sample_df.columns)

    def test_empty_columns_rejected(self):
        with pytest.raises(TransformConfigError):
            DropColumnsTransform(config={"columns": []})


# ═══════════════════════════════════════════════════════════════════════════
# CastTypesTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestCastTypes:
    def test_cast_int_to_float(self, sample_df):
        t = CastTypesTransform(config={"mapping": {"id": "float64"}})
        result = t.apply(sample_df)
        assert result["id"].dtype == pl.Float64

    def test_cast_to_string(self, sample_df):
        t = CastTypesTransform(config={"mapping": {"id": "string", "age": "utf8"}})
        result = t.apply(sample_df)
        assert result["id"].dtype == pl.Utf8
        assert result["age"].dtype == pl.Utf8

    def test_cast_to_int32(self, sample_df):
        t = CastTypesTransform(config={"mapping": {"age": "int32"}})
        result = t.apply(sample_df)
        assert result["age"].dtype == pl.Int32

    def test_unknown_type_rejected(self):
        with pytest.raises(TransformConfigError, match="unknown type"):
            CastTypesTransform(config={"mapping": {"id": "invalid_type"}})

    def test_nonexistent_column_ignored(self, sample_df):
        t = CastTypesTransform(config={"mapping": {"nonexistent": "int64"}})
        result = t.apply(sample_df)
        assert result.columns == sample_df.columns

    def test_empty_mapping_rejected(self):
        with pytest.raises(TransformConfigError):
            CastTypesTransform(config={"mapping": {}})

    def test_multiple_casts(self, sample_df):
        t = CastTypesTransform(config={"mapping": {"id": "float32", "age": "int16", "name": "utf8"}})
        result = t.apply(sample_df)
        assert result["id"].dtype == pl.Float32
        assert result["age"].dtype == pl.Int16


# ═══════════════════════════════════════════════════════════════════════════
# DeduplicateTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestDeduplicate:
    def test_dedup_on_subset_keep_first(self, sample_df_with_duplicates):
        t = DeduplicateTransform(config={"subset": ["id"], "keep": "first"})
        result = t.apply(sample_df_with_duplicates)
        assert len(result) == 3
        # Should keep first occurrence
        assert result.filter(pl.col("id") == 2)["name"].to_list() == ["Bob_v1"]

    def test_dedup_on_subset_keep_last(self, sample_df_with_duplicates):
        t = DeduplicateTransform(config={"subset": ["id"], "keep": "last"})
        result = t.apply(sample_df_with_duplicates)
        assert len(result) == 3
        assert result.filter(pl.col("id") == 2)["name"].to_list() == ["Bob_v2"]

    def test_dedup_all_columns(self):
        df = pl.DataFrame({"a": [1, 1, 2], "b": [10, 10, 20]})
        t = DeduplicateTransform(config={})
        result = t.apply(df)
        assert len(result) == 2

    def test_no_duplicates_unchanged(self, sample_df):
        t = DeduplicateTransform(config={"subset": ["id"]})
        result = t.apply(sample_df)
        assert len(result) == len(sample_df)

    def test_missing_column_raises(self, sample_df):
        t = DeduplicateTransform(config={"subset": ["nonexistent"]})
        with pytest.raises(TransformConfigError, match="not found"):
            t.apply(sample_df)


# ═══════════════════════════════════════════════════════════════════════════
# FilterRowsTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestFilterRows:
    def test_filter_greater_than(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "age", "operator": ">=", "value": 30}]
        })
        result = t.apply(sample_df)
        assert all(age >= 30 for age in result["age"].to_list())

    def test_filter_equals(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "status", "operator": "==", "value": "active"}]
        })
        result = t.apply(sample_df)
        assert len(result) == 3

    def test_filter_in(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "status", "operator": "in", "value": ["active", "pending"]}]
        })
        result = t.apply(sample_df)
        assert len(result) == 4

    def test_filter_not_in(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "status", "operator": "not_in", "value": ["inactive"]}]
        })
        result = t.apply(sample_df)
        assert len(result) == 4

    def test_filter_is_not_null(self, sample_df_with_nulls):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "name", "operator": "is_not_null"}]
        })
        result = t.apply(sample_df_with_nulls)
        assert len(result) == 3

    def test_filter_contains(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "email", "operator": "contains", "value": "alice"}]
        })
        result = t.apply(sample_df)
        assert len(result) == 1

    def test_filter_and_logic(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [
                {"column": "age", "operator": ">=", "value": 30},
                {"column": "status", "operator": "==", "value": "active"},
            ],
            "logic": "and",
        })
        result = t.apply(sample_df)
        assert len(result) == 2

    def test_filter_or_logic(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [
                {"column": "name", "operator": "==", "value": "Alice"},
                {"column": "name", "operator": "==", "value": "Bob"},
            ],
            "logic": "or",
        })
        result = t.apply(sample_df)
        assert len(result) == 2

    def test_sql_where(self, sample_df):
        t = FilterRowsTransform(config={"sql_where": "age >= 30"})
        result = t.apply(sample_df)
        assert all(age >= 30 for age in result["age"].to_list())

    def test_unknown_operator_raises(self, sample_df):
        t = FilterRowsTransform(config={
            "conditions": [{"column": "age", "operator": "~=", "value": 30}]
        })
        with pytest.raises(TransformConfigError, match="unknown operator"):
            t.apply(sample_df)

    def test_missing_config_rejected(self):
        with pytest.raises(TransformConfigError):
            FilterRowsTransform(config={})


# ═══════════════════════════════════════════════════════════════════════════
# FlattenTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestFlatten:
    def test_flatten_struct(self, nested_df):
        t = FlattenTransform(config={})
        result = t.apply(nested_df)
        assert "address.city" in result.columns
        assert "address.zip" in result.columns
        assert "address" not in result.columns

    def test_custom_separator(self, nested_df):
        t = FlattenTransform(config={"separator": "_"})
        result = t.apply(nested_df)
        assert "address_city" in result.columns
        assert "address_zip" in result.columns

    def test_flatten_specific_columns(self, nested_df):
        t = FlattenTransform(config={"columns": ["address"]})
        result = t.apply(nested_df)
        assert "address.city" in result.columns

    def test_no_structs_unchanged(self, sample_df):
        t = FlattenTransform(config={})
        result = t.apply(sample_df)
        assert result.columns == sample_df.columns

    def test_max_depth(self, nested_df):
        t = FlattenTransform(config={"max_depth": 0})
        result = t.apply(nested_df)
        # max_depth=0 means don't flatten at all
        assert "address" in result.columns


# ═══════════════════════════════════════════════════════════════════════════
# SqlTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestSqlTransform:
    def test_basic_query(self, sample_df):
        t = SqlTransform(config={"query": "SELECT id, name FROM data WHERE age > 30"})
        result = t.apply(sample_df)
        assert result.columns == ["id", "name"]
        assert len(result) > 0

    def test_aggregation(self, sample_df):
        t = SqlTransform(config={"query": "SELECT status, COUNT(*) AS cnt FROM data GROUP BY status"})
        result = t.apply(sample_df)
        assert "status" in result.columns
        assert "cnt" in result.columns

    def test_order_by(self, sample_df):
        t = SqlTransform(config={"query": "SELECT * FROM data ORDER BY age DESC"})
        result = t.apply(sample_df)
        ages = result["age"].to_list()
        assert ages == sorted(ages, reverse=True)

    def test_custom_table_name(self, sample_df):
        t = SqlTransform(config={"query": "SELECT * FROM my_table", "table_name": "my_table"})
        result = t.apply(sample_df)
        assert len(result) == len(sample_df)

    def test_missing_query_rejected(self):
        with pytest.raises(TransformConfigError):
            SqlTransform(config={})


# ═══════════════════════════════════════════════════════════════════════════
# ComputedColumnsTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestComputedColumns:
    def test_literal_value(self, sample_df):
        t = ComputedColumnsTransform(config={
            "columns": {"version": {"literal": "v1"}}
        })
        result = t.apply(sample_df)
        assert "version" in result.columns
        assert result["version"].to_list() == ["v1"] * 5

    def test_polars_expression(self, sample_df):
        t = ComputedColumnsTransform(config={
            "columns": {"age_plus_10": "col('age') + lit(10)"}
        })
        result = t.apply(sample_df)
        assert result["age_plus_10"].to_list() == [35, 40, 45, 38, 52]

    def test_sql_expression(self, sample_df):
        t = ComputedColumnsTransform(config={
            "columns": {"is_old": {"sql": "CASE WHEN age >= 35 THEN 'yes' ELSE 'no' END"}}
        })
        result = t.apply(sample_df)
        assert "is_old" in result.columns

    def test_direct_literal(self, sample_df):
        t = ComputedColumnsTransform(config={
            "columns": {"num": 42}
        })
        result = t.apply(sample_df)
        assert result["num"].to_list() == [42] * 5

    def test_invalid_expression_raises(self, sample_df):
        t = ComputedColumnsTransform(config={
            "columns": {"bad": "this_is_not_valid()"}
        })
        with pytest.raises(TransformConfigError, match="invalid expression"):
            t.apply(sample_df)

    def test_empty_columns_rejected(self):
        with pytest.raises(TransformConfigError):
            ComputedColumnsTransform(config={"columns": {}})


# ═══════════════════════════════════════════════════════════════════════════
# CustomTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestCustomTransform:
    def test_inline_code(self, sample_df):
        code = """
def transform(df):
    return df.with_columns(pl.col("name").str.to_uppercase().alias("name"))
"""
        t = CustomTransform(config={"code": code})
        result = t.apply(sample_df)
        assert result["name"].to_list() == ["ALICE", "BOB", "CHARLIE", "DIANA", "EVE"]

    def test_inline_must_define_transform(self, sample_df):
        t = CustomTransform(config={"code": "x = 1"})
        with pytest.raises(TransformConfigError, match="transform"):
            t.apply(sample_df)

    def test_missing_config_rejected(self):
        with pytest.raises(TransformConfigError):
            CustomTransform(config={})

    def test_inline_must_return_dataframe(self, sample_df):
        code = """
def transform(df):
    return "not a dataframe"
"""
        t = CustomTransform(config={"code": code})
        with pytest.raises(Exception):
            t.apply(sample_df)


# ═══════════════════════════════════════════════════════════════════════════
# ValidateSchemaTransform
# ═══════════════════════════════════════════════════════════════════════════

class TestValidateSchema:
    def test_reject_nulls(self, sample_df_with_nulls):
        t = ValidateSchemaTransform(config={
            "columns": {
                "name": {"nullable": False},
            },
            "on_fail": "reject",
        })
        result = t.apply(sample_df_with_nulls)
        assert len(result) == 3  # Row with null name removed
        assert None not in result["name"].to_list()

    def test_reject_range(self, sample_df_with_nulls):
        t = ValidateSchemaTransform(config={
            "columns": {
                "age": {"nullable": True, "min": 0, "max": 150},
            },
            "on_fail": "reject",
        })
        result = t.apply(sample_df_with_nulls)
        # age=-5 should be rejected
        for age in result["age"].to_list():
            if age is not None:
                assert age >= 0

    def test_pattern_validation(self):
        df = pl.DataFrame({
            "email": ["alice@test.com", "bad-email", "bob@test.com"],
        })
        t = ValidateSchemaTransform(config={
            "columns": {
                "email": {"pattern": r"^[^@]+@[^@]+$"},
            },
            "on_fail": "reject",
        })
        result = t.apply(df)
        assert len(result) == 2

    def test_fail_mode_raises(self, sample_df_with_nulls):
        t = ValidateSchemaTransform(config={
            "columns": {
                "name": {"nullable": False},
            },
            "on_fail": "fail",
        })
        with pytest.raises(SchemaValidationError, match="failed validation"):
            t.apply(sample_df_with_nulls)

    def test_warn_mode_keeps_all_rows(self, sample_df_with_nulls):
        t = ValidateSchemaTransform(config={
            "columns": {
                "name": {"nullable": False},
            },
            "on_fail": "warn",
        })
        result = t.apply(sample_df_with_nulls)
        assert len(result) == 4  # All rows kept
        assert "_validation_errors" in result.columns

    def test_missing_required_column_raises(self, sample_df):
        t = ValidateSchemaTransform(config={
            "columns": {
                "nonexistent_col": {"nullable": False},
            },
        })
        with pytest.raises(SchemaValidationError, match="missing"):
            t.apply(sample_df)

    def test_all_valid_rows_pass(self, sample_df):
        t = ValidateSchemaTransform(config={
            "columns": {
                "id": {"nullable": False, "min": 0},
                "name": {"nullable": False},
            },
            "on_fail": "reject",
        })
        result = t.apply(sample_df)
        assert len(result) == 5  # All pass

    def test_empty_config_rejected(self):
        with pytest.raises(TransformConfigError):
            ValidateSchemaTransform(config={"columns": {}})
