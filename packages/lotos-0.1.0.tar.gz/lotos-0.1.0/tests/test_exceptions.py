"""Tests for lotos.core.exceptions — exception hierarchy."""

from __future__ import annotations

import pytest

from lotos.core.exceptions import (
    ConfigError,
    ConnectorAuthError,
    ConnectorConnectionError,
    ConnectorError,
    ConnectorPaginationError,
    ConnectorTimeoutError,
    LotosError,
    MonitoringError,
    OrchestrationError,
    PipelineError,
    PipelineExecutionError,
    PipelineValidationError,
    RegistryError,
    SchemaValidationError,
    SecretResolutionError,
    SinkError,
    SinkWriteError,
    TransformConfigError,
    TransformError,
)


class TestExceptionHierarchy:
    """Verify that all exceptions inherit from LotosError."""

    @pytest.mark.parametrize("exc_cls", [
        ConfigError,
        SecretResolutionError,
        PipelineError,
        PipelineValidationError,
        PipelineExecutionError,
        ConnectorError,
        ConnectorAuthError,
        ConnectorConnectionError,
        ConnectorTimeoutError,
        ConnectorPaginationError,
        TransformError,
        SchemaValidationError,
        TransformConfigError,
        SinkError,
        SinkWriteError,
        OrchestrationError,
        MonitoringError,
        RegistryError,
    ])
    def test_inherits_from_lotos_error(self, exc_cls):
        assert issubclass(exc_cls, LotosError)

    def test_catch_all_with_lotos_error(self):
        with pytest.raises(LotosError):
            raise ConnectorAuthError("Unauthorized")

    def test_connector_subclass_chain(self):
        """ConnectorAuthError → ConnectorError → LotosError."""
        assert issubclass(ConnectorAuthError, ConnectorError)
        assert issubclass(ConnectorError, LotosError)

    def test_transform_subclass_chain(self):
        """TransformConfigError → TransformError → LotosError."""
        assert issubclass(TransformConfigError, TransformError)
        assert issubclass(SchemaValidationError, TransformError)

    def test_pipeline_subclass_chain(self):
        assert issubclass(PipelineValidationError, PipelineError)
        assert issubclass(PipelineExecutionError, PipelineError)

    def test_secret_resolution_is_config_error(self):
        assert issubclass(SecretResolutionError, ConfigError)

    def test_exception_message(self):
        err = ConnectorError("something broke")
        assert str(err) == "something broke"
