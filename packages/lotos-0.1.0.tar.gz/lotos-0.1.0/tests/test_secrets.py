"""Tests for lotos.config.secrets — secret resolution."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from lotos.config.secrets import (
    EnvSecretsBackend,
    _SECRET_PATTERN,
    resolve_secrets,
)
from lotos.core.exceptions import SecretResolutionError


class TestSecretPattern:
    """Test the regex pattern for ${SECRET:key}."""

    def test_matches_simple(self):
        m = _SECRET_PATTERN.fullmatch("${SECRET:my_key}")
        assert m is not None
        assert m.group(1) == "my_key"

    def test_matches_with_underscores(self):
        m = _SECRET_PATTERN.fullmatch("${SECRET:DB_CONNECTION_STRING}")
        assert m is not None
        assert m.group(1) == "DB_CONNECTION_STRING"

    def test_no_match_plain_string(self):
        m = _SECRET_PATTERN.fullmatch("just a string")
        assert m is None

    def test_no_match_incomplete(self):
        m = _SECRET_PATTERN.fullmatch("${SECRET:}")
        assert m is None


class TestEnvSecretsBackend:
    """Test the environment variable secrets backend."""

    def test_resolves_from_env(self):
        backend = EnvSecretsBackend()
        with patch.dict(os.environ, {"MY_TEST_SECRET": "s3cret"}):
            assert backend.get("MY_TEST_SECRET") == "s3cret"

    def test_missing_key_raises(self):
        backend = EnvSecretsBackend()
        with pytest.raises(SecretResolutionError, match="not found"):
            backend.get("THIS_KEY_DEFINITELY_DOES_NOT_EXIST_XYZ")


class TestResolveSecrets:
    """Test the recursive resolve_secrets function."""

    def test_resolve_string_value(self):
        with patch.dict(os.environ, {"DB_URL": "postgresql://localhost/db"}):
            result = resolve_secrets({"connection_string": "${SECRET:DB_URL}"})
            assert result["connection_string"] == "postgresql://localhost/db"

    def test_resolve_nested_dict(self):
        with patch.dict(os.environ, {"TOKEN": "abc123"}):
            data = {
                "source": {
                    "config": {
                        "auth": {"token": "${SECRET:TOKEN}"}
                    }
                }
            }
            result = resolve_secrets(data)
            assert result["source"]["config"]["auth"]["token"] == "abc123"

    def test_resolve_in_list(self):
        with patch.dict(os.environ, {"VAL": "resolved"}):
            data = {"items": ["${SECRET:VAL}", "plain"]}
            result = resolve_secrets(data)
            assert result["items"] == ["resolved", "plain"]

    def test_inline_replacement(self):
        with patch.dict(os.environ, {"HOST": "myhost", "PORT": "5432"}):
            data = {"url": "jdbc://${SECRET:HOST}:${SECRET:PORT}/db"}
            result = resolve_secrets(data)
            assert result["url"] == "jdbc://myhost:5432/db"

    def test_no_secrets_unchanged(self):
        data = {"key": "value", "num": 42, "nested": {"a": True}}
        result = resolve_secrets(data)
        assert result == data

    def test_missing_secret_raises(self):
        with pytest.raises(SecretResolutionError):
            resolve_secrets({"key": "${SECRET:NONEXISTENT_SECRET_XYZ_123}"})

    def test_does_not_mutate_original(self):
        with patch.dict(os.environ, {"X": "y"}):
            original = {"a": "${SECRET:X}"}
            original_copy = dict(original)
            resolve_secrets(original)
            assert original == original_copy
