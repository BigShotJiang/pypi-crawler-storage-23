"""Tests for lotos.cli — CLI commands via Typer test runner."""

from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
import yaml
from typer.testing import CliRunner

from lotos.cli import app

runner = CliRunner()


class TestCliRun:
    def test_run_valid_pipeline(self, tmp_path):
        # Create input CSV
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1, 2], "name": ["A", "B"]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "cli-test"},
            "source": {"connector": "file", "config": {"path": str(csv_path), "format": "csv"}},
            "transforms": [],
        }
        yaml_path = tmp_path / "cli_test.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        output_path = str(tmp_path / "out.parquet")
        result = runner.invoke(app, ["run", str(yaml_path), "--output", output_path])
        assert result.exit_code == 0
        assert "success" in result.output.lower()
        assert Path(output_path).exists()

    def test_run_with_csv_output(self, tmp_path):
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "csv-out"},
            "source": {"connector": "file", "config": {"path": str(csv_path), "format": "csv"}},
            "transforms": [],
        }
        yaml_path = tmp_path / "csv_out.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        output_path = str(tmp_path / "out.csv")
        result = runner.invoke(app, ["run", str(yaml_path), "--output", output_path, "--format", "csv"])
        assert result.exit_code == 0

    def test_run_nonexistent_file(self):
        result = runner.invoke(app, ["run", "/nonexistent/pipeline.yaml"])
        assert result.exit_code == 1

    def test_run_dry_run(self, tmp_path):
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1, 2]}).write_csv(str(csv_path))

        output_path = str(tmp_path / "sink_output.parquet")
        yaml_data = {
            "pipeline": {"name": "dry-run-test"},
            "source": {"connector": "file", "config": {"path": str(csv_path), "format": "csv"}},
            "transforms": [],
            "sink": {"connector": "file", "config": {"path": output_path, "format": "parquet"}, "write_mode": "overwrite"},
        }
        yaml_path = tmp_path / "dry.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        result = runner.invoke(app, ["run", str(yaml_path), "--dry-run"])
        assert result.exit_code == 0
        # Sink should NOT have been written
        assert not Path(output_path).exists()


class TestCliValidate:
    def test_validate_valid(self, tmp_path):
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "valid"},
            "source": {"connector": "file", "config": {"path": str(csv_path), "format": "csv"}},
            "transforms": [],
        }
        yaml_path = tmp_path / "valid.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        result = runner.invoke(app, ["validate", str(yaml_path)])
        assert result.exit_code == 0
        assert "valid" in result.output.lower()

    def test_validate_nonexistent(self):
        result = runner.invoke(app, ["validate", "/nonexistent.yaml"])
        assert result.exit_code == 1

    def test_validate_bad_schema(self, tmp_path):
        yaml_path = tmp_path / "bad.yaml"
        yaml_path.write_text(yaml.dump({"pipeline": {"name": "x"}}), encoding="utf-8")
        result = runner.invoke(app, ["validate", str(yaml_path)])
        assert result.exit_code == 1


class TestCliInspect:
    def test_inspect_valid(self, tmp_path):
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "inspect-me", "description": "For inspection", "tags": ["test"]},
            "source": {"connector": "file", "config": {"path": str(csv_path), "format": "csv"}},
            "transforms": [{"type": "select_columns", "config": {"columns": ["id"]}}],
        }
        yaml_path = tmp_path / "inspect.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        result = runner.invoke(app, ["inspect", str(yaml_path)])
        assert result.exit_code == 0
        assert "inspect-me" in result.output

    def test_inspect_nonexistent(self):
        result = runner.invoke(app, ["inspect", "/nonexistent.yaml"])
        assert result.exit_code == 1


class TestCliList:
    def test_list_connectors(self):
        result = runner.invoke(app, ["list", "connectors"])
        assert result.exit_code == 0
        assert "sql" in result.output.lower()
        assert "file" in result.output.lower()

    def test_list_transforms(self):
        result = runner.invoke(app, ["list", "transforms"])
        assert result.exit_code == 0
        assert "flatten" in result.output.lower()
        assert "cast_types" in result.output.lower()

    def test_list_sinks(self):
        result = runner.invoke(app, ["list", "sinks"])
        assert result.exit_code == 0
        assert "file" in result.output.lower()

    def test_list_all(self):
        result = runner.invoke(app, ["list", "all"])
        assert result.exit_code == 0


class TestCliInit:
    def test_init_default(self, tmp_path):
        result = runner.invoke(app, ["init", "my_test_pipe", "--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert (tmp_path / "my_test_pipe.yaml").exists()

    def test_init_rest_api(self, tmp_path):
        result = runner.invoke(app, ["init", "api_pipe", "--dir", str(tmp_path), "--source", "rest_api"])
        assert result.exit_code == 0
        content = (tmp_path / "api_pipe.yaml").read_text()
        assert "rest_api" in content

    def test_init_file(self, tmp_path):
        result = runner.invoke(app, ["init", "file_pipe", "--dir", str(tmp_path), "--source", "file"])
        assert result.exit_code == 0
        content = (tmp_path / "file_pipe.yaml").read_text()
        assert "file" in content


class TestCliBanner:
    def test_no_command_shows_banner(self):
        result = runner.invoke(app, [])
        assert result.exit_code == 0
