"""Tests for lotos.sinks — file sink."""

from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest

from lotos.core.exceptions import SinkError, SinkWriteError
from lotos.core.models import WriteMode
from lotos.sinks.file_sink import FileSink


class TestFileSink:
    def test_write_parquet(self, tmp_path, sample_df):
        path = str(tmp_path / "output.parquet")
        sink = FileSink(config={"path": path, "format": "parquet"}, write_mode=WriteMode.OVERWRITE)
        rows = sink.write(sample_df)
        assert rows == 5
        result = pl.read_parquet(path)
        assert len(result) == 5

    def test_write_csv(self, tmp_path, sample_df):
        path = str(tmp_path / "output.csv")
        sink = FileSink(config={"path": path, "format": "csv"}, write_mode=WriteMode.OVERWRITE)
        rows = sink.write(sample_df)
        assert rows == 5
        result = pl.read_csv(path)
        assert len(result) == 5

    def test_write_json(self, tmp_path, sample_df):
        path = str(tmp_path / "output.json")
        sink = FileSink(config={"path": path, "format": "json"}, write_mode=WriteMode.OVERWRITE)
        rows = sink.write(sample_df)
        assert rows == 5

    def test_auto_detect_format(self, tmp_path, sample_df):
        path = str(tmp_path / "auto.parquet")
        sink = FileSink(config={"path": path}, write_mode=WriteMode.OVERWRITE)
        rows = sink.write(sample_df)
        assert rows == 5
        result = pl.read_parquet(path)
        assert len(result) == 5

    def test_creates_parent_directory(self, tmp_path, sample_df):
        path = str(tmp_path / "nested" / "dir" / "output.parquet")
        sink = FileSink(config={"path": path, "format": "parquet"}, write_mode=WriteMode.OVERWRITE)
        sink.write(sample_df)
        assert Path(path).exists()

    def test_overwrite_replaces_file(self, tmp_path, sample_df):
        path = str(tmp_path / "overwrite.parquet")
        sink = FileSink(config={"path": path, "format": "parquet"}, write_mode=WriteMode.OVERWRITE)
        sink.write(sample_df)
        sink.write(sample_df.head(2))
        result = pl.read_parquet(path)
        assert len(result) == 2

    def test_append_csv(self, tmp_path, sample_df):
        path = str(tmp_path / "append.csv")
        sink = FileSink(config={"path": path, "format": "csv"}, write_mode=WriteMode.APPEND)
        sink.write(sample_df.head(2))
        rows = sink.write(sample_df.head(3))
        result = pl.read_csv(path)
        assert len(result) == 5  # 2 + 3

    def test_missing_path_raises(self):
        with pytest.raises(SinkError, match="path"):
            FileSink(config={})

    def test_unsupported_format_raises(self, tmp_path, sample_df):
        path = str(tmp_path / "bad.txt")
        sink = FileSink(config={"path": path, "format": "txt"}, write_mode=WriteMode.OVERWRITE)
        with pytest.raises(SinkWriteError, match="Unsupported"):
            sink.write(sample_df)

    def test_write_empty_dataframe(self, tmp_path):
        path = str(tmp_path / "empty.parquet")
        df = pl.DataFrame({"id": [], "name": []}).cast({"id": pl.Int64, "name": pl.Utf8})
        sink = FileSink(config={"path": path, "format": "parquet"}, write_mode=WriteMode.OVERWRITE)
        rows = sink.write(df)
        assert rows == 0

    def test_default_write_mode_is_append(self):
        sink = FileSink(config={"path": "/tmp/x.csv"})
        assert sink.write_mode == WriteMode.APPEND

    def test_repr(self):
        sink = FileSink(config={"path": "/tmp/x.csv"}, write_mode=WriteMode.OVERWRITE)
        assert "FileSink" in repr(sink)
        assert "overwrite" in repr(sink)
