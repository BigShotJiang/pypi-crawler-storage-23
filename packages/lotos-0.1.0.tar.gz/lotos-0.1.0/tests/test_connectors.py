"""Tests for lotos.connectors — File, SQL, and REST API connectors."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import polars as pl
import pytest

from lotos.connectors.file_connector import FileConnector
from lotos.connectors.sql_connector import SqlConnector
from lotos.connectors.rest_api import RestApiConnector, _deep_get
from lotos.core.exceptions import (
    ConnectorAuthError,
    ConnectorError,
    ConnectorTimeoutError,
)


# ═══════════════════════════════════════════════════════════════════════════
# FileConnector
# ═══════════════════════════════════════════════════════════════════════════

class TestFileConnector:
    def test_extract_csv(self, sample_csv):
        conn = FileConnector(config={"path": str(sample_csv), "format": "csv"})
        df = conn.extract()
        assert len(df) == 3
        assert "id" in df.columns
        assert "name" in df.columns

    def test_extract_json(self, sample_json):
        conn = FileConnector(config={"path": str(sample_json), "format": "json"})
        df = conn.extract()
        assert len(df) == 3

    def test_extract_parquet(self, sample_parquet):
        conn = FileConnector(config={"path": str(sample_parquet), "format": "parquet"})
        df = conn.extract()
        assert len(df) == 3

    def test_auto_detect_format_csv(self, sample_csv):
        conn = FileConnector(config={"path": str(sample_csv)})
        df = conn.extract()
        assert len(df) == 3

    def test_auto_detect_format_parquet(self, sample_parquet):
        conn = FileConnector(config={"path": str(sample_parquet)})
        df = conn.extract()
        assert len(df) == 3

    def test_missing_path_raises(self):
        with pytest.raises(ConnectorError, match="path"):
            FileConnector(config={})

    def test_unsupported_format_raises(self):
        with pytest.raises(ConnectorError, match="Unsupported format"):
            FileConnector(config={"path": "/data.csv", "format": "xml"})

    def test_file_not_found_raises(self, tmp_path):
        conn = FileConnector(config={"path": str(tmp_path / "nonexistent.csv"), "format": "csv"})
        with pytest.raises(ConnectorError, match="No files found"):
            conn.extract()

    def test_csv_separator(self, tmp_path):
        path = tmp_path / "semi.csv"
        path.write_text("id;name\n1;Alice\n2;Bob\n", encoding="utf-8")
        conn = FileConnector(config={"path": str(path), "format": "csv", "csv_separator": ";"})
        df = conn.extract()
        assert len(df) == 2
        assert "id" in df.columns

    def test_glob_pattern(self, tmp_path):
        for i in range(3):
            df = pl.DataFrame({"id": [i], "val": [i * 10]})
            df.write_csv(str(tmp_path / f"part_{i}.csv"))
        conn = FileConnector(config={"path": str(tmp_path / "part_*.csv"), "format": "csv"})
        df = conn.extract()
        assert len(df) == 3

    def test_ndjson(self, tmp_path):
        path = tmp_path / "data.ndjson"
        lines = [json.dumps({"id": i, "v": i * 2}) for i in range(3)]
        path.write_text("\n".join(lines), encoding="utf-8")
        conn = FileConnector(config={"path": str(path), "format": "ndjson"})
        df = conn.extract()
        assert len(df) == 3

    def test_watermark_returns_none_without_config(self, sample_csv):
        conn = FileConnector(config={"path": str(sample_csv), "format": "csv"})
        df = conn.extract()
        assert conn.get_new_watermark(df) is None

    def test_watermark_returns_max(self, sample_csv):
        conn = FileConnector(config={"path": str(sample_csv), "format": "csv", "watermark_field": "id"})
        df = conn.extract()
        wm = conn.get_new_watermark(df)
        assert wm == 3


# ═══════════════════════════════════════════════════════════════════════════
# SqlConnector
# ═══════════════════════════════════════════════════════════════════════════

class TestSqlConnector:
    def test_missing_connection_string_raises(self):
        with pytest.raises(ConnectorError, match="connection_string"):
            SqlConnector(config={"table": "users"})

    def test_missing_query_and_table_raises(self):
        with pytest.raises(ConnectorError, match="query.*table"):
            SqlConnector(config={"connection_string": "sqlite://"})

    def test_build_query_from_table(self):
        conn = SqlConnector(config={
            "connection_string": "sqlite://",
            "table": "users",
        })
        query = conn._build_query()
        assert "SELECT" in query
        assert "users" in query

    def test_build_query_with_schema(self):
        conn = SqlConnector(config={
            "connection_string": "sqlite://",
            "table": "users",
            "schema": "public",
        })
        query = conn._build_query()
        assert "public.users" in query

    def test_build_query_with_limit(self):
        conn = SqlConnector(config={
            "connection_string": "sqlite://",
            "query": "SELECT * FROM t",
            "limit": 10,
        })
        query = conn._build_query()
        assert "LIMIT 10" in query

    def test_build_query_with_columns(self):
        conn = SqlConnector(config={
            "connection_string": "sqlite://",
            "table": "users",
            "columns": ["id", "name"],
        })
        query = conn._build_query()
        assert "id, name" in query

    def test_build_query_with_watermark(self):
        conn = SqlConnector(
            config={
                "connection_string": "sqlite://",
                "query": "SELECT * FROM t",
                "watermark_field": "updated_at",
            },
            watermark_value="2025-01-01",
        )
        query = conn._build_query()
        assert "updated_at" in query
        assert "2025-01-01" in query

    def test_extract_sqlite_in_memory(self, tmp_path):
        """Test extract with a real SQLite database."""
        import sqlalchemy as sa
        db_path = tmp_path / "test.db"
        conn_str = f"sqlite:///{db_path}"
        engine = sa.create_engine(conn_str)
        with engine.connect() as conn:
            conn.execute(sa.text("CREATE TABLE users (id INTEGER, name TEXT)"))
            conn.execute(sa.text("INSERT INTO users VALUES (1, 'Alice')"))
            conn.execute(sa.text("INSERT INTO users VALUES (2, 'Bob')"))
            conn.commit()

        connector = SqlConnector(config={
            "connection_string": conn_str,
            "query": "SELECT * FROM users",
        })
        df = connector.extract()
        assert len(df) == 2
        assert "id" in df.columns
        assert "name" in df.columns

    def test_extract_empty_table(self, tmp_path):
        import sqlalchemy as sa
        db_path = tmp_path / "empty.db"
        conn_str = f"sqlite:///{db_path}"
        engine = sa.create_engine(conn_str)
        with engine.connect() as conn:
            conn.execute(sa.text("CREATE TABLE empty_table (id INTEGER, name TEXT)"))
            conn.commit()

        connector = SqlConnector(config={
            "connection_string": conn_str,
            "query": "SELECT * FROM empty_table",
        })
        df = connector.extract()
        assert df.is_empty()
        assert "id" in df.columns


# ═══════════════════════════════════════════════════════════════════════════
# RestApiConnector — deep_get helper
# ═══════════════════════════════════════════════════════════════════════════

class TestDeepGet:
    def test_simple_path(self):
        data = {"a": {"b": {"c": 42}}}
        assert _deep_get(data, "a.b.c") == 42

    def test_list_index(self):
        data = {"items": [10, 20, 30]}
        assert _deep_get(data, "items.1") == 20

    def test_missing_key_returns_none(self):
        data = {"a": 1}
        assert _deep_get(data, "b") is None

    def test_nested_missing_returns_none(self):
        data = {"a": {"b": 1}}
        assert _deep_get(data, "a.c") is None


# ═══════════════════════════════════════════════════════════════════════════
# RestApiConnector
# ═══════════════════════════════════════════════════════════════════════════

class TestRestApiConnector:
    def test_missing_url_raises(self):
        with pytest.raises(ConnectorError, match="url"):
            RestApiConnector(config={})

    def test_build_headers_bearer(self):
        conn = RestApiConnector(config={
            "url": "https://api.example.com",
            "auth": {"type": "bearer", "token": "xyz"},
        })
        headers = conn._build_headers()
        assert headers["Authorization"] == "Bearer xyz"

    def test_build_headers_api_key(self):
        conn = RestApiConnector(config={
            "url": "https://api.example.com",
            "auth": {"type": "api_key", "header": "X-API-Key", "key": "mykey"},
        })
        headers = conn._build_headers()
        assert headers["X-API-Key"] == "mykey"

    def test_build_headers_basic(self):
        import base64
        conn = RestApiConnector(config={
            "url": "https://api.example.com",
            "auth": {"type": "basic", "username": "user", "password": "pass"},
        })
        headers = conn._build_headers()
        expected = base64.b64encode(b"user:pass").decode()
        assert headers["Authorization"] == f"Basic {expected}"

    def test_build_headers_no_auth(self):
        conn = RestApiConnector(config={
            "url": "https://api.example.com",
            "headers": {"Accept": "application/json"},
        })
        headers = conn._build_headers()
        assert headers == {"Accept": "application/json"}

    def test_extract_records_list(self):
        conn = RestApiConnector(config={"url": "https://api.example.com"})
        records = conn._extract_records([{"id": 1}, {"id": 2}], None)
        assert len(records) == 2

    def test_extract_records_dict(self):
        conn = RestApiConnector(config={"url": "https://api.example.com"})
        records = conn._extract_records({"id": 1}, None)
        assert records == [{"id": 1}]

    def test_extract_records_with_path(self):
        conn = RestApiConnector(config={"url": "https://api.example.com"})
        data = {"data": {"results": [{"id": 1}, {"id": 2}]}}
        records = conn._extract_records(data, "data.results")
        assert len(records) == 2

    def test_extract_records_empty(self):
        conn = RestApiConnector(config={"url": "https://api.example.com"})
        records = conn._extract_records(None, None)
        assert records == []

    @patch("lotos.connectors.rest_api.httpx.Client")
    def test_extract_mocked(self, mock_client_cls):
        """Test extract with mocked HTTP response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.request.return_value = mock_response
        mock_client_cls.return_value = mock_client

        conn = RestApiConnector(config={"url": "https://api.example.com/data"})
        df = conn.extract()
        assert len(df) == 2
        assert "id" in df.columns

    def test_watermark_none_without_field(self):
        conn = RestApiConnector(config={"url": "https://api.example.com"})
        df = pl.DataFrame({"id": [1, 2]})
        assert conn.get_new_watermark(df) is None

    def test_watermark_returns_max(self):
        conn = RestApiConnector(config={
            "url": "https://api.example.com",
            "watermark_field": "id",
        })
        df = pl.DataFrame({"id": [1, 5, 3]})
        assert conn.get_new_watermark(df) == 5
