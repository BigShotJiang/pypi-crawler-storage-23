"""Tests for lotos.core.pipeline — load, validate, and run pipelines."""

from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest
import yaml

from lotos.core.exceptions import (
    PipelineExecutionError,
    PipelineValidationError,
)
from lotos.core.models import PipelineDefinition, RunStatus
from lotos.core.pipeline import load_pipeline, run_pipeline, validate_pipeline


# ═══════════════════════════════════════════════════════════════════════════
# load_pipeline
# ═══════════════════════════════════════════════════════════════════════════

class TestLoadPipeline:
    def test_load_valid_yaml(self, minimal_pipeline_yaml):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        assert pipeline.pipeline.name == "test-pipeline"
        assert pipeline.source.connector == "file"

    def test_load_with_transforms(self, pipeline_with_transforms_yaml):
        pipeline = load_pipeline(pipeline_with_transforms_yaml)
        assert len(pipeline.transforms) == 2
        assert pipeline.transforms[0].type == "select_columns"

    def test_load_with_sink(self, pipeline_with_sink_yaml):
        pipeline = load_pipeline(pipeline_with_sink_yaml)
        assert pipeline.sink is not None
        assert pipeline.sink.connector == "file"

    def test_file_not_found_raises(self):
        with pytest.raises(PipelineValidationError, match="not found"):
            load_pipeline("/nonexistent/path/pipeline.yaml")

    def test_invalid_yaml_raises(self, tmp_path):
        bad_yaml = tmp_path / "bad.yaml"
        bad_yaml.write_text(": invalid:\n  yaml: [bad", encoding="utf-8")
        with pytest.raises(PipelineValidationError, match="Invalid YAML"):
            load_pipeline(bad_yaml)

    def test_non_dict_yaml_raises(self, tmp_path):
        bad_yaml = tmp_path / "list.yaml"
        bad_yaml.write_text("- item1\n- item2\n", encoding="utf-8")
        with pytest.raises(PipelineValidationError, match="mapping"):
            load_pipeline(bad_yaml)

    def test_missing_required_fields_raises(self, tmp_path):
        bad_yaml = tmp_path / "missing.yaml"
        data = {"pipeline": {"name": "test"}}  # no source
        bad_yaml.write_text(yaml.dump(data), encoding="utf-8")
        with pytest.raises(PipelineValidationError, match="validation failed"):
            load_pipeline(bad_yaml)


# ═══════════════════════════════════════════════════════════════════════════
# validate_pipeline
# ═══════════════════════════════════════════════════════════════════════════

class TestValidatePipeline:
    def test_valid_pipeline_no_warnings(self, minimal_pipeline_yaml):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        warnings = validate_pipeline(pipeline)
        assert warnings == []

    def test_unknown_connector_warns(self):
        pipeline = PipelineDefinition(
            pipeline={"name": "test"},
            source={"connector": "nonexistent_xyz", "config": {}},
        )
        warnings = validate_pipeline(pipeline)
        assert any("nonexistent_xyz" in w for w in warnings)

    def test_unknown_transform_warns(self):
        pipeline = PipelineDefinition(
            pipeline={"name": "test"},
            source={"connector": "file", "config": {"path": "/x"}},
            transforms=[{"type": "nonexistent_transform_xyz", "config": {}}],
        )
        warnings = validate_pipeline(pipeline)
        assert any("nonexistent_transform_xyz" in w for w in warnings)

    def test_unknown_sink_warns(self):
        pipeline = PipelineDefinition(
            pipeline={"name": "test"},
            source={"connector": "file", "config": {"path": "/x"}},
            sink={"connector": "nonexistent_sink_xyz", "config": {}},
        )
        warnings = validate_pipeline(pipeline)
        assert any("nonexistent_sink_xyz" in w for w in warnings)


# ═══════════════════════════════════════════════════════════════════════════
# run_pipeline
# ═══════════════════════════════════════════════════════════════════════════

class TestRunPipeline:
    def test_run_minimal(self, minimal_pipeline_yaml):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_extracted == 3
        assert result.rows_transformed == 3

    def test_run_with_transforms(self, pipeline_with_transforms_yaml):
        pipeline = load_pipeline(pipeline_with_transforms_yaml)
        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_extracted == 3
        assert result.rows_transformed == 3

    def test_run_with_sink(self, pipeline_with_sink_yaml, tmp_path):
        pipeline = load_pipeline(pipeline_with_sink_yaml)
        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_loaded == 3

    def test_run_with_output(self, minimal_pipeline_yaml, tmp_path):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        output_path = str(tmp_path / "result.parquet")
        result = run_pipeline(pipeline, output_path=output_path)
        assert result.status == RunStatus.SUCCESS
        assert Path(output_path).exists()
        df = pl.read_parquet(output_path)
        assert len(df) == 3

    def test_run_output_csv(self, minimal_pipeline_yaml, tmp_path):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        output_path = str(tmp_path / "result.csv")
        result = run_pipeline(pipeline, output_path=output_path, output_format="csv")
        assert result.status == RunStatus.SUCCESS
        df = pl.read_csv(output_path)
        assert len(df) == 3

    def test_run_output_json(self, minimal_pipeline_yaml, tmp_path):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        output_path = str(tmp_path / "result.json")
        result = run_pipeline(pipeline, output_path=output_path, output_format="json")
        assert result.status == RunStatus.SUCCESS

    def test_dry_run_skips_sink(self, pipeline_with_sink_yaml):
        pipeline = load_pipeline(pipeline_with_sink_yaml)
        result = run_pipeline(pipeline, dry_run=True)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_loaded == 0

    def test_run_records_duration(self, minimal_pipeline_yaml):
        pipeline = load_pipeline(minimal_pipeline_yaml)
        result = run_pipeline(pipeline)
        assert result.started_at is not None
        assert result.finished_at is not None
        assert result.duration_seconds is not None
        assert result.duration_seconds >= 0

    def test_run_with_watermark(self, tmp_path):
        # Create CSV with an ID column
        csv_path = tmp_path / "wm.csv"
        pl.DataFrame({"id": [1, 2, 3], "name": ["A", "B", "C"]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "wm-test"},
            "source": {
                "connector": "file",
                "config": {"path": str(csv_path), "format": "csv", "watermark_field": "id"},
            },
            "transforms": [],
            "watermark": {"field": "id", "initial_value": "0"},
        }
        yaml_path = tmp_path / "wm.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        pipeline = load_pipeline(yaml_path)
        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.watermark_value == 3

    def test_run_bad_connector_raises(self, tmp_path):
        csv_path = tmp_path / "data.csv"
        pl.DataFrame({"id": [1]}).write_csv(str(csv_path))

        yaml_data = {
            "pipeline": {"name": "bad"},
            "source": {
                "connector": "file",
                "config": {"path": str(tmp_path / "nonexistent_*.csv"), "format": "csv"},
            },
            "transforms": [],
        }
        yaml_path = tmp_path / "bad.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        pipeline = load_pipeline(yaml_path)
        with pytest.raises(PipelineExecutionError):
            run_pipeline(pipeline)

    def test_run_empty_dataset(self, tmp_path):
        csv_path = tmp_path / "empty.csv"
        csv_path.write_text("id,name\n", encoding="utf-8")

        yaml_data = {
            "pipeline": {"name": "empty-test"},
            "source": {
                "connector": "file",
                "config": {"path": str(csv_path), "format": "csv"},
            },
            "transforms": [],
        }
        yaml_path = tmp_path / "empty.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        pipeline = load_pipeline(yaml_path)
        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_extracted == 0


# ═══════════════════════════════════════════════════════════════════════════
# Integration: Full pipeline with multiple transforms
# ═══════════════════════════════════════════════════════════════════════════

class TestPipelineIntegration:
    def test_full_pipeline_file_to_file(self, tmp_path):
        """End-to-end: CSV → transforms → Parquet output."""
        # Create input
        input_path = tmp_path / "input.csv"
        df = pl.DataFrame({
            "id": [1, 2, 3, 3, 4],
            "name": ["Alice", "Bob", "Charlie", "Charlie", "Diana"],
            "age": [25, 30, 35, 35, 28],
            "status": ["active", "inactive", "active", "active", "active"],
        })
        df.write_csv(str(input_path))

        output_path = str(tmp_path / "output.parquet")

        yaml_data = {
            "pipeline": {
                "name": "integration-test",
                "description": "Full integration test",
                "version": "1.0",
                "tags": ["test"],
            },
            "source": {
                "connector": "file",
                "config": {"path": str(input_path), "format": "csv"},
            },
            "transforms": [
                {"type": "select_columns", "config": {"columns": ["id", "name", "age", "status"]}},
                {"type": "deduplicate", "config": {"subset": ["id"], "keep": "first"}},
                {"type": "filter_rows", "config": {
                    "conditions": [{"column": "status", "operator": "==", "value": "active"}]
                }},
                {"type": "rename_columns", "config": {"mapping": {"name": "full_name"}}},
                {"type": "cast_types", "config": {"mapping": {"id": "int64", "age": "int32"}}},
            ],
            "sink": {
                "connector": "file",
                "config": {"path": output_path, "format": "parquet"},
                "write_mode": "overwrite",
            },
        }
        yaml_path = tmp_path / "integration.yaml"
        yaml_path.write_text(yaml.dump(yaml_data), encoding="utf-8")

        pipeline = load_pipeline(yaml_path)
        warnings = validate_pipeline(pipeline)
        assert warnings == []

        result = run_pipeline(pipeline)
        assert result.status == RunStatus.SUCCESS
        assert result.rows_extracted == 5
        # After dedup: 4 rows, after filter (active only): 3
        assert result.rows_transformed == 3
        assert result.rows_loaded == 3

        # Verify output
        out_df = pl.read_parquet(output_path)
        assert len(out_df) == 3
        assert "full_name" in out_df.columns
        assert out_df["id"].dtype == pl.Int64
        assert out_df["age"].dtype == pl.Int32
