"""Shared fixtures for Lotos test suite."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any

import polars as pl
import pytest
import yaml


# ── Sample DataFrames ────────────────────────────────────────────────────────

@pytest.fixture
def sample_df() -> pl.DataFrame:
    """A simple DataFrame used across many tests."""
    return pl.DataFrame({
        "id": [1, 2, 3, 4, 5],
        "name": ["Alice", "Bob", "Charlie", "Diana", "Eve"],
        "email": ["alice@test.com", "bob@test.com", "charlie@test.com", "diana@test.com", "eve@test.com"],
        "age": [25, 30, 35, 28, 42],
        "status": ["active", "inactive", "active", "pending", "active"],
        "score": [88.5, 72.0, 95.3, 60.1, 100.0],
    })


@pytest.fixture
def sample_df_with_nulls() -> pl.DataFrame:
    """DataFrame with null values for validation tests."""
    return pl.DataFrame({
        "id": [1, 2, 3, 4],
        "name": ["Alice", None, "Charlie", "Diana"],
        "email": ["alice@test.com", None, "bad-email", "diana@test.com"],
        "age": [25, 30, None, -5],
    })


@pytest.fixture
def sample_df_with_duplicates() -> pl.DataFrame:
    """DataFrame with duplicate rows for dedup tests."""
    return pl.DataFrame({
        "id": [1, 2, 2, 3, 3],
        "name": ["Alice", "Bob_v1", "Bob_v2", "Charlie_v1", "Charlie_v2"],
        "value": [10, 20, 25, 30, 35],
    })


@pytest.fixture
def nested_df() -> pl.DataFrame:
    """DataFrame with nested struct columns for flatten tests."""
    return pl.DataFrame({
        "id": [1, 2],
        "address": [
            {"city": "New York", "zip": "10001"},
            {"city": "London", "zip": "SW1A"},
        ],
    })


# ── Temporary files ──────────────────────────────────────────────────────────

@pytest.fixture
def tmp_dir(tmp_path: Path) -> Path:
    """Provide a temporary directory."""
    return tmp_path


@pytest.fixture
def sample_csv(tmp_path: Path) -> Path:
    """Create a temporary CSV file."""
    df = pl.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Charlie"],
        "age": [25, 30, 35],
    })
    path = tmp_path / "sample.csv"
    df.write_csv(str(path))
    return path


@pytest.fixture
def sample_json(tmp_path: Path) -> Path:
    """Create a temporary JSON file."""
    df = pl.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Charlie"],
    })
    path = tmp_path / "sample.json"
    df.write_json(str(path))
    return path


@pytest.fixture
def sample_parquet(tmp_path: Path) -> Path:
    """Create a temporary Parquet file."""
    df = pl.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Charlie"],
    })
    path = tmp_path / "sample.parquet"
    df.write_parquet(str(path))
    return path


# ── Pipeline YAML fixtures ──────────────────────────────────────────────────

@pytest.fixture
def minimal_pipeline_yaml(tmp_path: Path, sample_csv: Path) -> Path:
    """Create a minimal valid pipeline YAML pointing to a CSV."""
    data = {
        "pipeline": {
            "name": "test-pipeline",
            "description": "Test pipeline",
            "version": "1.0",
            "tags": ["test"],
        },
        "source": {
            "connector": "file",
            "config": {
                "path": str(sample_csv),
                "format": "csv",
            },
        },
        "transforms": [],
    }
    path = tmp_path / "test_pipeline.yaml"
    path.write_text(yaml.dump(data, default_flow_style=False), encoding="utf-8")
    return path


@pytest.fixture
def pipeline_with_transforms_yaml(tmp_path: Path, sample_csv: Path) -> Path:
    """Create a pipeline YAML with transforms."""
    data = {
        "pipeline": {
            "name": "test-transforms",
            "description": "Pipeline with transforms",
            "version": "1.0",
        },
        "source": {
            "connector": "file",
            "config": {
                "path": str(sample_csv),
                "format": "csv",
            },
        },
        "transforms": [
            {
                "type": "select_columns",
                "config": {"columns": ["id", "name"]},
            },
            {
                "type": "rename_columns",
                "config": {"mapping": {"name": "full_name"}},
            },
        ],
    }
    path = tmp_path / "test_transforms.yaml"
    path.write_text(yaml.dump(data, default_flow_style=False), encoding="utf-8")
    return path


@pytest.fixture
def pipeline_with_sink_yaml(tmp_path: Path, sample_csv: Path) -> Path:
    """Create a pipeline YAML with a file sink."""
    output_path = str(tmp_path / "output.parquet")
    data = {
        "pipeline": {
            "name": "test-sink",
            "description": "Pipeline with sink",
            "version": "1.0",
        },
        "source": {
            "connector": "file",
            "config": {
                "path": str(sample_csv),
                "format": "csv",
            },
        },
        "transforms": [],
        "sink": {
            "connector": "file",
            "config": {
                "path": output_path,
                "format": "parquet",
            },
            "write_mode": "overwrite",
        },
    }
    path = tmp_path / "test_sink.yaml"
    path.write_text(yaml.dump(data, default_flow_style=False), encoding="utf-8")
    return path


# ── Auto-discover registry ──────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def auto_discover_plugins():
    """Ensure all plugins are registered before each test."""
    from lotos.core.registry import _auto_discover
    _auto_discover()
