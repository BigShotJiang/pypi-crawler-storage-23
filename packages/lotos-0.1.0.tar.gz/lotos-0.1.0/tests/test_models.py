"""Tests for lotos.core.models — Pydantic models and enums."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from lotos.core.models import (
    PipelineDefinition,
    PipelineMeta,
    QualityAction,
    QualityCheck,
    RunResult,
    RunStatus,
    ScheduleConfig,
    SinkConfig,
    SourceConfig,
    TransformStep,
    WatermarkConfig,
    WriteMode,
)


# ═══════════════════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════════════════

class TestWriteMode:
    def test_values(self):
        assert WriteMode.APPEND == "append"
        assert WriteMode.OVERWRITE == "overwrite"
        assert WriteMode.UPSERT == "upsert"

    def test_from_string(self):
        assert WriteMode("append") == WriteMode.APPEND
        assert WriteMode("overwrite") == WriteMode.OVERWRITE


class TestRunStatus:
    def test_all_statuses(self):
        expected = {"pending", "running", "success", "failed", "cancelled"}
        actual = {s.value for s in RunStatus}
        assert actual == expected


class TestQualityAction:
    def test_values(self):
        assert QualityAction.ALERT == "alert"
        assert QualityAction.WARN == "warn"
        assert QualityAction.BLOCK == "block"


# ═══════════════════════════════════════════════════════════════════════════
# PipelineMeta
# ═══════════════════════════════════════════════════════════════════════════

class TestPipelineMeta:
    def test_minimal(self):
        meta = PipelineMeta(name="my-pipe")
        assert meta.name == "my-pipe"
        assert meta.description == ""
        assert meta.version == "1.0"
        assert meta.tags == []

    def test_full(self):
        meta = PipelineMeta(
            name="prod-pipeline",
            description="Production ETL",
            version="2.5",
            tags=["prod", "etl"],
        )
        assert meta.tags == ["prod", "etl"]

    def test_empty_name_rejected(self):
        with pytest.raises(ValidationError):
            PipelineMeta(name="")


# ═══════════════════════════════════════════════════════════════════════════
# SourceConfig
# ═══════════════════════════════════════════════════════════════════════════

class TestSourceConfig:
    def test_minimal(self):
        src = SourceConfig(connector="sql")
        assert src.connector == "sql"
        assert src.config == {}

    def test_with_config(self):
        src = SourceConfig(
            connector="sql",
            config={"connection_string": "postgresql://localhost/db", "table": "users"},
        )
        assert src.config["table"] == "users"

    def test_missing_connector_rejected(self):
        with pytest.raises(ValidationError):
            SourceConfig()


# ═══════════════════════════════════════════════════════════════════════════
# TransformStep
# ═══════════════════════════════════════════════════════════════════════════

class TestTransformStep:
    def test_minimal(self):
        step = TransformStep(type="flatten")
        assert step.type == "flatten"
        assert step.config == {}

    def test_with_config(self):
        step = TransformStep(type="cast_types", config={"mapping": {"id": "int64"}})
        assert step.config["mapping"]["id"] == "int64"


# ═══════════════════════════════════════════════════════════════════════════
# SinkConfig
# ═══════════════════════════════════════════════════════════════════════════

class TestSinkConfig:
    def test_defaults(self):
        sink = SinkConfig(connector="file", config={"path": "/out.csv"})
        assert sink.write_mode == WriteMode.APPEND
        assert sink.upsert_key == []
        assert sink.batch_size == 10_000

    def test_overwrite(self):
        sink = SinkConfig(connector="file", config={}, write_mode="overwrite")
        assert sink.write_mode == WriteMode.OVERWRITE


# ═══════════════════════════════════════════════════════════════════════════
# ScheduleConfig
# ═══════════════════════════════════════════════════════════════════════════

class TestScheduleConfig:
    def test_defaults(self):
        sc = ScheduleConfig()
        assert sc.cron is None
        assert sc.max_retries == 3
        assert sc.timeout_seconds == 3600
        assert sc.concurrency == 1

    def test_custom(self):
        sc = ScheduleConfig(cron="0 * * * *", max_retries=5, timeout_seconds=600)
        assert sc.cron == "0 * * * *"


# ═══════════════════════════════════════════════════════════════════════════
# WatermarkConfig
# ═══════════════════════════════════════════════════════════════════════════

class TestWatermarkConfig:
    def test_minimal(self):
        wm = WatermarkConfig(field="updated_at")
        assert wm.field == "updated_at"
        assert wm.initial_value is None

    def test_with_initial(self):
        wm = WatermarkConfig(field="id", initial_value="0")
        assert wm.initial_value == "0"


# ═══════════════════════════════════════════════════════════════════════════
# PipelineDefinition
# ═══════════════════════════════════════════════════════════════════════════

class TestPipelineDefinition:
    def test_minimal(self):
        pd = PipelineDefinition(
            pipeline={"name": "test"},
            source={"connector": "file", "config": {"path": "/data.csv"}},
        )
        assert pd.pipeline.name == "test"
        assert pd.transforms == []
        assert pd.sink is None
        assert pd.watermark is None

    def test_full(self):
        pd = PipelineDefinition(
            pipeline={"name": "full", "description": "Full pipeline", "version": "2.0", "tags": ["a"]},
            source={"connector": "sql", "config": {"connection_string": "pg://x", "query": "SELECT 1"}},
            transforms=[
                {"type": "flatten", "config": {}},
                {"type": "cast_types", "config": {"mapping": {"id": "int64"}}},
            ],
            sink={"connector": "file", "config": {"path": "/out.parquet"}, "write_mode": "overwrite"},
            watermark={"field": "updated_at", "initial_value": "2020-01-01"},
        )
        assert len(pd.transforms) == 2
        assert pd.sink.write_mode == WriteMode.OVERWRITE
        assert pd.watermark.field == "updated_at"

    def test_invalid_source_rejected(self):
        with pytest.raises(ValidationError):
            PipelineDefinition(
                pipeline={"name": "bad"},
                source={"config": {"path": "/x"}},  # missing connector
            )


# ═══════════════════════════════════════════════════════════════════════════
# RunResult
# ═══════════════════════════════════════════════════════════════════════════

class TestRunResult:
    def test_defaults(self):
        r = RunResult(pipeline_name="test")
        assert r.status == RunStatus.PENDING
        assert r.rows_extracted == 0
        assert r.error is None

    def test_duration(self):
        t1 = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        t2 = datetime(2026, 1, 1, 0, 0, 10, tzinfo=timezone.utc)
        r = RunResult(pipeline_name="test", started_at=t1, finished_at=t2)
        assert r.duration_seconds == 10.0

    def test_duration_none_when_not_finished(self):
        r = RunResult(pipeline_name="test", started_at=datetime.now(timezone.utc))
        assert r.duration_seconds is None
