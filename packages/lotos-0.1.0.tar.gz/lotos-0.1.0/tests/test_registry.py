"""Tests for lotos.core.registry — plugin registry and auto-discovery."""

from __future__ import annotations

import pytest

from lotos.core.exceptions import RegistryError
from lotos.core.registry import Registry, _auto_discover


class TestRegistryDecorators:
    """Test that @Registry.connector / transform / sink decorators work."""

    def test_register_connector(self):
        @Registry.connector("_test_connector")
        class _TestConn:
            pass

        assert Registry.get_connector("_test_connector") is _TestConn
        # Clean up
        del Registry._connectors["_test_connector"]

    def test_register_transform(self):
        @Registry.transform("_test_transform")
        class _TestTrans:
            pass

        assert Registry.get_transform("_test_transform") is _TestTrans
        del Registry._transforms["_test_transform"]

    def test_register_sink(self):
        @Registry.sink("_test_sink")
        class _TestSink:
            pass

        assert Registry.get_sink("_test_sink") is _TestSink
        del Registry._sinks["_test_sink"]


class TestRegistryLookup:
    """Test get_* methods raise RegistryError for unknown plugins."""

    def test_unknown_connector_raises(self):
        with pytest.raises(RegistryError, match="not found"):
            Registry.get_connector("nonexistent_connector_xyz")

    def test_unknown_transform_raises(self):
        with pytest.raises(RegistryError, match="not found"):
            Registry.get_transform("nonexistent_transform_xyz")

    def test_unknown_sink_raises(self):
        with pytest.raises(RegistryError, match="not found"):
            Registry.get_sink("nonexistent_sink_xyz")


class TestRegistryIntrospection:
    """Test listing and summary methods."""

    def test_list_connectors_returns_dict(self):
        result = Registry.list_connectors()
        assert isinstance(result, dict)
        assert "sql" in result
        assert "file" in result
        assert "rest_api" in result

    def test_list_transforms_returns_dict(self):
        result = Registry.list_transforms()
        assert isinstance(result, dict)
        # Check some built-in transforms
        for name in ["flatten", "cast_types", "select_columns", "rename_columns",
                      "drop_columns", "deduplicate", "filter_rows", "sql", "computed", "custom"]:
            assert name in result, f"Transform '{name}' not registered"

    def test_list_sinks_returns_dict(self):
        result = Registry.list_sinks()
        assert isinstance(result, dict)
        assert "file" in result

    def test_summary(self):
        summary = Registry.summary()
        assert "connectors" in summary
        assert "transforms" in summary
        assert "sinks" in summary
        assert isinstance(summary["connectors"], list)


class TestAutoDiscover:
    """Test _auto_discover imports all built-in modules."""

    def test_discover_registers_builtins(self):
        _auto_discover()
        assert "sql" in Registry._connectors
        assert "file" in Registry._connectors
        assert "rest_api" in Registry._connectors
        assert "flatten" in Registry._transforms
        assert "file" in Registry._sinks
