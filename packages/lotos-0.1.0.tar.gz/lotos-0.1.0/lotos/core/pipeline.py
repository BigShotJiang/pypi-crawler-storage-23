"""Pipeline loader, validator, and runner.

This is the execution engine that:
1. Parses a YAML pipeline definition
2. Resolves secrets
3. Instantiates the source connector (Layer 1)
4. Runs the transform chain (Layer 2)
5. (Future) Writes to sink (Layer 4)
6. (Future) Runs quality checks (Layer 5)
7. Returns a RunResult with metadata
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import polars as pl
import yaml

from lotos.config.logging import get_logger, new_trace_id
from lotos.config.secrets import resolve_secrets
from lotos.core.exceptions import (
    PipelineExecutionError,
    PipelineValidationError,
)
from lotos.core.models import (
    PipelineDefinition,
    RunResult,
    RunStatus,
)
from lotos.core.registry import Registry, _auto_discover

logger = get_logger(__name__)


def load_pipeline(path: str | Path) -> PipelineDefinition:
    """Load and validate a pipeline YAML file.

    Parameters
    ----------
    path : str or Path
        Path to the YAML file.

    Returns
    -------
    PipelineDefinition
        Validated pipeline model.

    Raises
    ------
    PipelineValidationError
        If the YAML is malformed or doesn't match the schema.
    """
    path = Path(path)
    if not path.exists():
        raise PipelineValidationError(f"Pipeline file not found: {path}")

    raw = path.read_text(encoding="utf-8")

    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise PipelineValidationError(f"Invalid YAML: {exc}") from exc

    if not isinstance(data, dict):
        raise PipelineValidationError("Pipeline YAML must be a mapping (dict) at top level")

    # Resolve secret placeholders before validation
    data = resolve_secrets(data)

    try:
        pipeline = PipelineDefinition.model_validate(data)
    except Exception as exc:
        raise PipelineValidationError(f"Pipeline schema validation failed: {exc}") from exc

    return pipeline


def validate_pipeline(pipeline: PipelineDefinition) -> list[str]:
    """Check that all referenced connectors and transforms exist.

    Returns a list of warnings (empty = all good).
    """
    _auto_discover()
    warnings: list[str] = []

    # Check source connector exists
    try:
        Registry.get_connector(pipeline.source.connector)
    except Exception:
        warnings.append(f"Source connector '{pipeline.source.connector}' is not registered")

    # Check transforms exist
    for i, step in enumerate(pipeline.transforms):
        try:
            Registry.get_transform(step.type)
        except Exception:
            warnings.append(f"Transform #{i + 1} '{step.type}' is not registered")

    # Check sink exists (if defined)
    if pipeline.sink:
        try:
            Registry.get_sink(pipeline.sink.connector)
        except Exception:
            warnings.append(f"Sink connector '{pipeline.sink.connector}' is not registered")

    return warnings


def run_pipeline(
    pipeline: PipelineDefinition,
    *,
    dry_run: bool = False,
    output_path: str | None = None,
    output_format: str = "parquet",
    watermark_value: Any = None,
) -> RunResult:
    """Execute a pipeline end-to-end.

    Parameters
    ----------
    pipeline : PipelineDefinition
        The validated pipeline to run.
    dry_run : bool
        If True, extract and transform but don't write to sink.
    output_path : str, optional
        Save the result DataFrame to this file (useful for Layer 1+2 only).
    output_format : str
        Format for output_path: csv, json, parquet.
    watermark_value : Any, optional
        Override the watermark value for incremental loading.

    Returns
    -------
    RunResult
        Execution result with metrics and status.
    """
    _auto_discover()

    trace_id = new_trace_id()
    result = RunResult(
        pipeline_name=pipeline.pipeline.name,
        status=RunStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
    )

    logger.info(
        "pipeline.start",
        pipeline=pipeline.pipeline.name,
        trace_id=trace_id,
    )

    try:
        # ── Layer 1: Extract ─────────────────────────────────────────
        connector_cls = Registry.get_connector(pipeline.source.connector)

        # Resolve watermark
        wm = watermark_value
        if wm is None and pipeline.watermark:
            wm = pipeline.watermark.initial_value

        connector = connector_cls(
            config=pipeline.source.config,
            watermark_value=wm,
        )

        df = connector.extract()
        result.rows_extracted = len(df)

        logger.info(
            "pipeline.extracted",
            rows=len(df),
            columns=len(df.columns),
            trace_id=trace_id,
        )

        if df.is_empty():
            logger.info("pipeline.empty", trace_id=trace_id)
            result.status = RunStatus.SUCCESS
            result.finished_at = datetime.now(timezone.utc)
            return result

        # ── Layer 2: Transform ───────────────────────────────────────
        for i, step in enumerate(pipeline.transforms):
            transform_cls = Registry.get_transform(step.type)
            transform = transform_cls(config=step.config)

            before = len(df)
            df = transform.apply(df)

            logger.info(
                "pipeline.transform",
                step=i + 1,
                type=step.type,
                rows_before=before,
                rows_after=len(df),
                trace_id=trace_id,
            )

        result.rows_transformed = len(df)

        # ── Layer 4: Sink (if configured) ────────────────────────────
        if pipeline.sink and not dry_run:
            try:
                sink_cls = Registry.get_sink(pipeline.sink.connector)
                sink = sink_cls(
                    config=pipeline.sink.config,
                    write_mode=pipeline.sink.write_mode,
                    upsert_key=pipeline.sink.upsert_key,
                    batch_size=pipeline.sink.batch_size,
                )
                result.rows_loaded = sink.write(df)
                logger.info(
                    "pipeline.loaded",
                    rows=result.rows_loaded,
                    sink=pipeline.sink.connector,
                    trace_id=trace_id,
                )
            except Exception as exc:
                logger.warning(
                    "pipeline.sink.error",
                    error=str(exc),
                    trace_id=trace_id,
                )
                raise

        # ── Optional: save output locally ────────────────────────────
        if output_path:
            _save_output(df, output_path, output_format)
            logger.info("pipeline.output.saved", path=output_path, trace_id=trace_id)

        # ── Update watermark ─────────────────────────────────────────
        new_wm = connector.get_new_watermark(df)
        if new_wm is not None:
            result.watermark_value = new_wm

        result.status = RunStatus.SUCCESS

    except Exception as exc:
        result.status = RunStatus.FAILED
        result.error = str(exc)
        logger.error(
            "pipeline.failed",
            error=str(exc),
            trace_id=trace_id,
        )
        raise PipelineExecutionError(str(exc)) from exc

    finally:
        result.finished_at = datetime.now(timezone.utc)

    logger.info(
        "pipeline.done",
        pipeline=pipeline.pipeline.name,
        status=result.status.value,
        duration=result.duration_seconds,
        rows_extracted=result.rows_extracted,
        rows_transformed=result.rows_transformed,
        rows_loaded=result.rows_loaded,
        trace_id=trace_id,
    )

    return result


def _save_output(df: pl.DataFrame, path: str, fmt: str) -> None:
    """Write DataFrame to a local file."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    match fmt.lower():
        case "csv":
            df.write_csv(str(p))
        case "json":
            df.write_json(str(p))
        case "parquet":
            df.write_parquet(str(p))
        case _:
            raise ValueError(f"Unsupported output format: {fmt}")
