"""Custom exceptions for Lotos framework.

All exceptions inherit from LotosError to allow catching
any framework error with a single except clause.
"""

from __future__ import annotations


class LotosError(Exception):
    """Base exception for all Lotos errors."""


# ── Configuration ────────────────────────────────────────────────────────────
class ConfigError(LotosError):
    """Invalid or missing configuration."""


class SecretResolutionError(ConfigError):
    """A secret reference could not be resolved."""


# ── Pipeline ─────────────────────────────────────────────────────────────────
class PipelineError(LotosError):
    """Generic pipeline error."""


class PipelineValidationError(PipelineError):
    """Pipeline YAML failed structural validation."""


class PipelineExecutionError(PipelineError):
    """Pipeline failed during execution."""


# ── Connectors (Layer 1) ────────────────────────────────────────────────────
class ConnectorError(LotosError):
    """Generic connector error."""


class ConnectorAuthError(ConnectorError):
    """Authentication / authorization failure."""


class ConnectorConnectionError(ConnectorError):
    """Could not establish connection to source."""


class ConnectorTimeoutError(ConnectorError):
    """Connection or read timed out."""


class ConnectorPaginationError(ConnectorError):
    """Pagination logic encountered an error."""


# ── Transforms (Layer 2) ────────────────────────────────────────────────────
class TransformError(LotosError):
    """Generic transform error."""


class SchemaValidationError(TransformError):
    """Data did not pass schema validation."""


class TransformConfigError(TransformError):
    """Transform received invalid configuration."""


# ── Sinks (Layer 4 — future) ────────────────────────────────────────────────
class SinkError(LotosError):
    """Generic sink error."""


class SinkWriteError(SinkError):
    """Failed to write data to destination."""


# ── Orchestration (Layer 3 — future) ────────────────────────────────────────
class OrchestrationError(LotosError):
    """Generic orchestration error."""


# ── Monitoring (Layer 5 — future) ───────────────────────────────────────────
class MonitoringError(LotosError):
    """Generic monitoring error."""


# ── Registry ────────────────────────────────────────────────────────────────
class RegistryError(LotosError):
    """Plugin not found in registry."""
