"""Plugin registry — auto-discovery of connectors, transforms, and sinks.

The registry uses a decorator pattern.  Every connector / transform class
decorates itself::

    @Registry.connector("sql")
    class SqlConnector(BaseConnector): ...

Then the pipeline runner retrieves it by name::

    cls = Registry.get_connector("sql")

This keeps layers decoupled — the runner doesn't import connectors directly.
"""

from __future__ import annotations

from typing import Any

from lotos.core.exceptions import RegistryError


class Registry:
    """Central plugin registry for all Lotos components."""

    _connectors: dict[str, type] = {}
    _transforms: dict[str, type] = {}
    _sinks: dict[str, type] = {}

    # ── Decorator helpers ────────────────────────────────────────────────

    @classmethod
    def connector(cls, name: str):
        """Register a source connector class."""
        def decorator(klass: type) -> type:
            cls._connectors[name] = klass
            return klass
        return decorator

    @classmethod
    def transform(cls, name: str):
        """Register a transform class."""
        def decorator(klass: type) -> type:
            cls._transforms[name] = klass
            return klass
        return decorator

    @classmethod
    def sink(cls, name: str):
        """Register a sink connector class."""
        def decorator(klass: type) -> type:
            cls._sinks[name] = klass
            return klass
        return decorator

    # ── Lookup helpers ───────────────────────────────────────────────────

    @classmethod
    def get_connector(cls, name: str) -> type:
        if name not in cls._connectors:
            available = ", ".join(sorted(cls._connectors)) or "(none)"
            raise RegistryError(
                f"Connector '{name}' not found. Available: {available}"
            )
        return cls._connectors[name]

    @classmethod
    def get_transform(cls, name: str) -> type:
        if name not in cls._transforms:
            available = ", ".join(sorted(cls._transforms)) or "(none)"
            raise RegistryError(
                f"Transform '{name}' not found. Available: {available}"
            )
        return cls._transforms[name]

    @classmethod
    def get_sink(cls, name: str) -> type:
        if name not in cls._sinks:
            available = ", ".join(sorted(cls._sinks)) or "(none)"
            raise RegistryError(
                f"Sink '{name}' not found. Available: {available}"
            )
        return cls._sinks[name]

    # ── Introspection ────────────────────────────────────────────────────

    @classmethod
    def list_connectors(cls) -> dict[str, type]:
        return dict(cls._connectors)

    @classmethod
    def list_transforms(cls) -> dict[str, type]:
        return dict(cls._transforms)

    @classmethod
    def list_sinks(cls) -> dict[str, type]:
        return dict(cls._sinks)

    @classmethod
    def summary(cls) -> dict[str, list[str]]:
        """Return a summary dict for CLI display."""
        return {
            "connectors": sorted(cls._connectors),
            "transforms": sorted(cls._transforms),
            "sinks": sorted(cls._sinks),
        }


def _auto_discover() -> None:
    """Import all built-in plugins so they register themselves.

    Called once at startup (in cli.py / pipeline.py) to make sure
    every ``@Registry.connector(...)`` decorator runs.
    """
    import importlib

    _builtin_modules = [
        # Layer 1 — Source Connectors
        "lotos.connectors.sql_connector",
        "lotos.connectors.rest_api",
        "lotos.connectors.file_connector",
        # Layer 2 — Transforms
        "lotos.transforms.flatten",
        "lotos.transforms.columns",
        "lotos.transforms.casting",
        "lotos.transforms.validation",
        "lotos.transforms.dedup",
        "lotos.transforms.filter",
        "lotos.transforms.sql_transform",
        "lotos.transforms.computed",
        "lotos.transforms.custom",
        # Layer 4 — Sinks
        "lotos.sinks.file_sink",
        "lotos.sinks.adls_gen2_sink",
    ]

    for mod in _builtin_modules:
        try:
            importlib.import_module(mod)
        except ImportError:
            # Optional dependency not installed — skip gracefully
            pass
