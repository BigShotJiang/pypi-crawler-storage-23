"""Pydantic models for pipeline definition and runtime state.

These models define the YAML schema that users write, and the internal
data structures used during pipeline execution.  Every field is typed
and validated — if a YAML file is invalid you get a clear error before
anything runs.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


# ═══════════════════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════════════════

class WriteMode(str, enum.Enum):
    """How the sink should write data."""
    APPEND = "append"
    OVERWRITE = "overwrite"
    UPSERT = "upsert"


class RunStatus(str, enum.Enum):
    """Pipeline run lifecycle."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"


class QualityAction(str, enum.Enum):
    """What to do when a quality check fails."""
    ALERT = "alert"
    WARN = "warn"
    BLOCK = "block"


# ═══════════════════════════════════════════════════════════════════════════
# Pipeline YAML models  (what the user writes)
# ═══════════════════════════════════════════════════════════════════════════

class PipelineMeta(BaseModel):
    """Top-level pipeline metadata."""
    name: str = Field(..., min_length=1, description="Unique pipeline identifier")
    description: str = ""
    version: str = "1.0"
    tags: list[str] = Field(default_factory=list)


class SourceConfig(BaseModel):
    """Layer 1 — Source connector configuration."""
    connector: str = Field(..., description="Registered connector name (e.g. 'sql', 'rest_api')")
    config: dict[str, Any] = Field(default_factory=dict, description="Connector-specific settings")


class TransformStep(BaseModel):
    """Layer 2 — A single transform step in the chain."""
    type: str = Field(..., description="Registered transform name (e.g. 'flatten', 'cast_types')")
    config: dict[str, Any] = Field(default_factory=dict, description="Transform-specific settings")


class SinkConfig(BaseModel):
    """Layer 4 — Destination sink configuration (stub — will be extended)."""
    connector: str = Field(..., description="Registered sink name (e.g. 'azure_blob', 'postgresql')")
    config: dict[str, Any] = Field(default_factory=dict)
    write_mode: WriteMode = WriteMode.APPEND
    upsert_key: list[str] = Field(default_factory=list)
    batch_size: int = Field(default=10_000, ge=1)


class ScheduleConfig(BaseModel):
    """Layer 3 — Schedule / orchestration config (stub — will be extended)."""
    cron: str | None = None
    max_retries: int = Field(default=3, ge=0)
    retry_backoff: str = "exponential"
    timeout_seconds: int = Field(default=3600, ge=1)
    concurrency: int = Field(default=1, ge=1)


class QualityCheck(BaseModel):
    """Layer 5 — A single quality check (stub — will be extended)."""
    type: str = Field(..., description="Check type: row_count, null_percentage, freshness, …")
    config: dict[str, Any] = Field(default_factory=dict)
    action: QualityAction = QualityAction.ALERT


class WatermarkConfig(BaseModel):
    """Incremental loading via watermark tracking."""
    field: str = Field(..., description="Column to use as watermark (e.g. 'updated_at')")
    initial_value: Any = None


class PipelineDefinition(BaseModel):
    """Complete pipeline definition — this is what a YAML file deserialises to."""
    pipeline: PipelineMeta
    source: SourceConfig
    transforms: list[TransformStep] = Field(default_factory=list)
    sink: SinkConfig | None = None
    schedule: ScheduleConfig | None = None
    quality_checks: list[QualityCheck] = Field(default_factory=list)
    watermark: WatermarkConfig | None = None


# ═══════════════════════════════════════════════════════════════════════════
# Runtime models  (internal state during execution)
# ═══════════════════════════════════════════════════════════════════════════

class RunResult(BaseModel):
    """Result of a single pipeline execution."""
    pipeline_name: str
    status: RunStatus = RunStatus.PENDING
    started_at: datetime | None = None
    finished_at: datetime | None = None
    rows_extracted: int = 0
    rows_transformed: int = 0
    rows_loaded: int = 0
    error: str | None = None
    watermark_value: Any = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def duration_seconds(self) -> float | None:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None
