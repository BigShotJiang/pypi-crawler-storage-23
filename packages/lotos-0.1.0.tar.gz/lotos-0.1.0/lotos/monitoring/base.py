"""Layer 5 — Monitoring & Quality (stub).

This module defines the interface for future monitoring and data quality
checks. Phase 1 logs results to stdout; Phase 2 will add persistent
storage, Grafana dashboards, alerting, and quality gates.

Architecture notes for future implementation:
─────────────────────────────────────────────
- PostgreSQL for run history / metrics storage
- Prometheus metrics endpoint (FastAPI)
- Grafana dashboards for success rates, latency, volumes
- Slack / email / PagerDuty alerting
- Quality checks: row counts, null %, uniqueness, freshness
- SLA monitoring with configurable thresholds
- Schema drift detection
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import polars as pl

from lotos.core.models import QualityCheck, RunResult


class BaseMonitor(ABC):
    """Interface for pipeline monitoring backends."""

    @abstractmethod
    def record_run(self, result: RunResult) -> None:
        """Persist a pipeline run result."""

    @abstractmethod
    def get_run_history(
        self,
        pipeline_name: str | None = None,
        limit: int = 100,
    ) -> list[RunResult]:
        """Retrieve run history."""

    @abstractmethod
    def send_alert(self, result: RunResult, message: str) -> None:
        """Send an alert on failure or SLA breach."""


class BaseQualityChecker(ABC):
    """Interface for data quality checks."""

    @abstractmethod
    def check(self, df: pl.DataFrame, checks: list[QualityCheck]) -> list[dict[str, Any]]:
        """Run quality checks against a DataFrame.

        Returns a list of check results::

            [
                {"check": "row_count", "passed": True, "details": {"count": 1500}},
                {"check": "null_percentage", "passed": False, "details": {"column": "email", "null_pct": 12.5}},
            ]
        """


class LogMonitor(BaseMonitor):
    """Simple monitor that logs results to stdout (for development)."""

    def __init__(self) -> None:
        from lotos.config.logging import get_logger
        self._logger = get_logger("lotos.monitoring")
        self._history: list[RunResult] = []

    def record_run(self, result: RunResult) -> None:
        self._history.append(result)
        self._logger.info(
            "pipeline.run.completed",
            pipeline=result.pipeline_name,
            status=result.status.value,
            rows_extracted=result.rows_extracted,
            rows_transformed=result.rows_transformed,
            duration_seconds=result.duration_seconds,
            error=result.error,
        )

    def get_run_history(
        self,
        pipeline_name: str | None = None,
        limit: int = 100,
    ) -> list[RunResult]:
        runs = self._history
        if pipeline_name:
            runs = [r for r in runs if r.pipeline_name == pipeline_name]
        return runs[-limit:]

    def send_alert(self, result: RunResult, message: str) -> None:
        self._logger.error(
            "pipeline.alert",
            pipeline=result.pipeline_name,
            message=message,
            status=result.status.value,
        )
