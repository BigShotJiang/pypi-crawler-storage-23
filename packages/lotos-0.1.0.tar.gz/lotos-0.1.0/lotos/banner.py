"""Lotos ASCII art banner — rendered with Rich gradient colors."""

from rich.console import Console
from rich.text import Text


def _make_flower() -> list[tuple[str, str]]:
    """Return the lotus flower as (line, zone) pairs.

    Zones control the color gradient:
        tp  = tip / top center petal
        ip  = inner petals
        op  = outer / side petals
        bs  = base / stem
        sd  = seed drop
    """
    # Clean, symmetrical lotus inspired by the reference image.
    # Uses Unicode box-drawing and smooth characters for crisp lines.
    return [
        ("                              ___", "tp"),
        ("                           .-'   '-.", "tp"),
        ("                          /         \\", "tp"),
        ("                         |           |", "tp"),
        ("                          \\         /", "tp"),
        ("                      _,,--\\       /--,,_", "ip"),
        ("                   ,-'      \\_   _/      '-,", "ip"),
        ("                  /           '''           \\", "ip"),
        ("                 |          .' '.,          |", "ip"),
        ("                 |         /     \\         |", "ip"),
        ("                  \\       |       |       /", "ip"),
        ("              _,,--\\      |       |      /--,,_", "op"),
        ("           ,-'      \\      \\     /      /      '-,", "op"),
        ("          /          '.     \\   /     .'          \\", "op"),
        ("         |             '.    | |    .'             |", "op"),
        ("         |               '.  | |  .'               |", "op"),
        ("          \\               '. | | .'               /", "op"),
        ("           '-.              '.|.'              .-'", "op"),
        ("              '-._            |            _.-'", "op"),
        ("                  '-._        |        _.-'", "bs"),
        ("                      '-._    |    _.-'", "bs"),
        ("                          '-. | .-'", "bs"),
        ("                             '|'", "bs"),
        ("                              |", "bs"),
        ("                             /|\\", "bs"),
        ("                            / | \\", "sd"),
        ("                           /  |  \\", "sd"),
        ("                          /  /|\\  \\", "sd"),
        ("                          '-' | '-'", "sd"),
        ("                              |", "sd"),
        ("                            .'|'.", "sd"),
        ("                           /  |  \\", "sd"),
        ("                          '.._|_..'", "sd"),
    ]


# Color palette — each zone maps to a Rich style
_ZONE_STYLES = {
    "tp": "bold #ff79c6",       # Pink — top petals
    "ip": "bold #bd93f9",       # Purple — inner petals
    "op": "#8be9fd",            # Cyan — outer petals
    "bs": "#50fa7b",            # Green — base / stem
    "sd": "#6272a4",            # Muted blue — seed
}


def print_banner(console: Console) -> None:
    """Print the Lotos lotus flower banner with gradient colors."""
    console.print()

    for line, zone in _make_flower():
        style = _ZONE_STYLES.get(zone, "")
        console.print(line, style=style, highlight=False)

    console.print()

    # # Title block
    # title = Text()
    # title.append("                           ╔══════════════════╗\n", style="#6272a4")
    # title.append("                           ║", style="#6272a4")
    # title.append("    L O T O S     ", style="bold #ff79c6")
    # title.append("║\n", style="#6272a4")
    # title.append("                           ╚══════════════════╝\n", style="#6272a4")
    # console.print(title, highlight=False)

    sub = Text()
    sub.append("            Self-hosted Data Ingestion Framework\n", style="#8be9fd")
    sub.append("                          v0.1.0\n", style="dim #50fa7b")
    console.print(sub, highlight=False)

    # Divider
    console.print("             ─────────────────────────────────\n", style="#6272a4", highlight=False)
