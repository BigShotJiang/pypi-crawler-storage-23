"""Global settings — loaded from environment variables.

Uses pydantic-settings so every value can be overridden via env vars
prefixed with ``LOTOS_``.  Example::

    export LOTOS_LOG_LEVEL=DEBUG
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class LotosSettings(BaseSettings):
    """Framework-wide configuration."""

    model_config = SettingsConfigDict(
        env_prefix="LOTOS_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── General ──────────────────────────────────────────────────────────
    log_level: str = Field(default="INFO", description="DEBUG | INFO | WARNING | ERROR")
    log_format: str = Field(default="json", description="json | console")
    pipelines_dir: Path = Field(
        default=Path("pipelines"),
        description="Default directory to look for pipeline YAML files",
    )

    # ── Secrets backend ──────────────────────────────────────────────────
    secrets_backend: str = Field(
        default="env",
        description="env | vault | azure_keyvault",
    )
    vault_url: str | None = None
    vault_token: str | None = None
    azure_keyvault_url: str | None = None

    # ── Database (metadata store — Layer 3 / 5 future use) ───────────────
    metadata_db_url: str | None = Field(
        default=None,
        description="PostgreSQL URL for run history / watermarks (future)",
    )

    # ── Azure defaults ───────────────────────────────────────────────────
    azure_storage_account: str | None = None
    azure_storage_key: str | None = None
    azure_storage_connection_string: str | None = None

    # ── Worker / orchestration (Layer 3 future use) ──────────────────────
    redis_url: str = "redis://localhost:6379/0"
    worker_concurrency: int = 4


# Singleton — import this everywhere
settings = LotosSettings()
