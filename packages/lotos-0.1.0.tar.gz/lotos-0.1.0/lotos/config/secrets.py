"""Pluggable secrets resolution.

Pipeline YAML files reference secrets with a ``${SECRET:name}`` syntax.
At runtime the resolver replaces these placeholders with actual values
from the configured backend.

Backends
--------
- **env** (default): read from environment variables.
- **vault**: HashiCorp Vault (future).
- **azure_keyvault**: Azure Key Vault (future).

Usage in pipeline YAML::

    source:
      connector: sql
      config:
        connection_string: "${SECRET:pg_connection}"
"""

from __future__ import annotations

import os
import re
from typing import Any

from lotos.core.exceptions import SecretResolutionError

_SECRET_PATTERN = re.compile(r"\$\{SECRET:([^}]+)\}")


class SecretsBackend:
    """Base interface for secret backends."""

    def get(self, key: str) -> str:
        raise NotImplementedError


class EnvSecretsBackend(SecretsBackend):
    """Resolve secrets from environment variables."""

    def get(self, key: str) -> str:
        value = os.environ.get(key)
        if value is None:
            raise SecretResolutionError(
                f"Secret '{key}' not found in environment variables. "
                f"Set the env var or switch to another secrets backend."
            )
        return value


class VaultSecretsBackend(SecretsBackend):
    """HashiCorp Vault backend (placeholder for future implementation)."""

    def __init__(self, url: str, token: str) -> None:
        self.url = url
        self.token = token

    def get(self, key: str) -> str:
        raise NotImplementedError(
            "Vault secrets backend is not yet implemented. "
            "Use 'env' backend or contribute the Vault integration."
        )


class AzureKeyVaultBackend(SecretsBackend):
    """Azure Key Vault backend (placeholder for future implementation)."""

    def __init__(self, vault_url: str) -> None:
        self.vault_url = vault_url

    def get(self, key: str) -> str:
        raise NotImplementedError(
            "Azure Key Vault backend is not yet implemented. "
            "Use 'env' backend or contribute the Azure KV integration."
        )


def _get_backend() -> SecretsBackend:
    """Return the configured secrets backend."""
    from lotos.config.settings import settings

    match settings.secrets_backend:
        case "env":
            return EnvSecretsBackend()
        case "vault":
            if not settings.vault_url or not settings.vault_token:
                raise SecretResolutionError("vault_url and vault_token must be set")
            return VaultSecretsBackend(settings.vault_url, settings.vault_token)
        case "azure_keyvault":
            if not settings.azure_keyvault_url:
                raise SecretResolutionError("azure_keyvault_url must be set")
            return AzureKeyVaultBackend(settings.azure_keyvault_url)
        case _:
            raise SecretResolutionError(
                f"Unknown secrets backend: {settings.secrets_backend}"
            )


def resolve_secrets(obj: Any) -> Any:
    """Recursively walk a nested dict/list and replace ``${SECRET:key}`` placeholders.

    Returns a new object — the original is never mutated.
    """
    backend = _get_backend()

    def _resolve(value: Any) -> Any:
        if isinstance(value, str):
            # Full-value replacement: "${SECRET:key}" → resolved string
            match = _SECRET_PATTERN.fullmatch(value)
            if match:
                return backend.get(match.group(1))
            # Inline replacement: "prefix_${SECRET:key}_suffix"
            def _replacer(m: re.Match) -> str:
                return backend.get(m.group(1))
            return _SECRET_PATTERN.sub(_replacer, value)
        if isinstance(value, dict):
            return {k: _resolve(v) for k, v in value.items()}
        if isinstance(value, list):
            return [_resolve(v) for v in value]
        return value

    return _resolve(obj)
