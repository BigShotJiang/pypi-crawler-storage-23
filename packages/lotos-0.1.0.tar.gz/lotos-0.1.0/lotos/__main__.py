"""Allow running Lotos as a module: python -m lotos"""

from lotos.cli import app

app()
