"""SQL source connector — PostgreSQL, MySQL, SQL Server, SQLite.

Supports full and incremental extraction via SQLAlchemy.

YAML example::

    source:
      connector: sql
      config:
        connection_string: "${SECRET:pg_connection}"
        query: "SELECT * FROM customers"
        # — OR use table + schema for auto-generated SELECT —
        # table: customers
        # schema: public

    watermark:
      field: updated_at
"""

from __future__ import annotations

from typing import Any

import polars as pl
import sqlalchemy as sa

from lotos.config.logging import get_logger
from lotos.connectors.base import BaseConnector
from lotos.core.exceptions import ConnectorConnectionError, ConnectorError
from lotos.core.registry import Registry

logger = get_logger(__name__)


@Registry.connector("sql")
class SqlConnector(BaseConnector):
    """Extract data from any SQL database supported by SQLAlchemy."""

    # ── Config validation ────────────────────────────────────────────────

    def validate_config(self) -> None:
        if "connection_string" not in self.config:
            raise ConnectorError("sql connector requires 'connection_string' in config")
        has_query = "query" in self.config
        has_table = "table" in self.config
        if not has_query and not has_table:
            raise ConnectorError("sql connector requires either 'query' or 'table' in config")

    # ── Extraction ───────────────────────────────────────────────────────

    def extract(self) -> pl.DataFrame:
        conn_str = self.config["connection_string"]
        query = self._build_query()

        logger.info("sql.extract.start", query_preview=query[:200])

        try:
            engine = sa.create_engine(conn_str, echo=False)
            with engine.connect() as conn:
                result = conn.execute(sa.text(query))
                rows = result.fetchall()
                columns = list(result.keys())
        except Exception as exc:
            raise ConnectorConnectionError(f"SQL extraction failed: {exc}") from exc

        if not rows:
            logger.info("sql.extract.empty", message="Query returned 0 rows")
            return pl.DataFrame(schema={c: pl.Utf8 for c in columns})

        df = pl.DataFrame(
            [dict(zip(columns, row)) for row in rows],
            infer_schema_length=1000,
        )
        logger.info("sql.extract.done", rows=len(df), columns=len(df.columns))
        return df

    # ── Watermark ────────────────────────────────────────────────────────

    def get_new_watermark(self, df: pl.DataFrame) -> Any:
        wm_field = self.config.get("watermark_field")
        if wm_field is None or df.is_empty():
            return None
        return df[wm_field].max()

    # ── Internals ────────────────────────────────────────────────────────

    def _build_query(self) -> str:
        """Build the SQL query from config, injecting watermark filter."""
        if "query" in self.config:
            base = self.config["query"].rstrip(";")
        else:
            table = self.config["table"]
            schema = self.config.get("schema", "")
            full_table = f"{schema}.{table}" if schema else table
            columns = self.config.get("columns", "*")
            if isinstance(columns, list):
                columns = ", ".join(columns)
            base = f"SELECT {columns} FROM {full_table}"

        # Append watermark filter for incremental loads
        wm_field = self.config.get("watermark_field")
        if wm_field and self.watermark_value is not None:
            # Use a CTE wrapper so the user's query can be arbitrarily complex
            base = (
                f"SELECT * FROM ({base}) _lotos_wm "
                f"WHERE {wm_field} > '{self.watermark_value}'"
            )

        # Optional LIMIT (useful for dev / testing)
        limit = self.config.get("limit")
        if limit is not None:
            base = f"SELECT * FROM ({base}) _lotos_lim LIMIT {int(limit)}"

        return base
