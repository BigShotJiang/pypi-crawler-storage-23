"""File-based source connector — CSV, JSON, Parquet, Excel.

Reads local files or Azure Blob Storage files.

YAML examples::

    # Local file
    source:
      connector: file
      config:
        path: "/data/input/customers.csv"
        format: csv
        csv_separator: ","
        csv_has_header: true

    # Azure Blob
    source:
      connector: file
      config:
        path: "az://container-name/path/to/file.parquet"
        format: parquet
        azure_storage_connection_string: "${SECRET:az_conn_str}"

    # Multiple files via glob
    source:
      connector: file
      config:
        path: "/data/input/*.json"
        format: json
"""

from __future__ import annotations

import glob
from pathlib import Path
from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.connectors.base import BaseConnector
from lotos.core.exceptions import ConnectorError
from lotos.core.registry import Registry

logger = get_logger(__name__)

_SUPPORTED_FORMATS = {"csv", "json", "jsonl", "ndjson", "parquet", "excel", "xlsx"}


@Registry.connector("file")
class FileConnector(BaseConnector):
    """Extract data from local or remote files."""

    def validate_config(self) -> None:
        if "path" not in self.config:
            raise ConnectorError("file connector requires 'path' in config")
        fmt = self.config.get("format")
        if fmt and fmt.lower() not in _SUPPORTED_FORMATS:
            raise ConnectorError(
                f"Unsupported format '{fmt}'. Supported: {_SUPPORTED_FORMATS}"
            )

    def extract(self) -> pl.DataFrame:
        path_str: str = self.config["path"]
        fmt = self._detect_format(path_str)

        # Azure Blob Storage path
        if path_str.startswith("az://") or path_str.startswith("abfss://"):
            return self._read_azure_blob(path_str, fmt)

        # Local path — supports glob patterns
        paths = sorted(glob.glob(path_str))
        if not paths:
            raise ConnectorError(f"No files found matching: {path_str}")

        dfs = [self._read_local(p, fmt) for p in paths]
        df = pl.concat(dfs, how="diagonal_relaxed") if len(dfs) > 1 else dfs[0]

        logger.info("file.extract.done", rows=len(df), files=len(paths))
        return df

    def get_new_watermark(self, df: pl.DataFrame) -> Any:
        wm_field = self.config.get("watermark_field")
        if wm_field is None or df.is_empty():
            return None
        return df[wm_field].max()

    # ── Internal helpers ─────────────────────────────────────────────────

    def _detect_format(self, path: str) -> str:
        fmt = self.config.get("format")
        if fmt:
            return fmt.lower()
        suffix = Path(path.split("*")[0].rstrip("/")).suffix.lstrip(".").lower()
        aliases = {"xlsx": "excel", "ndjson": "jsonl"}
        return aliases.get(suffix, suffix) or "csv"

    def _read_local(self, path: str, fmt: str) -> pl.DataFrame:
        logger.info("file.read", path=path, format=fmt)
        match fmt:
            case "csv":
                return pl.read_csv(
                    path,
                    separator=self.config.get("csv_separator", ","),
                    has_header=self.config.get("csv_has_header", True),
                    infer_schema_length=self.config.get("infer_schema_length", 1000),
                    ignore_errors=self.config.get("ignore_errors", False),
                )
            case "json":
                return pl.read_json(path)
            case "jsonl" | "ndjson":
                return pl.read_ndjson(path)
            case "parquet":
                return pl.read_parquet(path)
            case "excel" | "xlsx":
                return pl.read_excel(path, sheet_name=self.config.get("sheet_name", 0))
            case _:
                raise ConnectorError(f"Cannot read format: {fmt}")

    def _read_azure_blob(self, path: str, fmt: str) -> pl.DataFrame:
        """Download blob to memory and read with Polars."""
        try:
            from azure.storage.blob import BlobServiceClient
        except ImportError as exc:
            raise ConnectorError(
                "azure-storage-blob is required for az:// paths. "
                "Install it: pip install lotos[azure]"
            ) from exc

        conn_str = (
            self.config.get("azure_storage_connection_string")
            or self.config.get("connection_string")
        )
        if not conn_str:
            raise ConnectorError(
                "Azure Blob requires 'azure_storage_connection_string' in config"
            )

        # Parse az://container/blob/path
        clean = path.replace("az://", "").replace("abfss://", "")
        parts = clean.split("/", 1)
        container = parts[0]
        blob_path = parts[1] if len(parts) > 1 else ""

        blob_service = BlobServiceClient.from_connection_string(conn_str)
        blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
        data = blob_client.download_blob().readall()

        import io
        buf = io.BytesIO(data)

        match fmt:
            case "csv":
                return pl.read_csv(buf)
            case "json":
                return pl.read_json(buf)
            case "jsonl" | "ndjson":
                return pl.read_ndjson(buf)
            case "parquet":
                return pl.read_parquet(buf)
            case _:
                raise ConnectorError(f"Cannot read format '{fmt}' from Azure Blob")
