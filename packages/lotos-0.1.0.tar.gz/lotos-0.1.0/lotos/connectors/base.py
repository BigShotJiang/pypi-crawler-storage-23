"""Abstract base class for all source connectors (Layer 1).

Every source connector must inherit from ``BaseConnector`` and implement
the ``extract()`` method.  The framework calls ``extract()`` and expects
a Polars DataFrame back regardless of the source type.

Connectors register themselves via ``@Registry.connector("name")``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import polars as pl

from lotos.config.logging import get_logger

logger = get_logger(__name__)


class BaseConnector(ABC):
    """Interface that every source connector implements.

    Parameters
    ----------
    config : dict
        Connector-specific configuration (already secret-resolved).
    watermark_value : Any, optional
        Last watermark value for incremental loading.
    """

    def __init__(self, config: dict[str, Any], watermark_value: Any = None) -> None:
        self.config = config
        self.watermark_value = watermark_value
        self.validate_config()

    @abstractmethod
    def validate_config(self) -> None:
        """Raise ``ConnectorError`` if required config keys are missing."""

    @abstractmethod
    def extract(self) -> pl.DataFrame:
        """Connect to the source and return a Polars DataFrame.

        Implementations should:
        - Handle authentication
        - Handle pagination (if applicable)
        - Apply watermark filter for incremental loads
        - Return an empty DataFrame (not None) if no rows match
        """

    @abstractmethod
    def get_new_watermark(self, df: pl.DataFrame) -> Any:
        """Return the new watermark value from the extracted data.

        Called after a successful extract so the pipeline can persist
        the watermark for the next incremental run.

        Return ``None`` if this connector does not support watermarks.
        """

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"
