"""REST API source connector — generic HTTP extraction with pagination.

Supports multiple auth methods, pagination strategies, and response
formats.

YAML example::

    source:
      connector: rest_api
      config:
        url: "https://api.example.com/v2/contacts"
        method: GET
        headers:
          Accept: application/json
        auth:
          type: bearer
          token: "${SECRET:api_token}"
        pagination:
          type: offset          # offset | cursor | page | link_header
          limit_param: limit
          offset_param: offset
          page_size: 100
        response_path: "data.results"   # jmespath-like dot notation
        timeout: 30
        rate_limit_per_second: 5
"""

from __future__ import annotations

import time
from typing import Any

import httpx
import polars as pl

from lotos.config.logging import get_logger
from lotos.connectors.base import BaseConnector
from lotos.core.exceptions import (
    ConnectorAuthError,
    ConnectorError,
    ConnectorPaginationError,
    ConnectorTimeoutError,
)
from lotos.core.registry import Registry

logger = get_logger(__name__)


def _deep_get(data: Any, path: str) -> Any:
    """Navigate a nested dict using dot notation: 'data.results' → data["data"]["results"]."""
    for key in path.split("."):
        if isinstance(data, dict):
            data = data.get(key)
        elif isinstance(data, list) and key.isdigit():
            data = data[int(key)]
        else:
            return None
    return data


@Registry.connector("rest_api")
class RestApiConnector(BaseConnector):
    """Extract data from any REST / HTTP API."""

    def validate_config(self) -> None:
        if "url" not in self.config:
            raise ConnectorError("rest_api connector requires 'url' in config")

    def extract(self) -> pl.DataFrame:
        url = self.config["url"]
        method = self.config.get("method", "GET").upper()
        headers = self._build_headers()
        params = dict(self.config.get("params", {}))
        timeout = self.config.get("timeout", 30)
        rate_limit = self.config.get("rate_limit_per_second")
        response_path = self.config.get("response_path")

        pagination = self.config.get("pagination")
        all_records: list[dict] = []

        if pagination:
            all_records = self._extract_paginated(
                url, method, headers, params, timeout, rate_limit,
                response_path, pagination,
            )
        else:
            data = self._request(url, method, headers, params, timeout)
            records = self._extract_records(data, response_path)
            all_records.extend(records)

        if not all_records:
            logger.info("rest_api.extract.empty")
            return pl.DataFrame()

        df = pl.DataFrame(all_records, infer_schema_length=1000)
        logger.info("rest_api.extract.done", rows=len(df))
        return df

    def get_new_watermark(self, df: pl.DataFrame) -> Any:
        wm_field = self.config.get("watermark_field")
        if wm_field is None or df.is_empty():
            return None
        return df[wm_field].max()

    # ── Internal helpers ─────────────────────────────────────────────────

    def _build_headers(self) -> dict[str, str]:
        headers = dict(self.config.get("headers", {}))
        auth = self.config.get("auth")
        if auth:
            auth_type = auth.get("type", "bearer").lower()
            if auth_type == "bearer":
                token = auth.get("token", "")
                headers["Authorization"] = f"Bearer {token}"
            elif auth_type == "api_key":
                key_name = auth.get("header", "X-API-Key")
                headers[key_name] = auth.get("key", "")
            elif auth_type == "basic":
                import base64
                creds = base64.b64encode(
                    f"{auth['username']}:{auth['password']}".encode()
                ).decode()
                headers["Authorization"] = f"Basic {creds}"
        return headers

    def _request(
        self, url: str, method: str, headers: dict, params: dict, timeout: int,
    ) -> Any:
        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.request(method, url, headers=headers, params=params)
            if resp.status_code == 401:
                raise ConnectorAuthError(f"401 Unauthorized: {url}")
            if resp.status_code == 403:
                raise ConnectorAuthError(f"403 Forbidden: {url}")
            resp.raise_for_status()
            return resp.json()
        except httpx.TimeoutException as exc:
            raise ConnectorTimeoutError(f"Request timed out: {url}") from exc
        except httpx.HTTPStatusError as exc:
            raise ConnectorError(f"HTTP {exc.response.status_code}: {url}") from exc

    def _extract_records(self, data: Any, response_path: str | None) -> list[dict]:
        if response_path:
            data = _deep_get(data, response_path)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return [data]
        return []

    def _extract_paginated(
        self,
        url: str,
        method: str,
        headers: dict,
        params: dict,
        timeout: int,
        rate_limit: float | None,
        response_path: str | None,
        pagination: dict,
    ) -> list[dict]:
        strategy = pagination.get("type", "offset")
        all_records: list[dict] = []
        page = 0
        max_pages = pagination.get("max_pages", 1000)

        if strategy == "offset":
            limit_param = pagination.get("limit_param", "limit")
            offset_param = pagination.get("offset_param", "offset")
            page_size = pagination.get("page_size", 100)

            offset = 0
            while page < max_pages:
                params[limit_param] = page_size
                params[offset_param] = offset
                data = self._request(url, method, headers, params, timeout)
                records = self._extract_records(data, response_path)
                if not records:
                    break
                all_records.extend(records)
                if len(records) < page_size:
                    break
                offset += page_size
                page += 1
                self._rate_limit_sleep(rate_limit)

        elif strategy == "page":
            page_param = pagination.get("page_param", "page")
            page_size_param = pagination.get("page_size_param", "page_size")
            page_size = pagination.get("page_size", 100)
            current_page = pagination.get("start_page", 1)

            while page < max_pages:
                params[page_param] = current_page
                params[page_size_param] = page_size
                data = self._request(url, method, headers, params, timeout)
                records = self._extract_records(data, response_path)
                if not records:
                    break
                all_records.extend(records)
                if len(records) < page_size:
                    break
                current_page += 1
                page += 1
                self._rate_limit_sleep(rate_limit)

        elif strategy == "cursor":
            cursor_param = pagination.get("cursor_param", "cursor")
            cursor_path = pagination.get("cursor_path", "next_cursor")
            cursor = pagination.get("initial_cursor")

            while page < max_pages:
                if cursor:
                    params[cursor_param] = cursor
                data = self._request(url, method, headers, params, timeout)
                records = self._extract_records(data, response_path)
                all_records.extend(records)
                cursor = _deep_get(data, cursor_path) if isinstance(data, dict) else None
                if not cursor or not records:
                    break
                page += 1
                self._rate_limit_sleep(rate_limit)

        elif strategy == "link_header":
            next_url: str | None = url
            while next_url and page < max_pages:
                try:
                    with httpx.Client(timeout=timeout) as client:
                        resp = client.request(method, next_url, headers=headers, params=params)
                    resp.raise_for_status()
                    data = resp.json()
                except Exception as exc:
                    raise ConnectorPaginationError(f"link_header pagination failed: {exc}") from exc

                records = self._extract_records(data, response_path)
                all_records.extend(records)
                link = resp.headers.get("Link", "")
                next_url = self._parse_link_header(link)
                params = {}  # params are baked into the URL after first request
                page += 1
                self._rate_limit_sleep(rate_limit)
        else:
            raise ConnectorPaginationError(f"Unknown pagination type: {strategy}")

        return all_records

    @staticmethod
    def _parse_link_header(header: str) -> str | None:
        """Extract the 'next' URL from a Link header."""
        import re
        match = re.search(r'<([^>]+)>;\s*rel="next"', header)
        return match.group(1) if match else None

    @staticmethod
    def _rate_limit_sleep(rate_limit: float | None) -> None:
        if rate_limit and rate_limit > 0:
            time.sleep(1.0 / rate_limit)
