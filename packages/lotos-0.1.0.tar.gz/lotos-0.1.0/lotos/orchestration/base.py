"""Layer 3 — Pipeline Orchestration (stub).

This module defines the interface for future orchestration backends.
Phase 1 uses direct in-process execution; Phase 2 will add Celery-based
distributed workers, cron scheduling, DAG resolution, and retry logic.

Architecture notes for future implementation:
─────────────────────────────────────────────
- Celery + Redis for distributed task execution
- Celery Beat for cron scheduling
- DAG resolver for pipeline dependency graphs
- Exponential backoff retries with circuit-breaker
- Dead-letter queue for poison messages
- Configurable concurrency limits per pipeline
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from lotos.core.models import PipelineDefinition, RunResult


class BaseOrchestrator(ABC):
    """Interface for pipeline orchestrators.

    The orchestrator is responsible for:
    1. Accepting pipeline definitions
    2. Scheduling them (cron / manual / event-triggered)
    3. Dispatching execution to workers
    4. Handling retries and timeouts
    5. Tracking run state
    """

    @abstractmethod
    def submit(self, pipeline: PipelineDefinition) -> str:
        """Submit a pipeline for execution.

        Returns a run_id that can be used to track the run.
        """

    @abstractmethod
    def get_status(self, run_id: str) -> RunResult:
        """Get the current status of a pipeline run."""

    @abstractmethod
    def cancel(self, run_id: str) -> bool:
        """Cancel a running pipeline. Returns True if cancelled."""

    @abstractmethod
    def list_runs(
        self,
        pipeline_name: str | None = None,
        limit: int = 50,
    ) -> list[RunResult]:
        """List recent pipeline runs."""


class LocalOrchestrator(BaseOrchestrator):
    """Simple in-process orchestrator for development / single-machine use.

    Runs pipelines synchronously in the current process.
    No scheduling, no retries — just direct execution.
    """

    def __init__(self) -> None:
        self._runs: dict[str, RunResult] = {}

    def submit(self, pipeline: PipelineDefinition) -> str:
        # Actual execution is handled by PipelineRunner
        # This is a placeholder for the orchestration layer
        raise NotImplementedError("Use PipelineRunner.run() for now")

    def get_status(self, run_id: str) -> RunResult:
        if run_id not in self._runs:
            raise ValueError(f"Run {run_id} not found")
        return self._runs[run_id]

    def cancel(self, run_id: str) -> bool:
        return False  # Can't cancel synchronous runs

    def list_runs(
        self,
        pipeline_name: str | None = None,
        limit: int = 50,
    ) -> list[RunResult]:
        runs = list(self._runs.values())
        if pipeline_name:
            runs = [r for r in runs if r.pipeline_name == pipeline_name]
        return runs[-limit:]
