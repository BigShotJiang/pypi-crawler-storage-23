"""SQL-based transform — run SQL queries against the DataFrame.

Uses Polars' built-in SQL context so no external database is needed.

YAML example::

    transforms:
      - type: sql
        config:
          query: |
            SELECT
              id,
              UPPER(name) AS name,
              revenue / quantity AS unit_price,
              CASE WHEN status = 'active' THEN 1 ELSE 0 END AS is_active
            FROM data
            WHERE revenue > 0
            ORDER BY revenue DESC
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform


@Registry.transform("sql")
class SqlTransform(BaseTransform):
    """Run a SQL query against the DataFrame using Polars SQL context.

    The input DataFrame is registered as table ``data``.
    """

    def validate_config(self) -> None:
        if "query" not in self.config:
            raise TransformConfigError("sql transform requires 'query' in config")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        query: str = self.config["query"]
        table_name = self.config.get("table_name", "data")
        ctx = pl.SQLContext({table_name: df})
        return ctx.execute(query).collect()
