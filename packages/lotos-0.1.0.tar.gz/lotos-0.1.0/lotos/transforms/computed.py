"""Computed columns transform — add new columns via expressions.

YAML example::

    transforms:
      - type: computed
        config:
          columns:
            full_name: "col('first_name') + ' ' + col('last_name')"
            year: "col('created_at').dt.year()"
            revenue_bucket:
              sql: "CASE WHEN revenue > 1000 THEN 'high' ELSE 'low' END"
            constant_col:
              literal: "v1"
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform


@Registry.transform("computed")
class ComputedColumnsTransform(BaseTransform):
    """Add computed columns to the DataFrame."""

    def validate_config(self) -> None:
        if "columns" not in self.config or not self.config["columns"]:
            raise TransformConfigError("computed requires a non-empty 'columns' dict")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        columns: dict[str, Any] = self.config["columns"]

        for col_name, definition in columns.items():
            if isinstance(definition, dict):
                if "sql" in definition:
                    # SQL expression via context
                    ctx = pl.SQLContext({"data": df})
                    result = ctx.execute(
                        f"SELECT *, {definition['sql']} AS {col_name} FROM data"
                    ).collect()
                    df = result
                elif "literal" in definition:
                    df = df.with_columns(pl.lit(definition["literal"]).alias(col_name))
                else:
                    raise TransformConfigError(
                        f"computed column '{col_name}': dict must have 'sql' or 'literal' key"
                    )
            elif isinstance(definition, str):
                # Polars expression string (eval is sandboxed to pl namespace)
                try:
                    expr = eval(definition, {"__builtins__": {}}, {
                        "col": pl.col,
                        "lit": pl.lit,
                        "when": pl.when,
                        "concat_str": pl.concat_str,
                        "pl": pl,
                    })
                    df = df.with_columns(expr.alias(col_name))
                except Exception as exc:
                    raise TransformConfigError(
                        f"computed column '{col_name}': invalid expression '{definition}': {exc}"
                    ) from exc
            else:
                df = df.with_columns(pl.lit(definition).alias(col_name))

        return df
