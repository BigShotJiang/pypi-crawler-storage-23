"""Flatten nested JSON / struct columns into flat columns.

YAML::

    transforms:
      - type: flatten
        config:
          separator: "."          # default "."
          columns: ["address"]    # optional — flatten only these; omit for all
          max_depth: 2            # optional — limit nesting depth
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform


def _flatten_struct_columns(
    df: pl.DataFrame,
    separator: str = ".",
    columns: list[str] | None = None,
    prefix: str = "",
    max_depth: int | None = None,
    _current_depth: int = 0,
) -> pl.DataFrame:
    """Recursively unnest struct columns."""
    if max_depth is not None and _current_depth >= max_depth:
        return df

    struct_cols = [
        c for c in df.columns
        if df[c].dtype == pl.Struct
        and (columns is None or c in (columns if _current_depth == 0 else df.columns))
    ]

    if not struct_cols:
        return df

    for col in struct_cols:
        unnested = df[col].struct.unnest()
        # Prefix child columns with parent name
        rename_map = {child: f"{col}{separator}{child}" for child in unnested.columns}
        unnested = unnested.rename(rename_map)
        df = df.drop(col).hstack(unnested)

    # Recurse for nested structs
    return _flatten_struct_columns(
        df, separator, columns=None, prefix=prefix,
        max_depth=max_depth, _current_depth=_current_depth + 1,
    )


@Registry.transform("flatten")
class FlattenTransform(BaseTransform):
    """Flatten nested struct / JSON columns into a flat table."""

    def validate_config(self) -> None:
        pass  # All options are optional

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        separator = self.config.get("separator", ".")
        columns = self.config.get("columns")
        max_depth = self.config.get("max_depth")
        return _flatten_struct_columns(df, separator, columns, max_depth=max_depth)
