"""Deduplication transform.

YAML example::

    transforms:
      - type: deduplicate
        config:
          subset: [id]          # columns to check for duplicates
          keep: last            # first | last
          maintain_order: true
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform

logger = get_logger(__name__)


@Registry.transform("deduplicate")
class DeduplicateTransform(BaseTransform):
    """Remove duplicate rows based on a subset of columns."""

    def validate_config(self) -> None:
        pass  # All options are optional

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        subset = self.config.get("subset")
        keep = self.config.get("keep", "first")
        maintain_order = self.config.get("maintain_order", True)

        if subset:
            missing = [c for c in subset if c not in df.columns]
            if missing:
                raise TransformConfigError(
                    f"deduplicate: columns not found: {missing}"
                )

        before = len(df)
        df = df.unique(subset=subset, keep=keep, maintain_order=maintain_order)
        after = len(df)

        if before != after:
            logger.info("deduplicate.applied", removed=before - after, remaining=after)

        return df
