"""Row filtering transform.

YAML examples::

    transforms:
      # Simple column-based filters
      - type: filter_rows
        config:
          conditions:
            - column: age
              operator: ">="
              value: 18
            - column: status
              operator: "in"
              value: [active, pending]
            - column: email
              operator: "is_not_null"
          logic: "and"     # and | or

      # SQL WHERE expression (advanced)
      - type: filter_rows
        config:
          sql_where: "age >= 18 AND status IN ('active', 'pending')"
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform

_OPERATORS = {
    "==": lambda c, v: pl.col(c) == v,
    "!=": lambda c, v: pl.col(c) != v,
    ">": lambda c, v: pl.col(c) > v,
    ">=": lambda c, v: pl.col(c) >= v,
    "<": lambda c, v: pl.col(c) < v,
    "<=": lambda c, v: pl.col(c) <= v,
    "in": lambda c, v: pl.col(c).is_in(v if isinstance(v, list) else [v]),
    "not_in": lambda c, v: pl.col(c).is_in(v if isinstance(v, list) else [v]).not_(),
    "is_null": lambda c, v: pl.col(c).is_null(),
    "is_not_null": lambda c, v: pl.col(c).is_not_null(),
    "contains": lambda c, v: pl.col(c).cast(pl.Utf8).str.contains(str(v)),
    "starts_with": lambda c, v: pl.col(c).cast(pl.Utf8).str.starts_with(str(v)),
    "ends_with": lambda c, v: pl.col(c).cast(pl.Utf8).str.ends_with(str(v)),
}


@Registry.transform("filter_rows")
class FilterRowsTransform(BaseTransform):
    """Filter rows by column conditions or a SQL WHERE clause."""

    def validate_config(self) -> None:
        has_conditions = "conditions" in self.config
        has_sql = "sql_where" in self.config
        if not has_conditions and not has_sql:
            raise TransformConfigError(
                "filter_rows requires either 'conditions' or 'sql_where'"
            )

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        # SQL-based filter (uses Polars SQL context)
        if "sql_where" in self.config:
            ctx = pl.SQLContext({"data": df})
            return ctx.execute(
                f"SELECT * FROM data WHERE {self.config['sql_where']}"
            ).collect()

        # Condition-based filter
        conditions: list[dict] = self.config["conditions"]
        logic = self.config.get("logic", "and").lower()

        exprs: list[pl.Expr] = []
        for cond in conditions:
            col = cond["column"]
            op = cond.get("operator", "==")
            val = cond.get("value")

            if op not in _OPERATORS:
                raise TransformConfigError(
                    f"filter_rows: unknown operator '{op}'. "
                    f"Supported: {sorted(_OPERATORS.keys())}"
                )
            exprs.append(_OPERATORS[op](col, val))

        if not exprs:
            return df

        combined = exprs[0]
        for expr in exprs[1:]:
            combined = combined & expr if logic == "and" else combined | expr

        return df.filter(combined)
