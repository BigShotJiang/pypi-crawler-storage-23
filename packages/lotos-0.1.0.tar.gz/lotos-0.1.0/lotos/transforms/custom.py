"""Custom Python function transform — run user-defined code.

YAML example::

    transforms:
      - type: custom
        config:
          module: "my_transforms.clean_addresses"
          # OR inline (small snippets only):
          code: |
            def transform(df):
                return df.with_columns(
                    pl.col("email").str.to_lowercase().alias("email")
                )
"""

from __future__ import annotations

import importlib
from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.exceptions import TransformConfigError, TransformError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform

logger = get_logger(__name__)


@Registry.transform("custom")
class CustomTransform(BaseTransform):
    """Run a user-defined Python function on the DataFrame."""

    def validate_config(self) -> None:
        has_module = "module" in self.config
        has_code = "code" in self.config
        if not has_module and not has_code:
            raise TransformConfigError(
                "custom transform requires either 'module' (dotted path) or 'code' (inline)"
            )

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        if "module" in self.config:
            return self._apply_module(df)
        return self._apply_inline(df)

    def _apply_module(self, df: pl.DataFrame) -> pl.DataFrame:
        """Import a module path like 'my_package.transforms.clean' and call transform(df)."""
        module_path: str = self.config["module"]
        parts = module_path.rsplit(".", 1)
        if len(parts) == 2:
            mod_name, func_name = parts
        else:
            mod_name = parts[0]
            func_name = "transform"

        try:
            mod = importlib.import_module(mod_name)
            func = getattr(mod, func_name)
        except (ImportError, AttributeError) as exc:
            raise TransformError(
                f"Could not import '{module_path}': {exc}"
            ) from exc

        result = func(df)
        if not isinstance(result, pl.DataFrame):
            raise TransformError(
                f"Custom function '{module_path}' must return a polars.DataFrame, "
                f"got {type(result).__name__}"
            )
        return result

    def _apply_inline(self, df: pl.DataFrame) -> pl.DataFrame:
        """Execute inline code that defines a `transform(df)` function."""
        code: str = self.config["code"]
        namespace: dict[str, Any] = {"pl": pl, "polars": pl}

        try:
            exec(code, namespace)  # noqa: S102
        except Exception as exc:
            raise TransformError(f"Inline code compilation failed: {exc}") from exc

        func = namespace.get("transform")
        if func is None:
            raise TransformConfigError(
                "Inline code must define a function named 'transform(df)'"
            )

        result = func(df)
        if not isinstance(result, pl.DataFrame):
            raise TransformError(
                f"Inline transform must return polars.DataFrame, got {type(result).__name__}"
            )
        return result
