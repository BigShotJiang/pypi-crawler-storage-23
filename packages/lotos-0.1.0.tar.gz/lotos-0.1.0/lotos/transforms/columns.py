"""Column operations — select, rename, drop, reorder.

YAML examples::

    transforms:
      - type: select_columns
        config:
          columns: [id, name, email]

      - type: rename_columns
        config:
          mapping:
            old_name: new_name
            created_at: creation_date

      - type: drop_columns
        config:
          columns: [internal_id, _metadata]
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform


@Registry.transform("select_columns")
class SelectColumnsTransform(BaseTransform):
    """Keep only the specified columns (in order)."""

    def validate_config(self) -> None:
        if "columns" not in self.config or not self.config["columns"]:
            raise TransformConfigError("select_columns requires a non-empty 'columns' list")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        cols = self.config["columns"]
        missing = [c for c in cols if c not in df.columns]
        if missing:
            raise TransformConfigError(
                f"select_columns: columns not found in data: {missing}. "
                f"Available: {df.columns}"
            )
        return df.select(cols)


@Registry.transform("rename_columns")
class RenameColumnsTransform(BaseTransform):
    """Rename columns using a mapping dict."""

    def validate_config(self) -> None:
        if "mapping" not in self.config or not self.config["mapping"]:
            raise TransformConfigError("rename_columns requires a non-empty 'mapping' dict")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        mapping: dict[str, str] = self.config["mapping"]
        # Only rename columns that exist (ignore missing — allows reuse across datasets)
        valid = {k: v for k, v in mapping.items() if k in df.columns}
        return df.rename(valid)


@Registry.transform("drop_columns")
class DropColumnsTransform(BaseTransform):
    """Drop specified columns."""

    def validate_config(self) -> None:
        if "columns" not in self.config or not self.config["columns"]:
            raise TransformConfigError("drop_columns requires a non-empty 'columns' list")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        to_drop = [c for c in self.config["columns"] if c in df.columns]
        return df.drop(to_drop)
