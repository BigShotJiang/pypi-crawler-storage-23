"""Abstract base class for all transforms (Layer 2).

Every transform is a pure function:  DataFrame in → DataFrame out.
Transforms are composable and declared in pipeline YAML.

Register with ``@Registry.transform("name")``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import polars as pl

from lotos.config.logging import get_logger

logger = get_logger(__name__)


class BaseTransform(ABC):
    """Interface that every transform step implements.

    Parameters
    ----------
    config : dict
        Transform-specific settings from the pipeline YAML.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.validate_config()

    @abstractmethod
    def validate_config(self) -> None:
        """Raise ``TransformConfigError`` if config is invalid."""

    @abstractmethod
    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        """Apply the transform and return a new DataFrame.

        Must be a pure function — never mutate the input DataFrame.
        """

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} config={self.config}>"
