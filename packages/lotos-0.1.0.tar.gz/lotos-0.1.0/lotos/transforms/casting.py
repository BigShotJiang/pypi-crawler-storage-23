"""Type casting transform.

YAML example::

    transforms:
      - type: cast_types
        config:
          mapping:
            id: int64
            price: float64
            created_at: datetime
            is_active: boolean
            name: string
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.core.exceptions import TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform

# Mapping from friendly type names → Polars types
_TYPE_MAP: dict[str, pl.DataType] = {
    "string": pl.Utf8,
    "str": pl.Utf8,
    "utf8": pl.Utf8,
    "int8": pl.Int8,
    "int16": pl.Int16,
    "int32": pl.Int32,
    "int64": pl.Int64,
    "int": pl.Int64,
    "uint8": pl.UInt8,
    "uint16": pl.UInt16,
    "uint32": pl.UInt32,
    "uint64": pl.UInt64,
    "float32": pl.Float32,
    "float64": pl.Float64,
    "float": pl.Float64,
    "boolean": pl.Boolean,
    "bool": pl.Boolean,
    "date": pl.Date,
    "datetime": pl.Datetime,
    "time": pl.Time,
    "duration": pl.Duration,
}


@Registry.transform("cast_types")
class CastTypesTransform(BaseTransform):
    """Cast columns to specified data types."""

    def validate_config(self) -> None:
        if "mapping" not in self.config or not self.config["mapping"]:
            raise TransformConfigError("cast_types requires a non-empty 'mapping' dict")
        for col, dtype_name in self.config["mapping"].items():
            if dtype_name.lower() not in _TYPE_MAP:
                raise TransformConfigError(
                    f"cast_types: unknown type '{dtype_name}' for column '{col}'. "
                    f"Supported: {sorted(_TYPE_MAP.keys())}"
                )

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        mapping: dict[str, str] = self.config["mapping"]
        exprs = []
        for col, dtype_name in mapping.items():
            if col not in df.columns:
                continue
            target_type = _TYPE_MAP[dtype_name.lower()]
            exprs.append(pl.col(col).cast(target_type, strict=False))
        return df.with_columns(exprs) if exprs else df
