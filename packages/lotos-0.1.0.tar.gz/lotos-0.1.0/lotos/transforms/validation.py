"""Schema validation transform — reject rows that don't match the expected schema.

YAML example::

    transforms:
      - type: validate_schema
        config:
          columns:
            id:
              type: int64
              nullable: false
            email:
              type: string
              nullable: false
              pattern: "^[^@]+@[^@]+$"   # optional regex
            age:
              type: int64
              nullable: true
              min: 0
              max: 150
          on_fail: reject    # reject | warn | fail
          reject_column: "_validation_errors"   # optional
"""

from __future__ import annotations

from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.exceptions import SchemaValidationError, TransformConfigError
from lotos.core.registry import Registry
from lotos.transforms.base import BaseTransform

logger = get_logger(__name__)


@Registry.transform("validate_schema")
class ValidateSchemaTransform(BaseTransform):
    """Validate data against an expected schema and handle bad rows."""

    def validate_config(self) -> None:
        if "columns" not in self.config or not self.config["columns"]:
            raise TransformConfigError("validate_schema requires a non-empty 'columns' dict")

    def apply(self, df: pl.DataFrame) -> pl.DataFrame:
        col_specs: dict[str, dict] = self.config["columns"]
        on_fail = self.config.get("on_fail", "reject")
        reject_col = self.config.get("reject_column", "_validation_errors")

        error_exprs: list[pl.Expr] = []

        for col_name, rules in col_specs.items():
            if col_name not in df.columns:
                if not rules.get("nullable", True):
                    raise SchemaValidationError(
                        f"Required column '{col_name}' is missing from data"
                    )
                continue

            # Null check
            if not rules.get("nullable", True):
                error_exprs.append(
                    pl.when(pl.col(col_name).is_null())
                    .then(pl.lit(f"{col_name}:null"))
                    .otherwise(pl.lit(""))
                )

            # Range checks  (min / max)
            if "min" in rules:
                error_exprs.append(
                    pl.when(pl.col(col_name) < rules["min"])
                    .then(pl.lit(f"{col_name}:below_min"))
                    .otherwise(pl.lit(""))
                )
            if "max" in rules:
                error_exprs.append(
                    pl.when(pl.col(col_name) > rules["max"])
                    .then(pl.lit(f"{col_name}:above_max"))
                    .otherwise(pl.lit(""))
                )

            # Regex pattern check (string columns)
            if "pattern" in rules:
                error_exprs.append(
                    pl.when(
                        pl.col(col_name).cast(pl.Utf8).str.contains(rules["pattern"]).not_()
                    )
                    .then(pl.lit(f"{col_name}:pattern_mismatch"))
                    .otherwise(pl.lit(""))
                )

        if not error_exprs:
            return df

        # Combine all error messages into a single column
        combined = error_exprs[0]
        for expr in error_exprs[1:]:
            combined = combined + pl.lit("|") + expr

        df = df.with_columns(combined.alias(reject_col))

        # Clean up empty separators
        df = df.with_columns(
            pl.col(reject_col)
            .str.replace_all(r"\|{2,}", "|")
            .str.strip_chars("|")
            .alias(reject_col)
        )

        total = len(df)
        bad_mask = pl.col(reject_col) != ""
        bad_count = df.filter(bad_mask).height

        if bad_count > 0:
            logger.warning(
                "schema.validation.failures",
                bad_rows=bad_count,
                total_rows=total,
                sample_errors=df.filter(bad_mask)[reject_col].head(5).to_list(),
            )

        match on_fail:
            case "reject":
                df = df.filter(bad_mask.not_()).drop(reject_col)
            case "warn":
                pass  # Keep all rows, keep the error column
            case "fail":
                if bad_count > 0:
                    raise SchemaValidationError(
                        f"{bad_count}/{total} rows failed validation"
                    )
                df = df.drop(reject_col)
            case _:
                raise TransformConfigError(f"Unknown on_fail mode: {on_fail}")

        return df
