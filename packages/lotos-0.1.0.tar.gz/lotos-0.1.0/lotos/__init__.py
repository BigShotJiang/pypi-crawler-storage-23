"""Lotos — Self-hosted data ingestion framework."""

__version__ = "0.1.0"
__app_name__ = "lotos"
