"""Lotos CLI — terminal interface for the data ingestion framework.

Usage::

    lotos run pipelines/my_pipeline.yaml
    lotos run pipelines/my_pipeline.yaml --output results.parquet
    lotos validate pipelines/my_pipeline.yaml
    lotos inspect pipelines/my_pipeline.yaml
    lotos list connectors
    lotos list transforms
    lotos init my_pipeline
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="lotos",
    help="Lotos — self-hosted data ingestion framework.",
    add_completion=False,
    no_args_is_help=False,
    rich_markup_mode="rich",
    invoke_without_command=True,
)

console = Console()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Lotos — self-hosted data ingestion framework."""
    if ctx.invoked_subcommand is None:
        from lotos.banner import print_banner
        print_banner(console)
        raise typer.Exit()


# ═══════════════════════════════════════════════════════════════════════════
# lotos run
# ═══════════════════════════════════════════════════════════════════════════

@app.command()
def run(
    pipeline_path: str = typer.Argument(..., help="Path to pipeline YAML file"),
    output: Optional[str] = typer.Option(
        None, "--output", "-o",
        help="Save result to file (csv/json/parquet)",
    ),
    output_format: str = typer.Option(
        "parquet", "--format", "-f",
        help="Output format: csv, json, parquet",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Extract + transform only, don't write to sink",
    ),
    log_level: str = typer.Option(
        "INFO", "--log-level", "-l",
        help="Log level: DEBUG, INFO, WARNING, ERROR",
    ),
    log_format: str = typer.Option(
        "console", "--log-format",
        help="Log format: console, json",
    ),
) -> None:
    """Run a data ingestion pipeline."""
    _configure_logging(log_level, log_format)

    from lotos.core.pipeline import load_pipeline, run_pipeline, validate_pipeline

    console.print(f"\n[bold cyan]Lotos[/] — Loading pipeline: {pipeline_path}\n")

    try:
        pipeline = load_pipeline(pipeline_path)
    except Exception as exc:
        console.print(f"[bold red]Error:[/] {exc}")
        raise typer.Exit(1)

    # Pre-flight validation
    warnings = validate_pipeline(pipeline)
    if warnings:
        for w in warnings:
            console.print(f"[yellow]⚠ {w}[/]")
        raise typer.Exit(1)

    console.print(f"  Pipeline: [bold]{pipeline.pipeline.name}[/]")
    console.print(f"  Source:   {pipeline.source.connector}")
    console.print(f"  Transforms: {len(pipeline.transforms)}")
    if pipeline.sink:
        console.print(f"  Sink:     {pipeline.sink.connector}")
    console.print()

    try:
        result = run_pipeline(
            pipeline,
            dry_run=dry_run,
            output_path=output,
            output_format=output_format,
        )
    except Exception as exc:
        console.print(f"\n[bold red]Pipeline failed:[/] {exc}")
        raise typer.Exit(1)

    # Result summary
    table = Table(title="Run Result", show_header=False, border_style="dim")
    table.add_column("Key", style="dim")
    table.add_column("Value", style="bold")
    table.add_row("Status", f"[green]{result.status.value}[/]" if result.status.value == "success" else f"[red]{result.status.value}[/]")
    table.add_row("Rows extracted", str(result.rows_extracted))
    table.add_row("Rows transformed", str(result.rows_transformed))
    table.add_row("Rows loaded", str(result.rows_loaded))
    if result.duration_seconds is not None:
        table.add_row("Duration", f"{result.duration_seconds:.2f}s")
    if result.watermark_value is not None:
        table.add_row("Watermark", str(result.watermark_value))
    if output:
        table.add_row("Output", output)
    console.print(table)
    console.print()


# ═══════════════════════════════════════════════════════════════════════════
# lotos validate
# ═══════════════════════════════════════════════════════════════════════════

@app.command()
def validate(
    pipeline_path: str = typer.Argument(..., help="Path to pipeline YAML file"),
) -> None:
    """Validate a pipeline YAML file without running it."""
    _configure_logging("WARNING", "console")

    from lotos.core.pipeline import load_pipeline, validate_pipeline

    try:
        pipeline = load_pipeline(pipeline_path)
    except Exception as exc:
        console.print(f"[bold red]Validation failed:[/] {exc}")
        raise typer.Exit(1)

    warnings = validate_pipeline(pipeline)

    if warnings:
        for w in warnings:
            console.print(f"[yellow]⚠ {w}[/]")
        raise typer.Exit(1)

    console.print(f"[bold green]✓[/] Pipeline [bold]{pipeline.pipeline.name}[/] is valid")


# ═══════════════════════════════════════════════════════════════════════════
# lotos inspect
# ═══════════════════════════════════════════════════════════════════════════

@app.command()
def inspect(
    pipeline_path: str = typer.Argument(..., help="Path to pipeline YAML file"),
) -> None:
    """Show detailed information about a pipeline."""
    _configure_logging("WARNING", "console")

    from lotos.core.pipeline import load_pipeline

    try:
        pipeline = load_pipeline(pipeline_path)
    except Exception as exc:
        console.print(f"[bold red]Error:[/] {exc}")
        raise typer.Exit(1)

    p = pipeline.pipeline
    console.print(Panel(
        f"[bold]{p.name}[/]\n"
        f"[dim]{p.description}[/]\n"
        f"Version: {p.version}  Tags: {', '.join(p.tags) or '—'}",
        title="Pipeline",
        border_style="cyan",
    ))

    table = Table(title="Source", show_header=True, border_style="green")
    table.add_column("Connector", style="bold")
    table.add_column("Config Keys")
    table.add_row(
        pipeline.source.connector,
        ", ".join(pipeline.source.config.keys()),
    )
    console.print(table)

    if pipeline.transforms:
        table = Table(title="Transforms", show_header=True, border_style="magenta")
        table.add_column("#", style="dim")
        table.add_column("Type", style="bold")
        table.add_column("Config")
        for i, t in enumerate(pipeline.transforms, 1):
            table.add_row(str(i), t.type, str(t.config) if t.config else "—")
        console.print(table)

    if pipeline.sink:
        table = Table(title="Sink", show_header=True, border_style="yellow")
        table.add_column("Connector", style="bold")
        table.add_column("Write Mode")
        table.add_column("Config Keys")
        table.add_row(
            pipeline.sink.connector,
            pipeline.sink.write_mode.value,
            ", ".join(pipeline.sink.config.keys()),
        )
        console.print(table)

    if pipeline.watermark:
        console.print(f"\n[cyan]Watermark:[/] field={pipeline.watermark.field}")

    if pipeline.schedule:
        s = pipeline.schedule
        console.print(f"\n[cyan]Schedule:[/] cron={s.cron}  retries={s.max_retries}  timeout={s.timeout_seconds}s")


# ═══════════════════════════════════════════════════════════════════════════
# lotos list
# ═══════════════════════════════════════════════════════════════════════════

list_app = typer.Typer(help="List available plugins.")
app.add_typer(list_app, name="list")


@list_app.command("connectors")
def list_connectors() -> None:
    """List all registered source connectors."""
    _configure_logging("WARNING", "console")
    from lotos.core.registry import Registry, _auto_discover
    _auto_discover()

    table = Table(title="Source Connectors", border_style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Class")
    table.add_column("Doc")

    for name, cls in sorted(Registry.list_connectors().items()):
        doc = (cls.__doc__ or "").split("\n")[0].strip()
        table.add_row(name, cls.__name__, doc)
    console.print(table)


@list_app.command("transforms")
def list_transforms() -> None:
    """List all registered transforms."""
    _configure_logging("WARNING", "console")
    from lotos.core.registry import Registry, _auto_discover
    _auto_discover()

    table = Table(title="Transforms", border_style="magenta")
    table.add_column("Name", style="bold")
    table.add_column("Class")
    table.add_column("Doc")

    for name, cls in sorted(Registry.list_transforms().items()):
        doc = (cls.__doc__ or "").split("\n")[0].strip()
        table.add_row(name, cls.__name__, doc)
    console.print(table)


@list_app.command("sinks")
def list_sinks() -> None:
    """List all registered destination sinks."""
    _configure_logging("WARNING", "console")
    from lotos.core.registry import Registry, _auto_discover
    _auto_discover()

    table = Table(title="Destination Sinks", border_style="yellow")
    table.add_column("Name", style="bold")
    table.add_column("Class")
    table.add_column("Doc")

    for name, cls in sorted(Registry.list_sinks().items()):
        doc = (cls.__doc__ or "").split("\n")[0].strip()
        table.add_row(name, cls.__name__, doc)
    console.print(table)


@list_app.command("all")
def list_all() -> None:
    """List all registered plugins."""
    list_connectors()
    console.print()
    list_transforms()
    console.print()
    list_sinks()


# ═══════════════════════════════════════════════════════════════════════════
# lotos init
# ═══════════════════════════════════════════════════════════════════════════

@app.command()
def init(
    name: str = typer.Argument("my_pipeline", help="Pipeline name"),
    directory: str = typer.Option("pipelines", "--dir", "-d", help="Output directory"),
    source: str = typer.Option("sql", "--source", "-s", help="Source connector type"),
) -> None:
    """Generate a pipeline YAML template."""
    from lotos.core.registry import _auto_discover
    _auto_discover()

    dir_path = Path(directory)
    dir_path.mkdir(parents=True, exist_ok=True)
    file_path = dir_path / f"{name}.yaml"

    template = _generate_template(name, source)
    file_path.write_text(template, encoding="utf-8")

    console.print(f"[bold green]✓[/] Created pipeline template: {file_path}")


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _configure_logging(level: str, fmt: str) -> None:
    """Override settings and initialize logging."""
    from lotos.config.settings import settings
    settings.log_level = level
    settings.log_format = fmt
    from lotos.config.logging import setup_logging
    setup_logging()


def _generate_template(name: str, source: str) -> str:
    """Generate a YAML pipeline template."""

    templates = {
        "sql": """\
# ─────────────────────────────────────────────────────────────────
# Lotos Pipeline — {name}
# Generated template — edit to match your use case
# ─────────────────────────────────────────────────────────────────

pipeline:
  name: {name}
  description: "Extract data from SQL database"
  version: "1.0"
  tags: [sql, generated]

source:
  connector: sql
  config:
    connection_string: "${{SECRET:db_connection_string}}"
    # Option 1: Use a query
    query: "SELECT * FROM my_table"
    # Option 2: Use table name (uncomment below, comment query above)
    # table: my_table
    # schema: public
    # columns: [id, name, created_at]
    # limit: 1000  # useful for testing

transforms:
  # - type: select_columns
  #   config:
  #     columns: [id, name, email, created_at]

  # - type: rename_columns
  #   config:
  #     mapping:
  #       created_at: creation_date

  # - type: cast_types
  #   config:
  #     mapping:
  #       id: int64
  #       creation_date: datetime

  # - type: deduplicate
  #   config:
  #     subset: [id]
  #     keep: last

  # - type: filter_rows
  #   config:
  #     conditions:
  #       - column: id
  #         operator: ">"
  #         value: 0

# Uncomment when Layer 4 sinks are configured:
# sink:
#   connector: file
#   config:
#     path: "output/{name}.parquet"
#     format: parquet
#   write_mode: overwrite

# watermark:
#   field: updated_at
#   initial_value: "2020-01-01"

# schedule:
#   cron: "0 */6 * * *"
#   max_retries: 3
#   timeout_seconds: 3600
""",
        "rest_api": """\
# ─────────────────────────────────────────────────────────────────
# Lotos Pipeline — {name}
# Generated template — edit to match your use case
# ─────────────────────────────────────────────────────────────────

pipeline:
  name: {name}
  description: "Extract data from REST API"
  version: "1.0"
  tags: [api, generated]

source:
  connector: rest_api
  config:
    url: "https://api.example.com/v2/data"
    method: GET
    headers:
      Accept: application/json
    auth:
      type: bearer
      token: "${{SECRET:api_token}}"
    pagination:
      type: offset
      limit_param: limit
      offset_param: offset
      page_size: 100
    response_path: "data.results"
    timeout: 30
    rate_limit_per_second: 5

transforms: []
""",
        "file": """\
# ─────────────────────────────────────────────────────────────────
# Lotos Pipeline — {name}
# Generated template — edit to match your use case
# ─────────────────────────────────────────────────────────────────

pipeline:
  name: {name}
  description: "Extract data from files"
  version: "1.0"
  tags: [file, generated]

source:
  connector: file
  config:
    path: "data/input/my_data.csv"
    format: csv
    csv_separator: ","
    csv_has_header: true

    # Azure Blob example:
    # path: "az://my-container/path/to/file.parquet"
    # format: parquet
    # azure_storage_connection_string: "${{SECRET:az_conn_str}}"

transforms: []
""",
    }

    template = templates.get(source, templates["sql"])
    return template.format(name=name)


if __name__ == "__main__":
    app()
