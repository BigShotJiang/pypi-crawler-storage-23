"""Abstract base class for all destination sinks (Layer 4).

Sinks are the mirror of connectors — they write DataFrames to
a target system. Each sink supports multiple write modes.

Register with ``@Registry.sink("name")``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.models import WriteMode

logger = get_logger(__name__)


class BaseSink(ABC):
    """Interface that every destination sink implements.

    Parameters
    ----------
    config : dict
        Sink-specific configuration (already secret-resolved).
    write_mode : WriteMode
        How to write: append, overwrite, or upsert.
    upsert_key : list[str]
        Columns to use as the merge key for upserts.
    batch_size : int
        Number of rows per write batch.
    """

    def __init__(
        self,
        config: dict[str, Any],
        write_mode: WriteMode = WriteMode.APPEND,
        upsert_key: list[str] | None = None,
        batch_size: int = 10_000,
    ) -> None:
        self.config = config
        self.write_mode = write_mode
        self.upsert_key = upsert_key or []
        self.batch_size = batch_size
        self.validate_config()

    @abstractmethod
    def validate_config(self) -> None:
        """Raise ``SinkError`` if required config keys are missing."""

    @abstractmethod
    def write(self, df: pl.DataFrame) -> int:
        """Write the DataFrame to the destination.

        Returns the number of rows written.

        Implementations should:
        - Handle write mode (append / overwrite / upsert)
        - Handle batching for large datasets
        - Auto-create schema if configured
        """

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} mode={self.write_mode.value}>"
