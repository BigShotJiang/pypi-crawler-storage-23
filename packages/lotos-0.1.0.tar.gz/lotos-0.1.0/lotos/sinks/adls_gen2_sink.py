"""Azure Data Lake Storage Gen2 sink — write DataFrames to Azure Storage.

Supports CSV, JSON, and Parquet formats.  The ``hierarchical_namespace``
configuration option controls which Azure Storage API is used:

* ``hierarchical_namespace: true``  → Data Lake Storage (DFS) API
* ``hierarchical_namespace: false`` → Blob Storage API  (default)

YAML examples::

    # Blob Storage (HNS disabled — default)
    sink:
      connector: adls_gen2
      config:
        account_name: "mystorageaccount"
        container_name: "mycontainer"
        directory_path: "data/output"
        file_name: "results"
        format: parquet
        hierarchical_namespace: false
        account_key: "${SECRET:adls_account_key}"
      write_mode: overwrite

    # Data Lake Storage Gen2 (HNS enabled)
    sink:
      connector: adls_gen2
      config:
        account_name: "mydatalake"
        container_name: "myfilesystem"
        directory_path: "raw/events"
        file_name: "events"
        format: parquet
        hierarchical_namespace: true
        account_key: "${SECRET:adls_account_key}"
      write_mode: overwrite
"""

from __future__ import annotations

import io
from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.exceptions import SinkError, SinkWriteError
from lotos.core.models import WriteMode
from lotos.core.registry import Registry
from lotos.sinks.base import BaseSink

logger = get_logger(__name__)


@Registry.sink("adls_gen2")
class ADLSGen2Sink(BaseSink):
    """Write DataFrames to Azure Data Lake Storage Gen2 / Blob Storage."""

    def validate_config(self) -> None:
        required = ["account_name", "container_name"]
        missing = [k for k in required if k not in self.config]
        if missing:
            raise SinkError(f"adls_gen2 sink requires config keys: {', '.join(missing)}")

    # ── public API ───────────────────────────────────────────────────

    def write(self, df: pl.DataFrame) -> int:
        account_name: str = self.config["account_name"]
        container_name: str = self.config["container_name"]
        directory_path: str = self.config.get("directory_path", "")
        file_name: str = self.config.get("file_name", "output")
        fmt: str = self.config.get("format", "parquet")
        account_key: str | None = self.config.get("account_key")
        connection_string: str | None = self.config.get("connection_string")
        use_hns: bool = self.config.get("hierarchical_namespace", False)

        # Build the full file name with extension
        extension = fmt if fmt in ("csv", "json", "parquet") else "parquet"
        full_file_name = f"{file_name}.{extension}"
        blob_path = f"{directory_path}/{full_file_name}" if directory_path else full_file_name

        # Serialize the DataFrame
        data = self._serialize(df, fmt)

        if use_hns:
            logger.info(
                "adls_gen2_sink.mode",
                api="Data Lake (DFS)",
                account=account_name,
            )
            self._write_datalake(
                data, df, account_name, container_name, directory_path,
                full_file_name, fmt, account_key, connection_string,
            )
        else:
            logger.info(
                "adls_gen2_sink.mode",
                api="Blob Storage",
                account=account_name,
            )
            self._write_blob(
                data, df, account_name, container_name, blob_path,
                fmt, account_key, connection_string,
            )

        logger.info(
            "adls_gen2_sink.write",
            account=account_name,
            container=container_name,
            path=blob_path,
            format=fmt,
            rows=len(df),
        )
        return len(df)

    # ── serialisation ────────────────────────────────────────────────

    def _serialize(self, df: pl.DataFrame, fmt: str) -> bytes:
        buf = io.BytesIO()
        match fmt:
            case "csv":
                df.write_csv(buf)
            case "json":
                df.write_json(buf)
            case "parquet":
                df.write_parquet(buf)
            case _:
                raise SinkWriteError(f"Unsupported write format: {fmt}")
        buf.seek(0)
        return buf.read()

    # ── Data Lake (DFS) path ─────────────────────────────────────────

    def _write_datalake(
        self, data: bytes, df: pl.DataFrame,
        account_name: str, container_name: str, directory_path: str,
        full_file_name: str, fmt: str,
        account_key: str | None, connection_string: str | None,
    ) -> None:
        try:
            from azure.storage.filedatalake import DataLakeServiceClient
        except ImportError as exc:
            raise SinkError(
                "azure-storage-file-datalake is required for the adls_gen2 sink. "
                "Install: pip install lotos[azure]"
            ) from exc

        service_client = self._get_datalake_client(account_name, account_key, connection_string)
        fs_client = service_client.get_file_system_client(file_system=container_name)

        if directory_path:
            dir_client = fs_client.get_directory_client(directory_path)
            try:
                dir_client.create_directory()
            except Exception:
                pass
            file_client = dir_client.get_file_client(full_file_name)
        else:
            file_client = fs_client.get_file_client(full_file_name)

        # Handle append for CSV
        if self.write_mode == WriteMode.APPEND and fmt == "csv":
            existing = self._read_existing_datalake(file_client)
            if existing is not None:
                merged = pl.concat(
                    [pl.read_csv(io.BytesIO(existing)), df],
                    how="diagonal_relaxed",
                )
                data = self._serialize(merged, "csv")

        file_client.upload_data(data, overwrite=(self.write_mode == WriteMode.OVERWRITE))

    # ── Blob Storage fallback ────────────────────────────────────────

    def _write_blob(
        self, data: bytes, df: pl.DataFrame,
        account_name: str, container_name: str, blob_path: str,
        fmt: str, account_key: str | None, connection_string: str | None,
    ) -> None:
        try:
            from azure.storage.blob import BlobServiceClient
        except ImportError as exc:
            raise SinkError(
                "azure-storage-blob is required for the adls_gen2 sink (blob fallback). "
                "Install: pip install lotos[azure]"
            ) from exc

        blob_service = self._get_blob_client(account_name, account_key, connection_string)
        container_client = blob_service.get_container_client(container_name)

        # Ensure container exists
        try:
            container_client.get_container_properties()
        except Exception:
            try:
                container_client.create_container()
            except Exception:
                pass

        blob_client = container_client.get_blob_client(blob_path)

        # Handle append for CSV
        if self.write_mode == WriteMode.APPEND and fmt == "csv":
            existing = self._read_existing_blob(blob_client)
            if existing is not None:
                merged = pl.concat(
                    [pl.read_csv(io.BytesIO(existing)), df],
                    how="diagonal_relaxed",
                )
                data = self._serialize(merged, "csv")

        blob_client.upload_blob(data, overwrite=(self.write_mode == WriteMode.OVERWRITE))

    # ── client builders ──────────────────────────────────────────────

    @staticmethod
    def _get_datalake_client(account_name: str, account_key: str | None, connection_string: str | None):
        from azure.storage.filedatalake import DataLakeServiceClient

        if connection_string:
            return DataLakeServiceClient.from_connection_string(connection_string)
        if account_key:
            url = f"https://{account_name}.dfs.core.windows.net"
            return DataLakeServiceClient(account_url=url, credential=account_key)

        from azure.identity import DefaultAzureCredential
        url = f"https://{account_name}.dfs.core.windows.net"
        return DataLakeServiceClient(account_url=url, credential=DefaultAzureCredential())

    @staticmethod
    def _get_blob_client(account_name: str, account_key: str | None, connection_string: str | None):
        from azure.storage.blob import BlobServiceClient

        if connection_string:
            return BlobServiceClient.from_connection_string(connection_string)
        if account_key:
            url = f"https://{account_name}.blob.core.windows.net"
            return BlobServiceClient(account_url=url, credential=account_key)

        from azure.identity import DefaultAzureCredential
        url = f"https://{account_name}.blob.core.windows.net"
        return BlobServiceClient(account_url=url, credential=DefaultAzureCredential())

    # ── helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _read_existing_datalake(file_client) -> bytes | None:
        try:
            return file_client.download_file().readall()
        except Exception:
            return None

    @staticmethod
    def _read_existing_blob(blob_client) -> bytes | None:
        try:
            return blob_client.download_blob().readall()
        except Exception:
            return None
