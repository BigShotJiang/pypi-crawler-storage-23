"""File-based sink — write DataFrames to local or Azure Blob Storage files.

Supports CSV, JSON, and Parquet formats.

YAML example::

    sink:
      connector: file
      config:
        path: "/data/output/results.parquet"
        format: parquet
      write_mode: overwrite

    # Azure Blob
    sink:
      connector: file
      config:
        path: "az://output-container/results/data.parquet"
        format: parquet
        azure_storage_connection_string: "${SECRET:az_conn_str}"
      write_mode: overwrite
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import polars as pl

from lotos.config.logging import get_logger
from lotos.core.exceptions import SinkError, SinkWriteError
from lotos.core.models import WriteMode
from lotos.core.registry import Registry
from lotos.sinks.base import BaseSink

logger = get_logger(__name__)


@Registry.sink("file")
class FileSink(BaseSink):
    """Write DataFrames to local or Azure Blob Storage files."""

    def validate_config(self) -> None:
        if "path" not in self.config:
            raise SinkError("file sink requires 'path' in config")

    def write(self, df: pl.DataFrame) -> int:
        path_str: str = self.config["path"]
        fmt = self.config.get("format", self._detect_format(path_str))

        if path_str.startswith("az://") or path_str.startswith("abfss://"):
            return self._write_azure(df, path_str, fmt)

        return self._write_local(df, path_str, fmt)

    def _detect_format(self, path: str) -> str:
        suffix = Path(path).suffix.lstrip(".").lower()
        return {"csv": "csv", "json": "json", "parquet": "parquet"}.get(suffix, "parquet")

    def _write_local(self, df: pl.DataFrame, path: str, fmt: str) -> int:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)

        if self.write_mode == WriteMode.APPEND and p.exists() and fmt == "csv":
            # Append to existing CSV
            existing = pl.read_csv(str(p))
            df = pl.concat([existing, df], how="diagonal_relaxed")

        logger.info("file_sink.write", path=path, format=fmt, rows=len(df))
        match fmt:
            case "csv":
                df.write_csv(str(p))
            case "json":
                df.write_json(str(p))
            case "parquet":
                df.write_parquet(str(p))
            case _:
                raise SinkWriteError(f"Unsupported write format: {fmt}")

        return len(df)

    def _write_azure(self, df: pl.DataFrame, path: str, fmt: str) -> int:
        try:
            from azure.storage.blob import BlobServiceClient
        except ImportError as exc:
            raise SinkError(
                "azure-storage-blob required for az:// paths. "
                "Install: pip install lotos[azure]"
            ) from exc

        conn_str = self.config.get("azure_storage_connection_string")
        if not conn_str:
            raise SinkError("Azure Blob sink requires 'azure_storage_connection_string'")

        clean = path.replace("az://", "").replace("abfss://", "")
        parts = clean.split("/", 1)
        container = parts[0]
        blob_path = parts[1] if len(parts) > 1 else "output.parquet"

        buf = io.BytesIO()
        match fmt:
            case "csv":
                df.write_csv(buf)
            case "json":
                df.write_json(buf)
            case "parquet":
                df.write_parquet(buf)
            case _:
                raise SinkWriteError(f"Unsupported write format: {fmt}")

        buf.seek(0)
        blob_service = BlobServiceClient.from_connection_string(conn_str)
        blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
        blob_client.upload_blob(buf, overwrite=(self.write_mode == WriteMode.OVERWRITE))

        logger.info("file_sink.azure.write", container=container, blob=blob_path, rows=len(df))
        return len(df)
