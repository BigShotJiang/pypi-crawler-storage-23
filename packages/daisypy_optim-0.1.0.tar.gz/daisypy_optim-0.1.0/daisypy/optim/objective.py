'''Objective functors'''
# pylint: disable=unused-import
from daisypy.optim.scalar_objective import ScalarObjective
from daisypy.optim.aggregate_objective import AggregateObjective
