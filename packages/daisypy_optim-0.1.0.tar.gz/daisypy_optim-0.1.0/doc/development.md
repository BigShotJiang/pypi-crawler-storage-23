# Development

## Tests

    pip install pytest
    pytest


## Coverage

    pip install coverage
    coverage run
    coverage report
