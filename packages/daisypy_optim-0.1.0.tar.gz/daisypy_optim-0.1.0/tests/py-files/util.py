# Utilities used by template.py to illustrate how to include more python files when running daisy
def negate(x):
    '''negate input'''
    return -x 
