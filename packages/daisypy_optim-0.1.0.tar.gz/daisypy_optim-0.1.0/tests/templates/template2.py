from util import negate

def linear(x):
    return {a} * negate(x) + {b}
