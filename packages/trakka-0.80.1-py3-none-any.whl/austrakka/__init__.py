# NOTE: do not change the name of this variable or the quote type,
# doing so will break github actions.
__version__ = "0.80.1"
__prog_name__ = "Trakka"
