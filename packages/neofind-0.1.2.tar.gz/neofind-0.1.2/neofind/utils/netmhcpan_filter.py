"""
Utility functions for filtering and extracting data from NetMHCpan output files.
"""

import pandas as pd
from typing import List, Dict, Tuple, Optional, Literal
import logging

logger = logging.getLogger(__name__)


def parse_netmhcpan_header(filepath: str) -> Tuple[Dict[str, Dict[str, int]], List[str]]:
    """
    Parse the two-line header of NetMHCpan output file.
    
    Args:
        filepath: Path to NetMHCpan output file (.xls)
    
    Returns:
        Tuple containing:
        - hla_columns: Dictionary mapping HLA type to column indices for each field
        - all_columns: List of column names for the entire DataFrame
    
    Raises:
        ValueError: If header format is invalid
    """
    with open(filepath, 'r') as f:
        line1 = f.readline().rstrip('\n').split('\t')
        line2 = f.readline().rstrip('\n').split('\t')
    
    if len(line1) != len(line2):
        raise ValueError(f"Header lines have different lengths: {len(line1)} vs {len(line2)}")
    
    hla_columns = {}
    current_hla = None
    field_order = ['core', 'icore', 'EL-score', 'EL_Rank', 'BA-score', 'BA_Rank']
    
    for i, (hla_cell, col_name) in enumerate(zip(line1, line2)):
        if hla_cell and hla_cell.startswith('HLA-'):
            current_hla = hla_cell
            hla_columns[current_hla] = {'core': i}
            field_idx = 0  # core is already set
        elif current_hla and col_name in field_order:
            if col_name not in hla_columns[current_hla]:
                hla_columns[current_hla][col_name] = i
            else:
                # Handle duplicate column names (shouldn't happen)
                pass
    
    # Verify each HLA has all required fields
    for hla, fields in hla_columns.items():
        missing = [f for f in field_order if f not in fields]
        if missing:
            raise ValueError(f"HLA {hla} missing fields: {missing}")
    
    # Build column names for DataFrame
    all_columns = []
    for i in range(len(line2)):
        if i in [idx for fields in hla_columns.values() for idx in fields.values()]:
            # This column is part of an HLA group
            # Find which HLA and field it belongs to
            for hla, fields in hla_columns.items():
                for field, idx in fields.items():
                    if idx == i:
                        all_columns.append(f"{hla}_{field}")
                        break
                else:
                    continue
                break
        else:
            # Regular column
            all_columns.append(line2[i] if line2[i] else f"Unnamed_{i}")
    
    return hla_columns, all_columns


def parse_fasta_ids(fasta_file: str) -> Dict[str, Dict[str, str]]:
    """
    Parse FASTA file to create mapping from simplified IDs to full IDs and extract gene info.
    
    Args:
        fasta_file: Path to input FASTA file
        
    Returns:
        Dictionary mapping simplified ID to dict containing:
        - 'full_id': Complete FASTA header (without '>')
        - 'gene_name': Gene name extracted from header
        - 'transcript_id': Transcript ID extracted from header
        
    Raises:
        FileNotFoundError: If FASTA file doesn't exist
        ValueError: If FASTA format is invalid
    """
    id_mapping = {}
    
    try:
        with open(fasta_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                    
                if line.startswith('>'):
                    # FASTA header line
                    full_id = line[1:]  # Remove '>' prefix
                    
                    # Generate simplified ID: replace spaces and dots with underscores, take first 15 chars
                    simplified_id = full_id.split('|')[0]  # Take part before first '|'
                    simplified_id = simplified_id.replace(' ', '_').replace('.', '_')
                    simplified_id = simplified_id[:15]
                    
                    # Extract gene name and transcript ID from full ID
                    # Expected format: chr1 g.47395874A_gt_C|CYP4A11|ENST00000371904|index_22
                    parts = full_id.split('|')
                    gene_name = parts[1] if len(parts) > 1 else ''
                    transcript_id = parts[2] if len(parts) > 2 else ''
                    
                    id_mapping[simplified_id] = {
                        'full_id': full_id,
                        'gene_name': gene_name,
                        'transcript_id': transcript_id
                    }
    except FileNotFoundError:
        raise FileNotFoundError(f"FASTA file not found: {fasta_file}")
    
    if not id_mapping:
        raise ValueError(f"No valid FASTA headers found in {fasta_file}")
    
    logger.info(f"Parsed {len(id_mapping)} IDs from FASTA file")
    return id_mapping


def extract_gene_info_from_full_id(full_id: str) -> Tuple[str, str]:
    """
    Extract gene name and transcript ID from full FASTA ID.
    
    Args:
        full_id: Complete FASTA header (without '>')
        
    Returns:
        Tuple of (gene_name, transcript_id)
    """
    parts = full_id.split('|')
    gene_name = parts[1] if len(parts) > 1 else ''
    transcript_id = parts[2] if len(parts) > 2 else ''
    return gene_name, transcript_id


def extract_netmhcpan_binders(
    input_file: str,
    output_fasta: str,
    rank_type: str = "BA_Rank",
    sb_threshold: float = 0.5,
    wb_threshold: float = 2.0,
    include_wb: bool = True,
    peptide_id_col: str = "ID",
    peptide_col: str = "Peptide",
    input_fasta: Optional[str] = None,
    output_bed: Optional[str] = None
) -> Tuple[int, int]:
    """
    Extract strong and weak binding peptides from NetMHCpan output and write to FASTA.
    
    Args:
        input_file: Path to NetMHCpan output file (.xls)
        output_fasta: Path to output FASTA file
        rank_type: Which rank to use for classification ("EL_Rank" or "BA_Rank")
        sb_threshold: Threshold for strong binder (default: <0.5)
        wb_threshold: Threshold for weak binder (default: <2.0)
        include_wb: Whether to include weak binders in output
        peptide_id_col: Column name for peptide ID
        peptide_col: Column name for full peptide sequence
        input_fasta: Optional path to original FASTA file used for NetMHCpan prediction.
                    If provided, will map simplified IDs to full IDs and extract gene info.
        output_bed: Optional path to output BED file with binding information.
                   BED columns: HLA_type, core_peptide, BAlevel, rank, genename, transID
    
    Returns:
        Tuple of (strong_binders_count, weak_binders_count)
    
    Raises:
        FileNotFoundError: If input file doesn't exist
        ValueError: If required columns are missing or data format is invalid
    """
    # Parse header to get column mapping
    hla_columns, all_columns = parse_netmhcpan_header(input_file)
    
    # Read data (skip first two header lines)
    try:
        df = pd.read_csv(input_file, sep='\t', skiprows=2, header=None, names=all_columns)
    except FileNotFoundError:
        raise FileNotFoundError(f"Input file not found: {input_file}")
    
    # Verify required base columns exist
    required_cols = [peptide_id_col, peptide_col]
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"Required column '{col}' not found in input file")
    
    # Parse input FASTA file for ID mapping if provided
    id_mapping = {}
    if input_fasta:
        try:
            id_mapping = parse_fasta_ids(input_fasta)
            logger.info(f"Loaded ID mapping from {input_fasta}")
        except Exception as e:
            logger.warning(f"Failed to parse FASTA file {input_fasta}: {e}")
            logger.warning("Will use simplified IDs from NetMHCpan output")
    
    strong_binders = []
    weak_binders = []
    
    # Process each row
    for row_idx, row in df.iterrows():
        peptide_id = str(row[peptide_id_col]) if pd.notna(row[peptide_id_col]) else f"peptide_{row_idx}"
        full_peptide = str(row[peptide_col]) if pd.notna(row[peptide_col]) else ""
        
        # Get full ID, gene name and transcript ID from mapping
        full_id = peptide_id
        gene_name = ''
        transcript_id = ''
        
        if peptide_id in id_mapping:
            mapping = id_mapping[peptide_id]
            full_id = mapping['full_id']
            gene_name = mapping['gene_name']
            transcript_id = mapping['transcript_id']
        elif input_fasta:
            logger.debug(f"No mapping found for simplified ID: {peptide_id}")
        
        # Check each HLA type
        for hla in hla_columns.keys():
            core_col = f"{hla}_core"
            rank_col = f"{hla}_{rank_type}"
            
            if core_col not in df.columns or rank_col not in df.columns:
                logger.warning(f"Missing columns for HLA {hla}: {core_col} or {rank_col}")
                continue
            
            core_seq = str(row[core_col]) if pd.notna(row[core_col]) else ""
            rank_val = row[rank_col]
            
            # Skip if core sequence is empty or rank is NaN
            if not core_seq or pd.isna(rank_val):
                continue
            
            try:
                rank_float = float(rank_val)
            except (ValueError, TypeError):
                logger.warning(f"Invalid rank value '{rank_val}' for {peptide_id}, HLA {hla}")
                continue
            
            # Classify based on rank
            if rank_float < sb_threshold:
                binder_type = "SB"
                strong_binders.append({
                    'id': peptide_id,
                    'full_id': full_id,
                    'gene_name': gene_name,
                    'transcript_id': transcript_id,
                    'hla': hla,
                    'core': core_seq,
                    'full_peptide': full_peptide,
                    'rank': rank_float,
                    'rank_type': rank_type,
                    'type': binder_type
                })
            elif include_wb and rank_float < wb_threshold:
                binder_type = "WB"
                weak_binders.append({
                    'id': peptide_id,
                    'full_id': full_id,
                    'gene_name': gene_name,
                    'transcript_id': transcript_id,
                    'hla': hla,
                    'core': core_seq,
                    'full_peptide': full_peptide,
                    'rank': rank_float,
                    'rank_type': rank_type,
                    'type': binder_type
                })
    
    # Write to FASTA file
    with open(output_fasta, 'w') as f:
        # Write strong binders first
        for binder in strong_binders:
            # Use full ID if available, otherwise use simplified ID
            fasta_id = binder.get('full_id', binder['id'])
            # Replace pipes in full ID to avoid confusion with header separators
            fasta_id = fasta_id.replace('|', '_')
            header = f">{fasta_id}|{binder['hla']}|{binder['type']}|rank_{binder['rank']:.4f}"
            f.write(f"{header}\n")
            f.write(f"{binder['core']}\n")
        
        # Write weak binders
        for binder in weak_binders:
            # Use full ID if available, otherwise use simplified ID
            fasta_id = binder.get('full_id', binder['id'])
            # Replace pipes in full ID to avoid confusion with header separators
            fasta_id = fasta_id.replace('|', '_')
            header = f">{fasta_id}|{binder['hla']}|{binder['type']}|rank_{binder['rank']:.4f}"
            f.write(f"{header}\n")
            f.write(f"{binder['core']}\n")
    
    # Write BED file if requested
    if output_bed:
        with open(output_bed, 'w') as f:
            # Write header (optional for BED, but we'll include it)
            f.write("#HLA_type\tcore_peptide\tBAlevel\trank\tgenename\ttransID\n")
            # Write strong binders first
            for binder in strong_binders:
                bed_line = f"{binder['hla']}\t{binder['core']}\t{binder['type']}\t{binder['rank']:.4f}\t{binder['gene_name']}\t{binder['transcript_id']}\n"
                f.write(bed_line)
            # Write weak binders
            for binder in weak_binders:
                bed_line = f"{binder['hla']}\t{binder['core']}\t{binder['type']}\t{binder['rank']:.4f}\t{binder['gene_name']}\t{binder['transcript_id']}\n"
                f.write(bed_line)
        logger.info(f"BED file written to {output_bed}")
    
    # Also write a summary CSV if needed (optional)
    summary_file = output_fasta.replace('.fasta', '').replace('.fa', '') + '_summary.csv'
    summary_data = strong_binders + weak_binders
    if summary_data:
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_csv(summary_file, index=False)
        logger.info(f"Summary written to {summary_file}")
    
    logger.info(f"Found {len(strong_binders)} strong binders and {len(weak_binders)} weak binders")
    return len(strong_binders), len(weak_binders)


def filter_netmhcpan_results(
    input_file: str,
    output_csv: Optional[str] = None,
    output_fasta: Optional[str] = None,
    rank_type: str = "BA_Rank",
    sb_threshold: float = 0.5,
    wb_threshold: float = 2.0,
    include_wb: bool = True,
    input_fasta: Optional[str] = None,
    output_bed: Optional[str] = None
) -> pd.DataFrame:
    """
    Filter NetMHCpan results and return DataFrame with classified binders.
    
    Args:
        input_file: Path to NetMHCpan output file (.xls)
        output_csv: Optional path to output CSV file
        output_fasta: Optional path to output FASTA file
        rank_type: Which rank to use for classification
        sb_threshold: Threshold for strong binder
        wb_threshold: Threshold for weak binder
        include_wb: Whether to include weak binders
    
    Returns:
        DataFrame with filtered results
    """
    # Parse header to get column mapping
    hla_columns, all_columns = parse_netmhcpan_header(input_file)
    
    # Read data
    df = pd.read_csv(input_file, sep='\t', skiprows=2, header=None, names=all_columns)
    
    # Prepare list to store results
    results = []
    
    # Map column names to indices
    col_to_idx = {name: i for i, name in enumerate(all_columns)}
    
    # Process each HLA type
    for hla, fields in hla_columns.items():
        core_col = f"{hla}_core"
        rank_col = f"{hla}_{rank_type}"
        
        if core_col not in col_to_idx or rank_col not in col_to_idx:
            continue
        
        # Add columns to DataFrame for this HLA type
        df[f"{hla}_core_seq"] = df.iloc[:, col_to_idx[core_col]]
        df[f"{hla}_{rank_type}_val"] = df.iloc[:, col_to_idx[rank_col]]
        
        # Classify binders
        sb_mask = df[f"{hla}_{rank_type}_val"] < sb_threshold
        wb_mask = (df[f"{hla}_{rank_type}_val"] >= sb_threshold) & (df[f"{hla}_{rank_type}_val"] < wb_threshold)
        
        # Extract strong binders
        for idx in df[sb_mask].index:
            row = df.loc[idx]
            results.append({
                'Pos': row['Pos'] if 'Pos' in df.columns else idx,
                'Peptide': row['Peptide'] if 'Peptide' in df.columns else '',
                'ID': row['ID'] if 'ID' in df.columns else f"peptide_{idx}",
                'HLA': hla,
                'Core': row[f"{hla}_core_seq"],
                'Rank_Type': rank_type,
                'Rank_Value': row[f"{hla}_{rank_type}_val"],
                'Binder_Type': 'SB',
                'Full_Peptide': row['Peptide'] if 'Peptide' in df.columns else ''
            })
        
        # Extract weak binders if included
        if include_wb:
            for idx in df[wb_mask].index:
                row = df.loc[idx]
                results.append({
                    'Pos': row['Pos'] if 'Pos' in df.columns else idx,
                    'Peptide': row['Peptide'] if 'Peptide' in df.columns else '',
                    'ID': row['ID'] if 'ID' in df.columns else f"peptide_{idx}",
                    'HLA': hla,
                    'Core': row[f"{hla}_core_seq"],
                    'Rank_Type': rank_type,
                    'Rank_Value': row[f"{hla}_{rank_type}_val"],
                    'Binder_Type': 'WB',
                    'Full_Peptide': row['Peptide'] if 'Peptide' in df.columns else ''
            })
    
    # Create results DataFrame
    results_df = pd.DataFrame(results)
    
    # Write outputs if specified
    if output_csv and not results_df.empty:
        results_df.to_csv(output_csv, index=False)
    
    if output_fasta and not results_df.empty:
        with open(output_fasta, 'w') as f:
            for _, row in results_df.iterrows():
                header = f">{row['ID']}|{row['HLA']}|{row['Binder_Type']}|rank_{row['Rank_Value']:.4f}"
                f.write(f"{header}\n")
                f.write(f"{row['Core']}\n")
    
    return results_df