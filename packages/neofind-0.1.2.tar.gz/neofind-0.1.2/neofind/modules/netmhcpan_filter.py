"""
Module for filtering NetMHCpan output files and extracting binding peptides.
"""

import time
import typer
from typing import Optional
from typing_extensions import Annotated
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils.netmhcpan_filter import extract_netmhcpan_binders, filter_netmhcpan_results

app = typer.Typer()


@app.command()
def filter_netmhcpan(
    input: Annotated[str, typer.Option("--input", "-i", help="Path to input NetMHCpan output file (.xls).")],
    fasta: Annotated[str, typer.Option("--fasta", "-f", help="Path to output FASTA file with binding peptides.")],
    rank_type: Annotated[str, typer.Option(
        "--rank-type", help="Which rank to use for classification (EL_Rank or BA_Rank).")] = "BA_Rank",
    sb_threshold: Annotated[float, typer.Option(
        "--sb-threshold", help="Threshold for strong binder (default: <0.5).")] = 0.5,
    wb_threshold: Annotated[float, typer.Option(
        "--wb-threshold", help="Threshold for weak binder (default: <2.0).")] = 2.0,
    include_wb: Annotated[bool, typer.Option(
        "--include-wb/--no-wb", help="Whether to include weak binders in output.")] = True,
    output_csv: Annotated[Optional[str], typer.Option(
        "--output-csv", "-c", help="Path to optional output CSV file with detailed results.")] = None,
    input_fasta: Annotated[Optional[str], typer.Option(
        "--input-fasta", help="Path to original FASTA file used for NetMHCpan prediction. If provided, will map simplified IDs to full IDs and extract gene info.")] = None,
    output_bed: Annotated[Optional[str], typer.Option(
        "--output-bed", help="Path to output BED file with binding information. BED columns: HLA_type, core_peptide, BAlevel, rank, genename, transID.")] = None,
):
    """
    Extract strong and weak binding peptides from NetMHCpan output and write to FASTA.
    
    This command processes NetMHCpan output files and extracts peptide cores that are
    classified as strong binders (SB: rank < 0.5) or weak binders (WB: rank < 2.0).
    
    The FASTA file headers contain:
    >ID|HLA_type|Binder_Type|rank_value
    
    If --input-fasta is provided, the original FASTA file will be used to map simplified
    IDs to full IDs containing gene names and transcript IDs. The FASTA headers will
    contain the full IDs (with pipes replaced by underscores).
    
    Example with full ID:
    >chr1 g.47395874A_gt_C_CYP4A11_ENST00000371904_index_22|HLA-A33:03|SB|rank_0.1234
    RIPIPRLVL
    
    The input file should be a tab-separated NetMHCpan output with two header lines:
    Line 1: HLA type names
    Line 2: Column names (Pos, Peptide, ID, core, icore, EL-score, EL_Rank, BA-score, BA_Rank, ...)
    """
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        try:
            progress.add_task(description="Processing NetMHCpan results...", total=None)
            start = time.time()
            
            # Use the filter function to get results DataFrame
            results_df = filter_netmhcpan_results(
                input_file=input,
                output_csv=output_csv,
                output_fasta=fasta,
                rank_type=rank_type,
                sb_threshold=sb_threshold,
                wb_threshold=wb_threshold,
                include_wb=include_wb,
                input_fasta=input_fasta,
                output_bed=output_bed
            )
            
            end = time.time()
            elapsed = end - start
            
            # Count binders by type
            if not results_df.empty:
                sb_count = len(results_df[results_df['Binder_Type'] == 'SB'])
                wb_count = len(results_df[results_df['Binder_Type'] == 'WB'])
            else:
                sb_count = wb_count = 0
            
            time_cost = f"{int(elapsed // 3600)}h{int((elapsed % 3600) // 60)}m{elapsed % 60:.2f}s"
            
            progress.add_task(
                description=f"Found {sb_count} strong and {wb_count} weak binders", 
                total=None
            )
            print(f"Successfully processed NetMHCpan results from {input}")
            print(f"Found {sb_count} strong binders (rank < {sb_threshold}) and {wb_count} weak binders (rank < {wb_threshold})")
            print(f"FASTA file written to {fasta}")
            if input_fasta:
                print(f"Used full IDs from {input_fasta}")
            if output_csv:
                print(f"Detailed results CSV written to {output_csv}")
            if output_bed:
                print(f"BED file written to {output_bed}")
            print(f"Time cost: {time_cost}")
            
        except Exception as e:
            print(f"Error: {e}")
            progress.add_task(description="Processing failed", total=None)
            raise typer.Exit(code=1)


@app.command()
def extract_binders(
    input: Annotated[str, typer.Option("--input", "-i", help="Path to input NetMHCpan output file (.xls).")],
    fasta: Annotated[str, typer.Option("--fasta", "-f", help="Path to output FASTA file with binding peptides.")],
    rank_type: Annotated[str, typer.Option(
        "--rank-type", help="Which rank to use for classification (EL_Rank or BA_Rank).")] = "BA_Rank",
    sb_threshold: Annotated[float, typer.Option(
        "--sb-threshold", help="Threshold for strong binder (default: <0.5).")] = 0.5,
    wb_threshold: Annotated[float, typer.Option(
        "--wb-threshold", help="Threshold for weak binder (default: <2.0).")] = 2.0,
    include_wb: Annotated[bool, typer.Option(
        "--include-wb/--no-wb", help="Whether to include weak binders in output.")] = True,
    input_fasta: Annotated[Optional[str], typer.Option(
        "--input-fasta", help="Path to original FASTA file used for NetMHCpan prediction. If provided, will map simplified IDs to full IDs and extract gene info.")] = None,
    output_bed: Annotated[Optional[str], typer.Option(
        "--output-bed", help="Path to output BED file with binding information. BED columns: HLA_type, core_peptide, BAlevel, rank, genename, transID.")] = None,
):
    """
    Extract binding peptides from NetMHCpan output using the simpler extractor function.
    
    This is a simpler interface that directly writes FASTA output without intermediate CSV.
    If --input-fasta is provided, the original FASTA file will be used to map simplified
    IDs to full IDs containing gene names and transcript IDs. The FASTA headers will
    contain the full IDs, and a BED file can be generated with --output-bed option.
    """
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        try:
            progress.add_task(description="Extracting NetMHCpan binders...", total=None)
            start = time.time()
            
            sb_count, wb_count = extract_netmhcpan_binders(
                input_file=input,
                output_fasta=fasta,
                rank_type=rank_type,
                sb_threshold=sb_threshold,
                wb_threshold=wb_threshold,
                include_wb=include_wb,
                input_fasta=input_fasta,
                output_bed=output_bed
            )
            
            end = time.time()
            elapsed = end - start
            time_cost = f"{int(elapsed // 3600)}h{int((elapsed % 3600) // 60)}m{elapsed % 60:.2f}s"
            
            progress.add_task(
                description=f"Extracted {sb_count} strong and {wb_count} weak binders", 
                total=None
            )
            print(f"Successfully extracted binders from {input}")
            print(f"Found {sb_count} strong binders (rank < {sb_threshold}) and {wb_count} weak binders (rank < {wb_threshold})")
            print(f"FASTA file written to {fasta}")
            if input_fasta:
                print(f"Used full IDs from {input_fasta}")
            if output_bed:
                print(f"BED file written to {output_bed}")
            print(f"Time cost: {time_cost}")
            
        except Exception as e:
            print(f"Error: {e}")
            progress.add_task(description="Extraction failed", total=None)
            raise typer.Exit(code=1)