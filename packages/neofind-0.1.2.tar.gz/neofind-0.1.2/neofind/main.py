import typer
from .modules.vcf2fasta import vcf2fasta
from .modules.isovar_filter import filter_isovar
from .modules.netmhcpan_filter import filter_netmhcpan, extract_binders

app = typer.Typer(add_completion=False)

@app.callback()
def callback():
    """
    neofind: A pipeline for discovering and analyzing neoantigens using RNA, Ribo, and WES/WGS sequence data.
    
    neofind is designed to identify and analyze neoantigens from sequencing data, including:
    - Processing VCF files with RNA BAM files to generate mutant protein sequences
    - Filtering isovar results to extract mutant protein sequences
    - Analyzing NetMHCpan output to extract strong and weak binding peptides
    - Analyzing neoantigen candidates for personalized cancer immunotherapy
    """

app.command(name="vcf2fasta")(vcf2fasta)
app.command(name="filter")(filter_isovar)
app.command(name="netmhcpan-filter")(filter_netmhcpan)
app.command(name="netmhcpan-extract")(extract_binders)


if __name__ == "__main__":
    app()