"""Communication Patterns - Audience adaptation and technical translation"""
from .audience_adapter import AudienceAdapter
from .technical_translator import TechnicalTranslator

__all__ = [
    "AudienceAdapter",
    "TechnicalTranslator",
]
