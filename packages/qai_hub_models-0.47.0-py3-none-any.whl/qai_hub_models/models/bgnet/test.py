# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------


import numpy as np
import pytest

from qai_hub_models.models.bgnet.app import BGNetApp
from qai_hub_models.models.bgnet.demo import main as demo_main
from qai_hub_models.models.bgnet.model import (
    INPUT_IMAGE_ADDRESS,
    MODEL_ASSET_VERSION,
    MODEL_ID,
    BGNet,
)
from qai_hub_models.utils.asset_loaders import CachedWebModelAsset, load_image
from qai_hub_models.utils.testing import assert_most_same, skip_clone_repo_check

OUTPUT_IMAGE_ADDRESS = CachedWebModelAsset.from_asset_store(
    MODEL_ID, MODEL_ASSET_VERSION, "test_output_image.png"
)


# Verify that the output from Torch is as expected.
@skip_clone_repo_check
def test_task() -> None:
    app = BGNetApp(BGNet.from_pretrained())
    original_image = load_image(INPUT_IMAGE_ADDRESS)
    output_image = app.segment_image(original_image)[0]
    output_image_oracle = load_image(OUTPUT_IMAGE_ADDRESS)

    assert_most_same(
        np.asarray(output_image), np.asarray(output_image_oracle), diff_tol=0.01
    )


@pytest.mark.trace
@skip_clone_repo_check
def test_trace() -> None:
    app = BGNetApp(BGNet.from_pretrained().convert_to_torchscript())
    original_image = load_image(INPUT_IMAGE_ADDRESS)
    output_image = app.segment_image(original_image)[0]
    output_image_oracle = load_image(OUTPUT_IMAGE_ADDRESS)

    assert_most_same(
        np.asarray(output_image), np.asarray(output_image_oracle), diff_tol=0.01
    )


@skip_clone_repo_check
def test_demo() -> None:
    demo_main(is_test=True)
