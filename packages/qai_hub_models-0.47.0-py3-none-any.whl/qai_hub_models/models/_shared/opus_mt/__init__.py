# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------

from .demo import opus_mt_demo  # noqa: F401
from .model import OpusMT, OpusMTDecoder, OpusMTEncoder  # noqa: F401
