from setuptools import setup, find_packages

setup(
    name="normans-chat",
    version="1.6.6",
    description="A WhatsApp-style terminal chat app",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "colorama",
    ],
    entry_points={
        "console_scripts": [
            "normans-chat=termchat.client:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
