"""Kernel Fusion module for sagellm-compression (Task3.4).

This module provides a kernel-fusion framework including:
- KernelFusion: Abstract base class for all fusion operators.
- AttentionFusion: Fuses QKV projection + scaled-dot-product attention + output proj.
- MLPFusion: Fuses two linear layers with an activation (standard or gated).
- StubKernelFusion: Deterministic CPU-only stub for CI / unit tests.
- FusionConfig, AttentionFusionConfig, MLPFusionConfig, GatedMLPFusionConfig.
- FusionType enum and FusionResult dataclass.
"""

from __future__ import annotations

from sagellm_compression.fusion.attention_fusion import AttentionFusion
from sagellm_compression.fusion.base import KernelFusion
from sagellm_compression.fusion.configs import (
    AttentionFusionConfig,
    FusionConfig,
    FusionResult,
    FusionType,
    GatedMLPFusionConfig,
    MLPFusionConfig,
)
from sagellm_compression.fusion.mlp_fusion import MLPFusion
from sagellm_compression.fusion.stub_fusion import StubKernelFusion

__all__ = [
    # Abstract base
    "KernelFusion",
    # Implementations
    "AttentionFusion",
    "MLPFusion",
    "StubKernelFusion",
    # Configs
    "FusionConfig",
    "FusionType",
    "AttentionFusionConfig",
    "MLPFusionConfig",
    "GatedMLPFusionConfig",
    # Result
    "FusionResult",
]
