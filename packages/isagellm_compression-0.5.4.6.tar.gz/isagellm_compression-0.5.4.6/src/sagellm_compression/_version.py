"""Version information for sagellm-compression."""

__version__ = "0.5.4.6"
