"""CLI for folderbot configuration and management."""

import argparse
import os
import shutil
import sys
from getpass import getpass
from pathlib import Path

import tomllib

import tomlkit

from . import __version__
from .config import (
    Config,
    DEFAULT_EXCLUDE_PATTERNS,
    DEFAULT_INCLUDE_PATTERNS,
    find_config_path,
)


def get_config_path() -> Path:
    """Get the path to the config file (.folderbot/config.toml in PWD)."""
    return find_config_path()


def load_config_toml() -> dict:
    """Load raw config from TOML file."""
    config_path = get_config_path()
    if config_path.exists():
        with open(config_path, "rb") as f:
            try:
                return tomllib.load(f)
            except tomllib.TOMLDecodeError:
                return {}
    return {}


def save_config_toml(data: dict, config_path: Path | None = None) -> None:
    """Save config to TOML file."""
    if config_path is None:
        config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        f.write(tomlkit.dumps(data))


def cmd_init(args: argparse.Namespace) -> int:
    """Interactive setup wizard. Creates .folderbot/config.toml in PWD."""
    print(f"Folderbot Setup v{__version__}")
    print("=" * 40)
    print()

    # Determine config location: local .folderbot/config.toml in PWD
    cwd = Path.cwd()
    local_config_path = cwd / ".folderbot" / "config.toml"

    # Load existing local config if present, otherwise start fresh
    if local_config_path.exists():
        with open(local_config_path, "rb") as f:
            try:
                config_data = tomllib.load(f)
            except tomllib.TOMLDecodeError:
                config_data = {}
    else:
        config_data = {}

    print(f"  Config will be saved to: {local_config_path}")
    print(f"  Root folder: {cwd}")
    print()

    # Telegram token
    print("Step 1: Telegram Bot Token")
    print("  Get this from @BotFather: https://t.me/BotFather")
    current = config_data.get("telegram_token", "")
    if current and current != "YOUR_TELEGRAM_BOT_TOKEN":
        print(f"  Current: {current[:10]}...{current[-4:]}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            token = getpass("  Enter token: ").strip()
            if token:
                config_data["telegram_token"] = token
    else:
        token = getpass("  Enter token: ").strip()
        if not token:
            print("  Error: Telegram token is required")
            return 1
        config_data["telegram_token"] = token
    print()

    # LLM API key
    print("Step 2: LLM API Key")
    print("  For Anthropic: console.anthropic.com")
    print("  For OpenAI: platform.openai.com/api-keys")
    print("  Or set the provider's env var and press Enter to skip.")
    current = config_data.get("api_key") or config_data.get("anthropic_api_key", "")
    if current and current not in ("YOUR_ANTHROPIC_API_KEY", "YOUR_API_KEY"):
        print(f"  Current: {current[:10]}...{current[-4:]}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            key = getpass("  Enter API key: ").strip()
            if key:
                config_data["api_key"] = key
    else:
        key = getpass("  Enter API key (or press Enter to skip): ").strip()
        if key:
            config_data["api_key"] = key
    print()

    # Allowed user IDs
    print("Step 3: Allowed Telegram User IDs")
    print("  Get your ID from @userinfobot: https://t.me/userinfobot")
    current_ids = config_data.get("allowed_user_ids", [])
    if current_ids and current_ids != [123456789]:
        print(f"  Current: {current_ids}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            ids_str = input("  Enter user IDs (comma-separated): ").strip()
            if ids_str:
                config_data["allowed_user_ids"] = [
                    int(x.strip()) for x in ids_str.split(",")
                ]
    else:
        ids_str = input("  Enter your user ID: ").strip()
        if not ids_str:
            print("  Error: At least one user ID is required")
            return 1
        config_data["allowed_user_ids"] = [int(x.strip()) for x in ids_str.split(",")]
    print()

    # User name
    print("Step 4: Your Name")
    print("  Used in the AI assistant's responses")
    current_name = config_data.get("user_name", "")
    if current_name:
        print(f"  Current: {current_name}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            name = input("  Enter your name: ").strip()
            if name:
                config_data["user_name"] = name
    else:
        name = input("  Enter your name: ").strip()
        if name:
            config_data["user_name"] = name
    print()

    # Google Custom Search (optional)
    print("Step 5: Google Custom Search (optional)")
    print("  For web search. Get API key from console.cloud.google.com")
    current_gkey = config_data.get("google_api_key", "")
    if current_gkey:
        print(f"  Current API key: {current_gkey[:6]}...{current_gkey[-4:]}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            gkey = input("  Enter Google API key (or press Enter to skip): ").strip()
            if gkey:
                config_data["google_api_key"] = gkey
    else:
        gkey = input("  Enter Google API key (or press Enter to skip): ").strip()
        if gkey:
            config_data["google_api_key"] = gkey

    current_gcx = config_data.get("google_cx", "")
    if current_gcx:
        print(f"  Current CX: {current_gcx}")
        change = input("  Change? [y/N]: ").strip().lower()
        if change == "y":
            gcx = input("  Enter Google CX (or press Enter to skip): ").strip()
            if gcx:
                config_data["google_cx"] = gcx
    else:
        gcx = input(
            "  Enter Google Custom Search CX (or press Enter to skip): "
        ).strip()
        if gcx:
            config_data["google_cx"] = gcx
    print()

    # root_folder is implicit for local config — remove it if present
    config_data.pop("root_folder", None)

    # Save config to local .folderbot/config.toml
    save_config_toml(config_data, local_config_path)
    print(f"Configuration saved to {local_config_path}")
    print()
    print("Run 'folderbot run' to start the bot!")
    return 0


def cmd_config_show(args: argparse.Namespace) -> int:
    """Show current configuration."""
    config_path = get_config_path()

    print(f"Config file: {config_path}")
    print(f"Exists: {config_path.exists()}")
    print()

    if not config_path.exists():
        print("No configuration file found. Run 'folderbot init' to create one.")
        return 1

    config_data = load_config_toml()

    # Mask sensitive values
    def mask(value: str) -> str:
        if not value or len(value) < 10:
            return "***"
        return f"{value[:6]}...{value[-4:]}"

    print("Current configuration:")
    print("-" * 40)

    # Show each setting
    token = config_data.get("telegram_token", "")
    print(f"telegram_token: {mask(token)}")

    api_key = config_data.get("api_key") or config_data.get("anthropic_api_key", "")
    print(
        f"api_key: {mask(api_key) if api_key else '(not set - using provider env var)'}"
    )

    print(f"allowed_user_ids: {config_data.get('allowed_user_ids', [])}")
    print(f"user_name: {config_data.get('user_name', 'User')}")
    print(f"root_folder: {config_data.get('root_folder', '(default)')}")
    print(f"model: {config_data.get('model', 'anthropic/claude-sonnet-4-20250514')}")
    print(f"max_context_chars: {config_data.get('max_context_chars', 100000)}")
    print(
        f"db_path: {config_data.get('db_path', '~/.local/share/self-bot/sessions.db')}"
    )

    google_key = config_data.get("google_api_key", "")
    print(f"google_api_key: {mask(google_key) if google_key else '(not set)'}")
    print(f"google_cx: {config_data.get('google_cx', '(not set)') or '(not set)'}")

    read_rules = config_data.get("read_rules", {})
    print(f"read_rules.include: {read_rules.get('include', DEFAULT_INCLUDE_PATTERNS)}")
    print(f"read_rules.exclude: {read_rules.get('exclude', DEFAULT_EXCLUDE_PATTERNS)}")

    # Show environment overrides
    print()
    print("Environment overrides:")
    print("-" * 40)
    env_vars = [
        ("TELEGRAM_BOT_TOKEN", os.environ.get("TELEGRAM_BOT_TOKEN")),
        ("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY")),
        ("SELF_BOT_ROOT", os.environ.get("SELF_BOT_ROOT")),
        ("SELF_BOT_ALLOWED_IDS", os.environ.get("SELF_BOT_ALLOWED_IDS")),
        ("SELF_BOT_MODEL", os.environ.get("SELF_BOT_MODEL")),
        ("SELF_BOT_DB_PATH", os.environ.get("SELF_BOT_DB_PATH")),
        ("GOOGLE_API_KEY", os.environ.get("GOOGLE_API_KEY")),
        ("GOOGLE_CX", os.environ.get("GOOGLE_CX")),
    ]
    any_set = False
    for name, value in env_vars:
        if value:
            any_set = True
            if "TOKEN" in name or "KEY" in name:
                print(f"  {name}: {mask(value)}")
            else:
                print(f"  {name}: {value}")
    if not any_set:
        print("  (none)")

    return 0


def cmd_config_set(args: argparse.Namespace) -> int:
    """Set a configuration value."""
    config_data = load_config_toml()

    key = args.key
    value = args.value

    # Handle nested keys like read_rules.include
    if "." in key:
        parts = key.split(".", 1)
        parent = parts[0]
        child = parts[1]
        if parent not in config_data:
            config_data[parent] = {}
        # Try to parse as list if it looks like one
        if value.startswith("[") or "," in value:
            value = [v.strip().strip("\"'") for v in value.strip("[]").split(",")]
        config_data[parent][child] = value
    else:
        # Handle special types
        if key == "allowed_user_ids":
            value = [int(x.strip()) for x in value.split(",")]
        elif key == "max_context_chars":
            value = int(value)
        config_data[key] = value

    save_config_toml(config_data)
    print(f"Set {key} = {value}")
    return 0


def cmd_config_folder(args: argparse.Namespace) -> int:
    """Set the root folder."""
    config_data = load_config_toml()

    folder = args.path
    folder_path = Path(folder).expanduser().resolve()

    if not folder_path.exists():
        print(f"Warning: {folder_path} does not exist")
        confirm = input("Continue anyway? [y/N]: ").strip().lower()
        if confirm != "y":
            return 1

    config_data["root_folder"] = str(folder_path)
    save_config_toml(config_data)
    print(f"Root folder set to: {folder_path}")
    return 0


def cmd_move(args: argparse.Namespace) -> int:
    """Move the folderbot folder to a new location."""
    source = Path.cwd()
    dotfolder = source / ".folderbot"

    if not dotfolder.exists():
        print(
            "Error: No .folderbot/ directory found in current directory.",
            file=sys.stderr,
        )
        print("Run this command from a folder that has .folderbot/", file=sys.stderr)
        return 1

    dest = Path(args.destination).expanduser().resolve()

    if dest.exists():
        print(f"Error: Destination already exists: {dest}", file=sys.stderr)
        return 1

    # Move the entire folder
    shutil.move(str(source), str(dest))
    print(f"Moved {source} -> {dest}")

    # Update systemd service if installed
    service_path = _get_service_path()
    if service_path.exists():
        content = service_path.read_text()
        updated = content.replace(str(source), str(dest))
        service_path.write_text(updated)
        print(f"Updated systemd service: {service_path}")

        _run_systemctl("daemon-reload")
        print("Systemd daemon reloaded.")

    return 0


def cmd_status(args: argparse.Namespace) -> int:
    """Show current status."""
    config_path = get_config_path()

    print("Folderbot Status")
    print("=" * 40)
    print()

    # Config status
    print(f"Config file: {config_path}")
    if not config_path.exists():
        print("  Status: NOT CONFIGURED")
        print("  Run 'folderbot init' to set up")
        return 1

    # Try to load full config
    try:
        config = Config.load()
        print("  Status: OK")
    except ValueError as e:
        print(f"  Status: ERROR - {e}")
        return 1

    print()

    # Folder info
    print(f"Root folder: {config.root_folder}")
    if config.root_folder.exists():
        print("  Status: EXISTS")

        # Count files that match patterns
        from .context_builder import ContextBuilder

        builder = ContextBuilder(config)
        stats = builder.get_context_stats()

        print(f"  Files in context: {stats['file_count']}")
        print(f"  Total chars: {stats['total_chars']:,}")
        print(f"  Max allowed: {config.max_context_chars:,}")
    else:
        print("  Status: DOES NOT EXIST")

    print()

    # Credentials status
    print("Credentials:")
    config_data = load_config_toml()

    token = config_data.get("telegram_token", "")
    token_env = os.environ.get("TELEGRAM_BOT_TOKEN")
    if token_env:
        print("  Telegram token: set (from environment)")
    elif token and token != "YOUR_TELEGRAM_BOT_TOKEN":
        print("  Telegram token: set (from config)")
    else:
        print("  Telegram token: NOT SET")

    api_key = config_data.get("api_key") or config_data.get("anthropic_api_key", "")
    api_key_env = os.environ.get("FOLDERBOT_API_KEY") or os.environ.get(
        "ANTHROPIC_API_KEY"
    )
    if api_key_env:
        print("  LLM API key: set (from environment)")
    elif api_key and api_key not in ("YOUR_ANTHROPIC_API_KEY", "YOUR_API_KEY"):
        print("  LLM API key: set (from config)")
    else:
        print("  LLM API key: not set (provider env var may be used)")

    print()

    # Model info
    print(f"Model: {config.model}")
    print(f"Allowed users: {config.allowed_user_ids}")

    return 0


def cmd_run(args: argparse.Namespace) -> int:
    """Run the bot."""
    import logging

    from .telegram_handler import TelegramBot

    log_level = logging.DEBUG if getattr(args, "verbose", False) else logging.INFO
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=log_level,
    )

    try:
        bot_name = getattr(args, "bot", None)
        config = Config.load(bot_name=bot_name)
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        print("Run 'folderbot init' to set up configuration", file=sys.stderr)
        return 1

    bot = TelegramBot(config)
    bot.run()
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    """Check for updates and upgrade if available."""
    from .updater import (
        UpdateError,
        check_for_update,
        fetch_pypi_version,
        run_pip_upgrade,
    )

    try:
        latest = fetch_pypi_version()
    except UpdateError as e:
        print(f"Error checking for updates: {e}", file=sys.stderr)
        return 1

    result = check_for_update(__version__, latest)

    if not result.update_available:
        print(f"Already up to date (v{result.current_version})")
        return 0

    print(f"Update available: v{result.current_version} -> v{result.latest_version}")

    code, output = run_pip_upgrade()
    if code != 0:
        print(f"Upgrade failed: {output}", file=sys.stderr)
        return 1

    print(f"Upgraded to v{result.latest_version}")

    # Restart the main service if it's running
    service_path = _get_service_path()
    if service_path.exists():
        ret, _ = _run_systemctl("is-active", "folderbot")
        if ret == 0:
            print("Restarting folderbot service...")
            _run_systemctl("restart", "folderbot")
            print("Service restarted.")

    return 0


# Systemd service management

SYSTEMD_SERVICE_TEMPLATE = """[Unit]
Description=Folderbot - Telegram bot for chatting with your folder
After=network.target

[Service]
Type=simple
ExecStart={exec_path} run{bot_flag}
Restart=on-failure
RestartSec=10
WorkingDirectory={work_dir}

[Install]
WantedBy=default.target
"""

SYSTEMD_UPDATE_SERVICE_TEMPLATE = """[Unit]
Description=Folderbot auto-update check
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart={exec_path} update
"""

SYSTEMD_UPDATE_TIMER_TEMPLATE = """[Unit]
Description=Folderbot auto-update timer

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
RandomizedDelaySec=30

[Install]
WantedBy=timers.target
"""


def _service_name(bot_name: str | None = None) -> str:
    """Get the systemd service name, optionally for a specific bot."""
    if bot_name:
        return f"folderbot-{bot_name}"
    return "folderbot"


def _get_service_path(bot_name: str | None = None) -> Path:
    """Get the path to the systemd user service file."""
    return Path.home() / ".config/systemd/user" / f"{_service_name(bot_name)}.service"


def _get_update_service_path(bot_name: str | None = None) -> Path:
    """Get the path to the auto-update systemd service file."""
    return Path.home() / ".config/systemd/user/folderbot-update.service"


def _get_update_timer_path(bot_name: str | None = None) -> Path:
    """Get the path to the auto-update systemd timer file."""
    return Path.home() / ".config/systemd/user/folderbot-update.timer"


def _run_systemctl(*args: str) -> tuple[int, str]:
    """Run a systemctl --user command."""
    import subprocess

    result = subprocess.run(
        ["systemctl", "--user", *args],
        capture_output=True,
        text=True,
    )
    output = result.stdout + result.stderr
    return result.returncode, output.strip()


def cmd_service_install(args: argparse.Namespace) -> int:
    """Install the systemd user service."""
    bot_name = getattr(args, "bot", None)

    # Find the folderbot executable
    exec_path = shutil.which("folderbot")
    if not exec_path:
        print("Error: 'folderbot' not found in PATH", file=sys.stderr)
        print(
            "Make sure folderbot is installed: pip install folderbot", file=sys.stderr
        )
        return 1

    # Get config to determine working directory
    config_path = get_config_path()
    if not config_path.exists():
        print(
            "Error: No configuration found. Run 'folderbot init' first.",
            file=sys.stderr,
        )
        return 1

    config_data = load_config_toml()

    # For local config (.folderbot/config.toml), use the parent of .folderbot/
    # For global config, use root_folder from YAML or PWD
    from .config import _is_local_config

    if _is_local_config(config_path):
        work_dir = str(config_path.parent.parent.resolve())
    else:
        work_dir = config_data.get("root_folder", str(Path.cwd()))

    # Build bot flag for ExecStart
    bot_flag = f" --bot {bot_name}" if bot_name else ""

    # Create service file content
    service_content = SYSTEMD_SERVICE_TEMPLATE.format(
        exec_path=exec_path,
        work_dir=work_dir,
        bot_flag=bot_flag,
    )

    # Ensure directory exists
    service_path = _get_service_path(bot_name)
    service_path.parent.mkdir(parents=True, exist_ok=True)

    # Write service file
    service_path.write_text(service_content)
    print(f"Service file created: {service_path}")

    # Write auto-update service and timer
    update_service_path = _get_update_service_path()
    update_service_content = SYSTEMD_UPDATE_SERVICE_TEMPLATE.format(
        exec_path=exec_path,
    )
    update_service_path.write_text(update_service_content)

    update_timer_path = _get_update_timer_path()
    update_timer_path.write_text(SYSTEMD_UPDATE_TIMER_TEMPLATE)
    print(f"Auto-update timer created: {update_timer_path}")

    # Reload systemd
    code, _ = _run_systemctl("daemon-reload")
    if code != 0:
        print("Warning: Failed to reload systemd daemon", file=sys.stderr)

    # Check if linger is enabled
    import subprocess

    linger_check = subprocess.run(
        ["loginctl", "show-user", os.environ.get("USER", ""), "--property=Linger"],
        capture_output=True,
        text=True,
    )
    linger_enabled = "Linger=yes" in linger_check.stdout

    print()
    print("Service installed. Next steps:")
    print("  folderbot service enable   # Start on login")
    print("  folderbot service start    # Start now")
    if not linger_enabled:
        print()
        print("Note: To keep the bot running after logout (recommended for servers):")
        print("  sudo loginctl enable-linger $USER")
    return 0


def cmd_service_uninstall(args: argparse.Namespace) -> int:
    """Uninstall the systemd user service."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)
    service_path = _get_service_path(bot_name)

    if not service_path.exists():
        print("Service is not installed.")
        return 0

    # Stop and disable the update timer first
    _run_systemctl("stop", "folderbot-update.timer")
    _run_systemctl("disable", "folderbot-update.timer")

    # Stop and disable the main service
    _run_systemctl("stop", svc)
    _run_systemctl("disable", svc)

    # Remove all service/timer files
    service_path.unlink()
    print(f"Service file removed: {service_path}")

    update_service_path = _get_update_service_path()
    if update_service_path.exists():
        update_service_path.unlink()

    update_timer_path = _get_update_timer_path()
    if update_timer_path.exists():
        update_timer_path.unlink()

    # Reload systemd
    _run_systemctl("daemon-reload")
    print("Service uninstalled.")
    return 0


def cmd_service_enable(args: argparse.Namespace) -> int:
    """Enable the service to start on login."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)
    service_path = _get_service_path(bot_name)
    if not service_path.exists():
        print("Error: Service not installed. Run 'folderbot service install' first.")
        return 1

    code, output = _run_systemctl("enable", svc)
    if code != 0:
        print(f"Error: {output}", file=sys.stderr)
        return 1

    _run_systemctl("enable", "folderbot-update.timer")

    print("Service enabled. Folderbot will start automatically on login.")
    return 0


def cmd_service_disable(args: argparse.Namespace) -> int:
    """Disable the service from starting on login."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)

    _run_systemctl("disable", "folderbot-update.timer")

    code, output = _run_systemctl("disable", svc)
    if code != 0:
        print(f"Error: {output}", file=sys.stderr)
        return 1

    print("Service disabled. Folderbot will not start automatically.")
    return 0


def cmd_service_start(args: argparse.Namespace) -> int:
    """Start the service."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)
    service_path = _get_service_path(bot_name)
    if not service_path.exists():
        print("Error: Service not installed. Run 'folderbot service install' first.")
        return 1

    code, output = _run_systemctl("start", svc)
    if code != 0:
        print(f"Error: {output}", file=sys.stderr)
        return 1

    _run_systemctl("start", "folderbot-update.timer")

    print("Folderbot started.")
    return 0


def cmd_service_stop(args: argparse.Namespace) -> int:
    """Stop the service."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)

    _run_systemctl("stop", "folderbot-update.timer")

    code, output = _run_systemctl("stop", svc)
    if code != 0:
        print(f"Error: {output}", file=sys.stderr)
        return 1

    print("Folderbot stopped.")
    return 0


def cmd_service_restart(args: argparse.Namespace) -> int:
    """Restart the service."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)
    service_path = _get_service_path(bot_name)
    if not service_path.exists():
        print("Error: Service not installed. Run 'folderbot service install' first.")
        return 1

    code, output = _run_systemctl("restart", svc)
    if code != 0:
        print(f"Error: {output}", file=sys.stderr)
        return 1

    print("Folderbot restarted.")
    return 0


def cmd_service_status(args: argparse.Namespace) -> int:
    """Show service status."""
    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)
    service_path = _get_service_path(bot_name)

    if not service_path.exists():
        print("Service: not installed")
        print()
        print("Run 'folderbot service install' to set up the systemd service.")
        return 0

    code, output = _run_systemctl("status", svc)
    print(output)
    return 0


def cmd_service_logs(args: argparse.Namespace) -> int:
    """Show service logs."""
    import subprocess

    bot_name = getattr(args, "bot", None)
    svc = _service_name(bot_name)

    if args.follow:
        cmd = ["journalctl", "--user", "-u", svc, "-f"]
    else:
        cmd = ["journalctl", "--user", "-u", svc, "-n", "50"]

    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass
    return 0


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="folderbot",
        description="Telegram bot for chatting with your folder using LLMs",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # run command
    run_parser = subparsers.add_parser("run", help="Start the bot")
    run_parser.add_argument(
        "--bot", "-b", help="Name of bot to run (for multi-bot configs)"
    )
    run_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable debug logging"
    )
    run_parser.set_defaults(func=cmd_run)

    # init command
    init_parser = subparsers.add_parser("init", help="Interactive setup wizard")
    init_parser.set_defaults(func=cmd_init)

    # status command
    status_parser = subparsers.add_parser("status", help="Show current status")
    status_parser.set_defaults(func=cmd_status)

    # update command
    update_parser = subparsers.add_parser(
        "update", help="Check for and install updates from PyPI"
    )
    update_parser.set_defaults(func=cmd_update)

    # move command
    move_parser = subparsers.add_parser(
        "move", help="Move folder to a new location and update systemd"
    )
    move_parser.add_argument("destination", help="New path for the folder")
    move_parser.set_defaults(func=cmd_move)

    # config command with subcommands
    config_parser = subparsers.add_parser("config", help="View or modify configuration")
    config_subparsers = config_parser.add_subparsers(
        dest="config_command", help="Config commands"
    )

    # config show
    config_show_parser = config_subparsers.add_parser(
        "show", help="Show current configuration"
    )
    config_show_parser.set_defaults(func=cmd_config_show)

    # config set
    config_set_parser = config_subparsers.add_parser(
        "set", help="Set a configuration value"
    )
    config_set_parser.add_argument(
        "key", help="Configuration key (e.g., model, root_folder)"
    )
    config_set_parser.add_argument("value", help="Value to set")
    config_set_parser.set_defaults(func=cmd_config_set)

    # config folder (shortcut)
    config_folder_parser = config_subparsers.add_parser(
        "folder", help="Set the root folder"
    )
    config_folder_parser.add_argument("path", help="Path to the folder")
    config_folder_parser.set_defaults(func=cmd_config_folder)

    # service command with subcommands
    service_parser = subparsers.add_parser(
        "service", help="Manage systemd user service"
    )
    service_subparsers = service_parser.add_subparsers(
        dest="service_command", help="Service commands"
    )

    # Helper to add --bot to service subcommands
    def _add_bot_arg(p: argparse.ArgumentParser) -> None:
        p.add_argument("--bot", "-b", help="Bot name (for multi-bot configs)")

    # service install
    service_install_parser = service_subparsers.add_parser(
        "install", help="Install systemd user service"
    )
    service_install_parser.set_defaults(func=cmd_service_install)
    _add_bot_arg(service_install_parser)

    # service uninstall
    service_uninstall_parser = service_subparsers.add_parser(
        "uninstall", help="Uninstall systemd user service"
    )
    service_uninstall_parser.set_defaults(func=cmd_service_uninstall)
    _add_bot_arg(service_uninstall_parser)

    # service enable
    service_enable_parser = service_subparsers.add_parser(
        "enable", help="Enable service to start on login"
    )
    service_enable_parser.set_defaults(func=cmd_service_enable)
    _add_bot_arg(service_enable_parser)

    # service disable
    service_disable_parser = service_subparsers.add_parser(
        "disable", help="Disable service auto-start"
    )
    service_disable_parser.set_defaults(func=cmd_service_disable)
    _add_bot_arg(service_disable_parser)

    # service start
    service_start_parser = service_subparsers.add_parser(
        "start", help="Start the service"
    )
    service_start_parser.set_defaults(func=cmd_service_start)
    _add_bot_arg(service_start_parser)

    # service stop
    service_stop_parser = service_subparsers.add_parser("stop", help="Stop the service")
    service_stop_parser.set_defaults(func=cmd_service_stop)
    _add_bot_arg(service_stop_parser)

    # service restart
    service_restart_parser = service_subparsers.add_parser(
        "restart", help="Restart the service"
    )
    service_restart_parser.set_defaults(func=cmd_service_restart)
    _add_bot_arg(service_restart_parser)

    # service status
    service_status_parser = service_subparsers.add_parser(
        "status", help="Show service status"
    )
    service_status_parser.set_defaults(func=cmd_service_status)
    _add_bot_arg(service_status_parser)

    # service logs
    service_logs_parser = service_subparsers.add_parser(
        "logs", help="Show service logs"
    )
    service_logs_parser.add_argument(
        "-f", "--follow", action="store_true", help="Follow log output"
    )
    service_logs_parser.set_defaults(func=cmd_service_logs)
    _add_bot_arg(service_logs_parser)

    return parser


def main() -> int:
    """Main entry point."""
    try:
        parser = create_parser()
        args = parser.parse_args()

        if args.command is None:
            # Default: show help
            parser.print_help()
            return 0

        if args.command == "config" and getattr(args, "config_command", None) is None:
            # config without subcommand: show config
            return cmd_config_show(args)

        if args.command == "service" and getattr(args, "service_command", None) is None:
            # service without subcommand: show status
            return cmd_service_status(args)

        if hasattr(args, "func"):
            return args.func(args)

        parser.print_help()
        return 0
    except KeyboardInterrupt:
        print("\n\nAborted.")
        return 130
