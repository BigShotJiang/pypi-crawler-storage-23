"""Typed tool registration framework for FolderBot.

This module provides the core infrastructure for registering and executing
async tools with typed request/response models. Tools are registered using
the @folder_bot.tool() decorator and executed asynchronously.

Key classes:
- FolderBot: The main bot class with tool registration and execution
- BotContext: Conversation state including history and tool executions
- Tool: A registered async tool with typed request/response models
- ToolExecutionRecord: Records a tool execution for context tracking
"""

from collections.abc import Awaitable
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, TypeVar

from pydantic import BaseModel, Field
from structlog import get_logger

logger = get_logger()


RequestT = TypeVar("RequestT", bound=BaseModel)
ResponseT = TypeVar("ResponseT", bound=BaseModel)

# Type alias for async tool functions
ToolFunc = Callable[[RequestT, "BotContext | None"], Awaitable[ResponseT]]


@dataclass(frozen=True)
class Tool(Generic[RequestT, ResponseT]):
    """A registered async tool with typed request/response models."""

    name: str
    description: str
    request_type: type[RequestT]
    response_type: type[ResponseT]
    func: ToolFunc[RequestT, ResponseT]

    async def execute(
        self, request_dict: dict[str, Any], context: "BotContext | None" = None
    ) -> ResponseT:
        """Parse input and execute the tool."""
        request = self.request_type.model_validate(request_dict)
        return await self.func(request, context)

    def get_schema(self) -> dict[str, Any]:
        """Get the JSON schema for this tool's request model."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.request_type.model_json_schema(),
        }


@dataclass(frozen=True)
class ToolExecutionRecord:
    """Record of a tool execution for context tracking.

    Note: This is different from tools.base.ToolResult which is the actual
    tool response (content + is_error). This class tracks what tools were
    called during a conversation turn.
    """

    tool_name: str
    request: BaseModel
    response: BaseModel

    def summarize(self) -> str:
        """Summarize this tool execution as text."""
        return (
            f"Tool: {self.tool_name}\n"
            f"Request: {self.request.model_dump_json()}\n"
            f"Response: {self.response.model_dump_json()}"
        )


@dataclass(frozen=True)
class Turn:
    """A completed query/response turn."""

    query: str
    response: str


@dataclass
class BotContext:
    """Structured context for a bot conversation."""

    # Current query being processed
    query: str

    # History of previous turns (query + final response pairs)
    history: "list[Turn]" = field(default_factory=list)

    # Summary of a parent/previous context (for chaining)
    previous_context_summary: str | None = None

    # Tool executions for the current query
    tool_executions: list[ToolExecutionRecord] = field(default_factory=list)

    # Services/dependencies for tools (config, root folder, etc.)
    services: "dict[str, Any]" = field(default_factory=dict)

    # User ID for the current session
    user_id: int = 0

    def add_tool_execution(
        self, tool_name: str, request: BaseModel, response: BaseModel
    ) -> None:
        """Record a tool execution."""
        self.tool_executions.append(
            ToolExecutionRecord(tool_name=tool_name, request=request, response=response)
        )

    def complete_turn(self, response: str) -> None:
        """Mark current query as complete and add to history."""
        self.history.append(Turn(query=self.query, response=response))
        self.tool_executions.clear()
        self.query = ""

    def start_turn(self, query: str) -> None:
        """Start a new turn with a fresh query."""
        self.query = query
        self.tool_executions.clear()

    def summarize(self) -> str:
        """Turn the full context into text for nesting or chaining."""
        lines: list[str] = []

        if self.previous_context_summary:
            lines.append(f"Previous Context:\n{self.previous_context_summary}\n")

        if self.history:
            lines.append("Conversation History:")
            for turn in self.history:
                lines.append(f"  User: {turn.query}")
                lines.append(f"  Assistant: {turn.response}")
            lines.append("")

        lines.append(f"Current Query: {self.query}")

        if self.tool_executions:
            lines.append("\nTool Executions:")
            for execution in self.tool_executions:
                lines.append(f"\n{execution.summarize()}")

        return "\n".join(lines)


class ToolRequest(BaseModel):
    """A request from the LLM to use a tool."""

    reasoning: str = Field(description="Why this tool is needed to complete the task.")
    tool_name: str = Field(description="Name of the tool to use.")
    tool_input: dict[str, Any] = Field(description="Input parameters for the tool.")


class BotResponse(BaseModel):
    """Structured response from the LLM."""

    thinking: str = Field(
        description="Internal reasoning about the current state and next steps."
    )

    tool_requests: "list[ToolRequest]" = Field(
        default_factory=list,
        description="Tools to execute. Empty if ready to give final response.",
    )

    final_response: str | None = Field(
        default=None,
        description="Final response to the user. Only set when no more tools are needed.",
    )


@dataclass
class FolderBot:
    """FolderBot main class with async tool registration.

    All tools are async, enabling concurrent execution with asyncio.gather.
    """

    _tools: "dict[str, Tool[Any, Any]]"

    def __init__(self) -> None:
        self._tools = {}

    def tool(
        self,
        name: str,
        request_type: type[RequestT],
        response_type: type[ResponseT],
        description: str | None = None,
    ) -> Callable[
        [ToolFunc[RequestT, ResponseT]],
        ToolFunc[RequestT, ResponseT],
    ]:
        """Decorator to register an async tool with typed request/response models.

        Args:
            name: Tool name for the LLM to call.
            request_type: Pydantic model for the request.
            response_type: Pydantic model for the response.
            description: Tool description. If None, uses the function's docstring.
        """

        def decorator(
            func: ToolFunc[RequestT, ResponseT],
        ) -> ToolFunc[RequestT, ResponseT]:
            # Use docstring if description not provided
            tool_description = description or func.__doc__ or f"Tool: {name}"

            self._tools[name] = Tool(
                name=name,
                description=tool_description.strip(),
                request_type=request_type,
                response_type=response_type,
                func=func,
            )
            return func

        return decorator

    def get_tool(self, name: str) -> Tool[Any, Any] | None:
        """Get a tool by name."""
        return self._tools.get(name)

    def has_tool(self, name: str) -> bool:
        """Check if a tool exists."""
        return name in self._tools

    def list_tools(self) -> list[Tool[Any, Any]]:
        """List all registered tools."""
        return list(self._tools.values())

    def get_tools_schema(self) -> list[dict[str, Any]]:
        """Get JSON schemas for all tools."""
        return [tool.get_schema() for tool in self._tools.values()]

    async def execute_tool(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        context: BotContext | None = None,
    ) -> Any:
        """Execute a tool by name with given input.

        If a context is provided, the execution is recorded in context.tool_executions.
        """
        tool = self.get_tool(tool_name)
        if tool is None:
            raise ValueError(f"Unknown tool: {tool_name}")

        # Parse the request for tracking
        request = tool.request_type.model_validate(tool_input)

        # Execute the tool
        response = await tool.func(request, context)

        # Record execution in context if provided
        if context is not None:
            context.tool_executions.append(
                ToolExecutionRecord(
                    tool_name=tool_name,
                    request=request,
                    response=response,
                )
            )

        return response

    def create_context(self, query: str) -> BotContext:
        """Create a new context for a query."""
        return BotContext(query=query)
