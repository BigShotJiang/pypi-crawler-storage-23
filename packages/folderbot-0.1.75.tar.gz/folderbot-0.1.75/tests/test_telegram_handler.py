"""Tests for Telegram bot handler."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest

from telegram import Message

from folderbot.config import Config, ReadRules, WatchConfig
from folderbot.llm_client import AskUserRequest, TokenUsage
from folderbot.telegram_handler import TelegramBot


@pytest.fixture
def mock_config(tmp_path: Path) -> Config:
    """Create a mock config for testing."""
    config = MagicMock(spec=Config)
    config.telegram_token = "test_token"
    config.api_key = "test_api_key"
    config.root_folder = tmp_path
    config.allowed_user_ids = [12345, 67890]
    config.read_rules = ReadRules()
    config.watch_config = WatchConfig()
    config.db_path = tmp_path / "sessions.db"
    config.model = "anthropic/claude-sonnet-4-20250514"
    config.max_context_chars = 10000
    config.max_history_chars = 50000
    config.user_name = "User"
    config.whisper_model = "base"
    config.tools = {}
    return config


@pytest.fixture
def bot(mock_config: Config) -> TelegramBot:
    """Create a bot instance for testing."""
    with patch("folderbot.llm_client.instructor"):
        tb = TelegramBot(mock_config)
    mock_app = MagicMock()
    mock_app.bot = AsyncMock()
    tb._application = mock_app
    return tb


@pytest.fixture
def mock_update():
    """Create a mock Telegram update."""
    update = MagicMock()
    update.effective_user = MagicMock()
    update.effective_user.id = 12345
    update.message = MagicMock()
    update.message.reply_text = AsyncMock()
    update.message.chat = MagicMock()
    update.message.chat.send_action = AsyncMock()
    return update


class TestAuthorization:
    def test_authorized_user(self, bot: TelegramBot):
        assert bot._is_authorized(12345) is True
        assert bot._is_authorized(67890) is True

    def test_unauthorized_user(self, bot: TelegramBot):
        assert bot._is_authorized(99999) is False
        assert bot._is_authorized(0) is False


class TestStartCommand:
    @pytest.mark.asyncio
    async def test_start_authorized(self, bot: TelegramBot, mock_update):
        await bot.start_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once()
        call_args = mock_update.message.reply_text.call_args[0][0]
        assert "Self-bot ready" in call_args
        assert "/clear" in call_args

    @pytest.mark.asyncio
    async def test_start_unauthorized(self, bot: TelegramBot, mock_update):
        mock_update.effective_user.id = 99999

        await bot.start_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_start_no_user(self, bot: TelegramBot, mock_update):
        mock_update.effective_user = None

        await bot.start_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_not_called()


class TestClearCommand:
    @pytest.mark.asyncio
    async def test_clear_authorized(self, bot: TelegramBot, mock_update):
        # Add some messages first
        bot.session_manager.add_message(12345, "user", "test")

        await bot.clear_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "Conversation history cleared.", parse_mode="HTML"
        )
        assert bot.session_manager.get_history(12345) == []

    @pytest.mark.asyncio
    async def test_clear_unauthorized(self, bot: TelegramBot, mock_update):
        mock_update.effective_user.id = 99999

        await bot.clear_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )


class TestNewCommand:
    @pytest.mark.asyncio
    async def test_new_authorized(self, bot: TelegramBot, mock_update):
        bot.session_manager.add_message(12345, "user", "old message")

        await bot.new_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "New topic started. History cleared.", parse_mode="HTML"
        )
        assert bot.session_manager.get_history(12345) == []


class TestStatusCommand:
    @pytest.mark.asyncio
    async def test_status_authorized(self, bot: TelegramBot, mock_update):
        bot.session_manager.add_message(12345, "user", "test message")

        await bot.status_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once()
        status_text = mock_update.message.reply_text.call_args[0][0]
        assert "Messages: 1" in status_text
        assert "Files:" in status_text

    @pytest.mark.asyncio
    async def test_status_unauthorized(self, bot: TelegramBot, mock_update):
        mock_update.effective_user.id = 99999

        await bot.status_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )


class TestFilesCommand:
    @pytest.mark.asyncio
    async def test_files_empty(self, bot: TelegramBot, mock_update):
        await bot.files_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "No files in context.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_files_with_content(
        self, bot: TelegramBot, mock_update, mock_config: Config
    ):
        # Create a test file
        (mock_config.root_folder / "test.md").write_text("# Test")

        # Force cache refresh
        bot.context_builder._cache_time = 0

        await bot.files_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once()
        call_args = mock_update.message.reply_text.call_args[0][0]
        assert "test.md" in call_args


class TestHandleMessage:
    @pytest.mark.asyncio
    async def test_unauthorized_message(self, bot: TelegramBot, mock_update):
        mock_update.effective_user.id = 99999
        mock_update.message.text = "Hello"

        await bot.handle_message(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_message_sends_typing(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Hello"

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Hi there!", [], "general", TokenUsage(0, 0)),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        bot._application.bot.send_chat_action.assert_called()

    @pytest.mark.asyncio
    async def test_message_calls_claude(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "What's in my folder?"

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Your folder contains...", [], "general", TokenUsage(0, 0)),
        ) as mock_chat:
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        mock_chat.assert_called_once()
        call_args = mock_chat.call_args
        assert call_args[0][0] == "What's in my folder?"

    @pytest.mark.asyncio
    async def test_message_stores_history(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Hello"

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Hi there!", [], "general", TokenUsage(0, 0)),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        history = bot.session_manager.get_history(12345)
        assert len(history) == 2
        assert history[0]["role"] == "user"
        assert history[0]["content"] == "Hello"
        assert history[1]["role"] == "assistant"
        assert history[1]["content"] == "Hi there!"

    @pytest.mark.asyncio
    async def test_history_stores_clean_response_without_tools_suffix(
        self, bot: TelegramBot, mock_update
    ):
        """Session history should store the clean response, not the one with Tools suffix."""
        mock_update.message.text = "Read my notes"

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=(
                "Here are your notes.",
                ["read_file"],
                "general",
                TokenUsage(0, 0),
            ),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        history = bot.session_manager.get_history(12345)
        assert len(history) == 2
        assistant_content = history[1]["content"]
        # Should NOT contain the Tools suffix
        assert "Tools:" not in assistant_content
        assert "<i>" not in assistant_content
        # Should contain only the clean response
        assert assistant_content == "Here are your notes."

    @pytest.mark.asyncio
    async def test_long_response_split(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Tell me everything"
        long_response = "x" * 5000  # Longer than Telegram's 4096 limit

        # Mark user as already notified about current version
        from folderbot import __version__

        bot.session_manager.set_last_notified_version(
            mock_update.effective_user.id, __version__
        )

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=(long_response, [], "general", TokenUsage(0, 0)),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        # Should be called 2 times for split message
        assert mock_update.message.reply_text.call_count == 2

    @pytest.mark.asyncio
    async def test_error_handling(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Hello"

        with patch.object(bot.llm_client, "chat", side_effect=Exception("API Error")):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        call_args = mock_update.message.reply_text.call_args[0][0]
        assert "Error:" in call_args

    @pytest.mark.asyncio
    async def test_generic_error_shows_error_message(
        self, bot: TelegramBot, mock_update
    ):
        """Test that API errors show the error in the response."""
        mock_update.message.text = "Hello"

        with patch.object(
            bot.llm_client,
            "chat",
            side_effect=RuntimeError("Service unavailable"),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        call_args = mock_update.message.reply_text.call_args[0][0]
        assert "Error:" in call_args


class TestHtmlFormatting:
    @pytest.mark.asyncio
    async def test_reply_text_uses_html_parse_mode(self, bot: TelegramBot, mock_update):
        """Messages should be sent with parse_mode=HTML."""
        await bot.start_command(mock_update, MagicMock())

        mock_update.message.reply_text.assert_called_once()
        assert mock_update.message.reply_text.call_args.kwargs["parse_mode"] == "HTML"

    @pytest.mark.asyncio
    async def test_reply_text_falls_back_to_plain_on_bad_html(
        self, bot: TelegramBot, mock_update
    ):
        """If HTML parsing fails, message should be resent as plain text."""
        from telegram.error import BadRequest

        # First call (with HTML) raises BadRequest, second (plain) succeeds
        mock_update.message.reply_text.side_effect = [
            BadRequest("Can't parse entities"),
            None,
        ]

        mock_update.effective_user.id = 99999
        mock_update.message.text = "Hello"
        await bot.handle_message(mock_update, MagicMock())

        assert mock_update.message.reply_text.call_count == 2
        # First attempt with HTML
        first_call = mock_update.message.reply_text.call_args_list[0]
        assert first_call == call("Unauthorized.", parse_mode="HTML")
        # Fallback without parse_mode
        second_call = mock_update.message.reply_text.call_args_list[1]
        assert second_call == call("Unauthorized.")


# ---------- ask_user tests ----------


class TestAskUserHandler:
    """Test the _handle_ask_user method and its Telegram UI rendering."""

    @pytest.mark.asyncio
    async def test_handle_ask_user_choice_sends_inline_keyboard(self, bot: TelegramBot):
        """Choice type sends an inline keyboard with the options."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(
            question="Which file?",
            options=["a.md", "b.md", "c.md"],
            input_type="choice",
        )

        # Resolve the future immediately in a background task
        async def resolve_future():
            await asyncio.sleep(0.01)
            future = bot._ask_user_futures.get(12345)
            if future and not future.done():
                future.set_result("a.md")

        asyncio.create_task(resolve_future())
        result = await bot._handle_ask_user(12345, 12345, request)

        assert result == "a.md"
        # Verify send_message was called with inline keyboard
        mock_bot.send_message.assert_called_once()
        call_kwargs = mock_bot.send_message.call_args.kwargs
        assert call_kwargs["chat_id"] == 12345
        assert "Which file?" in call_kwargs["text"]
        reply_markup = call_kwargs["reply_markup"]
        # InlineKeyboardMarkup has inline_keyboard attribute
        assert hasattr(reply_markup, "inline_keyboard")
        # Should have 3 rows (one per option)
        assert len(reply_markup.inline_keyboard) == 3

    @pytest.mark.asyncio
    async def test_handle_ask_user_confirm_sends_yes_no(self, bot: TelegramBot):
        """Confirm type sends Yes/No inline keyboard by default."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(question="Delete notes.md?", input_type="confirm")

        async def resolve_future():
            await asyncio.sleep(0.01)
            future = bot._ask_user_futures.get(12345)
            if future and not future.done():
                future.set_result("Yes")

        asyncio.create_task(resolve_future())
        result = await bot._handle_ask_user(12345, 12345, request)

        assert result == "Yes"
        call_kwargs = mock_bot.send_message.call_args.kwargs
        reply_markup = call_kwargs["reply_markup"]
        # Confirm has a single row with Yes/No
        assert len(reply_markup.inline_keyboard) == 1
        button_texts = [btn.text for btn in reply_markup.inline_keyboard[0]]
        assert "Yes" in button_texts
        assert "No" in button_texts

    @pytest.mark.asyncio
    async def test_handle_ask_user_text_sends_question_only(self, bot: TelegramBot):
        """Text type sends the question without buttons."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(
            question="What should the title be?", input_type="text"
        )

        async def resolve_future():
            await asyncio.sleep(0.01)
            future = bot._ask_user_futures.get(12345)
            if future and not future.done():
                future.set_result("My Title")

        asyncio.create_task(resolve_future())
        result = await bot._handle_ask_user(12345, 12345, request)

        assert result == "My Title"
        call_kwargs = mock_bot.send_message.call_args.kwargs
        assert "What should the title be?" in call_kwargs["text"]
        # Text type should NOT have a reply_markup
        assert "reply_markup" not in call_kwargs

    @pytest.mark.asyncio
    async def test_handle_ask_user_location_sends_reply_keyboard(
        self, bot: TelegramBot
    ):
        """Location type sends a reply keyboard with location request button."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(question="Share your location", input_type="location")

        async def resolve_future():
            await asyncio.sleep(0.01)
            future = bot._ask_user_futures.get(12345)
            if future and not future.done():
                future.set_result("lat=51.50, lon=-0.12")

        asyncio.create_task(resolve_future())
        result = await bot._handle_ask_user(12345, 12345, request)

        assert result == "lat=51.50, lon=-0.12"
        call_kwargs = mock_bot.send_message.call_args.kwargs
        reply_markup = call_kwargs["reply_markup"]
        # ReplyKeyboardMarkup has keyboard attribute
        assert hasattr(reply_markup, "keyboard")
        # First button should request location
        assert reply_markup.keyboard[0][0].request_location is True

    @pytest.mark.asyncio
    async def test_handle_ask_user_timeout(self, bot: TelegramBot):
        """If user doesn't respond, TimeoutError is raised."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(question="Pick one", options=["a", "b"])

        # Don't resolve the future — let it timeout
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(
                bot._handle_ask_user(12345, 12345, request), timeout=0.05
            )

        # Future should be cleaned up
        assert 12345 not in bot._ask_user_futures

    @pytest.mark.asyncio
    async def test_handle_ask_user_cleans_up_after_resolution(self, bot: TelegramBot):
        """After the future resolves, cleanup happens."""
        mock_app = MagicMock()
        mock_bot = AsyncMock()
        mock_app.bot = mock_bot
        bot._application = mock_app

        request = AskUserRequest(question="Pick", options=["a"])

        async def resolve_future():
            await asyncio.sleep(0.01)
            future = bot._ask_user_futures.get(12345)
            if future and not future.done():
                future.set_result("a")

        asyncio.create_task(resolve_future())
        await bot._handle_ask_user(12345, 12345, request)

        assert 12345 not in bot._ask_user_futures
        assert 12345 not in bot._ask_user_input_types


class TestCallbackQueryHandler:
    """Test callback query handling for inline keyboard responses."""

    @pytest.mark.asyncio
    async def test_callback_resolves_future(self, bot: TelegramBot):
        """A callback query resolves the pending ask_user future."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        bot._ask_user_futures[12345] = future
        bot._ask_user_options[12345] = ["a.md", "b.md"]

        update = MagicMock()
        update.callback_query = MagicMock()
        update.callback_query.data = "ask:12345:0"
        update.callback_query.answer = AsyncMock()
        update.callback_query.message = MagicMock(spec=Message)
        update.callback_query.message.edit_text = AsyncMock()

        await bot._handle_callback_query(update, MagicMock())

        assert future.done()
        assert future.result() == "a.md"
        update.callback_query.answer.assert_called_once()

    @pytest.mark.asyncio
    async def test_callback_unknown_user_handled(self, bot: TelegramBot):
        """Callback for a user with no pending future is handled gracefully."""
        update = MagicMock()
        update.callback_query = MagicMock()
        update.callback_query.data = "ask:99999:0"
        update.callback_query.answer = AsyncMock()
        update.callback_query.message = MagicMock(spec=Message)
        update.callback_query.message.edit_text = AsyncMock()

        # Should not raise
        await bot._handle_callback_query(update, MagicMock())
        update.callback_query.answer.assert_called_once()

    @pytest.mark.asyncio
    async def test_callback_edits_message_with_selection(self, bot: TelegramBot):
        """After selection, the original message is edited to show the choice."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        bot._ask_user_futures[12345] = future
        bot._ask_user_options[12345] = ["a.md"]

        update = MagicMock()
        update.callback_query = MagicMock()
        update.callback_query.data = "ask:12345:0"
        update.callback_query.answer = AsyncMock()
        update.callback_query.message = MagicMock(spec=Message)
        update.callback_query.message.text = "Which file?"
        update.callback_query.message.edit_text = AsyncMock()

        await bot._handle_callback_query(update, MagicMock())

        update.callback_query.message.edit_text.assert_called_once()
        edited_text = update.callback_query.message.edit_text.call_args[0][0]
        assert "a.md" in edited_text


class TestAskUserTextInterception:
    """Test that text messages resolve pending ask_user text futures."""

    @pytest.mark.asyncio
    async def test_text_message_resolves_text_future(
        self, bot: TelegramBot, mock_update
    ):
        """When ask_user text is pending, a text message resolves it."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        bot._ask_user_futures[12345] = future
        bot._ask_user_input_types[12345] = "text"

        mock_update.message.text = "My custom title"

        await bot.handle_message(mock_update, MagicMock())

        assert future.done()
        assert future.result() == "My custom title"

    @pytest.mark.asyncio
    async def test_text_message_not_intercepted_for_choice(
        self, bot: TelegramBot, mock_update
    ):
        """When ask_user choice is pending, text messages are NOT intercepted."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        bot._ask_user_futures[12345] = future
        bot._ask_user_input_types[12345] = "choice"

        mock_update.message.text = "Hello"

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Hi!", [], "general", TokenUsage(0, 0)),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(12345)

        # Future should NOT be resolved by the text message
        assert not future.done()


class TestLocationHandler:
    """Test location message handling for ask_user location type."""

    @pytest.mark.asyncio
    async def test_location_resolves_future(self, bot: TelegramBot):
        """A location message resolves the pending ask_user location future."""
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        bot._ask_user_futures[12345] = future
        bot._ask_user_input_types[12345] = "location"

        update = MagicMock()
        update.effective_user = MagicMock()
        update.effective_user.id = 12345
        update.message = MagicMock()
        update.message.location = MagicMock()
        update.message.location.latitude = 51.5074
        update.message.location.longitude = -0.1278
        update.message.reply_text = AsyncMock()

        await bot._handle_location(update, MagicMock())

        assert future.done()
        result = future.result()
        assert "51.5074" in result
        assert "-0.1278" in result

    @pytest.mark.asyncio
    async def test_location_ignored_without_pending_future(self, bot: TelegramBot):
        """Location messages without pending ask_user are ignored."""
        update = MagicMock()
        update.effective_user = MagicMock()
        update.effective_user.id = 12345
        update.message = MagicMock()
        update.message.location = MagicMock()
        update.message.location.latitude = 51.5074
        update.message.location.longitude = -0.1278
        update.message.reply_text = AsyncMock()

        # Should not raise
        await bot._handle_location(update, MagicMock())


class TestAskUserWiredToChat:
    """Test that on_ask_user callback is wired in _process_message."""

    @pytest.mark.asyncio
    async def test_chat_receives_on_ask_user(self, bot: TelegramBot, mock_update):
        """The llm_client.chat() call should receive an on_ask_user callback."""
        mock_update.message.text = "Do something"
        mock_update.message.chat_id = 12345

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Done.", [], "general", TokenUsage(0, 0)),
        ) as mock_chat:
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        mock_chat.assert_called_once()
        call_kwargs = mock_chat.call_args.kwargs
        assert "on_ask_user" in call_kwargs
        assert callable(call_kwargs["on_ask_user"])

    @pytest.mark.asyncio
    async def test_chat_receives_on_tool_use(self, bot: TelegramBot, mock_update):
        """The llm_client.chat() call should receive an on_tool_use callback."""
        mock_update.message.text = "Search for something"
        mock_update.message.chat_id = 12345

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Found it.", ["web_search"], "general", TokenUsage(0, 0)),
        ) as mock_chat:
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        mock_chat.assert_called_once()
        call_kwargs = mock_chat.call_args.kwargs
        assert "on_tool_use" in call_kwargs
        assert callable(call_kwargs["on_tool_use"])


class TestStatusNotifierCleanup:
    """Test that the status notifier is cleaned up after processing."""

    @pytest.mark.asyncio
    async def test_notifier_stopped_on_success(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Hello"
        mock_update.message.chat_id = 12345

        with patch.object(
            bot.llm_client,
            "chat",
            return_value=("Hi!", [], "general", TokenUsage(0, 0)),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        bot._application.bot.send_chat_action.assert_called()

    @pytest.mark.asyncio
    async def test_notifier_stopped_on_error(self, bot: TelegramBot, mock_update):
        mock_update.message.text = "Hello"
        mock_update.message.chat_id = 12345

        with patch.object(
            bot.llm_client,
            "chat",
            side_effect=RuntimeError("API down"),
        ):
            await bot.handle_message(mock_update, MagicMock())
            await bot.wait_for_processing(mock_update.effective_user.id)

        bot._application.bot.send_chat_action.assert_called()


class TestHandleVoice:
    @pytest.fixture
    def mock_voice_update(self):
        """Create a mock Telegram update with a voice message."""
        update = MagicMock()
        update.effective_user = MagicMock()
        update.effective_user.id = 12345
        update.message = MagicMock()
        update.message.reply_text = AsyncMock()
        update.message.chat = MagicMock()
        update.message.chat.send_action = AsyncMock()
        # Voice message attributes
        update.message.voice = MagicMock()
        update.message.voice.file_id = "voice_file_123"
        update.message.voice.duration = 5
        update.message.voice.mime_type = "audio/ogg"
        mock_file = MagicMock()
        mock_file.download_as_bytearray = AsyncMock(return_value=bytearray(b"fake ogg"))
        update.message.voice.get_file = AsyncMock(return_value=mock_file)
        # No audio attribute
        update.message.audio = None
        return update

    @pytest.fixture
    def mock_audio_update(self):
        """Create a mock Telegram update with an audio file."""
        update = MagicMock()
        update.effective_user = MagicMock()
        update.effective_user.id = 12345
        update.message = MagicMock()
        update.message.reply_text = AsyncMock()
        update.message.chat = MagicMock()
        update.message.chat.send_action = AsyncMock()
        # Audio file attributes
        update.message.audio = MagicMock()
        update.message.audio.file_id = "audio_file_456"
        update.message.audio.file_name = "recording.mp3"
        update.message.audio.duration = 30
        update.message.audio.mime_type = "audio/mpeg"
        mock_file = MagicMock()
        mock_file.download_as_bytearray = AsyncMock(return_value=bytearray(b"fake mp3"))
        update.message.audio.get_file = AsyncMock(return_value=mock_file)
        # No voice attribute
        update.message.voice = None
        return update

    @pytest.mark.asyncio
    async def test_unauthorized_voice(self, bot: TelegramBot, mock_voice_update):
        mock_voice_update.effective_user.id = 99999

        await bot.handle_voice(mock_voice_update, MagicMock())

        mock_voice_update.message.reply_text.assert_called_once_with(
            "Unauthorized.", parse_mode="HTML"
        )

    @pytest.mark.asyncio
    async def test_voice_transcribes_and_processes(
        self, bot: TelegramBot, mock_voice_update
    ):
        """Voice message should be transcribed and fed into the message pipeline."""
        with (
            patch("folderbot.telegram_handler.transcribe_audio") as mock_transcribe,
            patch.object(
                bot.llm_client,
                "chat",
                return_value=("Got it!", [], "general", TokenUsage(0, 0)),
            ),
        ):
            from folderbot.transcription import TranscriptionResult

            mock_transcribe.return_value = TranscriptionResult(text="Hello from voice")
            await bot.handle_voice(mock_voice_update, MagicMock())
            await bot.wait_for_processing(mock_voice_update.effective_user.id)

        mock_transcribe.assert_called_once_with(
            audio_bytes=b"fake ogg",
            model_name="base",
        )

    @pytest.mark.asyncio
    async def test_audio_file_transcribes(self, bot: TelegramBot, mock_audio_update):
        """Audio file should be transcribed using its original filename."""
        with (
            patch("folderbot.telegram_handler.transcribe_audio") as mock_transcribe,
            patch.object(
                bot.llm_client,
                "chat",
                return_value=("Got it!", [], "general", TokenUsage(0, 0)),
            ),
        ):
            from folderbot.transcription import TranscriptionResult

            mock_transcribe.return_value = TranscriptionResult(text="Hello from audio")
            await bot.handle_voice(mock_audio_update, MagicMock())
            await bot.wait_for_processing(mock_audio_update.effective_user.id)

        mock_transcribe.assert_called_once_with(
            audio_bytes=b"fake mp3",
            model_name="base",
        )

    @pytest.mark.asyncio
    async def test_voice_sends_prefixed_text_to_llm(
        self, bot: TelegramBot, mock_voice_update
    ):
        """Transcribed text should include a prefix indicating it was voice."""
        with (
            patch("folderbot.telegram_handler.transcribe_audio") as mock_transcribe,
            patch.object(
                bot.llm_client,
                "chat",
                return_value=("Response!", [], "general", TokenUsage(0, 0)),
            ) as mock_chat,
        ):
            from folderbot.transcription import TranscriptionResult

            mock_transcribe.return_value = TranscriptionResult(
                text="What is in my folder?"
            )
            await bot.handle_voice(mock_voice_update, MagicMock())
            await bot.wait_for_processing(mock_voice_update.effective_user.id)

        mock_chat.assert_called_once()
        call_args = mock_chat.call_args[0]
        assert "[Transcribed from voice message]" in call_args[0]
        assert "What is in my folder?" in call_args[0]

    @pytest.mark.asyncio
    async def test_voice_saves_audio_recording(
        self, bot: TelegramBot, mock_voice_update
    ):
        """Audio bytes should be saved to the uploads directory."""
        with (
            patch("folderbot.telegram_handler.transcribe_audio") as mock_transcribe,
            patch.object(
                bot.llm_client,
                "chat",
                return_value=("Got it!", [], "general", TokenUsage(0, 0)),
            ),
        ):
            from folderbot.transcription import TranscriptionResult

            mock_transcribe.return_value = TranscriptionResult(text="hello")
            await bot.handle_voice(mock_voice_update, MagicMock())
            await bot.wait_for_processing(mock_voice_update.effective_user.id)

        voice_dir = bot.config.root_folder / ".folderbot" / "voice"
        assert voice_dir.exists()
        saved_files = list(voice_dir.iterdir())
        assert len(saved_files) == 1
        assert saved_files[0].read_bytes() == b"fake ogg"

    @pytest.mark.asyncio
    async def test_voice_transcription_error(self, bot: TelegramBot, mock_voice_update):
        """Should reply with error when transcription fails."""
        with patch(
            "folderbot.telegram_handler.transcribe_audio",
            side_effect=Exception("Whisper decode error"),
        ):
            await bot.handle_voice(mock_voice_update, MagicMock())

        mock_voice_update.message.reply_text.assert_called_once()
        call_args = mock_voice_update.message.reply_text.call_args
        assert "transcription failed" in call_args[0][0].lower()

    @pytest.mark.asyncio
    async def test_voice_uses_configured_model(
        self, bot: TelegramBot, mock_voice_update
    ):
        """Should pass the configured whisper_model to transcribe_audio."""
        bot.config.whisper_model = "small"

        with (
            patch("folderbot.telegram_handler.transcribe_audio") as mock_transcribe,
            patch.object(
                bot.llm_client,
                "chat",
                return_value=("Ok!", [], "general", TokenUsage(0, 0)),
            ),
        ):
            from folderbot.transcription import TranscriptionResult

            mock_transcribe.return_value = TranscriptionResult(text="hello")
            await bot.handle_voice(mock_voice_update, MagicMock())
            await bot.wait_for_processing(mock_voice_update.effective_user.id)

        mock_transcribe.assert_called_once_with(
            audio_bytes=b"fake ogg",
            model_name="small",
        )
