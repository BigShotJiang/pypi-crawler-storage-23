"""Tests for weather forecast tool via Open-Meteo."""

from unittest.mock import MagicMock, patch

import pytest

from folderbot.tools.weather import (
    GetWeatherRequest,
    get_weather,
    _describe_weather_code,
)


SAMPLE_RESPONSE = {
    "current": {
        "temperature_2m": 18.5,
        "apparent_temperature": 16.2,
        "relative_humidity_2m": 65,
        "weather_code": 1,
        "wind_speed_10m": 12.3,
    },
    "current_units": {
        "temperature_2m": "°C",
        "apparent_temperature": "°C",
        "relative_humidity_2m": "%",
        "wind_speed_10m": "km/h",
    },
    "daily": {
        "time": ["2026-02-16", "2026-02-17", "2026-02-18"],
        "temperature_2m_max": [20.1, 18.3, 22.0],
        "temperature_2m_min": [10.5, 9.8, 11.2],
        "precipitation_sum": [0.0, 2.5, 0.0],
        "weather_code": [1, 61, 0],
    },
    "daily_units": {
        "temperature_2m_max": "°C",
        "temperature_2m_min": "°C",
        "precipitation_sum": "mm",
    },
}


class TestDescribeWeatherCode:
    def test_clear_sky(self):
        assert _describe_weather_code(0) == "Clear sky"

    def test_rain(self):
        assert _describe_weather_code(61) == "Light rain"

    def test_unknown_code(self):
        assert _describe_weather_code(999) == "Unknown (999)"

    def test_thunderstorm(self):
        assert _describe_weather_code(95) == "Thunderstorm"


class TestGetWeather:
    @pytest.mark.asyncio
    async def test_returns_current_and_forecast(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response

        with patch("folderbot.tools.weather.httpx") as mock_httpx:
            mock_httpx.Client.return_value = mock_client
            result = await get_weather(
                GetWeatherRequest(latitude=40.71, longitude=-74.01), None
            )

        assert not result.is_error
        assert "18.5" in result.content
        assert "Mainly clear" in result.content
        assert "2026-02-16" in result.content
        assert "Light rain" in result.content

    @pytest.mark.asyncio
    async def test_passes_correct_params(self):
        mock_response = MagicMock()
        mock_response.json.return_value = SAMPLE_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.return_value = mock_response

        with patch("folderbot.tools.weather.httpx") as mock_httpx:
            mock_httpx.Client.return_value = mock_client
            await get_weather(
                GetWeatherRequest(latitude=52.52, longitude=13.41, forecast_days=5),
                None,
            )

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs["params"]
        assert params["latitude"] == 52.52
        assert params["longitude"] == 13.41
        assert params["forecast_days"] == 5

    @pytest.mark.asyncio
    async def test_http_error(self):
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = Exception("Connection refused")

        with patch("folderbot.tools.weather.httpx") as mock_httpx:
            mock_httpx.Client.return_value = mock_client
            result = await get_weather(GetWeatherRequest(latitude=0, longitude=0), None)

        assert result.is_error
        assert "Connection refused" in result.content

    @pytest.mark.asyncio
    async def test_forecast_days_clamped(self):
        request = GetWeatherRequest(latitude=0, longitude=0, forecast_days=3)
        assert request.forecast_days == 3
