"""Tests for the updater module."""

import json
import sys
from unittest.mock import MagicMock, patch

import pytest

from folderbot.updater import (
    UpdateCheckResult,
    UpdateError,
    check_for_update,
    fetch_pypi_version,
    run_pip_upgrade,
)


class TestUpdateCheckResult:
    def test_frozen_dataclass(self):
        result = UpdateCheckResult(
            current_version="0.1.0",
            latest_version="0.2.0",
            update_available=True,
        )
        with pytest.raises(AttributeError):
            result.current_version = "0.3.0"  # type: ignore[misc]

    def test_fields(self):
        result = UpdateCheckResult(
            current_version="0.1.0",
            latest_version="0.2.0",
            update_available=True,
        )
        assert result.current_version == "0.1.0"
        assert result.latest_version == "0.2.0"
        assert result.update_available is True


class TestFetchPyPIVersion:
    def test_fetches_version_from_json(self):
        response_data = json.dumps({"info": {"version": "1.2.3"}}).encode()
        mock_response = MagicMock()
        mock_response.read.return_value = response_data
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("folderbot.updater.urlopen", return_value=mock_response):
            version = fetch_pypi_version("folderbot")

        assert version == "1.2.3"

    def test_raises_on_network_error(self):
        from urllib.error import URLError

        with patch(
            "folderbot.updater.urlopen", side_effect=URLError("Connection refused")
        ):
            with pytest.raises(UpdateError, match="fetch"):
                fetch_pypi_version()

    def test_raises_on_invalid_json(self):
        mock_response = MagicMock()
        mock_response.read.return_value = b"not json"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("folderbot.updater.urlopen", return_value=mock_response):
            with pytest.raises(UpdateError):
                fetch_pypi_version()

    def test_raises_on_missing_version_key(self):
        response_data = json.dumps({"info": {}}).encode()
        mock_response = MagicMock()
        mock_response.read.return_value = response_data
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("folderbot.updater.urlopen", return_value=mock_response):
            with pytest.raises(UpdateError, match="version"):
                fetch_pypi_version()


class TestCheckForUpdate:
    def test_update_available_when_newer(self):
        result = check_for_update("0.1.0", "0.2.0")
        assert result.update_available is True
        assert result.current_version == "0.1.0"
        assert result.latest_version == "0.2.0"

    def test_no_update_when_same(self):
        result = check_for_update("0.1.0", "0.1.0")
        assert result.update_available is False

    def test_no_update_when_local_is_newer(self):
        result = check_for_update("0.2.0", "0.1.0")
        assert result.update_available is False

    def test_handles_patch_versions(self):
        result = check_for_update("0.1.51", "0.1.52")
        assert result.update_available is True

    def test_handles_equal_patch_versions(self):
        result = check_for_update("0.1.51", "0.1.51")
        assert result.update_available is False


class TestRunPipUpgrade:
    def test_runs_subprocess_with_correct_args(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Successfully installed folderbot-0.2.0"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            code, output = run_pip_upgrade("folderbot")

        mock_run.assert_called_once_with(
            [sys.executable, "-m", "pip", "install", "--upgrade", "folderbot"],
            capture_output=True,
            text=True,
        )
        assert code == 0

    def test_returns_exit_code_and_output(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "ERROR: Could not find version"

        with patch("subprocess.run", return_value=mock_result):
            code, output = run_pip_upgrade()

        assert code == 1
        assert "Could not find version" in output

    def test_returns_stdout_on_success(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Successfully installed folderbot-0.2.0"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            code, output = run_pip_upgrade()

        assert code == 0
        assert "Successfully installed" in output
