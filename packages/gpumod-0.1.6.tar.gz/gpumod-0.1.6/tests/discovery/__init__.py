"""Tests for the discovery module."""
