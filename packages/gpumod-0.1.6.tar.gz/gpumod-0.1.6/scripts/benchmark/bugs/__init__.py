# Multi-agent benchmark bug scenarios
