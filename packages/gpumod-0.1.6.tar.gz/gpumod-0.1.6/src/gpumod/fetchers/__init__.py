"""Model info fetchers for various sources."""
