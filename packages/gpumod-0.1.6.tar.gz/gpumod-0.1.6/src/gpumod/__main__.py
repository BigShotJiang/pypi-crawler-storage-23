"""Entry point for ``python -m gpumod``."""

from gpumod.cli import app

app()
