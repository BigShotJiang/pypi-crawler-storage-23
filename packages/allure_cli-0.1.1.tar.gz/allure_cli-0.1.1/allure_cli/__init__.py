"""Allure TestOps CLI — get test case ID by name."""

from .client import find_by_name, get_jwt, search_test_cases
from .cli import main

__version__ = "0.1.0"
__all__ = ["find_by_name", "get_jwt", "search_test_cases", "main"]
