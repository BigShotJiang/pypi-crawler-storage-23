version = '1.0.2'
repo = 'git@github.com:makora-ai/makora.git'
commit = 'c27448336d28f073ecea659c83984650d408bac5'
has_repo = True
