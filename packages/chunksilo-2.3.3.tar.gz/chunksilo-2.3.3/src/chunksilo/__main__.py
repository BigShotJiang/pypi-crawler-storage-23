from chunksilo.cli import main

main()
