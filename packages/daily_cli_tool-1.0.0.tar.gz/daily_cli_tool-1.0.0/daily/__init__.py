"""daily - CLI para registro de trabajo diario."""

__version__ = "0.1.0"
