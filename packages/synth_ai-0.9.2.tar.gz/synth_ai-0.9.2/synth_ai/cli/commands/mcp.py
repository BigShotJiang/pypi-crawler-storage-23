"""MCP tooling diagnostics for Synth AI CLI."""

from __future__ import annotations

import time
from typing import Any

import click
from synth_ai.cli.commands.managed_research import _connection_options, _emit
from synth_ai.sdk.managed_research import SmrApiError, SmrControlClient

from synth_ai.mcp.managed_research_server import ManagedResearchMcpServer


_CRITICAL_MCP_TOOLS = {
    "smr_get_project_status",
    "smr_trigger_run",
    "smr_get_run",
    "smr_list_runs",
    "smr_get_actor_status",
    "smr_search_project_logs",
}


def _run_check(fn: Any) -> tuple[bool, dict[str, Any]]:
    start_ms = int(time.perf_counter() * 1000)
    try:
        result = fn()
    except SmrApiError as exc:
        return False, {"status": "fail", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        return False, {"status": "fail", "message": str(exc)}
    elapsed_ms = int(time.perf_counter() * 1000) - start_ms
    return True, {"status": "pass", "elapsed_ms": elapsed_ms, "result": result}


def _mcp_tool_health(check_result: dict[str, Any]) -> dict[str, Any]:
    server = ManagedResearchMcpServer()
    tools = server.available_tool_names()
    missing = sorted(set(_CRITICAL_MCP_TOOLS) - set(tools))
    check_result.update(
        {
            "status": "pass" if not missing else "fail",
            "tool_count": len(tools),
            "missing_critical_tools": missing,
        }
    )
    return check_result


def _doctor_payload(
    api_key: str | None,
    backend_url: str,
    project_id: str | None,
) -> dict[str, Any]:
    with SmrControlClient(api_key=api_key, backend_base=backend_url) as client:
        capabilities_ok, capabilities = _run_check(
            lambda: client.get_capabilities(),
        )
        projects_ok, projects = _run_check(
            lambda: client.list_projects(limit=1),
        )
        tool_data = _mcp_tool_health({})
        checks = {
            "backend_capabilities": capabilities,
            "project_access": projects,
            "mcp_tools": tool_data,
        }

        if project_id:
            project_ok, project_status = _run_check(
                lambda: client.get_project_status(project_id),
            )
            checks["project_status"] = project_status
            required_pass = (
                capabilities_ok
                and projects_ok
                and project_ok
                and tool_data["status"] == "pass"
            )
        else:
            required_pass = capabilities_ok and projects_ok and tool_data["status"] == "pass"

        return {
            "ok": required_pass,
            "backend_url": backend_url,
            "project_id": project_id,
            "checks": checks,
            "cli": {"command": "synth-ai mcp doctor"},
        }


def _print_human_summary(payload: dict[str, Any], *, compact: bool) -> None:
    checks = payload.get("checks", {})
    click.echo(f"SMR MCP status: {'OK' if payload.get('ok') else 'ISSUES DETECTED'}")
    for name, check in checks.items():
        status = check.get("status", "unknown")
        if status == "pass":
            check_text = "pass"
        elif status == "fail":
            check_text = "fail"
        else:
            check_text = str(status)
        click.echo(
            f"- {name}: {check_text}"
            + (f" ({check.get('message')})" if check.get("message") else "")
        )
        if compact:
            continue
        if name == "mcp_tools" and check.get("missing_critical_tools"):
            click.echo(f"  missing: {', '.join(check['missing_critical_tools'])}")


@click.group(name="mcp")
def mcp() -> None:
    """SMR MCP diagnostics and connectivity checks."""


@mcp.command(name="doctor")
@_connection_options
@click.option("--project-id", help="Optional project id to validate project status endpoint.")
def doctor(api_key: str | None, backend_url: str, json_output: bool, project_id: str | None) -> None:
    """Run MCP health checks and fail on any issue."""
    try:
        payload = _doctor_payload(
            api_key=api_key,
            backend_url=backend_url,
            project_id=project_id,
        )
    except click.ClickException:
        raise
    except Exception as exc:  # noqa: BLE001
        if json_output:
            _emit({"ok": False, "error": str(exc)}, json_output=True)
            return
        raise click.ClickException(str(exc)) from None
    if not payload["ok"]:
        if json_output:
            _emit(payload, json_output=True)
            return
        failed = [
            name
            for name, details in payload.get("checks", {}).items()
            if details.get("status") != "pass"
        ]
        raise click.ClickException(
            f"MCP doctor failed for checks: {', '.join(failed)}"
        )
    _emit(payload, json_output=json_output)


@mcp.command(name="status")
@_connection_options
@click.option("--project-id", help="Optional project id to include project status check.")
@click.option(
    "--compact",
    is_flag=True,
    default=False,
    help="Print compact one-line output.",
)
def status(
    api_key: str | None,
    backend_url: str,
    json_output: bool,
    project_id: str | None,
    compact: bool,
) -> None:
    """Show a quick MCP + backend status snapshot."""
    try:
        payload = _doctor_payload(
            api_key=api_key, backend_url=backend_url, project_id=project_id
        )
    except Exception as exc:  # noqa: BLE001
        if json_output:
            _emit({"ok": False, "error": str(exc)}, json_output=True)
            return
        raise click.ClickException(str(exc)) from None

    if json_output:
        _emit(payload, json_output=True)
        return

    _print_human_summary(payload, compact=compact)
