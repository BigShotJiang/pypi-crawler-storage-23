"""Tunnel helpers for exposing local APIs to Synth's training infrastructure.

This module provides high-level and low-level tunnel management for
exposing local containers to the internet. Two tunnel backends are available:

- **SynthTunnel** (default, recommended): Relay-based HTTPS tunnel. Traffic
  flows through Synth's relay servers via WebSocket. No ``cloudflared``
  binary required. Supports up to 128 concurrent in-flight requests (with
  dynamic memory-based budgeting for large payloads). Uses ``worker_token``
  for authentication.

- **NgrokManaged**: Synth-managed ngrok-compatible URL flow. Requires an
  approved managed URL (`SYNTH_MANAGED_NGROK_URL` or explicit parameter)
  and allow-listing in `SYNTH_MANAGED_TUNNEL_HOSTS`.

**Recommended:** Use ``TunneledContainer`` for a clean, one-liner experience:

    from synth_ai.core.tunnels import TunneledContainer, TunnelBackend

    # SynthTunnel (relay-based, default — recommended)
    tunnel = await TunneledContainer.create(
        local_port=8001,
        api_key="sk_live_...",
    )
    print(tunnel.url)           # https://dev.st.usesynth.ai/s/rt_...
    print(tunnel.worker_token)  # pass to job config

    # Ngrok managed tunnel URL
    tunnel = await TunneledContainer.create(
        local_port=8001,
        backend=TunnelBackend.NgrokManaged,
        managed_ngrok_url="https://example-tunnel.usesynth.ai",
    )

    # Localhost passthrough (no tunnel, local dev only)
    tunnel = await TunneledContainer.create(
        local_port=8001,
        backend=TunnelBackend.Localhost,
    )

    tunnel.close()

**SynthTunnel vs NgrokManaged — when to use which:**

+---------------------+----------------------------+----------------------------+
| Concern             | SynthTunnel                | NgrokManaged               |
+---------------------+----------------------------+----------------------------+
| Setup               | Zero config, no binary     | Managed URL + allow-list   |
| Concurrency         | 128 in-flight (dynamic)    | Provider limits apply      |
| Auth                | ``worker_token``           | Relay/token auth            |
| URL stability       | Per-lease (session-lived)  | Stable managed endpoint    |
| Best for            | SDK jobs, GEPA, MiPRO      | Infra-managed ingress      |
+---------------------+----------------------------+----------------------------+

**Using tunnels with optimization jobs:**

    # SynthTunnel — pass worker_token
    job = PromptLearningJob.from_dict(
        config,
        container_url=tunnel.url,
        container_worker_token=tunnel.worker_token,
    )

    # Managed ngrok-compatible URL
    job = PromptLearningJob.from_dict(
        config,
        container_url=tunnel.url,
    )

**Low-level:** For local process/runtime control:

    from synth_ai.core.tunnels import (
        acquire_port,
        find_available_port,
        kill_port,
        wait_for_health_check,
    )

Note:
    Processes registered with track_process() are automatically cleaned up
    when Python exits (via atexit). You can also call cleanup_all() manually.
"""

from __future__ import annotations

from typing import Any

from .cleanup import cleanup_all, track_process, tracked_processes
from .errors import (
    ConnectorError,
    ConnectorNotInstalledError,
    GatewayError,
    LeaseError,
    LeaseExpiredError,
    LocalAppError,
    TunnelAPIError,
    TunnelErrorCode,
    TunnelConfigurationError,
    TunnelError,
    TunnelProviderError,
)
from .ports import PortConflictBehavior, PortInUseError
from .rust import (
    acquire_port,
    find_available_port,
    is_port_available,
    kill_port,
    stop_tunnel,
    wait_for_health_check,
)

# New: high-level tunnel abstraction
from .tunneled_api import TunnelBackend, TunnelProvider, TunneledContainer
from .types import (
    ConnectorState,
    Diagnostics,
    GatewayState,
    LeaseInfo,
    LeaseState,
    TunnelHandle,
)


# Convenience function for creating tunnels from apps
async def create_tunneled_api(
    app: Any,
    local_port: int | None = None,
    backend: TunnelBackend = TunnelBackend.SynthTunnel,
    *,
    provider: TunnelProvider | str | None = None,
    api_key: str | None = None,
    backend_url: str | None = None,
    verify_dns: bool = True,
    progress: bool = False,
) -> TunneledContainer:
    """Create a tunnel for a FastAPI/ASGI app, handling server startup automatically.

    This is a convenience function that handles the common pattern of:
    1. Finding an available port (or using the provided one)
    2. Starting the app server
    3. Waiting for health check
    4. Creating the tunnel

    Args:
        app: FastAPI or ASGI application to tunnel
        local_port: Port to use (defaults to auto-finding an available port from 8001)
        backend: Tunnel backend to use
        provider: Provider selector ("SynthTunnel" | "Ngrok" | "Localhost")
        api_key: Synth API key (defaults to SYNTH_API_KEY env var)
        backend_url: Backend URL (defaults to production)
        verify_dns: Whether to verify DNS resolution
        progress: If True, print status updates

    Returns:
        TunneledContainer instance

    Example:
        >>> from fastapi import FastAPI
        >>> app = FastAPI()
        >>> tunnel = await create_tunneled_api(app)
        >>> print(f"App exposed at: {tunnel.url}")
    """
    return await TunneledContainer.create_for_app(
        app=app,
        local_port=local_port,
        backend=backend,
        provider=provider,
        api_key=api_key,
        backend_url=backend_url,
        verify_dns=verify_dns,
        progress=progress,
    )


__all__ = [
    # High-level (RECOMMENDED)
    "TunneledContainer",
    "TunnelBackend",
    "TunnelProvider",
    "create_tunneled_api",
    # Lease-based system types
    "TunnelHandle",
    "LeaseInfo",
    "LeaseState",
    "Diagnostics",
    "ConnectorState",
    "GatewayState",
    # Errors
    "TunnelError",
    "TunnelErrorCode",
    "TunnelProviderError",
    "TunnelConfigurationError",
    "TunnelAPIError",
    "LeaseError",
    "LeaseExpiredError",
    "ConnectorError",
    "ConnectorNotInstalledError",
    "GatewayError",
    "LocalAppError",
    # Canonical: runtime lifecycle
    "stop_tunnel",
    "wait_for_health_check",
    # Process tracking
    "track_process",
    "cleanup_all",
    "tracked_processes",
    # Port management
    "kill_port",
    "is_port_available",
    "find_available_port",
    "acquire_port",
    "PortConflictBehavior",
    "PortInUseError",
]
