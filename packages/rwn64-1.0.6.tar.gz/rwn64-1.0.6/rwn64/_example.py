from __future__ import annotations
import sys

_NC = sys.stdout.isatty() is False
_c = {
    "r":"", "dim":"", "bold":"", "hi":"", "cyan":"", "gray":"", "green":""
} if _NC else {
    "r":    "\x1b[0m",
    "dim":  "\x1b[2m",
    "bold": "\x1b[1m",
    "hi":   "\x1b[38;5;252m",
    "cyan": "\x1b[36m",
    "gray": "\x1b[38;5;245m",
    "green":"\x1b[32m",
}

def _vis(s: str) -> int:
    import re
    return len(re.sub(r"\x1b\[[0-9;]*m", "", s))

def _code_box(title: str, lines: list[tuple[str, str]]) -> None:
    lw = max(len(l) for l, _ in lines) if lines else 0
    rows = []
    for label, val in lines:
        pad = " " * (lw - len(label) + 1)
        lc  = _c["gray"]  if label.startswith("#") or label == "" else _c["cyan"]
        vc  = _c["dim"]   if label.startswith("#") or label == "" else _c["hi"]
        rows.append(f"{lc}{label}{_c['r']}{pad}{vc}{val}{_c['r']}")

    width = max((_vis(r) for r in rows), default=0)
    width = max(width, len(title) + 4) + 4

    def hline(l: str, r: str) -> str:
        return f"{_c['gray']}{l}{'─' * (width - 2)}{r}{_c['r']}\n"

    sys.stderr.write(f"\n  {_c['dim']}{title}{_c['r']}\n")
    sys.stderr.write(hline("┌", "┐"))
    for row in rows:
        pad = max(0, width - _vis(row) - 2)
        sys.stderr.write(f"{_c['gray']}│{_c['r']} {row}{' ' * pad} {_c['gray']}│{_c['r']}\n")
    sys.stderr.write(hline("└", "┘"))

def show() -> None:
    import rwn64
    ver = rwn64.__version__

    sys.stderr.write(f"\n{_c['gray']}{'─' * 48}{_c['r']}\n")
    sys.stderr.write(f"  {_c['bold']}{_c['cyan']}rwn64{_c['r']}  {_c['gray']}v{ver}  examples  (python){_c['r']}\n")
    sys.stderr.write(f"{_c['gray']}{'─' * 48}{_c['r']}\n")

    _code_box("library  (python)", [
        ("# install",                      ""),
        ("pip install",                    "rwn64"),
        ("",                               ""),
        ("import",                         "rwn64"),
        ("",                               ""),
        ("# generate password",            ""),
        ("pw",                             "= rwn64.generate(32)"),
        ("",                               ""),
        ("# encrypt",                      ""),
        ("token",                          "= rwn64.encrypt('my secret', pw)"),
        ("token",                          "= rwn64.encrypt('expires', pw, expires='1h')"),
        ("",                               ""),
        ("# decrypt",                      ""),
        ("text",                           "= rwn64.decrypt(token, pw)"),
        ("",                               ""),
        ("# verify",                       ""),
        ("ok",                             "= rwn64.verify(token, pw)"),
        ("",                               ""),
        ("# fingerprint",                  ""),
        ("fp",                             "= rwn64.fingerprint('hello', 'secret')"),
        ("",                               ""),
        ("# inspect token metadata",       ""),
        ("meta",                           "= rwn64.inspect(token)"),
        ("# meta",                         "{ version, algo, kdf, salt_hex, nonce_hex, payload_bytes }"),
    ])

    sys.stderr.write(f"\n{_c['gray']}{'─' * 48}{_c['r']}\n\n")

if __name__ == "__main__":
    show()
