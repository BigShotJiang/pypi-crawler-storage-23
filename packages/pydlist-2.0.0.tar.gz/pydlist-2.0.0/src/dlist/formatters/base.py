"""Base formatter interface"""

from abc import ABC, abstractmethod


class BaseFormatter(ABC):
    """Base class for all formatters

    All formatters must implement the format method.
    Categorized formatting and save are optional.
    """

    @abstractmethod
    def format(self, dlist, keys=[], **kwargs):
        """Format a Dlist object

        Parameters:
            dlist: Dlist object to format
            keys (list): List of keys to include in output
            **kwargs: Format-specific options

        Returns:
            str: Formatted output
        """
        pass

    def format_categorized(self, dlist, ctree, keys, titles={}, **kwargs):
        """Format with categories (optional)

        Parameters:
            dlist: Dlist object to format
            ctree (list): List of keys used as categories
            keys (list): List of keys to use as columns
            titles (dict): Dictionary for titles in columns {key:title}
            **kwargs: Format-specific options

        Returns:
            str: Formatted categorized output
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support categorized formatting"
        )

    def save(self, dlist, filepath, **kwargs):
        """Save formatted output to a file

        Parameters:
            dlist: Dlist object to format
            filepath (str): Output file path
            **kwargs: Passed to format()
        """
        content = self.format(dlist, **kwargs)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
