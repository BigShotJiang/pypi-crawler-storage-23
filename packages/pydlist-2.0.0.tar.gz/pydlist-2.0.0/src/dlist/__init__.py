"""dlist: List of dictionaries in a database-flavoured way

This package provides the Dlist class for working with lists of dictionaries
with database-like operations.  Scalar values are stored as strings; list
values are preserved as-is.

Example::

    >>> from dlist import Dlist
    >>> data = [{'name': 'John', 'age': '30'}, {'name': 'Jane', 'age': '25'}]
    >>> d = Dlist(data, id_='name')

I/O via methods::

    >>> d = Dlist.read('data.json', id_='id')
    >>> d = Dlist.read_pivot('evidence/*.json')
    >>> d.write('output.json')
    >>> d.write('table.xlsx', format='excel', keys=['name', 'age'])

Pluggable parsers and formatters::

    >>> from dlist.parsers import get_parser       # json
    >>> from dlist.formatters import get_formatter  # json, ascii, md, latex, excel
"""

from .dlist import Dlist
from . import parsers
from . import formatters

__version__ = '2.0.0'
__all__ = ['Dlist', 'parsers', 'formatters']
