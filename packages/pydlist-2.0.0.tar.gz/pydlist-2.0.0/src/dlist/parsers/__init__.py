"""Parsers for dlist input

Parsers convert external formats into Dlist objects.

Usage::

    from dlist.parsers import get_parser

    parser = get_parser('json')
    d = parser.parse('data.json', id_='id')
"""

from .json_parser import JSONParser

_PARSERS = {
    'json': JSONParser(),
    'excel': None,  # lazy — loaded on first use
}


def get_parser(format_type):
    """Get parser by type

    Parameters:
        format_type (str): Type of parser ('json', 'excel')

    Returns:
        BaseParser: Parser instance

    Raises:
        ValueError: If format_type is unknown
        ImportError: If the parser requires an uninstalled dependency
    """
    key = format_type.lower()
    if key not in _PARSERS:
        raise ValueError(f"Unknown format: {format_type}. Available: {list(_PARSERS.keys())}")
    if _PARSERS[key] is None:
        # Lazy import
        if key == 'excel':
            from .excel_parser import ExcelParser
            _PARSERS['excel'] = ExcelParser()
    return _PARSERS[key]


def register_parser(name, parser):
    """Register a custom parser

    Parameters:
        name (str): Name to register parser under
        parser (BaseParser): Parser instance
    """
    _PARSERS[name.lower()] = parser


__all__ = [
    'JSONParser',
    'get_parser',
    'register_parser',
]
