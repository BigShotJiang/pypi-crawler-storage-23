"""Base parser interface"""

from abc import ABC, abstractmethod


class BaseParser(ABC):
    """Base class for all parsers

    All parsers must implement the parse method to convert
    external formats into Dlist objects.
    """

    @abstractmethod
    def parse(self, source, id_='', **kwargs):
        """Parse source and return a Dlist

        Parameters:
            source: Source data (file path, string, or data structure)
            id_ (str): Optional id field name for the Dlist
            **kwargs: Parser-specific options

        Returns:
            Dlist: Parsed Dlist object
        """
        pass
