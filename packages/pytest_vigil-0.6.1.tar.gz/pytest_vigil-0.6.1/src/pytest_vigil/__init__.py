"""pytest-vigil: A pytest plugin for enhanced test reliability and monitoring."""
