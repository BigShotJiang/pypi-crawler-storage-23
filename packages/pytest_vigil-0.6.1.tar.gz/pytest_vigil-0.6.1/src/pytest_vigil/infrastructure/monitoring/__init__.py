"""Monitoring infrastructure: system stats collection, per-test and session monitoring."""
