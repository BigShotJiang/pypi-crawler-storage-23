"""Reporting infrastructure: CLI terminal reporter and JSON report writer."""
