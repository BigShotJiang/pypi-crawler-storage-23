"""Enforcement infrastructure: test interruption and signal management."""
