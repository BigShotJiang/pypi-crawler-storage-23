"""
Project configuration package.

Contains application settings, constants, and logging configuration.
No technical implementation details, business logic, or imports from other layers.
"""
