#
#   Imandra Inc.
#
#   __init__.py
#

from ..cl_server import CLServer
from .metamodel import register_metamodel_endpoints
from .model import register_model_endpoints
from .server import register_server_endpoints
from .sketches import register_sketches_endpoints
from .strategy import register_strategy_endpoints


def register_endpoints(app: CLServer):
    """
    Register the endpoints
    """

    register_server_endpoints(app)
    register_metamodel_endpoints(app)
    register_model_endpoints(app)
    register_sketches_endpoints(app)
    register_strategy_endpoints(app)
