----
title: XState example - Credit Check
description: XState Credit Check example and IML model
order: 2
----