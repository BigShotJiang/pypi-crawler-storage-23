----
title: XState xample – timer
description: XState Timer example and IML model
order: 4
----