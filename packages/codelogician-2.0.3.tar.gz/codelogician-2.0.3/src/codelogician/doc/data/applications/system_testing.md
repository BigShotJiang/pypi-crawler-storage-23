----
title: Testing digital twins
description: Tutorial on how to model and test complex systems
order: 2
----

