#
#   Imandra Inc.
#
#   codelogician/commands/cmd_multiagent.py
#

from pathlib import Path
from typing import Annotated

import typer

from codelogician.util import ImandraAPIKeyError, setup_logging


# fmt: off
def run_multiagent_cmd(
    dir   : Annotated[str, typer.Argument(help='Target directory')],
    clean : Annotated[bool, typer.Option(help='Start clean by disregarding any existing cache files')] = False,
    config: Annotated[str, typer.Option(help='Server configuration YAML file')] = 'config/server_config.yaml',
    debug : Annotated[bool, typer.Option(help='Debug mode')] = False,
):
    from codelogician.server.oneshot import run_oneshot

    if not Path(dir).is_dir() or Path(dir).is_file():
        typer.secho(f'🛑 Target not a directory: {dir}', err=True)
        raise typer.Exit(1)

    setup_logging(debug=debug)

    # Validate API key before starting any work
    try:
        from codelogician.util import remote_graph_with_thread
        remote_graph_with_thread()
        run_oneshot(dir, clean, config)
    except ImandraAPIKeyError as e:
        typer.secho(f'Error: {str(e)}', err=True)
        typer.secho(f'Hint: {e.hint}', err=True)
        raise typer.Exit(1)
# fmt: on
