import os
import subprocess

from fastapi import FastAPI

api = FastAPI()


@api.post('/eval')
def run_eval_command(args: list[str]):
    result = subprocess.run(
        ['codelogician', 'eval'] + args,
        capture_output=True,
        text=True,
        env={'NO_COLOR': '1', **os.environ},
    )
    return {
        'stdout': result.stdout,
        'stderr': result.stderr,
        'returncode': result.returncode,
    }


@api.post('/doc')
def run_doc_command(args: list[str]):
    result = subprocess.run(
        ['codelogician', 'doc'] + args,
        capture_output=True,
        text=True,
        env={'NO_COLOR': '1', **os.environ},
    )
    return {
        'stdout': result.stdout,
        'stderr': result.stderr,
        'returncode': result.returncode,
    }


if __name__ == '__main__':
    import uvicorn

    uvicorn.run(api, host='0.0.0.0', port=8080)
