"""
CLI that only includes the eval and doc subcommands.

For dev-purposes mainly.
"""
#
#   Imandra Inc.
#
#   tool_cli.py
#

import typer

from codelogician.commands.cmd_eval import app as eval_app

app = typer.Typer(name='CodeLogician', no_args_is_help=True)

# Register all eval commands directly at the top level
for cmd in eval_app.registered_commands:
    app.registered_commands.append(cmd)


if __name__ == '__main__':
    app()
