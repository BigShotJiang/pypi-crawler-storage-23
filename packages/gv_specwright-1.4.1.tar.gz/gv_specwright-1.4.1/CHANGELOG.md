# CHANGELOG

<!-- version list -->

## v1.4.1 (2026-03-04)

### Bug Fixes

- **ci**: Fail if uv.lock is out of sync with pyproject.toml
  ([`b798442`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b798442c30253cf517659b6e92aeab7b213e7200))

### Chores

- Sync uv.lock with pyproject.toml v1.3.0
  ([`c4fde9c`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/c4fde9cf35ea79dd7f8dfbe007ce6634d90f1aa3))


## v1.4.0 (2026-03-04)

### Bug Fixes

- Address PR security feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- Address round 2 PR review feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- **ci**: Prevent duplicate claude review comments
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Code Style

- Format test_ticket_routes.py
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Documentation

- Update specs based on #118 ([#120](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/120),
  [`2abefec`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/2abefec28cd029636da9f4e22078d5e16d79e492))

### Features

- Server-proxied ticket sync via GitHub App tokens
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))


## v1.3.0 (2026-03-01)

### Bug Fixes

- Ruff format on integration conftest
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address PR review — permissions, marker conflict, coverage paths
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address round 2 review feedback
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Format integration tests and fix set -e in combine step
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

### Documentation

- Update specs based on #117 ([#119](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/119),
  [`b7a6def`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b7a6defc6c30dbe7095fc27d0902a9ba6aa2410c))

### Features

- **ci**: Add coverage reporting for unit and integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Coverage reporting for unit & integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))


## v1.2.0 (2026-03-01)

### Bug Fixes

- Default platform_url to empty, use module-level Settings, drop redundant path
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

- URL-encode spec paths and add links to reanalyze handler
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Chores

- Lock updates
  ([`566ee0a`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/566ee0aa09fbbf9d62a67fa0a204541000003be9))

### Code Style

- Fix ruff formatting ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Documentation

- Update specs based on #112 ([#114](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/114),
  [`a47ece3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a47ece3fc43189a0b043018237d53bd8dd2b9f52))

### Features

- Add Specwright web app links to PR comments
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))


## v1.1.0 (2026-02-28)

### Documentation

- Update install commands to use gv-specwright package name
  ([`8536e8b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/8536e8bdd3261f6cf2a68ed4be41d2ce92008064))

### Features

- **docs-site**: Logo links to main site + gradient wordmark
  ([`7e55c6b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7e55c6ba18aee0b5569382afcc14793850cf4b13))


## v1.0.3 (2026-02-28)

### Bug Fixes

- Add AUTH0_DEVICE_CLIENT_ID to deploy K8s secret
  ([#116](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/116),
  [`fc8b3a8`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fc8b3a8c21b14a4e9e0cfa21d1942c826976a7c7))


## v1.0.2 (2026-02-28)

### Bug Fixes

- Rename PyPI package to gv-specwright (specwright was taken)
  ([`44e3af3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/44e3af3397bb8c4deba4da6f4a11edf89edf3433))


## v1.0.1 (2026-02-28)

### Bug Fixes

- Use version tag for pypi-publish action (Docker-based, SHA pinning unsupported)
  ([`b48f730`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b48f730f7f8d066135010f9ff72b8cb1e55e3df9))


## v1.0.0 (2026-02-28)

- Initial Release
