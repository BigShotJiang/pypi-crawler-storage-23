## 0.1.1 (2026-02-19)

No significant changes.


## 0.1.0 (2026-02-18)

No significant changes.


## 0.3.3 (2026-02-17)

No significant changes.


## 0.3.2 (2026-02-16)

No significant changes.


## 0.3.1 (2026-02-16)

No significant changes.


## 0.3.0 (2026-02-16)

No significant changes.


## 0.2.4 (2026-02-15)

No significant changes.


## 0.2.3 (2026-02-15)

No significant changes.


## 0.2.2 (2026-02-15)

No significant changes.


## 0.2.1 (2026-02-15)

No significant changes.


## 0.2.0 (2026-02-15)

No significant changes.


## 0.1.1 (2026-02-12)

### Misc

- Add README as PyPI project description (add-readme-to-pypi)


## 0.1.0 (2026-02-12)

### Features

- Initial release with CLI support for auto-fixing markdown table alignment (initial-release)
