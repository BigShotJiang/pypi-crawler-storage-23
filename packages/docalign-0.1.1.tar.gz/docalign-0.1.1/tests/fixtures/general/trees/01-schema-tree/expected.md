```
├── src/
│   ├── index.ts
│   └── utils.ts
└── package.json
```
