```
GCP VM boots
    │
    v
bootstrap.sh
    │
    ├── download zip
    ├── extract to /opt
    └── exec main.sh
```
