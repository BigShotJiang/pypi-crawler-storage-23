tasks:
- item um da lista espera-se que devamos fazer tal coisa
- item dois da lista espera-se que outra coisa
- configurar o auto-deploy para producao
- usar o pre-commit hook para validar
