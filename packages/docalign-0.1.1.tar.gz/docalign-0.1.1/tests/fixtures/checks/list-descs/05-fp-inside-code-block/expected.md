example config:

```
- short - description
- much-longer-item - another description
```
