related docs:
- docs/repo.md - local tooling that mirrors CI steps
- docs/guides/testing-strategy.md - test suite run by CI

related sources:
- .github/workflows/callable-ci.yml - reusable CI workflow definition
- .github/workflows/prs.yml - PR trigger workflow
- .github/workflows/push-to-main.yml - main branch trigger workflow
