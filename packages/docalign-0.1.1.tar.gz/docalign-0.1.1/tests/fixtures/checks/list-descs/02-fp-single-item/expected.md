notes:
- docs/repo.md - local tooling that mirrors CI steps

other:
- .github/workflows/prs.yml - PR trigger workflow
