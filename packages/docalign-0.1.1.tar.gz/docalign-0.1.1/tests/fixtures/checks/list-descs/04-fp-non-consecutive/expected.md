references:
- docs/repo.md - local tooling
some paragraph between items
- docs/guide.md - testing strategy

- standalone/item.md - not grouped with above
