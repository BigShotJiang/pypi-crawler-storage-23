```
┌──────────────┐
│ validateAuth │
│ compare with │
└──────────────┘
```
