```
┌──────────────┐
│validateAuth  │
│ compare with │
└──────────────┘
```
