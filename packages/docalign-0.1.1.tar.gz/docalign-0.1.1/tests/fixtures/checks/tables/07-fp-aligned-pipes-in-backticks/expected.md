# Already aligned table with pipes in backticks

| Method     | Command                                  |
|------------|------------------------------------------|
| Native     | `curl -fsSL https://example.com \| bash` |
| PowerShell | `irm https://example.com \| iex`         |
| Simple     | `npm install`                            |
