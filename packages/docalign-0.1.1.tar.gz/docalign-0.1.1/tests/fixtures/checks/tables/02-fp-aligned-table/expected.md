| Name | Type   | Description |
|------|--------|-------------|
| foo  | string | a foo value |
| bar  | number | a bar value |
