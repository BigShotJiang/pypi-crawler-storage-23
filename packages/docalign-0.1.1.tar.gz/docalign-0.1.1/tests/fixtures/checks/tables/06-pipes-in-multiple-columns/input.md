# Pipes in multiple columns

| Input           | Transform         | Output             |
|-----------------|-------------------|--------------------|
| `cat \| head` | `grep \| sort`    | `tee \| less`    |
| `echo foo`      | `tr a-z A-Z`      | `cat`              |
