Use the `cmd | grep` pattern for filtering.

Also `cat file | sort | uniq` works well.
