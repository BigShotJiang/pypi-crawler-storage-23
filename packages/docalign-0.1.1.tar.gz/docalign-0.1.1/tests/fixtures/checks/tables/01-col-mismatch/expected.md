| Service    | Usage                        |
|------------|------------------------------|
| Linear API | Status transitions, comments |
| GitHub API | Repo clone, PR creation      |
