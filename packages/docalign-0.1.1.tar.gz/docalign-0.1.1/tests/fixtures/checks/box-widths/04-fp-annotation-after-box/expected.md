```
┌───────────────┐
│ list_descs.py │  (standalone, no shared deps)
└───────────────┘
```
