links:
- check the docs at https://example.com/guide
- see also http://localhost:3000/api
