config:
- timeout: 30s
- retries: 3
- max-connections: 100
