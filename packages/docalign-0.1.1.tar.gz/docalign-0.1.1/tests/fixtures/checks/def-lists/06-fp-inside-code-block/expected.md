```yaml
- host: localhost
- port: 8080
- timeout: 30s
```
