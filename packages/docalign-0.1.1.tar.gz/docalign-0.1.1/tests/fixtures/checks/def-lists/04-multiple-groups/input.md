server:
- host: localhost
- port: 8080
- timeout: 30s

database:
- driver: postgres
- host: db.local
