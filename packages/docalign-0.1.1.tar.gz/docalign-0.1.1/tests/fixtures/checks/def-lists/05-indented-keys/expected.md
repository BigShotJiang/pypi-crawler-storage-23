options:
  - name:     Alice
  - age:      30
  - location: NYC
