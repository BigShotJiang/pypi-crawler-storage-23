```
┌──────────┐
│  value   │
│  dev     │
└──────────┘
```

The variable v is used here. Use ^ for exponents.
