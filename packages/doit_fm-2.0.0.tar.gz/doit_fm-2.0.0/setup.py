from setuptools import setup, find_packages

setup(
    name="doit-fm",
    version="2.0.0",
    description="Telegram-Controlled Local Automation Engine",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    author="Doit Contributors",
    license="MIT",
    python_requires=">=3.10",
    packages=find_packages(),
    install_requires=[
        "python-telegram-bot>=20.0",
        "aiohttp>=3.9",
        "aiosqlite>=0.19",
        "cryptography>=41.0",
        "psutil>=5.9",
        "apscheduler>=3.10",
        "python-dateutil>=2.8",
        "httpx>=0.25",
        "click>=8.1",
        "rich>=13.0",
        "pydantic>=2.0",
        "aiofiles>=23.0",
    ],
    entry_points={
        "console_scripts": [
            "doit=cli.main:cli",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
