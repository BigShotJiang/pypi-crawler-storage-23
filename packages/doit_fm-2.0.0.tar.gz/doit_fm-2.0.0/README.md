# 🏋️ Doit v2.0 — Your AI-Powered Computer Butler

**Doit** runs silently on your machine and executes *real* OS-level tasks — controlled through Telegram in plain language. From a developer managing servers to a non-technical user who wants to automate their desktop, Doit understands what you mean and does it.

No GUI. No web dashboard. No daily terminal usage. **Just Telegram.**

---

## What's New in v2.0

| Category | New in v2.0 |
|----------|-------------|
| **Shell** | `shell_exec` — run any command; `repl_python`, `repl_js` — run code snippets |
| **Git** | Full git workflow: status, pull, add, commit, push, clone, log, diff, branch |
| **Docker** | List, start, stop, exec, logs, images |
| **Packages** | Install/uninstall via apt/brew/pip/npm/cargo/winget (auto-detected) |
| **SSH/SFTP** | Run commands on remote hosts; upload/download via SCP |
| **Desktop** | Open apps, desktop notifications, screenshot, clipboard r/w, type text, hotkeys, volume, TTS |
| **Dev Tools** | Run tests (pytest/jest), lint (ruff/flake8), format (black/prettier), build (make/npm/cargo) |
| **Files+** | PDF text extract + merge, image resize/convert, CSV read, JSON query, file hash, QR gen |
| **Web** | DuckDuckGo search, web page scraping, webhook POST |
| **Productivity** | Math calculator, translate (LibreTranslate), weather (no key needed), timed reminders |
| **Memory** | Persistent named facts (`remember X is Y`, recall later) |
| **Notes & Todo** | Full CRUD notes (Markdown) and todo list with priorities |
| **Secrets** | Encrypted keychain — store API keys, passwords; AI auto-fetches when needed |
| **AI Engine** | Dynamic tool discovery (prompts always match live tools), multi-turn conversation context |
| **Telegram UX** | Inline confirm buttons for dangerous ops, voice message support, `/tools`, `/memory`, `/run`, `/clear` |

---

## Quick Start

```bash
pip install doit-fm
doit init
```

The wizard:
1. Trust grant (once)
2. AI provider & model selection
3. Telegram bot setup
4. Auto-start service installation

Then just **talk to your bot**.

---

## What Doit Can Do

### Files & Folders
```
list files in ~/Downloads
find all .log files older than 7 days and delete them
find duplicates in ~/Pictures
diff requirements.txt with requirements.old.txt
organize my Downloads folder
backup ~/Documents to ~/Backups every day at 9am
```

### System
```
show system health
what's using the most RAM?
kill process 1234
check battery status
how much disk space is left on /?
```

### Shell / Code
```
run: ls -la ~/Projects
execute this Python: print(sum(range(100)))
run my tests in ~/myapp
lint the code in ~/myproject
build the project in ~/myapp
```

### Git
```
git status of ~/myproject
pull the latest code in ~/myrepo
commit everything in ~/myproject with message "fix login bug"
push ~/myproject to origin
show git log for ~/myproject
clone https://github.com/user/repo to ~/Projects
```

### Docker
```
list all my containers
start the postgres container
show logs for the api container
run "npm test" in the webapp container
list docker images
```

### Packages
```
install htop
install pandas with pip
uninstall imagemagick
```

### Network & Web
```
download https://example.com/report.pdf to ~/Desktop
ping google.com
search DuckDuckGo for "python asyncio best practices"
scrape text from https://docs.python.org/3/
send a webhook to https://hooks.zapier.com/... with payload {"event": "deploy"}
check if https://mysite.com is up
```

### Remote (SSH)
```
run "df -h" on server 192.168.1.100 as ubuntu
upload ~/deploy.tar.gz to user@host:/tmp/
```

### Desktop Automation
```
open Safari
take a screenshot
read my clipboard
write "Hello World" to clipboard
type this text: "Dear John,"
send notification: Meeting in 5 minutes
set volume to 60
say "your build is complete"
```

### Development
```
run tests in ~/myproject
lint ~/myproject/src
format code in ~/myproject
build ~/myproject
```

### Productivity
```
what's the weather in London?
translate "hello world" to Spanish
calculate 15% of 847.50
remind me to take a break in 25 minutes
generate a QR code for https://mysite.com
hash the file ~/important.zip
```

### Memory & Notes
```
remember that my prod server is 10.0.0.5
what did you remember?
create a note called "meeting notes" with content "..."
list my notes
add todo: review PRs - high priority
list todos
mark done: review PRs
```

### Secrets
```
store secret GITHUB_TOKEN = ghp_xxxx
get my GITHUB_TOKEN
```

---

## Architecture

```
doit/
├── cli/              # Bootstrap + onboarding wizard
├── core/             # Config, constants, paths
├── ai/               # Multi-provider AI engine (dynamic tools, conversation memory)
├── telegram_bot/     # Telegram interface (inline buttons, voice, docs, photos)
├── tools/            # 70+ tool implementations across 15 categories
├── task_engine/      # Async queue, workers, retry, resource guard
├── scheduler/        # Natural language + cron scheduler
├── security/         # Encryption, auth, injection guard, secret keychain
├── persistence/      # SQLite: tasks, schedules, logs, audit, memory
├── plugins/          # Dynamic plugin discovery (add your own tools)
├── services/         # systemd / LaunchAgent / Windows service
├── supervisor/       # Crash recovery + auto-restart
├── logging_system/   # Structured logging to file + DB
└── updates/          # Safe version updates + rollback
```

---

## AI Providers

| Provider | Free Tier | Notes |
|----------|-----------|-------|
| **NVIDIA NIM** | ✅ Llama 3.3 70B | High quality, free |
| **Zhipu AI** | ✅ GLM-4 Flash | Fast, free |
| **OpenAI** | — | GPT-4o recommended |
| **Anthropic** | — | Claude 3.5 Sonnet recommended |
| **Ollama** | ✅ All models | Fully offline, privacy-first |
| **Custom** | Any OpenAI-compatible | Your own endpoint |

---

## Security Model

- **Single user** — only your Telegram ID can control Doit
- **Encrypted config & secrets** — Fernet symmetric encryption
- **Tool sandboxing** — AI can only invoke registered tools
- **Injection protection** — pattern-based prompt injection detection
- **Dangerous op confirmation** — inline ✅/❌ buttons before destructive actions
- **Path blocklist** — /etc, /boot, /sys, /proc protected
- **No inbound ports** — outbound-only to Telegram API
- **Full audit trail** — every action logged to SQLite

---

## Plugin API

Drop a `.py` file in `~/.config/doit/plugins/`:

```python
PLUGIN_NAME = "my_plugin"
PLUGIN_VERSION = "1.0.0"
PLUGIN_DOIT_MIN_VERSION = "2.0.0"
PLUGIN_DESCRIPTION = "What this plugin does"

async def my_tool(arg1: str, count: int = 1, **kwargs) -> dict:
    return {"result": f"Did {arg1} x{count}", "success": True}

TOOLS = [
    ("my_tool", "Description of my tool", my_tool, False),
]
```

Restart Doit. Your tool is now available to the AI — the system prompt updates automatically.

---

## CLI

```bash
doit init        # Onboarding wizard
doit run         # Start agent
doit update      # Check and install updates
doit status      # Check if service running
doit uninstall   # Remove service + optionally data
```

---

## Telegram Commands

```
/status    — Agent status + AI health
/health    — System resources + battery
/tasks     — Recent task history
/logs      — Recent log entries
/tools     — Browse all 70+ available tools
/memory    — View stored facts
/clear     — Reset conversation context
/run <cmd> — Direct shell command
/safe      — Pause execution
/resume    — Resume execution
/export    — Download audit log (json/csv)
/help      — Full help
```

---

## Requirements

- Python 3.10+
- A Telegram bot token (free, from @BotFather)
- An AI API key (NVIDIA/Zhipu free, or OpenAI/Anthropic/Ollama)

**Optional for full power:**
- `git` for git tools
- `docker` for Docker tools
- `ssh`/`scp` for remote tools
- `scrot` (Linux) / built-in (macOS/Windows) for screenshots
- `notify-send` (Linux) for desktop notifications
- `espeak` (Linux) / built-in (macOS/Windows) for TTS
- `xdotool` (Linux) for type_text / hotkeys

---

## License

MIT — free to use, modify, distribute.
