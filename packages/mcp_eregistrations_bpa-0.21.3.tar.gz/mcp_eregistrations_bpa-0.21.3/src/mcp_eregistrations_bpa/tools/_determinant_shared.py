"""Shared helpers for building BPA determinant reference JSON.

The BPA UI stores determinant references (not inline JSONLogic) in the
jsonDeterminants field. Both component behaviours (effects) and component
actions use the same format.
"""

from __future__ import annotations

import json

__all__ = [
    "build_determinant_refs",
]


def build_determinant_refs(determinant_ids: list[str], logic: str) -> str:
    """Build stringified determinant reference JSON for jsonDeterminants.

    The UI query-builder expects the format::

        [{"type":"AND","items":[{"type":"AND","determinantId":"<uuid>"}, ...]}]

    The backend resolves these references at publish time (DataWeave).

    Args:
        determinant_ids: List of determinant UUIDs.
        logic: "AND" or "OR" for combining conditions.

    Returns:
        str: Stringified JSON matching the UI reference format.
    """
    logic_type = logic.upper()
    items = [
        {"type": logic_type, "determinantId": det_id} for det_id in determinant_ids
    ]
    # Wrap in array — the UI always stores an array of groups
    return json.dumps([{"type": logic_type, "items": items}])
