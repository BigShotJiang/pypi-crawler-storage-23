#!/usr/bin/env python3
"""MCP server entry point."""

from kevros_governance.mcp_server import main

if __name__ == "__main__":
    main()
