"""Kevros Governance SDK models."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Decision(str, Enum):
    ALLOW = "ALLOW"
    CLAMP = "CLAMP"
    DENY = "DENY"


class IntentType(str, Enum):
    NAVIGATION = "NAVIGATION"
    MANIPULATION = "MANIPULATION"
    SENSING = "SENSING"
    COMMUNICATION = "COMMUNICATION"
    MAINTENANCE = "MAINTENANCE"
    EMERGENCY = "EMERGENCY"
    OPERATOR_COMMAND = "OPERATOR_COMMAND"
    AI_GENERATED = "AI_GENERATED"
    AUTOMATED = "AUTOMATED"


class IntentSource(str, Enum):
    HUMAN_OPERATOR = "HUMAN_OPERATOR"
    AI_PLANNER = "AI_PLANNER"
    MISSION_SCRIPT = "MISSION_SCRIPT"
    REMOTE_API = "REMOTE_API"
    SENSOR_TRIGGER = "SENSOR_TRIGGER"
    INTERNAL = "INTERNAL"


class OutcomeStatus(str, Enum):
    ACHIEVED = "ACHIEVED"
    PARTIALLY_ACHIEVED = "PARTIALLY_ACHIEVED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    TIMEOUT = "TIMEOUT"


@dataclass
class VerifyResponse:
    decision: Decision
    verification_id: str
    reason: str
    epoch: int
    provenance_hash: str
    timestamp_utc: str
    release_token: Optional[str] = None
    applied_action: Optional[Dict[str, Any]] = None
    policy_applied: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> VerifyResponse:
        return cls(
            decision=Decision(d["decision"]),
            verification_id=d["verification_id"],
            release_token=d.get("release_token"),
            applied_action=d.get("applied_action"),
            policy_applied=d.get("policy_applied"),
            reason=d.get("reason", ""),
            epoch=d["epoch"],
            provenance_hash=d["provenance_hash"],
            timestamp_utc=d["timestamp_utc"],
        )


@dataclass
class AttestResponse:
    attestation_id: str
    epoch: int
    hash_prev: str
    hash_curr: str
    timestamp_utc: str
    chain_length: int
    pqc_block_ref: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> AttestResponse:
        return cls(
            attestation_id=d["attestation_id"],
            epoch=d["epoch"],
            hash_prev=d["hash_prev"],
            hash_curr=d["hash_curr"],
            pqc_block_ref=d.get("pqc_block_ref"),
            timestamp_utc=d["timestamp_utc"],
            chain_length=d["chain_length"],
        )


@dataclass
class BindIntentResponse:
    intent_id: str
    intent_hash: str
    binding_id: str
    binding_hmac: str
    command_hash: str
    epoch: int
    timestamp_utc: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> BindIntentResponse:
        return cls(
            intent_id=d["intent_id"],
            intent_hash=d["intent_hash"],
            binding_id=d["binding_id"],
            binding_hmac=d["binding_hmac"],
            command_hash=d["command_hash"],
            epoch=d["epoch"],
            timestamp_utc=d["timestamp_utc"],
        )


@dataclass
class VerifyOutcomeResponse:
    verification_id: str
    intent_id: str
    status: OutcomeStatus
    achieved_percentage: float
    evidence_hash: str
    timestamp_utc: str
    discrepancy: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> VerifyOutcomeResponse:
        return cls(
            verification_id=d["verification_id"],
            intent_id=d["intent_id"],
            status=OutcomeStatus(d["status"]),
            achieved_percentage=d["achieved_percentage"],
            discrepancy=d.get("discrepancy"),
            evidence_hash=d["evidence_hash"],
            timestamp_utc=d["timestamp_utc"],
        )


@dataclass
class BundleResponse:
    bundle_id: str
    agent_id: str
    record_count: int
    chain_integrity: bool
    time_range: Dict[str, str]
    records: List[Dict[str, Any]]
    bundle_hash: str
    timestamp_utc: str
    intent_chains: Optional[List[Dict[str, Any]]] = None
    pqc_signatures: Optional[List[Dict[str, Any]]] = None
    verification_instructions: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> BundleResponse:
        return cls(
            bundle_id=d["bundle_id"],
            agent_id=d["agent_id"],
            record_count=d["record_count"],
            chain_integrity=d["chain_integrity"],
            time_range=d["time_range"],
            records=d["records"],
            intent_chains=d.get("intent_chains"),
            pqc_signatures=d.get("pqc_signatures"),
            verification_instructions=d.get("verification_instructions"),
            bundle_hash=d["bundle_hash"],
            timestamp_utc=d["timestamp_utc"],
        )


@dataclass
class GatewayHealth:
    service: str
    status: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> GatewayHealth:
        return cls(
            service=d["service"],
            status=d["status"],
        )
