"""MCP server entry point."""

from kevros_governance.mcp_server import main

main()
