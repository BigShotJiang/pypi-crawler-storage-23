"""Kevros Governance SDK."""

__version__ = "0.2.3"

from .auto_signup import get_or_create_api_key
from .client import GovernanceClient
from .models import (
    AttestResponse,
    BindIntentResponse,
    BundleResponse,
    Decision,
    GatewayHealth,
    IntentSource,
    IntentType,
    OutcomeStatus,
    VerifyOutcomeResponse,
    VerifyResponse,
)

__all__ = [
    "GovernanceClient",
    "get_or_create_api_key",
    "Decision",
    "IntentType",
    "IntentSource",
    "OutcomeStatus",
    "VerifyResponse",
    "AttestResponse",
    "BindIntentResponse",
    "VerifyOutcomeResponse",
    "BundleResponse",
    "GatewayHealth",
]
