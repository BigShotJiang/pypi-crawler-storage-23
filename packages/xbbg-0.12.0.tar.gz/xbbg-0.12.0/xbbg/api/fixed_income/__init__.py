"""Bloomberg Fixed Income API.

Provides convenience functions for fixed income analytics including
yield and spread analysis (YAS) and bond analytics.
"""

from xbbg.ext.bonds import *

from .yas import *
