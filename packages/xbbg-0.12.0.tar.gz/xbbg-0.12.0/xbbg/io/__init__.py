"""I/O utilities for caching and data conversion.

This package contains internal utilities for:
- cache: Cache path resolution, adapters, and lookup for Bloomberg data
- convert: Backend conversion and output formatting
"""
