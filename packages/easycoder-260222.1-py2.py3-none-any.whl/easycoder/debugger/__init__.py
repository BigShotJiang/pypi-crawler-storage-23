"""EasyCoder debugger module"""

from .ec_debug import Debugger

__all__ = ['Debugger']
