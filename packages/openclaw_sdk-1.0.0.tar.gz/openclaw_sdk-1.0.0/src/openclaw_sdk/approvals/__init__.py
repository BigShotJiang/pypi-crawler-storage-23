"""OpenClaw execution approval manager."""

from openclaw_sdk.approvals.manager import ApprovalManager

__all__ = ["ApprovalManager"]
