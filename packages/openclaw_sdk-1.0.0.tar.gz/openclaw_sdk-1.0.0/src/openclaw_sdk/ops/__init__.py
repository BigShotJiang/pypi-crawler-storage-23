"""OpenClaw operations manager (logs, updates, usage)."""

from openclaw_sdk.ops.manager import OpsManager

__all__ = ["OpsManager"]
