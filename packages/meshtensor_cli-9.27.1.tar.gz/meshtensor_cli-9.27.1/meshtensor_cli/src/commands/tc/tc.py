"""
Technical Committee (TC) commands for meshcli.

Provides commands for interacting with the elected Technical Committee:
- List current TC members
- List TC election candidates
- Vote in TC elections
"""

import asyncio
import json
from typing import TYPE_CHECKING, Optional

from meshtensor_wallet import Wallet
from rich import box
from rich.table import Column, Table

from meshtensor_cli.src.meshtensor.utils import (
    confirm_action,
    console,
    print_error,
    print_success,
    unlock_key,
    json_console,
    print_extrinsic_id,
)

if TYPE_CHECKING:
    from meshtensor_cli.src.meshtensor.meshtensor_interface import MeshtensorInterface


# ============================================================================
# meshcli tc members
# ============================================================================

async def tc_members(
    subtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List current Technical Committee members."""

    try:
        members = await subtensor.substrate.query(
            module="TechnicalMembership",
            storage_function="Members",
        )

        member_list = members.value if members else []

        if output_json:
            json_console.print_json(json.dumps({"members": member_list}, default=str))
            return

        if not member_list:
            console.print("[dim]No Technical Committee members found.[/dim]")
            return

        console.print(f"\n[bold]Technical Committee Members ({len(member_list)})[/bold]")

        table = Table(
            Column("#", style="bold"),
            Column("Account", style="cyan"),
            title=f"TC Members (adaptive size: {len(member_list)} seats)",
            box=box.ROUNDED,
        )

        for i, member in enumerate(member_list, 1):
            account_str = str(member)
            table.add_row(str(i), account_str)

        console.print(table)

        # Show adaptive sizing info
        if len(member_list) <= 5:
            console.print("[dim]Current phase: 5 seats (initial)[/dim]")
        elif len(member_list) <= 7:
            console.print("[dim]Current phase: 7 seats (network growth)[/dim]")
        else:
            console.print("[dim]Current phase: 9 seats (mature network)[/dim]")

    except Exception as e:
        print_error(f"Error fetching TC members: {e}")


# ============================================================================
# meshcli tc candidates
# ============================================================================

async def tc_candidates(
    subtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List TC election candidates."""

    try:
        candidates = await subtensor.substrate.query(
            module="Elections",
            storage_function="Candidates",
        )

        candidate_list = candidates.value if candidates else []

        if output_json:
            json_console.print_json(
                json.dumps({"candidates": candidate_list}, default=str)
            )
            return

        if not candidate_list:
            console.print("[dim]No TC election candidates found.[/dim]")
            return

        table = Table(
            Column("#", style="bold"),
            Column("Candidate", style="cyan"),
            Column("Deposit", style="yellow"),
            title="TC Election Candidates",
            box=box.ROUNDED,
        )

        for i, (candidate, deposit) in enumerate(candidate_list, 1):
            table.add_row(
                str(i),
                str(candidate),
                f"{deposit / 1e9:.4f} MESH" if isinstance(deposit, (int, float)) else str(deposit),
            )

        console.print(table)

    except Exception as e:
        print_error(f"Error fetching TC candidates: {e}")


# ============================================================================
# meshcli tc vote
# ============================================================================

async def tc_vote(
    subtensor: "MeshtensorInterface",
    wallet: Wallet,
    candidates: list[str],
    stake: float,
    quiet: bool = False,
    verbose: bool = False,
):
    """Vote in a TC election."""

    stake_raw = int(stake * 1e9)

    if not quiet:
        console.print(f"\n[bold]Voting in TC Election[/bold]")
        console.print(f"  Candidates: {len(candidates)}")
        for c in candidates:
            console.print(f"    - {c[:16]}...")
        console.print(f"  Stake: {stake} MESH")

    if not confirm_action("Cast TC election vote?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await subtensor.substrate.compose_call(
            call_module="Elections",
            call_function="vote",
            call_params={
                "votes": candidates,
                "value": stake_raw,
            },
        )

        extrinsic = await subtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await subtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if response.is_success:
            print_success(f"TC election vote cast for {len(candidates)} candidate(s)")
            print_extrinsic_id(response)
        else:
            print_error(f"Failed to vote: {response.error_message}")
    except Exception as e:
        print_error(f"Error voting in TC election: {e}")
