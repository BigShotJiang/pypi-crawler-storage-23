"""
Treasury commands for meshcli.

Provides commands for interacting with the Meshtensor on-chain treasury:
- Submit treasury spend proposals
- List active proposals
- View treasury balance
"""

import asyncio
import json
from typing import TYPE_CHECKING, Optional

from meshtensor_wallet import Wallet
from rich import box
from rich.table import Column, Table

from meshtensor_cli.src.meshtensor.utils import (
    confirm_action,
    console,
    print_error,
    print_success,
    unlock_key,
    json_console,
    print_extrinsic_id,
)

if TYPE_CHECKING:
    from meshtensor_cli.src.meshtensor.meshtensor_interface import MeshtensorInterface


# ============================================================================
# meshcli treasury propose
# ============================================================================

async def treasury_propose(
    subtensor: "MeshtensorInterface",
    wallet: Wallet,
    value: float,
    beneficiary: str,
    description: str = "",
    quiet: bool = False,
    verbose: bool = False,
):
    """Submit a treasury spend proposal."""

    value_raw = int(value * 1e9)  # Convert MESH to meshlet

    if not quiet:
        console.print(f"\n[bold]Submitting Treasury Proposal[/bold]")
        console.print(f"  Amount: {value} MESH ({value_raw} meshlet)")
        console.print(f"  Beneficiary: {beneficiary}")
        if description:
            console.print(f"  Description: {description}")

    if not confirm_action("Submit this treasury proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await subtensor.substrate.compose_call(
            call_module="Treasury",
            call_function="propose_spend",
            call_params={
                "value": value_raw,
                "beneficiary": beneficiary,
            },
        )

        extrinsic = await subtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await subtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if response.is_success:
            print_success(f"Treasury proposal submitted: {value} MESH to {beneficiary[:8]}...{beneficiary[-8:]}")
            print_extrinsic_id(response)
        else:
            print_error(f"Failed to submit proposal: {response.error_message}")
    except Exception as e:
        print_error(f"Error submitting treasury proposal: {e}")


# ============================================================================
# meshcli treasury list
# ============================================================================

async def treasury_list(
    subtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List active treasury proposals."""

    try:
        proposals = await subtensor.substrate.query_map(
            module="Treasury",
            storage_function="Proposals",
        )

        results = []
        async for proposal_id, proposal_info in proposals:
            pid = proposal_id.value if hasattr(proposal_id, "value") else proposal_id
            data = proposal_info.value if hasattr(proposal_info, "value") else proposal_info
            results.append({
                "id": pid,
                "proposer": data.get("proposer", "Unknown"),
                "value": data.get("value", 0),
                "beneficiary": data.get("beneficiary", "Unknown"),
                "bond": data.get("bond", 0),
            })

        if output_json:
            json_console.print_json(json.dumps(results, default=str))
            return

        if not results:
            console.print("[dim]No active treasury proposals.[/dim]")
            return

        table = Table(
            Column("ID", style="bold"),
            Column("Value (MESH)", style="green"),
            Column("Beneficiary", style="cyan"),
            Column("Bond (MESH)", style="yellow"),
            title="Active Treasury Proposals",
            box=box.ROUNDED,
        )

        for p in sorted(results, key=lambda x: x["id"]):
            table.add_row(
                str(p["id"]),
                f"{p['value'] / 1e9:.4f}",
                str(p["beneficiary"])[:16] + "...",
                f"{p['bond'] / 1e9:.4f}",
            )

        console.print(table)

    except Exception as e:
        print_error(f"Error listing treasury proposals: {e}")


# ============================================================================
# meshcli treasury balance
# ============================================================================

async def treasury_balance(
    subtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show the treasury balance."""

    try:
        # Query treasury account balance
        # The treasury account is derived from the PalletId
        treasury_account = await subtensor.substrate.query(
            module="Treasury",
            storage_function="Pot",
        )

        balance = treasury_account.value if treasury_account else 0

        # Also query the governance reward pool
        gov_pool = await subtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="GovernanceRewardPool",
        )

        gov_balance = gov_pool.value if gov_pool else 0

        if output_json:
            data = {
                "treasury_balance": balance,
                "treasury_balance_mesh": balance / 1e9,
                "governance_reward_pool": gov_balance,
                "governance_reward_pool_mesh": gov_balance / 1e9,
            }
            json_console.print_json(json.dumps(data))
            return

        console.print(f"\n[bold]Treasury Status[/bold]")
        console.print(f"  Treasury Balance: [green]{balance / 1e9:.4f} MESH[/green]")
        console.print(f"  Governance Reward Pool: [yellow]{gov_balance / 1e9:.4f} MESH[/yellow]")

    except Exception as e:
        print_error(f"Error fetching treasury balance: {e}")
