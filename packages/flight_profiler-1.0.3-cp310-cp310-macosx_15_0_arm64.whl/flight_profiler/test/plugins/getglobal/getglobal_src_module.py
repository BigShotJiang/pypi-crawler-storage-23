class TestClass:
    VARB = "hello"

    def __init__(self):
        pass


global_varA = 3

global_list = [1, 2, 3]

global_dict = {"hello": "world"}
