def test_func():
    # Original implementation
    return "original"
