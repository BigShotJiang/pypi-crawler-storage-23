def test_func():
    # Modified implementation
    return "modified"
