# for server script to import
def target_func():
    return 1
