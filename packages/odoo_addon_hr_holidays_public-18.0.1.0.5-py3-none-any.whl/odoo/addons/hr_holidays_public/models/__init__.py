# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import hr_employee
from . import hr_leave
from . import hr_leave_type
from . import resource_calendar
from . import res_partner
from . import res_users
