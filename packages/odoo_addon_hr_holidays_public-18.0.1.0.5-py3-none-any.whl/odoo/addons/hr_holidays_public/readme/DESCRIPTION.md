The calculation of each leave can exclude rest public holiday, depending
on the leave type configuration.

In HR holiday app, public holiday will be displayed as unusual days
(grey like weekends).
