# Drift Detection Strategies

Choose the right strategy based on your target types and operational needs.

## Common Strategies

- Scheduled drift checks in CI/CD
- On-demand checks before deployment
- Monitoring hooks for sensitive targets

## Tips

- Focus on high-risk secrets first
- Use lockfile hash comparison for reliable detection
