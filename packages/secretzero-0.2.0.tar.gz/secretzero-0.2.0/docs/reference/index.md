# Reference

Authoritative reference material for SecretZero.

## Contents

- [Architecture](architecture.md)
- [Data Models](models.md)
- [API - Interactive](api-interactive.md)
- [API - Python](api-python.md)
- [CLI - Basics](cli.md)
- [CLI - Auto-Reference](cli-auto.md)
- [Security](security.md)
- [FAQ](faq.md)
- [Troubleshooting](troubleshooting.md)
- [Changelog](changelog.md)
