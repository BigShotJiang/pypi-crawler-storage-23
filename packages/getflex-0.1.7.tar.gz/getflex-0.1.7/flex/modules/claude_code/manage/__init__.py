"""Claude Code manage — offline enrichment for claude-code cells.

Exports cell-specific config that the generic meditate.py and enrichment
scripts consume. The generic primitives never know about warmups, agent
sessions, or tool name mappings.
"""
