"""Mousse — web-based mouse movement recorder for PX press-and-hold solver."""
