"""
MasteryTrack Exceptions

Re-exports common errors and adds MasteryTrack-specific exceptions.
"""

from timeback_common import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)

MasteryTrackError = TimebackError


__all__ = [
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "InputValidationError",
    "MasteryTrackError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "create_input_validation_error",
]
