"""
MasteryTrack Base Types

Foundational types for MasteryTrack client configuration.
"""

from __future__ import annotations

from typing import Literal, TypedDict

MasteryTrackEnvironment = Literal["staging", "production"]


class MasteryTrackAuth(TypedDict):
    """Credentials used for MasteryTrack authentication."""

    api_key: str
    email: str


__all__ = [
    "MasteryTrackAuth",
    "MasteryTrackEnvironment",
]
