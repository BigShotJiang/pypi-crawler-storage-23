"""
MasteryTrack Response Types

Pydantic models for MasteryTrack API responses.
Mirrors the TypeScript protocol types.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class MasteryTrackAuthorizerResponse(BaseModel):
    """Authorizer success payload."""

    success: bool = True
    jwt: str


class MasteryTrackInventoryMetadata(BaseModel):
    """Metadata attached to an inventory item."""

    model_config = {"extra": "allow", "populate_by_name": True}

    url: str | None = None
    type: str | None = None
    sub_type: str | None = Field(default=None, alias="subType")
    year: str | None = None
    format: str | None = None
    question_types: list[str] | None = Field(default=None, alias="questionTypes")


class MasteryTrackInventoryItem(BaseModel):
    """A single test in the MasteryTrack inventory."""

    id: int
    timeback_id: str
    name: str
    subject: str
    grade: str
    grade_rank: int
    version: int
    active: bool
    metadata: MasteryTrackInventoryMetadata | None = None
    supported: bool
    created_at: str
    updated_at: str
    invalidated_on: str | None = None


class MasteryTrackInventorySearchResponse(BaseModel):
    """Inventory search response envelope."""

    success: bool = True
    data: list[MasteryTrackInventoryItem]


class MasteryTrackAssignment(BaseModel):
    """A single test assignment."""

    id: int
    student_email: str
    test_name: str
    assigned_by: int | None = None
    test_url: str
    status: str
    expires_at: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str


class MasteryTrackAssignResponseData(BaseModel):
    """Inner data for assignment response."""

    assignment: MasteryTrackAssignment
    message: str


class MasteryTrackAssignResponse(BaseModel):
    """Assignment response envelope."""

    success: bool = True
    platform: str | None = None
    data: MasteryTrackAssignResponseData


class MasteryTrackInvalidatedAssignment(BaseModel):
    """An assignment that was invalidated."""

    assignment_id: int
    student_email: str


class MasteryTrackInvalidateResponseData(BaseModel):
    """Inner data for invalidation response."""

    message: str
    total_invalidated: int
    invalidated_assignments: list[MasteryTrackInvalidatedAssignment]


class MasteryTrackInvalidateResponse(BaseModel):
    """Invalidation response envelope."""

    success: bool = True
    data: MasteryTrackInvalidateResponseData


__all__ = [
    "MasteryTrackAssignResponse",
    "MasteryTrackAssignResponseData",
    "MasteryTrackAssignment",
    "MasteryTrackAuthorizerResponse",
    "MasteryTrackInvalidateResponse",
    "MasteryTrackInvalidateResponseData",
    "MasteryTrackInvalidatedAssignment",
    "MasteryTrackInventoryItem",
    "MasteryTrackInventoryMetadata",
    "MasteryTrackInventorySearchResponse",
]
