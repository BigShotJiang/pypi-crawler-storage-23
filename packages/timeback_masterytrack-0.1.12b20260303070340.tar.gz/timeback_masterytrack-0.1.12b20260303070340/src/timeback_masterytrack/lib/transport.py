"""
MasteryTrack Transport Layer

HTTP transport for MasteryTrack API communication.
MasteryTrack expects auth via ``X-Auth-Token`` (Bearer JWT) header
rather than the standard ``Authorization`` header.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from timeback_common import BaseTransport

if TYPE_CHECKING:
    from .token_provider import MasteryTrackJwtProvider


class Transport(BaseTransport):
    """HTTP transport layer for MasteryTrack API communication."""

    def __init__(
        self,
        *,
        base_url: str,
        jwt_provider: MasteryTrackJwtProvider,
        timeout: float = 30.0,
    ) -> None:
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            no_auth=True,
        )
        self._jwt_provider = jwt_provider

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """Make an authenticated request with X-Auth-Token header."""
        token = await self._jwt_provider.get_token()
        merged_headers = {**(headers or {}), "X-Auth-Token": f"Bearer {token}"}
        return await super().request(
            method,
            path,
            json=json,
            params=params,
            headers=merged_headers,
            request_id=request_id,
        )

    async def request_raw(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        request_id: str | None = None,
    ) -> Any:
        """Make an authenticated raw request with X-Auth-Token header."""
        token = await self._jwt_provider.get_token()
        merged_headers = {**(headers or {}), "X-Auth-Token": f"Bearer {token}"}
        return await super().request_raw(
            method,
            path,
            json=json,
            params=params,
            headers=merged_headers,
            request_id=request_id,
        )

    def _handle_error(
        self,
        status: int,
        body: Any,
        text: str,
        request_id: str,
    ) -> None:
        """Override to invalidate JWT on 401 before raising."""
        if status == 401:
            self._jwt_provider.invalidate()
        super()._handle_error(status, body, text, request_id)


__all__ = ["Transport"]
