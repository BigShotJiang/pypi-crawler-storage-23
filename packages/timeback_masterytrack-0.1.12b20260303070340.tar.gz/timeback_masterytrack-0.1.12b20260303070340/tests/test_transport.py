"""Tests for MasteryTrack Transport layer."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from timeback_common import AuthenticationError, ForbiddenError
from timeback_masterytrack.lib.token_provider import MasteryTrackJwtProvider
from timeback_masterytrack.lib.transport import Transport


def _make_jwt_provider(token: str = "test-jwt-token") -> MasteryTrackJwtProvider:
    """Create a mock-friendly JWT provider."""
    provider = MagicMock(spec=MasteryTrackJwtProvider)
    provider.get_token = AsyncMock(return_value=token)
    provider.invalidate = MagicMock()
    return provider


def _make_httpx_response(
    status_code: int = 200,
    json_data: dict | None = None,
    headers: dict | None = None,
) -> httpx.Response:
    """Create a mock httpx.Response."""
    content = b"{}"
    if json_data is not None:
        import json

        content = json.dumps(json_data).encode()
    resp = httpx.Response(
        status_code=status_code,
        content=content,
        headers=headers or {"content-type": "application/json"},
        request=httpx.Request("GET", "https://example.com/test"),
    )
    return resp


class TestTransportAuthHeader:
    """Tests for X-Auth-Token header injection."""

    @pytest.mark.asyncio
    async def test_injects_x_auth_token_header(self):
        """Transport should inject X-Auth-Token header with Bearer JWT."""
        provider = _make_jwt_provider("my-jwt")
        transport = Transport(
            base_url="https://example.com/api",
            jwt_provider=provider,
        )

        mock_response = _make_httpx_response(200, {"success": True})
        with patch.object(transport, "_get_client") as mock_client:
            client = AsyncMock()
            client.request = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            await transport.request("GET", "/test-endpoint")

            call_kwargs = client.request.call_args
            headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers", {})
            assert headers["X-Auth-Token"] == "Bearer my-jwt"

    @pytest.mark.asyncio
    async def test_preserves_existing_headers(self):
        """Transport should preserve custom headers alongside JWT header."""
        provider = _make_jwt_provider()
        transport = Transport(
            base_url="https://example.com/api",
            jwt_provider=provider,
        )

        mock_response = _make_httpx_response(200, {"success": True})
        with patch.object(transport, "_get_client") as mock_client:
            client = AsyncMock()
            client.request = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            await transport.request("GET", "/test-endpoint", headers={"X-Custom": "value"})

            call_kwargs = client.request.call_args
            headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers", {})
            assert headers["X-Auth-Token"] == "Bearer test-jwt-token"
            assert headers["X-Custom"] == "value"


class TestTransportJwtInvalidation:
    """Tests for JWT invalidation on error responses."""

    @pytest.mark.asyncio
    async def test_invalidates_jwt_on_401(self):
        """Transport should invalidate JWT on 401 response."""
        provider = _make_jwt_provider()
        transport = Transport(
            base_url="https://example.com/api",
            jwt_provider=provider,
        )

        mock_response = _make_httpx_response(401, {"error": "Unauthorized"})
        with patch.object(transport, "_get_client") as mock_client:
            client = AsyncMock()
            client.request = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            with pytest.raises(AuthenticationError):
                await transport.request("GET", "/protected")

            provider.invalidate.assert_called_once()

    @pytest.mark.asyncio
    async def test_does_not_invalidate_on_non_401(self):
        """Transport should not invalidate JWT on non-401 errors."""
        provider = _make_jwt_provider()
        transport = Transport(
            base_url="https://example.com/api",
            jwt_provider=provider,
        )

        mock_response = _make_httpx_response(403, {"error": "Forbidden"})
        with patch.object(transport, "_get_client") as mock_client:
            client = AsyncMock()
            client.request = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            with pytest.raises(ForbiddenError):
                await transport.request("GET", "/protected")

            provider.invalidate.assert_not_called()

    @pytest.mark.asyncio
    async def test_invalidates_jwt_on_401_raw(self):
        """request_raw should also invalidate JWT on 401 response."""
        provider = _make_jwt_provider()
        transport = Transport(
            base_url="https://example.com/api",
            jwt_provider=provider,
        )

        mock_response = _make_httpx_response(401, {"error": "Unauthorized"})
        with patch.object(transport, "_get_client") as mock_client:
            client = AsyncMock()
            client.request = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            with pytest.raises(AuthenticationError):
                await transport.request_raw("GET", "/protected")

            provider.invalidate.assert_called_once()
