"""Tests for MasteryTrack input type validation."""

import pytest
from pydantic import ValidationError

from timeback_masterytrack import (
    MasteryTrackAssignmentInput,
    MasteryTrackAuthorizerInput,
    MasteryTrackInvalidateAssignmentInput,
    MasteryTrackInventorySearchParams,
)


class TestAuthorizerInput:
    """Tests for MasteryTrackAuthorizerInput validation."""

    def test_valid_email(self):
        """Should accept a valid email."""
        result = MasteryTrackAuthorizerInput(email="user@example.com")
        assert result.email == "user@example.com"

    def test_invalid_email_rejects(self):
        """Should reject invalid email format."""
        with pytest.raises(ValidationError):
            MasteryTrackAuthorizerInput(email="not-an-email")

    def test_empty_email_rejects(self):
        """Should reject empty email."""
        with pytest.raises(ValidationError):
            MasteryTrackAuthorizerInput(email="")


class TestInventorySearchParams:
    """Tests for MasteryTrackInventorySearchParams validation."""

    def test_empty_params(self):
        """Should accept empty params (all optional)."""
        result = MasteryTrackInventorySearchParams()
        assert result.name is None
        assert result.subject is None

    def test_valid_params(self):
        """Should accept valid search params."""
        result = MasteryTrackInventorySearchParams(name="Math Test", subject="Math", grade="3rd")
        assert result.name == "Math Test"
        assert result.subject == "Math"
        assert result.grade == "3rd"

    def test_all_flag(self):
        """Should accept all boolean flag."""
        result = MasteryTrackInventorySearchParams(all=True)
        assert result.all is True

    def test_empty_string_name_rejects(self):
        """Should reject empty string for name (min_length=1)."""
        with pytest.raises(ValidationError):
            MasteryTrackInventorySearchParams(name="")


class TestAssignmentInput:
    """Tests for MasteryTrackAssignmentInput validation."""

    def test_valid_with_timeback_id(self):
        """Should accept valid input with timeback_id."""
        result = MasteryTrackAssignmentInput(
            student_email="student@example.com",
            timeback_id="_677e37c49e904cafcc66fdb4",
        )
        assert result.student_email == "student@example.com"
        assert result.timeback_id == "_677e37c49e904cafcc66fdb4"

    def test_valid_with_subject(self):
        """Should accept valid input with subject."""
        result = MasteryTrackAssignmentInput(
            student_email="student@example.com",
            subject="Math",
        )
        assert result.subject == "Math"

    def test_valid_with_subject_and_grade_rank(self):
        """Should accept subject with grade_rank."""
        result = MasteryTrackAssignmentInput(
            student_email="student@example.com",
            subject="Math",
            grade_rank=5,
        )
        assert result.grade_rank == 5

    def test_missing_timeback_id_and_subject_rejects(self):
        """Should reject when neither timeback_id nor subject is provided."""
        with pytest.raises(ValidationError, match="timeback_id or subject"):
            MasteryTrackAssignmentInput(
                student_email="student@example.com",
            )

    def test_grade_rank_without_subject_rejects(self):
        """Should reject grade_rank without subject."""
        with pytest.raises(ValidationError, match="grade_rank requires subject"):
            MasteryTrackAssignmentInput(
                student_email="student@example.com",
                timeback_id="_677e37c49e904cafcc66fdb4",
                grade_rank=5,
            )

    def test_assessment_ids_must_be_together(self):
        """assessment_line_item and assessment_result must appear together."""
        with pytest.raises(ValidationError, match="must be provided together"):
            MasteryTrackAssignmentInput(
                student_email="student@example.com",
                timeback_id="_677e37c49e904cafcc66fdb4",
                assessment_line_item_sourced_id="line-1",
            )

    def test_assessment_ids_both_present(self):
        """Should accept when both assessment IDs are provided."""
        result = MasteryTrackAssignmentInput(
            student_email="student@example.com",
            timeback_id="_677e37c49e904cafcc66fdb4",
            assessment_line_item_sourced_id="line-1",
            assessment_result_sourced_id="result-1",
        )
        assert result.assessment_line_item_sourced_id == "line-1"
        assert result.assessment_result_sourced_id == "result-1"

    def test_invalid_email_rejects(self):
        """Should reject invalid student email."""
        with pytest.raises(ValidationError):
            MasteryTrackAssignmentInput(
                student_email="not-an-email",
                timeback_id="_677e37c49e904cafcc66fdb4",
            )

    def test_grade_rank_bounds(self):
        """Should reject grade_rank outside 0-12."""
        with pytest.raises(ValidationError):
            MasteryTrackAssignmentInput(
                student_email="student@example.com",
                subject="Math",
                grade_rank=13,
            )

        with pytest.raises(ValidationError):
            MasteryTrackAssignmentInput(
                student_email="student@example.com",
                subject="Math",
                grade_rank=-1,
            )


class TestInvalidateAssignmentInput:
    """Tests for MasteryTrackInvalidateAssignmentInput validation."""

    def test_valid_with_assignment_id(self):
        """Should accept valid input with assignment_id."""
        result = MasteryTrackInvalidateAssignmentInput(
            student_email="student@example.com",
            assignment_id=123,
        )
        assert result.assignment_id == 123

    def test_valid_with_timeback_id(self):
        """Should accept valid input with timeback_id."""
        result = MasteryTrackInvalidateAssignmentInput(
            student_email="student@example.com",
            timeback_id="_677e37c49e904cafcc66fdb4",
        )
        assert result.timeback_id == "_677e37c49e904cafcc66fdb4"

    def test_valid_with_subject_and_grade_rank(self):
        """Should accept valid input with subject + grade_rank."""
        result = MasteryTrackInvalidateAssignmentInput(
            student_email="student@example.com",
            subject="Math",
            grade_rank=5,
        )
        assert result.subject == "Math"
        assert result.grade_rank == 5

    def test_missing_all_identifiers_rejects(self):
        """Should reject when no identifier is provided."""
        with pytest.raises(ValidationError, match=r"assignment_id.*timeback_id.*subject"):
            MasteryTrackInvalidateAssignmentInput(
                student_email="student@example.com",
            )

    def test_grade_rank_without_subject_rejects(self):
        """Should reject grade_rank without subject."""
        with pytest.raises(ValidationError, match="grade_rank requires subject"):
            MasteryTrackInvalidateAssignmentInput(
                student_email="student@example.com",
                grade_rank=5,
            )

    def test_assignment_id_must_be_positive(self):
        """Should reject non-positive assignment_id."""
        with pytest.raises(ValidationError):
            MasteryTrackInvalidateAssignmentInput(
                student_email="student@example.com",
                assignment_id=0,
            )

    def test_invalid_email_rejects(self):
        """Should reject invalid student email."""
        with pytest.raises(ValidationError):
            MasteryTrackInvalidateAssignmentInput(
                student_email="not-an-email",
                assignment_id=123,
            )
