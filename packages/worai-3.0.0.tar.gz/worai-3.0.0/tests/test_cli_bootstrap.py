from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_cli_reports_friendly_error_when_typer_is_missing() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = f"""
import builtins
import sys
sys.path.insert(0, {str(repo_root)!r})
sys.modules.pop("typer", None)
real_import = builtins.__import__
def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
    if name == "typer":
        raise ModuleNotFoundError("No module named 'typer'", name="typer")
    return real_import(name, globals, locals, fromlist, level)
builtins.__import__ = fake_import
import worai.cli
"""
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 1
    assert "Missing runtime dependency 'typer'" in result.stderr
    assert "uv sync --extra dev" in result.stderr
