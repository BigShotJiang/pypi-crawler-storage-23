# SPDX-FileCopyrightText: 2026-present Comet11x <>
# SPDX-License-Identifier: MIT

__version__ = "0.2.2"
