.. pyfplib documentation master file, created by
   sphinx-quickstart on Mon Feb  2 21:50:31 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyfplib documentation
=====================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

