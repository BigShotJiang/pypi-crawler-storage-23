# PyFPLib

🎯 PyFPLib is a tiny Rust-inspired functional programming library for Python.
It can serve as a basis for monadic computations in your Python code.

## 📦 Installation

```shell
pip install -U pyfplib
```
