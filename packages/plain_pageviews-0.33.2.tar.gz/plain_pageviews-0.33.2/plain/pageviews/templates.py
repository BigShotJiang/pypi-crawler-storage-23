from __future__ import annotations

from typing import Any

from jinja2.runtime import Context

from plain.templates import register_template_extension
from plain.templates.jinja.extensions import InclusionTagExtension
from plain.urls import reverse


@register_template_extension
class PageviewsJSExtension(InclusionTagExtension):
    tags = {"pageviews_js"}
    template_name = "pageviews/js.html"

    def get_context(
        self, context: Context, *args: Any, **kwargs: Any
    ) -> dict[str, Any]:
        return {
            "pageviews_track_url": reverse("pageviews:track"),
            "request": context.get("request"),
        }
