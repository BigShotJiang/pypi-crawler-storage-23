from cqrs.serializers.default import default_serializer

__all__ = ("default_serializer",)
