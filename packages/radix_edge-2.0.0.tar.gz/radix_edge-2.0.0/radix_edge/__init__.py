"""Radix Edge Agent — GPU orchestration with information-theoretic scheduling."""

__version__ = "2.0.0"
