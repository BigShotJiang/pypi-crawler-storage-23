"""Type definitions for bingx client."""

from typing import Literal, NotRequired, TypedDict

type AccountType = Literal[
    "spot",  # Spot (fund account)
    "stdFutures",  # Standard futures account
    "coinMPerp",  # Coin base account
    "USDTMPerp",  # U base account
    "copyTrading",  # Copy trading account
    "grid",  # Grid account
    "eran",  # Wealth account
    "c2c",  # C2C account
]
type MarginMode = Literal["ISOLATED", "CROSSED", "SEPARATE_ISOLATED"]


type SwapOrderType = Literal[
    "LIMIT",
    "MARKET",
    "STOP_MARKET",
    "TAKE_PROFIT_MARKET",
    "STOP",
    "TAKE_PROFIT",
    "TRIGGER_LIMIT",
    "TRIGGER_MARKET",
    "TRAILING_STOP_MARKET",
    "TRAILING_TP_SL",
]
type SpotOrderType = Literal[
    "MARKET",
    "LIMIT",
    "TAKE_STOP_LIMIT",
    "TAKE_STOP_MARKET",
    "TRIGGER_LIMIT",
    "TRIGGER_MARKET",
]
type TpSlOrderType = Literal["STOP", "TAKE_PROFIT", "STOP_MARKET", "TAKE_PROFIT_MARKET"]
type OrderSide = Literal["SELL", "BUY"]
type PositionSide = Literal["BOTH", "LONG", "SHORT"]
type TriggerPriceType = Literal["MARK_PRICE", "CONTRACT_PRICE", "INDEX_PRICE"]
type TimeInForce = Literal["PostOnly", "GTC", "IOC", "FOK"]
type StopGuaranteed = Literal["true", "false", "cutfee"]


# todo: use camel case direct here
class TpSlStruct(TypedDict, total=False):
    """Structured dict for takeProfit/stopLoss fields."""

    order_type: TpSlOrderType
    stop_price: float
    price: float
    working_type: TriggerPriceType


# todo: use camel case direct here
class PlaceSwapOrderParams(TypedDict, total=False):
    """Request parameters for creating/modifying an order on BingX."""

    # There must be a hyphen "-" in the trading pair symbol. eg: BTC-USDT
    symbol: str
    # Order type
    order_type: SwapOrderType
    # buying and selling direction
    side: OrderSide
    # Position direction
    position_side: NotRequired[PositionSide]
    # Only for single position mode
    reduce_only: NotRequired[bool]  # need to str
    # Price, or trailing stop distance for certain order types
    price: NotRequired[float]
    # Order quantity in COIN
    quantity: NotRequired[float]
    # Quote order quantity, e.g. 100USDT
    quote_order_qty: NotRequired[float]
    # Trigger price for some order types
    stop_price: NotRequired[float]
    # For trailing orders; Maximum: 1
    price_rate: NotRequired[float]
    # Stop loss setting, only STOP_MARKET/STOP
    working_type: NotRequired[TriggerPriceType]
    # Take-profit order (accepts a TpSlStruct dict, or stringified JSON)
    take_profit: NotRequired[TpSlStruct]
    # Stop-loss order (accepts a TpSlStruct dict, or stringified JSON)
    stop_loss: NotRequired[TpSlStruct]
    # User-custom order ID (1-40 chars, lowercased)
    client_order_id: NotRequired[str]
    # Order execution time-in-force
    time_in_force: NotRequired[TimeInForce]
    # Close all position after trigger
    close_position: NotRequired[bool]  # need to str
    # Used with trailing stop orders
    activation_price: NotRequired[float]
    # Guaranteed SL/TP feature
    stop_guaranteed: NotRequired[StopGuaranteed]
    # Required when closing in Separate Isolated mode
    position_id: NotRequired[int]


# todo: use camel case direct here
class PlaceSpotOrderParams(TypedDict, total=False):
    """Request parameters for placing a spot order on BingX."""

    # Trading pair symbol, with hyphen (e.g. "BTC-USDT")
    symbol: str
    # Order side, either "BUY" or "SELL"
    side: OrderSide
    # Type of order, e.g. MARKET, LIMIT, etc.
    order_type: SpotOrderType
    # Trigger price for stop-limit or stop-market orders
    stop_price: NotRequired[float]
    # Order quantity in base asset
    quantity: NotRequired[float]
    # Order quantity in quote asset (for MARKET/quote order)
    quote_order_qty: NotRequired[float]
    # Price for limit order types
    price: NotRequired[float]
    # Custom user order ID
    new_client_order_id: NotRequired[str]
    # Time in force, e.g. "GTC", "IOC", "FOK", "PostOnly"
    time_in_force: NotRequired[TimeInForce]
