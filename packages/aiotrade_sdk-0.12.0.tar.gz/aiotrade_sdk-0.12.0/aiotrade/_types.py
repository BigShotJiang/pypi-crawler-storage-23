from typing import Literal

type HttpMethod = Literal["GET", "POST", "PUT", "DELETE"]
type Exchange = Literal["bingx", "bybit", "okx", "bitget", "binance"]
