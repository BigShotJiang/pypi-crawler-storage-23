class FundMixin:
    """Fund-related methods for BingX API client.

    This mixin provides methods for managing funds and financial operations.
    """
