class WalletMixin:
    """Wallet-related methods for BingX API client.

    This mixin provides methods for managing wallets and balance operations.
    """
