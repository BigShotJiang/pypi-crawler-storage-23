from ._account import AccountMixin


class SpotMixin(AccountMixin):
    """Combine spot mixins."""
