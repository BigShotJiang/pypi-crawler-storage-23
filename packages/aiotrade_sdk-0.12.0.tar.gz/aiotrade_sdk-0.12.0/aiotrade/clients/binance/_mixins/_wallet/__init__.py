from ._account import AccountMixin


class AccountWalletMixin(AccountMixin):
    """Wallet account endpoints."""
