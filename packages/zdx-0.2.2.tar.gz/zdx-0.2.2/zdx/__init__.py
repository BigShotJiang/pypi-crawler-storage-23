"""ZDX documentation helpers.

These utilities support generating and serving project documentation
using MkDocs.
"""
