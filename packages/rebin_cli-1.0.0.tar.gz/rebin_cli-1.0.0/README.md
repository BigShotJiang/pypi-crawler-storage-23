# Rebin - Terminal Trash Tool
██████╗ ███████╗██████╗ ██╗███╗   ██╗         
██╔══██╗██╔════╝██╔══██╗██║████╗  ██║        
██████╔╝█████╗  ██████╔╝██║██╔██╗ ██║       
██╔══██╗██╔══╝  ██╔══██╗██║██║╚██╗██║       
██║  ██║███████╗██████╔╝██║██║ ╚████║       
╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═══╝ 

**Rebin**, terminal üzerinde çalışan bir çöp kutusu uygulamasıdır.  
Python ile yazılmıştır ve Windows/Linux/Mac terminallerinde çalışır.  

---

## Özellikler

- Dosyaları çöp kutusuna taşıma (`delete`)  
- Çöp kutusundan geri yükleme (`restore`)  
- Çöp kutusunu listeleme (`list`)  
- Dosya adı, boyut, tür, silinme tarihi  
- REBIN ASCII başlığı ve çöp kutusu simgesi ile görsellik  
- Çöp kutusunu tamamen boşaltma (`empty`)  

      