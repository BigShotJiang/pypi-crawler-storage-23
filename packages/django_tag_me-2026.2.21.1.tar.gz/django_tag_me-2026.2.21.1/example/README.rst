=================================
**Example**
=================================

|

**Version = "0.1.3"**

|

*An example for trying django-tag-me!*

|
.. image:: https://www.repostatus.org/badges/latest/concept.svg
   :target: https://www.repostatus.org/#concept
   :alt: Project Status: concept

|
:License: BSD license















Built with
`Django Cookiecutter <https://github.com/imAsparky/django-cookiecutter>`_
