Base Models
===========

.. currentmodule:: diffusiongym.base_models

.. autosummary::
    :toctree: generated/
    :template: class.rst
    :nosignatures:

    BaseModel
