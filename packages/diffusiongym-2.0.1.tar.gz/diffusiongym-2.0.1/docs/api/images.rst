Images
======

.. currentmodule:: diffusiongym.images

.. autosummary::
    :toctree: generated/
    :template: class.rst
    :nosignatures:

    CIFARBaseModel
    DiTBaseModel
    StableDiffusionBaseModel
    SD15BaseModel
    SD2BaseModel
    CompressionReward
    IncompressionReward
    AestheticReward
