Rewards
=======

.. currentmodule:: diffusiongym.rewards

.. autosummary::
    :toctree: generated/
    :template: class.rst
    :nosignatures:

    Reward
