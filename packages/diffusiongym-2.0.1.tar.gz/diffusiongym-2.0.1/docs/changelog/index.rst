:orphan: true

Changelog
=========

.. rst-class:: lead

   This is the changelog of Diffusion Gym.

----

.. include:: includes/2.0.1.rst

.. include:: includes/2.0.0.rst

.. include:: includes/1.13.rst

.. include:: includes/1.12.rst

.. include:: includes/1.11.rst

.. include:: includes/1.9.rst

.. include:: includes/1.8.rst

.. include:: includes/1.7.rst

.. include:: includes/1.6.rst

.. include:: includes/1.3.rst
