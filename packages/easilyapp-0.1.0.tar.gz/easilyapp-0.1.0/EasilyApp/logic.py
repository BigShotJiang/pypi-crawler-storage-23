import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QPushButton

class CustomWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.key_callback = None
        self.mouse_callback = None

    def keyPressEvent(self, event):
        if self.key_callback:
            key_name = QKeySequence(event.key()).toString()
            self.key_callback(key_name)

    def mousePressEvent(self, event):
        if self.mouse_callback:
            btn = event.button()
            if btn == Qt.LeftButton: name = "LeftClick"
            elif btn == Qt.RightButton: name = "RightClick"
            elif btn == Qt.MidButton: name = "MiddleClick"
            else: name = "UnknownClick"
            
            self.mouse_callback(name)

class Window:
    def __init__(self):
        self.app = QApplication.instance() or QApplication(sys.argv)
        self.window = CustomWidget()
        self.window.setWindowTitle("PyApp")
        self.window.resize(500, 500)
    
    def on_key(self, func):self.window.key_callback = func
    def FullScreen(self):self.window.showFullScreen()
    def NormalScreen(self):self.window.showNormal()
    def MaxScreen(self):self.window.showMaximized()
    def logo(self, path): self.window.setWindowIcon(QIcon(path))
    def on_click(self, func):self.window.mouse_callback = func
    def title(self, t): self.window.setWindowTitle(t)
    def size(self, w, h): self.window.resize(w, h)
    def bg(self, c): self.window.setStyleSheet(f"background-color: {c};")
    def on_key(self, func):
        def handler(event):
            name = QKeySequence(event.key()).toString()
            func(name)
        self.window.keyPressEvent = handler
    def run(self):
        self.window.show()
        sys.exit(self.app.exec_())

class Text:
    def __init__(self, parent_window, tx):
        self.label = QLabel(tx, parent=parent_window.window)
        self.label.show()

    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        def handler(event):
            name = self._get_btn_name(event.button())
            func(name)
        self.label.mousePressEvent = handler

    def on_double_click(self, func):
        def handler(event):
            name = self._get_btn_name(event.button())
            func(name)
        self.label.mouseDoubleClickEvent = handler
    
    def color(self, c1):self.label.setStyleSheet(f"color: {c1};")
    def bg(self, b1):self.text.setStyleSheet(f"background-color: {b1};")
    def position(self, x, y):self.text.move(x, y)
    def size(self, w, h): self.text.resize(w, h)

class Button:
    def __init__(self, parent_window, tx):
        self.obj = QPushButton(tx, parent=parent_window.window)
        self.obj.show()

    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))

    def color(self, c1): self.obj.setStyleSheet(f"color: {c1};")
    def bg(self, b1): self.obj.setStyleSheet(f"background-color: {b1};")
    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): self.obj.resize(w, h)