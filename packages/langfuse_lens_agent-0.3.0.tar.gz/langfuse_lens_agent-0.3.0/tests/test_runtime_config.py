from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from src.runtime_config import load_runtime_profile


class RuntimeConfigTests(unittest.TestCase):
    def test_selfhost_prod_requires_real_postgres_value(self) -> None:
        with patch.dict(os.environ, {"AGENT_PROFILE": "selfhost_prod"}, clear=False):
            with self.assertRaises(ValueError):
                load_runtime_profile()

    def test_selfhost_prod_accepts_env_postgres_dsn(self) -> None:
        with patch.dict(
            os.environ,
            {
                "AGENT_PROFILE": "selfhost_prod",
                "AGENT_POSTGRES_DSN": "postgresql://user:pw@127.0.0.1:5432/db",
            },
            clear=False,
        ):
            profile = load_runtime_profile()
            self.assertEqual(profile["name"], "selfhost_prod")
            self.assertEqual(profile["postgres_dsn"], "postgresql://user:pw@127.0.0.1:5432/db")

    def test_llm_settings_can_be_overridden_by_env(self) -> None:
        with patch.dict(
            os.environ,
            {
                "AGENT_PROFILE": "github",
                "AGENT_LLM_COMPARISON_MODELS": "openai:gpt-4o-mini,anthropic:claude-3-5-sonnet-latest",
                "AGENT_PROMPT_REVIEW_MODEL": "google_genai:gemini-2.0-flash",
            },
            clear=False,
        ):
            profile = load_runtime_profile()
            llm = profile.get("llm", {})
            self.assertEqual(
                llm.get("comparison_models"),
                ["openai:gpt-4o-mini", "anthropic:claude-3-5-sonnet-latest"],
            )
            self.assertEqual(llm.get("prompt_review_model"), "google_genai:gemini-2.0-flash")


if __name__ == "__main__":
    unittest.main()
