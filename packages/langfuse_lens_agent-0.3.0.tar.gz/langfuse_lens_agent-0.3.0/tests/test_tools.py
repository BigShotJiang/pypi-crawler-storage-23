from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from src import tools


class ToolsUnitTests(unittest.TestCase):
    def setUp(self) -> None:
        tools.clear_langfuse_openapi_tool_registry_cache()

    def _invoke_tool(self, tool_obj, payload: dict):
        if hasattr(tool_obj, "invoke"):
            return tool_obj.invoke(payload)
        return tool_obj(**payload)

    def test_parse_key_values_supports_quoted_values(self) -> None:
        message = 'mode=evaluation name="customer support flow" metadata.channel=prod'
        parsed = tools._parse_key_values(message)
        self.assertEqual(parsed["mode"], "evaluation")
        self.assertEqual(parsed["name"], "customer support flow")
        self.assertEqual(parsed["metadata.channel"], "prod")

    def test_parse_filters_with_metadata(self) -> None:
        message = 'mode=overview user_id=baem1n metadata.source=opencode limit=7'
        filters = tools._parse_filters(message)
        self.assertEqual(filters["mode"], "overview")
        self.assertEqual(filters["user_id"], "baem1n")
        self.assertEqual(filters["metadata"]["source"], "opencode")
        self.assertEqual(filters["limit"], 7)

    def test_time_regression_summary_detects_latency_and_cost_regression(self) -> None:
        traces = [
            {"timestamp": "2026-02-01T00:00:00+00:00", "latency": 10, "total_cost": 0.1, "observations": []},
            {"timestamp": "2026-02-01T00:05:00+00:00", "latency": 11, "total_cost": 0.1, "observations": []},
            {"timestamp": "2026-02-02T00:00:00+00:00", "latency": 30, "total_cost": 0.3, "observations": []},
            {"timestamp": "2026-02-02T00:05:00+00:00", "latency": 31, "total_cost": 0.3, "observations": []},
        ]
        summary = tools._time_regression_summary(traces)
        flags = summary["regression_flags"]
        self.assertIn("latency_regression", flags)
        self.assertIn("cost_regression", flags)

    def test_confidence_level(self) -> None:
        low = tools._confidence_level({"count": 3, "traces_with_observations": 3})
        high = tools._confidence_level({"count": 25, "traces_with_observations": 20})
        self.assertEqual(low, "low")
        self.assertEqual(high, "high")

    def test_parse_filters_supports_prompt_value(self) -> None:
        message = 'mode=prompt prompt="system prompt here" metadata.channel=prod'
        filters = tools._parse_filters(message)
        self.assertEqual(filters["mode"], "prompt_engineering")
        self.assertEqual(filters["prompt"], "system prompt here")

    def test_prompt_candidates_are_ranked_and_have_scores(self) -> None:
        metrics = {"error_rate": 0.25, "avg_latency_ms": 4200, "missing_user": 2, "missing_session": 1}
        baseline = "사용자 문의를 정확히 답변해줘."
        ranked = tools._score_prompt_candidates(tools._rewrite_prompt_candidates(baseline, metrics, None), metrics)
        self.assertEqual(len(ranked), 3)
        self.assertGreaterEqual(ranked[0]["scores"]["total"], ranked[-1]["scores"]["total"])
        self.assertIn("clarity", ranked[0]["scores"])

    def test_prompt_section_contains_recommended_prompt(self) -> None:
        trace = {"id": "tr-1", "name": "demo", "metadata": {"prompt": "요청을 해결해줘"}}
        metrics = {"error_rate": 0.1, "avg_latency_ms": 1500, "missing_user": 0, "missing_session": 0, "total_cost": 0.0}
        filters = {"prompt": None}
        with patch.dict(os.environ, {"AGENT_PROMPT_REVIEW_USE_MODEL": "0"}, clear=False):
            section = tools._polly_prompt_section({}, trace, metrics, filters, traces=[trace])
        self.assertIn("Recommended prompt", section)
        self.assertIn("expected_total_delta", section)

    def test_parse_model_spec_supports_provider_prefix(self) -> None:
        spec = tools._parse_model_spec("anthropic:claude-3-5-sonnet-latest")
        self.assertEqual(spec["provider"], "anthropic")
        self.assertEqual(spec["model"], "claude-3-5-sonnet-latest")
        self.assertEqual(spec["alias"], "anthropic:claude-3-5-sonnet-latest")

    def test_parse_model_spec_supports_gemini_alias(self) -> None:
        spec = tools._parse_model_spec("gemini:gemini-2.0-flash")
        self.assertEqual(spec["provider"], "google_genai")
        self.assertEqual(spec["model"], "gemini-2.0-flash")

    def test_comparison_model_specs_fallbacks_to_env_keys(self) -> None:
        env = {
            "OPENAI_API_KEY": "x",
            "ANTHROPIC_API_KEY": "y",
            "GOOGLE_API_KEY": "z",
            "AGENT_LLM_COMPARISON_MODELS": "",
            "AGENT_MODEL_SPECS": "",
            "AGENT_OPENROUTER_MODELS": "",
            "OPENROUTER_MODELS": "",
        }
        with patch.dict(os.environ, env, clear=False):
            specs = tools._comparison_model_specs({})
        providers = [spec["provider"] for spec in specs]
        self.assertIn("openai", providers)
        self.assertIn("anthropic", providers)
        self.assertIn("google_genai", providers)

    def test_invoke_model_with_langchain_uses_init_chat_model(self) -> None:
        class _DummyResponse:
            content = "ok"

        class _DummyLLM:
            def invoke(self, _messages):
                return _DummyResponse()

        with patch("langchain.chat_models.init_chat_model", return_value=_DummyLLM()) as mocked_init:
            result = tools._invoke_model_with_langchain(
                profile={},
                spec={"provider": "openai", "model": "gpt-4o-mini", "alias": "openai:gpt-4o-mini"},
                context_payload={"hello": "world"},
            )
        self.assertEqual(result, "ok")
        mocked_init.assert_called_once()
        _, kwargs = mocked_init.call_args
        self.assertEqual(kwargs["model_provider"], "openai")
        self.assertEqual(kwargs["model"], "gpt-4o-mini")

    def test_invoke_model_with_langchain_supports_openrouter_provider(self) -> None:
        class _DummyResponse:
            content = "openrouter-ok"

        class _DummyLLM:
            def invoke(self, _messages):
                return _DummyResponse()

        with patch.dict(
            os.environ,
            {"OPENROUTER_API_KEY": "test-key", "OPENROUTER_BASE_URL": "https://openrouter.ai/api/v1"},
            clear=False,
        ):
            with patch("langchain.chat_models.init_chat_model", return_value=_DummyLLM()) as mocked_init:
                result = tools._invoke_model_with_langchain(
                    profile={},
                    spec={"provider": "openrouter", "model": "openai/gpt-4o-mini", "alias": "openrouter:openai/gpt-4o-mini"},
                    context_payload={"k": "v"},
                )
        self.assertEqual(result, "openrouter-ok")
        _, kwargs = mocked_init.call_args
        self.assertEqual(kwargs["model_provider"], "openai")
        self.assertEqual(kwargs["base_url"], "https://openrouter.ai/api/v1")

    def test_build_langfuse_openapi_operation_tools_generates_callable_tools(self) -> None:
        operations = [
            {
                "operation_id": "projects_get",
                "method": "GET",
                "path": "/api/public/projects",
                "mutating": False,
                "summary": "List projects",
            },
            {
                "operation_id": "projects_create",
                "method": "POST",
                "path": "/api/public/projects",
                "mutating": True,
                "summary": "Create project",
            },
        ]

        def _identity_tool(*_args, **_kwargs):
            def _decorator(fn):
                return fn

            return _decorator

        with patch("src.tools.openapi_registry._lc_tool", side_effect=_identity_tool), patch(
            "src.tools.openapi_registry.run_langfuse_control_operation",
            side_effect=[
                {"result": {"operations": operations}},
                {"operation": "openapi.execute", "result": {"ok": True}},
            ],
        ):
            generated = tools.build_langfuse_openapi_operation_tools(refresh=True, include_mutating=False, max_tools=50)
            self.assertEqual(len(generated), 1)
            payload = generated[0](query={"limit": 1})
            self.assertIn("openapi.execute", payload)

    def test_get_langfuse_openapi_tool_registry_returns_metadata(self) -> None:
        operations = [
            {
                "operation_id": "datasets_get",
                "method": "GET",
                "path": "/api/public/v2/datasets",
                "mutating": False,
                "summary": "List datasets",
            }
        ]

        def _identity_tool(*_args, **_kwargs):
            def _decorator(fn):
                return fn

            return _decorator

        with patch("src.tools.openapi_registry._lc_tool", side_effect=_identity_tool), patch(
            "src.tools.openapi_registry.run_langfuse_control_operation",
            return_value={"result": {"operations": operations}},
        ):
            registry = tools.get_langfuse_openapi_tool_registry(refresh=True)
        self.assertEqual(registry["tool_count"], 1)
        self.assertEqual(registry["operation_count"], 1)
        self.assertIn("langfuse_api_datasets_get", registry["tools"][0]["name"])

    def test_trace_and_observation_tools_dispatch_expected_operations(self) -> None:
        with patch("src.tools.openapi_registry.run_langfuse_control_operation", return_value={"ok": True}) as mocked:
            self._invoke_tool(
                tools.langfuse_traces_list_tool,
                {"limit": 7, "user_id": "u1", "tags": ["prod", "chat"]},
            )
            self._invoke_tool(tools.langfuse_trace_get_tool, {"trace_id": "tr_1"})
            self._invoke_tool(
                tools.langfuse_observations_list_tool,
                {"trace_id": "tr_1", "limit": 10},
            )
        calls = [call.args[0] for call in mocked.call_args_list]
        self.assertEqual(calls, ["traces.list", "trace.get", "observations.list"])

    def test_prompt_management_tools_dispatch_expected_operations(self) -> None:
        with patch("src.tools.openapi_registry.run_langfuse_control_operation", return_value={"ok": True}) as mocked:
            self._invoke_tool(
                tools.langfuse_prompt_get_tool,
                {"name": "demo.prompt", "label": "latest"},
            )
            self._invoke_tool(tools.langfuse_prompt_list_tool, {"limit": 20})
            self._invoke_tool(
                tools.langfuse_prompt_upsert_tool,
                {"name": "demo.prompt", "prompt": "hello", "labels": ["latest"]},
            )
            self._invoke_tool(
                tools.langfuse_prompt_promote_label_tool,
                {"name": "demo.prompt", "label": "production", "version": 2},
            )
            self._invoke_tool(tools.langfuse_prompt_delete_tool, {"name": "demo.prompt", "version": 2})
        calls = [call.args[0] for call in mocked.call_args_list]
        self.assertEqual(
            calls,
            ["prompt.get", "prompt.list", "prompt.upsert", "prompt.promote_label", "prompt.delete"],
        )

    def test_evaluation_tools_dispatch_expected_operations(self) -> None:
        with patch("src.tools.openapi_registry.run_langfuse_control_operation", return_value={"ok": True}) as mocked:
            self._invoke_tool(
                tools.langfuse_score_create_tool,
                {"name": "quality", "value": 0.9, "trace_id": "tr_1"},
            )
            self._invoke_tool(
                tools.langfuse_annotation_create_tool,
                {"label": "good", "trace_id": "tr_1"},
            )
        calls = [call.args[0] for call in mocked.call_args_list]
        self.assertEqual(calls, ["score.create", "annotation.create"])

    def test_dataset_tools_dispatch_expected_operations(self) -> None:
        with patch("src.tools.openapi_registry.run_langfuse_control_operation", return_value={"ok": True}) as mocked:
            self._invoke_tool(tools.langfuse_datasets_list_tool, {"limit": 10})
            self._invoke_tool(tools.langfuse_datasets_create_tool, {"name": "eval-ds"})
            self._invoke_tool(
                tools.langfuse_dataset_items_upsert_tool,
                {"dataset_id": "ds_1", "items": [{"input": "x"}]},
            )
            self._invoke_tool(
                tools.langfuse_datasets_import_from_traces_tool,
                {"dataset_id": "ds_1", "trace_ids": ["tr_1", "tr_2"]},
            )
        calls = [call.args[0] for call in mocked.call_args_list]
        self.assertEqual(
            calls,
            ["datasets.list", "datasets.create", "dataset.items.upsert", "datasets.import_from_traces"],
        )

    def test_builtin_tool_registry_filters_mutating_tools(self) -> None:
        all_tools = tools.get_langfuse_builtin_tool_registry(include_mutating=True)
        readonly_tools = tools.get_langfuse_builtin_tool_registry(include_mutating=False)
        self.assertGreater(all_tools["count"], readonly_tools["count"])
        self.assertTrue(any(item["mutating"] for item in all_tools["tools"]))
        self.assertTrue(all(not item["mutating"] for item in readonly_tools["tools"]))


if __name__ == "__main__":
    unittest.main()
