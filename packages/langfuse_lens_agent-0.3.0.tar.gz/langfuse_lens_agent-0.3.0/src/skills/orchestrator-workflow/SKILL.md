---
name: orchestrator-workflow
description: Workflow skill generated from natural language for Langfuse Lens Agent
---

# Orchestrator Workflow

## Goal
딥에이전트 기반 랭퓨즈 트레이싱 분석 에이전트. 날짜, metadata, user_id, session_id 필터 조회와 모델별 비교

## Steps
1. Plan and store plan in `artifacts/request.md`.
2. Execute generated domain tools first.
3. If user asks for Langfuse experiment/model-compare/evaluator setup, load `skills/langfuse-python-sdk/SKILL.md` and `skills/reference/langfuse-python-sdk.md`.
4. Synthesize output and save to `artifacts/final.md`.
5. Verify coverage against original user request.

## Stack policy
- Current stack: **deepagents**
- Tool profile: **langfuse_trace_analysis**
