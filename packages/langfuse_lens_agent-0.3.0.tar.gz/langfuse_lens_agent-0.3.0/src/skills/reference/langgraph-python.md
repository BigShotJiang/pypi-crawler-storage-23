# langgraph-python

Source: `/Users/baem1n/Dev/company/agent-factory/langchain-ecosystem-skills/skills/langgraph-python/SKILL.md`

Description:
Design and implement LangGraph Python workflows with Graph API or Functional API, explicit state, nodes/edges, persistence, memory, interrupts, and durable execution. Use when requests require deterministic plus agentic orchestration, resumable long-running workflows, human approval gates, or advanced runtime control beyond high-level LangChain agents.
