# Langfuse Python SDK Reference Notes (Lens)

Lens에서 자주 쓰는 Python SDK 활용 패턴 요약.

## 1) 동일 프롬프트 + 모델 비교 실험
- 동일 dataset + 동일 task 함수
- 모델만 바꿔 run을 분기
- run metadata에 `model`, `prompt_version` 저장

```python
for model in ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet"]:
    langfuse.run_experiment(
        name="lens-model-compare",
        run_name=f"model={model}",
        data=items,
        task=lambda *, item, **kwargs: call_llm(model=model, prompt=item["input"]),
        evaluators=[quality_eval, format_eval],
        metadata={"model": model, "prompt_version": "v1"},
    )
```

## 2) Evaluator 구성
- evaluator는 pure function에 가깝게 구성
- 필요 시 judge LLM 호출
- run_evaluator로 run-level aggregate 점수 생성

## 3) Lens 관점 필수 메타데이터
- `model`
- `prompt_version`
- `evaluator_version`
- `dataset_name`
- `experiment_tag` (e.g., `prompt_self_improve`)

## 4) 운영 팁
- 실험 시작 전 trace filter 기준을 문서화
- 실패 샘플은 trace_id와 함께 저장
- 개선 라운드마다 prompt_version 증가

