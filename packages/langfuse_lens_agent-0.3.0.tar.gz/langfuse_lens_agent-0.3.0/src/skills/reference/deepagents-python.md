# deepagents-python

Source: `/Users/baem1n/Dev/company/agent-factory/langchain-ecosystem-skills/skills/deepagents-python/SKILL.md`

Description:
Build and operate Deep Agents in Python with planning, subagents, filesystem backends, long-term memory, HITL, and ACP/MCP integration. Use when requests mention Deep Agents, deepagents SDK/CLI, autonomous coding agents, multi-step planning with delegated subagents, or robust production agent behavior on top of LangChain/LangGraph.
