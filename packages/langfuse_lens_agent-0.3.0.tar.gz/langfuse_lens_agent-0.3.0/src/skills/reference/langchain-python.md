# langchain-python

Source: `/Users/baem1n/Dev/company/agent-factory/langchain-ecosystem-skills/skills/langchain-python/SKILL.md`

Description:
Build LangChain Python applications and agents using models, tools, middleware, retrieval, structured output, guardrails, and observability. Use when requests mention LangChain, create_agent, LCEL chains, tool-calling workflows, prompt engineering, or productionizing Python LLM apps without full custom graph orchestration.
