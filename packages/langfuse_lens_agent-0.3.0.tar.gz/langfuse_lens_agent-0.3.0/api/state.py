"""Global in-memory state shared across API routers."""
from __future__ import annotations

from datetime import datetime, timezone
from threading import Lock
from typing import Any

STATE_LOCK = Lock()
BOOT_TS = datetime.now(timezone.utc)
USERS: dict[str, dict[str, Any]] = {}
TOKENS: dict[str, dict[str, Any]] = {}

ROLE_LEVEL = {
    "viewer": 1,
    "analyst": 2,
    "editor": 3,
    "owner": 4,
    "ops": 4,
    "super_admin": 5,
}

ROLE_PERMISSIONS: dict[str, list[str]] = {
    "viewer": ["chat:read", "dashboard:read", "reports:read", "experiments:read"],
    "analyst": ["chat:read", "chat:write", "langfuse:read", "reports:read", "reports:write", "experiments:read", "experiments:write"],
    "editor": ["chat:read", "chat:write", "langfuse:read", "reports:read", "reports:write", "experiments:read", "experiments:write"],
    "owner": [
        "chat:read",
        "chat:write",
        "settings:read",
        "settings:write",
        "langfuse:read",
        "langfuse:write",
        "reports:read",
        "reports:write",
        "reports:admin",
        "experiments:read",
        "experiments:write",
    ],
    "ops": [
        "chat:read",
        "chat:write",
        "settings:read",
        "settings:write",
        "system:read",
        "langfuse:read",
        "reports:read",
        "reports:write",
        "reports:admin",
        "experiments:read",
        "experiments:write",
    ],
    "super_admin": [
        "*",
    ],
}
