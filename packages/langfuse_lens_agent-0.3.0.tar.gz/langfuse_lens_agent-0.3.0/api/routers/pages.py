"""HTML page routes."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from api.deps import _page_context

API_DIR = Path(__file__).resolve().parent.parent
TEMPLATES = Jinja2Templates(directory=str(API_DIR / "templates"))

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def page_dashboard(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="dashboard.html",
        context=_page_context("dashboard"),
    )


@router.get("/chat", response_class=HTMLResponse)
def page_chat(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="chat.html",
        context=_page_context("chat"),
    )


@router.get("/prompts", response_class=HTMLResponse)
def page_prompts(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="prompts.html",
        context=_page_context("prompts"),
    )


@router.get("/datasets", response_class=HTMLResponse)
def page_datasets(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="datasets.html",
        context=_page_context("datasets"),
    )


@router.get("/settings", response_class=HTMLResponse)
def page_settings(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="settings.html",
        context=_page_context("settings"),
    )


@router.get("/reports", response_class=HTMLResponse)
def page_reports(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="reports.html",
        context=_page_context("reports"),
    )


@router.get("/experiments", response_class=HTMLResponse)
def page_experiments(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="experiments.html",
        context=_page_context("experiments"),
    )


@router.get("/admin", response_class=HTMLResponse)
def page_admin(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="admin.html",
        context=_page_context("admin"),
    )


@router.get("/api-console", response_class=HTMLResponse)
def page_api_console(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="api_console.html",
        context=_page_context("api_console"),
    )


@router.get("/login", response_class=HTMLResponse)
def page_login(request: Request):
    return TEMPLATES.TemplateResponse(
        request=request,
        name="login.html",
        context={"active_page": "login"},
    )
