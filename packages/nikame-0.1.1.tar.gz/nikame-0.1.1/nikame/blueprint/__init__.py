"""NIKAME blueprint engine."""
