"""NIKAME cache modules."""
