"""NIKAME module system."""
