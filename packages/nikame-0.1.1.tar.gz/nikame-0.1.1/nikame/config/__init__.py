"""NIKAME configuration layer."""
