"""
kavram_sozlugu.data — Static reference data for the Ontology Lens.

Contains:
  - SIFAT_SEBA:    The 7 Attributes (immutable, AX64)
  - ESMA_UL_HUSNA: The 99 Names (el-Esmaul-Husna) with Sifat mappings
  - VALID_SIFAT_NAMES: Set of valid attribute name strings

Each Name is mapped to its parent Sifat(s) via sifat_of().
Sifat mappings follow classical Islamic theology (Kelam tradition).

Source references:
  AGENTS.md §1.3 (Sifat_Seba), §2.4 (AX17-AX20), §4.1 (Lens #1),
  Appendix C.2 (Named Constants)
"""

from kavram_sozlugu.types import Sifat, Isim


# ---------------------------------------------------------------------------
# The 7 Attributes (Sifat-i Seb'a) — AX64: immutable
# ---------------------------------------------------------------------------
# Per AGENTS.md §1.3:
#   Sifat_Seba = {Hayat} ⊔ {Ilim, Irade, Kudret} ⊔ {Sem, Basar, Kelam}

SIFAT_SEBA: dict[str, Sifat] = {
    "Hayat":  Sifat(name="Hayat",  role="root"),    # Integration prerequisite
    "Ilim":   Sifat(name="Ilim",   role="vucud"),   # Distinguishing
    "Irade":  Sifat(name="Irade",  role="vucud"),   # Specifying
    "Kudret": Sifat(name="Kudret", role="vucud"),   # Effecting
    "Sem":    Sifat(name="Sem",    role="beka"),     # Hearing
    "Basar":  Sifat(name="Basar",  role="beka"),     # Seeing
    "Kelam":  Sifat(name="Kelam",  role="beka"),     # Speaking
}

VALID_SIFAT_NAMES: frozenset[str] = frozenset(SIFAT_SEBA.keys())


# ---------------------------------------------------------------------------
# The 99 Names (el-Esmaul-Husna) — each mapped to parent Sifat(s)
# ---------------------------------------------------------------------------
# Format: (name, {sifat_names})
# Mappings based on classical Kelam theology and Risale-i Nur framework.
# Each Name derives from >= 1 Sifat (sifat_of constraint).

_NAMES_DATA: list[tuple[str, set[str]]] = [
    # 1-10
    ("er-Rahman",     {"Irade"}),
    ("er-Rahim",      {"Irade"}),
    ("el-Melik",      {"Irade", "Kudret"}),
    ("el-Kuddus",     {"Ilim"}),
    ("es-Selam",      {"Hayat"}),
    ("el-Mumin",      {"Ilim", "Irade"}),
    ("el-Muheymin",   {"Ilim", "Basar"}),
    ("el-Aziz",       {"Kudret"}),
    ("el-Cebbar",     {"Kudret", "Irade"}),
    ("el-Mutekebbir", {"Kudret"}),
    # 11-20
    ("el-Halik",      {"Ilim", "Irade", "Kudret"}),
    ("el-Bari",       {"Ilim", "Kudret"}),
    ("el-Musavvir",   {"Ilim", "Kudret"}),
    ("el-Gaffar",     {"Irade"}),
    ("el-Kahhar",     {"Kudret"}),
    ("el-Vehhab",     {"Irade", "Kudret"}),
    ("er-Rezzak",     {"Irade", "Kudret"}),
    ("el-Fettah",     {"Ilim", "Kudret"}),
    ("el-Alim",       {"Ilim"}),
    ("el-Kabid",      {"Kudret"}),
    # 21-30
    ("el-Basit",      {"Kudret"}),
    ("el-Hafid",      {"Irade", "Kudret"}),
    ("er-Rafi",       {"Irade", "Kudret"}),
    ("el-Muizz",      {"Irade"}),
    ("el-Muzill",     {"Irade", "Kudret"}),
    ("es-Semi",       {"Sem"}),
    ("el-Basir",      {"Basar"}),
    ("el-Hakem",      {"Ilim", "Irade"}),
    ("el-Adl",        {"Ilim", "Irade"}),
    ("el-Latif",      {"Ilim", "Irade"}),
    # 31-40
    ("el-Habir",      {"Ilim"}),
    ("el-Halim",      {"Irade"}),
    ("el-Azim",       {"Kudret"}),
    ("el-Gafur",      {"Irade"}),
    ("es-Sekur",      {"Ilim", "Irade"}),
    ("el-Aliyy",      {"Kudret"}),
    ("el-Kebir",      {"Kudret"}),
    ("el-Hafiz",      {"Ilim", "Kudret"}),
    ("el-Mukit",      {"Irade", "Kudret"}),
    ("el-Hasib",      {"Ilim"}),
    # 41-50
    ("el-Celil",      {"Kudret"}),
    ("el-Kerim",      {"Irade"}),
    ("er-Rakib",      {"Ilim", "Basar"}),
    ("el-Mucib",      {"Sem", "Irade"}),
    ("el-Vasi",       {"Ilim", "Kudret"}),
    ("el-Hakim",      {"Ilim", "Irade"}),
    ("el-Vedud",      {"Irade"}),
    ("el-Mecid",      {"Kudret"}),
    ("el-Bais",       {"Kudret"}),
    ("es-Sehid",      {"Ilim", "Basar"}),
    # 51-60
    ("el-Hakk",       {"Ilim"}),
    ("el-Vekil",      {"Irade", "Kudret"}),
    ("el-Kaviyy",     {"Kudret"}),
    ("el-Metin",      {"Kudret"}),
    ("el-Veliyy",     {"Irade"}),
    ("el-Hamid",      {"Kelam"}),
    ("el-Muhsi",      {"Ilim"}),
    ("el-Mubdi",      {"Ilim", "Kudret"}),
    ("el-Muid",       {"Kudret"}),
    ("el-Muhyi",      {"Hayat", "Kudret"}),
    # 61-70
    ("el-Mumit",      {"Kudret"}),
    ("el-Hayy",       {"Hayat"}),
    ("el-Kayyum",     {"Hayat", "Kudret"}),
    ("el-Vacid",      {"Ilim"}),
    ("el-Macid",      {"Kudret"}),
    ("el-Vahid",      {"Ilim", "Irade", "Kudret"}),
    ("es-Samed",      {"Hayat", "Kudret"}),
    ("el-Kadir",      {"Kudret"}),
    ("el-Muktedir",   {"Kudret"}),
    ("el-Mukaddim",   {"Irade"}),
    # 71-80
    ("el-Muahhir",    {"Irade"}),
    ("el-Evvel",      {"Hayat"}),
    ("el-Ahir",       {"Hayat"}),
    ("ez-Zahir",      {"Basar", "Kelam"}),
    ("el-Batin",      {"Ilim"}),
    ("el-Vali",       {"Irade", "Kudret"}),
    ("el-Muteali",    {"Kudret"}),
    ("el-Berr",       {"Irade"}),
    ("et-Tevvab",     {"Irade", "Sem"}),
    ("el-Muntekim",   {"Kudret", "Irade"}),
    # 81-90
    ("el-Afuvv",      {"Irade"}),
    ("er-Rauf",       {"Irade"}),
    ("Malikul-Mulk",  {"Irade", "Kudret"}),
    ("Zul-Celali vel-Ikram", {"Kudret", "Irade"}),
    ("el-Muksit",     {"Ilim", "Irade"}),
    ("el-Cami",       {"Kudret"}),
    ("el-Ganiyy",     {"Hayat"}),
    ("el-Mugni",      {"Irade", "Kudret"}),
    ("el-Mani",       {"Irade"}),
    ("ed-Darr",       {"Kudret"}),
    # 91-99
    ("en-Nafi",       {"Irade", "Kudret"}),
    ("en-Nur",        {"Ilim", "Basar"}),
    ("el-Hadi",       {"Ilim", "Irade"}),
    ("el-Bedi",       {"Ilim", "Kudret"}),
    ("el-Baki",       {"Hayat"}),
    ("el-Varis",      {"Hayat", "Kudret"}),
    ("er-Resid",      {"Ilim", "Irade"}),
    ("es-Sabur",      {"Irade"}),
    ("es-Safi",       {"Ilim", "Kudret"}),
]


def _build_name_registry() -> dict[str, Isim]:
    """Build Isim objects from raw data. Called once at module load."""
    registry = {}
    for name, sifat_set in _NAMES_DATA:
        # Validate all sifat references
        invalid = sifat_set - VALID_SIFAT_NAMES
        if invalid:
            raise ValueError(
                f"Name '{name}' references unknown Sifat: {invalid}. "
                f"Valid: {VALID_SIFAT_NAMES}"
            )
        registry[name] = Isim(
            name=name,
            sifat=frozenset(sifat_set),
            ekmel=float('inf'),  # AX22: supremum always infinite
        )
    return registry


# Build at import time — static, immutable data
ESMA_UL_HUSNA: dict[str, Isim] = _build_name_registry()

# Convenience: set of all known Name strings
VALID_NAME_STRINGS: frozenset[str] = frozenset(ESMA_UL_HUSNA.keys())
