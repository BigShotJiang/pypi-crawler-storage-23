"""
kategori_teorisi — KategoriTeorisi Lens (Lens #6 of 7).

Category-theoretic verification for the multi-lens analytical apparatus
defined in AGENTS.md §4.1 and §4.3.

  Lens: KategoriTeorisi | Faculty: Sır | Domain: Functor F: Rep→Hakikat,
        η: Vahidiyet⇒Ehadiyet

Public API
----------
Types:
    CatObject, Morphism, MorphismKind, Category, CategoryRole,
    Functor, FunctorProperty, NaturalTransformation, clamp_score

Verification:
    has_identities, check_composition_defined, is_valid_category,
    check_functor_objects, check_functor_morphisms,
    is_faithful, is_full, check_identity_preservation, verify_functor,
    check_naturality, check_component_coverage,
    verify_natural_transformation,
    check_vahidiyet, check_ehadiyet,
    yakinlasma, framework_summary

Constraints:
    category_validity, functor_faithfulness,
    vahidiyet_containment, ehadiyet_reflection,
    naturality_check, category_convergence_bound,
    valid_category_entry
"""

# -- Types -----------------------------------------------------------------
from .types import (
    CatObject,
    Category,
    CategoryRole,
    Functor,
    FunctorProperty,
    Morphism,
    MorphismKind,
    NaturalTransformation,
    clamp_score,
)

# -- Verification ----------------------------------------------------------
from .verification import (
    check_component_coverage,
    check_composition_defined,
    check_ehadiyet,
    check_functor_morphisms,
    check_functor_objects,
    check_identity_preservation,
    check_naturality,
    check_vahidiyet,
    framework_summary,
    has_identities,
    is_faithful,
    is_full,
    is_valid_category,
    verify_functor,
    verify_natural_transformation,
    yakinlasma,
)

# -- Constraints -----------------------------------------------------------
from .constraints import (
    category_convergence_bound,
    category_validity,
    ehadiyet_reflection,
    functor_faithfulness,
    naturality_check,
    vahidiyet_containment,
    valid_category_entry,
)

__all__ = [
    # Types
    "CatObject",
    "Category",
    "CategoryRole",
    "Functor",
    "FunctorProperty",
    "Morphism",
    "MorphismKind",
    "NaturalTransformation",
    "clamp_score",
    # Verification
    "check_component_coverage",
    "check_composition_defined",
    "check_ehadiyet",
    "check_functor_morphisms",
    "check_functor_objects",
    "check_identity_preservation",
    "check_naturality",
    "check_vahidiyet",
    "framework_summary",
    "has_identities",
    "is_faithful",
    "is_full",
    "is_valid_category",
    "verify_functor",
    "verify_natural_transformation",
    "yakinlasma",
    # Constraints
    "category_convergence_bound",
    "category_validity",
    "ehadiyet_reflection",
    "functor_faithfulness",
    "naturality_check",
    "vahidiyet_containment",
    "valid_category_entry",
]
