# Support Palfrey

If Palfrey helps your team, there are simple ways to support the project.

## Star the repository

A GitHub star increases visibility and helps more users find the project.

- [https://github.com/dymmond/palfrey](https://github.com/dymmond/palfrey)

## Follow releases

Use GitHub watch settings to be notified of new releases and important updates.

## Join the community

- [Palfrey Discord](https://discord.gg/eMrM9sWWvu)

## Sponsor development

Financial sponsorship helps sustain maintenance, issue response, and long-term feature work.

- [GitHub Sponsors](https://github.com/sponsors/tarsil)

## Non-technical summary

Open-source quality depends on sustained maintenance.
Community support directly improves reliability and delivery speed.
