from tests.importer.circular_import_b import bar  # noqa: F401
