from pyzm.ml.detector import Detector

__all__ = ["Detector"]
