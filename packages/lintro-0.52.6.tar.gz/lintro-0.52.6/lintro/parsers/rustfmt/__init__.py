"""Rustfmt parser module."""
