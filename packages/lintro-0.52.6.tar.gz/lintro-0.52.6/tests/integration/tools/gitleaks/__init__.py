"""Integration tests for gitleaks tool."""
