"""Integration tests for astro-check tool."""
