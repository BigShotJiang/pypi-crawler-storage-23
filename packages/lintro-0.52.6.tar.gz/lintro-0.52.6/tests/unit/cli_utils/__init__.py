"""Unit tests for CLI utility modules."""
