// Clean JavaScript file with no linting issues
const greeting = "Hello, World!";

function add(a, b) {
  return a + b;
}

const result = add(1, 2);
console.log(greeting, result);
