#!/bin/bash
exec cloak hook safety-guard
