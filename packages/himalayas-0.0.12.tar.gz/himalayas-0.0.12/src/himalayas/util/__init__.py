"""
himalayas/util
~~~~~~~~~~~~~~
"""

from .warnings import warn

__all__ = ["warn"]
