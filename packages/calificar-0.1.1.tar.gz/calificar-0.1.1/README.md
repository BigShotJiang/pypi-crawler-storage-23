# 📦 Calificar

[![PyPI version](https://img.shields.io/pypi/v/calificar.svg)](https://pypi.org/project/calificar/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Es una librería para calificar talleres a partir de Python.

## 🚀 Instalación

Instálalo fácilmente usando pip:

```bash
pip install calificar