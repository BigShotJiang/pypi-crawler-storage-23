# Progress

## ✅ COMPLETED — v0.1.2 Published

### PyPI: https://pypi.org/project/gsc-bing-mcp/0.1.2/
### GitHub: https://github.com/codermillat/gsc-bing-mcp

---

## What Works (v0.1.2)

### GSC Tools — batchexecute RPC (no OAuth, no GCP)
| Tool | RPC | Status |
|------|-----|--------|
| `gsc_performance_trend` | OLiH4d | ✅ **Fully working** — 17 days real data |
| `gsc_site_summary` | gydQ5d | ✅ **Fully working** — coverage counts |
| `gsc_top_queries` | nDAfwb dim=2 | ✅ Structural (verified on low-traffic site) |
| `gsc_top_pages` | nDAfwb dim=3 | ✅ Structural |
| `gsc_search_analytics` | nDAfwb multi-dim | ✅ Structural |
| `gsc_list_sites` | SM7Bqb | ⚠️ Returns [] — graceful fallback with user instructions |
| `refresh_google_session` | — | ✅ Clears cookie + XSRF cache |

### Bing Tools (unchanged from v0.1.0)
| Tool | Status |
|------|--------|
| `bing_get_site_info` | ✅ Working |
| `bing_top_pages` | ✅ Working |
| `bing_top_queries` | ✅ Working |
| `bing_crawl_stats` | ✅ Working |

### Infrastructure
- SAPISIDHASH auth (SHA1 based, no OAuth) ✅
- rookiepy Chrome cookie extraction ✅
- Multi-browser auto-detect: Chrome → Brave → Edge ✅
- Env var overrides: `BROWSER`, `CHROME_PROFILE` ✅
- XSRF token auto-fetch from 400 error ✅
- batchexecute response parser (chunked streaming + wrb.fr) ✅
- 5-minute in-memory cache for cookies + XSRF ✅

## Sample Test Output (real data from kitovo.app)
```
[5] Date time series — OLiH4d:
  ✓ Got 17 date rows
    {'date': '2026-01-31', 'clicks': 0, 'impressions': 0, 'ctr': 0.0, 'position': 0.0}
    {'date': '2026-02-01', 'clicks': 1, 'impressions': 13, 'ctr': 7.69, 'position': 28.9}
    {'date': '2026-02-02', 'clicks': 2, 'impressions': 160, 'ctr': 1.25, 'position': 54.0}
    ...
[4] gydQ5d: ✓ returns coverage: [[[43,[43,8,0]],[20,[20,3,0]],...],False,0,'https://www.kitovo.app/']
```

## Current MCP Config (Cline)
```json
"gsc-bing-mcp": {
  "command": "uvx",
  "args": ["gsc-bing-mcp"],
  "env": { "BING_API_KEY": "caafd6505af04f9c90edca8b73ddfc3e" }
}
```

---

## Version History
| Version | Date | Notes |
|---------|------|-------|
| 0.1.0 | 2026-02-18 | Initial release — used wrong GSC API (404s) |
| 0.1.1 | 2026-02-18 | First batchexecute attempt (incomplete) |
| 0.1.2 | 2026-02-18 | **Full batchexecute rewrite — real data working** |

---

## Known Limitations
- `gsc_list_sites`: SM7Bqb returns `[]` because it depends on browser localStorage. Users must provide `site_url` directly.
- `nDAfwb` breakdown on very low-traffic sites only returns aggregate totals (no per-query rows). Works correctly for high-traffic sites.
- Chrome must not have the Cookies SQLite DB locked (close Chrome or use --no-sandbox profile)
- SAPISIDHASH is an internal Google technique — could theoretically break if Google changes auth
- Bing API key must be manually obtained from bing.com/webmasters

## ⚠️ Security Note
- Regenerate PyPI API token if the old one was ever exposed in chat logs
  - Go to: https://pypi.org/manage/account/token/
  - Delete old token, create new one scoped to "gsc-bing-mcp" project
  - Update `~/.pypirc`

---

## What's Left to Build (Future)

### v0.2.0 Ideas
- `gsc_index_coverage` — use czrWJf RPC for detailed coverage breakdown
- `gsc_sitemaps` — discover sitemap RPC
- `gsc_inspect_url` — URL inspection RPC
- Firefox cookie support as fallback
- Better `gsc_list_sites` via GSC HTML scraping

### v0.3.0 Ideas
- Multi-account Google support (profile selector)
- Date range support (currently fixed 17-day window)
- Export to CSV/JSON option
- Bing URL submission tool
