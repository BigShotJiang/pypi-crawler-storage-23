#!/usr/bin/env python3
"""
Probe script to discover GSC batchexecute RPC IDs.
Uses curl (subprocess) since Python/httpx has DNS issues on macOS miniconda.

Run: python probe_gsc_rpc.py
"""

import re
import sys
import json
import time
import hashlib
import subprocess

try:
    import rookiepy
except ImportError:
    print("ERROR: rookiepy not installed. Run: pip install rookiepy")
    sys.exit(1)

BATCHEXECUTE_URL = "https://search.google.com/_/SearchConsoleAggReportUi/data/batchexecute"
GSC_WELCOME_URL = "https://search.google.com/search-console/welcome"
GSC_ORIGIN = "https://search.google.com"

CANDIDATE_RPC_IDS = [
    "GetSitesList", "ListSites", "GetSites", "GetProperties",
    "ListProperties", "SearchAnalytics", "GetSearchAnalytics",
    "QuerySearchAnalytics", "GetSearchData", "InspectUrl",
    "GetUrlInspection", "UrlInspect", "GetIndexStatus",
    "hFVgQe", "RMFTTe", "KF4T6b", "Mhwfke", "nGNc3e", "a2KIo",
    "gMHDWb", "TNBxle", "bjXlje", "V6LKQD", "VsAjrf",
]


def get_cookies():
    print("Extracting Chrome cookies...")
    browsers = [
        ("Chrome", lambda: rookiepy.chrome(["google.com"])),
        ("Brave",  lambda: rookiepy.brave(["google.com"])),
        ("Edge",   lambda: rookiepy.edge(["google.com"])),
    ]
    for name, fn in browsers:
        try:
            raw = fn()
            cookies = {c["name"]: c["value"] for c in raw if c.get("name") and c.get("value")}
            sapisid = (cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID")
                       or cookies.get("__Secure-1PAPISID"))
            if sapisid:
                print(f"[OK] Got {len(cookies)} cookies from {name}")
                return cookies
            print(f"[WARN] {name}: no SAPISID")
        except Exception as e:
            print(f"[WARN] {name}: {e}")
    raise RuntimeError("No Google session found")


def build_cookie_header(cookies):
    NAMES = {
        "SAPISID", "__Secure-1PAPISID", "__Secure-3PAPISID",
        "__Secure-1PSID", "__Secure-3PSID", "SID", "HSID",
        "SSID", "APISID", "OSID", "NID", "SIDCC",
        "__Secure-1PSIDCC", "__Secure-3PSIDCC",
        "__Secure-1PSIDTS", "__Secure-3PSIDTS",
    }
    parts = [f"{n}={cookies[n]}" for n in NAMES if n in cookies]
    parts += [f"{n}={v}" for n, v in cookies.items()
              if (n.startswith("__Host-") or n.startswith("__Secure-")) and n not in NAMES]
    return "; ".join(parts)


def sapisidhash(sapisid, origin):
    ts = int(time.time())
    digest = hashlib.sha1(f"{ts} {sapisid} {origin}".encode()).hexdigest()
    return f"SAPISIDHASH {ts}_{digest}"


def curl_get(url, cookies, extra_headers=None):
    """Run a GET request via curl."""
    origin = GSC_ORIGIN
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or cookies.get("__Secure-1PAPISID") or ""
    cookie_str = build_cookie_header(cookies)
    auth = sapisidhash(sapisid, origin)

    cmd = [
        "curl", "-s", "-L",
        "--max-time", "15",
        "-w", "\n__STATUS__%{http_code}",
        "-H", f"Cookie: {cookie_str}",
        "-H", f"Authorization: {auth}",
        "-H", f"X-Origin: {origin}",
        "-H", f"Referer: {origin}/",
        "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "-H", "Accept-Language: en-US,en;q=0.9",
        "-H", "X-Goog-Authuser: 0",
    ]
    if extra_headers:
        for k, v in extra_headers.items():
            cmd += ["-H", f"{k}: {v}"]
    cmd.append(url)

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    output = result.stdout
    # Extract status code
    if "__STATUS__" in output:
        parts = output.rsplit("__STATUS__", 1)
        body = parts[0]
        status = int(parts[1].strip())
    else:
        body = output
        status = 0
    return status, body


def curl_post(url, data, cookies):
    """Run a POST request via curl."""
    origin = GSC_ORIGIN
    sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or cookies.get("__Secure-1PAPISID") or ""
    cookie_str = build_cookie_header(cookies)
    auth = sapisidhash(sapisid, origin)

    cmd = [
        "curl", "-s",
        "--max-time", "10",
        "-w", "\n__STATUS__%{http_code}",
        "-X", "POST",
        "-H", f"Cookie: {cookie_str}",
        "-H", f"Authorization: {auth}",
        "-H", f"X-Origin: {origin}",
        "-H", f"Origin: {origin}",
        "-H", f"Referer: {origin}/",
        "-H", "Content-Type: application/x-www-form-urlencoded",
        "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "-H", "Accept-Language: en-US,en;q=0.9",
        "-H", "X-Goog-Authuser: 0",
        "--data-raw", data,
        url,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    output = result.stdout
    if "__STATUS__" in output:
        parts = output.rsplit("__STATUS__", 1)
        body = parts[0]
        status = int(parts[1].strip())
    else:
        body = output
        status = 0
    return status, body


def probe_rpc(rpc_id, cookies):
    payload = "f.req=" + json.dumps([[[rpc_id, "[]", None, "1"]]])
    status, body = curl_post(BATCHEXECUTE_URL, payload, cookies)
    anti_xssi = ")]}'"
    ok = status == 200 and anti_xssi in body[:10]
    sym = "OK " if ok else "   "
    print(f"  [{sym}] {rpc_id:30s}  HTTP {status}  len={len(body):5d}  {body[:60]!r}")
    return ok, body


def search_html_for_rpcs(html):
    patterns = [
        r'"rpcId"\s*:\s*"([A-Za-z0-9_]{3,30})"',
        r"'rpcId'\s*:\s*'([A-Za-z0-9_]{3,30})'",
        r'"([A-Za-z][A-Za-z0-9]{3,20})"\s*,\s*JSON\.stringify',
        r'"(Get[A-Za-z]{3,30})"',
        r'"(List[A-Za-z]{3,30})"',
        r'"(Query[A-Za-z]{3,30})"',
        r'"(Search[A-Za-z]{3,30})"',
        r'"(Inspect[A-Za-z]{3,30})"',
    ]
    found = set()
    for p in patterns:
        found.update(re.findall(p, html))
    return sorted(found)


def main():
    print("=" * 60)
    print("GSC batchexecute RPC Discovery (curl-based)")
    print("=" * 60)

    cookies = get_cookies()

    # ── Phase 1: Fetch GSC HTML ─────────────────────────────────────
    print("\n[Phase 1] Fetching GSC page for RPC hints...")
    status, html = curl_get(GSC_WELCOME_URL, cookies)
    print(f"  Status: {status}  len={len(html)}")

    if status == 200 and html:
        # Save for manual inspection
        with open("/tmp/gsc_page.html", "w") as f:
            f.write(html)
        print("  Saved to /tmp/gsc_page.html")

        if "accounts.google.com" in html or "Sign in" in html:
            print("  [WARN] Got login redirect — cookies may be expired")
        else:
            print("  Authenticated page received")

        rpc_hints = search_html_for_rpcs(html)
        if rpc_hints:
            print(f"  RPC hints in HTML ({len(rpc_hints)} found): {rpc_hints[:30]}")

        # Look for JS bundle URLs
        js_urls = re.findall(r'"(https://ssl\.gstatic\.com/[^"]+\.js)"', html)
        print(f"  Found {len(js_urls)} gstatic JS URLs")

        # Scan first 3 JS bundles  
        for url in js_urls[:3]:
            print(f"\n  Scanning JS: {url[-70:]}")
            js_status, js_body = curl_get(url, cookies)
            if js_status == 200 and js_body:
                hints = search_html_for_rpcs(js_body)
                if hints:
                    print(f"    RPC hints: {hints[:20]}")
                # Grep for batchexecute patterns
                be_matches = re.findall(
                    r'"([A-Za-z0-9]{4,12})"\s*,\s*(?:null|JSON\.stringify)',
                    js_body
                )
                if be_matches:
                    unique = sorted(set(be_matches))
                    print(f"    batchexecute patterns ({len(unique)}): {unique[:30]}")
    else:
        print(f"  Failed to fetch GSC page (status {status})")

    # ── Phase 2: Probe batchexecute endpoint ──────────────────────
    print(f"\n[Phase 2] Probing: {BATCHEXECUTE_URL}")
    print("  Connectivity test (dummy RPC)...")
    probe_rpc("__test__", cookies)

    print(f"\n  Testing {len(CANDIDATE_RPC_IDS)} candidate RPC IDs...")
    valid_ids = []
    for rpc_id in CANDIDATE_RPC_IDS:
        ok, body = probe_rpc(rpc_id, cookies)
        if ok:
            valid_ids.append((rpc_id, body))

    print("\n" + "=" * 60)
    if valid_ids:
        print(f"[RESULT] {len(valid_ids)} valid RPC IDs found:")
        for rpc_id, body in valid_ids:
            print(f"  - {rpc_id}")
            print(f"    Response: {body[:300]!r}")
    else:
        print("[RESULT] No candidate RPC IDs matched.")
        print("  All responses returned non-200 or missing anti-XSSI prefix.")
        print("  Check /tmp/gsc_page.html for manual JS inspection.")

    print("\nDone.")


if __name__ == "__main__":
    main()
