#!/usr/bin/env python3
"""
test_gsc_client.py — Quick end-to-end test for the new batchexecute-based GSC client.

Tests:
  1. Cookie extraction
  2. XSRF token acquisition
  3. list_sites (SM7Bqb RPC)
  4. query_search_analytics (OLiH4d RPC) — using first discovered site
"""

import asyncio
import json
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from gsc_bing_mcp.extractors.chrome_cookies import get_google_cookies
from gsc_bing_mcp.clients.gsc_client import (
    _get_xsrf_token,
    list_sites,
    query_search_analytics,
    get_site_summary,
    get_coverage_stats,
)


async def main():
    print("=" * 60)
    print("GSC Client Test — batchexecute approach")
    print("=" * 60)

    # 1. Cookies
    print("\n[1] Extracting Chrome cookies...")
    try:
        cookies = get_google_cookies()
        print(f"  ✓ Got {len(cookies)} cookies")
        print(f"  SAPISID present: {bool(cookies.get('SAPISID'))}")
        print(f"  __Secure-3PAPISID present: {bool(cookies.get('__Secure-3PAPISID'))}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")
        return

    # 2. XSRF token
    print("\n[2] Getting XSRF token...")
    try:
        xsrf = _get_xsrf_token(cookies)
        print(f"  ✓ XSRF token: {xsrf[:30]}...")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")
        return

    # 3. List sites
    print("\n[3] Listing GSC properties (SM7Bqb)...")
    sites = []
    try:
        sites = await list_sites(cookies)
        print(f"  ✓ Found {len(sites)} sites:")
        for s in sites[:10]:
            print(f"    - {s}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")
        print("  (Will try to use a known site URL for further tests)")

    # Pick a site to test
    test_site = None
    if sites and isinstance(sites[0], dict) and "siteUrl" in sites[0]:
        test_site = sites[0]["siteUrl"]
        print(f"\n  Using site: {test_site}")
    else:
        # Fallback: use a known verified site from the discovered RPC logs
        test_site = "https://www.kitovo.app/"
        print(f"\n  No sites from SM7Bqb, falling back to: {test_site}")

    # 4. Site summary
    print(f"\n[4] Getting site summary for {test_site} (gydQ5d)...")
    try:
        summary = await get_site_summary(test_site, cookies)
        raw_preview = str(summary.get("data"))[:300]
        print(f"  ✓ Summary data (first 300 chars): {raw_preview}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")

    # 5. Performance data — date time series (OLiH4d)
    print(f"\n[5] Date time series — OLiH4d...")
    try:
        result = await query_search_analytics(
            site_url=test_site,
            dimensions=["date"],
            cookies=cookies,
        )
        rows = result.get("rows", [])
        print(f"  ✓ Got {result.get('row_count', 0)} date rows")
        for row in rows[:5]:
            print(f"    {row}")
        if not rows:
            print(f"  Raw: {str(result.get('raw'))[:400]}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")

    # 6. Performance data — top queries (nDAfwb)
    print(f"\n[6] Top queries — nDAfwb...")
    try:
        result = await query_search_analytics(
            site_url=test_site,
            dimensions=["query"],
            cookies=cookies,
        )
        rows = result.get("rows", [])
        print(f"  ✓ Got {result.get('row_count', 0)} query rows")
        for row in rows[:5]:
            print(f"    {row}")
        if not rows:
            print(f"  Raw preview: {str(result.get('raw'))[:600]}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")

    # 7. Performance data — top pages (nDAfwb)
    print(f"\n[7] Top pages — nDAfwb...")
    try:
        result = await query_search_analytics(
            site_url=test_site,
            dimensions=["page"],
            cookies=cookies,
        )
        rows = result.get("rows", [])
        print(f"  ✓ Got {result.get('row_count', 0)} page rows")
        for row in rows[:3]:
            print(f"    {row}")
        if not rows:
            print(f"  Raw preview: {str(result.get('raw'))[:600]}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")

    # 7. Coverage stats
    print(f"\n[7] Getting coverage stats (czrWJf)...")
    try:
        cov = await get_coverage_stats(test_site, cookies)
        print(f"  ✓ Coverage raw: {str(cov.get('raw'))[:300]}")
    except Exception as e:
        print(f"  ✗ FAILED: {e}")

    print("\n" + "=" * 60)
    print("Test complete!")


if __name__ == "__main__":
    asyncio.run(main())
