#!/usr/bin/env python3
"""Test obfuscated RPC ID candidates from the GSC JS bundle."""
import re, json, time, hashlib, subprocess, sys
from collections import Counter

try:
    import rookiepy
except ImportError:
    sys.exit("pip install rookiepy")

raw = rookiepy.chrome(["google.com"])
cookies = {c["name"]: c["value"] for c in raw if c.get("name") and c.get("value")}
sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""

NAMES = {
    "SAPISID","__Secure-1PAPISID","__Secure-3PAPISID","__Secure-1PSID","__Secure-3PSID",
    "SID","HSID","SSID","APISID","OSID","NID","SIDCC",
    "__Secure-1PSIDCC","__Secure-3PSIDCC","__Secure-1PSIDTS","__Secure-3PSIDTS",
}
cookie_str = "; ".join([f"{n}={cookies[n]}" for n in NAMES if n in cookies])
ORIGIN = "https://search.google.com"
BE_URL = f"{ORIGIN}/_/SearchConsoleAggReportUi/data/batchexecute"

def make_auth():
    ts = int(time.time())
    return f"SAPISIDHASH {ts}_" + hashlib.sha1(f"{ts} {sapisid} {ORIGIN}".encode()).hexdigest()

def curl_post(url, data):
    cmd = ["curl", "-s", "--max-time", "12", "-X", "POST",
           "-H", f"Cookie: {cookie_str}",
           "-H", f"Authorization: {make_auth()}",
           "-H", f"X-Origin: {ORIGIN}",
           "-H", f"Origin: {ORIGIN}",
           "-H", f"Referer: {ORIGIN}/",
           "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
           "-H", "X-Goog-Authuser: 0",
           "-H", "Content-Type: application/x-www-form-urlencoded",
           "--data-raw", data, url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout

# Get XSRF token
print("Getting XSRF token...")
resp0 = curl_post(BE_URL, 'f.req=[[["x","null",null,"1"]]]')
xsrf = re.search(r'"xsrf"\s*,\s*"([^"]+)"', resp0)
xsrf = xsrf.group(1) if xsrf else ""
print(f"XSRF: {xsrf[:40]}...")

# Extract candidates from JS bundle
print("\nExtracting RPC candidates from JS bundle...")
js = open("/tmp/gsc_analytics.js").read()
all_strs = re.findall(r'"([A-Za-z][A-Za-z0-9]{3,11})"', js)
freq = Counter(all_strs)

# Candidates: mixed case, 4-12 chars, appear 1-8 times
candidates = [s for s, c in freq.most_common(500)
              if 1 <= c <= 8
              and any(ch.isupper() for ch in s)
              and any(ch.islower() for ch in s)
              and not s[0].isupper()  # Google uses camelCase starting with lowercase for RPC IDs
              and len(s) >= 5]
print(f"Extracted {len(candidates)} candidates from JS")

# Also add known Google RPC ID patterns (from other Google services reverse engineering)
extra_candidates = [
    # From yt-dlp / YouTube patterns
    "rpcId", "SQOsUb", "VHnV6b", "bjXlje", "nGNc3e", "xNWkPe",
    # Patterns that look like GSC RPC IDs
    "rhfQ5c", "UgAtXe", "rHjpXd", "GmEyCb", "rcuQ6b", "rJzNtf",
    "JbjMkf", "MH8Kwd", "YCvDsc", "O8k1Cd", "SF3gsd", "doKs4c",
    "iWP1Yb", "SdcwHb", "CBlRxf", "iQvDh", "CD9DCc", "FKbPbe",
    "d7YSfd", "uiNkee", "O7jPNb", "dyRcpb", "xQtZb",
]

all_candidates = list(dict.fromkeys(extra_candidates + candidates[:50]))
print(f"Total candidates to test: {len(all_candidates)}")

print("\nTesting candidates (comparing response sizes - different sizes = valid RPC!)...")
print("Format: [rpcId] HTTP_status len=LENGTH response_preview")

# First get the baseline error response length (invalid RPC)
baseline = curl_post(BE_URL, f'f.req={json.dumps([[["__invalid_xyz__","null",None,"1"]]])}&at={xsrf}')
baseline_len = len(baseline)
print(f"\nBaseline (invalid RPC): len={baseline_len} {baseline[:80]!r}")

# Test all candidates
interesting = []
for rpc_id in all_candidates:
    payload = f'f.req={json.dumps([[[rpc_id,"null",None,"1"]]])}&at={xsrf}'
    body = curl_post(BE_URL, payload)
    body_len = len(body)
    # A "hit" is when the response is DIFFERENT from baseline
    is_different = abs(body_len - baseline_len) > 10 or (body_len > 200 and "er" not in body[:30])
    marker = ">>> DIFFERENT <<<" if is_different else ""
    print(f"  [{rpc_id}] len={body_len} {marker} {body[:80]!r}")
    if is_different:
        interesting.append((rpc_id, body))

print(f"\n{'='*60}")
if interesting:
    print(f"INTERESTING RPC IDs ({len(interesting)} found):")
    for rpc_id, body in interesting:
        print(f"  {rpc_id}: {body[:300]!r}")
else:
    print("No different responses found. Trying with verified site URL in args...")
    # Try with actual args - maybe the RPC needs site_url
    for rpc_id in extra_candidates[:10]:
        args = json.dumps(["https://www.example.com/"])
        payload = f'f.req={json.dumps([[[rpc_id,args,None,"1"]]])}&at={xsrf}'
        body = curl_post(BE_URL, payload)
        is_diff = abs(len(body) - baseline_len) > 10
        marker = ">>> " if is_diff else ""
        print(f"  [{rpc_id} with url]: {marker}len={len(body)} {body[:80]!r}")

print("\nDone.")
