import re

html = open('/tmp/gsc_page.html').read()
print(f'HTML size: {len(html)} bytes')

# Pattern 1: strings next to JSON.stringify (classic batchexecute pattern)
p1 = re.findall(r'"([A-Za-z][A-Za-z0-9_]{2,20})",JSON\.stringify', html)
print(f'\nPattern JSON.stringify ({len(p1)}): {sorted(set(p1))[:30]}')

# Pattern 2: Get/List/Query/Search/Inspect method names
p4 = re.findall(r'"((?:Get|List|Query|Search|Inspect|Submit|Delete)[A-Za-z]{3,30})"', html)
print(f'\nPattern Get/List/Query ({len(set(p4))}): {sorted(set(p4))[:30]}')

# Pattern 3: Look at all SearchAnalytics contexts
print('\nNear SearchAnalytics contexts:')
idx = 0
count = 0
while count < 10:
    idx = html.find('SearchAnalytics', idx)
    if idx == -1:
        break
    ctx = html[max(0, idx-150):idx+300]
    ids = re.findall(r'"([A-Za-z][A-Za-z0-9]{3,20})"', ctx)
    if ids:
        print(f'  ctx: ...{ctx[:200]}...')
        print(f'  ids: {ids[:15]}')
    idx += 1
    count += 1

# Pattern 4: Look for short identifier strings followed by array patterns
p5 = re.findall(r'"([A-Za-z0-9]{4,12})",\s*null,\s*null,\s*"(\d+)"', html)
print(f'\nID patterns (id, null, null, seq): {p5[:20]}')

# Pattern 5: Look at f.req style patterns
p6 = re.findall(r'f\.req.*?"([A-Za-z0-9]{4,15})"', html)
print(f'\nf.req patterns: {p6[:20]}')

# Pattern 6: BOQ service names
p7 = re.findall(r'"([a-z][a-zA-Z0-9]{3,20})":\s*\{[^}]{0,200}rpc', html[:500000])
print(f'\nBOQ service-rpc: {p7[:20]}')

# Pattern 7: Any 4-8 char IDs that appear to be methods
p8 = re.findall(r'method:"([A-Za-z0-9_]{4,20})"', html)
print(f'\nmethod:"..." ({len(p8)}): {sorted(set(p8))[:20]}')

# Pattern 8: xhrd or xhr patterns
p9 = re.findall(r'xhrd?[^"]{0,30}"([A-Za-z][A-Za-z0-9]{3,20})"', html)
print(f'\nxhr patterns: {sorted(set(p9))[:20]}')

# Show unique strings that appear near 'rpc'
rpc_contexts = []
for m in re.finditer(r'rpc', html[:600000], re.IGNORECASE):
    ctx = html[max(0, m.start()-100):m.start()+200]
    short_strs = re.findall(r'"([A-Za-z0-9]{4,12})"', ctx)
    rpc_contexts.extend(short_strs)

from collections import Counter
top_rpc = Counter(rpc_contexts).most_common(30)
print(f'\nStrings near "rpc": {top_rpc}')
