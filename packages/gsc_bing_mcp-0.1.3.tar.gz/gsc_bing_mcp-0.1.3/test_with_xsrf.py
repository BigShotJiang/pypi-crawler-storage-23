#!/usr/bin/env python3
"""
Test GSC batchexecute with XSRF token and find correct RPC IDs.
The XSRF token is returned in error responses - use it to retry.
"""
import re, json, time, hashlib, subprocess, sys

try:
    import rookiepy
except ImportError:
    sys.exit("pip install rookiepy")

# --- Auth setup ---
raw = rookiepy.chrome(["google.com"])
cookies = {c["name"]: c["value"] for c in raw if c.get("name") and c.get("value")}
sapisid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""

NAMES = {
    "SAPISID","__Secure-1PAPISID","__Secure-3PAPISID","__Secure-1PSID","__Secure-3PSID",
    "SID","HSID","SSID","APISID","OSID","NID","SIDCC",
    "__Secure-1PSIDCC","__Secure-3PSIDCC","__Secure-1PSIDTS","__Secure-3PSIDTS",
}
cookie_str = "; ".join([f"{n}={cookies[n]}" for n in NAMES if n in cookies])
ORIGIN = "https://search.google.com"
BE_URL = f"{ORIGIN}/_/SearchConsoleAggReportUi/data/batchexecute"


def make_auth():
    ts = int(time.time())
    auth = f"SAPISIDHASH {ts}_" + hashlib.sha1(f"{ts} {sapisid} {ORIGIN}".encode()).hexdigest()
    return auth


def base_headers():
    return [
        "-H", f"Cookie: {cookie_str}",
        "-H", f"Authorization: {make_auth()}",
        "-H", f"X-Origin: {ORIGIN}",
        "-H", f"Origin: {ORIGIN}",
        "-H", f"Referer: {ORIGIN}/",
        "-H", "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "-H", "Accept-Language: en-US,en;q=0.9",
        "-H", "X-Goog-Authuser: 0",
        "-H", "Content-Type: application/x-www-form-urlencoded",
    ]


def curl_post(url, data, extra_headers=None):
    headers = base_headers()
    if extra_headers:
        for k, v in extra_headers.items():
            headers += ["-H", f"{k}: {v}"]
    cmd = ["curl", "-s", "--max-time", "15", "-X", "POST"] + headers + ["--data-raw", data, url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout


def extract_xsrf(response_body):
    """Extract XSRF token from batchexecute error response."""
    # Pattern: ["xsrf","TOKEN_VALUE"]
    match = re.search(r'"xsrf"\s*,\s*"([^"]+)"', response_body)
    if match:
        return match.group(1)
    return None


# Step 1: Get XSRF token from first request (it's in the error response)
print("Step 1: Getting XSRF token...")
init_payload = "f.req=" + json.dumps([[["GetSitesList", "null", None, "1"]]])
first_resp = curl_post(BE_URL, init_payload)
print(f"  Response: {first_resp[:300]!r}")

xsrf = extract_xsrf(first_resp)
if xsrf:
    print(f"  [OK] XSRF token: {xsrf[:30]}...")
else:
    print("  [WARN] No XSRF token found in response")
    # Try to get it from the page HTML
    print("  Trying to get XSRF from GSC page...")
    cmd = ["curl", "-s", "-L", "--max-time", "20"] + base_headers()[:12] + [
        f"{ORIGIN}/search-console/performance/search-analytics"
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    html = r.stdout
    # Look for at= token in HTML
    at_match = re.search(r'"SNlM0e"\s*:\s*"([^"]+)"', html)
    if at_match:
        xsrf = at_match.group(1)
        print(f"  [OK] XSRF from HTML (SNlM0e): {xsrf[:30]}...")
    else:
        # Try other patterns
        at_match2 = re.search(r'at\s*=\s*"([^"]+)"', html)
        if at_match2:
            xsrf = at_match2.group(1)
            print(f"  [OK] XSRF from HTML (at): {xsrf[:30]}...")

# Step 2: Scan the saved JS bundle for RPC IDs
print("\nStep 2: Scanning JS bundle for RPC IDs...")
try:
    js = open("/tmp/gsc_analytics.js").read()
    print(f"  JS size: {len(js)} bytes")

    # Pattern 1: RPC method strings before JSON.stringify
    p1 = sorted(set(re.findall(r'"([A-Za-z0-9]{4,12})"\s*,\s*JSON\.stringify', js)))
    print(f"  [JSON.stringify]: {p1[:30]}")

    # Pattern 2: rpcId patterns
    p2 = sorted(set(re.findall(r'rpcId\s*[=:]\s*"([A-Za-z0-9]{4,20})"', js)))
    print(f"  [rpcId=]: {p2[:30]}")

    # Pattern 3: generic method pattern
    p3 = sorted(set(re.findall(r'"([A-Za-z0-9]{4,12})"\s*,\s*null\s*,\s*"generic"', js)))
    print(f"  [null,generic]: {p3[:30]}")

    # Pattern 4: Look for method registration patterns
    p4 = sorted(set(re.findall(r'\.([a-zA-Z]{4,20})\s*=\s*function.*?batchexecute', js[:200000], re.DOTALL)))
    print(f"  [func.batchexecute]: {p4[:20]}")

    # Pattern 5: SearchConsole specific patterns
    p5 = sorted(set(re.findall(r'"([A-Za-z][A-Za-z0-9]{3,20})".*?search.google.com', js[:200000])))
    print(f"  [search.google.com nearby]: {p5[:20]}")

    # Pattern 6: Google BOQ method IDs
    p6 = sorted(set(re.findall(r'call\s*\(\s*["\']([A-Za-z0-9]{4,20})["\']', js)))
    print(f"  [call(id)]: {p6[:20]}")

    # Pattern 7: Array method patterns [methodName, ...args]
    p7 = sorted(set(re.findall(r'\["([A-Za-z0-9]{4,15})"\s*,\s*(?:JSON|null|function)', js)))
    print(f"  [array-method]: {p7[:30]}")

    # Extract all short 4-12 char strings and show frequency
    all_strs = re.findall(r'"([A-Za-z][A-Za-z0-9]{3,11})"', js)
    from collections import Counter
    freq = Counter(all_strs)
    # Filter to likely RPC IDs (appear 1-3 times, mixed case)
    candidates = [(s, c) for s, c in freq.most_common(200)
                  if 1 <= c <= 5 and any(ch.isupper() for ch in s) and any(ch.islower() for ch in s)]
    print(f"  [Candidate IDs (1-5 occurrences, mixed case)]: {candidates[:30]}")

except FileNotFoundError:
    print("  JS file not found at /tmp/gsc_analytics.js")

# Step 3: If we have XSRF, retry with it
if xsrf:
    print(f"\nStep 3: Retrying batchexecute with XSRF token...")
    CANDIDATE_RPC_IDS = [
        "GetSitesList", "ListSites", "GetSites", "GetProperties", "ListProperties",
        "SearchAnalytics", "GetSearchAnalytics", "QuerySearchAnalytics",
        "InspectUrl", "GetUrlInspection", "UrlInspect",
    ]

    for rpc_id in CANDIDATE_RPC_IDS[:6]:
        # batchexecute with at= (XSRF) token
        payload = f"f.req={json.dumps([[[rpc_id, 'null', None, '1']]])}&at={xsrf}"
        body = curl_post(BE_URL, payload)
        anti = ")]}\'"
        ok = anti in body[:10]
        print(f"  [{rpc_id}]: ok={ok} {body[:100]!r}")

print("\nDone.")
