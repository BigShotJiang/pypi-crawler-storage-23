=========
Changelog
=========

Version 0.2.0
=============

- Added prefix-aware word generation for the Python API.
- Added the `momble` CLI for generating words from the terminal.
- Added XDG cache support for analyzed corpuses, including explicit rebuild support.
- Added CLI support for custom corpus files via `--corpus`.

Version 0.0.1
===========

- Initial Release
