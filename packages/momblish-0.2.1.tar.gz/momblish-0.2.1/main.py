def main():
    print("Hello from momblish!")


if __name__ == "__main__":
    main()
