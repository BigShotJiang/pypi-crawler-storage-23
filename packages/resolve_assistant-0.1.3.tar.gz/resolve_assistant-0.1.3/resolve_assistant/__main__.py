"""Entry point: python -m resolve_assistant"""

from . import mcp

mcp.run()
