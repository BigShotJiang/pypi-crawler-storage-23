"""
CVE-ready format generator
"""

from typing import Dict, Any, List
from datetime import datetime
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class CVEFormatter:
    """Formats findings as CVE-ready reports"""
    
    def format_as_cve(self, finding: Dict[str, Any], plugin_info: Dict[str, Any]) -> str:
        """Format a finding as CVE report"""
        cve_report = []
        
        # Title
        cve_report.append(f"# {finding.get('title', 'Security Vulnerability')}")
        cve_report.append("")
        
        # Overview
        cve_report.append("## Overview")
        cve_report.append(f"{finding.get('description', 'Security vulnerability detected')}")
        cve_report.append("")
        
        # Affected Product
        cve_report.append("## Affected Product")
        cve_report.append(f"- **Product**: {plugin_info.get('name', 'Unknown Plugin')}")
        cve_report.append(f"- **Vendor**: {plugin_info.get('author', 'Unknown')}")
        cve_report.append(f"- **Affected Version(s)**: {plugin_info.get('version', 'Unknown')}")
        cve_report.append("")
        
        # Vulnerability Details
        cve_report.append("## Vulnerability Details")
        cve_report.append(f"- **Type**: {finding.get('title', 'Unknown')}")
        cve_report.append(f"- **CWE**: {finding.get('cwe', 'N/A')}")
        cve_report.append(f"- **CVSS Score**: {finding.get('cvss', 'N/A')}")
        cve_report.append(f"- **Severity**: {finding.get('severity', 'medium').upper()}")
        cve_report.append("")
        
        # Technical Details
        cve_report.append("## Technical Details")
        cve_report.append(f"- **File**: `{finding.get('file', 'Unknown')}`")
        cve_report.append(f"- **Line**: {finding.get('line', 'N/A')}")
        
        if 'source' in finding:
            cve_report.append(f"- **Source**: `{finding['source']}`")
        if 'sink' in finding:
            cve_report.append(f"- **Sink**: `{finding['sink']}`")
        
        cve_report.append("")
        
        # Impact
        cve_report.append("## Impact")
        impact = self._generate_impact(finding)
        cve_report.append(impact)
        cve_report.append("")
        
        # Proof of Concept
        cve_report.append("## Proof of Concept")
        poc = self._generate_poc(finding)
        cve_report.append(poc)
        cve_report.append("")
        
        # Remediation
        cve_report.append("## Remediation")
        remediation = self._generate_remediation(finding)
        cve_report.append(remediation)
        cve_report.append("")
        
        # Timeline
        cve_report.append("## Timeline")
        cve_report.append(f"- **Discovered**: {datetime.now().strftime('%Y-%m-%d')}")
        cve_report.append(f"- **Reported**: [To be filled]")
        cve_report.append(f"- **Fixed**: [To be filled]")
        cve_report.append(f"- **Disclosed**: [To be filled]")
        cve_report.append("")
        
        # Credits
        cve_report.append("## Credits")
        cve_report.append("Discovered by: LAKSHMIKANTHAN K (letchupkt)")
        cve_report.append("Tool: PluginHunter")
        cve_report.append("")
        
        return '\n'.join(cve_report)
    
    def _generate_impact(self, finding: Dict[str, Any]) -> str:
        """Generate impact description"""
        category = finding.get('rule_id', '').split('-')[0] if '-' in finding.get('rule_id', '') else ''
        
        impacts = {
            'sqli': 'An attacker can execute arbitrary SQL queries, potentially leading to unauthorized data access, modification, or deletion. This could result in complete database compromise.',
            'xss': 'An attacker can inject malicious scripts that execute in victims\' browsers, potentially stealing session cookies, credentials, or performing actions on behalf of the victim.',
            'rce': 'An attacker can execute arbitrary code on the server, potentially leading to complete server compromise, data theft, or service disruption.',
            'csrf': 'An attacker can trick authenticated users into performing unintended actions, potentially leading to unauthorized changes or data manipulation.',
            'ssrf': 'An attacker can make the server perform requests to arbitrary URLs, potentially accessing internal services or exfiltrating data.',
            'file_upload': 'An attacker can upload malicious files, potentially leading to remote code execution or defacement.',
            'deserialization': 'An attacker can execute arbitrary code by providing malicious serialized data, potentially leading to complete server compromise.',
            'auth': 'An attacker can bypass authentication or authorization checks, potentially gaining unauthorized access to sensitive functionality or data.'
        }
        
        return impacts.get(category, 'This vulnerability could allow an attacker to compromise the security of the application.')
    
    def _generate_poc(self, finding: Dict[str, Any]) -> str:
        """Generate proof of concept"""
        poc = "```\n"
        poc += f"# Vulnerability Location\n"
        poc += f"File: {finding.get('file', 'Unknown')}\n"
        poc += f"Line: {finding.get('line', 'N/A')}\n\n"
        
        if 'source' in finding and 'sink' in finding:
            poc += f"# Data Flow\n"
            poc += f"Source: {finding['source']}\n"
            poc += f"Sink: {finding['sink']}\n\n"
        
        poc += "# Exploitation Steps\n"
        poc += "[To be filled with specific exploitation steps]\n"
        poc += "```"
        
        return poc
    
    def _generate_remediation(self, finding: Dict[str, Any]) -> str:
        """Generate remediation advice"""
        category = finding.get('rule_id', '').split('-')[0] if '-' in finding.get('rule_id', '') else ''
        
        remediations = {
            'sqli': '1. Use prepared statements with parameterized queries\n2. Use $wpdb->prepare() for all database queries\n3. Validate and sanitize all user input\n4. Use appropriate escaping functions',
            'xss': '1. Use esc_html(), esc_attr(), esc_url() for output escaping\n2. Validate and sanitize all user input\n3. Use wp_kses() for HTML content\n4. Implement Content Security Policy',
            'rce': '1. Avoid using dangerous functions (eval, exec, system)\n2. Never pass user input to code execution functions\n3. Use whitelisting for allowed values\n4. Implement strict input validation',
            'csrf': '1. Implement nonce verification using wp_verify_nonce()\n2. Check nonces for all state-changing operations\n3. Use check_ajax_referer() for AJAX requests\n4. Verify user capabilities',
            'ssrf': '1. Validate and whitelist allowed URLs\n2. Use wp_http_validate_url()\n3. Implement URL parsing and validation\n4. Restrict access to internal networks',
            'file_upload': '1. Validate file types using wp_check_filetype()\n2. Check MIME types\n3. Restrict file extensions\n4. Store uploads outside webroot\n5. Implement file size limits',
            'deserialization': '1. Avoid unserialize() with user input\n2. Use JSON instead of PHP serialization\n3. Implement signature verification\n4. Validate data before unserialization',
            'auth': '1. Implement current_user_can() checks\n2. Verify user capabilities for all sensitive operations\n3. Use wp_verify_nonce() for CSRF protection\n4. Implement proper permission_callback for REST routes'
        }
        
        return remediations.get(category, '1. Review and fix the vulnerable code\n2. Implement proper input validation\n3. Use WordPress security functions\n4. Test thoroughly')
    
    def generate_bulk_cve_report(self, findings: List[Dict[str, Any]], 
                                 plugin_info: Dict[str, Any], output_file: str):
        """Generate CVE reports for all critical/high findings"""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("# CVE Reports\n\n")
                f.write(f"Plugin: {plugin_info.get('name', 'Unknown')}\n")
                f.write(f"Version: {plugin_info.get('version', 'Unknown')}\n\n")
                f.write("---\n\n")
                
                for i, finding in enumerate(findings, 1):
                    if finding.get('severity') in ['critical', 'high']:
                        f.write(f"\n\n# Vulnerability #{i}\n\n")
                        cve_report = self.format_as_cve(finding, plugin_info)
                        f.write(cve_report)
                        f.write("\n\n---\n")
            
            logger.info(f"CVE reports saved to {output_file}")
        except Exception as e:
            logger.error(f"Failed to generate CVE reports: {e}")