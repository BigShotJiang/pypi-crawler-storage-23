"""
Report generation in multiple formats
"""

import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class ReportGenerator:
    """Generates vulnerability reports in various formats"""
    
    def generate_json_report(self, scan_result: Dict[str, Any], output_file: Path):
        """Generate JSON report"""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(scan_result, f, indent=2, default=str)
            
            logger.info(f"JSON report saved to {output_file}")
        except Exception as e:
            logger.error(f"Failed to generate JSON report: {e}")
    
    def generate_markdown_report(self, scan_result: Dict[str, Any], output_file: Path):
        """Generate Markdown report"""
        try:
            md = self._build_markdown(scan_result)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(md)
            
            logger.info(f"Markdown report saved to {output_file}")
        except Exception as e:
            logger.error(f"Failed to generate Markdown report: {e}")
    
    def _build_markdown(self, scan_result: Dict[str, Any]) -> str:
        """Build Markdown report content"""
        md = []
        
        # Header
        md.append("# PluginHunter Scan Report\n")
        md.append(f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        md.append(f"**Scan ID**: {scan_result.get('scan_id', 'N/A')}\n")
        
        # Plugin Info
        plugin_info = scan_result.get('plugin_info', {})
        md.append("\n## Plugin Information\n")
        md.append(f"- **Name**: {plugin_info.get('name', 'Unknown')}")
        md.append(f"- **Version**: {plugin_info.get('version', 'Unknown')}")
        md.append(f"- **Author**: {plugin_info.get('author', 'Unknown')}")
        md.append(f"- **Description**: {plugin_info.get('description', 'N/A')}\n")
        
        # Statistics
        stats = scan_result.get('statistics', {})
        md.append("\n## Scan Statistics\n")
        md.append(f"- **Duration**: {stats.get('duration', 0):.2f} seconds")
        md.append(f"- **Files Scanned**: {stats.get('files_scanned', 0)}")
        md.append(f"- **Total Findings**: {stats.get('total_findings', 0)}\n")
        
        # Severity Breakdown
        severity_counts = stats.get('severity_counts', {})
        md.append("\n### Severity Breakdown\n")
        md.append(f"- **Critical**: {severity_counts.get('critical', 0)}")
        md.append(f"- **High**: {severity_counts.get('high', 0)}")
        md.append(f"- **Medium**: {severity_counts.get('medium', 0)}")
        md.append(f"- **Low**: {severity_counts.get('low', 0)}\n")
        
        # Findings
        findings = scan_result.get('findings', [])
        if findings:
            md.append("\n## Vulnerabilities Found\n")
            
            # Group by severity
            by_severity = self._group_by_severity(findings)
            
            for severity in ['critical', 'high', 'medium', 'low']:
                if severity in by_severity and by_severity[severity]:
                    md.append(f"\n### {severity.upper()} Severity\n")
                    
                    for finding in by_severity[severity]:
                        md.append(f"\n#### {finding.get('title', 'Unknown')}\n")
                        md.append(f"- **File**: `{finding.get('file', 'Unknown')}`")
                        md.append(f"- **Line**: {finding.get('line', 'N/A')}")
                        md.append(f"- **CWE**: {finding.get('cwe', 'N/A')}")
                        md.append(f"- **Confidence**: {finding.get('confidence', 'N/A')}")
                        md.append(f"- **Description**: {finding.get('description', 'N/A')}")
                        
                        if 'source' in finding:
                            md.append(f"- **Source**: `{finding['source']}`")
                        if 'sink' in finding:
                            md.append(f"- **Sink**: `{finding['sink']}`")
                        
                        md.append("")
        else:
            md.append("\n## No Vulnerabilities Found\n")
            md.append("Great job! No security issues were detected.\n")
        
        # WordPress Analysis
        hook_map = scan_result.get('hook_map', {})
        if hook_map:
            hook_stats = hook_map.get('statistics', {})
            md.append("\n## WordPress Analysis\n")
            md.append(f"- **Total Actions**: {hook_stats.get('total_actions', 0)}")
            md.append(f"- **Total Filters**: {hook_stats.get('total_filters', 0)}")
            md.append(f"- **AJAX Endpoints**: {hook_stats.get('total_ajax', 0)}")
            md.append(f"  - Public: {hook_stats.get('public_ajax', 0)}")
            md.append(f"  - Admin: {hook_stats.get('admin_ajax', 0)}\n")
        
        rest_map = scan_result.get('rest_map', {})
        if rest_map:
            rest_stats = rest_map.get('statistics', {})
            md.append("\n### REST API\n")
            md.append(f"- **Total Endpoints**: {rest_stats.get('total_endpoints', 0)}")
            md.append(f"- **Namespaces**: {rest_stats.get('total_namespaces', 0)}")
            md.append(f"- **Public Endpoints**: {rest_stats.get('public_endpoints', 0)}")
            md.append(f"- **Insecure Endpoints**: {rest_stats.get('insecure_endpoints', 0)}\n")
        
        # Footer
        md.append("\n---\n")
        md.append("*Report generated by PluginHunter*\n")
        md.append("*Author: LAKSHMIKANTHAN K (letchupkt)*\n")
        
        return '\n'.join(md)
    
    def _group_by_severity(self, findings: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """Group findings by severity"""
        grouped = {'critical': [], 'high': [], 'medium': [], 'low': []}
        
        for finding in findings:
            severity = finding.get('severity', 'medium')
            if severity in grouped:
                grouped[severity].append(finding)
        
        return grouped
    
    def generate_html_report(self, scan_result: Dict[str, Any], output_file: Path):
        """Generate HTML report"""
        try:
            html = self._build_html(scan_result)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(html)
            
            logger.info(f"HTML report saved to {output_file}")
        except Exception as e:
            logger.error(f"Failed to generate HTML report: {e}")
    
    def _build_html(self, scan_result: Dict[str, Any]) -> str:
        """Build HTML report content"""
        # Basic HTML template
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>PluginHunter Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        .critical {{ color: #d32f2f; }}
        .high {{ color: #f57c00; }}
        .medium {{ color: #fbc02d; }}
        .low {{ color: #1976d2; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
    </style>
</head>
<body>
    <h1>PluginHunter Scan Report</h1>
    <p><strong>Scan ID:</strong> {scan_result.get('scan_id', 'N/A')}</p>
    <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    
    <h2>Summary</h2>
    <p>Total Findings: {scan_result.get('statistics', {}).get('total_findings', 0)}</p>
    
    <h2>Findings</h2>
    <table>
        <tr>
            <th>Severity</th>
            <th>Title</th>
            <th>File</th>
            <th>Line</th>
        </tr>
"""
        
        for finding in scan_result.get('findings', []):
            severity = finding.get('severity', 'medium')
            html += f"""
        <tr>
            <td class="{severity}">{severity.upper()}</td>
            <td>{finding.get('title', 'Unknown')}</td>
            <td>{finding.get('file', 'Unknown')}</td>
            <td>{finding.get('line', 'N/A')}</td>
        </tr>
"""
        
        html += """
    </table>
</body>
</html>
"""
        
        return html