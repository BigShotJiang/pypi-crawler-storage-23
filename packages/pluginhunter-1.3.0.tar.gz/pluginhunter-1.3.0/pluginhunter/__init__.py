"""
PluginHunter: Advanced WordPress Plugin Vulnerability Scanner
Author: LAKSHMIKANTHAN K (letchupkt)
Version: 1.3.0
License: MIT
"""

__version__ = "1.3.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
__license__ = "MIT"

from .scanner import VulnerabilityScanner
from .config import Config

__all__ = ["VulnerabilityScanner", "Config"]
