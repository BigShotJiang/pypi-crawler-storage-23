# WP-VulnHunter Detection Rules

## Rules Organization

All detection rules are organized by vulnerability category in this directory structure:

```
data/
├── csrf/                           # CSRF Protection Rules
│   └── hooks/
│       ├── wp-hook-missing-csrf-protection-class-method.yml
│       ├── wp-hook-missing-csrf-protection-closures.yml
│       └── wp-hook-missing-csrf-protection-functions.yml
│
├── xss/                            # Cross-Site Scripting Rules
│   └── wp-reflected-xss.yml
│
├── deserialization/                # Object Injection Rules
│   └── wp-php-object-injection-audit.yml
│
├── missing-auth/                   # Authorization Rules
│   ├── hooks/
│   │   ├── wp-hook-missing-auth-class-method.yml
│   │   ├── wp-hook-missing-auth-closures.yml
│   │   └── wp-hook-missing-auth-functions.yml
│   └── rest-route/
│       ├── wp-missing-auth-rest-route-closures.yml
│       └── wp-return-true-rest-route.yml
│
├── misc/                           # Miscellaneous Rules
│   ├── wp-missing-direct-access-check.yml
│   └── wp-open-redirect-audit.yml
│
└── pro/                            # Advanced Rules
    └── missing-auth/
        └── wp-pro-missing-auth.yml
```

## Rule Format

Rules support both formats:

### 1. Semgrep-Style Format (from GitHub)
```yaml
rules:
  - id: rule-id
    mode: taint
    message: Description
    languages: [php]
    severity: WARNING
    pattern-sources:
      - patterns:
        - pattern: $_GET[$KEY]
    pattern-sinks:
      - pattern: echo (...);
    pattern-sanitizers:
      - patterns:
        - pattern: $SANITIZER(...)
    metadata:
      cwe: ["CWE-79"]
      category: security
```

### 2. Custom Format
```yaml
id: rule-id
title: Rule Title
description: Description
severity: high
cwe: CWE-79
cvss: 7.5
category: xss
sources:
  - $_GET
  - $_POST
sinks:
  - echo
sanitizers:
  - esc_html
```

## Rule Categories

- **csrf** - Cross-Site Request Forgery detection
- **xss** - Cross-Site Scripting detection
- **deserialization** - PHP Object Injection detection
- **missing-auth** - Authorization bypass detection
- **misc** - Other security issues
- **pro** - Advanced detection rules

## Adding Custom Rules

1. Create a new YAML file in the appropriate category directory
2. Follow either the Semgrep or custom format
3. Rules are automatically loaded on next scan

Example:
```bash
# Add custom rule
echo "your-rule-content" > wp_vulnhunter/data/xss/my-custom-xss.yml

# Or use custom rules directory
wp-vulnhunter scan --source local --target ./plugin \
  --rules-dir /path/to/custom/rules
```

## Rule Statistics

Total Rules: 13
- CSRF: 3 rules
- XSS: 1 rule
- Deserialization: 1 rule
- Missing Auth: 6 rules
- Miscellaneous: 2 rules

## Rule Sources

Rules are sourced from:
- Custom WP-VulnHunter rules
- Semgrep WordPress security rules
- Community contributions

## Severity Levels

- **ERROR** → Critical
- **WARNING** → High
- **INFO** → Medium

## References

- [Semgrep Rules](https://github.com/semgrep/semgrep-rules)
- [WordPress Security](https://developer.wordpress.org/apis/security/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
