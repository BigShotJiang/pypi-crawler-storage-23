"""
File loading utilities for PluginHunter
"""

import os
import zipfile
import tempfile
import shutil
import requests
from pathlib import Path
from typing import Optional, List, Dict, Any
import subprocess
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class FileLoader:
    """Handles loading files from various sources"""
    
    def __init__(self):
        self.temp_dirs: List[str] = []
    
    def load_from_source(self, source_type: str, target: str) -> Optional[Path]:
        """Load files from specified source"""
        try:
            if source_type == "local":
                return self._load_local(target)
            elif source_type == "zip":
                return self._load_zip(target)
            elif source_type == "slug":
                return self._load_wordpress_plugin(target)
            elif source_type == "github":
                return self._load_github(target)
            else:
                logger.error(f"Unsupported source type: {source_type}")
                return None
        except Exception as e:
            logger.error(f"Failed to load from {source_type}: {e}")
            return None
    
    def _load_local(self, path: str) -> Optional[Path]:
        """Load from local directory or file"""
        local_path = Path(path)
        if not local_path.exists():
            logger.error(f"Local path does not exist: {path}")
            return None
        
        if local_path.is_file() and local_path.suffix == '.zip':
            return self._extract_zip(local_path)
        elif local_path.is_dir():
            return local_path
        else:
            logger.error(f"Unsupported local file type: {path}")
            return None
    
    def _load_zip(self, zip_path: str) -> Optional[Path]:
        """Load from ZIP file"""
        zip_file = Path(zip_path)
        if not zip_file.exists():
            logger.error(f"ZIP file does not exist: {zip_path}")
            return None
        
        return self._extract_zip(zip_file)
    
    def _extract_zip(self, zip_path: Path) -> Optional[Path]:
        """Extract ZIP file to temporary directory"""
        temp_dir = tempfile.mkdtemp(prefix="pluginhunter_")
        self.temp_dirs.append(temp_dir)
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Find the main plugin directory
            extracted_items = list(Path(temp_dir).iterdir())
            if len(extracted_items) == 1 and extracted_items[0].is_dir():
                return extracted_items[0]
            else:
                return Path(temp_dir)
        except Exception as e:
            logger.error(f"Failed to extract ZIP: {e}")
            return None
    
    def _load_wordpress_plugin(self, slug: str) -> Optional[Path]:
        """Download plugin from WordPress.org repository"""
        download_url = f"https://downloads.wordpress.org/plugin/{slug}.latest-stable.zip"
        
        try:
            response = requests.get(download_url, timeout=30)
            response.raise_for_status()
            
            temp_dir = tempfile.mkdtemp(prefix="pluginhunter_")
            self.temp_dirs.append(temp_dir)
            
            zip_path = Path(temp_dir) / f"{slug}.zip"
            with open(zip_path, 'wb') as f:
                f.write(response.content)
            
            return self._extract_zip(zip_path)
        except Exception as e:
            logger.error(f"Failed to download WordPress plugin {slug}: {e}")
            return None
    
    def _load_github(self, repo_url: str) -> Optional[Path]:
        """Clone from GitHub repository"""
        temp_dir = tempfile.mkdtemp(prefix="pluginhunter_")
        self.temp_dirs.append(temp_dir)
        
        try:
            # Extract repo info from URL
            if repo_url.startswith("https://github.com/"):
                repo_url = repo_url.replace("https://github.com/", "")
            
            if not repo_url.endswith(".git"):
                repo_url += ".git"
            
            clone_url = f"https://github.com/{repo_url}"
            
            result = subprocess.run(
                ["git", "clone", clone_url, temp_dir],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                return Path(temp_dir)
            else:
                logger.error(f"Git clone failed: {result.stderr}")
                return None
        except Exception as e:
            logger.error(f"Failed to clone GitHub repository: {e}")
            return None
    
    def find_php_files(self, directory: Path) -> List[Path]:
        """Find all PHP files in directory"""
        php_files = []
        
        for root, dirs, files in os.walk(directory):
            # Skip common non-plugin directories
            dirs[:] = [d for d in dirs if d not in ['.git', 'node_modules', '.svn', '__pycache__']]
            
            for file in files:
                if file.endswith('.php'):
                    php_files.append(Path(root) / file)
        
        return php_files
    
    def get_plugin_info(self, directory: Path) -> Dict[str, Any]:
        """Extract plugin information from main plugin file"""
        info = {
            'name': directory.name,
            'version': 'unknown',
            'description': '',
            'author': '',
            'main_file': None
        }
        
        # Look for main plugin file
        php_files = self.find_php_files(directory)
        
        for php_file in php_files:
            try:
                with open(php_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(2048)  # Read first 2KB
                    
                    if 'Plugin Name:' in content:
                        info['main_file'] = php_file
                        
                        # Extract plugin header information
                        lines = content.split('\n')
                        for line in lines:
                            line = line.strip()
                            if line.startswith('Plugin Name:'):
                                info['name'] = line.split(':', 1)[1].strip()
                            elif line.startswith('Version:'):
                                info['version'] = line.split(':', 1)[1].strip()
                            elif line.startswith('Description:'):
                                info['description'] = line.split(':', 1)[1].strip()
                            elif line.startswith('Author:'):
                                info['author'] = line.split(':', 1)[1].strip()
                        break
            except Exception as e:
                logger.debug(f"Error reading {php_file}: {e}")
                continue
        
        return info
    
    def cleanup(self):
        """Clean up temporary directories"""
        for temp_dir in self.temp_dirs:
            try:
                shutil.rmtree(temp_dir)
            except Exception as e:
                logger.warning(f"Failed to cleanup {temp_dir}: {e}")
        
        self.temp_dirs.clear()
    
    def __del__(self):
        """Cleanup on destruction"""
        self.cleanup()