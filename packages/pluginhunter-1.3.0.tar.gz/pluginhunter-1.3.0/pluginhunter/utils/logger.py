"""
Logging utilities for PluginHunter
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from rich.logging import RichHandler
from rich.console import Console


def setup_logger(name: str, level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """Setup logger with rich formatting"""
    
    logger = logging.getLogger(name)
    
    # Avoid duplicate handlers
    if logger.handlers:
        return logger
    
    logger.setLevel(getattr(logging, level.upper()))
    
    # Console handler with rich formatting
    console = Console(stderr=True)
    rich_handler = RichHandler(
        console=console,
        show_time=True,
        show_path=False,
        markup=True,
        rich_tracebacks=True
    )
    rich_handler.setLevel(getattr(logging, level.upper()))
    
    # Format for console
    console_format = "%(message)s"
    rich_handler.setFormatter(logging.Formatter(console_format))
    
    logger.addHandler(rich_handler)
    
    # File handler if specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(logging.DEBUG)
        
        # Detailed format for file
        file_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        file_handler.setFormatter(logging.Formatter(file_format))
        
        logger.addHandler(file_handler)
    
    return logger


class ScanLogger:
    """Specialized logger for scan operations"""
    
    def __init__(self, scan_id: str):
        self.scan_id = scan_id
        self.logger = setup_logger(f"pluginhunter.scan.{scan_id}")
        self.findings_count = 0
        self.files_scanned = 0
    
    def log_scan_start(self, target: str, source_type: str):
        """Log scan start"""
        self.logger.info(f"[bold green]Starting scan[/bold green] - Target: {target} ({source_type})")
    
    def log_scan_complete(self, duration: float):
        """Log scan completion"""
        self.logger.info(
            f"[bold green]Scan complete[/bold green] - "
            f"Files: {self.files_scanned}, "
            f"Findings: {self.findings_count}, "
            f"Duration: {duration:.2f}s"
        )
    
    def log_file_scan(self, file_path: str):
        """Log file being scanned"""
        self.files_scanned += 1
        self.logger.debug(f"Scanning: {file_path}")
    
    def log_finding(self, severity: str, title: str, file_path: str, line: int):
        """Log vulnerability finding"""
        self.findings_count += 1
        severity_colors = {
            "critical": "red",
            "high": "orange3",
            "medium": "yellow",
            "low": "blue"
        }
        color = severity_colors.get(severity.lower(), "white")
        
        self.logger.warning(
            f"[{color}]{severity.upper()}[/{color}] - {title} "
            f"in {file_path}:{line}"
        )
    
    def log_error(self, message: str, exception: Optional[Exception] = None):
        """Log error"""
        if exception:
            self.logger.error(f"[red]ERROR[/red]: {message} - {exception}")
        else:
            self.logger.error(f"[red]ERROR[/red]: {message}")
    
    def log_warning(self, message: str):
        """Log warning"""
        self.logger.warning(f"[yellow]WARNING[/yellow]: {message}")
    
    def log_info(self, message: str):
        """Log info"""
        self.logger.info(message)
    
    def log_debug(self, message: str):
        """Log debug"""
        self.logger.debug(message)