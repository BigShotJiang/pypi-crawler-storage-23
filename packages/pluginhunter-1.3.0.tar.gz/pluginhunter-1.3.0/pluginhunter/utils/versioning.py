"""
Version management utilities for PluginHunter
"""

import re
from typing import Optional, Tuple, List
from packaging import version


class VersionManager:
    """Handles version parsing and comparison"""
    
    @staticmethod
    def parse_version(version_string: str) -> Optional[version.Version]:
        """Parse version string into Version object"""
        try:
            # Clean up version string
            clean_version = re.sub(r'[^\d\.]', '', version_string)
            if not clean_version:
                return None
            
            return version.parse(clean_version)
        except Exception:
            return None
    
    @staticmethod
    def is_vulnerable_version(current_version: str, vulnerable_ranges: List[str]) -> bool:
        """Check if current version is in vulnerable range"""
        current_ver = VersionManager.parse_version(current_version)
        if not current_ver:
            return False
        
        for range_spec in vulnerable_ranges:
            if VersionManager._version_in_range(current_ver, range_spec):
                return True
        
        return False
    
    @staticmethod
    def _version_in_range(ver: version.Version, range_spec: str) -> bool:
        """Check if version is in specified range"""
        try:
            # Handle different range formats
            if '<=' in range_spec:
                max_ver = VersionManager.parse_version(range_spec.replace('<=', '').strip())
                return max_ver and ver <= max_ver
            elif '<' in range_spec:
                max_ver = VersionManager.parse_version(range_spec.replace('<', '').strip())
                return max_ver and ver < max_ver
            elif '>=' in range_spec:
                min_ver = VersionManager.parse_version(range_spec.replace('>=', '').strip())
                return min_ver and ver >= min_ver
            elif '>' in range_spec:
                min_ver = VersionManager.parse_version(range_spec.replace('>', '').strip())
                return min_ver and ver > min_ver
            elif '==' in range_spec or '=' in range_spec:
                target_ver = VersionManager.parse_version(range_spec.replace('==', '').replace('=', '').strip())
                return target_ver and ver == target_ver
            elif '-' in range_spec:
                # Range format: "1.0-2.0"
                parts = range_spec.split('-')
                if len(parts) == 2:
                    min_ver = VersionManager.parse_version(parts[0].strip())
                    max_ver = VersionManager.parse_version(parts[1].strip())
                    return min_ver and max_ver and min_ver <= ver <= max_ver
            else:
                # Exact match
                target_ver = VersionManager.parse_version(range_spec.strip())
                return target_ver and ver == target_ver
        except Exception:
            pass
        
        return False
    
    @staticmethod
    def extract_wordpress_version(content: str) -> Optional[str]:
        """Extract WordPress version from plugin file"""
        patterns = [
            r'Requires at least:\s*([0-9\.]+)',
            r'Tested up to:\s*([0-9\.]+)',
            r'WP_VERSION.*?([0-9\.]+)',
            r'wordpress.*?([0-9\.]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    @staticmethod
    def extract_plugin_version(content: str) -> Optional[str]:
        """Extract plugin version from plugin header"""
        patterns = [
            r'Version:\s*([0-9\.]+)',
            r'define\s*\(\s*[\'"].*?VERSION[\'"].*?[\'"]([0-9\.]+)[\'"]',
            r'\$version\s*=\s*[\'"]([0-9\.]+)[\'"]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    @staticmethod
    def get_version_info(plugin_content: str) -> dict:
        """Extract all version information from plugin"""
        return {
            'plugin_version': VersionManager.extract_plugin_version(plugin_content),
            'wordpress_version': VersionManager.extract_wordpress_version(plugin_content),
            'requires_php': VersionManager._extract_php_version(plugin_content)
        }
    
    @staticmethod
    def _extract_php_version(content: str) -> Optional[str]:
        """Extract required PHP version"""
        patterns = [
            r'Requires PHP:\s*([0-9\.]+)',
            r'PHP_VERSION_ID.*?([0-9]+)',
            r'version_compare.*?PHP_VERSION.*?[\'"]([0-9\.]+)[\'"]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                version_str = match.group(1)
                if len(version_str) > 5:  # Handle PHP_VERSION_ID format
                    # Convert 70400 to 7.4.0
                    major = version_str[0]
                    minor = version_str[1:3].lstrip('0') or '0'
                    patch = version_str[3:5].lstrip('0') or '0'
                    return f"{major}.{minor}.{patch}"
                return version_str
        
        return None