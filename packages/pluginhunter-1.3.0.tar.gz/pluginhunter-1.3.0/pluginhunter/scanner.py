"""
Main vulnerability scanner
"""

import time
from pathlib import Path
from typing import Dict, List, Any, Optional
from .config import Config
from .engine.ast_parser import ASTParser
from .engine.taint_engine import TaintEngine
from .engine.flow_tracker import FlowTracker
from .engine.wordpress_analyzer import WordPressAnalyzer
from .engine.hook_mapper import HookMapper
from .engine.rest_mapper import RESTMapper
from .engine.pattern_matcher import PatternMatcher
from .engine.taint_analyzer import TaintAnalyzer
from .rules.loader import RuleLoader
from .utils.file_loader import FileLoader
from .utils.logger import ScanLogger
from .utils.versioning import VersionManager
from .reporting.report_generator import ReportGenerator
from .reporting.cve_formatter import CVEFormatter
from .dynamic.exploit_tester import ExploitTester
import uuid

class VulnerabilityScanner:
    """Main vulnerability scanner"""
    
    def __init__(self, config: Config):
        self.config = config
        self.scan_id = str(uuid.uuid4())[:8]
        self.logger = ScanLogger(self.scan_id)
        
        # Initialize components
        self.file_loader = FileLoader()
        self.ast_parser = ASTParser()
        self.flow_tracker = FlowTracker()
        self.taint_engine = TaintEngine(self.flow_tracker)
        self.pattern_matcher = PatternMatcher(self.ast_parser)
        self.taint_analyzer = TaintAnalyzer(self.ast_parser, self.pattern_matcher)
        self.wordpress_analyzer = WordPressAnalyzer(self.ast_parser)
        self.hook_mapper = HookMapper()
        self.rest_mapper = RESTMapper()
        self.rule_loader = RuleLoader()
        self.report_generator = ReportGenerator()
        self.exploit_tester = ExploitTester() if config.scan_config.dynamic_verification else None
        
        # Load rules
        self._load_rules()
        
        # Scan results
        self.findings: List[Dict[str, Any]] = []
        self.plugin_info: Dict[str, Any] = {}
        self.scan_stats: Dict[str, Any] = {}
    
    def _load_rules(self):
        """Load vulnerability detection rules"""
        rule_dirs = self.config.get_rules_directories()
        self.rule_loader.load_rules_from_directories(rule_dirs)
        
        stats = self.rule_loader.get_rule_stats()
        self.logger.log_info(f"Loaded {stats['total_rules']} rules in {stats['categories']} categories")
    
    def scan(self) -> Dict[str, Any]:
        """Perform vulnerability scan"""
        start_time = time.time()
        
        self.logger.log_scan_start(
            self.config.scan_config.target,
            self.config.scan_config.source_type
        )
        
        # Load target files
        target_path = self.file_loader.load_from_source(
            self.config.scan_config.source_type,
            self.config.scan_config.target
        )
        
        if not target_path:
            self.logger.log_error("Failed to load target")
            return self._generate_error_result("Failed to load target")
        
        # Get plugin info
        self.plugin_info = self.file_loader.get_plugin_info(target_path)
        self.logger.log_info(f"Scanning plugin: {self.plugin_info.get('name', 'Unknown')}")
        
        # Find PHP files
        php_files = self.file_loader.find_php_files(target_path)
        self.logger.log_info(f"Found {len(php_files)} PHP files")
        
        # Scan each file
        for php_file in php_files:
            self._scan_file(php_file)
        
        # Perform WordPress-specific analysis
        self._perform_wordpress_analysis()
        
        # Dynamic verification if enabled
        if self.config.scan_config.dynamic_verification and self.exploit_tester:
            self._perform_dynamic_verification(target_path)
        
        # Calculate statistics
        duration = time.time() - start_time
        self._calculate_stats(duration)
        
        self.logger.log_scan_complete(duration)
        
        # Generate result
        result = self._generate_result()
        
        # Auto-save reports to current directory
        self._auto_save_reports(result)
        
        # Cleanup
        self.file_loader.cleanup()
        
        return result
    
    def _auto_save_reports(self, result: Dict[str, Any]):
        """Automatically save reports to current directory"""
        try:
            plugin_name = self.plugin_info.get('name', 'unknown').replace(' ', '-').lower()
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            
            # Save JSON report
            json_file = self.config.get_output_path(f"scan_{plugin_name}_{timestamp}.json")
            self.report_generator.generate_json_report(result, json_file)
            
            # Save HTML report
            html_file = self.config.get_output_path(f"scan_{plugin_name}_{timestamp}.html")
            self.report_generator.generate_html_report(result, html_file)
            
            # Save CVE report if critical/high findings
            critical_high = [f for f in self.findings if f.get('severity') in ['critical', 'high']]
            if critical_high:
                cve_file = self.config.get_output_path(f"scan_{plugin_name}_{timestamp}_cve.md")
                cve_formatter = CVEFormatter()
                cve_formatter.generate_bulk_cve_report(critical_high, self.plugin_info, str(cve_file))
            
            self.logger.log_info(f"Reports saved to: {json_file.parent}")
            
        except Exception as e:
            self.logger.log_error(f"Failed to auto-save reports: {e}")
    
    def _scan_file(self, file_path: Path):
        """Scan a single PHP file"""
        self.logger.log_file_scan(str(file_path))
        
        try:
            # Read file content
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            
            # Parse file
            ast_root = self.ast_parser.parse_file(file_path)
            if not ast_root:
                return
            
            # Set current file for flow tracker
            self.flow_tracker.set_current_file(file_path)
            
            # Extract AST data
            ast_data = self._extract_ast_data(ast_root)
            
            # Perform WordPress analysis
            wp_analysis = self.wordpress_analyzer.analyze_file(file_path, ast_root)
            
            # Process hooks and REST endpoints
            self.hook_mapper.process_hooks_from_ast(wp_analysis.get('hooks', []), file_path)
            self.rest_mapper.process_rest_routes_from_ast(wp_analysis.get('rest_endpoints', []), file_path)
            
            # Run rule-based detection with new taint analyzer
            self._run_rule_detection(file_path, ast_root, code, ast_data, wp_analysis)
            
        except Exception as e:
            self.logger.log_error(f"Error scanning {file_path}", e)
    
    def _extract_ast_data(self, ast_root) -> Dict[str, Any]:
        """Extract relevant data from AST"""
        return {
            'function_calls': self.ast_parser.find_function_calls(ast_root, []),
            'superglobals': self.ast_parser.find_superglobals(ast_root),
            'sql_queries': self.ast_parser.find_sql_queries(ast_root),
            'echo_statements': self.ast_parser.find_echo_statements(ast_root),
            'file_operations': self.ast_parser.find_file_operations(ast_root),
            'unserialize_calls': self.ast_parser.find_unserialize_calls(ast_root),
            'remote_requests': self.ast_parser.find_remote_requests(ast_root),
            'includes': self.ast_parser.find_includes(ast_root)
        }
    
    def _run_rule_detection(self, file_path: Path, ast_root, code: str, 
                           ast_data: Dict[str, Any], wp_analysis: Dict[str, Any]):
        """Run detection based on loaded rules using pattern matching"""
        for rule in self.rule_loader.get_all_rules():
            try:
                # Convert VulnerabilityRule to dict for taint analyzer
                rule_dict = {
                    'id': rule.id,
                    'message': rule.title,
                    'severity': rule.severity,
                    'pattern-sources': self._convert_sources_to_patterns(rule.sources),
                    'pattern-sinks': self._convert_sinks_to_patterns(rule.sinks),
                    'pattern-sanitizers': self._convert_sanitizers_to_patterns(rule.sanitizers),
                    'metadata': {
                        'cwe': [rule.cwe] if rule.cwe else [],
                        'confidence': 'MEDIUM',
                        'category': rule.category
                    }
                }
                
                # Determine mode based on whether we have sources/sinks
                if rule.sources and rule.sinks:
                    # Use taint analysis for source-sink-sanitizer rules
                    findings = self.taint_analyzer.analyze_taint_rule(
                        rule_dict, ast_root, code, file_path
                    )
                    for finding in findings:
                        self._add_finding(finding, file_path)
                
                elif rule.pattern or rule.regex:
                    # Use simple pattern matching for search rules
                    findings = self.taint_analyzer.analyze_search_rule(
                        rule_dict, ast_root, code, file_path
                    )
                    for finding in findings:
                        self._add_finding(finding, file_path)
                
            except Exception as e:
                self.logger.log_debug(f"Error running rule {rule.id}: {e}")
    
    def _convert_sources_to_patterns(self, sources: List[str]) -> List[Dict[str, Any]]:
        """Convert source strings to Semgrep-style patterns"""
        patterns = []
        for source in sources:
            if source.startswith('$_'):
                # Superglobal pattern
                patterns.append({
                    'patterns': [
                        {'pattern': f'{source}[$KEY]'}
                    ]
                })
            else:
                patterns.append({'pattern': source})
        return patterns
    
    def _convert_sinks_to_patterns(self, sinks: List[str]) -> List[Dict[str, Any]]:
        """Convert sink strings to Semgrep-style patterns"""
        patterns = []
        for sink in sinks:
            patterns.append({'pattern': f'{sink}(...);'})
        return patterns
    
    def _convert_sanitizers_to_patterns(self, sanitizers: List[str]) -> List[Dict[str, Any]]:
        """Convert sanitizer strings to Semgrep-style patterns"""
        if not sanitizers:
            return []
        
        # Create regex pattern from sanitizer list
        regex_pattern = '(' + '|'.join(sanitizers) + ')'
        
        return [{
            'patterns': [
                {'pattern': '$SANITIZER(...)'},
                {'metavariable-regex': {
                    'metavariable': '$SANITIZER',
                    'regex': regex_pattern
                }}
            ]
        }]
    
    def _detect_rce(self, ast_data: Dict[str, Any], rule) -> List[Dict[str, Any]]:
        """Detect RCE vulnerabilities"""
        vulnerabilities = []
        dangerous_functions = ['eval', 'system', 'exec', 'shell_exec', 'passthru', 'popen', 'proc_open']
        
        for call in ast_data.get('function_calls', []):
            func = call.get('function', '')
            if any(df in func for df in dangerous_functions):
                args = call.get('arguments', [])
                args_str = ' '.join(args)
                
                # Check if using user input
                if any(sg in args_str for sg in ['$_GET', '$_POST', '$_REQUEST', '$_COOKIE']):
                    vulnerabilities.append({
                        'rule_id': rule.id,
                        'title': 'Remote Code Execution',
                        'severity': 'critical',
                        'line': call.get('line', 0),
                        'sink': func,
                        'confidence': 'high',
                        'description': f'Dangerous function {func} with user input'
                    })
        
        # Check includes with user input
        for inc in ast_data.get('includes', []):
            path = inc.get('path', '')
            if any(sg in path for sg in ['$_GET', '$_POST', '$_REQUEST']):
                vulnerabilities.append({
                    'rule_id': rule.id,
                    'title': 'Remote File Inclusion',
                    'severity': 'critical',
                    'line': inc.get('line', 0),
                    'sink': inc.get('type', 'include'),
                    'confidence': 'high',
                    'description': 'File inclusion with user-controlled path'
                })
        
        return vulnerabilities
    
    def _detect_auth_issues(self, wp_analysis: Dict[str, Any], rule) -> List[Dict[str, Any]]:
        """Detect authentication/authorization issues"""
        vulnerabilities = []
        
        # Missing capability checks
        for missing in wp_analysis.get('missing_capability_checks', []):
            vulnerabilities.append({
                'rule_id': rule.id,
                'title': 'Missing Authorization Check',
                'severity': missing.get('severity', 'high'),
                'line': missing.get('line', 0),
                'description': f"Endpoint {missing.get('endpoint')} missing capability check"
            })
        
        # Insecure REST routes
        for insecure in wp_analysis.get('insecure_rest_routes', []):
            vulnerabilities.append({
                'rule_id': rule.id,
                'title': 'Insecure REST Route',
                'severity': insecure.get('severity', 'high'),
                'line': insecure.get('line', 0),
                'description': insecure.get('description', '')
            })
        
        return vulnerabilities
    
    def _add_findings(self, vulns: List[Dict[str, Any]], file_path: Path):
        """Add multiple findings"""
        for vuln in vulns:
            self._add_finding(vuln, file_path)
    
    def _add_finding(self, vuln: Dict[str, Any], file_path: Path):
        """Add a single finding"""
        finding = {
            **vuln,
            'file': str(file_path),
            'scan_id': self.scan_id,
            'plugin': self.plugin_info.get('name', 'Unknown')
        }
        
        self.findings.append(finding)
        
        self.logger.log_finding(
            finding.get('severity', 'medium'),
            finding.get('title', 'Unknown'),
            str(file_path),
            finding.get('line', 0)
        )
    
    def _perform_wordpress_analysis(self):
        """Perform WordPress-specific analysis"""
        # Check for privilege escalation
        # Check for IDOR
        # These are already done per-file, this is for cross-file analysis
        pass
    
    def _perform_dynamic_verification(self, target_path: Path):
        """Perform dynamic verification of findings"""
        if not self.exploit_tester:
            return
        
        self.logger.log_info("Starting dynamic verification...")
        
        verified_count = 0
        for finding in self.findings:
            if finding.get('severity') in ['critical', 'high']:
                result = self.exploit_tester.verify_vulnerability(finding, target_path)
                finding['dynamic_verification'] = result
                
                if result.get('status') == 'CONFIRMED':
                    verified_count += 1
        
        self.logger.log_info(f"Dynamically verified {verified_count} vulnerabilities")
    
    def _calculate_stats(self, duration: float):
        """Calculate scan statistics"""
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        
        for finding in self.findings:
            severity = finding.get('severity', 'medium')
            if severity in severity_counts:
                severity_counts[severity] += 1
        
        self.scan_stats = {
            'scan_id': self.scan_id,
            'duration': duration,
            'total_findings': len(self.findings),
            'severity_counts': severity_counts,
            'files_scanned': self.logger.files_scanned,
            'plugin_name': self.plugin_info.get('name', 'Unknown'),
            'plugin_version': self.plugin_info.get('version', 'unknown'),
            'hook_stats': self.hook_mapper.get_hook_statistics(),
            'rest_stats': self.rest_mapper.get_rest_statistics()
        }
    
    def _generate_result(self) -> Dict[str, Any]:
        """Generate scan result"""
        return {
            'scan_id': self.scan_id,
            'plugin_info': self.plugin_info,
            'statistics': self.scan_stats,
            'findings': self.findings,
            'hook_map': self.hook_mapper.export_hook_map(),
            'rest_map': self.rest_mapper.export_rest_map()
        }
    
    def _generate_error_result(self, error: str) -> Dict[str, Any]:
        """Generate error result"""
        return {
            'scan_id': self.scan_id,
            'error': error,
            'statistics': {'total_findings': 0},
            'findings': []
        }