"""
Data flow tracking using directed graphs
"""

import networkx as nx
from typing import Dict, List, Set, Optional, Any, Tuple
from dataclasses import dataclass
from pathlib import Path
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class DataFlow:
    """Represents a single data flow step"""
    variable: str
    value: str
    line: int
    context: str
    file_path: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'variable': self.variable,
            'value': self.value,
            'line': self.line,
            'context': self.context,
            'file': str(self.file_path)
        }


class FlowTracker:
    """Tracks data flow through code using directed graphs"""
    
    def __init__(self):
        self.flow_graph = nx.DiGraph()
        self.variable_flows: Dict[str, List[DataFlow]] = {}
        self.current_file: Optional[Path] = None
    
    def set_current_file(self, file_path: Path):
        """Set the current file being analyzed"""
        self.current_file = file_path
    
    def add_flow(self, from_var: str, to_var: str, line: int, 
                 context: str = "", value: str = ""):
        """Add a data flow edge"""
        if not self.current_file:
            return
        
        # Add nodes
        self.flow_graph.add_node(from_var, type='variable')
        self.flow_graph.add_node(to_var, type='variable')
        
        # Add edge with metadata
        self.flow_graph.add_edge(from_var, to_var, 
                                line=line, 
                                context=context,
                                file=str(self.current_file))
        
        # Track flow for variable
        if from_var not in self.variable_flows:
            self.variable_flows[from_var] = []
        
        flow = DataFlow(
            variable=to_var,
            value=value,
            line=line,
            context=context,
            file_path=self.current_file
        )
        self.variable_flows[from_var].append(flow)
    
    def add_assignment(self, variable: str, value: str, line: int):
        """Track variable assignment"""
        if not self.current_file:
            return
        
        # Extract variables from value
        source_vars = self._extract_variables(value)
        
        for source_var in source_vars:
            self.add_flow(source_var, variable, line, 
                         context=f"assignment: {variable} = {value}",
                         value=value)
    
    def add_function_call(self, function: str, arguments: List[str], 
                         return_var: Optional[str], line: int):
        """Track function call data flow"""
        if not self.current_file:
            return
        
        context = f"call: {function}({', '.join(arguments)})"
        
        # Track flow from arguments to function
        for arg in arguments:
            arg_vars = self._extract_variables(arg)
            for var in arg_vars:
                if return_var:
                    self.add_flow(var, return_var, line, context=context)
                else:
                    # Function call without return (side effect)
                    self.add_flow(var, f"{function}_sink", line, context=context)
    
    def add_echo_output(self, content: str, line: int):
        """Track echo/print output"""
        if not self.current_file:
            return
        
        variables = self._extract_variables(content)
        
        for var in variables:
            self.add_flow(var, "output_sink", line, 
                         context=f"echo: {content}")
    
    def add_sql_query(self, query: str, line: int):
        """Track SQL query data flow"""
        if not self.current_file:
            return
        
        variables = self._extract_variables(query)
        
        for var in variables:
            self.add_flow(var, "sql_sink", line, 
                         context=f"sql: {query}")
    
    def get_flow_path(self, from_var: str, to_var: str) -> List[List[str]]:
        """Get all paths from source to sink"""
        try:
            if from_var in self.flow_graph and to_var in self.flow_graph:
                paths = list(nx.all_simple_paths(self.flow_graph, from_var, to_var))
                return paths
        except nx.NetworkXNoPath:
            pass
        
        return []
    
    def has_path(self, from_var: str, to_var: str) -> bool:
        """Check if path exists from source to sink"""
        try:
            return nx.has_path(self.flow_graph, from_var, to_var)
        except nx.NodeNotFound:
            return False
    
    def get_all_flows(self) -> Dict[str, List[DataFlow]]:
        """Get all tracked flows"""
        return self.variable_flows
    
    def get_flows_for_variable(self, variable: str) -> List[DataFlow]:
        """Get all flows for a specific variable"""
        return self.variable_flows.get(variable, [])
    
    def get_reachable_sinks(self, source: str) -> Set[str]:
        """Get all sinks reachable from source"""
        if source not in self.flow_graph:
            return set()
        
        reachable = nx.descendants(self.flow_graph, source)
        
        # Filter for sink nodes
        sinks = {node for node in reachable if node.endswith('_sink')}
        
        return sinks
    
    def analyze_flow_complexity(self, from_var: str, to_var: str) -> Dict[str, Any]:
        """Analyze complexity of flow path"""
        paths = self.get_flow_path(from_var, to_var)
        
        if not paths:
            return {
                'has_path': False,
                'path_count': 0,
                'shortest_path_length': 0,
                'complexity': 'none'
            }
        
        shortest = min(len(p) for p in paths)
        longest = max(len(p) for p in paths)
        
        # Determine complexity
        if shortest == 2:
            complexity = 'direct'
        elif shortest <= 4:
            complexity = 'simple'
        elif shortest <= 8:
            complexity = 'moderate'
        else:
            complexity = 'complex'
        
        return {
            'has_path': True,
            'path_count': len(paths),
            'shortest_path_length': shortest,
            'longest_path_length': longest,
            'complexity': complexity
        }
    
    def _extract_variables(self, code: str) -> List[str]:
        """Extract variable names from code string"""
        import re
        
        # Match PHP variables ($var, $_GET['key'], etc.)
        pattern = r'\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*'
        matches = re.findall(pattern, code)
        
        return list(set(matches))
    
    def get_graph_stats(self) -> Dict[str, Any]:
        """Get statistics about the flow graph"""
        return {
            'nodes': self.flow_graph.number_of_nodes(),
            'edges': self.flow_graph.number_of_edges(),
            'variables_tracked': len(self.variable_flows),
            'total_flows': sum(len(flows) for flows in self.variable_flows.values())
        }
    
    def clear(self):
        """Clear all tracked flows"""
        self.flow_graph.clear()
        self.variable_flows.clear()
        self.current_file = None
    
    def export_graph(self, output_file: Path):
        """Export flow graph to file"""
        try:
            nx.write_gexf(self.flow_graph, str(output_file))
            logger.info(f"Flow graph exported to {output_file}")
        except Exception as e:
            logger.error(f"Failed to export flow graph: {e}")
    
    def find_cycles(self) -> List[List[str]]:
        """Find cycles in flow graph (potential infinite loops)"""
        try:
            cycles = list(nx.simple_cycles(self.flow_graph))
            return cycles
        except Exception as e:
            logger.error(f"Failed to find cycles: {e}")
            return []