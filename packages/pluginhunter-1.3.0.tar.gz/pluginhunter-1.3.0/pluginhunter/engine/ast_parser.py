"""
AST Parser using tree-sitter for PHP code analysis
"""

import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from tree_sitter import Language, Parser, Node
import tree_sitter_php
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class ASTParser:
    """PHP AST parser using tree-sitter"""
    
    def __init__(self):
        self.parser = Parser()
        try:
            # Get PHP language - tree-sitter-php v0.23+ uses language_php()
            if hasattr(tree_sitter_php, 'language_php'):
                php_lang_capsule = tree_sitter_php.language_php()
            elif hasattr(tree_sitter_php, 'language'):
                php_lang_capsule = tree_sitter_php.language()
            else:
                raise AttributeError("Cannot find PHP language function in tree_sitter_php")
            
            # Wrap in Language object if it's a PyCapsule
            if type(php_lang_capsule).__name__ == 'PyCapsule':
                php_lang = Language(php_lang_capsule)
            else:
                php_lang = php_lang_capsule
            
            # Set language - tree-sitter v0.21+ uses parser.language property
            if hasattr(self.parser, 'language') and not callable(getattr(self.parser, 'language')):
                self.parser.language = php_lang
            else:
                self.parser.set_language(php_lang)
            
            self.php_language = php_lang
        except Exception as e:
            logger.error(f"Failed to initialize PHP parser: {e}")
            self.php_language = None
    
    def parse_file(self, file_path: Path) -> Optional[Node]:
        """Parse PHP file and return AST root node"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            
            return self.parse_code(code)
        except Exception as e:
            logger.error(f"Failed to parse file {file_path}: {e}")
            return None
    
    def parse_code(self, code: str) -> Optional[Node]:
        """Parse PHP code string and return AST root node"""
        if not self.php_language:
            return None
        
        try:
            tree = self.parser.parse(bytes(code, 'utf-8'))
            return tree.root_node
        except Exception as e:
            logger.error(f"Failed to parse code: {e}")
            return None
    
    def find_function_calls(self, node: Node, function_names: List[str]) -> List[Dict[str, Any]]:
        """Find all function calls matching given names"""
        calls = []
        
        def traverse(n: Node):
            if n.type == 'function_call_expression':
                func_name = self._get_function_name(n)
                if func_name and any(fn in func_name for fn in function_names):
                    calls.append({
                        'function': func_name,
                        'node': n,
                        'line': n.start_point[0] + 1,
                        'column': n.start_point[1],
                        'arguments': self._extract_arguments(n)
                    })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return calls
    
    def find_variable_assignments(self, node: Node, var_names: List[str] = None) -> List[Dict[str, Any]]:
        """Find variable assignments"""
        assignments = []
        
        def traverse(n: Node):
            if n.type == 'assignment_expression':
                left = n.child_by_field_name('left')
                right = n.child_by_field_name('right')
                
                if left and right:
                    var_name = self._get_node_text(left)
                    if not var_names or any(v in var_name for v in var_names):
                        assignments.append({
                            'variable': var_name,
                            'value': self._get_node_text(right),
                            'node': n,
                            'line': n.start_point[0] + 1,
                            'column': n.start_point[1]
                        })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return assignments
    
    def find_echo_statements(self, node: Node) -> List[Dict[str, Any]]:
        """Find echo/print statements"""
        statements = []
        
        def traverse(n: Node):
            if n.type in ['echo_statement', 'print_intrinsic']:
                statements.append({
                    'type': n.type,
                    'content': self._get_node_text(n),
                    'node': n,
                    'line': n.start_point[0] + 1,
                    'column': n.start_point[1]
                })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return statements
    
    def find_sql_queries(self, node: Node) -> List[Dict[str, Any]]:
        """Find SQL query patterns"""
        queries = []
        
        # Look for $wpdb->query, $wpdb->get_results, etc.
        wpdb_methods = ['query', 'get_results', 'get_row', 'get_col', 'get_var', 'prepare']
        
        def traverse(n: Node):
            if n.type == 'member_call_expression':
                object_node = n.child_by_field_name('object')
                method_node = n.child_by_field_name('name')
                
                if object_node and method_node:
                    object_name = self._get_node_text(object_node)
                    method_name = self._get_node_text(method_node)
                    
                    if 'wpdb' in object_name and method_name in wpdb_methods:
                        queries.append({
                            'object': object_name,
                            'method': method_name,
                            'node': n,
                            'line': n.start_point[0] + 1,
                            'column': n.start_point[1],
                            'arguments': self._extract_arguments(n)
                        })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return queries
    
    def find_includes(self, node: Node) -> List[Dict[str, Any]]:
        """Find include/require statements"""
        includes = []
        
        def traverse(n: Node):
            if n.type in ['include_expression', 'include_once_expression', 
                         'require_expression', 'require_once_expression']:
                includes.append({
                    'type': n.type,
                    'path': self._get_node_text(n),
                    'node': n,
                    'line': n.start_point[0] + 1,
                    'column': n.start_point[1]
                })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return includes
    
    def find_wordpress_hooks(self, node: Node) -> List[Dict[str, Any]]:
        """Find WordPress add_action and add_filter calls"""
        hooks = []
        hook_functions = ['add_action', 'add_filter', 'do_action', 'apply_filters']
        
        calls = self.find_function_calls(node, hook_functions)
        
        for call in calls:
            args = call.get('arguments', [])
            hook_info = {
                'type': call['function'],
                'hook_name': args[0] if len(args) > 0 else None,
                'callback': args[1] if len(args) > 1 else None,
                'priority': args[2] if len(args) > 2 else 10,
                'line': call['line'],
                'node': call['node']
            }
            hooks.append(hook_info)
        
        return hooks
    
    def find_rest_routes(self, node: Node) -> List[Dict[str, Any]]:
        """Find register_rest_route calls"""
        routes = []
        calls = self.find_function_calls(node, ['register_rest_route'])
        
        for call in calls:
            args = call.get('arguments', [])
            route_info = {
                'namespace': args[0] if len(args) > 0 else None,
                'route': args[1] if len(args) > 1 else None,
                'options': args[2] if len(args) > 2 else None,
                'line': call['line'],
                'node': call['node']
            }
            routes.append(route_info)
        
        return routes
    
    def find_capability_checks(self, node: Node) -> List[Dict[str, Any]]:
        """Find current_user_can checks"""
        checks = []
        calls = self.find_function_calls(node, ['current_user_can', 'user_can'])
        
        for call in calls:
            checks.append({
                'function': call['function'],
                'capability': call.get('arguments', [None])[0],
                'line': call['line'],
                'node': call['node']
            })
        
        return checks
    
    def find_nonce_checks(self, node: Node) -> List[Dict[str, Any]]:
        """Find wp_verify_nonce checks"""
        checks = []
        nonce_functions = ['wp_verify_nonce', 'check_ajax_referer', 'check_admin_referer']
        calls = self.find_function_calls(node, nonce_functions)
        
        for call in calls:
            checks.append({
                'function': call['function'],
                'line': call['line'],
                'node': call['node']
            })
        
        return checks
    
    def find_file_operations(self, node: Node) -> List[Dict[str, Any]]:
        """Find file upload and manipulation operations"""
        operations = []
        file_functions = [
            'move_uploaded_file', 'copy', 'file_put_contents', 
            'fopen', 'fwrite', 'file_get_contents', 'unlink'
        ]
        
        calls = self.find_function_calls(node, file_functions)
        
        for call in calls:
            operations.append({
                'function': call['function'],
                'arguments': call.get('arguments', []),
                'line': call['line'],
                'node': call['node']
            })
        
        return operations
    
    def find_unserialize_calls(self, node: Node) -> List[Dict[str, Any]]:
        """Find unserialize calls"""
        calls = self.find_function_calls(node, ['unserialize'])
        return calls
    
    def find_remote_requests(self, node: Node) -> List[Dict[str, Any]]:
        """Find remote HTTP request functions"""
        request_functions = [
            'wp_remote_get', 'wp_remote_post', 'wp_remote_request',
            'curl_exec', 'file_get_contents', 'fopen'
        ]
        
        calls = self.find_function_calls(node, request_functions)
        return calls
    
    def _get_function_name(self, node: Node) -> Optional[str]:
        """Extract function name from function call node"""
        if node.type != 'function_call_expression':
            return None
        
        func_node = node.child_by_field_name('function')
        if func_node:
            return self._get_node_text(func_node)
        
        return None
    
    def _extract_arguments(self, node: Node) -> List[str]:
        """Extract arguments from function call"""
        arguments = []
        
        args_node = node.child_by_field_name('arguments')
        if not args_node:
            return arguments
        
        for child in args_node.children:
            if child.type != ',' and child.type != '(' and child.type != ')':
                arg_text = self._get_node_text(child)
                arguments.append(arg_text)
        
        return arguments
    
    def _get_node_text(self, node: Node) -> str:
        """Get text content of node"""
        if not node:
            return ""
        
        return node.text.decode('utf-8') if node.text else ""
    
    def get_function_definitions(self, node: Node) -> List[Dict[str, Any]]:
        """Find all function definitions"""
        functions = []
        
        def traverse(n: Node):
            if n.type == 'function_definition':
                name_node = n.child_by_field_name('name')
                params_node = n.child_by_field_name('parameters')
                
                func_info = {
                    'name': self._get_node_text(name_node) if name_node else 'anonymous',
                    'parameters': self._extract_parameters(params_node) if params_node else [],
                    'line': n.start_point[0] + 1,
                    'node': n
                }
                functions.append(func_info)
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return functions
    
    def _extract_parameters(self, params_node: Node) -> List[str]:
        """Extract parameter names from function parameters node"""
        params = []
        
        for child in params_node.children:
            if child.type == 'simple_parameter' or child.type == 'variadic_parameter':
                name_node = child.child_by_field_name('name')
                if name_node:
                    params.append(self._get_node_text(name_node))
        
        return params
    
    def find_superglobals(self, node: Node) -> List[Dict[str, Any]]:
        """Find usage of PHP superglobals"""
        superglobals = ['$_GET', '$_POST', '$_REQUEST', '$_COOKIE', '$_SERVER', '$_FILES']
        usages = []
        
        def traverse(n: Node):
            if n.type == 'variable_name':
                var_text = self._get_node_text(n)
                if any(sg in var_text for sg in superglobals):
                    usages.append({
                        'variable': var_text,
                        'line': n.start_point[0] + 1,
                        'column': n.start_point[1],
                        'node': n
                    })
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return usages