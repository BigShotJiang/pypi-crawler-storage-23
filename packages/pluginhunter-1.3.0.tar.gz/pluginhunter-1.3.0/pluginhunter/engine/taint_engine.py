"""
Taint tracking engine for data flow analysis
"""

from typing import Dict, List, Set, Optional, Any, Tuple
from pathlib import Path
from tree_sitter import Node
from .flow_tracker import FlowTracker, DataFlow
from ..rules.loader import VulnerabilityRule
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class TaintAnalysis:
    """Represents a taint analysis result"""
    
    def __init__(self, source: str, sink: str, flow_path: List[DataFlow], 
                 rule: VulnerabilityRule, confidence: str = "high"):
        self.source = source
        self.sink = sink
        self.flow_path = flow_path
        self.rule = rule
        self.confidence = confidence
        self.sanitized = False
        self.sanitizers_found: List[str] = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'source': self.source,
            'sink': self.sink,
            'flow_path': [flow.to_dict() for flow in self.flow_path],
            'rule_id': self.rule.id,
            'confidence': self.confidence,
            'sanitized': self.sanitized,
            'sanitizers': self.sanitizers_found
        }


class TaintEngine:
    """Taint tracking engine for vulnerability detection"""
    
    def __init__(self, flow_tracker: FlowTracker):
        self.flow_tracker = flow_tracker
        self.taint_sources: Set[str] = set()
        self.taint_sinks: Set[str] = set()
        self.sanitizers: Set[str] = set()
    
    def analyze_taint_flow(self, rule: VulnerabilityRule, 
                          file_path: Path) -> List[TaintAnalysis]:
        """Analyze taint flow for a specific rule"""
        results = []
        
        # Register sources, sinks, and sanitizers from rule
        self.taint_sources = set(rule.sources)
        self.taint_sinks = set(rule.sinks)
        self.sanitizers = set(rule.sanitizers)
        
        # Get all flows from tracker
        flows = self.flow_tracker.get_all_flows()
        
        # Find flows from sources to sinks
        for source_var, flow_list in flows.items():
            if self._is_tainted_source(source_var):
                # Check if this flow reaches any sink
                sink_flows = self._find_sink_flows(flow_list)
                
                for sink_flow in sink_flows:
                    # Check if flow is sanitized
                    is_sanitized, sanitizers_found = self._check_sanitization(sink_flow)
                    
                    analysis = TaintAnalysis(
                        source=source_var,
                        sink=sink_flow[-1].variable if sink_flow else "",
                        flow_path=sink_flow,
                        rule=rule,
                        confidence="high" if not is_sanitized else "low"
                    )
                    analysis.sanitized = is_sanitized
                    analysis.sanitizers_found = sanitizers_found
                    
                    if not is_sanitized:
                        results.append(analysis)
        
        return results
    
    def _is_tainted_source(self, variable: str) -> bool:
        """Check if variable is a taint source"""
        for source in self.taint_sources:
            if source in variable:
                return True
        return False
    
    def _is_taint_sink(self, variable: str, context: str = "") -> bool:
        """Check if variable/function is a taint sink"""
        combined = f"{variable} {context}"
        for sink in self.taint_sinks:
            if sink in combined:
                return True
        return False
    
    def _find_sink_flows(self, flow_list: List[DataFlow]) -> List[List[DataFlow]]:
        """Find flows that reach sinks"""
        sink_flows = []
        
        for i, flow in enumerate(flow_list):
            # Check if this flow reaches a sink
            if self._is_taint_sink(flow.variable, flow.context):
                # Build the flow path up to this point
                flow_path = flow_list[:i+1]
                sink_flows.append(flow_path)
        
        return sink_flows
    
    def _check_sanitization(self, flow_path: List[DataFlow]) -> Tuple[bool, List[str]]:
        """Check if flow path contains sanitization"""
        sanitizers_found = []
        
        for flow in flow_path:
            for sanitizer in self.sanitizers:
                if sanitizer in flow.context or sanitizer in flow.value:
                    sanitizers_found.append(sanitizer)
        
        return len(sanitizers_found) > 0, sanitizers_found
    
    def detect_direct_vulnerabilities(self, rule: VulnerabilityRule, 
                                     ast_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect direct vulnerabilities without complex flow tracking"""
        vulnerabilities = []
        
        # Check for direct source->sink patterns
        if rule.sources and rule.sinks:
            vulnerabilities.extend(self._detect_direct_source_sink(rule, ast_data))
        
        # Check for pattern-based detection
        if rule.pattern or rule.regex:
            vulnerabilities.extend(self._detect_pattern_based(rule, ast_data))
        
        return vulnerabilities
    
    def _detect_direct_source_sink(self, rule: VulnerabilityRule, 
                                   ast_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect direct source to sink without intermediate steps"""
        vulnerabilities = []
        
        # Get superglobal usages (sources)
        superglobals = ast_data.get('superglobals', [])
        
        # Get function calls (potential sinks)
        function_calls = ast_data.get('function_calls', [])
        
        # Check if any source is directly used in a sink
        for sg in superglobals:
            sg_line = sg.get('line', 0)
            sg_var = sg.get('variable', '')
            
            # Look for sinks near this source
            for call in function_calls:
                call_line = call.get('line', 0)
                call_func = call.get('function', '')
                call_args = call.get('arguments', [])
                
                # Check if this is a sink function
                if any(sink in call_func for sink in rule.sinks):
                    # Check if source variable is in arguments
                    args_str = ' '.join(call_args)
                    if sg_var.replace('$', '') in args_str:
                        # Check for sanitization
                        is_sanitized = any(san in args_str for san in rule.sanitizers)
                        
                        if not is_sanitized:
                            vulnerabilities.append({
                                'rule_id': rule.id,
                                'title': rule.title,
                                'severity': rule.severity,
                                'line': call_line,
                                'source': sg_var,
                                'sink': call_func,
                                'confidence': 'high',
                                'description': f"Unsanitized {sg_var} used in {call_func}"
                            })
        
        return vulnerabilities
    
    def _detect_pattern_based(self, rule: VulnerabilityRule, 
                             ast_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect vulnerabilities based on patterns"""
        vulnerabilities = []
        
        # This would use regex patterns from rules
        # For now, return empty list as patterns are handled elsewhere
        
        return vulnerabilities
    
    def analyze_sql_injection(self, ast_data: Dict[str, Any], 
                             rule: VulnerabilityRule) -> List[Dict[str, Any]]:
        """Specialized SQL injection detection"""
        vulnerabilities = []
        
        sql_queries = ast_data.get('sql_queries', [])
        superglobals = ast_data.get('superglobals', [])
        
        for query in sql_queries:
            method = query.get('method', '')
            args = query.get('arguments', [])
            line = query.get('line', 0)
            
            # Check if using prepare() method (safe)
            if method == 'prepare':
                continue
            
            # Check if query contains user input
            args_str = ' '.join(args)
            
            for sg in superglobals:
                sg_var = sg.get('variable', '').replace('$', '')
                
                if sg_var in args_str:
                    # Check if properly escaped
                    is_safe = any(safe in args_str for safe in [
                        'esc_sql', 'absint', 'intval', 'sanitize_'
                    ])
                    
                    if not is_safe:
                        vulnerabilities.append({
                            'rule_id': rule.id,
                            'title': 'SQL Injection',
                            'severity': 'critical',
                            'line': line,
                            'source': f"${sg_var}",
                            'sink': f"$wpdb->{method}()",
                            'confidence': 'high',
                            'description': f"Unsanitized user input in SQL query"
                        })
        
        return vulnerabilities
    
    def analyze_xss(self, ast_data: Dict[str, Any], 
                   rule: VulnerabilityRule) -> List[Dict[str, Any]]:
        """Specialized XSS detection"""
        vulnerabilities = []
        
        echo_statements = ast_data.get('echo_statements', [])
        superglobals = ast_data.get('superglobals', [])
        
        for echo in echo_statements:
            content = echo.get('content', '')
            line = echo.get('line', 0)
            
            # Check if echoing user input
            for sg in superglobals:
                sg_var = sg.get('variable', '').replace('$', '')
                
                if sg_var in content:
                    # Check if properly escaped
                    is_safe = any(esc in content for esc in [
                        'esc_html', 'esc_attr', 'esc_url', 'esc_js',
                        'wp_kses', 'sanitize_text_field'
                    ])
                    
                    if not is_safe:
                        vulnerabilities.append({
                            'rule_id': rule.id,
                            'title': 'Cross-Site Scripting (XSS)',
                            'severity': 'high',
                            'line': line,
                            'source': f"${sg_var}",
                            'sink': 'echo',
                            'confidence': 'high',
                            'description': f"Unescaped user input in output"
                        })
        
        return vulnerabilities
    
    def analyze_file_upload(self, ast_data: Dict[str, Any], 
                           rule: VulnerabilityRule) -> List[Dict[str, Any]]:
        """Specialized file upload vulnerability detection"""
        vulnerabilities = []
        
        file_operations = ast_data.get('file_operations', [])
        
        for op in file_operations:
            func = op.get('function', '')
            args = op.get('arguments', [])
            line = op.get('line', 0)
            
            if func == 'move_uploaded_file':
                args_str = ' '.join(args)
                
                # Check for proper validation
                has_mime_check = '$_FILES' in args_str and any(check in args_str for check in [
                    'type', 'mime', 'wp_check_filetype'
                ])
                
                has_extension_check = any(check in args_str for check in [
                    'pathinfo', 'extension', 'wp_check_filetype'
                ])
                
                if not (has_mime_check and has_extension_check):
                    vulnerabilities.append({
                        'rule_id': rule.id,
                        'title': 'Unrestricted File Upload',
                        'severity': 'critical',
                        'line': line,
                        'source': '$_FILES',
                        'sink': 'move_uploaded_file',
                        'confidence': 'high',
                        'description': 'File upload without proper validation'
                    })
        
        return vulnerabilities
    
    def analyze_deserialization(self, ast_data: Dict[str, Any], 
                               rule: VulnerabilityRule) -> List[Dict[str, Any]]:
        """Specialized insecure deserialization detection"""
        vulnerabilities = []
        
        unserialize_calls = ast_data.get('unserialize_calls', [])
        superglobals = ast_data.get('superglobals', [])
        
        for call in unserialize_calls:
            args = call.get('arguments', [])
            line = call.get('line', 0)
            args_str = ' '.join(args)
            
            # Check if unserializing user input
            for sg in superglobals:
                sg_var = sg.get('variable', '').replace('$', '')
                
                if sg_var in args_str:
                    vulnerabilities.append({
                        'rule_id': rule.id,
                        'title': 'Insecure Deserialization',
                        'severity': 'critical',
                        'line': line,
                        'source': f"${sg_var}",
                        'sink': 'unserialize',
                        'confidence': 'high',
                        'description': 'Unserializing untrusted user input'
                    })
        
        return vulnerabilities
    
    def analyze_ssrf(self, ast_data: Dict[str, Any], 
                    rule: VulnerabilityRule) -> List[Dict[str, Any]]:
        """Specialized SSRF detection"""
        vulnerabilities = []
        
        remote_requests = ast_data.get('remote_requests', [])
        superglobals = ast_data.get('superglobals', [])
        
        for req in remote_requests:
            func = req.get('function', '')
            args = req.get('arguments', [])
            line = req.get('line', 0)
            args_str = ' '.join(args)
            
            # Check if URL comes from user input
            for sg in superglobals:
                sg_var = sg.get('variable', '').replace('$', '')
                
                if sg_var in args_str:
                    # Check for URL validation
                    is_validated = any(val in args_str for val in [
                        'esc_url_raw', 'wp_http_validate_url', 'filter_var'
                    ])
                    
                    if not is_validated:
                        vulnerabilities.append({
                            'rule_id': rule.id,
                            'title': 'Server-Side Request Forgery (SSRF)',
                            'severity': 'high',
                            'line': line,
                            'source': f"${sg_var}",
                            'sink': func,
                            'confidence': 'high',
                            'description': 'User-controlled URL in remote request'
                        })
        
        return vulnerabilities