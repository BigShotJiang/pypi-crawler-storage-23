"""
WordPress hook mapping and analysis
"""

from typing import Dict, List, Any, Set
from pathlib import Path
from tree_sitter import Node
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class HookMapper:
    """Maps and analyzes WordPress hooks"""
    
    def __init__(self):
        self.hooks: Dict[str, List[Dict[str, Any]]] = {
            'actions': [],
            'filters': [],
            'ajax': [],
            'cron': []
        }
        self.hook_callbacks: Dict[str, List[str]] = {}
    
    def add_hook(self, hook_type: str, hook_name: str, callback: str, 
                 priority: int, file_path: Path, line: int):
        """Add a hook to the map"""
        hook_info = {
            'name': hook_name,
            'callback': callback,
            'priority': priority,
            'file': str(file_path),
            'line': line
        }
        
        if hook_type in self.hooks:
            self.hooks[hook_type].append(hook_info)
        
        # Track callbacks
        if hook_name not in self.hook_callbacks:
            self.hook_callbacks[hook_name] = []
        self.hook_callbacks[hook_name].append(callback)
    
    def process_hooks_from_ast(self, hooks_data: List[Dict[str, Any]], file_path: Path):
        """Process hooks found by AST parser"""
        for hook in hooks_data:
            hook_type_func = hook.get('type', '')
            hook_name = hook.get('hook_name', '')
            callback = hook.get('callback', '')
            priority = hook.get('priority', 10)
            line = hook.get('line', 0)
            
            # Determine hook category
            if 'add_action' in hook_type_func:
                if 'wp_ajax_' in hook_name:
                    category = 'ajax'
                elif 'cron' in hook_name or 'schedule' in hook_name:
                    category = 'cron'
                else:
                    category = 'actions'
            elif 'add_filter' in hook_type_func:
                category = 'filters'
            else:
                category = 'actions'
            
            self.add_hook(category, hook_name, callback, priority, file_path, line)
    
    def get_ajax_hooks(self) -> List[Dict[str, Any]]:
        """Get all AJAX hooks"""
        return self.hooks.get('ajax', [])
    
    def get_public_ajax_hooks(self) -> List[Dict[str, Any]]:
        """Get public AJAX hooks (wp_ajax_nopriv_)"""
        return [h for h in self.hooks.get('ajax', []) 
                if 'nopriv' in h.get('name', '')]
    
    def get_admin_ajax_hooks(self) -> List[Dict[str, Any]]:
        """Get admin-only AJAX hooks"""
        return [h for h in self.hooks.get('ajax', []) 
                if 'nopriv' not in h.get('name', '')]
    
    def get_init_hooks(self) -> List[Dict[str, Any]]:
        """Get hooks that run on init"""
        init_hooks = ['init', 'admin_init', 'wp_loaded', 'plugins_loaded']
        return [h for h in self.hooks.get('actions', []) 
                if h.get('name') in init_hooks]
    
    def get_hooks_by_priority(self, hook_name: str) -> List[Dict[str, Any]]:
        """Get all callbacks for a hook sorted by priority"""
        callbacks = []
        
        for category in self.hooks.values():
            for hook in category:
                if hook.get('name') == hook_name:
                    callbacks.append(hook)
        
        # Convert priority to int for sorting, default to 10
        def get_priority(hook):
            priority = hook.get('priority', 10)
            try:
                return int(priority)
            except (ValueError, TypeError):
                return 10
        
        return sorted(callbacks, key=get_priority)
    
    def find_hook_conflicts(self) -> List[Dict[str, Any]]:
        """Find potential hook conflicts"""
        conflicts = []
        
        # Check for multiple callbacks with same priority
        for hook_name, callbacks in self.hook_callbacks.items():
            if len(callbacks) > 1:
                hook_list = self.get_hooks_by_priority(hook_name)
                
                # Group by priority
                priority_groups: Dict[int, List[Dict[str, Any]]] = {}
                for hook in hook_list:
                    priority = hook.get('priority', 10)
                    if priority not in priority_groups:
                        priority_groups[priority] = []
                    priority_groups[priority].append(hook)
                
                # Find conflicts
                for priority, hooks in priority_groups.items():
                    if len(hooks) > 1:
                        conflicts.append({
                            'hook_name': hook_name,
                            'priority': priority,
                            'callbacks': [h.get('callback') for h in hooks],
                            'count': len(hooks)
                        })
        
        return conflicts
    
    def get_security_sensitive_hooks(self) -> List[Dict[str, Any]]:
        """Get hooks that are security-sensitive"""
        sensitive_patterns = [
            'login', 'auth', 'password', 'user', 'admin',
            'upload', 'delete', 'update', 'save', 'ajax'
        ]
        
        sensitive_hooks = []
        
        for category in self.hooks.values():
            for hook in category:
                hook_name = hook.get('name', '').lower()
                if any(pattern in hook_name for pattern in sensitive_patterns):
                    sensitive_hooks.append(hook)
        
        return sensitive_hooks
    
    def get_hook_statistics(self) -> Dict[str, Any]:
        """Get statistics about hooks"""
        return {
            'total_actions': len(self.hooks.get('actions', [])),
            'total_filters': len(self.hooks.get('filters', [])),
            'total_ajax': len(self.hooks.get('ajax', [])),
            'public_ajax': len(self.get_public_ajax_hooks()),
            'admin_ajax': len(self.get_admin_ajax_hooks()),
            'total_cron': len(self.hooks.get('cron', [])),
            'unique_hooks': len(self.hook_callbacks),
            'conflicts': len(self.find_hook_conflicts())
        }
    
    def export_hook_map(self) -> Dict[str, Any]:
        """Export complete hook map"""
        return {
            'hooks': self.hooks,
            'callbacks': self.hook_callbacks,
            'statistics': self.get_hook_statistics(),
            'conflicts': self.find_hook_conflicts(),
            'security_sensitive': self.get_security_sensitive_hooks()
        }