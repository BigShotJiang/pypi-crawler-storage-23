"""
WordPress REST API endpoint mapping and analysis
"""

from typing import Dict, List, Any, Optional
from pathlib import Path
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class RESTMapper:
    """Maps and analyzes WordPress REST API endpoints"""
    
    def __init__(self):
        self.endpoints: List[Dict[str, Any]] = []
        self.namespaces: Dict[str, List[Dict[str, Any]]] = {}
    
    def add_endpoint(self, namespace: str, route: str, methods: List[str],
                    permission_callback: Optional[str], callback: Optional[str],
                    file_path: Path, line: int):
        """Add a REST endpoint to the map"""
        endpoint = {
            'namespace': namespace,
            'route': route,
            'methods': methods,
            'permission_callback': permission_callback,
            'callback': callback,
            'file': str(file_path),
            'line': line,
            'full_route': f"/{namespace}{route}"
        }
        
        self.endpoints.append(endpoint)
        
        # Group by namespace
        if namespace not in self.namespaces:
            self.namespaces[namespace] = []
        self.namespaces[namespace].append(endpoint)
    
    def process_rest_routes_from_ast(self, routes_data: List[Dict[str, Any]], file_path: Path):
        """Process REST routes found by AST parser"""
        for route in routes_data:
            namespace = self._clean_string(route.get('namespace', ''))
            route_path = self._clean_string(route.get('route', ''))
            options = route.get('options', '')
            line = route.get('line', 0)
            
            # Parse options to extract methods and callbacks
            methods = self._extract_methods(options)
            permission_callback = self._extract_permission_callback(options)
            callback = self._extract_callback(options)
            
            self.add_endpoint(namespace, route_path, methods, 
                            permission_callback, callback, file_path, line)
    
    def _clean_string(self, value: str) -> str:
        """Clean string value from AST"""
        if not value:
            return ""
        
        # Remove quotes
        value = value.strip().strip('"').strip("'")
        return value
    
    def _extract_methods(self, options: str) -> List[str]:
        """Extract HTTP methods from options"""
        methods = []
        
        method_keywords = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
        
        for method in method_keywords:
            if method in options.upper():
                methods.append(method)
        
        if not methods:
            methods = ['GET']  # Default
        
        return methods
    
    def _extract_permission_callback(self, options: str) -> Optional[str]:
        """Extract permission callback from options"""
        if 'permission_callback' in options:
            # Try to extract the callback function name
            import re
            match = re.search(r'permission_callback[\'"]?\s*=>\s*[\'"]?([a-zA-Z_][a-zA-Z0-9_]*)', options)
            if match:
                return match.group(1)
            
            # Check for __return_true
            if '__return_true' in options:
                return '__return_true'
        
        return None
    
    def _extract_callback(self, options: str) -> Optional[str]:
        """Extract main callback from options"""
        import re
        match = re.search(r'callback[\'"]?\s*=>\s*[\'"]?([a-zA-Z_][a-zA-Z0-9_]*)', options)
        if match:
            return match.group(1)
        
        return None
    
    def get_public_endpoints(self) -> List[Dict[str, Any]]:
        """Get endpoints with public access"""
        return [ep for ep in self.endpoints 
                if ep.get('permission_callback') == '__return_true']
    
    def get_unauthenticated_endpoints(self) -> List[Dict[str, Any]]:
        """Get endpoints without authentication"""
        return [ep for ep in self.endpoints 
                if not ep.get('permission_callback') or 
                ep.get('permission_callback') == '__return_true']
    
    def get_endpoints_by_method(self, method: str) -> List[Dict[str, Any]]:
        """Get endpoints by HTTP method"""
        return [ep for ep in self.endpoints 
                if method.upper() in ep.get('methods', [])]
    
    def get_write_endpoints(self) -> List[Dict[str, Any]]:
        """Get endpoints that modify data"""
        write_methods = ['POST', 'PUT', 'DELETE', 'PATCH']
        return [ep for ep in self.endpoints 
                if any(m in ep.get('methods', []) for m in write_methods)]
    
    def find_insecure_endpoints(self) -> List[Dict[str, Any]]:
        """Find potentially insecure endpoints"""
        insecure = []
        
        for endpoint in self.endpoints:
            issues = []
            
            # Check for __return_true permission callback
            if endpoint.get('permission_callback') == '__return_true':
                issues.append('Public access with __return_true')
            
            # Check for missing permission callback
            if not endpoint.get('permission_callback'):
                issues.append('Missing permission_callback')
            
            # Check write endpoints without proper auth
            if any(m in endpoint.get('methods', []) for m in ['POST', 'PUT', 'DELETE', 'PATCH']):
                if not endpoint.get('permission_callback') or endpoint.get('permission_callback') == '__return_true':
                    issues.append('Write endpoint without authentication')
            
            if issues:
                insecure.append({
                    **endpoint,
                    'security_issues': issues,
                    'severity': 'critical' if 'Write endpoint' in str(issues) else 'high'
                })
        
        return insecure
    
    def get_endpoints_by_namespace(self, namespace: str) -> List[Dict[str, Any]]:
        """Get all endpoints in a namespace"""
        return self.namespaces.get(namespace, [])
    
    def get_all_namespaces(self) -> List[str]:
        """Get all registered namespaces"""
        return list(self.namespaces.keys())
    
    def find_route_conflicts(self) -> List[Dict[str, Any]]:
        """Find potential route conflicts"""
        conflicts = []
        route_map: Dict[str, List[Dict[str, Any]]] = {}
        
        # Group by full route
        for endpoint in self.endpoints:
            full_route = endpoint.get('full_route', '')
            if full_route not in route_map:
                route_map[full_route] = []
            route_map[full_route].append(endpoint)
        
        # Find conflicts
        for route, endpoints in route_map.items():
            if len(endpoints) > 1:
                conflicts.append({
                    'route': route,
                    'count': len(endpoints),
                    'endpoints': endpoints
                })
        
        return conflicts
    
    def get_rest_statistics(self) -> Dict[str, Any]:
        """Get statistics about REST endpoints"""
        return {
            'total_endpoints': len(self.endpoints),
            'total_namespaces': len(self.namespaces),
            'public_endpoints': len(self.get_public_endpoints()),
            'unauthenticated_endpoints': len(self.get_unauthenticated_endpoints()),
            'write_endpoints': len(self.get_write_endpoints()),
            'insecure_endpoints': len(self.find_insecure_endpoints()),
            'route_conflicts': len(self.find_route_conflicts()),
            'methods': {
                'GET': len(self.get_endpoints_by_method('GET')),
                'POST': len(self.get_endpoints_by_method('POST')),
                'PUT': len(self.get_endpoints_by_method('PUT')),
                'DELETE': len(self.get_endpoints_by_method('DELETE')),
                'PATCH': len(self.get_endpoints_by_method('PATCH'))
            }
        }
    
    def export_rest_map(self) -> Dict[str, Any]:
        """Export complete REST API map"""
        return {
            'endpoints': self.endpoints,
            'namespaces': self.namespaces,
            'statistics': self.get_rest_statistics(),
            'insecure_endpoints': self.find_insecure_endpoints(),
            'conflicts': self.find_route_conflicts()
        }
    
    def generate_rest_documentation(self) -> str:
        """Generate REST API documentation"""
        doc = "# REST API Endpoints\n\n"
        
        for namespace in sorted(self.namespaces.keys()):
            doc += f"## Namespace: {namespace}\n\n"
            
            endpoints = self.namespaces[namespace]
            for endpoint in endpoints:
                doc += f"### {endpoint.get('full_route')}\n"
                doc += f"- **Methods**: {', '.join(endpoint.get('methods', []))}\n"
                doc += f"- **Permission**: {endpoint.get('permission_callback', 'Not specified')}\n"
                doc += f"- **Callback**: {endpoint.get('callback', 'Not specified')}\n"
                doc += f"- **File**: {endpoint.get('file')}:{endpoint.get('line')}\n\n"
        
        return doc