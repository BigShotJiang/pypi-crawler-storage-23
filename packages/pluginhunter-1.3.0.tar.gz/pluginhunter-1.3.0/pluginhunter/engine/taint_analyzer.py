"""
Taint analysis engine using pattern matching
"""

from typing import List, Dict, Any, Set, Optional
from pathlib import Path
from tree_sitter import Node
from .pattern_matcher import PatternMatcher


class TaintAnalyzer:
    """Performs taint analysis using source-sink-sanitizer patterns"""
    
    def __init__(self, ast_parser, pattern_matcher: PatternMatcher):
        self.ast_parser = ast_parser
        self.pattern_matcher = pattern_matcher
    
    def analyze_taint_rule(self, rule: Dict[str, Any], ast_root: Node, 
                          code: str, file_path: Path) -> List[Dict[str, Any]]:
        """
        Analyze a taint-mode rule
        
        Rule structure:
        - pattern-sources: List of source patterns (user input)
        - pattern-sinks: List of sink patterns (dangerous functions)
        - pattern-sanitizers: List of sanitizer patterns (safety functions)
        """
        findings = []
        
        # Extract patterns from rule
        sources = rule.get('pattern-sources', [])
        sinks = rule.get('pattern-sinks', [])
        sanitizers = rule.get('pattern-sanitizers', [])
        
        if not sources or not sinks:
            return findings
        
        # Find all source nodes (tainted data origins)
        source_nodes = []
        for source_pattern in sources:
            matches = self.pattern_matcher.find_pattern_matches(
                [source_pattern] if isinstance(source_pattern, dict) else source_pattern,
                ast_root,
                code
            )
            source_nodes.extend(matches)
        
        # Find all sink nodes (dangerous operations)
        sink_nodes = []
        for sink_pattern in sinks:
            matches = self.pattern_matcher.find_pattern_matches(
                [sink_pattern] if isinstance(sink_pattern, dict) else sink_pattern,
                ast_root,
                code
            )
            sink_nodes.extend(matches)
        
        # For each sink, check if it uses tainted data
        for sink in sink_nodes:
            sink_node = sink['node']
            
            # Check if sink uses any source data
            tainted_sources = self._find_tainted_sources(
                sink_node, source_nodes, code
            )
            
            if tainted_sources:
                # Check if the taint is sanitized
                is_sanitized = False
                
                if sanitizers:
                    is_sanitized = self.pattern_matcher.check_sanitizer(
                        sanitizers, sink_node, code
                    )
                
                if not is_sanitized:
                    # Found a vulnerability!
                    findings.append({
                        'rule_id': rule.get('id', 'unknown'),
                        'message': rule.get('message', 'Potential vulnerability detected'),
                        'severity': rule.get('severity', 'WARNING'),
                        'file': str(file_path),
                        'line': sink['line'],
                        'column': sink['column'],
                        'sink': sink['text'],
                        'sources': [s['text'] for s in tainted_sources],
                        'category': self._extract_category(rule),
                        'cwe': rule.get('metadata', {}).get('cwe', []),
                        'confidence': rule.get('metadata', {}).get('confidence', 'MEDIUM')
                    })
        
        return findings
    
    def _find_tainted_sources(self, sink_node: Node, source_nodes: List[Dict[str, Any]], 
                             code: str) -> List[Dict[str, Any]]:
        """
        Find which sources taint the sink
        
        This is a simplified taint tracking that checks if:
        1. Source and sink are in the same function
        2. Source appears before sink
        3. Variables from source are used in sink
        """
        tainted = []
        
        # Get all variables used in the sink
        sink_vars = self._extract_variables(sink_node, code)
        
        for source in source_nodes:
            source_node = source['node']
            
            # Check if source is before sink in the code
            if source_node.start_point[0] > sink_node.start_point[0]:
                continue
            
            # Check if they're in the same scope (simplified)
            if not self._in_same_scope(source_node, sink_node):
                continue
            
            # Check if sink uses variables from source
            source_vars = self._extract_variables(source_node, code)
            
            # If any variable from source is used in sink, it's tainted
            if sink_vars & source_vars:
                tainted.append(source)
        
        return tainted
    
    def _extract_variables(self, node: Node, code: str) -> Set[str]:
        """Extract all variable names used in a node"""
        variables = set()
        
        def traverse(n: Node):
            if n.type in ['variable_name', 'variable']:
                var_text = self.pattern_matcher._get_node_text(n, code)
                if var_text:
                    variables.add(var_text)
            
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return variables
    
    def _in_same_scope(self, node1: Node, node2: Node) -> bool:
        """
        Check if two nodes are in the same scope
        
        Simplified: checks if they share a common function parent
        """
        # Find function parent of node1
        func1 = self._find_function_parent(node1)
        func2 = self._find_function_parent(node2)
        
        # If both are in the same function (or both at global scope)
        return func1 == func2
    
    def _find_function_parent(self, node: Node) -> Optional[Node]:
        """Find the function definition that contains this node"""
        current = node.parent
        
        while current:
            if current.type in ['function_definition', 'method_declaration']:
                return current
            current = current.parent
        
        return None  # Global scope
    
    def _extract_category(self, rule: Dict[str, Any]) -> str:
        """Extract vulnerability category from rule"""
        rule_id = rule.get('id', '')
        
        if 'xss' in rule_id.lower():
            return 'xss'
        elif 'sql' in rule_id.lower() or 'sqli' in rule_id.lower():
            return 'sqli'
        elif 'csrf' in rule_id.lower():
            return 'csrf'
        elif 'auth' in rule_id.lower():
            return 'auth'
        elif 'upload' in rule_id.lower() or 'file' in rule_id.lower():
            return 'file_upload'
        elif 'deserial' in rule_id.lower():
            return 'deserialization'
        
        return 'security'
    
    def analyze_search_rule(self, rule: Dict[str, Any], ast_root: Node, 
                           code: str, file_path: Path) -> List[Dict[str, Any]]:
        """
        Analyze a search-mode rule (simple pattern matching)
        
        Rule structure:
        - pattern: Single pattern to find
        - patterns: List of patterns (AND)
        - pattern-either: List of patterns (OR)
        """
        findings = []
        
        # Get the pattern(s) to search for
        if 'pattern' in rule:
            patterns = [{'pattern': rule['pattern']}]
        elif 'patterns' in rule:
            patterns = rule['patterns']
        elif 'pattern-either' in rule:
            patterns = [{'pattern-either': rule['pattern-either']}]
        else:
            return findings
        
        # Find all matches
        matches = self.pattern_matcher.find_pattern_matches(patterns, ast_root, code)
        
        # Convert matches to findings
        for match in matches:
            findings.append({
                'rule_id': rule.get('id', 'unknown'),
                'message': rule.get('message', 'Pattern matched'),
                'severity': rule.get('severity', 'INFO'),
                'file': str(file_path),
                'line': match['line'],
                'column': match['column'],
                'match': match['text'],
                'category': self._extract_category(rule),
                'cwe': rule.get('metadata', {}).get('cwe', []),
                'confidence': rule.get('metadata', {}).get('confidence', 'LOW')
            })
        
        return findings
