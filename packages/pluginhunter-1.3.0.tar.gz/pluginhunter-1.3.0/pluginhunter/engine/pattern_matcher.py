"""
Pattern matching engine for Semgrep-style rules
"""

import re
from typing import List, Dict, Any, Optional, Set
from pathlib import Path
from tree_sitter import Node


class PatternMatcher:
    """Matches Semgrep-style patterns against AST nodes"""
    
    def __init__(self, ast_parser):
        self.ast_parser = ast_parser
        self.metavariables = {}
    
    def match_pattern(self, pattern: str, node: Node, code: str) -> bool:
        """
        Match a Semgrep pattern against an AST node
        
        Supported patterns:
        - $_GET[$KEY] - Superglobal access
        - echo (...) - Function calls with any arguments
        - $FUNC(...) - Any function call
        - $VAR - Any variable
        - Literal strings and identifiers
        """
        pattern = pattern.strip()
        
        # Handle superglobal patterns: $_GET[$KEY], $_POST[$KEY], etc.
        if pattern.startswith('$_'):
            return self._match_superglobal_pattern(pattern, node, code)
        
        # Handle function call patterns: echo (...), func(...)
        if '(' in pattern:
            return self._match_function_call_pattern(pattern, node, code)
        
        # Handle variable patterns: $VAR
        if pattern.startswith('$') and pattern.isupper():
            return self._match_metavariable_pattern(pattern, node, code)
        
        # Handle literal patterns
        return self._match_literal_pattern(pattern, node, code)
    
    def _match_superglobal_pattern(self, pattern: str, node: Node, code: str) -> bool:
        """Match superglobal access patterns like $_GET[$KEY]"""
        # Extract superglobal name - handle both $_GET[$KEY] and $_GET[...]
        match = re.match(r'\$(_[A-Z]+)(\[|$)', pattern)
        if not match:
            return False
        
        superglobal = '$' + match.group(1)
        
        # Check if node is subscript expression (array access)
        if node.type != 'subscript_expression':
            # Also check if it's the variable itself
            if node.type in ['variable_name', 'variable']:
                var_text = self._get_node_text(node, code)
                return var_text == superglobal
            return False
        
        # Get the variable being accessed
        var_node = node.child_by_field_name('object')
        if not var_node:
            return False
        
        var_text = self._get_node_text(var_node, code)
        
        # Check if it matches the superglobal
        if var_text == superglobal:
            # Store the key as a metavariable if pattern has $KEY
            if '$KEY' in pattern:
                index_node = node.child_by_field_name('index')
                if index_node:
                    self.metavariables['$KEY'] = self._get_node_text(index_node, code)
            return True
        
        return False
    
    def _match_function_call_pattern(self, pattern: str, node: Node, code: str) -> bool:
        """Match function call patterns like echo (...), $FUNC(...)"""
        # Extract function name from pattern
        func_match = re.match(r'([a-zA-Z_$][a-zA-Z0-9_]*)\s*\(', pattern)
        if not func_match:
            return False
        
        func_pattern = func_match.group(1)
        
        # Check if node is a function call
        if node.type not in ['function_call_expression', 'echo_statement', 'print_intrinsic']:
            return False
        
        # For echo/print statements
        if node.type in ['echo_statement', 'print_intrinsic']:
            return func_pattern in ['echo', 'print']
        
        # For regular function calls
        func_node = node.child_by_field_name('function')
        if not func_node:
            return False
        
        func_name = self._get_node_text(func_node, code)
        
        # Handle metavariable patterns like $FUNC
        if func_pattern.startswith('$') and func_pattern.isupper():
            self.metavariables[func_pattern] = func_name
            return True
        
        # Handle literal function names
        return func_name == func_pattern
    
    def _match_metavariable_pattern(self, pattern: str, node: Node, code: str) -> bool:
        """Match metavariable patterns like $VAR, $FUNC"""
        # Metavariables match any node of appropriate type
        if pattern == '$VAR':
            return node.type in ['variable_name', 'variable']
        
        if pattern == '$FUNC':
            return node.type in ['name', 'qualified_name']
        
        if pattern == '$KEY':
            return True  # Keys can be anything
        
        # Store the matched value
        self.metavariables[pattern] = self._get_node_text(node, code)
        return True
    
    def _match_literal_pattern(self, pattern: str, node: Node, code: str) -> bool:
        """Match literal text patterns"""
        node_text = self._get_node_text(node, code)
        return pattern == node_text
    
    def _get_node_text(self, node: Node, code: str) -> str:
        """Get text content of a node"""
        if not node or not node.text:
            return ""
        return node.text.decode('utf-8')
    
    def match_pattern_list(self, patterns: List[Dict[str, Any]], node: Node, 
                          code: str, parent_node: Optional[Node] = None) -> bool:
        """
        Match a list of pattern conditions (AND logic)
        
        Handles:
        - pattern: Single pattern to match
        - pattern-not-inside: Pattern that should NOT contain this node
        - patterns: Nested list of patterns (AND)
        - pattern-either: List of patterns (OR)
        """
        for pattern_dict in patterns:
            if 'pattern' in pattern_dict:
                pattern = pattern_dict['pattern']
                if not self.match_pattern(pattern, node, code):
                    return False
            
            elif 'pattern-not-inside' in pattern_dict:
                # Check if node is NOT inside this pattern
                pattern = pattern_dict['pattern-not-inside']
                if self._is_inside_pattern(pattern, node, parent_node, code):
                    return False
            
            elif 'patterns' in pattern_dict:
                # Nested AND patterns
                if not self.match_pattern_list(pattern_dict['patterns'], node, code, parent_node):
                    return False
            
            elif 'pattern-either' in pattern_dict:
                # OR patterns - at least one must match
                matched = False
                for either_pattern in pattern_dict['pattern-either']:
                    if self.match_pattern_list([either_pattern], node, code, parent_node):
                        matched = True
                        break
                if not matched:
                    return False
            
            elif 'metavariable-regex' in pattern_dict:
                # Check metavariable against regex
                meta_config = pattern_dict['metavariable-regex']
                metavar = meta_config.get('metavariable')
                regex = meta_config.get('regex')
                
                if metavar in self.metavariables:
                    value = self.metavariables[metavar]
                    if not re.search(regex, value):
                        return False
        
        return True
    
    def _is_inside_pattern(self, pattern: str, node: Node, parent_node: Optional[Node], 
                          code: str) -> bool:
        """Check if node is inside a pattern (for pattern-not-inside)"""
        if not parent_node:
            return False
        
        # Walk up the tree to find if any parent matches the pattern
        current = parent_node
        while current:
            if self.match_pattern(pattern, current, code):
                return True
            current = current.parent
        
        return False
    
    def find_pattern_matches(self, pattern_list: List[Dict[str, Any]], 
                            ast_root: Node, code: str) -> List[Dict[str, Any]]:
        """Find all nodes matching a pattern list"""
        matches = []
        
        def traverse(node: Node, parent: Optional[Node] = None):
            # Reset metavariables for each node
            self.metavariables = {}
            
            # Try to match this node
            if self.match_pattern_list(pattern_list, node, code, parent):
                matches.append({
                    'node': node,
                    'line': node.start_point[0] + 1,
                    'column': node.start_point[1],
                    'text': self._get_node_text(node, code),
                    'metavariables': dict(self.metavariables)
                })
            
            # Traverse children
            for child in node.children:
                traverse(child, node)
        
        traverse(ast_root)
        return matches
    
    def check_sanitizer(self, sanitizer_patterns: List[Dict[str, Any]], 
                       node: Node, code: str) -> bool:
        """Check if a node is sanitized by any of the sanitizer patterns"""
        # Walk up the tree to find sanitizer functions
        current = node.parent
        
        while current:
            # Reset metavariables
            self.metavariables = {}
            
            # Check if current node matches any sanitizer pattern
            if self.match_pattern_list(sanitizer_patterns, current, code):
                return True
            
            current = current.parent
        
        return False
