"""
Configuration management for PluginHunter
"""

import os
from pathlib import Path
from typing import Dict, List, Optional
import yaml
from dataclasses import dataclass, field


@dataclass
class ScanConfig:
    """Configuration for vulnerability scanning"""
    source_type: str = "local"
    target: str = ""
    deep_scan: bool = False
    dynamic_verification: bool = False
    custom_rules_dir: Optional[str] = None
    output_format: str = "json"
    output_file: Optional[str] = None
    severity_filter: List[str] = field(default_factory=lambda: ["critical", "high", "medium", "low"])
    max_depth: int = 10
    timeout: int = 300
    current_directory: Path = field(default_factory=Path.cwd)


@dataclass
class Config:
    """Main configuration class"""
    
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.data_dir = self.base_dir / "data"
        self.rules_dir = self.data_dir  # Point to data directory with all subdirectories
        self.scan_config = ScanConfig()
        self.scan_config.current_directory = Path.cwd()
        
    def load_config(self, config_file: Optional[str] = None) -> None:
        """Load configuration from file"""
        if config_file and os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config_data = yaml.safe_load(f)
                
            # Update scan config
            for key, value in config_data.get('scan', {}).items():
                if hasattr(self.scan_config, key):
                    setattr(self.scan_config, key, value)
    
    def get_rules_directories(self) -> List[Path]:
        """Get all rule directories recursively"""
        dirs = []
        
        # Add all subdirectories in data folder
        if self.rules_dir.exists():
            for item in self.rules_dir.rglob('*'):
                if item.is_dir() and any(item.glob('*.yaml')) or any(item.glob('*.yml')):
                    dirs.append(item)
        
        # Add custom rules directory if specified
        if self.scan_config.custom_rules_dir:
            custom_dir = Path(self.scan_config.custom_rules_dir)
            if custom_dir.exists():
                dirs.append(custom_dir)
                
        return dirs
    
    def get_output_path(self, filename: str) -> Path:
        """Get output file path in current directory"""
        if self.scan_config.output_file:
            output_path = Path(self.scan_config.output_file)
            if not output_path.is_absolute():
                return self.scan_config.current_directory / output_path
            return output_path
        else:
            return self.scan_config.current_directory / filename