"""
Interactive configuration wizard for server mode
"""

import json
from pathlib import Path
from typing import Dict, Any
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table

console = Console()


class ServerConfigWizard:
    """Interactive wizard for server mode configuration"""
    
    def __init__(self, config_file: str = "server_config.json"):
        self.config_file = Path(config_file)
        self.config = self._load_or_create_config()
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """Load existing config or create default"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                console.print(f"[red]Error loading config: {e}[/red]")
        
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "continuous_mode": {
                "enabled": True,
                "delay_between_scans": 10,
                "max_concurrent_scans": 1,
                "restart_on_queue_empty": True
            },
            "cron_mode": {
                "enabled": False,
                "schedule_type": "daily",
                "time": "02:00",
                "day": "monday",
                "interval_hours": 24
            },
            "max_plugins_per_run": 10,
            "reports_dir": "./server_reports",
            "cache_dir": "./.wp_cache",
            "temp_dir": "./.wp_temp",
            "deep_scan": True,
            "dynamic_verification": False,
            "cleanup_temp_after_scan": True,
            "notifications": {
                "discord": {
                    "enabled": False,
                    "webhook_url": "",
                    "notify_on_start": True,
                    "notify_on_complete": True,
                    "notify_on_critical": True
                },
                "telegram": {
                    "enabled": False,
                    "bot_token": "",
                    "chat_id": "",
                    "notify_on_start": True,
                    "notify_on_complete": True,
                    "notify_on_critical": True,
                    "send_reports": False
                }
            },
            "scan_targets": {
                "popular_plugins": True,
                "new_plugins": True,
                "updated_plugins": True,
                "custom_list": [],
                "max_plugins_to_fetch": 1000
            },
            "alert_on_severity": ["critical", "high"],
            "database_refresh_hours": 24,
            "rate_limiting": {
                "enabled": True,
                "delay_between_plugins": 5,
                "max_retries": 3
            }
        }
    
    def run(self):
        """Run the configuration wizard"""
        console.print("\n[bold cyan]PluginHunter Server Mode Configuration[/bold cyan]")
        console.print("=" * 60)
        
        while True:
            self._show_menu()
            choice = console.input("\n[cyan]Select option (0-9):[/cyan] ").strip()
            
            if choice == "1":
                self._configure_scan_mode()
            elif choice == "2":
                self._configure_notifications()
            elif choice == "3":
                self._configure_scan_targets()
            elif choice == "4":
                self._configure_directories()
            elif choice == "5":
                self._configure_scan_settings()
            elif choice == "6":
                self._configure_rate_limiting()
            elif choice == "7":
                self._view_current_config()
            elif choice == "8":
                self._save_config()
            elif choice == "9":
                self._test_configuration()
            elif choice == "0":
                if Confirm.ask("Save configuration before exit?"):
                    self._save_config()
                break
            else:
                console.print("[red]Invalid option![/red]")
    
    def _show_menu(self):
        """Show configuration menu"""
        console.print("\n[bold]Configuration Menu:[/bold]")
        console.print("1. Configure Scan Mode (Continuous/Cron)")
        console.print("2. Configure Notifications (Discord/Telegram)")
        console.print("3. Configure Scan Targets")
        console.print("4. Configure Directories")
        console.print("5. Configure Scan Settings")
        console.print("6. Configure Rate Limiting")
        console.print("7. View Current Configuration")
        console.print("8. Save Configuration")
        console.print("9. Test Configuration")
        console.print("0. Exit")
    
    def _configure_scan_mode(self):
        """Configure scan mode"""
        console.print("\n[bold cyan]Scan Mode Configuration[/bold cyan]")
        
        mode = Prompt.ask(
            "Select mode",
            choices=["continuous", "cron"],
            default="continuous"
        )
        
        if mode == "continuous":
            self.config["continuous_mode"]["enabled"] = True
            self.config["cron_mode"]["enabled"] = False
            
            console.print("\n[yellow]Continuous Mode Settings:[/yellow]")
            
            delay = Prompt.ask(
                "Delay between scans (seconds)",
                default=str(self.config["continuous_mode"]["delay_between_scans"])
            )
            self.config["continuous_mode"]["delay_between_scans"] = int(delay)
            
            restart = Confirm.ask(
                "Restart queue when empty?",
                default=self.config["continuous_mode"]["restart_on_queue_empty"]
            )
            self.config["continuous_mode"]["restart_on_queue_empty"] = restart
            
        else:  # cron
            self.config["continuous_mode"]["enabled"] = False
            self.config["cron_mode"]["enabled"] = True
            
            console.print("\n[yellow]Cron Mode Settings:[/yellow]")
            
            schedule_type = Prompt.ask(
                "Schedule type",
                choices=["daily", "weekly", "hourly", "interval"],
                default=self.config["cron_mode"]["schedule_type"]
            )
            self.config["cron_mode"]["schedule_type"] = schedule_type
            
            if schedule_type == "daily":
                time = Prompt.ask(
                    "Time (HH:MM format)",
                    default=self.config["cron_mode"]["time"]
                )
                self.config["cron_mode"]["time"] = time
                
            elif schedule_type == "weekly":
                day = Prompt.ask(
                    "Day of week",
                    choices=["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"],
                    default=self.config["cron_mode"]["day"]
                )
                self.config["cron_mode"]["day"] = day
                
                time = Prompt.ask(
                    "Time (HH:MM format)",
                    default=self.config["cron_mode"]["time"]
                )
                self.config["cron_mode"]["time"] = time
                
            elif schedule_type == "interval":
                hours = Prompt.ask(
                    "Interval (hours)",
                    default=str(self.config["cron_mode"]["interval_hours"])
                )
                self.config["cron_mode"]["interval_hours"] = int(hours)
        
        # Database refresh schedule
        console.print("\n[yellow]Database Refresh Settings:[/yellow]")
        refresh_hours = Prompt.ask(
            "Refresh plugin database every (hours)",
            default=str(self.config["database_refresh_hours"])
        )
        self.config["database_refresh_hours"] = int(refresh_hours)
        
        console.print("\n[green]Scan mode configured successfully![/green]")
    
    def _configure_notifications(self):
        """Configure notification services"""
        console.print("\n[bold cyan]Notification Configuration[/bold cyan]")
        
        # Discord
        console.print("\n[yellow]Discord Configuration:[/yellow]")
        discord_enabled = Confirm.ask("Enable Discord notifications?", default=False)
        self.config["notifications"]["discord"]["enabled"] = discord_enabled
        
        if discord_enabled:
            webhook = Prompt.ask("Discord webhook URL")
            self.config["notifications"]["discord"]["webhook_url"] = webhook
            
            self.config["notifications"]["discord"]["notify_on_start"] = Confirm.ask(
                "Notify on scan start?", default=True
            )
            self.config["notifications"]["discord"]["notify_on_complete"] = Confirm.ask(
                "Notify on scan complete?", default=True
            )
            self.config["notifications"]["discord"]["notify_on_critical"] = Confirm.ask(
                "Notify on critical findings?", default=True
            )
        
        # Telegram
        console.print("\n[yellow]Telegram Configuration:[/yellow]")
        telegram_enabled = Confirm.ask("Enable Telegram notifications?", default=False)
        self.config["notifications"]["telegram"]["enabled"] = telegram_enabled
        
        if telegram_enabled:
            bot_token = Prompt.ask("Telegram bot token")
            self.config["notifications"]["telegram"]["bot_token"] = bot_token
            
            chat_id = Prompt.ask("Telegram chat ID")
            self.config["notifications"]["telegram"]["chat_id"] = chat_id
            
            self.config["notifications"]["telegram"]["notify_on_start"] = Confirm.ask(
                "Notify on scan start?", default=True
            )
            self.config["notifications"]["telegram"]["notify_on_complete"] = Confirm.ask(
                "Notify on scan complete?", default=True
            )
            self.config["notifications"]["telegram"]["notify_on_critical"] = Confirm.ask(
                "Notify on critical findings?", default=True
            )
            self.config["notifications"]["telegram"]["send_reports"] = Confirm.ask(
                "Send report files?", default=False
            )
        
        console.print("\n[green]Notifications configured successfully![/green]")
    
    def _configure_scan_targets(self):
        """Configure scan targets"""
        console.print("\n[bold cyan]Scan Targets Configuration[/bold cyan]")
        
        self.config["scan_targets"]["popular_plugins"] = Confirm.ask(
            "Scan popular plugins?",
            default=self.config["scan_targets"]["popular_plugins"]
        )
        
        self.config["scan_targets"]["new_plugins"] = Confirm.ask(
            "Scan new plugins?",
            default=self.config["scan_targets"]["new_plugins"]
        )
        
        self.config["scan_targets"]["updated_plugins"] = Confirm.ask(
            "Scan recently updated plugins?",
            default=self.config["scan_targets"]["updated_plugins"]
        )
        
        max_plugins = Prompt.ask(
            "Maximum plugins to fetch from WordPress.org",
            default=str(self.config["scan_targets"]["max_plugins_to_fetch"])
        )
        self.config["scan_targets"]["max_plugins_to_fetch"] = int(max_plugins)
        
        # Custom plugin list
        if Confirm.ask("Add custom plugins to scan?", default=False):
            console.print("Enter plugin slugs (comma-separated):")
            slugs = console.input("[cyan]Slugs:[/cyan] ").strip()
            if slugs:
                custom_list = [s.strip() for s in slugs.split(",")]
                self.config["scan_targets"]["custom_list"] = custom_list
        
        console.print("\n[green]Scan targets configured successfully![/green]")
    
    def _configure_directories(self):
        """Configure directory paths"""
        console.print("\n[bold cyan]Directory Configuration[/bold cyan]")
        
        reports_dir = Prompt.ask(
            "Reports directory",
            default=self.config["reports_dir"]
        )
        self.config["reports_dir"] = reports_dir
        
        cache_dir = Prompt.ask(
            "Cache directory",
            default=self.config["cache_dir"]
        )
        self.config["cache_dir"] = cache_dir
        
        temp_dir = Prompt.ask(
            "Temporary files directory",
            default=self.config.get("temp_dir", "./.wp_temp")
        )
        self.config["temp_dir"] = temp_dir
        
        cleanup = Confirm.ask(
            "Cleanup temporary files after scan?",
            default=self.config.get("cleanup_temp_after_scan", True)
        )
        self.config["cleanup_temp_after_scan"] = cleanup
        
        console.print("\n[green]Directories configured successfully![/green]")
    
    def _configure_scan_settings(self):
        """Configure scan settings"""
        console.print("\n[bold cyan]Scan Settings Configuration[/bold cyan]")
        
        max_per_run = Prompt.ask(
            "Maximum plugins per run",
            default=str(self.config["max_plugins_per_run"])
        )
        self.config["max_plugins_per_run"] = int(max_per_run)
        
        self.config["deep_scan"] = Confirm.ask(
            "Enable deep scan?",
            default=self.config["deep_scan"]
        )
        
        self.config["dynamic_verification"] = Confirm.ask(
            "Enable dynamic verification? (requires Docker)",
            default=self.config["dynamic_verification"]
        )
        
        # Alert severity
        console.print("\n[yellow]Alert on severity levels:[/yellow]")
        alert_severities = []
        
        if Confirm.ask("Alert on CRITICAL?", default=True):
            alert_severities.append("critical")
        if Confirm.ask("Alert on HIGH?", default=True):
            alert_severities.append("high")
        if Confirm.ask("Alert on MEDIUM?", default=False):
            alert_severities.append("medium")
        if Confirm.ask("Alert on LOW?", default=False):
            alert_severities.append("low")
        
        self.config["alert_on_severity"] = alert_severities
        
        console.print("\n[green]Scan settings configured successfully![/green]")
    
    def _configure_rate_limiting(self):
        """Configure rate limiting"""
        console.print("\n[bold cyan]Rate Limiting Configuration[/bold cyan]")
        
        self.config["rate_limiting"]["enabled"] = Confirm.ask(
            "Enable rate limiting?",
            default=self.config["rate_limiting"]["enabled"]
        )
        
        if self.config["rate_limiting"]["enabled"]:
            delay = Prompt.ask(
                "Delay between plugins (seconds)",
                default=str(self.config["rate_limiting"]["delay_between_plugins"])
            )
            self.config["rate_limiting"]["delay_between_plugins"] = int(delay)
            
            retries = Prompt.ask(
                "Maximum retries on failure",
                default=str(self.config["rate_limiting"]["max_retries"])
            )
            self.config["rate_limiting"]["max_retries"] = int(retries)
        
        console.print("\n[green]Rate limiting configured successfully![/green]")
    
    def _view_current_config(self):
        """Display current configuration"""
        console.print("\n[bold cyan]Current Configuration[/bold cyan]")
        console.print("=" * 60)
        
        # Scan Mode
        table = Table(title="Scan Mode")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="yellow")
        
        if self.config["continuous_mode"]["enabled"]:
            table.add_row("Mode", "CONTINUOUS")
            table.add_row("Delay Between Scans", f"{self.config['continuous_mode']['delay_between_scans']}s")
            table.add_row("Restart on Empty", str(self.config['continuous_mode']['restart_on_queue_empty']))
        else:
            table.add_row("Mode", "CRON")
            table.add_row("Schedule Type", self.config['cron_mode']['schedule_type'])
            if self.config['cron_mode']['schedule_type'] in ['daily', 'weekly']:
                table.add_row("Time", self.config['cron_mode']['time'])
            if self.config['cron_mode']['schedule_type'] == 'weekly':
                table.add_row("Day", self.config['cron_mode']['day'])
        
        console.print(table)
        
        # Notifications
        table = Table(title="Notifications")
        table.add_column("Service", style="cyan")
        table.add_column("Status", style="yellow")
        
        discord_status = "ENABLED" if self.config["notifications"]["discord"]["enabled"] else "DISABLED"
        telegram_status = "ENABLED" if self.config["notifications"]["telegram"]["enabled"] else "DISABLED"
        
        table.add_row("Discord", discord_status)
        table.add_row("Telegram", telegram_status)
        
        console.print(table)
        
        # Directories
        table = Table(title="Directories")
        table.add_column("Type", style="cyan")
        table.add_column("Path", style="yellow")
        
        table.add_row("Reports", self.config["reports_dir"])
        table.add_row("Cache", self.config["cache_dir"])
        table.add_row("Temp", self.config.get("temp_dir", "./.wp_temp"))
        
        console.print(table)
        
        console.input("\n[dim]Press Enter to continue...[/dim]")
    
    def _save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            console.print(f"\n[green]Configuration saved to {self.config_file}[/green]")
        except Exception as e:
            console.print(f"\n[red]Error saving configuration: {e}[/red]")
    
    def _test_configuration(self):
        """Test configuration"""
        console.print("\n[bold cyan]Testing Configuration[/bold cyan]")
        
        # Test Discord
        if self.config["notifications"]["discord"]["enabled"]:
            webhook_url = self.config["notifications"]["discord"]["webhook_url"]
            if webhook_url:
                console.print("[yellow]Testing Discord webhook...[/yellow]")
                try:
                    import requests
                    response = requests.post(
                        webhook_url,
                        json={"content": "[TEST] PluginHunter configuration test"},
                        timeout=10
                    )
                    if response.status_code == 204:
                        console.print("[green]Discord webhook OK![/green]")
                    else:
                        console.print(f"[red]Discord webhook failed: {response.status_code}[/red]")
                except Exception as e:
                    console.print(f"[red]Discord test failed: {e}[/red]")
        
        # Test Telegram
        if self.config["notifications"]["telegram"]["enabled"]:
            bot_token = self.config["notifications"]["telegram"]["bot_token"]
            chat_id = self.config["notifications"]["telegram"]["chat_id"]
            if bot_token and chat_id:
                console.print("[yellow]Testing Telegram bot...[/yellow]")
                try:
                    import requests
                    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                    response = requests.post(
                        url,
                        json={"chat_id": chat_id, "text": "[TEST] PluginHunter configuration test"},
                        timeout=10
                    )
                    if response.status_code == 200:
                        console.print("[green]Telegram bot OK![/green]")
                    else:
                        console.print(f"[red]Telegram bot failed: {response.status_code}[/red]")
                except Exception as e:
                    console.print(f"[red]Telegram test failed: {e}[/red]")
        
        # Test directories
        console.print("[yellow]Testing directories...[/yellow]")
        for dir_key in ["reports_dir", "cache_dir", "temp_dir"]:
            dir_path = Path(self.config.get(dir_key, ""))
            try:
                dir_path.mkdir(parents=True, exist_ok=True)
                console.print(f"[green]{dir_key}: OK[/green]")
            except Exception as e:
                console.print(f"[red]{dir_key}: Failed - {e}[/red]")
        
        console.input("\n[dim]Press Enter to continue...[/dim]")