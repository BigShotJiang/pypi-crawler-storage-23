"""
Server mode for automated continuous scanning
"""

import time
from pathlib import Path
from typing import Optional, List, Dict, Any
import json
from datetime import datetime

from ..config import Config
from ..scanner import VulnerabilityScanner
from .notifier import DiscordNotifier, TelegramNotifier
from .wp_api import WordPressAPIClient
from .scheduler import ScanScheduler
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class ServerMode:
    """Server mode for automated scanning"""
    
    def __init__(self, config_file: str):
        self.config_file = Path(config_file)
        self.server_config = self._load_server_config()
        self.config = Config()
        
        # Initialize components
        self.wp_api = WordPressAPIClient()
        self.scheduler = ScanScheduler()
        self.notifiers = self._init_notifiers()
        
        # Scan tracking
        self.scanned_plugins = set()
        self.scan_queue = []
        self.reports_dir = Path(self.server_config.get('reports_dir', './server_reports'))
        self.reports_dir.mkdir(exist_ok=True)
        
        # Statistics
        self.stats = {
            'total_scans': 0,
            'total_findings': 0,
            'critical_findings': 0,
            'plugins_scanned': 0
        }
    
    def _load_server_config(self) -> Dict[str, Any]:
        """Load server configuration"""
        if not self.config_file.exists():
            logger.error(f"Server config file not found: {self.config_file}")
            return self._get_default_config()
        
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load server config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default server configuration"""
        return {
            'mode': 'continuous',
            'continuous_mode': {
                'enabled': True,
                'delay_between_scans': 10,
                'max_concurrent_scans': 1,
                'restart_on_queue_empty': True
            },
            'cron_mode': {
                'enabled': False,
                'schedule_type': 'daily',
                'time': '02:00',
                'day': 'monday',
                'interval_hours': 24
            },
            'scan_interval_hours': 24,
            'max_plugins_per_run': 10,
            'reports_dir': './server_reports',
            'cache_dir': './.wp_cache',
            'deep_scan': True,
            'dynamic_verification': False,
            'notifications': {
                'discord': {
                    'enabled': False,
                    'webhook_url': '',
                    'notify_on_start': True,
                    'notify_on_complete': True,
                    'notify_on_critical': True
                },
                'telegram': {
                    'enabled': False,
                    'bot_token': '',
                    'chat_id': '',
                    'notify_on_start': True,
                    'notify_on_complete': True,
                    'notify_on_critical': True,
                    'send_reports': False
                }
            },
            'scan_targets': {
                'popular_plugins': True,
                'new_plugins': True,
                'updated_plugins': True,
                'custom_list': [],
                'max_plugins_to_fetch': 1000
            },
            'alert_on_severity': ['critical', 'high'],
            'database_refresh_hours': 24,
            'rate_limiting': {
                'enabled': True,
                'delay_between_plugins': 5,
                'max_retries': 3
            }
        }
    
    def _init_notifiers(self) -> List:
        """Initialize notification services"""
        notifiers = []
        
        notifications = self.server_config.get('notifications', {})
        
        # Discord
        discord_config = notifications.get('discord', {})
        if discord_config.get('enabled'):
            webhook_url = discord_config.get('webhook_url')
            if webhook_url:
                notifiers.append(DiscordNotifier(webhook_url))
                logger.info("Discord notifier initialized")
        
        # Telegram
        telegram_config = notifications.get('telegram', {})
        if telegram_config.get('enabled'):
            bot_token = telegram_config.get('bot_token')
            chat_id = telegram_config.get('chat_id')
            if bot_token and chat_id:
                notifiers.append(TelegramNotifier(bot_token, chat_id))
                logger.info("Telegram notifier initialized")
        
        return notifiers
    
    def start(self):
        """Start server mode"""
        logger.info("Starting PluginHunter in server mode...")
        
        # Build/refresh plugin database
        self._refresh_plugin_database()
        
        # Check mode
        continuous_config = self.server_config.get('continuous_mode', {})
        cron_config = self.server_config.get('cron_mode', {})
        
        if continuous_config.get('enabled', True):
            # Continuous endless scanning mode
            logger.info("Running in CONTINUOUS mode (endless scanning)")
            self._notify_startup()
            self._run_continuous_mode()
        elif cron_config.get('enabled', False):
            # Cron-based scheduled scanning
            logger.info("Running in CRON mode (scheduled scanning)")
            self._setup_schedule()
            self.scheduler.start()
            self._notify_startup()
            
            # Keep running
            try:
                while True:
                    time.sleep(60)
            except KeyboardInterrupt:
                logger.info("Shutting down server mode...")
                self.scheduler.stop()
        else:
            logger.error("No mode enabled in configuration!")
            return
    
    def _run_continuous_mode(self):
        """Run continuous endless scanning"""
        continuous_config = self.server_config.get('continuous_mode', {})
        delay = continuous_config.get('delay_between_scans', 10)
        restart_on_empty = continuous_config.get('restart_on_queue_empty', True)
        
        logger.info(f"Continuous mode: delay={delay}s, restart_on_empty={restart_on_empty}")
        
        try:
            while True:
                if not self.scan_queue:
                    if restart_on_empty:
                        logger.info("Queue empty, refreshing plugin database...")
                        self._refresh_plugin_database()
                    else:
                        logger.info("Queue empty, stopping...")
                        break
                
                if self.scan_queue:
                    slug = self.scan_queue.pop(0)
                    
                    if slug not in self.scanned_plugins:
                        self._scan_plugin(slug)
                        self.scanned_plugins.add(slug)
                        
                        # Rate limiting
                        rate_config = self.server_config.get('rate_limiting', {})
                        if rate_config.get('enabled', True):
                            delay_time = rate_config.get('delay_between_plugins', 5)
                            time.sleep(delay_time)
                    
                    # Delay between scans
                    time.sleep(delay)
                
        except KeyboardInterrupt:
            logger.info("Shutting down continuous mode...")
        except Exception as e:
            logger.error(f"Error in continuous mode: {e}")
            raise
    
    def _refresh_plugin_database(self):
        """Refresh plugin database from WordPress.org"""
        logger.info("Refreshing plugin database...")
        
        if self.wp_api.should_refresh_cache(max_age_hours=24):
            slugs = self.wp_api.build_plugin_database(max_pages=10)
            logger.info(f"Plugin database refreshed: {len(slugs)} plugins")
        else:
            slugs = self.wp_api.get_cached_slugs()
            logger.info(f"Using cached plugin database: {len(slugs)} plugins")
        
        self.scan_queue = slugs
    
    def _setup_schedule(self):
        """Setup scan schedule based on configuration"""
        cron_config = self.server_config.get('cron_mode', {})
        
        schedule_type = cron_config.get('schedule_type', 'daily')
        time_str = cron_config.get('time', '02:00')
        day = cron_config.get('day', 'monday')
        interval_hours = cron_config.get('interval_hours', 24)
        
        if schedule_type == 'daily':
            self.scheduler.schedule_daily_scan(self._run_scan_batch, time_str)
        elif schedule_type == 'weekly':
            self.scheduler.schedule_weekly_scan(self._run_scan_batch, day, time_str)
        elif schedule_type == 'hourly':
            self.scheduler.schedule_hourly_scan(self._run_scan_batch)
        elif schedule_type == 'interval':
            self.scheduler.schedule_interval_scan(self._run_scan_batch, interval_hours * 60)
        
        logger.info(f"Scan schedule configured: {schedule_type}")
    
    def _run_scan_batch(self):
        """Run a batch of scans"""
        max_plugins = self.server_config.get('max_plugins_per_run', 10)
        
        logger.info(f"Starting scan batch (max {max_plugins} plugins)...")
        
        scanned_count = 0
        
        while scanned_count < max_plugins and self.scan_queue:
            slug = self.scan_queue.pop(0)
            
            if slug in self.scanned_plugins:
                continue
            
            self._scan_plugin(slug)
            self.scanned_plugins.add(slug)
            scanned_count += 1
            
            # Rate limiting
            time.sleep(5)
        
        logger.info(f"Scan batch complete: {scanned_count} plugins scanned")
        
        # Refresh queue if empty
        if not self.scan_queue:
            self._refresh_plugin_database()
    
    def _scan_plugin(self, slug: str):
        """Scan a single plugin"""
        logger.info(f"Scanning plugin: {slug}")
        
        # Notify scan start
        scan_id = f"{slug}_{int(time.time())}"
        notifications = self.server_config.get('notifications', {})
        
        for notifier in self.notifiers:
            # Check if start notifications are enabled
            if isinstance(notifier, DiscordNotifier):
                if notifications.get('discord', {}).get('notify_on_start', True):
                    notifier.send_scan_start(slug, scan_id)
            elif isinstance(notifier, TelegramNotifier):
                if notifications.get('telegram', {}).get('notify_on_start', True):
                    notifier.send_scan_start(slug, scan_id)
        
        # Configure scanner
        self.config.scan_config.source_type = "slug"
        self.config.scan_config.target = slug
        self.config.scan_config.deep_scan = self.server_config.get('deep_scan', True)
        self.config.scan_config.dynamic_verification = self.server_config.get('dynamic_verification', False)
        
        # Run scan
        try:
            scanner = VulnerabilityScanner(self.config)
            result = scanner.scan()
            
            # Save report
            self._save_server_report(slug, result)
            
            # Update statistics
            self._update_stats(result)
            
            # Notify completion
            stats = result.get('statistics', {})
            findings_count = stats.get('total_findings', 0)
            severity_counts = stats.get('severity_counts', {})
            
            for notifier in self.notifiers:
                # Check if completion notifications are enabled
                if isinstance(notifier, DiscordNotifier):
                    if notifications.get('discord', {}).get('notify_on_complete', True):
                        notifier.send_scan_complete(slug, scan_id, findings_count, severity_counts)
                elif isinstance(notifier, TelegramNotifier):
                    if notifications.get('telegram', {}).get('notify_on_complete', True):
                        notifier.send_scan_complete(slug, scan_id, findings_count, severity_counts)
            
            # Alert on critical/high findings
            self._alert_critical_findings(slug, result)
            
            logger.info(f"Scan complete for {slug}: {findings_count} findings")
            
        except Exception as e:
            logger.error(f"Failed to scan {slug}: {e}")
    
    def _save_server_report(self, slug: str, result: Dict[str, Any]):
        """Save report in server reports directory"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Create plugin-specific directory
        plugin_dir = self.reports_dir / slug
        plugin_dir.mkdir(exist_ok=True)
        
        # Save JSON report
        json_file = plugin_dir / f"scan_{timestamp}.json"
        with open(json_file, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        
        # Generate and save markdown report
        md_file = plugin_dir / f"scan_{timestamp}.md"
        self._generate_markdown_report(result, md_file)
        
        logger.info(f"Reports saved to {plugin_dir}")
    
    def _generate_markdown_report(self, result: Dict[str, Any], output_file: Path):
        """Generate professional markdown report with POC"""
        from ..reporting.cve_formatter import CVEFormatter
        
        plugin_info = result.get('plugin_info', {})
        findings = result.get('findings', [])
        stats = result.get('statistics', {})
        
        md = []
        
        # Header
        md.append(f"# Security Audit Report: {plugin_info.get('name', 'Unknown')}\n")
        md.append(f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        md.append(f"**Scanner**: PluginHunter v1.2.1\n")
        md.append(f"**Author**: LAKSHMIKANTHAN K (letchupkt)\n")
        md.append("---\n")
        
        # Executive Summary
        md.append("\n## Executive Summary\n")
        md.append(f"- **Plugin**: {plugin_info.get('name', 'Unknown')}")
        md.append(f"- **Version**: {plugin_info.get('version', 'Unknown')}")
        md.append(f"- **Total Findings**: {stats.get('total_findings', 0)}")
        md.append(f"- **Critical**: {stats.get('severity_counts', {}).get('critical', 0)}")
        md.append(f"- **High**: {stats.get('severity_counts', {}).get('high', 0)}")
        md.append(f"- **Medium**: {stats.get('severity_counts', {}).get('medium', 0)}")
        md.append(f"- **Low**: {stats.get('severity_counts', {}).get('low', 0)}\n")
        
        # Detailed Findings
        if findings:
            md.append("\n## Detailed Findings\n")
            
            for i, finding in enumerate(findings, 1):
                cve_formatter = CVEFormatter()
                cve_report = cve_formatter.format_as_cve(finding, plugin_info)
                md.append(f"\n### Finding #{i}\n")
                md.append(cve_report)
                md.append("\n---\n")
        
        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(md))
    
    def _update_stats(self, result: Dict[str, Any]):
        """Update server statistics"""
        stats = result.get('statistics', {})
        
        self.stats['total_scans'] += 1
        self.stats['total_findings'] += stats.get('total_findings', 0)
        self.stats['critical_findings'] += stats.get('severity_counts', {}).get('critical', 0)
        self.stats['plugins_scanned'] += 1
    
    def _alert_critical_findings(self, slug: str, result: Dict[str, Any]):
        """Send alerts for critical/high findings"""
        alert_severities = self.server_config.get('alert_on_severity', ['critical', 'high'])
        findings = result.get('findings', [])
        notifications = self.server_config.get('notifications', {})
        
        for finding in findings:
            severity = finding.get('severity', '')
            if severity in alert_severities:
                for notifier in self.notifiers:
                    # Check if critical notifications are enabled
                    if isinstance(notifier, DiscordNotifier):
                        if notifications.get('discord', {}).get('notify_on_critical', True):
                            notifier.send_vulnerability_alert(slug, finding)
                    elif isinstance(notifier, TelegramNotifier):
                        if notifications.get('telegram', {}).get('notify_on_critical', True):
                            notifier.send_vulnerability_alert(slug, finding)
    
    def _notify_startup(self):
        """Send startup notification"""
        mode = "CONTINUOUS" if self.server_config.get('continuous_mode', {}).get('enabled') else "CRON"
        
        for notifier in self.notifiers:
            if hasattr(notifier, '_send_message'):
                notifier._send_message(
                    "*[SERVER STARTED] PluginHunter Server Mode*\n\n"
                    f"Mode: {mode}\n"
                    f"Plugins in queue: {len(self.scan_queue)}"
                )
            elif hasattr(notifier, '_send_webhook'):
                notifier._send_webhook({
                    "embeds": [{
                        "title": "[SERVER STARTED] PluginHunter",
                        "description": "Server mode is now running",
                        "color": 3066993,
                        "fields": [
                            {"name": "Mode", "value": mode},
                            {"name": "Plugins in Queue", "value": str(len(self.scan_queue))}
                        ]
                    }]
                })