"""
Cron-based scan scheduler
"""

import time
import schedule
from typing import Callable, List, Optional
from pathlib import Path
import threading
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class ScanScheduler:
    """Manages scheduled scans"""
    
    def __init__(self):
        self.jobs = []
        self.running = False
        self.thread = None
    
    def schedule_daily_scan(self, scan_func: Callable, time_str: str = "02:00"):
        """Schedule daily scan at specific time"""
        job = schedule.every().day.at(time_str).do(scan_func)
        self.jobs.append(job)
        logger.info(f"Scheduled daily scan at {time_str}")
        return job
    
    def schedule_hourly_scan(self, scan_func: Callable):
        """Schedule hourly scan"""
        job = schedule.every().hour.do(scan_func)
        self.jobs.append(job)
        logger.info("Scheduled hourly scan")
        return job
    
    def schedule_weekly_scan(self, scan_func: Callable, day: str = "monday", time_str: str = "02:00"):
        """Schedule weekly scan"""
        day_func = getattr(schedule.every(), day.lower())
        job = day_func.at(time_str).do(scan_func)
        self.jobs.append(job)
        logger.info(f"Scheduled weekly scan on {day} at {time_str}")
        return job
    
    def schedule_interval_scan(self, scan_func: Callable, minutes: int):
        """Schedule scan at specific interval"""
        job = schedule.every(minutes).minutes.do(scan_func)
        self.jobs.append(job)
        logger.info(f"Scheduled scan every {minutes} minutes")
        return job
    
    def start(self):
        """Start the scheduler"""
        if self.running:
            logger.warning("Scheduler already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._run_scheduler, daemon=True)
        self.thread.start()
        logger.info("Scheduler started")
    
    def stop(self):
        """Stop the scheduler"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Scheduler stopped")
    
    def _run_scheduler(self):
        """Run the scheduler loop"""
        while self.running:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
    
    def clear_all(self):
        """Clear all scheduled jobs"""
        schedule.clear()
        self.jobs.clear()
        logger.info("All scheduled jobs cleared")
    
    def get_jobs(self) -> List:
        """Get all scheduled jobs"""
        return schedule.get_jobs()
    
    def get_next_run(self) -> Optional[str]:
        """Get next scheduled run time"""
        jobs = schedule.get_jobs()
        if jobs:
            next_job = min(jobs, key=lambda j: j.next_run)
            return str(next_job.next_run)
        return None