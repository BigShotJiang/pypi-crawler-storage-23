"""
Notification system for Discord and Telegram
"""

import requests
from typing import Dict, Any, List, Optional
from pathlib import Path
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class BaseNotifier:
    """Base class for notifiers"""
    
    def send_scan_start(self, plugin_name: str, scan_id: str):
        """Send scan start notification"""
        raise NotImplementedError
    
    def send_scan_complete(self, plugin_name: str, scan_id: str, findings_count: int, severity_counts: Dict[str, int]):
        """Send scan completion notification"""
        raise NotImplementedError
    
    def send_vulnerability_alert(self, plugin_name: str, vulnerability: Dict[str, Any]):
        """Send critical vulnerability alert"""
        raise NotImplementedError
    
    def send_report(self, plugin_name: str, report_path: Path):
        """Send full report"""
        raise NotImplementedError


class DiscordNotifier(BaseNotifier):
    """Discord webhook notifier"""
    
    def __init__(self, webhook_url: str):
        self.webhook_url = webhook_url
    
    def send_scan_start(self, plugin_name: str, scan_id: str):
        """Send scan start notification to Discord"""
        embed = {
            "title": "[SCAN STARTED]",
            "description": f"Starting vulnerability scan for **{plugin_name}**",
            "color": 3447003,
            "fields": [
                {"name": "Plugin", "value": plugin_name, "inline": True},
                {"name": "Scan ID", "value": scan_id, "inline": True}
            ],
            "timestamp": self._get_timestamp()
        }
        
        self._send_webhook({"embeds": [embed]})
    
    def send_scan_complete(self, plugin_name: str, scan_id: str, findings_count: int, severity_counts: Dict[str, int]):
        """Send scan completion notification to Discord"""
        color = self._get_color_by_severity(severity_counts)
        
        fields = [
            {"name": "Plugin", "value": plugin_name, "inline": True},
            {"name": "Total Findings", "value": str(findings_count), "inline": True},
            {"name": "Critical", "value": str(severity_counts.get('critical', 0)), "inline": True},
            {"name": "High", "value": str(severity_counts.get('high', 0)), "inline": True},
            {"name": "Medium", "value": str(severity_counts.get('medium', 0)), "inline": True},
            {"name": "Low", "value": str(severity_counts.get('low', 0)), "inline": True}
        ]
        
        embed = {
            "title": "[SCAN COMPLETE]",
            "description": f"Vulnerability scan completed for **{plugin_name}**",
            "color": color,
            "fields": fields,
            "timestamp": self._get_timestamp()
        }
        
        self._send_webhook({"embeds": [embed]})
    
    def send_vulnerability_alert(self, plugin_name: str, vulnerability: Dict[str, Any]):
        """Send critical vulnerability alert to Discord"""
        severity = vulnerability.get('severity', 'unknown')
        title = vulnerability.get('title', 'Unknown Vulnerability')
        
        embed = {
            "title": f"[ALERT] {severity.upper()} Vulnerability Detected",
            "description": f"**{title}** found in **{plugin_name}**",
            "color": 15158332,
            "fields": [
                {"name": "Plugin", "value": plugin_name, "inline": True},
                {"name": "Severity", "value": severity.upper(), "inline": True},
                {"name": "Type", "value": title, "inline": False},
                {"name": "File", "value": vulnerability.get('file', 'Unknown'), "inline": True},
                {"name": "Line", "value": str(vulnerability.get('line', 'N/A')), "inline": True},
                {"name": "CWE", "value": vulnerability.get('cwe', 'N/A'), "inline": True}
            ],
            "timestamp": self._get_timestamp()
        }
        
        self._send_webhook({"embeds": [embed]})
    
    def send_report(self, plugin_name: str, report_path: Path):
        """Send report link to Discord"""
        embed = {
            "title": "[REPORT] Scan Report Available",
            "description": f"Full report for **{plugin_name}** is ready",
            "color": 3066993,
            "fields": [
                {"name": "Plugin", "value": plugin_name, "inline": True},
                {"name": "Report", "value": str(report_path.name), "inline": True}
            ],
            "timestamp": self._get_timestamp()
        }
        
        self._send_webhook({"embeds": [embed]})
    
    def _send_webhook(self, payload: Dict[str, Any]):
        """Send webhook to Discord"""
        try:
            response = requests.post(self.webhook_url, json=payload, timeout=10)
            response.raise_for_status()
            logger.debug("Discord notification sent successfully")
        except Exception as e:
            logger.error(f"Failed to send Discord notification: {e}")
    
    def _get_color_by_severity(self, severity_counts: Dict[str, int]) -> int:
        """Get embed color based on severity"""
        if severity_counts.get('critical', 0) > 0:
            return 15158332  # Red
        elif severity_counts.get('high', 0) > 0:
            return 15105570  # Orange
        elif severity_counts.get('medium', 0) > 0:
            return 16776960  # Yellow
        else:
            return 3066993  # Green
    
    def _get_timestamp(self) -> str:
        """Get ISO timestamp"""
        from datetime import datetime
        return datetime.utcnow().isoformat()


class TelegramNotifier(BaseNotifier):
    """Telegram bot notifier"""
    
    def __init__(self, bot_token: str, chat_id: str):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{bot_token}"
    
    def send_scan_start(self, plugin_name: str, scan_id: str):
        """Send scan start notification to Telegram"""
        message = (
            f"*[SCAN STARTED]*\n\n"
            f"Plugin: `{plugin_name}`\n"
            f"Scan ID: `{scan_id}`"
        )
        self._send_message(message)
    
    def send_scan_complete(self, plugin_name: str, scan_id: str, findings_count: int, severity_counts: Dict[str, int]):
        """Send scan completion notification to Telegram"""
        status = self._get_status_by_severity(severity_counts)
        
        message = (
            f"*[SCAN COMPLETE] {status}*\n\n"
            f"Plugin: `{plugin_name}`\n"
            f"Total Findings: *{findings_count}*\n\n"
            f"Critical: {severity_counts.get('critical', 0)}\n"
            f"High: {severity_counts.get('high', 0)}\n"
            f"Medium: {severity_counts.get('medium', 0)}\n"
            f"Low: {severity_counts.get('low', 0)}"
        )
        self._send_message(message)
    
    def send_vulnerability_alert(self, plugin_name: str, vulnerability: Dict[str, Any]):
        """Send critical vulnerability alert to Telegram"""
        severity = vulnerability.get('severity', 'unknown')
        title = vulnerability.get('title', 'Unknown Vulnerability')
        
        message = (
            f"*[ALERT] {severity.upper()} Vulnerability Detected*\n\n"
            f"Plugin: `{plugin_name}`\n"
            f"Type: *{title}*\n"
            f"File: `{vulnerability.get('file', 'Unknown')}`\n"
            f"Line: `{vulnerability.get('line', 'N/A')}`\n"
            f"CWE: `{vulnerability.get('cwe', 'N/A')}`"
        )
        self._send_message(message)
    
    def send_report(self, plugin_name: str, report_path: Path):
        """Send report to Telegram"""
        message = (
            f"*[REPORT] Scan Report Available*\n\n"
            f"Plugin: `{plugin_name}`\n"
            f"Report: `{report_path.name}`"
        )
        self._send_message(message)
        
        # Try to send the file
        if report_path.exists() and report_path.suffix in ['.html', '.md']:
            self._send_document(report_path)
    
    def _send_message(self, text: str):
        """Send text message to Telegram"""
        try:
            url = f"{self.api_url}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": text,
                "parse_mode": "Markdown"
            }
            response = requests.post(url, json=payload, timeout=10)
            response.raise_for_status()
            logger.debug("Telegram notification sent successfully")
        except Exception as e:
            logger.error(f"Failed to send Telegram notification: {e}")
    
    def _send_document(self, file_path: Path):
        """Send document to Telegram"""
        try:
            url = f"{self.api_url}/sendDocument"
            with open(file_path, 'rb') as f:
                files = {'document': f}
                data = {'chat_id': self.chat_id}
                response = requests.post(url, data=data, files=files, timeout=30)
                response.raise_for_status()
            logger.debug("Telegram document sent successfully")
        except Exception as e:
            logger.error(f"Failed to send Telegram document: {e}")
    
    def _get_emoji_by_severity(self, severity_counts: Dict[str, int]) -> str:
        """Get emoji based on severity"""
        if severity_counts.get('critical', 0) > 0:
            return "[CRITICAL]"
        elif severity_counts.get('high', 0) > 0:
            return "[HIGH]"
        elif severity_counts.get('medium', 0) > 0:
            return "[MEDIUM]"
        else:
            return "[CLEAN]"
    
    def _get_status_by_severity(self, severity_counts: Dict[str, int]) -> str:
        """Get status based on severity"""
        if severity_counts.get('critical', 0) > 0:
            return "CRITICAL"
        elif severity_counts.get('high', 0) > 0:
            return "HIGH"
        elif severity_counts.get('medium', 0) > 0:
            return "MEDIUM"
        else:
            return "CLEAN"