"""
WordPress.org API client for plugin discovery
"""

import requests
import time
from typing import List, Dict, Any, Optional
from pathlib import Path
import json
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


class WordPressAPIClient:
    """Client for WordPress.org Plugin API"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        self.api_base = "https://api.wordpress.org/plugins/info/1.2/"
        self.cache_dir = cache_dir or Path.cwd() / ".wp_cache"
        self.cache_dir.mkdir(exist_ok=True)
        self.cache_file = self.cache_dir / "plugins_cache.json"
    
    def get_popular_plugins(self, per_page: int = 100, page: int = 1) -> List[Dict[str, Any]]:
        """Get popular plugins from WordPress.org"""
        try:
            params = {
                'action': 'query_plugins',
                'request[browse]': 'popular',
                'request[per_page]': per_page,
                'request[page]': page
            }
            
            response = requests.get(self.api_base, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            plugins = data.get('plugins', [])
            
            logger.info(f"Retrieved {len(plugins)} popular plugins (page {page})")
            return plugins
            
        except Exception as e:
            logger.error(f"Failed to fetch popular plugins: {e}")
            return []
    
    def get_new_plugins(self, per_page: int = 100) -> List[Dict[str, Any]]:
        """Get newly added plugins"""
        try:
            params = {
                'action': 'query_plugins',
                'request[browse]': 'new',
                'request[per_page]': per_page
            }
            
            response = requests.get(self.api_base, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            plugins = data.get('plugins', [])
            
            logger.info(f"Retrieved {len(plugins)} new plugins")
            return plugins
            
        except Exception as e:
            logger.error(f"Failed to fetch new plugins: {e}")
            return []
    
    def get_updated_plugins(self, per_page: int = 100) -> List[Dict[str, Any]]:
        """Get recently updated plugins"""
        try:
            params = {
                'action': 'query_plugins',
                'request[browse]': 'updated',
                'request[per_page]': per_page
            }
            
            response = requests.get(self.api_base, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            plugins = data.get('plugins', [])
            
            logger.info(f"Retrieved {len(plugins)} updated plugins")
            return plugins
            
        except Exception as e:
            logger.error(f"Failed to fetch updated plugins: {e}")
            return []
    
    def get_plugin_info(self, slug: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific plugin"""
        try:
            params = {
                'action': 'plugin_information',
                'request[slug]': slug
            }
            
            response = requests.get(self.api_base, params=params, timeout=30)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to fetch plugin info for {slug}: {e}")
            return None
    
    def build_plugin_database(self, max_pages: int = 10) -> List[str]:
        """Build database of plugin slugs"""
        all_slugs = set()
        
        logger.info("Building plugin database from WordPress.org...")
        
        # Get popular plugins
        for page in range(1, max_pages + 1):
            plugins = self.get_popular_plugins(per_page=100, page=page)
            for plugin in plugins:
                all_slugs.add(plugin.get('slug'))
            time.sleep(1)  # Rate limiting
        
        # Get new plugins
        new_plugins = self.get_new_plugins(per_page=100)
        for plugin in new_plugins:
            all_slugs.add(plugin.get('slug'))
        
        # Get updated plugins
        updated_plugins = self.get_updated_plugins(per_page=100)
        for plugin in updated_plugins:
            all_slugs.add(plugin.get('slug'))
        
        slugs_list = sorted(list(all_slugs))
        
        # Cache the slugs
        self._save_cache(slugs_list)
        
        logger.info(f"Built database with {len(slugs_list)} plugins")
        return slugs_list
    
    def get_cached_slugs(self) -> List[str]:
        """Get cached plugin slugs"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    return data.get('slugs', [])
            except Exception as e:
                logger.error(f"Failed to load cache: {e}")
        
        return []
    
    def _save_cache(self, slugs: List[str]):
        """Save slugs to cache"""
        try:
            data = {
                'slugs': slugs,
                'timestamp': time.time(),
                'count': len(slugs)
            }
            
            with open(self.cache_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"Cached {len(slugs)} plugin slugs")
        except Exception as e:
            logger.error(f"Failed to save cache: {e}")
    
    def get_cache_age(self) -> Optional[float]:
        """Get age of cache in hours"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    timestamp = data.get('timestamp', 0)
                    age_seconds = time.time() - timestamp
                    return age_seconds / 3600  # Convert to hours
            except Exception:
                pass
        
        return None
    
    def should_refresh_cache(self, max_age_hours: int = 24) -> bool:
        """Check if cache should be refreshed"""
        age = self.get_cache_age()
        if age is None:
            return True
        
        return age > max_age_hours