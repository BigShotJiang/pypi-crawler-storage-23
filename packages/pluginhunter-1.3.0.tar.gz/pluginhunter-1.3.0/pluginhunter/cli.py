"""
CLI interface for PluginHunter
Author: LAKSHMIKANTHAN K (letchupkt)
"""

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress
from pathlib import Path
from typing import Optional, Dict, Any
import sys

from .config import Config
from .scanner import VulnerabilityScanner
from .reporting.report_generator import ReportGenerator
from .reporting.cve_formatter import CVEFormatter
from . import __version__, __author__

app = typer.Typer(help="PluginHunter - Advanced WordPress Plugin Vulnerability Scanner")
console = Console()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """PluginHunter - Advanced WordPress Plugin Vulnerability Scanner
    
    Run without arguments to launch interactive menu, or use commands:
    
    • scan: Scan a WordPress plugin
    
    • interactive: Launch interactive menu
    
    • version: Show version information
    """
    if ctx.invoked_subcommand is None:
        # No command provided, launch interactive mode
        interactive()


def print_banner():
    """Print ASCII banner"""
    banner = r"""
[bold red]
__________ .__            ____  .__           ___ ___                  __                   
\______   \|  |   __ __  / ___\ |__|  ____   /   |   \  __ __   ____ _/  |_   ____ _______ 
 |     ___/|  |  |  |  \/ /_/  >|  | /    \ /    ~    \|  |  \ /    \\   __\_/ __ \\_  __ \
 |    |    |  |__|  |  /\___  / |  ||   |  \\    Y    /|  |  /|   |  \|  |  \  ___/ |  | \/
 |____|    |____/|____//_____/  |__||___|  / \___|_  / |____/ |___|  /|__|   \___  >|__|   
                                         \/        \/              \/            \/         
[/bold red]

[bold cyan]PluginHunter — WordPress Plugin Vulnerability Scanner[/bold cyan]
[yellow]Author: {author} | Version: {version} | License: MIT[/yellow]
""".format(author=__author__, version=__version__)
    
    console.print(banner)


@app.command()
def scan(
    source: str = typer.Option(..., "--source", "-s", help="Source type: local, zip, slug, github"),
    target: str = typer.Option(..., "--target", "-t", help="Target path/slug/URL"),
    deep: bool = typer.Option(False, "--deep", help="Enable deep scan"),
    dynamic: bool = typer.Option(False, "--dynamic", help="Enable dynamic verification"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
    format: str = typer.Option("json", "--format", "-f", help="Output format: json, markdown, html"),
    rules_dir: Optional[str] = typer.Option(None, "--rules-dir", help="Custom rules directory")
):
    """Scan WordPress plugin for vulnerabilities"""
    
    print_banner()
    
    # Configure scan
    config = Config()
    config.scan_config.source_type = source
    config.scan_config.target = target
    config.scan_config.deep_scan = deep
    config.scan_config.dynamic_verification = dynamic
    config.scan_config.custom_rules_dir = rules_dir
    config.scan_config.output_format = format
    config.scan_config.output_file = output
    
    # Run scan
    console.print("\n[bold green]Starting scan...[/bold green]\n")
    
    scanner = VulnerabilityScanner(config)
    result = scanner.scan()
    
    # Display results
    display_results(result)
    
    # Generate reports
    if output:
        generate_reports(result, output, format)
    
    # Exit with appropriate code
    total_findings = result.get('statistics', {}).get('total_findings', 0)
    sys.exit(1 if total_findings > 0 else 0)


@app.command()
def interactive():
    """Launch interactive menu"""
    
    print_banner()
    
    while True:
        console.print("\n" + "=" * 60)
        console.print("[bold cyan][*] PluginHunter Interactive Menu[/bold cyan]")
        console.print("=" * 60)
        console.print("[bold green]1[/bold green]           [*] Scan WordPress.org Plugin (by slug)")
        console.print("[bold green]2[/bold green]           [*] Scan Local ZIP File")
        console.print("[bold green]3[/bold green]           [*] Scan GitHub Repository")
        console.print("[bold green]4[/bold green]           [*] Manage Detection Rules (Unified)")
        console.print("[bold green]5[/bold green]           [*] View Scan History")
        console.print("[bold green]6[/bold green]           [*] Configuration Settings")
        console.print("[bold green]7[/bold green]           [*] Server Mode Configuration")
        console.print("[bold green]8[/bold green]           [*] Start Server Mode")
        console.print("[bold green]9[/bold green]           [*] About PluginHunter")
        console.print("[bold green]0[/bold green]           [*] Exit")
        console.print("=" * 60)
        
        choice = console.input("\n[bold cyan]Select an option [0-9] (1):[/bold cyan] ").strip() or "1"
        
        if choice == "1":
            scan_wordpress_plugin()
        elif choice == "2":
            scan_local_zip()
        elif choice == "3":
            scan_github_repo()
        elif choice == "4":
            manage_rules()
        elif choice == "5":
            view_history()
        elif choice == "6":
            configuration_settings()
        elif choice == "7":
            server_mode_configuration()
        elif choice == "8":
            start_server_mode()
        elif choice == "9":
            about()
        elif choice == "0":
            console.print("\n[yellow]Exiting PluginHunter...[/yellow]")
            break
        else:
            console.print("[red]Invalid option! Please select 0-9.[/red]")


def scan_wordpress_plugin():
    """Scan WordPress.org plugin"""
    console.print("\n[bold cyan]═══ Scan WordPress.org Plugin ═══[/bold cyan]")
    slug = console.input("[yellow]Enter plugin slug:[/yellow] ").strip()
    
    if not slug:
        console.print("[red]Plugin slug cannot be empty![/red]")
        return
    
    console.print(f"\n[bold green]Starting deep scan of '{slug}'...[/bold green]\n")
    
    config = Config()
    config.scan_config.source_type = "slug"
    config.scan_config.target = slug
    config.scan_config.deep_scan = True  # Always deep scan
    config.scan_config.dynamic_verification = False  # Disable by default
    
    scanner = VulnerabilityScanner(config)
    result = scanner.scan()
    
    display_results(result)
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def scan_local_zip():
    """Scan local ZIP file"""
    console.print("\n[bold cyan]═══ Scan Local ZIP File ═══[/bold cyan]")
def scan_local_zip():
    """Scan local ZIP file"""
    console.print("\n[bold cyan]═══ Scan Local ZIP File ═══[/bold cyan]")
    path = console.input("[yellow]Enter ZIP file path:[/yellow] ").strip()
    
    if not path:
        console.print("[red]Path cannot be empty![/red]")
        return
    
    console.print(f"\n[bold green]Starting deep scan of '{path}'...[/bold green]\n")
    
    config = Config()
    config.scan_config.source_type = "zip"
    config.scan_config.target = path
    config.scan_config.deep_scan = True  # Always deep scan
    
    scanner = VulnerabilityScanner(config)
    result = scanner.scan()
    
    display_results(result)
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def scan_github_repo():
    """Scan GitHub repository"""
    console.print("\n[bold cyan]═══ Scan GitHub Repository ═══[/bold cyan]")
    repo = console.input("[yellow]Enter GitHub repository (user/repo):[/yellow] ").strip()
    
    if not repo:
        console.print("[red]Repository cannot be empty![/red]")
        return
    
    console.print(f"\n[bold green]Starting deep scan of '{repo}'...[/bold green]\n")
    
    config = Config()
    config.scan_config.source_type = "github"
    config.scan_config.target = repo
    config.scan_config.deep_scan = True  # Always deep scan
    
    scanner = VulnerabilityScanner(config)
    result = scanner.scan()
    
    display_results(result)
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def manage_rules():
    """Manage detection rules"""
    console.print("\n[bold cyan]═══ Detection Rules Management ═══[/bold cyan]")
    
    from .rules.loader import RuleLoader
    from .config import Config
    
    config = Config()
    loader = RuleLoader()
    loader.load_rules_from_directories(config.get_rules_directories())
    
    stats = loader.get_rule_stats()
    
    console.print(f"\n[green]Total Rules:[/green] {stats['total_rules']}")
    console.print(f"[green]Categories:[/green] {stats['categories']}")
    console.print(f"\n[yellow]Rules by Category:[/yellow]")
    
    for category, count in stats['by_category'].items():
        console.print(f"  • {category}: {count}")
    
    console.print(f"\n[yellow]Rules by Severity:[/yellow]")
    for severity, count in stats['by_severity'].items():
        console.print(f"  • {severity}: {count}")
    
    console.print(f"\n[dim]Rules location: {config.rules_dir}[/dim]")
    console.print("[dim]Add custom rules by creating YAML files in the rules directory[/dim]")
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def view_history():
    """View scan history"""
    console.print("\n[bold cyan]═══ Scan History ═══[/bold cyan]")
    
    import glob
    from pathlib import Path
    
    # Look for scan reports in current directory
    json_files = list(Path.cwd().glob("scan_*.json"))
    
    if not json_files:
        console.print("\n[yellow]No scan history found in current directory.[/yellow]")
    else:
        console.print(f"\n[green]Found {len(json_files)} scan reports:[/green]\n")
        
        for i, file in enumerate(sorted(json_files, reverse=True)[:10], 1):
            import json
            try:
                with open(file, 'r') as f:
                    data = json.load(f)
                    plugin = data.get('plugin_info', {}).get('name', 'Unknown')
                    findings = data.get('statistics', {}).get('total_findings', 0)
                    console.print(f"  {i}. {file.name}")
                    console.print(f"     Plugin: {plugin}, Findings: {findings}")
            except:
                console.print(f"  {i}. {file.name}")
        
        if len(json_files) > 10:
            console.print(f"\n[dim]... and {len(json_files) - 10} more[/dim]")
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def configuration_settings():
    """Configuration settings"""
    console.print("\n[bold cyan]═══ Configuration Settings ═══[/bold cyan]")
    
    from .config import Config
    import os
    
    config = Config()
    
    console.print(f"\n[yellow]Current Settings:[/yellow]")
    console.print(f"  • Working Directory: {Path.cwd()}")
    console.print(f"  • Rules Directory: {config.rules_dir}")
    console.print(f"  • Python Version: {os.sys.version.split()[0]}")
    
    # Check dependencies
    console.print(f"\n[yellow]Dependencies:[/yellow]")
    
    deps = {
        'tree-sitter': 'tree_sitter',
        'tree-sitter-php': 'tree_sitter_php',
        'networkx': 'networkx',
        'docker': 'docker'
    }
    
    for name, module in deps.items():
        try:
            __import__(module)
            console.print(f"  ✓ {name}: [green]Installed[/green]")
        except ImportError:
            status = "[yellow]Not installed[/yellow]" if name != 'docker' else "[dim]Not installed (optional)[/dim]"
            console.print(f"  ✗ {name}: {status}")
    
    console.input("\n[dim]Press Enter to continue...[/dim]")


def about():
    """About PluginHunter"""
    console.print(Panel.fit(
        f"""
[bold cyan]PluginHunter[/bold cyan]
[yellow]Version:[/yellow] {__version__}
[yellow]Author:[/yellow] {__author__}
[yellow]License:[/yellow] MIT

[bold]Advanced WordPress Plugin Vulnerability Scanner[/bold]

Features:
• Static analysis using tree-sitter AST parsing
• Taint tracking with data flow analysis
• WordPress-specific security checks
• YAML-based rule engine
• Dynamic verification (optional)
• Multiple output formats

Detects:
• SQL Injection
• Cross-Site Scripting (XSS)
• Remote Code Execution (RCE)
• CSRF
• SSRF
• File Upload vulnerabilities
• Insecure Deserialization
• Authentication/Authorization issues
• And more...
        """,
        title="About",
        border_style="cyan"
    ))
    console.print("\nPress Enter to continue...")
    input()


def display_results(result: Dict):
    """Display scan results"""
    stats = result.get('statistics', {})
    findings = result.get('findings', [])
    
    # Summary table
    table = Table(title="Scan Summary", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="yellow")
    
    table.add_row("Scan ID", result.get('scan_id', 'N/A'))
    table.add_row("Plugin", stats.get('plugin_name', 'Unknown'))
    table.add_row("Version", stats.get('plugin_version', 'Unknown'))
    table.add_row("Duration", f"{stats.get('duration', 0):.2f}s")
    table.add_row("Files Scanned", str(stats.get('files_scanned', 0)))
    table.add_row("Total Findings", str(stats.get('total_findings', 0)))
    
    console.print("\n")
    console.print(table)
    
    # Severity breakdown
    severity_counts = stats.get('severity_counts', {})
    if any(severity_counts.values()):
        console.print("\n[bold]Severity Breakdown:[/bold]")
        console.print(f"  [red]Critical:[/red] {severity_counts.get('critical', 0)}")
        console.print(f"  [orange3]High:[/orange3] {severity_counts.get('high', 0)}")
        console.print(f"  [yellow]Medium:[/yellow] {severity_counts.get('medium', 0)}")
        console.print(f"  [blue]Low:[/blue] {severity_counts.get('low', 0)}")
    
    # Findings table
    if findings:
        console.print("\n[bold red]Vulnerabilities Found:[/bold red]\n")
        
        findings_table = Table(show_header=True, header_style="bold cyan")
        findings_table.add_column("Severity", style="cyan")
        findings_table.add_column("Title")
        findings_table.add_column("File")
        findings_table.add_column("Line")
        
        for finding in findings[:20]:  # Show first 20
            severity = finding.get('severity', 'medium')
            severity_colors = {
                'critical': '[red]CRITICAL[/red]',
                'high': '[orange3]HIGH[/orange3]',
                'medium': '[yellow]MEDIUM[/yellow]',
                'low': '[blue]LOW[/blue]'
            }
            
            findings_table.add_row(
                severity_colors.get(severity, severity.upper()),
                finding.get('title', 'Unknown'),
                Path(finding.get('file', '')).name,
                str(finding.get('line', 'N/A'))
            )
        
        console.print(findings_table)
        
        if len(findings) > 20:
            console.print(f"\n[yellow]... and {len(findings) - 20} more findings[/yellow]")
    else:
        console.print("\n[bold green]✓ No vulnerabilities found![/bold green]")


def generate_reports(result: Dict, output: str, format: str):
    """Generate output reports"""
    report_gen = ReportGenerator()
    output_path = Path(output)
    
    if format == "json":
        report_gen.generate_json_report(result, output_path)
    elif format == "markdown":
        report_gen.generate_markdown_report(result, output_path)
    elif format == "html":
        report_gen.generate_html_report(result, output_path)
    
    # Generate CVE reports for critical/high findings
    cve_formatter = CVEFormatter()
    cve_output = output_path.parent / f"{output_path.stem}_cve.md"
    cve_formatter.generate_bulk_cve_report(
        result.get('findings', []),
        result.get('plugin_info', {}),
        str(cve_output)
    )


@app.command()
def server(
    config: str = typer.Option("server_config.json", "--config", "-c", help="Server configuration file")
):
    """Start server mode for automated scanning"""
    
    print_banner()
    
    from .server.server_mode import ServerMode
    
    console.print("\n[bold cyan]Starting Server Mode...[/bold cyan]\n")
    
    server_mode = ServerMode(config)
    server_mode.start()


@app.command()
def version():
    """Show version information"""
    console.print(f"PluginHunter version {__version__}")
    console.print(f"Author: {__author__}")


if __name__ == "__main__":
    app()


def server_mode_configuration():
    """Server mode configuration wizard"""
    console.print("\n[bold cyan]=== Server Mode Configuration ===[/bold cyan]")
    
    from .server.config_wizard import ServerConfigWizard
    
    wizard = ServerConfigWizard()
    wizard.run()


def start_server_mode():
    """Start server mode with current configuration"""
    console.print("\n[bold cyan]=== Start Server Mode ===[/bold cyan]")
    
    from pathlib import Path
    import os
    
    # Check if config file exists
    config_file = Path("server_config.json")
    
    if not config_file.exists():
        console.print("\n[red]Error: server_config.json not found![/red]")
        console.print("[yellow]Please configure server mode first (Option 7)[/yellow]")
        console.input("\n[dim]Press Enter to continue...[/dim]")
        return
    
    # Display config info
    console.print(f"\n[green]Configuration file:[/green] {config_file}")
    
    try:
        import json
        with open(config_file, 'r') as f:
            config_data = json.load(f)
        
        # Show key settings
        console.print("\n[yellow]Current Configuration:[/yellow]")
        
        if config_data.get('continuous_mode', {}).get('enabled'):
            console.print("  • Mode: [cyan]Continuous Scanning[/cyan]")
            delay = config_data['continuous_mode'].get('delay_between_scans', 10)
            console.print(f"  • Delay: {delay} seconds between scans")
        elif config_data.get('cron_mode', {}).get('enabled'):
            console.print("  • Mode: [cyan]Cron-Based Scheduling[/cyan]")
            schedule = config_data['cron_mode'].get('schedule_type', 'daily')
            console.print(f"  • Schedule: {schedule}")
        else:
            console.print("  • Mode: [yellow]Not configured[/yellow]")
        
        # Notifications
        discord_enabled = config_data.get('notifications', {}).get('discord', {}).get('enabled', False)
        telegram_enabled = config_data.get('notifications', {}).get('telegram', {}).get('enabled', False)
        
        if discord_enabled or telegram_enabled:
            console.print("\n[yellow]Notifications:[/yellow]")
            if discord_enabled:
                console.print("  • Discord: [green]Enabled[/green]")
            if telegram_enabled:
                console.print("  • Telegram: [green]Enabled[/green]")
        
        # Scan settings
        deep_scan = config_data.get('scan_settings', {}).get('deep_scan', False)
        max_plugins = config_data.get('scan_settings', {}).get('max_plugins_per_run', 10)
        console.print(f"\n[yellow]Scan Settings:[/yellow]")
        console.print(f"  • Deep Scan: {'[green]Enabled[/green]' if deep_scan else '[dim]Disabled[/dim]'}")
        console.print(f"  • Max Plugins per Run: {max_plugins}")
        
    except Exception as e:
        console.print(f"\n[red]Error reading configuration: {e}[/red]")
        console.input("\n[dim]Press Enter to continue...[/dim]")
        return
    
    # Confirm start
    console.print("\n[bold yellow]Warning:[/bold yellow] Server mode will run continuously.")
    console.print("[dim]Press Ctrl+C to stop the server.[/dim]")
    
    confirm = console.input("\n[bold cyan]Start server mode? (y/N):[/bold cyan] ").strip().lower()
    
    if confirm != 'y':
        console.print("[yellow]Server mode start cancelled.[/yellow]")
        console.input("\n[dim]Press Enter to continue...[/dim]")
        return
    
    # Start server mode
    console.print("\n[bold green]Starting Server Mode...[/bold green]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")
    
    try:
        from .server.server_mode import ServerMode
        
        server_mode = ServerMode(str(config_file))
        server_mode.start()
        
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Server mode stopped by user.[/yellow]")
        console.input("\n[dim]Press Enter to continue...[/dim]")
    except Exception as e:
        console.print(f"\n[red]Error starting server mode: {e}[/red]")
        console.input("\n[dim]Press Enter to continue...[/dim]")
