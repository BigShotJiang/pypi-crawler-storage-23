"""
Docker container management for dynamic testing (Optional)
"""

from typing import Dict, Any, Optional
from pathlib import Path
from ..utils.logger import setup_logger

logger = setup_logger(__name__)

try:
    import docker
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    logger.debug("Docker module not available - dynamic verification disabled")


class DockerRunner:
    """Manages Docker containers for dynamic testing (Optional)"""
    
    def __init__(self):
        self.client = None
        self.container = None
        
        if not DOCKER_AVAILABLE:
            logger.debug("Docker Python module not installed")
            return
            
        try:
            self.client = docker.from_env()
        except Exception as e:
            logger.debug(f"Docker not available: {e}")
            self.client = None
    
    def is_available(self) -> bool:
        """Check if Docker is available"""
        return self.client is not None
    
    def start_wordpress_container(self, plugin_path: Path) -> Optional[Dict[str, Any]]:
        """Start WordPress container with plugin"""
        if not self.is_available():
            logger.error("Docker is not available")
            return None
        
        try:
            # Pull WordPress image
            logger.info("Pulling WordPress image...")
            self.client.images.pull('wordpress:latest')
            
            # Start container
            logger.info("Starting WordPress container...")
            self.container = self.client.containers.run(
                'wordpress:latest',
                detach=True,
                ports={'80/tcp': 8080},
                environment={
                    'WORDPRESS_DB_HOST': 'db',
                    'WORDPRESS_DB_USER': 'wordpress',
                    'WORDPRESS_DB_PASSWORD': 'wordpress',
                    'WORDPRESS_DB_NAME': 'wordpress'
                },
                volumes={
                    str(plugin_path.absolute()): {
                        'bind': '/var/www/html/wp-content/plugins/test-plugin',
                        'mode': 'ro'
                    }
                }
            )
            
            return {
                'container_id': self.container.id,
                'url': 'http://localhost:8080',
                'status': 'running'
            }
            
        except Exception as e:
            logger.error(f"Failed to start WordPress container: {e}")
            return None
    
    def stop_container(self):
        """Stop and remove container"""
        if self.container:
            try:
                self.container.stop()
                self.container.remove()
                logger.info("Container stopped and removed")
            except Exception as e:
                logger.error(f"Failed to stop container: {e}")
    
    def execute_command(self, command: str) -> Optional[str]:
        """Execute command in container"""
        if not self.container:
            return None
        
        try:
            result = self.container.exec_run(command)
            return result.output.decode('utf-8')
        except Exception as e:
            logger.error(f"Failed to execute command: {e}")
            return None
    
    def get_container_logs(self) -> Optional[str]:
        """Get container logs"""
        if not self.container:
            return None
        
        try:
            return self.container.logs().decode('utf-8')
        except Exception as e:
            logger.error(f"Failed to get logs: {e}")
            return None
    
    def __del__(self):
        """Cleanup on destruction"""
        self.stop_container()