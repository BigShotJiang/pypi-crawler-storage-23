"""
Rule management for PluginHunter
"""

from .loader import RuleLoader

__all__ = ["RuleLoader"]