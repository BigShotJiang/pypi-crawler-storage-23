"""
YAML rule loader for PluginHunter
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from ..utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class VulnerabilityRule:
    """Represents a vulnerability detection rule"""
    id: str
    title: str
    description: str
    severity: str
    cwe: str
    cvss: float
    category: str
    sources: List[str] = field(default_factory=list)
    sinks: List[str] = field(default_factory=list)
    sanitizers: List[str] = field(default_factory=list)
    wordpress_context: Dict[str, Any] = field(default_factory=dict)
    pattern: Optional[str] = None
    regex: Optional[str] = None
    requires_capability_check: bool = False
    requires_nonce_check: bool = False
    dynamic_verification: Dict[str, Any] = field(default_factory=dict)
    file_path: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], file_path: str = None) -> 'VulnerabilityRule':
        """Create rule from dictionary"""
        return cls(
            id=data.get('id', ''),
            title=data.get('title', ''),
            description=data.get('description', ''),
            severity=data.get('severity', 'medium'),
            cwe=data.get('cwe', ''),
            cvss=float(data.get('cvss', 0.0)),
            category=data.get('category', ''),
            sources=data.get('sources', []),
            sinks=data.get('sinks', []),
            sanitizers=data.get('sanitizers', []),
            wordpress_context=data.get('wordpress_context', {}),
            pattern=data.get('pattern'),
            regex=data.get('regex'),
            requires_capability_check=data.get('requires_capability_check', False),
            requires_nonce_check=data.get('requires_nonce_check', False),
            dynamic_verification=data.get('dynamic_verification', {}),
            file_path=file_path
        )


class RuleLoader:
    """Loads and manages vulnerability detection rules"""
    
    def __init__(self):
        self.rules: Dict[str, VulnerabilityRule] = {}
        self.rules_by_category: Dict[str, List[VulnerabilityRule]] = {}
        self.loaded_files: Dict[str, float] = {}  # file_path -> mtime
    
    def load_rules_from_directories(self, directories: List[Path]) -> None:
        """Load rules from multiple directories"""
        for directory in directories:
            if directory.exists():
                self.load_rules_from_directory(directory)
            else:
                logger.warning(f"Rules directory does not exist: {directory}")
    
    def load_rules_from_directory(self, directory: Path) -> None:
        """Load all YAML rules from directory"""
        # Show only the category name, not full path
        category = directory.name if directory.name != 'data' else 'rules'
        logger.info(f"Loading rules: {category}")
        
        yaml_files = list(directory.glob("*.yaml")) + list(directory.glob("*.yml"))
        
        for yaml_file in yaml_files:
            try:
                self.load_rules_from_file(yaml_file)
            except Exception as e:
                logger.error(f"Failed to load rules from {yaml_file}: {e}")
    
    def load_rules_from_file(self, file_path: Path) -> None:
        """Load rules from single YAML file (supports both formats)"""
        try:
            current_mtime = file_path.stat().st_mtime
            file_str = str(file_path)
            
            # Check if file needs reloading
            if file_str in self.loaded_files and self.loaded_files[file_str] >= current_mtime:
                return
            
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if not data:
                logger.warning(f"Empty or invalid YAML file: {file_path}")
                return
            
            # Handle Semgrep-style format (rules: [...])
            if isinstance(data, dict) and 'rules' in data:
                rules_data = data['rules']
            # Handle our custom format (list or single dict)
            elif isinstance(data, list):
                rules_data = data
            else:
                rules_data = [data]
            
            loaded_count = 0
            for rule_data in rules_data:
                if not isinstance(rule_data, dict):
                    continue
                
                try:
                    # Convert Semgrep format to our format if needed
                    rule_data = self._normalize_rule_format(rule_data)
                    
                    rule = VulnerabilityRule.from_dict(rule_data, file_str)
                    
                    if not rule.id:
                        logger.warning(f"Rule missing ID in {file_path}")
                        continue
                    
                    # Store rule
                    self.rules[rule.id] = rule
                    
                    # Index by category
                    if rule.category not in self.rules_by_category:
                        self.rules_by_category[rule.category] = []
                    
                    # Remove old rule from category if exists
                    self.rules_by_category[rule.category] = [
                        r for r in self.rules_by_category[rule.category] 
                        if r.id != rule.id
                    ]
                    self.rules_by_category[rule.category].append(rule)
                    
                    loaded_count += 1
                    
                except Exception as e:
                    logger.error(f"Failed to parse rule in {file_path}: {e}")
            
            self.loaded_files[file_str] = current_mtime
            logger.debug(f"Loaded {loaded_count} rules from {file_path}")
            
        except Exception as e:
            logger.error(f"Failed to load rules file {file_path}: {e}")
    
    def _normalize_rule_format(self, rule_data: Dict[str, Any]) -> Dict[str, Any]:
        """Convert Semgrep-style rules to our format"""
        normalized = {}
        
        # ID
        normalized['id'] = rule_data.get('id', '')
        
        # Title and description
        normalized['title'] = rule_data.get('message', rule_data.get('title', ''))
        normalized['description'] = rule_data.get('message', rule_data.get('description', ''))
        
        # Severity mapping
        severity_map = {
            'ERROR': 'critical',
            'WARNING': 'high',
            'INFO': 'medium'
        }
        semgrep_severity = rule_data.get('severity', 'WARNING')
        normalized['severity'] = severity_map.get(semgrep_severity, rule_data.get('severity', 'medium').lower())
        
        # CWE and CVSS from metadata
        metadata = rule_data.get('metadata', {})
        cwe_list = metadata.get('cwe', [])
        if cwe_list and isinstance(cwe_list, list):
            # Extract CWE number from string like "CWE-79: ..."
            cwe_str = cwe_list[0] if cwe_list else ''
            if 'CWE-' in cwe_str:
                normalized['cwe'] = cwe_str.split(':')[0].strip()
            else:
                normalized['cwe'] = cwe_str
        else:
            normalized['cwe'] = rule_data.get('cwe', '')
        
        # CVSS - calculate from impact/likelihood
        impact = metadata.get('impact', 'MEDIUM')
        likelihood = metadata.get('likelihood', 'MEDIUM')
        cvss_map = {
            ('HIGH', 'HIGH'): 9.0,
            ('HIGH', 'MEDIUM'): 7.5,
            ('MEDIUM', 'HIGH'): 7.5,
            ('MEDIUM', 'MEDIUM'): 6.0,
            ('LOW', 'HIGH'): 5.0,
            ('HIGH', 'LOW'): 5.0,
            ('MEDIUM', 'LOW'): 4.0,
            ('LOW', 'MEDIUM'): 4.0,
            ('LOW', 'LOW'): 2.0
        }
        normalized['cvss'] = cvss_map.get((impact, likelihood), rule_data.get('cvss', 5.0))
        
        # Category - derive from ID or metadata
        rule_id = normalized['id']
        if 'xss' in rule_id.lower():
            category = 'xss'
        elif 'sql' in rule_id.lower():
            category = 'sqli'
        elif 'csrf' in rule_id.lower():
            category = 'csrf'
        elif 'auth' in rule_id.lower() or 'missing-auth' in rule_id.lower():
            category = 'auth'
        elif 'deserialization' in rule_id.lower() or 'object-injection' in rule_id.lower():
            category = 'deserialization'
        elif 'redirect' in rule_id.lower():
            category = 'ssrf'
        elif 'rce' in rule_id.lower() or 'code-execution' in rule_id.lower():
            category = 'rce'
        else:
            category = metadata.get('category', 'misc')
        normalized['category'] = category
        
        # Sources, sinks, sanitizers from Semgrep taint mode
        if rule_data.get('mode') == 'taint':
            # Extract sources
            sources = []
            for source in rule_data.get('pattern-sources', []):
                if isinstance(source, dict) and 'patterns' in source:
                    for pattern in source['patterns']:
                        if isinstance(pattern, dict) and 'pattern' in pattern:
                            sources.append(self._extract_variable_from_pattern(pattern['pattern']))
            normalized['sources'] = sources if sources else ['$_GET', '$_POST', '$_REQUEST']
            
            # Extract sinks
            sinks = []
            for sink in rule_data.get('pattern-sinks', []):
                if isinstance(sink, dict) and 'pattern' in sink:
                    sinks.append(self._extract_function_from_pattern(sink['pattern']))
            normalized['sinks'] = sinks
            
            # Extract sanitizers
            sanitizers = []
            for sanitizer in rule_data.get('pattern-sanitizers', []):
                if isinstance(sanitizer, dict) and 'patterns' in sanitizer:
                    for pattern in sanitizer['patterns']:
                        if isinstance(pattern, dict) and 'metavariable-regex' in pattern:
                            regex_data = pattern['metavariable-regex']
                            if 'regex' in regex_data:
                                # Extract function names from regex
                                regex_str = regex_data['regex']
                                # Remove regex syntax and split
                                funcs = regex_str.strip('()').split('|')
                                sanitizers.extend(funcs)
            normalized['sanitizers'] = sanitizers
        else:
            normalized['sources'] = rule_data.get('sources', [])
            normalized['sinks'] = rule_data.get('sinks', [])
            normalized['sanitizers'] = rule_data.get('sanitizers', [])
        
        # WordPress context
        normalized['wordpress_context'] = rule_data.get('wordpress_context', {})
        
        # Pattern and regex
        normalized['pattern'] = rule_data.get('pattern')
        normalized['regex'] = rule_data.get('regex')
        
        # Capability and nonce checks
        normalized['requires_capability_check'] = rule_data.get('requires_capability_check', False)
        normalized['requires_nonce_check'] = rule_data.get('requires_nonce_check', False)
        
        # Dynamic verification
        normalized['dynamic_verification'] = rule_data.get('dynamic_verification', {})
        
        return normalized
    
    def _extract_variable_from_pattern(self, pattern: str) -> str:
        """Extract variable name from Semgrep pattern"""
        # Pattern like "$_GET[$KEY]" -> "$_GET"
        if '[' in pattern:
            return pattern.split('[')[0]
        return pattern
    
    def _extract_function_from_pattern(self, pattern: str) -> str:
        """Extract function name from Semgrep pattern"""
        # Pattern like "echo (...);" -> "echo"
        if '(' in pattern:
            return pattern.split('(')[0].strip()
        return pattern
    
    def get_rules_by_category(self, category: str) -> List[VulnerabilityRule]:
        """Get all rules for a specific category"""
        return self.rules_by_category.get(category, [])
    
    def get_rule_by_id(self, rule_id: str) -> Optional[VulnerabilityRule]:
        """Get rule by ID"""
        return self.rules.get(rule_id)
    
    def get_all_rules(self) -> List[VulnerabilityRule]:
        """Get all loaded rules"""
        return list(self.rules.values())
    
    def get_categories(self) -> List[str]:
        """Get all available categories"""
        return list(self.rules_by_category.keys())
    
    def reload_rules(self, directories: List[Path]) -> None:
        """Reload all rules from directories"""
        logger.info("Reloading all rules...")
        
        # Clear existing rules
        self.rules.clear()
        self.rules_by_category.clear()
        self.loaded_files.clear()
        
        # Reload from directories
        self.load_rules_from_directories(directories)
        
        logger.info(f"Reloaded {len(self.rules)} rules in {len(self.rules_by_category)} categories")
    
    def hot_reload_changed_files(self, directories: List[Path]) -> bool:
        """Hot reload only changed files"""
        changed = False
        
        for directory in directories:
            if not directory.exists():
                continue
                
            yaml_files = list(directory.glob("*.yaml")) + list(directory.glob("*.yml"))
            
            for yaml_file in yaml_files:
                try:
                    current_mtime = yaml_file.stat().st_mtime
                    file_str = str(yaml_file)
                    
                    if file_str not in self.loaded_files or self.loaded_files[file_str] < current_mtime:
                        logger.info(f"Hot reloading changed file: {yaml_file}")
                        self.load_rules_from_file(yaml_file)
                        changed = True
                        
                except Exception as e:
                    logger.error(f"Failed to hot reload {yaml_file}: {e}")
        
        return changed
    
    def validate_rule(self, rule: VulnerabilityRule) -> List[str]:
        """Validate rule configuration"""
        errors = []
        
        if not rule.id:
            errors.append("Rule ID is required")
        
        if not rule.title:
            errors.append("Rule title is required")
        
        if not rule.category:
            errors.append("Rule category is required")
        
        if rule.severity not in ['critical', 'high', 'medium', 'low']:
            errors.append(f"Invalid severity: {rule.severity}")
        
        if not rule.sources and not rule.pattern and not rule.regex:
            errors.append("Rule must have sources, pattern, or regex")
        
        if rule.sources and not rule.sinks:
            errors.append("Rules with sources must have sinks")
        
        return errors
    
    def get_rule_stats(self) -> Dict[str, Any]:
        """Get statistics about loaded rules"""
        stats = {
            'total_rules': len(self.rules),
            'categories': len(self.rules_by_category),
            'by_category': {},
            'by_severity': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
            'loaded_files': len(self.loaded_files)
        }
        
        for category, rules in self.rules_by_category.items():
            stats['by_category'][category] = len(rules)
        
        for rule in self.rules.values():
            if rule.severity in stats['by_severity']:
                stats['by_severity'][rule.severity] += 1
        
        return stats