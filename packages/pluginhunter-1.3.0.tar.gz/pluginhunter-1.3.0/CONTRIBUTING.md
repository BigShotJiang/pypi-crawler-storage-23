# Contributing to PluginHunter

Thank you for your interest in contributing to PluginHunter!

## How to Contribute

### Reporting Issues

If you find a bug or have a feature request:

1. Check if the issue already exists in [GitHub Issues](https://github.com/letchupkt/PluginHunter/issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce (for bugs)
   - Expected vs actual behavior
   - Your environment (OS, Python version)
   - Relevant logs or screenshots

### Suggesting Features

We welcome feature suggestions! Please:

1. Check existing issues and discussions
2. Create a new issue with the `enhancement` label
3. Describe the feature and its use case
4. Explain why it would be valuable

### Contributing Code

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**
4. **Test thoroughly**
5. **Commit with clear messages**
   ```bash
   git commit -m "Add: feature description"
   ```
6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```
7. **Create a Pull Request**

### Adding Detection Rules

To add new vulnerability detection rules:

1. Create a YAML file in the appropriate category
2. Follow the existing rule format
3. Test the rule thoroughly
4. Submit a PR with example vulnerable code

Example rule structure:
```yaml
id: vuln-xxx
title: Vulnerability Title
description: Detailed description
severity: critical
cwe: CWE-XXX
cvss: 9.8
category: sqli
sources:
  - $_GET
  - $_POST
sinks:
  - dangerous_function
sanitizers:
  - safe_function
wordpress_context:
  requires_capability: true
  requires_nonce: true
```

### Code Style

- Follow PEP 8 guidelines
- Use type hints
- Add docstrings to functions and classes
- Keep functions focused and modular
- Write clear, self-documenting code

### Testing

Before submitting:

1. Test your changes locally
2. Ensure no regressions
3. Add test cases if applicable
4. Verify all existing tests pass

### Documentation

- Update README.md if needed
- Add comments for complex logic
- Update SERVER_MODE.md for server features
- Include examples in your PR description

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow
- Maintain a positive community

## Questions?

Feel free to:
- Open a discussion on GitHub
- Email: letchupkt.dev@gmail.com
- Create an issue with the `question` label

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for contributing to PluginHunter!**

Author: LAKSHMIKANTHAN K (letchupkt)
