# Frequently Asked Questions (FAQ)

## General Questions

### What is PluginHunter?

PluginHunter is an advanced security scanner specifically designed for WordPress plugins. It uses static analysis, taint tracking, and WordPress-specific intelligence to identify vulnerabilities with high accuracy.

### Who should use PluginHunter?

- Security researchers
- Plugin developers
- Security auditors
- Bug bounty hunters
- WordPress site administrators
- DevOps teams

### Is PluginHunter free?

Yes, PluginHunter is open-source and free to use under the MIT License.

---

## Installation & Setup

### How do I install PluginHunter?

Simply run:
```bash
pip install PluginHunter
```

### What are the system requirements?

- Python 3.8 or higher
- Linux (recommended) or Windows with WSL
- Docker (optional, only for dynamic verification)

### Do I need Docker?

No, Docker is optional. It's only required if you want to use the dynamic verification feature. All other features work without Docker.

### Can I use it on Windows?

Yes, but we recommend using WSL (Windows Subsystem for Linux) for the best experience.

---

## Usage Questions

### How do I scan a plugin?

**Interactive mode:**
```bash
PluginHunter
# Select option 1 and enter plugin slug
```

**Command line:**
```bash
PluginHunter scan --source slug --target plugin-name
```

### Where are the reports saved?

Reports are automatically saved in your current directory with names like:
- `scan_<plugin>_<timestamp>.json`
- `scan_<plugin>_<timestamp>.html`
- `scan_<plugin>_<timestamp>_cve.md`

### What output formats are supported?

- JSON - Structured data format
- HTML - Beautiful, readable reports
- Markdown - CVE-ready format for critical/high findings

### Can I scan local plugins?

Yes:
```bash
PluginHunter scan --source local --target /path/to/plugin
```

### Can I scan GitHub repositories?

Yes:
```bash
PluginHunter scan --source github --target username/repository
```

---

## Server Mode Questions

### What is Server Mode?

Server Mode enables automated, continuous scanning with notifications. Perfect for VPS deployment and continuous monitoring.

### How do I set up Server Mode?

```bash
PluginHunter
# Select option 7: Server Mode Configuration
# Follow the interactive wizard
```

### Can I get notifications?

Yes, PluginHunter supports:
- Discord webhooks
- Telegram bots

### How do I start Server Mode?

**From the menu:**
```bash
PluginHunter
# Select option 8: Start Server Mode
```

**From command line:**
```bash
PluginHunter server --config server_config.json
```

### What's the difference between continuous and cron mode?

- **Continuous mode**: Scans endlessly without stopping
- **Cron mode**: Scans at scheduled times (daily, weekly, etc.)

### How do I run Server Mode in the background?

```bash
nohup PluginHunter server --config server_config.json > server.log 2>&1 &
```

Or use screen/tmux for persistent sessions.

---

## Detection Questions

### What vulnerabilities can it detect?

- SQL Injection (SQLi)
- Cross-Site Scripting (XSS)
- Remote Code Execution (RCE)
- CSRF
- Authentication bypass
- SSRF
- Insecure file uploads
- Insecure deserialization
- Privilege escalation
- IDOR
- LFI/RFI

### How accurate is the detection?

PluginHunter is designed for low false positives through:
- Context-aware analysis
- WordPress-specific intelligence
- Recognition of sanitization functions
- Proper taint tracking

### Can I add custom detection rules?

Yes! Create YAML files in:
- `~/.PluginHunter/rules/` (user-level)
- `.PluginHunter/rules/` (project-level)

### What is taint tracking?

Taint tracking follows data from user input (sources) to dangerous functions (sinks), checking if proper sanitization occurs along the way.

---

## Troubleshooting

### Command not found after installation

Try:
```bash
pip install --upgrade PluginHunter
# Or
pip install --user PluginHunter
```

Then restart your terminal.

### Missing dependencies error

```bash
pip install --upgrade --force-reinstall PluginHunter
```

### Scan is very slow

- Use `--deep` only when needed
- Disable dynamic verification if not required
- Check system resources (CPU, memory)

### No vulnerabilities found

This could mean:
- The plugin is secure (good!)
- The plugin uses patterns not yet covered by rules
- False negatives (rare but possible)

### Discord/Telegram notifications not working

1. Verify webhook URL / bot token
2. Test manually with curl
3. Check network connectivity
4. Review server logs

---

## Advanced Questions

### Can I integrate it into CI/CD?

Yes:
```bash
PluginHunter scan --source local --target $PLUGIN_PATH --output report.json
if [ $? -ne 0 ]; then
  echo "Security issues found!"
  exit 1
fi
```

### Can I scan multiple plugins at once?

In Server Mode, yes. Configure a list of plugins and enable continuous scanning.

### How do I update PluginHunter?

```bash
pip install --upgrade PluginHunter
```

### Can I contribute detection rules?

Yes! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Is there an API?

Not yet, but it's planned for future releases.

### Can I use it for commercial purposes?

Yes, the MIT License allows commercial use.

---

## Security & Legal

### Is it legal to scan plugins?

Yes, for:
- Your own plugins
- Plugins you have permission to test
- Public plugins for security research (responsible disclosure)

Always obtain proper authorization before scanning.

### How should I report vulnerabilities I find?

1. Contact the plugin author privately
2. Give them time to fix (typically 90 days)
3. Follow responsible disclosure practices
4. Use the CVE report format generated by PluginHunter

### Does PluginHunter exploit vulnerabilities?

No, it only detects them. The optional dynamic verification feature tests for vulnerabilities but doesn't exploit them maliciously.

### Can I scan WordPress core?

PluginHunter is designed for plugins, but you can scan any PHP code. Results may vary for WordPress core.

---

## Support

### Where can I get help?

- GitHub Issues: https://github.com/letchupkt/PluginHunter/issues
- Email: letchupkt.dev@gmail.com
- Documentation: README.md, SERVER_MODE.md

### How do I report a bug?

Create an issue on GitHub with:
- Clear description
- Steps to reproduce
- Expected vs actual behavior
- Your environment details
- Relevant logs

### Can I request features?

Yes! Create an issue with the `enhancement` label on GitHub.

### Is there a community?

Check the GitHub repository for discussions and issues.

---

## Miscellaneous

### Why "VulnHunter"?

It hunts for vulnerabilities in WordPress plugins!

### Who created PluginHunter?

LAKSHMIKANTHAN K (letchupkt)

### What's the license?

MIT License - free and open-source.

### Can I modify the code?

Yes, under the MIT License you can modify and distribute it.

### How often is it updated?

Check the [CHANGELOG.md](CHANGELOG.md) for version history and updates.

---

**Still have questions?**

Open an issue on GitHub or email letchupkt.dev@gmail.com

---

**Author:** LAKSHMIKANTHAN K (letchupkt)  
**License:** MIT
