# Changelog

All notable changes to PluginHunter will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2026-02-28

### Added
- **48 Comprehensive Detection Rules** covering basic to advanced vulnerabilities
- Complete Semgrep-style pattern matching engine
- Taint analysis with source-sink-sanitizer tracking
- **Advanced Vulnerability Detection**:
  - Second-order SQL injection
  - Type juggling/loose comparison attacks
  - Timing attack vulnerabilities
  - JWT security flaws (none algorithm)
  - Insecure randomness in tokens
  - Race conditions (TOCTOU)
  - Array/prototype pollution
  - Server-side template injection (SSTI)
  - Cache poisoning
  - HTTP request smuggling
  - DOM clobbering
  - Business logic flaws (price manipulation)
  - OAuth vulnerabilities
  - CORS misconfiguration
  - GraphQL injection
  - NoSQL/MongoDB injection
  - Email header injection
  - Zip slip vulnerabilities
  - ReDoS (Regular Expression DoS)
- **Modern Attack Detection**:
  - IDOR with missing authorization
  - Privilege escalation
  - Missing nonce/CSRF protection
  - Information disclosure
  - Mass assignment
  - Open redirect
  - Session fixation
- Pattern matcher supports metavariables, pattern lists, and regex validation
- Sanitizer checking with AST tree walking
- Total of 48 detection rules across 15 categories
- Complete OWASP Top 10 2021 coverage
- 40+ CWE category coverage

### Fixed
- Rule detection now properly converts VulnerabilityRule dataclass to dict
- Added missing CVEFormatter import in scanner
- Improved error handling in rule processing
- Fixed YAML syntax errors in CORS and open redirect rules
- Fixed PHP parser compatibility with tree-sitter-php versions

### Changed
- Enhanced taint tracking for better vulnerability detection
- Improved pattern matching accuracy
- Simplified logging output (category names only)
- Version bumped to 1.3.0

### Known Issues
- Some false positives in sanitizer detection (will be fixed in v1.3.1)
- Duplicate findings may occur (will be deduplicated in v1.3.1)
- Limited variable assignment tracking (will be enhanced in v1.3.1)

## [1.2.1] - 2024-02-27

### Added
- Initial public release
- AST-based PHP analysis using tree-sitter
- Advanced taint tracking with data flow analysis
- WordPress-specific security intelligence
- YAML-based rule engine with 13+ detection rules
- Interactive menu interface with 10 options
- Command-line argument support
- Multiple output formats (JSON, HTML, CVE-ready Markdown)
- Auto-report generation with timestamps
- Server mode for continuous scanning
- Server mode start from interactive menu (Option 8)
- Discord webhook notifications
- Telegram bot notifications
- WordPress.org API integration
- Cron-based scheduling
- Continuous endless scanning mode
- Interactive configuration wizard
- Organized report directories (per plugin)
- Temp directory with auto-cleanup
- Professional POC reports

### Vulnerability Detection
- SQL Injection (SQLi)
- Cross-Site Scripting (XSS)
- Remote Code Execution (RCE)
- Cross-Site Request Forgery (CSRF)
- Authentication/Authorization bypass
- Server-Side Request Forgery (SSRF)
- Insecure File Upload
- Insecure Deserialization
- Privilege Escalation
- Insecure Direct Object Reference (IDOR)
- Local/Remote File Inclusion (LFI/RFI)

### Features
- Scan WordPress.org plugins by slug
- Scan local plugin directories
- Scan ZIP files
- Scan GitHub repositories
- Deep scanning mode
- Dynamic verification (optional, requires Docker)
- Custom rules support
- Scan history viewing
- Configuration management
- Dependency checking
- Low false positive rate

### Documentation
- Comprehensive README
- Server mode documentation
- Contributing guidelines
- MIT License

---

## [Unreleased]

### Planned Features
- AI-powered vulnerability analysis
- Machine learning for false positive reduction
- Additional vulnerability patterns
- Enhanced reporting formats
- API for integration
- Web dashboard
- Multi-language support
- Performance optimizations

---

## Version History

- **1.2.1** - Initial public release (2024-02-27)

---

**Author:** LAKSHMIKANTHAN K (letchupkt)  
**License:** MIT
