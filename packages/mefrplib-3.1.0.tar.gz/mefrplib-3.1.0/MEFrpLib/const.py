BASE_URL = "https://api.mefrp.com/api"
VERSION = "0.1.0"
DEFAULT_USER_AGENT = f"MEFrp-Python-SDK/{VERSION}"
