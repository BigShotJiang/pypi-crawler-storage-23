# Corporate finance\n\nCorporate finance is an area of finance that deals with the sources of funding, and the capital structure of businesses, the actions that managers take to increase the value of the firm to the shareholders, and the tools and analysis used to allocate financial resources. The primary goal of corporate finance is to maximize or increase shareholder value.
Correspondingly, corporate finance comprises two main sub-disciplines. Capital budgeting is concerned with the setting of criteria about which value-adding projects should receive investment funding, and whether to finance that investment with equity or debt capital. Working capital management is the management of the company's monetary funds that deal with the short-term operating balance of current assets and current liabilities; the focus here is on managing cash, inventories, and short-term borrowing and lending (such as the terms on credit extended to customers).
The terms corporate finance and corporate financier are also associated with investment banking. The typical role of an investment bank is to evaluate the company's financial needs and raise the appropriate type of capital that best fits those needs. Thus, the terms "corporate finance" and "corporate financier" may be associated with transactions in which capital is raised in order to create, develop, grow or acquire businesses.
Although it is in principle different from managerial finance which studies the financial management of all firms, rather than corporations alone, the main concepts in the study of corporate finance are applicable to the financial problems of all kinds of firms. Financial management overlaps with the financial function of the accounting profession. However, financial accounting is the reporting of historical financial information, while financial management is concerned with the deployment of capital resources to increase a firm's value to the shareholders.


## \1

Corporate finance for the pre-industrial world began to emerge in the Italian city-states and the low countries of Europe from the 15th century.
The Dutch East India Company (also known by the abbreviation "VOC" in Dutch) was the first publicly listed company ever to pay regular dividends. 
The VOC was also the first recorded joint-stock company to get a fixed capital stock. Public markets for investment securities developed in the Dutch Republic during the 17th century.
By the early 1800s, London acted as a center of corporate finance for companies around the world, which innovated new forms of lending and investment; see City of London § Economy. 
The twentieth century brought the rise of managerial capitalism and common stock finance, with share capital raised through listings, in preference to other sources of capital.
Modern corporate finance, alongside investment management, developed in the second half of the 20th century, particularly driven by innovations in theory and practice in the United States and Britain.
Here, see the later sections of History of banking in the United States and of History of private equity and venture capital.


## \1

The primary goal of Corporate Finance  
is to maximize or to continually increase shareholder value (see Fisher separation theorem).

Here, the three main questions that financial managers addresses are: what long-term investments should we make? What methods should we employ to finance the investment? How do we manage our day-to-day financial activities? These three questions lead to the primary areas of concern in corporate finance: capital budgeting, capital structure, and working capital management.
This then requires that managers find an appropriate balance between: investments in "projects" that increase the firm's long term profitability; and paying excess cash in the form of dividends to shareholders; short term considerations, such as paying back creditor-related debt, will also feature.
Choosing between investment projects will thus be based upon several inter-related criteria.
(1) Corporate management seeks to maximize the value of the firm by investing in projects which yield a positive net present value when valued using an appropriate discount rate - "hurdle rate" - in consideration of risk. (2) These projects must also be financed appropriately. (3) If no growth is possible by the company and excess cash surplus is not needed to the firm, then financial theory suggests that management should return some or all of the excess cash to shareholders (i.e., distribution via dividends).
The first two criteria concern "capital budgeting", the planning of value-adding, long-term corporate financial projects relating to investments funded through and affecting the firm's capital structure, and where management must allocate the firm's limited resources between competing opportunities ("projects").

Capital budgeting is thus also concerned with the setting of criteria about which projects should receive investment funding to increase the value of the firm, and whether to finance that investment with equity or debt capital. Investments should be made on the basis of value-added to the future of the corporation. Projects that increase a firm's value may include a wide variety of different types of investments, including but not limited to, expansion policies, or mergers and acquisitions.
The third criterion relates to dividend policy.
In general, managers of growth companies (i.e. firms that earn high rates of return on invested capital) will use most of the firm's capital resources and surplus cash on investments and projects so the company can continue to expand its business operations into the future. When companies reach maturity levels within their industry (i.e. companies that earn approximately average or lower returns on invested capital), managers of these companies will use surplus cash to payout dividends to shareholders. 
Thus, when no growth or expansion is likely, and excess cash surplus exists and is not needed, then management is expected to pay out some or all of those surplus earnings in the form of cash dividends or to repurchase the company's stock through a share buyback program.


## \1

Achieving the goals of corporate finance requires that any corporate investment be financed appropriately. The sources of financing are, generically, capital self-generated by the firm and capital from external funders, obtained by issuing new debt and equity (and hybrid- or convertible securities). However, as above, since both hurdle rate and cash flows (and hence the riskiness of the firm) will be affected,  the financing mix will impact the valuation of the firm, and a considered decision 

is required here. 
See Balance sheet, WACC.
Finally, there is much theoretical discussion as to other considerations that management might weigh.


### \1

Corporations, as outlined, may rely on borrowed funds (debt capital or credit) as sources of investment to sustain ongoing business operations or to fund future growth.  Debt comes in several forms, such as through bank loans, notes payable, or bonds issued to the public. Bonds require the corporation to make regular interest payments (interest expenses) on the borrowed capital until the debt reaches its maturity date, therein the firm must pay back the obligation in full. (An exception is zero-coupon bonds - or "zeros"). Debt payments can also be made in the form of a sinking fund provision, whereby the corporation pays annual installments of the borrowed debt above regular interest charges.  Corporations that issue callable bonds are entitled to pay back the obligation in full whenever the company feels it is in their best interest to pay off the debt payments.  If interest expenses cannot be made by the corporation through cash payments, the firm may also use collateral assets as a form of repaying their debt obligations (or through the process of liquidation).
Especially re debt funded corporations, see Bankruptcy and Financial distress.
Under some treatments (especially for valuation) leases are regarded as debt: the payments are set; they are tax deductible; failing to make them results in the loss of the asset.
Corporations can alternatively sell shares of the company to investors to raise capital.  Investors, or shareholders, expect that there will be an upward trend in value of the company (shares appreciate in value) over time to make their investment a profitable purchase.  As outlined:
Shareholder value is increased when corporations invest equity capital and other funds into projects (or investments) that earn a positive rate of return for the owners.  Investors then prefer to buy shares of stock in companies that will consistently earn a positive rate of return on capital (on equity) in the future, thus increasing the market value of the stock of that corporation.  
Shareholder value may also be increased when corporations payout excess cash surplus (funds that are not needed for business) in the form of dividends.
Internal financing, often, is constituted of retained earnings, i.e. those remaining after dividends; this provides, per some measures, the cheapest form of funding.
Preferred stock is a specialized form of financing which combines properties of common stock and debt instruments, and may then be considered a hybrid security. 
Preferreds are senior (i.e. higher ranking) to common stock, but subordinate to bonds in terms of claim (or rights to their share of the assets of the company).
Preferred stock is usually Nonvoting, i.e. carries no voting rights, but may carry a dividend and may have priority over common stock in the payment of dividends and upon liquidation. 
Similar to bonds, preferred stocks are rated by the major credit-rating companies. The rating for preferreds is generally lower, since preferred dividends do not carry the same guarantees as interest payments from bonds and they are junior to all creditors.
Other features may include Convertibility to common stock and Callability at the option of the corporation.
Terms of the preferred stock are stated in a "Certificate of Designation".


### \1

As outlined, the financing "mix" will impact the valuation (as well as the cashflows) of the firm, and must therefore be structured appropriately: 
there are then two interrelated considerations  here:

Management must identify the "optimal mix" of financing – the capital structure that results in maximum firm value  - but must also take other factors into account (see trade-off theory below). Financing a project through debt results in a liability or obligation that must be serviced, thus entailing cash flow implications independent of the project's degree of success. Equity financing is less risky with respect to cash flow commitments, but results in a dilution of share ownership, control and earnings. The cost of equity (see CAPM and APT) is also typically higher than the cost of debt - which is, additionally, a deductible expense – and so equity financing may result in an increased hurdle rate which may offset any reduction in cash flow risk.
Management must attempt to match the long-term financing mix to the assets being financed as closely as possible, in terms of both timing and cash flows. Managing any potential asset liability mismatch or duration gap entails matching the assets and liabilities respectively according to maturity pattern ("cashflow matching") or duration ("immunization"); managing this relationship in the short-term is a major function of working capital management, as discussed below. Other techniques, such as securitization, or hedging using interest rate- or credit derivatives, are also common. See: Asset liability management; Treasury management; Credit risk; Interest rate risk.


### \1

The above, are the primary objectives in deciding on the firm's capitalization structure. Parallel considerations, also, will factor into management's thinking.
The starting point for discussion here is the Modigliani–Miller theorem.
This states, through two connected Propositions, that in a "perfect market" how a firm is financed is irrelevant to its value:
(i) the value of a company is independent of its capital structure; (ii) the cost of equity will be the same for a leveraged firm and an unleveraged firm.
"Modigliani and Miller", however, is generally viewed as a theoretical result, and in practice, management will here too focus on enhacing firm value and / or reducing the cost of funding.
Re value, much of the discussion falls under the umbrella of the Trade-Off Theory in which firms are assumed to trade-off the tax benefits of debt with the bankruptcy costs of debt when choosing how to allocate the company's resources, finding an optimum re firm value. 
The capital structure substitution theory hypothesizes that management manipulates the capital structure such that earnings per share (EPS) are maximized.
Re cost of funds, the Pecking Order Theory (Stewart Myers) suggests that firms avoid external financing while they have internal financing available and avoid new equity financing while they can engage in new debt financing at reasonably low interest rates.
One of the more recent innovations in this area from a theoretical point of view is the market timing hypothesis. This hypothesis, inspired by the behavioral finance literature, states that firms look for the cheaper type of financing regardless of their current levels of internal resources, debt and equity.
(See also below re corporate governance.)


## \1

The process of allocating financial resources to major investment- or capital expenditure is known as capital budgeting.  

Consistent with the overall goal of increasing firm value, the decisioning here focuses on whether the investment in question is worthy of funding through the firm's capitalization structures (debt, equity or retained earnings as above). 
To be considered acceptable, the investment must be value additive re: (i) improved operating profit and cash flows; as combined with (ii) any new funding commitments and capital implications.
Re the latter: if the investment is large in the context of the firm as a whole, so the discount rate applied by outside investors to the (private) firm's equity may be adjusted upwards to reflect the new level of risk, thus impacting future financing activities and overall valuation.
More sophisticated treatments will thus produce accompanying sensitivity- and risk metrics, and will incorporate any inherent contingencies.
The focus of capital budgeting is on major "projects" - often investments in other firms, or expansion into new markets or geographies - but may extend also to new plants, new / replacement machinery, new products, and research and development programs;
day to day operational expenditure is the realm of financial management as below.


### \1

In general, each "project's" value will be estimated using a discounted cash flow (DCF) valuation, and the opportunity with the highest value, as measured by the resultant net present value (NPV) will be selected (first applied in a corporate finance setting by Joel Dean in 1951). This requires estimating the size and timing of all of the incremental cash flows resulting from the project. Such future cash flows are then discounted to determine their present value (see Time value of money). These present values are then summed, and this sum net of the initial investment outlay is the NPV. See Financial modeling § Accounting for general discussion, and Valuation using discounted cash flows for the mechanics, with discussion re modifications for corporate finance.
The NPV is greatly affected by the discount rate. Thus, identifying the proper discount rate – often termed, the project "hurdle rate" – is critical to choosing appropriate projects and investments for the firm. The hurdle rate is the minimum acceptable return on an investment – i.e., the project appropriate discount rate. The hurdle rate should reflect the riskiness of the investment, typically measured by volatility of cash flows, and must take into account the project-relevant financing mix. Managers use models such as the CAPM or the APT to estimate a discount rate appropriate for a particular project, and use the weighted average cost of capital (WACC) to reflect the financing mix selected. (A common error in choosing a discount rate for a project is to apply a WACC that applies to the entire firm. Such an approach may not be appropriate where the risk of a particular project differs markedly from that of the firm's existing portfolio of assets.)
In conjunction with NPV, there are several other measures used as (secondary) selection criteria in corporate finance; see Capital budgeting § Ranked projects. These are visible from the DCF and include discounted payback period, IRR, Modified IRR, equivalent annuity, capital efficiency, and ROI.
Alternatives (complements) to the standard DCF, model economic profit as opposed to free cash flow; these include residual income valuation, MVA / EVA (Joel Stern, Stern Stewart & Co) and APV (Stewart Myers).  With the cost of capital correctly and correspondingly adjusted, these valuations should yield the same result as the DCF. These may, however, be considered more appropriate for projects with negative free cash flow several years out, but which are expected to generate positive cash flow thereafter (and may also be less sensitive to terminal value).


### \1

Given the uncertainty inherent in project forecasting and valuation,

analysts will wish to assess the sensitivity of project NPV to the various inputs (i.e. assumptions) to the DCF model. In a typical sensitivity analysis the analyst will vary one key factor while holding all other inputs constant, ceteris paribus. The sensitivity of NPV to a change in that factor is then observed, and is calculated as a "slope": ΔNPV / Δfactor. For example, the analyst will determine NPV at various growth rates in annual revenue as specified (usually at set increments, e.g. -10%, -5%, 0%, 5%...), and then determine the sensitivity using this formula. Often, several variables may be of interest, and their various combinations produce a "value-surface" (or even a "value-space"), where NPV is then a function of several variables. See also Stress testing.
Using a related technique, analysts also run scenario based forecasts of NPV. Here, a scenario comprises a particular outcome for economy-wide, "global" factors (demand for the product, exchange rates, commodity prices, etc.) as well as for company-specific factors (unit costs, etc.). As an example, the analyst may specify various revenue growth scenarios (e.g. -5% for "Worst Case", +5% for "Likely Case" and +15% for "Best Case"), where all key inputs are adjusted so as to be consistent with the growth assumptions, and calculate the NPV for each. Note that for scenario based analysis, the various combinations of inputs must be internally consistent (see discussion at Financial modeling), whereas for the sensitivity approach these need not be so.  An application of this methodology is to determine an "unbiased" NPV, where management determines a (subjective) probability for each scenario – the NPV for the project is then the probability-weighted average of the various scenarios; see First Chicago Method. (See also rNPV, where cash flows, as opposed to scenarios, are probability-weighted.)


### \1

A further advancement which "overcomes the limitations of sensitivity and scenario analyses by examining the effects of all possible combinations of variables and their realizations" is to construct stochastic or probabilistic financial models – as opposed to the traditional static and deterministic models as above. For this purpose, the most common method is to use Monte Carlo simulation to analyze the project's NPV. This method was introduced to finance by David B. Hertz in 1964, although it has only recently become common: today analysts are even able to run simulations in spreadsheet based DCF models, typically using a risk-analysis add-in, such as @Risk or Crystal Ball. Here, the cash flow components that are (heavily) impacted by uncertainty are simulated, mathematically reflecting their "random characteristics". In contrast to the scenario approach above, the simulation produces several thousand random but possible outcomes, or trials, "covering all conceivable real world contingencies in proportion to their likelihood;" see Monte Carlo Simulation versus "What If" Scenarios. The output is then a histogram of project NPV, and the average NPV of the potential investment – as well as its volatility and other sensitivities – is then observed. This histogram provides information not visible from the static DCF: for example, it allows for an estimate of the probability that a project has a net present value greater than zero (or any other value).
Continuing the above example: instead of assigning three discrete values to revenue growth, and to the other relevant variables, the analyst would assign an appropriate probability distribution to each variable (commonly triangular or beta), and, where possible, specify the observed or supposed correlation between the variables. These distributions would then be "sampled" repeatedly – incorporating this correlation – so as to generate several thousand random but possible scenarios, with corresponding valuations, which are then used to generate the NPV histogram. The resultant statistics (average NPV and standard deviation of NPV) will be a more accurate mirror of the project's "randomness" than the variance observed under the scenario based approach. (These are often used as estimates of the underlying "spot price" and volatility for the real option valuation below; see Real options valuation § Valuation inputs.) A more robust Monte Carlo model would include the possible occurrence of risk events - e.g., a credit crunch - that drive variations in one or more of the DCF model inputs.


### \1

Often - for example R&D projects - a project may open (or close) various paths of action to the company, but this reality will not (typically) be captured in a strict NPV approach. Some analysts account for this uncertainty by  adjusting the discount rate (e.g. by increasing the cost of capital) or the cash flows (using certainty equivalents, or applying (subjective) "haircuts" to the forecast numbers; see Penalized present value). Even when employed, however, these latter methods do not normally properly account for changes in risk over the project's lifecycle and hence fail to appropriately adapt the risk adjustment.  Management will therefore (sometimes) employ tools which place an explicit value on these options. So, whereas in a DCF valuation the most likely or average or scenario specific cash flows are discounted, here the "flexible and staged nature" of the investment is modelled, and hence "all" potential payoffs are considered. See further under Real options valuation. The difference between the two valuations is the "value of flexibility" inherent in the project.
The two most common tools are Decision Tree Analysis (DTA) 

and real options valuation (ROV); they may often be used interchangeably:

DTA values flexibility by incorporating possible events (or states) and consequent management decisions. (For example, a company would build a factory given that demand for its product exceeded a certain level during the pilot-phase, and outsource production otherwise. In turn, given further demand, it would similarly expand the factory, and maintain it otherwise. In a DCF model, by contrast, there is no "branching" – each scenario must be modelled separately.) In the decision tree, each management decision in response to an "event" generates a "branch" or "path" which the company could follow; the probabilities of each event are determined or specified by management. Once the tree is constructed: (1) "all" possible events and their resultant paths are visible to management; (2) given this "knowledge" of the events that could follow — and applying the above value-maximization criterion — management chooses the branches (i.e. actions) corresponding to the highest value path probability weighted; (3) this path is then taken as representative of project value.
ROV is usually used when the value of a project is contingent on the value of some other asset or underlying variable. (For example, the viability of a mining project is contingent on the price of gold; if the price is too low, management will abandon the mining rights, if sufficiently high, management will develop the ore body. Again, a DCF valuation would capture only one of these outcomes.) Here: (1) using financial option theory as a framework, the decision to be taken is identified as corresponding to either a call option or a put option; (2) an appropriate valuation technique is then employed – usually a variant on the binomial options model or a bespoke simulation model, while Black–Scholes type formulae are used less often; see Contingent claim valuation. (3) The "true" value of the project is then the NPV of the "most likely" scenario plus the option value. (Real options in corporate finance were first discussed by Stewart Myers in 1977; viewing corporate strategy as a series of options was originally per Timothy Luehrman, in the late 1990s.)  See also § Option pricing approaches under Business valuation.


## \1

Dividend policy is concerned with financial policies regarding the payment of a cash dividend in the present, or retaining earnings and then paying an increased dividend at a later stage.  
The policy will be set based upon the type of company and what management determines is the best use of those dividend resources for the firm and its shareholders.
Practical and theoretical considerations - interacting with the above funding and investment decisioning, and re overall firm value - will inform this thinking.


### \1
In general, whether  to issue dividends, and what amount, is determined on the basis of the company's unappropriated profit (excess cash) and influenced by the company's long-term earning power.  In all instances, as above, the appropriate dividend policy is in parallel directed by that which maximizes long-term shareholder value.
When cash surplus exists and is not needed by the firm, then management is expected to pay out some or all of those surplus earnings in the form of cash dividends or to repurchase the company's stock through a share buyback program.
Thus, if there are no NPV positive opportunities, i.e. projects where returns exceed the hurdle rate, and excess cash surplus is not needed, then management should return (some or all of) the excess cash to shareholders as dividends.
This is the general case, however the "style" of the stock may also impact the decision. Shareholders of a "growth stock", for example, expect that the company will retain (most of) the excess cash surplus so as to fund future projects internally to help increase the value of the firm.  Shareholders of value- or secondary stocks, on the other hand, would prefer management to pay surplus earnings in the form of cash dividends, especially when a positive return cannot be earned through the reinvestment of undistributed earnings; a share buyback program may be accepted when the value of the stock is greater than the returns to be realized from the reinvestment of undistributed profits.
Management will also choose the form of the dividend distribution, as stated, generally as cash dividends or via a share buyback. Various factors may be taken into consideration: where shareholders must pay tax on dividends, firms may elect to retain earnings or to perform a stock buyback, in both cases increasing the value of shares outstanding. Alternatively, some companies will pay "dividends" from stock rather than in cash or via a share buyback as mentioned; see Corporate action.


### \1

As for capital structure above, there are several schools of thought on dividends, in particular re their impact on firm value. 
A key consideration will be whether there are any tax disadvantages associated with dividends: i.e. dividends attract a higher tax rate as compared, e.g., to capital gains; see dividend tax and Retained earnings  § Tax implications.
Here, per the abovementioned Modigliani–Miller theorem: 
if there are no such disadvantages - and companies can raise equity finance cheaply, i.e. can issue stock at low cost - then dividend policy is value neutral; 
if dividends suffer a tax disadvantage, then increasing dividends should reduce firm value.
Regardless, but particularly in the second (more realistic) case, other considerations apply.
The first set of these, relates to investor preferences and behavior (see Clientele effect).
Investors are seen to prefer a “bird in the hand” - i.e. cash dividends are certain as compared to income from future capital gains - and in fact, commonly employ some form of dividend valuation model in valuing shares.
Relatedly, investors will then prefer a stable or "smooth" dividend payout - as far as is reasonable given earnings prospects and sustainability - which will then positively impact share price; see Lintner model.
Cash dividends may also allow management to convey (insider) information about corporate performance; and increasing a company's dividend payout may then predict (or lead to) favorable performance of the company's stock in the future; see Dividend signaling hypothesis
The second set relates to management's thinking re capital structure and earnings, overlapping the above.
Under a "Residual dividend policy" - i.e. as contrasted with a "smoothed" payout policy - the firm will use retained profits to finance capital investments if cheaper than the same via equity financing; see again Pecking order theory.
Similarly, under the Walter model, dividends are paid only if capital retained will earn a higher return than that available to investors (proxied: ROE > Ke).
Management may also want to "manipulate" the capital structure - in this context, by paying or not paying dividends - such that earnings per share are maximized; see again,  Capital structure substitution theory.


## \1

Managing the corporation's working capital position so as to sustain ongoing business operations is referred to as working capital management. 
This entails, essentially, managing the relationship between a firm's short-term assets and its short-term liabilities, conscious of various considerations. 
Here, as above, the goal of Corporate Finance is the maximization of firm value. In the context of long term, capital budgeting, firm value is enhanced through appropriately selecting and funding NPV positive investments. These investments, in turn, have implications in terms of cash flow and cost of capital.
The goal of Working Capital (i.e. short term) management is therefore to ensure that the firm is able to operate, and that it has sufficient cash flow to service long-term debt, and to satisfy both maturing short-term debt and upcoming operational expenses. In so doing, firm value is enhanced when, and if, the return on capital exceeds the cost of capital; See Economic value added (EVA).  Managing short term finance along with long term finance is therefore one task of a modern CFO.


### \1
Working capital is the amount of funds that are necessary for an organization to continue its ongoing business operations, until the firm is reimbursed through payments for the goods or services it has delivered to its customers.  Working capital is measured through the difference between resources in cash or readily convertible into cash (Current Assets), and cash requirements (Current Liabilities). As a result, capital resource allocations relating to working capital are always current, i.e. short-term.
In addition to time horizon, working capital management differs from capital budgeting in terms of discounting and profitability considerations; decisions here are also "reversible" to a much larger extent. (Considerations as to risk appetite and return targets remain identical, although some constraints – such as those imposed by loan covenants – may be more relevant here).
The (short term) goals of working capital are therefore not approached on the same basis as (long term) profitability, and working capital management applies different criteria in allocating resources: the main considerations are (1) cash flow / liquidity and (2) profitability / return on capital (of which cash flow is probably the most important).

The most widely used measure of cash flow is the net operating cycle, or cash conversion cycle. This represents the time difference between cash payment for raw materials and cash collection for sales. The cash conversion cycle indicates the firm's ability to convert its resources into cash. Because this number effectively corresponds to the time that the firm's cash is tied up in operations and unavailable for other activities, management generally aims at a low net count. (Another measure is gross operating cycle which is the same as net operating cycle except that it does not take into account the creditors deferral period.)
In this context, the most useful measure of profitability is return on capital (ROC). The result is shown as a percentage, determined by dividing relevant income for the 12 months by capital employed; return on equity (ROE) shows this result for the firm's shareholders. As outlined, firm value is enhanced when, and if, the return on capital exceeds the cost of capital.


### \1
Guided by the above criteria, management will use a combination of policies and techniques for the management of working capital. These policies, as outlined, aim at managing the current assets (generally cash and cash equivalents, inventories and debtors) and the short term financing, such that cash flows and returns are acceptable.

Cash management. Identify the cash balance which allows for the business to meet day to day expenses, but reduces cash holding costs.
Inventory management.  Identify the level of inventory which allows for uninterrupted production but reduces the investment in raw materials – and minimizes reordering costs – and hence increases cash flow. See discussion under Inventory optimization and Supply chain management.
Debtors management. There are two inter-related roles here:  (1) Identify the appropriate credit policy, i.e. credit terms which will attract customers, such that any impact on cash flows and the cash conversion cycle will be offset by increased revenue and hence Return on Capital (or vice versa); see Discounts and allowances.  (2) Implement appropriate credit scoring policies and techniques such that the risk of default on any new business is acceptable given these criteria.
Short term financing. Identify the appropriate source of financing, given the cash conversion cycle: the inventory is ideally financed by credit granted by the supplier; however, it may be necessary to utilize a bank loan (or overdraft), or to "convert debtors to cash" through "factoring"; see generally, trade finance.


## \1


### \1

As discussed, corporate finance comprises the activities, analytical methods, and techniques that deal with the company's long-term investments, finances and capital.
Re the latter, when capital must be raised for the corporation or shareholders, the "corporate finance team" will engage  its investment bank. 
The bank will then facilitate the required share listing (IPO or SEO) or bond issuance, as appropriate given the above analysis.
Thereafter the bank will work closely with the corporate re servicing the new securities, and managing its presence in the capital markets more generally
(offering advisory, financial advisory, deal advisory, and / or transaction advisory
 
services).
Use of the term "corporate finance", correspondingly, varies considerably across the world. 
In the United States, "Corporate Finance" corresponds to the first usage.
A professional here may be referred to as a "corporate finance analyst" and will typically be based in the FP&A area, reporting to the CFO. 

 
See Financial analyst § Financial planning and analysis.
In the United Kingdom and Commonwealth countries, on the other hand, "corporate finance" and "corporate financier" are associated with investment banking.


### \1

Financial risk management, generally, is focused on measuring and managing market risk, credit risk and operational risk.
Within corporates   (i.e. as opposed to banks), the scope extends to preserving (and enhancing) the firm's economic value. 
It will then overlap both corporate finance and enterprise risk management: addressing risks to the firm's overall strategic objectives,
by focusing on the financial exposures and opportunities arising from business decisions, and their link to the firm's appetite for risk, as well as their impact on share price.
(In large firms, Risk Management typically exists as an independent function, with the CRO consulted on capital-investment and other strategic decisions.)
Re corporate finance, both operational and funding issues are addressed; respectively:

Businesses actively manage any impact on profitability, cash flow, and hence firm value, due to credit and operational factors - this, overlapping "working capital management" to a large extent.  Firms then devote much time and effort to forecasting, analytics and performance monitoring (the above analyst role). See also "ALM" and treasury management.
Firm exposure to market (and business) risk is a direct result of previous capital investments and funding decisions: where applicable here, typically in large corporates and under guidance from their investment bankers, firms actively manage and hedge  these exposures using traded financial instruments, usually  standard derivatives, creating interest rate-, commodity- and foreign exchange hedges; see Cash flow hedge.


### \1
Broadly, corporate governance considers the mechanisms, processes, practices, and relations by which corporations are controlled and operated by their board of directors, managers, shareholders, and other stakeholders.
In the context of corporate finance, 

a more specific concern will be that executives do not serve their own vested interests to the detriment of capital providers. 

There are several interrelated considerations:

As regards investments: acquisitions and takeovers may be driven by management interests (a larger company; "Empire building") rather than stockholder interests; managers may then overpay on investments, reducing firm value.
Several issues inhere also in the capital structure and management will be expected to balance these: Stockholders, with "potentially unlimited"  upside, have an incentive to take riskier projects than bondholders, who earn a fixed return. Further, total agency costs will differ as a function of capital structure. 
Stockholders will also wish to pay more out in dividends than bondholders would like them to.
In general, here, debt funding may be seen as "an internal means of controlling management", which has to work hard to ensure that repayments are met, 

balancing these interests, and also limiting the possibility of overpaying on investments.
As a further control, large investments will need the approval of the Board-appointed Investment Committee.
Granting Executive stock options, alternatively or in parallel, is seen as a mechanism to align management with stockholder interests. 
A more formal treatment is offered under agency theory, 
where these problems and approaches can be seen, and hence analysed, as real options;

see Principal–agent problem § Options framework for discussion.


## \1


## \1


## \1


## \1
Jonathan Berk; Peter DeMarzo (2013). Corporate Finance (3rd ed.). Pearson. ISBN 978-0132992473.
Peter Bossaerts; Bernt Arne Ødegaard (2006). Lectures on Corporate Finance (Second ed.). World Scientific. ISBN 978-981-256-899-1.
Richard Brealey; Stewart Myers; Franklin Allen (2013). Principles of Corporate Finance. Mcgraw-Hill. ISBN 978-0078034763.
CFA Institute (2022). Corporate Finance: Economic Foundations and Financial Modeling (3rd ed.). Wiley. ISBN 978-1119743767.
Donald H. Chew, ed. (2000). The New Corporate Finance: Where Theory Meets Practice (3rd ed.). Non Basic Stock Line. ISBN 978-0071120432.
Thomas E. Copeland; J. Fred Weston; Kuldeep Shastri (2004). Financial Theory and Corporate Policy (4th ed.). Pearson. ISBN 978-0321127211.
Julie Dahlquist, Rainford Knight, Alan S. Adams (2022). Principles of Finance. OpenStax, Rice University. ISBN 9781951693541.{{cite book}}:  CS1 maint: multiple names: authors list (link)
Aswath Damodaran (2001). Corporate Finance: Theory and Practice (2nd ed.). Wiley. ISBN 978-0471283324.
Aswath Damodaran (2014). Applied Corporate Finance (4th ed.). Wiley. ISBN 978-1118808931.
João Amaro de Matos (2001). Theoretical Foundations of Corporate Finance. Princeton University Press. ISBN 9780691087948.
Michael C. Ehrhardt, Eugene F. Brigham (2024). Corporate Finance: A Focused Approach (8th ed.). Cengage. ISBN 9780357714638.
Frank Fabozzi, Pamela Peterson, and Ralph Polimeni (2008). The Complete CFO Handbook - From Accounting To Accountability. Wiley. ISBN 9780470099261
Tim Koller, Marc Goedhart, David Wessels (McKinsey & Company) (2020). Valuation: Measuring and Managing the Value of Companies (7th ed.). John Wiley & Sons. ISBN 978-1119610885
Joseph Ogden; Frank C. Jen; Philip F. O'Connor (2002). Advanced Corporate Finance. Prentice Hall. ISBN 978-0130915689.
C. Krishnamurti; S. R. Vishwanath (2010). Advanced Corporate Finance. MediaMatics. ISBN 978-8120336117.
Pascal Quiry; Yann Le Fur; Antonio Salvi; Maurizio Dallochio; Pierre Vernimmen (2011). Corporate Finance: Theory and Practice (3rd ed.). Wiley. ISBN 978-1119975588.
Stephen Ross, Randolph Westerfield, Jeffrey Jaffe (2012). Corporate Finance (10th ed.). Mcgraw-Hill. ISBN 978-0078034770.{{cite book}}:  CS1 maint: multiple names: authors list (link)
Joel M. Stern, ed. (2003). The Revolution in Corporate Finance (4th ed.). Wiley-Blackwell. ISBN 9781405107815.
Jean Tirole (2006). The Theory of Corporate Finance. Princeton University Press. ISBN 0691125562.
Ivo Welch (2017). Corporate Finance (4th ed.). ISBN 9780984004928.


## \1
Jensen, Michael C.; Smith. Clifford W. (29 September 2000). The Theory of Corporate Finance: A Historical Overview. SSRN 244161. In The Modern Theory of Corporate Finance, edited by Michael C. Jensen and Clifford H. Smith Jr., pp. 2–20. McGraw-Hill, 1990. ISBN 0070591091
Graham, John R.; Harvey, Campbell R. (1999). "The Theory and Practice of Corporate Finance: Evidence from the Field". AFA 2001 New Orleans; Duke University Working Paper. SSRN 220251.


## \1

Corporate Finance Overview - Corporate Finance Institute
Corporate Finance Glossary - Pierre Vernimmen
Corporate finance resources  - Aswath Damodaran
Financial management resources  - James Van Horne
Financial analysis items - Fincyclopedia\n\n