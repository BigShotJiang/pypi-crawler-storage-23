gui_default_settings["show_bonds"] = True
