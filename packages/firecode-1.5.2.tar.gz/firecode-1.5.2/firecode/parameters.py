# coding=utf-8
"""FIRECODE: Filtering Refiner and Embedder for Conformationally Dense Ensembles
Copyright (C) 2021-2026 Nicolò Tampellini

SPDX-License-Identifier: LGPL-3.0-or-later

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program. If not, see
https://www.gnu.org/licenses/lgpl-3.0.en.html#license-text.

"""

orb_dim_dict = {
    "H Single Bond": 0.85,
    "C Single Bond": 1,
    "O Single Bond": 1,
    "N Single Bond": 1,
    "F Single Bond": 1,
    "Cl Single Bond": 1.5,
    "Br Single Bond": 1.5,
    "I Single Bond": 2,
    "C sp": 1,
    "N sp": 1,
    "B sp2": 0.8,
    "C sp2": 1.1,
    "N sp2": 1,
    "B sp3": 1,
    "C sp3": 1,
    "Br sp3": 1,
    "O Ether": 1,
    "S Ether": 1,
    "O Ketone": 0.85,
    "S Ketone": 1,
    "N Imine": 1,
    "C bent carbene": 1,
    "Metal": 2.5,
    "Fallback": 1,
}
# Half-lenght of the transition state bonding distance involving a given atom
