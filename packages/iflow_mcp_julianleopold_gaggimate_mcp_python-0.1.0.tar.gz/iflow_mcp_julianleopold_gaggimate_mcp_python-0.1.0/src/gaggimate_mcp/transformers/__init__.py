"""Transformers for converting data to AI-friendly formats."""
