#!/usr/bin/env python3
"""Entry point for running the Gaggimate MCP server."""

from gaggimate_mcp.server import mcp

if __name__ == "__main__":
    mcp.run()