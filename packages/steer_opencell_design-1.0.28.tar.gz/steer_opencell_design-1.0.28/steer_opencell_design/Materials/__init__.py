"""Battery material definitions including active materials, binders, conductive additives, electrolytes, and formulations."""
