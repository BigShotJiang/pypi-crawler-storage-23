"""Construction-level assemblies combining components into layups, electrode assemblies, and complete cells."""
