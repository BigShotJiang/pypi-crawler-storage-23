"""Electrode layup configurations defining how cathode, anode, and separator layers are arranged."""
