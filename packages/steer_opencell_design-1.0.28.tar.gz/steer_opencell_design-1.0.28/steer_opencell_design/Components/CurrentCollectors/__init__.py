"""Current collector components for battery electrodes."""
