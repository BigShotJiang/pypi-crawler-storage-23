This directory is usually not imported. It contains periodic table
data used by Psi4 and Cfour so as to run comparisons versus this module
through `PeriodicTable.run_comparison()`.

Also physical constant data from Psi4.
