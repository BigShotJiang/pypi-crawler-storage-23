# Sources

These are automatically generated python scripts. For more information please
consult the GitHub repository at github.com/MolSSI/QCElemental
