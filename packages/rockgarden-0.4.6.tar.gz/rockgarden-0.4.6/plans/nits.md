# Nits

Things to revisit before release.

- **Date field defaults**: Research commonly used frontmatter field names for modified/created dates across Obsidian plugins and other SSGs. Current defaults (`modified`, `updated`, `last_modified` / `created`, `date`, `date_created`) are guesses — validate against real-world usage before shipping.
