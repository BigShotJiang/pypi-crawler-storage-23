"""SAF-T MCP Server -- Parse and analyze Portuguese SAF-T XML files."""

__version__ = "0.1.0"
