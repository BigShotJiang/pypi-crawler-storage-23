"""Allow running the server with: python -m saft_mcp"""

from saft_mcp.server import mcp

mcp.run()
