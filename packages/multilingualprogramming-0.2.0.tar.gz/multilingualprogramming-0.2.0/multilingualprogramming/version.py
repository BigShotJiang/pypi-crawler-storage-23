#
# SPDX-FileCopyrightText: 2022 John Samuel <johnsamuelwrites@gmail.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later
#

"""multilingualprogramming is an application for multilingual programming."""

__version__ = "0.2.0"
