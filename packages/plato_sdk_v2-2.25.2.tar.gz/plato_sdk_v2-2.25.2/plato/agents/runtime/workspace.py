"""Workspace abstractions for sharing files between world and agent VMs."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

from plato.utils.subprocess import run_local, run_ssh

if TYPE_CHECKING:
    from plato.v2.async_.environment import Environment

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Rsync helpers (used by RsyncWorkspace and PlatoVMRuntime for code sync)
# ---------------------------------------------------------------------------


async def rsync_to(
    ssh_key_path: Path,
    local_path: Path,
    remote_path: str,
    hostname: str,
    chown: str | None = None,
    max_retries: int = 3,
    retry_delay: float = 5.0,
) -> None:
    """Rsync a directory to a remote VM."""
    ssh_cmd = f"ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"

    cmd = [
        "rsync",
        "-az",
        "--delete",
        "--rsync-path",
        f"mkdir -p {remote_path} && rsync",
        "-e",
        ssh_cmd,
    ]
    if chown:
        cmd.extend(["--chown", chown])
    cmd.extend([f"{local_path}/", f"root@{hostname}:{remote_path}/"])

    last_error = ""
    for attempt in range(1, max_retries + 1):
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode == 0:
            return

        last_error = stderr.decode()
        if attempt < max_retries:
            logger.warning(
                f"rsync to VM failed (attempt {attempt}/{max_retries}), "
                f"retrying in {retry_delay}s: {last_error.strip()}"
            )
            await asyncio.sleep(retry_delay)

    raise RuntimeError(f"rsync to VM failed after {max_retries} attempts: {last_error}")


async def rsync_from(
    ssh_key_path: Path,
    remote_path: str,
    local_path: Path,
    hostname: str,
    max_retries: int = 3,
    retry_delay: float = 5.0,
) -> None:
    """Rsync a directory from a remote VM back to local."""
    ssh_cmd = f"ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"

    local_path.mkdir(parents=True, exist_ok=True)

    cmd = [
        "rsync",
        "-az",
        "-e",
        ssh_cmd,
        f"root@{hostname}:{remote_path}/",
        f"{local_path}/",
    ]

    last_error = ""
    for attempt in range(1, max_retries + 1):
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode == 0:
            return

        last_error = stderr.decode()
        if attempt < max_retries:
            logger.warning(
                f"rsync from VM failed (attempt {attempt}/{max_retries}), "
                f"retrying in {retry_delay}s: {last_error.strip()}"
            )
            await asyncio.sleep(retry_delay)

    raise RuntimeError(f"rsync from VM failed after {max_retries} attempts: {last_error}")


# ---------------------------------------------------------------------------
# Workspace ABC and implementations
# ---------------------------------------------------------------------------


class Workspace(ABC):
    """Abstract workspace shared between world VM and agent VMs."""

    path: str
    mount_path: str | None = None  # Where to mount on agent VM (default: same as path)

    @abstractmethod
    async def initialize(self) -> None:
        """One-time setup on the world VM (e.g., start NFS server)."""

    @abstractmethod
    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        """Make workspace available on an agent VM."""

    @abstractmethod
    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        """Sync changes back from agent VM to world VM."""

    @abstractmethod
    def with_path(self, path: str) -> Workspace:
        """Return a copy of this workspace with a different path."""

    @property
    def agent_mount_path(self) -> str:
        """Path where this workspace appears on the agent VM. Defaults to same as host path."""
        return self.mount_path or self.path

    async def prepare(self) -> None:
        """Prepare this workspace's path on the world VM (e.g., NFS bind mount).

        Call this after with_path() if data will be written before setup_agent().
        Default is a no-op; NFS workspaces bind-mount the path into the NFS tree.
        """

    def mount_at(self, remote_path: str) -> Workspace:
        """Return a copy of this workspace that mounts at a custom path on the agent VM."""
        ws = self.with_path(self.path)
        ws.mount_path = remote_path
        return ws


class RsyncWorkspace(Workspace):
    """Workspace shared via rsync over SSH."""

    def __init__(self, path: str, ssh_key_path: Path, mount_path: str | None = None) -> None:
        self.path = path
        self.ssh_key_path = ssh_key_path
        self.mount_path = mount_path

    async def initialize(self) -> None:
        pass

    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        workspace_path = Path(self.path)
        if not workspace_path.exists():
            logger.debug(f"Workspace path {self.path} does not exist, skipping rsync")
            return
        remote = self.agent_mount_path
        logger.debug(f"Syncing workspace: {self.path} -> {remote}")
        await rsync_to(
            self.ssh_key_path,
            workspace_path,
            remote,
            hostname,
            chown="superman:superman",
        )

    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        workspace_path = Path(self.path)
        remote = self.agent_mount_path
        logger.debug(f"Syncing workspace back: {remote} -> {self.path}")
        await rsync_from(
            self.ssh_key_path,
            remote,
            workspace_path,
            hostname,
        )

    def with_path(self, path: str) -> RsyncWorkspace:
        return RsyncWorkspace(path, self.ssh_key_path, self.mount_path)


# ---------------------------------------------------------------------------
# NFS Workspace
# ---------------------------------------------------------------------------

NFS_ROOT = "/srv/nfs"


class NFSWorkspace(Workspace):
    """Workspace shared via NFSv4 mount from world VM.

    All workspace data lives on a loopback ext4 filesystem mounted at
    /srv/nfs (the NFSv4 pseudo-root). This uses real disk instead of tmpfs
    to avoid eating RAM, while still being exportable via NFS (overlayfs
    cannot be exported). The world VM's workspace path (e.g. /workspace)
    is symlinked to /srv/nfs/workspace so both world code and NFS clients
    see the same data.
    """

    def __init__(self, path: str, world_vm_ip: str, ssh_key_path: Path, mount_path: str | None = None) -> None:
        self.path = path
        self.world_vm_ip = world_vm_ip
        self.ssh_key_path = ssh_key_path
        self.mount_path = mount_path

    async def initialize(self) -> None:
        """Set up NFS server with disk-backed workspace on the world VM."""
        # Install NFS server if not present (pre-installed in plato-world-base >= 1.1.0)
        await run_local(
            "which exportfs > /dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq nfs-kernel-server)",
            timeout=120,
        )

        # Create a loopback ext4 filesystem at NFS_ROOT.
        # This uses real disk instead of tmpfs so workspace data doesn't eat RAM.
        # overlayfs can't be exported via NFS, so we need a separate filesystem.
        loop_file = "/var/lib/nfs-workspace.img"
        exit_code, _, _ = await run_local(f"mountpoint -q {NFS_ROOT}", timeout=5)
        if exit_code != 0:
            # Determine available disk space — use 80% of free space
            _, df_out, _ = await run_local("df --output=avail -B1 / | tail -1", timeout=5)
            avail_bytes = int(df_out.strip())
            loop_size = int(avail_bytes * 0.8)
            # Cap at 50GB, floor at 1GB
            loop_size = max(loop_size, 1 * 1024**3)
            loop_size = min(loop_size, 50 * 1024**3)
            loop_size_mb = loop_size // (1024 * 1024)

            exit_code, _, stderr = await run_local(
                f"mkdir -p {NFS_ROOT} && "
                f"truncate -s {loop_size_mb}M {loop_file} && "
                f"mkfs.ext4 -q -F {loop_file} && "
                f"mount -o loop {loop_file} {NFS_ROOT}",
                timeout=60,
            )
            if exit_code != 0:
                # Fall back to tmpfs if loopback fails
                logger.warning("Loopback mount failed (%s), falling back to tmpfs", stderr.strip())
                exit_code, _, stderr = await run_local(
                    f"mkdir -p {NFS_ROOT} && mount -t tmpfs tmpfs {NFS_ROOT}",
                    timeout=10,
                )
                if exit_code != 0:
                    raise RuntimeError(f"Failed to create workspace filesystem at {NFS_ROOT}: {stderr}")
            else:
                logger.info("Workspace: loopback ext4 (%dMB) mounted at %s", loop_size_mb, NFS_ROOT)

        # Set NFS root ownership to superman so agent can write
        await run_local(f"chown 1000:1000 {NFS_ROOT}", timeout=5)

        # Create workspace dir on NFS filesystem and bind-mount the world path to it
        await self._setup_workspace_path(self.path)

        # Export the entire tmpfs as NFSv4 pseudo-root
        exit_code, _, stderr = await run_local(
            f"printf '%s\\n' '{NFS_ROOT} *(rw,sync,fsid=0,no_subtree_check,all_squash,anonuid=1000,anongid=1000)' > /etc/exports",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to configure NFS exports: {stderr}")

        # Mount nfsd filesystem if needed
        exit_code, _, stderr = await run_local(
            "modprobe nfsd 2>/dev/null; "
            "mkdir -p /proc/fs/nfsd && "
            "mountpoint -q /proc/fs/nfsd || mount -t nfsd nfsd /proc/fs/nfsd",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to mount nfsd filesystem: {stderr}")

        # Start NFS services
        exit_code, _, stderr = await run_local(
            "systemctl start rpcbind && "
            "systemctl reset-failed proc-fs-nfsd.mount 2>/dev/null; "
            "exportfs -ra && "
            "systemctl start nfs-kernel-server",
            timeout=30,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to start NFS server: {stderr}")

        # Verify
        exit_code, exports, _ = await run_local("exportfs -s", timeout=5)
        logger.info(f"NFS server running. Exports:\n{exports.strip()}")

    async def _setup_workspace_path(self, path: str) -> None:
        """Create workspace dir on the NFS filesystem and bind-mount the world path to it.

        Uses bind mount instead of symlink so that restic (and other tools that
        don't follow symlinks) see the real files when backing up the workspace.
        If the path already has content (e.g. template copied before agent runs),
        it is moved into the NFS dir first so the agent sees it.
        """
        nfs_path = f"{NFS_ROOT}{path}"
        exit_code, _, stderr = await run_local(
            f"mkdir -p {nfs_path} && mkdir -p {path} && mountpoint -q {path} || mount --bind {nfs_path} {path}",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to setup workspace path {path}: {stderr}")
        logger.info(f"Workspace {path} -> {nfs_path} (bind mount)")

    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        """Mount the world VM's NFS export on an agent VM via SSH."""
        # Ensure NFS directory exists and world VM path is symlinked to it.
        # This is critical for with_path() created workspaces whose paths
        # weren't set up during initialize().
        await self._setup_workspace_path(self.path)

        # Fix ownership locally on the world VM (fast local FS, not over NFS).
        # World VM creates files as root; agent runs as superman (uid 1000).
        nfs_path = f"{NFS_ROOT}{self.path}"
        await run_local(f"chown -R 1000:1000 {nfs_path}", timeout=120)

        # Install NFS client if not present (pre-installed in plato-agent-base >= 1.2.0)
        await run_ssh(
            self.ssh_key_path,
            hostname,
            "which mount.nfs > /dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq nfs-common)",
            timeout=60,
        )

        # Mount NFSv4 (path is relative to pseudo-root)
        remote = self.agent_mount_path
        mount_cmd = f"mkdir -p {remote} && mount -t nfs4 -o soft,timeo=30 {self.world_vm_ip}:{self.path} {remote}"
        exit_code, _, stderr = await run_ssh(
            self.ssh_key_path,
            hostname,
            mount_cmd,
            timeout=30,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to mount NFS on agent VM: {stderr}")

        logger.debug(f"NFS mounted {self.path} -> {remote} on agent VM ({hostname})")

    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        """NFS writes are immediate — nothing to do."""
        pass

    async def prepare(self) -> None:
        """Set up the NFS bind mount for this workspace path."""
        await self._setup_workspace_path(self.path)

    def with_path(self, path: str) -> NFSWorkspace:
        return NFSWorkspace(path, self.world_vm_ip, self.ssh_key_path, self.mount_path)
