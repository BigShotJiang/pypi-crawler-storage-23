# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
import sys
import signal
from .main import machine
from .config import settings
import click
import fileinput
import json


def handle_sigint(signum, frame):
    # Send the acknowledgment explicitly to stderr
    sys.stderr.write("[Child: SIGINT handled gracefully]\n")
    sys.stderr.flush()
    # Exit
    sys.exit(0)


# Register the signal interceptor
signal.signal(signal.SIGINT, handle_sigint)


@click.command()
@click.option('--provider-api-key', envvar='PROVIDER_API_KEY') #,
              #default='no_key', help='Language Model API provider key.')
@click.option('--github-token', envvar='GITHUB_TOKEN') #,
              #default='no_token', help='GitHub access token (classic).')
def run(provider_api_key, github_token):
    """
        $ messages | ./run.py               # Accepts messages list from the pipe
        $ ./run.py /home/user/file.txt      # Reads file.
        $ ./run.py < /home/user/file.txt    # Reads file.
    """
    raw_input = ''
    for line in fileinput.input(encoding="utf-8"):
        raw_input += line
        if line.rstrip('\n') == '__END__':
            # Do your thing with this input
            # result = json.loads(raw_input)
            print(raw_input)
            ...
        else:
            raw_input += line
    # The code only reaches this point if the pipe is permanently closed
    # (e.g., the parent script crashed, or a user piped a file from the terminal).
    sys.stderr.write("\n[SYSTEM: EOF detected. Input stream permanently closed.]\n")
    sys.stderr.flush()
    if raw_input:
        # Do your thing with single input that has EOF and not __END__
        sys.stdout.write("Processed text (via EOF):\n")
        sys.stdout.write(raw_input + "\n")
        sys.stdout.write("__END__\n")
        sys.stdout.flush()

    print(f'\napi_key = {provider_api_key}')
    print(f'\ngithub_token = {github_token}')

