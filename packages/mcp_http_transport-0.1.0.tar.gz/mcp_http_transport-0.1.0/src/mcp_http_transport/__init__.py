"""
mcp-http-transport: HTTP/SSE transport for MCP servers with hot reload support.

This package provides a transport layer abstraction for MCP (Model Context Protocol)
servers, enabling both stdio and HTTP/SSE transports.

Key features:
- Stdio transport (default): standard MCP over stdin/stdout
- HTTP/SSE transport: enables hot reload without client restart
- Zero modification to MCP server handlers
- Automatic reconnection on server restart
- Compatible with all MCP Python servers

Example:
    >>> import os
    >>> from mcp.server import Server
    >>> from mcp_http_transport import MCPTransportManager
    >>>
    >>> server = Server("my-server")
    >>>
    >>> # Configure via environment variables
    >>> transport_mode = os.getenv("MCP_TRANSPORT", "stdio")
    >>> http_host = os.getenv("MCP_HTTP_HOST", "localhost")
    >>> http_port = int(os.getenv("MCP_HTTP_PORT", "3000"))
    >>>
    >>> async def main():
    >>>     transport = MCPTransportManager(server, transport_mode, http_host, http_port)
    >>>     await transport.start()
"""

from .transport import MCPTransportManager

__version__ = "0.1.0"
__all__ = ["MCPTransportManager"]
