"""Tests for the BSL compiler package."""
