# Chatsee SDK (Python)

## Installation

```bash
pip install chatsee-ai
```

## Environment deployment (QA / Demo / GCP)

The SDK supports **one package** and you select the environment by setting `api_base_url` to an **alias**: `"qa" | "demo" | "gcp"`.

### Classifiers source (redaction)
By default, the SDK always fetches redaction classifiers from **QA** (`qa`) regardless of the selected environment.

### QA
- **Alias**: `qa` → `https://qa-api.chatsee.ai:8000`
- Interaction endpoint: `/v1/api/process_interaction`
- Classifiers endpoint: `/v1/redaction/fetch-classifiers`
- API docs: [`qa process_interaction`](https://qa-api.chatsee.ai:8000/docs#/Processing/process_interaction_v1_api_process_interaction_post), [`qa redaction classifiers`](https://qa-api.chatsee.ai:8000/docs#/Redaction/fetch_redaction_classifiers_v1_redaction_fetch_classifiers_post)

### Demo
- **Alias**: `demo` → `https://demo-api.chatsee.ai:8000`
- Interaction endpoint: `/v1/api/process_interaction`
- Classifiers endpoint: `/v1/redaction/fetch-classifiers`
- API docs: [`demo process_interaction`](https://demo-api.chatsee.ai:8000/docs#/Processing/process_interaction_v1_api_process_interaction_post)

### GCP QA
- **Alias**: `gcp` → `https://gcp-qa.chatsee.ai/api`
- Interaction endpoint: `/v1/api/process_interaction`
- Classifiers endpoint: `/v1/redaction/fetch-classifiers`

## Usage (tracking)

```python
from chatsee import ChatseeTracker

tracker = ChatseeTracker(
    agent_id="agent_1",
    tenant_id="tenant_1",
    api_base_url="qa",  # or "demo" / "gcp"
    redaction_enabled=True,  # optional: locally redact before sending
)

tracker.start_turn("My email is test@example.com", metadata={"any": "metadata"})
tracker.end_turn("Thanks!")
```

## Usage (redaction as an SDK feature)

### Module-level `chatsee.redact()`

```python
from chatsee import redact

redacted = redact(
    {"message": "Card 4111 1111 1111 1111", "email": "a@b.com"},
    api_base_url="qa",
    fields_to_redact="*",
    verify_ssl=True,
)
```

### Tracker instance `tracker.redact()`

```python
redacted = tracker.redact({"user_message": "Phone +1 (555) 123-4567"}, fields_to_redact="*")
```

## Encryption

Encryption support has been removed from this SDK.
