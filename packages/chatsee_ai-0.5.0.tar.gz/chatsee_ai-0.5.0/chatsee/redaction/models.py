from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Callable, Optional


@dataclass(frozen=True)
class RedactionRule:
    type: str
    regex: re.Pattern
    priority: int
    mask_char: str = "X"
    mask_strategy: str = "ALTERNATE"
    validator: Optional[Callable[[str], bool]] = None

