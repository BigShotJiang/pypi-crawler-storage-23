"""
Chatsee AI SDK
Tracks conversation data with optional support for tool calls, errors, and metadata.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
from datetime import datetime
import requests
import logging
import warnings

# Optional local redaction support (fail open if unavailable)
from chatsee.redaction.engine import redact_payload_sync
from chatsee.redaction.loader import load_redaction_rules_sync
from chatsee.env import resolve_api_base_url

# Set up a logger for the library
logger = logging.getLogger(__name__)

@dataclass
class ToolCall:
    tool_name: str
    arguments: Dict[str, Any]
    result: Optional[Any] = None
    error: Optional[str] = None
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()

class ChatseeTracker:
    """
    SDK class for tracking LLM conversations.
    """
    
    _DEFAULT_API_BASE_URL = "qa"
    _PROCESS_INTERACTION_PATH = "/v1/api/process_interaction"
    _CLASSIFIERS_PATH = "/v1/redaction/fetch-classifiers"
    
    def __init__(self, 
                 agent_id: str,
                 tenant_id: str,
                 # Removed chatsee_api_key
                 session_id: Optional[str] = None,
                 timeout: int = 10,
                 verify_ssl: bool = False,
                 api_base_url: Optional[str] = None,
                 redaction_enabled: bool = False,
                 redaction_fields_to_redact: Optional[Any] = None,
                 redaction_cache_ttl_seconds: int = 300,
                 redaction_timeout_seconds: float = 5.0,
                 redaction_classifiers_url: Optional[str] = None):
        
        if not agent_id or not tenant_id:
            raise ValueError("agent_id and tenant_id are required.")
            
        self.agent_id = agent_id
        self.tenant_id = tenant_id
        self.session_id = session_id 
        self.timeout = timeout
        self.verify_ssl = verify_ssl

        base_url = resolve_api_base_url(api_base_url or self._DEFAULT_API_BASE_URL).rstrip("/")
        self._api_endpoint = f"{base_url}{self._PROCESS_INTERACTION_PATH}"
        # Requirement: classifiers are always fetched from QA environment by default.
        qa_base_url = resolve_api_base_url("qa").rstrip("/")
        self._classifiers_url = redaction_classifiers_url or f"{qa_base_url}{self._CLASSIFIERS_PATH}"

        self._redaction_enabled = bool(redaction_enabled)
        self._redaction_fields_to_redact = (
            redaction_fields_to_redact
            if redaction_fields_to_redact is not None
            else {"user_message", "bot_message", "interactions"}
        )
        self._redaction_cache_ttl_seconds = int(redaction_cache_ttl_seconds)
        self._redaction_timeout_seconds = float(redaction_timeout_seconds)
        
        # Internal state for the current turn
        self.current_user_message: Optional[str] = None
        self.current_metadata: Dict[str, Any] = {}
        self.current_tool_calls: List[ToolCall] = []
        self.current_exception: Optional[str] = None
        self.error_encountered: int = 0
        self.current_system_prompt: Optional[str] = None
        
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json"
        })
        
        if not self.verify_ssl:
            warnings.filterwarnings('ignore', 'Unverified HTTPS request')

    def _apply_redaction_if_enabled(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._redaction_enabled:
            return payload
        rules = load_redaction_rules_sync(
            classifiers_url=self._classifiers_url,
            cache_ttl_seconds=self._redaction_cache_ttl_seconds,
            timeout_seconds=self._redaction_timeout_seconds,
            verify_ssl=self.verify_ssl,
        )
        if not rules:
            return payload

        try:
            redacted = redact_payload_sync(
                payload, rules, fields_to_redact=self._redaction_fields_to_redact
            )
            return redacted if isinstance(redacted, dict) else payload
        except Exception:
            # Fail open: do not block tracking
            return payload

    def redact(self, payload: Any, fields_to_redact: Optional[Any] = None) -> Any:
        """
        Redact an arbitrary payload using this tracker’s configured environment.
        This does not send anything to Chatsee.
        """
        rules = load_redaction_rules_sync(
            classifiers_url=self._classifiers_url,
            cache_ttl_seconds=self._redaction_cache_ttl_seconds,
            timeout_seconds=self._redaction_timeout_seconds,
            verify_ssl=self.verify_ssl,
        )
        if not rules:
            return payload
        return redact_payload_sync(
            payload,
            rules,
            fields_to_redact=fields_to_redact
            if fields_to_redact is not None
            else self._redaction_fields_to_redact,
        )

    def start_turn(self, user_message: str, metadata: Optional[Dict[str, Any]] = None, system_prompt: Optional[str] = None):
        """
        Start tracking a turn.
        """
        self.current_user_message = user_message
        self.current_metadata = metadata or {}
        self.current_tool_calls = []
        self.current_exception = None
        self.error_encountered = 0
        self.current_system_prompt = system_prompt
    
    def log_tool_call(self, tool_name: str, arguments: Dict[str, Any], 
                      result: Optional[Any] = None, error: Optional[str] = None):
        """
        Log an optional tool/function call.
        """
        if self.current_user_message is None:
             logger.warning("log_tool_call called before start_turn.")
             return

        tool_call = ToolCall(
            tool_name=tool_name,
            arguments=arguments,
            result=result,
            error=error
        )
        self.current_tool_calls.append(tool_call)
        
        if error:
            self.error_encountered = 1
            if not self.current_exception:
                self.current_exception = error
    
    def log_exception(self, exception: Exception):
        """
        Log an optional exception.
        """
        if self.current_user_message is None:
             logger.warning("log_exception called before start_turn.")
             return

        self.error_encountered = 1
        self.current_exception = str(exception)
    
    def end_turn(self, bot_message: str):
        """
        Complete the turn and send data to the API.
        """
        if not self.current_user_message:
            logger.warning("end_turn called without start_turn. Skipping log.")
            return

        try:
            # Prepare optional tool call data
            tool_calls_dicts = [asdict(tc) for tc in self.current_tool_calls]
            
            payload = {
                # Required Fields (No API Key)
                'agent_id': self.agent_id,
                'tenant_id': self.tenant_id,
                'user_message': self.current_user_message,
                'bot_message': bot_message,
                'session_id': self.session_id,
                
                # Optional Fields
                'tool_call': 1 if tool_calls_dicts else 0,
                'tool_calls_details': tool_calls_dicts,
                'error_encountered': self.error_encountered,
                'exception': self.current_exception,
                'metadata': self.current_metadata,
                'system_prompt': self.current_system_prompt
            }

            payload_to_send = self._apply_redaction_if_enabled(payload)
            
            # Send to API
            response = self.session.post(
                self._api_endpoint,
                json=payload_to_send,
                timeout=self.timeout,
                verify=self.verify_ssl
            )
            response.raise_for_status()

            # Log success (useful for QA/debugging; controlled by consumer's logging config)
            interaction_id = None
            try:
                data = response.json()
                interaction_id = data.get("interaction_id") or data.get("data", {}).get("interaction_id")
            except Exception:
                data = None

            if interaction_id:
                logger.info(
                    "Chatsee interaction sent successfully. status=%s interaction_id=%s",
                    response.status_code,
                    interaction_id,
                )
            else:
                logger.info(
                    "Chatsee interaction sent successfully. status=%s",
                    response.status_code,
                )
            
            # Update session ID if generated by API
            if not self.session_id:
                if data is None:
                    data = response.json()
                if 'session_id' in data:
                    self.session_id = data['session_id']
            
        except Exception as e:
            logger.error(f"Failed to send turn to Chatsee: {e}")
        finally:
            # Reset state
            self.current_user_message = None
            self.current_metadata = {}
            self.current_tool_calls = []
            self.current_exception = None
            self.error_encountered = 0
            self.current_system_prompt = None