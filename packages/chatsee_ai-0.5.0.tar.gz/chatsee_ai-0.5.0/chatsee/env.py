from __future__ import annotations

from typing import Optional


_ENV_TO_BASE_URL = {
    "qa": "https://qa-api.chatsee.ai:8000",
    "demo": "https://demo-api.chatsee.ai:8000",
    # Note: GCP QA has an `/api` prefix in the base URL
    "gcp": "https://gcp-qa.chatsee.ai/api",
}


def resolve_api_base_url(api_base_url: Optional[str]) -> str:
    """
    Accepts either:
    - environment alias: "qa" | "demo" | "gcp"
    - full URL: "https://..."
    """
    raw = (api_base_url or "").strip()
    if not raw:
        return _ENV_TO_BASE_URL["qa"]

    key = raw.lower()
    if key in _ENV_TO_BASE_URL:
        return _ENV_TO_BASE_URL[key]

    # Backward compatible: allow full URL.
    return raw.rstrip("/")

