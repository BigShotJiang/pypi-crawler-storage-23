List of all command execution API calls
