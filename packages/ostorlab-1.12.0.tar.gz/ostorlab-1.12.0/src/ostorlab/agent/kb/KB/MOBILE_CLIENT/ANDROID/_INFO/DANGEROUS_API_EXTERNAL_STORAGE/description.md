List of all external storage API calls. Insecure storage of sensitive information by setting insecure permissions or storing data without encryption might expose this information to an attacker.
