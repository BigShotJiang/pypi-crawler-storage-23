Obfuscation refers to methods to obscure code and make it hard to understand. Compiled Java classes can be decompiled if there is no obfuscation during compilation step.

Adversaries can steal code and repurpose it and sell it in a new application or create a malicious fake application based on the initial one.

Code obfuscation only slows the attacker from reverse engineering but does not make it impossible.