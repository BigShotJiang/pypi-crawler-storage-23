"""
shamash-openclaw-setup — One-command setup for the Shamash OpenClaw plugin.

Steps:
  1. Verify ~/.openclaw/ exists (OpenClaw installed)
  2. Copy plugin files to ~/.openclaw/plugins/shamash-openclaw/
  3. Install the platform-appropriate shamash binary (bundled in package)
  4. Register the plugin path in ~/.openclaw/openclaw.json (idempotent)
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import stat
import sys
from pathlib import Path

PLUGIN_NAME = "shamash-openclaw"

# Files to copy from the bundled plugin/ directory into the install target
PLUGIN_FILES = [
    "dist/index.js",
    "dist/index.d.ts",
    "dist/scanner.js",
    "dist/scanner.d.ts",
    "dist/telemetry.js",
    "dist/telemetry.d.ts",
    "openclaw.plugin.json",
    "package.json",
]


def _openclaw_dir() -> Path:
    return Path.home() / ".openclaw"


def _plugin_source_dir() -> Path:
    """Return the path to the bundled plugin files shipped with this package."""
    return Path(__file__).parent / "plugin"


def _bin_source_dir() -> Path:
    """Return the path to the bundled binaries shipped with this package."""
    return Path(__file__).parent / "bin"


def _resolve_binary_name() -> str | None:
    """Map current platform/arch to the bundled Shamash binary name."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    platform_map = {"darwin": "darwin", "linux": "linux", "windows": "windows"}
    arch_map = {"x86_64": "x64", "amd64": "x64", "aarch64": "arm64", "arm64": "arm64"}

    mapped_platform = platform_map.get(system)
    mapped_arch = arch_map.get(machine)

    if not mapped_platform or not mapped_arch:
        return None

    ext = ".exe" if system == "windows" else ""
    return f"shamash-{mapped_platform}-{mapped_arch}{ext}"


def _sha256_file(file_path: Path) -> str:
    digest = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _parse_sha256sums(checksum_text: str) -> dict[str, str]:
    checksums: dict[str, str] = {}
    for line in checksum_text.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        digest = parts[0].lower()
        filename = parts[-1].lstrip("*")
        if len(digest) == 64:
            checksums[filename] = digest
    return checksums


def _verify_binary_checksum(binary_name: str, binary_path: Path, checksums_path: Path) -> None:
    """Verify binary against bundled SHA256SUMS.txt."""
    if not checksums_path.exists():
        print("  WARNING: SHA256SUMS.txt not found in package, skipping checksum verification")
        return
    checksum_text = checksums_path.read_text(encoding="utf-8")
    checksums = _parse_sha256sums(checksum_text)
    expected = checksums.get(binary_name)
    if not expected:
        print(f"  WARNING: No checksum entry for {binary_name}, skipping verification")
        return
    actual = _sha256_file(binary_path)
    if actual != expected:
        raise RuntimeError(
            f"Checksum mismatch for {binary_name}: expected {expected}, got {actual}"
        )
    print(f"  Checksum verified: {binary_name}")


def _copy_plugin_files(target_dir: Path) -> None:
    """Copy bundled plugin files to the target directory."""
    source_dir = _plugin_source_dir()

    for rel_path in PLUGIN_FILES:
        src = source_dir / rel_path
        dst = target_dir / rel_path

        if not src.exists():
            print(f"  WARNING: Missing bundled file: {rel_path}")
            continue

        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            same = dst.exists() and os.path.samefile(src, dst)
        except OSError:
            same = False
        if same:
            data = src.read_bytes()
            dst.unlink()
            dst.write_bytes(data)
        else:
            shutil.copy2(src, dst)
        print(f"  Copied {rel_path}")


def _install_binary(target_dir: Path) -> None:
    """Install the platform-appropriate shamash binary from bundled binaries."""
    binary_name = _resolve_binary_name()
    if not binary_name:
        print(
            f"  WARNING: Unsupported platform: {platform.system()}/{platform.machine()}"
        )
        print("  You can manually install shamash and set binaryPath in your OpenClaw config.")
        return

    bin_source = _bin_source_dir()
    src = bin_source / binary_name

    if not src.exists():
        print(f"  ERROR: Bundled binary not found: {binary_name}")
        print("  Available binaries:")
        for f in sorted(bin_source.iterdir()):
            if f.name != "SHA256SUMS.txt":
                print(f"    - {f.name}")
        print("  You can manually install shamash and set binaryPath in your OpenClaw config.")
        return

    # Verify checksum against bundled SHA256SUMS.txt
    checksums_path = bin_source / "SHA256SUMS.txt"
    _verify_binary_checksum(binary_name, src, checksums_path)

    # Copy to target
    bin_dir = target_dir / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    local_name = "shamash.exe" if platform.system().lower() == "windows" else "shamash"
    dest = bin_dir / local_name

    try:
        same = dest.exists() and os.path.samefile(src, dest)
    except OSError:
        same = False
    if same:
        data = src.read_bytes()
        dest.unlink()
        dest.write_bytes(data)
    else:
        shutil.copy2(src, dest)

    if platform.system().lower() != "windows":
        dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    print(f"  Binary installed: {dest}")


def _register_plugin_path(plugin_dir: Path) -> None:
    """Register the plugin path in ~/.openclaw/openclaw.json (idempotent)."""
    config_path = _openclaw_dir() / "openclaw.json"

    config: dict = {}
    if config_path.exists():
        config = json.loads(config_path.read_text(encoding="utf-8"))

    plugins = config.setdefault("plugins", {})
    load = plugins.setdefault("load", {})
    paths: list = load.setdefault("paths", [])

    plugin_path_str = str(plugin_dir)
    if plugin_path_str not in paths:
        paths.append(plugin_path_str)
        config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
        print(f"  Registered plugin path in {config_path}")
    else:
        print(f"  Plugin path already registered in {config_path}")


def main() -> None:
    print(f"[{PLUGIN_NAME}] Setting up Shamash OpenClaw plugin...")

    openclaw_dir = _openclaw_dir()
    if not openclaw_dir.exists():
        print(f"  ERROR: {openclaw_dir} not found. Is OpenClaw installed?")
        print("  Install OpenClaw first, then re-run: shamash-openclaw-setup")
        sys.exit(1)

    plugin_dir = openclaw_dir / "plugins" / PLUGIN_NAME
    plugin_dir.mkdir(parents=True, exist_ok=True)

    print(f"  Installing to {plugin_dir}")

    # Step 1: Copy plugin files
    _copy_plugin_files(plugin_dir)

    # Step 2: Install shamash binary
    try:
        _install_binary(plugin_dir)
    except RuntimeError as e:
        print(f"  ERROR: {e}")
        print("  Binary install aborted to avoid unverified executable.")
        sys.exit(1)

    # Step 3: Register in openclaw.json
    _register_plugin_path(plugin_dir)

    print(f"[{PLUGIN_NAME}] Setup complete. Restart OpenClaw to activate the 4-gate firewall.")


if __name__ == "__main__":
    main()
