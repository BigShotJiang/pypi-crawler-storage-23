# shamash-openclaw (pip)

Python package wrapper that installs the OpenClaw Shamash plugin and downloads a compatible Shamash binary.

## Install

```bash
pip install shamash-openclaw
```

## One-command setup

```bash
shamash-openclaw-setup
```

This command:

1. Verifies `~/.openclaw/` exists.
2. Copies plugin assets into `~/.openclaw/plugins/shamash-openclaw/`.
3. Downloads a platform-appropriate `shamash` binary into `bin/shamash`.
4. Registers plugin load path in `~/.openclaw/openclaw.json`.

## Recommended config hardening

Set an explicit allow-list in `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "allow": ["shamash-openclaw"]
  }
}
```

## Verify

After restarting OpenClaw:

- Run `/shamash` in chat and confirm plugin status appears.
- Check logs for `Shamash 4-gate firewall active`.

## Notes

- If binary download fails, set `plugins.config.shamash-openclaw.binaryPath` manually.
- For detailed plugin configuration, see `integrations/openclaw/README.md`.
