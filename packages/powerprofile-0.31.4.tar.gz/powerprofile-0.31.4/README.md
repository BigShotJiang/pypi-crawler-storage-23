# PowerProfile

![Build Status](https://github.com/gisce/powerprofile/actions/workflows/python2.7-app.yml/badge.svg)

![Build Status](https://github.com/gisce/powerprofile/actions/workflows/python3.11-app.yml/badge.svg)

Electric Power Curve and Profiles library

Libray to manipulate easily profiles and operate with and between them

Automatic version with labels https://github.com/gisce/powerprofile/labels/major https://github.com/gisce/powerprofile/labels/minor https://github.com/gisce/powerprofile/labels/patch
