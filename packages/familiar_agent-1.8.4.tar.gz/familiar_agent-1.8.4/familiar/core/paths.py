# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Path Configuration

Centralized path definitions used across the entire application.
Import paths from here instead of defining them locally.

Usage:
    from familiar.core.paths import DATA_DIR, SKILLS_DIR, MEMORY_FILE
"""

from pathlib import Path
from typing import Optional

# Base directories
HOME_DIR = Path.home()
AGENT_DIR = HOME_DIR / ".familiar"

# Tenant isolation support (set by Reflection's TenantAgent)
_tenant_id: Optional[str] = None

# Configuration
CONFIG_FILE = AGENT_DIR / "config.yaml"

# Data storage
DATA_DIR = AGENT_DIR / "data"
MEMORY_FILE = DATA_DIR / "memory.json"
HISTORY_FILE = DATA_DIR / "history.json"
TASKS_FILE = DATA_DIR / "scheduled_tasks.json"

# Skills
SKILLS_DIR = AGENT_DIR / "skills"

# Skill-specific data directories (created on demand)
BROWSER_DIR = DATA_DIR / "browser"
SCREENSHOTS_DIR = DATA_DIR / "screenshots"
DOWNLOADS_DIR = DATA_DIR / "downloads"
COOKIES_DIR = DATA_DIR / "browser_cookies"

TRIGGERS_DIR = DATA_DIR / "triggers"
TRIGGERS_FILE = TRIGGERS_DIR / "triggers.json"
WEBHOOKS_FILE = TRIGGERS_DIR / "webhooks.json"
EXECUTIONS_LOG = TRIGGERS_DIR / "executions.log"

KNOWLEDGE_DIR = DATA_DIR / "knowledge"
COLLECTIONS_DIR = KNOWLEDGE_DIR / "collections"
EMBEDDINGS_CACHE = KNOWLEDGE_DIR / "embeddings_cache.json"

VOICE_DIR = DATA_DIR / "voice"
RECORDINGS_DIR = VOICE_DIR / "recordings"
TRANSCRIPTS_DIR = VOICE_DIR / "transcripts"

CALENDAR_DIR = DATA_DIR / "calendar"
GDRIVE_DIR = DATA_DIR / "gdrive"
PLUGINS_DIR = AGENT_DIR / "plugins"

# Mesh networking
MESH_DIR = DATA_DIR / "mesh"

# Genesis block chain
CHAIN_DIR = DATA_DIR / "chain"

# Logs
LOGS_DIR = AGENT_DIR / "logs"


def ensure_dir(path: Path) -> Path:
    """Create directory if it doesn't exist, return the path."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_core_dirs() -> None:
    """Create all core directories needed by Familiar."""
    ensure_dir(AGENT_DIR)
    ensure_dir(DATA_DIR)
    ensure_dir(SKILLS_DIR)
    ensure_dir(LOGS_DIR)


def set_tenant_data_root(tenant_id: str) -> None:
    """
    Scope all data paths to a tenant-specific directory.

    Called by Reflection's TenantAgent to isolate tenant data.
    After calling this, DATA_DIR becomes ~/.familiar/tenants/{tenant_id}/data/
    and all derived paths update accordingly.

    For standalone Familiar (single-user), this is never called and
    paths remain at their defaults (~/.familiar/data/).
    """
    global _tenant_id, AGENT_DIR, DATA_DIR, MEMORY_FILE, HISTORY_FILE, TASKS_FILE
    global SKILLS_DIR, BROWSER_DIR, SCREENSHOTS_DIR, DOWNLOADS_DIR, COOKIES_DIR
    global TRIGGERS_DIR, TRIGGERS_FILE, WEBHOOKS_FILE, EXECUTIONS_LOG
    global KNOWLEDGE_DIR, COLLECTIONS_DIR, EMBEDDINGS_CACHE
    global VOICE_DIR, RECORDINGS_DIR, TRANSCRIPTS_DIR
    global CALENDAR_DIR, GDRIVE_DIR, PLUGINS_DIR, MESH_DIR, CHAIN_DIR, LOGS_DIR

    _tenant_id = tenant_id
    AGENT_DIR = HOME_DIR / ".familiar" / "tenants" / tenant_id

    DATA_DIR = AGENT_DIR / "data"
    MEMORY_FILE = DATA_DIR / "memory.json"
    HISTORY_FILE = DATA_DIR / "history.json"
    TASKS_FILE = DATA_DIR / "scheduled_tasks.json"

    SKILLS_DIR = AGENT_DIR / "skills"

    BROWSER_DIR = DATA_DIR / "browser"
    SCREENSHOTS_DIR = DATA_DIR / "screenshots"
    DOWNLOADS_DIR = DATA_DIR / "downloads"
    COOKIES_DIR = DATA_DIR / "browser_cookies"

    TRIGGERS_DIR = DATA_DIR / "triggers"
    TRIGGERS_FILE = TRIGGERS_DIR / "triggers.json"
    WEBHOOKS_FILE = TRIGGERS_DIR / "webhooks.json"
    EXECUTIONS_LOG = TRIGGERS_DIR / "executions.log"

    KNOWLEDGE_DIR = DATA_DIR / "knowledge"
    COLLECTIONS_DIR = KNOWLEDGE_DIR / "collections"
    EMBEDDINGS_CACHE = KNOWLEDGE_DIR / "embeddings_cache.json"

    VOICE_DIR = DATA_DIR / "voice"
    RECORDINGS_DIR = VOICE_DIR / "recordings"
    TRANSCRIPTS_DIR = VOICE_DIR / "transcripts"

    CALENDAR_DIR = DATA_DIR / "calendar"
    GDRIVE_DIR = DATA_DIR / "gdrive"
    PLUGINS_DIR = AGENT_DIR / "plugins"
    MESH_DIR = DATA_DIR / "mesh"
    CHAIN_DIR = DATA_DIR / "chain"
    LOGS_DIR = AGENT_DIR / "logs"

    ensure_dir(DATA_DIR)


def set_data_root(root: str | Path) -> None:
    """Override the base data directory.

    Used by platform wrappers (Android, containers) to redirect
    all Familiar data to a platform-appropriate location.

    Args:
        root: Absolute path to use as the new AGENT_DIR base.
              All derived paths (DATA_DIR, SKILLS_DIR, etc.) are
              rebound relative to this root.
    """
    global AGENT_DIR, DATA_DIR, MEMORY_FILE, HISTORY_FILE, TASKS_FILE
    global SKILLS_DIR, BROWSER_DIR, SCREENSHOTS_DIR, DOWNLOADS_DIR, COOKIES_DIR
    global TRIGGERS_DIR, TRIGGERS_FILE, WEBHOOKS_FILE, EXECUTIONS_LOG
    global KNOWLEDGE_DIR, COLLECTIONS_DIR, EMBEDDINGS_CACHE
    global VOICE_DIR, RECORDINGS_DIR, TRANSCRIPTS_DIR
    global CALENDAR_DIR, GDRIVE_DIR, PLUGINS_DIR, MESH_DIR, CHAIN_DIR, LOGS_DIR
    global CONFIG_FILE

    AGENT_DIR = Path(root)

    CONFIG_FILE = AGENT_DIR / "config.yaml"

    DATA_DIR = AGENT_DIR / "data"
    MEMORY_FILE = DATA_DIR / "memory.json"
    HISTORY_FILE = DATA_DIR / "history.json"
    TASKS_FILE = DATA_DIR / "scheduled_tasks.json"

    SKILLS_DIR = AGENT_DIR / "skills"

    BROWSER_DIR = DATA_DIR / "browser"
    SCREENSHOTS_DIR = DATA_DIR / "screenshots"
    DOWNLOADS_DIR = DATA_DIR / "downloads"
    COOKIES_DIR = DATA_DIR / "browser_cookies"

    TRIGGERS_DIR = DATA_DIR / "triggers"
    TRIGGERS_FILE = TRIGGERS_DIR / "triggers.json"
    WEBHOOKS_FILE = TRIGGERS_DIR / "webhooks.json"
    EXECUTIONS_LOG = TRIGGERS_DIR / "executions.log"

    KNOWLEDGE_DIR = DATA_DIR / "knowledge"
    COLLECTIONS_DIR = KNOWLEDGE_DIR / "collections"
    EMBEDDINGS_CACHE = KNOWLEDGE_DIR / "embeddings_cache.json"

    VOICE_DIR = DATA_DIR / "voice"
    RECORDINGS_DIR = VOICE_DIR / "recordings"
    TRANSCRIPTS_DIR = VOICE_DIR / "transcripts"

    CALENDAR_DIR = DATA_DIR / "calendar"
    GDRIVE_DIR = DATA_DIR / "gdrive"
    PLUGINS_DIR = AGENT_DIR / "plugins"
    MESH_DIR = DATA_DIR / "mesh"
    CHAIN_DIR = DATA_DIR / "chain"
    LOGS_DIR = AGENT_DIR / "logs"

    ensure_dir(DATA_DIR)


def get_tenant_id() -> Optional[str]:
    """Return current tenant ID, or None for standalone mode."""
    return _tenant_id


def get_data_dir() -> Path:
    """Get current DATA_DIR (tenant-scoped if set, default otherwise)."""
    return DATA_DIR
