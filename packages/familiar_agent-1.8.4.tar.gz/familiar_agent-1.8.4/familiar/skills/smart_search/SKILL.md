# Smart Search / Unified Query Skill

Cross-skill unified search: one query searches contacts, donors,
grants, tasks, knowledge base, bookkeeping, meetings, documents,
emails, and calendar simultaneously.

## Usage

- smart_search: AI-routed query to the most relevant skills
- search_everything: Brute-force search across all data stores
- recent_activity: Activity feed across all skills (last N hours)
- quick_lookup: Fast entity lookup by name/ID across all skills

## Architecture

Reads directly from all skill JSON stores in ~/.familiar/data/.
No external dependencies. Results ranked by relevance and recency.
