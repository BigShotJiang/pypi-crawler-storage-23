# Role & Permission Skill (RBAC)

Granular role-based access control with per-skill and per-tool permissions.

## Built-in Roles

- **admin**: All skills, all tools, user management
- **editor**: Write access to assigned skills
- **viewer/readonly**: Read-only tools only
- **auditor**: Read-only + audit + compliance + encryption_status
- **volunteer**: contacts + tasks only

## Permission Model

Permissions are defined as `skill:tool` pairs (e.g. `bookkeeping:log_income`).
Wildcards: `bookkeeping:*` (all tools in skill), `*:*` (everything).

## HIPAA Relevance

- §164.312(a)(1): Access control — unique user, role-based permissions
- §164.308(a)(4): Information access management
