# Messaging Skill

Send messages via multiple platforms: iMessage, WhatsApp, Signal, SMS.

## Available Platforms

### iMessage (macOS only)
- Requires Mac with Messages app configured
- Requires Full Disk Access permission
- Works with iPhone contacts

### WhatsApp
- Requires Node.js bridge running
- Run: `node ~/.pi_agent/whatsapp_bridge.js`
- Scan QR code on first run
- Works with any WhatsApp contact

### Signal
- Requires signal-cli installed
- Requires registered/linked phone number
- Most secure option

### SMS (via Twilio)
- Requires Twilio account
- Costs per message
- Works with any phone number

## Usage Examples

"Send an iMessage to Mom saying I'll be late"
"WhatsApp John: meeting confirmed for 3pm"
"Signal message to +14155551234: the document is ready"
"Text Sarah that I'm on my way"

## Setup

### WhatsApp Bridge
```bash
cd ~/.pi_agent
npm install whatsapp-web.js qrcode-terminal ws
node whatsapp_bridge.js
# Scan QR code
```

### Signal
```bash
# macOS
brew install signal-cli

# Register new number
signal-cli -u +1YOURPHONE register
signal-cli -u +1YOURPHONE verify CODE

# Or link existing
signal-cli link -n "Pi Agent"

# Set environment
export SIGNAL_PHONE="+1YOURPHONE"
```
