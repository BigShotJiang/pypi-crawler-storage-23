from datetime import datetime
import json
from requests.exceptions import HTTPError
from rich.progress_bar import ProgressBar
import yaml
from uuid import uuid4
from pydantic import AnyUrl, BaseModel, Field
import tomli
from threading import Thread, Event
from contextlib import suppress
from dataclasses import dataclass
import logging
from pathlib import Path
from time import sleep
from typing import Any, Generator, Literal, Sequence
from docker import DockerClient
from rich.console import Console, Group
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.text import Text
from takk.models import CompiledJob, CompiledNetworkApp, CompiledProject, Project, secrets_for, settings_for_secrets
from takk.models import TakkEnvironment
from takk.secrets import Environments, ResourceTags, S3StorageConfig, ServiceUrl, settings_for_resources
from hashlib import sha256
import subprocess

logger = logging.getLogger(__name__)


def exposed_ports_at_host() -> list[int]:
    """
    Find all ports currently in use on the host machine (not just Docker ports).

    Tries multiple methods in order of preference:
    1. psutil (cross-platform, most reliable)
    2. lsof (macOS/Linux)
    3. netstat (fallback)

    Returns a list of port numbers that are currently listening or established.
    """
    ports: set[int] = set()

    # Try psutil first (most reliable cross-platform solution)
    try:
        import psutil
        try:
            for conn in psutil.net_connections(kind='inet'):
                if conn.laddr and conn.status in ('LISTEN', 'ESTABLISHED'):
                    ports.add(conn.laddr.port)
            return sorted(ports)
        except psutil.AccessDenied:
            pass
    except ImportError:
        pass

    # Try lsof on macOS/Linux
    try:
        result = subprocess.run(
            ["lsof", "-iTCP", "-sTCP:LISTEN", "-nP"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n')[1:]:  # Skip header
                parts = line.split()
                if len(parts) >= 9:
                    # Format: COMMAND PID USER FD TYPE DEVICE SIZE/OFF NODE NAME
                    # NAME is like *:8080 or localhost:3000
                    name = parts[8]
                    if ':' in name:
                        port_str = name.split(':')[-1]
                        with suppress(ValueError):
                            ports.add(int(port_str))
            return sorted(ports)
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    # Try netstat as fallback
    try:
        result = subprocess.run(
            ["netstat", "-an"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if 'LISTEN' in line or 'ESTABLISHED' in line:
                    parts = line.split()
                    for part in parts:
                        # Look for address:port patterns
                        if ':' in part and not part.startswith('::'):
                            port_str = part.split(':')[-1]
                            with suppress(ValueError):
                                port = int(port_str)
                                if 0 < port < 65536:
                                    ports.add(port)
            return sorted(ports)
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return []

console = Console()

class ImageKeys:
    lock_hash = "com.takkthon.lockhash"
    source_dir = "com.takkthon.source-dir"

@dataclass
class ProjectContainer:
    source_dir: str

@dataclass
class Container:
    name: str
    image: str
    restart: str
    environments: dict[str, str]
    volumes: list[str]
    ports: dict[str, int]
    command: list[str] | None = None


class GrafanaSource(BaseModel):
    name: str
    type: str
    url: AnyUrl

    access: str = Field(default="proxy")
    orgId: int = Field(default=1)
    basicAuth: bool = Field(default=False)
    isDefault: bool = Field(default=False)
    version: int = Field(default=1)
    editable: bool = Field(default=False)
    

class GrafanaSourcesFile(BaseModel):
    datasources: list[GrafanaSource]
    apiVersion: int = Field(default=1)


def needed_containers(project: CompiledProject, envs: dict[str, str | None], data_dir: Path | None = None) -> tuple[list[Container], dict[str, str]]:
    containers = []

    needed_res: set[str] = set()

    resource_tags = set(ResourceTags)

    for secret in project.shared_secrets:
        if secret.name in envs:
            continue

        tags = set(secret.tags).intersection(resource_tags)
        needed_res.update(tags)
        needed_res.add(secret.data_type)

    all_comps: Sequence[CompiledJob | CompiledNetworkApp] = [*project.network_apps, *project.jobs]
    for comp in all_comps:
        for secret in comp.secrets or []:
            if secret.name in envs:
                continue

            tags = set(secret.tags).intersection(resource_tags)
            needed_res.update(tags)
            needed_res.add(secret.data_type)

    resource_values: dict[str, str] = {}

    if data_dir is None:
        data_dir = Path.cwd().absolute() / ".data"


    grafana_sources: list[GrafanaSource] = []

    if ResourceTags.loki_push_endpoint in needed_res:
        name = f"{project.name}-loki"

        base_url = f"http://{name}:3100"
        resource_values[ResourceTags.loki_base_url] = base_url
        resource_values[ResourceTags.loki_push_endpoint] = f"{base_url}/loki/api/v1/push"

        containers.append(
            Container(
                name=name,
                image="grafana/loki:3.1.0",
                restart="always",
                environments={ },
                volumes=[],
                ports={"3100/tcp": 3100},
            )
        )
        grafana_sources.append(
            GrafanaSource(
                name=f"{project.name}-Loki",
                type="loki",
                url=AnyUrl(base_url)
            )
        )

    if grafana_sources:
        name = f"{project.name}-grafana"

        grafana_dir = data_dir / "grafana"
        grafana_dir.mkdir(exist_ok=True, parents=True)

        grafana_source_file = grafana_dir / "sources.yaml"

        file = GrafanaSourcesFile(datasources=grafana_sources)
        grafana_source_file.write_text(yaml.dump(json.loads(file.model_dump_json())))


        containers.append(
            Container(
                name=name,
                image="grafana/grafana:11.0.0",
                restart="always",
                environments={ 
                    "GF_AUTH_ANONYMOUS_ENABLED": "true",
                    "GF_AUTH_ANONYMOUS_ORG_ROLE": "Admin",
                    "GF_AUTH_DISABLE_LOGIN_FORM": "true",
                    "GF_SECURITY_ALLOW_EMBEDDING": "true",
                },
                volumes=[f"{grafana_source_file.as_posix()}:/etc/grafana/provisioning/datasources/datasources.yaml"],
                ports={"3000/tcp": 3000},
            )
        )

    if ResourceTags.opensearch_url in needed_res or ResourceTags.opensearch_host in needed_res:
        name = f"{project.name}-opensearch"
        port = 9200
        user = "admin"
        password = "mT7#kQ2$vL9p"

        resource_values[ResourceTags.opensearch_url] = f"http://{name}:{port}"
        resource_values[ResourceTags.opensearch_host] = name
        resource_values[ResourceTags.opensearch_port] = str(port)
        resource_values[ResourceTags.opensearch_password] = password
        resource_values[ResourceTags.opensearch_user] = user

        containers.append(
            Container(
                name=name,
                image="opensearchproject/opensearch:2",
                restart="always",
                environments={
                    "OPENSEARCH_INITIAL_ADMIN_PASSWORD": password,
                    "discovery.type": "single-node"
                },
                volumes=[f"{data_dir.as_posix()}/opensearch:/usr/share/opensearch/data"],
                ports={
                    f"{port}/tcp": port
                },
            )
        )

    if ResourceTags.mongo_dsn in needed_res:
        name = f"{project.name}-mongo"
        protocol = "mongodb"
        port = 27017
        user = "user"
        password = "pass"

        resource_values[ResourceTags.mongo_dsn] = f"{protocol}://{user}:{password}@{name}:{port}"
        resource_values[ResourceTags.mongo_port] = str(port)
        resource_values[ResourceTags.mongo_host] = name
        resource_values[ResourceTags.mongo_username] = user
        resource_values[ResourceTags.mongo_password] = password
        resource_values[ResourceTags.mongo_ssl] = "false"

        containers.append(
            Container(
                name=name,
                image="mongo:7.0.11",
                restart="always",
                environments={
                    "MONGO_INITDB_ROOT_PASSWORD": password,
                    "MONGO_INITDB_ROOT_USERNAME": user
                },
                volumes=[f"{data_dir.as_posix()}/mongo:/data"],
                ports={f"{port}/tcp": port},
            )
        )

    if ResourceTags.mysql_dsn in needed_res:
        name = f"{project.name}-mysql"
        protocol = "mysql"
        port = 3306
        db = "db"
        user = "root"
        password = "pass"

        resource_values[ResourceTags.mysql_dsn] = f"{protocol}://{user}:{password}@{name}:{port}/{db}"
        resource_values[ResourceTags.mysql_port] = str(port)
        resource_values[ResourceTags.mysql_host] = name
        resource_values[ResourceTags.mysql_username] = user
        resource_values[ResourceTags.mysql_password] = password
        resource_values[ResourceTags.mysql_db] = db

        containers.append(
            Container(
                name=name,
                image="mysql:8",
                restart="always",
                environments={
                    "MYSQL_ROOT_PASSWORD": password,
                    "MYSQL_DATABASE": db,
                },
                volumes=[f"{data_dir.as_posix()}/mysql:/var/lib/mysql"],
                ports={f"{port}/tcp": port},
            )
        )


    if ResourceTags.psql_dsn in needed_res:
        name = f"{project.name}-psql"
        protocol = "postgresql"

        with suppress(ImportError):
            import psycopg
            protocol = "postgresql+psycopg"

        with suppress(ImportError):
            import psycopg2
            protocol = "postgresql+psycopg2"

        with suppress(ImportError):
            import asyncpg
            protocol = "postgresql+asyncpg"


        user = "user"
        password = "pass"
        database = "db"

        resource_values[ResourceTags.psql_dsn] = f"{protocol}://{user}:{password}@{name}:5432/{database}"
        resource_values[ResourceTags.psql_port] = "5432"
        resource_values[ResourceTags.psql_host] = name
        resource_values[ResourceTags.psql_name] = database
        resource_values[ResourceTags.psql_username] = user
        resource_values[ResourceTags.psql_password] = password
        resource_values[ResourceTags.psql_ssl] = "false"

        containers.append(
            Container(
                name=name,
                image="postgres:16",
                restart="always",
                environments={
                    "POSTGRES_USER": user,
                    "POSTGRES_PASSWORD": password,
                    "POSTGRES_DB": database
                },
                volumes=[f"{data_dir.as_posix()}/postgresql:/var/lib/postgresql/data"],
                ports={"5432/tcp": 5432},
            )
        )

    if ResourceTags.redis_dsn in needed_res:
        name = f"{project.name}-redis"
        resource_values[ResourceTags.redis_dsn] = f"redis://{name}:6379"
        resource_values[ResourceTags.redis_username] = ""
        resource_values[ResourceTags.redis_password] = ""
        containers.append(
            Container(
                name=name,
                image="redis:7.2.11",
                restart="always",
                environments={},
                volumes=[
                    f"{data_dir.as_posix()}/valkey:/data"
                ],
                ports={"6379/tcp": 6379},
            )
        )


    if ResourceTags.kafka_dsn in needed_res or ResourceTags.kafka_bootstrap_servers in needed_res:
        name = f"{project.name}-kafka"
        port = 9092

        resource_values[ResourceTags.kafka_dsn] = f"kafka://{name}:{port}"
        resource_values[ResourceTags.kafka_bootstrap_servers] = f"{name}:{port}"
        resource_values[ResourceTags.kafka_host] = name
        resource_values[ResourceTags.kafka_port] = str(port)

        containers.append(
            Container(
                name=name,
                image="apache/kafka:3.8.0",
                restart="always",
                environments={
                    "KAFKA_NODE_ID": "1",
                    "KAFKA_PROCESS_ROLES": "broker,controller",
                    "KAFKA_LISTENERS": f"PLAINTEXT://:{port},CONTROLLER://:9093",
                    "KAFKA_ADVERTISED_LISTENERS": f"PLAINTEXT://{name}:{port}",
                    "KAFKA_CONTROLLER_LISTENER_NAMES": "CONTROLLER",
                    "KAFKA_LISTENER_SECURITY_PROTOCOL_MAP": "CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT",
                    "KAFKA_CONTROLLER_QUORUM_VOTERS": f"1@{name}:9093",
                    "KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR": "1",
                    "KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR": "1",
                    "KAFKA_TRANSACTION_STATE_LOG_MIN_ISR": "1",
                    "KAFKA_LOG_DIRS": "/var/lib/kafka/data",
                },
                volumes=[f"{data_dir.as_posix()}/kafka:/var/lib/kafka/data"],
                ports={f"{port}/tcp": port},
            )
        )

    if ResourceTags.clickhouse_dsn in needed_res or ResourceTags.clickhouse_host in needed_res:
        name = f"{project.name}-clickhouse"
        port = 9000
        http_port = 8123
        user = "user"
        password = "pass"
        database = "db"

        resource_values[ResourceTags.clickhouse_dsn] = f"clickhouse://{user}:{password}@{name}:{port}/{database}"
        resource_values[ResourceTags.clickhouse_host] = name
        resource_values[ResourceTags.clickhouse_port] = str(port)
        resource_values[ResourceTags.clickhouse_username] = user
        resource_values[ResourceTags.clickhouse_password] = password
        resource_values[ResourceTags.clickhouse_database] = database

        containers.append(
            Container(
                name=name,
                image="clickhouse/clickhouse-server:25.8",
                restart="always",
                environments={
                    "CLICKHOUSE_USER": user,
                    "CLICKHOUSE_PASSWORD": password,
                    "CLICKHOUSE_DB": database,
                },
                volumes=[f"{data_dir.as_posix()}/clickhouse:/var/lib/clickhouse"],
                ports={
                    f"{http_port}/tcp": http_port,
                    f"{port}/tcp": port,
                },
            )
        )

    if ResourceTags.spark_master_url in needed_res or ResourceTags.spark_connect_url in needed_res:
        name = f"{project.name}-spark"
        sc_port = 15002
        spark_port = 7077
        ui_port = 8080

        resource_values[ResourceTags.spark_connect_url] = f"sc://{name}:{sc_port}"
        resource_values[ResourceTags.spark_master_url] = f"spark://{name}:{spark_port}"
        resource_values[ResourceTags.spark_ui_url] = f"http://{name}:{ui_port}"

        containers.append(
            Container(
                name=name,
                image="spark:4.0.1",
                restart="always",
                environments={
                    # "SPARK_MODE": "master",
                    "SPARK_MASTER_HOST": name,
                    "SPARK_MASTER_PORT": f"{spark_port}",
                    "SPARK_MASTER_WEBUI_PORT": f"{ui_port}",
                },
                volumes=[
                    f"{data_dir.as_posix()}/sprk:/opt/spark/work-dir/spark-warehouse/data"
                ],
                ports={
                    f"{spark_port}/tcp": spark_port,
                    f"{ui_port}/tcp": ui_port,
                    f"{sc_port}/tcp": sc_port,
                },
                command=[
                    "bash",
                    "-c",
                    f"/opt/spark/sbin/start-master.sh && tail -f /dev/null & sleep 5 && /opt/spark/bin/spark-class org.apache.spark.deploy.worker.Worker spark://{name}:{spark_port} & sleep 5 && /opt/spark/sbin/start-connect-server.sh --master spark://{name}:{spark_port} --conf spark.jars.ivy=/tmp/.ivy2 && tail -f $(ls /opt/spark/logs/spark-*SparkConnectServer*.out | head -1)"
                ]
            )
        )


    if project.subscribers or ResourceTags.nats_dsn in needed_res:
        name = f"{project.name}-nats"
        nats_url = f"nats://{name}:4222"

        resource_values[ResourceTags.nats_dsn] = nats_url
        containers.append(
            Container(
                name=name,
                image="nats:2.12.2-alpine",
                restart="always",
                environments={},
                volumes=[],
                ports={"4222/tcp": 4222},
            )
        )


    needs_localstack = False

    if ResourceTags.s3_secret_key in needed_res:
        needs_localstack = True

    if needs_localstack or project.workers:
        name = f"{project.name}-infra"

        resource_values.update({
            ResourceTags.sqs_endpoint: f"http://{name}:4566",
            ResourceTags.sqs_access_key: "local",
            ResourceTags.sqs_secret_key: "local",
            ResourceTags.sqs_region_name: "us-east-1",

            ResourceTags.s3_endpoint: f"http://{name}:4566",
            ResourceTags.s3_access_key: "local",
            ResourceTags.s3_secret_key: "local",
            ResourceTags.s3_region_name: "us-east-1",
            ResourceTags.s3_bucket_name: "local",
        })

        containers.append(
            Container(
                name=name,
                image="localstack/localstack",
                restart="always",
                ports={"4566/tcp": 4566},
                environments={},
                volumes=[
                    "/var/run/docker.sock:/var/run/docker.sock",
                    f"{data_dir.as_posix()}/localstack:/var/lib/localstack"
                ],
            )
        )

    return (containers, resource_values)


def setup_resource() -> None:
    pass


def stream_container(
    container_id: str,
    container_type: Literal["resource", "app", "worker", "subscriber", "primary"],
    event: Event | None = None
) -> None:
    color_map = {
        "resource": "blue",
        "app": "yellow",
        "worker": "green",
        "subscriber": "red",
        "primary": "bold magenta",
        "other": "cyan"
    }

    color = color_map.get(container_type, "cyan")
    is_primary = container_type == "primary"


    try:
        client = DockerClient.from_env()

        container = client.containers.get(container_id)
        console.print(f"[dim]  Waiting for {container.name} to start...[/dim]")

        is_ready_and_healthy = False

        wait_loops = -1

        log_load = None



        while not is_ready_and_healthy:
            wait_loops += 1
            sleep(0.5)

            if container.status == "exited":

                status = container.attrs.get("State", {})
                exit_code = status.get("ExitCode")
                error = status.get("Error")

                console.print(f"Container {container.name} {container.status} with exit code {exit_code}")
                console.print(container.logs(stream=False).decode())

                if event:
                    event.set()
                return

            try:
                container.reload()
            except HTTPError as e:
                if e.response.status_code == 404:
                    console.print(f"[bold red]Unable to find image. Most likely due to error at startup. {container.short_id}[/bold red]")
                raise e

            if container.status != "running":
                continue

            if 'Health' not in container.attrs['State']:
                is_ready_and_healthy = True
                console.print(f"[bold green]✓[/bold green] {container.name} is running")

                if event: 
                    event.set()

                continue

            health_status = container.attrs['State']['Health']['Status']

            if health_status == 'healthy':
                is_ready_and_healthy = True
                console.print(f"[bold green]✓[/bold green] {container.name} is running")

                if event: 
                    event.set()
            elif wait_loops % 5 == 0:
                console.print(f"[bold yellow]✓[/bold yellow] waiting for {container.name} to get healthy.")

                with suppress(Exception):
                    load_from = log_load
                    log_load = datetime.now()
                    logs = container.logs(since=load_from)

                    for line in logs.decode('utf-8').splitlines():
                        log_text = Text()
                        if is_primary:
                            log_text.append(">>> ", style="bold magenta")
                        log_text.append(f"[{container.name}]", style=f"bold {color}")
                        log_text.append(" ")
                        log_text.append(line.rstrip())
                        console.print(log_text)


    except HTTPError as e:
        if e.response.status_code != 404:
            raise e

        if event:
            event.set()
        return
    except Exception as e:
        console.print(f"[dim] And error occured at startup for {container_id}[/dim]")
        logger.exception(e)
        if event:
            event.set()
        return

    try:
        console.print(f"Starting to follow logs for [bold {color}]{container.name}[/bold {color}]")
        for log in client.api.logs(container_id, stream=True, follow=True):
            log_text = Text()
            if is_primary:
                log_text.append(">>> ", style="bold magenta")
            log_text.append(f"[{container.name}]", style=f"bold {color}")
            log_text.append(" ")
            log_text.append(log.decode('utf-8').rstrip())
            console.print(log_text)


    except Exception:
        console.print(f"[bold red]Run docker inspect {container_id} to get more info[/bold red]")

    cont = client.containers.get(container_id)

    status = cont.attrs.get("State", {})
    exit_code = status.get("ExitCode")
    error = status.get("Error")
    is_oom_killed = status.get("OOMKilled")

    console.print(f"Container {cont.name} {cont.status} with exit code {exit_code}")

    if is_oom_killed:
        logger.error(f"OOM! Consider increasing the the memory limit of {cont.name}")

    if error:
        logger.error(f"Container had error message {error}")


def dev_volumes(
    project: Project, 
    current_dir: Path, 
    sub_source_dir: str,
    with_tests: bool = False,
    can_write: bool = False
) -> dict[str, dict[str, str]]:
    source_dir = f"/app/{sub_source_dir}"

    if (current_dir / project.name).is_dir():
        src_dir = current_dir / project.name
        volumes = {
            src_dir.absolute().as_posix(): {
                "bind": f"{source_dir}/{src_dir.name}",
                "mode": "rw" if can_write else "ro"
            }
        }
    elif (current_dir / "src").is_dir():
        src_dir = current_dir / "src"
        volumes = {
            src_dir.absolute().as_posix(): {
                "bind": f"{source_dir}/{src_dir.name}",
                "mode": "rw" if can_write else "ro"
            }
        }
    else:
        import os
        src_dir = current_dir
        volumes = {}

        ignore_paths = [".venv", "venv", ".git", ".cursor", "tests", "__pycache__", ".github"]

        for sub_dir in os.listdir(src_dir.as_posix()):

            if sub_dir in ignore_paths:
                continue

            sub_path = src_dir / sub_dir

            if sub_path.is_dir():
                volumes[sub_path.absolute().as_posix()] = {
                    "bind": f"{source_dir}/{sub_dir}",
                    "mode": "rw" if can_write else "ro"
                }

    project_file = current_dir / "project.py"
    if project_file.is_file():
        volumes[project_file.absolute().as_posix()] = {
            "bind": f"{source_dir}/{project_file.name}",
            "mode": "rw" if can_write else "ro"
        }


    for path in project.additional_dirs or []:
        if path.is_dir() or path.is_file():
            volumes[path.absolute().as_posix()] = {
                "bind": f"{source_dir}/{path.as_posix()}",
                "mode": "rw" if can_write else "ro"
            }


    if with_tests:
        for path in project.testing_dirs or []:
            if path.is_dir() or path.is_file():
                volumes[path.absolute().as_posix()] = {
                    "bind": f"{source_dir}/{path.as_posix()}",
                    "mode": "rw" if can_write else "ro"
                }

    return volumes


def prepare_project(project: Project, context: str | None, dockerfile: str | None) -> ProjectContainer:
    client = DockerClient.from_env()

    should_build = True

    lockfile = find_lockfile()
    lockhash = sha256(lockfile.read_bytes(), usedforsecurity=False).hexdigest()

    try:
        image = client.images.get(name=f"{project.name}:latest")
        labels = image.attrs.get("Config", {}).get("Labels", {})
        stored_hash = str(labels.get(ImageKeys.lock_hash, ""))

        logger.debug(f"Stored hash: '{stored_hash}' is compared against hash: '{lockhash}'")
        logger.debug(f"Are they equal? '{stored_hash == lockhash}'")

        if stored_hash == lockhash:
            should_build = False
    except HTTPError as e:
        if e.response.status_code != 404:
            logger.exception(e)
            raise e

    if should_build:
        console.print(f"[bold blue]Building image for {project.name}...[/bold blue]")
        build_image(project, tags="latest", context=context, dockerfile_path=dockerfile)
        console.print("[bold green]✓[/bold green] Image built successfully")

    image = client.images.get(name=f"{project.name}:latest")
    labels = image.attrs.get("Config", {}).get("Labels", {})

    source_dir = labels.get(ImageKeys.source_dir, "")

    return ProjectContainer(source_dir=source_dir)


def stream_docker_logs(generator: Generator[dict[str, Any], None, None]):

    ids: set[str] = set()
    rows: dict[str, tuple[str, dict]] = {}
    error: str | None = None

    def build_table() -> Group:
        components: Sequence[Text | Table] = []
        has_added_table = False

        table = Table(show_header=False, box=None, pad_edge=False)
        table.add_column("ID", style="cyan", width=14)
        table.add_column("Status", width=24)
        table.add_column("Progress", width=40)

        for layer_id, (status, detail) in rows.items():

            if layer_id not in ids:
                components.append(
                    Text(layer_id)
                )
                continue

            if not has_added_table:
                components.append(table)
                has_added_table = True

            current = detail.get("current")
            total = detail.get("total")
            if current is not None and total:
                bar = ProgressBar(total=total, completed=current, width=30)
                table.add_row(layer_id, status, bar)
            else:
                table.add_row(layer_id, status, Text(""))
        return Group(*components)

    with Live(build_table(), refresh_per_second=12) as live:
        for line in generator:
            if "error" in line:
                error = line["error"]
                break
            layer_id = line.get("id")
            status = line.get("status", "")
            detail = line.get("progressDetail", {}) or {}
            if layer_id:
                rows[layer_id] = (status, detail)
                ids.add(layer_id)
            else:
                rows[status] = ("", {})
            live.update(build_table())

    return error



def compose(
    project: Project,
    base_image: str,
    volumes: dict[str, dict[str, str]],
    env_file: str | None,
    components: list[str] | None = None,
    client: DockerClient | None = None,
    data_dir: Path | None = None,
    primary_container: CompiledJob | None = None,
    env: Environments | None = None,
    use_ollama: bool = False
) -> int | None:
    from dotenv.main import dotenv_values, find_dotenv
    from docker.models.containers import Container as ContainerType

    console.print()
    console.print(Panel(
        f"Starting project: [bold cyan]{project.name}[/bold cyan]\n"
        f"Base image: [dim]{base_image}[/dim]",
        title="Docker Compose",
        border_style="blue",
        title_align="left"
    ))


    env_file = env_file or find_dotenv() or ".env"
    dotenvs = dotenv_values(dotenv_path=env_file)

    if not env:
        env = "dev"
    
    dotenvs.update(TakkEnvironment(nobs_env=env).model_dump())

    client = client or DockerClient.from_env()
    containers: list[ContainerType] = []
    log_treads: list[Thread] = []

    compiled = CompiledProject.from_project(project, packages=[])

    networks = [
        net for net in client.networks.list()
        if net.name == project.name
    ]
    platform_arc = "linux/amd64"

    container_labels = ["takk", project.name]
    conts: list[ContainerType] = client.containers.list(
        all=True, filters={"label": container_labels}
    )

    existing_resources: list[str] = []

    if components is not None:
        components = [
            f"{project.name}-{comp}" for comp in components
        ]

    for cont in conts:
        if primary_container:
            cont.remove(force=True)
        elif "resource" not in cont.labels and (components is None or cont.name in components):
            cont.remove(force=True)
        else:
            existing_resources.append(cont.name) # type: ignore

    other_containers: list[ContainerType] = client.containers.list(all=True)
    exposed_ports: list[int] = exposed_ports_at_host()
    for container in other_containers:
        for vals in container.ports.values():
            if vals:
                exposed_ports.extend(
                    [
                        int(val.get("HostPort"))
                        for val in vals
                    ]
                )

    def unexposed_ports(ports: dict[str, int]) -> dict[str, int]:
        new_ports = {}
        for internal_port, exposed_port in ports.items():
            modified_port = exposed_port
            while modified_port in exposed_ports:
                modified_port += 1
            new_ports[internal_port] = modified_port
            exposed_ports.append(modified_port)
        return new_ports

    if networks:
        network = networks[0]
    else:
        network = client.networks.create(name=project.name, driver="bridge")

    application_volume = volumes
    resource_containers, resource_values = needed_containers(compiled, dotenvs, data_dir)

    new_exposed_ports: dict[str, list[int]] = {}

    resource_ready: list[Event] = []

    # Pulling all images first to make sure the TUI is rendered correctly
    for container in resource_containers:
        if container.name in existing_resources:
            continue

        try:
            image = client.images.get(container.image)
            console.print(f"Found local image {image.tags}")
        except Exception as _:
            console.print(f"Pulling image '{container.image}'")
            repo, _, tag = container.image.partition(":")

            stream_docker_logs(client.api.pull(repository=repo, tag=tag, stream=True, decode=True))


    for container in resource_containers:
        if container.name in existing_resources:
            console.print(f"[bold blue]→[/bold blue] Using existing resource: [cyan]{container.name}[/cyan]")
            continue

        console.print(f"[bold blue]→[/bold blue] Creating resource: [cyan]{container.name}[/cyan]")

        new_ports = unexposed_ports(container.ports)
        new_exposed_ports[container.name] = list(new_ports.values())
        event = Event()

        resource_ready.append(event)

        cont = client.containers.run(
            image=container.image,
            environment=container.environments,
            volumes=container.volumes,
            ports=new_ports,
            network=network.name,
            name=container.name,
            labels=[*container_labels, "resource"],
            detach=True,
            remove=True,
            command=container.command
            # restart_policy=container.restart,
            # ports=container.ports,
        )

        containers.append(cont)
        thread = Thread(target=stream_container, args=(cont.id, "resource", event))
        thread.daemon = True
        thread.start()
        log_treads.append(thread)



    for event in resource_ready:
        event.wait(60)

    shared_secrets: dict[str, str] = {}

    for container in compiled.network_apps:

        name = f"{project.name}-{container.name}"
        new_ports = unexposed_ports({f"{container.port}/tcp": container.port})
        new_exposed_ports[name] = list(new_ports.values())

        port = next(iter(new_exposed_ports[name]))

        resource_values[ServiceUrl(container.name, "internal").to_string()] = f"http://{name}:{container.port}"
        resource_values[ServiceUrl(container.name, "external").to_string()] = f"http://localhost:{port}"


    if use_ollama:
        resource_values[ResourceTags.llm_token] = "ollama"
        resource_values[ResourceTags.llm_base_url] = "http://host.docker.internal:11434"
        resource_values[ResourceTags.llm_base_api] = "http://host.docker.internal:11434/v1"


    for secret_type in project.shared_secrets or []:
        shared_secrets.update(
            settings_for_secrets(
                secrets_for(secret_type),
                resource_values, 
            )
        )

    if ResourceTags.s3_secret_key in resource_values:
        import boto3
        conf = settings_for_resources(resource_values, S3StorageConfig)

        assert conf.s3_endpoint
        url = conf.s3_endpoint.encoded_string().replace(conf.s3_endpoint.host or "", "localhost")

        s3 = boto3.client(
            "s3",
            endpoint_url=url,
            aws_access_key_id=conf.s3_access_key,
            aws_secret_access_key=conf.s3_secret_key.get_secret_value(),
            region_name=conf.s3_region
        )
        try:
            s3.head_bucket(Bucket=conf.s3_bucket)
            logger.info(f"Bucket '{conf.s3_bucket}' already exists")
        except Exception:
            logger.info(f"Creating bucket '{conf.s3_bucket}'")
            s3.create_bucket(Bucket=conf.s3_bucket)
            logger.info(f"Created bucket '{conf.s3_bucket}'")


    health_events: list[Event] = []

    for container in compiled.network_apps:

        if components is not None and container.name not in components:
            continue

        console.print(f"[bold blue]→[/bold blue] Creating app: [yellow]{container.name}[/yellow]")

        envs = settings_for_secrets(
            container.secrets or [], resource_values
        )

        if container.command:
            if "uvicorn" in container.command[-1] and "--reload" not in container.command:
                container.command[-1] = container.command[-1] + " --reload"

            if "guvicorn" in container.command[-1] and "--reload" not in container.command:
                container.command[-1] = container.command[-1] + " --reload"

            if "fastapi" in container.command[-1]:
                container.command[-1] = container.command[-1].replace("run", "dev")


        name = f"{project.name}-{container.name}"
        new_ports = {f"{container.port}/tcp": new_exposed_ports[name][0]}


        healthcheck = None
        health_event = None
        if container.health_check:
            check = container.health_check
            healthcheck = {
                "test": ["CMD", "python", "-c", f"import urllib.request; urllib.request.urlopen('http://localhost:{container.port}{check.url}')" ],
                "interval": check.interval * 1_000_000_000,  # 10 seconds in nanoseconds
                "timeout": check.timeout * 1_000_000_000,    # 5 seconds in nanoseconds
                "retries": check.retries,
                "start_period": 10_000_000_000
            }
            health_event = Event()
            health_events.append(health_event)


        console.print(f"[bold blue]→[/bold blue] Starting up: [yellow]{container.name}[/yellow]")
        cont = client.containers.run(
            image=container.docker_image or base_image,
            name=name,
            environment={
                **(container.environments or {}),
                **envs,
                **shared_secrets,
                **{
                    key: value for key, value 
                    in dotenvs.items()
                    if key not in envs and key not in shared_secrets and value
                }
            },
            volumes=application_volume,
            command=container.command,
            network=network.name,
            detach=True,
            labels=container_labels,
            ports=new_ports,
            mem_limit=f"{container.compute.mb_memory_limit}m",
            cpu_quota=container.compute.mvcpu_limit * 100,
            cpu_period=100_000,
            platform=platform_arc,
            healthcheck=healthcheck
        )
        containers.append(cont)

        thread = Thread(target=stream_container, args=(cont.id, "app", health_event))
        thread.daemon = True
        thread.start()
        log_treads.append(thread)


    for container in compiled.subscribers:
        if components is not None and container.name not in components:
            continue

        envs = settings_for_secrets(
            container.secrets or [], resource_values
        )

        console.print(f"[bold blue]→[/bold blue] Creating subscriber: [red]{container.name}[/red]")
        cont = client.containers.run(
            image=base_image,
            name=f"{project.name}-{container.name}",
            environment={
                **(container.environments or {}),
                **envs,
                **shared_secrets,
                **{
                    key: value for key, value 
                    in dotenvs.items()
                    if key not in envs and key not in shared_secrets and value
                }
            },
            volumes=application_volume,
            command=["/bin/bash", "-c", f"nobs subscriber {container.name}"],
            network=network.name,
            detach=True,
            labels=container_labels,
            cpu_quota=container.compute.mvcpu_limit * 100,
            cpu_period=100_000,
            mem_limit=f"{container.compute.mb_memory_limit}m",
            platform=platform_arc,
        )

        containers.append(cont)

        thread = Thread(target=stream_container, args=(cont.id, "subscriber"))
        thread.daemon = True
        thread.start()
        log_treads.append(thread)


    for container in compiled.workers:
        if components is not None and container.name not in components:
            continue

        envs = settings_for_secrets(
            container.secrets or [], resource_values
        )
        console.print(f"[bold blue]→[/bold blue] Creating worker: [green]{container.name}[/green]")
        cont = client.containers.run(
            image=base_image,
            name=f"{project.name}-{container.name}",
            environment={ 
                **envs,
                **shared_secrets,
                **{
                    key: value for key, value 
                    in dotenvs.items()
                    if key not in envs and key not in shared_secrets and value
                }
            },
            volumes=application_volume,
            command=["/bin/bash", "-c", f"nobs process-queue {container.name}"],
            network=network.name,
            detach=True,
            labels=container_labels,
            cpu_quota=container.compute.mvcpu_limit * 100,
            cpu_period=100_000,
            mem_limit=f"{container.compute.mb_memory_limit}m",
            platform=platform_arc,
        )

        containers.append(cont)

        thread = Thread(target=stream_container, args=(cont.id, "worker"))
        thread.daemon = True
        thread.start()
        log_treads.append(thread)

    if components:
        for container in compiled.jobs:
            envs = settings_for_secrets(
                container.secrets or [], resource_values
            )
            console.print(f"[bold blue]→[/bold blue] Running job: [green]{container.name}[/green]")
            cont = client.containers.run(
                image=base_image,
                name=f"{project.name}-{container.name}",
                environment={ 
                    **envs,
                    **shared_secrets,
                    **{
                        key: value for key, value 
                        in dotenvs.items()
                        if key not in envs and key not in shared_secrets and value
                    }
                },
                volumes=application_volume,
                command=["/bin/bash", "-c", container.command(project.name)],
                network=network.name,
                detach=True,
                labels=container_labels,
                cpu_quota=container.compute.mvcpu_limit * 100,
                cpu_period=100_000,
                mem_limit=f"{container.compute.mb_memory_limit}m",
                platform=platform_arc,
            )

            containers.append(cont)

            thread = Thread(target=stream_container, args=(cont.id, "worker"))
            thread.daemon = True
            thread.start()
            log_treads.append(thread)





    table = Table(title="Running Containers", show_header=True, header_style="bold magenta")
    table.add_column("Container", style="cyan", no_wrap=True)
    table.add_column("ID", style="dim")
    table.add_column("Type", style="green")
    table.add_column("Access", style="blue")
    table.add_column("Credentials", style="blue")

    resource_names = {rc.name for rc in resource_containers}
    app_names = {f"{project.name}-{app.name}" for app in compiled.network_apps}
    worker_names = {f"{project.name}-{worker.name}" for worker in compiled.workers}
    subscriber_names = {f"{project.name}-{sub.name}" for sub in compiled.subscribers}

    conts: list[ContainerType] = client.containers.list(
        all=True, filters={"label": container_labels}
    )

    for container in conts:
        ports = new_exposed_ports.get(container.name or "Unknown", [])

        credentials = ""

        container_type = "other"
        if container.name in resource_names:
            container_type = "resource"

            if container.name == f"{project.name}-psql":
                print_values = {
                    "Username": ResourceTags.database_username,
                    "Password": ResourceTags.database_password,
                    "Database": ResourceTags.database_name
                }
                credentials = "\n".join([
                    f"{key}: {resource_values.get(value, '')}" for key, value in print_values.items()
                ])

            if container.name == f"{project.name}-redis":
                print_values = {
                    "Username": ResourceTags.redis_username,
                    "Password": ResourceTags.redis_password,
                }
                credentials = "\n".join([
                    f"{key}: {resource_values.get(value, '')}" for key, value in print_values.items()
                ])
        elif container.name in app_names:
            container_type = "app"
        elif container.name in worker_names:
            container_type = "worker"
        elif container.name in subscriber_names:
            container_type = "subscriber"

        if ports:
            port_numbers = sorted(ports)
            
            if len(port_numbers) > 3:
                min_port = min(port_numbers)
                max_port = max(port_numbers)
                access_urls = f"http://localhost:{min_port}-{max_port}"
            else:
                access_urls = "\n".join([
                    f"http://localhost:{port}"
                    for port in port_numbers
                ])
        else:
            access_urls = "background"

        table.add_row(
            container.name,
            container.id[:12],
            container_type,
            access_urls, 
            credentials
        )

    console.print()
    console.print(table)
    console.print()

    for event in health_events:
        event.wait(60)


    def shutdown_containers(reason: str, border_style: str = "red") -> None:
        console.print()
        console.print(Panel(
            reason,
            title="Shutdown",
            border_style=border_style,
            title_align="left"
        ))
        for container in reversed(containers):
            console.print(f"[dim]Stopping {container.name}...[/dim]")
            with suppress(Exception):
                container.stop()
        console.print("[bold green]✓[/bold green] All containers stopped")

    if primary_container:
        envs = settings_for_secrets(
            primary_container.secrets or [], resource_values
        )
        container_full_name = f"{project.name}-{primary_container.name}"
        console.print(f"[bold blue]→[/bold blue] Running primary: [bold magenta]{container.name}[/bold magenta]")

        cont = client.containers.run(
            image=base_image,
            name=container_full_name,
            environment={
                **envs,
                **shared_secrets,
                **{
                    key: value for key, value
                    in dotenvs.items()
                    if key not in envs and key not in shared_secrets and value
                }
            },
            volumes=application_volume,
            command=["/bin/bash", "-c", primary_container.command(project.name)],
            network=network.name,
            detach=True,
            labels=container_labels,
            cpu_quota=primary_container.compute.mvcpu_limit * 100,
            cpu_period=100_000,
            mem_limit=f"{primary_container.compute.mb_memory_limit}m",
            platform=platform_arc,
        )

        thread = Thread(target=stream_container, args=(cont.id, "worker"))
        thread.daemon = True
        thread.start()
        log_treads.append(thread)

        try:
            result = cont.wait()
            exit_code = result.get("StatusCode", 1)

            if exit_code == 0:
                shutdown_containers("Primary container completed successfully", "green")
            else:
                shutdown_containers(f"Primary container exited with code {exit_code}", "red")

            return exit_code
        except KeyboardInterrupt:
            shutdown_containers("Received shutdown signal, stopping all containers...")
            return 130
    else:
        try:
            while True:
                sleep(10000)
        except KeyboardInterrupt:
            shutdown_containers("Received shutdown signal, stopping all containers...")

    return None


def default_docker_image(
    uv_image: str, 
    source_code_dir: str, 
    pre_lock_add: str,
    lock_file: Path,
    pyproject_file: Path,
    project_file: Path,
    copy_additional_dirs: str,
    copy_path_packages: str,
    source_dir: Path,
    uv_sync_args: str | None = None
) -> str:

    docker_source = "/app" / source_dir

    if not uv_sync_args:
        uv_sync_args = "--locked --no-editable --active"

    return f"""FROM {uv_image} AS builder

WORKDIR /app

{pre_lock_add}
{copy_path_packages}
{copy_additional_dirs}

COPY {lock_file} {docker_source}/uv.lock
COPY {pyproject_file} {docker_source}/pyproject.toml

WORKDIR {docker_source}

ENV UV_SYSTEM_PYTHON=true 
RUN uv venv {docker_source}/.venv --python $(which python)
ENV VIRTUAL_ENV={docker_source}/.venv
RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync {uv_sync_args} --no-install-project 

COPY {source_dir / source_code_dir} {docker_source / source_code_dir}

RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync {uv_sync_args}

FROM {uv_image}

COPY --from=builder --chown=app:app {docker_source}/.venv {docker_source}/.venv

WORKDIR {docker_source}

{copy_additional_dirs}
COPY {project_file} {docker_source / 'project.py'}
COPY {source_dir / source_code_dir} {docker_source / source_code_dir}

ENV PATH="{docker_source}/.venv/bin:$PATH"
"""


def create_dockerfile_for(
    project: Project, dockerfile: Path, pyproject: Path, lockfile: Path, path_packages: list[str], python_version: str, uv_sync_args: str | None = None
) -> tuple[Path, Path]:
    import os

    context = Path(".")
    source_dir_sub_dir = Path()

    if path_packages:
        context = Path(os.path.commonpath([
            context.resolve(),
            *[
                Path(path).resolve() 
                for path in path_packages
            ]
        ]))
        source_dir_sub_dir = Path(".").resolve().relative_to(context)


    def copy_from_path(path: Path) -> str:
        if context.resolve() == Path(".").resolve():
            return path.as_posix()
        return path.resolve().relative_to(context.resolve()).as_posix()

    source_code_dir_name = "src" 
    source_code_dir = source_dir_sub_dir / source_code_dir_name

    if not (context / source_code_dir).is_dir():
        source_code_dir_name = project.name.replace("-", "_").replace("/", "")
        source_code_dir = source_dir_sub_dir / source_code_dir_name

    if not (context / source_code_dir).is_dir():
        source_code_dir = source_dir_sub_dir.resolve()
        source_code_dir_name = ""

    uv_image = f"ghcr.io/astral-sh/uv:python{python_version}-bookworm-slim"

    if not (context / source_code_dir).is_dir():
        raise ValueError(f"Expected to find source code at '{context / source_code_dir}', but found nothing.")

    pre_lock_add = ""
    copy_additional_dirs = ""
    copy_path_packages = ""

    apt_packages = set()

    deps = pyproject.read_text()
    if "git =" in deps or "git=" in deps:
        # Install git so that git dependencies can be loaded in the slim image
        apt_packages.add("git")
        pre_lock_add += "RUN apt-get update && apt-get install -y git && rm -rf /var/lib/apt/lists/*\n"

    if "psycopg2-binary" in deps:
        apt_packages.update(["libpq-dev", "gcc"])

    if "pyodbc" in deps:
        apt_packages.add("g++")

    if apt_packages:
        packages = " ".join(sorted(apt_packages))
        pre_lock_add += f"RUN apt-get update && apt-get install -y {packages} && rm -rf /var/lib/apt/lists/*\n"


    if path_packages:
        rel_source = source_code_dir.resolve().relative_to(context.resolve())
        for path in path_packages:
            package_path = Path(path).resolve()
            rel_path = package_path.relative_to(context)

            if rel_path == rel_source or rel_source.is_relative_to(rel_path):
                logger.debug(f"Skipping to add package at '{rel_path}' as it contains the source code.")
                continue

            copy_path_packages += f"COPY {rel_path.as_posix()} /app/{rel_path.as_posix()}\n"

    if project.additional_dirs:
        copy_additional_dirs += "\n".join([
            f"COPY {copy_from_path(path)} /app/{source_dir_sub_dir / path.as_posix()}"
            for path in project.additional_dirs
        ])

    project_file = "project.py"

    if "workspace = " in deps or "workspace=" in deps:
        current = Path.cwd()

        paths = []

        while not (current / ".git").is_dir():
            paths.insert(0, current.name)
            current = (current / "..").resolve()

        context = current

        pre_lock_add += "COPY . ."
        if paths:
            source_code_dir_name = source_code_dir_name
            source_dir_sub_dir = Path("/".join(paths))
    else:
        lockfile = source_dir_sub_dir / lockfile

    if "../" in lockfile.as_posix():
        lockfile = lockfile.resolve().relative_to(context)

    file = default_docker_image(
        uv_image, 
        source_code_dir_name, 
        pre_lock_add,
        lock_file=lockfile,
        pyproject_file=source_dir_sub_dir / pyproject,
        copy_additional_dirs=copy_additional_dirs,
        copy_path_packages=copy_path_packages,
        source_dir=source_dir_sub_dir,
        project_file=source_dir_sub_dir / project_file,
        uv_sync_args=uv_sync_args
    )

    logger.debug(file)
    dockerfile.write_text(file)
    return context, source_dir_sub_dir

def find_lockfile() -> Path:
    max_checks = 10
    lockfile = Path("uv.lock")
    original_file = lockfile.resolve()
    n_checks = 0

    while not lockfile.is_file():
        lockfile = ".." / lockfile 
        n_checks += 1
        if n_checks > max_checks:
            raise ValueError(f"Unable to find a uv.lock file. Was looking in '{original_file}'")

    return lockfile


@dataclass
class LockfileInfo:
    packages: list[str]
    path_packages: list[str]
    current_package: str

def packages_from_lockfile(file: Path) -> LockfileInfo:
    packages: list[str] = []
    path_packages: list[str] = []
    current_package: str | None = None

    lock_file = tomli.loads(
        file.read_text()
    )
    for package in lock_file["package"]:
        packages.append(package["name"])

        source = package["source"]
        if "virtual" in source:
            path = source["virtual"]
            if path == ".":
                current_package = package["name"]
        elif "directory" in source:
            path_packages.append(source["directory"])
        elif "editable" in source:
            path = source["editable"]
            if path == ".":
                current_package = package["name"]
            else:
                path_packages.append(source["editable"])

    assert current_package, "Unable to find package name from lock file"
    return LockfileInfo(
        packages=packages, path_packages=path_packages, current_package=current_package
        
    ) 


def build_image(
    project: Project, 
    tags: str | list[str], 
    context: str | None = None,
    dockerfile_path: str | None = None,
    uv_sync_args: str | None = None
) -> str:
    pyproject_path = Path("pyproject.toml")

    dockerfile = Path(dockerfile_path) if dockerfile_path else Path(".build/Dockerfile")

    version: str = tomli.loads(
        pyproject_path.read_text()
    ).get("project", {}).get("requires-python", "3.12").split(",")[0]


    if version.startswith(">="):
        version = "3.13"
    else:
        version = "".join([
            c for c in version
            if c.isnumeric() or c == "."
        ])
    version = '.'.join(version.split(".")[0:2])


    lockfile = find_lockfile()
    lockhash = sha256(lockfile.read_bytes(), usedforsecurity=False).hexdigest()
    lockfile_info = packages_from_lockfile(lockfile)

    if not pyproject_path.is_file():
        raise ValueError("Expected a pyproject.toml file using uv.")

    source_dir = Path("")
    if dockerfile_path is None:

        dockerfile.parent.mkdir(exist_ok=True, parents=True)

        temp_context, source_dir = create_dockerfile_for(
            project, 
            dockerfile,
            pyproject_path, 
            lockfile=lockfile,
            path_packages=lockfile_info.path_packages,
            python_version=version or "3.12",
            uv_sync_args=uv_sync_args
        )

        if context is None:
            context = temp_context.resolve().as_posix()

    platform = "linux/amd64"
    if isinstance(tags, list):
        reg_url = [f"{project.name}:{tag}" for tag in tags]
    else:
        reg_url = [f"{project.name}:{tags}"]

    build_dir = Path.cwd()
    try:
        if context:
            context_path = (build_dir / context).resolve().as_posix()
            logger.info(f"Using context {context_path} with dockerfile {dockerfile.resolve().as_posix()}")
        else:
            context_path = "."

        dockerignore_path = Path(context_path) / ".dockerignore"
        if not dockerignore_path.is_file():
            from takk.dockerignore import dockerignore_default
            dockerignore_path.write_text(dockerignore_default)

        tag_args = []
        for tag in reg_url:
            tag_args += ["-t", tag]

        docker_command = [
            "docker", "build", context_path,
            *tag_args,
            "-f", dockerfile.resolve().as_posix(),
            "--platform", platform,
            "--label", f"com.takkthon.lockhash={lockhash}",
            "--label", f"com.takkthon.source-dir={source_dir.as_posix()}",
        ]
        logger.debug(f"Running command {docker_command}")

        process = subprocess.Popen(
            docker_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        output_lines: list[str] = []
        max_lines_per_step = 10
        current_step_num: str | None = None
        current_step_lines: list[str] = []
        completed_steps: list[str] = []
        skip_steps = {"1"}

        def parse_step_num(line: str) -> str | None:
            if not line.startswith("#"):
                return None
            space_idx = line.find(" ", 1)
            if space_idx == -1:
                return None
            return line[1:space_idx]

        with Live(Text("Starting build..."), console=console, refresh_per_second=8) as live:
            for line in process.stdout:
                decoded = line.decode("utf-8", errors="replace")
                output_lines.append(decoded)
                stripped = decoded.rstrip("\n")

                if not stripped:
                    continue

                step_num = parse_step_num(stripped) or current_step_num

                if step_num and step_num in skip_steps:
                    continue

                if step_num and step_num != current_step_num:
                    if current_step_num is not None and current_step_lines:
                        completed_steps.append(
                            f"[bold green]✓[/bold green] Step #{current_step_num} [dim]done[/dim]"
                        )
                    current_step_num = step_num
                    current_step_lines = []

                if stripped.startswith("ERROR") or stripped.startswith("error"):
                    current_step_lines.append(f"[bold red]{stripped}[/bold red]")
                else:
                    current_step_lines.append(f"[dim]{stripped}[/dim]")

                display = Text.from_markup("\n".join(completed_steps[-3:]))
                if current_step_lines:
                    visible = current_step_lines[-max_lines_per_step:]
                    display.append("\n")
                    display.append_text(Text.from_markup("\n".join(visible)))

                live.update(display)

        return_code = process.wait()

        if return_code != 0:
            full_output = "".join(output_lines)
            common_fixes = {
                "no space left on device": "Run 'docker system prune --volumes' or increase the Docker engine size",
                "The lockfile at `uv.lock` needs to": "Run 'uv lock'",
            }
            found_common = False

            for pattern, fix in common_fixes.items():
                if pattern in full_output:
                    console.print(
                        Panel(
                            f"Try to do the following:\n{fix}",
                            title="Docker build failed",
                            title_align="left",
                            style="red",
                        )
                    )
                    found_common = True

            if not found_common:
                console.print(
                    Panel(
                        f"Build exited with code {return_code}",
                        title="Docker build failed",
                        title_align="left",
                        style="red",
                    )
                )
                raise ValueError(f"Docker build failed with exit code {return_code}")
    except Exception as e:
        logger.exception(e)

    return reg_url[0]
