"""CLI package for phi-redactor.

The entry point is :func:`phi_redactor.cli.main.cli`, registered as the
``phi-redactor`` console script in ``pyproject.toml``.
"""
