"""Encrypted PHI vault for token mapping storage."""

from __future__ import annotations

from phi_redactor.vault.store import PhiVault

__all__ = ["PhiVault"]
