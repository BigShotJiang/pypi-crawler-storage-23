"""Entry point for python -m phi_redactor."""

from phi_redactor.cli.main import cli

if __name__ == "__main__":
    cli()
