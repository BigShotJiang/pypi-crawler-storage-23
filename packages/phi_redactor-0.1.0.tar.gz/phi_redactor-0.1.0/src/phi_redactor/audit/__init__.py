"""Append-only hash-chain audit trail for PHI redaction events."""

from __future__ import annotations

from phi_redactor.audit.trail import AuditTrail

__all__ = ["AuditTrail"]
