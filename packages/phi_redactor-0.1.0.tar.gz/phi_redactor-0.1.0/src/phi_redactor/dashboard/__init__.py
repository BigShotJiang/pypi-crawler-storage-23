"""Real-time monitoring dashboard for the PHI redaction proxy."""
