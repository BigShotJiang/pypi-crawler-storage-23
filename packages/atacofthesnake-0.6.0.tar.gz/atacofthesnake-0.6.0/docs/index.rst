ATACofthesnake
--------------

A versatile snakemake workflow to analyze multifactorial ATAC-seq data, with a specific focus on time-series analysis.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   content/installation
   content/usage
   content/example
