from enum import Enum


class Item(Enum):
    TIN_ORE = "tin_ore"
    COPPER_ORE = "copper_ore"
    COBALT_ORE = "cobalt_ore"
    IRON_ORE = "iron_ore"
    RAW_SHRIMP = "raw_shrimp"
    RAW_SHARK = "raw_shark"
    REGULAR_LOG = "regular_log"
    OAK_LOG = "oak_log"
    REDWOOD_LOG = "redwood_log"
    COPPER_BAR = "copper_bar"
