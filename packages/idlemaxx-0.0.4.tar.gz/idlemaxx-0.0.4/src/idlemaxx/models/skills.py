from enum import Enum


class Skill(Enum):
    MINING = "mining"
    WOODCUTTING = "woodcutting"
    FISHING = "fishing"
    SMELTING = "smelting"
