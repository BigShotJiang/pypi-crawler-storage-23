from __future__ import annotations
from rich.text import Text
from wcwidth import wcswidth
from textual.widgets.option_list import Option
from textual.screen import Screen
from idlemaxx.models.models import Character, Activity, ActivityCategory, level_from_xp
from idlemaxx.game import Game
import pendulum
from textual.widgets import OptionList, Label, Input, DataTable, Footer
from textual.app import App, ComposeResult


def _icon_label(icon: str, text: str, col_width: int) -> str:
    """Left-pad `text` so it starts at `col_width + 2` regardless of `icon` display width."""
    pad = col_width - wcswidth(icon)
    return icon + " " * pad + "  " + text


def _back_label(col_width: int) -> Text:
    return Text.assemble(" " * (col_width + 2), ("⬅ ", "red"), "Back")


def _icon_col_width(icons: list[str]) -> int:
    return max(wcswidth(i) for i in icons)


class WrappingOptionList(OptionList):
    def action_cursor_down(self) -> None:
        if self.option_count > 0 and self.highlighted == self.option_count - 1:
            self.highlighted = 0
        else:
            super().action_cursor_down()

    def action_cursor_up(self) -> None:
        if self.option_count > 0 and self.highlighted == 0:
            self.highlighted = self.option_count - 1
        else:
            super().action_cursor_up()


class WrappingDataTable(DataTable):
    def action_cursor_down(self) -> None:
        if self.row_count > 0 and self.cursor_row == self.row_count - 1:
            self.move_cursor(row=0)
        else:
            super().action_cursor_down()

    def action_cursor_up(self) -> None:
        if self.row_count > 0 and self.cursor_row == 0:
            self.move_cursor(row=self.row_count - 1)
        else:
            super().action_cursor_up()


class PopScreen(Screen):
    """Base screen that pops itself on escape."""

    BINDINGS = [("escape", "app.pop_screen", "Back")]


class TableViewScreen(PopScreen):
    """Read-only data table. Escape to go back."""

    def __init__(self, columns: list[str], rows: list[tuple]) -> None:
        super().__init__()
        self._columns = columns
        self._rows = rows

    def compose(self) -> ComposeResult:
        table = DataTable(cursor_type="none", disabled=True)
        table.add_columns(*self._columns)
        for row in self._rows:
            table.add_row(*row)
        yield table
        yield Footer()


class CreateCharacterScreen(Screen[str]):
    BINDINGS = [("escape", "dismiss_cancel", "Back")]

    def action_dismiss_cancel(self) -> None:
        self.dismiss("")

    def compose(self) -> ComposeResult:
        yield Label("Enter character name:")
        yield Input(placeholder="Name", id="character-name")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self.dismiss(event.value)
        event.stop()


class ConfirmScreen(Screen[bool]):
    BINDINGS = [("escape", "dismiss_cancel", "Back")]

    def action_dismiss_cancel(self) -> None:
        self.dismiss(False)

    def __init__(self, message: str) -> None:
        super().__init__()
        self.message = message

    def compose(self) -> ComposeResult:
        yield Label(self.message)
        yield WrappingOptionList(
            Option("Yes", "yes"),
            Option("No", "no"),
        )

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(event.option.id == "yes")
        event.stop()


class ActionLimitScreen(Screen["tuple[int | None, bool] | None"]):
    BINDINGS = [("escape", "dismiss_cancel", "Back")]
    app: "IdlemaxxApp"

    def __init__(self, character: Character, activity: Activity) -> None:
        super().__init__()
        self.character = character
        self.activity = activity

    def action_dismiss_cancel(self) -> None:
        self.dismiss(None)

    def compose(self) -> ComposeResult:
        est = self.app.game.estimate_activity(self.character, self.activity)
        default_value = str(est.possible_actions) if est.possible_actions is not None else ""
        cat = self.activity.category
        act_name = self.activity.value.name.replace("_", " ").title()
        yield Label(f"Activity: {cat.icon} {cat.display_name} - {act_name}")
        yield Label("Actions (blank = unlimited):")
        yield Input(value=default_value, placeholder="", id="action-limit-input")
        yield WrappingOptionList(
            Option("▶ Start", "start"),
            Option("+ Add to queue", "queue"),
            Option("⬅ Cancel", "cancel"),
        )

    def _parse_limit(self) -> "int | None | str":
        raw = self.query_one("#action-limit-input", Input).value.strip()
        if not raw:
            return None
        try:
            val = int(raw)
            if val <= 0:
                return "Action count must be a positive integer"
            return val
        except ValueError:
            return "Action count must be a positive integer or blank"

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        if event.option.id == "cancel":
            self.dismiss(None)
            event.stop()
            return
        limit = self._parse_limit()
        if isinstance(limit, str):
            self.app.notify(limit, severity="error")
            event.stop()
            return
        self.dismiss((limit, event.option.id == "queue"))
        event.stop()


class ActivityCategoryScreen(PopScreen):
    app: IdlemaxxApp

    def __init__(self, character: Character) -> None:
        super().__init__()
        self.character = character

    def compose(self) -> ComposeResult:
        yield Label("Choose a category")
        categories = self.app.game.activity_categories()
        icons = [cat.icon for cat in categories] + ["💤"]
        col_width = _icon_col_width(icons)
        yield WrappingOptionList(
            *[Option(_icon_label(cat.icon, cat.display_name, col_width), cat.name) for cat in categories],
            Option(_icon_label("💤", "Idle", col_width), "__idle__"),
            Option(_back_label(col_width), "__back__"),
        )

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        match str(event.option.id):
            case "__idle__":
                rewards = self.app.game.end_activity(self.character)
                if rewards:
                    total_actions = sum(r.actions_completed for r in rewards)
                    self.app.notify(f"Stopped activity ({total_actions} actions completed)", timeout=5)
                self.app.pop_screen()
            case "__back__":
                self.app.pop_screen()
            case category_name:
                self.app.push_screen(ActivityScreen(self.character, ActivityCategory[category_name]))
        event.stop()


class ActivityScreen(PopScreen):
    app: IdlemaxxApp

    def __init__(self, character: Character, category: ActivityCategory) -> None:
        super().__init__()
        self.character = character
        self.category = category

    def compose(self) -> ComposeResult:
        yield Label(f"Choose a {self.category.display_name} activity")
        table = WrappingDataTable(cursor_type="row", id="activity-table")
        table.add_columns("Activity", "Time (s)", "Skill Requirements", "Item Requirements", "XP", "Rewards", "Est.")
        for a in self.app.game.activities_for_category(self.category):
            data = a.value
            skill_reqs = ", ".join(f"{r.skill.value} lv.{r.required_level}" for r in data.skill_requirements) or "-"
            item_reqs = ", ".join(f"{i.item.value}" for i in data.materials) or "-"
            xp = ", ".join(f"{r.skill.value} +{r.xp}" for r in data.skill_rewards) or "-"
            items = ", ".join(f"{r.quantity}x {r.item.value}" for r in data.item_rewards) or "-"
            est = self.app.game.estimate_activity(self.character, a)
            if est.possible_actions is None:
                est_str = "∞"
            else:
                total_items = ", ".join(f"{qty}x {item.value}" for item, qty in est.total_items.items()) or "-"
                total_xp = ", ".join(f"+{xp} {skill.value}" for skill, xp in est.total_xp.items()) or "-"
                est_str = f"{est.possible_actions} actions → {total_items} | {total_xp}"
            table.add_row(data.name, str(data.action_time), skill_reqs, item_reqs, xp, items, est_str, key=data.name)
        table.add_row("Back", "", "", "", "", "", "", key="__back__")
        yield table

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        match str(event.row_key.value):
            case "__back__":
                self.app.pop_screen()  # back to ActivityCategoryScreen
            case activity_name:
                chosen_activity = Activity.from_name(activity_name)

                def on_action_limit(result: "tuple[int | None, bool] | None") -> None:
                    if result is None:
                        return
                    limit, should_queue = result
                    if should_queue:
                        try:
                            self.app.game.queue_activity(self.character, chosen_activity, action_limit=limit)
                        except Exception as e:
                            self.app.notify(str(e), severity="error")
                            return
                        self.app.pop_screen()  # close ActivityScreen
                        self.app.pop_screen()  # close ActivityCategoryScreen
                        self.app.notify(f"Queued {chosen_activity.value.name}!", timeout=5)
                    else:
                        if self.character.current_activity:
                            self.app.game.end_activity(self.character)
                        started = self.app.game.start_activity(self.character, chosen_activity, action_limit=limit)
                        self.app.pop_screen()  # close ActivityScreen
                        self.app.pop_screen()  # close ActivityCategoryScreen
                        self.app.notify(f"{self.character.name} started {started.activity.name}!", timeout=5)

                self.app.push_screen(ActionLimitScreen(self.character, chosen_activity), callback=on_action_limit)
        event.stop()


class QueueScreen(PopScreen):
    app: "IdlemaxxApp"

    def __init__(self, character: Character) -> None:
        super().__init__()
        self.character = character

    def _build_options(self) -> list[Option]:
        options: list[Option] = []
        act = self.character.current_activity
        if act:
            cat = act.activity.category
            name = act.activity.value.name.replace("_", " ").title()
            limit_str = f" ({act.action_limit} actions)" if act.action_limit is not None else ""
            options.append(Option(f"[Active] {cat.icon} {name}{limit_str} — end early", "current"))
        else:
            options.append(Option("💤 Idle", "idle"))
        for i, item in enumerate(self.app.game.get_activity_queue(self.character)):
            cat = item.activity.category
            name = item.activity.value.name.replace("_", " ").title()
            limit_str = f" ({item.action_limit} actions)" if item.action_limit is not None else "∞"
            options.append(Option(f"[#{i + 1}] {cat.icon} {name} — {limit_str} — remove", f"queue_{i}"))
        options.append(Option("⬅ Back", "__back__"))
        return options

    def compose(self) -> ComposeResult:
        yield Label("Queue")
        yield WrappingOptionList(*self._build_options())

    def _refresh(self) -> None:
        ol = self.query_one(WrappingOptionList)
        ol.clear_options()
        for opt in self._build_options():
            ol.add_option(opt)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        match str(event.option.id):
            case "__back__" | "idle":
                self.app.pop_screen()
            case "current":

                def on_end_confirm(confirmed: bool | None) -> None:
                    if confirmed:
                        self.app.game.end_activity(self.character)
                        self._refresh()

                self.app.push_screen(ConfirmScreen("End current activity early?"), callback=on_end_confirm)
            case queue_key if queue_key.startswith("queue_"):
                idx = int(queue_key.removeprefix("queue_"))
                queue = self.app.game.get_activity_queue(self.character)
                item = queue[idx]

                def on_remove_confirm(confirmed: bool | None) -> None:
                    if confirmed:
                        self.app.game.remove_from_queue(self.character, item)
                        self._refresh()

                self.app.push_screen(ConfirmScreen("Remove from queue?"), callback=on_remove_confirm)
        event.stop()


class CharacterScreen(PopScreen):
    app: IdlemaxxApp

    def __init__(self, character: Character) -> None:
        super().__init__()
        self.character = character

    def _activity_label(self) -> str:
        act = self.character.current_activity
        if not act:
            return "Current Activity: 💤 Idle"
        category = act.activity.category
        activity_name = act.activity.value.name.replace("_", " ").title()
        label = f"Current Activity: {category.icon} {category.display_name} - {activity_name}"
        if act.action_limit is not None:
            label += f" ({act.action_limit} actions)"
        return label

    def on_screen_resume(self) -> None:
        self.query_one("#activity-label", Label).update(self._activity_label())
        self.query_one("#skills-items-count", Label).update(
            f"Skills: {len(self.character.skills)} | Items: {len(self.character.items)}",
        )

    def compose(self) -> ComposeResult:
        yield Label(f"Character: {self.character.name}")
        yield Label(
            f"Skills: {len(self.character.skills)} | Items: {len(self.character.items)}", id="skills-items-count"
        )
        yield Label(self._activity_label(), id="activity-label")
        yield WrappingOptionList(
            Option("Start activity", "start_activity"),
            Option("View skills", "view_skills"),
            Option("View items", "view_items"),
            Option("View queue", "view_queue"),
            Option("Delete character", "delete_char"),
            Option("Back", "back"),
        )

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        match event.option.id:
            case "start_activity":
                self.app.push_screen(ActivityCategoryScreen(self.character))
            case "view_skills":
                rows = [
                    (
                        s.skill.name,
                        level_from_xp(s.experience),
                        s.experience,
                        pendulum.instance(s.updated_at).in_tz("local").to_rfc850_string(),
                    )
                    for s in self.character.skills
                ]
                self.app.push_screen(TableViewScreen(["Skill", "Level", "Experience", "Last Modified"], rows))
            case "view_items":
                rows = [
                    (i.item.name, i.quantity, pendulum.instance(i.updated_at).in_tz("local").to_rfc850_string())
                    for i in self.character.items
                ]
                self.app.push_screen(TableViewScreen(["Item", "Quantity", "Last Modified"], rows))
            case "view_queue":
                self.app.push_screen(QueueScreen(self.character))
            case "back":
                self.app.pop_screen()
            case "delete_char":

                def on_confirm(confirmed: bool | None) -> None:
                    if confirmed:
                        name = self.character.name
                        self.app.game.delete_character(self.character)
                        self.app.pop_screen()
                        self.app.refresh_character_menu()
                        self.app.notify(f"Deleted {name}")

                self.app.push_screen(ConfirmScreen(f"Delete {self.character.name}?"), callback=on_confirm)
            case _:
                self.app.exit()


class IdlemaxxApp(App):
    def __init__(self) -> None:
        super().__init__()
        self.game = Game("sqlite:///idlemaxx-cli.db")

    def refresh_character_menu(self) -> None:
        menu = self.query_one("#menu", OptionList)
        menu.clear_options()

        characters = self.game.list_characters()
        for char in characters:
            menu.add_option(Option(char.name, f"char:{char.name}"))
        menu.add_option(Option("Create a new character", "create_character"))
        menu.add_option(Option("Quit", "quit"))
        menu.highlighted = 0

    def on_mount(self) -> None:
        self.refresh_character_menu()

    def compose(self) -> ComposeResult:
        yield Label("Choose your character")
        yield WrappingOptionList(id="menu")

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        if event.option_list.id != "menu":
            return
        option_id = str(event.option.id)
        match option_id:
            case "create_character":

                def on_name(name: str | None) -> None:
                    if name:
                        character = self.game.create_character(name)
                        self.notify(f"Created character {character.name}")
                        self.refresh_character_menu()
                    else:
                        self.exit()

                self.push_screen(CreateCharacterScreen(), callback=on_name)

            case "quit":
                self.exit()
            case _:
                char_name = option_id.removeprefix("char:")
                self.character = self.game.get_character_by_name(char_name)
                self.push_screen(CharacterScreen(self.character))


def main() -> None:
    app = IdlemaxxApp()
    app.run(inline=True)


if __name__ == "__main__":
    main()
