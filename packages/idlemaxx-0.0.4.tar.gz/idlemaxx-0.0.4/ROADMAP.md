# Roadmap

## Game Features
- [x] Specify action count when starting an activity (e.g. "mine 1000x iron ore, then stop")
- [x] Action queue — chain activities back-to-back (e.g. mine 1000x iron → smelt 1000x iron bars → smith 200 iron daggers)
- [ ] Incremental activity rewards — grant XP and items progressively during an activity, not just at completion; preview rewards earned so far mid-activity
- [ ] Non-deterministic rewards — e.g. 1% chance to find a gem while mining, X% chance to mine two ores in one action
- [x] Complete partially-implemented activities (Oak/Redwood woodcutting, Cobalt mining, Shrimp/Shark fishing)
- [ ] Smooth skill progression with cross-skill integration across all skills
- [ ] Equipment slots — equip items to your character
- [ ] Achievements and milestones

## New Skills
- [ ] Smithing — craft bars into equipment
- [ ] Cooking — prepare food from raw ingredients
- [ ] Tailoring — craft cloth armor
- [ ] Leatherworking — craft leather armor
- [ ] Fletching — craft ranged weapons
- [ ] Runecrafting — craft consumable runes used for magic
- [ ] Magic (non-combat) — cast spells using runes

## Quests
- [ ] Quest system with multiple skill requirements and quest prerequisites
- [ ] Semi-interactive quest experiences (not purely idle)

## Combat
- [ ] Combat system — use equipment to fight enemies and train combat skills
- [ ] Bosses — difficult enemies with unique mechanics requiring preparation
- [ ] Multiplayer boss encounters

## CLI Features
- [ ] Color-coded information — e.g. red for unmet requirements, green for met
- [ ] Activity progress bar / time-remaining display
- [ ] Projected time-to-level-up per skill
- [ ] Activity history log
- [ ] Multi-character side-by-side view
- [ ] Configurable keybindings
- [ ] Color themes / dark-light mode toggle
- [ ] Sound/bell notifications on activity completion

## New Frontends
- [x] Discord bot (priority)
- [ ] REST API / server mode for headless operation
- [ ] Web frontend
