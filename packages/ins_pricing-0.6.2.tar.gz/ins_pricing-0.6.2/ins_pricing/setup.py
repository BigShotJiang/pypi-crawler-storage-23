"""Compatibility shim.

Package metadata is defined in the repository root `pyproject.toml`.
"""

from setuptools import setup


if __name__ == "__main__":
    setup()
