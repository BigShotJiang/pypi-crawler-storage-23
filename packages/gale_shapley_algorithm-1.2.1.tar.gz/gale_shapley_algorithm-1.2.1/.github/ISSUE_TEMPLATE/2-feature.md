---
name: Feature Request
about: Suggest an idea for this project
title: "feature: "
labels: feature
assignees: oedokumaci
---

## Problem

<!-- Is your feature request related to a problem? Describe it here. -->

## Proposed solution

<!-- A clear and concise description of what you want to happen. -->

## Alternatives considered

<!-- Any alternative solutions or features you've considered. -->

## Additional context

<!-- Any other context or screenshots about the feature request. -->
