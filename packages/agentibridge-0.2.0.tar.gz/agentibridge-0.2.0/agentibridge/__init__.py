"""AgentiBridge — Claude CLI transcript index and MCP tools."""

__version__ = "0.2.0"
