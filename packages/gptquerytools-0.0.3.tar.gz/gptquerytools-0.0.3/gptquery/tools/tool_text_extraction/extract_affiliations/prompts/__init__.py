# gptquery\tools\tool_text_extraction\extract_affiliations\prompts\__init__.py
# FILE INTENTIONALLY BLANK