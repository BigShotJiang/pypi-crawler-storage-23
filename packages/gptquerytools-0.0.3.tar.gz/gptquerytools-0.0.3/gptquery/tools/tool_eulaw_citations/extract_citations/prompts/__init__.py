#gptquery/tools/tool_eulaw_citations/extract_citations/prompts/__init__.py

#FILE INTENTIONALLY BLANK