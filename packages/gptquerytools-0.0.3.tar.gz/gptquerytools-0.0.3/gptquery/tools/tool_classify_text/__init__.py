# gptquery/tools/tool_classify_text/__init__.py

"""TEXT Classification  tool ."""
from .is_sentence_valance.task import run_is_sentence_valance_basic

__all__ = ["run_is_sentence_valance_basic"]
