# gptquery/gptquery/tools/tool_classify_text/classify_snippets/prompts/__init__.py
# FILE INTENTIONALLY BLANK