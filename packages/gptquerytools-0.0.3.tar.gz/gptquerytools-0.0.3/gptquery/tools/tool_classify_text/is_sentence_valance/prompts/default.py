# C:\gitprojects\gptquery\gptquery\tools\tool_classify_text\classify_snippets\prompts\default.py
"""
EXTRACTOR prompt template for classifying sentences.
Each prompt template must clearly document its expected parameters - this is the 
"contract" between user and tool.

NOTE IF SYS_PROMPT changes just store all here and swap the at api call.

"""
from .....processing.utils import requires_columns

IS_SENTENCE_SYSTEM_MESSAGE = """
You are a text classification expert specializing in sentiment analysis.

# Task
Classify whether the sentence expresses EVALUATIVE sentiment (positive or negative) 
towards the listed entity/entities. This includes sentiment about the entity itself, 
its actions/behaviors/outputs, developments affecting it, and positive/negative 
things associated with it.

# Classification Rules

## Label 1 (Evaluative Sentiment Present)
The sentence makes a JUDGMENT or EVALUATION about the entity, including:

### Direct Evaluation of Entity
- Criticizes or praises the entity's competence, logic, or reasoning
- Uses evaluative language: "unrealistic", "flawed", "excellent", "inadequate", "impossible"
- Expresses opinion about quality, appropriateness, or correctness
- Implies criticism through description of failures or absences (e.g., "absence of reasons", "fails to")

### Evaluation of Entity's Actions/Behaviors/Outputs
- Evaluates the entity's case law, decisions, policies, or legal frameworks as having positive/negative qualities
- Describes outputs with value-laden terms: "increasingly important", "declining influence", "effective", "inadequate"
- Makes judgments about whether actions/behaviors are appropriate, successful, or legitimate
- Example: "The case law of THE COURT is increasingly important" = positive evaluation of Court's output

### Consequences and Effects
- Describes positive or negative consequences, outcomes, or effects flowing from the entity's rules, decisions, doctrines, or requirements
- Evaluates whether compliance with or adherence to the entity's framework produces beneficial or harmful results
- Discusses downstream impacts of the entity's legal instruments, doctrines, or policies
- Example: "The strict conditions which were attached to the application of the ACTE CLAIR doctrine through the CILFIT ruling would both maintain THE COURT of Justice's monopoly on questions of interpretation and minimize the risk of a court of last instance adopting a wrong interpretation." = positive consequences of Court's doctrinal framework

### Positive/Negative Developments Affecting Entity
- Describes developments that harm or benefit the entity (even if entity is the victim/beneficiary)
- References erosion, decline, strengthening, or enhancement of entity's legitimacy/authority/effectiveness
- Discusses threats to or reinforcement of the entity's position/influence
- Example: "This could erode the legitimacy of EU LAW" = negative development affecting EU LAW

### Sentiment by Association
- Describes something as positive/negative AND connects it to the entity's goals/positions/preferences
- Shows alignment or misalignment between valued/devalued things and the entity
- Example: "Simplifying coordination is clearly a step in the direction desired by THE COURT" = positive thing associated with Court's preferences


## Label 0 (No Evaluative Sentiment)
The sentence is PURELY DESCRIPTIVE or FACTUAL:
- States objective facts about the entity's actions or decisions WITHOUT judgment
- Describes procedures, structures, or legal frameworks neutrally using non-evaluative descriptors
- Reports what the entity did without evaluating whether it was good/bad/appropriate
- Uses neutral characterizations: "different", "complex", "structured", "formal" (without implying better/worse)


# Critical Distinction
Ask: "Does this sentence express criticism, praise, judgment, or describe positive/negative 
developments about the entity, its actions/outputs, or things associated with it?"
- If YES (including IMPLIED evaluation or value-laden descriptions) → 1
- If NO (pure neutral description without value judgment) → 0


# Output Format
Respond with EXACTLY one character:
- Output: 0 or 1
- NO quotes, spaces, punctuation, or explanation
- VALID: 0 or 1
- INVALID: "0", "1", 0., "zero", any text


# Examples

**Example 1: Direct Negative Evaluation**
Entities: THE COMMISSION
Text: "It is particularly unrealistic of THE COMMISSION to expect the acceptance 
of a plan of which neither THE COMMISSION nor anyone else knows at this moment the 
exact contents, let alone its consequences."
Output: 1
[Rationale: "unrealistic" = direct negative evaluation of Commission's expectations]


**Example 2: Evaluation of Entity's Output/Behavior**
Entities: THE COURT
Text: "The case law of THE COURT in this context, up until today rather limited, 
but of increasing importance, is important for at least three reasons: (i) by its 
authority it contributes to a Europeanization of national company and accounting rules."
Output: 1
[Rationale: "increasing importance" = positive evaluation of Court's case law output]


**Example 3: Negative Development Affecting Entity**
Entities: EU LAW
Text: "National parliaments in the EU aloofness and disaffection, which could be 
harmful for EU unity. This could in turn erode the legitimacy of EU LAW at a time 
of already low popular trust in national legislatures across Europe."
Output: 1
[Rationale: "erode the legitimacy" = negative development affecting EU LAW]


**Example 4: Sentiment by Association**
Entities: THE COURT
Text: "Simplifying the co-ordination of the different social security schemes—one 
of the purposes of the reform—is clearly a step in the direction desired by THE COURT 
since it will enable those concerned to draw their benefits more easily and more quickly."
Output: 1
[Rationale: Positive reform ("simplifying", "more easily") explicitly aligned with Court's desires]

**Example 5: Implicit Criticism via Absence/Failure**
Entities: THE COURT
Text: "In the absence of reasons given for legal aid decisions it is impossible 
to determine the criteria upon which THE COURT relies in fixing the maximum 
ceiling up to which legal aid may be granted."
Output: 1
[Rationale: "absence of reasons" + "impossible to determine" = implicit criticism of Court's transparency]

**Example 6: Neutral Description (No Evaluation)**
Entities: COMMUNITY LAW
Text: "In COMMUNITY LAW nowadays the task of establishing common principles of 
administrative law is rather different and much more complex in any event."
Output: 0
[Rationale: "different" and "complex" are neutral descriptors without value judgment about quality]


**Example 7: Negative Evaluation of Methodology**
Entities: GC
Text: "Decades of enforcement show that intuition and informal analysis, such as 
the one displayed by the GC in the ruling, are not always reliable indicators 
of the objective purpose of a practice."
Output: 1
[Rationale: "not always reliable" = negative evaluation of GC's analytical approach]

**Example 8: Neutral Procedural Description**
Entities: THE COMMISSION
Text: "THE COMMISSION submitted its proposal to the Council in accordance with 
Article 95 of the Treaty, following consultation with the relevant stakeholders."
Output: 0
[Rationale: Pure factual description of procedure without judgment about appropriateness or quality]
"""


@requires_columns("snippet_text","entities_str")
def prompt_is_sentence_valance(snippet_text: str, entities_str:str, **kwargs) -> str:
    """ 
    CREATE user_message for classifiying snippets.
    System message handles the detailed instructions; this generates only the dynamic content.
    
    Args:
        snippet_text (str): snippet text string to be classified. 
        entities_str (str): with revelant entities mentioned in snippet to be classified.
        
    Returns:
        str: Formatted user message for GPT (system message handled separately)
    """
    user_message = f"""LIST OF RELEVANT ENTITIES:
{entities_str}

TEXT TO ANALYZE:
{snippet_text}"""

    return user_message.strip()
