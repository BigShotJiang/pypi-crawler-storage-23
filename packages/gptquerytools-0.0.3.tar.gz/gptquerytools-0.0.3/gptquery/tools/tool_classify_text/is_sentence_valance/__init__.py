# gptquery/tools/tool_classify_text/is_agent_target/__init__.py
# FILE INTENTIONALLY BLANK