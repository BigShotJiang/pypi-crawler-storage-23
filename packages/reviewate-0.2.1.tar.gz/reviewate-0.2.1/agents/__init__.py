"""Agents Module

AI agents for code review using LiteLLM.
"""

from .base import BaseAgentImpl
from .duplicate import DuplicateAgent
from .fact_checker import FactCheckerAgent
from .issue_explorer import (
    ExtractedIssue,
    ExtractedIssues,
    IssueAnalysis,
    IssueExplorerAgent,
)
from .output_parser import OutputParserAgent
from .specialized import (
    SimpleReviewAgent,
    SynthesizerAgent,
)
from .style import StyleAgent
from .summarizer import SummarizerAgent
from .summary_parser import SummaryParserAgent
from .triage import ReasoningConfig, TriageAgent
from .types import (
    AgentConfig,
    AgentResponse,
    ReasoningEffort,
    TokenUsage,
    ToolHandler,
    ToolResult,
)

__all__ = [
    # Base types
    "AgentConfig",
    "AgentResponse",
    "BaseAgentImpl",
    "ReasoningEffort",
    "TokenUsage",
    "ToolHandler",
    "ToolResult",
    # Review Agents
    "SimpleReviewAgent",
    "SynthesizerAgent",
    # Supporting Agents
    "DuplicateAgent",
    "FactCheckerAgent",
    "IssueExplorerAgent",
    "OutputParserAgent",
    "StyleAgent",
    "SummarizerAgent",
    "SummaryParserAgent",
    "TriageAgent",
    # Triage types
    "ReasoningConfig",
    # Issue Explorer types
    "ExtractedIssue",
    "ExtractedIssues",
    "IssueAnalysis",
]
