from ..logging_config import BaseLogger


class AgentLogger(BaseLogger):
    """Agent logger (e.g., business, fact_checker, etc.)"""

    def __init__(self, agent_name: str):
        super().__init__("agent", agent_name)
