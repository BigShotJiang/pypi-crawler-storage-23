"""Code Reviewer - AI-powered code review for GitHub and GitLab.

This package provides automated code review using a multi-agent pipeline
with tool-augmented codebase exploration for verification.
"""

__version__ = "0.1.0"

from .agents import (
    AgentConfig,
    AgentResponse,
    BaseAgentImpl,
    DuplicateAgent,
    FactCheckerAgent,
    IssueExplorerAgent,
    OutputParserAgent,
    StyleAgent,
    TokenUsage,
    TriageAgent,
)
from .config import Config, Platform
from .workflows import ReviewWorkflow, SummaryWorkflow, WorkflowResult

__all__ = [
    # Version
    "__version__",
    # Config
    "Config",
    "Platform",
    # Agent types
    "AgentConfig",
    "AgentResponse",
    "BaseAgentImpl",
    "TokenUsage",
    # Supporting Agents
    "DuplicateAgent",
    "FactCheckerAgent",
    "IssueExplorerAgent",
    "OutputParserAgent",
    "StyleAgent",
    "TriageAgent",
    # Workflows
    "ReviewWorkflow",
    "SummaryWorkflow",
    "WorkflowResult",
]
