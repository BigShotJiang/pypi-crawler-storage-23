"""Adaptors module - Git platform integrations.

Provides abstraction for GitHub and GitLab APIs, separated by concern:
- repository/: Repository operations (MRs, discussions, archives)
- issue/: Issue tracking operations
"""

from .issue import (
    GitHubIssueHandler,
    GitLabIssueHandler,
    Issue,
    IssueHandler,
)
from .repository import (
    DiscussionItem,
    DiscussionItemType,
    DiscussionNote,
    GitHubRepositoryHandler,
    GitLabRepositoryHandler,
    MergeRequest,
    RepositoryHandler,
)

__all__ = [
    # Repository handlers
    "RepositoryHandler",
    "GitHubRepositoryHandler",
    "GitLabRepositoryHandler",
    # Issue handlers
    "IssueHandler",
    "GitHubIssueHandler",
    "GitLabIssueHandler",
    # Schemas
    "MergeRequest",
    "DiscussionItem",
    "DiscussionItemType",
    "DiscussionNote",
    "Issue",
]
