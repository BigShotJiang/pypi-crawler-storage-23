"""GitHub issue handler module."""

from .handler import GitHubIssueHandler

__all__ = [
    "GitHubIssueHandler",
]
