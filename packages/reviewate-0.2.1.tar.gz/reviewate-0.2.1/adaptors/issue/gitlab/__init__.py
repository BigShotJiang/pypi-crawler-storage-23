"""GitLab issue handler module."""

from .handler import GitLabIssueHandler

__all__ = [
    "GitLabIssueHandler",
]
