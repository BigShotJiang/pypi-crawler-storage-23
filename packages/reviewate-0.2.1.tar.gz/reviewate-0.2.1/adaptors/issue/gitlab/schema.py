"""GitLab-specific issue schemas.

Currently empty - GitLab issues use the shared Issue schema.
Add GitLab-specific issue types here if needed in the future.
"""
