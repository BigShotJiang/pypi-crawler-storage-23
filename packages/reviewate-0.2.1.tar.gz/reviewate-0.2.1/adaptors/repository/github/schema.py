"""GitHub-specific repository schemas."""

from typing import Annotated, Any

from pydantic import BaseModel, Field


class GitHubPullRequest(BaseModel):
    """GitHub Pull Request model (raw API response)."""

    number: Annotated[int, Field(description="Pull request number")]
    title: Annotated[str, Field(description="Pull request title")]
    body: Annotated[str | None, Field(description="Pull request body/description")] = None
    state: Annotated[str, Field(description="Pull request state (open, closed)")]
    head: Annotated[dict[str, Any], Field(description="Head branch information")]
    base: Annotated[dict[str, Any], Field(description="Base branch information")]


class GitHubReviewComment(BaseModel):
    """GitHub review comment format for LLM output.

    This schema is used by agents to generate structured review comments.
    The adaptor will add commit_id and other metadata when posting.
    """

    path: Annotated[str | None, Field(description="Path to the file being commented on")] = None
    body: Annotated[str, Field(description="The review comment body (supports markdown)")]
    line: Annotated[
        int | None,
        Field(
            description="Line number in the new file (RIGHT side) or in the old file (LEFT side)"
        ),
    ] = None
    side: Annotated[
        str | None, Field(description="Side of the diff (LEFT or RIGHT)", default="RIGHT")
    ] = None
