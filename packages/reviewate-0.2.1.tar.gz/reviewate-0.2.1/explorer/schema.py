"""Schema definitions for ast-grep explorer."""

from pydantic import BaseModel, Field


class SearchMatch(BaseModel):
    """A single search match."""

    file_path: str
    line: int
    content: str


class SearchResult(BaseModel):
    """Result from a search operation."""

    matches: list[SearchMatch] = Field(default_factory=list)
    query: str = ""
