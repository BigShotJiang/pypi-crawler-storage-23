# Reviewate - AI-Powered Code Review

**Reviewate** is a multi-agent code review system for GitHub and GitLab pull requests. It explores your codebase, verifies every finding against actual code, and posts only fact-checked feedback.

## Quick Start

### Run without installing (recommended)

```bash
uvx reviewate --repo facebook/react --pr 28000 --platform github --review
# First run: prompts for your LLM provider + API key
# Saves config to ~/.reviewate/config.toml — all future runs just work
```

Requires [uv](https://docs.astral.sh/uv/).

### Or install globally

```bash
uv tool install reviewate   # or: pip install reviewate
reviewate --repo facebook/react --pr 28000 --platform github --review
```

No token needed if the `gh` or `glab` CLI is logged in.

### From source (for development)

```bash
git clone https://github.com/numberly/reviewate.git
cd reviewate/code_reviewer
uv sync

uv run python main.py --repo facebook/react --pr 28000 --platform github --review
```

## Config file

On first run, Reviewate saves your config to `~/.reviewate/config.toml`:

```toml
[models]
review = "gemini/gemini-2.5-flash"
utility = "gemini/gemini-2.5-flash-lite"
```

API keys are read from environment variables only (not stored in the config file).

You can also set env vars or pass CLI args — they take priority over the config file.

## Authentication

| Method | Best for | Setup |
|--------|----------|-------|
| **CLI Auth** | Local development | Log in with `gh auth login` or `glab auth login` |
| **API Token** | CI pipelines, Docker, self-hosted | Set `GITHUB_API_TOKEN` or `GITLAB_API_TOKEN` |

## CLI Options

```bash
reviewate \
  --repo owner/repo \
  --pr 123 \
  --platform github \
  --review \            # Run review pipeline
  --summary \           # Generate PR summary
  --dry-run \           # Don't post comments
  --review-model anthropic/claude-sonnet-4  # Override review tier model
  --utility-model gemini/gemini-2.5-flash-lite  # Override utility tier model
```

## Architecture

### Multi-Agent Pipeline

```text
PR Diff
  │
  ▼
Triage ──▶ 2 Review Agents (parallel, with grep/read tools)
                │
                ▼
           Synthesizer ──▶ Deduplicate ──▶ Fact Checker ──▶ Style
                                                              │
                                                              ▼
                                                        Post Comments
```

1. **TriageAgent** — Analyzes PR complexity, determines reasoning effort
2. **IssueExplorerAgent** — Finds and summarizes linked issues
3. **SimpleReviewAgent** (x2, parallel) — Reviews code with search/read tools
4. **SynthesizerAgent** — Combines findings from both reviewers
5. **DuplicateAgent** — Removes duplicates with existing human comments
6. **FactCheckerAgent** — Verifies every claim against actual code
7. **StyleAgent** — Final formatting (makes reviews concise)

### Two-Tier Model Configuration

Agents are grouped into tiers so you can use a strong model for critical analysis and a fast/cheap model for supporting tasks:

| Tier | Agents | Purpose |
|------|--------|---------|
| **REVIEW** | triage, review (x2), fact_checker | Critical analysis |
| **UTILITY** | style, duplicate, issue_explorer, summarizer, output_parser | Supporting tasks |

### Code Structure

```text
code_reviewer/
├── main.py              # CLI entry point
├── config.py            # Two-tier model configuration
├── config_file.py       # ~/.reviewate/config.toml handling
├── output.py            # Progress tracking & result output
├── adaptors/
│   ├── factory.py       # Platform handler factory
│   ├── _transport.py    # Abstract transport (APIClient protocol)
│   ├── _http.py         # HTTP client (httpx)
│   ├── _cli.py          # CLI fallback (gh api / glab api)
│   ├── repository/      # PR/MR diffs, reviews, comments
│   └── issue/           # Linked issue fetching
├── agents/
│   ├── base.py          # BaseAgentImpl (LLM calls, tool loop, retry)
│   ├── specialized.py   # SimpleReviewAgent, SynthesizerAgent
│   ├── triage.py        # TriageAgent
│   ├── fact_checker.py  # FactCheckerAgent
│   ├── issue_explorer.py
│   ├── duplicate.py     # DuplicateAgent
│   ├── style.py         # StyleAgent
│   ├── summarizer.py    # SummarizerAgent
│   └── tools.py         # Tool definitions for agents
├── explorer/
│   ├── explorer.py      # CodeExplorer (ripgrep search + file reads)
│   └── builder.py       # Explorer factory
├── workflows/
│   ├── review.py        # ReviewWorkflow (main pipeline)
│   ├── summary.py       # SummaryWorkflow (PR summaries)
│   └── context.py       # Linked repos, team guidelines
├── prompts/             # Jinja2 prompt templates (.txt)
└── schema/              # Data models
```

## Environment Variables

All env vars are **optional** if you have a config file (`~/.reviewate/config.toml`). Env vars override config file values when set.

| Variable | Description |
|----------|-------------|
| `REVIEW_AGENT_MODEL` | Model for review tier agents |
| `REVIEW_AGENT_PROVIDER` | Provider for review tier |
| `UTILITY_AGENT_MODEL` | Model for utility tier agents |
| `UTILITY_AGENT_PROVIDER` | Provider for utility tier |
| `GEMINI_API_KEY` | Google Gemini API key |
| `ANTHROPIC_API_KEY` | Anthropic Claude API key |
| `OPENAI_API_KEY` | OpenAI API key |
| `GITHUB_API_TOKEN` | GitHub token (optional with `gh` CLI) |
| `GITLAB_API_TOKEN` | GitLab token (optional with `glab` CLI) |

**Override priority:** CLI args > env vars > config file

## Development

```bash
# From monorepo root
make code-review-test  # Run tests
make qa                # Run linters and type checks
```

## License

AGPL-3.0 — see LICENSE file for details.
