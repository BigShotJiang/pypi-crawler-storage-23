"""Base data schemas for the workflow."""

from typing import TYPE_CHECKING, Annotated, TypeVar

from pydantic import BaseModel, Field

# Import BasicReviewOutput and other schemas that don't cause circular imports
from code_reviewer.adaptors.issue.schema import Issue
from code_reviewer.adaptors.repository.schema import (
    BasicReviewOutput,
    DiscussionItem,
    DiscussionItemType,
    DiscussionNote,
    MergeRequest,
)

# Defer imports that would cause circular imports
if TYPE_CHECKING:
    pass

# Re-export from new locations for backwards compatibility
__all__ = [
    "BasicReviewOutput",
    "DiscussionItem",
    "DiscussionItemType",
    "DiscussionNote",
    "GuardrailResult",
    "Issue",
    "MergeRequest",
    "ParsedSummaryOutput",
    "PlatformReview",
    "ReviewOutput",
    "SummaryOutput",
]


# Using string annotation to avoid circular import issues with TypeVar
PlatformReview = TypeVar("PlatformReview")


class ReviewOutput[PlatformReview](BaseModel):
    """Generic review output structure.

    Platform-specific review types will be wrapped in this structure.
    """

    reviews: Annotated[
        list[PlatformReview], Field(description="Collection of review comments/notes")
    ]


class GuardrailResult(BaseModel):
    """Result from guardrail agent checking for AI agent threats."""

    valid: Annotated[bool, Field(description="True if code is safe for AI agents to process")]
    reason: Annotated[
        str | None,
        Field(
            None,
            description="Explanation of why code is invalid (if valid=False), otherwise None",
        ),
    ]


class SummaryOutput(BaseModel):
    """Output from summarizer agent"""

    description: Annotated[str, Field(description="Comprehensive but concise summary")]


class ParsedSummaryOutput(BaseModel):
    """Output from summary parser agent"""

    description: Annotated[str, Field(description="Refined technical description")]
