"""Apply pipeline: Chrome management, prompt building, orchestration, and dashboard."""
