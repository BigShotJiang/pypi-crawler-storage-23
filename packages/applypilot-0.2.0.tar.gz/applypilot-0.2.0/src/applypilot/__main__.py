"""Enable `python -m applypilot`."""

from applypilot.cli import app

app()
