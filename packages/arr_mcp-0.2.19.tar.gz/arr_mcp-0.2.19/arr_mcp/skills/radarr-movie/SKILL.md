---
name: radarr-movie
description: Skills related to movie in Radarr.
tags: [radarr, movie]
---

# Radarr Movie Skill

This skill provides tools for managing movie within Radarr.

## Capabilities

- Access movie resources
