---
name: sonarr-qualityprofile
description: Skills related to qualityprofile in Sonarr.
tags: [sonarr, qualityprofile]
---

# Sonarr Qualityprofile Skill

This skill provides tools for managing qualityprofile within Sonarr.

## Capabilities

- Access qualityprofile resources
