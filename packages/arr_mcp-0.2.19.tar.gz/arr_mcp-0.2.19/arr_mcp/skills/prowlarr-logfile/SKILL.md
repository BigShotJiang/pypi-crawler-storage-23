---
name: prowlarr-logfile
description: Skills related to logfile in Prowlarr.
tags: [prowlarr, logfile]
---

# Prowlarr Logfile Skill

This skill provides tools for managing logfile within Prowlarr.

## Capabilities

- Access logfile resources
