---
name: radarr-namingconfig
description: Skills related to namingconfig in Radarr.
tags: [radarr, namingconfig]
---

# Radarr Namingconfig Skill

This skill provides tools for managing namingconfig within Radarr.

## Capabilities

- Access namingconfig resources
