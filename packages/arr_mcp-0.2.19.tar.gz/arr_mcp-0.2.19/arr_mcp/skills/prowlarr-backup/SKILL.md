---
name: prowlarr-backup
description: Skills related to backup in Prowlarr.
tags: [prowlarr, backup]
---

# Prowlarr Backup Skill

This skill provides tools for managing backup within Prowlarr.

## Capabilities

- Access backup resources
