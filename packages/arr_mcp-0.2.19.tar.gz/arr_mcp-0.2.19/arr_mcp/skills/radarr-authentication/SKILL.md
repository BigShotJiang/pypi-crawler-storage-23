---
name: radarr-authentication
description: Skills related to authentication in Radarr.
tags: [radarr, authentication]
---

# Radarr Authentication Skill

This skill provides tools for managing authentication within Radarr.

## Capabilities

- Access authentication resources
