---
name: sonarr-ping
description: Skills related to ping in Sonarr.
tags: [sonarr, ping]
---

# Sonarr Ping Skill

This skill provides tools for managing ping within Sonarr.

## Capabilities

- Access ping resources
