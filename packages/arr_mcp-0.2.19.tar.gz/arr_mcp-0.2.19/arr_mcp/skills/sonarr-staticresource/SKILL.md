---
name: sonarr-staticresource
description: Skills related to staticresource in Sonarr.
tags: [sonarr, staticresource]
---

# Sonarr Staticresource Skill

This skill provides tools for managing staticresource within Sonarr.

## Capabilities

- Access staticresource resources
