---
name: sonarr-qualitydefinition
description: Skills related to qualitydefinition in Sonarr.
tags: [sonarr, qualitydefinition]
---

# Sonarr Qualitydefinition Skill

This skill provides tools for managing qualitydefinition within Sonarr.

## Capabilities

- Access qualitydefinition resources
