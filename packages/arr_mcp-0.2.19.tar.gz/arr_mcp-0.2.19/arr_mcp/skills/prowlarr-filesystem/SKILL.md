---
name: prowlarr-filesystem
description: Skills related to filesystem in Prowlarr.
tags: [prowlarr, filesystem]
---

# Prowlarr Filesystem Skill

This skill provides tools for managing filesystem within Prowlarr.

## Capabilities

- Access filesystem resources
