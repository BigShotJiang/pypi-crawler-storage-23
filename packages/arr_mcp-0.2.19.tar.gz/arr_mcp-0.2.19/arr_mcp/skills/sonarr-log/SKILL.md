---
name: sonarr-log
description: Skills related to log in Sonarr.
tags: [sonarr, log]
---

# Sonarr Log Skill

This skill provides tools for managing log within Sonarr.

## Capabilities

- Access log resources
