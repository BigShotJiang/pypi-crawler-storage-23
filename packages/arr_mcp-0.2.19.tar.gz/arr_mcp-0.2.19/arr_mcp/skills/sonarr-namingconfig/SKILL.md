---
name: sonarr-namingconfig
description: Skills related to namingconfig in Sonarr.
tags: [sonarr, namingconfig]
---

# Sonarr Namingconfig Skill

This skill provides tools for managing namingconfig within Sonarr.

## Capabilities

- Access namingconfig resources
