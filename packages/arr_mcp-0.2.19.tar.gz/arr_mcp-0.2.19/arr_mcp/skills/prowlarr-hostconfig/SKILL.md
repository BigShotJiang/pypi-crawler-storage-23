---
name: prowlarr-hostconfig
description: Skills related to hostconfig in Prowlarr.
tags: [prowlarr, hostconfig]
---

# Prowlarr Hostconfig Skill

This skill provides tools for managing hostconfig within Prowlarr.

## Capabilities

- Access hostconfig resources
