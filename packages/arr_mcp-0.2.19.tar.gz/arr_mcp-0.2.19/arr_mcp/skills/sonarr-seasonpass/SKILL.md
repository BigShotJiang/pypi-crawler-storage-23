---
name: sonarr-seasonpass
description: Skills related to seasonpass in Sonarr.
tags: [sonarr, seasonpass]
---

# Sonarr Seasonpass Skill

This skill provides tools for managing seasonpass within Sonarr.

## Capabilities

- Access seasonpass resources
