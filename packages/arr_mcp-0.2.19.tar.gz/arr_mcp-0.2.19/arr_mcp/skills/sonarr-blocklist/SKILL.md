---
name: sonarr-blocklist
description: Skills related to blocklist in Sonarr.
tags: [sonarr, blocklist]
---

# Sonarr Blocklist Skill

This skill provides tools for managing blocklist within Sonarr.

## Capabilities

- Access blocklist resources
