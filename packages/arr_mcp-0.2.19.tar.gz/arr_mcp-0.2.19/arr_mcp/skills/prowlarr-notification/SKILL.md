---
name: prowlarr-notification
description: Skills related to notification in Prowlarr.
tags: [prowlarr, notification]
---

# Prowlarr Notification Skill

This skill provides tools for managing notification within Prowlarr.

## Capabilities

- Access notification resources
