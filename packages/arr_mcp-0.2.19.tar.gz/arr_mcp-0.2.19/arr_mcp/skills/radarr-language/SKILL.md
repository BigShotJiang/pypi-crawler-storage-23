---
name: radarr-language
description: Skills related to language in Radarr.
tags: [radarr, language]
---

# Radarr Language Skill

This skill provides tools for managing language within Radarr.

## Capabilities

- Access language resources
