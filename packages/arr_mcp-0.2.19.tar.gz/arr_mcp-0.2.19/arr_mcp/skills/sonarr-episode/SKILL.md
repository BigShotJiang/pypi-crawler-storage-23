---
name: sonarr-episode
description: Skills related to episode in Sonarr.
tags: [sonarr, episode]
---

# Sonarr Episode Skill

This skill provides tools for managing episode within Sonarr.

## Capabilities

- Access episode resources
