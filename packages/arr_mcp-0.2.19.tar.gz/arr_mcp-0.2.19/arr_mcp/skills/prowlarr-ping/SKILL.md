---
name: prowlarr-ping
description: Skills related to ping in Prowlarr.
tags: [prowlarr, ping]
---

# Prowlarr Ping Skill

This skill provides tools for managing ping within Prowlarr.

## Capabilities

- Access ping resources
