---
name: radarr-staticresource
description: Skills related to staticresource in Radarr.
tags: [radarr, staticresource]
---

# Radarr Staticresource Skill

This skill provides tools for managing staticresource within Radarr.

## Capabilities

- Access staticresource resources
