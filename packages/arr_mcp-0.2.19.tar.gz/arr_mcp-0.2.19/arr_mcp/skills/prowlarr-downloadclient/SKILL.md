---
name: prowlarr-downloadclient
description: Skills related to downloadclient in Prowlarr.
tags: [prowlarr, downloadclient]
---

# Prowlarr Downloadclient Skill

This skill provides tools for managing downloadclient within Prowlarr.

## Capabilities

- Access downloadclient resources
