---
name: sonarr-authentication
description: Skills related to authentication in Sonarr.
tags: [sonarr, authentication]
---

# Sonarr Authentication Skill

This skill provides tools for managing authentication within Sonarr.

## Capabilities

- Access authentication resources
