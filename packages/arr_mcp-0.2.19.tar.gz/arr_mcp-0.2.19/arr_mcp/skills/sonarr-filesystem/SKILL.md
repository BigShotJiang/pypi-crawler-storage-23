---
name: sonarr-filesystem
description: Skills related to filesystem in Sonarr.
tags: [sonarr, filesystem]
---

# Sonarr Filesystem Skill

This skill provides tools for managing filesystem within Sonarr.

## Capabilities

- Access filesystem resources
