---
name: sonarr-hostconfig
description: Skills related to hostconfig in Sonarr.
tags: [sonarr, hostconfig]
---

# Sonarr Hostconfig Skill

This skill provides tools for managing hostconfig within Sonarr.

## Capabilities

- Access hostconfig resources
