---
name: sonarr-command
description: Skills related to command in Sonarr.
tags: [sonarr, command]
---

# Sonarr Command Skill

This skill provides tools for managing command within Sonarr.

## Capabilities

- Access command resources
