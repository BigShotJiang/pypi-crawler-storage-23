---
name: radarr-extrafile
description: Skills related to extrafile in Radarr.
tags: [radarr, extrafile]
---

# Radarr Extrafile Skill

This skill provides tools for managing extrafile within Radarr.

## Capabilities

- Access extrafile resources
