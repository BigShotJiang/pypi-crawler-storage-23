---
name: radarr-downloadclient
description: Skills related to downloadclient in Radarr.
tags: [radarr, downloadclient]
---

# Radarr Downloadclient Skill

This skill provides tools for managing downloadclient within Radarr.

## Capabilities

- Access downloadclient resources
