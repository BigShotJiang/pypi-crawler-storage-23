---
name: sonarr-indexerconfig
description: Skills related to indexerconfig in Sonarr.
tags: [sonarr, indexerconfig]
---

# Sonarr Indexerconfig Skill

This skill provides tools for managing indexerconfig within Sonarr.

## Capabilities

- Access indexerconfig resources
