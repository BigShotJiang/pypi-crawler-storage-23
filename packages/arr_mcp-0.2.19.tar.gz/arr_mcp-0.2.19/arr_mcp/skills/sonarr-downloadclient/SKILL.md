---
name: sonarr-downloadclient
description: Skills related to downloadclient in Sonarr.
tags: [sonarr, downloadclient]
---

# Sonarr Downloadclient Skill

This skill provides tools for managing downloadclient within Sonarr.

## Capabilities

- Access downloadclient resources
