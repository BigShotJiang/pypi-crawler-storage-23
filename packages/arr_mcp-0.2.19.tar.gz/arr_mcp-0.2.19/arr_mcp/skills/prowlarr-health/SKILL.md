---
name: prowlarr-health
description: Skills related to health in Prowlarr.
tags: [prowlarr, health]
---

# Prowlarr Health Skill

This skill provides tools for managing health within Prowlarr.

## Capabilities

- Access health resources
