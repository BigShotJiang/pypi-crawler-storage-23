---
name: sonarr-localization
description: Skills related to localization in Sonarr.
tags: [sonarr, localization]
---

# Sonarr Localization Skill

This skill provides tools for managing localization within Sonarr.

## Capabilities

- Access localization resources
