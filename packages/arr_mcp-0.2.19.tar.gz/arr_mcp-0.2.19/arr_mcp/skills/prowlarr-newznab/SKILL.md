---
name: prowlarr-newznab
description: Skills related to newznab in Prowlarr.
tags: [prowlarr, newznab]
---

# Prowlarr Newznab Skill

This skill provides tools for managing newznab within Prowlarr.

## Capabilities

- Access newznab resources
