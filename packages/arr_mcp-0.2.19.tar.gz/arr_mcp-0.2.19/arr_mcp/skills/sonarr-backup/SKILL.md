---
name: sonarr-backup
description: Skills related to backup in Sonarr.
tags: [sonarr, backup]
---

# Sonarr Backup Skill

This skill provides tools for managing backup within Sonarr.

## Capabilities

- Access backup resources
