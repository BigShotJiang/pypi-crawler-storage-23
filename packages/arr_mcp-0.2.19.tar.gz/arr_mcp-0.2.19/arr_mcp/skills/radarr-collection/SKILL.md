---
name: radarr-collection
description: Skills related to collection in Radarr.
tags: [radarr, collection]
---

# Radarr Collection Skill

This skill provides tools for managing collection within Radarr.

## Capabilities

- Access collection resources
