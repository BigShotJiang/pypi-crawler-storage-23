---
name: sonarr-episodefile
description: Skills related to episodefile in Sonarr.
tags: [sonarr, episodefile]
---

# Sonarr Episodefile Skill

This skill provides tools for managing episodefile within Sonarr.

## Capabilities

- Access episodefile resources
