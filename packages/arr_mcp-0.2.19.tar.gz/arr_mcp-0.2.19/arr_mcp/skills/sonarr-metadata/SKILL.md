---
name: sonarr-metadata
description: Skills related to metadata in Sonarr.
tags: [sonarr, metadata]
---

# Sonarr Metadata Skill

This skill provides tools for managing metadata within Sonarr.

## Capabilities

- Access metadata resources
