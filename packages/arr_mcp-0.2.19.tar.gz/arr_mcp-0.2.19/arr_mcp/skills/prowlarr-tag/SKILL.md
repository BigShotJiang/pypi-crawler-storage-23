---
name: prowlarr-tag
description: Skills related to tag in Prowlarr.
tags: [prowlarr, tag]
---

# Prowlarr Tag Skill

This skill provides tools for managing tag within Prowlarr.

## Capabilities

- Access tag resources
