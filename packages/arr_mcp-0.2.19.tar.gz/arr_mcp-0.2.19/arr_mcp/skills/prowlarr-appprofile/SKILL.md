---
name: prowlarr-appprofile
description: Skills related to appprofile in Prowlarr.
tags: [prowlarr, appprofile]
---

# Prowlarr Appprofile Skill

This skill provides tools for managing appprofile within Prowlarr.

## Capabilities

- Access appprofile resources
