---
name: sonarr-tagdetails
description: Skills related to tagdetails in Sonarr.
tags: [sonarr, tagdetails]
---

# Sonarr Tagdetails Skill

This skill provides tools for managing tagdetails within Sonarr.

## Capabilities

- Access tagdetails resources
