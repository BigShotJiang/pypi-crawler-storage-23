---
name: sonarr-calendarfeed
description: Skills related to calendarfeed in Sonarr.
tags: [sonarr, calendarfeed]
---

# Sonarr Calendarfeed Skill

This skill provides tools for managing calendarfeed within Sonarr.

## Capabilities

- Access calendarfeed resources
