---
name: prowlarr-uiconfig
description: Skills related to uiconfig in Prowlarr.
tags: [prowlarr, uiconfig]
---

# Prowlarr Uiconfig Skill

This skill provides tools for managing uiconfig within Prowlarr.

## Capabilities

- Access uiconfig resources
