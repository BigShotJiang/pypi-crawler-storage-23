---
name: prowlarr-indexerproxy
description: Skills related to indexerproxy in Prowlarr.
tags: [prowlarr, indexerproxy]
---

# Prowlarr Indexerproxy Skill

This skill provides tools for managing indexerproxy within Prowlarr.

## Capabilities

- Access indexerproxy resources
