---
name: sonarr-update
description: Skills related to update in Sonarr.
tags: [sonarr, update]
---

# Sonarr Update Skill

This skill provides tools for managing update within Sonarr.

## Capabilities

- Access update resources
