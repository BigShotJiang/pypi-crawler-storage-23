---
name: sonarr-seriesimport
description: Skills related to seriesimport in Sonarr.
tags: [sonarr, seriesimport]
---

# Sonarr Seriesimport Skill

This skill provides tools for managing seriesimport within Sonarr.

## Capabilities

- Access seriesimport resources
