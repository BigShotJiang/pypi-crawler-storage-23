---
name: prowlarr-apiinfo
description: Skills related to apiinfo in Prowlarr.
tags: [prowlarr, apiinfo]
---

# Prowlarr Apiinfo Skill

This skill provides tools for managing apiinfo within Prowlarr.

## Capabilities

- Access apiinfo resources
