---
name: sonarr-manualimport
description: Skills related to manualimport in Sonarr.
tags: [sonarr, manualimport]
---

# Sonarr Manualimport Skill

This skill provides tools for managing manualimport within Sonarr.

## Capabilities

- Access manualimport resources
