---
name: sonarr-customfilter
description: Skills related to customfilter in Sonarr.
tags: [sonarr, customfilter]
---

# Sonarr Customfilter Skill

This skill provides tools for managing customfilter within Sonarr.

## Capabilities

- Access customfilter resources
