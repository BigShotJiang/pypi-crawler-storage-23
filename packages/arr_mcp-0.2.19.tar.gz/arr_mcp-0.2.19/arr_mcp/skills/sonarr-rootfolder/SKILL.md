---
name: sonarr-rootfolder
description: Skills related to rootfolder in Sonarr.
tags: [sonarr, rootfolder]
---

# Sonarr Rootfolder Skill

This skill provides tools for managing rootfolder within Sonarr.

## Capabilities

- Access rootfolder resources
