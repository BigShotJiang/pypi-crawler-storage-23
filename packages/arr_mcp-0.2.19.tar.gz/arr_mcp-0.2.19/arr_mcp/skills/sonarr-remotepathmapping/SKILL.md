---
name: sonarr-remotepathmapping
description: Skills related to remotepathmapping in Sonarr.
tags: [sonarr, remotepathmapping]
---

# Sonarr Remotepathmapping Skill

This skill provides tools for managing remotepathmapping within Sonarr.

## Capabilities

- Access remotepathmapping resources
