---
name: prowlarr-task
description: Skills related to task in Prowlarr.
tags: [prowlarr, task]
---

# Prowlarr Task Skill

This skill provides tools for managing task within Prowlarr.

## Capabilities

- Access task resources
