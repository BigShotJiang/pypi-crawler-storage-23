---
name: radarr-uiconfig
description: Skills related to uiconfig in Radarr.
tags: [radarr, uiconfig]
---

# Radarr Uiconfig Skill

This skill provides tools for managing uiconfig within Radarr.

## Capabilities

- Access uiconfig resources
