"""Connection config for analyzers. Wraps utils/connection.py."""

import sys
import os

# Ensure the analysis root is importable
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.connection import init, query_df  # noqa: E402, F401


def get_connection(env: str = "local"):
    """Open a DB connection. env: 'local' (.local.env) or 'prod' (.prod.env)."""
    filename = ".local.env" if env == "local" else ".prod.env"
    return init(env_filename=filename)
