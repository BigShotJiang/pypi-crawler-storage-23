# Fix CLI/daemon version mismatch — detect and warn

The CLI (`quickcall status`) and daemon can run different versions because they're separate `uvx` invocations. The CLI version depends on the shell alias (cached per terminal session), while the daemon auto-updates via PyPI. No warning is shown when they diverge.

Reference: https://github.com/quickcall-dev/trace/issues/66

## Key files

- `qc_trace/daemon/main.py` — `_write_pid()` at line 224
- `qc_trace/cli/traced.py` — `cmd_status()` at line 253

## Changes needed

### 1. Write daemon version on startup (`main.py`)

In `_write_pid()`, also write `~/.quickcall-trace/daemon_version`:

```python
version_file = self.config.base_dir / "daemon_version"
version_file.write_text(__version__)
```

### 2. Detect mismatch in `cmd_status()` (`traced.py`)

Read `daemon_version` file and compare against CLI's `__version__`:

```python
daemon_version_file = QC_TRACE_DIR / "daemon_version"
if daemon_version_file.exists():
    daemon_ver = daemon_version_file.read_text().strip()
    if daemon_ver != __version__:
        print(f"  ⚠ CLI is v{__version__} but daemon is v{daemon_ver} — run: source ~/.zshrc")
```

### 3. Also show daemon version in status output

Instead of showing the CLI's version at the top, show:
```
  QuickCall Trace v0.4.11 (daemon) / v0.4.10 (cli) ⚠
```

Or when they match:
```
  QuickCall Trace v0.4.11
```

## Git workflow

You are on branch `bugs-and-perf`. Commit and push as you go:

```bash
git add -A && git commit -m "fix: <description>" && git push origin bugs-and-perf
```

After each meaningful change, update the tracking issue with a comment:

```bash
gh issue comment 66 --repo quickcall-dev/trace --body "**Version mismatch update**: <what was done>"
```

## Verification

1. Start daemon on version X, run `quickcall status` on version Y — should see warning
2. Run `source ~/.zshrc` — warning should disappear
3. `uv run pytest tests/` should pass
4. Bump version and publish to PyPI using `.prod.env` for the token
