# Agent: Heuristic Analyzers A6-A10

## Your Task

Implement 5 heuristic analyzers in `analysis-14022026/analyzers/`. These are independent — each reads session/message data and outputs a JSON dict.

**Read these first:**
- `analysis-14022026/session_view_scripts/research/ideation.md` — full feature specs (sections A6-A10)
- `analysis-14022026/session_view_scripts/research/04_undo_revert_and_ai_behavior.py` — AI clarification patterns
- `analysis-14022026/session_view_scripts/research/03_autonomy_and_streaks.py` — tool usage patterns

**Read the shared foundation code (created by another agent, may not exist yet — create stubs if needed):**
- `analysis-14022026/analyzers/base.py` — BaseAnalyzer class
- `analysis-14022026/analyzers/helpers.py` — tool name sets, `clean_user_content()`, `categorize_tool()`, `is_shell_error()`, `is_compaction_message()`

If `base.py`/`helpers.py` don't exist yet, create them with the minimal interface you need. The foundation agent is building them in parallel.

## Analyzers to Implement

### A6: `a06_ai_clarification.py` (ideation.md section A6)
Detect when AI asks real clarification questions (not sign-off pleasantries).
- Scan `assistant` messages for: `would you like me to`, `do you want me to`, `should I `, `could you clarify`, `which one`, `before I proceed`, `would you prefer`
- **Exclude** sign-offs: `let me know`, `feel free to`, `if you have any questions`
- Per-session: `ai_asked_clarification`, `clarification_count`, `clarification_position` (early=first 20%, mid, late)

### A7: `a07_conversation_dynamics.py` (ideation.md section A7)
- Per-session: `total_turns` (each user msg starts a turn), `avg_ai_msgs_per_turn` ((assistant + tool_call) / user_messages), `deepest_turn` (max AI msgs between consecutive user msgs), `user_to_ai_char_ratio` (sum user content len / sum assistant content len), `session_duration_min` ((last_timestamp - first_timestamp) in minutes), `avg_gap_between_user_msgs_sec`, `longest_gap_sec`

### A8: `a08_session_linkage.py` (ideation.md section A8)
- Needs ALL sessions for the user (not just one), to compute cross-session relationships
- Per-session: `is_continuation` (first user msg is compaction), `compaction_count` (msgs starting with compaction text), `time_gap_to_prev_session_min` (time between this session start and prev session end, same user+repo), `is_sequential` (gap < 120 min and same repo), `has_parallel_sessions` (another session overlaps in time), `parallel_same_repo` (overlapping + same repo)
- Sort sessions by start time, walk sequentially

### A9: `a09_tool_profile.py` (ideation.md section A9)
- Per-session: count tool_calls by category using `categorize_tool()`: `explore_count`, `edit_count`, `shell_count`, `plan_count`, `delegation_count`, `web_count`, `mcp_count`
- Computed: `explore_edit_ratio` (explore / max(edit, 1)), `unique_tools_used` (distinct tool names), `dominant_tool_category` (category with most calls)

### A10: `a10_error_detection.py` (ideation.md section A10)
- Since `tool_result.status` is useless (36,893 success vs 14 failure), detect errors from `tool_result.output` content using `is_shell_error()` from helpers
- Per-session: `shell_error_count`, `consecutive_shell_errors` (max streak of shell tool_results with errors), `error_cascade_count` (sequences of 3+ consecutive tool_results with errors), `error_then_user_rescue` (error cascade followed by user message)

## Output Format

Each analyzer returns a dict with:
- Summary stats
- `per_session`: list of dicts, one per session with `session_id` + all computed features

## Commit Convention
Use conventional commits: `feat:`, `fix:`, etc. No Claude/Anthropic attribution.
