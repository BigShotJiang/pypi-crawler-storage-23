# PROMPTING PATTERNS Agent Instructions

Your job: analyze HOW this developer (Nikhil) prompts across all 34 sessions. Not coach tips. Not advice. Just patterns — what does he actually do?

## Paths

- **Parsed sessions**: `docs/run1-09022026/analysis-outputs/parsed/` (34 JSON files — read `user_messages` from each)
- **Raw JSONL**: `docs/internal/2026/01/{28,29,30,31}/` (for exact quotes)
- **Deep dives**: `docs/run1-09022026/analysis-outputs/deep_dive/` (for context)
- **Output**: `docs/run1-09022026/analysis-outputs/prompting-patterns.md`

## What to Analyze

Read EVERY user message across all 34 sessions. You're looking for patterns in how this person communicates with AI. Not whether they're "good" or "bad" — just what they DO.

### Dimensions to examine:

**1. Prompt structure**
- Does he write long detailed prompts or short ones?
- Does he give context upfront or let the AI ask?
- Does he paste errors/tracebacks or describe them?
- Does he reference files/line numbers or speak abstractly?

**2. Iteration style**
- When the AI gives a wrong answer, how does he correct it? (re-explain, paste error, try different phrasing, give up)
- Does he build on previous responses or start fresh?
- How many back-and-forths before he gets what he wants?

**3. First message patterns**
- What does his opening message typically look like?
- Group the first messages into archetypes (e.g., "here's an error fix it", "build me X", "one-word test", "detailed spec")

**4. Session-to-session evolution**
- Does his prompting change from Jan 28 to Jan 31?
- Does he learn from AI interactions and adjust?
- Are there sessions where he clearly got better vs worse?

**5. Copy-paste behavior**
- Does he paste full error outputs or summarize?
- Does he paste code snippets with context or just the broken line?
- Does he re-paste the same thing across sessions?

**6. What he NEVER does**
- Patterns that experienced AI users do but he doesn't (e.g., giving examples, specifying output format, providing constraints, setting persona)

## Output Format

Write `prompting-patterns.md`:

```markdown
# How Nikhil Prompts: Pattern Analysis Across 34 Sessions

## At a Glance
[3-4 sentences summarizing his prompting fingerprint]

## Opening Moves
[Analysis of first messages, grouped by archetype, with EXACT QUOTES from multiple sessions]

## When Things Go Wrong
[How he handles AI mistakes/misunderstandings, with EXACT QUOTES showing the correction patterns]

## The Prompt Spectrum
[Show his range — from his most minimal prompt to his most detailed, with EXACT QUOTES]

> Minimal: "{actual shortest meaningful prompt}"
> Maximal: "{actual most detailed prompt}"

## Evolution Over 4 Days
[Did anything change? Show day-by-day with evidence]

## Signature Patterns
[3-5 distinctive things he consistently does, each with 2+ examples]

### Pattern 1: [Name]
> "{quote from session A}"
> "{quote from session B}"

### Pattern 2: [Name]
...

## Blind Spots
[Things he never does that could help — but frame as observations, NOT advice. Just "he never X" with evidence, not "he should X"]

## Raw Data
| Session | First Message (truncated) | Length | Style |
|---------|--------------------------|--------|-------|
| ... | ... | ... | ... |
```

### EVIDENCE RULES
- Every claim must have at least 2 EXACT QUOTES from different sessions
- No paraphrasing — copy the actual text
- Include the session filename with each quote so it's traceable
- Skip trivial sessions (context-only, single "hi", etc.) — they add noise not signal
- Aim for 20+ quotes total across the analysis

## Constraints
- Do NOT give advice or coach tips. This is DESCRIPTIVE, not prescriptive.
- Do NOT do git operations
- Do NOT modify files outside the output directory
- Focus on non-trivial sessions — skip the ones that are just "hi" + close
