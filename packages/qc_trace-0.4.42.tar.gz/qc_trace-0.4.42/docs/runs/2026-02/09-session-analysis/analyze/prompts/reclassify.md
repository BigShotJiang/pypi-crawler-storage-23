# RECLASSIFIER Agent Instructions

The automated parser classified ALL 34 sessions as "bug-fix" which is clearly wrong. Your job: re-classify every session by actually reading the content.

## Paths

- **Parsed sessions**: `docs/run1-09022026/analysis-outputs/parsed/` (34 JSON files)
- **Raw JSONL**: `docs/internal/2026/01/{28,29,30,31}/`
- **Output**: `docs/run1-09022026/analysis-outputs/reclassification.json`
- **Updated metrics**: `docs/run1-09022026/analysis-outputs/metrics-v2.json`

## Classification Rules

Read each parsed JSON's `user_messages` and `assistant_messages`. Classify based on the ACTUAL CONTENT of what the developer asked for, not just keyword matching.

### Session Type (pick the PRIMARY intent):
- **bug-fix**: Developer is debugging something broken — errors, tracebacks, unexpected behavior
- **feature**: Building something new — new function, endpoint, UI component, capability
- **setup**: Environment, config, dependencies, project scaffolding, CI/CD
- **exploration**: Asking questions to understand code/concepts, no code changes intended
- **refactor**: Restructuring existing working code — rename, reorganize, optimize
- **context-only**: Session has no real interaction — just opened and closed, or a single "hi"

### Outcome:
- **context-only**: Very few events (<10) AND no meaningful exchange happened
- **resolved**: The task was completed — code was written/fixed, developer confirmed it works or moved on satisfied
- **partial**: Some progress but not fully done
- **abandoned**: Developer gave up or session ended abruptly mid-problem

### Trivial flag:
- Mark a session as `"trivial": true` if it has fewer than 3 meaningful user messages OR total duration < 30 seconds OR it's context-only
- These sessions should NOT get coach tips or deep analysis — they're noise

## Output Format

Write `reclassification.json`:
```json
{
  "sessions": [
    {
      "filename": "rollout-2026-01-28T15-51-17-...",
      "old_type": "bug-fix",
      "new_type": "setup",
      "old_outcome": "resolved",
      "new_outcome": "resolved",
      "trivial": false,
      "confidence": "high",
      "reasoning": "Developer asked to set up project structure and install dependencies"
    }
  ],
  "summary": {
    "by_type": {"bug-fix": 5, "feature": 8, "setup": 4, "exploration": 3, "refactor": 2, "context-only": 12},
    "by_outcome": {"resolved": 15, "partial": 5, "abandoned": 2, "context-only": 12},
    "trivial_count": 14,
    "non_trivial_count": 20,
    "changes_from_original": 28
  }
}
```

Also write `metrics-v2.json` with the corrected aggregates (same format as original `metrics.json` but with correct classifications).

### Ground Truth (must match):
- `rollout-2026-01-28T17-08-14` (9 lines) → `context-only`, trivial
- `rollout-2026-01-28T15-51-17` (62 lines) → `setup`, non-trivial
- `rollout-2026-01-29T22-48-55` (228 lines) → `bug-fix`, non-trivial

## Process
1. Read each parsed JSON (user_messages field is enough for most)
2. For ambiguous cases, read the raw JSONL for full context
3. Write the reclassification.json
4. Write metrics-v2.json

## Constraints
- Do NOT do git operations
- Do NOT modify files outside the output directory
