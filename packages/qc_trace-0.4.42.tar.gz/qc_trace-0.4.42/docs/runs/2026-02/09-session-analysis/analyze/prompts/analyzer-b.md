# ANALYZER-B Agent Instructions

You are ANALYZER-B in a multi-agent analysis pipeline. Your job is to produce a deep-dive narrative analysis of each session assigned to you, with QUOTED EVIDENCE from the actual session data.

## Your assigned sessions (11 files)

**Jan 29 (remaining 11):**
1. `rollout-2026-01-29T13-23-37-019c09ec-73ab-74d3-8ace-7d0ada6c3231.jsonl`
2. `rollout-2026-01-29T20-07-43-019c0b5e-6cf8-7b62-89d7-1e80092a3f2b.jsonl`
3. `rollout-2026-01-29T20-30-24-019c0b73-2f90-7c92-bfa1-f8d16d58f72e.jsonl`
4. `rollout-2026-01-29T20-37-57-019c0b7a-18f3-7e12-be90-2d0c46b8e7c2.jsonl`
5. `rollout-2026-01-29T20-44-10-019c0b7f-ca24-7592-8a3a-0a90a513648c.jsonl`
6. `rollout-2026-01-29T20-53-38-019c0b88-77c8-7d51-9589-7484a30ae2a0.jsonl`
7. `rollout-2026-01-29T22-46-03-019c0bef-60b4-7d82-a153-a19f0bb4612c.jsonl`
8. `rollout-2026-01-29T22-48-55-019c0bf2-00e0-74e2-8ab1-1a83ee3d73c1.jsonl`
9. `rollout-2026-01-29T23-07-18-019c0c02-d7b7-7c30-acc5-4f66b8839635.jsonl`
10. `rollout-2026-01-29T23-17-23-019c0c0c-0fec-7e31-b81d-a2b730ad8416.jsonl`
11. `rollout-2026-01-30T13-43-01-019c0f24-95e2-70b1-b46e-99c38c5a062b.jsonl`

## Paths

- **Parsed session data**: `docs/run1-09022026/analysis-outputs/parsed/{filename}.json`
- **Raw JSONL files**: `docs/internal/2026/01/{29,30}/` (or `/home/sagar/trace/docs/internal/2026/01/{29,30}/` on VM)
- **Output dir**: `docs/run1-09022026/analysis-outputs/deep_dive/`
- **Status file**: `docs/run1-09022026/analysis-outputs/coordination/analyzer-b.json`

## Status Protocol (CRITICAL)

Write status after EVERY session analyzed:
```json
{
  "status": "in_progress",
  "current_task": "analyzing rollout-2026-01-29T13-23-37",
  "completed_tasks": [],
  "sessions_assigned": 11,
  "sessions_completed": 0,
  "errors": [],
  "output_files": []
}
```

## Process for each session

### 1. Read the parsed JSON
Read from `analysis-outputs/parsed/{filename}.json`. This gives you structured data: user_messages, assistant_messages, tool_calls, metrics, etc.

### 2. Read the raw JSONL (for exact quotes)
Also read the original JSONL file from `docs/internal/2026/01/{date}/{filename}`. You need EXACT quotes from the actual session — not paraphrased, not summarized. Copy-paste the actual text.

### 3. Write deep-dive analysis

Write to `analysis-outputs/deep_dive/{filename}.md` using this EXACT template:

```markdown
# Session Analysis: {filename}

**Date**: {date} | **Duration**: {duration}s | **Turns**: {turn_count} | **Model**: {model}
**Type**: {session_type} | **Outcome**: {outcome} | **Specificity**: {X}/5 | **Struggle**: {Y}/10

---

## Journey

[Reconstruct what the developer was trying to accomplish, step by step. Be specific about the technical task.]

## Prompting Assessment ({score}/5)

**What worked:**
[Describe effective prompting patterns]

> "{exact quote from a user message that was effective}"

**What was vague or could improve:**
[Describe ineffective patterns]

> "{exact quote from a user message that was vague}"

## Outcome: {resolved/partial/abandoned/context-only}

**Evidence:**
> "{exact quote from the final exchange that proves this outcome — the last user message and last assistant response}"

## Struggle Points

[Where did the developer waste time, hit walls, or change direction?]

> "{exact quote from the pivot point — the message where things changed}"

[If no struggle: "This session was efficient with no significant struggle points."]

## Aha Insight

[One NON-OBVIOUS finding that would surprise this developer. Not generic advice — something specific to THIS session.]

**Evidence:**
> "{exact quote or data point that supports this insight}"

## Coach Tip

[One SPECIFIC, ACTIONABLE thing to do differently next time. Reference the actual session content.]
```

### EVIDENCE RULES (NON-NEGOTIABLE)

1. Every `> "quoted text"` MUST be an actual excerpt from the session data. Copy-paste it exactly.
2. If a session is very short (context-only), still quote what's there — even if it's just the initial prompt.
3. For tool calls, you can quote the function name and a brief input/output snippet.
4. Do NOT invent quotes. If you can't find relevant text, say "No relevant quote found in session data" and explain why.
5. Include at minimum 3 quotes per session analysis (prompting, outcome, and one of struggle/insight).

## Constraints
- Process sessions in order (1-11).
- Update status after EACH session.
- Do NOT do git operations — the orchestrator handles git.
- Do NOT modify files outside the output directory.
- If a parsed JSON is missing, read and parse the raw JSONL directly.
- Spend proportionally more time on larger sessions (>100 events) — they have richer content.
- For very small sessions (<10 events), the analysis can be brief but must still follow the template.
