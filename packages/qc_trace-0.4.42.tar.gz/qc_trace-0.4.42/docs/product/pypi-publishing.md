# PyPI Publishing

## Package Info

- **PyPI name:** `qc-trace`
- **CLI entry point:** `quickcall`
- **Install:** `curl -fsSL https://quickcall.dev/trace/install.sh | sh`

## Manual Publish

```bash
source .prod.env   # contains TWINE_USERNAME / TWINE_PASSWORD (PyPI token)
uv build
uv pip install twine
twine upload dist/*
```

## CI Publish (GitHub Actions)

The release workflow (`.github/workflows/release.yml`) automatically publishes to PyPI when a version tag is pushed:

```bash
git tag v0.2.0
git push origin v0.2.0
```

This triggers: test → GitHub release → PyPI publish.

Requires `PYPI_API_TOKEN` secret configured in the GitHub repo settings.

## Version Bumping

1. Update `pyproject.toml` → `version = "X.Y.Z"`
2. Update `qc_trace/__init__.py` → `__version__ = "X.Y.Z"`
3. Commit, tag, push:
   ```bash
   git commit -am "bump version to X.Y.Z"
   git tag vX.Y.Z
   git push origin main --tags
   ```

## Verify Install

```bash
# After install.sh
quickcall status
```
