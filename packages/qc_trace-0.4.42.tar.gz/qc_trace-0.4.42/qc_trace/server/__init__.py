"""HTTP ingest server for qc-trace.

Accepts NormalizedMessage batches over HTTP and writes to PostgreSQL.
"""

from qc_trace.server.app import create_server, run_server
from qc_trace.server.batch import BatchAccumulator

__all__ = ["create_server", "run_server", "BatchAccumulator"]
