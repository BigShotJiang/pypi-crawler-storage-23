import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Use VITE_API_URL to point at a remote server, e.g.:
//   VITE_API_URL=https://trace.quickcall.dev npm run dev
const apiTarget = process.env.VITE_API_URL || 'http://localhost:19777'

const proxyOpts = {
  target: apiTarget,
  changeOrigin: true,
  secure: true,
}

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/api': proxyOpts,
      '/health': proxyOpts,
      '/ingest': proxyOpts,
    },
  },
})
