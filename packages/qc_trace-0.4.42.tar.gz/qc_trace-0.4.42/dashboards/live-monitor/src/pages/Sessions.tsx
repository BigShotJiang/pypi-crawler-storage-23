import { SessionsTable } from '../components/SessionsTable';

export function Sessions() {
  return (
    <div className="space-y-6">
      <SessionsTable />
    </div>
  );
}
