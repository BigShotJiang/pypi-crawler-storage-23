import { useState, useCallback } from 'react';

const STORAGE_KEY = 'qc_trace_org';

export function useOrg() {
  const [org, setOrgState] = useState<string | undefined>(() => {
    return localStorage.getItem(STORAGE_KEY) || undefined;
  });

  const setOrg = useCallback((value: string | undefined) => {
    if (value) {
      localStorage.setItem(STORAGE_KEY, value);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
    setOrgState(value);
  }, []);

  return { org, setOrg } as const;
}
