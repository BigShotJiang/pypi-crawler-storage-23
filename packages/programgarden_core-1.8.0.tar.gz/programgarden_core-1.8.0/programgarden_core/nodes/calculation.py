"""
ProgramGarden Core - Calculation Nodes

Note: CustomPnLNode has been removed.
RealAccountNode already provides basic P&L calculation via StockAccountTracker.
"""

# 이 파일은 향후 계산 관련 노드 추가를 위해 유지됩니다.
# 현재 사용되는 노드가 없습니다.
