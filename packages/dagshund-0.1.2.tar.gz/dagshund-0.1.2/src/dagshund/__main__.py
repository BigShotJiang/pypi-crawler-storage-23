"""Allow running dagshund as a module: python -m dagshund"""

from dagshund.cli import main

main()
