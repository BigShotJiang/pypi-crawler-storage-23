export { DetailPanel } from "./detail-panel.tsx";
