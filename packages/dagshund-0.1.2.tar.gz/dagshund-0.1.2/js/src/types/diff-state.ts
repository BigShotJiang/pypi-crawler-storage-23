export type DiffState = "added" | "removed" | "modified" | "unchanged";
