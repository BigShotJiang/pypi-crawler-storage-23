# Filters

::: ode_filters.filters
    handler: python
    options:
        show_object_full_path: true
        show_source: false
        show_submodules: true
        members_order: source
        show_signature_annotations: true
