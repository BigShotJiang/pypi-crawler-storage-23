"""Structured data ingestion for CSV, JSON, and SQLite (v4.7.0)."""

import csv
import hashlib
import json
import logging
import os
import sqlite3
from typing import List, Optional

_log = logging.getLogger("antaris_memory.ingest_structured")


def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class StructuredIngester:
    """Ingest structured data from CSV, JSON, and SQLite sources."""

    def from_csv(self, path: str, text_columns: Optional[List[str]] = None) -> List[dict]:
        """Ingest rows from a CSV file.

        Args:
            path: Path to the CSV file.
            text_columns: Columns to concatenate as text. If None, all columns are used.

        Returns:
            List of {text, source_url, content_hash}.
        """
        results: List[dict] = []
        source_url = f"file://{os.path.abspath(path)}"
        try:
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    try:
                        if text_columns:
                            parts = [str(row.get(col, "")) for col in text_columns if row.get(col)]
                        else:
                            parts = [str(v) for v in row.values() if v]
                        text = " | ".join(parts).strip()
                        if not text:
                            continue
                        results.append({
                            "text": text,
                            "source_url": source_url,
                            "content_hash": _content_hash(text),
                        })
                    except Exception as e:
                        _log.warning("Skipping CSV row: %s", e)
        except Exception as e:
            _log.error("Failed to read CSV %s: %s", path, e)
        return results

    def from_json(self, path: str) -> List[dict]:
        """Ingest from a JSON file (list-of-dicts or flat dict).

        Args:
            path: Path to the JSON file.

        Returns:
            List of {text, source_url, content_hash}.
        """
        results: List[dict] = []
        source_url = f"file://{os.path.abspath(path)}"
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)

            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = [data]
            else:
                return results

            for item in items:
                try:
                    if isinstance(item, dict):
                        parts = [str(v) for v in item.values() if v]
                        text = " | ".join(parts).strip()
                    else:
                        text = str(item).strip()
                    if not text:
                        continue
                    results.append({
                        "text": text,
                        "source_url": source_url,
                        "content_hash": _content_hash(text),
                    })
                except Exception as e:
                    _log.warning("Skipping JSON item: %s", e)
        except Exception as e:
            _log.error("Failed to read JSON %s: %s", path, e)
        return results

    def from_sqlite(self, db_path: str, query: str) -> List[dict]:
        """Ingest rows from a SQLite query.

        Args:
            db_path: Path to the SQLite database.
            query: SQL SELECT query to execute.

        Returns:
            List of {text, source_url, content_hash}.
        """
        results: List[dict] = []
        source_url = f"file://{os.path.abspath(db_path)}"
        try:
            conn = sqlite3.connect(db_path)
            try:
                cursor = conn.execute(query)
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                for row in cursor:
                    try:
                        parts = [str(v) for v in row if v is not None]
                        text = " | ".join(parts).strip()
                        if not text:
                            continue
                        results.append({
                            "text": text,
                            "source_url": source_url,
                            "content_hash": _content_hash(text),
                        })
                    except Exception as e:
                        _log.warning("Skipping SQLite row: %s", e)
            finally:
                conn.close()
        except Exception as e:
            _log.error("Failed to query SQLite %s: %s", db_path, e)
        return results
