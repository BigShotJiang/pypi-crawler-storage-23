"""
tests/test_v46_scaling.py — antaris-memory v4.6.0 feature tests.

Covers:
 - WAL write / read / apply_wal_entries / flush at 500 entries
 - SearchEngine.save_index / load_index / corrupt-fallback / persistence
 - ShardManager routing by timestamp, ts=None → active shard
 - load_active_shards vs load_all_shards
 - migrate_to_shards: correctness, idempotency, backup
 - MemorySystem integration: sharding=True end-to-end
 - MemorySystem integration: sharding=False backward compat (memories.jsonl)
 - Auto-migration trigger
"""

import json
import os
import shutil
import tempfile
import time
import warnings
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List

import pytest

from antaris_memory.entry import MemoryEntry
from antaris_memory.wal import WALWriter, WALReader
from antaris_memory.shards import ShardManager as TimeShardManager
from antaris_memory.migrate import migrate_to_shards
from antaris_memory.search import SearchEngine
from antaris_memory import MemorySystem


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def make_entry(content: str, created: str = None, source: str = "test") -> MemoryEntry:
    e = MemoryEntry(content, source=source, line=0, category="test")
    if created:
        e.created = created
        e.last_accessed = created
    return e


def week_label(dt: datetime) -> str:
    """Return 'YYYY-WXX' for the given datetime (mirrors ShardManager logic)."""
    year, week, _ = dt.isocalendar()
    return f"{year}-W{week:02d}"


def write_flat_memories(workspace: str, entries: List[MemoryEntry]) -> None:
    """Write entries to memories.jsonl in workspace."""
    path = os.path.join(workspace, "memories.jsonl")
    with open(path, "w", encoding="utf-8") as fh:
        for e in entries:
            fh.write(json.dumps(e.to_dict()) + "\n")


# ──────────────────────────────────────────────────────────────────────────────
# 1. WAL — WALWriter / WALReader
# ──────────────────────────────────────────────────────────────────────────────

class TestWAL:
    """Tests for wal.WALWriter and wal.WALReader."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="wal_test_")
        self.wal_path = os.path.join(self.tmpdir, ".antaris_wal.jsonl")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_writer_creates_file(self):
        w = WALWriter()
        w.open(self.wal_path)
        w.append({"content": "hello", "hash": "abc"})
        w.close()
        assert os.path.exists(self.wal_path)

    def test_reader_returns_all_entries(self):
        w = WALWriter()
        w.open(self.wal_path)
        for i in range(10):
            w.append({"content": f"entry {i}", "hash": str(i)})
        w.close()

        r = WALReader()
        r.open(self.wal_path)
        entries = r.read_all()
        assert len(entries) == 10
        assert entries[0]["content"] == "entry 0"
        assert entries[9]["hash"] == "9"

    def test_reader_empty_on_missing_file(self):
        r = WALReader()
        r.open(os.path.join(self.tmpdir, "nonexistent.jsonl"))
        assert r.read_all() == []

    def test_reader_skips_corrupt_lines(self):
        with open(self.wal_path, "w", encoding="utf-8") as fh:
            fh.write('{"content": "good"}\n')
            fh.write("NOT JSON\n")
            fh.write('{"content": "also good"}\n')

        r = WALReader()
        r.open(self.wal_path)
        entries = r.read_all()
        assert len(entries) == 2
        assert entries[0]["content"] == "good"
        assert entries[1]["content"] == "also good"

    def test_reader_clear_removes_file(self):
        w = WALWriter()
        w.open(self.wal_path)
        w.append({"content": "x"})
        w.close()
        assert os.path.exists(self.wal_path)

        r = WALReader()
        r.open(self.wal_path)
        r.clear()
        assert not os.path.exists(self.wal_path)

    def test_writer_size_returns_bytes(self):
        w = WALWriter()
        w.open(self.wal_path)
        w.append({"content": "test"})
        w.close()
        assert w.size() > 0

    def test_writer_size_zero_before_open(self):
        w = WALWriter()
        assert w.size() == 0

    def test_append_raises_without_open(self):
        w = WALWriter()
        with pytest.raises(RuntimeError, match="open"):
            w.append({"content": "x"})

    def test_roundtrip_memory_entry(self):
        entry = make_entry("The quick brown fox jumps over the lazy dog")
        w = WALWriter()
        w.open(self.wal_path)
        w.append(entry.to_dict())
        w.close()

        r = WALReader()
        r.open(self.wal_path)
        dicts = r.read_all()
        assert len(dicts) == 1
        restored = MemoryEntry.from_dict(dicts[0])
        assert restored.content == entry.content
        assert restored.hash == entry.hash

    def test_wal_survives_500_entries(self):
        """Write 500 entries — writer must not error or corrupt."""
        w = WALWriter()
        w.open(self.wal_path)
        for i in range(500):
            w.append({"content": f"memory entry number {i}", "hash": f"h{i}"})
        w.close()

        r = WALReader()
        r.open(self.wal_path)
        entries = r.read_all()
        assert len(entries) == 500

    def test_clear_is_safe_on_missing_file(self):
        r = WALReader()
        r.open(os.path.join(self.tmpdir, "ghost.jsonl"))
        r.clear()  # must not raise


# ──────────────────────────────────────────────────────────────────────────────
# 2. SearchEngine — save_index / load_index / apply_wal_entries
# ──────────────────────────────────────────────────────────────────────────────

class TestSearchEngineIndex:
    """Tests for SearchEngine.save_index, load_index, apply_wal_entries."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="idx_test_")
        self.idx_path = os.path.join(self.tmpdir, ".antaris_index.json")
        self.engine = SearchEngine()
        self.memories = [
            make_entry("BM25 search engine uses term frequency"),
            make_entry("Inverse document frequency rewards rare terms"),
            make_entry("Field boosting improves tag and source matching"),
        ]
        self.engine.build_index(self.memories)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_save_creates_file(self):
        self.engine.save_index(self.idx_path)
        assert os.path.exists(self.idx_path)

    def test_load_returns_true_on_valid_file(self):
        self.engine.save_index(self.idx_path)
        fresh = SearchEngine()
        result = fresh.load_index(self.idx_path)
        assert result is True

    def test_load_returns_false_on_missing_file(self):
        fresh = SearchEngine()
        result = fresh.load_index(os.path.join(self.tmpdir, "nope.json"))
        assert result is False

    def test_load_returns_false_on_corrupt_file(self):
        with open(self.idx_path, "w") as fh:
            fh.write("{not valid json}")
        fresh = SearchEngine()
        assert fresh.load_index(self.idx_path) is False

    def test_load_returns_false_on_missing_required_key(self):
        # Write a JSON file missing 'idf_cache'
        with open(self.idx_path, "w") as fh:
            json.dump({"doc_count": 3}, fh)
        fresh = SearchEngine()
        assert fresh.load_index(self.idx_path) is False

    def test_loaded_index_reproduces_search_results(self):
        """Saving and loading an index must produce the same top result."""
        self.engine.save_index(self.idx_path)

        fresh = SearchEngine()
        fresh.load_index(self.idx_path)

        orig_results = self.engine.search("term frequency", self.memories, limit=3)
        restored_results = fresh.search("term frequency", self.memories, limit=3)

        assert len(orig_results) > 0
        assert orig_results[0].content == restored_results[0].content

    def test_index_persistence_across_restart(self):
        """Simulate a restart: engine2 loads index saved by engine1."""
        self.engine.save_index(self.idx_path)

        engine2 = SearchEngine()
        assert engine2.load_index(self.idx_path)
        assert engine2._doc_count == self.engine._doc_count
        assert abs(engine2._avg_doc_len - self.engine._avg_doc_len) < 0.01
        assert set(engine2._idf_cache.keys()) == set(self.engine._idf_cache.keys())

    def test_apply_wal_entries_increments_doc_count(self):
        self.engine.save_index(self.idx_path)
        fresh = SearchEngine()
        fresh.load_index(self.idx_path)

        initial_count = fresh._doc_count
        new_entries = [
            make_entry("New memory about neural networks and deep learning"),
            make_entry("Another entry with gradient descent optimization"),
        ]
        fresh.apply_wal_entries(new_entries)
        assert fresh._doc_count == initial_count + 2

    def test_apply_wal_entries_updates_idf(self):
        fresh = SearchEngine()
        fresh.load_index(self.idx_path) if os.path.exists(self.idx_path) else None
        self.engine.save_index(self.idx_path)
        fresh.load_index(self.idx_path)

        # 'neural' doesn't appear in original corpus → IDF should be high after applying
        new_entry = make_entry("Neural networks with attention mechanisms")
        fresh.apply_wal_entries([new_entry])
        # 'neural' should now be in the IDF cache
        assert "neural" in fresh._idf_cache

    def test_apply_empty_wal_entries_is_noop(self):
        before_count = self.engine._doc_count
        self.engine.apply_wal_entries([])
        assert self.engine._doc_count == before_count

    def test_corrupt_index_falls_back_gracefully(self):
        """Corrupt index file: load_index returns False, caller rebuilds."""
        with open(self.idx_path, "w") as fh:
            fh.write("GARBAGE DATA\n")
        fresh = SearchEngine()
        result = fresh.load_index(self.idx_path)
        assert result is False
        # Caller can safely rebuild
        fresh.build_index(self.memories)
        results = fresh.search("term frequency", self.memories, limit=3)
        assert len(results) > 0

    def test_save_is_atomic(self):
        """Save must use atomic rename: file must be complete after save."""
        self.engine.save_index(self.idx_path)
        # Read it back — must be valid JSON
        with open(self.idx_path) as fh:
            data = json.load(fh)
        assert "idf_cache" in data
        assert "doc_count" in data


# ──────────────────────────────────────────────────────────────────────────────
# 3. ShardManager — routing, load_active, load_all
# ──────────────────────────────────────────────────────────────────────────────

class TestTimeShardManager:
    """Tests for shards.ShardManager (time-window sharding)."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="shards_test_")
        self.mgr = TimeShardManager(self.tmpdir)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _iso(self, dt: datetime) -> str:
        return dt.isoformat()

    def test_write_entry_creates_shard_file(self):
        e = make_entry("test content")
        self.mgr.write_entry(e)
        shards = self.mgr.list_shards()
        assert len(shards) == 1
        assert shards[0].startswith("memories_")
        assert shards[0].endswith(".jsonl")

    def test_write_entry_routes_by_timestamp(self):
        now = datetime.now(timezone.utc)
        old_dt = now - timedelta(weeks=4)

        new_entry = make_entry("recent memory", created=self._iso(now))
        old_entry = make_entry("old memory from four weeks ago", created=self._iso(old_dt))

        self.mgr.write_entry(new_entry)
        self.mgr.write_entry(old_entry)

        shards = self.mgr.list_shards()
        assert len(shards) == 2, f"Expected 2 shards, got: {shards}"
        # Each in a different week
        new_week = week_label(now)
        old_week = week_label(old_dt)
        assert new_week != old_week
        assert any(new_week in s for s in shards)
        assert any(old_week in s for s in shards)

    def test_ts_none_goes_to_active_shard(self):
        """Entries with created=None route to current week's shard."""
        e = make_entry("memory with no timestamp")
        e.created = None  # type: ignore[assignment]
        self.mgr.write_entry(e)

        now = datetime.now(timezone.utc)
        active = f"memories_{week_label(now)}.jsonl"
        shards = self.mgr.list_shards()
        assert active in shards

    def test_load_active_shards_returns_recent(self):
        now = datetime.now(timezone.utc)
        recent = make_entry("recent entry", created=self._iso(now))
        old = make_entry("very old entry from 10 weeks ago",
                         created=self._iso(now - timedelta(weeks=10)))

        self.mgr.write_entry(recent)
        self.mgr.write_entry(old)

        active = self.mgr.load_active_shards(weeks=1)
        contents = {e.content for e in active}
        assert "recent entry" in contents
        assert "very old entry from 10 weeks ago" not in contents

    def test_load_active_shards_includes_previous_week(self):
        now = datetime.now(timezone.utc)
        last_week = now - timedelta(weeks=1)

        e_now = make_entry("this week entry", created=self._iso(now))
        e_prev = make_entry("previous week entry", created=self._iso(last_week))

        self.mgr.write_entry(e_now)
        self.mgr.write_entry(e_prev)

        active = self.mgr.load_active_shards(weeks=1)
        contents = {e.content for e in active}
        assert "this week entry" in contents
        assert "previous week entry" in contents

    def test_load_all_shards_returns_everything(self):
        now = datetime.now(timezone.utc)
        entries = [
            make_entry("entry A", created=self._iso(now)),
            make_entry("entry B", created=self._iso(now - timedelta(weeks=3))),
            make_entry("entry C", created=self._iso(now - timedelta(weeks=8))),
        ]
        for e in entries:
            self.mgr.write_entry(e)

        all_entries = self.mgr.load_all_shards()
        contents = {e.content for e in all_entries}
        assert "entry A" in contents
        assert "entry B" in contents
        assert "entry C" in contents

    def test_load_all_vs_active_difference(self):
        now = datetime.now(timezone.utc)
        new_e = make_entry("new entry this week", created=self._iso(now))
        old_e = make_entry("entry from six weeks ago is ancient history",
                           created=self._iso(now - timedelta(weeks=6)))

        self.mgr.write_entry(new_e)
        self.mgr.write_entry(old_e)

        active = self.mgr.load_active_shards(weeks=1)
        all_shards = self.mgr.load_all_shards()

        active_contents = {e.content for e in active}
        all_contents = {e.content for e in all_shards}

        assert "new entry this week" in active_contents
        assert "entry from six weeks ago is ancient history" not in active_contents
        assert "entry from six weeks ago is ancient history" in all_contents

    def test_list_shards_sorted(self):
        now = datetime.now(timezone.utc)
        for i in range(3):
            e = make_entry(f"entry {i}", created=self._iso(now - timedelta(weeks=i)))
            self.mgr.write_entry(e)

        shards = self.mgr.list_shards()
        assert shards == sorted(shards)

    def test_list_shards_empty_on_fresh_workspace(self):
        fresh_dir = tempfile.mkdtemp(prefix="shards_empty_")
        try:
            mgr = TimeShardManager(fresh_dir)
            assert mgr.list_shards() == []
        finally:
            shutil.rmtree(fresh_dir, ignore_errors=True)

    def test_deduplication_in_load_active(self):
        """If the same hash appears in multiple shards, load_active deduplicates."""
        now = datetime.now(timezone.utc)
        e = make_entry("duplicate entry", created=self._iso(now))
        # Write twice to same shard
        self.mgr.write_entry(e)
        self.mgr.write_entry(e)

        active = self.mgr.load_active_shards(weeks=1)
        hashes = [x.hash for x in active]
        assert len(hashes) == len(set(hashes)), "Duplicates found in load_active_shards"

    def test_deduplication_in_load_all(self):
        now = datetime.now(timezone.utc)
        e = make_entry("duplicate for load_all", created=self._iso(now))
        self.mgr.write_entry(e)
        self.mgr.write_entry(e)

        all_entries = self.mgr.load_all_shards()
        hashes = [x.hash for x in all_entries]
        assert len(hashes) == len(set(hashes))


# ──────────────────────────────────────────────────────────────────────────────
# 4. migrate_to_shards
# ──────────────────────────────────────────────────────────────────────────────

class TestMigrateToShards:
    """Tests for migrate.migrate_to_shards."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="migrate_test_")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _write_flat(self, entries: List[MemoryEntry]) -> str:
        path = os.path.join(self.tmpdir, "memories.jsonl")
        with open(path, "w", encoding="utf-8") as fh:
            for e in entries:
                fh.write(json.dumps(e.to_dict()) + "\n")
        return path

    def test_migrate_success(self):
        now = datetime.now(timezone.utc)
        entries = [
            make_entry("memory one", created=now.isoformat()),
            make_entry("memory two", created=(now - timedelta(weeks=1)).isoformat()),
        ]
        self._write_flat(entries)

        result = migrate_to_shards(self.tmpdir)
        assert result["status"] == "success"
        assert result["entries_migrated"] == 2
        assert len(result["shards"]) >= 1

    def test_migrate_creates_backup(self):
        entries = [make_entry("backup test entry abc")]
        self._write_flat(entries)

        result = migrate_to_shards(self.tmpdir)
        assert result["status"] == "success"
        assert os.path.exists(result["backup"])
        assert result["backup"].endswith(".bak")

    def test_migrate_original_not_deleted(self):
        entries = [make_entry("original should survive the migration")]
        self._write_flat(entries)

        migrate_to_shards(self.tmpdir)
        assert os.path.exists(os.path.join(self.tmpdir, "memories.jsonl"))

    def test_migrate_correctness(self):
        """All entries in flat file must appear in shard files."""
        now = datetime.now(timezone.utc)
        entries = [
            make_entry(f"correctness entry {i}", created=now.isoformat())
            for i in range(5)
        ]
        self._write_flat(entries)

        migrate_to_shards(self.tmpdir)

        mgr = TimeShardManager(self.tmpdir)
        loaded = mgr.load_all_shards()
        loaded_contents = {e.content for e in loaded}
        for e in entries:
            assert e.content in loaded_contents

    def test_migrate_idempotent(self):
        """Calling migrate_to_shards twice must not duplicate entries."""
        entries = [make_entry("idempotency check entry one two three")]
        self._write_flat(entries)

        res1 = migrate_to_shards(self.tmpdir)
        res2 = migrate_to_shards(self.tmpdir)

        assert res1["status"] == "success"
        assert res2["status"] == "already_migrated"

        mgr = TimeShardManager(self.tmpdir)
        all_entries = mgr.load_all_shards()
        # Should only have 1 unique entry
        unique_contents = {e.content for e in all_entries}
        assert len(unique_contents) == 1

    def test_migrate_skipped_when_no_flat_file(self):
        result = migrate_to_shards(self.tmpdir)
        assert result["status"] == "skipped"

    def test_migrate_skipped_when_flat_file_empty(self):
        open(os.path.join(self.tmpdir, "memories.jsonl"), "w").close()
        result = migrate_to_shards(self.tmpdir)
        assert result["status"] == "skipped"

    def test_backup_file_content_matches_original(self):
        entries = [make_entry("backup content check gamma delta")]
        flat_path = self._write_flat(entries)

        with open(flat_path) as fh:
            original_content = fh.read()

        result = migrate_to_shards(self.tmpdir)
        assert result["status"] == "success"

        with open(result["backup"]) as fh:
            backup_content = fh.read()

        assert original_content == backup_content


# ──────────────────────────────────────────────────────────────────────────────
# 5. MemorySystem integration — sharding=True end-to-end
# ──────────────────────────────────────────────────────────────────────────────

class TestMemorySystemShardingTrue:
    """Integration tests for MemorySystem with sharding=True (use_sharding=False)."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="msys_true_")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_mem(self, **kwargs) -> MemorySystem:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            return MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
                **kwargs,
            )

    def test_ingest_creates_shard_file(self):
        mem = self._make_mem()
        mem.ingest("This is a meaningful test memory about neural networks", source="test")
        mgr = TimeShardManager(self.tmpdir)
        assert len(mgr.list_shards()) >= 1

    def test_ingest_and_search_roundtrip(self):
        mem = self._make_mem()
        mem.ingest(
            "The gradient descent algorithm optimises neural network weights",
            source="test",
        )
        results = mem.search("gradient descent neural")
        assert len(results) > 0
        contents = [getattr(r, "content", str(r)) for r in results]
        assert any("gradient" in c.lower() for c in contents)

    def test_shards_persist_across_restart(self):
        """Data written in one MemorySystem instance is readable by the next."""
        mem1 = self._make_mem()
        mem1.ingest(
            "Persistent memory about the production deployment pipeline",
            source="test",
        )

        # Simulate restart: new instance, same workspace
        mem2 = self._make_mem()
        contents = [m.content for m in mem2.memories]
        assert any("deployment" in c for c in contents)

    def test_search_engine_index_saved(self):
        mem = self._make_mem()
        mem.ingest("Index persistence test with unique token xyzzy42", source="test")
        # Index should have been saved
        assert os.path.exists(mem._index_path)

    def test_index_wal_written(self):
        mem = self._make_mem()
        mem.ingest("WAL test entry with unique content alpha bravo charlie", source="test")
        # Index WAL should exist (written on ingest)
        assert os.path.exists(mem._index_wal_path)

    def test_index_wal_flush_at_500(self):
        """WAL should be cleared and index rebuilt when 500 entries ingested."""
        mem = self._make_mem()
        # Ingest 500+ unique entries (each line >= 15 chars after strip)
        lines = "\n".join(
            f"Meaningful memory item number {i:04d} for WAL flush test coverage"
            for i in range(520)
        )
        mem.ingest(lines, source="bulk_test")

        # Index WAL entry count must have been reset
        assert mem._index_wal_entry_count == 0  # flushed at 500

    def test_sharding_true_multiweek(self):
        """Entries from different weeks go to different shards."""
        now = datetime.now(timezone.utc)
        mem = self._make_mem()

        e_new = make_entry("current week entry about alpha systems", created=now.isoformat())
        e_old = make_entry(
            "entry from three weeks ago about beta systems",
            created=(now - timedelta(weeks=3)).isoformat(),
        )
        # Bypass ingest() gating — write directly via shard manager
        mgr = TimeShardManager(self.tmpdir)
        mgr.write_entry(e_new)
        mgr.write_entry(e_old)

        shards = mgr.list_shards()
        assert len(shards) >= 2


# ──────────────────────────────────────────────────────────────────────────────
# 6. MemorySystem integration — sharding=False backward compat
# ──────────────────────────────────────────────────────────────────────────────

class TestMemorySystemShardingFalse:
    """Integration tests for MemorySystem with sharding=False (flat memories.jsonl)."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="msys_false_")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_mem(self, **kwargs) -> MemorySystem:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            return MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test-agent",
                **kwargs,
            )

    def test_no_shard_files_created(self):
        mem = self._make_mem()
        mem.ingest("Simple flat file test entry with enough content here", source="test")

        mgr = TimeShardManager(self.tmpdir)
        # No v4.6 shard files when sharding=False
        assert mgr.list_shards() == []

    def test_ingest_search_still_works(self):
        mem = self._make_mem()
        mem.ingest("Backward compatibility test with keyword sphinx", source="test")
        results = mem.search("sphinx")
        assert len(results) > 0

    def test_flat_memories_jsonl_written(self):
        """When sharding=False, saving should use legacy or flat file."""
        mem = self._make_mem()
        mem.ingest("Flat storage test entry with meaningful words here", source="test")
        mem.save()
        # Legacy save uses memory_metadata.json (the existing v4 flat path)
        assert os.path.exists(mem.legacy_metadata_path) or \
               os.path.exists(os.path.join(self.tmpdir, "memories.jsonl"))

    def test_enterprise_sharding_still_unaffected(self):
        """Default MemorySystem (use_sharding=True) is unaffected by sharding param."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=True,
                sharding=True,
                agent_name="test-agent",
            )
        mem.ingest("Enterprise shard test entry with useful content here", source="test")
        # Enterprise sharding writes to shards/ directory
        shards_dir = os.path.join(self.tmpdir, "shards")
        assert os.path.isdir(shards_dir)


# ──────────────────────────────────────────────────────────────────────────────
# 7. Auto-migration trigger
# ──────────────────────────────────────────────────────────────────────────────

class TestAutoMigration:
    """Tests for the auto-migration trigger in MemorySystem."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="automig_test_")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_mem_v46(self) -> MemorySystem:
        with warnings.catch_warnings():
            warnings.simplefilter("always", UserWarning)
            return MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

    def test_auto_migrate_fires_when_flat_file_exists(self):
        """memories.jsonl exists + no shard files → auto-migration with UserWarning."""
        entries = [
            make_entry("auto migrate entry one two three four five six"),
            make_entry("auto migrate entry seven eight nine ten eleven twelve"),
        ]
        write_flat_memories(self.tmpdir, entries)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        # Expect at least one UserWarning about auto-migration
        migration_warnings = [
            x for x in w
            if issubclass(x.category, UserWarning) and "migrat" in str(x.message).lower()
        ]
        assert len(migration_warnings) >= 1

    def test_auto_migrate_creates_shard_files(self):
        entries = [make_entry("auto migration shard creation test entry")]
        write_flat_memories(self.tmpdir, entries)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        mgr = TimeShardManager(self.tmpdir)
        assert len(mgr.list_shards()) >= 1

    def test_auto_migrate_creates_backup(self):
        entries = [make_entry("auto migration backup file creation verification")]
        write_flat_memories(self.tmpdir, entries)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        assert os.path.exists(os.path.join(self.tmpdir, "memories.jsonl.bak"))

    def test_auto_migrate_does_not_fire_without_flat_file(self):
        """Fresh workspace with no memories.jsonl → no migration warning."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        migration_warnings = [
            x for x in w
            if issubclass(x.category, UserWarning) and "migrat" in str(x.message).lower()
        ]
        assert len(migration_warnings) == 0

    def test_auto_migrate_idempotent_on_second_start(self):
        """After migration, second startup must not re-migrate (no duplicate shards)."""
        entries = [make_entry("idempotent auto migration test entry alpha beta")]
        write_flat_memories(self.tmpdir, entries)

        # First startup — triggers migration
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        mgr = TimeShardManager(self.tmpdir)
        shards_after_first = mgr.list_shards()

        # Second startup — should NOT migrate again
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=True,
                agent_name="test-agent",
            )

        shards_after_second = mgr.list_shards()
        assert set(shards_after_first) == set(shards_after_second)

        migration_warnings = [
            x for x in w
            if issubclass(x.category, UserWarning) and "migrat" in str(x.message).lower()
        ]
        assert len(migration_warnings) == 0


# ──────────────────────────────────────────────────────────────────────────────
# 8. WAL flush threshold integration (500-entry boundary)
# ──────────────────────────────────────────────────────────────────────────────

class TestWALFlushThreshold:
    """Verify that the index WAL flush fires at exactly 500 entries."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp(prefix="walflush_test_")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_index_wal_cleared_after_500_ingests(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test-agent",
            )

        # Feed 500 entries one by one
        for i in range(500):
            mem.ingest(
                f"Threshold test memory number {i:04d} with enough meaningful words here",
                source="threshold",
            )

        # After exactly 500, the flush fires and counter resets
        assert mem._index_wal_entry_count == 0

    def test_index_saved_after_flush(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test-agent",
            )

        for i in range(500):
            mem.ingest(
                f"Index save test memory {i:04d} with enough words to pass gating",
                source="save_test",
            )

        assert os.path.exists(mem._index_path)

    def test_index_wal_file_cleared_after_flush(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            mem = MemorySystem(
                self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test-agent",
            )

        for i in range(500):
            mem.ingest(
                f"WAL clear test memory {i:04d} with meaningful and valuable content",
                source="clear_test",
            )

        # After flush, the index WAL should be cleared (file removed or empty)
        r = WALReader()
        r.open(mem._index_wal_path)
        remaining = r.read_all()
        assert len(remaining) == 0
