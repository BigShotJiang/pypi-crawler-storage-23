"""
antaris-memory v4.9.2 — Stats, Health, and CLI Tests
======================================================
"""

import json
import os
import sys
import tempfile
from unittest.mock import patch

import pytest

from antaris_memory.core_v4 import MemorySystemV4 as MemorySystem


# ════════════════════════════════════════════════════════════════════════════
# STATS
# ════════════════════════════════════════════════════════════════════════════

class TestStats:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.ms = MemorySystem(workspace=self.tmpdir, agent_name="test-agent",
                               graph_intelligence=True)

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_stats_returns_dict(self):
        s = self.ms.stats()
        assert isinstance(s, dict)

    def test_stats_has_version(self):
        s = self.ms.stats()
        assert "version" in s
        assert s["version"].startswith("4.")

    def test_stats_has_total_entries(self):
        s = self.ms.stats()
        assert "total_entries" in s
        assert s["total_entries"] == 0  # empty store

    def test_stats_total_entries_increments_on_ingest(self):
        self.ms.ingest("test memory for stats check", agent_id="test-agent")
        s = self.ms.stats()
        assert s["total_entries"] >= 1

    def test_stats_has_hot_warm_cold(self):
        s = self.ms.stats()
        assert "hot_entries" in s
        assert "warm_entries" in s
        assert "cold_entries" in s

    def test_stats_hot_equals_total(self):
        self.ms.ingest("another entry for stats", agent_id="test-agent")
        s = self.ms.stats()
        assert s["hot_entries"] == s["total_entries"]

    def test_stats_has_enrichment_count(self):
        s = self.ms.stats()
        assert "enrichment_count" in s
        assert isinstance(s["enrichment_count"], int)

    def test_stats_has_enrichment_cost(self):
        s = self.ms.stats()
        assert "enrichment_cost_usd" in s
        assert isinstance(s["enrichment_cost_usd"], float)

    def test_stats_has_graph_enabled(self):
        s = self.ms.stats()
        assert "graph_enabled" in s

    def test_stats_graph_nodes_edge_keys_present(self):
        s = self.ms.stats()
        assert "graph_nodes" in s
        assert "graph_edges" in s

    def test_stats_has_workspace(self):
        s = self.ms.stats()
        assert s["workspace"] == self.tmpdir

    def test_stats_has_agent_name(self):
        s = self.ms.stats()
        assert s["agent_name"] == "test-agent"

    def test_stats_has_wal_size(self):
        s = self.ms.stats()
        assert "wal_size" in s

    def test_stats_has_cache_size(self):
        s = self.ms.stats()
        assert "cache_size" in s

    def test_stats_has_cooccurrence_pairs(self):
        s = self.ms.stats()
        assert "cooccurrence_pairs" in s

    def test_stats_is_json_serializable(self):
        s = self.ms.stats()
        # Should not raise
        serialized = json.dumps(s)
        assert len(serialized) > 0

    def test_stats_nonfatal_with_disabled_graph(self):
        ms2 = MemorySystem(workspace=self.tmpdir, agent_name="test-agent",
                           graph_intelligence=False)
        s = ms2.stats()
        assert isinstance(s, dict)
        assert s["graph_enabled"] is False


# ════════════════════════════════════════════════════════════════════════════
# HEALTH
# ════════════════════════════════════════════════════════════════════════════

class TestHealth:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.ms = MemorySystem(workspace=self.tmpdir, agent_name="test-agent")

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_get_health_returns_dict(self):
        h = self.ms.get_health()
        assert isinstance(h, dict)

    def test_get_health_has_status(self):
        h = self.ms.get_health()
        assert "status" in h
        assert h["status"] in ("ok", "degraded")

    def test_get_health_has_checks(self):
        h = self.ms.get_health()
        assert "checks" in h
        assert isinstance(h["checks"], dict)

    def test_get_health_workspace_accessible(self):
        h = self.ms.get_health()
        assert h["checks"].get("workspace_accessible") is True

    def test_get_health_memories_loaded(self):
        h = self.ms.get_health()
        assert h["checks"].get("memories_loaded") is True

    def test_get_health_wal_ok(self):
        h = self.ms.get_health()
        assert h["checks"].get("wal_ok") is True

    def test_get_health_search_ok(self):
        h = self.ms.get_health()
        assert h["checks"].get("search_ok") is True

    def test_get_health_status_ok_on_healthy_system(self):
        h = self.ms.get_health()
        assert h["status"] == "ok"

    def test_get_health_is_json_serializable(self):
        h = self.ms.get_health()
        serialized = json.dumps(h)
        assert len(serialized) > 0


# ════════════════════════════════════════════════════════════════════════════
# CLI
# ════════════════════════════════════════════════════════════════════════════

class TestCLI:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _run(self, args: list) -> tuple:
        """Run CLI with args, return (exit_code, stdout_output)."""
        from antaris_memory.cli import main
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        try:
            with redirect_stdout(buf):
                code = main(args)
        except SystemExit as e:
            code = e.code
        return code, buf.getvalue()

    def test_init_creates_workspace(self):
        ws = os.path.join(self.tmpdir, "new_ws")
        code, out = self._run(["init", "--workspace", ws])
        assert code == 0
        assert os.path.isdir(ws)

    def test_init_writes_config(self):
        ws = os.path.join(self.tmpdir, "init_ws")
        self._run(["init", "--workspace", ws])
        config_path = os.path.join(ws, "antaris_config.json")
        assert os.path.exists(config_path)

    def test_init_config_has_agent_name(self):
        ws = os.path.join(self.tmpdir, "init_ws2")
        self._run(["init", "--workspace", ws, "--agent-name", "my-agent"])
        config_path = os.path.join(ws, "antaris_config.json")
        with open(config_path) as f:
            cfg = json.load(f)
        assert cfg["agent_name"] == "my-agent"

    def test_init_config_has_version(self):
        ws = os.path.join(self.tmpdir, "init_ws3")
        self._run(["init", "--workspace", ws])
        config_path = os.path.join(ws, "antaris_config.json")
        with open(config_path) as f:
            cfg = json.load(f)
        assert "version" in cfg

    def test_init_output_mentions_ready(self):
        ws = os.path.join(self.tmpdir, "init_ws4")
        code, out = self._run(["init", "--workspace", ws])
        assert "Ready" in out or "✅" in out

    def test_init_skips_existing_config_without_force(self):
        ws = os.path.join(self.tmpdir, "init_ws5")
        self._run(["init", "--workspace", ws, "--agent-name", "original"])
        # Run again without --force — should not overwrite
        self._run(["init", "--workspace", ws, "--agent-name", "new-name"])
        with open(os.path.join(ws, "antaris_config.json")) as f:
            cfg = json.load(f)
        assert cfg["agent_name"] == "original"

    def test_init_force_overwrites(self):
        ws = os.path.join(self.tmpdir, "init_ws6")
        self._run(["init", "--workspace", ws, "--agent-name", "original"])
        self._run(["init", "--workspace", ws, "--agent-name", "new-name", "--force"])
        with open(os.path.join(ws, "antaris_config.json")) as f:
            cfg = json.load(f)
        assert cfg["agent_name"] == "new-name"

    def test_status_returns_zero_on_valid_workspace(self):
        ws = os.path.join(self.tmpdir, "status_ws")
        self._run(["init", "--workspace", ws])
        code, out = self._run(["status", "--workspace", ws])
        assert code == 0

    def test_status_output_contains_entries(self):
        ws = os.path.join(self.tmpdir, "status_ws2")
        self._run(["init", "--workspace", ws])
        code, out = self._run(["status", "--workspace", ws])
        assert "Entries" in out or "entries" in out.lower()

    def test_status_output_contains_health(self):
        ws = os.path.join(self.tmpdir, "status_ws3")
        self._run(["init", "--workspace", ws])
        code, out = self._run(["status", "--workspace", ws])
        assert "Health" in out or "ok" in out.lower()

    def test_status_nonexistent_workspace_returns_nonzero(self):
        code, _ = self._run(["status", "--workspace", "/tmp/nonexistent_xyz_abc_123"])
        # May succeed (creates empty) or fail — just ensure no exception
        assert isinstance(code, (int, type(None)))

    def test_rebuild_graph_returns_zero(self):
        ws = os.path.join(self.tmpdir, "graph_ws")
        self._run(["init", "--workspace", ws])
        code, out = self._run(["rebuild-graph", "--workspace", ws])
        assert code == 0

    def test_rebuild_graph_output_mentions_graph(self):
        ws = os.path.join(self.tmpdir, "graph_ws2")
        self._run(["init", "--workspace", ws])
        code, out = self._run(["rebuild-graph", "--workspace", ws])
        assert "graph" in out.lower() or "Graph" in out

    def test_no_command_prints_help(self):
        code, out = self._run([])
        # Should exit 0 and show usage
        assert code == 0

    def test_main_module_importable(self):
        import antaris_memory.__main__  # noqa — just check it imports
