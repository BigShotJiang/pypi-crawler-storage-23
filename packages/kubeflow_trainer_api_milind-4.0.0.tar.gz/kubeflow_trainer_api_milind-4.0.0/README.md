# Kubeflow Trainer API

Python package containing Kubeflow Trainer API models.
