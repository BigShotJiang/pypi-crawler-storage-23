"""qanneal Python package."""

from ._qanneal import *  # noqa: F401,F403
from .solver import SolveResult, solve, auto_schedule_sa, auto_schedule_sqa  # noqa: F401

__version__ = version_string()

__all__ = [
    "__version__",
    "version_string",
    "version_major",
    "version_minor",
    "version_patch",
    "State",
    "Hamiltonian",
    "DenseIsing",
    "SparseEdge",
    "SparseIsing",
    "QUBO",
    "AnnealSchedule",
    "Observer",
    "MetricsObserver",
    "StateTraceObserver",
    "AnnealResult",
    "Annealer",
    "ReplicaResult",
    "MultiAnnealResult",
    "ReplicaAnnealer",
    "ParallelTemperingAnnealer",
    "ParallelTemperingResult",
    "SQASchedule",
    "SQAObserver",
    "SQASweepPhase",
    "SQAMetricsObserver",
    "SQAStateTraceObserver",
    "SQAResult",
    "SQAAnnealer",
    "magnetization",
    "overlap",
    "SolveResult",
    "solve",
    "auto_schedule_sa",
    "auto_schedule_sqa",
]
