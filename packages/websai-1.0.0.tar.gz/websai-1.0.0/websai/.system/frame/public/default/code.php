<?php

class Default
{
}