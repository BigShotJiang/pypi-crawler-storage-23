# py-enjoy

jfinal-enjoy  5.2.2 的python 3.9.0 实现，基于jpype1实现。 
python port by mrzhou@miw.cn

### 使用样例

#### 示例1：使用项目内置的jar文件（推荐）
```python
from enjoy import Enjoy

if __name__ == "__main__":
    # 1. 配置参数（仅需配置模板路径）
    TEMPLATE_BASE_PATH = "./templates"  # 模板文件所在目录（如index.html放在这个目录下）

    # 2. 创建Enjoy实例（初始化Engine，自动使用内置的enjoy-5.2.2.jar）
    try:
        enjoy = Enjoy(
            template_base_path=TEMPLATE_BASE_PATH
        )
```

#### 示例2：指定自定义的jar文件路径
```python
from enjoy import Enjoy

if __name__ == "__main__":
    # 1. 配置参数（需配置jar路径和模板路径）
    JAR_PATH = "enjoy-5.2.2.jar"  # enjoy-5.2.2.jar的绝对/相对路径
    TEMPLATE_BASE_PATH = "./templates"  # 模板文件所在目录（如index.html放在这个目录下）

    # 2. 创建Enjoy实例（初始化Engine）
    try:
        enjoy = Enjoy(
            jar_path=JAR_PATH,
            template_base_path=TEMPLATE_BASE_PATH
        )

        # 3. 准备模板参数
        render_data = {
            "name": "JFinal Enjoy 5.2.2测试",
            "hobbies": ["Python调用Java", "模板渲染", "跨语言开发"],
            "user": {"age": 25, "gender": "男"}
        }

        # 4. 渲染模板（tempStr是模板文件名，相对于TEMPLATE_BASE_PATH）
        result = enjoy.render(
            tempStr="index.html",  # 模板文件：./templates/index.html
            data=render_data       # 渲染数据（Python字典）
        )

        # 5. 输出结果
        print("\n=== 模板渲染结果 ===")
        print(result)

    except RuntimeError as e:
        print(f"\n执行失败: {e}")
    finally:
        # 6. 关闭资源
        if 'enjoy' in locals():
            enjoy.close()
```