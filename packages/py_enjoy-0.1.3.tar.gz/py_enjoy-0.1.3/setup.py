from setuptools import setup, find_packages

setup(
    name="py-enjoy",
    version="0.1.3",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "enjoy": ["*.jar", "templates/*"]
    },
    install_requires=[
        "jpype1>=1.4.0"
    ],
    author="mrzhou",
    author_email="mrzhou@miw.cn",
    description="jfinal-enjoy 5.2.2 的python 3.9.0 实现，基于jpype1实现。 mrzhou@miw.cn",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.9",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    url="https://git.miw.cn/mrzhou/py-enjoy"
)