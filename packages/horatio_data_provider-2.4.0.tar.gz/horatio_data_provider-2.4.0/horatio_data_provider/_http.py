import io

import httpx
import pyarrow as pa
import pyarrow.parquet as pq

from .exceptions import DataProviderHTTPError


async def fetch_table(session: httpx.AsyncClient, url: str, body: dict) -> pa.Table:
    response = await session.post(url, json=body)
    content_type = response.headers.get("content-type", "")
    if "application/json" in content_type:
        data = response.json()
        raise DataProviderHTTPError(response.status_code, data.get("error", str(data)))
    response.raise_for_status()
    return pq.read_table(io.BytesIO(response.content))
