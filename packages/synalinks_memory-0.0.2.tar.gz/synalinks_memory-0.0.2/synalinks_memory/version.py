# License Apache 2.0: (c) 2026 Yoan Sallami (Synalinks Team)

# Unique source of truth for the version number.
__version__ = "0.0.002"

def version():
    return __version__