#pragma once

size_t binary_search_with_guess(double key, const double* array, size_t length, size_t guess);
