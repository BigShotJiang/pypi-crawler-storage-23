from setuptools import setup

# This file is required for editable installs in older versions of pip and setuptools.
# All project metadata and build configuration are defined in pyproject.toml.
setup()