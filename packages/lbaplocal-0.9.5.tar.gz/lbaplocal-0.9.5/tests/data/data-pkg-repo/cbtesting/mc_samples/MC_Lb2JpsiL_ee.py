# FILE TO SET DECAY NAME

sample_decay = 'Lb2LJpsee'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
