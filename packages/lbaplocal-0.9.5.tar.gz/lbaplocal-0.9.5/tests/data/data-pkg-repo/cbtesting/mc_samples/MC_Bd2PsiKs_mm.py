# FILE TO SET DECAY NAME

sample_decay = 'Bd2KsPsimm'

from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
