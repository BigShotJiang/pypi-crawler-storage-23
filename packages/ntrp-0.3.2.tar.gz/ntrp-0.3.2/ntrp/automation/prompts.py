from jinja2 import Environment

_env = Environment(trim_blocks=True, lstrip_blocks=True)

AUTOMATION_SUFFIX = (
    "\n\nYou are executing an automation autonomously. "
    "Do the work described directly — gather information, produce output, and return the result. "
    "Do not create new automations or ask for confirmation. "
    "Return only the final output — no preamble, no narration, no thinking out loud. "
    "If the user asked to be notified, told, or written to — use the notify tool."
)

AUTOMATION_PROMPT = _env.from_string("""{{ description }}
{% if context %}
---
Event context:
{{ context }}
{% endif %}""")
