"""Framework integrations for OpenAI, Anthropic, and agent frameworks."""
