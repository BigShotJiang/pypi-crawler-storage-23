# Agent Trust Hub Reference

Cloud-based AI agent security scanner by Gen Digital (Norton, Avast, LifeLock).

## Overview

Agent Trust Hub provides independent safety verification for AI skills and extensions. Backed by Gen Threat Labs with 500M+ users protected worldwide.

## API Endpoint

```
POST https://ai.gendigital.com/api/scan/lookup
```

## Usage

### cURL
```bash
curl -X POST "https://ai.gendigital.com/api/scan/lookup" \
  -H "Content-Type: application/json" \
  -d '{"skillUrl":"https://skills.sh/author/skill-name"}'
```

### Python
```python
import urllib.request
import json

url = "https://ai.gendigital.com/api/scan/lookup"
payload = json.dumps({"skillUrl": "https://skills.sh/author/skill-name"}).encode()

req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
response = urllib.request.urlopen(req)
result = json.loads(response.read())
```

## Response Format

```json
{
  "severity": "SAFE | LOW | HIGH | CRITICAL",
  "notes": "Human-readable analysis",
  "trusted": true | false
}
```

## Severity Levels

| Level | Description | Action |
|-------|-------------|--------|
| SAFE | Verified by Gen Threat Labs | Install freely |
| LOW | Minor concerns detected | Warn, allow install |
| HIGH | Significant security risks | Block, explain risks |
| CRITICAL | Malicious or dangerous code | Block installation |

## What It Detects

- Malicious code in skills
- Data exfiltration to external servers
- Untrusted developer patterns
- Credential theft attempts
- Unsafe external connections
- Prompt injection patterns

## Supported Sources

- skills.sh (Vercel)
- ClawHub
- GitHub repositories
- Direct skill URLs

## Related Products

| Product | Description |
|---------|-------------|
| Sage | Lightweight security layer for AI agents |
| Secure NeoClaw | 1-click secure deployment |
| Skill Scanner | Pre-execution skill analysis |
| Norton Neo | Private AI browser |

## Resources

- Website: https://ai.gendigital.com/
- Blog: https://www.gendigital.com/blog/news/company-news/sage-ai-agent-security
- Partnership with Vercel: https://newsroom.gendigital.com/2026-02-17-Gen-and-Vercel-Partner

## Stats (as of Feb 2026)

- 12,000+ malicious skills detected
- 500M+ users protected
- 7.5B+ threats blocked daily
