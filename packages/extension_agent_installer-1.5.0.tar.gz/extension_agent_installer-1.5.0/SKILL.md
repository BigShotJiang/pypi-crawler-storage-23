---
name: extension-agent-installer
version: 1.5.0
description: |-
  Secure extension installer for AI coding agents. Protects users who cannot verify
  extension safety themselves. Scans for vulnerabilities before installation to prevent
  malicious code from accessing sensitive data like banking credentials. Promotes digital
  hygiene in the AI era. Supports OpenCode, Claude Code, Cursor, Windsurf, Gemini CLI, Codex.
  ALWAYS notifies user of vulnerabilities and guides credential setup.
  
  Examples:
  - user: "https://github.com/user/skill-repo" - fetch docs, scan, notify, install
  - user: "install this MCP server" - scan, show vulnerabilities, ask user decision
  - user: "add this skill" - validate, notify issues, guide setup, install
  - user: "I want a notification plugin" - search ecosystem, suggest options
  - user: "install opencode-wakatime" - check npm, scan, guide credentials
  - user: "update extension-agent-installer" - check GitHub for new version, update if available
---

# AI Agent Extension Installer

**Version:** 1.1.0  
**Repository:** https://github.com/lmt-expert-company/extension-agent-installer

Install skills, plugins, MCP servers, and custom tools for AI coding assistants with security validation and setup guidance.

## Self-Update

**This skill can update itself.** When the user asks to "update extension-agent-installer" or "обнови скилл", follow this workflow:

### Update Workflow

1. **Fetch current version from GitHub**
   ```
   https://raw.githubusercontent.com/lmt-expert-company/extension-agent-installer/main/SKILL.md
   ```

2. **Compare versions**
   - Extract `version:` from the fetched SKILL.md
   - Compare with current version in this file
   - If remote version > local version, update is available

3. **Notify user**
   ```
   Update available: v1.0.0 → v1.1.0
   Changes: [description from CHANGELOG if available]
   
   Would you like to update?
   ```

4. **If user agrees, update files**
   - Download new SKILL.md to the skill directory
   - Optionally download updated scripts/ and references/
   - Confirm update successful

5. **After update**
   - Show new version number
   - Summarize what changed
   - Remind user to restart agent if needed

### Version Format

This skill uses semantic versioning (MAJOR.MINOR.PATCH):

- **MAJOR** - Breaking changes, incompatible with previous versions
- **MINOR** - New features, backward compatible
- **PATCH** - Bug fixes, backward compatible

### Check for Updates Command

Users can ask:
- "check for updates to extension-agent-installer"
- "есть обновления для скилла?"
- "update extension-agent-installer"
- "обнови инсталлер"

### Update Instructions for Agent

```
When user asks to update this skill:

1. Fetch: https://raw.githubusercontent.com/lmt-expert-company/extension-agent-installer/main/SKILL.md
2. Parse version from line: version: X.X.X
3. Compare with current version in this file
4. If newer version exists:
   - Ask user to confirm update
   - Download new SKILL.md to replace current file
   - Download scripts/*.py and references/*.md if updated
   - Report success with new version
5. If already latest:
   - Tell user "Already up to date (vX.X.X)"
```

## Mission

**This skill exists to protect users in the AI era.**

As AI agents become more powerful and gain access to our files, terminals, and credentials, the risk of installing malicious extensions grows. A single compromised skill can:

- Exfiltrate your API keys and secrets
- Access your banking information
- Steal personal data
- Execute unauthorized commands

**This skill helps users who cannot verify extension safety themselves by:**

1. **Scanning before installation** - Never install blindly
2. **Alerting to vulnerabilities** - Know the risks before you proceed
3. **Guiding credential setup** - Understand what access you're granting
4. **Promoting digital hygiene** - Make informed decisions about what you install

In the AI era, your agent has access to your digital life. Don't give that access to untrusted code.

## Supported Clients

| Client | Project Path | Global Path |
|--------|--------------|-------------|
| OpenCode | `.opencode/skills/` | `~/.config/opencode/skills/` |
| Claude Code | `.claude/skills/` | `~/.claude/skills/` |
| Cursor | `.cursor/skills/` | `~/.cursor/skills/` |
| Windsurf | `.windsurf/skills/` | `~/.codeium/windsurf/skills/` |
| Gemini CLI | `.gemini/skills/` | `~/.gemini/skills/` |
| Codex | `.agents/skills/` | `~/.agents/skills/` |
| GitHub Copilot | `.github/skills/` | `~/.copilot/skills/` |

## Workflow

1. **Fetch the URL** - Get content from user-provided link
2. **Determine extension type** - skill / plugin / MCP server / custom tool
3. **Detect current client** - ALWAYS check which AI assistant is being used (MANDATORY)
4. **Check dependencies** - Verify required tools are installed (node, npx, python, etc.)
5. **Download to temp location** - For scanning before installation
6. **Security Scan** - Run BOTH scanners for comprehensive coverage
7. **Handle vulnerabilities** - ALWAYS notify user, ask to proceed or reject
8. **Ask installation scope** - ALWAYS ask: project-local or global (MANDATORY)
9. **Install** - Write files or update config as needed (different for each client!)
10. **Validate installation** - Check JSON, test commands
11. **Cleanup temp files** - ALWAYS remove temporary files after installation
12. **Setup credentials** - Guide user through required configuration
13. **Verify** - Confirm installation successful

## Mandatory Rules

### Rule 1: ALWAYS Ask Installation Scope

**EVERY installation MUST ask the user:**

```json
{
  "questions": [{
    "question": "Where should I install this extension?",
    "header": "Scope",
    "options": [
      {"label": "Project-local", "description": "Only this project can use it (.opencode/, .claude/, etc.)"},
      {"label": "Global", "description": "All projects can use it (~/.config/opencode/, ~/.claude/, etc.)"}
    ]
  }]
}
```

**NEVER assume the scope.** Even if user previously chose one option, ask again for each new extension.

### Rule 2: ALWAYS Cleanup Temporary Files

After installation (success or failure), remove all temporary files:

```bash
# Create temp directory for scanning
TEMP_DIR=$(mktemp -d)  # Linux/Mac
# or
TEMP_DIR=$env:TEMP\extension-scan-$(Get-Random)  # Windows PowerShell

# Download and scan files in $TEMP_DIR
# ... installation process ...

# ALWAYS cleanup after installation
rm -rf "$TEMP_DIR"  # Linux/Mac
# or
Remove-Item -Recurse -Force $TEMP_DIR  # Windows
```

**Cleanup must happen:**
- After successful installation
- After failed installation
- After user cancels
- After vulnerability rejection

### Rule 3: NEVER Leave Orphan Files

Track all files created during installation:
1. Temp download directory
2. Scanned files
3. Log files (if any)

All must be removed before reporting completion.

### Rule 4: ALWAYS Detect Current Client

**BEFORE installing any extension, ALWAYS detect which AI client is being used.**

Different clients have different:
- Config file locations
- Config file names
- MCP server configuration formats
- Installation paths

```bash
# Detect client by checking which directories exist
ls -la .opencode 2>/dev/null && echo "CLIENT: OpenCode"
ls -la .claude 2>/dev/null && echo "CLIENT: Claude Code"
ls -la .cursor 2>/dev/null && echo "CLIENT: Cursor"
ls -la .windsurf 2>/dev/null && echo "CLIENT: Windsurf"
ls -la .gemini 2>/dev/null && echo "CLIENT: Gemini CLI"
ls -la .agents 2>/dev/null && echo "CLIENT: Codex"
ls -la .github/copilot 2>/dev/null && echo "CLIENT: GitHub Copilot"
```

**NEVER assume the client.** Always verify before installation.

## Client Detection

### How to Detect Current Client

Check for client-specific directories in the project:

| Directory | Client |
|-----------|--------|
| `.opencode/` | OpenCode |
| `.claude/` | Claude Code |
| `.cursor/` | Cursor |
| `.windsurf/` | Windsurf |
| `.gemini/` | Gemini CLI |
| `.agents/` | Codex |
| `.github/copilot/` | GitHub Copilot |

### Detection Commands

```bash
# Check multiple clients at once
for client in ".opencode" ".claude" ".cursor" ".windsurf" ".gemini" ".agents"; do
  if [ -d "$client" ]; then
    echo "Detected: $client"
  fi
done
```

### Client-Specific Config Files

| Client | Config File (Project) | Config File (Global) |
|--------|----------------------|---------------------|
| OpenCode | `opencode.json` | `~/.config/opencode/opencode.json` |
| Claude Code | `.claude/settings.json` | `~/.claude/settings.json` |
| Cursor | `.cursor/mcp.json` | `~/.cursor/mcp.json` |
| Windsurf | `.windsurf/mcp.json` | `~/.codeium/windsurf/mcp.json` |
| Gemini CLI | `.gemini/config.json` | `~/.gemini/config.json` |
| Codex | `codex.json` | `~/.codex/codex.json` |

### MCP Server Configuration by Client

#### OpenCode (CORRECT FORMAT)
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "local",
      "command": ["npx", "-y", "package-name@latest"],
      "enabled": true
    }
  }
}
```

**IMPORTANT for OpenCode:**
- `type: "local"` is **REQUIRED**
- `command` is an **ARRAY** with command and all arguments together
- `enabled: true` is optional (defaults to true)
- For remote servers use `"type": "remote"` with `"url"`

#### Claude Code
```json
{
  "mcpServers": {
    "server-name": {
      "command": "npx",
      "args": ["-y", "package-name@latest"]
    }
  }
}
```

#### Cursor
```json
{
  "mcpServers": {
    "server-name": {
      "command": "npx",
      "args": ["-y", "package-name@latest"]
    }
  }
}
```

#### Windsurf
```json
{
  "mcpServers": {
    "server-name": {
      "command": "npx",
      "args": ["-y", "package-name@latest"]
    }
  }
}
```

**KEY DIFFERENCES:**

| Client | Config Key | type field | command format |
|--------|------------|------------|----------------|
| OpenCode | `"mcp"` | **Required** | Array: `["npx", "-y", "pkg"]` |
| Claude Code | `"mcpServers"` | None | String + `args` array |
| Cursor | `"mcpServers"` | None | String + `args` array |
| Windsurf | `"mcpServers"` | None | String + `args` array |

**Installing with wrong config format will NOT work!**

### Client Detection Workflow

1. **Check project directories** - Look for `.opencode/`, `.claude/`, etc.
2. **If multiple clients detected** - Ask user which one to use
3. **If no client detected** - Ask user to specify
4. **Read existing config** - Check if config file already exists
5. **Use correct format** - Apply client-specific config format

### Questions to Ask for Client Detection

If client cannot be auto-detected or multiple clients found:

```json
{
  "questions": [{
    "question": "Which AI client are you using?",
    "header": "Client",
    "options": [
      {"label": "OpenCode", "description": "Config: opencode.json with 'mcp' key"},
      {"label": "Claude Code", "description": "Config: .claude/settings.json with 'mcpServers' key"},
      {"label": "Cursor", "description": "Config: .cursor/mcp.json with 'mcpServers' key"},
      {"label": "Windsurf", "description": "Config: .windsurf/mcp.json with 'mcpServers' key"}
    ]
  }]
}
```

## Dependency Checking

**CRITICAL: Check required tools BEFORE installing any extension.**

Installing an extension without required dependencies can break your project or make it unusable.

### How to Check Dependencies

Run these commands to verify tools are installed:

```bash
# Node.js / npm / npx (required for most MCP servers and npm plugins)
node --version
npm --version
npx --version

# Bun (required for some agents and plugins)
bun --version

# Python (required for Python-based extensions)
python --version
python3 --version

# uv (required for mcp-scan and some Python extensions)
uv --version

# Git (required for cloning repositories)
git --version
```

### Dependency Requirements by Extension Type

| Extension Type | Required Tools |
|----------------|----------------|
| MCP Server (npm) | node, npx |
| MCP Server (local) | node, npx, or python |
| Plugin (npm) | bun or node |
| Skill | None (text files only) |
| Custom Tool (TS/JS) | bun or node |
| Custom Tool (Python) | python |

### Installation Commands by Platform

#### Windows
```bash
# Node.js (includes npm and npx)
winget install OpenJS.NodeJS.LTS
# or download from https://nodejs.org/

# Bun
powershell -c "irm bun.sh/install.ps1 | iex"

# Python
winget install Python.Python.3.12
# or download from https://python.org/

# uv (after Python is installed)
pip install uv
```

#### macOS
```bash
# Node.js
brew install node

# Bun
curl -fsSL https://bun.sh/install | bash

# Python
brew install python3

# uv
pip3 install uv
```

#### Linux
```bash
# Node.js
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

# Bun
curl -fsSL https://bun.sh/install | bash

# Python
sudo apt install python3 python3-pip

# uv
pip install uv
```

### Dependency Check Workflow

Before installing any extension:

1. **Detect extension requirements** - Check package.json, README, or config
2. **Run version checks** - Verify each required tool is installed
3. **If missing, offer to install** - Show installation commands for user's platform
4. **Wait for confirmation** - Only proceed after dependencies are ready

### Example Check for MCP Server

```bash
# Check if npx is available
npx --version

# If not found, notify user:
# "This MCP server requires Node.js and npx. 
#  Would you like me to show installation instructions?"
```

### Questions to Ask for Missing Dependencies

```json
{
  "questions": [{
    "question": "This extension requires Node.js (npx) which is not installed. What would you like to do?",
    "header": "Dependencies",
    "options": [
      {"label": "Show install instructions", "description": "I'll guide you through installing Node.js"},
      {"label": "I'll install it myself", "description": "I'll install Node.js and come back"},
      {"label": "Cancel installation", "description": "Don't install this extension"}
    ]
  }]
}
```

### NEVER Install Without Checking Dependencies

Installing an extension that requires missing tools can:
- Break your project configuration
- Create invalid config files
- Make your AI agent unable to load the project
- Cause confusing error messages

Always verify dependencies FIRST!

## Security Scanning

Use BOTH scanners for maximum protection. Each catches different threat types.

### Scanner 1: mcp-scan (Snyk)

Local static analysis for MCP servers, tools, and skills.

#### Install
```bash
# Requires uv (Python package manager)
# Windows: pip install uv
# Mac/Linux: curl -LsSf https://astral.sh/uv/install.sh | sh
```

#### Scan Commands
```bash
# Scan a single skill file
uvx mcp-scan@latest --skills /path/to/SKILL.md

# Scan a directory of skills
uvx mcp-scan@latest --skills /path/to/skills/

# JSON output for parsing
uvx mcp-scan@latest --json --skills /path/to/extension
```

#### What mcp-scan Detects
- Prompt injection attacks
- Tool poisoning attacks
- Toxic flows
- Malware payloads
- Hard-coded secrets

### Scanner 2: Agent Trust Hub (Gen Digital)

Cloud-based verification backed by Gen Threat Labs.

#### API Usage
```bash
curl -X POST "https://ai.gendigital.com/api/scan/lookup" \
  -H "Content-Type: application/json" \
  -d '{"skillUrl":"https://skills.sh/author/skill-name"}'
```

#### Response Format
```json
{
  "severity": "SAFE | LOW | HIGH | CRITICAL",
  "notes": "Description of findings",
  "trusted": true | false
}
```

### Dual Scan Strategy

For maximum security, use both scanners. If EITHER scanner reports CRITICAL/HIGH, notify user.

## Vulnerability Handling

**CRITICAL RULE: Always notify user about ANY vulnerability found.**

When a scan detects issues:

1. **Show vulnerability report** - Present findings clearly to user
2. **Explain the risks** - What could happen if installed
3. **Ask user decision** - Use `question` tool for install/reject choice

### User Decision Flow

Use the `question` tool:

```json
{
  "questions": [{
    "question": "Vulnerabilities found! Proceed with installation?",
    "header": "Security",
    "options": [
      {"label": "Reject (Recommended)", "description": "Do not install - security risk too high"},
      {"label": "Install anyway", "description": "I understand the risks and want to proceed"}
    ]
  }]
}
```

## Credential Setup Guidance

**CRITICAL: After installing, always check if the extension requires credentials.**

### How to Detect Required Credentials

1. **Environment variables** - Look for `process.env`, `{env:VAR_NAME}`, `$VAR_NAME`
2. **API keys** - Mentions of "API key", "token", "secret", "credential"
3. **OAuth requirements** - Mentions of "OAuth", "authenticate", "login"
4. **Config files** - References to config files that need creation

### Common Credential Patterns

| Pattern | Extension Needs |
|---------|-----------------|
| `{env:API_KEY}` | Environment variable API_KEY |
| `process.env.OPENAI_KEY` | OpenAI API key in env |
| `Authorization: Bearer` | Bearer token |
| `oauth: {}` | OAuth authentication |

### Credential Guidance Workflow

After installation, if credentials are needed:

1. **Fetch extension documentation** - Read README, SKILL.md for setup instructions
2. **Extract required credentials** - List all env vars, tokens, config needed
3. **Present step-by-step guide** - Use clear, non-technical language
4. **Offer to help configure** - Guide user through each step

### Example Guidance Output

```
To use [extension-name], you need to configure:

1. API Key (Required)
   - Go to https://service.com/settings/api-keys
   - Click "Create new API key"
   - Copy the key
   - Add to .env: API_KEY=your-key-here

2. OAuth Setup (Optional)
   - Run: opencode mcp auth service-name

Would you like me to help you set up these credentials now?
```

### Questions to Ask for Credential Setup

```json
{
  "questions": [{
    "question": "This extension requires an API key. Do you have one?",
    "header": "Setup",
    "options": [
      {"label": "Yes, I have it", "description": "I'll help you configure it"},
      {"label": "No, help me get one", "description": "I'll guide you through signup"},
      {"label": "Skip for now", "description": "You can configure later"}
    ]
  }]
}
```

### Common Service Setup Guides

| Service | Where to get credentials |
|---------|-------------------------|
| OpenAI | https://platform.openai.com/api-keys |
| Anthropic | https://console.anthropic.com/settings/keys |
| GitHub | https://github.com/settings/tokens |
| Vercel | https://vercel.com/account/tokens |
| Sentry | https://sentry.io/settings/account/api/auth-tokens/ |
| Stripe | https://dashboard.stripe.com/apikeys |
| Cloudflare | https://dash.cloudflare.com/profile/api-tokens |

## Extension Types and Install Locations

### OpenCode
| Type | Project | Global |
|------|---------|--------|
| Skill | `.opencode/skills/name/SKILL.md` | `~/.config/opencode/skills/name/SKILL.md` |
| Plugin (npm) | `opencode.json` → `plugin: [...]` | Same |
| MCP Server | `opencode.json` → `mcp: {...}` | Same |

### Claude Code
| Type | Project | Global |
|------|---------|--------|
| Skill | `.claude/skills/name/SKILL.md` | `~/.claude/skills/name/SKILL.md` |

### Cursor
| Type | Project | Global |
|------|---------|--------|
| Skill | `.cursor/skills/name/SKILL.md` | `~/.cursor/skills/name/SKILL.md` |

### Windsurf
| Type | Project | Global |
|------|---------|--------|
| Skill | `.windsurf/skills/name/SKILL.md` | `~/.codeium/windsurf/skills/name/SKILL.md` |

### Gemini CLI
| Type | Project | Global |
|------|---------|--------|
| Skill | `.gemini/skills/name/SKILL.md` | `~/.gemini/skills/name/SKILL.md` |

### Codex
| Type | Project | Global |
|------|---------|--------|
| Skill | `.agents/skills/name/SKILL.md` | `~/.agents/skills/name/SKILL.md` |

### GitHub Copilot
| Type | Project | Global |
|------|---------|--------|
| Skill | `.github/skills/name/SKILL.md` | `~/.copilot/skills/name/SKILL.md` |

## Detection Heuristics

- **Skill**: README mentions "skill", has SKILL.md file, frontmatter with name/description
- **Plugin**: npm package with agent-related prefix, exports plugin functions
- **MCP Server**: mentions "MCP", "Model Context Protocol", has command or url config
- **Custom Tool**: standalone .ts/.js with tool() helper

## Questions to Ask

Use the `question` tool:

1. **Dependency Check** - If required tools missing, offer to install or cancel
2. **Vulnerability Decision** - ALWAYS ask if vulnerabilities found
3. **Target client** - Which AI assistant to install for?
4. **Scope**: Install globally (all projects) or project-local?
5. **Credentials**: Do you have the required API keys?

## Security Best Practices

1. **Always check dependencies first** - Missing tools can break your project
2. **Always scan before install** - Never skip security check
3. **Always notify user of vulnerabilities** - User must explicitly approve
4. **Trust but verify** - Even popular packages can be compromised
5. **Guide credential setup** - Help non-technical users configure
6. **Verify after install** - Confirm the extension works correctly

## After Installation

1. Verify the installation (check file exists or config updated)
2. Run a post-install scan to confirm safe state
3. **Validate configuration** - See "Installation Validation" section below
4. Test the extension works (run a simple command if applicable)
5. Guide user through credential setup
6. Explain how to use the extension
7. Provide troubleshooting tips if setup fails

## Installation Validation

**CRITICAL: Always validate the installation before telling user it's done.**

### Validation Steps for Each Extension Type

#### MCP Servers

1. **Validate JSON syntax**
   ```bash
   # Check if opencode.json is valid JSON
   cat opencode.json | python -m json.tool
   # or
   cat opencode.json | node -e "JSON.parse(require('fs').readFileSync(0))"
   ```

2. **Check command exists**
   ```bash
   # Verify the command in config is available
   npx --version  # if using npx
   bun --version  # if using bun
   ```

3. **Test MCP server starts** (optional but recommended)
   ```bash
   # Try running the MCP server briefly
   timeout 5 npx -y package-name --version 2>&1 || echo "Server check completed"
   ```

4. **Check config structure**
   - For OpenCode: `opencode.json` must have `mcp` object
   - Each MCP server needs `command` and optionally `args`
   - Use `-y` flag for npx to avoid interactive prompts

#### Skills

1. **Check file exists**
   ```bash
   ls -la .opencode/skills/skill-name/SKILL.md
   ```

2. **Validate frontmatter**
   - Must have `name:` field
   - Must have `description:` field
   - YAML must be valid

3. **Test skill loads** - restart agent and verify skill appears

#### Plugins

1. **Check npm package exists**
   ```bash
   npm view package-name
   ```

2. **Verify config entry**
   - Check `plugin` array in opencode.json

### Common Installation Errors

| Error | Cause | Fix |
|-------|-------|-----|
| JSON parse error | Invalid JSON syntax | Fix brackets, quotes, commas |
| Command not found | Missing `-y` flag in npx | Add `"-y"` to args array |
| Module not found | Package doesn't exist | Check package name |
| Permission denied | No execute permission | Check file permissions |
| Timeout | Server won't start | Check dependencies |

### Correct MCP Config Examples (OpenCode)

**With npx:**
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "local",
      "command": ["npx", "-y", "package-name@latest"],
      "enabled": true
    }
  }
}
```

**With bun:**
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "local",
      "command": ["bun", "x", "package-name"]
    }
  }
}
```

**Local script:**
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "local",
      "command": ["node", "./path/to/server.js"]
    }
  }
}
```

**Remote server:**
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "remote",
      "url": "https://mcp.example.com"
    }
  }
}
```

**With environment variables:**
```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "server-name": {
      "type": "local",
      "command": ["npx", "-y", "package-name"],
      "environment": {
        "API_KEY": "{env:MY_API_KEY}"
      }
    }
  }
}
```

### Validation Failure Response

If validation fails:

1. **DO NOT tell user "installed successfully"**
2. **Show the error clearly**
3. **Offer to fix or rollback**

```
INSTALLATION FAILED

Error: Invalid JSON in opencode.json
Line 5: Missing comma after "command"

Would you like me to:
1. Fix the JSON automatically
2. Restore backup
3. Show the full error for manual fix
```

## Troubleshooting & Rollback

If installation causes problems:

### Extension Not Working

1. **Check dependencies again** - Verify all required tools are installed
2. **Check configuration** - Verify the config file is valid JSON
3. **Check logs** - Look for error messages in agent output
4. **Restart the agent** - Some extensions require restart

### Project Broken / Agent Can't Load

1. **Backup and remove config** - If opencode.json is corrupted, restore from backup or remove
2. **Remove the extension** - Delete the extension files/config
3. **Check for conflicts** - Multiple extensions may conflict
4. **Report the issue** - Let the extension author know

### Rollback Steps

```bash
# For MCP servers - remove from config or disable
# Edit opencode.json and remove or set "enabled": false

# For skills - delete the skill folder
rm -rf .opencode/skills/extension-name

# Restore opencode.json from backup if corrupted
# If no backup exists, create minimal valid config:
```

Minimal opencode.json:
```json
{
  "$schema": "https://opencode.ai/config.json"
}
```

## Known Installation Issues & Solutions

**CRITICAL: ALWAYS inform user when ANY problem occurs. Ask before proceeding with fixes.**

### Issue 1: Wrong MCP Config Format for OpenCode

**Symptom:** MCP server installed but not working.

**Root Cause:** 
- Missing `type: "local"` field (REQUIRED for OpenCode)
- `command` was a string instead of array

**Wrong:**
```json
{"mcp": {"server": {"command": "npx", "args": ["-y", "pkg"]}}}
```

**Correct:**
```json
{"mcp": {"server": {"type": "local", "command": ["npx", "-y", "pkg"]}}}
```

**Fix:** Always use `type: "local"` and array for `command`.

---

### Issue 2: Config File Does Not Exist

**Symptom:** Extension "installed" but config file missing.

**Cause:** Agent didn't create config file.

**Fix:** Check if config exists, create if needed:
```bash
ls opencode.json 2>/dev/null || echo '{"$schema":"https://opencode.ai/config.json"}' > opencode.json
```

---

### Issue 3: npx Interactive Prompt Blocks Installation

**Symptom:** npx hangs waiting for "yes" input.

**Cause:** Missing `-y` flag.

**Wrong:** `["npx", "package-name"]`
**Correct:** `["npx", "-y", "package-name"]`

**Fix:** ALWAYS include `-y` flag for npx.

---

### Issue 4: Extension Installed But Not Appearing

| Symptom | Cause | Fix |
|---------|-------|-----|
| Tools not appearing | Agent not restarted | Restart OpenCode |
| "Command not found" | npx/node not in PATH | Install Node.js |
| JSON parse error | Invalid JSON | Validate syntax |
| Permission denied | No execute permission | Check permissions |

---

### Issue 5: Temporary Files Not Cleaned Up

**Symptom:** Temp directories left after installation.

**Fix:** ALWAYS cleanup:
```bash
TEMP_DIR=$(mktemp -d)
# ... work ...
rm -rf "$TEMP_DIR"  # ALWAYS at end
```

---

### Issue 6: Wrong Client Detected

**Symptom:** Extension installed for wrong client.

**Fix:** ALWAYS detect client first, ASK if unsure:
```bash
ls -la .opencode 2>/dev/null && echo "OpenCode"
ls -la .claude 2>/dev/null && echo "Claude Code"
```

---

## Rule 5: ALWAYS Ask User About Problems

**When ANY installation problem occurs:**

1. **STOP** - Don't continue with broken state
2. **SHOW** - Explain what went wrong
3. **OFFER** - Give options to proceed
4. **WAIT** - Get explicit user choice

**Example:**
```
PROBLEM: MCP config has wrong format

What would you like me to do?
1. Fix automatically
2. Show config for manual edit  
3. Cancel installation
```

**NEVER silently ignore problems.**


