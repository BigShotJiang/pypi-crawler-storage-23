#!/usr/bin/env python3
"""
Cross-platform installer for extension-agent-installer skill.
Installs to OpenCode, Claude Code, Cursor, Windsurf, Gemini CLI, Codex, GitHub Copilot.
"""

import argparse
import os
import platform
import shutil
import sys
from pathlib import Path

VERSION = "1.5.0"
REPO_URL = "https://github.com/lmt-expert-company/extension-agent-installer"

CLIENTS = {
    "opencode": {
        "project_dir": ".opencode/skills/extension-agent-installer",
        "global_dir": "~/.config/opencode/skills/extension-agent-installer",
        "name": "OpenCode"
    },
    "claude": {
        "project_dir": ".claude/skills/extension-agent-installer",
        "global_dir": "~/.claude/skills/extension-agent-installer",
        "name": "Claude Code"
    },
    "cursor": {
        "project_dir": ".cursor/skills/extension-agent-installer",
        "global_dir": "~/.cursor/skills/extension-agent-installer",
        "name": "Cursor"
    },
    "windsurf": {
        "project_dir": ".windsurf/skills/extension-agent-installer",
        "global_dir": "~/.codeium/windsurf/skills/extension-agent-installer",
        "name": "Windsurf"
    },
    "gemini": {
        "project_dir": ".gemini/skills/extension-agent-installer",
        "global_dir": "~/.gemini/skills/extension-agent-installer",
        "name": "Gemini CLI"
    },
    "codex": {
        "project_dir": ".agents/skills/extension-agent-installer",
        "global_dir": "~/.agents/skills/extension-agent-installer",
        "name": "Codex"
    },
    "copilot": {
        "project_dir": ".github/skills/extension-agent-installer",
        "global_dir": "~/.copilot/skills/extension-agent-installer",
        "name": "GitHub Copilot"
    }
}


def get_package_dir():
    """Get the directory where package files are located."""
    return Path(__file__).parent.parent


def expand_path(path: str) -> Path:
    """Expand ~ to user home directory."""
    return Path(path).expanduser().resolve()


def detect_client():
    """Detect which AI client is being used based on project directories."""
    cwd = Path.cwd()
    detected = []
    
    for client_id, client_info in CLIENTS.items():
        project_dir = cwd / client_info["project_dir"].split("/")[0]
        if project_dir.exists():
            detected.append(client_id)
    
    return detected


def install(client: str, global_install: bool = False, verbose: bool = True):
    """Install the skill to specified client."""
    if client not in CLIENTS:
        print(f"Error: Unknown client '{client}'")
        print(f"Available clients: {', '.join(CLIENTS.keys())}")
        return False
    
    client_info = CLIENTS[client]
    dir_key = "global_dir" if global_install else "project_dir"
    target_dir = expand_path(client_info[dir_key])
    
    if verbose:
        scope = "global" if global_install else "project"
        print(f"Installing to {client_info['name']} ({scope})...")
        print(f"Target: {target_dir}")
    
    target_dir.mkdir(parents=True, exist_ok=True)
    
    package_dir = get_package_dir()
    
    files_to_copy = [
        ("SKILL.md", "SKILL.md"),
        ("README.md", "README.md"),
        ("LICENSE", "LICENSE"),
        ("CHANGELOG.md", "CHANGELOG.md"),
    ]
    
    dirs_to_copy = ["scripts", "references"]
    
    copied_files = 0
    for src_name, dst_name in files_to_copy:
        src = package_dir / src_name
        dst = target_dir / dst_name
        if src.exists():
            shutil.copy2(src, dst)
            copied_files += 1
            if verbose:
                print(f"  Copied: {dst_name}")
    
    for dir_name in dirs_to_copy:
        src_dir = package_dir / dir_name
        dst_dir = target_dir / dir_name
        if src_dir.exists():
            if dst_dir.exists():
                shutil.rmtree(dst_dir)
            shutil.copytree(src_dir, dst_dir)
            if verbose:
                print(f"  Copied: {dir_name}/")
    
    if verbose:
        print(f"\nSuccess! Installed extension-agent-installer v{VERSION}")
        print(f"Location: {target_dir}")
        print(f"\nRepository: {REPO_URL}")
    
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Install extension-agent-installer skill for AI coding agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  extension-agent-installer install --client opencode --global
  extension-agent-installer install --client claude
  extension-agent-installer detect
"""
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command")
    
    install_parser = subparsers.add_parser("install", help="Install the skill")
    install_parser.add_argument(
        "--client", "-c",
        choices=list(CLIENTS.keys()),
        help="Target AI client (auto-detect if not specified)"
    )
    install_parser.add_argument(
        "--global", "-g",
        action="store_true",
        dest="global_install",
        help="Install globally (all projects)"
    )
    install_parser.add_argument(
        "--project", "-p",
        action="store_false",
        dest="global_install",
        help="Install to current project only (default)"
    )
    
    detect_parser = subparsers.add_parser("detect", help="Detect installed AI clients")
    
    subparsers.add_parser("version", help="Show version")
    
    args = parser.parse_args()
    
    if args.command == "version":
        print(f"extension-agent-installer v{VERSION}")
        return 0
    
    if args.command == "detect":
        detected = detect_client()
        if detected:
            print("Detected AI clients:")
            for client_id in detected:
                print(f"  - {CLIENTS[client_id]['name']}")
        else:
            print("No AI clients detected in current directory")
            print("\nAvailable clients:")
            for client_id, info in CLIENTS.items():
                print(f"  - {info['name']}: --client {client_id}")
        return 0
    
    if args.command == "install":
        client = args.client
        if not client:
            detected = detect_client()
            if len(detected) == 1:
                client = detected[0]
                print(f"Auto-detected: {CLIENTS[client]['name']}")
            elif len(detected) > 1:
                print("Multiple clients detected. Please specify with --client")
                print(f"Options: {', '.join(detected)}")
                return 1
            else:
                print("No client detected. Please specify with --client")
                print(f"Options: {', '.join(CLIENTS.keys())}")
                return 1
        
        success = install(client, args.global_install)
        return 0 if success else 1
    
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
