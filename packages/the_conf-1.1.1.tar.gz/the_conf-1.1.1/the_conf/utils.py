TYPE_MAPPING = {
    "int": int,
    "str": str,
    "list": list,
    "dict": dict,
    "bool": bool,
}


class Index:
    pass


class NoValue:
    pass
