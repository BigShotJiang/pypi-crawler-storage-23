"""TrikHub CLI - scaffold, install, and publish triks."""

from trikhub.cli.main import cli

__all__ = ["cli"]
