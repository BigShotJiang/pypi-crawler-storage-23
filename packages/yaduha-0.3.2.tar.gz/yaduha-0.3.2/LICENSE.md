# Yaduha License (Academic Open License v1.0)

**Copyright © 2025**  
**Loyola Marymount University** – Kubishi Research Group  
**University of Southern California** – Autonomous Networks Research Group  
**Authors:** Jared Coleman, Diego Cuadros, Nicholas Leeds, Bhaskar Krishnamachari, Kira Toal, Ruben Rosales, Khalil Iskarous  

## 1. Permission and Use

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to use, copy, modify, merge, publish, and distribute the Software **for academic, research, and educational purposes**, subject to the following conditions:

1. **Attribution** — All copies or substantial portions of the Software must include this copyright notice, the list of authors, and this permission notice.  
2. **Acknowledgment** — Any publication, product, or presentation using the Software must acknowledge:  
   > “This work utilizes the *Yaduha* framework, developed by the Kubishi Research Group at Loyola Marymount University and the Autonomous Networks Research Group at the University of Southern California.”  
3. **No Endorsement** — The names of Loyola Marymount University, the University of Southern California, or any of the authors may not be used to endorse or promote products derived from this Software without prior written permission.  
4. **Noncommercial Use** — The Software may not be used for commercial purposes without explicit written permission from Loyola Marymount University.  
5. **Derivative Works** — Modified versions or derivative works must clearly indicate that they have been changed and may not imply endorsement by the original authors or institutions.

## 2. Disclaimer

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


For questions or permissions, contact:  
**Dr. Jared Coleman**  
*Kubishi Research Group, Loyola Marymount University*  
[jared.coleman@lmu.edu](mailto:jared.coleman@lmu.edu)
