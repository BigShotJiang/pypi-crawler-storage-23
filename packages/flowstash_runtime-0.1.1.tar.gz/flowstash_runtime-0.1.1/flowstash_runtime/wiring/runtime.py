import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Optional, List, Union
import importlib
import importlib.util
import dramatiq
from dramatiq.brokers.redis import RedisBroker
from flowstash_lib.config.runtime_config import RuntimeConfig, BackendType
from flowstash_lib.queue.backend import set_backend, TaskBackend
from flowstash_runtime.worker.backends.dramatiq.dramatiq_backend import DramatiqBackend, FrameworkContextMiddleware


@dataclass
class Runtime:
    """Runtime container for backend and config references."""
    backend: TaskBackend
    config: RuntimeConfig
    imported_modules: List[Any] = field(default_factory=list)

    @property
    def broker(self):
        """Return the global Dramatiq broker."""
        import dramatiq
        return dramatiq.get_broker()


def _auto_import_path(path: Union[str, Path]) -> List[Any]:
    """
    Import modules from a file or directory path.
    
    If path is a directory:
    - If it contains __init__.py, import it as a module.
    - Otherwise, import all *.py files in it.
    If path is a .py file, import it.
    """
    p = Path(path)
    if not p.exists():
        return []

    modules = []
    if p.is_dir():
        if (p / "__init__.py").exists():
            mod = _import_module_from_path(p)
            if mod:
                modules.append(mod)
        else:
            for f in sorted(p.glob("*.py")):
                if f.name != "__init__.py":
                    mod = _import_module_from_path(f)
                    if mod:
                        modules.append(mod)
    elif p.is_file() and p.suffix == ".py":
        mod = _import_module_from_path(p)
        if mod:
            modules.append(mod)
            
    return modules


def _import_module_from_path(file_path: Path) -> Any:
    """Import a module from a file path dynamically."""
    import sys
    # Use parent directory name if it's an __init__.py file for package names
    if file_path.name == "__init__.py":
        module_name = file_path.parent.name
    elif file_path.is_dir():
        module_name = file_path.name
        file_path = file_path / "__init__.py"
    else:
        module_name = file_path.stem
        
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec and spec.loader:
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module
    
    return None


def _build_redis_url(config: RuntimeConfig) -> str:
    """Build Redis URL from config or environment."""
    if os.getenv("REDIS_URL"):
        return os.getenv("REDIS_URL")
        
    if config.backend.dramatiq and config.backend.dramatiq.redis_url:
        return config.backend.dramatiq.redis_url
        
    return "redis://localhost:6379/0"


def initialize_runtime(
    config: RuntimeConfig, 
    auto_import: Optional[List[Union[str, Path]]] = None
) -> Runtime:
    """
    Initialize the framework runtime: configuration, clients, and task backend.
    
    This is the single entry point for setting up the producer side (backend submission)
    and registry initialization.
    """
    # 1. Init Client Registry
    from flowstash_clients.registry import init_registry
    init_registry(config)

    # 2. Handle auto-imports from paths
    imported_modules = []
    if auto_import:
        for path in auto_import:
            mods = _auto_import_path(path)
            if mods:
                imported_modules.extend(mods)

    # 3. Configure task backend based on config.backend.type
    backend: Optional[TaskBackend] = None
    if config.backend.type == BackendType.DRAMATIQ:
        redis_url = _build_redis_url(config)
        broker = RedisBroker(url=redis_url)
        dramatiq.set_broker(broker)
        
        # Dramatiq's built-in middlewares (like Prometheus) expect the process_boot 
        # signal to be emitted to initialize their internal states (like prometheus Counters).
        # We must emit this manually here because we are initializing the broker programmatically 
        # (not via dramatiq CLI), ensuring producers (API) also initialize metrics.
        broker.emit_after("process_boot")
        
        # Set flowstash_lib.queue.backend
        backend = set_backend(DramatiqBackend())
    elif config.backend.type == BackendType.MANAGED:
        managed_api_url = os.getenv("flowstash_API_URL") or os.getenv("MANAGED_API_URL") or "https://api.flowstash.dev"
        managed_auth_token = os.getenv("MANAGED_AUTH_TOKEN")
        
        if managed_auth_token:
            from flowstash_lib.queue.backends.managed_tasks import ManagedTasksBackend
            from flowstash_lib.pipelines.backends.managed_feed import ManagedFeedBackend
            from flowstash_lib.pipelines.records_feed import set_feed_backend
            
            backend = set_backend(ManagedTasksBackend(
                api_url=managed_api_url,
                auth_token=managed_auth_token,
                service_url=os.getenv("MANAGED_SERVICE_URL"),
            ))
            
            set_feed_backend(ManagedFeedBackend(
                api_url=managed_api_url,
                auth_token=managed_auth_token,
            ))
        else:
            raise ValueError("MANAGED backend requires MANAGED_AUTH_TOKEN environment variable to be set")
            
    elif config.backend.type == BackendType.ASYNC:
        # Local asyncio development backend
        print("Falling back to asyncio development backend! This should not be used in production!")
        from flowstash_lib.queue.asyncio_backend import AsyncioBackend
        backend = set_backend(AsyncioBackend())
    else:
        raise ValueError(f"Unsupported backend: {config.backend.type}")
    
    if backend and hasattr(backend, "on_worker_init"):
        backend.on_worker_init()
    
    return Runtime(backend=backend, config=config, imported_modules=imported_modules)



def build_worker_runtime(
    config: RuntimeConfig, 
    auto_import: Optional[List[Union[str, Path]]] = None
) -> Runtime:
    """
    Configure runtime for worker service.
    
    Deprecated: Use initialize_runtime(config) and then get a consumer.
    """
    # Import task modules is now out of scope for RuntimeConfig, 
    # and they should be passed as auto_import paths or imported manually.

    return initialize_runtime(config, auto_import=auto_import)
