from django.apps import AppConfig
from lariv.registry import ConfigRegistry


@ConfigRegistry.register("users")
class UsersConfig(AppConfig):
    name = "users"
    p_type = "core"
    verbose_name = "Users"
    icon = "user"
    url_prefix = "users"

    def ready(self):
        from . import ui  # noqa: F401
