from users.models import User
from django.contrib.auth.models import Group
import random
import os
from faker import Faker

faker = Faker("en_IN")
phone_format = "+91##########"
default_password = "Pass1234#"

INDIAN_FIRST_NAMES = [
    "Arjun",
    "Rahul",
    "Vikram",
    "Rajesh",
    "Amit",
    "Suresh",
    "Karthik",
    "Ravi",
    "Sandeep",
    "Prakash",
    "Naveen",
    "Deepak",
    "Manoj",
    "Sunil",
    "Anand",
    "Vijay",
    "Gaurav",
    "Rohit",
    "Sachin",
    "Aditya",
    "Kunal",
    "Ritesh",
    "Piyush",
    "Abhishek",
    "Vivek",
    "Rajiv",
    "Sanjay",
    "Dinesh",
    "Mukesh",
    "Harish",
    "Priya",
    "Anjali",
    "Neha",
    "Pooja",
    "Meera",
    "Divya",
    "Shweta",
    "Ritu",
    "Sneha",
    "Kavita",
    "Anita",
    "Deepika",
    "Rashmi",
    "Swati",
    "Jyoti",
    "Manisha",
    "Pallavi",
    "Rachana",
    "Shilpa",
    "Tanvi",
    "Aarti",
    "Bhavana",
    "Chitra",
    "Dipika",
    "Ekta",
    "Farah",
    "Geeta",
    "Hema",
    "Indira",
    "Jaya",
]

INDIAN_LAST_NAMES = [
    "Sharma",
    "Patel",
    "Singh",
    "Kumar",
    "Gupta",
    "Verma",
    "Chopra",
    "Reddy",
    "Kapoor",
    "Malhotra",
    "Mehta",
    "Joshi",
    "Chauhan",
    "Agarwal",
    "Nair",
    "Menon",
    "Iyer",
    "Pillai",
    "Nayak",
    "Mishra",
    "Tiwari",
    "Bhat",
    "Desai",
    "Kaur",
    "Rao",
    "Khan",
    "Ali",
    "Hussain",
    "Khatri",
    "Gandhi",
    "Conversationterjee",
    "Banerjee",
    "Mukherjee",
    "Sen",
    "Das",
    "Dutta",
    "Bose",
    "Ghosh",
    "Chakrabarti",
    "Basu",
    "Nambiar",
    "Kurup",
    "Warrier",
    "Namboothiri",
    "Panicker",
    "Thampi",
    "Nambissan",
    "Kartha",
    "Nair",
    "Menon",
    "Shetty",
    "Hegde",
    "Pai",
    "Kamath",
    "Bhat",
    "Rao",
    "Prabhu",
    "Kunder",
    "Kotian",
    "Salian",
]


def get_random_indian_name():
    """Get a random combination of Indian first and last name"""
    first_name = random.choice(INDIAN_FIRST_NAMES)
    last_name = random.choice(INDIAN_LAST_NAMES)
    return f"{first_name} {last_name}"


def generate_user(group: str) -> User:
    """Generate a user with realistic Indian data"""
    name = get_random_indian_name()

    # Get current count of users for unique ID
    user_count = User.objects.count() + 1
    username = f"{name.replace(' ', '.').lower()}_{user_count}"

    user = User.objects.create_user(
        email=f"{username}@school1.com",
        phone=faker.numerify(phone_format),
        password=default_password,
        name=name,
        is_active=True,
        is_staff=False,
        is_superuser=False,
        is_approved=True,
    )
    user.groups.add(Group.objects.get_or_create(name=group)[0])
    return user


def generate_user_without_password(group: str) -> User:
    """
    Generate a user with realistic Indian data without a password
    Hashing passwords is very time consuming, so we don't do it here
    """
    name = get_random_indian_name()

    # Get current count of users for unique ID
    user_count = User.objects.count() + 1
    username = f"{name.replace(' ', '.').lower()}_{user_count}"

    user = User.objects.create_user(
        email=f"{username}@school1.com",
        phone=faker.numerify(phone_format),
        name=name,
        is_active=True,
        is_staff=False,
        is_superuser=False,
    )
    user.groups.add(Group.objects.get_or_create(name=group)[0])
    return user


def create_overall_superuser():
    """Create an overall superuser for the system"""

    if User.objects.filter(email="superadmin@lariv.in").exists():
        user = User.objects.get(email="superadmin@lariv.in")
        print("Overall superuser already exists")
        return user

    user = User.objects.create_superuser(
        email="superadmin@lariv.in",
        password=default_password,
        name="Super Admin",
    )
    print("Created overall superuser")
    return user
