from django.urls import path, reverse_lazy
from django.contrib.auth.views import LogoutView
from lariv.registry import ViewRegistry
from . import views  # noqa: F401 - ensures views are registered
from . import ui  # noqa: F401 - ensures UI components are registered

# New views using the component system
Login = ViewRegistry.get("users.Login")
Signup = ViewRegistry.get("users.Signup")
UserList = ViewRegistry.get("users.UserList")
UserDetail = ViewRegistry.get("users.UserView")
UserCreate = ViewRegistry.get("users.UserCreate")
UserUpdate = ViewRegistry.get("users.UserUpdate")
UserDelete = ViewRegistry.get("users.UserDelete")
UserSelectionTableView = ViewRegistry.get("users.UserSelectionTable")
UserMultiSelectionTableView = ViewRegistry.get("users.UserMultiSelectionTable")
RoleSelectionTableView = ViewRegistry.get("users.RoleSelectionTable")
ChangePassword = ViewRegistry.get("users.ChangePassword")

app_name = "users"

urlpatterns = [
    path("login/", Login.as_view(), name="login"),
    path(
        "logout/",
        LogoutView.as_view(next_page=reverse_lazy("users:login")),
        name="logout",
    ),
    path("signup/", Signup.as_view(), name="signup"),
    path("", UserList.as_view(), name="default"),
    path("list/", UserList.as_view(), name="list"),
    path("create/", UserCreate.as_view(), name="create"),
    path("<int:pk>/", UserDetail.as_view(), name="detail"),
    path("<int:pk>/update/", UserUpdate.as_view(), name="update"),
    path("<int:pk>/delete/", UserDelete.as_view(), name="delete"),
    path("select/", UserSelectionTableView.as_view(), name="select"),
    path("multi-select/", UserMultiSelectionTableView.as_view(), name="multi_select"),
    path("roles/select/", RoleSelectionTableView.as_view(), name="role_select"),
    path("<int:pk>/change-password/", ChangePassword.as_view(), name="change_password"),
]
