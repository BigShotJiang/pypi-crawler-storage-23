from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("users", "0002_change_phone_to_phonenumber"),
    ]

    operations = [
        migrations.CreateModel(
            name="Role",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("name", models.CharField(max_length=250, unique=True)),
            ],
        ),
    ]
