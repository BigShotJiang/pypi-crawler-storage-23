from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from .models import User, Role


class UserResource(resources.ModelResource):
    class Meta:
        model = User
        exclude = ("password",)


class UserAdmin(ImportExportModelAdmin, BaseUserAdmin):
    resource_classes = [UserResource]
    list_display = ("email", "name", "phone", "is_active", "is_staff", "is_superuser")
    search_fields = ("email", "name", "phone")
    list_filter = ("is_active", "is_staff", "is_superuser")
    ordering = ("email",)

    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Personal info", {"fields": ("name", "phone")}),
        ("Permissions", {"fields": ("is_active", "is_staff", "is_superuser")}),
    )
    add_fieldsets = (
        (None, {"fields": ("email", "password1", "password2", "name", "phone")}),
    )


class RoleAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)


admin.site.register(User, UserAdmin)
admin.site.register(Role, RoleAdmin)
