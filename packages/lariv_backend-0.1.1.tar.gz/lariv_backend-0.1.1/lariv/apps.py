from django.apps import AppConfig


class LarivConfig(AppConfig):
    name = "lariv"
    url_prefix = ""

    def ready(self):
        from . import ui  # noqa: F401
