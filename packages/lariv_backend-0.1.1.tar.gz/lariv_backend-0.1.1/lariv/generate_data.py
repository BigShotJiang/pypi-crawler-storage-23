import users.generator as users_generator
from lariv.registry import GeneratorRegistry
import logging

logger = logging.getLogger(__name__)


class DataGenerator:
    def generate_all_data(self):
        print("\nStarting data generation...")
        users_generator.create_overall_superuser()
        GeneratorRegistry.run_all()


def generate_data():
    generator = DataGenerator()
    return generator.generate_all_data()


if __name__ == "__main__":
    generate_data()
