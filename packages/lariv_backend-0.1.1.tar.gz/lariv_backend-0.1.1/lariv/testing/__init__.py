"""
Lariv UI Testing Harness

Provides base classes and utilities for Selenium-based UI testing
that integrates with Django's test framework and HTMX interactions.

Usage:
    from lariv.testing import LarivUITestCase, PageObject

    class MyUITest(LarivUITestCase):
        def test_my_feature(self):
            self.login()
            self.navigate_to('/app/students/list/')
            self.wait_for_htmx()
            ...
"""

from lariv.testing.base import LarivUITestCase

__all__ = [
    "LarivUITestCase",
]
