from lariv.registry import UIRegistry
from components.base import Component
from components.layouts import SimpleScaffoldLayout
from components.apps_grid import AppsGrid




@UIRegistry.register("lariv.AppsPage")
class AppsPage(Component):
    def build(self):
        return SimpleScaffoldLayout(
            uid="apps-scaffold",
            children=[AppsGrid(uid="apps-grid", key="apps")],
        )


class ComingSoon(Component):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def render_html(self, **kwargs) -> str:
        return """
        <div class="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
            <div class="mb-6">
                {% heroicon_outline "clock" class="w-24 h-24 text-primary" %}
            </div>
            <h1 class="text-4xl font-bold mb-4">Coming Soon</h1>
            <p class="text-lg text-base-content/70 mb-8 max-w-md">
                We're working hard to bring you something amazing. Stay tuned!
            </p>
            <a href="{% url 'apps' %}" class="btn btn-primary" hx-get="{% url 'apps' %}" hx-target="#app-layout" hx-swap="outerHTML">
                {% heroicon_mini "arrow-left" class="w-5 h-5" %}
                Back to Apps
            </a>
        </div>
        """


@UIRegistry.register("lariv.ComingSoon")
class ComingSoonPage(Component):
    def build(self):
        return SimpleScaffoldLayout(
            uid="coming-soon-scaffold",
            children=[ComingSoon(uid="coming-soon-content")],
        )
