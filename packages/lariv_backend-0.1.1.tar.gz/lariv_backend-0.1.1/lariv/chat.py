from channels.generic.websocket import AsyncWebsocketConsumer
import json

class Chat(AsyncWebsocketConsumer):
    def get_allowed_message_types(self):
        return ["button", "load_more", "message"]

    async def receive(self, text_data=None, bytes_data=None):
        if text_data is None:
            return

        data = json.loads(text_data)
        message_type = data.pop("type")
        if message_type not in self.get_allowed_message_types():
            raise ValueError(f"Invalid message type received: {message_type!r}")
        await getattr(self, f"handle_{message_type}")(**data)

