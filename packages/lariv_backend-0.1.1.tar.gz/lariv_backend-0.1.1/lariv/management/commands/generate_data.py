from django.core.management.base import BaseCommand
from lariv.registry import GeneratorRegistry
from lariv.generate_data import generate_data


class Command(BaseCommand):
    help = "Generate sample data. Run all or specific generators."

    def add_arguments(self, parser):
        parser.add_argument(
            "generators",
            nargs="*",
            help="Specific generators to run (e.g., batches.BatchGenerator)",
        )
        parser.add_argument(
            "--list", action="store_true", help="List all available generators"
        )

    def handle(self, *args, **options):
        if options["list"]:
            self.stdout.write("Available generators:")
            for key in GeneratorRegistry.keys():
                gen_cls = GeneratorRegistry.get(key)
                deps = getattr(gen_cls, "dependencies", [])
                dep_str = f" (depends: {', '.join(deps)})" if deps else ""
                self.stdout.write(f"  - {key}{dep_str}")
            return

        if options["generators"]:
            for name in options["generators"]:
                gen_cls = GeneratorRegistry.get(name)
                if gen_cls:
                    self.stdout.write(f"Running {name}...")
                    gen_cls().run()
                    self.stdout.write(self.style.SUCCESS(f"  Done."))
                else:
                    self.stderr.write(self.style.ERROR(f"Generator not found: {name}"))
        else:
            self.stdout.write("Generating all data...")
            generate_data()
            self.stdout.write(self.style.SUCCESS("Data generated successfully!"))
