from django.core.management.base import BaseCommand
from django.db.migrations.autodetector import MigrationAutodetector


class Command(BaseCommand):
    autodetector = MigrationAutodetector
    help = "Overrides the default makemigrations command to do nothing and insult the user."
    requires_system_checks = []

    def handle(self, *args, **options):
        self.stdout.write(self.style.ERROR("Make your own migrations you lazy bum."))
