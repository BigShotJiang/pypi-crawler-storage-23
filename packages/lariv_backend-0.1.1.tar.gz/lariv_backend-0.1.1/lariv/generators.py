from abc import ABC, abstractmethod
from faker import Faker


class BaseGenerator(ABC):
    """Base class for all data generators."""

    name: str = None
    dependencies: list[str] = []

    def __init__(self):
        self.faker = Faker("en_IN")

    def clean(self):
        """Override to delete existing data."""
        pass

    @abstractmethod
    def generate(self):
        """Override to generate sample data."""
        pass

    def run(self):
        """Clean and generate."""
        self.clean()
        self.generate()
