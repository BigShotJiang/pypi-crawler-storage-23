# Detail

::: components.detail
