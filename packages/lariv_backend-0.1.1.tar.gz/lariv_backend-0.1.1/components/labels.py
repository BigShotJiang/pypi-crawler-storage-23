"""
Text label components suitable for displaying read-only data.
"""
from .base import Component


class Label(Component):
    """Base text label component."""
    def __init__(self, title: str, **kwargs):
        super().__init__(**kwargs)
        self.title = title


class InlineLabel(Label):
    """A label rendered inline with its children."""
    def render_html(self, **kwargs):
        return f"""
        <div id="{self.uid}" class="flex gap-2 {self.classes}">
            <span class="text-primary font-bold">
                {self.title}:
            </span>
            {"".join([component.render(**kwargs) for component in self.children])}
        </div>
        """


class NewlineLabel(Label):
    """A label rendered above its children on a new line."""
    def render_html(self, **kwargs):
        return f"""
        <div id="{self.uid}" class="{self.classes}">
            <span class="text-primary font-bold">
                {self.title}:</span>
            <div>{"".join([component.render(**kwargs) for component in self.children])}</div>
        </div>
        """
