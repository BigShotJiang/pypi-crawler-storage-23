"""
Container components for layout structuring.
"""
from .base import Component


class Row(Component):
    """A flexbox row container component."""
    def render_html(self, **kwargs) -> str:
        url = self.get_url(**kwargs)
        if url is None:
            return f'<div id="{self.uid}" class="flex flex-row gap-1 {self.classes}">{"".join([child.render(**kwargs) for child in self.children])}</div>'
        else:
            return f'<a href="{url}" id="{self.uid}" class="gap-1 flex flex-row {self.classes}">{"".join([child.render(**kwargs) for child in self.children])}</a>'


class Column(Component):
    """A flexbox column container component."""
    def render_html(self, **kwargs) -> str:
        url = self.get_url(**kwargs)
        if url is None:
            return f'<div id="{self.uid}" class="gap-1 flex flex-col {self.classes}">{"".join([child.render(**kwargs) for child in self.children])}</div>'
        else:
            return f'<a href="{url}" id="{self.uid}" class="gap-1 flex flex-col {self.classes}">{"".join([child.render(**kwargs) for child in self.children])}</a>'
