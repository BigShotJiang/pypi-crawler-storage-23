from django.apps import AppConfig


class ComponentsConfig(AppConfig):
    name = "components"
    url_prefix = None
