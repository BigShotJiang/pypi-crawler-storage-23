#[derive(Debug, Clone, PartialEq, Copy)]
pub enum UCTObservability {
    Confirmed,
    Possible,
    Unavailable,
}
