import xyzrender


def test_import():
    assert xyzrender is not None
