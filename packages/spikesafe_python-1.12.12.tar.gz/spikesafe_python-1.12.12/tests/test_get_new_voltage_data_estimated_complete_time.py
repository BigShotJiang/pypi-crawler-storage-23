import pytest
from spikesafe_python.DigitizerDataFetch import DigitizerDataFetch

@pytest.mark.parametrize(
    "aperture_microseconds, reading_count, hardware_trigger_count, hardware_trigger_delay_microseconds, expected",
    [
        # 488us aperture, 1 reading, 1 hardware trigger, 200us delay
        (488, 1, 1, 200, 0.000688),        
        # 500us aperture, 1 reading, 1 hardware trigger, 150us delay
        (500, 1, 1, 150, 0.00065),
        # 694us aperture, 1 reading, 1 hardware trigger, 0us delay
        (694, 1, 1, 0, 0.000694),
        # 25ms aperture, 1 reading, 1 hardware trigger, 3ms delay
        (25000, 1, 1, 3000, 0.028),
    ]
)
def test_get_new_voltage_data_estimated_complete_time(
    aperture_microseconds, reading_count, hardware_trigger_count, hardware_trigger_delay_microseconds, expected
):
    result = DigitizerDataFetch.get_new_voltage_data_estimated_complete_time(
        aperture_microseconds,
        reading_count,
        hardware_trigger_count,
        hardware_trigger_delay_microseconds
    )
    assert pytest.approx(result, rel=1e-6) == expected
