import time
from .SpikeSafeInfo import SpikeSafeInfo
from .TcpSocket import TcpSocket
from .Threading import wait

class Discharge:
    """
    Class for calculating SpikeSafe channel discharge time based on compliance voltage.

    Methods
    -------
    get_spikesafe_channel_discharge_time(compliance_voltage: float) -> float
        Returns the time in seconds to fully discharge the SpikeSafe channel based on the compliance voltage
    wait_for_spikesafe_channel_discharge(spike_safe_socket: TcpSocket, spikesafe_info: SpikeSafeInfo, compliance_voltage: float, channel_number: int = 1, enable_logging: bool | None = None) -> None
        Automatically waits for the SpikeSafe channel to fully discharge based on SpikeSafe capabilities.
        If the SpikeSafe supports the Discharge Complete query, it will poll the channel until discharge is complete.
        If not, it will wait for a calculated time based on the compliance voltage.
    """

    @staticmethod
    def get_spikesafe_channel_discharge_time(compliance_voltage: float) -> float:
        """
        Returns the time in seconds to fully discharge the SpikeSafe channel based on the compliance voltage

        Parameters
        ----------
        compliance_voltage : float
            Compliance voltage to factor in discharge time
        
        Returns
        -------
        float
            Discharge time in seconds

        Raises
        ------
        None
        """
        # Discharge time accounting for compliance voltage, voltage readroom, and discharge voltage per second
        voltage_headroom_voltage = 7
        discharge_voltage_per_second = 1000
        discharge_time = (compliance_voltage + voltage_headroom_voltage) / discharge_voltage_per_second
        return discharge_time

    @staticmethod
    def wait_for_spikesafe_channel_discharge(
        spikesafe_socket: TcpSocket,
        spikesafe_info: SpikeSafeInfo,
        compliance_voltage: float,
        channel_number: int = 1,
        enable_logging: bool | None = None
    ) -> None:
        """
        Automatically waits for the SpikeSafe channel to fully discharge based on SpikeSafe capabilities.
        If the SpikeSafe supports the Discharge Complete query, it will poll the channel until discharge is complete.
        If not, it will wait for a calculated time based on the compliance voltage.

        Parameters
        ----------
        spikesafe_socket : TcpSocket
            Socket object used to communicate with SpikeSafe.
        spikesafe_info : SpikeSafeInfo
            An object containing the SpikeSafe information.
        compliance_voltage : float
            Compliance voltage to factor in discharge time.
        channel_number : int, optional
            Channel number to wait for discharge. By default, this is 1.
        enable_logging : bool, optional
            Overrides spikesafe_socket.enable_logging attribute (default to None will use spikesafe_socket.enable_logging value).

        Raises
        ------
        TimeoutError
            Thrown when the wait times out.
        Exception
            On any error.
        """
        if spikesafe_info.supports_discharge_query:
            # when Discharge Complete query is supported, query for completion
            start_time = time.time()
            expected_max_discharge_time = Discharge.get_spikesafe_channel_discharge_time(spikesafe_info.maximum_compliance_voltage + 35) # 35V gives extra time, some windows pcs return early from wait function

            # wait until the channel is fully discharged before disconnecting the load
            is_discharge_complete = ""
            while is_discharge_complete != "TRUE":
                spikesafe_socket.send_scpi_command(f"OUTP{channel_number}:DISC:COMP?", enable_logging)
                is_discharge_complete = spikesafe_socket.read_data(enable_logging)

                elapsed_seconds = time.time() - start_time
                if elapsed_seconds > expected_max_discharge_time:
                    raise TimeoutError(f"SpikeSafe channel discharge exceeded expected maximum time of {expected_max_discharge_time} seconds")
        else:
            # when Discharge Complete query is not supported, use a calculated wait time
            wait_time = Discharge.get_spikesafe_channel_discharge_time(compliance_voltage + 35) # 35V gives extra time, some windows pcs return early from wait function
            wait(wait_time)

def get_spikesafe_channel_discharge_time(compliance_voltage: float) -> float:
    """
    Obsolete: use Discharge.get_spikesafe_channel_discharge_time instead
    """
    return Discharge.get_spikesafe_channel_discharge_time(compliance_voltage)