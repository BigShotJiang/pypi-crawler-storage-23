import datetime
from pathlib import Path
from libfelix.rename_scans import parse_date_str, rename_path


def test_parse_date_str():
    assert parse_date_str('16 Sept. 25') == datetime.datetime(2025, 9, 16)
    assert parse_date_str('01 Dez. 25') == datetime.datetime(2025, 12, 1)
    assert parse_date_str('01 März 26') == datetime.datetime(2026, 3, 1)


def test_rename_path():
    input_path = Path('Scan 16 Sept. 25 20·36·09.pdf')
    assert rename_path(input_path) == Path('2025-09-16.pdf')
    assert rename_path(Path('other.pdf')) is None
    assert rename_path(Path('Scan 01 März 26 06·48·07.pdf')) == Path(
        '2026-03-01.pdf'
    )
