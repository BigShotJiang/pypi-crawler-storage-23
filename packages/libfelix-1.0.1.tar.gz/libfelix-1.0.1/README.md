# libfelix
Felix' library of snippets.

- few dependencies
- keep it simple


## Installation
```
pip install libfelix
pip install libfelix[full]
```

[^full]: `libfelix[full]` is required for this feature


## libfelix.git
```python
>>> from libfelix.git import Repo
>>> r = Repo('.')
>>> r.head
'9e260ece8558ba9a6c4ad6a9c89905630fe0140b'
```


## libfelix.music [^full]
Controls music players via dbus (`org.mpris.MediaPlayer2.Player`) and scores them based on a simple heuristic (see
`score_players` in `libfelix/music/api.py`).
```
$ music --help
Usage: music [OPTIONS] COMMAND [ARGS]...

Options:
  --help  Show this message and exit.

Commands:
  Next
  PlayPause
  Previous
  players
```


## libfelix.logging
Opinionated settings for Structlog:

- log to STDERR
- configure the log level by setting the environment variable `LOGLEVEL`

```python
from libfelix.logging import configure_structlog_console_from_env, get_logger

configure_structlog_console_from_env()
log = get_logger()
log.info('...')
```


## libfelix.rename_scans [^full]
Renames scanned PDFs (from the M365 Android app and shared via [KDE Connect](https://kdeconnect.kde.org/)) in a directory to a sane format.
```bash
felix-kdeconnect-rename-scans ~/Downloads/kdeconnect/
```


## Development
```
mise trust
mise install
pre-commit install -f
uv sync --all-extras
```
