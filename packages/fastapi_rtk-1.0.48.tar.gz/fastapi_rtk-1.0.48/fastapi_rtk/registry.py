import typing


class APIRouteMetadata(typing.TypedDict):
    urls: list[dict[str, typing.Any]]
    dependencies: list[
        tuple[typing.Callable[..., typing.Any], dict[str, typing.Any] | None]
    ]
    permission_name: str | None
    priority: int | None
    response_model_str: str | None


class APIRouteRegistry:
    """
    Singleton registry for storing API route metadata, including URLs, dependencies, permissions, and response models.
    """

    route_map = dict[tuple[int, int] | int, APIRouteMetadata]()

    @classmethod
    def get_route_metadata(cls, func: typing.Callable[..., typing.Any]):
        func_id = cls._get_id(func)
        # Fallback to function id if the function is a bound method of a class and the combined id is not found
        return cls.route_map.get(func_id) or (
            cls.route_map.get(func_id[0]) if isinstance(func_id, tuple) else None
        )

    @classmethod
    def add_permission_name(
        cls, func: typing.Callable[..., typing.Any], permission_name: str
    ):
        func_id = cls._get_id(func)
        cls._ensure_route(func_id)
        cls.route_map[func_id]["permission_name"] = permission_name

    @classmethod
    def add_urls(
        cls, func: typing.Callable[..., typing.Any], *urls: dict[str, typing.Any]
    ):
        func_id = cls._get_id(func)
        cls._ensure_route(func_id)
        if "urls" not in cls.route_map[func_id]:
            cls.route_map[func_id]["urls"] = []
        cls.route_map[func_id]["urls"].extend(urls)

    @classmethod
    def add_dependencies(
        cls,
        func: typing.Callable[..., typing.Any],
        *dependencies: tuple[
            typing.Callable[..., typing.Any], dict[str, typing.Any] | None
        ],
    ):
        func_id = cls._get_id(func)
        cls._ensure_route(func_id)
        if "dependencies" not in cls.route_map[func_id]:
            cls.route_map[func_id]["dependencies"] = []
        cls.route_map[func_id]["dependencies"].extend(dependencies)

    @classmethod
    def add_priority(cls, func: typing.Callable[..., typing.Any], priority: int):
        func_id = cls._get_id(func)
        cls._ensure_route(func_id)
        cls.route_map[func_id]["priority"] = priority

    @classmethod
    def add_response_model_str(
        cls, func: typing.Callable[..., typing.Any], response_model_str: str
    ):
        func_id = cls._get_id(func)
        cls._ensure_route(func_id)
        cls.route_map[func_id]["response_model_str"] = response_model_str

    @classmethod
    def _get_id(cls, func: typing.Callable[..., typing.Any]):
        # If it is a bound method of a class, combine the id of the function and the class to ensure uniqueness
        if hasattr(func, "__func__") and hasattr(func, "__self__"):
            return (id(func.__func__), id(func.__self__))
        return id(func)

    @classmethod
    def _ensure_route(
        cls, func_id_or_func: tuple[int, int] | int | typing.Callable[..., typing.Any]
    ):
        func_id = (
            cls._get_id(func_id_or_func)
            if callable(func_id_or_func)
            else func_id_or_func
        )
        if func_id not in cls.route_map:
            cls.route_map[func_id] = APIRouteMetadata()
