from __future__ import annotations

from typing import TYPE_CHECKING

from click import Command, command
from utilities.click import CONTEXT_SETTINGS
from utilities.core import is_pytest, set_up_logging, to_logger
from utilities.subprocess import run

from restic import __version__
from restic._click import (
    password_file_option,
    password_option,
    print_option,
    repo_argument,
)
from restic._constants import RESTIC_PASSWORD, RESTIC_PASSWORD_FILE
from restic._utilities import yield_password

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.types import PathLike, SecretLike

    from restic._repo import Repo


_LOGGER = to_logger(__name__)


def init(
    repo: Repo,
    /,
    *,
    password: SecretLike | None = RESTIC_PASSWORD,
    password_file: PathLike | None = RESTIC_PASSWORD_FILE,
    print: bool = True,  # noqa: A002
) -> None:
    """Initialize a new repository."""
    _LOGGER.info("Initializing %s...", repo)
    with (
        repo.yield_env(),
        yield_password(password=password, password_file=password_file),
    ):
        run("restic", "init", print=print)
    _LOGGER.info("Finished initializing %s", repo)


##


def make_init_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @repo_argument
    @password_option
    @password_file_option
    @print_option
    def func(
        *,
        repo: Repo,
        password: SecretLike | None,
        password_file: PathLike | None,
        print: bool,  # noqa: A002
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        init(repo, password=password, password_file=password_file, print=print)

    return cli(name=name, help="Initialize a new repository", **CONTEXT_SETTINGS)(func)


__all__ = ["init", "make_init_cmd"]
