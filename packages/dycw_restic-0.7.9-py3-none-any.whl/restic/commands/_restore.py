from __future__ import annotations

from typing import TYPE_CHECKING

from click import Command, command
from utilities.click import CONTEXT_SETTINGS, ListStrs, Path, Str, argument, option
from utilities.core import TemporaryDirectory, is_pytest, one, set_up_logging, to_logger
from utilities.subprocess import cp, run
from utilities.types import MaybeSequenceStr, PathLike, SecretLike

from restic import __version__
from restic._click import (
    dry_run_option,
    exclude_i_option,
    exclude_option,
    include_i_option,
    include_option,
    password_file_option,
    password_option,
    print_option,
    repo_argument,
)
from restic._constants import LATEST, RESTIC_PASSWORD, RESTIC_PASSWORD_FILE
from restic._repo import Repo
from restic._utilities import (
    expand_bool,
    expand_dry_run,
    expand_exclude,
    expand_exclude_i,
    expand_include,
    expand_include_i,
    expand_tag,
    expand_target,
    yield_password,
)
from restic.commands._snapshots import snapshots

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.types import MaybeSequenceStr, PathLike, SecretLike

    from restic._repo import Repo


_LOGGER = to_logger(__name__)


##


def restore(
    repo: Repo,
    target: PathLike,
    /,
    *,
    password: SecretLike | None = RESTIC_PASSWORD,
    password_file: PathLike | None = RESTIC_PASSWORD_FILE,
    delete: bool = False,
    dry_run: bool = False,
    exclude: MaybeSequenceStr | None = None,
    exclude_i: MaybeSequenceStr | None = None,
    include: MaybeSequenceStr | None = None,
    include_i: MaybeSequenceStr | None = None,
    tag: MaybeSequenceStr | None = None,
    snapshot: str = LATEST,
    print: bool = True,  # noqa: A002
) -> None:
    """Extract the data from a snapshot from the repository to a directory."""
    _LOGGER.info("Restoring snapshot %s of %s to %r...", snapshot, repo, str(target))
    with (
        repo.yield_env(),
        yield_password(password=password, password_file=password_file),
        TemporaryDirectory() as temp,
    ):
        run(
            "restic",
            "restore",
            *expand_bool("delete", bool_=delete),
            *expand_dry_run(dry_run=dry_run),
            *expand_exclude(exclude=exclude),
            *expand_exclude_i(exclude_i=exclude_i),
            *expand_include(include=include),
            *expand_include_i(include_i=include_i),
            *expand_tag(tag=tag),
            *expand_target(temp),
            "--verify",
            snapshot,
            print=print,
        )
        snaps = snapshots(
            repo,
            password=password,
            password_file=password_file,
            return_=True,
            print=False,
        )
        path = one(snaps[-1].paths)
        src = temp / path.relative_to(path.anchor)
        cp(src, target)
    _LOGGER.info(
        "Finished restoring snapshot %s of %s to %r", snapshot, repo, str(target)
    )


##


def make_restore_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @repo_argument
    @argument("target", type=Path(exist=False))
    @password_option
    @password_file_option
    @option(
        "--delete",
        is_flag=True,
        default=False,
        help="Delete files from target directory if they do not exist in snapshot",
    )
    @dry_run_option
    @exclude_option
    @exclude_i_option
    @include_option
    @include_i_option
    @option(
        "--tag",
        type=ListStrs(),
        default=None,
        help='Only consider snapshots including `tag[,tag,...]`, when snapshot ID "latest" is given',
    )
    @option("--snapshot", type=Str(), default=LATEST, help="Snapshot ID to restore")
    @print_option
    def func(
        *,
        repo: Repo,
        target: PathLike,
        password: SecretLike | None,
        password_file: PathLike | None,
        delete: bool,
        dry_run: bool,
        exclude: MaybeSequenceStr | None,
        exclude_i: MaybeSequenceStr | None,
        include: MaybeSequenceStr | None,
        include_i: MaybeSequenceStr | None,
        tag: MaybeSequenceStr | None,
        snapshot: str,
        print: bool,  # noqa: A002
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        restore(
            repo,
            target,
            password=password,
            password_file=password_file,
            delete=delete,
            dry_run=dry_run,
            exclude=exclude,
            exclude_i=exclude_i,
            include=include,
            include_i=include_i,
            tag=tag,
            snapshot=snapshot,
            print=print,
        )

    return cli(name=name, help="Extract data from a snapshot", **CONTEXT_SETTINGS)(func)


__all__ = ["make_restore_cmd", "restore"]
