# kernel/journals/__init__.py

from .observation_long import ObservationLongEvent, ObservationLongJournal
