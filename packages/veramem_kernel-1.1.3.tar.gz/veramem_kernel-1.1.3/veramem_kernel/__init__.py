# veramem_kernel/__init__.py

__version__ = "1.0.2"

# Public API namespace
from . import api

__all__ = [
    "__version__",
    "api",
]
