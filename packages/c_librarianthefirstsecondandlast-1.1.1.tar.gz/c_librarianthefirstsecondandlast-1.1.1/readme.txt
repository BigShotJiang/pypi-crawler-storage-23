Changelog

1.1.0

-Added truncation of decimals.
-Added text wrapping of text through popup_text
-Added cull_whitespace. A function that removes whitespace within an image.
-Added the ability to rotate a point about a separate point.