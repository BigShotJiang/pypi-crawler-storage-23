"""
verity.errors — Structured error hierarchy

Catch by type:

    try:
        await client.protect(...)
    except LeaseConflictError:
        ...
    except CommitUncertainError as e:
        print(e.result)  # the action DID happen
    except VerityError:
        ...  # catch-all for any Verity SDK error
"""

from __future__ import annotations

from typing import Any


class VerityError(Exception):
    """Base for all Verity SDK errors."""


class VerityApiError(VerityError):
    """The Verity API returned a non-2xx status code.

    Inspect ``.status_code`` and ``.body`` for details.
    """

    def __init__(
        self, status_code: int, body: Any, request_id: str | None = None
    ) -> None:
        self.status_code = status_code
        self.body = body
        self.request_id = request_id
        id_str = f" [{request_id}]" if request_id else ""
        super().__init__(f"Verity API error {status_code}{id_str}: {body}")


class VerityConfigError(VerityError):
    """SDK was called without a required configuration value."""


class VerityValidationError(VerityError):
    """A value passed to the SDK failed validation (non-serializable, too large, etc.)."""


class LeaseConflictError(VerityError):
    """HTTP 409 — another agent currently holds the lease for this effect.

    Raised when ``on_conflict='throw'`` or all retry attempts are exhausted.
    """

    def __init__(self, body: Any, effect_key: str) -> None:
        self.body = body
        self.effect_key = effect_key
        super().__init__(
            f'Effect "{effect_key}" is currently being processed by another agent'
        )


class EffectPreviouslyFailedError(VerityError):
    """The effect already FAILED on a prior attempt — admin must reset before retry.

    Inspect ``.cached_error`` for the original failure details.
    """

    def __init__(
        self, cached_error: Any, effect_key: str, effect_id: str | None = None
    ) -> None:
        self.cached_error = cached_error
        self.effect_key = effect_key
        self.effect_id = effect_id
        super().__init__(
            f'Effect "{effect_key}" previously failed — reset required before retry'
        )


class CommitUncertainError(VerityError):
    """The action was executed by ``act()``, but Verity could not confirm the commit.

    **CRITICAL**: The side effect happened. Do NOT blindly retry.
    Check the Explorer UI or query API to reconcile.

    Attributes:
        result: The value that ``act()`` returned successfully.
        commit_error: The error that prevented the commit from being recorded.
    """

    def __init__(self, effect_key: str, result: Any, commit_error: Any) -> None:
        self.effect_key = effect_key
        self.result = result
        self.commit_error = commit_error
        super().__init__(
            f'Action succeeded for "{effect_key}" but commit could not be confirmed. '
            f"DO NOT RETRY — check the Explorer UI or query API to reconcile."
        )

