"""
verity.types — Type definitions for the Verity SDK

Dataclasses mirroring the backend API contracts.
Zero dependencies beyond the standard library.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, Union, runtime_checkable


# =============================================================================
# Configuration
# =============================================================================


@dataclass
class ConflictRetryConfig:
    """Retry behaviour when another agent holds the lease (HTTP 409)."""

    enabled: bool = True
    """Enable automatic retry on 409 Conflict."""

    max_attempts: int = 12
    """Maximum number of retry attempts."""

    initial_delay_s: float = 0.5
    """Initial delay between retries in seconds."""

    max_delay_s: float = 15.0
    """Maximum delay between retries in seconds."""

    jitter: bool = True
    """Add random jitter ±30% to delays to avoid thundering herd."""


# =============================================================================
# Logging protocol
# =============================================================================


@runtime_checkable
class VerityLogger(Protocol):
    """Logger interface accepted by VerityClient.

    Only ``warn`` and ``error`` are required. ``debug`` and ``info`` are optional.
    """

    def warn(self, message: str, *args: Any) -> None: ...
    def error(self, message: str, *args: Any) -> None: ...


class FullVerityLogger(VerityLogger, Protocol):
    """Extended logger with optional debug/info methods."""

    def debug(self, message: str, *args: Any) -> None: ...
    def info(self, message: str, *args: Any) -> None: ...


# =============================================================================
# API Responses
# =============================================================================


@dataclass
class LeaseGrantedResponse:
    """Lease was acquired — proceed to observe/act."""

    status: Literal["granted"]
    effect_id: str
    effect_key: str
    fence_token: int
    lease_token: str
    lease_expires_at: str
    prior_state: Literal["none", "expired", "reset"]


@dataclass
class LeaseCachedResponse:
    """Effect already reached a terminal state — cached result returned."""

    status: Literal["cached_completed", "cached_failed"]
    effect_id: str
    effect_key: str
    fence_token: int
    lease_token: None = None
    cached_result: Any = None
    cached_error: Any = None


LeaseResponse = Union[LeaseGrantedResponse, LeaseCachedResponse]


@dataclass
class CommitResponse:
    """Server acknowledged the commit."""

    status: Literal["accepted", "already_committed"]
    effect_id: str
    fence_token: int
    message: str


@dataclass
class FailResponse:
    """Server recorded the failure."""

    status: Literal["recorded", "already_failed"]
    effect_id: str
    fence_token: int
    message: str


@dataclass
class RenewResponse:
    """Lease was renewed with a new expiry."""

    status: Literal["renewed"]
    lease_expires_at: str


# =============================================================================
# Request body types (for low-level API — mirrors TypeScript SDK)
# =============================================================================


@dataclass
class LeaseRequestBody:
    """Request body for ``request_lease()``."""

    effect_key: str
    effect_name: str | None = None
    agent_id: str | None = None
    lease_duration_ms: int | None = None
    input_json: Any = None
    workflow_name: str | None = None
    case_id: str | None = None
    run_id: str | None = None

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to camelCase dict for the API."""
        d: dict[str, Any] = {"effectKey": self.effect_key}
        if self.effect_name is not None:
            d["effectName"] = self.effect_name
        if self.agent_id is not None:
            d["agentId"] = self.agent_id
        if self.lease_duration_ms is not None:
            d["leaseDurationMs"] = self.lease_duration_ms
        if self.input_json is not None:
            d["inputJson"] = self.input_json
        if self.workflow_name is not None:
            d["workflowName"] = self.workflow_name
        if self.case_id is not None:
            d["caseId"] = self.case_id
        if self.run_id is not None:
            d["runId"] = self.run_id
        return d


@dataclass
class CommitRequestBody:
    """Request body for ``commit()``."""

    effect_key: str
    fence_token: int
    lease_token: str
    result: Any
    source: Literal["observed", "acted"] | None = None
    run_id: str | None = None

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to camelCase dict for the API."""
        d: dict[str, Any] = {
            "effectKey": self.effect_key,
            "fenceToken": self.fence_token,
            "leaseToken": self.lease_token,
            "result": self.result,
        }
        if self.source is not None:
            d["source"] = self.source
        if self.run_id is not None:
            d["runId"] = self.run_id
        return d


@dataclass
class FailRequestBody:
    """Request body for ``fail()``."""

    effect_key: str
    fence_token: int
    lease_token: str
    error: Any
    source: Literal["acted"] | None = None
    run_id: str | None = None

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to camelCase dict for the API."""
        d: dict[str, Any] = {
            "effectKey": self.effect_key,
            "fenceToken": self.fence_token,
            "leaseToken": self.lease_token,
            "error": self.error,
        }
        if self.source is not None:
            d["source"] = self.source
        if self.run_id is not None:
            d["runId"] = self.run_id
        return d


@dataclass
class RenewRequestBody:
    """Request body for ``renew()``."""

    effect_key: str
    fence_token: int
    lease_token: str
    extension_ms: int | None = None

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to camelCase dict for the API."""
        d: dict[str, Any] = {
            "effectKey": self.effect_key,
            "fenceToken": self.fence_token,
            "leaseToken": self.lease_token,
        }
        if self.extension_ms is not None:
            d["extensionMs"] = self.extension_ms
        return d


@dataclass
class ReportObserveBody:
    """Request body for ``report_observe()``."""

    effect_key: str
    fence_token: int
    lease_token: str
    hit: bool
    duration_ms: int | None = None

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to camelCase dict for the API."""
        d: dict[str, Any] = {
            "effectKey": self.effect_key,
            "fenceToken": self.fence_token,
            "leaseToken": self.lease_token,
            "hit": self.hit,
        }
        if self.duration_ms is not None:
            d["durationMs"] = self.duration_ms
        return d


# =============================================================================
# Parsing helpers (camelCase JSON → snake_case dataclasses)
# =============================================================================


def parse_lease_response(data: dict[str, Any]) -> LeaseResponse:
    """Parse a lease API response dict into a typed dataclass."""
    status = data["status"]
    if status == "granted":
        return LeaseGrantedResponse(
            status=status,
            effect_id=data["effectId"],
            effect_key=data["effectKey"],
            fence_token=data["fenceToken"],
            lease_token=data["leaseToken"],
            lease_expires_at=data["leaseExpiresAt"],
            prior_state=data["priorState"],
        )
    return LeaseCachedResponse(
        status=status,
        effect_id=data["effectId"],
        effect_key=data["effectKey"],
        fence_token=data["fenceToken"],
        lease_token=None,
        cached_result=data.get("cachedResult"),
        cached_error=data.get("cachedError"),
    )


def parse_commit_response(data: dict[str, Any]) -> CommitResponse:
    """Parse a commit API response dict into a typed dataclass."""
    return CommitResponse(
        status=data["status"],
        effect_id=data["effectId"],
        fence_token=data["fenceToken"],
        message=data["message"],
    )


def parse_fail_response(data: dict[str, Any]) -> FailResponse:
    """Parse a fail API response dict into a typed dataclass."""
    return FailResponse(
        status=data["status"],
        effect_id=data["effectId"],
        fence_token=data["fenceToken"],
        message=data["message"],
    )


def parse_renew_response(data: dict[str, Any]) -> RenewResponse:
    """Parse a renew API response dict into a typed dataclass."""
    return RenewResponse(
        status=data["status"],
        lease_expires_at=data["leaseExpiresAt"],
    )

