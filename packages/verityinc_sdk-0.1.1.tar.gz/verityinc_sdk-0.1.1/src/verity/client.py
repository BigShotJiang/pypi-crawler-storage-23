"""
verity.client — Main client for the Verity SDK

Two usage patterns::

    # 1. Standalone effect protection
    result = await verity.protect("charge-order-123",
        act=lambda: stripe.charges.create(amount=5000),
    )

    # 2. Workflow-aware (Explorer UI grouping)
    run = verity.workflow("refund_flow").case("order_123").run()
    await run.protect("notify_customer", act=lambda: send_email(...))
    await run.protect("refund_payment", act=lambda: stripe.refunds.create(...))
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import time
import traceback
import uuid
from contextlib import suppress
from typing import Any, Awaitable, Callable, Literal, TypeVar, Union

import httpx

from .errors import (
    CommitUncertainError,
    EffectPreviouslyFailedError,
    LeaseConflictError,
    VerityApiError,
    VerityConfigError,
    VerityValidationError,
)
from .types import (
    CommitResponse,
    ConflictRetryConfig,
    FailResponse,
    LeaseGrantedResponse,
    LeaseCachedResponse,
    LeaseResponse,
    RenewResponse,
    parse_commit_response,
    parse_fail_response,
    parse_lease_response,
    parse_renew_response,
)

T = TypeVar("T")

# =============================================================================
# Defaults
# =============================================================================

_DEFAULT_CONFLICT_RETRY = ConflictRetryConfig()
_DEFAULT_RENEW_AT_FRACTION = 0.65
_MIN_RENEWAL_INTERVAL_S = 3.0
_DEFAULT_REQUEST_TIMEOUT_S = 20.0
_COMMIT_FAIL_RETRY_ATTEMPTS = 3
_COMMIT_FAIL_RETRY_BASE_S = 0.3

# HTTP statuses that mean "your lease is gone" — renewal should stop.
_LEASE_LOST_STATUSES = frozenset({409, 404, 410, 403})

_MAX_JSON_PAYLOAD_BYTES = 65_536
_MAX_ERROR_FIELD_LEN = 8_000

_default_logger = logging.getLogger("verity")


# =============================================================================
# Helpers
# =============================================================================


async def _maybe_await(fn: Callable[[], Any]) -> Any:
    """Call *fn* and await the result if it's a coroutine.

    Allows callers to pass either sync or async callables to ``act`` / ``observe``.
    """
    result = fn()
    if inspect.isawaitable(result):
        return await result
    return result


def _serialize_error(err: BaseException | Any) -> dict[str, Any]:
    """Convert an unknown error into a safe JSON-friendly dict."""
    if isinstance(err, BaseException):
        return {
            "name": type(err).__name__,
            "message": str(err),
            "stack": traceback.format_exception(type(err), err, err.__traceback__),
        }
    if isinstance(err, dict):
        try:
            json.dumps(err)
            return err
        except (TypeError, ValueError):
            return {"message": str(err)}
    return {"message": str(err)}


def _safe_error_payload(err: Any) -> dict[str, Any]:
    """Build a guaranteed-fits-in-64KB error payload. Never raises."""
    try:
        raw = _serialize_error(err)

        # Truncate long fields
        if isinstance(raw.get("message"), str) and len(raw["message"]) > _MAX_ERROR_FIELD_LEN:
            raw["message"] = raw["message"][:_MAX_ERROR_FIELD_LEN] + "…[truncated]"
        stack = raw.get("stack")
        if isinstance(stack, list):
            raw["stack"] = "".join(stack)
        if isinstance(raw.get("stack"), str) and len(raw["stack"]) > _MAX_ERROR_FIELD_LEN:
            raw["stack"] = raw["stack"][:_MAX_ERROR_FIELD_LEN] + "…[truncated]"

        serialized = json.dumps(raw)
        byte_size = len(serialized.encode("utf-8"))
        if byte_size <= _MAX_JSON_PAYLOAD_BYTES:
            return raw

        # Nuclear fallback
        msg = str(raw.get("message", str(err)))[:2_000]
        return {"name": raw.get("name", "Error"), "message": msg + "…[truncated to fit 64KB]"}
    except Exception:
        return {"name": "Error", "message": str(err)[:2_000]}


def _validate_json_payload(value: Any, field_name: str) -> None:
    """Validate that *value* is JSON-serializable and within the 64 KB limit."""
    if value is None:
        return
    try:
        serialized = json.dumps(value)
    except (TypeError, ValueError) as exc:
        raise VerityValidationError(
            f"{field_name} is not JSON-serializable. "
            f"Circular references, sets, and custom objects are not allowed."
        ) from exc
    byte_size = len(serialized.encode("utf-8"))
    if byte_size > _MAX_JSON_PAYLOAD_BYTES:
        raise VerityValidationError(
            f"{field_name} exceeds maximum size of {_MAX_JSON_PAYLOAD_BYTES} bytes "
            f"(got {byte_size} bytes)."
        )


def _is_transient_error(err: BaseException) -> bool:
    """Check if an error is a transient network/server failure worth retrying."""
    # httpx transport errors (DNS, connection refused, etc.)
    if isinstance(err, httpx.TransportError):
        return True
    # 5xx server errors
    if isinstance(err, VerityApiError) and err.status_code >= 500:
        return True
    return False


def _strip_none(d: dict[str, Any]) -> dict[str, Any]:
    """Remove None values from a dict for clean JSON payloads."""
    return {k: v for k, v in d.items() if v is not None}


# =============================================================================
# VerityClient
# =============================================================================


class VerityClient:
    """Async client for the Verity Durable Execution Ledger.

    Args:
        base_url: Verity API base URL (e.g. ``"https://api.yourverity.com/v1"``).
        api_key: API key (agent or org_admin role).
        namespace: Default namespace — used when none is provided per call.
        agent_id: Default agent/worker identifier attached to all requests.
        conflict_retry: Retry behaviour when another agent holds the lease (HTTP 409).
        auto_renew: Automatically renew leases in the background while ``act()`` runs.
        renew_at_fraction: Fraction of lease duration at which renewal fires (0.3–0.9).
        request_timeout_s: Timeout for individual HTTP requests in seconds.
        logger: Custom ``logging.Logger`` instance. Defaults to ``logging.getLogger("verity")``.

    Usage::

        async with VerityClient(base_url="...", api_key="...") as client:
            result = await client.protect("charge-123",
                act=lambda: stripe.charges.create(amount=5000),
            )
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        namespace: str | None = None,
        agent_id: str | None = None,
        conflict_retry: ConflictRetryConfig | None = None,
        auto_renew: bool = True,
        renew_at_fraction: float = _DEFAULT_RENEW_AT_FRACTION,
        request_timeout_s: float = _DEFAULT_REQUEST_TIMEOUT_S,
        logger: logging.Logger | None = None,
    ) -> None:
        if not base_url:
            raise VerityConfigError("base_url is required")
        if not api_key:
            raise VerityConfigError("api_key is required")

        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._default_namespace = namespace
        self._default_agent_id = agent_id
        self._conflict_retry = conflict_retry or _DEFAULT_CONFLICT_RETRY
        self._auto_renew = auto_renew
        self._renew_at_fraction = min(0.9, max(0.3, renew_at_fraction))
        self._request_timeout_s = request_timeout_s
        self._logger = logger or logging.getLogger("verity")
        self._http = httpx.AsyncClient(
            timeout=httpx.Timeout(request_timeout_s),
        )

    async def close(self) -> None:
        """Close the underlying HTTP client. Idempotent."""
        await self._http.aclose()

    async def __aenter__(self) -> VerityClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # =========================================================================
    # High-level API
    # =========================================================================

    def workflow(self, workflow_name: str) -> WorkflowContext:
        """Start a workflow context for multi-effect orchestration.

        Example::

            run = verity.workflow("refund_flow").case("order_123").run()
            await run.protect("notify_customer", act=send_email)
            await run.protect("refund_payment", act=issue_refund)
        """
        return WorkflowContext(self, workflow_name)

    async def protect(
        self,
        effect_key: str,
        *,
        act: Callable[[], Any],
        observe: Callable[[], Any] | None = None,
        namespace: str | None = None,
        effect_name: str | None = None,
        agent_id: str | None = None,
        lease_duration_ms: int | None = None,
        input_json: Any = None,
        key_suffix: str | None = None,
        on_conflict: Literal["retry", "throw"] | None = None,
        on_lease: Callable[[LeaseResponse], None] | None = None,
    ) -> Any:
        """Protect a single, standalone effect.

        Example::

            result = await verity.protect("charge-order-456",
                act=lambda: stripe.charges.create(amount=5000),
            )

        Args:
            effect_key: Unique idempotency key for this effect.
            act: Execute the real-world side effect. Called when the action
                hasn't been performed yet. Can be sync or async.
            observe: Check the external system for an already-completed action.
                Called only when ``prior_state == 'expired'``. Return the result
                if the action already happened, or ``None`` to fall through to
                ``act()``. Can be sync or async.
            namespace: Override the client-level default namespace.
            effect_name: Human-readable effect name for the Explorer UI.
            agent_id: Override the client-level default agent ID.
            lease_duration_ms: Lease duration in ms (5000–120000, default 30000).
            input_json: Input data for debugging/replay (JSON, max 64 KB).
            key_suffix: Appended to effect_key for cardinality within the same name.
            on_conflict: ``'retry'`` (default) or ``'throw'`` on 409.
            on_lease: Called after lease is acquired (for metrics/debugging).
        """
        ns = namespace or self._default_namespace
        if not ns:
            raise VerityConfigError(
                "Namespace is required. Provide it via namespace= or the client-level default."
            )

        resolved_key = f"{effect_key}:{key_suffix}" if key_suffix else effect_key

        return await self._execute_protect(
            namespace=ns,
            effect_key=resolved_key,
            act=act,
            observe=observe,
            lease_params=_strip_none({
                "effectName": effect_name,
                "agentId": agent_id or self._default_agent_id,
                "leaseDurationMs": lease_duration_ms,
                "inputJson": input_json,
            }),
            on_conflict=on_conflict,
            on_lease=on_lease,
        )

    # =========================================================================
    # Low-level API (public — for power users who want manual control)
    # =========================================================================

    async def request_lease(
        self, namespace: str, body: dict[str, Any]
    ) -> LeaseResponse:
        """Request a lease for an effect."""
        return await self._request_lease_raw(namespace, body)

    async def commit(
        self, namespace: str, body: dict[str, Any]
    ) -> CommitResponse:
        """Commit a successful effect result."""
        return parse_commit_response(
            await self._api_call("POST", f"/effects/{namespace}/commit", body)
        )

    async def fail(
        self, namespace: str, body: dict[str, Any]
    ) -> FailResponse:
        """Record an effect failure."""
        return parse_fail_response(
            await self._api_call("POST", f"/effects/{namespace}/fail", body)
        )

    async def renew(
        self, namespace: str, body: dict[str, Any]
    ) -> RenewResponse:
        """Renew an active lease to extend its expiry."""
        return parse_renew_response(
            await self._api_call("POST", f"/effects/{namespace}/renew", body)
        )

    async def report_observe(
        self, namespace: str, body: dict[str, Any]
    ) -> dict[str, Any]:
        """Report the result of an observe() call (audit-only, no state change)."""
        return await self._api_call("POST", f"/effects/{namespace}/report-observe", body)

    # =========================================================================
    # Internal: Core protect logic (also used by RunContext)
    # =========================================================================

    async def _execute_protect(
        self,
        *,
        namespace: str,
        effect_key: str,
        act: Callable[[], Any],
        observe: Callable[[], Any] | None = None,
        lease_params: dict[str, Any],
        on_conflict: Literal["retry", "throw"] | None = None,
        on_lease: Callable[[LeaseResponse], None] | None = None,
    ) -> Any:
        """Core protect logic — shared between standalone and workflow protect."""

        # 0. Validate inputJson before sending
        input_json = lease_params.get("inputJson")
        if input_json is not None:
            _validate_json_payload(input_json, "input_json")

        # 1. Acquire lease (with optional 409 retry)
        lease_body = _strip_none({"effectKey": effect_key, **lease_params})
        lease = await self._request_lease_with_retry(namespace, lease_body, on_conflict)

        # Fire on_lease callback
        if on_lease:
            on_lease(lease)

        # 2. Terminal states → return cached data
        if isinstance(lease, LeaseCachedResponse):
            if lease.status == "cached_completed":
                self._logger.debug('[verity] "%s" already completed — returning cached result', effect_key)
                return lease.cached_result

            if lease.status == "cached_failed":
                raise EffectPreviouslyFailedError(
                    lease.cached_error, effect_key, lease.effect_id
                )

        # 3. Lease granted
        assert isinstance(lease, LeaseGrantedResponse)
        run_id = lease_params.get("runId")

        # Start auto-renewal background task
        renewal_task: asyncio.Task[None] | None = None
        renewal_stop = asyncio.Event()
        if self._auto_renew:
            renewal_task = asyncio.create_task(
                self._renewal_loop(namespace, lease, renewal_stop)
            )

        try:
            # 4. Observe (only for expired leases)
            #
            # expired → prior agent may have acted but crashed before committing
            #           → observe the external system to check
            # reset   → admin explicitly reset a FAILED effect → prior action failed
            #           → skip observe, go straight to act()
            # none    → brand-new effect → act()
            if lease.prior_state == "expired" and observe is not None:
                try:
                    observe_start = time.monotonic()
                    observed = await _maybe_await(observe)
                    observe_duration_ms = int((time.monotonic() - observe_start) * 1000)

                    if observed is not None:
                        # Report observe hit (fire-and-forget)
                        self._fire_and_forget_observe_report(
                            namespace, effect_key, lease, True, observe_duration_ms
                        )
                        # Validate + commit, then stop renewal
                        _validate_json_payload(observed, "observe() result")
                        await self._commit_with_retry(namespace, _strip_none({
                            "effectKey": effect_key,
                            "fenceToken": lease.fence_token,
                            "leaseToken": lease.lease_token,
                            "result": observed,
                            "source": "observed",
                            "runId": run_id,
                        }))
                        self._stop_renewal(renewal_task, renewal_stop)
                        self._logger.debug(
                            '[verity] "%s" observe() found existing result — committed',
                            effect_key,
                        )
                        return observed

                    # Report observe miss (fire-and-forget)
                    self._fire_and_forget_observe_report(
                        namespace, effect_key, lease, False, observe_duration_ms
                    )

                except Exception as observe_err:
                    # observe() is best-effort — if it fails, proceed to act()
                    self._logger.warning(
                        '[verity] observe() threw for "%s", proceeding to act(): %s',
                        effect_key,
                        observe_err,
                    )

            # 5. Execute the real-world action
            result = await _maybe_await(act)

            # 6. Validate result, then commit (with retry), THEN stop renewal
            try:
                _validate_json_payload(result, "result")
            except VerityValidationError as validation_err:
                self._stop_renewal(renewal_task, renewal_stop)
                raise CommitUncertainError(effect_key, result, validation_err) from validation_err

            try:
                await self._commit_with_retry(namespace, _strip_none({
                    "effectKey": effect_key,
                    "fenceToken": lease.fence_token,
                    "leaseToken": lease.lease_token,
                    "result": result,
                    "source": "acted",
                    "runId": run_id,
                }))
            except Exception as commit_err:
                self._stop_renewal(renewal_task, renewal_stop)
                raise CommitUncertainError(effect_key, result, commit_err) from commit_err

            self._stop_renewal(renewal_task, renewal_stop)
            self._logger.debug('[verity] "%s" committed successfully', effect_key)
            return result

        except CommitUncertainError:
            self._stop_renewal(renewal_task, renewal_stop)
            raise

        except Exception as error:
            # 7. Record the failure (with retry)
            safe_err = _safe_error_payload(error)
            try:
                await self._fail_with_retry(namespace, _strip_none({
                    "effectKey": effect_key,
                    "fenceToken": lease.fence_token,
                    "leaseToken": lease.lease_token,
                    "error": safe_err,
                    "source": "acted",
                    "runId": run_id,
                }))
            except Exception as fail_err:
                self._logger.error(
                    '[verity] CRITICAL: Failed to record failure for "%s" after retries. '
                    "Use the Explorer UI or query API to check effect state and reconcile. %s",
                    effect_key,
                    fail_err,
                )
            self._stop_renewal(renewal_task, renewal_stop)
            raise

    # =========================================================================
    # Internal: 409 conflict retry
    # =========================================================================

    async def _request_lease_with_retry(
        self,
        namespace: str,
        body: dict[str, Any],
        on_conflict: Literal["retry", "throw"] | None = None,
    ) -> LeaseResponse:
        should_retry = on_conflict != "throw" and self._conflict_retry.enabled

        if not should_retry:
            return await self._request_lease_raw(namespace, body)

        delay_s = self._conflict_retry.initial_delay_s

        for attempt in range(1, self._conflict_retry.max_attempts + 1):
            try:
                return await self._request_lease_raw(namespace, body)
            except LeaseConflictError:
                if attempt >= self._conflict_retry.max_attempts:
                    raise

                import random

                jitter = (random.random() - 0.5) * 2 * delay_s * 0.3 if self._conflict_retry.jitter else 0
                wait_s = max(0.1, delay_s + jitter)

                self._logger.debug(
                    '[verity] Lease conflict for "%s" — retry %d/%d in %.1fs',
                    body.get("effectKey"),
                    attempt,
                    self._conflict_retry.max_attempts,
                    wait_s,
                )

                await asyncio.sleep(wait_s)
                delay_s = min(delay_s * 2, self._conflict_retry.max_delay_s)

        # Unreachable, but satisfies type checker
        raise LeaseConflictError({}, body.get("effectKey", ""))

    async def _request_lease_raw(
        self, namespace: str, body: dict[str, Any]
    ) -> LeaseResponse:
        response = await self._fetch("POST", f"/effects/{namespace}/lease", body)

        if response.status_code == 409:
            err_body = response.json()
            raise LeaseConflictError(err_body, body.get("effectKey", ""))

        if not (200 <= response.status_code < 300):
            err_body = response.json()
            request_id = err_body.get("requestId") if isinstance(err_body, dict) else None
            raise VerityApiError(response.status_code, err_body, request_id)

        return parse_lease_response(response.json())

    # =========================================================================
    # Internal: Auto lease renewal
    # =========================================================================

    async def _renewal_loop(
        self,
        namespace: str,
        lease: LeaseGrantedResponse,
        stop_event: asyncio.Event,
    ) -> None:
        """Background renewal loop. Runs until stop_event is set or lease is lost."""
        current_expires_at = lease.lease_expires_at

        while not stop_event.is_set():
            delay_s = self._compute_renewal_delay(current_expires_at)
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=delay_s)
                return  # stop_event was set
            except asyncio.TimeoutError:
                pass  # time to renew

            if stop_event.is_set():
                return

            try:
                result = await self.renew(namespace, {
                    "effectKey": lease.effect_key,
                    "fenceToken": lease.fence_token,
                    "leaseToken": lease.lease_token,
                })
                self._logger.debug('[verity] Renewed lease for "%s"', lease.effect_key)
                current_expires_at = result.lease_expires_at
            except VerityApiError as err:
                if err.status_code in _LEASE_LOST_STATUSES:
                    self._logger.warning(
                        '[verity] Lease lost for "%s" (HTTP %d) — stopping renewal.',
                        lease.effect_key,
                        err.status_code,
                    )
                    return
                # Transient error — retry sooner
                self._logger.warning(
                    '[verity] Lease renewal failed for "%s": %s',
                    lease.effect_key,
                    err,
                )
                current_expires_at = self._soon_expiry()
            except Exception as err:
                self._logger.warning(
                    '[verity] Lease renewal failed for "%s": %s',
                    lease.effect_key,
                    err,
                )
                current_expires_at = self._soon_expiry()

    def _compute_renewal_delay(self, expires_at: str) -> float:
        """Compute seconds until the next renewal should fire."""
        from datetime import datetime, timezone

        now = time.time()
        try:
            expires_ts = datetime.fromisoformat(expires_at.replace("Z", "+00:00")).timestamp()
        except (ValueError, AttributeError):
            expires_ts = now + 5.0
        duration_s = max(expires_ts - now, 5.0)
        return max(duration_s * self._renew_at_fraction, _MIN_RENEWAL_INTERVAL_S)

    @staticmethod
    def _soon_expiry() -> str:
        """Return an ISO timestamp a short time from now (for retry-sooner logic)."""
        from datetime import datetime, timezone

        return (
            datetime.fromtimestamp(time.time() + _MIN_RENEWAL_INTERVAL_S * 2, tz=timezone.utc)
            .isoformat()
        )

    @staticmethod
    def _stop_renewal(
        task: asyncio.Task[None] | None, stop_event: asyncio.Event
    ) -> None:
        """Signal the renewal loop to stop and cancel the task."""
        stop_event.set()
        if task is not None and not task.done():
            task.cancel()

    # =========================================================================
    # Internal: Fire-and-forget observe report
    # =========================================================================

    def _fire_and_forget_observe_report(
        self,
        namespace: str,
        effect_key: str,
        lease: LeaseGrantedResponse,
        hit: bool,
        duration_ms: int,
    ) -> None:
        """Report observe() result — fire-and-forget. Never blocks or raises."""
        asyncio.create_task(
            self._safe_report_observe(namespace, effect_key, lease, hit, duration_ms)
        )

    async def _safe_report_observe(
        self,
        namespace: str,
        effect_key: str,
        lease: LeaseGrantedResponse,
        hit: bool,
        duration_ms: int,
    ) -> None:
        try:
            await self.report_observe(namespace, {
                "effectKey": effect_key,
                "fenceToken": lease.fence_token,
                "leaseToken": lease.lease_token,
                "hit": hit,
                "durationMs": duration_ms,
            })
        except Exception as err:
            self._logger.debug(
                '[verity] Failed to report observe() for "%s" (non-blocking): %s',
                effect_key,
                err,
            )

    # =========================================================================
    # Internal: HTTP layer
    # =========================================================================

    async def _api_call(
        self, method: str, path: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        response = await self._fetch(method, path, body)
        if not (200 <= response.status_code < 300):
            err_body = response.json()
            request_id = err_body.get("requestId") if isinstance(err_body, dict) else None
            raise VerityApiError(response.status_code, err_body, request_id)
        return response.json()  # type: ignore[no-any-return]

    async def _fetch(
        self, method: str, path: str, body: dict[str, Any] | None = None
    ) -> httpx.Response:
        headers = {"Authorization": f"Bearer {self._api_key}"}
        return await self._http.request(
            method,
            f"{self._base_url}{path}",
            json=body,
            headers=headers,
        )

    # =========================================================================
    # Internal: Bounded retry for commit/fail (5xx + network errors)
    # =========================================================================

    async def _commit_with_retry(
        self, namespace: str, body: dict[str, Any]
    ) -> CommitResponse:
        return await self._retry_transient(
            lambda: self.commit(namespace, body),
            f'commit "{body.get("effectKey")}"',
        )

    async def _fail_with_retry(
        self, namespace: str, body: dict[str, Any]
    ) -> FailResponse:
        return await self._retry_transient(
            lambda: self.fail(namespace, body),
            f'fail "{body.get("effectKey")}"',
        )

    async def _retry_transient(
        self, fn: Callable[[], Any], label: str
    ) -> Any:
        """Retry on transient errors (network + 5xx). Bounded: 3 attempts."""
        last_err: BaseException | None = None
        for attempt in range(1, _COMMIT_FAIL_RETRY_ATTEMPTS + 1):
            try:
                return await fn()
            except Exception as err:
                last_err = err
                if not _is_transient_error(err) or attempt >= _COMMIT_FAIL_RETRY_ATTEMPTS:
                    raise
                delay_s = _COMMIT_FAIL_RETRY_BASE_S * (2 ** (attempt - 1))
                self._logger.warning(
                    "[verity] Transient error on %s, retry %d/%d in %.1fs: %s",
                    label,
                    attempt,
                    _COMMIT_FAIL_RETRY_ATTEMPTS,
                    delay_s,
                    err,
                )
                await asyncio.sleep(delay_s)
        raise last_err  # type: ignore[misc]  # unreachable but satisfies checker


# =============================================================================
# Workflow builder: workflow() → case() → run() → protect()
# =============================================================================


class WorkflowContext:
    """Binds a client to a workflow name.

    Created via ``verity.workflow("refund_flow")``.
    """

    def __init__(self, client: VerityClient, workflow_name: str) -> None:
        self._client = client
        self._workflow_name = workflow_name

    def case(self, case_id: str) -> CaseContext:
        """Bind to a specific case (customer intent / business entity).

        Example::

            order_case = verity.workflow("refund_flow").case("order_123")
        """
        return CaseContext(self._client, self._workflow_name, case_id)


class CaseContext:
    """Binds a client to a workflow + case.

    Created via ``verity.workflow("refund_flow").case("order_123")``.
    """

    def __init__(
        self, client: VerityClient, workflow_name: str, case_id: str
    ) -> None:
        self._client = client
        self._workflow_name = workflow_name
        self._case_id = case_id

    def run(
        self,
        *,
        run_id: str | None = None,
        namespace: str | None = None,
        lease_duration_ms: int | None = None,
        agent_id: str | None = None,
    ) -> RunContext:
        """Start a run (execution attempt) for this case.

        A case may have multiple runs if earlier runs failed for some effects.

        Example::

            run = verity.workflow("refund_flow").case("order_123").run()
            # or with explicit run ID:
            run = verity.workflow("refund_flow").case("order_123").run(
                run_id="attempt-3"
            )
        """
        resolved_run_id = run_id or f"run_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"
        resolved_namespace = namespace or self._workflow_name
        return RunContext(
            client=self._client,
            workflow_name=self._workflow_name,
            case_id=self._case_id,
            run_id=resolved_run_id,
            namespace=resolved_namespace,
            default_lease_duration_ms=lease_duration_ms,
            agent_id=agent_id,
        )


class RunContext:
    """A single run (execution attempt) of a workflow for a case.

    Created via ``verity.workflow(...).case(...).run()``.

    Each call to ``.protect(effect_name, ...)`` constructs a deterministic
    ``effect_key = "{case_id}:{effect_name}"``. This means:

    - The same effect in different runs maps to the same key.
    - If run_001 completed ``notify_customer``, run_002 gets the cached result.
    """

    def __init__(
        self,
        *,
        client: VerityClient,
        workflow_name: str,
        case_id: str,
        run_id: str,
        namespace: str,
        default_lease_duration_ms: int | None = None,
        agent_id: str | None = None,
    ) -> None:
        self._client = client
        self._workflow_name = workflow_name
        self._case_id = case_id
        self.run_id = run_id
        self._namespace = namespace
        self._default_lease_duration_ms = default_lease_duration_ms
        self._agent_id = agent_id

    async def protect(
        self,
        effect_name: str,
        *,
        act: Callable[[], Any],
        observe: Callable[[], Any] | None = None,
        namespace: str | None = None,
        lease_duration_ms: int | None = None,
        input_json: Any = None,
        key_suffix: str | None = None,
        on_conflict: Literal["retry", "throw"] | None = None,
        on_lease: Callable[[LeaseResponse], None] | None = None,
    ) -> Any:
        """Protect an effect within this workflow run.

        The effect key is automatically derived as ``"{case_id}:{effect_name}"``,
        ensuring idempotency across runs.

        Example::

            result = await run.protect("notify_customer",
                observe=lambda: email_service.check_sent(order_id),
                act=lambda: email_service.send(to=email, template="refund"),
            )

        Args:
            effect_name: Human-readable name (also used to derive effect_key).
            act: Execute the real-world side effect. Can be sync or async.
            observe: Check external system for prior completion. Can be sync or async.
            namespace: Override the run-level namespace for this effect.
            lease_duration_ms: Override lease duration for this effect.
            input_json: Input data for debugging/replay (JSON, max 64 KB).
            key_suffix: Appended to effect_key for cardinality.
            on_conflict: ``'retry'`` (default) or ``'throw'`` on 409.
            on_lease: Called after lease is acquired.
        """
        # effectKey = caseId:effectName[:keySuffix]
        effect_key = (
            f"{self._case_id}:{effect_name}:{key_suffix}"
            if key_suffix
            else f"{self._case_id}:{effect_name}"
        )

        ns = namespace or self._namespace

        return await self._client._execute_protect(
            namespace=ns,
            effect_key=effect_key,
            act=act,
            observe=observe,
            lease_params=_strip_none({
                "effectName": effect_name,
                "agentId": self._agent_id,
                "leaseDurationMs": lease_duration_ms or self._default_lease_duration_ms,
                "inputJson": input_json,
                "workflowName": self._workflow_name,
                "caseId": self._case_id,
                "runId": self.run_id,
            }),
            on_conflict=on_conflict,
            on_lease=on_lease,
        )

