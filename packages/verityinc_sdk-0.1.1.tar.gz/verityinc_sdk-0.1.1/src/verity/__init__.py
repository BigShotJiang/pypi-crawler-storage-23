"""
verity — Python SDK for the Verity Durable Execution Ledger

Exactly-once effect protection for AI agents and autonomous systems.

Quick start::

    from verity import VerityClient

    async with VerityClient(
        base_url="https://api.yourverity.com/v1",
        api_key="vt_live_xxxxxx",
        namespace="payments",
    ) as verity:

        # Standalone effect
        charge = await verity.protect("charge-order-456",
            act=lambda: stripe.charges.create(amount=5000),
        )

        # Workflow-aware (multi-effect)
        run = verity.workflow("refund_flow").case("order_123").run()
        await run.protect("notify_customer", act=lambda: send_email(...))
        await run.protect("refund_payment", act=lambda: stripe.refunds.create(...))
"""

from .client import CaseContext, RunContext, VerityClient, WorkflowContext
from .errors import (
    CommitUncertainError,
    EffectPreviouslyFailedError,
    LeaseConflictError,
    VerityApiError,
    VerityConfigError,
    VerityError,
    VerityValidationError,
)
from .types import (
    CommitRequestBody,
    CommitResponse,
    ConflictRetryConfig,
    FailRequestBody,
    FailResponse,
    LeaseCachedResponse,
    LeaseGrantedResponse,
    LeaseRequestBody,
    LeaseResponse,
    RenewRequestBody,
    RenewResponse,
    ReportObserveBody,
)

__version__ = "0.1.0"

__all__ = [
    # Client + workflow builder
    "VerityClient",
    "WorkflowContext",
    "CaseContext",
    "RunContext",
    # Errors
    "VerityError",
    "VerityApiError",
    "VerityConfigError",
    "VerityValidationError",
    "LeaseConflictError",
    "EffectPreviouslyFailedError",
    "CommitUncertainError",
    # Response types
    "ConflictRetryConfig",
    "LeaseResponse",
    "LeaseGrantedResponse",
    "LeaseCachedResponse",
    "CommitResponse",
    "FailResponse",
    "RenewResponse",
    # Request body types (for low-level API)
    "LeaseRequestBody",
    "CommitRequestBody",
    "FailRequestBody",
    "RenewRequestBody",
    "ReportObserveBody",
]

