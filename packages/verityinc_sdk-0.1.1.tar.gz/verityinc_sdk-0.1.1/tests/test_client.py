"""
verity SDK — Unit tests

Strategy: mock httpx responses using respx to simulate API responses.
No real network calls — pure logic testing.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest
import respx

from verity import (
    CaseContext,
    CommitUncertainError,
    ConflictRetryConfig,
    EffectPreviouslyFailedError,
    LeaseConflictError,
    RunContext,
    VerityApiError,
    VerityClient,
    VerityConfigError,
    VerityValidationError,
    WorkflowContext,
)

BASE_URL = "https://api.test.com/v1"


# =============================================================================
# Test helpers
# =============================================================================


def make_client(**overrides: Any) -> VerityClient:
    """Build a standard VerityClient for tests."""
    defaults = {
        "base_url": BASE_URL,
        "api_key": "test-key",
        "namespace": "test-ns",
        "auto_renew": False,
        "request_timeout_s": 5.0,
    }
    defaults.update(overrides)
    return VerityClient(**defaults)


def granted_lease(**overrides: Any) -> dict[str, Any]:
    """Standard 'granted' lease response."""
    base = {
        "status": "granted",
        "effectId": "eff-123",
        "effectKey": "test-effect",
        "fenceToken": 1,
        "leaseToken": "lease-abc",
        "leaseExpiresAt": "2099-01-01T00:00:00Z",
        "priorState": "none",
    }
    base.update(overrides)
    return base


def cached_completed(result: Any = None) -> dict[str, Any]:
    """Standard 'cached_completed' response."""
    return {
        "status": "cached_completed",
        "effectId": "eff-123",
        "effectKey": "test-effect",
        "fenceToken": 1,
        "leaseToken": None,
        "cachedResult": result if result is not None else {"ok": True},
    }


def cached_failed(error: Any = None) -> dict[str, Any]:
    """Standard 'cached_failed' response."""
    return {
        "status": "cached_failed",
        "effectId": "eff-123",
        "effectKey": "test-effect",
        "fenceToken": 1,
        "leaseToken": None,
        "cachedError": error if error is not None else {"message": "prior failure"},
    }


def commit_ok() -> dict[str, Any]:
    return {"status": "accepted", "effectId": "eff-123", "fenceToken": 1, "message": "ok"}


def fail_ok() -> dict[str, Any]:
    return {"status": "recorded", "effectId": "eff-123", "fenceToken": 1, "message": "ok"}


# =============================================================================
# 1. protect() — happy path + cached states
# =============================================================================


class TestProtectHappyPath:
    @respx.mock
    async def test_acquires_lease_calls_act_commits_and_returns(self):
        client = make_client()
        act_result = {"chargeId": "ch_123", "amount": 5000}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        act = MagicMock(return_value=act_result)
        result = await client.protect("test-effect", act=act)

        assert result == act_result
        act.assert_called_once()

    @respx.mock
    async def test_returns_cached_result_when_already_completed(self):
        client = make_client()
        cached_result = {"chargeId": "ch_old", "amount": 3000}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=cached_completed(cached_result))
        )

        act = MagicMock()
        result = await client.protect("test-effect", act=act)

        assert result == cached_result
        act.assert_not_called()

    @respx.mock
    async def test_raises_previously_failed_error(self):
        client = make_client()
        cached_err = {"message": "card declined"}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=cached_failed(cached_err))
        )

        act = MagicMock()
        with pytest.raises(EffectPreviouslyFailedError):
            await client.protect("test-effect", act=act)

        act.assert_not_called()

    @respx.mock
    async def test_sends_authorization_header(self):
        client = make_client(api_key="my-secret-key")

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect("test-effect", act=lambda: {"ok": True})

        assert lease_route.calls[0].request.headers["authorization"] == "Bearer my-secret-key"

    @respx.mock
    async def test_accepts_async_act_callable(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        async def async_act():
            return {"async": True}

        result = await client.protect("test-effect", act=async_act)
        assert result == {"async": True}


# =============================================================================
# 2. observe() flow
# =============================================================================


class TestObserveFlow:
    @respx.mock
    async def test_calls_observe_when_prior_state_expired(self):
        client = make_client()
        observed_result = {"chargeId": "ch_existing"}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="expired"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/report-observe").mock(
            return_value=httpx.Response(200, json={"status": "recorded"})
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        observe = MagicMock(return_value=observed_result)
        act = MagicMock()

        result = await client.protect("test-effect", act=act, observe=observe)

        assert result == observed_result
        observe.assert_called_once()
        act.assert_not_called()

    @respx.mock
    async def test_falls_through_to_act_when_observe_returns_none(self):
        client = make_client()
        act_result = {"chargeId": "ch_new"}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="expired"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/report-observe").mock(
            return_value=httpx.Response(200, json={"status": "recorded"})
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        observe = MagicMock(return_value=None)
        act = MagicMock(return_value=act_result)

        result = await client.protect("test-effect", act=act, observe=observe)

        assert result == act_result
        observe.assert_called_once()
        act.assert_called_once()

    @respx.mock
    async def test_skips_observe_when_prior_state_none(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="none"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        observe = MagicMock()
        act = MagicMock(return_value={"ok": True})

        await client.protect("test-effect", act=act, observe=observe)

        observe.assert_not_called()
        act.assert_called_once()

    @respx.mock
    async def test_skips_observe_when_prior_state_reset(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="reset"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        observe = MagicMock()
        act = MagicMock(return_value={"ok": True})

        await client.protect("test-effect", act=act, observe=observe)

        observe.assert_not_called()
        act.assert_called_once()

    @respx.mock
    async def test_falls_through_to_act_when_observe_raises(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="expired"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        observe = MagicMock(side_effect=RuntimeError("observe failed"))
        act = MagicMock(return_value={"ok": True})

        result = await client.protect("test-effect", act=act, observe=observe)

        assert result == {"ok": True}
        act.assert_called_once()

    @respx.mock
    async def test_observe_accepts_async_callable(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease(priorState="expired"))
        )
        respx.post(f"{BASE_URL}/effects/test-ns/report-observe").mock(
            return_value=httpx.Response(200, json={"status": "recorded"})
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        async def async_observe():
            return {"found": True}

        act = MagicMock()
        result = await client.protect("test-effect", act=act, observe=async_observe)

        assert result == {"found": True}
        act.assert_not_called()


# =============================================================================
# 3. CommitUncertainError scenarios
# =============================================================================


class TestCommitUncertain:
    @respx.mock
    async def test_raises_when_commit_fails_after_act_succeeds(self):
        client = make_client()
        act_result = {"chargeId": "ch_123"}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        # commit fails 3 times (exhausts retries)
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(500, json={"error": "internal"})
        )

        with pytest.raises(CommitUncertainError) as exc_info:
            await client.protect("test-effect", act=lambda: act_result)

        assert exc_info.value.result == act_result
        assert exc_info.value.effect_key == "test-effect"
        assert isinstance(exc_info.value.commit_error, VerityApiError)

    @respx.mock
    async def test_raises_when_result_too_large(self):
        client = make_client()
        huge_result = {"data": "x" * 70_000}

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )

        with pytest.raises(CommitUncertainError) as exc_info:
            await client.protect("test-effect", act=lambda: huge_result)

        assert exc_info.value.result == huge_result
        assert isinstance(exc_info.value.commit_error, VerityValidationError)

    @respx.mock
    async def test_does_not_call_fail_on_commit_uncertainty(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        commit_route = respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(500, json={"error": "down"})
        )
        fail_route = respx.post(f"{BASE_URL}/effects/test-ns/fail").mock(
            return_value=httpx.Response(200, json=fail_ok())
        )

        with pytest.raises(CommitUncertainError):
            await client.protect("test-effect", act=lambda: {"ok": True})

        # Should have: lease + 3 commit retries. NO fail() calls.
        assert len(lease_route.calls) == 1
        assert len(commit_route.calls) == 3
        assert len(fail_route.calls) == 0


# =============================================================================
# 4. Error / failure path
# =============================================================================


class TestFailurePath:
    @respx.mock
    async def test_calls_fail_and_rethrows_when_act_raises(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        fail_route = respx.post(f"{BASE_URL}/effects/test-ns/fail").mock(
            return_value=httpx.Response(200, json=fail_ok())
        )

        def bad_act():
            raise RuntimeError("Stripe API down")

        with pytest.raises(RuntimeError, match="Stripe API down"):
            await client.protect("test-effect", act=bad_act)

        # Verify fail() was called
        assert len(fail_route.calls) == 1
        fail_body = json.loads(fail_route.calls[0].request.content)
        assert fail_body["error"]["name"] == "RuntimeError"
        assert fail_body["error"]["message"] == "Stripe API down"

    @respx.mock
    async def test_rethrows_original_error_even_when_fail_itself_fails(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        # fail() returns 500 all 3 retries
        respx.post(f"{BASE_URL}/effects/test-ns/fail").mock(
            return_value=httpx.Response(500, json={})
        )

        with pytest.raises(RuntimeError, match="original problem"):
            await client.protect(
                "test-effect", act=lambda: (_ for _ in ()).throw(RuntimeError("original problem"))
            )

    @respx.mock
    async def test_truncates_huge_error_payloads(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        fail_route = respx.post(f"{BASE_URL}/effects/test-ns/fail").mock(
            return_value=httpx.Response(200, json=fail_ok())
        )

        def bad_act():
            raise RuntimeError("x" * 100_000)

        with pytest.raises(RuntimeError):
            await client.protect("test-effect", act=bad_act)

        # fail() was called (not skipped)
        assert len(fail_route.calls) == 1
        fail_body = json.loads(fail_route.calls[0].request.content)
        assert len(fail_body["error"]["message"]) < 10_000


# =============================================================================
# 5. 409 conflict retry
# =============================================================================


class TestConflictRetry:
    @respx.mock
    async def test_retries_on_409_and_succeeds(self):
        client = make_client(
            conflict_retry=ConflictRetryConfig(
                enabled=True, max_attempts=3, initial_delay_s=0.01, jitter=False
            )
        )

        call_count = 0

        def lease_side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(409, json={"error": "conflict"})
            return httpx.Response(200, json=granted_lease())

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(side_effect=lease_side_effect)
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        result = await client.protect("test-effect", act=lambda: {"ok": True})
        assert result == {"ok": True}
        assert call_count == 2

    @respx.mock
    async def test_raises_after_exhausting_retries(self):
        client = make_client(
            conflict_retry=ConflictRetryConfig(
                enabled=True, max_attempts=2, initial_delay_s=0.01, jitter=False
            )
        )

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(409, json={"error": "conflict"})
        )

        with pytest.raises(LeaseConflictError):
            await client.protect("test-effect", act=lambda: {"ok": True})

    @respx.mock
    async def test_throws_immediately_on_conflict_when_configured(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(409, json={"error": "conflict"})
        )

        with pytest.raises(LeaseConflictError):
            await client.protect("test-effect", act=lambda: {}, on_conflict="throw")

        assert len(lease_route.calls) == 1  # no retries

    @respx.mock
    async def test_throws_non_conflict_errors_immediately(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(400, json={"error": "bad request"})
        )

        with pytest.raises(VerityApiError):
            await client.protect("test-effect", act=lambda: {})

        assert len(lease_route.calls) == 1


# =============================================================================
# 6. Auto lease renewal
# =============================================================================


class TestAutoRenewal:
    @respx.mock
    async def test_renews_lease_before_expiry(self):
        # Use a very short lease so renewal fires quickly
        lease_expires_at = (
            __import__("datetime")
            .datetime.fromtimestamp(time.time() + 2, tz=__import__("datetime").timezone.utc)
            .isoformat()
        )
        client = make_client(auto_renew=True, renew_at_fraction=0.3)

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(
                200, json=granted_lease(leaseExpiresAt=lease_expires_at)
            )
        )
        renew_route = respx.post(f"{BASE_URL}/effects/test-ns/renew").mock(
            return_value=httpx.Response(200, json={
                "status": "renewed",
                "leaseExpiresAt": "2099-01-01T00:00:00Z",
            })
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        async def slow_act():
            await asyncio.sleep(4)  # longer than the lease
            return {"done": True}

        result = await client.protect("test-effect", act=slow_act)

        assert result == {"done": True}
        assert len(renew_route.calls) >= 1

    @respx.mock
    async def test_does_not_renew_when_disabled(self):
        client = make_client(auto_renew=False)

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        renew_route = respx.post(f"{BASE_URL}/effects/test-ns/renew").mock(
            return_value=httpx.Response(200, json={
                "status": "renewed",
                "leaseExpiresAt": "2099-01-01T00:00:00Z",
            })
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect("test-effect", act=lambda: {"ok": True})

        assert len(renew_route.calls) == 0


# =============================================================================
# 7. Validation
# =============================================================================


class TestValidation:
    @respx.mock
    async def test_rejects_non_serializable_input_json(self):
        client = make_client()

        with pytest.raises(VerityValidationError):
            await client.protect(
                "test-effect", act=lambda: {}, input_json={1, 2, 3}  # sets aren't JSON
            )

    @respx.mock
    async def test_rejects_input_json_exceeding_64kb(self):
        client = make_client()

        with pytest.raises(VerityValidationError):
            await client.protect(
                "test-effect", act=lambda: {}, input_json={"data": "x" * 70_000}
            )

    @respx.mock
    async def test_allows_none_input_json(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect("test-effect", act=lambda: {"ok": True}, input_json=None)


# =============================================================================
# 8. Workflow builder + key construction
# =============================================================================


class TestWorkflowBuilder:
    @respx.mock
    async def test_constructs_effect_key_as_case_id_colon_effect_name(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/refund_flow/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/refund_flow/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        run = client.workflow("refund_flow").case("order_123").run()
        await run.protect("notify_customer", act=lambda: {"sent": True})

        lease_body = json.loads(lease_route.calls[0].request.content)
        assert lease_body["effectKey"] == "order_123:notify_customer"
        assert lease_body["workflowName"] == "refund_flow"
        assert lease_body["caseId"] == "order_123"
        assert "runId" in lease_body

    @respx.mock
    async def test_appends_key_suffix(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/notifications/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/notifications/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        run = client.workflow("notifications").case("order_456").run()
        await run.protect(
            "email.send", act=lambda: {"ok": True}, key_suffix="alice@example.com"
        )

        lease_body = json.loads(lease_route.calls[0].request.content)
        assert lease_body["effectKey"] == "order_456:email.send:alice@example.com"

    @respx.mock
    async def test_uses_workflow_name_as_default_namespace(self):
        client = make_client(namespace=None)

        lease_route = respx.post(f"{BASE_URL}/effects/refund_flow/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/refund_flow/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        run = client.workflow("refund_flow").case("order_123").run()
        await run.protect("step1", act=lambda: {"ok": True})

        # Should hit the refund_flow namespace endpoint
        assert len(lease_route.calls) == 1

    @respx.mock
    async def test_allows_namespace_override_in_run(self):
        client = make_client(namespace=None)

        lease_route = respx.post(f"{BASE_URL}/effects/custom-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/custom-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        run = client.workflow("refund_flow").case("order_123").run(namespace="custom-ns")
        await run.protect("step1", act=lambda: {"ok": True})

        assert len(lease_route.calls) == 1

    @respx.mock
    async def test_allows_per_effect_namespace_override(self):
        client = make_client(namespace=None)

        # Effect 1: run-level namespace (workflow name)
        lease_route_1 = respx.post(f"{BASE_URL}/effects/refund_flow/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/refund_flow/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        # Effect 2: per-effect namespace override
        lease_route_2 = respx.post(f"{BASE_URL}/effects/notifications/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/notifications/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        run = client.workflow("refund_flow").case("order_123").run()

        await run.protect("refund_payment", act=lambda: {"ok": True})
        assert len(lease_route_1.calls) == 1

        await run.protect("notify_customer", act=lambda: {"ok": True}, namespace="notifications")
        assert len(lease_route_2.calls) == 1

    def test_generates_unique_run_ids(self):
        client = make_client()
        run1 = client.workflow("wf").case("c1").run()
        run2 = client.workflow("wf").case("c1").run()
        assert run1.run_id != run2.run_id

    def test_uses_explicit_run_id(self):
        client = make_client()
        run = client.workflow("wf").case("c1").run(run_id="my-run-id")
        assert run.run_id == "my-run-id"

    def test_returns_correct_context_types(self):
        client = make_client()
        wf = client.workflow("wf")
        assert isinstance(wf, WorkflowContext)

        cs = wf.case("c1")
        assert isinstance(cs, CaseContext)

        run = cs.run()
        assert isinstance(run, RunContext)


# =============================================================================
# 9. Configuration errors
# =============================================================================


class TestConfigErrors:
    def test_raises_when_base_url_missing(self):
        with pytest.raises(VerityConfigError):
            VerityClient(base_url="", api_key="key")

    def test_raises_when_api_key_missing(self):
        with pytest.raises(VerityConfigError):
            VerityClient(base_url="http://test", api_key="")

    async def test_raises_when_namespace_missing_on_protect(self):
        client = make_client(namespace=None)

        with pytest.raises(VerityConfigError):
            await client.protect("test-effect", act=lambda: {})


# =============================================================================
# 10. on_lease callback + key_suffix (standalone)
# =============================================================================


class TestOnLeaseCallback:
    @respx.mock
    async def test_fires_on_lease_after_acquisition(self):
        client = make_client()
        on_lease = MagicMock()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect("test-effect", act=lambda: {"ok": True}, on_lease=on_lease)

        on_lease.assert_called_once()
        call_arg = on_lease.call_args[0][0]
        assert call_arg.status == "granted"
        assert call_arg.effect_id == "eff-123"

    @respx.mock
    async def test_fires_on_lease_for_cached_responses(self):
        client = make_client()
        on_lease = MagicMock()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=cached_completed({"result": True}))
        )

        await client.protect("test-effect", act=lambda: {}, on_lease=on_lease)

        on_lease.assert_called_once()
        call_arg = on_lease.call_args[0][0]
        assert call_arg.status == "cached_completed"


class TestKeySuffixStandalone:
    @respx.mock
    async def test_appends_key_suffix_to_standalone_effect_key(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect(
            "send-email", act=lambda: {"ok": True}, key_suffix="alice@example.com"
        )

        lease_body = json.loads(lease_route.calls[0].request.content)
        assert lease_body["effectKey"] == "send-email:alice@example.com"

    @respx.mock
    async def test_no_suffix_when_omitted(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.protect("send-email", act=lambda: {"ok": True})

        lease_body = json.loads(lease_route.calls[0].request.content)
        assert lease_body["effectKey"] == "send-email"


# =============================================================================
# 11. Low-level API
# =============================================================================


class TestLowLevelApi:
    @respx.mock
    async def test_request_lease_sends_correct_request(self):
        client = make_client()

        lease_route = respx.post(f"{BASE_URL}/effects/my-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )

        result = await client.request_lease("my-ns", {
            "effectKey": "effect-1",
            "leaseDurationMs": 30_000,
        })

        assert result.status == "granted"
        assert len(lease_route.calls) == 1

    @respx.mock
    async def test_commit_sends_correct_request(self):
        client = make_client()

        commit_route = respx.post(f"{BASE_URL}/effects/my-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        await client.commit("my-ns", {
            "effectKey": "effect-1",
            "fenceToken": 1,
            "leaseToken": "tok",
            "result": {"amount": 500},
        })

        assert len(commit_route.calls) == 1

    @respx.mock
    async def test_fail_sends_correct_request(self):
        client = make_client()

        fail_route = respx.post(f"{BASE_URL}/effects/my-ns/fail").mock(
            return_value=httpx.Response(200, json=fail_ok())
        )

        await client.fail("my-ns", {
            "effectKey": "effect-1",
            "fenceToken": 1,
            "leaseToken": "tok",
            "error": {"message": "boom"},
        })

        assert len(fail_route.calls) == 1

    @respx.mock
    async def test_renew_sends_correct_request(self):
        client = make_client()

        renew_route = respx.post(f"{BASE_URL}/effects/my-ns/renew").mock(
            return_value=httpx.Response(200, json={
                "status": "renewed",
                "leaseExpiresAt": "2099-01-01T00:00:00Z",
            })
        )

        await client.renew("my-ns", {
            "effectKey": "effect-1",
            "fenceToken": 1,
            "leaseToken": "tok",
        })

        assert len(renew_route.calls) == 1


# =============================================================================
# 12. Commit/fail transient retry
# =============================================================================


class TestTransientRetry:
    @respx.mock
    async def test_retries_commit_on_500_and_succeeds(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )

        commit_count = 0

        def commit_side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal commit_count
            commit_count += 1
            if commit_count <= 1:
                return httpx.Response(500, json={"error": "internal"})
            return httpx.Response(200, json=commit_ok())

        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(side_effect=commit_side_effect)

        result = await client.protect("test-effect", act=lambda: {"ok": True})
        assert result == {"ok": True}
        assert commit_count == 2

    @respx.mock
    async def test_does_not_retry_commit_on_4xx(self):
        client = make_client()

        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        commit_route = respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(409, json={"error": "fence mismatch"})
        )

        with pytest.raises(CommitUncertainError):
            await client.protect("test-effect", act=lambda: {"ok": True})

        # 1 commit attempt only — no retry on 4xx
        assert len(commit_route.calls) == 1


# =============================================================================
# 13. Context manager
# =============================================================================


class TestContextManager:
    @respx.mock
    async def test_works_as_async_context_manager(self):
        respx.post(f"{BASE_URL}/effects/test-ns/lease").mock(
            return_value=httpx.Response(200, json=granted_lease())
        )
        respx.post(f"{BASE_URL}/effects/test-ns/commit").mock(
            return_value=httpx.Response(200, json=commit_ok())
        )

        async with make_client() as client:
            result = await client.protect("test-effect", act=lambda: {"ok": True})
            assert result == {"ok": True}

