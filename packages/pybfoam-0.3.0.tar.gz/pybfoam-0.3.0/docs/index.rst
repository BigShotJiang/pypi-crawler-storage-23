.. pybFoam documentation master file, created by
   sphinx-quickstart on Sun Sep  7 12:02:25 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pybFoam Documentation
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation
   usage
   api
   contributing
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
