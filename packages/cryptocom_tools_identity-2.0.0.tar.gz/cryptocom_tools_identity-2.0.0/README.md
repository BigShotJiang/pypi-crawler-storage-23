# cryptocom-tools-identity

CronosID identity tools for the Crypto.com Developer Platform.

## Installation

```bash
pip install cryptocom-tools-identity
```

## Tools

- **ResolveCronosIdTool** - Resolve a CronosID name to its blockchain address
- **LookupAddressTool** - Look up the CronosID name for a blockchain address (reverse lookup)

## Usage

```python
import os
from cryptocom_tools_identity import ResolveCronosIdTool, LookupAddressTool

# Resolve name to address
resolve_tool = ResolveCronosIdTool()
result = resolve_tool.invoke({"name": "alice.cro"})
print(result)

# Reverse lookup: address to name
lookup_tool = LookupAddressTool()
result = lookup_tool.invoke({"address": "0x..."})
print(result)
```

## Environment Variables

- `CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY` - CDP API key (auto-read by CDPTool)

## License

MIT
