"""
Crypto.com Tools Identity - CronosID identity resolution tools.

This package provides read-only tools for CronosID resolution:
- ResolveCronosIdTool: Resolve CronosID name to blockchain address
- LookupAddressTool: Look up CronosID name for a blockchain address

Example:
    from cryptocom_tools_identity import ResolveCronosIdTool, LookupAddressTool

    # Resolve name to address
    resolve_tool = ResolveCronosIdTool()
    result = resolve_tool.invoke({"name": "alice.cro"})

    # Reverse lookup: address to name
    lookup_tool = LookupAddressTool()
    result = lookup_tool.invoke({"address": "0x..."})
"""

from __future__ import annotations

__version__ = "0.1.0"

from .read import (
    CronosIdResult,
    LookupAddressInput,
    LookupAddressTool,
    ResolveCronosIdInput,
    ResolveCronosIdTool,
)

__all__ = [
    "__version__",
    # Result type
    "CronosIdResult",
    # Input schemas
    "ResolveCronosIdInput",
    "LookupAddressInput",
    # Tools
    "ResolveCronosIdTool",
    "LookupAddressTool",
]
