"""Shared result classes for identity read tools."""

from __future__ import annotations

from dataclasses import dataclass

from cryptocom_tools_core import ToolResult


@dataclass
class CronosIdResult(ToolResult):
    """Result from CronosID resolution tools."""

    name: str | None
    address: str | None
    success: bool
    message: str

    def _format_result(self) -> str:
        if self.success:
            if self.name and self.address:
                return f"CronosID '{self.name}' resolves to {self.address}"
            elif self.address:
                return f"Address {self.address} has CronosID: {self.name or 'None'}"
            else:
                return self.message
        else:
            return f"CronosID resolution failed: {self.message}"


__all__ = ["CronosIdResult"]
