"""ResolveCronosIdTool - Resolve a CronosID name to blockchain address."""

from __future__ import annotations

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import CronosIdResult


class ResolveCronosIdInput(BaseModel):
    """Input schema for ResolveCronosIdTool."""

    name: str = Field(description="The CronosID name to resolve (e.g., alice.cro)")


class ResolveCronosIdTool(CDPTool):
    """
    Resolve a CronosID name to its associated blockchain address.

    Example:
        tool = ResolveCronosIdTool()
        result = tool.invoke({"name": "alice.cro"})
    """

    name: str = "resolve_cronosid"
    description: str = "Resolve a CronosID name to its associated blockchain address"
    args_schema: type[BaseModel] = ResolveCronosIdInput  # type: ignore[assignment]

    def _run(self, name: str) -> str:  # type: ignore[override]
        """Resolve CronosID name to address."""
        from crypto_com_developer_platform_client import CronosId

        # Normalize the name
        normalized_name = self._normalize_name(name)

        try:
            response = CronosId.resolve_name(normalized_name)

            if response.get("status") == "Success":
                data = response.get("data", {})
                address = data.get("address") if data else None
                if address:
                    result = CronosIdResult(
                        name=normalized_name,
                        address=address,
                        success=True,
                        message=f"Successfully resolved {normalized_name}",
                    )
                    return str(result)

            result = CronosIdResult(
                name=normalized_name,
                address=None,
                success=False,
                message=f"No address found for CronosID '{normalized_name}'",
            )
            return str(result)

        except Exception as e:
            result = CronosIdResult(
                name=normalized_name,
                address=None,
                success=False,
                message=f"Error resolving CronosID: {e!s}",
            )
            return str(result)

    @staticmethod
    def _normalize_name(name: str) -> str:
        """Normalize CronosID name."""
        name = name.lower().strip()
        if "." not in name:
            name = f"{name}.cro"
        return name


__all__ = ["ResolveCronosIdInput", "ResolveCronosIdTool"]
