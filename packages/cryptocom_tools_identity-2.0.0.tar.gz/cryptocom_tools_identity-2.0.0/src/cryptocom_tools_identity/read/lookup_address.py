"""LookupAddressTool - Look up CronosID name for a blockchain address."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import CronosIdResult


class LookupAddressInput(BaseModel):
    """Input schema for LookupAddressTool."""

    address: str = Field(description="The blockchain address to look up (0x format)")


class LookupAddressTool(CDPTool):
    """
    Look up the CronosID name associated with a blockchain address.

    Example:
        tool = LookupAddressTool()
        result = tool.invoke({"address": "0x..."})
    """

    name: str = "lookup_cronosid_address"
    description: str = "Look up the CronosID name associated with a blockchain address"
    args_schema: type[BaseModel] = LookupAddressInput  # type: ignore[assignment]

    def _run(self, address: str) -> str:  # type: ignore[override]
        """Look up CronosID for an address."""
        from crypto_com_developer_platform_client import CronosId

        # Normalize address
        normalized_address = self._normalize_address(address)

        try:
            # Original API uses lookup_address, not reverse_resolve
            response: Any = CronosId.lookup_address(normalized_address)

            if isinstance(response, dict) and response.get("status") == "Success":
                cronosid_name = response.get("data", {}).get("name")
                if cronosid_name:
                    result = CronosIdResult(
                        name=cronosid_name,
                        address=normalized_address,
                        success=True,
                        message="Found CronosID for address",
                    )
                    return str(result)

            result = CronosIdResult(
                name=None,
                address=normalized_address,
                success=True,
                message=f"No CronosID registered for address {normalized_address}",
            )
            return str(result)

        except Exception as e:
            result = CronosIdResult(
                name=None,
                address=normalized_address,
                success=False,
                message=f"Error looking up CronosID: {e!s}",
            )
            return str(result)

    @staticmethod
    def _normalize_address(address: str) -> str:
        """Normalize address to checksum format."""
        from web3 import Web3

        if Web3.is_address(address):
            return Web3.to_checksum_address(address)
        return address


__all__ = ["LookupAddressInput", "LookupAddressTool"]
