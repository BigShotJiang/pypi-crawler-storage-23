"""
GCP Pipeline Beam Library
"""
__version__ = "1.0.2"
