WORKFLOW_SCHEMA = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "required": ["name", "description", "version", "data", "steps", "outcomes"],
    "properties": {
        "name": {
            "type": "string",
            "description": "Workflow name"
        },
        "description": {
            "type": "string",
            "description": "Workflow description"
        },
        "version": {
            "type": "string",
            "pattern": "^\\d+\\.\\d+(\\.\\d+)?$",
            "description": "Semantic version (e.g., 1.0.0)"
        },
        "agent_framework": {
            "type": "string",
            "enum": ["langgraph", "crewai", "agno", "pydantic-ai"],
            "default": "langgraph",
            "description": "Agent framework to use for all agents in this workflow (default: langgraph)"
        },
        "humanization_agent": {
            "type": "object",
            "description": "Configuration for LLM-powered message humanization (enabled by default)",
            "properties": {
                "enabled": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether to enable LLM humanization for outcome messages (default: true)"
                },
                "model": {
                    "type": "string",
                    "description": "Model to use for humanization (overrides model_config.model_name)"
                },
                "base_url": {
                    "type": "string",
                    "format": "uri",
                    "description": "Base URL for humanization model (overrides model_config.base_url)"
                },
                "instructions": {
                    "type": "string",
                    "description": "Custom system prompt for the humanization agent"
                }
            }
        },
        "localization": {
            "type": "object",
            "description": "Default localization configuration (can be overridden per-turn via execute() parameters)",
            "properties": {
                "language": {
                    "type": "string",
                    "description": "Default target language (e.g., Tamil, Hindi, Spanish)"
                },
                "script": {
                    "type": "string",
                    "description": "Default target script/writing system (e.g., Tamil, Devanagari, Latin)"
                },
                "instructions": {
                    "type": "string",
                    "description": "Custom instructions for language/script requirements"
                }
            }
        },
        "data": {
            "type": "array",
            "description": "Data fields used in the workflow",
            "items": {
                "type": "object",
                "required": ["name", "type", "description"],
                "properties": {
                    "name": {
                        "type": "string",
                        "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                        "description": "Field name (must be valid Python identifier)"
                    },
                    "type": {
                        "type": "string",
                        "enum": ["text", "number", "boolean", "list", "dict", "any", "double"],
                        "description": "Field data type"
                    },
                    "description": {
                        "type": "string",
                        "description": "Field description"
                    },
                    "default": {
                        "description": "Default value for the field"
                    }
                }
            }
        },
        "inputs": {
            "type": "array",
            "description": "Input fields required to start the workflow (list of data field names)",
            "items": {
                "type": "string",
                "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                "description": "Name of a field from the data array"
            }
        },
        "failure_message":{
            "type": "string",
            "description": "Default message to be returned when any error occurs within the framework."
        },
        "steps": {
            "type": "array",
            "description": "Workflow steps",
            "minItems": 1,
            "items": {
                "type": "object",
                "required": ["id", "action"],
                "properties": {
                    "id": {
                        "type": "string",
                        "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                        "description": "Step ID (must be unique and valid Python identifier)"
                    },
                    "action": {
                        "type": "string",
                        "enum": ["collect_input_with_agent", "call_function", "call_async_function", "mfa", "follow_up"],
                        "description": "Action type"
                    },
                    "field": {
                        "type": "string",
                        "description": "Field to collect (for collect_input_with_agent)"
                    },
                    "fields": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Multiple fields to collect in one step (alternative to 'field')"
                    },
                    "validators": {
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                        "description": "Per-field validator function paths (for multi-field collection)"
                    },
                    "validator": {
                        "type": "string",
                        "description": "Optional data validator"
                    },
                    "max_attempts": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 20,
                        "description": "Maximum attempts (for collect_input_with_agent)"
                    },
                    "on_max_attempts_reached": {
                        "type": "string",
                        "description": "Custom error message to display when max attempts are exhausted (for collect_input_with_agent)"
                    },
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of options to present to the user for selection (for collect_input_with_agent)"
                    },
                    "is_selectable": {
                        "type": "boolean",
                        "default": False,
                        "description": "Whether user must select from options (true) or can type freely (false)"
                    },
                    "agent": {
                        "type": "object",
                        "description": "Agent configuration (for collect_input_with_agent)",
                        "required": ["name", "instructions"],
                        "properties": {
                            "name": {
                                "type": "string"
                            },
                            "model": {
                                "type": "string"
                            },
                            "description": {
                                "type": "string"
                            },
                            "instructions": {
                                "type": "string"
                            },
                            "tools": {
                                "type": "array"
                            },
                            "base_url": {
                                "type": "string",
                                "format": "uri"
                            },
                            "api_key": {
                                "type": "string"
                            },
                            "humanize": {
                                "type": "boolean",
                                "default": True,
                                "description": "Whether to apply LLM humanization to this agent's prompts (default: true)"
                            },
                            "grounding_check": {
                                "type": "boolean",
                                "default": False,
                                "description": "Enable Bedrock Guardrails grounding check on agent responses (requires BEDROCK_GUARDRAIL_ID env var)"
                            },
                            "bot_response_rules": {
                                "type": "string",
                                "description": (
                                    "Override the default BOT RESPONSE RULES prompt injected into the agent's "
                                    "instructions. When set, replaces the built-in rules entirely."
                                )
                            },
                            "guardrails": {
                                "type": "array",
                                "description": (
                                    "Names of guardrails from the top-level guardrails registry "
                                    "to apply to this agent's responses. Order determines execution order."
                                ),
                                "items": {
                                    "type": "string",
                                    "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                                    "description": "Must match an 'action' defined in the top-level guardrails array"
                                },
                                "uniqueItems": True
                            },
                            "structured_output": {
                                "type": "object",
                                "description": "Structured output configuration",
                                "required": ["enabled"],
                                "properties": {
                                    "enabled": {
                                        "type": "boolean",
                                        "description": "Whether to enable structured output"
                                    },
                                    "fields": {
                                        "type": "array",
                                        "description": "Field definitions for structured output",
                                        "items": {
                                            "type": "object",
                                            "required": ["name", "type", "description"],
                                            "properties": {
                                                "name": {
                                                    "type": "string",
                                                    "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                                                    "description": "Field name (must be valid Python identifier)"
                                                },
                                                "type": {
                                                    "type": "string",
                                                    "enum": ["text", "number", "boolean", "list", "dict", "double"],
                                                    "description": "Field data type"
                                                },
                                                "description": {
                                                    "type": "string",
                                                    "description": "Field description"
                                                },
                                                "required": {
                                                    "type": "boolean",
                                                    "description": "Whether the field is required",
                                                    "default": True
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "function": {
                        "type": "string",
                        "pattern": "^[a-zA-Z_][a-zA-Z0-9_.]*\\.[a-zA-Z_][a-zA-Z0-9_]*$",
                        "description": "Function path (for call_function, format: module.function)"
                    },
                    "output": {
                        "type": "string",
                        "description": "Output field name"
                    },
                    "next": {
                        "type": "string",
                        "description": "Next step ID (for simple routing)"
                    },
                    "transitions": {
                        "type": "array",
                        "description": "Conditional transitions",
                        "items": {
                            "type": "object",
                            "properties": {
                                "pattern": {
                                    "anyOf": [
                                        {"type": "string"},
                                        {"type": "array", "items": {"type": "string"}}
                                    ],
                                    "description": "Pattern(s) to match in response (for non-structured output)"
                                },
                                "match": {
                                    "description": "Value to match against a field (for structured output)"
                                },
                                "ref": {
                                    "type": "string",
                                    "description": "Field name to check when using 'match' (for structured output)"
                                },
                                "condition": {
                                    "description": "Condition to evaluate (for call_function)"
                                },
                                "next": {
                                    "type": "string",
                                    "description": "Next step or outcome ID"
                                }
                            },
                            "oneOf": [
                                {"required": ["pattern", "next"]},
                                {"required": ["match", "next", "ref"]},
                                {"required": ["condition", "next"]}
                            ]
                        }
                    },
                    "url": {
                        "type": "string",
                        "format": "uri",
                        "description": "Webhook URL (for webhook action)"
                    },
                    "method": {
                        "type": "string",
                        "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                        "description": "HTTP method (for webhook action)"
                    },
                    "headers": {
                        "type": "object",
                        "description": "HTTP headers (for webhook action)"
                    },
                    "timeout": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 600,
                        "description": "Timeout in seconds"
                    },
                    "mfa": {
                        "type": "object",
                        "description": "Multi-factor authentication configuration",
                        "required": ["type", "payload"],
                        "properties": {
                            "model": {
                                "type": "string",
                                "description": "Path to the model which will be used to parse the MFA input from the user"
                            },
                            "type": {
                                "type": "string",
                                "enum": ["REST"],
                                "description": "API type for MFA"
                            },
                            "payload": {
                                "type": "object",
                                "description": "MFA payload data that is posted to the RESTAPI, Apart from the properties provided transactionId is sent by the framework in the post payload as an additional property, transactionId is the same throughout the MFA process",
                                "additionalProperties": True
                            },
                            "max_attempts": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 20,
                                "description": "Maximum number of attempts allowed for MFA validation (default: 3)"
                            },
                            "on_max_attempts_reached": {
                                "type": "string",
                                "description": "Custom error message to display when MFA max attempts are exhausted"
                            }
                        }
                    },
                    "guardrails": {
                        "type": "array",
                        "description": (
                            "Names of guardrails from the top-level guardrails registry "
                            "to apply to this agent's responses. Order determines execution order."
                        ),
                        "items": {
                            "type": "string",
                            "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                            "description": "Must match a 'name' defined in the top-level guardrails array"
                        },
                        "uniqueItems": True
                    }
                }
            }
        },
        "outcomes": {
            "type": "array",
            "description": "Workflow outcomes",
            "minItems": 1,
            "items": {
                "type": "object",
                "required": ["id", "type", "message"],
                "properties": {
                    "id": {
                        "type": "string",
                        "pattern": "^[a-zA-Z_][a-zA-Z0-9_]*$",
                        "description": "Outcome ID (must be unique)"
                    },
                    "type": {
                        "type": "string",
                        "enum": ["success", "failure", "redirect"],
                        "description": "Outcome type"
                    },
                    "message": {
                        "type": "string",
                        "description": "Outcome message (supports {field} placeholders)"
                    },
                    "redirect_to": {
                        "type": "string",
                        "description": "Redirect target (required when type is redirect)"
                    },
                    "humanize": {
                        "type": "boolean",
                        "default": True,
                        "description": "Whether to apply LLM humanization to this outcome's message (default: true)"
                    }
                }
            }
        },
        "metadata": {
            "type": "object",
            "description": "Additional workflow metadata",
            "properties": {
                "author": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "documentation": {"type": "string"}
            }
        },
        "tool_config": {
            "type": "object",
            "description": "Tool configuration for the workflow",
            "properties": {
                "tools": {
                    "type": "array",
                    "description": "List of available tools",
                    "items": {
                        "type": "object",
                        "required": ["name", "description", "callable"],
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Tool name"
                            },
                            "description": {
                                "type": "string",
                                "description": "Tool description"
                            },
                            "callable": {
                                "type": "string",
                                "pattern": "^[a-zA-Z_][a-zA-Z0-9_.]*\\.[a-zA-Z_][a-zA-Z0-9_]*$",
                                "description": "Callable path (format: module.function)"
                            }
                        }
                    }
                }
            }
        },
        "guardrails": {
            "type": "array",
            "description": (
                "Global guardrail definitions. Each entry uses 'action' as both the "
                "reference name and the factory type. Steps reference guardrails by "
                "their action name in agent.guardrails."
            ),
            "items": {
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["thought_action_check", "grounding_check"],
                        "description": "Guardrail type and reference name (must match a registered GuardrailFactory type)"
                    },
                    "error_message": {
                        "type": "string",
                        "description": "User-facing message returned when this guardrail fails"
                    },
                    "bedrock_guardrail_id": {
                        "type": "string",
                        "description": "Bedrock Guardrail ID (grounding_check only — overrides BEDROCK_GUARDRAIL_ID env var)"
                    },
                    "bedrock_guardrail_version": {
                        "type": "string",
                        "description": "Bedrock Guardrail version (grounding_check only, default: DRAFT)"
                    },
                    "aws_region_name": {
                        "type": "string",
                        "description": "AWS region for Bedrock runtime (grounding_check only — overrides AWS_REGION_NAME env var)"
                    },
                    "max_retries": {
                        "type": "integer",
                        "minimum": 1,
                        "description": "Number of regeneration attempts if guardrail fails"
                    }
                }
            }
        },
    
    }
}
