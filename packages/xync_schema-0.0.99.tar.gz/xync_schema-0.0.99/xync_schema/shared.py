from io import BytesIO
from pathlib import Path
from struct import pack, unpack

from PIL import Image, ImageDraw, ImageFont
from qrcode.image.pure import PyPNGImage
from qrcode.main import QRCode
from xync_schema.enums import ZERO_TS


def qr_gen(data: str, text: str = "") -> bytes:
    qr = QRCode(border=0, box_size=8, error_correction=1)
    qr.add_data(data, optimize=1)
    qr.make(fit=True)
    pp = qr.make_image(PyPNGImage)
    with BytesIO() as fo:
        pp.get_image().write(fo, pp.rows_iter())
        fo.seek(0)
        qr_img = Image.open(fo).convert("RGB")
    # Uniform padding
    pad = 16
    # Load logo
    logo = Image.open(Path(__file__).parent / "logo.png")
    font_size = 18
    font = ImageFont.load_default(font_size)
    dummy_draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    text_bbox = dummy_draw.textbbox((0, 0), text, font=font)
    text_w = int(text_bbox[2] - text_bbox[0]) + 5
    text_h = int(text_bbox[3] - text_bbox[1]) + 9
    # Render text at 2x
    text_img = Image.new("RGB", (text_w, text_h), "white")
    text_draw = ImageDraw.Draw(text_img)
    text_draw.text((5, 5), text, fill="black", font=font)
    # Compose final image with uniform padding (logo + text in one row)
    gap = 2  # gap between logo and text
    row_w = logo.width + gap + text_img.width
    canvas_w = max(qr_img.width, row_w) + pad * 2
    canvas_h = pad + qr_img.height + pad + logo.height + pad - 4
    new_img = Image.new("RGB", (canvas_w, canvas_h), "white")
    qr_x = (canvas_w - qr_img.width) // 2
    new_img.paste(qr_img, (qr_x, pad))
    row_x = (canvas_w - row_w) // 2
    row_y = pad + qr_img.height + pad
    logo_y = row_y + (logo.height - logo.height) // 2
    new_img.paste(logo, (row_x, logo_y))
    text_x = row_x + logo.width
    text_y = row_y + (logo.height - text_img.height) // 2 - 6
    new_img.paste(text_img, (text_x, text_y))
    # new_img.save("qr.png", format="PNG")  # save to disk for debug
    with BytesIO() as out:  # bytes for sending
        new_img.save(out, format="PNG")
        return out.getvalue()


def typ_ts_pack(typ: int, ts: int):  # тип + ts (2+30=32bit=4byte)
    """Упаковка тип(2bit)+время(30bit) в 4 байта"""
    assert 0 <= typ < 4  # 2 бита
    secs2026 = ts - ZERO_TS  # секунд от Feb 02 2026 02:40 в UTC (max 1_073_741_823 = Feb 11 2060 16:17:03)
    assert 0 <= secs2026 < 1 << 30  # 30 бит
    bits = typ << 30 | secs2026  # суммируем тип(2 бита) + секунды(30 бит) в 32 бита
    return pack(">I", bits)  # упаковали 32 бита в 4 байта


def typ_ts_unpack(packed: bytes) -> tuple[int, int]:  # 4byte -> тип + ts (2+30=32bit)
    """Распаковка 4 байт в тип(2bit)+время(30bit)"""
    (value,) = unpack(">I", packed)
    typ = (value >> 30) & 0b11  # сдвинули typ обратно на 30 бит, и вырезаем нужные биты по маске
    secs2026 = value & ((1 << 30) - 1)
    return typ, secs2026 + ZERO_TS
