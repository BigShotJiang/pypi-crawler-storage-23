"""Tests for the Drift Alert Surface panel (F-11).

Covers: GET /v1/ui/drift-alerts, POST /v1/ui/drift-alerts/{id}/dismiss,
GET /v1/ui/panels/drift-alerts HTML panel, sorting, filtering, and audit trail.
"""

import json
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

from nomotic.api import NomoticAPIServer
from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.drift import DriftScore
from nomotic.human_drift import HumanDriftResult, HumanInteractionProfile
from nomotic.keys import SigningKey
from nomotic.monitor import DriftAlert, DriftMonitor
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


def _make_drift_score(overall: float = 0.5) -> DriftScore:
    """Create a DriftScore with reasonable defaults."""
    return DriftScore(
        overall=overall,
        action_drift=overall * 0.6,
        target_drift=overall * 0.4,
        temporal_drift=overall * 0.3,
        outcome_drift=overall * 0.2,
        confidence=0.9,
        window_size=50,
        baseline_size=100,
    )


def _make_agent_alert(
    agent_id: str = "claims-bot",
    severity: str = "high",
    overall: float = 0.5,
    timestamp: float | None = None,
) -> DriftAlert:
    """Create a DriftAlert for testing."""
    return DriftAlert(
        agent_id=agent_id,
        severity=severity,
        drift_score=_make_drift_score(overall),
        timestamp=timestamp or time.time(),
        acknowledged=False,
    )


def _make_reviewer_result(
    reviewer_id: str = "alice@example.com",
    overall_drift: float = 0.6,
    category: str = "severe",
    timestamp: float | None = None,
) -> HumanDriftResult:
    """Create a HumanDriftResult for testing."""
    ts = timestamp or time.time()
    baseline = HumanInteractionProfile(
        reviewer_id=reviewer_id,
        mean_review_duration=30.0,
        approval_rate=0.7,
        rationale_provided_rate=0.8,
        window_start=ts - 3600,
        window_end=ts - 1800,
    )
    recent = HumanInteractionProfile(
        reviewer_id=reviewer_id,
        mean_review_duration=5.0,
        approval_rate=0.98,
        rationale_provided_rate=0.2,
        window_start=ts - 600,
        window_end=ts,
    )
    return HumanDriftResult(
        reviewer_id=reviewer_id,
        overall_drift=overall_drift,
        drift_category=category,
        timing_drift=0.5,
        decision_drift=0.4,
        engagement_drift=0.6,
        throughput_drift=0.2,
        risk_timing_drift=0.3,
        fatigue_score=0.15,
        alerts=["Approval rate is 98%", "Review duration dropped 83%"],
        baseline_profile=baseline,
        recent_profile=recent,
    )


def _make_mock_runtime(
    agent_alerts: list[DriftAlert] | None = None,
    reviewer_alerts: list[HumanDriftResult] | None = None,
    has_human_drift: bool = True,
):
    """Create a mock runtime with drift monitor and optional human drift monitor."""
    runtime = SimpleNamespace()

    # Mock fingerprint observer with drift monitor
    drift_monitor = MagicMock(spec=DriftMonitor)
    drift_monitor.get_alerts.return_value = agent_alerts or []

    observer = SimpleNamespace(drift_monitor=drift_monitor)
    runtime._fingerprint_observer = observer

    # Mock human drift monitor
    if has_human_drift:
        human_monitor = MagicMock()
        human_monitor.get_alerts.return_value = reviewer_alerts or []
        runtime._human_drift_monitor = human_monitor
    else:
        # Simulate absence by not setting the attribute at all
        pass

    # Stub get_drift_alerts for backward compat
    runtime.get_drift_alerts = lambda agent_id=None, **kw: drift_monitor.get_alerts(
        agent_id, **kw
    )

    return runtime


def _setup_server(
    agent_alerts: list[DriftAlert] | None = None,
    reviewer_alerts: list[HumanDriftResult] | None = None,
    has_human_drift: bool = True,
    base_dir: Path | None = None,
):
    """Create a running API server for drift panel testing."""
    import tempfile

    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)

    if base_dir is None:
        base_dir = Path(tempfile.mkdtemp())

    runtime = _make_mock_runtime(agent_alerts, reviewer_alerts, has_human_drift)

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=True,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port, base_dir


def _get_json(port: int, path: str) -> tuple[int, list | dict]:
    """GET request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def _post_json(port: int, path: str, data: dict | None = None) -> tuple[int, dict]:
    """POST request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    body = json.dumps(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


# ── Test 1: GET returns JSON array ────────────────────────────────────


def test_get_drift_alerts_returns_json_array():
    """GET /v1/ui/drift-alerts returns a JSON array."""
    httpd, port, _ = _setup_server(agent_alerts=[_make_agent_alert()])
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        assert isinstance(data, list)
    finally:
        httpd.shutdown()


# ── Test 2: Agent alerts have alert_type="agent" ─────────────────────


def test_agent_alerts_have_correct_type():
    """Agent drift alerts have alert_type='agent'."""
    httpd, port, _ = _setup_server(agent_alerts=[_make_agent_alert()])
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        assert len(data) >= 1
        for a in data:
            if a["subject_id"] == "claims-bot":
                assert a["alert_type"] == "agent"
    finally:
        httpd.shutdown()


# ── Test 3: Reviewer alerts have alert_type="reviewer" ───────────────


def test_reviewer_alerts_have_correct_type():
    """Reviewer drift alerts have alert_type='reviewer'."""
    httpd, port, _ = _setup_server(
        reviewer_alerts=[_make_reviewer_result()],
    )
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        reviewer_found = False
        for a in data:
            if a["alert_type"] == "reviewer":
                reviewer_found = True
                assert a["subject_id"] == "alice@example.com"
        assert reviewer_found, "No reviewer alerts found"
    finally:
        httpd.shutdown()


# ── Test 4: CRITICAL before WARNING sort order ────────────────────────


def test_critical_alerts_sorted_before_warning():
    """CRITICAL alerts appear before WARNING in sorted results."""
    agent_alerts = [
        _make_agent_alert("bot-a", severity="moderate", overall=0.25),
        _make_agent_alert("bot-b", severity="critical", overall=0.7),
    ]
    httpd, port, _ = _setup_server(agent_alerts=agent_alerts)
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        assert len(data) == 2
        assert data[0]["severity"] == "CRITICAL"
        assert data[1]["severity"] == "WARNING"
    finally:
        httpd.shutdown()


# ── Test 5: POST dismiss returns dismissed=true ──────────────────────


def test_dismiss_returns_success():
    """POST /v1/ui/drift-alerts/{id}/dismiss returns dismissed=true."""
    agent_alerts = [_make_agent_alert()]
    httpd, port, _ = _setup_server(agent_alerts=agent_alerts)
    try:
        # First get alerts to find alert_id
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert len(data) >= 1
        alert_id = data[0]["alert_id"]

        # Dismiss it
        status, result = _post_json(
            port,
            f"/v1/ui/drift-alerts/{alert_id}/dismiss",
            {"dismissed_by": "admin", "reason": "test dismiss"},
        )
        assert status == 200
        assert result["dismissed"] is True
        assert result["alert_id"] == alert_id
    finally:
        httpd.shutdown()


# ── Test 6: POST dismiss writes audit record ─────────────────────────


def test_dismiss_writes_audit_record():
    """POST dismiss writes record to audit trail."""
    import tempfile

    base_dir = Path(tempfile.mkdtemp())
    agent_alerts = [_make_agent_alert(agent_id="audit-test-bot")]
    httpd, port, _ = _setup_server(
        agent_alerts=agent_alerts,
        base_dir=base_dir,
    )
    try:
        # Get and dismiss
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        alert_id = data[0]["alert_id"]

        _post_json(
            port,
            f"/v1/ui/drift-alerts/{alert_id}/dismiss",
            {"dismissed_by": "alice", "reason": "investigated"},
        )

        # Check audit store
        store = AuditStore(base_dir)
        records = store.query_all("audit-test-bot")
        assert len(records) >= 1
        dismiss_record = records[-1]
        assert dismiss_record.action_type == "DRIFT_ALERT_DISMISSED"
        assert dismiss_record.parameters["authority"] == "alice"
        assert dismiss_record.parameters["reason"] == "investigated"
        assert dismiss_record.parameters["action"] == "DRIFT_ALERT_DISMISSED"
    finally:
        httpd.shutdown()


# ── Test 7: POST dismiss returns 404 for unknown ID ──────────────────


def test_dismiss_unknown_alert_returns_404():
    """POST dismiss returns 404 for unknown alert_id."""
    httpd, port, _ = _setup_server()
    try:
        status, result = _post_json(
            port,
            "/v1/ui/drift-alerts/nonexistent-alert-id/dismiss",
            {"dismissed_by": "admin"},
        )
        assert status == 404
    finally:
        httpd.shutdown()


# ── Test 8: Dismissed alerts do not appear in subsequent GET ──────────


def test_dismissed_alerts_filtered_from_get():
    """Dismissed alerts do not appear in subsequent GET /v1/ui/drift-alerts."""
    agent_alerts = [_make_agent_alert()]
    httpd, port, _ = _setup_server(agent_alerts=agent_alerts)
    try:
        # Get alerts
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert len(data) >= 1
        alert_id = data[0]["alert_id"]

        # Dismiss
        _post_json(
            port,
            f"/v1/ui/drift-alerts/{alert_id}/dismiss",
            {"dismissed_by": "admin"},
        )

        # Subsequent GET should not include the dismissed alert
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        dismissed_ids = [a["alert_id"] for a in data]
        assert alert_id not in dismissed_ids
    finally:
        httpd.shutdown()


# ── Test 9: GET returns empty array when no active alerts ─────────────


def test_no_alerts_returns_empty_array():
    """GET returns empty array (not 404) when no active alerts."""
    httpd, port, _ = _setup_server()
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        assert data == []
    finally:
        httpd.shutdown()


# ── Test 10: Only agent alerts when HumanDriftDetector not configured ─


def test_no_human_drift_returns_only_agent_alerts():
    """When HumanDriftDetector is not configured, returns only agent alerts."""
    agent_alerts = [_make_agent_alert()]
    httpd, port, _ = _setup_server(
        agent_alerts=agent_alerts,
        has_human_drift=False,
    )
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        assert len(data) >= 1
        for a in data:
            assert a["alert_type"] == "agent"
    finally:
        httpd.shutdown()


# ── Test 11: Each alert has required fields ──────────────────────────


def test_alerts_have_required_fields():
    """Each alert has required fields: alert_id, alert_type, subject_id,
    drift_score, severity, detected_at."""
    agent_alerts = [_make_agent_alert()]
    reviewer_alerts = [_make_reviewer_result()]
    httpd, port, _ = _setup_server(
        agent_alerts=agent_alerts,
        reviewer_alerts=reviewer_alerts,
    )
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        required_fields = {
            "alert_id",
            "alert_type",
            "subject_id",
            "drift_score",
            "severity",
            "detected_at",
        }
        for alert in data:
            for field in required_fields:
                assert field in alert, f"Missing field '{field}' in alert: {alert}"
    finally:
        httpd.shutdown()


# ── Test 12: dismissed field is false for active alerts ───────────────


def test_active_alerts_have_dismissed_false():
    """dismissed field is false for active alerts."""
    agent_alerts = [_make_agent_alert()]
    httpd, port, _ = _setup_server(agent_alerts=agent_alerts)
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        for alert in data:
            assert alert["dismissed"] is False
    finally:
        httpd.shutdown()


# ── Test 13: HTML panel renders both sections ─────────────────────────


def test_html_panel_renders_both_sections():
    """GET /v1/ui/panels/drift-alerts returns HTML with both sections."""
    agent_alerts = [_make_agent_alert()]
    reviewer_alerts = [_make_reviewer_result()]
    httpd, port, _ = _setup_server(
        agent_alerts=agent_alerts,
        reviewer_alerts=reviewer_alerts,
    )
    try:
        url = f"http://127.0.0.1:{port}/v1/ui/panels/drift-alerts"
        with urllib.request.urlopen(url) as resp:
            html = resp.read().decode("utf-8")
        assert "Agent Behavioral Drift" in html
        assert "Human Reviewer Drift" in html
        assert "patterns of disengagement" in html
    finally:
        httpd.shutdown()


# ── Test 14: HTML panel shows empty state ─────────────────────────────


def test_html_panel_empty_state():
    """HTML panel shows empty state when no alerts."""
    httpd, port, _ = _setup_server()
    try:
        url = f"http://127.0.0.1:{port}/v1/ui/panels/drift-alerts"
        with urllib.request.urlopen(url) as resp:
            html = resp.read().decode("utf-8")
        assert "No drift alerts" in html
        assert "expected behavioral baselines" in html
    finally:
        httpd.shutdown()


# ── Test 15: Mixed alerts sorted by severity then score ───────────────


def test_mixed_alerts_sorted_correctly():
    """Both agent and reviewer alerts are sorted: CRITICAL first, then by score desc."""
    now = time.time()
    agent_alerts = [
        _make_agent_alert("bot-low", severity="moderate", overall=0.25, timestamp=now),
        _make_agent_alert("bot-crit", severity="critical", overall=0.8, timestamp=now),
    ]
    reviewer_alerts = [
        _make_reviewer_result(
            "bob@example.com", overall_drift=0.7, category="critical", timestamp=now,
        ),
    ]
    httpd, port, _ = _setup_server(
        agent_alerts=agent_alerts,
        reviewer_alerts=reviewer_alerts,
    )
    try:
        status, data = _get_json(port, "/v1/ui/drift-alerts")
        assert status == 200
        # All CRITICAL first
        critical_idx = [i for i, a in enumerate(data) if a["severity"] == "CRITICAL"]
        warning_idx = [i for i, a in enumerate(data) if a["severity"] == "WARNING"]
        if critical_idx and warning_idx:
            assert max(critical_idx) < min(warning_idx)
    finally:
        httpd.shutdown()
