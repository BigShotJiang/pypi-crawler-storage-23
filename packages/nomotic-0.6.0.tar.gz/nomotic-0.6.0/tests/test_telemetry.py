"""Tests for opt-in anonymous telemetry (F-21)."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from nomotic.telemetry import (
    TelemetryClient,
    _load_telemetry_setting,
    get_telemetry,
    reset_telemetry_singleton,
)


@pytest.fixture(autouse=True)
def _reset_singleton():
    """Reset the telemetry singleton before and after every test."""
    reset_telemetry_singleton()
    yield
    reset_telemetry_singleton()


# ---------------------------------------------------------------------------
# 1. Disabled client does NOT call _deliver
# ---------------------------------------------------------------------------


def test_disabled_client_does_not_deliver():
    client = TelemetryClient(enabled=False)
    client._deliver = MagicMock()
    client.record_archetype("healthcare-agent")
    client._deliver.assert_not_called()


# ---------------------------------------------------------------------------
# 2. Enabled client DOES call _deliver
# ---------------------------------------------------------------------------


def test_enabled_client_calls_deliver():
    client = TelemetryClient(enabled=True)
    with patch.object(client, "_deliver") as mock_deliver:
        # Patch threading to run synchronously
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_archetype("healthcare-agent")

            mock_deliver.assert_called_once()


# ---------------------------------------------------------------------------
# 3. Payload properties are SHA-256 hashes (16 hex chars), not raw values
# ---------------------------------------------------------------------------


def test_payload_properties_are_hashed():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_archetype("healthcare-agent")

    archetype_value = captured["properties"]["archetype"]
    # Must be 16 hex chars
    assert re.fullmatch(r"[0-9a-f]{16}", archetype_value), f"Not a 16-char hex hash: {archetype_value}"
    # Must NOT be the raw value
    assert archetype_value != "healthcare-agent"
    # Must match expected SHA-256 prefix
    expected = hashlib.sha256("healthcare-agent".encode()).hexdigest()[:16]
    assert archetype_value == expected


# ---------------------------------------------------------------------------
# 4. Payload contains nomotic_version field
# ---------------------------------------------------------------------------


def test_payload_contains_nomotic_version():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_cli_command("birth")

    assert "nomotic_version" in captured
    from nomotic import __version__
    assert captured["nomotic_version"] == __version__


# ---------------------------------------------------------------------------
# 5. Payload contains os_platform field
# ---------------------------------------------------------------------------


def test_payload_contains_os_platform():
    import platform

    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_cli_command("birth")

    assert "os_platform" in captured
    assert captured["os_platform"] == platform.system()


# ---------------------------------------------------------------------------
# 6. Payload contains session_id field
# ---------------------------------------------------------------------------


def test_payload_contains_session_id():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_cli_command("birth")

    assert "session_id" in captured
    assert len(captured["session_id"]) > 0


# ---------------------------------------------------------------------------
# 7. record_cli_command sends event_type="cli_command_invoked"
# ---------------------------------------------------------------------------


def test_record_cli_command_event_type():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_cli_command("birth")

    assert captured["event"] == "cli_command_invoked"


# ---------------------------------------------------------------------------
# 8. record_archetype sends event_type="archetype_declared"
# ---------------------------------------------------------------------------


def test_record_archetype_event_type():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_archetype("healthcare-agent")

    assert captured["event"] == "archetype_declared"


# ---------------------------------------------------------------------------
# 9. _deliver raises no exception when endpoint is unreachable
# ---------------------------------------------------------------------------


def test_deliver_does_not_raise_on_network_error():
    client = TelemetryClient(enabled=True, endpoint="http://localhost:1/nope")
    # Should not raise, even with an unreachable endpoint
    client._deliver({"event": "test", "properties": {}})


# ---------------------------------------------------------------------------
# 10. _send_event raises no exception when _deliver crashes
# ---------------------------------------------------------------------------


def test_send_event_does_not_raise_when_deliver_crashes():
    client = TelemetryClient(enabled=True)

    def exploding_deliver(payload):
        raise RuntimeError("boom")

    with patch.object(client, "_deliver", side_effect=exploding_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            # Should not raise
            client.record_cli_command("birth")


# ---------------------------------------------------------------------------
# 11. _load_telemetry_setting returns False when config file does not exist
# ---------------------------------------------------------------------------


def test_load_setting_false_when_no_config():
    td = tempfile.mkdtemp()
    try:
        fake_config = Path(td) / "config.json"
        with patch("nomotic.telemetry._CONFIG_PATH", fake_config):
            assert _load_telemetry_setting() is False
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ---------------------------------------------------------------------------
# 12. _load_telemetry_setting returns True when telemetry_enabled=y
# ---------------------------------------------------------------------------


def test_load_setting_true_when_enabled():
    td = tempfile.mkdtemp()
    try:
        config_file = Path(td) / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": "y"}), encoding="utf-8")
        with patch("nomotic.telemetry._CONFIG_PATH", config_file):
            assert _load_telemetry_setting() is True
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ---------------------------------------------------------------------------
# 13. _load_telemetry_setting returns False when telemetry_enabled=n
# ---------------------------------------------------------------------------


def test_load_setting_false_when_disabled():
    td = tempfile.mkdtemp()
    try:
        config_file = Path(td) / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": "n"}), encoding="utf-8")
        with patch("nomotic.telemetry._CONFIG_PATH", config_file):
            assert _load_telemetry_setting() is False
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ---------------------------------------------------------------------------
# 14. get_telemetry() returns the same instance on multiple calls (singleton)
# ---------------------------------------------------------------------------


def test_get_telemetry_singleton():
    with patch("nomotic.telemetry._load_telemetry_setting", return_value=False):
        a = get_telemetry()
        b = get_telemetry()
        assert a is b


# ---------------------------------------------------------------------------
# 15. reset_telemetry_singleton clears the singleton
# ---------------------------------------------------------------------------


def test_reset_clears_singleton():
    with patch("nomotic.telemetry._load_telemetry_setting", return_value=False):
        a = get_telemetry()
        reset_telemetry_singleton()
        b = get_telemetry()
        assert a is not b


# ---------------------------------------------------------------------------
# 16. record_framework_detected sends event_type="framework_detected"
# ---------------------------------------------------------------------------


def test_record_framework_detected_event_type():
    client = TelemetryClient(enabled=True)
    captured = {}

    def capture_deliver(payload):
        captured.update(payload)

    with patch.object(client, "_deliver", side_effect=capture_deliver):
        with patch("nomotic.telemetry.threading") as mock_threading:
            mock_thread = MagicMock()
            mock_threading.Thread.return_value = mock_thread
            mock_thread.start.side_effect = lambda: mock_threading.Thread.call_args[1]["target"](*mock_threading.Thread.call_args[1]["args"])

            client.record_framework_detected("langgraph")

    assert captured["event"] == "framework_detected"
    expected_hash = hashlib.sha256("langgraph".encode()).hexdigest()[:16]
    assert captured["properties"]["framework"] == expected_hash


# ---------------------------------------------------------------------------
# 17. _load_telemetry_setting handles boolean True in config
# ---------------------------------------------------------------------------


def test_load_setting_handles_bool_true():
    td = tempfile.mkdtemp()
    try:
        config_file = Path(td) / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": True}), encoding="utf-8")
        with patch("nomotic.telemetry._CONFIG_PATH", config_file):
            assert _load_telemetry_setting() is True
    finally:
        shutil.rmtree(td, ignore_errors=True)


# ---------------------------------------------------------------------------
# 18. _load_telemetry_setting handles boolean False in config
# ---------------------------------------------------------------------------


def test_load_setting_handles_bool_false():
    td = tempfile.mkdtemp()
    try:
        config_file = Path(td) / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": False}), encoding="utf-8")
        with patch("nomotic.telemetry._CONFIG_PATH", config_file):
            assert _load_telemetry_setting() is False
    finally:
        shutil.rmtree(td, ignore_errors=True)
