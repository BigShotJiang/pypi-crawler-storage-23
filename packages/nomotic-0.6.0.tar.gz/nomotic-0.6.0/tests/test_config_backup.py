"""Tests for tamper-resistant configuration backups (v0.6.0 Item 15).

Minimum 20 test functions covering ConfigBackup dataclass, ConfigBackupManager
operations (backup, verify, restore, list, cleanup), runtime integration,
and doctor check integration.
"""

from __future__ import annotations

import json
import tempfile
import time
from pathlib import Path
from typing import Any

import pytest

from nomotic.config_backup import ConfigBackup, ConfigBackupManager


# ── Helpers ──────────────────────────────────────────────────────────────


def _tmp_manager(
    max_backups: int = 5,
    secret: str = "test-secret-123",
) -> tuple[ConfigBackupManager, Path]:
    """Create a ConfigBackupManager with a temp directory."""
    tmp = tempfile.mkdtemp()
    mgr = ConfigBackupManager(
        base_dir=Path(tmp),
        signing_secret=secret,
        max_backups_per_type=max_backups,
    )
    return mgr, Path(tmp)


def _sample_content() -> dict[str, Any]:
    return {"ruleset_id": "test-001", "rules": [{"name": "r1"}]}


# ── TestConfigBackup ────────────────────────────────────────────────────


class TestConfigBackup:
    """Tests for the ConfigBackup dataclass."""

    def test_verify_returns_true_for_valid_backup(self) -> None:
        secret = "my-secret"
        mgr, _ = _tmp_manager(secret=secret)
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        assert backup.verify(secret) is True

    def test_verify_returns_false_for_tampered_content(self) -> None:
        secret = "my-secret"
        mgr, _ = _tmp_manager(secret=secret)
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        # Tamper with content hash
        backup.content_hash = "0000000000000000000000000000000000000000000000000000000000000000"
        assert backup.verify(secret) is False

    def test_verify_returns_false_for_tampered_signature(self) -> None:
        secret = "my-secret"
        mgr, _ = _tmp_manager(secret=secret)
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        backup.signature = "deadbeef" * 8
        assert backup.verify(secret) is False

    def test_verify_returns_false_for_wrong_secret(self) -> None:
        mgr, _ = _tmp_manager(secret="correct-secret")
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        assert backup.verify("wrong-secret") is False

    def test_to_dict_from_dict_roundtrip(self) -> None:
        mgr, _ = _tmp_manager()
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        d = backup.to_dict()
        restored = ConfigBackup.from_dict(d)
        assert restored.backup_id == backup.backup_id
        assert restored.artifact_type == backup.artifact_type
        assert restored.created_at == backup.created_at
        assert restored.content_hash == backup.content_hash
        assert restored.content == backup.content
        assert restored.signature == backup.signature
        assert restored.nomotic_version == backup.nomotic_version

    def test_backup_id_prefix(self) -> None:
        mgr, _ = _tmp_manager()
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        assert backup.backup_id.startswith("nmbk-")

    def test_nomotic_version_set(self) -> None:
        import nomotic
        mgr, _ = _tmp_manager()
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        assert backup.nomotic_version == nomotic.__version__


# ── TestConfigBackupManager ─────────────────────────────────────────────


class TestConfigBackupManager:
    """Tests for ConfigBackupManager operations."""

    def test_backup_creates_signed_backup(self) -> None:
        mgr, _ = _tmp_manager()
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        assert isinstance(backup, ConfigBackup)
        assert backup.artifact_type == "constitutional_ruleset"
        assert backup.signature != ""
        assert backup.content_hash != ""

    def test_backup_content_hash_computed(self) -> None:
        mgr, _ = _tmp_manager()
        content = _sample_content()
        backup = mgr.backup("constitutional_ruleset", content)
        expected_hash = mgr._compute_content_hash(content)
        assert backup.content_hash == expected_hash

    def test_backup_invalid_artifact_type_raises(self) -> None:
        mgr, _ = _tmp_manager()
        with pytest.raises(ValueError, match="Unknown artifact_type"):
            mgr.backup("invalid_type", {})

    def test_empty_signing_secret_raises(self) -> None:
        with pytest.raises(ValueError, match="signing_secret is required"):
            ConfigBackupManager(
                base_dir=Path("/tmp/test"),
                signing_secret="",
            )

    def test_verify_latest_returns_true_for_clean_backup(self) -> None:
        mgr, _ = _tmp_manager()
        mgr.backup("constitutional_ruleset", _sample_content())
        valid, msg = mgr.verify_latest("constitutional_ruleset")
        assert valid is True
        assert "Backup verified" in msg

    def test_verify_latest_returns_false_no_backups(self) -> None:
        mgr, _ = _tmp_manager()
        valid, msg = mgr.verify_latest("constitutional_ruleset")
        assert valid is False
        assert "No backups found" in msg

    def test_verify_latest_returns_false_tampered(self) -> None:
        mgr, tmp_dir = _tmp_manager()
        backup = mgr.backup("authority_registry", {"authorities": []})
        # Tamper with the file on disk
        backup_dir = tmp_dir / "backups" / "authority_registry"
        files = list(backup_dir.glob("nmbk-*.json"))
        assert len(files) == 1
        data = json.loads(files[0].read_text(encoding="utf-8"))
        data["signature"] = "tampered" * 8
        files[0].write_text(json.dumps(data), encoding="utf-8")
        valid, msg = mgr.verify_latest("authority_registry")
        assert valid is False
        assert "Signature verification failed" in msg

    def test_restore_latest_returns_content(self) -> None:
        mgr, _ = _tmp_manager()
        content = _sample_content()
        mgr.backup("constitutional_ruleset", content)
        restored = mgr.restore_latest("constitutional_ruleset")
        assert restored == content

    def test_restore_latest_none_when_no_backups(self) -> None:
        mgr, _ = _tmp_manager()
        result = mgr.restore_latest("constitutional_ruleset")
        assert result is None

    def test_restore_latest_none_when_tampered(self) -> None:
        mgr, tmp_dir = _tmp_manager()
        mgr.backup("role_registry", {"roles": []})
        # Tamper
        backup_dir = tmp_dir / "backups" / "role_registry"
        files = list(backup_dir.glob("nmbk-*.json"))
        data = json.loads(files[0].read_text(encoding="utf-8"))
        data["content_hash"] = "tampered"
        files[0].write_text(json.dumps(data), encoding="utf-8")
        result = mgr.restore_latest("role_registry")
        assert result is None

    def test_list_backups_all_types(self) -> None:
        mgr, _ = _tmp_manager()
        mgr.backup("constitutional_ruleset", {"rules": []})
        mgr.backup("authority_registry", {"authorities": []})
        mgr.backup("role_registry", {"roles": []})
        all_backups = mgr.list_backups()
        assert len(all_backups) == 3
        types = {b.artifact_type for b in all_backups}
        assert types == {"constitutional_ruleset", "authority_registry", "role_registry"}

    def test_list_backups_filtered_by_type(self) -> None:
        mgr, _ = _tmp_manager()
        mgr.backup("constitutional_ruleset", {"rules": []})
        mgr.backup("authority_registry", {"authorities": []})
        filtered = mgr.list_backups("constitutional_ruleset")
        assert len(filtered) == 1
        assert filtered[0].artifact_type == "constitutional_ruleset"

    def test_list_backups_most_recent_first(self) -> None:
        mgr, _ = _tmp_manager()
        b1 = mgr.backup("constitutional_ruleset", {"rules": [], "v": 1})
        b2 = mgr.backup("constitutional_ruleset", {"rules": [], "v": 2})
        backups = mgr.list_backups("constitutional_ruleset")
        assert len(backups) == 2
        # Most recent first
        assert backups[0].created_at >= backups[1].created_at
        assert backups[0].content["v"] == 2

    def test_cleanup_removes_old_backups(self) -> None:
        mgr, _ = _tmp_manager(max_backups=2)
        mgr.backup("constitutional_ruleset", {"v": 1})
        mgr.backup("constitutional_ruleset", {"v": 2})
        mgr.backup("constitutional_ruleset", {"v": 3})
        backups = mgr.list_backups("constitutional_ruleset")
        assert len(backups) == 2
        # Oldest should be pruned
        versions = [b.content["v"] for b in backups]
        assert 1 not in versions

    def test_cleanup_respects_max_count(self) -> None:
        mgr, _ = _tmp_manager(max_backups=3)
        for i in range(5):
            mgr.backup("authority_registry", {"n": i})
        backups = mgr.list_backups("authority_registry")
        assert len(backups) == 3

    def test_backup_auto_prunes_on_create(self) -> None:
        mgr, tmp_dir = _tmp_manager(max_backups=1)
        mgr.backup("role_registry", {"v": 1})
        mgr.backup("role_registry", {"v": 2})
        backup_dir = tmp_dir / "backups" / "role_registry"
        files = list(backup_dir.glob("nmbk-*.json"))
        assert len(files) == 1

    def test_backup_file_persisted(self) -> None:
        mgr, tmp_dir = _tmp_manager()
        backup = mgr.backup("constitutional_ruleset", _sample_content())
        filepath = tmp_dir / "backups" / "constitutional_ruleset" / f"{backup.backup_id}.json"
        assert filepath.exists()
        data = json.loads(filepath.read_text(encoding="utf-8"))
        assert data["backup_id"] == backup.backup_id

    def test_content_hash_deterministic(self) -> None:
        mgr, _ = _tmp_manager()
        content = {"b": 2, "a": 1}
        h1 = mgr._compute_content_hash(content)
        h2 = mgr._compute_content_hash(content)
        assert h1 == h2
        # Key order shouldn't matter since we use sort_keys
        content2 = {"a": 1, "b": 2}
        h3 = mgr._compute_content_hash(content2)
        assert h1 == h3


# ── TestRuntimeIntegration ──────────────────────────────────────────────


class TestRuntimeIntegration:
    """Tests for runtime.py integration with backup manager."""

    def test_backup_manager_created_when_configured(self) -> None:
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        with tempfile.TemporaryDirectory() as tmp:
            config = RuntimeConfig(
                enable_config_backups=True,
                config_backup_signing_secret="test-secret",
                config_backup_max_per_type=3,
            )
            runtime = GovernanceRuntime(config=config)
            assert runtime._backup_manager is not None

    def test_backup_manager_none_when_not_configured(self) -> None:
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        config = RuntimeConfig(enable_config_backups=False)
        runtime = GovernanceRuntime(config=config)
        assert runtime._backup_manager is None

    def test_backup_manager_none_when_no_secret(self) -> None:
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        config = RuntimeConfig(
            enable_config_backups=True,
            config_backup_signing_secret="",
        )
        runtime = GovernanceRuntime(config=config)
        assert runtime._backup_manager is None

    def test_startup_backups_created(self) -> None:
        """When configured and artifacts exist, startup creates backups."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        with tempfile.TemporaryDirectory() as tmp:
            config = RuntimeConfig(
                enable_config_backups=True,
                config_backup_signing_secret="test-secret",
            )
            runtime = GovernanceRuntime(config=config)
            # With no artifacts configured, no backups should be created
            # but the manager should exist
            assert runtime._backup_manager is not None
            # Backups list should be empty (no artifacts loaded)
            backups = runtime._backup_manager.list_backups()
            assert len(backups) == 0

    def test_shutdown_creates_final_backup(self) -> None:
        """Shutdown method exists and runs without error."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        config = RuntimeConfig(
            enable_config_backups=True,
            config_backup_signing_secret="test-secret",
        )
        runtime = GovernanceRuntime(config=config)
        # Should not raise
        runtime.shutdown()

    def test_runtime_config_has_backup_fields(self) -> None:
        from nomotic.runtime import RuntimeConfig
        config = RuntimeConfig()
        assert hasattr(config, "enable_config_backups")
        assert hasattr(config, "config_backup_signing_secret")
        assert hasattr(config, "config_backup_max_per_type")
        assert config.enable_config_backups is False
        assert config.config_backup_signing_secret == ""
        assert config.config_backup_max_per_type == 5


# ── TestDoctorIntegration ───────────────────────────────────────────────


class TestDoctorIntegration:
    """Tests for doctor.py config backup checks."""

    def test_doctor_warns_when_not_configured(self) -> None:
        from nomotic.doctor import DoctorReport, _check_config_backups
        with tempfile.TemporaryDirectory() as tmp:
            report = DoctorReport()
            _check_config_backups(report, Path(tmp))
            assert len(report.checks) >= 1
            check = report.checks[0]
            assert check.status == "warning"
            assert "not configured" in check.message

    def test_doctor_warns_when_no_backups(self) -> None:
        from nomotic.doctor import DoctorReport, _check_config_backups
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            # Create backups dir but no artifact subdirs
            (tmp_path / "backups").mkdir()
            report = DoctorReport()
            _check_config_backups(report, tmp_path)
            # Should warn about no backups for each type
            warnings = [c for c in report.checks if c.status == "warning"]
            assert len(warnings) >= 1

    def test_doctor_ok_when_backups_valid_and_fresh(self) -> None:
        from nomotic.doctor import DoctorReport, _check_config_backups
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            mgr = ConfigBackupManager(
                base_dir=tmp_path,
                signing_secret="test-secret",
            )
            mgr.backup("constitutional_ruleset", {"rules": []})
            report = DoctorReport()
            _check_config_backups(report, tmp_path)
            ok_checks = [c for c in report.checks if c.status == "ok"]
            assert len(ok_checks) >= 1
            # The constitutional_ruleset check should be ok
            cr_check = next(
                (c for c in report.checks if "constitutional_ruleset" in c.name),
                None,
            )
            assert cr_check is not None
            assert cr_check.status == "ok"

    def test_doctor_warns_when_backup_older_than_7_days(self) -> None:
        from nomotic.doctor import DoctorReport, _check_config_backups
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            mgr = ConfigBackupManager(
                base_dir=tmp_path,
                signing_secret="test-secret",
            )
            backup = mgr.backup("authority_registry", {"authorities": []})
            # Manually age the backup file
            backup_dir = tmp_path / "backups" / "authority_registry"
            files = list(backup_dir.glob("nmbk-*.json"))
            data = json.loads(files[0].read_text(encoding="utf-8"))
            data["created_at"] = time.time() - (8 * 86400)  # 8 days ago
            files[0].write_text(json.dumps(data), encoding="utf-8")

            report = DoctorReport()
            _check_config_backups(report, tmp_path)
            ar_check = next(
                (c for c in report.checks if "authority_registry" in c.name),
                None,
            )
            assert ar_check is not None
            assert ar_check.status == "warning"
            assert "days old" in ar_check.message


# ── TestExports ─────────────────────────────────────────────────────────


class TestExports:
    """Test that ConfigBackup and ConfigBackupManager are importable from nomotic."""

    def test_import_from_package(self) -> None:
        from nomotic import ConfigBackup, ConfigBackupManager
        assert ConfigBackup is not None
        assert ConfigBackupManager is not None
