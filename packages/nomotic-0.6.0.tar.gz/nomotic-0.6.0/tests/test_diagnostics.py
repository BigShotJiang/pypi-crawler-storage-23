"""Tests for the ``nomotic diagnose`` error diagnostics command."""

from __future__ import annotations

import argparse
import sys
from io import StringIO
from unittest.mock import patch

import pytest

from nomotic.diagnostics import (
    DIAGNOSTIC_REGISTRY,
    DiagnosticEntry,
    list_known_errors,
    resolve_diagnostic,
)


# ---------------------------------------------------------------------------
# resolve_diagnostic — exact matches
# ---------------------------------------------------------------------------


def test_resolve_constitutional_violation_exact():
    entry = resolve_diagnostic("ConstitutionalViolationError")
    assert entry is not None
    assert entry.error_class == "ConstitutionalViolationError"


def test_resolve_constitutional_alias():
    entry = resolve_diagnostic("constitutional")
    assert entry is not None
    assert entry.error_class == "ConstitutionalViolationError"


def test_resolve_cve_alias():
    entry = resolve_diagnostic("CVE")
    assert entry is not None
    assert entry.error_class == "ConstitutionalViolationError"


def test_resolve_budget_alias():
    entry = resolve_diagnostic("budget")
    assert entry is not None
    assert entry.error_class == "BudgetExhaustedError"


def test_resolve_cert_status_alias():
    entry = resolve_diagnostic("cert_status")
    assert entry is not None
    assert entry.error_class == "CertificateStatusError"


def test_resolve_permission_alias():
    entry = resolve_diagnostic("permission")
    assert entry is not None
    assert entry.error_class == "PermissionDeniedError"


# ---------------------------------------------------------------------------
# resolve_diagnostic — unknown
# ---------------------------------------------------------------------------


def test_resolve_unknown_returns_none():
    result = resolve_diagnostic("completely_unknown_xyz")
    assert result is None


# ---------------------------------------------------------------------------
# resolve_diagnostic — case insensitivity
# ---------------------------------------------------------------------------


def test_resolve_case_insensitive_upper():
    entry = resolve_diagnostic("CONSTITUTIONAL")
    assert entry is not None
    assert entry.error_class == "ConstitutionalViolationError"


def test_resolve_case_insensitive_mixed():
    entry = resolve_diagnostic("BudgetExhaustedError")
    assert entry is not None
    assert entry.error_class == "BudgetExhaustedError"


# ---------------------------------------------------------------------------
# DiagnosticEntry field validation
# ---------------------------------------------------------------------------


def test_all_entries_have_nonempty_what_it_means():
    seen = set()
    for entry in DIAGNOSTIC_REGISTRY.values():
        if entry.error_class in seen:
            continue
        seen.add(entry.error_class)
        assert entry.what_it_means.strip(), (
            f"{entry.error_class} has empty what_it_means"
        )


def test_all_entries_have_at_least_two_common_causes():
    seen = set()
    for entry in DIAGNOSTIC_REGISTRY.values():
        if entry.error_class in seen:
            continue
        seen.add(entry.error_class)
        assert len(entry.common_causes) >= 2, (
            f"{entry.error_class} has {len(entry.common_causes)} common_causes, need >= 2"
        )


def test_all_entries_have_at_least_two_fix_steps():
    seen = set()
    for entry in DIAGNOSTIC_REGISTRY.values():
        if entry.error_class in seen:
            continue
        seen.add(entry.error_class)
        assert len(entry.how_to_fix) >= 2, (
            f"{entry.error_class} has {len(entry.how_to_fix)} fix steps, need >= 2"
        )


# ---------------------------------------------------------------------------
# list_known_errors
# ---------------------------------------------------------------------------


def test_list_known_errors_no_duplicates():
    errors = list_known_errors()
    assert len(errors) == len(set(errors))


def test_list_known_errors_sorted():
    errors = list_known_errors()
    assert errors == sorted(errors)


def test_list_known_errors_contains_expected():
    errors = list_known_errors()
    assert "ConstitutionalViolationError" in errors
    assert "BudgetExhaustedError" in errors
    assert "PermissionDeniedError" in errors
    assert "CertificateStatusError" in errors


# ---------------------------------------------------------------------------
# _cmd_diagnose — integration via CLI
# ---------------------------------------------------------------------------


def test_cmd_diagnose_known_error_output():
    from nomotic.cli import _cmd_diagnose

    args = argparse.Namespace(
        error_code="ConstitutionalViolationError",
        no_doctor=True,
        base_dir=None,
    )
    buf = StringIO()
    with patch("sys.stdout", buf):
        _cmd_diagnose(args)

    output = buf.getvalue()
    assert "What it means" in output
    assert "Common causes" in output
    assert "How to fix" in output
    assert "ConstitutionalViolationError" in output


def test_cmd_diagnose_unknown_error_exits_nonzero():
    from nomotic.cli import _cmd_diagnose

    args = argparse.Namespace(
        error_code="totally_bogus_error_xyz",
        no_doctor=True,
        base_dir=None,
    )
    with pytest.raises(SystemExit) as exc_info:
        _cmd_diagnose(args)
    assert exc_info.value.code == 1


# ---------------------------------------------------------------------------
# Substring matching
# ---------------------------------------------------------------------------


def test_resolve_substring_match():
    entry = resolve_diagnostic("Violation")
    assert entry is not None
    # Should match one of the violation errors
    assert "Violation" in entry.error_class


def test_resolve_delegation_substring():
    entry = resolve_diagnostic("depth")
    assert entry is not None
    assert entry.error_class == "DelegationDepthError"
