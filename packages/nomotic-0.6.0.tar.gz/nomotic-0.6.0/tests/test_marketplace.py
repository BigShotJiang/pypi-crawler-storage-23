"""Tests for the archetype marketplace (F-20).

All network calls are mocked — no real HTTP requests.
"""

from __future__ import annotations

import io
import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from nomotic.marketplace import (
    ArchetypeEntry,
    ArchetypeMarketplace,
    ArchetypeValidationError,
    CommunityArchetype,
    MarketplaceConnectionError,
)


# ── Fixtures ───────────────────────────────────────────────────────────


def _sample_index() -> dict:
    return {
        "archetypes": [
            {
                "name": "fintech-compliance",
                "description": "Financial compliance archetype with SOX focus",
                "resolves_to": "compliance-audit",
                "author": "acme-corp",
                "version": "1.0.0",
                "compliance_tags": ["sox", "pci-dss"],
            },
            {
                "name": "retail-cx",
                "description": "Retail customer experience agent",
                "resolves_to": "customer-experience",
                "author": "shop-ai",
                "version": "0.9.0",
                "compliance_tags": ["gdpr"],
            },
        ],
    }


def _sample_archetype_yaml() -> str:
    return yaml.dump(
        {
            "name": "fintech-compliance",
            "version": "1.0.0",
            "resolves_to": "compliance-audit",
            "description": "Financial compliance archetype with SOX focus",
            "author": "acme-corp",
            "license": "Apache-2.0",
            "weight_overrides": {
                "jurisdictional_compliance": 0.3,
                "incident_detection": 0.15,
            },
            "use_cases": ["SOX compliance", "Audit reporting"],
            "compliance_tags": ["sox", "pci-dss"],
        }
    )


def _valid_community_archetype() -> CommunityArchetype:
    return CommunityArchetype(
        name="fintech-compliance",
        version="1.0.0",
        resolves_to="compliance-audit",
        weight_overrides={
            "jurisdictional_compliance": 0.3,
            "incident_detection": 0.15,
        },
        description="Financial compliance archetype with SOX focus",
        use_cases=["SOX compliance", "Audit reporting"],
        compliance_tags=["sox", "pci-dss"],
        author="acme-corp",
        license="Apache-2.0",
    )


def _mock_urlopen(data: bytes, status: int = 200):
    """Return a context-manager mock that behaves like urlopen()."""
    resp = MagicMock()
    resp.read.return_value = data
    resp.status = status
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


# ═══════════════════════════════════════════════════════════════════════
# fetch_index
# ═══════════════════════════════════════════════════════════════════════


class TestFetchIndex:
    """Tests for ArchetypeMarketplace.fetch_index()."""

    @patch("urllib.request.urlopen")
    def test_parses_index_json(self, mock_urlopen: MagicMock) -> None:
        """1. fetch_index() parses index JSON → list[ArchetypeEntry]."""
        index_data = _sample_index()
        mock_urlopen.return_value = _mock_urlopen(
            json.dumps(index_data).encode()
        )

        mp = ArchetypeMarketplace()
        entries = mp.fetch_index()

        assert len(entries) == 2
        assert isinstance(entries[0], ArchetypeEntry)
        assert entries[0].name == "fintech-compliance"
        assert entries[0].resolves_to == "compliance-audit"
        assert entries[0].author == "acme-corp"
        assert entries[0].compliance_tags == ["sox", "pci-dss"]
        assert entries[1].name == "retail-cx"

    @patch("urllib.request.urlopen")
    def test_connection_error(self, mock_urlopen: MagicMock) -> None:
        """2. fetch_index() raises MarketplaceConnectionError on failure."""
        import urllib.error

        mock_urlopen.side_effect = urllib.error.URLError("connection refused")

        mp = ArchetypeMarketplace()
        with pytest.raises(MarketplaceConnectionError, match="Could not reach"):
            mp.fetch_index()


# ═══════════════════════════════════════════════════════════════════════
# fetch_archetype
# ═══════════════════════════════════════════════════════════════════════


class TestFetchArchetype:
    """Tests for ArchetypeMarketplace.fetch_archetype()."""

    @patch("urllib.request.urlopen")
    def test_returns_community_archetype(self, mock_urlopen: MagicMock) -> None:
        """3. fetch_archetype() returns CommunityArchetype with all fields."""
        yaml_content = _sample_archetype_yaml()
        mock_urlopen.return_value = _mock_urlopen(yaml_content.encode())

        mp = ArchetypeMarketplace()
        arch = mp.fetch_archetype("fintech-compliance")

        assert isinstance(arch, CommunityArchetype)
        assert arch.name == "fintech-compliance"
        assert arch.version == "1.0.0"
        assert arch.resolves_to == "compliance-audit"
        assert arch.author == "acme-corp"
        assert arch.license == "Apache-2.0"
        assert arch.weight_overrides["jurisdictional_compliance"] == 0.3
        assert "SOX compliance" in arch.use_cases
        assert "sox" in arch.compliance_tags

    @patch("urllib.request.urlopen")
    def test_404_raises_validation_error(self, mock_urlopen: MagicMock) -> None:
        """4. fetch_archetype() raises ArchetypeValidationError on 404."""
        import urllib.error

        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="https://example.com",
            code=404,
            msg="Not Found",
            hdrs=None,  # type: ignore[arg-type]
            fp=io.BytesIO(b""),
        )

        mp = ArchetypeMarketplace()
        with pytest.raises(ArchetypeValidationError, match="not found"):
            mp.fetch_archetype("nonexistent")


# ═══════════════════════════════════════════════════════════════════════
# validate_archetype
# ═══════════════════════════════════════════════════════════════════════


class TestValidateArchetype:
    """Tests for ArchetypeMarketplace.validate_archetype()."""

    def test_valid_archetype_passes(self) -> None:
        """5. validate_archetype() raises nothing for a valid archetype."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        mp.validate_archetype(arch)  # should not raise

    def test_unknown_resolves_to(self) -> None:
        """6. Raises ArchetypeValidationError for unknown resolves_to."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.resolves_to = "totally-bogus-archetype"

        with pytest.raises(ArchetypeValidationError, match="not a valid base"):
            mp.validate_archetype(arch)

    def test_weight_above_max(self) -> None:
        """7. Raises ArchetypeValidationError for weight > 5.0."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.weight_overrides["too_high"] = 6.5

        with pytest.raises(ArchetypeValidationError, match="outside range"):
            mp.validate_archetype(arch)

    def test_weight_below_min(self) -> None:
        """8. Raises ArchetypeValidationError for weight < 0.0."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.weight_overrides["too_low"] = -0.5

        with pytest.raises(ArchetypeValidationError, match="outside range"):
            mp.validate_archetype(arch)

    def test_invalid_name_chars(self) -> None:
        """9. Raises ArchetypeValidationError for invalid name characters."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.name = "bad name!@#"

        with pytest.raises(ArchetypeValidationError, match="alphanumeric"):
            mp.validate_archetype(arch)


# ═══════════════════════════════════════════════════════════════════════
# install_archetype
# ═══════════════════════════════════════════════════════════════════════


class TestInstallArchetype:
    """Tests for ArchetypeMarketplace.install_archetype()."""

    def test_writes_yaml_file(self) -> None:
        """10. install_archetype() writes YAML file to install_dir."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()

        with tempfile.TemporaryDirectory() as tmpdir:
            install_dir = Path(tmpdir) / "archetypes"
            result = mp.install_archetype(arch, install_dir=install_dir)

            assert result.exists()
            assert result.name == "fintech-compliance.yaml"
            content = result.read_text()
            assert "fintech-compliance" in content
            assert "compliance-audit" in content

    def test_creates_install_dir(self) -> None:
        """11. install_archetype() creates install_dir if it doesn't exist."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()

        with tempfile.TemporaryDirectory() as tmpdir:
            install_dir = Path(tmpdir) / "deep" / "nested" / "dir"
            assert not install_dir.exists()

            result = mp.install_archetype(arch, install_dir=install_dir)
            assert install_dir.exists()
            assert result.exists()

    def test_yaml_round_trip(self) -> None:
        """12. Installed YAML round-trips: fields match original."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()

        with tempfile.TemporaryDirectory() as tmpdir:
            install_dir = Path(tmpdir)
            result = mp.install_archetype(arch, install_dir=install_dir)

            raw = yaml.safe_load(result.read_text())
            assert raw["name"] == arch.name
            assert raw["version"] == arch.version
            assert raw["resolves_to"] == arch.resolves_to
            assert raw["author"] == arch.author
            assert raw["license"] == arch.license
            assert raw["description"] == arch.description
            assert raw["weight_overrides"]["jurisdictional_compliance"] == 0.3
            assert raw["weight_overrides"]["incident_detection"] == 0.15
            assert "SOX compliance" in raw["use_cases"]
            assert "sox" in raw["compliance_tags"]


# ═══════════════════════════════════════════════════════════════════════
# CLI handler: browse
# ═══════════════════════════════════════════════════════════════════════


class TestHandleArchetypeBrowse:
    """Tests for _handle_archetype_browse()."""

    @patch("urllib.request.urlopen")
    def test_connection_error_prints_message(
        self, mock_urlopen: MagicMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """13. Browse handles MarketplaceConnectionError gracefully."""
        import urllib.error

        mock_urlopen.side_effect = urllib.error.URLError("connection refused")

        from nomotic.cli import _handle_archetype_browse

        args = MagicMock()
        args.search = None

        _handle_archetype_browse(args)  # should not raise

        captured = capsys.readouterr()
        assert "Could not reach" in captured.out

    @patch("urllib.request.urlopen")
    def test_search_filters_entries(
        self, mock_urlopen: MagicMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """14. --search filter: only matching entries displayed."""
        index_data = _sample_index()
        mock_urlopen.return_value = _mock_urlopen(
            json.dumps(index_data).encode()
        )

        from nomotic.cli import _handle_archetype_browse

        args = MagicMock()
        args.search = "retail"

        _handle_archetype_browse(args)

        captured = capsys.readouterr()
        assert "retail-cx" in captured.out
        assert "fintech-compliance" not in captured.out


# ═══════════════════════════════════════════════════════════════════════
# CommunityArchetype.to_yaml
# ═══════════════════════════════════════════════════════════════════════


class TestCommunityArchetypeToYaml:
    """Tests for CommunityArchetype.to_yaml() serialization."""

    def test_to_yaml_contains_all_fields(self) -> None:
        """to_yaml() output contains all archetype fields."""
        arch = _valid_community_archetype()
        output = arch.to_yaml()

        assert "name: fintech-compliance" in output
        assert "version: 1.0.0" in output
        assert "resolves_to: compliance-audit" in output
        assert "author: acme-corp" in output
        assert "license: Apache-2.0" in output
        assert "jurisdictional_compliance: 0.3" in output
        assert "- SOX compliance" in output
        assert "- sox" in output


# ═══════════════════════════════════════════════════════════════════════
# Edge cases
# ═══════════════════════════════════════════════════════════════════════


class TestEdgeCases:
    """Additional edge-case tests."""

    def test_validate_empty_name(self) -> None:
        """validate_archetype rejects empty name."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.name = ""
        with pytest.raises(ArchetypeValidationError, match="alphanumeric"):
            mp.validate_archetype(arch)

    @patch("urllib.request.urlopen")
    def test_fetch_archetype_server_error(
        self, mock_urlopen: MagicMock
    ) -> None:
        """fetch_archetype raises MarketplaceConnectionError on 500."""
        import urllib.error

        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="https://example.com",
            code=500,
            msg="Internal Server Error",
            hdrs=None,  # type: ignore[arg-type]
            fp=io.BytesIO(b""),
        )

        mp = ArchetypeMarketplace()
        with pytest.raises(MarketplaceConnectionError, match="Registry error"):
            mp.fetch_archetype("some-archetype")

    @patch("urllib.request.urlopen")
    def test_browse_no_results(
        self, mock_urlopen: MagicMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Browse with search that matches nothing shows 'No archetypes'."""
        index_data = _sample_index()
        mock_urlopen.return_value = _mock_urlopen(
            json.dumps(index_data).encode()
        )

        from nomotic.cli import _handle_archetype_browse

        args = MagicMock()
        args.search = "zzzzz-nonexistent"

        _handle_archetype_browse(args)

        captured = capsys.readouterr()
        assert "No archetypes found" in captured.out

    def test_install_rejects_invalid(self) -> None:
        """install_archetype rejects invalid archetype (validates first)."""
        mp = ArchetypeMarketplace()
        arch = _valid_community_archetype()
        arch.resolves_to = "bogus-base"

        with pytest.raises(ArchetypeValidationError, match="not a valid base"):
            mp.install_archetype(arch)
