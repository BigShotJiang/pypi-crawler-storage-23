"""Tests for certificate-required proxy mode.

Verifies that both the HTTP governance proxy and MCP proxies correctly
enforce certificate requirements when ``require_certificate=True``.
"""

from __future__ import annotations

import io
import json
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.certificate import AgentCertificate, CertStatus
from nomotic.keys import SigningKey
from nomotic.mcp_proxy import MCPGovernanceProxy, MCPHTTPGovernanceProxy
from nomotic.proxy import (
    GovernanceProxyHandler,
    verify_certificate_status,
)
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore, MemoryCertificateStore


# ── Fixtures / helpers ───────────────────────────────────────────────────


def _setup_agent(
    tmp_path: Path,
    agent_id: str = "CertBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path.

    Returns the certificate_id.
    """
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


def _set_cert_status(tmp_path: Path, cert_id: str, status: CertStatus) -> None:
    """Change the status of an existing certificate on disk."""
    store = FileCertificateStore(tmp_path)
    cert = store.get(cert_id)
    assert cert is not None
    # Dataclass — create replacement with new status
    updated = AgentCertificate(
        certificate_id=cert.certificate_id,
        agent_id=cert.agent_id,
        owner=cert.owner,
        archetype=cert.archetype,
        organization=cert.organization,
        zone_path=cert.zone_path,
        issued_at=cert.issued_at,
        trust_score=cert.trust_score,
        behavioral_age=cert.behavioral_age,
        status=status,
        public_key=cert.public_key,
        fingerprint=cert.fingerprint,
        governance_hash=cert.governance_hash,
        lineage=cert.lineage,
        issuer_signature=cert.issuer_signature,
        expires_at=cert.expires_at,
        agent_numeric_id=cert.agent_numeric_id,
    )
    store.update(updated)


def _make_handler(
    *,
    require_certificate: bool = False,
    cert_store: Any = None,
    agent_id_map: dict[str, str] | None = None,
    headers: dict[str, str] | None = None,
    client_ip: str = "127.0.0.1",
) -> GovernanceProxyHandler:
    """Create a mock GovernanceProxyHandler for unit testing.

    Does NOT start a real server — patches just enough to test
    _resolve_agent_identity() and _deny_no_certificate().
    """
    handler = object.__new__(GovernanceProxyHandler)
    # Set class-level attributes on instance for testing isolation
    handler.require_certificate = require_certificate
    handler.cert_store = cert_store
    handler.agent_id_map = agent_id_map or {}

    # Mock request/connection attributes
    mock_headers = MagicMock()
    mock_headers.get = lambda key, default=None: (headers or {}).get(key, default)
    handler.headers = mock_headers
    handler.client_address = (client_ip, 12345)

    return handler


# ── verify_certificate_status (shared helper) ───────────────────────────


class TestVerifyCertificateStatus:
    def test_none_store_returns_error(self):
        result = verify_certificate_status(None, "any-agent")
        assert result == "Certificate store not configured"

    def test_active_cert_returns_none(self, tmp_path):
        cert_id = _setup_agent(tmp_path, "ActiveBot")
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, "ActiveBot")
        assert result is None

    def test_active_cert_by_cert_id(self, tmp_path):
        cert_id = _setup_agent(tmp_path, "CertIdBot")
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is None

    def test_no_cert_returns_error(self, tmp_path):
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, "ghost-agent")
        assert result is not None
        assert "NO_VALID_CERTIFICATE" in result

    def test_suspended_cert_returns_error(self, tmp_path):
        cert_id = _setup_agent(tmp_path, "SuspendedBot")
        _set_cert_status(tmp_path, cert_id, CertStatus.SUSPENDED)
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is not None
        assert "CERTIFICATE_SUSPENDED" in result

    def test_revoked_cert_returns_error(self, tmp_path):
        cert_id = _setup_agent(tmp_path, "RevokedBot")
        _set_cert_status(tmp_path, cert_id, CertStatus.REVOKED)
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is not None
        assert "CERTIFICATE_REVOKED" in result

    def test_expired_cert_returns_error(self, tmp_path):
        cert_id = _setup_agent(tmp_path, "ExpiredBot")
        _set_cert_status(tmp_path, cert_id, CertStatus.EXPIRED)
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is not None
        assert "CERTIFICATE_EXPIRED" in result

    def test_lookup_by_agent_id_scan(self, tmp_path):
        """When get() doesn't find by cert_id, falls back to scanning by agent_id."""
        _setup_agent(tmp_path, "ScanBot")
        store = FileCertificateStore(tmp_path)
        # agent_id "ScanBot" won't match cert_id, but scan should find it
        result = verify_certificate_status(store, "ScanBot")
        assert result is None


# ── Agent identity resolution ────────────────────────────────────────────


class TestAgentIdentityResolution:
    def test_agent_id_header_takes_priority(self):
        handler = _make_handler(
            headers={
                "X-Nomotic-Agent-Id": "header-agent",
                "X-Nomotic-Certificate-Id": "cert-agent",
            },
        )
        assert handler._resolve_agent_identity() == "header-agent"

    def test_certificate_id_header_fallback(self):
        handler = _make_handler(
            headers={"X-Nomotic-Certificate-Id": "cert-agent"},
        )
        assert handler._resolve_agent_identity() == "cert-agent"

    def test_ip_mapping_used_when_no_headers(self):
        handler = _make_handler(
            agent_id_map={"10.0.0.1": "mapped-agent"},
            client_ip="10.0.0.1",
        )
        assert handler._resolve_agent_identity() == "mapped-agent"

    def test_none_returned_when_no_identification(self):
        handler = _make_handler()
        assert handler._resolve_agent_identity() is None


# ── HTTP Proxy certificate enforcement ───────────────────────────────────


class TestHTTPProxyCertEnforcement:
    """Integration tests for GovernanceProxyHandler certificate checks."""

    def _make_request_handler(
        self,
        tmp_path: Path,
        agent_id: str,
        *,
        require_certificate: bool = True,
        agent_id_map: dict[str, str] | None = None,
        request_headers: dict[str, str] | None = None,
        method: str = "GET",
        path: str = "/test",
    ) -> tuple[GovernanceProxyHandler, io.BytesIO]:
        """Build a handler wired to a real executor and cert store."""
        _setup_agent(tmp_path, agent_id, actions=["read", "write"])
        store = FileCertificateStore(tmp_path)
        from nomotic.executor import GovernedToolExecutor

        executor = GovernedToolExecutor.connect(agent_id, base_dir=tmp_path, test_mode=True)

        # Build a handler with mocked I/O
        wfile = io.BytesIO()

        handler = object.__new__(GovernanceProxyHandler)
        handler.executor = executor
        handler.upstream_url = "http://localhost:9999"
        handler.require_certificate = require_certificate
        handler.cert_store = store if require_certificate else None
        handler.agent_id_map = agent_id_map or {}

        # Mock HTTP attributes
        all_headers: dict[str, str] = {}
        if request_headers:
            all_headers.update(request_headers)
        all_headers.setdefault("Content-Length", "0")

        mock_headers = MagicMock()
        mock_headers.get = lambda key, default=None: all_headers.get(key, default)
        mock_headers.items = lambda: list(all_headers.items())
        handler.headers = mock_headers
        handler.client_address = ("127.0.0.1", 54321)
        handler.command = method
        handler.path = path
        handler.rfile = io.BytesIO(b"")
        handler.wfile = wfile
        handler.requestline = f"{method} {path} HTTP/1.1"
        handler.request_version = "HTTP/1.1"

        # Patch send_response/send_header/end_headers to write to wfile
        handler._response_status = None
        handler._response_headers: list[tuple[str, str]] = []

        def send_response(code, message=None):
            handler._response_status = code
            wfile.write(f"HTTP/1.1 {code}\r\n".encode())

        def send_header(key, value):
            handler._response_headers.append((key, value))
            wfile.write(f"{key}: {value}\r\n".encode())

        def end_headers():
            wfile.write(b"\r\n")

        handler.send_response = send_response
        handler.send_header = send_header
        handler.end_headers = end_headers

        return handler, wfile

    def test_valid_cert_passes_to_governance(self, tmp_path):
        """Request with valid agent header and ACTIVE cert proceeds to governance."""
        handler, wfile = self._make_request_handler(
            tmp_path, "ValidBot",
            request_headers={"X-Nomotic-Agent-Id": "ValidBot"},
        )
        # Mock urlopen so the upstream forward doesn't fail
        mock_resp = MagicMock()
        mock_resp.read.return_value = b'{"ok": true}'
        mock_resp.status = 200
        mock_resp.headers = MagicMock()
        mock_resp.headers.items.return_value = [("Content-Type", "application/json")]
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.object(urllib.request, "urlopen", return_value=mock_resp):
            handler._handle()
        wfile.seek(0)
        raw = wfile.read()
        # Should NOT contain "certificate_required" — it passed cert check
        assert b"certificate_required" not in raw

    def test_no_agent_header_returns_403(self, tmp_path):
        """Request with no agent identification returns 403."""
        handler, wfile = self._make_request_handler(
            tmp_path, "NoHeaderBot",
        )
        handler._handle()
        assert handler._response_status == 403
        wfile.seek(0)
        raw = wfile.read()
        assert b"certificate_required" in raw

    def test_agent_header_no_cert_returns_403(self, tmp_path):
        """Request with agent header but no matching certificate returns 403."""
        handler, wfile = self._make_request_handler(
            tmp_path, "OrphanBot",
            request_headers={"X-Nomotic-Agent-Id": "unknown-agent-xyz"},
        )
        handler._handle()
        assert handler._response_status == 403
        wfile.seek(0)
        raw = wfile.read()
        assert b"NO_VALID_CERTIFICATE" in raw

    def test_suspended_cert_returns_403(self, tmp_path):
        """Request with SUSPENDED certificate returns 403."""
        cert_id = _setup_agent(tmp_path, "SuspBot", actions=["read", "write"])
        _set_cert_status(tmp_path, cert_id, CertStatus.SUSPENDED)

        store = FileCertificateStore(tmp_path)
        from nomotic.executor import GovernedToolExecutor

        executor = GovernedToolExecutor.connect("SuspBot", base_dir=tmp_path, test_mode=True)

        wfile = io.BytesIO()
        handler = object.__new__(GovernanceProxyHandler)
        handler.executor = executor
        handler.upstream_url = "http://localhost:9999"
        handler.require_certificate = True
        handler.cert_store = store
        handler.agent_id_map = {}
        mock_headers = MagicMock()
        mock_headers.get = lambda key, default=None: {"X-Nomotic-Agent-Id": cert_id, "Content-Length": "0"}.get(key, default)
        mock_headers.items = lambda: []
        handler.headers = mock_headers
        handler.client_address = ("127.0.0.1", 54321)
        handler.command = "GET"
        handler.path = "/test"
        handler.rfile = io.BytesIO(b"")
        handler.wfile = wfile
        handler.requestline = "GET /test HTTP/1.1"
        handler.request_version = "HTTP/1.1"
        handler._response_status = None
        handler._response_headers = []

        def send_response(code, message=None):
            handler._response_status = code
            wfile.write(f"HTTP/1.1 {code}\r\n".encode())

        def send_header(key, value):
            wfile.write(f"{key}: {value}\r\n".encode())

        def end_headers():
            wfile.write(b"\r\n")

        handler.send_response = send_response
        handler.send_header = send_header
        handler.end_headers = end_headers

        handler._handle()
        assert handler._response_status == 403
        wfile.seek(0)
        assert b"CERTIFICATE_SUSPENDED" in wfile.read()

    def test_revoked_cert_returns_403(self, tmp_path):
        """Request with REVOKED certificate returns 403."""
        cert_id = _setup_agent(tmp_path, "RevBot", actions=["read", "write"])
        _set_cert_status(tmp_path, cert_id, CertStatus.REVOKED)
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is not None
        assert "CERTIFICATE_REVOKED" in result

    def test_expired_cert_returns_403(self, tmp_path):
        """Request with EXPIRED certificate returns 403."""
        cert_id = _setup_agent(tmp_path, "ExpBot", actions=["read", "write"])
        _set_cert_status(tmp_path, cert_id, CertStatus.EXPIRED)
        store = FileCertificateStore(tmp_path)
        result = verify_certificate_status(store, cert_id)
        assert result is not None
        assert "CERTIFICATE_EXPIRED" in result

    def test_ip_mapping_resolves_agent(self, tmp_path):
        """Request identified via IP mapping resolves correctly."""
        handler, wfile = self._make_request_handler(
            tmp_path, "MappedBot",
            agent_id_map={"127.0.0.1": "MappedBot"},
        )
        # Mock urlopen so the upstream forward doesn't fail
        mock_resp = MagicMock()
        mock_resp.read.return_value = b'{"ok": true}'
        mock_resp.status = 200
        mock_resp.headers = MagicMock()
        mock_resp.headers.items.return_value = [("Content-Type", "application/json")]
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.object(urllib.request, "urlopen", return_value=mock_resp):
            handler._handle()
        wfile.seek(0)
        raw = wfile.read()
        # Should NOT get certificate_required — IP mapped to valid agent
        assert b"certificate_required" not in raw

    def test_require_certificate_false_allows_all(self, tmp_path):
        """Default require_certificate=False allows requests without headers."""
        handler, wfile = self._make_request_handler(
            tmp_path, "FreeBot",
            require_certificate=False,
        )
        # Mock urlopen so the upstream forward doesn't fail
        mock_resp = MagicMock()
        mock_resp.read.return_value = b'{"ok": true}'
        mock_resp.status = 200
        mock_resp.headers = MagicMock()
        mock_resp.headers.items.return_value = [("Content-Type", "application/json")]
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.object(urllib.request, "urlopen", return_value=mock_resp):
            handler._handle()
        wfile.seek(0)
        raw = wfile.read()
        # Should NOT contain certificate_required
        assert b"certificate_required" not in raw


# ── MCP HTTP Proxy certificate enforcement ───────────────────────────────


class TestMCPHTTPProxyCertEnforcement:
    def test_http_proxy_with_valid_cert(self, tmp_path):
        """MCPHTTPGovernanceProxy with valid cert allows _verify_certificate."""
        _setup_agent(tmp_path, "MCPValidBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPValidBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        assert proxy._verify_certificate("MCPValidBot") is None

    def test_http_proxy_no_cert_returns_error(self, tmp_path):
        """MCPHTTPGovernanceProxy returns error for unknown agent."""
        _setup_agent(tmp_path, "MCPHostBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPHostBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        result = proxy._verify_certificate("nonexistent-agent")
        assert result is not None
        assert "NO_VALID_CERTIFICATE" in result

    def test_http_proxy_suspended_cert(self, tmp_path):
        """MCPHTTPGovernanceProxy returns error for suspended cert."""
        cert_id = _setup_agent(tmp_path, "MCPSuspBot", actions=["read"])
        _set_cert_status(tmp_path, cert_id, CertStatus.SUSPENDED)
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPSuspBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        result = proxy._verify_certificate(cert_id)
        assert result is not None
        assert "CERTIFICATE_SUSPENDED" in result

    def test_http_proxy_revoked_cert(self, tmp_path):
        """MCPHTTPGovernanceProxy returns error for revoked cert."""
        cert_id = _setup_agent(tmp_path, "MCPRevBot", actions=["read"])
        _set_cert_status(tmp_path, cert_id, CertStatus.REVOKED)
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPRevBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        result = proxy._verify_certificate(cert_id)
        assert result is not None
        assert "CERTIFICATE_REVOKED" in result

    def test_http_proxy_expired_cert(self, tmp_path):
        """MCPHTTPGovernanceProxy returns error for expired cert."""
        cert_id = _setup_agent(tmp_path, "MCPExpBot", actions=["read"])
        _set_cert_status(tmp_path, cert_id, CertStatus.EXPIRED)
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPExpBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        result = proxy._verify_certificate(cert_id)
        assert result is not None
        assert "CERTIFICATE_EXPIRED" in result

    def test_http_proxy_require_false_no_store(self, tmp_path):
        """require_certificate=False means no cert_store is created."""
        _setup_agent(tmp_path, "MCPFreeBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPFreeBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=False,
        )
        assert proxy._cert_store is None
        assert proxy._require_certificate is False

    def test_http_proxy_agent_id_map_stored(self, tmp_path):
        """Agent ID map is stored correctly."""
        _setup_agent(tmp_path, "MCPMapBot", actions=["read"])
        agent_map = {"10.0.0.5": "mapped-agent"}
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MCPMapBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
            agent_id_map=agent_map,
        )
        assert proxy._agent_id_map == agent_map


# ── MCP Stdio proxy certificate enforcement ─────────────────────────────


class TestMCPStdioProxyCertEnforcement:
    def test_init_with_valid_cert_succeeds(self, tmp_path):
        """Stdio proxy init with valid certificate succeeds."""
        _setup_agent(tmp_path, "StdioValidBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="StdioValidBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        assert proxy._agent_id == "StdioValidBot"

    def test_init_no_cert_raises(self, tmp_path):
        """Stdio proxy init with no certificate raises ValueError."""
        # Set up a different agent so the store exists, but not the one we ask for
        _setup_agent(tmp_path, "OtherBot", actions=["read"])
        with pytest.raises(ValueError, match="Certificate required"):
            MCPGovernanceProxy(
                agent_id="NonexistentBot",
                upstream_command="echo test",
                base_dir=tmp_path,
                test_mode=True,
                require_certificate=True,
            )

    def test_init_suspended_cert_raises(self, tmp_path):
        """Stdio proxy init with SUSPENDED certificate raises ValueError."""
        cert_id = _setup_agent(tmp_path, "StdioSuspBot", actions=["read"])
        _set_cert_status(tmp_path, cert_id, CertStatus.SUSPENDED)
        with pytest.raises(ValueError, match="CERTIFICATE_SUSPENDED"):
            MCPGovernanceProxy(
                agent_id="StdioSuspBot",
                upstream_command="echo test",
                base_dir=tmp_path,
                test_mode=True,
                require_certificate=True,
            )

    def test_init_revoked_cert_raises(self, tmp_path):
        """Stdio proxy init with REVOKED certificate raises ValueError."""
        cert_id = _setup_agent(tmp_path, "StdioRevBot", actions=["read"])
        _set_cert_status(tmp_path, cert_id, CertStatus.REVOKED)
        with pytest.raises(ValueError, match="CERTIFICATE_REVOKED"):
            MCPGovernanceProxy(
                agent_id="StdioRevBot",
                upstream_command="echo test",
                base_dir=tmp_path,
                test_mode=True,
                require_certificate=True,
            )

    def test_require_false_works_without_cert(self, tmp_path):
        """require_certificate=False works without any certificate."""
        _setup_agent(tmp_path, "StdioFreeBot", actions=["read"])
        proxy = MCPGovernanceProxy(
            agent_id="StdioFreeBot",
            upstream_command="echo test",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=False,
        )
        assert proxy._agent_id == "StdioFreeBot"


# ── Health check endpoint ────────────────────────────────────────────────


class TestHealthCheckEndpoint:
    def test_health_endpoint_attributes(self, tmp_path):
        """Health check returns proxy metadata."""
        _setup_agent(tmp_path, "HealthBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HealthBot",
            upstream_url="http://localhost:9999",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=True,
        )
        # Verify the proxy has the attributes the health endpoint uses
        assert proxy._agent_id == "HealthBot"
        assert proxy._require_certificate is True
        assert proxy._upstream_url == "http://localhost:9999"

    def test_health_endpoint_without_cert_required(self, tmp_path):
        """Health check correctly reflects require_certificate=False."""
        _setup_agent(tmp_path, "HealthFreeBot", actions=["read"])
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HealthFreeBot",
            upstream_url="http://localhost:8000",
            base_dir=tmp_path,
            test_mode=True,
            require_certificate=False,
        )
        assert proxy._require_certificate is False


# ── CLI argument parsing ─────────────────────────────────────────────────


class TestCLICertificateArgs:
    def test_mcp_proxy_require_certificate_flag(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
            "--require-certificate",
        ])
        assert args.require_certificate is True

    def test_mcp_proxy_default_no_require_certificate(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
        ])
        assert args.require_certificate is False

    def test_mcp_proxy_agent_map_arg(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
            "--agent-map", "/tmp/map.json",
        ])
        assert args.agent_map == "/tmp/map.json"

    def test_proxy_require_certificate_flag(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "proxy",
            "--agent-id", "test-bot",
            "--upstream", "http://localhost:8080",
            "--require-certificate",
        ])
        assert args.require_certificate is True

    def test_proxy_default_no_require_certificate(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "proxy",
            "--agent-id", "test-bot",
            "--upstream", "http://localhost:8080",
        ])
        assert args.require_certificate is False

    def test_proxy_agent_map_arg(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "proxy",
            "--agent-id", "test-bot",
            "--upstream", "http://localhost:8080",
            "--agent-map", "/tmp/map.json",
        ])
        assert args.agent_map == "/tmp/map.json"
