"""Tests for generic webhook callback (F-05 Part D).

Minimum 14 tests covering:
  - Token generation and verification
  - POST /v1/overrides/{id}/callback endpoint
  - Outbound webhook firing
"""

from __future__ import annotations

import json
import threading
import time
import uuid
import urllib.error
import urllib.request
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from nomotic.api import NomoticAPIServer, _get_webhook_secret
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.store import MemoryCertificateStore
from nomotic.types import (
    MultiSigOverridePolicy,
    OverrideSignature,
    PendingOverride,
)
from nomotic.webhook_callback import (
    _generate_callback_token,
    _verify_callback_token,
    fire_approval_webhook,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _create_pending(runtime: GovernanceRuntime, required: int = 2) -> PendingOverride:
    now = time.time()
    pending = PendingOverride(
        override_id=f"nmpo-{uuid.uuid4()}",
        action_id="test-action-001",
        agent_id="agent-1",
        override_type="APPROVE",
        policy_id="test-policy",
        required_signatures=required,
        status="PENDING",
        created_at=now,
        expires_at=now + 3600,
        original_verdict="DENY",
        initial_authority="admin-1",
        initial_reason="Test override",
    )
    sig = OverrideSignature(
        signature_id=f"nmosig-{uuid.uuid4()}",
        authority="admin-1",
        role_id=None,
        reason="Initial",
        signed_at=now,
        signature_hash=OverrideSignature.compute_hash(
            pending.override_id, "admin-1", "Initial", now
        ),
    )
    pending.signatures.append(sig)
    runtime._pending_overrides[pending.override_id] = pending
    return pending


class CallbackClient:
    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def post(self, path: str, data: dict) -> tuple[int, Any]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body


@pytest.fixture(scope="module")
def callback_server():
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    runtime = GovernanceRuntime(RuntimeConfig())
    policy = MultiSigOverridePolicy(
        policy_id="test-policy",
        name="Test Policy",
        required_signatures=2,
        eligible_roles=["admin"],
    )
    runtime._multisig_policies.append(policy)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = CallbackClient(f"http://127.0.0.1:{port}")
    return client, runtime


# ── Test 1: _generate_callback_token is deterministic ───────────────────


def test_token_deterministic():
    t1 = _generate_callback_token("nmpo-123", 1000000.0, "secret")
    t2 = _generate_callback_token("nmpo-123", 1000000.0, "secret")
    assert t1 == t2
    assert len(t1) == 64  # SHA-256 hex


# ── Test 2: _verify_callback_token returns True for valid ───────────────


def test_verify_valid_token():
    token = _generate_callback_token("nmpo-123", 1000000.0, "secret")
    assert _verify_callback_token("nmpo-123", 1000000.0, token, "secret") is True


# ── Test 3: _verify_callback_token returns False for tampered ───────────


def test_verify_tampered_token():
    token = _generate_callback_token("nmpo-123", 1000000.0, "secret")
    assert _verify_callback_token("nmpo-123", 1000000.0, token + "x", "secret") is False


# ── Test 4: _verify_callback_token returns False for wrong pending_id ───


def test_verify_wrong_pending_id():
    token = _generate_callback_token("nmpo-123", 1000000.0, "secret")
    assert _verify_callback_token("nmpo-456", 1000000.0, token, "secret") is False


# ── Test 5: POST callback with valid token + approve returns 200 ────────


def test_callback_approve(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime, required=3)

    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "approve",
            "authority": "admin-2",
            "reason": "Approved via callback",
            "callback_token": token,
        },
    )
    assert status == 200
    assert body["decision"] == "approve"


# ── Test 6: POST callback approve response contains decision field ──────


def test_callback_approve_response_fields(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime, required=3)

    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "approve",
            "authority": "admin-2",
            "reason": "OK",
            "callback_token": token,
        },
    )
    assert status == 200
    assert body["decision"] == "approve"
    assert "pending_id" in body
    assert "status" in body


# ── Test 7: POST callback with valid token + deny returns 200 ───────────


def test_callback_deny(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)

    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "deny",
            "authority": "admin-2",
            "reason": "Denied via callback",
            "callback_token": token,
        },
    )
    assert status == 200
    assert body["status"] == "DENIED"


# ── Test 8: POST callback deny response contains status=DENIED ──────────


def test_callback_deny_status(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)

    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "deny",
            "authority": "admin-2",
            "reason": "No",
            "callback_token": token,
        },
    )
    assert body["decision"] == "deny"
    assert body["status"] == "DENIED"


# ── Test 9: POST callback with invalid token returns 401 ────────────────


def test_callback_invalid_token(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "approve",
            "authority": "admin-2",
            "reason": "Bad token",
            "callback_token": "invalid-token-value",
        },
    )
    assert status == 401


# ── Test 10: POST callback for expired override returns 410 ─────────────


def test_callback_expired(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)

    # Generate valid token before expiring
    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    # Now expire it
    pending.expires_at = time.time() - 10

    # Regenerate token with new expires_at for signature to pass
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "approve",
            "authority": "admin-2",
            "reason": "Too late",
            "callback_token": token,
        },
    )
    assert status == 410


# ── Test 11: POST callback with unknown authority (registry) returns 403


def test_callback_unknown_authority(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)

    webhook_secret = _get_webhook_secret(runtime)
    token = _generate_callback_token(
        pending.override_id, pending.expires_at, webhook_secret
    )

    # Set up a mock authority registry that rejects
    mock_registry = MagicMock()
    mock_registry.is_valid.return_value = False
    runtime._authority_registry = mock_registry

    status, body = client.post(
        f"/v1/overrides/{pending.override_id}/callback",
        {
            "decision": "approve",
            "authority": "unknown-person",
            "reason": "Who am I?",
            "callback_token": token,
        },
    )
    assert status == 403
    runtime._authority_registry = None  # cleanup


# ── Test 12: POST callback for already-resolved returns 404 ─────────────


def test_callback_already_resolved(callback_server):
    client, runtime = callback_server
    runtime._pending_overrides.clear()

    status, body = client.post(
        "/v1/overrides/nmpo-nonexistent/callback",
        {
            "decision": "approve",
            "authority": "admin-2",
            "reason": "Gone",
            "callback_token": "anything",
        },
    )
    assert status == 404


# ── Test 13: Outbound webhook fires with callback_url and token ─────────


def test_outbound_webhook_fires():
    """Verify fire_approval_webhook constructs correct payload."""
    mock_runtime = MagicMock()
    pending = _create_pending.__wrapped__(MagicMock()) if hasattr(_create_pending, '__wrapped__') else None

    # Create pending manually
    now = time.time()
    pending = PendingOverride(
        override_id="nmpo-webhook-test",
        action_id="test-action-001",
        agent_id="agent-1",
        override_type="APPROVE",
        policy_id="test-policy",
        required_signatures=2,
        status="PENDING",
        created_at=now,
        expires_at=now + 3600,
        original_verdict="DENY",
        initial_authority="admin-1",
        initial_reason="Test",
    )

    # Call directly instead of in thread
    from nomotic.webhook_callback import _send_approval_webhook
    _send_approval_webhook(
        runtime=mock_runtime,
        pending=pending,
        approval_webhook_url="https://example.com/webhook",
        server_host="governance.example.com",
        webhook_secret="test-secret",
    )

    mock_runtime._dispatch_webhook.assert_called_once()
    call_args = mock_runtime._dispatch_webhook.call_args
    event_type = call_args[0][0]
    payload = call_args[0][2]
    assert event_type == "ESCALATION_PENDING_APPROVAL"
    assert "callback_url" in payload
    assert "callback_token" in payload


# ── Test 14: Outbound webhook payload contains correct fields ───────────


def test_outbound_webhook_payload_fields():
    mock_runtime = MagicMock()
    now = time.time()
    pending = PendingOverride(
        override_id="nmpo-payload-test",
        action_id="test-action-002",
        agent_id="agent-2",
        override_type="REVOKE",
        policy_id="test-policy-2",
        required_signatures=3,
        status="PENDING",
        created_at=now,
        expires_at=now + 7200,
        original_verdict="ALLOW",
        initial_authority="admin-1",
        initial_reason="Revoke test",
    )

    from nomotic.webhook_callback import _send_approval_webhook
    _send_approval_webhook(
        runtime=mock_runtime,
        pending=pending,
        approval_webhook_url="https://example.com/webhook",
        server_host="gov.example.com",
        webhook_secret="test-secret",
    )

    call_args = mock_runtime._dispatch_webhook.call_args
    payload = call_args[0][2]

    assert payload["event"] == "ESCALATION_PENDING_APPROVAL"
    assert payload["pending_id"] == "nmpo-payload-test"
    assert payload["agent_id"] == "agent-2"
    assert payload["action_type"] == "REVOKE"
    assert payload["signatures_required"] == 3
    assert "callback_url" in payload
    assert "gov.example.com" in payload["callback_url"]
    assert "callback_token" in payload
    assert "callback_expires_at" in payload
