"""Tests for GovernedAgentBase — framework governance wrapper."""

from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import MagicMock, patch

import pytest

from nomotic.governed_agent import (
    GovernanceVetoError,
    GovernedAgentBase,
    GovResult,
    OutputResult,
)
from nomotic.types import GovernanceVerdict, Verdict


# ── Helpers ──────────────────────────────────────────────────────────


def _make_certificate(
    agent_id: str = "test-agent",
    trust_score: float = 0.5,
    zone_path: str = "global",
    archetype: str = "general",
) -> MagicMock:
    cert = MagicMock()
    cert.agent_id = agent_id
    cert.certificate_id = "nmc-test-123"
    cert.trust_score = trust_score
    cert.zone_path = zone_path
    cert.archetype = archetype
    return cert


def _make_verdict(
    verdict: Verdict = Verdict.ALLOW,
    ucs: float = 0.85,
    action_id: str = "abc123",
) -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=verdict,
        ucs=ucs,
    )


def _make_runtime(verdict: GovernanceVerdict | None = None) -> MagicMock:
    runtime = MagicMock()
    runtime.evaluate.return_value = verdict or _make_verdict()
    return runtime


def _make_output_governor(
    verdict_str: str = "PASS",
    redacted_output: str | None = None,
) -> MagicMock:
    gov = MagicMock()
    result = MagicMock()
    result.verdict = verdict_str
    result.redacted_output = redacted_output
    gov.evaluate.return_value = result
    return gov


# ── Tests: govern_action ─────────────────────────────────────────────


class TestGovernAction:
    """Tests for govern_action() pre-execution governance."""

    def test_allow_verdict_returns_allowed(self):
        """1. govern_action() with ALLOW verdict returns GovResult with allowed=True."""
        runtime = _make_runtime(_make_verdict(Verdict.ALLOW, ucs=0.9))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        result = agent.govern_action("read", "patient_records")

        assert isinstance(result, GovResult)
        assert result.allowed is True
        assert result.verdict == "ALLOW"
        assert result.ucs_score == 0.9

    def test_deny_verdict_returns_not_allowed(self):
        """2. govern_action() with DENY verdict returns GovResult with allowed=False."""
        runtime = _make_runtime(_make_verdict(Verdict.DENY, ucs=0.2))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        result = agent.govern_action("delete", "all_records")

        assert result.allowed is False
        assert result.verdict == "DENY"

    def test_escalate_verdict_returns_not_allowed(self):
        """3. govern_action() with ESCALATE verdict returns GovResult with allowed=False."""
        runtime = _make_runtime(_make_verdict(Verdict.ESCALATE, ucs=0.5))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        result = agent.govern_action("transfer", "funds")

        assert result.allowed is False
        assert result.verdict == "ESCALATE"


# ── Tests: governed_run ──────────────────────────────────────────────


class TestGovernedRun:
    """Tests for governed_run() full lifecycle."""

    def test_allow_calls_execute_fn(self):
        """4. governed_run() with ALLOW calls execute_fn and returns its result."""
        runtime = _make_runtime(_make_verdict(Verdict.ALLOW))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        output = agent.governed_run(
            action_type="read",
            target="data",
            execute_fn=lambda: "execution result",
        )

        assert output == "execution result"

    def test_deny_raises_veto_error(self):
        """5. governed_run() with DENY raises GovernanceVetoError."""
        runtime = _make_runtime(_make_verdict(Verdict.DENY, ucs=0.1))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        with pytest.raises(GovernanceVetoError) as exc_info:
            agent.governed_run(
                action_type="delete",
                target="records",
                execute_fn=lambda: "should not run",
            )

        assert exc_info.value.verdict == "DENY"

    def test_block_raises_veto_error(self):
        """6. governed_run() with BLOCK (SUSPEND) raises GovernanceVetoError."""
        runtime = _make_runtime(_make_verdict(Verdict.SUSPEND, ucs=0.0))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        with pytest.raises(GovernanceVetoError):
            agent.governed_run(
                action_type="admin",
                target="system",
                execute_fn=lambda: "blocked",
            )

    def test_veto_error_fields(self):
        """7. GovernanceVetoError contains correct verdict, ucs_score, record_id."""
        runtime = _make_runtime(
            _make_verdict(Verdict.DENY, ucs=0.25, action_id="rec-xyz")
        )
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        with pytest.raises(GovernanceVetoError) as exc_info:
            agent.governed_run("write", "secrets", execute_fn=lambda: "x")

        err = exc_info.value
        assert err.verdict == "DENY"
        assert err.ucs_score == 0.25
        assert err.record_id == "rec-xyz"

    def test_deny_does_not_call_execute_fn(self):
        """8. governed_run() does not call execute_fn when governance denies."""
        runtime = _make_runtime(_make_verdict(Verdict.DENY))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        called = []

        def spy_fn():
            called.append(True)
            return "result"

        with pytest.raises(GovernanceVetoError):
            agent.governed_run("delete", "all", execute_fn=spy_fn)

        assert called == [], "execute_fn should not be called when governance denies"


# ── Tests: validate_output ───────────────────────────────────────────


class TestValidateOutput:
    """Tests for validate_output() post-generation validation."""

    def test_no_governor_returns_pass(self):
        """9. validate_output() with no OutputGovernor returns OUTPUT_PASS."""
        runtime = _make_runtime()
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert, output_governor=None)

        result = agent.validate_output("some output")

        assert isinstance(result, OutputResult)
        assert result.verdict == "OUTPUT_PASS"
        assert result.output == "some output"
        assert result.redacted is False

    def test_with_governor_passes_output(self):
        """10. validate_output() with OutputGovernor passes output through."""
        og = _make_output_governor(verdict_str="PASS")
        runtime = _make_runtime()
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert, output_governor=og)

        result = agent.validate_output("clean output", action_type="read")

        og.evaluate.assert_called_once()
        call_kwargs = og.evaluate.call_args
        assert call_kwargs.kwargs.get("output") == "clean output" or \
               call_kwargs[1].get("output") == "clean output"

    def test_redact_returns_redacted_output(self):
        """11. validate_output() OUTPUT_REDACT: returned output is redacted version."""
        og = _make_output_governor(
            verdict_str="REDACT",
            redacted_output="[REDACTED] safe output",
        )
        runtime = _make_runtime()
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert, output_governor=og)

        result = agent.validate_output("sensitive data here")

        assert result.verdict == "REDACT"
        assert result.output == "[REDACTED] safe output"
        assert result.redacted is True

    def test_pass_returns_original_output(self):
        """12. validate_output() OUTPUT_PASS: returned output is original."""
        og = _make_output_governor(verdict_str="PASS")
        runtime = _make_runtime()
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert, output_governor=og)

        result = agent.validate_output("original text")

        assert result.output == "original text"
        assert result.redacted is False


# ── Tests: governed_run + output validation ──────────────────────────


class TestGovernedRunWithOutput:
    """Tests for governed_run() calling validate_output()."""

    def test_governed_run_validates_output(self):
        """13. governed_run() calls validate_output() on execute_fn result when allowed."""
        og = _make_output_governor(
            verdict_str="REDACT",
            redacted_output="[SAFE] output",
        )
        runtime = _make_runtime(_make_verdict(Verdict.ALLOW))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert, output_governor=og)

        result = agent.governed_run(
            action_type="read",
            target="data",
            execute_fn=lambda: "raw sensitive output",
        )

        assert result == "[SAFE] output"
        og.evaluate.assert_called_once()


# ── Tests: example files compile ─────────────────────────────────────


class TestExamplesCompile:
    """14. Each example file compiles without error."""

    @pytest.mark.parametrize(
        "example_path",
        [
            "examples/langgraph_governed_agent.py",
            "examples/crewai_governed_agent.py",
            "examples/openai_governed_agent.py",
        ],
    )
    def test_example_compiles(self, example_path):
        with open(example_path) as f:
            source = f.read()
        compile(source, example_path, "exec")


# ── Tests: GovResult.from_evaluation ─────────────────────────────────


class TestGovResult:
    """Additional tests for GovResult construction."""

    def test_from_evaluation_with_verdict_enum(self):
        """GovResult.from_evaluation works with GovernanceVerdict."""
        verdict = _make_verdict(Verdict.ALLOW, ucs=0.95, action_id="id-001")
        result = GovResult.from_evaluation(verdict)

        assert result.verdict == "ALLOW"
        assert result.ucs_score == 0.95
        assert result.record_id == "id-001"
        assert result.allowed is True

    def test_from_evaluation_deny(self):
        """GovResult.from_evaluation correctly marks DENY as not allowed."""
        verdict = _make_verdict(Verdict.DENY, ucs=0.1)
        result = GovResult.from_evaluation(verdict)

        assert result.allowed is False


# ── Tests: GovernedAgentBase construction ────────────────────────────


class TestGovernedAgentBaseInit:
    """Tests for GovernedAgentBase initialization."""

    def test_default_zone_from_certificate(self):
        """default_zone is taken from certificate zone_path."""
        runtime = _make_runtime()
        cert = _make_certificate(zone_path="org/team")
        agent = GovernedAgentBase(runtime, cert)
        assert agent.default_zone == "org/team"

    def test_explicit_default_zone(self):
        """Explicit default_zone overrides certificate."""
        runtime = _make_runtime()
        cert = _make_certificate(zone_path="org/team")
        agent = GovernedAgentBase(runtime, cert, default_zone="custom/zone")
        assert agent.default_zone == "custom/zone"

    def test_govern_action_passes_context_overrides(self):
        """Context overrides are passed through to AgentContext."""
        runtime = _make_runtime(_make_verdict(Verdict.ALLOW))
        cert = _make_certificate()
        agent = GovernedAgentBase(runtime, cert)

        agent.govern_action(
            "read", "data",
            context_overrides={"session_id": "sess-abc"},
        )

        # Verify runtime.evaluate was called
        runtime.evaluate.assert_called_once()
        _, ctx = runtime.evaluate.call_args[0]
        assert ctx.session_id == "sess-abc"
