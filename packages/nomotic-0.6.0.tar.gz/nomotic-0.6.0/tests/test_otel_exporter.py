"""Tests for the OpenTelemetry exporter and Prometheus metrics."""

from __future__ import annotations

import threading

import pytest

from nomotic.otel_exporter import NomoticOtelExporter, PrometheusMetrics


# ── PrometheusMetrics ──────────────────────────────────────────────────


class TestPrometheusMetrics:
    def test_counter(self) -> None:
        m = PrometheusMetrics()
        m.inc("requests_total", {"method": "GET"})
        m.inc("requests_total", {"method": "GET"})
        output = m.format_prometheus()
        assert "requests_total" in output
        # Two increments should yield 2
        assert '2' in output

    def test_counter_no_labels(self) -> None:
        m = PrometheusMetrics()
        m.inc("simple_counter")
        m.inc("simple_counter")
        m.inc("simple_counter")
        output = m.format_prometheus()
        assert "simple_counter 3" in output

    def test_gauge(self) -> None:
        m = PrometheusMetrics()
        m.set_gauge("trust_score", 0.85, {"agent_id": "bot1"})
        output = m.format_prometheus()
        assert "0.85" in output
        assert "# TYPE trust_score gauge" in output

    def test_gauge_overwrite(self) -> None:
        m = PrometheusMetrics()
        m.set_gauge("trust_score", 0.85, {"agent_id": "bot1"})
        m.set_gauge("trust_score", 0.42, {"agent_id": "bot1"})
        output = m.format_prometheus()
        assert "0.42" in output
        # Old value should be replaced
        assert "0.85" not in output

    def test_histogram(self) -> None:
        m = PrometheusMetrics()
        m.observe("latency", 1.5)
        m.observe("latency", 2.5)
        m.observe("latency", 3.0)
        output = m.format_prometheus()
        assert "# TYPE latency summary" in output
        assert "latency_count 3" in output
        assert "latency_sum 7.0" in output

    def test_record_evaluation(self) -> None:
        m = PrometheusMetrics()
        m.record_evaluation("TestBot", "ALLOW", 0.9, 2, 1.5)
        m.record_evaluation("TestBot", "DENY", 0.0, 1, 0.8)
        output = m.format_prometheus()
        assert "nomotic_evaluation_total" in output
        assert "nomotic_evaluation_denied_total" in output
        assert "nomotic_evaluation_duration_ms" in output
        assert "nomotic_evaluation_ucs" in output

    def test_record_trust(self) -> None:
        m = PrometheusMetrics()
        m.record_trust("agent-1", 0.75)
        output = m.format_prometheus()
        assert "nomotic_trust_score" in output
        assert "0.75" in output

    def test_record_drift(self) -> None:
        m = PrometheusMetrics()
        m.record_drift("agent-1", 0.35)
        output = m.format_prometheus()
        assert "nomotic_drift_score" in output
        assert "0.35" in output

    def test_format_empty(self) -> None:
        m = PrometheusMetrics()
        output = m.format_prometheus()
        # Should produce just a newline (no metrics recorded)
        assert output == "\n"

    def test_label_key_formatting(self) -> None:
        key = PrometheusMetrics._label_key("metric", {"a": "1", "b": "2"})
        assert key == 'metric{a="1",b="2"}'

    def test_label_key_no_labels(self) -> None:
        key = PrometheusMetrics._label_key("metric", None)
        assert key == "metric"

    def test_thread_safety(self) -> None:
        """Concurrent increments should not lose counts."""
        m = PrometheusMetrics()
        n = 1000

        def bump() -> None:
            for _ in range(n):
                m.inc("concurrent_counter")

        threads = [threading.Thread(target=bump) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        output = m.format_prometheus()
        assert f"concurrent_counter {4 * n}" in output

    def test_multiple_label_sets(self) -> None:
        m = PrometheusMetrics()
        m.inc("requests_total", {"method": "GET"})
        m.inc("requests_total", {"method": "POST"})
        output = m.format_prometheus()
        assert 'method="GET"' in output
        assert 'method="POST"' in output


# ── NomoticOtelExporter (graceful degradation) ────────────────────────


class TestOtelExporterNoop:
    """OTel exporter should not crash if opentelemetry is not installed."""

    def test_no_crash_without_otel(self) -> None:
        exporter = NomoticOtelExporter()
        # These should all be no-ops without crashing
        exporter.record_evaluation(
            "bot", "read", "db", "ALLOW", 0.9, 2, 0.5, 0.51, 1.0
        )
        exporter.record_trust_change("bot", 0.51, 0.01)
        exporter.record_drift("bot", 0.3, "moderate")
        exporter.record_interrupt("bot", "trust_threshold")

    def test_service_name_stored(self) -> None:
        exporter = NomoticOtelExporter(service_name="my-service")
        assert exporter._service_name == "my-service"

    def test_otel_not_available_flag(self) -> None:
        """Without opentelemetry installed, _otel_available should be False."""
        exporter = NomoticOtelExporter()
        # This will be False if opentelemetry is not installed in the test env
        # (which is expected — it's an optional dependency)
        assert isinstance(exporter._otel_available, bool)

    def test_record_evaluation_with_dimensions(self) -> None:
        exporter = NomoticOtelExporter()
        exporter.record_evaluation(
            agent_id="bot",
            action="write",
            target="fs",
            verdict="DENY",
            ucs=0.1,
            tier=1,
            trust_before=0.5,
            trust_after=0.4,
            duration_ms=2.3,
            dimension_scores={"safety": 0.1, "privacy": 0.3},
            vetoed_by=["safety"],
        )

    def test_record_evaluation_with_no_optional_args(self) -> None:
        exporter = NomoticOtelExporter()
        exporter.record_evaluation(
            agent_id="bot",
            action="read",
            target="db",
            verdict="ALLOW",
            ucs=0.95,
            tier=3,
            trust_before=0.8,
            trust_after=0.81,
            duration_ms=0.5,
        )


# ── Import from package ──────────────────────────────────────────────


class TestPackageExports:
    def test_importable_from_nomotic(self) -> None:
        from nomotic import NomoticOtelExporter, PrometheusMetrics

        assert NomoticOtelExporter is not None
        assert PrometheusMetrics is not None
