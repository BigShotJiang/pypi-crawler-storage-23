"""Tests for the Playground API (F-17)."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


# ── Test fixtures ───────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class PlaygroundTestClient:
    """HTTP client for testing playground endpoints."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str, accept: str = "application/json") -> tuple[int, Any, dict[str, str]]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("Accept", accept)
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                headers = dict(resp.headers)
                ct = resp.headers.get("Content-Type", "")
                if "json" in ct:
                    return resp.status, json.loads(raw), headers
                return resp.status, raw, headers
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = raw
            return e.code, body, {}

    def post(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        accept: str = "application/json",
    ) -> tuple[int, Any, dict[str, str]]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Accept": accept,
                },
            )
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                headers = dict(resp.headers)
                ct = resp.headers.get("Content-Type", "")
                if "json" in ct:
                    return resp.status, json.loads(raw), headers
                return resp.status, raw, headers
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = raw
            return e.code, body, {}


@pytest.fixture(scope="module")
def playground_server() -> PlaygroundTestClient:
    """Start a test API server with playground enabled."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=port,
        ui_enabled=True,
        playground_enabled=True,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.5)

    client = PlaygroundTestClient(f"http://127.0.0.1:{port}")
    yield client
    server.shutdown()


@pytest.fixture(scope="module")
def no_playground_server() -> PlaygroundTestClient:
    """Start a test API server with playground DISABLED."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=port,
        ui_enabled=True,
        playground_enabled=False,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.5)

    client = PlaygroundTestClient(f"http://127.0.0.1:{port}")
    yield client
    server.shutdown()


# ── Helper: standard evaluate payload ──────────────────────────────────


def _eval_payload(
    action_type: str = "read",
    target: str = "customer_records",
    archetype: str = "customer-experience",
    trust_score: float = 0.8,
    reversible: bool = True,
    trust_low: float = 0.35,
    trust_high: float = 0.65,
    weight_overrides: dict[str, float] | None = None,
) -> dict[str, Any]:
    return {
        "action": {
            "type": action_type,
            "target": target,
            "reversible": reversible,
            "parameters": {},
        },
        "agent": {
            "archetype": archetype,
            "trust_score": trust_score,
            "compliance_preset": "",
        },
        "config": {
            "trust_low_threshold": trust_low,
            "trust_high_threshold": trust_high,
            "dimension_weight_overrides": weight_overrides or {},
        },
    }


# ═══════════════════════════════════════════════════════════════════════
# Test 1: POST /v1/playground/evaluate returns 200 with verdict field
# ═══════════════════════════════════════════════════════════════════════


class TestPlaygroundEvaluateBasic:
    def test_evaluate_returns_200_with_verdict(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(),
        )
        assert status == 200
        assert "verdict" in body
        assert body["verdict"] in ("ALLOW", "DENY", "ESCALATE", "MODIFY", "SUSPEND")

    # ═══════════════════════════════════════════════════════════════════
    # Test 2: healthcare-agent + high trust → ALLOW for normal read
    # ═══════════════════════════════════════════════════════════════════

    def test_healthcare_high_trust_allow(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(
                action_type="read",
                target="patient_records",
                archetype="healthcare-agent",
                trust_score=0.85,
            ),
        )
        assert status == 200
        assert body["verdict"] == "ALLOW"

    # ═══════════════════════════════════════════════════════════════════
    # Test 3: scope violation → DENY with veto_triggered
    # ═══════════════════════════════════════════════════════════════════

    def test_scope_violation_deny(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        # Force scope_compliance weight very high and set a custom archetype
        # that would trigger scope violations
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(
                action_type="delete_all",
                target="system_root",
                archetype="healthcare-agent",
                trust_score=0.9,
                weight_overrides={"scope_compliance": 5.0},
            ),
        )
        assert status == 200
        # The result should reflect governance concern (not ALLOW)
        # since delete_all is a destructive action on system_root
        assert body["verdict"] in ("DENY", "ESCALATE", "MODIFY")

    # ═══════════════════════════════════════════════════════════════════
    # Test 4: trust_score in deliberation range → ESCALATE
    # ═══════════════════════════════════════════════════════════════════

    def test_deliberation_range_escalate(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(
                trust_score=0.42,
                trust_low=0.35,
                trust_high=0.65,
            ),
        )
        assert status == 200
        # Agent trust in deliberation range — should escalate or the UCS
        # reflects the middle ground
        assert body["verdict"] in ("ALLOW", "ESCALATE", "DENY")
        assert "ucs_score" in body

    # ═══════════════════════════════════════════════════════════════════
    # Test 5: low trust + irreversible action
    # ═══════════════════════════════════════════════════════════════════

    def test_low_trust_irreversible(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(
                action_type="delete",
                target="production_database",
                trust_score=0.15,
                reversible=False,
                trust_low=0.35,
                trust_high=0.65,
            ),
        )
        assert status == 200
        # Low trust should push toward deny/escalate/modify
        assert body["verdict"] in ("DENY", "ESCALATE", "MODIFY")

    # ═══════════════════════════════════════════════════════════════════
    # Test 6: dimension_weight_overrides appear in config_used
    # ═══════════════════════════════════════════════════════════════════

    def test_weight_overrides_in_config(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(
                weight_overrides={"scope_compliance": 3.5, "ethical_alignment": 4.0},
            ),
        )
        assert status == 200
        ew = body["config_used"]["effective_weights"]
        assert ew["scope_compliance"] == 3.5
        assert ew["ethical_alignment"] == 4.0

    # ═══════════════════════════════════════════════════════════════════
    # Test 7: missing action.type → 400
    # ═══════════════════════════════════════════════════════════════════

    def test_missing_action_type_400(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        payload = _eval_payload()
        del payload["action"]["type"]
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate", payload,
        )
        assert status == 400
        assert "action.type" in body.get("message", "")

    # ═══════════════════════════════════════════════════════════════════
    # Test 8: unknown archetype → 400
    # ═══════════════════════════════════════════════════════════════════

    def test_unknown_archetype_400(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(archetype="nonexistent-archetype-xyz"),
        )
        assert status == 400
        assert "Unknown archetype" in body.get("message", "")

    # ═══════════════════════════════════════════════════════════════════
    # Test 9: playground evaluate does NOT write to main AuditStore
    # ═══════════════════════════════════════════════════════════════════

    def test_no_main_audit_pollution(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        # Make a few evaluations — since we have no runtime with a
        # persistent audit store, the playground uses its own list
        for _ in range(3):
            playground_server.post(
                "/v1/playground/evaluate", _eval_payload(),
            )
        # The main audit trail endpoint should not have these
        # playground-agent records (if runtime is None, audit returns
        # empty or 404 — either way, playground data isn't there)
        status, body, _ = playground_server.get("/v1/health")
        assert status == 200
        # The key assertion: playground evaluations use ephemeral runtimes
        # and are stored in ctx.playground_audit, not the main store


# ═══════════════════════════════════════════════════════════════════════
# Test 10: GET /v1/playground/archetypes returns ≥ 6 archetypes
# ═══════════════════════════════════════════════════════════════════════


class TestPlaygroundArchetypes:
    def test_archetypes_count(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get("/v1/playground/archetypes")
        assert status == 200
        assert isinstance(body, list)
        assert len(body) >= 6

    # ═══════════════════════════════════════════════════════════════════
    # Test 11: each archetype has dimension_weights with 14 keys
    # ═══════════════════════════════════════════════════════════════════

    def test_archetypes_dimension_weights(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get("/v1/playground/archetypes")
        assert status == 200
        for arch in body:
            assert "dimension_weights" in arch
            assert len(arch["dimension_weights"]) == 14, (
                f"Archetype {arch['name']} has {len(arch['dimension_weights'])} "
                f"dimension weights, expected 14"
            )


# ═══════════════════════════════════════════════════════════════════════
# Test 12: GET /v1/playground/presets returns ≥ 4 presets
# ═══════════════════════════════════════════════════════════════════════


class TestPlaygroundPresets:
    def test_presets_count(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get("/v1/playground/presets")
        assert status == 200
        assert isinstance(body, list)
        assert len(body) >= 4


# ═══════════════════════════════════════════════════════════════════════
# Test 13: export-config returns Content-Disposition attachment
# ═══════════════════════════════════════════════════════════════════════


class TestPlaygroundExport:
    def test_export_content_disposition(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, headers = playground_server.post(
            "/v1/playground/export-config",
            _eval_payload(),
            accept="application/x-yaml",
        )
        assert status == 200
        cd = headers.get("Content-Disposition", "")
        assert "attachment" in cd
        assert "nomotic.yaml" in cd

    # ═══════════════════════════════════════════════════════════════════
    # Test 14: exported YAML is valid
    # ═══════════════════════════════════════════════════════════════════

    def test_exported_yaml_valid(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        import yaml

        status, body, _ = playground_server.post(
            "/v1/playground/export-config",
            _eval_payload(),
            accept="application/x-yaml",
        )
        assert status == 200
        if isinstance(body, bytes):
            content = body.decode("utf-8")
        else:
            content = str(body)
        parsed = yaml.safe_load(content)
        assert isinstance(parsed, dict)
        assert "governance" in parsed or "version" in parsed


# ═══════════════════════════════════════════════════════════════════════
# Playground UI Tests (F-17 Part 2)
# ═══════════════════════════════════════════════════════════════════════


class TestPlaygroundUI:
    # Test 15: GET /ui/playground returns 200 when enabled
    def test_playground_ui_200_when_enabled(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get(
            "/ui/playground", accept="text/html",
        )
        assert status == 200

    # Test 16: GET /ui/playground returns 404 when disabled
    def test_playground_ui_404_when_disabled(
        self, no_playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = no_playground_server.get(
            "/ui/playground", accept="text/html",
        )
        assert status == 404

    # Test 17: playground HTML contains archetype dropdown
    def test_playground_html_archetype_dropdown(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get(
            "/ui/playground", accept="text/html",
        )
        assert status == 200
        html = body.decode("utf-8") if isinstance(body, bytes) else str(body)
        assert "archetype" in html.lower()
        assert "select" in html.lower() or "dropdown" in html.lower()

    # Test 18: playground HTML contains trust score slider
    def test_playground_html_trust_slider(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, _ = playground_server.get(
            "/ui/playground", accept="text/html",
        )
        assert status == 200
        html = body.decode("utf-8") if isinstance(body, bytes) else str(body)
        assert "trust" in html.lower()
        assert 'type="range"' in html

    # Test 19: POST evaluate with Accept: text/html returns HTML
    def test_evaluate_html_response(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        status, body, headers = playground_server.post(
            "/v1/playground/evaluate",
            _eval_payload(),
            accept="text/html",
        )
        assert status == 200
        html = body.decode("utf-8") if isinstance(body, bytes) else str(body)
        # Should contain verdict text
        assert any(v in html for v in ("ALLOW", "DENY", "ESCALATE", "MODIFY", "SUSPEND"))

    # Test 20: export-config returns valid YAML as attachment
    def test_export_yaml_attachment(
        self, playground_server: PlaygroundTestClient,
    ) -> None:
        import yaml

        status, body, headers = playground_server.post(
            "/v1/playground/export-config",
            _eval_payload(),
            accept="application/x-yaml",
        )
        assert status == 200
        cd = headers.get("Content-Disposition", "")
        assert "attachment" in cd
        content = body.decode("utf-8") if isinstance(body, bytes) else str(body)
        parsed = yaml.safe_load(content)
        assert parsed is not None
