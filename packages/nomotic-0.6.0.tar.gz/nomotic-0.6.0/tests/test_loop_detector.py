"""Tests for the loop detection monitor — governance-aware repetitive action detection."""

import time

import pytest

from nomotic.interrupt import ExecutionHandle, InterruptAuthority
from nomotic.loop_detector import LoopDetector, LoopDetectorConfig, LoopEvent
from nomotic.types import Action, InterruptRequest, Severity


def _action(
    agent_id: str = "agent-1",
    action_type: str = "write",
    target: str = "resource-a",
) -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


# ── 1. Basic detection tests ────────────────────────────────────────


class TestBasicDetection:
    def test_no_event_for_first_occurrence(self):
        detector = LoopDetector()
        event = detector.record_action(_action())
        assert event is None

    def test_no_event_below_warning_threshold(self):
        detector = LoopDetector()
        for _ in range(4):  # default warning_threshold is 5
            event = detector.record_action(_action())
        assert event is None

    def test_warning_at_warning_threshold(self):
        detector = LoopDetector()
        event = None
        for _ in range(5):
            event = detector.record_action(_action())
        assert event is not None
        assert event.level == "warning"
        assert event.count == 5

    def test_halt_at_halt_threshold(self):
        detector = LoopDetector()
        event = None
        for _ in range(10):
            event = detector.record_action(_action())
        assert event is not None
        assert event.level == "halt"
        assert event.count == 10

    def test_different_action_types_tracked_separately(self):
        detector = LoopDetector()
        for _ in range(4):
            detector.record_action(_action(action_type="write"))
        for _ in range(4):
            detector.record_action(_action(action_type="delete"))
        # Neither should have crossed warning threshold
        count_write = detector.get_repetition_count("agent-1", "write", "resource-a")
        count_delete = detector.get_repetition_count("agent-1", "delete", "resource-a")
        assert count_write == 4
        assert count_delete == 4

    def test_same_action_different_targets_tracked_separately(self):
        detector = LoopDetector()
        for _ in range(4):
            detector.record_action(_action(target="resource-a"))
        for _ in range(4):
            detector.record_action(_action(target="resource-b"))
        count_a = detector.get_repetition_count("agent-1", "write", "resource-a")
        count_b = detector.get_repetition_count("agent-1", "write", "resource-b")
        assert count_a == 4
        assert count_b == 4

    def test_event_count_matches_actual_repetitions(self):
        detector = LoopDetector()
        for i in range(7):
            event = detector.record_action(_action())
        assert event is not None
        assert event.count == 7

    def test_loop_event_to_dict(self):
        detector = LoopDetector()
        for _ in range(5):
            event = detector.record_action(_action())
        assert event is not None
        d = event.to_dict()
        assert d["agent_id"] == "agent-1"
        assert d["action_type"] == "write"
        assert d["target"] == "resource-a"
        assert d["count"] == 5
        assert d["level"] == "warning"


# ── 2. Time window tests ────────────────────────────────────────────


class TestTimeWindow:
    def test_actions_outside_window_not_counted(self):
        config = LoopDetectorConfig(window_seconds=0.2)
        detector = LoopDetector(config)
        for _ in range(3):
            detector.record_action(_action())
        time.sleep(0.3)
        # Actions should be evicted
        count = detector.get_repetition_count("agent-1", "write", "resource-a")
        assert count == 0

    def test_eviction_removes_old_entries(self):
        config = LoopDetectorConfig(window_seconds=0.15)
        detector = LoopDetector(config)
        for _ in range(3):
            detector.record_action(_action())
        time.sleep(0.2)
        # Record new action — old ones should be evicted
        event = detector.record_action(_action())
        assert event is None  # count is 1, not 4
        count = detector.get_repetition_count("agent-1", "write", "resource-a")
        assert count == 1

    def test_count_resets_after_window_expires(self):
        config = LoopDetectorConfig(window_seconds=0.15, warning_threshold=3)
        detector = LoopDetector(config)
        for _ in range(3):
            detector.record_action(_action())
        time.sleep(0.2)
        # After expiry, count should reset and no warning on new action
        event = detector.record_action(_action())
        assert event is None

    def test_actions_within_window_are_counted(self):
        config = LoopDetectorConfig(window_seconds=10.0, warning_threshold=5)
        detector = LoopDetector(config)
        for _ in range(5):
            event = detector.record_action(_action())
        assert event is not None
        assert event.level == "warning"
        assert event.count == 5


# ── 3. Configuration tests ──────────────────────────────────────────


class TestConfiguration:
    def test_custom_warning_threshold(self):
        config = LoopDetectorConfig(warning_threshold=3)
        detector = LoopDetector(config)
        for _ in range(3):
            event = detector.record_action(_action())
        assert event is not None
        assert event.level == "warning"

    def test_custom_halt_threshold(self):
        config = LoopDetectorConfig(halt_threshold=5)
        detector = LoopDetector(config)
        for _ in range(5):
            event = detector.record_action(_action())
        assert event is not None
        assert event.level == "halt"

    def test_custom_window_seconds(self):
        config = LoopDetectorConfig(window_seconds=0.1, warning_threshold=3)
        detector = LoopDetector(config)
        detector.record_action(_action())
        time.sleep(0.15)
        # First action should be evicted
        for _ in range(2):
            event = detector.record_action(_action())
        assert event is None  # only 2 in window, threshold is 3

    def test_custom_trust_decay_value(self):
        config = LoopDetectorConfig(trust_decay_per_warning=0.1)
        detector = LoopDetector(config)
        assert detector._config.trust_decay_per_warning == 0.1

    def test_exempt_action_types_prevents_tracking(self):
        detector = LoopDetector()
        for _ in range(15):
            event = detector.record_action(_action(action_type="read"))
        assert event is None  # "read" is exempt

    def test_default_exempt_list(self):
        config = LoopDetectorConfig()
        assert "read" in config.exempt_action_types
        assert "list" in config.exempt_action_types
        assert "get" in config.exempt_action_types
        assert "query" in config.exempt_action_types

    def test_custom_exempt_list(self):
        config = LoopDetectorConfig(exempt_action_types=["ping", "heartbeat"])
        detector = LoopDetector(config)
        # "write" is no longer exempt
        for _ in range(5):
            event = detector.record_action(_action(action_type="write"))
        assert event is not None
        assert event.level == "warning"
        # "ping" is exempt
        for _ in range(15):
            event2 = detector.record_action(_action(action_type="ping"))
        assert event2 is None


# ── 4. Target normalization tests ────────────────────────────────────


class TestTargetNormalization:
    def test_exact_target_matching_by_default(self):
        detector = LoopDetector()
        for _ in range(4):
            detector.record_action(_action(target="users/123"))
        detector.record_action(_action(target="users/456"))
        count_123 = detector.get_repetition_count("agent-1", "write", "users/123")
        count_456 = detector.get_repetition_count("agent-1", "write", "users/456")
        assert count_123 == 4
        assert count_456 == 1

    def test_prefix_matching_depth_1(self):
        config = LoopDetectorConfig(
            target_prefix_match=True,
            target_prefix_depth=1,
            warning_threshold=5,
        )
        detector = LoopDetector(config)
        for i in range(5):
            event = detector.record_action(_action(target=f"users/{i}"))
        # All should match "users" at depth 1
        assert event is not None
        assert event.level == "warning"
        assert event.count == 5

    def test_prefix_matching_depth_2(self):
        config = LoopDetectorConfig(
            target_prefix_match=True,
            target_prefix_depth=2,
            warning_threshold=5,
        )
        detector = LoopDetector(config)
        for i in range(5):
            event = detector.record_action(_action(target=f"api/users/{i}"))
        # All match "api/users" at depth 2
        assert event is not None
        assert event.level == "warning"
        assert event.count == 5

    def test_prefix_matching_different_prefixes(self):
        config = LoopDetectorConfig(
            target_prefix_match=True,
            target_prefix_depth=1,
        )
        detector = LoopDetector(config)
        for _ in range(3):
            detector.record_action(_action(target="users/123"))
        for _ in range(3):
            detector.record_action(_action(target="orders/456"))
        count_users = detector.get_repetition_count("agent-1", "write", "users/123")
        count_orders = detector.get_repetition_count("agent-1", "write", "orders/456")
        assert count_users == 3
        assert count_orders == 3

    def test_empty_target_handled(self):
        detector = LoopDetector()
        for _ in range(5):
            event = detector.record_action(_action(target=""))
        assert event is not None
        assert event.count == 5


# ── 5. Interrupt monitor tests ──────────────────────────────────────


class TestInterruptMonitor:
    def test_check_returns_none_below_halt_threshold(self):
        detector = LoopDetector()
        for _ in range(5):
            detector.record_action(_action())
        handle = ExecutionHandle(action=_action(), agent_id="agent-1")
        result = detector.check(handle)
        assert result is None

    def test_check_returns_interrupt_request_at_halt_threshold(self):
        detector = LoopDetector()
        for _ in range(10):
            detector.record_action(_action())
        handle = ExecutionHandle(action=_action(), agent_id="agent-1")
        result = detector.check(handle)
        assert result is not None
        assert isinstance(result, InterruptRequest)

    def test_interrupt_request_has_correct_fields(self):
        detector = LoopDetector()
        action = _action()
        for _ in range(10):
            detector.record_action(action)
        handle = ExecutionHandle(action=action, agent_id="agent-1")
        result = detector.check(handle)
        assert result is not None
        assert result.action_id == action.id
        assert "Loop detected" in result.reason
        assert result.source == "loop_detector"
        assert result.severity == Severity.HIGH
        assert result.scope == "agent"

    def test_check_respects_exempt_action_types(self):
        detector = LoopDetector()
        action = _action(action_type="read")
        for _ in range(15):
            detector.record_action(action)
        handle = ExecutionHandle(action=action, agent_id="agent-1")
        result = detector.check(handle)
        assert result is None

    def test_integration_with_interrupt_authority(self):
        detector = LoopDetector()
        auth = InterruptAuthority()
        auth.add_monitor(detector.check)

        action = _action()
        for _ in range(10):
            detector.record_action(action)

        handle = auth.register_execution(action, "agent-1")
        result = auth.check_monitors(handle)
        assert result is not None
        assert result.source == "loop_detector"


# ── 6. Executor integration tests ──────────────────────────────────


def _setup_agent(tmp_path, agent_id="TestBot", actions=None, boundaries=None):
    """Create a certificate and config for an agent in tmp_path."""
    from nomotic.authority import CertificateAuthority
    from nomotic.keys import SigningKey
    from nomotic.sandbox import AgentConfig, save_agent_config
    from nomotic.store import FileCertificateStore

    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "delete"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


class TestExecutorIntegration:
    def test_execute_denied_on_loop_halt(self, tmp_path):
        """Execute returns denied result when loop halt threshold reached."""
        from nomotic.executor import GovernedToolExecutor
        from nomotic.loop_detector import LoopDetectorConfig

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)
        executor.configure_loop_detection(LoopDetectorConfig(halt_threshold=5))

        for i in range(4):
            result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
            assert result.allowed is True

        # 5th should be halted
        result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        assert result.allowed is False
        assert result.verdict == "DENY"
        assert "Loop detected" in result.reason
        assert result.loop_detected is True
        assert result.loop_count == 5

    def test_execute_normal_below_threshold(self, tmp_path):
        """Execute succeeds normally below threshold."""
        from nomotic.executor import GovernedToolExecutor

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        assert result.allowed is True
        assert result.loop_detected is False
        assert result.loop_count == 0

    def test_warning_allows_execution(self, tmp_path):
        """Warning-level loop events allow execution to proceed."""
        from nomotic.executor import GovernedToolExecutor
        from nomotic.loop_detector import LoopDetectorConfig

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)
        executor.configure_loop_detection(
            LoopDetectorConfig(warning_threshold=3, halt_threshold=20)
        )

        for _ in range(2):
            executor.execute("write", "resource-a", tool_fn=lambda: "ok")

        # 3rd triggers warning but still allowed
        result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        assert result.allowed is True
        assert result.loop_detected is True
        assert result.loop_count == 3

    def test_trust_decays_on_warning(self, tmp_path):
        """Trust decays on warning-level events."""
        from nomotic.executor import GovernedToolExecutor
        from nomotic.loop_detector import LoopDetectorConfig

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)
        executor.configure_loop_detection(
            LoopDetectorConfig(
                warning_threshold=3,
                halt_threshold=20,
                trust_decay_per_warning=0.1,
            )
        )

        trust_before = executor.trust
        for _ in range(3):
            executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        trust_after = executor.trust
        # Trust should have decreased due to warning decay
        # (may also increase from successful actions, but decay of 0.1 is large)
        assert trust_after < trust_before + 0.1  # decay must have had effect

    def test_loop_detected_and_loop_count_populated(self, tmp_path):
        """loop_detected and loop_count populated on ExecutionResult."""
        from nomotic.executor import GovernedToolExecutor
        from nomotic.loop_detector import LoopDetectorConfig

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)
        executor.configure_loop_detection(
            LoopDetectorConfig(warning_threshold=2, halt_threshold=20)
        )

        executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        assert result.loop_detected is True
        assert result.loop_count == 2

    def test_exempt_action_types_never_loop_detected(self, tmp_path):
        """Exempt action types are never loop-detected."""
        from nomotic.executor import GovernedToolExecutor

        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        for _ in range(15):
            result = executor.execute("read", "resource-a", tool_fn=lambda: "ok")
        assert result.allowed is True
        assert result.loop_detected is False

    def test_configure_loop_detection_changes_thresholds(self, tmp_path):
        """configure_loop_detection() changes thresholds."""
        from nomotic.executor import GovernedToolExecutor
        from nomotic.loop_detector import LoopDetectorConfig

        _setup_agent(tmp_path, "TestBot", actions=["write"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        # With default thresholds, 5 actions should not trigger halt
        for _ in range(5):
            result = executor.execute("write", "resource-a", tool_fn=lambda: "ok")
        assert result.allowed is True

        # Reconfigure with lower halt threshold
        executor.configure_loop_detection(LoopDetectorConfig(halt_threshold=3))
        for _ in range(3):
            result = executor.execute("write", "resource-b", tool_fn=lambda: "ok")
        assert result.allowed is False
        assert result.loop_detected is True


# ── 7. Reset and state management tests ──────────────────────────────


class TestResetAndState:
    def test_reset_agent_clears_only_that_agent(self):
        detector = LoopDetector()
        for _ in range(4):
            detector.record_action(_action(agent_id="agent-1"))
        for _ in range(4):
            detector.record_action(_action(agent_id="agent-2"))

        detector.reset("agent-1")
        count_1 = detector.get_repetition_count("agent-1", "write", "resource-a")
        count_2 = detector.get_repetition_count("agent-2", "write", "resource-a")
        assert count_1 == 0
        assert count_2 == 4

    def test_reset_all_clears_everything(self):
        detector = LoopDetector()
        for _ in range(4):
            detector.record_action(_action(agent_id="agent-1"))
        for _ in range(4):
            detector.record_action(_action(agent_id="agent-2"))

        detector.reset()
        count_1 = detector.get_repetition_count("agent-1", "write", "resource-a")
        count_2 = detector.get_repetition_count("agent-2", "write", "resource-a")
        assert count_1 == 0
        assert count_2 == 0

    def test_get_repetition_count_returns_correct_value(self):
        detector = LoopDetector()
        for _ in range(7):
            detector.record_action(_action())
        count = detector.get_repetition_count("agent-1", "write", "resource-a")
        assert count == 7

    def test_multiple_agents_tracked_independently(self):
        detector = LoopDetector()
        for _ in range(5):
            detector.record_action(_action(agent_id="agent-1"))
        for _ in range(3):
            detector.record_action(_action(agent_id="agent-2"))

        count_1 = detector.get_repetition_count("agent-1", "write", "resource-a")
        count_2 = detector.get_repetition_count("agent-2", "write", "resource-a")
        assert count_1 == 5
        assert count_2 == 3

    def test_warning_not_re_emitted_at_same_count(self):
        """Warning is only emitted once per threshold crossing, not on every subsequent action."""
        detector = LoopDetector()
        events = []
        for _ in range(9):  # below halt (10), above warning (5)
            event = detector.record_action(_action())
            if event is not None:
                events.append(event)
        # Should have warning events but not one for every action above 5
        warning_events = [e for e in events if e.level == "warning"]
        assert len(warning_events) >= 1
        # Each warning should be at a different count
        counts = [e.count for e in warning_events]
        assert len(counts) == len(set(counts))


# ── 8. Import tests ─────────────────────────────────────────────────


class TestImports:
    def test_import_from_nomotic(self):
        from nomotic import LoopDetector as LD
        from nomotic import LoopDetectorConfig as LDC
        from nomotic import LoopEvent as LE

        assert LD is LoopDetector
        assert LDC is LoopDetectorConfig
        assert LE is LoopEvent
