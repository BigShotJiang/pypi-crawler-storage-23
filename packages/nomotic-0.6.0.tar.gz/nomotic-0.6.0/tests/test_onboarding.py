"""Tests for archetype-first onboarding enhancements (F-02).

Covers:
  - Auto-compliance-preset application from archetype during birth
  - Interactive archetype picker
  - detect_installed_frameworks() utility
"""

import tempfile
from unittest.mock import patch, MagicMock

import pytest

from nomotic.cli import main, ARCHETYPE_PRESET_MAP, _PICKER_ARCHETYPES, _interactive_archetype_picker
from nomotic.framework_detect import detect_installed_frameworks


# ── Auto-compliance-preset tests ─────────────────────────────────────────


class TestAutoCompliancePreset:
    """Tests 1–6: auto-preset application from archetype during birth."""

    def test_healthcare_agent_auto_applies_hipaa_aligned(self, capsys):
        """Test 1: healthcare-agent auto-applies hipaa_aligned preset."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "health-bot",
                "--archetype", "healthcare-agent",
                "--org", "hospital-co",
            ])
            captured = capsys.readouterr()
            assert "Agent created:" in captured.out
            assert "Applying preset: hipaa_aligned (from archetype healthcare-agent)" in captured.out

    def test_financial_analyst_auto_applies_soc2_aligned(self, capsys):
        """Test 2: financial-analyst auto-applies soc2_aligned."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "fin-bot",
                "--archetype", "financial-analyst",
                "--org", "bank-co",
            ])
            captured = capsys.readouterr()
            assert "Applying preset: soc2_aligned (from archetype financial-analyst)" in captured.out

    def test_security_monitor_auto_applies_ultra_strict(self, capsys):
        """Test 3: security-monitor auto-applies ultra_strict."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "sec-bot",
                "--archetype", "security-monitor",
                "--org", "sec-co",
            ])
            captured = capsys.readouterr()
            assert "Applying preset: ultra_strict (from archetype security-monitor)" in captured.out

    def test_fraud_detection_auto_applies_ultra_strict(self, capsys):
        """Test 4: fraud-detection auto-applies ultra_strict."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "fraud-bot",
                "--archetype", "fraud-detection",
                "--org", "fraud-co",
            ])
            captured = capsys.readouterr()
            assert "Applying preset: ultra_strict (from archetype fraud-detection)" in captured.out

    def test_customer_experience_auto_applies_strict_default(self, capsys):
        """Test 5: customer-experience auto-applies strict (default fallback)."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "cx-bot",
                "--archetype", "customer-experience",
                "--org", "cx-co",
            ])
            captured = capsys.readouterr()
            assert "Applying preset: strict (from archetype customer-experience)" in captured.out

    def test_explicit_preset_overrides_auto(self, capsys):
        """Test 6: explicit --preset overrides auto-detected preset, no auto-preset message."""
        with tempfile.TemporaryDirectory() as tmp:
            main([
                "--base-dir", tmp,
                "birth",
                "--name", "health-bot-2",
                "--archetype", "healthcare-agent",
                "--org", "hospital-co",
                "--preset", "standard",
            ])
            captured = capsys.readouterr()
            assert "Agent created:" in captured.out
            # Should NOT print auto-preset message
            assert "Applying preset:" not in captured.out
            assert "Override with --preset" not in captured.out


# ── detect_installed_frameworks tests ────────────────────────────────────


class TestDetectInstalledFrameworks:
    """Tests 7–9: framework detection utility."""

    def test_returns_empty_when_no_frameworks_installed(self):
        """Test 7: returns [] when no frameworks installed."""
        with patch("nomotic.framework_detect.importlib.util.find_spec", return_value=None):
            result = detect_installed_frameworks()
            assert result == []

    def test_returns_only_langgraph_when_installed(self):
        """Test 8: returns ['langgraph'] when only langgraph installed."""
        def mock_find_spec(name):
            if name == "langgraph":
                return MagicMock()  # Non-None = installed
            return None

        with patch("nomotic.framework_detect.importlib.util.find_spec", side_effect=mock_find_spec):
            result = detect_installed_frameworks()
            assert result == ["langgraph"]

    def test_returns_all_four_when_all_installed(self):
        """Test 9: returns all 4 when all installed."""
        with patch("nomotic.framework_detect.importlib.util.find_spec", return_value=MagicMock()):
            result = detect_installed_frameworks()
            assert result == ["langgraph", "crewai", "openai", "anthropic"]


# ── Interactive archetype picker tests ───────────────────────────────────


class TestInteractiveArchetypePicker:
    """Tests 10–12: interactive archetype picker."""

    def test_input_number_1_selects_customer_experience(self):
        """Test 10: input '1' selects customer-experience."""
        with patch("builtins.input", return_value="1"):
            result = _interactive_archetype_picker()
            assert result == "customer-experience"

    def test_input_name_selects_healthcare_agent(self):
        """Test 11: input 'healthcare-agent' selects healthcare-agent."""
        with patch("builtins.input", return_value="healthcare-agent"):
            result = _interactive_archetype_picker()
            assert result == "healthcare-agent"

    def test_three_invalid_inputs_exits_nonzero(self):
        """Test 12: 3 invalid inputs exits with non-zero code."""
        with patch("builtins.input", side_effect=["bad", "nope", "wrong"]):
            with pytest.raises(SystemExit) as exc_info:
                _interactive_archetype_picker()
            assert exc_info.value.code == 1

    def test_input_number_13_selects_executive_assistant(self):
        """Input '13' selects executive-assistant."""
        with patch("builtins.input", return_value="13"):
            result = _interactive_archetype_picker()
            assert result == "executive-assistant"

    def test_invalid_then_valid_input_succeeds(self):
        """Invalid input followed by valid input succeeds."""
        with patch("builtins.input", side_effect=["bad", "5"]):
            result = _interactive_archetype_picker()
            assert result == "healthcare-agent"

    def test_archetype_name_case_insensitive(self):
        """Archetype name is case-insensitive."""
        with patch("builtins.input", return_value="Healthcare-Agent"):
            result = _interactive_archetype_picker()
            assert result == "healthcare-agent"

    def test_non_interactive_mode_requires_archetype(self):
        """Non-interactive mode (non-tty) exits with error when --archetype missing."""
        with tempfile.TemporaryDirectory() as tmp:
            with patch("sys.stdin") as mock_stdin:
                mock_stdin.isatty.return_value = False
                with pytest.raises(SystemExit) as exc_info:
                    main([
                        "--base-dir", tmp,
                        "birth",
                        "--name", "ci-bot",
                        "--org", "ci-co",
                    ])
                assert exc_info.value.code == 1


# ── ARCHETYPE_PRESET_MAP sanity checks ───────────────────────────────────


class TestArchetypePresetMap:
    """Additional validation of the preset map."""

    def test_all_mapped_presets_are_valid(self):
        """Every preset name in ARCHETYPE_PRESET_MAP is a real preset."""
        from nomotic.presets import get_preset_names
        valid_names = {n.lower() for n in get_preset_names()}
        for archetype, preset in ARCHETYPE_PRESET_MAP.items():
            assert preset.lower() in valid_names, (
                f"Archetype '{archetype}' maps to unknown preset '{preset}'"
            )

    def test_picker_archetypes_count(self):
        """Picker has exactly 13 archetypes."""
        assert len(_PICKER_ARCHETYPES) == 13
