"""Tests for ambiguity drift detection, unified health score, and feedback loop."""

from __future__ import annotations

import time
from unittest import TestCase

from nomotic.drift import (
    AUDIT_BAND_WIDTH_MODIFIED,
    AUDIT_STATUS_BOUNDARY_CROSSED,
    AUDIT_TRUST_CALIBRATION_APPLIED,
    AmbiguityDriftConfig,
    AmbiguityDriftObserver,
    AmbiguityDriftProfile,
    FeedbackLoopManager,
    UnifiedAgentHealthScore,
    UnifiedHealthScoreCalculator,
    compute_ambiguity_health_score,
)
from nomotic.trust import TrustCalibrator, TrustConfig
from nomotic.ucs_tracker import UCSTracker


# ── AmbiguityDriftObserver tests ──────────────────────────────────────


class TestRoutineExclusion(TestCase):
    """1. Routine observations do not affect ambiguity_rate."""

    def test_routine_does_not_affect_ambiguity_rate(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        # Record only routine observations
        for _ in range(20):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", action_class="routine", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertEqual(profile.ambiguity_rate, 0.0)
        self.assertEqual(profile.ritual_exclusion_rate, 1.0)
        self.assertEqual(profile._routine_evals, 20)
        self.assertEqual(profile._total_evals, 20)


class TestRateComputation(TestCase):
    """2. N in-band / M total = correct ambiguity_rate."""

    def test_rate_is_in_band_over_total(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=100, band_low=0.30, band_high=0.70)

        # 30 in-band, 70 out-of-band
        for i in range(100):
            if i < 30:
                ucs = 0.50  # in band
            else:
                ucs = 0.10  # out of band
            observer.observe("a1", ucs=ucs, verdict="ALLOW", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertAlmostEqual(profile.ambiguity_rate, 0.30, places=2)


class TestRateTrendRising(TestCase):
    """3. Rate trend — rising: fill window, add more in-band, verify trend."""

    def test_rising_trend_detected(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(
            window_size=50, band_low=0.30, band_high=0.70,
            rise_threshold=0.20, baseline_ema_alpha=0.05,
        )

        # Establish baseline: low ambiguity rate (10% in-band)
        for i in range(50):
            ucs = 0.50 if i < 5 else 0.10
            observer.observe("a1", ucs=ucs, verdict="ALLOW", config=cfg)

        # Now push in many in-band observations to shift rate up
        for _ in range(50):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        # Rate should be high now, trend should be rising
        self.assertEqual(profile.ambiguity_rate_trend, "rising")


class TestRateTrendStable(TestCase):
    """4. Rate trend — stable: consistent in-band rate."""

    def test_stable_trend(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(
            window_size=100, band_low=0.30, band_high=0.70,
            rise_threshold=0.25, fall_threshold=0.25, baseline_ema_alpha=0.50,
        )

        # Consistent 20% in-band rate
        for i in range(100):
            ucs = 0.50 if i % 5 == 0 else 0.10
            observer.observe("a1", ucs=ucs, verdict="ALLOW", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertEqual(profile.ambiguity_rate_trend, "stable")


class TestResolutionBias(TestCase):
    """5. Resolution bias: all ALLOW → +1.0; all DENY → -1.0; mixed → correct."""

    def test_all_allow_in_band(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        for _ in range(20):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertAlmostEqual(profile.resolution_bias, 1.0, places=2)

    def test_all_deny_in_band(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        for _ in range(20):
            observer.observe("a1", ucs=0.50, verdict="DENY", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertAlmostEqual(profile.resolution_bias, -1.0, places=2)

    def test_mixed_bias(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        # 15 ALLOW, 5 DENY in band
        for i in range(20):
            verdict = "ALLOW" if i < 15 else "DENY"
            observer.observe("a1", ucs=0.50, verdict=verdict, config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        # (15 - 5) / 20 = 0.50
        self.assertAlmostEqual(profile.resolution_bias, 0.50, places=2)

    def test_escalate_treated_as_allow(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        for _ in range(10):
            observer.observe("a1", ucs=0.50, verdict="ESCALATE", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertAlmostEqual(profile.resolution_bias, 1.0, places=2)


class TestResolutionBiasTrend(TestCase):
    """6. Resolution bias trend: shifting toward accept → 'toward_accept'."""

    def test_toward_accept_trend(self) -> None:
        observer = AmbiguityDriftObserver()
        # Use a small window so each observation shifts bias significantly
        cfg = AmbiguityDriftConfig(
            window_size=10, accept_drift_threshold=0.05,
        )

        # Establish balanced bias: 5 ALLOW, 5 DENY fills the window
        for _ in range(5):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)
        for _ in range(5):
            observer.observe("a1", ucs=0.50, verdict="DENY", config=cfg)

        # Now shift toward ALLOW — each replaces a DENY after the first 5
        for _ in range(10):
            observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertEqual(profile.resolution_bias_trend, "toward_accept")


class TestOverrideRate(TestCase):
    """7. Override rate: correct proportion of human overrides within band."""

    def test_override_rate_computation(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=50)

        # 20 observations in band, 5 with overrides
        for i in range(20):
            override = i < 5
            observer.observe(
                "a1", ucs=0.50, verdict="ALLOW",
                was_human_override=override, config=cfg,
            )

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertAlmostEqual(profile.human_override_rate_in_band, 0.25, places=2)


class TestCompoundAlarmFires(TestCase):
    """8. Compound alarm fires when all three conditions converge."""

    def test_compound_alarm(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(
            window_size=20, rise_threshold=0.15, fall_threshold=0.15,
            accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
        )

        # Phase 1: establish baseline with low ambiguity rate.
        # Put out-of-band entries FIRST, in-band DENYs with overrides LAST.
        # This way, phase 2 replaces out-of-band entries first (raising rate)
        # while old in-band entries remain (enabling bias/override transitions).
        for i in range(20):
            if i < 16:
                # Out of band
                observer.observe(
                    "a1", ucs=0.10, verdict="DENY",
                    was_human_override=False, config=cfg,
                )
            else:
                # In band, DENY with override
                observer.observe(
                    "a1", ucs=0.50, verdict="DENY",
                    was_human_override=True, config=cfg,
                )

        # Phase 2: push in-band ALLOWs with no overrides.
        # New entries replace out-of-band entries first → rate rises.
        # Old in-band DENYs with overrides still in buffer → bias shifts
        # toward accept and override rate falls simultaneously.
        for _ in range(10):
            observer.observe(
                "a1", ucs=0.50, verdict="ALLOW",
                was_human_override=False, config=cfg,
            )

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertTrue(profile.alert)
        self.assertIn("Compound alarm", profile.alert_reason)


class TestCompoundAlarmPartial(TestCase):
    """9. Compound alarm does NOT fire on partial conditions."""

    def test_no_alarm_on_two_of_three(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(
            window_size=20, rise_threshold=0.15,
            accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
        )

        # Establish baseline
        for i in range(20):
            ucs = 0.50 if i < 3 else 0.10
            observer.observe("a1", ucs=ucs, verdict="DENY", config=cfg)

        # Rising ambiguity + toward_accept, but override rate NOT falling (stable)
        for _ in range(20):
            observer.observe(
                "a1", ucs=0.50, verdict="ALLOW",
                was_human_override=False, config=cfg,
            )

        profile = observer.get_profile("a1")
        assert profile is not None
        # Override trend may be stable or falling depending on data — but let's
        # test the specific case where we provide some overrides to keep it stable
        observer2 = AmbiguityDriftObserver()
        for i in range(20):
            ucs = 0.50 if i < 3 else 0.10
            observer2.observe(
                "a2", ucs=ucs, verdict="DENY",
                was_human_override=False, config=cfg,
            )

        # Rising ambiguity + toward_accept + RISING overrides (not falling)
        for _ in range(20):
            observer2.observe(
                "a2", ucs=0.50, verdict="ALLOW",
                was_human_override=True, config=cfg,
            )

        profile2 = observer2.get_profile("a2")
        assert profile2 is not None
        # override is rising (went from 0 to all-override), so alarm should NOT fire
        self.assertFalse(profile2.alert)


class TestBandAdjustmentFloor(TestCase):
    """10. Band adjustment: cannot narrow beyond archetype floor."""

    def test_floor_constraint(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)

        # Create a profile first
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        # Try to narrow band significantly
        observer.adjust_band("a1", new_band_low=0.50, new_band_high=0.50,
                             floor_low=0.30, floor_high=0.70)

        profile = observer.get_profile("a1")
        assert profile is not None
        # band_low <= floor_low + 0.10 = 0.40
        self.assertLessEqual(profile.band_low, 0.40)
        # band_high >= floor_high - 0.10 = 0.60
        self.assertGreaterEqual(profile.band_high, 0.60)


# ── UnifiedAgentHealthScore tests ────────────────────────────────────


class TestPerfectHealth(TestCase):
    """11. Perfect health: all components 1.0 → score == 100."""

    def test_perfect_score(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=1.0, oversight_score=1.0, ambiguity_score=1.0,
        )
        self.assertEqual(score.unified_score, 100)
        self.assertEqual(score.health_status, "excellent")


class TestZeroHealth(TestCase):
    """12. Zero health: all components 0.0 → score == 0."""

    def test_zero_score(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.0, oversight_score=0.0, ambiguity_score=0.0,
        )
        self.assertEqual(score.unified_score, 0)
        self.assertEqual(score.health_status, "critical")


class TestPrimarySignal(TestCase):
    """13. Primary signal: one degraded component → correct primary_signal."""

    def test_behavioral_primary(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.0, oversight_score=1.0, ambiguity_score=1.0,
        )
        # Score = 0.40*0 + 0.30*1 + 0.30*1 = 60 → watch
        self.assertEqual(score.primary_signal, "behavioral")

    def test_oversight_primary(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=1.0, oversight_score=0.0, ambiguity_score=1.0,
        )
        # Score = 0.40*1 + 0.30*0 + 0.30*1 = 70 → watch
        self.assertEqual(score.primary_signal, "oversight")

    def test_ambiguity_primary(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=1.0, oversight_score=1.0, ambiguity_score=0.0,
        )
        # Score = 0.40*1 + 0.30*1 + 0.30*0 = 70 → watch
        self.assertEqual(score.primary_signal, "ambiguity")


class TestNoPrimarySignalWhenHealthy(TestCase):
    """14. No primary signal when score >= 75."""

    def test_no_primary_signal(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.90, oversight_score=0.90, ambiguity_score=0.90,
        )
        self.assertGreaterEqual(score.unified_score, 75)
        self.assertEqual(score.primary_signal, "")


class TestStatusBoundaries(TestCase):
    """15. Status boundaries: scores at thresholds map correctly."""

    def test_excellent(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=1.0, oversight_score=1.0, ambiguity_score=0.80,
        )
        self.assertGreaterEqual(score.unified_score, 90)
        self.assertEqual(score.health_status, "excellent")

    def test_good(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        # 0.40*0.80 + 0.30*0.80 + 0.30*0.70 = 0.32+0.24+0.21 = 0.77 → 77
        self.assertEqual(score.health_status, "good")

    def test_watch(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )
        # 60
        self.assertEqual(score.health_status, "watch")

    def test_warning(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.40, oversight_score=0.40, ambiguity_score=0.40,
        )
        # 40
        self.assertEqual(score.health_status, "warning")

    def test_critical(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.20, oversight_score=0.20, ambiguity_score=0.20,
        )
        # 20
        self.assertEqual(score.health_status, "critical")


class TestWeightNormalization(TestCase):
    """16. Archetype weights apply correctly to composite."""

    def test_custom_weights(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=1.0, oversight_score=0.0, ambiguity_score=0.0,
            behavioral_weight=1.0, oversight_weight=0.0, ambiguity_weight=0.0,
        )
        self.assertEqual(score.unified_score, 100)


class TestDynamicWeightBoost(TestCase):
    """17. alarm_active=True increases ambiguity weight to 0.45."""

    def test_alarm_boosts_ambiguity_weight(self) -> None:
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(
            window_size=20, rise_threshold=0.15, fall_threshold=0.15,
            accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
        )

        # Build an alarm-triggering profile: out-of-band first, in-band DENYs last
        for i in range(20):
            if i < 16:
                observer.observe(
                    "a1", ucs=0.10, verdict="DENY",
                    was_human_override=False, config=cfg,
                )
            else:
                observer.observe(
                    "a1", ucs=0.50, verdict="DENY",
                    was_human_override=True, config=cfg,
                )
        for _ in range(10):
            observer.observe(
                "a1", ucs=0.50, verdict="ALLOW",
                was_human_override=False, config=cfg,
            )

        profile = observer.get_profile("a1")
        assert profile is not None
        assert profile.alert  # precondition

        calc = UnifiedHealthScoreCalculator()
        score = calc.compute(
            "a1",
            behavioral_drift_score=0.0,
            oversight_degradation_score=0.0,
            ambiguity_profile=profile,
        )

        self.assertAlmostEqual(score.ambiguity_weight, 0.45, places=2)
        self.assertAlmostEqual(score.behavioral_weight, 0.30, places=2)
        self.assertAlmostEqual(score.oversight_weight, 0.25, places=2)


# ── compute_ambiguity_health_score tests ─────────────────────────────


class TestRisingRateHighRise(TestCase):
    """18. Rising rate with high rise above baseline → low rate_sub."""

    def test_high_rise_low_score(self) -> None:
        profile = AmbiguityDriftProfile(
            agent_id="a1", window_size=100,
            ambiguity_rate=0.80, ambiguity_rate_baseline=0.20,
            ambiguity_rate_trend="rising",
            resolution_bias=0.0, resolution_bias_trend="stable",
            human_override_rate_in_band=0.5, human_override_rate_trend="stable",
        )
        ahs = compute_ambiguity_health_score(profile)
        # rate_sub: rise_pct = (0.80-0.20)/0.20 = 3.0 → max(0, 1-3) = 0.0
        # bias_sub: 1.0 - 0.0 = 1.0
        # override_sub: stable → 0.7 + 0.3*0.5 = 0.85
        # ahs = 0.35*0 + 0.30*1.0 + 0.35*0.85 = 0 + 0.30 + 0.2975 = 0.5975
        self.assertLess(ahs, 0.65)
        self.assertGreater(ahs, 0.50)


class TestAcceptBiasWithTrend(TestCase):
    """19. Accept bias with toward_accept trend → 0.80 penalty."""

    def test_bias_penalty(self) -> None:
        profile = AmbiguityDriftProfile(
            agent_id="a1", window_size=100,
            ambiguity_rate=0.20, ambiguity_rate_baseline=0.20,
            ambiguity_rate_trend="stable",
            resolution_bias=0.50, resolution_bias_trend="toward_accept",
            human_override_rate_in_band=0.5, human_override_rate_trend="stable",
        )
        ahs = compute_ambiguity_health_score(profile)
        # rate_sub: stable → 1.0
        # bias_sub: (1.0 - 0.50) * 0.80 = 0.40
        # override_sub: stable → 0.7 + 0.3*0.5 = 0.85
        # ahs = 0.35*1.0 + 0.30*0.40 + 0.35*0.85 = 0.35 + 0.12 + 0.2975 = 0.7675
        self.assertAlmostEqual(ahs, 0.7675, places=3)


class TestFallingOverrideRate(TestCase):
    """20. Falling override rate: low rate + falling → low override_sub."""

    def test_falling_override_low_score(self) -> None:
        profile = AmbiguityDriftProfile(
            agent_id="a1", window_size=100,
            ambiguity_rate=0.20, ambiguity_rate_baseline=0.20,
            ambiguity_rate_trend="stable",
            resolution_bias=0.0, resolution_bias_trend="stable",
            human_override_rate_in_band=0.05, human_override_rate_trend="falling",
        )
        ahs = compute_ambiguity_health_score(profile)
        # rate_sub: 1.0
        # bias_sub: 1.0
        # override_sub: falling → max(0, 0.05) = 0.05
        # ahs = 0.35*1.0 + 0.30*1.0 + 0.35*0.05 = 0.35 + 0.30 + 0.0175 = 0.6675
        self.assertAlmostEqual(ahs, 0.6675, places=3)


# ── FeedbackLoopManager tests ────────────────────────────────────────


class TestGoodToWatchCrossing(TestCase):
    """21. Good→Watch crossing: trust penalty -0.05 × confidence."""

    def test_good_to_watch(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")  # initialize

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.90, oversight_score=0.90, ambiguity_score=0.90,
        )
        # prev status: excellent → need "good" status
        prev_good = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        self.assertEqual(prev_good.health_status, "good")

        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )
        self.assertEqual(current.health_status, "watch")

        events = flm.process(
            "a1", current, prev_good, observer, tc, confidence=1.0,
        )

        # Check trust penalty event
        trust_events = [e for e in events if e["event_type"] == AUDIT_TRUST_CALIBRATION_APPLIED]
        self.assertTrue(len(trust_events) > 0)
        self.assertAlmostEqual(trust_events[0]["adjustment"], -0.05, places=3)


class TestWarningToCriticalCrossing(TestCase):
    """22. Warning→Critical: penalty -0.20 × confidence."""

    def test_warning_to_critical(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.40, oversight_score=0.40, ambiguity_score=0.40,
        )
        self.assertEqual(prev.health_status, "warning")

        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.20, oversight_score=0.20, ambiguity_score=0.20,
        )
        self.assertEqual(current.health_status, "critical")

        events = flm.process(
            "a1", current, prev, observer, tc, confidence=0.80,
        )

        trust_events = [e for e in events if e["event_type"] == AUDIT_TRUST_CALIBRATION_APPLIED]
        self.assertTrue(len(trust_events) > 0)
        # -0.20 * 0.80 = -0.16
        self.assertAlmostEqual(trust_events[0]["adjustment"], -0.16, places=3)


class TestRecoveryCredit(TestCase):
    """23. Recovery credit: score improves >= 10 points → recovery credit."""

    def test_recovery(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.50, oversight_score=0.50, ambiguity_score=0.50,
        )

        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.70, oversight_score=0.70, ambiguity_score=0.70,
        )

        diff = current.unified_score - prev.unified_score
        self.assertGreaterEqual(diff, 10)

        events = flm.process("a1", current, prev, observer, tc)

        trust_events = [e for e in events if e["event_type"] == AUDIT_TRUST_CALIBRATION_APPLIED]
        self.assertTrue(len(trust_events) > 0)
        self.assertAlmostEqual(trust_events[0]["adjustment"], 0.03, places=3)


class TestFloorConstraintRespected(TestCase):
    """24. Floor constraint: band narrowing stops at archetype floor."""

    def test_floor_prevents_over_narrowing(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        # Set band close to limits
        observer.adjust_band("a1", 0.38, 0.62, floor_low=0.30, floor_high=0.70)

        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.70,
        )
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.60, oversight_score=0.60, ambiguity_score=0.60,
        )

        flm.process("a1", current, prev, observer, tc,
                     floor_low=0.30, floor_high=0.70)

        profile = observer.get_profile("a1")
        assert profile is not None
        # band_low should not exceed floor_low + 0.10
        self.assertLessEqual(profile.band_low, 0.40)
        # band_high should not go below floor_high - 0.10
        self.assertGreaterEqual(profile.band_high, 0.60)


class TestNoCrossingOnStable(TestCase):
    """25. No crossing on stable score: no penalties when status unchanged."""

    def test_no_events_on_stable(self) -> None:
        flm = FeedbackLoopManager()
        observer = AmbiguityDriftObserver()
        cfg = AmbiguityDriftConfig(window_size=10)
        observer.observe("a1", ucs=0.50, verdict="ALLOW", config=cfg)

        prev = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.80, oversight_score=0.80, ambiguity_score=0.80,
        )
        current = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=time.time(),
            behavioral_score=0.79, oversight_score=0.79, ambiguity_score=0.79,
        )

        # Both should be "good"
        self.assertEqual(prev.health_status, current.health_status)

        events = flm.process("a1", current, prev, observer)
        # No crossing, no significant recovery → no events
        self.assertEqual(len(events), 0)


# ── Integration test ─────────────────────────────────────────────────


class TestFullPipeline(TestCase):
    """26. Full pipeline: observe → alert → UAHS degrades → feedback events."""

    def test_end_to_end(self) -> None:
        observer = AmbiguityDriftObserver()
        calc = UnifiedHealthScoreCalculator()
        flm = FeedbackLoopManager()
        tc = TrustCalibrator(TrustConfig(baseline_trust=0.50))
        tc.get_profile("a1")

        cfg = AmbiguityDriftConfig(
            window_size=50, rise_threshold=0.15, fall_threshold=0.15,
            accept_drift_threshold=0.10, baseline_ema_alpha=0.05,
        )

        # Phase 1: Healthy baseline (low ambiguity, balanced, overrides present)
        # Out-of-band entries first, then a few in-band DENYs with overrides last.
        # Use few in-band entries (5) so override rate delta per step > fall_threshold.
        for i in range(50):
            if i < 45:
                observer.observe(
                    "a1", ucs=0.10, verdict="DENY",
                    was_human_override=False, config=cfg,
                )
            else:
                observer.observe(
                    "a1", ucs=0.50, verdict="DENY",
                    was_human_override=True, config=cfg,
                )

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertFalse(profile.alert)

        # Compute initial healthy UAHS
        initial_score = calc.compute(
            "a1",
            behavioral_drift_score=0.05,
            oversight_degradation_score=0.05,
            ambiguity_profile=profile,
        )
        self.assertGreaterEqual(initial_score.unified_score, 70)

        # Phase 2: Rising ambiguity pattern (attack simulation)
        # New in-band ALLOWs replace out-of-band entries, raising rate
        for _ in range(30):
            observer.observe(
                "a1", ucs=0.50, verdict="ALLOW",
                was_human_override=False, config=cfg,
            )

        profile = observer.get_profile("a1")
        assert profile is not None
        self.assertTrue(profile.alert)

        # Compute degraded UAHS
        degraded_score = calc.compute(
            "a1",
            behavioral_drift_score=0.30,
            oversight_degradation_score=0.30,
            ambiguity_profile=profile,
            prev_score=initial_score.unified_score,
        )
        self.assertLess(degraded_score.unified_score, initial_score.unified_score)

        # Verify dynamic weight boost is active
        self.assertAlmostEqual(degraded_score.ambiguity_weight, 0.45, places=2)

        # FeedbackLoopManager detects the crossing
        events = flm.process(
            "a1", degraded_score, initial_score, observer, tc,
        )

        # Should have crossing and trust adjustment events
        event_types = [e["event_type"] for e in events]
        self.assertIn(AUDIT_STATUS_BOUNDARY_CROSSED, event_types)

        # Verify audit events have required fields
        for event in events:
            self.assertIn("event_type", event)
            self.assertIn("agent_id", event)
            self.assertIn("timestamp", event)
            self.assertEqual(event["agent_id"], "a1")


class TestUCSTracker(TestCase):
    """Test the UCSTracker integration wrapper."""

    def test_basic_tracking(self) -> None:
        tracker = UCSTracker()
        for _ in range(10):
            tracker.record("a1", ucs=0.50, verdict="ALLOW")

        profile = tracker.get_profile("a1")
        assert profile is not None
        self.assertGreater(profile.ambiguity_rate, 0.0)

    def test_per_agent_config(self) -> None:
        tracker = UCSTracker()
        custom_cfg = AmbiguityDriftConfig(window_size=20, band_low=0.20, band_high=0.80)
        tracker.set_agent_config("a2", custom_cfg)

        tracker.record("a2", ucs=0.50, verdict="ALLOW")
        profile = tracker.get_profile("a2")
        assert profile is not None
        self.assertEqual(profile.band_low, 0.20)
        self.assertEqual(profile.band_high, 0.80)

    def test_alerts_delegation(self) -> None:
        tracker = UCSTracker()
        alerts = tracker.get_all_alerts()
        self.assertEqual(len(alerts), 0)

    def test_to_dict_serialization(self) -> None:
        profile = AmbiguityDriftProfile(agent_id="a1", window_size=100)
        d = profile.to_dict()
        self.assertEqual(d["agent_id"], "a1")
        self.assertIn("ambiguity_rate", d)

    def test_uahs_to_dict(self) -> None:
        score = UnifiedAgentHealthScore(
            agent_id="a1", timestamp=1000.0,
            behavioral_score=0.80, oversight_score=0.70, ambiguity_score=0.60,
        )
        d = score.to_dict()
        self.assertEqual(d["agent_id"], "a1")
        self.assertIn("components", d)
        self.assertIn("behavioral", d["components"])
