"""Tests for the SIEM exporter — CEF, Syslog (RFC 5424), and JSONL formats."""

from __future__ import annotations

import json
import os
import re
import time

import pytest

from nomotic.audit import AuditRecord, AuditTrail
from nomotic.siem import SIEMExporter


# ── Helpers ────────────────────────────────────────────────────────────


def _make_record(
    *,
    agent_id: str = "agent-1",
    context_code: str = "GOVERNANCE.ALLOW",
    severity: str = "info",
    verdict: str = "ALLOW",
    ucs: float = 0.82,
    tier: int = 2,
    trust_score: float = 0.75,
    timestamp: float | None = None,
    action_type: str = "write",
    action_target: str = "customer_records",
    justification: str = "Action ALLOW (UCS: 0.82, Tier 2).",
    drift_overall: float | None = None,
    drift_severity: str | None = None,
    dimension_scores: list | None = None,
    record_id: str = "rec-00001",
    record_hash: str = "abc123",
    previous_hash: str = "prev000",
) -> AuditRecord:
    return AuditRecord(
        record_id=record_id,
        timestamp=timestamp or 1739789400.0,  # 2025-02-17T10:30:00Z
        context_code=context_code,
        severity=severity,
        agent_id=agent_id,
        owner_id="owner-1",
        user_id="user-1",
        action_id="act-00001",
        action_type=action_type,
        action_target=action_target,
        verdict=verdict,
        ucs=ucs,
        tier=tier,
        trust_score=trust_score,
        trust_trend="stable",
        drift_overall=drift_overall,
        drift_severity=drift_severity,
        justification=justification,
        dimension_scores=dimension_scores or [],
    )


def _make_trail(*records: AuditRecord) -> AuditTrail:
    trail = AuditTrail()
    for r in records:
        trail.append(r)
    return trail


# ── CEF format tests ──────────────────────────────────────────────────


class TestCEFFormat:
    """Common Event Format output correctness."""

    def test_basic_cef_structure(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record()
        line = exporter.export_record(record)
        assert line.startswith("CEF:0|Nomotic|GovernanceRuntime|1.0|")
        # 7 pipe-delimited header fields + extensions
        parts = line.split("|", 7)
        assert len(parts) == 8

    def test_cef_event_id(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record(context_code="GOVERNANCE.ALLOW")
        line = exporter.export_record(record)
        parts = line.split("|", 7)
        assert parts[4] == "GOVERNANCE.ALLOW"

    def test_cef_event_name(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record(context_code="GOVERNANCE.ALLOW")
        line = exporter.export_record(record)
        parts = line.split("|", 7)
        assert parts[5] == "Governance: Allow"

    def test_cef_event_name_multi_word(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record(
            context_code="SECURITY.INJECTION_ATTEMPT", severity="critical"
        )
        line = exporter.export_record(record)
        parts = line.split("|", 7)
        assert parts[5] == "Security: Injection Attempt"

    def test_cef_severity_mapping(self):
        exporter = SIEMExporter(format="cef")
        for sev, expected in [("info", "1"), ("warning", "4"), ("alert", "7"), ("critical", "10")]:
            record = _make_record(severity=sev)
            line = exporter.export_record(record)
            parts = line.split("|", 7)
            assert parts[6] == expected, f"severity {sev} should map to {expected}"

    def test_cef_extensions_present(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record()
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "src=agent-1" in ext
        assert "dst=customer_records" in ext
        assert "act=write" in ext
        assert "outcome=ALLOW" in ext
        assert "cs1=0.82" in ext
        assert "cs1Label=UnifiedConfidenceScore" in ext
        assert "cs2=0.75" in ext
        assert "cs2Label=TrustScore" in ext
        assert "cn1=2" in ext
        assert "cn1Label=EvaluationTier" in ext
        assert "msg=" in ext
        assert "rt=" in ext

    def test_cef_timestamp_epoch_ms(self):
        exporter = SIEMExporter(format="cef")
        record = _make_record(timestamp=1739789400.0)
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "rt=1739789400000" in ext

    def test_cef_pipe_escaping_in_header(self):
        """Pipe chars in event fields must be escaped in the header."""
        exporter = SIEMExporter(format="cef")
        record = _make_record(context_code="TEST|PIPE")
        line = exporter.export_record(record)
        # The event_id header field should have the pipe escaped
        assert "TEST\\|PIPE" in line

    def test_cef_special_char_escaping_in_extensions(self):
        """Equals signs and backslashes in extension values must be escaped."""
        exporter = SIEMExporter(format="cef")
        record = _make_record(
            justification="key=value and C:\\path",
            action_target="target=test",
        )
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "key\\=value" in ext
        assert "C:\\\\path" in ext
        assert "dst=target\\=test" in ext

    def test_cef_dimension_scores_when_enabled(self):
        exporter = SIEMExporter(format="cef", include_dimension_scores=True)
        record = _make_record(
            dimension_scores=[
                {"dimension_name": "safety", "score": 0.95},
                {"dimension_name": "privacy", "score": 0.8},
            ]
        )
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "cs3=0.95" in ext
        assert "cs3Label=safety" in ext
        assert "cs4=0.8" in ext
        assert "cs4Label=privacy" in ext

    def test_cef_drift_data_included(self):
        exporter = SIEMExporter(format="cef", include_drift=True)
        record = _make_record(drift_overall=0.45, drift_severity="high")
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "flexNumber1=0.45" in ext
        assert "flexNumber1Label=DriftScore" in ext
        assert "flexString1=high" in ext
        assert "flexString1Label=DriftSeverity" in ext

    def test_cef_drift_excluded_when_disabled(self):
        exporter = SIEMExporter(format="cef", include_drift=False)
        record = _make_record(drift_overall=0.45, drift_severity="high")
        line = exporter.export_record(record)
        ext = line.split("|", 7)[7]
        assert "flexNumber1" not in ext
        assert "DriftScore" not in ext


# ── Syslog RFC 5424 tests ────────────────────────────────────────────


class TestSyslogFormat:
    """RFC 5424 syslog output correctness."""

    def test_basic_syslog_structure(self):
        exporter = SIEMExporter(format="syslog")
        record = _make_record()
        line = exporter.export_record(record)
        # <priority>1 timestamp hostname app-name pid msg-id sd msg
        m = re.match(r"<(\d+)>1 (\S+) (\S+) (\S+) (\d+) (\S+) (\[.+?\]) (.*)$", line)
        assert m is not None, f"Syslog line does not match RFC 5424 pattern: {line}"

    def test_syslog_priority_info(self):
        """local0 (16) * 8 + info (6) = 134"""
        exporter = SIEMExporter(format="syslog", facility=16)
        record = _make_record(severity="info")
        line = exporter.export_record(record)
        assert line.startswith("<134>1 ")

    def test_syslog_priority_warning(self):
        """local0 (16) * 8 + warning (4) = 132"""
        exporter = SIEMExporter(format="syslog", facility=16)
        record = _make_record(severity="warning")
        line = exporter.export_record(record)
        assert line.startswith("<132>1 ")

    def test_syslog_priority_alert(self):
        """local0 (16) * 8 + alert (2) = 130"""
        exporter = SIEMExporter(format="syslog", facility=16)
        record = _make_record(severity="alert")
        line = exporter.export_record(record)
        assert line.startswith("<130>1 ")

    def test_syslog_priority_critical(self):
        """local0 (16) * 8 + critical (1) = 129"""
        exporter = SIEMExporter(format="syslog", facility=16)
        record = _make_record(severity="critical")
        line = exporter.export_record(record)
        assert line.startswith("<129>1 ")

    def test_syslog_timestamp_iso8601(self):
        exporter = SIEMExporter(format="syslog")
        record = _make_record(timestamp=1739789400.0)
        line = exporter.export_record(record)
        # ISO 8601 timestamp with Z suffix
        assert re.search(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z", line)

    def test_syslog_hostname(self):
        exporter = SIEMExporter(format="syslog", hostname="myhost")
        record = _make_record()
        line = exporter.export_record(record)
        assert " myhost " in line

    def test_syslog_msg_id_is_context_code(self):
        exporter = SIEMExporter(format="syslog")
        record = _make_record(context_code="SECURITY.INJECTION_ATTEMPT")
        line = exporter.export_record(record)
        assert "SECURITY.INJECTION_ATTEMPT" in line

    def test_syslog_structured_data(self):
        exporter = SIEMExporter(format="syslog")
        record = _make_record()
        line = exporter.export_record(record)
        assert "[nomotic@49152 " in line
        assert 'agent="agent-1"' in line
        assert 'action="write"' in line
        assert 'target="customer_records"' in line
        assert 'verdict="ALLOW"' in line
        assert 'ucs="0.82"' in line
        assert 'trust="0.75"' in line
        assert 'tier="2"' in line

    def test_syslog_sd_bracket_escaping(self):
        """Brackets in SD values must be escaped per RFC 5424 §6.3.3."""
        exporter = SIEMExporter(format="syslog")
        record = _make_record(agent_id='agent[1]', action_target='target"]')
        line = exporter.export_record(record)
        assert r'agent="agent[1\]"' in line
        assert r'target="target\"\]"' in line

    def test_syslog_sd_backslash_escaping(self):
        exporter = SIEMExporter(format="syslog")
        record = _make_record(agent_id="agent\\test")
        line = exporter.export_record(record)
        assert r'agent="agent\\test"' in line

    def test_syslog_message_is_justification(self):
        exporter = SIEMExporter(format="syslog")
        just = "Action ALLOW because reasons."
        record = _make_record(justification=just)
        line = exporter.export_record(record)
        assert line.endswith(just)

    def test_syslog_drift_in_sd(self):
        exporter = SIEMExporter(format="syslog", include_drift=True)
        record = _make_record(drift_overall=0.35, drift_severity="moderate")
        line = exporter.export_record(record)
        assert 'drift="0.35"' in line
        assert 'driftSeverity="moderate"' in line

    def test_syslog_custom_facility(self):
        """Facility 17 (local1): 17*8 + 6(info) = 142"""
        exporter = SIEMExporter(format="syslog", facility=17)
        record = _make_record(severity="info")
        line = exporter.export_record(record)
        assert line.startswith("<142>1 ")


# ── JSONL format tests ────────────────────────────────────────────────


class TestJSONLFormat:
    """JSONL output correctness and ECS field naming."""

    def test_valid_json(self):
        exporter = SIEMExporter(format="jsonl")
        record = _make_record()
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert isinstance(obj, dict)

    def test_ecs_field_names(self):
        exporter = SIEMExporter(format="jsonl")
        record = _make_record()
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert obj["event.category"] == "governance"
        assert obj["event.action"] == "write"
        assert obj["event.outcome"] == "allow"
        assert obj["agent.id"] == "agent-1"
        assert obj["agent.trust"] == 0.75
        assert obj["governance.verdict"] == "ALLOW"
        assert obj["governance.ucs"] == 0.82
        assert obj["governance.tier"] == 2
        assert obj["governance.context_code"] == "GOVERNANCE.ALLOW"
        assert obj["action.type"] == "write"
        assert obj["action.target"] == "customer_records"
        assert obj["severity"] == "info"

    def test_jsonl_timestamp_iso8601(self):
        exporter = SIEMExporter(format="jsonl")
        record = _make_record(timestamp=1739789400.0)
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert re.match(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z", obj["timestamp"])

    def test_jsonl_audit_fields(self):
        exporter = SIEMExporter(format="jsonl")
        record = _make_record(record_id="rec-test", record_hash="hash1", previous_hash="hash0")
        # The trail.append will recompute hashes, so let's export directly
        # by creating a trail and checking the fields exist
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert "audit.record_id" in obj
        assert "audit.record_hash" in obj
        assert "audit.previous_hash" in obj

    def test_jsonl_dimension_scores_when_enabled(self):
        exporter = SIEMExporter(format="jsonl", include_dimension_scores=True)
        record = _make_record(
            dimension_scores=[
                {"dimension_name": "safety", "score": 0.95},
            ]
        )
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert "governance.dimension_scores" in obj
        assert obj["governance.dimension_scores"][0]["score"] == 0.95

    def test_jsonl_dimension_scores_excluded_by_default(self):
        exporter = SIEMExporter(format="jsonl")
        record = _make_record(
            dimension_scores=[
                {"dimension_name": "safety", "score": 0.95},
            ]
        )
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert "governance.dimension_scores" not in obj

    def test_jsonl_drift_data_included(self):
        exporter = SIEMExporter(format="jsonl", include_drift=True)
        record = _make_record(drift_overall=0.3, drift_severity="moderate")
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert obj["governance.drift_score"] == 0.3
        assert obj["governance.drift_severity"] == "moderate"

    def test_jsonl_drift_excluded_when_disabled(self):
        exporter = SIEMExporter(format="jsonl", include_drift=False)
        record = _make_record(drift_overall=0.3, drift_severity="moderate")
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert "governance.drift_score" not in obj
        assert "governance.drift_severity" not in obj

    def test_jsonl_no_drift_when_none(self):
        exporter = SIEMExporter(format="jsonl", include_drift=True)
        record = _make_record()  # drift_overall=None by default
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert "governance.drift_score" not in obj

    def test_jsonl_compact_output(self):
        """JSONL should use compact separators (no extra whitespace)."""
        exporter = SIEMExporter(format="jsonl")
        record = _make_record(justification="simple")
        line = exporter.export_record(record)
        # Compact JSON uses ":" and "," without trailing spaces as separators
        # (the message content may contain ": " but the JSON structure should not)
        parsed = json.loads(line)
        re_encoded = json.dumps(parsed, separators=(",", ":"))
        assert line == re_encoded


# ── Message truncation ────────────────────────────────────────────────


class TestMessageTruncation:
    """Justification truncation at max_message_length."""

    def test_truncation_at_default_limit(self):
        exporter = SIEMExporter(format="jsonl", max_message_length=1023)
        long_msg = "x" * 2000
        record = _make_record(justification=long_msg)
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert len(obj["message"]) == 1023

    def test_truncation_custom_limit(self):
        exporter = SIEMExporter(format="cef", max_message_length=50)
        long_msg = "y" * 200
        record = _make_record(justification=long_msg)
        line = exporter.export_record(record)
        # The msg extension value should be truncated
        ext = line.split("|", 7)[7]
        # Extract msg value — it comes after "msg=" and before the next space-key=
        match = re.search(r"msg=([^ ]+(?:\\ [^ ]+)*)", ext)
        assert match is not None
        msg_val = match.group(1)
        assert len(msg_val) <= 50

    def test_no_truncation_when_short(self):
        exporter = SIEMExporter(format="jsonl", max_message_length=1023)
        short_msg = "Short message."
        record = _make_record(justification=short_msg)
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert obj["message"] == short_msg

    def test_truncation_in_syslog(self):
        exporter = SIEMExporter(format="syslog", max_message_length=10)
        long_msg = "a" * 100
        record = _make_record(justification=long_msg)
        line = exporter.export_record(record)
        # The message at the end should be truncated
        # After the structured data block, the remaining is the message
        sd_end = line.rindex("]")
        message = line[sd_end + 2:]  # skip "] "
        assert len(message) == 10


# ── Stream and trail export ───────────────────────────────────────────


class TestStreamExport:
    """export_stream and export_trail behavior."""

    def test_export_stream_is_iterator(self):
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(_make_record(), _make_record(agent_id="agent-2"))
        stream = exporter.export_stream(trail)
        assert hasattr(stream, "__iter__")
        assert hasattr(stream, "__next__")

    def test_export_stream_yields_correct_count(self):
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(
            _make_record(timestamp=1.0),
            _make_record(timestamp=2.0),
            _make_record(timestamp=3.0),
        )
        lines = list(exporter.export_stream(trail))
        assert len(lines) == 3

    def test_export_stream_chronological_order(self):
        """Stream should yield records in chronological order."""
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(
            _make_record(timestamp=1.0),
            _make_record(timestamp=2.0),
            _make_record(timestamp=3.0),
        )
        lines = list(exporter.export_stream(trail))
        timestamps = [json.loads(l)["timestamp"] for l in lines]
        # Chronological: earliest first
        assert timestamps == sorted(timestamps)

    def test_export_trail_newline_separated(self):
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(
            _make_record(timestamp=1.0),
            _make_record(timestamp=2.0),
        )
        output = exporter.export_trail(trail)
        lines = output.split("\n")
        assert len(lines) == 2
        for line in lines:
            json.loads(line)  # each line must be valid JSON

    def test_export_trail_with_query_filters(self):
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(
            _make_record(agent_id="a", verdict="ALLOW", timestamp=1.0),
            _make_record(agent_id="a", verdict="DENY", timestamp=2.0),
            _make_record(agent_id="b", verdict="ALLOW", timestamp=3.0),
        )
        output = exporter.export_trail(trail, agent_id="a")
        lines = output.split("\n")
        assert len(lines) == 2
        for line in lines:
            obj = json.loads(line)
            assert obj["agent.id"] == "a"

    def test_export_trail_with_verdict_filter(self):
        exporter = SIEMExporter(format="jsonl")
        trail = _make_trail(
            _make_record(verdict="ALLOW", timestamp=1.0),
            _make_record(verdict="DENY", timestamp=2.0),
            _make_record(verdict="ALLOW", timestamp=3.0),
        )
        output = exporter.export_trail(trail, verdict="DENY")
        lines = output.split("\n")
        assert len(lines) == 1
        obj = json.loads(lines[0])
        assert obj["governance.verdict"] == "DENY"


# ── Empty trail ───────────────────────────────────────────────────────


class TestEmptyTrail:
    """Export of empty trails."""

    def test_empty_trail_stream(self):
        exporter = SIEMExporter(format="jsonl")
        trail = AuditTrail()
        lines = list(exporter.export_stream(trail))
        assert lines == []

    def test_empty_trail_export(self):
        exporter = SIEMExporter(format="cef")
        trail = AuditTrail()
        output = exporter.export_trail(trail)
        assert output == ""


# ── Sanitizer integration ─────────────────────────────────────────────


class TestSanitizerIntegration:
    """Sanitizer strips sensitive data before formatting."""

    def test_sanitizer_redacts_fields(self):
        from nomotic.sanitize import SanitizationPolicy, Sanitizer

        policy = SanitizationPolicy(
            enabled=True,
            sensitive_field_patterns=[r"(?i)justification"],
        )
        sanitizer = Sanitizer(policy)
        exporter = SIEMExporter(format="jsonl", sanitizer=sanitizer)
        record = _make_record(justification="secret api_key=abc123")
        line = exporter.export_record(record)
        obj = json.loads(line)
        # The sanitizer should have redacted the justification
        assert "abc123" not in obj["message"] or "[REDACTED" in obj["message"]

    def test_no_sanitizer_preserves_data(self):
        exporter = SIEMExporter(format="jsonl", sanitizer=None)
        record = _make_record(justification="plaintext data")
        line = exporter.export_record(record)
        obj = json.loads(line)
        assert obj["message"] == "plaintext data"


# ── Invalid format ────────────────────────────────────────────────────


class TestInvalidFormat:
    """Constructor validation."""

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Unknown format"):
            SIEMExporter(format="xml")


# ── CLI argument parsing ──────────────────────────────────────────────


class TestSIEMExportCLI:
    """CLI siem-export subcommand argument parsing."""

    def test_siem_export_args_jsonl(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["siem-export", "agent-1", "--format", "jsonl"])
        assert args.command == "siem-export"
        assert args.identifier == "agent-1"
        assert args.siem_format == "jsonl"

    def test_siem_export_args_cef(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["siem-export", "agent-1", "--format", "cef"])
        assert args.siem_format == "cef"

    def test_siem_export_args_syslog(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["siem-export", "agent-1", "--format", "syslog"])
        assert args.siem_format == "syslog"

    def test_siem_export_args_all_flag(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["siem-export", "--all", "--format", "cef"])
        assert args.siem_all is True
        assert args.identifier is None

    def test_siem_export_args_date_filters(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "siem-export", "agent-1",
            "--since", "2026-02-01",
            "--until", "2026-02-28",
        ])
        assert args.since == "2026-02-01"
        assert args.until == "2026-02-28"

    def test_siem_export_args_severity(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "siem-export", "agent-1", "--severity", "alert",
        ])
        assert args.severity == "alert"

    def test_siem_export_args_verdict(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "siem-export", "agent-1", "--verdict", "DENY",
        ])
        assert args.verdict == "DENY"

    def test_siem_export_args_output_file(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "siem-export", "agent-1", "--output", "/tmp/siem.log",
        ])
        assert args.output == "/tmp/siem.log"

    def test_siem_export_args_include_dimensions(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "siem-export", "agent-1", "--include-dimensions",
        ])
        assert args.include_dimensions is True

    def test_siem_export_default_format(self):
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args(["siem-export", "agent-1"])
        assert args.siem_format == "jsonl"


# ── Package export ────────────────────────────────────────────────────


class TestPackageExport:
    """SIEMExporter is importable from the nomotic package."""

    def test_importable_from_nomotic(self):
        from nomotic import SIEMExporter

        assert SIEMExporter is not None

    def test_in_all(self):
        import nomotic

        assert "SIEMExporter" in nomotic.__all__


# ── Cross-format consistency ──────────────────────────────────────────


class TestCrossFormatConsistency:
    """Same record exported in all formats should contain the same data."""

    def test_all_formats_contain_agent_id(self):
        record = _make_record(agent_id="test-agent")
        for fmt in ("cef", "syslog", "jsonl"):
            exporter = SIEMExporter(format=fmt)
            line = exporter.export_record(record)
            assert "test-agent" in line, f"agent_id missing from {fmt}"

    def test_all_formats_contain_verdict(self):
        record = _make_record(verdict="DENY")
        for fmt in ("cef", "syslog", "jsonl"):
            exporter = SIEMExporter(format=fmt)
            line = exporter.export_record(record)
            assert "DENY" in line, f"verdict missing from {fmt}"

    def test_all_formats_contain_context_code(self):
        record = _make_record(context_code="SECURITY.INJECTION_ATTEMPT")
        for fmt in ("cef", "syslog", "jsonl"):
            exporter = SIEMExporter(format=fmt)
            line = exporter.export_record(record)
            assert "SECURITY.INJECTION_ATTEMPT" in line, f"context_code missing from {fmt}"
