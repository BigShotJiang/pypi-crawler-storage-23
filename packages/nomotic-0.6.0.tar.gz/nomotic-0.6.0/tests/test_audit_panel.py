"""Tests for the Audit Trail Viewer panel (F-12).

Covers: GET /v1/ui/audit, GET /v1/ui/audit/export, POST /v1/ui/audit/verify/{id},
GET /v1/ui/panels/audit-trail HTML panel, filtering, pagination, and chain verification.
"""

import csv
import io
import json
import threading
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

from nomotic.api import NomoticAPIServer
from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


def _make_record(
    agent_id: str = "claims-bot",
    action_type: str = "DATA_ACCESS",
    target: str = "/patient/123",
    verdict: str = "ALLOW",
    ucs: float = 0.85,
    timestamp: float | None = None,
    record_id: str | None = None,
    archetype: str = "healthcare-agent",
) -> PersistentLogRecord:
    """Create a PersistentLogRecord for testing."""
    ts = timestamp or time.time()
    rid = record_id or f"rec-{ts}-{agent_id}"
    return PersistentLogRecord(
        record_id=rid,
        timestamp=ts,
        agent_id=agent_id,
        action_type=action_type,
        action_target=target,
        verdict=verdict,
        ucs=ucs,
        tier=1,
        trust_score=0.8,
        trust_delta=0.0,
        trust_trend="stable",
        severity="info",
        justification="Test record",
        parameters={"archetype": archetype},
    )


def _seed_records(
    store: AuditStore,
    agent_id: str = "claims-bot",
    count: int = 5,
    verdict: str = "ALLOW",
    archetype: str = "healthcare-agent",
    base_time: float | None = None,
) -> list[PersistentLogRecord]:
    """Seed audit records with proper hash chaining."""
    base = base_time or time.time() - count
    records = []
    for i in range(count):
        rec = _make_record(
            agent_id=agent_id,
            verdict=verdict,
            ucs=0.80 + i * 0.01,
            timestamp=base + i,
            record_id=f"rec-{i:04d}-{agent_id}",
            archetype=archetype,
        )
        previous_hash = store.get_last_hash(agent_id)
        rec.previous_hash = previous_hash
        rec.record_hash = store.compute_hash(rec.to_dict(), previous_hash)
        store.append(rec)
        records.append(rec)
    return records


def _setup_server(
    base_dir: Path | None = None,
    seed: bool = True,
    seed_count: int = 5,
    register_cert: bool = True,
):
    """Create a running API server for audit panel testing."""
    import tempfile

    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)

    if base_dir is None:
        base_dir = Path(tempfile.mkdtemp())

    # Register an agent certificate so archetype lookup works
    if register_cert:
        ca.issue(
            agent_id="claims-bot",
            owner="test-owner",
            archetype="healthcare-agent",
            organization="test-org",
            zone_path="/global",
        )

    audit_store = AuditStore(base_dir)
    seeded_records = []
    if seed:
        seeded_records = _seed_records(audit_store, count=seed_count)

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=True,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port, base_dir, audit_store, seeded_records


def _get_json(port: int, path: str) -> tuple[int, dict | list]:
    """GET request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def _get_raw(port: int, path: str) -> tuple[int, bytes, dict[str, str]]:
    """GET request that returns raw bytes and headers."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req) as resp:
            headers = {k.lower(): v for k, v in resp.getheaders()}
            return resp.status, resp.read(), headers
    except urllib.error.HTTPError as exc:
        headers = {k.lower(): v for k, v in exc.headers.items()}
        return exc.code, exc.read(), headers


def _post_json(port: int, path: str, data: dict | None = None) -> tuple[int, dict]:
    """POST request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    body = json.dumps(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


# ── Test 1: GET /v1/ui/audit returns correct structure ──────────────


def test_audit_returns_correct_structure():
    """GET /v1/ui/audit returns records array, total, chain_verified."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, data = _get_json(port, "/v1/ui/audit")
        assert status == 200
        assert "records" in data
        assert "total" in data
        assert "offset" in data
        assert "limit" in data
        assert "chain_verified" in data
        assert isinstance(data["records"], list)
        assert isinstance(data["chain_verified"], bool)
    finally:
        httpd.shutdown()


# ── Test 2: No filters returns up to 100 records ────────────────────


def test_audit_no_filters_default_limit():
    """No filters: returns up to 100 records (default limit)."""
    httpd, port, _, _, _ = _setup_server(seed_count=5)
    try:
        status, data = _get_json(port, "/v1/ui/audit")
        assert status == 200
        assert len(data["records"]) == 5
        assert data["total"] == 5
        assert data["limit"] == 100
    finally:
        httpd.shutdown()


# ── Test 3: agent_id filter ─────────────────────────────────────────


def test_audit_agent_id_filter():
    """?agent_id filter: only records for that agent returned."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)
    ca.issue(agent_id="agent-a", owner="o", archetype="healthcare-agent",
             organization="org", zone_path="/global")
    ca.issue(agent_id="agent-b", owner="o", archetype="financial-agent",
             organization="org", zone_path="/global")

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="agent-a", count=3)
    _seed_records(audit_store, agent_id="agent-b", count=4)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(port, "/v1/ui/audit?agent_id=agent-a")
        assert status == 200
        assert data["total"] == 3
        for rec in data["records"]:
            assert rec["agent_id"] == "agent-a"
    finally:
        httpd.shutdown()


# ── Test 4: verdict=DENY filter ─────────────────────────────────────


def test_audit_verdict_filter():
    """?verdict=DENY filter: only DENY records returned."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="bot-a", count=3, verdict="ALLOW")
    _seed_records(audit_store, agent_id="bot-b", count=2, verdict="DENY")

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(port, "/v1/ui/audit?verdict=DENY")
        assert status == 200
        assert data["total"] == 2
        for rec in data["records"]:
            assert rec["verdict"] == "DENY"
    finally:
        httpd.shutdown()


# ── Test 5: archetype filter ────────────────────────────────────────


def test_audit_archetype_filter():
    """?archetype filter: only records for agents with that archetype."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)
    ca.issue(agent_id="health-bot", owner="o", archetype="healthcare-agent",
             organization="org", zone_path="/global")
    ca.issue(agent_id="fin-bot", owner="o", archetype="financial-agent",
             organization="org", zone_path="/global")

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="health-bot", count=3,
                  archetype="healthcare-agent")
    _seed_records(audit_store, agent_id="fin-bot", count=2,
                  archetype="financial-agent")

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(
            port, "/v1/ui/audit?archetype=healthcare-agent",
        )
        assert status == 200
        assert data["total"] == 3
        for rec in data["records"]:
            assert rec["archetype"] == "healthcare-agent"
    finally:
        httpd.shutdown()


# ── Test 6: date_from filter ────────────────────────────────────────


def test_audit_date_from_filter():
    """?date_from filter: records from that date onward."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)

    # Create records at known timestamps
    old_time = datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp()
    recent_time = datetime(2025, 6, 1, tzinfo=timezone.utc).timestamp()

    _seed_records(audit_store, agent_id="bot", count=2, base_time=old_time)
    _seed_records(audit_store, agent_id="bot2", count=3, base_time=recent_time)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(
            port, "/v1/ui/audit?date_from=2025-01-01T00:00:00%2B00:00",
        )
        assert status == 200
        assert data["total"] == 3
    finally:
        httpd.shutdown()


# ── Test 7: date_to filter ──────────────────────────────────────────


def test_audit_date_to_filter():
    """?date_to filter: records up to that date."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)

    old_time = datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp()
    recent_time = datetime(2025, 6, 1, tzinfo=timezone.utc).timestamp()

    _seed_records(audit_store, agent_id="bot", count=2, base_time=old_time)
    _seed_records(audit_store, agent_id="bot2", count=3, base_time=recent_time)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(
            port, "/v1/ui/audit?date_to=2024-06-01T00:00:00%2B00:00",
        )
        assert status == 200
        assert data["total"] == 2
    finally:
        httpd.shutdown()


# ── Test 8: Combined filters ────────────────────────────────────────


def test_audit_combined_filters():
    """Combined filters: agent_id + verdict both applied correctly."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="bot-x", count=3, verdict="ALLOW")
    _seed_records(audit_store, agent_id="bot-x", count=2, verdict="DENY")
    _seed_records(audit_store, agent_id="bot-y", count=4, verdict="DENY")

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(
            port, "/v1/ui/audit?agent_id=bot-x&verdict=DENY",
        )
        assert status == 200
        assert data["total"] == 2
        for rec in data["records"]:
            assert rec["agent_id"] == "bot-x"
            assert rec["verdict"] == "DENY"
    finally:
        httpd.shutdown()


# ── Test 9: limit=10 returns at most 10 records ─────────────────────


def test_audit_limit():
    """?limit=10 returns at most 10 records."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="bot", count=20)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(port, "/v1/ui/audit?limit=10")
        assert status == 200
        assert len(data["records"]) == 10
        assert data["limit"] == 10
    finally:
        httpd.shutdown()


# ── Test 10: offset=50 skips first 50 records ───────────────────────


def test_audit_offset():
    """?offset=50 skips first 50 records."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="bot", count=60)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(port, "/v1/ui/audit?offset=50&limit=100")
        assert status == 200
        assert len(data["records"]) == 10  # 60 - 50 = 10 remaining
        assert data["offset"] == 50
    finally:
        httpd.shutdown()


# ── Test 11: total field reflects count before limit/offset ──────────


def test_audit_total_before_pagination():
    """total field reflects count before limit/offset applied."""
    import tempfile
    base_dir = Path(tempfile.mkdtemp())

    sk, _vk = SigningKey.generate()
    cert_store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=cert_store)

    audit_store = AuditStore(base_dir)
    _seed_records(audit_store, agent_id="bot", count=25)

    server = NomoticAPIServer(
        ca, host="127.0.0.1", port=0, base_dir=base_dir, ui_enabled=True,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(), org_registry=OrganizationRegistry(),
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]

    try:
        status, data = _get_json(port, "/v1/ui/audit?limit=10&offset=5")
        assert status == 200
        assert data["total"] == 25
        assert len(data["records"]) == 10
    finally:
        httpd.shutdown()


# ── Test 12: CSV export returns CSV content-type ─────────────────────


def test_export_csv_content_type():
    """GET /v1/ui/audit/export?format=csv returns CSV content-type."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, body, headers = _get_raw(port, "/v1/ui/audit/export?format=csv")
        assert status == 200
        assert "text/csv" in headers.get("content-type", "")
    finally:
        httpd.shutdown()


# ── Test 13: CSV export Content-Disposition is attachment ────────────


def test_export_csv_content_disposition():
    """GET /v1/ui/audit/export?format=csv Content-Disposition is attachment."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, body, headers = _get_raw(port, "/v1/ui/audit/export?format=csv")
        assert status == 200
        disp = headers.get("content-disposition", "")
        assert "attachment" in disp
        assert "nomotic-audit-" in disp
        assert ".csv" in disp

        # Verify CSV is parseable
        reader = csv.reader(io.StringIO(body.decode("utf-8")))
        rows = list(reader)
        assert len(rows) >= 2  # header + at least 1 data row
        header_row = rows[0]
        assert "timestamp" in header_row
        assert "agent_id" in header_row
        assert "verdict" in header_row
        assert "record_id" in header_row
    finally:
        httpd.shutdown()


# ── Test 14: JSON export returns JSON array ──────────────────────────


def test_export_json_returns_array():
    """GET /v1/ui/audit/export?format=json returns JSON array."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, body, headers = _get_raw(
            port, "/v1/ui/audit/export?format=json",
        )
        assert status == 200
        assert "application/json" in headers.get("content-type", "")
        disp = headers.get("content-disposition", "")
        assert "attachment" in disp
        assert ".json" in disp

        data = json.loads(body.decode("utf-8"))
        assert isinstance(data, list)
        assert len(data) == 5
        assert "record_id" in data[0]
    finally:
        httpd.shutdown()


# ── Test 15: POST verify returns verified=true for valid chain ──────


def test_verify_valid_chain():
    """POST /v1/ui/audit/verify/{id} returns verified=true for valid chain."""
    httpd, port, _, _, records = _setup_server()
    try:
        last_record_id = records[-1].record_id
        status, data = _post_json(
            port, f"/v1/ui/audit/verify/{last_record_id}",
        )
        assert status == 200
        assert data["verified"] is True
        assert data["record_id"] == last_record_id
        assert data["chain_position"] == 4  # 0-indexed, 5th record
        assert data["error"] is None
    finally:
        httpd.shutdown()


# ── Test 16: POST verify returns 404 for unknown record_id ──────────


def test_verify_unknown_record_404():
    """POST /v1/ui/audit/verify/{id} returns 404 for unknown record_id."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, data = _post_json(
            port, "/v1/ui/audit/verify/nonexistent-record-id",
        )
        assert status == 404
        assert data["error"] == "not_found"
    finally:
        httpd.shutdown()


# ── Test 17: HTML panel returns valid HTML ───────────────────────────


def test_panel_returns_html():
    """GET /v1/ui/panels/audit-trail returns HTML content."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, body, headers = _get_raw(
            port, "/v1/ui/panels/audit-trail",
        )
        assert status == 200
        assert "text/html" in headers.get("content-type", "")
        html = body.decode("utf-8")
        # Should contain table structure
        assert "<table" in html
        assert "Verify" in html
        # Should contain chain status
        assert "Chain Intact" in html
    finally:
        httpd.shutdown()


# ── Test 18: Empty state shows message ───────────────────────────────


def test_panel_empty_state():
    """Empty audit trail shows empty state message."""
    httpd, port, _, _, _ = _setup_server(seed=False)
    try:
        status, body, headers = _get_raw(
            port, "/v1/ui/panels/audit-trail",
        )
        assert status == 200
        html = body.decode("utf-8")
        assert "No audit records found" in html
    finally:
        httpd.shutdown()


# ── Test 19: Record fields have correct format ──────────────────────


def test_audit_record_field_format():
    """Records have correct field format (UCS rounded, hash truncated)."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, data = _get_json(port, "/v1/ui/audit")
        assert status == 200
        rec = data["records"][0]

        # UCS should be float rounded to 2 decimal places
        assert isinstance(rec["ucs_score"], float)

        # previous_hash should be truncated
        if rec["previous_hash"]:
            assert rec["previous_hash"].endswith("...")

        # chain_position should be int
        assert isinstance(rec["chain_position"], int)

        # Required fields present
        for field in [
            "timestamp", "agent_id", "archetype", "action_type",
            "target", "verdict", "ucs_score", "record_id",
            "chain_position", "previous_hash",
        ]:
            assert field in rec, f"Missing field: {field}"
    finally:
        httpd.shutdown()


# ── Test 20: chain_verified reflects actual chain integrity ──────────


def test_chain_verified_flag():
    """chain_verified=true when all chains are intact."""
    httpd, port, _, _, _ = _setup_server()
    try:
        status, data = _get_json(port, "/v1/ui/audit")
        assert status == 200
        assert data["chain_verified"] is True
    finally:
        httpd.shutdown()
