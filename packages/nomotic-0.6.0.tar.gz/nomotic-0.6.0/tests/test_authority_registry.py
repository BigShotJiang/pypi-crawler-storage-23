"""Tests for the Governance Authority Registry (Item 15, v0.5.0).

Minimum 30 test functions covering bootstrap, authority registration,
permission checking, role enforcement, change history, serialisation
round-trips, and runtime integration.
"""

from __future__ import annotations

import json
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

import pytest

from nomotic.authority_registry import (
    GovernanceAuthority,
    GovernanceAuthorityRegistry,
    GovernanceChangeRecord,
    GovernanceRole,
    UnauthorizedGovernanceChange,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_authority(
    roles: list[GovernanceRole] | None = None,
    expires_at: float | None = None,
    authority_id: str | None = None,
    name: str = "test-authority",
) -> GovernanceAuthority:
    """Create a test GovernanceAuthority."""
    return GovernanceAuthority(
        authority_id=authority_id or f"nma-{uuid.uuid4()}",
        name=name,
        roles=roles or [GovernanceRole.SCOPE_OWNER],
        created_by="test-creator",
        created_at=time.time(),
        expires_at=expires_at,
    )


def _bootstrapped_registry() -> tuple[GovernanceAuthorityRegistry, str]:
    """Return a registry with a bootstrapped RUNTIME_ADMINISTRATOR."""
    registry = GovernanceAuthorityRegistry()
    admin_id = f"nma-{uuid.uuid4()}"
    registry.bootstrap(admin_id, "root-admin")
    return registry, admin_id


# ── Bootstrap tests ──────────────────────────────────────────────────────


class TestBootstrap:
    def test_bootstrap_creates_runtime_administrator(self) -> None:
        registry = GovernanceAuthorityRegistry()
        admin_id = f"nma-{uuid.uuid4()}"
        authority = registry.bootstrap(admin_id, "root-admin")

        assert authority.authority_id == admin_id
        assert authority.name == "root-admin"
        assert GovernanceRole.RUNTIME_ADMINISTRATOR in authority.roles
        assert authority.created_by == "__bootstrap__"
        assert registry.get_authority(admin_id) is not None

    def test_bootstrap_only_allowed_once(self) -> None:
        registry = GovernanceAuthorityRegistry()
        registry.bootstrap(f"nma-{uuid.uuid4()}", "admin")

        with pytest.raises(RuntimeError, match="already bootstrapped"):
            registry.bootstrap(f"nma-{uuid.uuid4()}", "admin-2")

    def test_bootstrap_flag_false_after_first_registration(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        # After bootstrap, the registry is bootstrapped
        assert registry._bootstrapped is True

        # Trying to bootstrap again fails
        with pytest.raises(RuntimeError):
            registry.bootstrap(f"nma-{uuid.uuid4()}", "another")

    def test_bootstrap_authority_revoked_after_registration(self) -> None:
        """Once real authorities are registered, __bootstrap__ no longer works."""
        registry = GovernanceAuthorityRegistry()

        # Before any authority, __bootstrap__ works
        record = registry.check_permission(
            authority_id="__bootstrap__",
            required_role=GovernanceRole.RUNTIME_ADMINISTRATOR,
            change_type="test_op",
        )
        assert record is not None

        # Now bootstrap a real authority
        admin_id = f"nma-{uuid.uuid4()}"
        registry.bootstrap(admin_id, "admin")

        # __bootstrap__ should now fail (registry is not empty)
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id="__bootstrap__",
                required_role=GovernanceRole.RUNTIME_ADMINISTRATOR,
                change_type="test_op",
            )


# ── Authority management tests ───────────────────────────────────────────


class TestAuthorityManagement:
    def test_register_authority_requires_runtime_administrator(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        # Register a SCOPE_OWNER
        scope_owner = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(scope_owner, admin_id, "add scope owner")

        # The scope owner should NOT be able to register new authorities
        new_auth = _make_authority(roles=[GovernanceRole.OBSERVER])
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.register_authority(new_auth, scope_owner.authority_id, "try")

    def test_register_authority_success(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(
            roles=[GovernanceRole.POLICY_AUTHOR],
            name="policy-writer",
        )
        registry.register_authority(auth, admin_id, "adding policy author")

        retrieved = registry.get_authority(auth.authority_id)
        assert retrieved is not None
        assert retrieved.name == "policy-writer"
        assert GovernanceRole.POLICY_AUTHOR in retrieved.roles

    def test_revoke_authority_success(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority()
        registry.register_authority(auth, admin_id, "test")
        assert registry.get_authority(auth.authority_id) is not None

        registry.revoke_authority(auth.authority_id, admin_id, "no longer needed")
        assert registry.get_authority(auth.authority_id) is None

    def test_revoke_authority_unauthorized_raises(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        other = _make_authority(roles=[GovernanceRole.OBSERVER])
        registry.register_authority(other, admin_id, "test")

        # OBSERVER cannot revoke
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.revoke_authority(auth.authority_id, other.authority_id, "try")

    def test_revoked_authority_cannot_make_changes(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        # Revoke it
        registry.revoke_authority(auth.authority_id, admin_id, "done")

        # Now it cannot make changes
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=auth.authority_id,
                required_role=GovernanceRole.SCOPE_OWNER,
                change_type="scope_update",
            )

    def test_list_authorities_excludes_revoked(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth1 = _make_authority(name="auth-1")
        auth2 = _make_authority(name="auth-2")
        registry.register_authority(auth1, admin_id, "test")
        registry.register_authority(auth2, admin_id, "test")

        assert len(registry.list_authorities()) == 3  # admin + 2

        registry.revoke_authority(auth1.authority_id, admin_id, "remove")
        authorities = registry.list_authorities()
        assert len(authorities) == 2
        ids = [a.authority_id for a in authorities]
        assert auth1.authority_id not in ids
        assert auth2.authority_id in ids


# ── Permission checking tests ────────────────────────────────────────────


class TestPermissionChecking:
    def test_check_permission_correct_role_succeeds(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        record = registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
            target="agent-1",
            reason="update scope",
        )
        assert isinstance(record, GovernanceChangeRecord)
        assert record.authority_id == auth.authority_id
        assert record.change_type == "scope_update"

    def test_check_permission_wrong_role_raises(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=auth.authority_id,
                required_role=GovernanceRole.TRUST_ADMINISTRATOR,
                change_type="trust_reset",
            )

    def test_check_permission_unknown_authority_raises(self) -> None:
        registry, _admin_id = _bootstrapped_registry()

        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id="nma-nonexistent",
                required_role=GovernanceRole.SCOPE_OWNER,
                change_type="scope_update",
            )

    def test_check_permission_expired_authority_raises(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(
            roles=[GovernanceRole.SCOPE_OWNER],
            expires_at=time.time() - 100,  # Already expired
        )
        registry.register_authority(auth, admin_id, "test")

        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=auth.authority_id,
                required_role=GovernanceRole.SCOPE_OWNER,
                change_type="scope_update",
            )

    def test_check_permission_creates_change_record(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.POLICY_AUTHOR])
        registry.register_authority(auth, admin_id, "test")

        record = registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.POLICY_AUTHOR,
            change_type="policy_load",
            target="compliance-v2",
            reason="updating compliance",
        )
        assert record.change_id.startswith("nmgc-")
        assert record.target == "compliance-v2"
        assert record.reason == "updating compliance"
        assert record.change_hash != ""

    def test_runtime_administrator_can_do_all_roles(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        for role in GovernanceRole:
            if role == GovernanceRole.OBSERVER:
                continue  # OBSERVER is read-only, but admin still "has" it
            record = registry.check_permission(
                authority_id=admin_id,
                required_role=role,
                change_type=f"test_{role.value}",
            )
            assert record is not None

    def test_observer_cannot_make_changes(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        observer = _make_authority(roles=[GovernanceRole.OBSERVER])
        registry.register_authority(observer, admin_id, "test")

        # OBSERVER cannot do scope changes
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=observer.authority_id,
                required_role=GovernanceRole.SCOPE_OWNER,
                change_type="scope_update",
            )

        # OBSERVER cannot do trust changes
        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=observer.authority_id,
                required_role=GovernanceRole.TRUST_ADMINISTRATOR,
                change_type="trust_reset",
            )


# ── Role-specific permission tests ──────────────────────────────────────


class TestRolePermissions:
    def test_scope_owner_can_update_scope(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        record = registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
            target="agent-1",
        )
        assert record.role_used == GovernanceRole.SCOPE_OWNER

    def test_policy_author_cannot_update_scope(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.POLICY_AUTHOR])
        registry.register_authority(auth, admin_id, "test")

        with pytest.raises(UnauthorizedGovernanceChange):
            registry.check_permission(
                authority_id=auth.authority_id,
                required_role=GovernanceRole.SCOPE_OWNER,
                change_type="scope_update",
            )

    def test_trust_administrator_can_reset_trust(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.TRUST_ADMINISTRATOR])
        registry.register_authority(auth, admin_id, "test")

        record = registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.TRUST_ADMINISTRATOR,
            change_type="trust_reset",
            target="agent-1",
        )
        assert record.role_used == GovernanceRole.TRUST_ADMINISTRATOR

    def test_constitutional_guardian_can_load_constitution(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.CONSTITUTIONAL_GUARDIAN])
        registry.register_authority(auth, admin_id, "test")

        record = registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.CONSTITUTIONAL_GUARDIAN,
            change_type="constitutional_load",
            target="ruleset-v2",
        )
        assert record.role_used == GovernanceRole.CONSTITUTIONAL_GUARDIAN


# ── Change history tests ────────────────────────────────────────────────


class TestChangeHistory:
    def test_get_change_history_all(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(auth, admin_id, "test")

        registry.check_permission(
            authority_id=auth.authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
            target="agent-1",
        )

        history = registry.get_change_history()
        # bootstrap + register + check
        assert len(history) >= 3

    def test_get_change_history_filtered_by_authority(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth1 = _make_authority(roles=[GovernanceRole.SCOPE_OWNER], name="auth-1")
        auth2 = _make_authority(roles=[GovernanceRole.POLICY_AUTHOR], name="auth-2")
        registry.register_authority(auth1, admin_id, "test")
        registry.register_authority(auth2, admin_id, "test")

        registry.check_permission(
            authority_id=auth1.authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
        )
        registry.check_permission(
            authority_id=auth2.authority_id,
            required_role=GovernanceRole.POLICY_AUTHOR,
            change_type="policy_load",
        )

        history_auth1 = registry.get_change_history(authority_id=auth1.authority_id)
        for record in history_auth1:
            assert record.authority_id == auth1.authority_id


# ── Serialisation tests ─────────────────────────────────────────────────


class TestSerialisation:
    def test_load_from_file_round_trip(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        auth = _make_authority(roles=[GovernanceRole.SCOPE_OWNER], name="saved-auth")
        registry.register_authority(auth, admin_id, "test")

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            path = Path(f.name)

        registry.save_to_file(path)

        # Load into new registry
        registry2 = GovernanceAuthorityRegistry()
        registry2.load_from_file(path)

        authorities = registry2.list_authorities()
        assert len(authorities) == 2  # admin + saved-auth
        ids = {a.authority_id for a in authorities}
        assert admin_id in ids
        assert auth.authority_id in ids

        path.unlink()

    def test_authority_hash_computed_on_init(self) -> None:
        auth = _make_authority(name="hash-test")
        assert auth.authority_hash != ""
        assert len(auth.authority_hash) == 64  # SHA-256 hex

        # Recompute and verify consistency
        assert auth.compute_hash() == auth.authority_hash

    def test_governance_change_record_immutable_hash(self) -> None:
        registry, admin_id = _bootstrapped_registry()

        record = registry.check_permission(
            authority_id=admin_id,
            required_role=GovernanceRole.RUNTIME_ADMINISTRATOR,
            change_type="test_op",
            target="test-target",
            reason="test reason",
        )
        assert record.change_hash != ""
        assert len(record.change_hash) == 64

        # Verify frozen (immutable)
        with pytest.raises(AttributeError):
            record.change_hash = "tampered"  # type: ignore[misc]


# ── Error attributes tests ──────────────────────────────────────────────


class TestExceptionAttributes:
    def test_unauthorized_governance_change_error_attributes(self) -> None:
        exc = UnauthorizedGovernanceChange(
            authority_id="nma-bad",
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
        )
        assert exc.authority_id == "nma-bad"
        assert exc.required_role == GovernanceRole.SCOPE_OWNER
        assert exc.change_type == "scope_update"
        assert "nma-bad" in str(exc)
        assert "scope_owner" in str(exc)


# ── Runtime integration tests ────────────────────────────────────────────


class TestRuntimeIntegration:
    def test_runtime_no_registry_no_check(self) -> None:
        """When no registry is configured, governance changes pass through."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        config = RuntimeConfig()
        runtime = GovernanceRuntime(config)

        # configure_scope should work without authority registry
        scope = runtime.registry.get("scope_compliance")
        runtime.configure_scope("agent-1", {"read", "write"}, actor="system")

        allowed = scope._allowed_scopes.get("agent-1")
        assert allowed == {"read", "write"}

    def test_runtime_registry_blocks_unauthorized_scope_change(self) -> None:
        """With a registry, unauthorized scope changes are rejected."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        registry = GovernanceAuthorityRegistry()
        admin_id = f"nma-{uuid.uuid4()}"
        registry.bootstrap(admin_id, "admin")

        config = RuntimeConfig(authority_registry=registry)
        runtime = GovernanceRuntime(config)

        # Using a non-existent authority should fail
        with pytest.raises(UnauthorizedGovernanceChange):
            runtime.configure_scope(
                "agent-1",
                {"read"},
                authority_id="nma-nonexistent",
                reason="test",
            )

    def test_runtime_registry_allows_authorized_scope_change(self) -> None:
        """With a registry, authorized scope changes succeed."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        registry = GovernanceAuthorityRegistry()
        admin_id = f"nma-{uuid.uuid4()}"
        registry.bootstrap(admin_id, "admin")

        # Register a SCOPE_OWNER
        scope_owner = _make_authority(roles=[GovernanceRole.SCOPE_OWNER])
        registry.register_authority(scope_owner, admin_id, "add scope owner")

        config = RuntimeConfig(authority_registry=registry)
        runtime = GovernanceRuntime(config)

        # Using the scope owner authority should work
        runtime.configure_scope(
            "agent-1",
            {"read", "write"},
            authority_id=scope_owner.authority_id,
            reason="setup scope",
        )

        scope = runtime.registry.get("scope_compliance")
        assert scope._allowed_scopes.get("agent-1") == {"read", "write"}
