"""Tests for Governance Seal — commit-time authority binding."""

import base64
import json
import time

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.certificate import AgentCertificate
from nomotic.executor import ExecutionResult, GovernedToolExecutor
from nomotic.keys import SigningKey, VerifyKey
from nomotic.runtime import GovernanceRuntime
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.seal import GovernanceSeal, SealRegistry, seal_action
from nomotic.store import FileCertificateStore, MemoryCertificateStore
from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _make_signing_key() -> tuple[SigningKey, VerifyKey]:
    return SigningKey.generate()


def _make_allow_verdict(
    action_id: str = "test-action-001",
    ucs: float = 0.85,
    tier: int = 2,
    agent_id: str = "test-agent",
) -> GovernanceVerdict:
    """Create an ALLOW verdict with dimension scores."""
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.ALLOW,
        ucs=ucs,
        tier=tier,
        dimension_scores=[
            DimensionScore(dimension_name="scope_compliance", score=0.9, weight=1.0),
            DimensionScore(dimension_name="data_sensitivity", score=0.8, weight=1.0),
            DimensionScore(dimension_name="ethical_alignment", score=0.95, weight=1.0),
        ],
        vetoed_by=[],
        reasoning="All dimensions passed",
        reversibility={"level": "reversible", "confidence": 0.9},
    )


def _make_deny_verdict(action_id: str = "test-action-002") -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.DENY,
        ucs=0.2,
        tier=1,
        vetoed_by=["scope_compliance"],
        reasoning="Out of scope",
    )


def _make_escalate_verdict(action_id: str = "test-action-003") -> GovernanceVerdict:
    return GovernanceVerdict(
        action_id=action_id,
        verdict=Verdict.ESCALATE,
        ucs=0.5,
        tier=3,
        reasoning="Needs human review",
    )


def _make_context(agent_id: str = "test-agent", trust: float = 0.7) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _make_certificate(
    sk: SigningKey,
    agent_id: str = "test-agent",
    owner: str = "test-owner",
    org: str = "test-org",
) -> AgentCertificate:
    """Issue a certificate via CA."""
    store = MemoryCertificateStore()
    ca = CertificateAuthority(
        issuer_id="test-issuer", signing_key=sk, store=store
    )
    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization=org,
        zone_path="global",
        owner=owner,
    )
    return cert


def _make_seal(
    sk: SigningKey | None = None,
    verdict: GovernanceVerdict | None = None,
    context: AgentContext | None = None,
    certificate: AgentCertificate | None = None,
    ttl_seconds: int = 30,
    **kwargs,
) -> GovernanceSeal:
    """Create a valid seal for testing."""
    if sk is None:
        sk, _vk = _make_signing_key()
    if verdict is None:
        verdict = _make_allow_verdict()
    if context is None:
        context = _make_context()
    seal = seal_action(
        verdict=verdict,
        context=context,
        signing_key=sk,
        certificate=certificate,
        ttl_seconds=ttl_seconds,
        **kwargs,
    )
    assert seal is not None
    return seal


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )
    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(agent_id=agent_id, actions=actions, boundaries=[])
    save_agent_config(tmp_path, config)
    return cert.certificate_id


# ── Seal Creation Tests ───────────────────────────────────────────────


class TestSealCreation:
    """Tests for seal_action() — the seal factory function."""

    def test_allow_verdict_produces_seal(self):
        sk, vk = _make_signing_key()
        verdict = _make_allow_verdict()
        context = _make_context()
        seal = seal_action(verdict, context, sk)
        assert seal is not None
        assert isinstance(seal, GovernanceSeal)

    def test_deny_verdict_returns_none(self):
        sk, vk = _make_signing_key()
        verdict = _make_deny_verdict()
        context = _make_context()
        seal = seal_action(verdict, context, sk)
        assert seal is None

    def test_escalate_verdict_returns_none(self):
        sk, vk = _make_signing_key()
        verdict = _make_escalate_verdict()
        context = _make_context()
        seal = seal_action(verdict, context, sk)
        assert seal is None

    def test_seal_id_format(self):
        seal = _make_seal()
        assert seal.seal_id.startswith("nms-")
        # Should have a UUID after the prefix
        uuid_part = seal.seal_id[4:]
        assert len(uuid_part) == 36  # UUID4 with hyphens

    def test_seal_captures_verdict_fields(self):
        verdict = _make_allow_verdict(ucs=0.92, tier=3)
        seal = _make_seal(verdict=verdict)
        assert seal.ucs == 0.92
        assert seal.tier == 3
        assert seal.action_id == verdict.action_id
        assert seal.verdict == "ALLOW"

    def test_seal_captures_dimension_scores(self):
        seal = _make_seal()
        assert "scope_compliance" in seal.dimension_summary
        assert seal.dimension_summary["scope_compliance"] == 0.9
        assert "data_sensitivity" in seal.dimension_summary
        assert seal.dimension_summary["data_sensitivity"] == 0.8
        assert "ethical_alignment" in seal.dimension_summary

    def test_seal_captures_authority_chain(self):
        sk, vk = _make_signing_key()
        cert = _make_certificate(sk, owner="alice", org="acme-corp")
        context = _make_context(agent_id=cert.agent_id)
        verdict = _make_allow_verdict(agent_id=cert.agent_id)
        seal = seal_action(verdict, context, sk, certificate=cert)
        assert seal is not None
        assert seal.agent_owner == "alice"
        assert seal.organization == "acme-corp"

    def test_seal_without_certificate_has_empty_authority(self):
        seal = _make_seal(certificate=None)
        assert seal.agent_owner == ""
        assert seal.organization == ""

    def test_seal_ttl_defaults_to_30(self):
        seal = _make_seal()
        assert seal.ttl_seconds == 30

    def test_seal_ttl_is_configurable(self):
        seal = _make_seal(ttl_seconds=60)
        assert seal.ttl_seconds == 60
        assert seal.expires_at == pytest.approx(seal.issued_at + 60, abs=0.1)

    def test_seal_expires_at_equals_issued_plus_ttl(self):
        seal = _make_seal(ttl_seconds=30)
        assert seal.expires_at == pytest.approx(seal.issued_at + 30, abs=0.1)

    def test_seal_captures_agent_id(self):
        context = _make_context(agent_id="my-agent-123")
        seal = _make_seal(context=context)
        assert seal.agent_id == "my-agent-123"

    def test_seal_captures_trust_level(self):
        context = _make_context(trust=0.85)
        seal = _make_seal(context=context)
        assert seal.trust_level == 0.85

    def test_seal_captures_reversibility(self):
        verdict = _make_allow_verdict()
        verdict.reversibility = {"level": "irreversible", "confidence": 0.7}
        seal = _make_seal(verdict=verdict)
        assert seal.reversibility == "irreversible"

    def test_seal_reversibility_default_unknown(self):
        verdict = _make_allow_verdict()
        verdict.reversibility = None
        seal = _make_seal(verdict=verdict)
        assert seal.reversibility == "unknown"

    def test_seal_preset_and_risk_tier(self):
        seal = _make_seal(preset="hipaa_aligned", risk_tier="high")
        assert seal.preset == "hipaa_aligned"
        assert seal.risk_tier == "high"

    def test_seal_org_policy_hash(self):
        seal = _make_seal(org_policy_hash="sha256:abc123")
        assert seal.org_policy_hash == "sha256:abc123"

    def test_seal_vetoed_by_empty_for_allow(self):
        seal = _make_seal()
        assert seal.vetoed_by == []


# ── Signature and Verification Tests ──────────────────────────────────


class TestSealVerification:
    """Tests for GovernanceSeal.verify() and signature validation."""

    def test_verify_with_correct_key(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        assert seal.verify(vk) is True

    def test_verify_fails_with_wrong_key(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        _other_sk, other_vk = _make_signing_key()
        assert seal.verify(other_vk) is False

    def test_expired_seal_fails_verification(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk, ttl_seconds=1)
        # Manually expire the seal
        seal.expires_at = time.time() - 10
        assert seal.verify(vk) is False
        assert seal.is_expired() is True

    def test_tampered_ucs_fails_verification(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        seal.ucs = 0.99  # Tamper with UCS
        assert seal.verify(vk) is False

    def test_tampered_agent_id_fails_verification(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        seal.agent_id = "evil-agent"  # Tamper with agent ID
        assert seal.verify(vk) is False

    def test_non_expired_seal_passes_expiration_check(self):
        seal = _make_seal(ttl_seconds=300)
        assert seal.is_expired() is False

    def test_issuer_fingerprint_set(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        assert seal.issuer_fingerprint.startswith("SHA256:")
        assert seal.issuer_fingerprint == vk.fingerprint()

    def test_signature_is_bytes(self):
        seal = _make_seal()
        assert isinstance(seal.signature, bytes)
        assert len(seal.signature) > 0


# ── Serialization Tests ──────────────────────────────────────────────


class TestSealSerialization:
    """Tests for to_dict/from_dict and to_compact/from_compact."""

    def test_to_dict_from_dict_roundtrip(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        d = seal.to_dict()
        restored = GovernanceSeal.from_dict(d)

        assert restored.seal_id == seal.seal_id
        assert restored.action_id == seal.action_id
        assert restored.agent_id == seal.agent_id
        assert restored.verdict == seal.verdict
        assert restored.ucs == seal.ucs
        assert restored.tier == seal.tier
        assert restored.dimension_summary == seal.dimension_summary
        assert restored.vetoed_by == seal.vetoed_by
        assert restored.agent_owner == seal.agent_owner
        assert restored.organization == seal.organization
        assert restored.preset == seal.preset
        assert restored.risk_tier == seal.risk_tier
        assert restored.org_policy_hash == seal.org_policy_hash
        assert restored.trust_level == seal.trust_level
        assert restored.reversibility == seal.reversibility
        assert restored.issued_at == seal.issued_at
        assert restored.expires_at == seal.expires_at
        assert restored.ttl_seconds == seal.ttl_seconds
        assert restored.signature == seal.signature
        assert restored.issuer_fingerprint == seal.issuer_fingerprint

        # Restored seal should still verify
        assert restored.verify(vk) is True

    def test_to_compact_from_compact_roundtrip(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        compact = seal.to_compact()
        assert isinstance(compact, str)
        restored = GovernanceSeal.from_compact(compact)

        assert restored.seal_id == seal.seal_id
        assert restored.signature == seal.signature
        assert restored.verify(vk) is True

    def test_to_dict_signature_is_base64_string(self):
        seal = _make_seal()
        d = seal.to_dict()
        assert isinstance(d["signature"], str)
        # Should be valid base64
        decoded = base64.b64decode(d["signature"])
        assert decoded == seal.signature

    def test_to_dict_is_json_serializable(self):
        seal = _make_seal()
        d = seal.to_dict()
        json_str = json.dumps(d)
        assert isinstance(json_str, str)

    def test_canonical_bytes_deterministic(self):
        sk, vk = _make_signing_key()
        seal = _make_seal(sk=sk)
        b1 = seal.canonical_bytes()
        b2 = seal.canonical_bytes()
        assert b1 == b2

    def test_canonical_bytes_excludes_signature(self):
        seal = _make_seal()
        canonical = seal.canonical_bytes()
        d = json.loads(canonical)
        assert "signature" not in d
        assert "issuer_fingerprint" not in d

    def test_canonical_bytes_includes_all_other_fields(self):
        seal = _make_seal()
        canonical = seal.canonical_bytes()
        d = json.loads(canonical)
        assert "seal_id" in d
        assert "action_id" in d
        assert "agent_id" in d
        assert "verdict" in d
        assert "ucs" in d
        assert "tier" in d
        assert "dimension_summary" in d
        assert "issued_at" in d
        assert "expires_at" in d
        assert "ttl_seconds" in d

    def test_compact_is_url_safe(self):
        seal = _make_seal()
        compact = seal.to_compact()
        # Base64url should not contain + or /
        assert "+" not in compact
        assert "/" not in compact


# ── Registry Tests ───────────────────────────────────────────────────


class TestSealRegistry:
    """Tests for SealRegistry — single-use seal tracking."""

    def test_consume_returns_true_first_time(self):
        registry = SealRegistry()
        assert registry.consume("nms-abc123") is True

    def test_consume_returns_false_second_time(self):
        registry = SealRegistry()
        assert registry.consume("nms-abc123") is True
        assert registry.consume("nms-abc123") is False

    def test_is_consumed_works(self):
        registry = SealRegistry()
        assert registry.is_consumed("nms-abc123") is False
        registry.consume("nms-abc123")
        assert registry.is_consumed("nms-abc123") is True

    def test_different_seals_independent(self):
        registry = SealRegistry()
        assert registry.consume("nms-1") is True
        assert registry.consume("nms-2") is True
        assert registry.consume("nms-1") is False
        assert registry.consume("nms-2") is False

    def test_eviction_removes_old_entries(self):
        registry = SealRegistry()
        # Manually add an old entry
        registry._consumed["old-seal"] = time.time() - 7200  # 2 hours ago
        registry._consumed["recent-seal"] = time.time()
        # Trigger eviction via new consume
        registry.consume("trigger-evict")
        assert "old-seal" not in registry._consumed
        assert "recent-seal" in registry._consumed


# ── Executor Integration Tests ───────────────────────────────────────


class TestExecutorSealed:
    """Tests for execute_sealed() and seal support in execute()."""

    def test_execute_sealed_with_valid_seal(self, tmp_path):
        """execute_sealed() succeeds with a valid seal."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        # Create a seal using the runtime's CA
        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        vk = ca._verify_key
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, sk, ttl_seconds=60)
        assert seal is not None

        result = executor.execute_sealed(
            action="read",
            target="test_db",
            tool_fn=lambda: {"rows": [1, 2, 3]},
            seal=seal,
        )
        assert result.allowed is True
        assert result.verdict == "ALLOW"
        assert result.data == {"rows": [1, 2, 3]}
        assert result.action_id == verdict.action_id

    def test_execute_sealed_without_seal_returns_seal_required(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        result = executor.execute_sealed(
            action="read",
            target="test_db",
            tool_fn=lambda: "ok",
            seal=None,
        )
        assert result.allowed is False
        assert result.reason == "SEAL_REQUIRED"

    def test_execute_sealed_with_expired_seal(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, sk, ttl_seconds=1)
        assert seal is not None
        # Force expiration
        seal.expires_at = time.time() - 10
        # Re-sign the seal so signature is valid for expired canonical form
        seal.signature = sk.sign(seal.canonical_bytes())

        result = executor.execute_sealed(
            action="read",
            target="test_db",
            tool_fn=lambda: "ok",
            seal=seal,
        )
        assert result.allowed is False
        assert result.reason == "EXPIRED_SEAL"

    def test_execute_sealed_with_consumed_seal(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, sk, ttl_seconds=60)
        assert seal is not None

        # First use succeeds
        result1 = executor.execute_sealed(
            action="read", target="test_db", tool_fn=lambda: "ok", seal=seal,
        )
        assert result1.allowed is True

        # Second use fails (reuse)
        result2 = executor.execute_sealed(
            action="read", target="test_db", tool_fn=lambda: "ok", seal=seal,
        )
        assert result2.allowed is False
        assert result2.reason == "REUSED_SEAL"

    def test_execute_sealed_with_wrong_agent_id(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        # Seal for a different agent
        verdict = _make_allow_verdict(agent_id="OtherAgent")
        context = _make_context(agent_id="OtherAgent")
        seal = seal_action(verdict, context, sk, ttl_seconds=60)
        assert seal is not None

        result = executor.execute_sealed(
            action="read", target="test_db", tool_fn=lambda: "ok", seal=seal,
        )
        assert result.allowed is False
        assert result.reason == "AGENT_MISMATCH"

    def test_execute_sealed_with_invalid_signature(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        # Create seal with a DIFFERENT key than the runtime's CA
        other_sk, _other_vk = SigningKey.generate()
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, other_sk, ttl_seconds=60)
        assert seal is not None

        result = executor.execute_sealed(
            action="read", target="test_db", tool_fn=lambda: "ok", seal=seal,
        )
        assert result.allowed is False
        assert result.reason == "INVALID_SEAL"

    def test_execute_with_require_seal_true_and_no_seal(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect(
            "TestBot", base_dir=tmp_path, require_seal=True,
        )

        result = executor.execute(
            action="read", target="test_db", tool_fn=lambda: "ok",
        )
        assert result.allowed is False
        assert result.reason == "SEAL_REQUIRED"

    def test_execute_with_require_seal_true_and_valid_seal(self, tmp_path):
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect(
            "TestBot", base_dir=tmp_path, require_seal=True,
        )

        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, sk, ttl_seconds=60)
        assert seal is not None

        result = executor.execute(
            action="read",
            target="test_db",
            tool_fn=lambda: {"data": "ok"},
            seal=seal,
        )
        assert result.allowed is True
        assert result.data == {"data": "ok"}

    def test_execute_without_require_seal_works_as_before(self, tmp_path):
        """Backward compatibility: execute() without seal still works."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        result = executor.execute(
            action="read",
            target="test_db",
            tool_fn=lambda: "backward_compat",
        )
        assert result.allowed is True
        assert result.data == "backward_compat"


class TestAuditRecordSealId:
    """Tests for seal_id in audit records."""

    def test_audit_record_includes_seal_id(self, tmp_path):
        """Audit record has seal_id when seal is used."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        ca = executor._runtime._ensure_ca()
        sk = ca._signing_key
        verdict = _make_allow_verdict(agent_id="TestBot")
        context = _make_context(agent_id="TestBot")
        seal = seal_action(verdict, context, sk, ttl_seconds=60)
        assert seal is not None

        executor.execute_sealed(
            action="read", target="test_db", tool_fn=lambda: "ok", seal=seal,
        )

        # Read the audit log
        records = executor._log_store.query(executor.agent_id, limit=1)
        assert len(records) >= 1
        latest = records[0]
        assert latest.seal_id == seal.seal_id

    def test_audit_record_empty_seal_id_without_seal(self, tmp_path):
        """Audit record has empty seal_id when no seal is used."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        executor = GovernedToolExecutor.connect("TestBot", base_dir=tmp_path)

        executor.execute(
            action="read", target="test_db", tool_fn=lambda: "ok",
        )

        records = executor._log_store.query(executor.agent_id, limit=1)
        assert len(records) >= 1
        latest = records[0]
        assert latest.seal_id == ""


# ── Runtime Integration Tests ────────────────────────────────────────


class TestRuntimeSeal:
    """Tests for GovernanceRuntime.seal() integration."""

    def test_runtime_seal_returns_seal_for_allow(self):
        runtime = GovernanceRuntime()
        agent_id = "test-agent-rt"
        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="test-org",
            zone_path="global",
            owner="test-owner",
        )

        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict == Verdict.ALLOW:
            seal = runtime.seal(verdict, context, certificate=cert)
            assert seal is not None
            assert isinstance(seal, GovernanceSeal)
            assert seal.agent_id == agent_id
            assert seal.agent_owner == "test-owner"
            assert seal.organization == "test-org"

    def test_runtime_seal_returns_none_for_deny(self):
        runtime = GovernanceRuntime()
        agent_id = "test-agent-deny"
        # Don't configure scope, so actions are out of scope -> DENY
        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)

        verdict = _make_deny_verdict()
        seal = runtime.seal(verdict, context)
        assert seal is None

    def test_runtime_seal_verifies_correctly(self):
        runtime = GovernanceRuntime()
        agent_id = "test-agent-verify"
        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="verify-org",
            zone_path="global",
            owner="verify-owner",
        )

        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict == Verdict.ALLOW:
            seal = runtime.seal(verdict, context, certificate=cert)
            assert seal is not None

            # Verify using the CA's verify key
            ca = runtime._ensure_ca()
            vk = ca._verify_key
            assert seal.verify(vk) is True

    def test_runtime_seal_auto_looks_up_certificate(self):
        runtime = GovernanceRuntime()
        agent_id = "test-agent-lookup"
        cert = runtime.birth(
            agent_id=agent_id,
            archetype="general",
            organization="lookup-org",
            zone_path="global",
            owner="lookup-owner",
        )

        trust_profile = runtime.get_trust_profile(agent_id)
        context = AgentContext(agent_id=agent_id, trust_profile=trust_profile)
        action = Action(agent_id=agent_id, action_type="read", target="test")
        verdict = runtime.evaluate(action, context)

        if verdict.verdict == Verdict.ALLOW:
            # Don't pass certificate — runtime should look it up
            seal = runtime.seal(verdict, context)
            assert seal is not None
            assert seal.agent_owner == "lookup-owner"
            assert seal.organization == "lookup-org"


# ── PersistentLogRecord backward compatibility ───────────────────────


class TestPersistentLogRecordCompat:
    """Ensure seal_id field is backward compatible."""

    def test_seal_id_defaults_to_empty(self):
        record = PersistentLogRecord(
            record_id="test",
            timestamp=time.time(),
            agent_id="agent-1",
            action_type="read",
            action_target="db",
            verdict="ALLOW",
            ucs=0.85,
            tier=2,
            trust_score=0.5,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="ok",
        )
        assert record.seal_id == ""

    def test_from_dict_without_seal_id(self):
        """from_dict works with old records that don't have seal_id."""
        d = {
            "record_id": "test",
            "timestamp": time.time(),
            "agent_id": "agent-1",
            "action_type": "read",
            "action_target": "db",
            "verdict": "ALLOW",
            "ucs": 0.85,
            "tier": 2,
            "trust_score": 0.5,
            "trust_delta": 0.0,
            "trust_trend": "stable",
            "severity": "info",
            "justification": "ok",
        }
        record = PersistentLogRecord.from_dict(d)
        assert record.seal_id == ""

    def test_to_dict_includes_seal_id(self):
        record = PersistentLogRecord(
            record_id="test",
            timestamp=time.time(),
            agent_id="agent-1",
            action_type="read",
            action_target="db",
            verdict="ALLOW",
            ucs=0.85,
            tier=2,
            trust_score=0.5,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="ok",
            seal_id="nms-12345",
        )
        d = record.to_dict()
        assert d["seal_id"] == "nms-12345"
