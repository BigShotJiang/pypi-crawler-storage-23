"""Tests for the Governance Dashboard server (F-01).

Covers: static UI serving, /v1/ui/overview, /v1/ui/feed, /v1/ui/events,
API key authentication, and empty-state behavior.
"""

import json
import threading
import time
import uuid
import urllib.request
import urllib.error
from pathlib import Path

from nomotic.api import NomoticAPIServer
from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


def _setup_server(
    *,
    ui_enabled: bool = True,
    api_key: str | None = None,
    base_dir: Path | None = None,
):
    """Create a running API server for testing the dashboard."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)

    if base_dir is None:
        import tempfile
        base_dir = Path(tempfile.mkdtemp())

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=ui_enabled,
        api_key=api_key,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port, base_dir


def _get(port: int, path: str, headers: dict | None = None) -> tuple[int, bytes, dict]:
    """GET request helper. Returns (status, body_bytes, response_headers)."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(), dict(exc.headers)


def _get_json(port: int, path: str, headers: dict | None = None) -> tuple[int, dict | list]:
    """GET request that parses JSON response."""
    status, body, _ = _get(port, path, headers)
    return status, json.loads(body.decode("utf-8"))


def _post(port: int, path: str, data: dict | None = None) -> tuple[int, bytes]:
    """POST request helper."""
    url = f"http://127.0.0.1:{port}{path}"
    body = json.dumps(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def _post_full(
    port: int, path: str, data: dict | None = None,
) -> tuple[int, bytes, dict]:
    """POST request helper that also returns response headers."""
    url = f"http://127.0.0.1:{port}{path}"
    body = json.dumps(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(), dict(exc.headers)


def _seed_audit_records(base_dir: Path, agent_id: str, count: int = 5):
    """Seed audit records for testing."""
    audit = AuditStore(base_dir)
    now = time.time()
    for i in range(count):
        record = PersistentLogRecord(
            record_id=f"rec-{uuid.uuid4().hex[:8]}",
            timestamp=now - (count - i),
            agent_id=agent_id,
            action_type="file.read",
            action_target="/data/test.txt",
            verdict="ALLOW" if i % 3 != 0 else "DENY",
            ucs=0.85 - (i * 0.05),
            tier=1,
            trust_score=0.7,
            trust_delta=0.01,
            trust_trend="stable",
            severity="info",
            justification="Test evaluation",
            parameters={"archetype": "data-analyst", "latency_ms": 12.5},
        )
        prev_hash = audit.get_last_hash(agent_id)
        record.previous_hash = prev_hash
        record.record_hash = audit.compute_hash(record.to_dict(), prev_hash)
        audit.append(record)


class TestDashboardStaticServing:
    """Tests 1-4, 16, 18: Static file serving."""

    def test_get_ui_returns_200_when_enabled(self):
        """Test 1: GET /ui returns 200 when ui_enabled=True."""
        httpd, port, _ = _setup_server(ui_enabled=True)
        try:
            status, body, headers = _get(port, "/ui")
            assert status == 200
            assert b"Nomotic Governance" in body
        finally:
            httpd.shutdown()

    def test_get_ui_returns_404_when_disabled(self):
        """Test 2: GET /ui returns 404 when ui_enabled=False."""
        httpd, port, _ = _setup_server(ui_enabled=False)
        try:
            status, _, _ = _get(port, "/ui")
            assert status == 404
        finally:
            httpd.shutdown()

    def test_get_htmx_js_returns_javascript(self):
        """Test 3: GET /ui/htmx.min.js returns JavaScript content-type."""
        httpd, port, _ = _setup_server(ui_enabled=True)
        try:
            status, body, headers = _get(port, "/ui/htmx.min.js")
            assert status == 200
            assert "application/javascript" in headers.get("Content-Type", "")
        finally:
            httpd.shutdown()

    def test_get_dashboard_css_returns_css(self):
        """Test 4: GET /ui/dashboard.css returns CSS content-type."""
        httpd, port, _ = _setup_server(ui_enabled=True)
        try:
            status, body, headers = _get(port, "/ui/dashboard.css")
            assert status == 200
            assert "text/css" in headers.get("Content-Type", "")
        finally:
            httpd.shutdown()

    def test_nonexistent_static_file_returns_404(self):
        """Test 16: GET /ui/nonexistent.js returns 404."""
        httpd, port, _ = _setup_server(ui_enabled=True)
        try:
            status, _, _ = _get(port, "/ui/nonexistent.js")
            assert status == 404
        finally:
            httpd.shutdown()

    def test_index_html_contains_hx_ext(self):
        """Test 18: Dashboard shell index.html contains 'hx-ext'."""
        httpd, port, _ = _setup_server(ui_enabled=True)
        try:
            status, body, _ = _get(port, "/ui")
            assert status == 200
            assert b"hx-ext" in body
        finally:
            httpd.shutdown()


class TestUIOverview:
    """Tests 5-8, 17: /v1/ui/overview endpoint."""

    def test_overview_returns_json_with_required_keys(self):
        """Test 5: GET /v1/ui/overview returns JSON with all 4 required keys."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert status == 200
            assert "active_agents" in data
            assert "evaluations_today" in data
            assert "allow_deny_ratio" in data
            assert "open_approvals" in data
        finally:
            httpd.shutdown()

    def test_overview_active_agents_is_integer(self):
        """Test 6: active_agents is integer >= 0."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert isinstance(data["active_agents"], int)
            assert data["active_agents"] >= 0
        finally:
            httpd.shutdown()

    def test_overview_evaluations_today_is_integer(self):
        """Test 7: evaluations_today is integer >= 0."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert isinstance(data["evaluations_today"], int)
            assert data["evaluations_today"] >= 0
        finally:
            httpd.shutdown()

    def test_overview_no_agents_returns_zeros(self):
        """Test 8: With no agents, returns zeros not error."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert status == 200
            assert data["active_agents"] == 0
            assert data["evaluations_today"] == 0
            assert data["allow_deny_ratio"] == "0:0"
            assert data["open_approvals"] == 0
        finally:
            httpd.shutdown()

    def test_overview_no_audit_records_returns_zero_evaluations(self):
        """Test 17: _handle_ui_overview() with no audit records returns evaluations_today=0."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert status == 200
            assert data["evaluations_today"] == 0
        finally:
            httpd.shutdown()


class TestUIFeed:
    """Tests 9-11: /v1/ui/feed endpoint."""

    def test_feed_returns_json_array(self):
        """Test 9: GET /v1/ui/feed returns JSON array."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/feed")
            assert status == 200
            assert isinstance(data, list)
        finally:
            httpd.shutdown()

    def test_feed_items_have_required_fields(self):
        """Test 10: Feed items have required fields."""
        import tempfile
        base_dir = Path(tempfile.mkdtemp())
        _seed_audit_records(base_dir, "test-agent", count=3)
        httpd, port, _ = _setup_server(base_dir=base_dir)
        try:
            status, data = _get_json(port, "/v1/ui/feed")
            assert status == 200
            assert len(data) > 0
            item = data[0]
            assert "timestamp" in item
            assert "agent_id" in item
            assert "verdict" in item
            assert "ucs_score" in item
            assert "record_id" in item
        finally:
            httpd.shutdown()

    def test_feed_returns_at_most_50_items(self):
        """Test 11: Feed returns at most 50 items."""
        import tempfile
        base_dir = Path(tempfile.mkdtemp())
        _seed_audit_records(base_dir, "agent-a", count=30)
        _seed_audit_records(base_dir, "agent-b", count=30)
        httpd, port, _ = _setup_server(base_dir=base_dir)
        try:
            status, data = _get_json(port, "/v1/ui/feed")
            assert status == 200
            assert len(data) <= 50
        finally:
            httpd.shutdown()


class TestUIEvents:
    """Test 12: /v1/ui/events SSE endpoint."""

    def test_events_returns_event_stream_content_type(self):
        """Test 12: GET /v1/ui/events returns Content-Type: text/event-stream."""
        httpd, port, _ = _setup_server()
        try:
            status, body, headers = _get(port, "/v1/ui/events")
            assert status == 200
            assert "text/event-stream" in headers.get("Content-Type", "")
        finally:
            httpd.shutdown()


class TestAPIKeyAuth:
    """Tests 13-15: API key authentication."""

    def test_no_api_key_from_non_localhost_returns_401(self):
        """Test 13: Request without X-Api-Key from non-localhost returns 401.

        Since we test from localhost (127.0.0.1), the localhost bypass means
        we cannot directly test non-localhost rejection. Instead, we verify
        that the api_key mechanism is wired by testing that a correct key
        works.
        """
        httpd, port, _ = _setup_server(api_key="test-secret-key")
        try:
            # From localhost, should still work without key (localhost bypass)
            status, _ = _get_json(port, "/v1/ui/overview")
            assert status == 200
        finally:
            httpd.shutdown()

    def test_correct_api_key_returns_200(self):
        """Test 14: Request with correct X-Api-Key header returns 200."""
        httpd, port, _ = _setup_server(api_key="test-secret-key")
        try:
            status, data = _get_json(
                port, "/v1/ui/overview",
                headers={"X-Api-Key": "test-secret-key"},
            )
            assert status == 200
            assert "active_agents" in data
        finally:
            httpd.shutdown()

    def test_localhost_bypass_without_key_returns_200(self):
        """Test 15: Request from 127.0.0.1 without key returns 200."""
        httpd, port, _ = _setup_server(api_key="some-key")
        try:
            status, _ = _get_json(port, "/v1/ui/overview")
            assert status == 200
        finally:
            httpd.shutdown()


class TestOverviewWithData:
    """Additional tests with seeded data."""

    def test_overview_with_agents_shows_counts(self):
        """Overview shows non-zero counts when audit records exist."""
        import tempfile
        base_dir = Path(tempfile.mkdtemp())
        _seed_audit_records(base_dir, "agent-x", count=10)
        httpd, port, _ = _setup_server(base_dir=base_dir)
        try:
            status, data = _get_json(port, "/v1/ui/overview")
            assert status == 200
            assert data["evaluations_today"] > 0
        finally:
            httpd.shutdown()

    def test_feed_sorted_newest_first(self):
        """Feed items are sorted newest-first."""
        import tempfile
        base_dir = Path(tempfile.mkdtemp())
        _seed_audit_records(base_dir, "agent-y", count=5)
        httpd, port, _ = _setup_server(base_dir=base_dir)
        try:
            status, data = _get_json(port, "/v1/ui/feed")
            assert status == 200
            assert len(data) >= 2
            # Timestamps should be descending
            assert data[0]["timestamp"] >= data[1]["timestamp"]
        finally:
            httpd.shutdown()

    def test_events_contains_overview_event(self):
        """SSE response contains an 'overview' event."""
        httpd, port, _ = _setup_server()
        try:
            status, body, _ = _get(port, "/v1/ui/events")
            text = body.decode("utf-8")
            assert "event: overview" in text
            assert "data:" in text
        finally:
            httpd.shutdown()

    def test_ui_export_returns_200(self):
        """POST /v1/ui/export returns success response."""
        httpd, port, _ = _setup_server()
        try:
            status, body, headers = _post_full(port, "/v1/ui/export")
            assert status == 200
            assert b"Nomotic" in body
        finally:
            httpd.shutdown()


class TestUIExportSnapshot:
    """Tests for POST /v1/ui/export — dashboard snapshot export (F-13)."""

    def test_export_html_returns_content_disposition_attachment(self):
        """POST /v1/ui/export?format=html returns Content-Disposition with attachment."""
        httpd, port, _ = _setup_server()
        try:
            status, body, headers = _post_full(
                port, "/v1/ui/export?format=html",
            )
            assert status == 200
            cd = headers.get("Content-Disposition", "")
            assert "attachment" in cd
            assert "nomotic-snapshot-" in cd
            assert cd.endswith('.html"')
        finally:
            httpd.shutdown()

    def test_export_html_returns_html_content_type(self):
        """POST /v1/ui/export?format=html returns Content-Type: text/html."""
        httpd, port, _ = _setup_server()
        try:
            status, body, headers = _post_full(
                port, "/v1/ui/export?format=html",
            )
            assert status == 200
            assert "text/html" in headers.get("Content-Type", "")
        finally:
            httpd.shutdown()

    def test_export_json_returns_json_content_type(self):
        """POST /v1/ui/export?format=json returns Content-Type: application/json."""
        httpd, port, _ = _setup_server()
        try:
            status, body, headers = _post_full(
                port, "/v1/ui/export?format=json",
            )
            assert status == 200
            assert "application/json" in headers.get("Content-Type", "")
        finally:
            httpd.shutdown()

    def test_export_json_returns_valid_json(self):
        """POST /v1/ui/export?format=json returns valid JSON with snapshot keys."""
        import tempfile
        base_dir = Path(tempfile.mkdtemp())
        _seed_audit_records(base_dir, "export-agent", count=3)
        httpd, port, _ = _setup_server(base_dir=base_dir)
        try:
            status, body, headers = _post_full(
                port, "/v1/ui/export?format=json",
            )
            assert status == 200
            data = json.loads(body.decode("utf-8"))
            assert "exported_at" in data
            assert "overview" in data
            assert "feed" in data
        finally:
            httpd.shutdown()
