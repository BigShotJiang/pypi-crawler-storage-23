"""Tests for the demo agent — database setup and tool registration."""

import sqlite3

from examples.demo_agent import create_demo_db, create_demo_tools


class TestDemoDatabase:
    """Test demo database creation."""

    def test_creates_all_tables(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = {row[0] for row in cursor.fetchall()}
        assert "customers" in tables
        assert "orders" in tables
        assert "employee_salaries" in tables
        assert "user_credentials" in tables
        assert "system_audit_log" in tables
        conn.close()

    def test_customers_populated(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM customers")
        count = cursor.fetchone()[0]
        assert count == 5
        conn.close()

    def test_orders_populated(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders")
        count = cursor.fetchone()[0]
        assert count == 6
        conn.close()

    def test_salaries_populated(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM employee_salaries")
        count = cursor.fetchone()[0]
        assert count == 3
        conn.close()

    def test_credentials_populated(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM user_credentials")
        count = cursor.fetchone()[0]
        assert count == 2
        conn.close()

    def test_idempotent_inserts(self):
        """Calling create_demo_db twice on same db doesn't duplicate data."""
        conn = sqlite3.connect(":memory:")
        # Manually run the function logic twice on the same connection
        create_demo_db.__wrapped__ = None  # just verify no crash
        conn2 = create_demo_db(":memory:")
        cursor = conn2.cursor()
        cursor.execute("SELECT COUNT(*) FROM customers")
        assert cursor.fetchone()[0] == 5
        conn.close()
        conn2.close()

    def test_customer_data_correct(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("SELECT name, email FROM customers WHERE name = 'Alice Chen'")
        row = cursor.fetchone()
        assert row is not None
        assert row[0] == "Alice Chen"
        assert row[1] == "alice@example.com"
        conn.close()

    def test_order_references_customer(self):
        conn = create_demo_db(":memory:")
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.name, o.product
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE c.name = 'Alice Chen'
        """)
        rows = cursor.fetchall()
        assert len(rows) == 2
        products = {row[1] for row in rows}
        assert "Widget Pro" in products
        assert "Gadget Max" in products
        conn.close()


class TestDemoTools:
    """Test tool registration and basic function execution."""

    def test_tools_registered(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        names = tools.names()
        assert "query_table" in names
        assert "list_tables" in names
        assert "describe_table" in names
        assert "insert_record" in names
        assert "update_record" in names
        assert "delete_record" in names
        assert "write_report" in names
        conn.close()

    def test_query_table_returns_results(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("query_table")
        result = tool_def.function(
            table="customers",
            sql="SELECT name FROM customers WHERE status = 'active'",
        )
        assert "Alice Chen" in result
        assert "Bob Smith" in result
        conn.close()

    def test_query_table_no_results(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("query_table")
        result = tool_def.function(
            table="customers",
            sql="SELECT name FROM customers WHERE status = 'nonexistent'",
        )
        assert "No results" in result
        conn.close()

    def test_list_tables(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("list_tables")
        result = tool_def.function()
        assert "customers" in result
        assert "orders" in result
        assert "employee_salaries" in result
        conn.close()

    def test_describe_table(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("describe_table")
        result = tool_def.function(table="customers")
        assert "name" in result
        assert "email" in result
        assert "TEXT" in result
        conn.close()

    def test_insert_record(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("insert_record")
        result = tool_def.function(
            table="customers",
            sql="INSERT INTO customers (name, email) VALUES ('Test User', 'test@example.com')",
        )
        assert "Inserted 1 record" in result

        # Verify the insert worked
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM customers WHERE name = 'Test User'")
        assert cursor.fetchone() is not None
        conn.close()

    def test_update_record(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("update_record")
        result = tool_def.function(
            table="customers",
            sql="UPDATE customers SET status = 'vip' WHERE name = 'Alice Chen'",
        )
        assert "Updated 1 record" in result
        conn.close()

    def test_delete_record(self):
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        tool_def = tools.get("delete_record")
        result = tool_def.function(
            table="customers",
            sql="DELETE FROM customers WHERE name = 'Carol Davis'",
        )
        assert "Deleted 1 record" in result

        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM customers")
        assert cursor.fetchone()[0] == 4
        conn.close()

    def test_to_claude_tools_format(self):
        """Tools export correctly for Claude API."""
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        claude_tools = tools.to_claude_tools()
        assert len(claude_tools) == 7

        # Each tool should have required fields
        for tool in claude_tools:
            assert "name" in tool
            assert "description" in tool
            assert "input_schema" in tool
            assert tool["input_schema"]["type"] == "object"

        # Check specific tools have correct schemas
        query_tool = next(t for t in claude_tools if t["name"] == "query_table")
        assert "table" in query_tool["input_schema"]["properties"]
        assert "sql" in query_tool["input_schema"]["properties"]
        conn.close()

    def test_action_types_set(self):
        """Tools have correct action_type for governance."""
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)

        assert tools.get("query_table").action_type == "read"
        assert tools.get("list_tables").action_type == "read"
        assert tools.get("describe_table").action_type == "read"
        assert tools.get("insert_record").action_type == "write"
        assert tools.get("update_record").action_type == "write"
        assert tools.get("delete_record").action_type == "delete"
        assert tools.get("write_report").action_type == "write"
        conn.close()

    def test_extract_target_functions(self):
        """Tools with extract_target correctly extract from args."""
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)

        query_def = tools.get("query_table")
        assert query_def.extract_target({"table": "customers"}) == "customers"

        delete_def = tools.get("delete_record")
        assert delete_def.extract_target({"table": "orders"}) == "orders"

        report_def = tools.get("write_report")
        assert report_def.extract_target({"filename": "report.txt"}) == "report.txt"
        conn.close()

    def test_static_target(self):
        """list_tables has a static target."""
        conn = create_demo_db(":memory:")
        tools = create_demo_tools(conn)
        assert tools.get("list_tables").target == "schema"
        conn.close()
