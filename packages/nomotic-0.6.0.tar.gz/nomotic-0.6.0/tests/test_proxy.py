"""Tests for the HTTP governance proxy."""

from __future__ import annotations

from pathlib import Path

from nomotic.proxy import METHOD_ACTION_MAP, GovernanceProxyHandler


class TestMethodActionMapping:
    def test_get_maps_to_read(self):
        assert METHOD_ACTION_MAP["GET"] == "read"

    def test_post_maps_to_write(self):
        assert METHOD_ACTION_MAP["POST"] == "write"

    def test_put_maps_to_write(self):
        assert METHOD_ACTION_MAP["PUT"] == "write"

    def test_patch_maps_to_write(self):
        assert METHOD_ACTION_MAP["PATCH"] == "write"

    def test_delete_maps_to_delete(self):
        assert METHOD_ACTION_MAP["DELETE"] == "delete"

    def test_head_maps_to_read(self):
        assert METHOD_ACTION_MAP["HEAD"] == "read"

    def test_options_maps_to_read(self):
        assert METHOD_ACTION_MAP["OPTIONS"] == "read"

    def test_all_standard_methods_covered(self):
        expected = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}
        assert set(METHOD_ACTION_MAP.keys()) == expected


class TestGovernanceProxyHandler:
    def test_handler_class_attributes_exist(self):
        assert hasattr(GovernanceProxyHandler, "executor")
        assert hasattr(GovernanceProxyHandler, "upstream_url")

    def test_handler_has_method_handlers(self):
        assert hasattr(GovernanceProxyHandler, "do_GET")
        assert hasattr(GovernanceProxyHandler, "do_POST")
        assert hasattr(GovernanceProxyHandler, "do_PUT")
        assert hasattr(GovernanceProxyHandler, "do_PATCH")
        assert hasattr(GovernanceProxyHandler, "do_DELETE")


class TestDockerBuild:
    def test_dockerfile_exists(self):
        assert Path("Dockerfile").exists()

    def test_docker_compose_exists(self):
        assert Path("docker-compose.yml").exists()

    def test_deploy_prometheus_config_exists(self):
        assert Path("deploy/prometheus.yml").exists()

    def test_deploy_grafana_datasource_exists(self):
        assert Path("deploy/grafana-datasource.yml").exists()

    def test_deploy_grafana_dashboard_provider_exists(self):
        assert Path("deploy/grafana-dashboard-provider.yml").exists()


class TestHelmChart:
    def test_chart_yaml_exists(self):
        assert Path("helm/nomotic/Chart.yaml").exists()

    def test_values_yaml_exists(self):
        assert Path("helm/nomotic/values.yaml").exists()

    def test_deployment_template_exists(self):
        assert Path("helm/nomotic/templates/deployment.yaml").exists()

    def test_service_template_exists(self):
        assert Path("helm/nomotic/templates/service.yaml").exists()

    def test_pvc_template_exists(self):
        assert Path("helm/nomotic/templates/pvc.yaml").exists()

    def test_ingress_template_exists(self):
        assert Path("helm/nomotic/templates/ingress.yaml").exists()

    def test_serviceaccount_template_exists(self):
        assert Path("helm/nomotic/templates/serviceaccount.yaml").exists()

    def test_helpers_template_exists(self):
        assert Path("helm/nomotic/templates/_helpers.tpl").exists()

    def test_configmap_template_exists(self):
        assert Path("helm/nomotic/templates/configmap.yaml").exists()


class TestServerModule:
    def test_server_module_importable(self):
        import nomotic.server  # should not crash
        assert hasattr(nomotic.server, "main")

    def test_server_load_or_create_issuer(self):
        from nomotic.server import _load_or_create_issuer
        assert callable(_load_or_create_issuer)

    def test_proxy_module_importable(self):
        import nomotic.proxy  # should not crash
        assert hasattr(nomotic.proxy, "start_proxy")
        assert hasattr(nomotic.proxy, "GovernanceProxyHandler")
        assert hasattr(nomotic.proxy, "METHOD_ACTION_MAP")
