"""Tests for custom compliance framework loading, discovery, and registration."""

import json
import warnings
from pathlib import Path

import pytest

from nomotic.compliance_report import (
    FRAMEWORK_MAPPINGS,
    ComplianceReportGenerator,
    ControlMapping,
    FrameworkLoadError,
    FrameworkMapping,
    discover_frameworks,
    format_json,
    format_markdown,
    load_custom_framework,
)


# ── Helpers ─────────────────────────────────────────────────────────────


def _valid_framework_data(**overrides: object) -> dict:
    """Return a minimal valid custom framework dict."""
    base: dict = {
        "framework_id": "test-fw",
        "name": "Test Framework",
        "controls": [
            {
                "control_id": "TF-001",
                "description": "Test control one",
                "nomotic_dimensions": ["scope_compliance"],
                "coverage": "full",
                "notes": "Test notes",
            },
            {
                "control_id": "TF-002",
                "description": "Test control two",
                "nomotic_dimensions": ["human_override", "authority_verification"],
                "coverage": "partial",
            },
        ],
    }
    base.update(overrides)
    return base


def _write_framework(path: Path, data: dict | None = None) -> Path:
    """Write a framework JSON file and return the path."""
    if data is None:
        data = _valid_framework_data()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


# ── TestLoadCustomFramework ─────────────────────────────────────────────


class TestLoadCustomFramework:
    """Tests for load_custom_framework()."""

    def test_valid_framework_loads(self, tmp_path: Path) -> None:
        p = _write_framework(tmp_path / "fw.json")
        fm = load_custom_framework(p)
        assert isinstance(fm, FrameworkMapping)

    def test_framework_id_populated(self, tmp_path: Path) -> None:
        p = _write_framework(tmp_path / "fw.json")
        fm = load_custom_framework(p)
        assert fm.framework_id == "test-fw"

    def test_framework_name_populated(self, tmp_path: Path) -> None:
        p = _write_framework(tmp_path / "fw.json")
        fm = load_custom_framework(p)
        assert fm.framework_name == "Test Framework"

    def test_controls_populated(self, tmp_path: Path) -> None:
        p = _write_framework(tmp_path / "fw.json")
        fm = load_custom_framework(p)
        assert len(fm.controls) == 2
        assert fm.controls[0].control_id == "TF-001"
        assert fm.controls[1].control_id == "TF-002"

    def test_control_coverage_set(self, tmp_path: Path) -> None:
        p = _write_framework(tmp_path / "fw.json")
        fm = load_custom_framework(p)
        assert fm.controls[0].coverage == "full"
        assert fm.controls[1].coverage == "partial"

    def test_optional_fields_default(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        # No version, no description, no notes on second control
        p = _write_framework(tmp_path / "fw.json", data)
        fm = load_custom_framework(p)
        assert fm.version == ""
        assert fm.description == ""
        assert fm.controls[1].notes == ""

    def test_optional_fields_populated(self, tmp_path: Path) -> None:
        data = _valid_framework_data(version="2026-Q1", description="A test")
        p = _write_framework(tmp_path / "fw.json", data)
        fm = load_custom_framework(p)
        assert fm.version == "2026-Q1"
        assert fm.description == "A test"

    def test_missing_framework_id_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["framework_id"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="framework_id"):
            load_custom_framework(p)

    def test_missing_name_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["name"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="name"):
            load_custom_framework(p)

    def test_missing_controls_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["controls"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="controls"):
            load_custom_framework(p)

    def test_empty_controls_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data(controls=[])
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="non-empty"):
            load_custom_framework(p)

    def test_control_missing_control_id_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["controls"][0]["control_id"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="control_id"):
            load_custom_framework(p)

    def test_control_missing_description_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["controls"][0]["description"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="description"):
            load_custom_framework(p)

    def test_control_missing_dimensions_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["controls"][0]["nomotic_dimensions"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="nomotic_dimensions"):
            load_custom_framework(p)

    def test_control_missing_coverage_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        del data["controls"][0]["coverage"]
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="coverage"):
            load_custom_framework(p)

    def test_invalid_coverage_raises(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        data["controls"][0]["coverage"] = "complete"
        p = _write_framework(tmp_path / "fw.json", data)
        with pytest.raises(FrameworkLoadError, match="invalid coverage"):
            load_custom_framework(p)

    def test_non_json_file_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "fw.json"
        p.write_text("this is not json", encoding="utf-8")
        with pytest.raises(FrameworkLoadError, match="Invalid JSON"):
            load_custom_framework(p)

    def test_non_existent_file_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "missing.json"
        with pytest.raises(FrameworkLoadError, match="does not exist"):
            load_custom_framework(p)

    def test_unknown_dimension_warns(self, tmp_path: Path) -> None:
        data = _valid_framework_data()
        data["controls"][0]["nomotic_dimensions"] = ["scope_compliance", "magic_dimension"]
        p = _write_framework(tmp_path / "fw.json", data)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            fm = load_custom_framework(p)
            assert len(w) == 1
            assert "magic_dimension" in str(w[0].message)
        # Should still load successfully
        assert fm.framework_id == "test-fw"

    def test_error_attributes_accessible(self, tmp_path: Path) -> None:
        p = tmp_path / "missing.json"
        with pytest.raises(FrameworkLoadError) as exc_info:
            load_custom_framework(p)
        assert exc_info.value.path == str(p)
        assert "does not exist" in exc_info.value.reason


# ── TestDiscoverFrameworks ──────────────────────────────────────────────


class TestDiscoverFrameworks:
    """Tests for discover_frameworks()."""

    def test_empty_directories_returns_empty(self, tmp_path: Path) -> None:
        d = tmp_path / "empty"
        d.mkdir()
        result = discover_frameworks(extra_dirs=[d])
        # No JSON files → empty
        assert isinstance(result, dict)

    def test_framework_in_extra_dir_discovered(self, tmp_path: Path) -> None:
        d = tmp_path / "frameworks"
        d.mkdir()
        _write_framework(d / "my-fw.json", _valid_framework_data(framework_id="my-fw"))
        result = discover_frameworks(extra_dirs=[d])
        assert "my-fw" in result
        assert result["my-fw"] == d / "my-fw.json"

    def test_same_id_later_dir_wins(self, tmp_path: Path) -> None:
        d1 = tmp_path / "dir1"
        d2 = tmp_path / "dir2"
        d1.mkdir()
        d2.mkdir()
        _write_framework(d1 / "fw.json", _valid_framework_data(
            framework_id="shared", name="From Dir1",
        ))
        _write_framework(d2 / "fw.json", _valid_framework_data(
            framework_id="shared", name="From Dir2",
        ))
        result = discover_frameworks(extra_dirs=[d1, d2])
        assert "shared" in result
        # dir2 should win (later overrides earlier)
        assert result["shared"] == d2 / "fw.json"

    def test_invalid_json_skipped_with_warning(self, tmp_path: Path) -> None:
        d = tmp_path / "frameworks"
        d.mkdir()
        # Write one valid, one invalid
        _write_framework(d / "good.json", _valid_framework_data(framework_id="good"))
        (d / "bad.json").write_text("NOT JSON", encoding="utf-8")
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = discover_frameworks(extra_dirs=[d])
            assert len(w) >= 1
            assert any("bad.json" in str(warning.message) for warning in w)
        assert "good" in result

    def test_nonexistent_dir_handled(self, tmp_path: Path) -> None:
        d = tmp_path / "does_not_exist"
        result = discover_frameworks(extra_dirs=[d])
        assert result == {}

    def test_home_dir_discovery(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        fake_home = tmp_path / "fakehome"
        fw_dir = fake_home / ".nomotic" / "frameworks"
        fw_dir.mkdir(parents=True)
        _write_framework(fw_dir / "org-policy.json", _valid_framework_data(framework_id="org-policy"))
        monkeypatch.setattr(Path, "home", classmethod(lambda cls: fake_home))
        result = discover_frameworks()
        assert "org-policy" in result

    def test_cwd_discovery(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        fw_dir = tmp_path / "nomotic-frameworks"
        fw_dir.mkdir()
        _write_framework(fw_dir / "cwd-fw.json", _valid_framework_data(framework_id="cwd-fw"))
        monkeypatch.setattr(Path, "cwd", classmethod(lambda cls: tmp_path))
        # Also mock home to avoid picking up real frameworks
        monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path / "nohome"))
        result = discover_frameworks()
        assert "cwd-fw" in result


# ── TestCustomFrameworkRegistration ─────────────────────────────────────


class TestCustomFrameworkRegistration:
    """Tests for ComplianceReportGenerator custom framework methods."""

    def _make_custom_fm(self, **overrides: object) -> FrameworkMapping:
        defaults: dict = {
            "framework_id": "custom-fw",
            "framework_name": "Custom Framework",
            "version": "1.0",
            "controls": [
                ControlMapping(
                    "C-001", "Custom Control", "A custom control",
                    ["scope_compliance"], "full", "Custom notes",
                ),
            ],
        }
        defaults.update(overrides)
        return FrameworkMapping(**defaults)

    def test_register_adds_to_generator(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        fm = self._make_custom_fm()
        gen.register_custom_framework(fm)
        frameworks = gen.list_frameworks()
        assert "custom-fw" in frameworks

    def test_custom_framework_usable_by_generate(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        fm = self._make_custom_fm()
        gen.register_custom_framework(fm)
        report = gen.generate(framework="custom-fw")
        assert report.framework_id == "custom-fw"
        assert len(report.controls) == 1

    def test_custom_framework_in_list_frameworks(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        fm = self._make_custom_fm()
        gen.register_custom_framework(fm)
        frameworks = gen.list_frameworks()
        assert "custom-fw" in frameworks
        assert "(custom)" in frameworks["custom-fw"]

    def test_custom_overrides_builtin(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        fm = self._make_custom_fm(framework_id="soc2", framework_name="My SOC2")
        gen.register_custom_framework(fm)
        report = gen.generate(framework="soc2")
        assert report.framework_name == "My SOC2"
        assert len(report.controls) == 1  # Only our custom control

    def test_load_frameworks_from_dir_returns_count(self, tmp_path: Path) -> None:
        fw_dir = tmp_path / "fws"
        fw_dir.mkdir()
        _write_framework(fw_dir / "a.json", _valid_framework_data(framework_id="fw-a"))
        _write_framework(fw_dir / "b.json", _valid_framework_data(framework_id="fw-b"))
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        count = gen.load_frameworks_from_dir(fw_dir)
        assert count == 2

    def test_load_frameworks_from_dir_invalid_skipped(self, tmp_path: Path) -> None:
        fw_dir = tmp_path / "fws"
        fw_dir.mkdir()
        _write_framework(fw_dir / "good.json", _valid_framework_data(framework_id="good"))
        (fw_dir / "bad.json").write_text("NOPE", encoding="utf-8")
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            count = gen.load_frameworks_from_dir(fw_dir)
        assert count == 1
        assert "good" in gen.list_frameworks()

    def test_load_frameworks_from_nonexistent_dir(self, tmp_path: Path) -> None:
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        count = gen.load_frameworks_from_dir(tmp_path / "nope")
        assert count == 0


# ── TestComplianceReportWithCustomFramework ─────────────────────────────


class TestComplianceReportWithCustomFramework:
    """Tests for generating reports with custom frameworks."""

    def _load_and_generate(self, tmp_path: Path) -> tuple:
        p = _write_framework(tmp_path / "fw.json", _valid_framework_data(
            framework_id="custom-test",
            name="Custom Test Framework",
            version="1.0",
            description="A test custom framework",
        ))
        fm = load_custom_framework(p)
        gen = ComplianceReportGenerator(base_dir=tmp_path)
        gen.register_custom_framework(fm)
        report = gen.generate(framework="custom-test")
        return fm, gen, report

    def test_generates_compliance_report(self, tmp_path: Path) -> None:
        _fm, _gen, report = self._load_and_generate(tmp_path)
        from nomotic.compliance_report import ComplianceReport
        assert isinstance(report, ComplianceReport)

    def test_report_framework_id_matches(self, tmp_path: Path) -> None:
        _fm, _gen, report = self._load_and_generate(tmp_path)
        assert report.framework_id == "custom-test"

    def test_report_controls_count(self, tmp_path: Path) -> None:
        fm, _gen, report = self._load_and_generate(tmp_path)
        assert len(report.controls) == len(fm.controls)

    def test_format_markdown_includes_name(self, tmp_path: Path) -> None:
        _fm, _gen, report = self._load_and_generate(tmp_path)
        md = format_markdown(report)
        assert "Custom Test Framework" in md

    def test_format_json_valid(self, tmp_path: Path) -> None:
        _fm, _gen, report = self._load_and_generate(tmp_path)
        d = format_json(report)
        # Verify it's valid JSON-serializable
        output = json.dumps(d)
        assert isinstance(output, str)
        assert d["framework_id"] == "custom-test"


# ── TestCLICustomFramework ──────────────────────────────────────────────


class TestCLICustomFramework:
    """Tests for CLI integration with custom frameworks."""

    def test_framework_file_path_loads(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        p = _write_framework(tmp_path / "my-framework.json")
        main([
            "--base-dir", str(tmp_path),
            "compliance-report",
            "--framework", str(p),
        ])

    def test_framework_file_with_output(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        p = _write_framework(tmp_path / "my-framework.json")
        out = tmp_path / "report.json"
        main([
            "--base-dir", str(tmp_path),
            "compliance-report",
            "--framework", str(p),
            "--output", str(out),
        ])
        assert out.exists()
        data = json.loads(out.read_text())
        assert data["framework_id"] == "test-fw"

    def test_list_frameworks_includes_builtins(self, tmp_path: Path, capsys: pytest.CaptureFixture) -> None:
        from nomotic.cli import main

        main([
            "--base-dir", str(tmp_path),
            "compliance-report",
            "--list-frameworks",
        ])
        captured = capsys.readouterr()
        assert "soc2" in captured.out
        assert "hipaa" in captured.out
        assert "eu-ai-act" in captured.out

    def test_nonexistent_json_errors(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        with pytest.raises(SystemExit):
            main([
                "--base-dir", str(tmp_path),
                "compliance-report",
                "--framework", str(tmp_path / "nonexistent.json"),
            ])

    def test_no_framework_no_list_errors(self, tmp_path: Path) -> None:
        from nomotic.cli import main

        with pytest.raises(SystemExit):
            main([
                "--base-dir", str(tmp_path),
                "compliance-report",
            ])
