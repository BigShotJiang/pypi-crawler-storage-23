"""Tests for the nomotic init CLI command (F-08)."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from nomotic.cli import (
    ARCHETYPE_PRESET_MAP,
    build_parser,
    generate_hello_script,
    generate_nomotic_yaml,
    main,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_setup_config(
    base_dir: str,
    org: str = "acme-corp",
    owner: str = "admin@acme.com",
    zone: str = "global",
) -> None:
    """Write a minimal config.json simulating `nomotic setup` output."""
    config = {
        "organization": org,
        "owner": owner,
        "default_zone": zone,
    }
    Path(base_dir, "config.json").write_text(
        json.dumps(config), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestInitCommandEndToEnd:
    """End-to-end tests for 'nomotic init'."""

    def test_creates_nomotic_yaml(self, capsys):
        """nomotic init --name --archetype --no-interactive creates nomotic.yaml."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            assert (Path(out) / "nomotic.yaml").exists()

    def test_nomotic_yaml_is_valid_yaml(self, capsys):
        """Generated nomotic.yaml parses as valid YAML."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "nomotic.yaml").read_text(encoding="utf-8")
            data = yaml.safe_load(content)
            assert isinstance(data, dict)

    def test_nomotic_yaml_contains_agent_name(self, capsys):
        """nomotic.yaml contains the agent name from --name argument."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "my-special-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "nomotic.yaml").read_text(encoding="utf-8")
            data = yaml.safe_load(content)
            assert data["agent"]["name"] == "my-special-agent"

    def test_nomotic_yaml_contains_archetype(self, capsys):
        """nomotic.yaml contains the archetype from --archetype argument."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "financial-analyst",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "nomotic.yaml").read_text(encoding="utf-8")
            data = yaml.safe_load(content)
            assert data["agent"]["archetype"] == "financial-analyst"

    def test_nomotic_yaml_hipaa_preset_for_healthcare(self, capsys):
        """nomotic.yaml has compliance.preset = hipaa_aligned for healthcare-agent."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "nomotic.yaml").read_text(encoding="utf-8")
            data = yaml.safe_load(content)
            assert data["compliance"]["preset"] == "hipaa_aligned"

    def test_nomotic_yaml_weight_hint_comment_for_legal_assistant(self, capsys):
        """nomotic.yaml contains weight hint comment for legal-assistant alias."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "legal-assistant",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "nomotic.yaml").read_text(encoding="utf-8")
            assert "jurisdictional_compliance" in content

    def test_creates_hello_nomotic_py(self, capsys):
        """nomotic init creates hello_nomotic.py in output-dir."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            assert (Path(out) / "hello_nomotic.py").exists()

    def test_hello_nomotic_is_valid_python(self, capsys):
        """hello_nomotic.py is valid Python (compiles without errors)."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            content = (Path(out) / "hello_nomotic.py").read_text(encoding="utf-8")
            compile(content, "hello_nomotic.py", "exec")

    def test_creates_gitignore(self, capsys):
        """nomotic init creates .gitignore with nomotic-private.pem entry."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            gitignore = (Path(out) / ".gitignore").read_text(encoding="utf-8")
            assert "nomotic-private.pem" in gitignore

    def test_appends_to_existing_gitignore(self, capsys):
        """nomotic init appends to existing .gitignore without overwriting."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            existing_content = "node_modules/\n*.pyc\n"
            (Path(out) / ".gitignore").write_text(existing_content, encoding="utf-8")

            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            gitignore = (Path(out) / ".gitignore").read_text(encoding="utf-8")
            assert "node_modules/" in gitignore
            assert "*.pyc" in gitignore
            assert "nomotic-private.pem" in gitignore

    def test_no_setup_config_exits_with_error(self, capsys):
        """nomotic init with no setup config prints 'Run: nomotic setup' and exits 1."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            # No config.json written — setup not run
            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", base,
                    "init",
                    "--name", "test-agent",
                    "--archetype", "healthcare-agent",
                    "--no-interactive",
                    "--output-dir", out,
                ])
            assert exc_info.value.code == 1
            captured = capsys.readouterr()
            assert "nomotic setup" in captured.err

    def test_no_interactive_without_archetype_exits(self, capsys):
        """nomotic init --no-interactive without --archetype exits 1."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", base,
                    "init",
                    "--name", "test-agent",
                    "--no-interactive",
                    "--output-dir", out,
                ])
            assert exc_info.value.code == 1
            captured = capsys.readouterr()
            assert "--archetype" in captured.err

    def test_no_interactive_without_name_exits(self, capsys):
        """nomotic init --no-interactive without --name exits 1."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            with pytest.raises(SystemExit) as exc_info:
                main([
                    "--base-dir", base,
                    "init",
                    "--archetype", "healthcare-agent",
                    "--no-interactive",
                    "--output-dir", out,
                ])
            assert exc_info.value.code == 1
            captured = capsys.readouterr()
            assert "--name" in captured.err

    def test_output_dir_writes_files(self, capsys):
        """nomotic init --output-dir writes all files to that directory."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as parent:
            out = str(Path(parent) / "subdir" / "project")
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            out_path = Path(out)
            assert (out_path / "nomotic.yaml").exists()
            assert (out_path / "hello_nomotic.py").exists()
            assert (out_path / ".gitignore").exists()

    def test_certificate_issuance_called(self, capsys):
        """nomotic init calls certificate issuance with correct archetype."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "cert-test-agent",
                "--archetype", "security-monitor",
                "--no-interactive",
                "--output-dir", out,
            ])
            # Verify cert was created by checking the certs directory
            certs_dir = Path(base) / "certs"
            assert certs_dir.exists()
            cert_files = list(certs_dir.glob("nmc-*.json"))
            assert len(cert_files) >= 1
            # Verify the cert has the right archetype
            cert_data = json.loads(cert_files[0].read_text(encoding="utf-8"))
            assert cert_data["archetype"] == "security-monitor"

    def test_summary_output(self, capsys):
        """Summary output contains 'python hello_nomotic.py' and 'nomotic serve --ui'."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as out:
            _write_setup_config(base)
            main([
                "--base-dir", base,
                "init",
                "--name", "test-agent",
                "--archetype", "healthcare-agent",
                "--no-interactive",
                "--output-dir", out,
            ])
            captured = capsys.readouterr()
            assert "python hello_nomotic.py" in captured.out
            assert "nomotic serve --ui" in captured.out


class TestInitArgParsing:
    """Test that the init subparser is correctly registered."""

    def test_init_parser_name(self):
        parser = build_parser()
        args = parser.parse_args([
            "init",
            "--name", "my-agent",
            "--archetype", "healthcare-agent",
            "--no-interactive",
        ])
        assert args.command == "init"
        assert args.name == "my-agent"
        assert args.archetype == "healthcare-agent"
        assert args.no_interactive is True

    def test_init_parser_framework_choices(self):
        parser = build_parser()
        args = parser.parse_args([
            "init",
            "--name", "my-agent",
            "--archetype", "healthcare-agent",
            "--framework", "langgraph",
            "--no-interactive",
        ])
        assert args.framework == "langgraph"

    def test_init_parser_output_dir_default(self):
        parser = build_parser()
        args = parser.parse_args([
            "init",
            "--name", "my-agent",
            "--archetype", "healthcare-agent",
            "--no-interactive",
        ])
        assert args.output_dir == "."


class TestGenerateNomoticYaml:
    """Unit tests for generate_nomotic_yaml()."""

    def test_valid_yaml(self):
        content = generate_nomotic_yaml(
            name="test-agent",
            archetype="healthcare-agent",
            preset="hipaa_aligned",
            org="acme",
            zone="global",
            weight_hints={},
        )
        data = yaml.safe_load(content)
        assert data["agent"]["name"] == "test-agent"
        assert data["agent"]["archetype"] == "healthcare-agent"
        assert data["compliance"]["preset"] == "hipaa_aligned"

    def test_weight_hints_in_comments(self):
        content = generate_nomotic_yaml(
            name="test-agent",
            archetype="legal-assistant",
            preset="soc2_aligned",
            org="acme",
            zone="global",
            weight_hints={"jurisdictional_compliance": 0.2},
        )
        assert "jurisdictional_compliance" in content
        assert "+0.2" in content

    def test_org_fallback(self):
        content = generate_nomotic_yaml(
            name="test-agent",
            archetype="healthcare-agent",
            preset="hipaa_aligned",
            org=None,
            zone="global",
            weight_hints={},
        )
        data = yaml.safe_load(content)
        assert data["agent"]["organization"] == "your-organization"


class TestGenerateHelloScript:
    """Unit tests for generate_hello_script()."""

    def test_valid_python_generic(self):
        script = generate_hello_script("healthcare-agent", None)
        compile(script, "hello_nomotic.py", "exec")

    def test_valid_python_langgraph(self):
        script = generate_hello_script("healthcare-agent", "langgraph")
        compile(script, "hello_nomotic.py", "exec")
        assert "LangGraph" in script

    def test_valid_python_crewai(self):
        script = generate_hello_script("healthcare-agent", "crewai")
        compile(script, "hello_nomotic.py", "exec")
        assert "crewai" in script

    def test_archetype_specific_vocab(self):
        script = generate_hello_script("financial-analyst", None)
        assert "market_trade" in script

    def test_unknown_archetype_gets_defaults(self):
        script = generate_hello_script("unknown-archetype", None)
        compile(script, "hello_nomotic.py", "exec")
        assert "data_source" in script
