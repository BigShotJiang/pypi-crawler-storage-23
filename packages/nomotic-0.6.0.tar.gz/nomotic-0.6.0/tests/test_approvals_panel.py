"""Tests for the Approval Queue Dashboard Panel (F-05 Part B).

Minimum 8 tests covering:
  GET /v1/ui/panels/approval-queue (HTML panel rendering)
  POST approve/deny with Accept: text/html (HTML response)
"""

from __future__ import annotations

import json
import threading
import time
import uuid
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.store import MemoryCertificateStore
from nomotic.types import (
    MultiSigOverridePolicy,
    OverrideSignature,
    PendingOverride,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _create_pending(runtime: GovernanceRuntime, required: int = 2) -> PendingOverride:
    now = time.time()
    pending = PendingOverride(
        override_id=f"nmpo-{uuid.uuid4()}",
        action_id="test-action-001",
        agent_id="agent-1",
        override_type="APPROVE",
        policy_id="test-policy",
        required_signatures=required,
        status="PENDING",
        created_at=now,
        expires_at=now + 3600,
        original_verdict="DENY",
        initial_authority="admin-1",
        initial_reason="Test override",
    )
    sig = OverrideSignature(
        signature_id=f"nmosig-{uuid.uuid4()}",
        authority="admin-1",
        role_id=None,
        reason="Initial",
        signed_at=now,
        signature_hash=OverrideSignature.compute_hash(
            pending.override_id, "admin-1", "Initial", now
        ),
    )
    pending.signatures.append(sig)
    runtime._pending_overrides[pending.override_id] = pending
    return pending


class PanelClient:
    """HTTP client that can request HTML."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get_html(self, path: str) -> tuple[int, str, str]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                ct = resp.headers.get("Content-Type", "")
                body = resp.read().decode("utf-8")
                return resp.status, body, ct
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8")
            ct = e.headers.get("Content-Type", "")
            return e.code, body, ct

    def post_html(self, path: str, data: dict) -> tuple[int, str, str]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Accept": "text/html",
                },
            )
            with urllib.request.urlopen(req) as resp:
                ct = resp.headers.get("Content-Type", "")
                body = resp.read().decode("utf-8")
                return resp.status, body, ct
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8")
            ct = e.headers.get("Content-Type", "")
            return e.code, body, ct


@pytest.fixture(scope="module")
def panel_server():
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    runtime = GovernanceRuntime(RuntimeConfig())
    policy = MultiSigOverridePolicy(
        policy_id="test-policy",
        name="Test Policy",
        required_signatures=2,
        eligible_roles=["admin"],
    )
    runtime._multisig_policies.append(policy)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = PanelClient(f"http://127.0.0.1:{port}")
    return client, runtime


# ── Test 1: GET /v1/ui/panels/approval-queue returns text/html ──────────


def test_panel_content_type(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert status == 200
    assert "text/html" in ct


# ── Test 2: Response contains card markup with pending overrides ────────


def test_panel_has_cards(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert status == 200
    assert "approval-card" in body
    assert pending.override_id in body


# ── Test 3: Response contains empty state when no pending overrides ─────


def test_panel_empty_state(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert status == 200
    assert "No pending approvals" in body


# ── Test 4: Each card contains countdown timer with data-ttl ────────────


def test_panel_countdown_timer(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    _create_pending(runtime)
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert "data-ttl=" in body
    assert "countdown" in body


# ── Test 5: Each card contains Approve and Deny buttons ─────────────────


def test_panel_approve_deny_buttons(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    _create_pending(runtime)
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert "btn-approve" in body
    assert "btn-deny" in body
    assert "Approve" in body
    assert "Deny" in body


# ── Test 6: POST approve with Accept: text/html returns HTML ────────────


def test_approve_html_response_complete(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body, ct = client.post_html(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2", "reason": "OK"},
    )
    assert status == 200
    assert "text/html" in ct
    assert "complete" in body.lower() or "approval-card" in body


# ── Test 7: POST deny with Accept: text/html returns HTML ──────────────


def test_deny_html_response(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body, ct = client.post_html(
        f"/v1/overrides/pending/{pending.override_id}/deny",
        {"authority": "admin-2", "reason": "No"},
    )
    assert status == 200
    assert "text/html" in ct
    assert "denied" in body.lower()


# ── Test 8: Signature progress bar percentage is correct ────────────────


def test_panel_signature_progress(panel_server):
    client, runtime = panel_server
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime, required=4)
    # 1 of 4 = 25%
    status, body, ct = client.get_html("/v1/ui/panels/approval-queue")
    assert "1 of 4 signatures" in body
    assert "width: 25%" in body
