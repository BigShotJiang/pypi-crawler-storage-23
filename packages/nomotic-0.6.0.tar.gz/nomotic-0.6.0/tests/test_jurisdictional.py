"""Tests for Jurisdictional Compliance — Dimension 14, context, modifiers, and integration."""

from nomotic.types import Action, AgentContext, TrustProfile
from nomotic.dimensions import (
    DimensionRegistry,
    JurisdictionalCompliance,
    JURISDICTION_RULES,
)
from nomotic.context_profile import (
    ContextProfile,
    ContextProfileManager,
    JurisdictionalContext,
    derive_regulations,
)
from nomotic.contextual_modifier import (
    ContextConstraint,
    ContextualModifier,
    ModifierConfig,
    WeightAdjustment,
)
from nomotic.compliance_report import FRAMEWORK_MAPPINGS, ComplianceReportGenerator


# ── Test helpers ───────────────────────────────────────────────────────


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
        action_history=[],
    )


def _action(action_type: str = "read", target: str = "db") -> Action:
    return Action(agent_id="agent-1", action_type=action_type, target=target)


def _dim_with_accessor(jctx):
    """Create a JurisdictionalCompliance dimension with a mock accessor."""
    dim = JurisdictionalCompliance()
    dim.set_jurisdictional_accessor(lambda _: jctx)
    return dim


# ── TestJurisdictionalContext ──────────────────────────────────────────


class TestJurisdictionalContext:
    def test_creation_all_fields(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de", "eu/fr"],
            data_classification="pii",
            agent_operating_zone="eu/de",
            model_inference_zone="eu/de",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="standard_contractual_clauses",
            applicable_regulations=["gdpr"],
            data_subject_jurisdiction="eu/de",
            legal_basis="consent",
            consent_verified=True,
        )
        assert jctx.data_residency_zones == ["eu/de", "eu/fr"]
        assert jctx.data_classification == "pii"
        assert jctx.agent_operating_zone == "eu/de"
        assert jctx.model_inference_zone == "eu/de"
        assert jctx.cross_border_transfer is True
        assert jctx.transfer_destination_zones == ["us/east"]
        assert jctx.transfer_mechanism == "standard_contractual_clauses"
        assert jctx.applicable_regulations == ["gdpr"]
        assert jctx.data_subject_jurisdiction == "eu/de"
        assert jctx.legal_basis == "consent"
        assert jctx.consent_verified is True

    def test_to_dict_from_dict_roundtrip(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            agent_operating_zone="eu/de",
            model_inference_zone="eu/fr",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="adequacy_decision",
            applicable_regulations=["gdpr"],
            data_subject_jurisdiction="eu/de",
            legal_basis="consent",
            consent_verified=True,
        )
        d = jctx.to_dict()
        restored = JurisdictionalContext.from_dict(d)
        assert restored.data_residency_zones == jctx.data_residency_zones
        assert restored.data_classification == jctx.data_classification
        assert restored.agent_operating_zone == jctx.agent_operating_zone
        assert restored.model_inference_zone == jctx.model_inference_zone
        assert restored.cross_border_transfer == jctx.cross_border_transfer
        assert restored.transfer_destination_zones == jctx.transfer_destination_zones
        assert restored.transfer_mechanism == jctx.transfer_mechanism
        assert restored.applicable_regulations == jctx.applicable_regulations
        assert restored.data_subject_jurisdiction == jctx.data_subject_jurisdiction
        assert restored.legal_basis == jctx.legal_basis
        assert restored.consent_verified == jctx.consent_verified

    def test_optional_fields_absent_from_to_dict(self):
        jctx = JurisdictionalContext()
        d = jctx.to_dict()
        assert "agent_operating_zone" not in d
        assert "model_inference_zone" not in d
        assert "transfer_mechanism" not in d
        assert "data_subject_jurisdiction" not in d
        assert "legal_basis" not in d
        # Always-present fields
        assert "data_residency_zones" in d
        assert "data_classification" in d
        assert "cross_border_transfer" in d
        assert "consent_verified" in d

    def test_from_dict_partial(self):
        jctx = JurisdictionalContext.from_dict({"data_classification": "health"})
        assert jctx.data_classification == "health"
        assert jctx.data_residency_zones == []
        assert jctx.agent_operating_zone == ""
        assert jctx.model_inference_zone == ""
        assert jctx.cross_border_transfer is False
        assert jctx.transfer_destination_zones == []
        assert jctx.transfer_mechanism is None
        assert jctx.applicable_regulations == []
        assert jctx.data_subject_jurisdiction is None
        assert jctx.legal_basis is None
        assert jctx.consent_verified is False

    def test_default_values(self):
        jctx = JurisdictionalContext()
        assert jctx.data_classification == "unclassified"
        assert jctx.transfer_mechanism is None
        assert jctx.legal_basis is None
        assert jctx.data_subject_jurisdiction is None


# ── TestJurisdictionalComplianceDimension ──────────────────────────────


class TestJurisdictionalComplianceDimension:
    def test_no_jurisdictional_context_score_0_7(self):
        dim = JurisdictionalCompliance()
        # No accessor set → no jctx
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.7
        assert not score.veto
        assert "No jurisdictional context" in score.reasoning

    def test_all_checks_pass_score_1_0(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_eu_to_switzerland_adequate_destination(self):
        """EU → Switzerland is an adequate destination, score 0.9 via SCC (not needed but tests path)."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["ch/zurich"],
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        # ch/* is in eu/* adequacy_destinations, but since it matches, it doesn't
        # enter the non-adequate path — the transfer check passes.
        # After the cross-border check passes, legal_basis is set, so score=1.0
        assert score.score == 1.0
        assert not score.veto

    def test_eu_to_non_adequate_no_mechanism_veto(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism=None,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto is True
        assert "Cross-border transfer" in score.reasoning

    def test_eu_to_non_adequate_scc_mechanism_score_0_9(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="standard_contractual_clauses",
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.9
        assert not score.veto

    def test_gdpr_pii_no_legal_basis_score_0_3(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.3
        assert not score.veto
        assert "GDPR applies" in score.reasoning
        assert "no legal basis" in score.reasoning

    def test_gdpr_pii_with_legal_basis_score_1_0(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_gdpr_public_data_no_legal_basis_score_1_0(self):
        """Public data doesn't require legal basis even under GDPR."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="public",
            applicable_regulations=["gdpr"],
            legal_basis=None,
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0

    def test_china_cross_border_inference_veto(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="us/east",
            model_inference_zone="us/east",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.0
        assert score.veto is True
        assert "prohibited" in score.reasoning

    def test_china_same_country_inference_pass(self):
        jctx = JurisdictionalContext(
            data_residency_zones=["cn/shanghai"],
            data_classification="pii",
            applicable_regulations=["pipl"],
            agent_operating_zone="cn/beijing",
            model_inference_zone="cn/beijing",
            cross_border_transfer=False,
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 1.0
        assert not score.veto

    def test_custom_jurisdiction_rule_overrides_builtin(self):
        dim = JurisdictionalCompliance()
        dim.add_jurisdiction_rule("eu/*", {
            "regulations": ["custom_gdpr"],
            "residency_strict": False,
            "adequacy_destinations": ["*"],
        })
        # Custom rule says residency_strict=False, so EU transfers don't trigger veto
        rules = dim._get_rules_for_zone("eu/de")
        assert rules.get("residency_strict") is False
        assert "custom_gdpr" in rules["regulations"]

    def test_configure_agent_zone(self):
        dim = JurisdictionalCompliance()
        dim.configure_agent_zone("agent-1", "eu/de")
        assert dim._agent_zones["agent-1"] == "eu/de"

    def test_add_jurisdiction_rule(self):
        dim = JurisdictionalCompliance()
        dim.add_jurisdiction_rule("au/*", {"regulations": ["au_privacy_act"], "residency_strict": False})
        assert "au/*" in dim._custom_rules
        assert dim._custom_rules["au/*"]["regulations"] == ["au_privacy_act"]

    def test_zone_is_adequate_destination_match(self):
        dim = JurisdictionalCompliance()
        # eu/* rules have ch/* as adequate destination
        assert dim._zone_is_adequate_destination("eu/de", "ch/zurich") is True

    def test_zone_is_adequate_destination_no_match(self):
        dim = JurisdictionalCompliance()
        # us/east is NOT in eu/* adequacy destinations
        assert dim._zone_is_adequate_destination("eu/de", "us/east") is False

    def test_get_rules_for_zone_custom_precedence(self):
        dim = JurisdictionalCompliance()
        dim.add_jurisdiction_rule("eu/*", {"regulations": ["custom"], "residency_strict": False})
        rules = dim._get_rules_for_zone("eu/de")
        assert "custom" in rules["regulations"]
        assert rules.get("residency_strict") is False

    def test_get_rules_for_zone_builtin(self):
        dim = JurisdictionalCompliance()
        rules = dim._get_rules_for_zone("eu/de")
        assert "gdpr" in rules["regulations"]
        assert rules["residency_strict"] is True

    def test_get_rules_for_zone_no_match(self):
        dim = JurisdictionalCompliance()
        rules = dim._get_rules_for_zone("xx/unknown")
        assert rules == {}

    def test_minimal_context_score_0_8(self):
        """No residency zones, no regulations → score 0.8."""
        jctx = JurisdictionalContext()
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.8
        assert "Minimal jurisdictional context" in score.reasoning

    def test_eu_to_non_adequate_bcr_mechanism(self):
        """BCR is a safe mechanism."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="binding_corporate_rules",
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.9
        assert not score.veto

    def test_eu_to_non_adequate_explicit_consent_mechanism(self):
        """Explicit consent is a safe mechanism."""
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism="explicit_consent",
        )
        dim = _dim_with_accessor(jctx)
        score = dim.evaluate(_action(), _ctx())
        assert score.score == 0.9
        assert not score.veto

    def test_dimension_properties(self):
        dim = JurisdictionalCompliance()
        assert dim.name == "jurisdictional_compliance"
        assert dim.weight == 1.4
        assert dim.can_veto is True


# ── TestDimensionRegistryWith14 ────────────────────────────────────────


class TestDimensionRegistryWith14:
    def test_create_default_returns_14(self):
        reg = DimensionRegistry.create_default()
        assert len(reg.dimensions) == 14

    def test_evaluate_all_returns_14_scores(self):
        reg = DimensionRegistry.create_default()
        scores = reg.evaluate_all(_action(), _ctx())
        assert len(scores) == 14

    def test_jurisdictional_compliance_in_dimension_names(self):
        reg = DimensionRegistry.create_default()
        names = {d.name for d in reg.dimensions}
        assert "jurisdictional_compliance" in names

    def test_all_dimension_names_unique(self):
        reg = DimensionRegistry.create_default()
        names = [d.name for d in reg.dimensions]
        assert len(names) == len(set(names))


# ── TestJurisdictionalContextProfile ───────────────────────────────────


class TestJurisdictionalContextProfile:
    def test_context_profile_with_jurisdictional(self):
        profile = ContextProfile(
            profile_id="cp-test",
            agent_id="agent-1",
            profile_type="workflow",
            jurisdictional=JurisdictionalContext(
                data_residency_zones=["eu/de"],
                data_classification="pii",
            ),
        )
        assert profile.jurisdictional is not None
        assert profile.jurisdictional.data_classification == "pii"

    def test_completeness_score_with_11_sections(self):
        """All 11 sections populated → completeness = 1.0"""
        from nomotic.context_profile import (
            WorkflowContext, SituationalContext, RelationalContext,
            TemporalContext, HistoricalContext, InputContext,
            OutputContext, ExternalContext, MetaContext, FeedbackContext,
        )
        profile = ContextProfile(
            profile_id="cp-full",
            agent_id="agent-1",
            profile_type="workflow",
            workflow=WorkflowContext(
                workflow_id="wf-1", workflow_type="test",
                total_steps=3, current_step=1,
            ),
            situational=SituationalContext(origin="user_request", trigger_description="test"),
            relational=RelationalContext(),
            temporal=TemporalContext(current_time="2025-01-01T00:00:00Z"),
            historical=HistoricalContext(
                trust_current=0.5, trust_direction="stable",
                trust_trajectory_summary="stable",
            ),
            input_context=InputContext(input_type="text", input_summary="test", input_category="standard_request"),
            output=OutputContext(),
            external=ExternalContext(),
            meta=MetaContext(),
            feedback=FeedbackContext(),
            jurisdictional=JurisdictionalContext(),
        )
        assert profile.completeness_score() == 1.0

    def test_to_dict_includes_jurisdictional(self):
        profile = ContextProfile(
            profile_id="cp-test",
            agent_id="agent-1",
            profile_type="workflow",
            jurisdictional=JurisdictionalContext(data_classification="pii"),
        )
        d = profile.to_dict()
        assert "jurisdictional" in d
        assert d["jurisdictional"]["data_classification"] == "pii"

    def test_from_dict_restores_jurisdictional(self):
        d = {
            "profile_id": "cp-test",
            "agent_id": "agent-1",
            "profile_type": "workflow",
            "jurisdictional": {
                "data_residency_zones": ["eu/de"],
                "data_classification": "health",
            },
        }
        profile = ContextProfile.from_dict(d)
        assert profile.jurisdictional is not None
        assert profile.jurisdictional.data_classification == "health"
        assert profile.jurisdictional.data_residency_zones == ["eu/de"]

    def test_context_fields_has_11_entries(self):
        assert len(ContextProfile._CONTEXT_FIELDS) == 11
        assert "jurisdictional" in ContextProfile._CONTEXT_FIELDS


# ── TestJurisdictionalModifier ─────────────────────────────────────────


class TestJurisdictionalModifier:
    def _profile_with_jctx(self, jctx: JurisdictionalContext) -> ContextProfile:
        return ContextProfile(
            profile_id="cp-test",
            agent_id="agent-1",
            profile_type="workflow",
            jurisdictional=jctx,
        )

    def test_gdpr_increases_authority_verification(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(
            applicable_regulations=["gdpr"],
            data_classification="pii",
        )
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        auth_adj = [a for a in result.weight_adjustments if a.dimension_name == "authority_verification"]
        assert len(auth_adj) > 0
        assert auth_adj[0].adjusted_weight > auth_adj[0].original_weight

    def test_cross_border_increases_jurisdictional_weight(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(cross_border_transfer=True)
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        jc_adj = [a for a in result.weight_adjustments if a.dimension_name == "jurisdictional_compliance"]
        assert len(jc_adj) > 0
        assert jc_adj[0].adjusted_weight > 1.4

    def test_sensitive_pii_increases_isolation_integrity(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(data_classification="sensitive_pii")
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        iso_adj = [a for a in result.weight_adjustments if a.dimension_name == "isolation_integrity"]
        assert len(iso_adj) > 0
        assert iso_adj[0].adjusted_weight > iso_adj[0].original_weight

    def test_health_data_increases_isolation_integrity(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(data_classification="health")
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        iso_adj = [a for a in result.weight_adjustments if a.dimension_name == "isolation_integrity"]
        assert len(iso_adj) > 0

    def test_gdpr_no_legal_basis_pii_requires_human_review(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(
            applicable_regulations=["gdpr"],
            data_classification="pii",
            legal_basis=None,
        )
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        review_constraints = [
            c for c in result.constraints
            if c.constraint_type == "require_human_review"
            and c.source_context == "jurisdictional"
        ]
        assert len(review_constraints) > 0
        assert "GDPR" in review_constraints[0].description

    def test_cross_border_no_mechanism_confirmation_required(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(
            cross_border_transfer=True,
            transfer_mechanism=None,
        )
        profile = self._profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        confirm_constraints = [
            c for c in result.constraints
            if c.constraint_type == "confirmation_required"
            and c.source_context == "jurisdictional"
        ]
        assert len(confirm_constraints) > 0

    def test_no_jurisdictional_context_no_modifications(self):
        """Without jurisdictional context, no jurisdictional modifications are added."""
        modifier = ContextualModifier()
        profile = ContextProfile(
            profile_id="cp-test",
            agent_id="agent-1",
            profile_type="workflow",
        )
        result = modifier.modify(_action(), _ctx(), profile)
        jc_adj = [a for a in result.weight_adjustments if "jurisdictional" in a.reason.lower()]
        assert len(jc_adj) == 0


# ── TestJurisdictionalRuntimeIntegration ───────────────────────────────


class TestJurisdictionalRuntimeIntegration:
    def test_set_jurisdictional_context_stores(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()
        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
        )
        runtime.set_jurisdictional_context("agent-1", jctx)
        profile = runtime.context_profiles.get_active_profile("agent-1")
        assert profile is not None
        assert profile.jurisdictional is not None
        assert profile.jurisdictional.data_classification == "pii"

    def test_evaluate_uses_jurisdictional_context(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"write"})

        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=False,
        )
        runtime.set_jurisdictional_context("agent-1", jctx)

        action = Action(agent_id="agent-1", action_type="write", target="users/profile")
        ctx = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1"),
        )
        verdict = runtime.evaluate(action, ctx)
        assert len(verdict.dimension_scores) == 14

    def test_eu_to_us_transfer_no_mechanism_deny(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"write"})

        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["us/east"],
            transfer_mechanism=None,
        )
        runtime.set_jurisdictional_context("agent-1", jctx)

        action = Action(agent_id="agent-1", action_type="write", target="users/profile")
        ctx = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1"),
        )
        verdict = runtime.evaluate(action, ctx)
        from nomotic.types import Verdict
        assert verdict.verdict == Verdict.DENY

    def test_eu_to_switzerland_transfer_allow(self):
        from nomotic.runtime import GovernanceRuntime
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"write"})

        jctx = JurisdictionalContext(
            data_residency_zones=["eu/de"],
            data_classification="pii",
            applicable_regulations=["gdpr"],
            legal_basis="consent",
            cross_border_transfer=True,
            transfer_destination_zones=["ch/zurich"],
        )
        runtime.set_jurisdictional_context("agent-1", jctx)

        action = Action(agent_id="agent-1", action_type="write", target="data/export")
        ctx = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1"),
        )
        verdict = runtime.evaluate(action, ctx)
        from nomotic.types import Verdict
        assert verdict.verdict == Verdict.ALLOW

    def test_gdpr_framework_in_compliance_report(self):
        gen = ComplianceReportGenerator()
        report = gen.generate("gdpr")
        assert report.framework_id == "gdpr"
        assert report.framework_name == "EU General Data Protection Regulation (GDPR)"
        assert report.summary.total_controls > 0
        # Verify jurisdictional_compliance is in at least one control
        jc_controls = [
            cr for cr in report.controls
            if "jurisdictional_compliance" in cr.mapping.nomotic_dimensions
        ]
        assert len(jc_controls) > 0


# ── TestJURISDICTION_RULES ────────────────────────────────────────────


class TestJURISDICTION_RULES:
    def test_eu_rules_have_adequacy_destinations(self):
        eu_rules = JURISDICTION_RULES["eu/*"]
        assert "adequacy_destinations" in eu_rules
        assert "ch/*" in eu_rules["adequacy_destinations"]
        assert "gb/*" in eu_rules["adequacy_destinations"]
        assert "jp/*" in eu_rules["adequacy_destinations"]

    def test_cn_rules_strict_residency_empty_adequacy(self):
        cn_rules = JURISDICTION_RULES["cn/*"]
        assert cn_rules["residency_strict"] is True
        assert cn_rules["adequacy_destinations"] == []
        assert cn_rules.get("critical_data_transfer_prohibited") is True

    def test_us_rules_not_strict(self):
        us_rules = JURISDICTION_RULES["us/*"]
        assert us_rules["residency_strict"] is False
        assert "ccpa" in us_rules["regulations"]

    def test_gb_rules_have_uk_gdpr(self):
        gb_rules = JURISDICTION_RULES["gb/*"]
        assert "uk_gdpr" in gb_rules["regulations"]
        assert gb_rules["residency_strict"] is True

    def test_in_rules(self):
        in_rules = JURISDICTION_RULES["in/*"]
        assert "dpdpa" in in_rules["regulations"]
        assert in_rules["residency_strict"] is True

    def test_sg_rules(self):
        sg_rules = JURISDICTION_RULES["sg/*"]
        assert "pdpa" in sg_rules["regulations"]
        assert sg_rules["residency_strict"] is False


# ── TestDeriveRegulations ──────────────────────────────────────────────


class TestDeriveRegulations:
    def test_derive_eu_regulations(self):
        regs, _ = derive_regulations(["eu/de"])
        assert "gdpr" in regs

    def test_derive_cn_regulations(self):
        regs, _ = derive_regulations(["cn/shanghai"])
        assert "pipl" in regs
        assert "dsl" in regs

    def test_derive_multiple_zones(self):
        regs, _ = derive_regulations(["eu/de", "us/ca/la"])
        assert "gdpr" in regs
        assert "ccpa" in regs

    def test_derive_unknown_zone(self):
        regs, _ = derive_regulations(["xx/unknown"])
        assert regs == []

    def test_derive_deduplicates(self):
        regs, _ = derive_regulations(["eu/de", "eu/fr"])
        assert regs.count("gdpr") == 1


# ── TestGDPRFramework ──────────────────────────────────────────────────


class TestGDPRFramework:
    def test_gdpr_in_framework_mappings(self):
        assert "gdpr" in FRAMEWORK_MAPPINGS

    def test_gdpr_framework_has_controls(self):
        mapping = FRAMEWORK_MAPPINGS["gdpr"]
        assert len(mapping.controls) > 0

    def test_gdpr_art44_has_jurisdictional_compliance(self):
        mapping = FRAMEWORK_MAPPINGS["gdpr"]
        art44 = [c for c in mapping.controls if c.control_id == "GDPR-Art44"]
        assert len(art44) == 1
        assert "jurisdictional_compliance" in art44[0].nomotic_dimensions

    def test_gdpr_art5_1a_coverage_full(self):
        mapping = FRAMEWORK_MAPPINGS["gdpr"]
        art5_1a = [c for c in mapping.controls if c.control_id == "GDPR-Art5-1a"]
        assert len(art5_1a) == 1
        assert art5_1a[0].coverage == "full"
