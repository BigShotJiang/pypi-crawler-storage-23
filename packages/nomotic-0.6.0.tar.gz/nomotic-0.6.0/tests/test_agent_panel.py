"""Tests for the Agent Live Status Panel (F-10).

Covers: GET /v1/ui/agents, GET /v1/ui/agent/{id}, trust_color logic,
sorting, archetype filtering, agent detail fields.
"""

import json
import threading
import time
import uuid
import urllib.request
import urllib.error
from pathlib import Path

from nomotic.api import NomoticAPIServer
from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


def _setup_server(*, base_dir: Path | None = None):
    """Create a running API server for testing the agent panel."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)

    if base_dir is None:
        import tempfile
        base_dir = Path(tempfile.mkdtemp())

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=True,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port, base_dir, ca


def _get_json(port: int, path: str) -> tuple[int, any]:
    """GET request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def _issue_agent(ca, agent_id: str, archetype: str, trust_score: float = 0.5):
    """Issue a certificate and override its trust_score for testing."""
    cert, _key = ca.issue(
        agent_id=agent_id,
        archetype=archetype,
        organization="test-org",
        zone_path="/test",
        owner="test-owner",
    )
    cert.trust_score = trust_score
    ca._store.update(cert)
    return cert


def _seed_audit_records(
    base_dir: Path,
    agent_id: str,
    count: int = 5,
    verdicts: list[str] | None = None,
):
    """Seed audit records for testing."""
    audit = AuditStore(base_dir)
    now = time.time()
    for i in range(count):
        if verdicts:
            verdict = verdicts[i % len(verdicts)]
        else:
            verdict = "ALLOW" if i % 3 != 0 else "DENY"
        record = PersistentLogRecord(
            record_id=f"rec-{uuid.uuid4().hex[:8]}",
            timestamp=now - (count - i),
            agent_id=agent_id,
            action_type="file.read",
            action_target="/data/test.txt",
            verdict=verdict,
            ucs=0.85 - (i * 0.05),
            tier=1,
            trust_score=0.5 + (i * 0.02),
            trust_delta=0.01,
            trust_trend="stable",
            severity="info",
            justification="Test evaluation",
            parameters={"archetype": "data-analyst", "latency_ms": 12.5},
        )
        prev_hash = audit.get_last_hash(agent_id)
        record.previous_hash = prev_hash
        record.record_hash = audit.compute_hash(record.to_dict(), prev_hash)
        audit.append(record)


class TestAgentRoster:
    """Tests for GET /v1/ui/agents."""

    def test_agents_returns_json_array(self):
        """Test 1: GET /v1/ui/agents returns a JSON array."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-alpha", "customer-experience", 0.8)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            assert isinstance(data, list)
            assert len(data) == 1
        finally:
            httpd.shutdown()

    def test_agent_has_required_fields(self):
        """Test 2: Each agent object has all required fields."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-beta", "healthcare-agent", 0.6)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            agent = data[0]
            required_fields = [
                "agent_id", "trust_score", "trust_color",
                "archetype", "certificate_status", "drift_status",
                "last_evaluation_at",
            ]
            for field in required_fields:
                assert field in agent, f"Missing field: {field}"
        finally:
            httpd.shutdown()

    def test_trust_color_green_above_07(self):
        """Test 3: trust_color = 'green' when trust_score > 0.7."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-green", "customer-experience", 0.85)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            assert data[0]["trust_color"] == "green"
        finally:
            httpd.shutdown()

    def test_trust_color_amber_between_03_and_07(self):
        """Test 4: trust_color = 'amber' when trust_score between 0.3 and 0.7."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-amber", "customer-experience", 0.5)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            assert data[0]["trust_color"] == "amber"
        finally:
            httpd.shutdown()

    def test_trust_color_red_below_03(self):
        """Test 5: trust_color = 'red' when trust_score < 0.3."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-red", "customer-experience", 0.1)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            assert data[0]["trust_color"] == "red"
        finally:
            httpd.shutdown()

    def test_results_sorted_by_trust_ascending(self):
        """Test 6: Results sorted by trust_score ascending."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-high", "customer-experience", 0.9)
            _issue_agent(ca, "agent-low", "customer-experience", 0.2)
            _issue_agent(ca, "agent-mid", "customer-experience", 0.5)
            status, data = _get_json(port, "/v1/ui/agents")
            assert status == 200
            scores = [a["trust_score"] for a in data]
            assert scores == sorted(scores), f"Not sorted ascending: {scores}"
        finally:
            httpd.shutdown()

    def test_archetype_filter_returns_matching(self):
        """Test 7: ?archetype= filter returns only matching agents."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-health", "healthcare-agent", 0.6)
            _issue_agent(ca, "agent-cx", "customer-experience", 0.7)
            status, data = _get_json(port, "/v1/ui/agents?archetype=healthcare-agent")
            assert status == 200
            assert len(data) == 1
            assert data[0]["archetype"] == "healthcare-agent"
        finally:
            httpd.shutdown()

    def test_archetype_filter_no_matches_returns_empty(self):
        """Test 8: ?archetype= filter with no matches returns empty array."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-cx", "customer-experience", 0.7)
            status, data = _get_json(port, "/v1/ui/agents?archetype=nonexistent-type")
            assert status == 200
            assert isinstance(data, list)
            assert len(data) == 0
        finally:
            httpd.shutdown()


class TestAgentDetail:
    """Tests for GET /v1/ui/agent/{agent_id}."""

    def test_known_agent_returns_200(self):
        """Test 9: GET /v1/ui/agent/{id} returns 200 for known agent."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-detail", "healthcare-agent", 0.65)
            _seed_audit_records(base_dir, "agent-detail", count=3)
            status, data = _get_json(port, "/v1/ui/agent/agent-detail")
            assert status == 200
            assert "certificate" in data
            assert data["archetype"] == "healthcare-agent"
        finally:
            httpd.shutdown()

    def test_unknown_agent_returns_404(self):
        """Test 10: GET /v1/ui/agent/{id} returns 404 for unknown agent."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/agent/does-not-exist")
            assert status == 404
        finally:
            httpd.shutdown()

    def test_detail_has_evaluation_summary_with_all_verdicts(self):
        """Test 11: Agent detail contains evaluation_summary_30d with all 5 verdict types."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-summary", "customer-experience", 0.7)
            _seed_audit_records(
                base_dir, "agent-summary", count=10,
                verdicts=["ALLOW", "DENY", "ESCALATE", "ALLOW", "ALLOW"],
            )
            status, data = _get_json(port, "/v1/ui/agent/agent-summary")
            assert status == 200
            summary = data["evaluation_summary_30d"]
            for key in ("total", "allow", "deny", "escalate", "block"):
                assert key in summary, f"Missing key in evaluation_summary_30d: {key}"
            assert summary["total"] == 10
        finally:
            httpd.shutdown()

    def test_detail_trust_trajectory_is_float_list(self):
        """Test 12: Agent detail trust_trajectory_30d is a list of floats."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-traj", "customer-experience", 0.7)
            _seed_audit_records(base_dir, "agent-traj", count=5)
            status, data = _get_json(port, "/v1/ui/agent/agent-traj")
            assert status == 200
            trajectory = data["trust_trajectory_30d"]
            assert isinstance(trajectory, list)
            assert len(trajectory) == 5
            for val in trajectory:
                assert isinstance(val, (int, float)), f"Expected float, got {type(val)}"
        finally:
            httpd.shutdown()

    def test_detail_contains_compliance_preset(self):
        """Test 13: Agent detail contains compliance_preset field."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-compliance", "healthcare-agent", 0.7)
            status, data = _get_json(port, "/v1/ui/agent/agent-compliance")
            assert status == 200
            assert "compliance_preset" in data
            assert data["compliance_preset"] == "hipaa_aligned"
        finally:
            httpd.shutdown()

    def test_detail_contains_open_drift_alerts(self):
        """Test 14: Agent detail contains open_drift_alerts list."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-drift", "customer-experience", 0.7)
            status, data = _get_json(port, "/v1/ui/agent/agent-drift")
            assert status == 200
            assert "open_drift_alerts" in data
            assert isinstance(data["open_drift_alerts"], list)
        finally:
            httpd.shutdown()

    def test_detail_last_evaluation_at_null_when_no_records(self):
        """Test 15: last_evaluation_at is null when no audit records exist."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-noseen", "customer-experience", 0.7)
            status, data = _get_json(port, "/v1/ui/agent/agent-noseen")
            assert status == 200
            assert data["last_evaluation_at"] is None
        finally:
            httpd.shutdown()

    def test_detail_certificate_dict_has_agent_id(self):
        """Test 16: Agent detail certificate dict contains agent_id."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-certcheck", "customer-experience", 0.7)
            status, data = _get_json(port, "/v1/ui/agent/agent-certcheck")
            assert status == 200
            assert data["certificate"]["agent_id"] == "agent-certcheck"
        finally:
            httpd.shutdown()


class TestAgentRosterPanel:
    """Tests for GET /v1/ui/panels/agent-roster (HTML panel)."""

    def test_panel_returns_html(self):
        """Panel endpoint returns HTML content."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            _issue_agent(ca, "agent-html", "customer-experience", 0.7)
            url = f"http://127.0.0.1:{port}/v1/ui/panels/agent-roster"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as resp:
                assert resp.status == 200
                ct = resp.headers.get("Content-Type", "")
                assert "text/html" in ct
                body = resp.read().decode("utf-8")
                assert "agent-html" in body
        finally:
            httpd.shutdown()

    def test_panel_empty_state(self):
        """Panel shows empty state when no agents exist."""
        httpd, port, base_dir, ca = _setup_server()
        try:
            url = f"http://127.0.0.1:{port}/v1/ui/panels/agent-roster"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as resp:
                assert resp.status == 200
                body = resp.read().decode("utf-8")
                assert "No agents yet" in body
        finally:
            httpd.shutdown()
