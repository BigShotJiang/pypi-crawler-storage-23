"""Tests for jurisdictional regulation improvements — new zones, conflict detection, and modifier integration."""

from nomotic.dimensions import CONFLICTING_REGULATION_PAIRS, JURISDICTION_RULES
from nomotic.context_profile import (
    ContextProfile,
    JurisdictionalContext,
    derive_regulations,
)
from nomotic.contextual_modifier import ContextualModifier
from nomotic.types import Action, AgentContext, TrustProfile


# ── Test helpers ───────────────────────────────────────────────────────


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
        action_history=[],
    )


def _action(action_type: str = "read", target: str = "db") -> Action:
    return Action(agent_id="agent-1", action_type=action_type, target=target)


def _profile_with_jctx(jctx: JurisdictionalContext) -> ContextProfile:
    return ContextProfile(
        profile_id="cp-test",
        agent_id="agent-1",
        profile_type="workflow",
        jurisdictional=jctx,
    )


# ── TestNewJurisdictionZones ──────────────────────────────────────────


class TestNewJurisdictionZones:
    def test_us_hipaa_zone_infers_hipaa_and_ccpa(self):
        regs, _ = derive_regulations(["us/hipaa"])
        assert "hipaa" in regs
        assert "ccpa" in regs

    def test_us_ny_zone_infers_ny_shield(self):
        regs, _ = derive_regulations(["us/ny"])
        assert "ny_shield" in regs

    def test_us_tx_zone_infers_tdpsa(self):
        regs, _ = derive_regulations(["us/tx"])
        assert "tdpsa" in regs

    def test_us_va_zone_infers_vcdpa(self):
        regs, _ = derive_regulations(["us/va"])
        assert "vcdpa" in regs

    def test_brazil_zone_infers_lgpd(self):
        regs, _ = derive_regulations(["br"])
        assert "lgpd" in regs

    def test_australia_zone_infers_privacy_act(self):
        regs, _ = derive_regulations(["au"])
        assert "privacy_act" in regs
        assert "apps" in regs

    def test_canada_zone_infers_pipeda(self):
        regs, _ = derive_regulations(["ca"])
        assert "pipeda" in regs


# ── TestConflictDetection ─────────────────────────────────────────────


class TestConflictDetection:
    def test_gdpr_pipl_conflict_detected(self):
        regs, conflicts = derive_regulations(["eu/de", "cn/shanghai"])
        assert "gdpr" in regs
        assert "pipl" in regs
        assert len(conflicts) >= 1
        assert any("GDPR" in c and "PIPL" in c for c in conflicts)

    def test_hipaa_gdpr_conflict_detected(self):
        regs, conflicts = derive_regulations(["us/hipaa", "eu/de"])
        assert "hipaa" in regs
        assert "gdpr" in regs
        assert any("HIPAA" in c and "GDPR" in c for c in conflicts)

    def test_ccpa_pipl_conflict_detected(self):
        regs, conflicts = derive_regulations(["us/hipaa", "cn/shanghai"])
        assert "ccpa" in regs
        assert "pipl" in regs
        assert any("CCPA" in c and "PIPL" in c for c in conflicts)

    def test_no_conflict_single_regulation(self):
        regs, conflicts = derive_regulations(["eu/de"])
        assert "gdpr" in regs
        assert conflicts == []

    def test_derive_regulations_returns_tuple(self):
        result = derive_regulations(["eu/de"])
        assert isinstance(result, tuple)
        assert len(result) == 2
        regs, conflicts = result
        assert isinstance(regs, list)
        assert isinstance(conflicts, list)

    def test_derive_regulations_empty_zones(self):
        regs, conflicts = derive_regulations([])
        assert regs == []
        assert conflicts == []

    def test_multiple_conflicts_all_reported(self):
        # eu/de → gdpr, cn/shanghai → pipl+dsl, us/hipaa → hipaa+ccpa
        # Should trigger: gdpr/pipl, hipaa/gdpr, ccpa/pipl
        regs, conflicts = derive_regulations(["eu/de", "cn/shanghai", "us/hipaa"])
        assert len(conflicts) >= 3
        conflict_text = " ".join(conflicts)
        assert "GDPR" in conflict_text and "PIPL" in conflict_text
        assert "HIPAA" in conflict_text
        assert "CCPA" in conflict_text


# ── TestContextualModifierConflicts ───────────────────────────────────


class TestContextualModifierConflicts:
    def test_authority_verification_weight_increased_on_conflict(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(
            applicable_regulations=["gdpr", "pipl"],
            regulation_conflicts=[
                "Conflicting regulations detected: GDPR and PIPL apply simultaneously. "
                "Manual review recommended for cross-border transfers."
            ],
        )
        profile = _profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        auth_adj = [
            a for a in result.weight_adjustments
            if a.dimension_name == "authority_verification"
            and "Conflicting" in a.reason
        ]
        assert len(auth_adj) > 0
        assert auth_adj[0].adjusted_weight >= 1.6

    def test_risk_signal_added_on_conflict(self):
        modifier = ContextualModifier()
        jctx = JurisdictionalContext(
            applicable_regulations=["gdpr", "pipl"],
            regulation_conflicts=[
                "Conflicting regulations detected: GDPR and PIPL apply simultaneously. "
                "Manual review recommended for cross-border transfers."
            ],
        )
        profile = _profile_with_jctx(jctx)
        result = modifier.modify(_action(), _ctx(), profile)
        conflict_signals = [
            s for s in result.risk_signals
            if s.signal_type == "regulation_conflict_detected"
        ]
        assert len(conflict_signals) == 1
        assert conflict_signals[0].severity == "high"


# ── TestJurisdictionalContextConflictsField ───────────────────────────


class TestJurisdictionalContextConflictsField:
    def test_regulation_conflicts_default_empty(self):
        jctx = JurisdictionalContext()
        assert jctx.regulation_conflicts == []

    def test_regulation_conflicts_to_dict(self):
        jctx = JurisdictionalContext(
            regulation_conflicts=["conflict warning 1"],
        )
        d = jctx.to_dict()
        assert d["regulation_conflicts"] == ["conflict warning 1"]

    def test_regulation_conflicts_from_dict(self):
        d = {"regulation_conflicts": ["conflict warning 1"]}
        jctx = JurisdictionalContext.from_dict(d)
        assert jctx.regulation_conflicts == ["conflict warning 1"]

    def test_regulation_conflicts_omitted_when_empty(self):
        jctx = JurisdictionalContext()
        d = jctx.to_dict()
        assert "regulation_conflicts" not in d
