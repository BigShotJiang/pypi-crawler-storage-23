"""Tests for Fleet Cost 7-Day Trend Analysis (Item 5 of v0.5.1)."""

import time
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.fleet import (
    CostGroup,
    FleetCostAggregator,
    GroupCostSummary,
)


# ── Helpers ────────────────────────────────────────────────────────────


def _write_records(base_dir, agent_id, records):
    """Write audit records for an agent to temp dir."""
    store = LogStore(base_dir, "audit")
    for r in records:
        store.append(PersistentLogRecord(**r))


def _make_record(
    agent_id="test-agent",
    action_type="read",
    verdict="ALLOW",
    trust_score=0.65,
    trust_delta=0.01,
    trust_trend="rising",
    timestamp=None,
    parameters=None,
    **kwargs,
):
    """Build a record dict suitable for PersistentLogRecord."""
    return {
        "record_id": kwargs.get("record_id", f"r-{time.time_ns()}"),
        "timestamp": timestamp or time.time(),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": kwargs.get("action_target", "db"),
        "verdict": verdict,
        "ucs": kwargs.get("ucs", 0.85),
        "tier": kwargs.get("tier", 2),
        "trust_score": trust_score,
        "trust_delta": trust_delta,
        "trust_trend": trust_trend,
        "severity": kwargs.get("severity", "info"),
        "justification": kwargs.get("justification", "ok"),
        "parameters": parameters or {},
    }


def _day_timestamp(days_ago: int, hour: int = 12) -> float:
    """Return a UTC timestamp for `days_ago` days in the past at given hour."""
    now = datetime.now(tz=timezone.utc)
    day = now.date() - timedelta(days=days_ago)
    return datetime(day.year, day.month, day.day, hour, 0, 0, tzinfo=timezone.utc).timestamp()


@pytest.fixture
def cost_store(tmp_path):
    """Create a LogStore for cost tests."""
    return LogStore(tmp_path, "audit")


def _setup_steady_cost_agents(tmp_path, cost_per_day=0.10):
    """Create agents with steady daily costs over 7 days."""
    for days_back in range(6, -1, -1):
        ts = _day_timestamp(days_back)
        _write_records(tmp_path, "steady-1", [
            _make_record(
                "steady-1",
                timestamp=ts,
                record_id=f"s1-d{days_back}",
                parameters={"cost_usd": cost_per_day, "tokens": 100},
            ),
        ])
    store = LogStore(tmp_path, "audit")
    agg = FleetCostAggregator(audit_store=store)
    agg.add_group(CostGroup(
        group_id="steady-group",
        name="Steady Group",
        agent_ids=["steady-1"],
    ))
    return agg


def _setup_accelerating_agents(tmp_path):
    """Create agents with accelerating daily costs over 7 days.

    Costs double each day: 0.01, 0.02, 0.04, 0.08, 0.16, 0.32, 0.64
    Growth rate = 100% per day.
    """
    costs = [0.01, 0.02, 0.04, 0.08, 0.16, 0.32, 0.64]
    for i, days_back in enumerate(range(6, -1, -1)):
        ts = _day_timestamp(days_back)
        _write_records(tmp_path, "accel-1", [
            _make_record(
                "accel-1",
                timestamp=ts,
                record_id=f"a1-d{days_back}",
                parameters={"cost_usd": costs[i], "tokens": 100},
            ),
        ])
    store = LogStore(tmp_path, "audit")
    agg = FleetCostAggregator(audit_store=store)
    agg.add_group(CostGroup(
        group_id="accel-group",
        name="Accel Group",
        agent_ids=["accel-1"],
    ))
    return agg


def _setup_decelerating_agents(tmp_path):
    """Create agents with decelerating daily costs over 7 days.

    Costs halve each day: 0.64, 0.32, 0.16, 0.08, 0.04, 0.02, 0.01
    Growth rate = -50% per day.
    """
    costs = [0.64, 0.32, 0.16, 0.08, 0.04, 0.02, 0.01]
    for i, days_back in enumerate(range(6, -1, -1)):
        ts = _day_timestamp(days_back)
        _write_records(tmp_path, "decel-1", [
            _make_record(
                "decel-1",
                timestamp=ts,
                record_id=f"d1-d{days_back}",
                parameters={"cost_usd": costs[i], "tokens": 100},
            ),
        ])
    store = LogStore(tmp_path, "audit")
    agg = FleetCostAggregator(audit_store=store)
    agg.add_group(CostGroup(
        group_id="decel-group",
        name="Decel Group",
        agent_ids=["decel-1"],
    ))
    return agg


# ── Tests ──────────────────────────────────────────────────────────────


class TestFleetCostTrends:
    def test_7d_trend_all_zeros_returns_zeros(self, cost_store):
        """When no cost data exists, all trend fields should be zero."""
        agg = FleetCostAggregator(audit_store=cost_store)
        agg.add_group(CostGroup(
            group_id="empty",
            name="Empty",
            agent_ids=["nonexistent"],
        ))
        summary = agg.get_group_cost("empty")
        assert summary.daily_costs_7d == [0.0] * 7
        assert summary.moving_average_7d == 0.0
        assert summary.daily_growth_rate == 0.0
        assert summary.cost_acceleration_alert is False

    def test_7d_trend_steady_returns_near_zero_growth(self, tmp_path):
        """Steady daily costs should yield ~0% growth rate."""
        agg = _setup_steady_cost_agents(tmp_path, cost_per_day=0.10)
        summary = agg.get_group_cost("steady-group")
        # With constant costs, growth rate should be 0
        assert summary.daily_growth_rate == 0.0
        assert summary.cost_acceleration_alert is False

    def test_7d_trend_accelerating_returns_positive_growth(self, tmp_path):
        """Doubling daily costs should yield strongly positive growth."""
        agg = _setup_accelerating_agents(tmp_path)
        summary = agg.get_group_cost("accel-group")
        # Each day doubles → 100% growth rate
        assert summary.daily_growth_rate > 0.20
        assert summary.cost_acceleration_alert is True

    def test_7d_trend_decelerating_returns_negative_growth(self, tmp_path):
        """Halving daily costs should yield negative growth."""
        agg = _setup_decelerating_agents(tmp_path)
        summary = agg.get_group_cost("decel-group")
        assert summary.daily_growth_rate < 0.0
        assert summary.cost_acceleration_alert is False

    def test_daily_costs_always_7_elements(self, tmp_path):
        """daily_costs_7d should always have exactly 7 elements."""
        agg = _setup_steady_cost_agents(tmp_path)
        summary = agg.get_group_cost("steady-group")
        assert len(summary.daily_costs_7d) == 7

    def test_daily_costs_always_7_elements_empty(self, cost_store):
        """Even with no data, daily_costs_7d should have 7 elements."""
        agg = FleetCostAggregator(audit_store=cost_store)
        agg.add_group(CostGroup(
            group_id="e", name="E", agent_ids=["ghost"],
        ))
        summary = agg.get_group_cost("e")
        assert len(summary.daily_costs_7d) == 7

    def test_moving_average_calculated_correctly(self, tmp_path):
        """Moving average should equal sum(daily_costs) / 7."""
        agg = _setup_accelerating_agents(tmp_path)
        summary = agg.get_group_cost("accel-group")
        expected_avg = sum(summary.daily_costs_7d) / 7
        assert abs(summary.moving_average_7d - expected_avg) < 1e-4

    def test_acceleration_alert_fires_above_threshold(self, tmp_path):
        """Alert should be True when growth exceeds 20% threshold."""
        agg = _setup_accelerating_agents(tmp_path)
        summary = agg.get_group_cost("accel-group")
        assert summary.daily_growth_rate > 0.20
        assert summary.cost_acceleration_alert is True

    def test_acceleration_alert_clear_below_threshold(self, tmp_path):
        """Alert should be False when growth is below threshold."""
        agg = _setup_steady_cost_agents(tmp_path)
        summary = agg.get_group_cost("steady-group")
        assert summary.cost_acceleration_alert is False

    def test_custom_acceleration_threshold_respected(self, tmp_path):
        """_compute_7d_trend should respect a custom threshold."""
        # Create accelerating cost data with 100% growth
        costs = [0.01, 0.02, 0.04, 0.08, 0.16, 0.32, 0.64]
        for i, days_back in enumerate(range(6, -1, -1)):
            ts = _day_timestamp(days_back)
            _write_records(tmp_path, "custom-1", [
                _make_record(
                    "custom-1",
                    timestamp=ts,
                    record_id=f"c1-d{days_back}",
                    parameters={"cost_usd": costs[i], "tokens": 100},
                ),
            ])
        store = LogStore(tmp_path, "audit")
        agg = FleetCostAggregator(audit_store=store)

        # With very high threshold (200%), alert should NOT fire
        _, _, growth_rate, alert = agg._compute_7d_trend(
            ["custom-1"], acceleration_threshold=2.0,
        )
        assert growth_rate > 0.20  # Growth is high
        assert alert is False  # But threshold is even higher

        # With very low threshold (1%), alert SHOULD fire
        _, _, growth_rate_low, alert_low = agg._compute_7d_trend(
            ["custom-1"], acceleration_threshold=0.01,
        )
        assert alert_low is True

    def test_alerts_includes_acceleration_group(self, tmp_path):
        """alerts() should include groups with cost_acceleration_alert."""
        agg = _setup_accelerating_agents(tmp_path)
        # The group has no budget set, so budget alerts are False.
        # But acceleration alert should be True.
        alerts = agg.alerts()
        alert_ids = [a.group_id for a in alerts]
        assert "accel-group" in alert_ids

    def test_group_cost_summary_to_dict_includes_trend_fields(self, tmp_path):
        """to_dict() should include all trend-related fields."""
        agg = _setup_accelerating_agents(tmp_path)
        summary = agg.get_group_cost("accel-group")
        d = summary.to_dict()
        assert "daily_costs_7d" in d
        assert "moving_average_7d" in d
        assert "daily_growth_rate" in d
        assert "cost_acceleration_alert" in d
        assert isinstance(d["daily_costs_7d"], list)
        assert len(d["daily_costs_7d"]) == 7

    def test_zero_to_zero_transitions_excluded_from_growth(self, tmp_path):
        """Growth rate should skip zero→nonzero transitions (only prev>0 counts)."""
        # Only put cost data on last 2 days; first 5 days are zero
        for days_back in range(6, 2, -1):
            ts = _day_timestamp(days_back)
            _write_records(tmp_path, "sparse-1", [
                _make_record(
                    "sparse-1",
                    timestamp=ts,
                    record_id=f"sp-d{days_back}",
                    parameters={"cost_usd": 0.0, "tokens": 0},
                ),
            ])
        # Day 2 ago: $0.10
        ts2 = _day_timestamp(2)
        _write_records(tmp_path, "sparse-1", [
            _make_record(
                "sparse-1",
                timestamp=ts2,
                record_id="sp-d2",
                parameters={"cost_usd": 0.10, "tokens": 100},
            ),
        ])
        # Day 1 ago: $0.10
        ts1 = _day_timestamp(1)
        _write_records(tmp_path, "sparse-1", [
            _make_record(
                "sparse-1",
                timestamp=ts1,
                record_id="sp-d1",
                parameters={"cost_usd": 0.10, "tokens": 100},
            ),
        ])
        # Today: $0.10
        ts0 = _day_timestamp(0)
        _write_records(tmp_path, "sparse-1", [
            _make_record(
                "sparse-1",
                timestamp=ts0,
                record_id="sp-d0",
                parameters={"cost_usd": 0.10, "tokens": 100},
            ),
        ])

        store = LogStore(tmp_path, "audit")
        agg = FleetCostAggregator(audit_store=store)

        daily_costs, moving_avg, growth_rate, alert = agg._compute_7d_trend(
            ["sparse-1"],
        )
        # The first 4 days are zero → zero→nonzero transition should be skipped
        # Only transitions where prev > 0 contribute (day2→day1, day1→today)
        # Both are 0.10 → 0.10 = 0% growth
        assert growth_rate == 0.0
        assert alert is False
