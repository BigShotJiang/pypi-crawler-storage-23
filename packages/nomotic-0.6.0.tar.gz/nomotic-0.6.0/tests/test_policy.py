"""Tests for Policy-as-Code — declarative governance pre-filters."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from nomotic.policy import PolicyEngine, PolicyLoadError, PolicyResult, PolicyRule
from nomotic.runtime import GovernanceRuntime
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


def _try_import_yaml() -> bool:
    try:
        import yaml  # noqa: F401
        return True
    except ImportError:
        return False


# ── Helpers ──────────────────────────────────────────────────────────────


def _action(
    action_type: str = "read",
    target: str = "db",
    agent_id: str = "agent-1",
    **params,
) -> Action:
    return Action(
        agent_id=agent_id,
        action_type=action_type,
        target=target,
        parameters=params,
    )


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _deny_policy(
    name: str = "block-deletes",
    when: dict | None = None,
    priority: int = 0,
    enabled: bool = True,
    **then_overrides,
) -> PolicyRule:
    then = {"verdict": "DENY", "reason": f"Policy '{name}' blocked this"}
    then.update(then_overrides)
    return PolicyRule(
        name=name,
        when=when or {"action_type": "delete"},
        then=then,
        priority=priority,
        enabled=enabled,
    )


def _escalate_policy(
    name: str = "escalate-writes",
    when: dict | None = None,
    priority: int = 0,
) -> PolicyRule:
    return PolicyRule(
        name=name,
        when=when or {"action_type": "write"},
        then={
            "verdict": "ESCALATE",
            "reason": f"Policy '{name}' requires escalation",
            "require_human": True,
        },
        priority=priority,
    )


# ── Policy Matching ─────────────────────────────────────────────────────


class TestPolicyMatching:
    def test_exact_action_type_match(self):
        policy = _deny_policy(when={"action_type": "delete"})
        assert policy.matches(_action("delete"), _ctx())

    def test_exact_action_type_no_match(self):
        policy = _deny_policy(when={"action_type": "delete"})
        assert not policy.matches(_action("read"), _ctx())

    def test_wildcard_target_match(self):
        policy = _deny_policy(when={"target": "production/*"})
        assert policy.matches(_action(target="production/db"), _ctx())

    def test_wildcard_target_no_match(self):
        policy = _deny_policy(when={"target": "production/*"})
        assert not policy.matches(_action(target="staging/db"), _ctx())

    def test_numeric_comparison_greater_than(self):
        policy = _deny_policy(when={"parameters.row_count": "> 1000"})
        assert policy.matches(_action(row_count=1500), _ctx())
        assert not policy.matches(_action(row_count=500), _ctx())

    def test_numeric_comparison_less_than(self):
        policy = _deny_policy(when={"parameters.threshold": "< 50"})
        assert policy.matches(_action(threshold=30), _ctx())
        assert not policy.matches(_action(threshold=60), _ctx())

    def test_numeric_comparison_greater_equal(self):
        policy = _deny_policy(when={"parameters.count": ">= 100"})
        assert policy.matches(_action(count=100), _ctx())
        assert policy.matches(_action(count=200), _ctx())
        assert not policy.matches(_action(count=99), _ctx())

    def test_numeric_comparison_less_equal(self):
        policy = _deny_policy(when={"parameters.count": "<= 10"})
        assert policy.matches(_action(count=10), _ctx())
        assert not policy.matches(_action(count=11), _ctx())

    def test_numeric_comparison_equal(self):
        policy = _deny_policy(when={"parameters.count": "== 42"})
        assert policy.matches(_action(count=42), _ctx())
        assert not policy.matches(_action(count=43), _ctx())

    def test_list_membership_match(self):
        policy = _deny_policy(
            when={"action_type": ["delete", "drop", "truncate"]}
        )
        assert policy.matches(_action("delete"), _ctx())
        assert policy.matches(_action("drop"), _ctx())
        assert policy.matches(_action("truncate"), _ctx())
        assert not policy.matches(_action("read"), _ctx())

    def test_multiple_conditions_all_must_match(self):
        policy = _deny_policy(
            when={"action_type": "delete", "target": "production/*"}
        )
        assert policy.matches(
            _action("delete", target="production/db"), _ctx()
        )
        assert not policy.matches(
            _action("delete", target="staging/db"), _ctx()
        )
        assert not policy.matches(
            _action("read", target="production/db"), _ctx()
        )

    def test_no_match_returns_none_from_engine(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(when={"action_type": "delete"}))
        result = engine.evaluate(_action("read"), _ctx())
        assert result is None

    def test_disabled_policy_skipped(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(
            _deny_policy(when={"action_type": "read"}, enabled=False)
        )
        result = engine.evaluate(_action("read"), _ctx())
        assert result is None

    def test_priority_ordering_respected(self):
        engine = PolicyEngine(policy_dirs=[])
        # Low priority: escalate reads
        engine.add_policy(
            PolicyRule(
                name="low-pri",
                when={"action_type": "read"},
                then={"verdict": "ESCALATE", "reason": "low pri"},
                priority=1,
            )
        )
        # High priority: deny reads
        engine.add_policy(
            PolicyRule(
                name="high-pri",
                when={"action_type": "read"},
                then={"verdict": "DENY", "reason": "high pri"},
                priority=10,
            )
        )
        result = engine.evaluate(_action("read"), _ctx())
        assert result is not None
        assert result.matched_policy == "high-pri"
        assert result.verdict == "DENY"

    def test_empty_when_does_not_match(self):
        """A policy with no 'when' conditions should never match."""
        policy = PolicyRule(
            name="no-when",
            when={},
            then={"verdict": "DENY", "reason": "nope"},
        )
        assert not policy.matches(_action("read"), _ctx())


# ── Policy Loading ──────────────────────────────────────────────────────


class TestPolicyLoading:
    def test_empty_directory_loads_zero_policies(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            assert len(engine.list_policies()) == 0

    def test_nonexistent_directory_loads_zero_policies(self):
        engine = PolicyEngine(
            policy_dirs=[Path("/nonexistent/path/that/does/not/exist")]
        )
        assert len(engine.list_policies()) == 0

    def test_programmatic_add_policy(self):
        engine = PolicyEngine(policy_dirs=[])
        assert len(engine.list_policies()) == 0
        engine.add_policy(_deny_policy())
        assert len(engine.list_policies()) == 1
        assert engine.list_policies()[0].name == "block-deletes"

    def test_add_policy_maintains_priority_sort(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(name="low", priority=1))
        engine.add_policy(_deny_policy(name="high", priority=10))
        engine.add_policy(_deny_policy(name="mid", priority=5))
        names = [p.name for p in engine.list_policies()]
        assert names == ["high", "mid", "low"]

    def test_load_json_policy_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            policy_data = {
                "name": "block-prod-deletes",
                "description": "Block all deletes in production",
                "when": {
                    "action_type": "delete",
                    "target": "production/*",
                },
                "then": {
                    "verdict": "DENY",
                    "reason": "Deletes are blocked in production",
                },
                "enabled": True,
                "priority": 10,
            }
            policy_file = Path(tmpdir) / "block-deletes.json"
            policy_file.write_text(json.dumps(policy_data))

            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            policies = engine.list_policies()
            assert len(policies) == 1
            assert policies[0].name == "block-prod-deletes"
            assert policies[0].priority == 10

    def test_invalid_json_skipped_gracefully(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_file = Path(tmpdir) / "bad.json"
            bad_file.write_text("{this is not valid json")

            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            # Should not crash; invalid file is skipped
            assert len(engine.list_policies()) == 0

    def test_load_multiple_json_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            for i, name in enumerate(["policy-a", "policy-b"]):
                data = {
                    "name": name,
                    "when": {"action_type": "delete"},
                    "then": {"verdict": "DENY", "reason": "test"},
                    "priority": i,
                }
                (Path(tmpdir) / f"{name}.json").write_text(json.dumps(data))

            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            assert len(engine.list_policies()) == 2


# ── JSON / YAML File Loading ────────────────────────────────────────────


class TestJSONAndYAMLLoading:
    def test_json_policy_loads_without_pyyaml(self):
        """JSON files load natively — no PyYAML needed."""
        with tempfile.TemporaryDirectory() as tmpdir:
            policy_data = {
                "name": "no-delete-in-production",
                "description": "Block all delete operations in production zone",
                "when": {
                    "action_type": "delete",
                    "zone_path": "production/*",
                },
                "then": {
                    "verdict": "DENY",
                    "reason": "Delete operations prohibited in production zone",
                },
            }
            policy_file = Path(tmpdir) / "no-delete.json"
            policy_file.write_text(json.dumps(policy_data))

            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            policies = engine.list_policies()
            assert len(policies) == 1
            assert policies[0].name == "no-delete-in-production"

            # Confirm the rule evaluates correctly
            action = _action("delete")
            ctx = _ctx()
            # zone_path defaults to "" via getattr, won't match "production/*"
            assert not policies[0].matches(action, ctx)

    def test_yaml_without_pyyaml_raises_clear_error(self):
        """YAML files raise PolicyLoadError when PyYAML is not installed."""
        import builtins

        real_import = builtins.__import__

        def _mock_import(name, *args, **kwargs):
            if name == "yaml":
                raise ImportError("No module named 'yaml'")
            return real_import(name, *args, **kwargs)

        with tempfile.TemporaryDirectory() as tmpdir:
            yaml_file = Path(tmpdir) / "block-deletes.yaml"
            yaml_file.write_text(
                '{"name": "test", "when": {"action_type": "delete"}, '
                '"then": {"verdict": "DENY", "reason": "test"}}'
            )

            with patch.object(builtins, "__import__", side_effect=_mock_import):
                with pytest.raises(PolicyLoadError) as exc_info:
                    PolicyEngine(policy_dirs=[Path(tmpdir)])

            assert "pip install pyyaml" in str(exc_info.value)
            assert str(yaml_file) in str(exc_info.value)

    @pytest.mark.skipif(
        not _try_import_yaml(), reason="PyYAML not installed"
    )
    def test_yaml_with_pyyaml_installed_loads_correctly(self):
        """YAML files load correctly when PyYAML IS installed."""
        import yaml

        with tempfile.TemporaryDirectory() as tmpdir:
            policy_data = {
                "name": "yaml-policy",
                "description": "A YAML-loaded policy",
                "when": {"action_type": "write"},
                "then": {
                    "verdict": "ESCALATE",
                    "reason": "Write requires approval",
                    "require_human": True,
                },
                "priority": 5,
            }
            policy_file = Path(tmpdir) / "escalate-writes.yaml"
            policy_file.write_text(yaml.dump(policy_data))

            engine = PolicyEngine(policy_dirs=[Path(tmpdir)])
            policies = engine.list_policies()
            assert len(policies) == 1
            assert policies[0].name == "yaml-policy"
            assert policies[0].priority == 5

            # Confirm evaluation
            result = engine.evaluate(_action("write"), _ctx())
            assert result is not None
            assert result.verdict == "ESCALATE"


# ── Policy Validation ───────────────────────────────────────────────────


class TestPolicyValidation:
    def test_duplicate_names_detected(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(name="dup"))
        engine.add_policy(_deny_policy(name="dup"))
        issues = engine.validate_all()
        dup_issues = [i for i in issues if i["issue"] == "Duplicate policy name"]
        assert len(dup_issues) == 1

    def test_missing_when_detected(self):
        engine = PolicyEngine(policy_dirs=[])
        engine._policies.append(
            PolicyRule(
                name="no-when",
                when={},
                then={"verdict": "DENY", "reason": "test"},
            )
        )
        issues = engine.validate_all()
        when_issues = [
            i for i in issues if "when" in i["issue"].lower()
        ]
        assert len(when_issues) == 1

    def test_missing_then_detected(self):
        engine = PolicyEngine(policy_dirs=[])
        engine._policies.append(
            PolicyRule(
                name="no-then",
                when={"action_type": "read"},
                then={},
            )
        )
        issues = engine.validate_all()
        then_issues = [
            i for i in issues if "then" in i["issue"].lower()
        ]
        assert len(then_issues) == 1

    def test_invalid_verdict_detected(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(
            PolicyRule(
                name="bad-verdict",
                when={"action_type": "read"},
                then={"verdict": "WARN", "reason": "test"},
            )
        )
        issues = engine.validate_all()
        verdict_issues = [
            i for i in issues if "Invalid verdict" in i["issue"]
        ]
        assert len(verdict_issues) == 1

    def test_allow_verdict_rejected(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(
            PolicyRule(
                name="allow-attempt",
                when={"action_type": "read"},
                then={"verdict": "ALLOW", "reason": "should fail"},
            )
        )
        issues = engine.validate_all()
        verdict_issues = [
            i for i in issues if "Invalid verdict" in i["issue"]
        ]
        assert len(verdict_issues) == 1
        assert "ALLOW" in verdict_issues[0]["issue"]

    def test_valid_policies_no_issues(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(name="a"))
        engine.add_policy(_escalate_policy(name="b"))
        issues = engine.validate_all()
        assert len(issues) == 0


# ── PolicyEngine.evaluate() ─────────────────────────────────────────────


class TestPolicyEngineEvaluate:
    def test_matching_policy_returns_policy_result(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(when={"action_type": "delete"}))
        result = engine.evaluate(_action("delete"), _ctx())
        assert result is not None
        assert isinstance(result, PolicyResult)

    def test_no_match_returns_none(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(when={"action_type": "delete"}))
        result = engine.evaluate(_action("read"), _ctx())
        assert result is None

    def test_deny_verdict_correct(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy())
        result = engine.evaluate(_action("delete"), _ctx())
        assert result is not None
        assert result.verdict == "DENY"

    def test_escalate_verdict_correct(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_escalate_policy())
        result = engine.evaluate(_action("write"), _ctx())
        assert result is not None
        assert result.verdict == "ESCALATE"

    def test_require_human_flag_passed_through(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_escalate_policy())
        result = engine.evaluate(_action("write"), _ctx())
        assert result is not None
        assert result.require_human is True

    def test_matched_policy_name_correct(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(_deny_policy(name="my-policy"))
        result = engine.evaluate(_action("delete"), _ctx())
        assert result is not None
        assert result.matched_policy == "my-policy"

    def test_reason_from_policy(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(
            PolicyRule(
                name="custom-reason",
                when={"action_type": "delete"},
                then={"verdict": "DENY", "reason": "Not allowed here"},
            )
        )
        result = engine.evaluate(_action("delete"), _ctx())
        assert result is not None
        assert result.reason == "Not allowed here"

    def test_default_reason_when_not_specified(self):
        engine = PolicyEngine(policy_dirs=[])
        engine.add_policy(
            PolicyRule(
                name="no-reason",
                when={"action_type": "delete"},
                then={"verdict": "DENY"},
            )
        )
        result = engine.evaluate(_action("delete"), _ctx())
        assert result is not None
        assert "no-reason" in result.reason


# ── Runtime Integration ──────────────────────────────────────────────────


class TestRuntimeIntegration:
    def test_policy_deny_short_circuits_before_dimensional(self):
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        # Add a policy that denies deletes
        runtime._policy_engine.add_policy(
            _deny_policy(when={"action_type": "delete"})
        )

        verdict = runtime.evaluate(_action("delete"), _ctx())
        assert verdict.verdict == Verdict.DENY
        assert verdict.tier == 0  # Pre-filter tier
        assert verdict.dimension_scores == []  # No dimensions evaluated
        assert "policy_match" in verdict.modifications
        assert verdict.modifications["policy_match"] == "block-deletes"

    def test_policy_escalate_triggers_escalation(self):
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        runtime._policy_engine.add_policy(
            _escalate_policy(when={"action_type": "write"})
        )

        verdict = runtime.evaluate(_action("write"), _ctx())
        assert verdict.verdict == Verdict.ESCALATE
        assert verdict.tier == 0
        assert "policy_match" in verdict.modifications

    def test_nonmatching_policy_passes_through_to_dimensional(self):
        runtime = GovernanceRuntime()
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"*"})

        # Add a policy that only blocks deletes
        runtime._policy_engine.add_policy(
            _deny_policy(when={"action_type": "delete"})
        )

        # Read should pass through to dimensional evaluation
        verdict = runtime.evaluate(_action("read"), _ctx())
        # The action should be evaluated through dimensions (not tier 0)
        assert verdict.tier != 0
        # With wildcard scope, reads should be allowed
        assert verdict.verdict == Verdict.ALLOW

    def test_policy_result_recorded_in_verdict_modifications(self):
        runtime = GovernanceRuntime()
        runtime._policy_engine.add_policy(
            _deny_policy(name="test-policy", when={"action_type": "delete"})
        )

        verdict = runtime.evaluate(_action("delete"), _ctx())
        assert verdict.modifications.get("policy_match") == "test-policy"

    def test_policy_deny_has_zero_ucs(self):
        runtime = GovernanceRuntime()
        runtime._policy_engine.add_policy(
            _deny_policy(when={"action_type": "delete"})
        )

        verdict = runtime.evaluate(_action("delete"), _ctx())
        assert verdict.ucs == 0.0

    def test_policy_engine_accessible_from_runtime(self):
        runtime = GovernanceRuntime()
        assert runtime.policy_engine is not None
        assert isinstance(runtime.policy_engine, PolicyEngine)

    def test_policy_evaluation_time_recorded(self):
        runtime = GovernanceRuntime()
        runtime._policy_engine.add_policy(
            _deny_policy(when={"action_type": "delete"})
        )

        verdict = runtime.evaluate(_action("delete"), _ctx())
        assert verdict.evaluation_time_ms >= 0


# ── Field Resolution ─────────────────────────────────────────────────────


class TestFieldResolution:
    def test_action_type_resolved(self):
        policy = _deny_policy(when={"action_type": "delete"})
        assert policy.matches(_action("delete"), _ctx())

    def test_target_resolved(self):
        policy = _deny_policy(when={"target": "my-db"})
        assert policy.matches(_action(target="my-db"), _ctx())

    def test_agent_id_from_action(self):
        policy = _deny_policy(when={"agent_id": "agent-1"})
        assert policy.matches(_action(agent_id="agent-1"), _ctx())

    def test_agent_id_fallback_to_context(self):
        policy = _deny_policy(when={"agent_id": "agent-1"})
        # Action with no agent_id, context has agent_id
        action = Action(agent_id="", action_type="delete")
        assert policy.matches(action, _ctx(agent_id="agent-1"))

    def test_parameters_dotted_path(self):
        policy = _deny_policy(when={"parameters.env": "production"})
        assert policy.matches(_action(env="production"), _ctx())
        assert not policy.matches(_action(env="staging"), _ctx())

    def test_metadata_dotted_path(self):
        policy = _deny_policy(when={"metadata.source": "api"})
        action = Action(
            action_type="delete",
            metadata={"source": "api"},
        )
        assert policy.matches(action, _ctx())

    def test_unknown_field_returns_none_no_match(self):
        policy = _deny_policy(when={"nonexistent_field": "value"})
        assert not policy.matches(_action("delete"), _ctx())

    def test_zone_path_from_context(self):
        """zone_path uses getattr so it works even without the field."""
        policy = _deny_policy(when={"zone_path": ""})
        # AgentContext doesn't have zone_path, getattr returns ""
        assert policy.matches(_action(), _ctx())


# ── PolicyRule serialization ─────────────────────────────────────────────


class TestPolicyRuleSerialization:
    def test_to_dict_roundtrip(self):
        policy = _deny_policy(
            name="test",
            when={"action_type": "delete"},
            priority=5,
        )
        data = policy.to_dict()
        restored = PolicyRule.from_dict(data)
        assert restored.name == policy.name
        assert restored.when == policy.when
        assert restored.then == policy.then
        assert restored.priority == policy.priority
        assert restored.enabled == policy.enabled

    def test_from_dict_with_policy_wrapper(self):
        data = {
            "policy": {
                "name": "wrapped",
                "when": {"action_type": "read"},
                "then": {"verdict": "DENY", "reason": "test"},
            }
        }
        policy = PolicyRule.from_dict(data)
        assert policy.name == "wrapped"

    def test_from_dict_defaults(self):
        data = {"name": "minimal"}
        policy = PolicyRule.from_dict(data)
        assert policy.description == ""
        assert policy.when == {}
        assert policy.then == {}
        assert policy.enabled is True
        assert policy.priority == 0


# ── Exports ──────────────────────────────────────────────────────────────


class TestExports:
    def test_importable_from_nomotic(self):
        from nomotic import PolicyEngine, PolicyResult, PolicyRule

        assert PolicyEngine is not None
        assert PolicyResult is not None
        assert PolicyRule is not None


