"""Tests for reversibility-aware governance.

Covers:
- CommitPointDetector: action pattern matching, target sensitivity,
  environment context, compound action names, custom patterns
- ReversibilityAssessment: cascading_impact modifier, to_dict,
  is_irreversible/is_time_bounded properties
- Affected scope estimation
- Integration: reversibility modifiers in contextual_modifier,
  tier escalation in runtime, verdict metadata
- Workflow governor backward compatibility
"""

from __future__ import annotations

import pytest

from nomotic.reversibility import (
    CommitPointDetector,
    ReversibilityAssessment,
    ReversibilityLevel,
)


# ── CommitPointDetector tests ───────────────────────────────────────────


class TestCommitPointDetector:
    """Test the core detection logic."""

    def test_read_is_fully_reversible(self):
        detector = CommitPointDetector()
        result = detector.assess("read", "customers")
        assert result.level == ReversibilityLevel.FULLY_REVERSIBLE
        assert result.score == 1.0
        assert not result.requires_escalation

    def test_delete_is_irreversible(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "customers")
        assert result.level == ReversibilityLevel.IRREVERSIBLE
        assert result.score == 0.0

    def test_delete_sensitive_target_requires_escalation(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "customer_data")
        assert result.requires_escalation

    def test_delete_nonsensitive_target_no_escalation(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "temp_logs")
        assert result.level == ReversibilityLevel.IRREVERSIBLE
        assert not result.requires_escalation  # Not a sensitive target pattern

    def test_send_email_is_time_bounded(self):
        detector = CommitPointDetector()
        result = detector.assess("send_email", "user@example.com")
        assert result.level == ReversibilityLevel.TIME_BOUNDED
        assert result.window_seconds == 30
        assert result.undo_mechanism == "recall_message"

    def test_update_is_partially_reversible(self):
        detector = CommitPointDetector()
        result = detector.assess("update", "orders")
        assert result.level == ReversibilityLevel.PARTIALLY_REVERSIBLE
        assert result.score == 0.50

    def test_sensitive_target_escalates_level(self):
        """Sensitive targets bump reversibility up one level."""
        detector = CommitPointDetector()
        # update on normal target = PARTIALLY_REVERSIBLE
        normal = detector.assess("update", "temp_data")
        # update on sensitive target = DIFFICULT_TO_REVERSE
        sensitive = detector.assess("update", "credentials")
        assert sensitive.level.value != normal.level.value
        assert sensitive.score < normal.score

    def test_staging_environment_deescalates(self):
        """Non-production environments are more reversible."""
        detector = CommitPointDetector()
        prod = detector.assess(
            "delete", "customers", context={"environment": "production"}
        )
        staging = detector.assess(
            "delete", "customers", context={"environment": "staging"}
        )
        assert staging.score > prod.score

    def test_compound_action_name(self):
        """Action names like 'hard_delete' or 'db_delete' are detected."""
        detector = CommitPointDetector()
        result = detector.assess("hard_delete", "users")
        assert result.level in (
            ReversibilityLevel.IRREVERSIBLE,
            ReversibilityLevel.DIFFICULT_TO_REVERSE,
        )

    def test_unknown_action_defaults_to_partially_reversible(self):
        detector = CommitPointDetector()
        result = detector.assess("frobnicate", "widgets")
        assert result.level == ReversibilityLevel.PARTIALLY_REVERSIBLE
        assert result.confidence == 0.5  # Low confidence for unknown

    def test_custom_patterns(self):
        """Custom patterns override defaults."""
        detector = CommitPointDetector(
            custom_patterns={"read": ReversibilityLevel.DIFFICULT_TO_REVERSE}
        )
        result = detector.assess("read", "customers")
        assert result.level == ReversibilityLevel.DIFFICULT_TO_REVERSE

    def test_transfer_funds_is_irreversible(self):
        detector = CommitPointDetector()
        result = detector.assess("transfer_funds", "account_123")
        assert result.level == ReversibilityLevel.IRREVERSIBLE
        assert result.undo_mechanism is None

    def test_query_is_fully_reversible(self):
        detector = CommitPointDetector()
        result = detector.assess("query", "database")
        assert result.level == ReversibilityLevel.FULLY_REVERSIBLE
        assert result.score == 1.0
        assert result.confidence == 0.9

    def test_deploy_is_difficult_to_reverse(self):
        detector = CommitPointDetector()
        result = detector.assess("deploy", "service")
        assert result.level == ReversibilityLevel.DIFFICULT_TO_REVERSE
        assert result.undo_mechanism == "rollback_deployment"

    def test_create_is_partially_reversible(self):
        detector = CommitPointDetector()
        result = detector.assess("create", "order")
        assert result.level == ReversibilityLevel.PARTIALLY_REVERSIBLE
        assert result.undo_mechanism == "delete_created"

    def test_deploy_on_production_sensitive_requires_escalation(self):
        detector = CommitPointDetector()
        result = detector.assess("deploy", "production")
        # deploy is DIFFICULT_TO_REVERSE, production is sensitive -> escalation
        assert result.requires_escalation

    def test_reasoning_includes_action_and_target(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "customers")
        assert "delete" in result.reasoning
        assert "customers" in result.reasoning


# ── ReversibilityAssessment tests ───────────────────────────────────────


class TestReversibilityAssessment:
    """Test the assessment dataclass behavior."""

    def test_cascading_impact_modifier_irreversible(self):
        assessment = ReversibilityAssessment(
            level=ReversibilityLevel.IRREVERSIBLE,
            score=0.0,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="test",
            affected_scope="table",
            requires_escalation=True,
        )
        assert assessment.cascading_impact_modifier == 0.40

    def test_cascading_impact_modifier_reversible(self):
        assessment = ReversibilityAssessment(
            level=ReversibilityLevel.FULLY_REVERSIBLE,
            score=1.0,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="test",
            affected_scope="single_record",
            requires_escalation=False,
        )
        assert assessment.cascading_impact_modifier == -0.10

    def test_cascading_impact_modifier_time_bounded(self):
        assessment = ReversibilityAssessment(
            level=ReversibilityLevel.TIME_BOUNDED,
            score=0.75,
            window_seconds=30,
            undo_mechanism="recall_message",
            confidence=0.9,
            reasoning="test",
            affected_scope="external",
            requires_escalation=False,
        )
        assert assessment.cascading_impact_modifier == 0.05

    def test_cascading_impact_modifier_difficult(self):
        assessment = ReversibilityAssessment(
            level=ReversibilityLevel.DIFFICULT_TO_REVERSE,
            score=0.20,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="test",
            affected_scope="system",
            requires_escalation=False,
        )
        assert assessment.cascading_impact_modifier == 0.30

    def test_to_dict_roundtrip(self):
        assessment = ReversibilityAssessment(
            level=ReversibilityLevel.TIME_BOUNDED,
            score=0.75,
            window_seconds=30,
            undo_mechanism="recall_message",
            confidence=0.9,
            reasoning="send_email is time-bounded",
            affected_scope="external",
            requires_escalation=False,
        )
        d = assessment.to_dict()
        assert d["level"] == "time_bounded"
        assert d["window_seconds"] == 30
        assert d["undo_mechanism"] == "recall_message"
        assert d["score"] == 0.75
        assert d["confidence"] == 0.9
        assert d["affected_scope"] == "external"
        assert d["requires_escalation"] is False

    def test_is_irreversible_property(self):
        irrev = ReversibilityAssessment(
            level=ReversibilityLevel.IRREVERSIBLE,
            score=0.0,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="",
            affected_scope="",
            requires_escalation=False,
        )
        assert irrev.is_irreversible

        rev = ReversibilityAssessment(
            level=ReversibilityLevel.FULLY_REVERSIBLE,
            score=1.0,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="",
            affected_scope="",
            requires_escalation=False,
        )
        assert not rev.is_irreversible

    def test_is_time_bounded_property(self):
        tb = ReversibilityAssessment(
            level=ReversibilityLevel.TIME_BOUNDED,
            score=0.75,
            window_seconds=30,
            undo_mechanism="recall_message",
            confidence=0.9,
            reasoning="",
            affected_scope="",
            requires_escalation=False,
        )
        assert tb.is_time_bounded

        irrev = ReversibilityAssessment(
            level=ReversibilityLevel.IRREVERSIBLE,
            score=0.0,
            window_seconds=None,
            undo_mechanism=None,
            confidence=0.9,
            reasoning="",
            affected_scope="",
            requires_escalation=False,
        )
        assert not irrev.is_time_bounded


# ── Affected scope tests ────────────────────────────────────────────────


class TestAffectedScope:
    """Test blast radius estimation."""

    def test_delete_single_record(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "order_123")
        assert result.affected_scope == "single_record"

    def test_truncate_is_table_scope(self):
        detector = CommitPointDetector()
        result = detector.assess("truncate", "logs")
        assert result.affected_scope == "table"

    def test_send_email_is_external(self):
        detector = CommitPointDetector()
        result = detector.assess("send_email", "user@example.com")
        assert result.affected_scope == "external"

    def test_broadcast_is_external(self):
        detector = CommitPointDetector()
        result = detector.assess("broadcast", "all_users")
        assert result.affected_scope == "external"

    def test_delete_all_is_table_scope(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "all_records")
        assert result.affected_scope == "table"

    def test_delete_wildcard_is_table_scope(self):
        detector = CommitPointDetector()
        result = detector.assess("delete", "users/*")
        assert result.affected_scope == "table"


# ── Integration tests ───────────────────────────────────────────────────


class TestIntegrationWithEvaluation:
    """Test that reversibility modifies governance outcomes."""

    def test_verdict_contains_reversibility_metadata(self):
        """Verdict should contain reversibility assessment."""
        from nomotic.runtime import GovernanceRuntime
        from nomotic.types import Action, AgentContext, TrustProfile

        runtime = GovernanceRuntime()
        context = AgentContext(
            agent_id="rev-test",
            trust_profile=TrustProfile(agent_id="rev-test"),
        )

        verdict = runtime.evaluate(
            Action(action_type="send_email", target="user@example.com"),
            context,
        )
        assert verdict.reversibility is not None
        assert verdict.reversibility["level"] == "time_bounded"
        assert verdict.reversibility["window_seconds"] == 30

    def test_read_verdict_has_reversibility(self):
        """Even read actions get reversibility assessment."""
        from nomotic.runtime import GovernanceRuntime
        from nomotic.types import Action, AgentContext, TrustProfile

        runtime = GovernanceRuntime()
        context = AgentContext(
            agent_id="rev-test",
            trust_profile=TrustProfile(agent_id="rev-test"),
        )

        verdict = runtime.evaluate(
            Action(action_type="read", target="customers"),
            context,
        )
        assert verdict.reversibility is not None
        assert verdict.reversibility["level"] == "fully_reversible"

    def test_delete_verdict_has_irreversible(self):
        """Delete actions marked as irreversible in verdict."""
        from nomotic.runtime import GovernanceRuntime
        from nomotic.types import Action, AgentContext, TrustProfile

        runtime = GovernanceRuntime()
        context = AgentContext(
            agent_id="rev-test",
            trust_profile=TrustProfile(agent_id="rev-test"),
        )

        verdict = runtime.evaluate(
            Action(action_type="delete", target="temp_logs"),
            context,
        )
        assert verdict.reversibility is not None
        assert verdict.reversibility["level"] == "irreversible"
        assert verdict.reversibility["score"] == 0.0


class TestTokenReversibilityWindow:
    """Test that reversibility_window_seconds works in tokens."""

    def test_token_claims_reversibility_window(self):
        from nomotic.token import TokenClaims

        claims = TokenClaims(
            iss="eval-01",
            sub="agent-1",
            exp=9999999999,
            iat=1000000000,
            jti="test-123",
            nomo_verdict="PROCEED",
            nomo_artifact_hash="sha256:abc",
            nomo_method="send_email",
            nomo_action_target="user@example.com",
            nomo_flow="full",
            nomo_scope="single",
            nomo_reversibility_window_seconds=30,
        )
        d = claims.to_dict()
        assert d["nomo_reversibility_window_seconds"] == 30

    def test_token_claims_no_reversibility_window(self):
        from nomotic.token import TokenClaims

        claims = TokenClaims(
            iss="eval-01",
            sub="agent-1",
            exp=9999999999,
            iat=1000000000,
            jti="test-123",
            nomo_verdict="PROCEED",
            nomo_artifact_hash="sha256:abc",
            nomo_method="read",
            nomo_action_target="customers",
            nomo_flow="full",
            nomo_scope="single",
        )
        d = claims.to_dict()
        assert "nomo_reversibility_window_seconds" not in d

    def test_token_claims_from_dict_roundtrip(self):
        from nomotic.token import TokenClaims

        original = TokenClaims(
            iss="eval-01",
            sub="agent-1",
            exp=9999999999,
            iat=1000000000,
            jti="test-123",
            nomo_verdict="PROCEED",
            nomo_artifact_hash="sha256:abc",
            nomo_method="send_email",
            nomo_action_target="user@example.com",
            nomo_flow="full",
            nomo_scope="single",
            nomo_reversibility_window_seconds=30,
        )
        d = original.to_dict()
        restored = TokenClaims.from_dict(d)
        assert restored.nomo_reversibility_window_seconds == 30


class TestWorkflowGovernorCompat:
    """Verify that workflow_governor still works after refactor."""

    def test_is_transaction_still_works(self):
        """Legacy _is_transaction helper should still detect transactions."""
        from nomotic.workflow_governor import _is_transaction

        assert _is_transaction("transfer")
        assert _is_transaction("charge")
        assert _is_transaction("purchase")
        assert _is_transaction("some_transaction_method")
        assert not _is_transaction("read")
        assert not _is_transaction("query")

    def test_workflow_governor_still_detects_irreversibility_chain(self):
        """Workflow risk assessment should still detect irreversibility chains."""
        from nomotic.context_profile import (
            CompletedStep,
            ContextProfile,
            WorkflowContext,
        )
        from nomotic.workflow_governor import WorkflowGovernor

        # Build a workflow with consecutive non-reversible steps
        # (steps without rollback points)
        steps = []
        for i in range(5):
            steps.append(CompletedStep(
                step_number=i + 1,
                step_id=f"step-{i + 1}",
                method="transfer" if i < 3 else "query",
                target=f"resource_{i}",
                ucs=0.6,
                verdict="ALLOW",
                timestamp="2026-01-01T00:00:00Z",
            ))

        workflow = WorkflowContext(
            workflow_id="test-wf",
            workflow_type="test_workflow",
            total_steps=5,
            current_step=5,
            steps_completed=steps,
            steps_remaining=[],
            dependencies=[],
            rollback_points=[],  # No rollback points
        )

        profile = ContextProfile(
            profile_id="test-profile",
            agent_id="test-agent",
            profile_type="workflow",
            workflow=workflow,
        )
        governor = WorkflowGovernor()
        assessment = governor.assess_workflow("test-wf", profile)

        # Should detect irreversibility chain risk factor
        irrev_factors = [
            f for f in assessment.risk_factors
            if f.factor_type == "irreversibility_chain"
        ]
        assert len(irrev_factors) >= 1
