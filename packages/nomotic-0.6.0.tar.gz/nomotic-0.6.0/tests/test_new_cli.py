"""Tests for the nomotic new CLI command."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from nomotic.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_config(tmp: str, org: str = "acme-corp", owner: str = "admin@acme.com",
                  zone: str = "global", default_preset: str | None = None,
                  compliance_presets: list[str] | None = None) -> None:
    """Write a minimal config.json to the temp base dir."""
    config = {
        "organization": org,
        "owner": owner,
        "default_zone": zone,
    }
    if default_preset:
        config["default_preset"] = default_preset
    if compliance_presets:
        config["compliance_presets"] = compliance_presets
    Path(tmp, "config.json").write_text(json.dumps(config), encoding="utf-8")


def _read_yaml(project_dir: str) -> str:
    """Read nomotic.yaml from project directory."""
    return Path(project_dir, "nomotic.yaml").read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestNewCommand:
    """Tests for 'nomotic new'."""

    def test_fully_noninteractive(self, capsys):
        """All flags provided → fully non-interactive, no input() calls."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "test-agent",
                "--preset", "strict",
                "--actions", "read,query",
                "--targets", "docs",
                "--owner", "test@co.com",
                "--reason", "Test agent",
                "--force",
            ])
            captured = capsys.readouterr()
            assert "Created nomotic.yaml" in captured.out
            assert "Validation passed" in captured.out

            content = _read_yaml(proj)
            assert 'version: "1.0"' in content
            assert 'extends: "strict"' in content
            assert "test-agent:" in content
            assert "actions: [read, query]" in content
            assert "targets: [docs]" in content
            assert "boundaries: [docs]" in content
            assert "initial: 0.5" in content
            assert "minimum_for_action: 0.3" in content
            assert 'owner: "test@co.com"' in content
            assert 'reason: "Test agent"' in content

    def test_preset_strict(self, capsys):
        """--preset strict sets extends to strict."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
            ])
            content = _read_yaml(proj)
            assert 'extends: "strict"' in content

    def test_preset_hipaa_shows_disclaimer(self, capsys):
        """--preset hipaa_aligned shows disclaimer."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "hipaa_aligned",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
            ])
            captured = capsys.readouterr()
            assert "hipaa_aligned" in captured.out
            content = _read_yaml(proj)
            assert 'extends: "hipaa_aligned"' in content

    def test_preset_invalid_suggests_correction(self, capsys):
        """--preset HIPAA gives error suggesting hipaa_aligned."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            with pytest.raises(SystemExit):
                main([
                    "--base-dir", base,
                    "new", proj,
                    "--name", "a",
                    "--preset", "HIPAA",
                    "--actions", "read",
                    "--targets", "x",
                    "--owner", "o",
                    "--reason", "r",
                    "--force",
                ])
            captured = capsys.readouterr()
            assert "hipaa_aligned" in captured.err

    def test_existing_without_force_asks_confirmation(self, capsys):
        """Existing nomotic.yaml without --force asks for confirmation, exits on N."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            # Create existing file
            Path(proj, "nomotic.yaml").write_text("existing", encoding="utf-8")

            with patch("builtins.input", return_value="N"):
                with pytest.raises(SystemExit) as exc:
                    main([
                        "--base-dir", base,
                        "new", proj,
                        "--name", "a",
                        "--preset", "strict",
                        "--actions", "read",
                        "--targets", "x",
                        "--owner", "o",
                        "--reason", "r",
                    ])
                assert exc.value.code == 0

            # File should not be overwritten
            assert Path(proj, "nomotic.yaml").read_text(encoding="utf-8") == "existing"

    def test_existing_with_force_overwrites(self, capsys):
        """Existing nomotic.yaml with --force overwrites without asking."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            Path(proj, "nomotic.yaml").write_text("existing", encoding="utf-8")

            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
            ])
            content = _read_yaml(proj)
            assert 'extends: "strict"' in content

    def test_full_flag_includes_comments(self, capsys):
        """--full flag includes commented override sections."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
                "--full",
            ])
            content = _read_yaml(proj)
            assert "# ─── Optional overrides" in content
            assert "# dimensions:" in content
            assert "#   weights:" in content
            assert "# thresholds:" in content
            assert "# trust:" in content
            assert "# compliance:" in content

    def test_without_full_no_comments(self, capsys):
        """Without --full, output has NO commented sections."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
            ])
            content = _read_yaml(proj)
            assert "# ─── Optional overrides" not in content
            assert "# dimensions:" not in content

    def test_no_validate_skips_validation(self, capsys):
        """--no-validate skips validation."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
                "--no-validate",
            ])
            captured = capsys.readouterr()
            assert "Created nomotic.yaml" in captured.out
            assert "Validation" not in captured.out

    def test_default_name_from_directory(self, capsys):
        """Default agent name comes from directory name."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            dir_name = Path(proj).name

            with patch("builtins.input", side_effect=[
                "",          # agent name (accept default = dir name)
                "read",      # actions
                "docs",      # targets
                "1",         # preset (standard)
                "owner@x",   # owner
                "reason",    # reason
            ]):
                main(["--base-dir", base, "new", proj, "--force"])
                captured = capsys.readouterr()
                assert "Created nomotic.yaml" in captured.out

                content = _read_yaml(proj)
                assert f"  {dir_name}:" in content

    def test_defaults_from_config(self, capsys):
        """Defaults pulled from ~/.nomotic/config.json when available (owner, preset)."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            _write_config(base, owner="config-owner@x.com")

            # Provide all flags except owner; mock input to accept config default
            with patch("builtins.input", return_value=""):
                main([
                    "--base-dir", base,
                    "new", proj,
                    "--name", "a",
                    "--preset", "strict",
                    "--actions", "read",
                    "--targets", "x",
                    "--reason", "r",
                    "--force",
                ])
            content = _read_yaml(proj)
            assert 'owner: "config-owner@x.com"' in content

    def test_generated_yaml_validates_clean(self, capsys):
        """Generated YAML can be loaded by load_governance_config_from_string and validates."""
        from nomotic.config_loader import (
            load_governance_config_from_string,
            validate_governance_config,
        )

        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "test-agent",
                "--preset", "strict",
                "--actions", "read,query",
                "--targets", "docs,records",
                "--owner", "test@co.com",
                "--reason", "Testing",
                "--force",
            ])
            content = _read_yaml(proj)
            config = load_governance_config_from_string(content)
            errors = validate_governance_config(config)
            assert errors == []

    def test_generated_yaml_to_runtime_config(self, capsys):
        """Generated YAML can be converted to RuntimeConfig without errors."""
        from nomotic.config_loader import load_governance_config_from_string

        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "test-agent",
                "--preset", "strict",
                "--actions", "read,query",
                "--targets", "docs",
                "--owner", "test@co.com",
                "--reason", "Testing",
                "--force",
            ])
            content = _read_yaml(proj)
            config = load_governance_config_from_string(content)
            runtime_config = config.to_runtime_config()
            assert runtime_config is not None

    def test_interactive_mode_all_prompts(self, capsys):
        """Fully interactive mode with all prompts creates correct nomotic.yaml."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            with patch("builtins.input", side_effect=[
                "my-agent",             # agent name
                "read, write, query",   # actions
                "customer_records, orders",  # targets
                "2",                    # preset (strict)
                "team@company.com",     # owner
                "Customer service automation agent",  # reason
            ]):
                main(["--base-dir", base, "new", proj, "--force"])

            captured = capsys.readouterr()
            assert "Created nomotic.yaml" in captured.out

            content = _read_yaml(proj)
            assert 'version: "1.0"' in content
            assert 'extends: "strict"' in content
            assert "my-agent:" in content
            assert "actions: [read, write, query]" in content
            assert "targets: [customer_records, orders]" in content
            assert "boundaries: [customer_records, orders]" in content
            assert 'owner: "team@company.com"' in content
            assert 'reason: "Customer service automation agent"' in content

    def test_flags_skip_prompts(self, capsys):
        """--name, --preset, --actions, --targets flags skip corresponding prompts."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            # Only owner and reason need interactive input
            with patch("builtins.input", side_effect=[
                "team@co.com",  # owner
                "Test reason",  # reason
            ]):
                main([
                    "--base-dir", base,
                    "new", proj,
                    "--name", "my-agent",
                    "--preset", "strict",
                    "--actions", "read,query",
                    "--targets", "docs",
                    "--force",
                ])

            content = _read_yaml(proj)
            assert "my-agent:" in content
            assert 'extends: "strict"' in content
            assert "actions: [read, query]" in content
            assert "targets: [docs]" in content

    def test_auto_validation_runs(self, capsys):
        """Auto-validation runs and reports pass."""
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as proj:
            main([
                "--base-dir", base,
                "new", proj,
                "--name", "a",
                "--preset", "strict",
                "--actions", "read",
                "--targets", "x",
                "--owner", "o",
                "--reason", "r",
                "--force",
            ])
            captured = capsys.readouterr()
            assert "Validation passed" in captured.out
