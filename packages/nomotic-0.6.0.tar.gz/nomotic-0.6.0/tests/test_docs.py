"""Verify all documented modules are importable."""

import importlib

import pytest

DOCUMENTED_MODULES = [
    "nomotic.runtime",
    "nomotic.executor",
    "nomotic.evaluator",
    "nomotic.dimensions",
    "nomotic.trust",
    "nomotic.drift",
    "nomotic.audit_store",
    "nomotic.workflow_governor",
    "nomotic.token",
    "nomotic.certificate",
    "nomotic.sdk",
]


@pytest.mark.parametrize("module", DOCUMENTED_MODULES)
def test_documented_modules_importable(module):
    """Every module in Sphinx autodoc must be importable."""
    importlib.import_module(module)
