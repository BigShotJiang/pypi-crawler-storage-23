"""Tests for AsyncGovernedToolExecutor — async governance wrapper."""

from __future__ import annotations

import asyncio

import pytest

pytest.importorskip("pytest_asyncio")

from nomotic.async_executor import AsyncGovernedToolExecutor
from nomotic.audit_store import LogStore
from nomotic.authority import CertificateAuthority
from nomotic.executor import GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )
    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


class TestAsyncConnect:
    """Test async executor creation."""

    @pytest.mark.asyncio
    async def test_connect(self, tmp_path):
        """Async connect loads agent identity."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        assert executor.agent_id == "test-bot"

    @pytest.mark.asyncio
    async def test_connect_from_sync(self, tmp_path):
        """Can wrap a sync executor directly."""
        _setup_agent(tmp_path, "test-bot")
        sync = GovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        executor = AsyncGovernedToolExecutor(sync)
        assert executor.agent_id == "test-bot"


class TestAsyncExecute:
    """Test async execution."""

    @pytest.mark.asyncio
    async def test_execute_allowed(self, tmp_path):
        """Allowed actions execute and return data."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        result = await executor.execute(
            action="read",
            target="customers",
            tool_fn=lambda: {"rows": 5},
        )
        assert result.allowed
        assert result.data == {"rows": 5}

    @pytest.mark.asyncio
    async def test_execute_denied(self, tmp_path):
        """Denied actions return without executing tool."""
        _setup_agent(tmp_path, "test-bot", actions=["read"])
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        called = []
        result = await executor.execute(
            action="delete_all",
            target="production_db",
            tool_fn=lambda: called.append(True),
        )
        assert not result.allowed
        assert result.verdict == "DENY"
        assert len(called) == 0

    @pytest.mark.asyncio
    async def test_async_tool_fn(self, tmp_path):
        """Async tool functions are awaited directly."""
        _setup_agent(tmp_path, "test-bot")

        async def my_async_tool():
            await asyncio.sleep(0.001)
            return "async result"

        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        result = await executor.execute(
            action="read",
            target="customers",
            async_tool_fn=my_async_tool,
        )
        assert result.allowed
        assert result.data == "async result"

    @pytest.mark.asyncio
    async def test_concurrent_execution(self, tmp_path):
        """Multiple agents can evaluate concurrently."""
        executors = []
        for i in range(5):
            name = f"agent-{i}"
            _setup_agent(tmp_path, name)
            executors.append(
                await AsyncGovernedToolExecutor.connect(
                    name, base_dir=tmp_path, test_mode=True
                )
            )

        results = await asyncio.gather(
            *[
                e.execute("read", "customers", tool_fn=lambda: "ok")
                for e in executors
            ]
        )
        assert all(r.allowed for r in results)
        assert all(r.data == "ok" for r in results)

    @pytest.mark.asyncio
    async def test_check_without_execute(self, tmp_path):
        """check() evaluates governance without running the tool."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        result = await executor.check("read", "customers")
        assert result.data is None

    @pytest.mark.asyncio
    async def test_error_both_fns_raises(self, tmp_path):
        """Providing both tool_fn and async_tool_fn raises ValueError."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )

        async def async_fn():
            return "async"

        with pytest.raises(ValueError, match="not both"):
            await executor.execute(
                action="read",
                target="customers",
                tool_fn=lambda: "sync",
                async_tool_fn=async_fn,
            )

    @pytest.mark.asyncio
    async def test_error_no_fn_raises(self, tmp_path):
        """Providing neither tool_fn nor async_tool_fn raises ValueError."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        with pytest.raises(ValueError, match="Provide either"):
            await executor.execute(action="read", target="customers")

    @pytest.mark.asyncio
    async def test_tool_exception_propagates(self, tmp_path):
        """Exceptions from tool_fn propagate to the caller."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )

        def bad_tool():
            raise RuntimeError("tool failed")

        with pytest.raises(RuntimeError, match="tool failed"):
            await executor.execute(
                action="read",
                target="customers",
                tool_fn=bad_tool,
            )

    @pytest.mark.asyncio
    async def test_async_tool_exception_propagates(self, tmp_path):
        """Exceptions from async_tool_fn propagate to the caller."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )

        async def bad_async_tool():
            raise ValueError("async tool failed")

        with pytest.raises(ValueError, match="async tool failed"):
            await executor.execute(
                action="read",
                target="customers",
                async_tool_fn=bad_async_tool,
            )


class TestAsyncAuditAndTrust:
    """Test audit records and trust evolution in async execution."""

    @pytest.mark.asyncio
    async def test_audit_records_written(self, tmp_path):
        """Async execution writes audit records."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        await executor.execute("read", "customers", tool_fn=lambda: "ok")

        store = LogStore(tmp_path, "testlog")
        records = store.query("test-bot")
        assert len(records) >= 1

    @pytest.mark.asyncio
    async def test_trust_evolves(self, tmp_path):
        """Trust score changes after async execution."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        initial = executor.trust_score

        for _ in range(10):
            await executor.execute("read", "customers", tool_fn=lambda: "ok")

        assert executor.trust_score != initial

    @pytest.mark.asyncio
    async def test_trust_score_property(self, tmp_path):
        """trust_score property returns current trust."""
        _setup_agent(tmp_path, "test-bot")
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        score = executor.trust_score
        assert 0.0 <= score <= 1.0

    @pytest.mark.asyncio
    async def test_denied_action_audit(self, tmp_path):
        """Denied actions also write audit records."""
        _setup_agent(tmp_path, "test-bot", actions=["read"])
        executor = await AsyncGovernedToolExecutor.connect(
            "test-bot", base_dir=tmp_path, test_mode=True
        )
        result = await executor.execute(
            "delete_all", "production_db", tool_fn=lambda: None
        )
        assert not result.allowed

        store = LogStore(tmp_path, "testlog")
        records = store.query("test-bot")
        assert len(records) >= 1
        assert any(r.verdict == "DENY" for r in records)
