"""Tests for the Fleet Simulator (F-23)."""

import json
import tempfile
import time
from pathlib import Path

import pytest

from nomotic.fleet_sim import (
    BEHAVIOR_PROFILES,
    DEPARTMENTS,
    FleetSimulator,
    SimulatedAgent,
    SimulationConfig,
)
from nomotic.priors import ARCHETYPE_PRIOR_MAP, PriorRegistry
from nomotic.store import MemoryCertificateStore


# ── Helpers ────────────────────────────────────────────────────────────


def _make_sim(agent_count: int = 20, departments: list[str] | None = None) -> FleetSimulator:
    """Create a small FleetSimulator for testing."""
    config = SimulationConfig(
        agent_count=agent_count,
        departments=departments or list(DEPARTMENTS.keys()),
        evaluations_per_second=1000.0,  # fast for tests
    )
    return FleetSimulator(config)


# ── Test 1: FleetSimulator instantiates with default SimulationConfig ──


def test_instantiate_with_default_config():
    config = SimulationConfig()
    sim = FleetSimulator(config)
    assert sim.config.agent_count == 100
    assert sim.agents == []
    assert sim._running is False


# ── Test 2: provision_agents creates config.agent_count agents ─────────


def test_provision_creates_correct_count(capsys):
    sim = _make_sim(agent_count=30)
    sim.provision_agents()
    assert len(sim.agents) == 30


# ── Test 3: provision distributes agents across all departments ────────


def test_provision_distributes_across_departments(capsys):
    sim = _make_sim(agent_count=30)
    sim.provision_agents()
    depts = {a.department for a in sim.agents}
    # With 30 agents across 10 departments, each should get at least 2
    assert len(depts) == 10


# ── Test 4: Each provisioned agent has a valid certificate_id ──────────


def test_agents_have_valid_certificate_id(capsys):
    sim = _make_sim(agent_count=10)
    sim.provision_agents()
    for agent in sim.agents:
        assert agent.certificate_id
        assert agent.certificate_id.startswith("nmc-")


# ── Test 5: Each agent's behavior_profile is one of BEHAVIOR_PROFILES ──


def test_agents_have_valid_behavior_profile(capsys):
    sim = _make_sim(agent_count=20)
    sim.provision_agents()
    for agent in sim.agents:
        assert agent.behavior_profile in BEHAVIOR_PROFILES


# ── Test 6: DEPARTMENTS dict contains all 10 expected department names ──


def test_departments_contains_all_ten():
    expected = {
        "CRM", "Finance", "DevOps", "Data & Analytics", "Security",
        "Human Resources", "Procurement", "Support", "Legal", "Executive",
    }
    assert set(DEPARTMENTS.keys()) == expected


# ── Test 7: All archetypes in DEPARTMENTS are valid Nomotic archetypes ──


def test_department_archetypes_are_valid():
    registry = PriorRegistry.with_defaults()
    for dept_name, dept_def in DEPARTMENTS.items():
        for archetype in dept_def["archetypes"]:
            # Archetype must be resolvable via PriorRegistry
            # (either a direct prior name or a mapped alias)
            prior = registry.get(archetype)
            assert prior is not None or archetype in ARCHETYPE_PRIOR_MAP, (
                f"Unknown archetype '{archetype}' in department '{dept_name}'"
            )


# ── Test 8: SimulationConfig agent_count defaults to 100 ──────────────


def test_simulation_config_defaults():
    config = SimulationConfig()
    assert config.agent_count == 100
    assert config.evaluations_per_second == 10.0
    assert config.org_id == "simulation"
    assert config.zone == "sim/production"


# ── Test 9: stats_snapshot returns dict with required keys ─────────────


def test_stats_snapshot_has_required_keys(capsys):
    sim = _make_sim(agent_count=10)
    sim.provision_agents()
    snap = sim.stats_snapshot()

    required = {
        "total_evaluations", "total_refused", "denial_rate_pct",
        "department_breakdown", "total_agents", "total_governed",
        "total_escalated", "governance_rate_pct", "scenario",
        "top_denied_tools", "profile_distribution", "elapsed_seconds",
    }
    assert required.issubset(set(snap.keys()))


# ── Test 10: denial_rate_pct is float between 0 and 100 ───────────────


def test_denial_rate_pct_is_bounded(capsys):
    sim = _make_sim(agent_count=10)
    sim.provision_agents()
    snap = sim.stats_snapshot()
    assert isinstance(snap["denial_rate_pct"], float)
    assert 0.0 <= snap["denial_rate_pct"] <= 100.0


# ── Test 11: _top_denied_tools returns correct structure ───────────────


def test_top_denied_tools_structure(capsys):
    sim = _make_sim(agent_count=10)
    sim.provision_agents()
    # Give some agents denials to generate data
    for a in sim.agents[:3]:
        a.denials = 5
    tools = sim._top_denied_tools()
    assert isinstance(tools, list)
    for item in tools:
        assert "tool" in item
        assert "count" in item


# ── Test 12: _profile_distribution returns dict with multiple profiles ──


def test_profile_distribution(capsys):
    sim = _make_sim(agent_count=50)
    sim.provision_agents()
    dist = sim._profile_distribution()
    assert isinstance(dist, dict)
    # With 50 agents, we should see at least 2 distinct profiles
    assert len(dist) >= 2


# ── Test 13: FleetSimulator uses isolated MemoryCertificateStore ───────


def test_uses_isolated_memory_store():
    sim = _make_sim(agent_count=5)
    assert isinstance(sim._cert_store, MemoryCertificateStore)


# ── Test 14: FleetSimulator uses isolated stores (not production) ──────


def test_stores_are_isolated():
    sim1 = _make_sim(agent_count=5)
    sim2 = _make_sim(agent_count=5)
    # Each simulator has its own separate store
    assert sim1._cert_store is not sim2._cert_store


# ── Test 15: stop() clears STATE_PATH if it exists ────────────────────


def test_stop_clears_state_path(capsys, monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        state_path = Path(td) / "fleet-sim-state.json"
        monkeypatch.setattr(FleetSimulator, "STATE_PATH", state_path)
        sim = _make_sim(agent_count=5)
        sim.provision_agents()
        sim.start()
        assert FleetSimulator.STATE_PATH.exists()
        sim.stop()
        assert not FleetSimulator.STATE_PATH.exists()


# ── Test 16: _write_state creates STATE_PATH with valid JSON ──────────


def test_write_state_creates_valid_json(capsys, monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        state_path = Path(td) / "fleet-sim-state.json"
        monkeypatch.setattr(FleetSimulator, "STATE_PATH", state_path)
        sim = _make_sim(agent_count=5)
        sim.provision_agents()
        sim._started_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        sim._running = True
        sim._write_state()

        assert FleetSimulator.STATE_PATH.exists()
        data = json.loads(FleetSimulator.STATE_PATH.read_text())
        assert isinstance(data, dict)


# ── Test 17: STATE_PATH JSON contains agent_count and config fields ────


def test_state_json_structure(capsys, monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        state_path = Path(td) / "fleet-sim-state.json"
        monkeypatch.setattr(FleetSimulator, "STATE_PATH", state_path)
        sim = _make_sim(agent_count=15)
        sim.provision_agents()
        sim._started_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        sim._running = True
        sim._write_state()

        data = json.loads(FleetSimulator.STATE_PATH.read_text())
        assert data["agent_count"] == 15
        assert "config" in data
        assert data["config"]["agent_count"] == 15


# ── Test 18: 100-agent provisioning completes in < 10 seconds ──────────


def test_provisioning_performance(capsys):
    sim = _make_sim(agent_count=100)
    t0 = time.time()
    sim.provision_agents()
    elapsed = time.time() - t0
    assert elapsed < 10.0, f"Provisioning 100 agents took {elapsed:.2f}s (> 10s)"


# ── Test 19: "rogue" profile has higher risky_multiplier than "compliant"


def test_rogue_has_higher_risky_multiplier():
    assert BEHAVIOR_PROFILES["rogue"]["risky_multiplier"] > BEHAVIOR_PROFILES["compliant"]["risky_multiplier"]


# ── Test 20: department_breakdown contains entries for departments ──────


def test_department_breakdown_coverage(capsys):
    sim = _make_sim(agent_count=20)
    sim.provision_agents()
    snap = sim.stats_snapshot()
    breakdown = snap["department_breakdown"]
    # Every department with agents should appear
    agent_depts = {a.department for a in sim.agents}
    for dept in agent_depts:
        assert dept in breakdown


# ── Test 21: start() + stop() does not raise exceptions ───────────────


def test_start_stop_no_exceptions(capsys, monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        state_path = Path(td) / "fleet-sim-state.json"
        monkeypatch.setattr(FleetSimulator, "STATE_PATH", state_path)
        sim = _make_sim(agent_count=10)
        sim.provision_agents()
        sim.start()
        time.sleep(0.1)
        sim.stop()
        # If we get here without exception, test passes


# ── Test 22: agents count matches config after provisioning ────────────


def test_agent_count_matches_config(capsys):
    for n in [10, 25, 50]:
        sim = _make_sim(agent_count=n)
        sim.provision_agents()
        assert len(sim.agents) == n, f"Expected {n} agents, got {len(sim.agents)}"


# ── Test 23: SimulatedAgent.to_dict() returns complete dict ────────────


def test_simulated_agent_to_dict():
    agent = SimulatedAgent(
        agent_id="test-001",
        department="CRM",
        archetype="customer-experience",
        behavior_profile="compliant",
        certificate_id="nmc-test",
        initial_trust=0.8,
    )
    d = agent.to_dict()
    assert d["agent_id"] == "test-001"
    assert d["department"] == "CRM"
    assert d["evaluations"] == 0
    assert d["denials"] == 0


# ── Test 24: get_runtime() returns a GovernanceRuntime ─────────────────


def test_get_runtime():
    from nomotic.runtime import GovernanceRuntime
    sim = _make_sim(agent_count=5)
    rt = sim.get_runtime()
    assert isinstance(rt, GovernanceRuntime)


# ── Test 25: get_cert_store() returns isolated MemoryCertificateStore ──


def test_get_cert_store():
    sim = _make_sim(agent_count=5)
    store = sim.get_cert_store()
    assert isinstance(store, MemoryCertificateStore)


# ── Test 26: get_ca() returns CertificateAuthority ─────────────────────


def test_get_ca():
    from nomotic.authority import CertificateAuthority
    sim = _make_sim(agent_count=5)
    ca = sim.get_ca()
    assert isinstance(ca, CertificateAuthority)


# ── Test 27: Evaluations run and update agent counters ─────────────────


def test_evaluations_update_counters(capsys, monkeypatch):
    with tempfile.TemporaryDirectory() as td:
        state_path = Path(td) / "fleet-sim-state.json"
        monkeypatch.setattr(FleetSimulator, "STATE_PATH", state_path)
        sim = _make_sim(agent_count=5)
        sim.provision_agents()
        sim.config.evaluations_per_second = 1000.0
        sim.start()
        time.sleep(0.5)
        sim.stop()
        snap = sim.stats_snapshot()
        assert snap["total_evaluations"] > 0


# ── Test 28: Subset of departments can be selected ─────────────────────


def test_subset_departments(capsys):
    sim = _make_sim(agent_count=10, departments=["CRM", "Finance"])
    sim.provision_agents()
    depts = {a.department for a in sim.agents}
    assert depts == {"CRM", "Finance"}
    assert len(sim.agents) == 10


# ── Test 29: Each department action list has exactly 5 actions ─────────


def test_department_actions_count():
    for dept_name, dept_def in DEPARTMENTS.items():
        assert len(dept_def["actions"]) == 5, (
            f"Department '{dept_name}' has {len(dept_def['actions'])} actions, expected 5"
        )


# ── Test 30: Action weights per department sum to approximately 1.0 ────


def test_department_action_weights_sum():
    for dept_name, dept_def in DEPARTMENTS.items():
        total = sum(w for _, _, w in dept_def["actions"])
        assert abs(total - 1.0) < 0.01, (
            f"Department '{dept_name}' action weights sum to {total}, expected ~1.0"
        )
