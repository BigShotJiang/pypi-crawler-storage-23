"""Tests for delegation depth limits enforcement."""

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.certificate import CertStatus
from nomotic.delegation import (
    DEFAULT_DELEGATION_DEPTH_LIMITS,
    DelegationDepthConfig,
    DelegationDepthError,
    DelegationTracker,
)
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore


# ── Helpers ────────────────────────────────────────────────────────────


def _ca_with_agents(
    *names: str,
    archetype: str = "specialist",
) -> tuple[CertificateAuthority, MemoryCertificateStore]:
    """Create a CA and issue certificates with the given archetype."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)
    for name in names:
        ca.issue(name, archetype, "acme", "global/us")
    return ca, store


# ── TestDelegationDepthConfig ──────────────────────────────────────────


class TestDelegationDepthConfig:
    def test_default_limits_match_constants(self):
        config = DelegationDepthConfig()
        assert config.max_depths == DEFAULT_DELEGATION_DEPTH_LIMITS

    def test_get_limit_decision_maker(self):
        config = DelegationDepthConfig()
        assert config.get_limit("decision_maker") == 3

    def test_get_limit_specialist(self):
        config = DelegationDepthConfig()
        assert config.get_limit("specialist") == 2

    def test_get_limit_gatekeeper(self):
        config = DelegationDepthConfig()
        assert config.get_limit("gatekeeper") == 1

    def test_get_limit_observer(self):
        config = DelegationDepthConfig()
        assert config.get_limit("observer") == 0

    def test_get_limit_executor(self):
        config = DelegationDepthConfig()
        assert config.get_limit("executor") == 2

    def test_get_limit_unknown_falls_back_to_star(self):
        config = DelegationDepthConfig()
        assert config.get_limit("unknown_archetype") == 3

    def test_custom_depths_override_defaults(self):
        custom = {"specialist": 5, "*": 10}
        config = DelegationDepthConfig(max_depths=custom)
        assert config.get_limit("specialist") == 5
        assert config.get_limit("decision_maker") == 10  # falls back to *

    def test_enforce_at_delegation_default_true(self):
        config = DelegationDepthConfig()
        assert config.enforce_at_delegation is True

    def test_enforce_at_evaluation_default_true(self):
        config = DelegationDepthConfig()
        assert config.enforce_at_evaluation is True


# ── TestDelegationDepthError ───────────────────────────────────────────


class TestDelegationDepthError:
    def test_constructor_fields_accessible(self):
        err = DelegationDepthError(
            agent_id="agent-a",
            archetype="specialist",
            current_depth=2,
            attempted_depth=3,
            limit=2,
            chain=["root", "agent-a", "agent-b"],
        )
        assert err.agent_id == "agent-a"
        assert err.archetype == "specialist"
        assert err.current_depth == 2
        assert err.attempted_depth == 3
        assert err.limit == 2
        assert err.chain == ["root", "agent-a", "agent-b"]

    def test_error_message_contains_agent_id(self):
        err = DelegationDepthError("agent-x", "specialist", 2, 3, 2, ["a", "agent-x", "b"])
        assert "agent-x" in str(err)

    def test_error_message_contains_attempted_depth(self):
        err = DelegationDepthError("agent-x", "specialist", 2, 3, 2, ["a", "b"])
        assert "attempted depth 3" in str(err)

    def test_error_message_contains_limit(self):
        err = DelegationDepthError("agent-x", "specialist", 2, 3, 2, ["a", "b"])
        assert "limit 2" in str(err)

    def test_error_message_contains_chain(self):
        err = DelegationDepthError("agent-x", "specialist", 2, 3, 2, ["a", "b", "c"])
        assert "a -> b -> c" in str(err)

    def test_is_exception_subclass(self):
        err = DelegationDepthError("a", "specialist", 0, 1, 0, ["a", "b"])
        assert isinstance(err, Exception)


# ── TestDelegationTrackerDepthEnforcement ──────────────────────────────


class TestDelegationTrackerDepthEnforcement:
    def test_first_delegation_succeeds_within_limit(self):
        """A→B (depth 0→1) within specialist limit of 2."""
        _, store = _ca_with_agents("A", "B", archetype="specialist")
        tracker = DelegationTracker(cert_store=store)
        record = tracker.delegate("A", "B", {"read"}, {"*"})
        assert record.from_agent == "A"
        assert record.to_agent == "B"

    def test_second_hop_succeeds_within_limit(self):
        """A→B→C (depth 1→2) within specialist limit of 2."""
        _, store = _ca_with_agents("A", "B", "C", archetype="specialist")
        tracker = DelegationTracker(cert_store=store)
        tracker.delegate("A", "B", {"read"}, {"*"})
        record = tracker.delegate("B", "C", {"read"}, {"*"})
        assert record.from_agent == "B"
        assert record.to_agent == "C"

    def test_third_hop_raises_depth_error(self):
        """A→B→C→D (depth 2→3) exceeds specialist limit of 2."""
        _, store = _ca_with_agents("A", "B", "C", "D", archetype="specialist")
        tracker = DelegationTracker(cert_store=store)
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("C", "D", {"read"}, {"*"})
        err = exc_info.value
        assert err.limit == 2
        assert err.attempted_depth == 3
        assert err.archetype == "specialist"

    def test_depth_error_chain_contains_all_agents(self):
        """Chain in error should contain A, B, C, D."""
        _, store = _ca_with_agents("A", "B", "C", "D", archetype="specialist")
        tracker = DelegationTracker(cert_store=store)
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("C", "D", {"read"}, {"*"})
        chain = exc_info.value.chain
        assert "A" in chain
        assert "B" in chain
        assert "C" in chain
        assert "D" in chain

    def test_observer_cannot_delegate_at_all(self):
        """Observer (limit=0): A→B raises immediately."""
        _, store = _ca_with_agents("A", "B", archetype="observer")
        tracker = DelegationTracker(cert_store=store)
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("A", "B", {"read"}, {"*"})
        assert exc_info.value.limit == 0
        assert exc_info.value.attempted_depth == 1

    def test_decision_maker_allows_deeper_chains(self):
        """decision_maker has limit 3: A→B→C→D should succeed."""
        _, store = _ca_with_agents("A", "B", "C", "D", archetype="decision_maker")
        tracker = DelegationTracker(cert_store=store)
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        record = tracker.delegate("C", "D", {"read"}, {"*"})
        assert record.to_agent == "D"

    def test_decision_maker_blocked_at_depth_4(self):
        """decision_maker limit is 3: A→B→C→D→E should fail."""
        _, store = _ca_with_agents("A", "B", "C", "D", "E", archetype="decision_maker")
        tracker = DelegationTracker(cert_store=store)
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        tracker.delegate("C", "D", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("D", "E", {"read"}, {"*"})
        assert exc_info.value.limit == 3

    def test_enforce_at_delegation_false_disables_enforcement(self):
        """When enforce_at_delegation=False, no error is raised."""
        _, store = _ca_with_agents("A", "B", archetype="observer")
        config = DelegationDepthConfig(enforce_at_delegation=False)
        tracker = DelegationTracker(cert_store=store, depth_config=config)
        # Observer would normally be blocked, but enforcement is off
        record = tracker.delegate("A", "B", {"read"}, {"*"})
        assert record.to_agent == "B"

    def test_get_depth_root_agent(self):
        tracker = DelegationTracker()
        assert tracker.get_depth("agent-a") == 0

    def test_get_depth_after_single_delegation(self):
        tracker = DelegationTracker()
        tracker.delegate("A", "B", {"read"}, {"*"})
        assert tracker.get_depth("A") == 0
        assert tracker.get_depth("B") == 1

    def test_get_depth_multi_hop(self):
        tracker = DelegationTracker()
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        tracker.delegate("C", "D", {"read"}, {"*"})
        assert tracker.get_depth("A") == 0
        assert tracker.get_depth("B") == 1
        assert tracker.get_depth("C") == 2
        assert tracker.get_depth("D") == 3

    def test_no_cert_store_uses_fallback_archetype(self):
        """Without cert store, fallback archetype '*' is used (limit=3)."""
        config = DelegationDepthConfig()
        tracker = DelegationTracker(cert_store=None, depth_config=config)
        tracker.delegate("A", "B", {"read"}, {"*"})
        tracker.delegate("B", "C", {"read"}, {"*"})
        tracker.delegate("C", "D", {"read"}, {"*"})
        # Depth 3 is the limit for '*', so A→B→C→D→E should fail
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("D", "E", {"read"}, {"*"})
        assert exc_info.value.limit == 3

    def test_custom_depth_config_enforced(self):
        """Custom config with specialist limit=1 should block at depth 2."""
        _, store = _ca_with_agents("A", "B", "C", archetype="specialist")
        config = DelegationDepthConfig(max_depths={"specialist": 1, "*": 3})
        tracker = DelegationTracker(cert_store=store, depth_config=config)
        tracker.delegate("A", "B", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError) as exc_info:
            tracker.delegate("B", "C", {"read"}, {"*"})
        assert exc_info.value.limit == 1


# ── TestDelegationDepthRuntime ────────────────────────────────────────


class TestDelegationDepthRuntime:
    def test_runtime_delegate_propagates_depth_error(self):
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        # Default config with no cert store → fallback '*' limit=3
        runtime.delegate("A", "B", {"read"}, {"*"})
        runtime.delegate("B", "C", {"read"}, {"*"})
        runtime.delegate("C", "D", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError):
            runtime.delegate("D", "E", {"read"}, {"*"})

    def test_runtime_configure_delegation_depth_updates_config(self):
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        # Initially, observer limit is 0 via fallback '*'=3 (no cert store)
        # Set a custom config that makes '*' limit=1
        new_config = DelegationDepthConfig(max_depths={"*": 1})
        runtime.configure_delegation_depth(new_config)
        runtime.delegate("A", "B", {"read"}, {"*"})
        with pytest.raises(DelegationDepthError):
            runtime.delegate("B", "C", {"read"}, {"*"})

    def test_runtime_configure_depth_disables_enforcement(self):
        from nomotic.runtime import GovernanceRuntime

        runtime = GovernanceRuntime()
        config = DelegationDepthConfig(enforce_at_delegation=False)
        runtime.configure_delegation_depth(config)
        # Should not raise even beyond normal limits
        runtime.delegate("A", "B", {"read"}, {"*"})
        runtime.delegate("B", "C", {"read"}, {"*"})
        runtime.delegate("C", "D", {"read"}, {"*"})
        record = runtime.delegate("D", "E", {"read"}, {"*"})
        assert record.to_agent == "E"


# ── TestDelegationDepthDoctor ──────────────────────────────────────────


class TestDelegationDepthDoctor:
    def test_agent_at_limit_no_warning(self, tmp_path):
        """Agent at exactly the limit should not trigger a warning."""
        from nomotic.doctor import DoctorReport, _check_delegation_depths

        report = DoctorReport()
        # No audit dir → no warnings
        _check_delegation_depths(report, tmp_path)
        depth_warnings = [
            c for c in report.checks
            if c.category == "Delegation Depths" and c.status == "warning"
        ]
        assert len(depth_warnings) == 0

    def test_doctor_check_called_in_run_doctor(self, tmp_path):
        """run_doctor should include delegation depth checks."""
        from nomotic.doctor import run_doctor

        # Create minimal directory structure
        (tmp_path / "certs").mkdir(exist_ok=True)
        report = run_doctor(tmp_path)
        # Should not crash even without audit data
        assert isinstance(report.checks, list)

    def test_doctor_warns_on_excessive_depth(self, tmp_path):
        """Agents with chain exceeding default limit should produce warning."""
        from nomotic.audit_store import LogStore
        from nomotic.runtime import GovernanceRuntime

        # Set up runtime with audit store
        runtime = GovernanceRuntime()
        audit_dir = tmp_path / "audit"
        audit_dir.mkdir(parents=True, exist_ok=True)
        store = LogStore(tmp_path, "audit")
        runtime.set_audit_store(store)

        # Disable enforcement so we can create deep chains
        config = DelegationDepthConfig(enforce_at_delegation=False)
        runtime.configure_delegation_depth(config)

        # Create a chain of depth 5 (exceeds default '*' limit of 3)
        runtime.delegate("A", "B", {"read"}, {"*"})
        runtime.delegate("B", "C", {"read"}, {"*"})
        runtime.delegate("C", "D", {"read"}, {"*"})
        runtime.delegate("D", "E", {"read"}, {"*"})
        runtime.delegate("E", "F", {"read"}, {"*"})

        from nomotic.doctor import DoctorReport, _check_delegation_depths

        report = DoctorReport()
        _check_delegation_depths(report, tmp_path)
        depth_warnings = [
            c for c in report.checks
            if c.category == "Delegation Depths" and c.status == "warning"
        ]
        # At least one agent should exceed the default limit
        assert len(depth_warnings) > 0
        # Warning message should reference depth and limit
        assert any("depth" in w.message.lower() for w in depth_warnings)


# ── TestContextualModifierDepth ────────────────────────────────────────


class TestContextualModifierDepth:
    def test_depth_accessor_adds_constraint_when_exceeded(self):
        from nomotic.context_profile import ContextProfile, RelationalContext
        from nomotic.contextual_modifier import ContextualModifier
        from nomotic.types import Action, AgentContext

        modifier = ContextualModifier()
        # depth=5, archetype='specialist', limit=2
        modifier.set_depth_accessor(lambda agent_id: (5, "specialist", 2))

        action = Action(action_type="read", target="data/reports", parameters={})
        from nomotic.types import TrustProfile
        context = AgentContext(agent_id="deep-agent", trust_profile=TrustProfile(agent_id="deep-agent"))
        relational = RelationalContext(
            delegation_chain=[],
            compound_methods=[],
            shared_workflow_agents=[],
            child_agent_ids=[],
        )
        profile = ContextProfile(profile_id="test-profile", agent_id=context.agent_id, profile_type="session", relational=relational)

        result = modifier.modify(action, context, profile)
        # Should have a require_human_review constraint
        hr_constraints = [
            c for c in result.constraints
            if c.constraint_type == "require_human_review"
            and "delegation depth" in c.description.lower()
        ]
        assert len(hr_constraints) >= 1

    def test_depth_accessor_no_constraint_when_within_limit(self):
        from nomotic.context_profile import ContextProfile, RelationalContext
        from nomotic.contextual_modifier import ContextualModifier
        from nomotic.types import Action, AgentContext

        modifier = ContextualModifier()
        # depth=1, archetype='specialist', limit=2 — within limits
        modifier.set_depth_accessor(lambda agent_id: (1, "specialist", 2))

        action = Action(action_type="read", target="data/reports", parameters={})
        from nomotic.types import TrustProfile
        context = AgentContext(agent_id="normal-agent", trust_profile=TrustProfile(agent_id="normal-agent"))
        relational = RelationalContext(
            delegation_chain=[],
            compound_methods=[],
            shared_workflow_agents=[],
            child_agent_ids=[],
        )
        profile = ContextProfile(profile_id="test-profile", agent_id=context.agent_id, profile_type="session", relational=relational)

        result = modifier.modify(action, context, profile)
        hr_constraints = [
            c for c in result.constraints
            if c.constraint_type == "require_human_review"
            and "delegation depth" in c.description.lower()
        ]
        assert len(hr_constraints) == 0


# ── TestExports ────────────────────────────────────────────────────────


class TestExports:
    def test_delegation_depth_config_importable(self):
        from nomotic import DelegationDepthConfig
        assert DelegationDepthConfig is not None

    def test_delegation_depth_error_importable(self):
        from nomotic import DelegationDepthError
        assert DelegationDepthError is not None

    def test_default_limits_importable(self):
        from nomotic import DEFAULT_DELEGATION_DEPTH_LIMITS
        assert isinstance(DEFAULT_DELEGATION_DEPTH_LIMITS, dict)
        assert "specialist" in DEFAULT_DELEGATION_DEPTH_LIMITS
