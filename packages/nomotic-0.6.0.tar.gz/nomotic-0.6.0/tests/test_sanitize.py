"""Comprehensive tests for the data sanitization layer."""

import json
import string
import time

import pytest

from nomotic.sanitize import (
    SanitizationPolicy,
    Sanitizer,
    sanitize_audit_record,
    sanitize_for_export,
    sanitize_reasoning_artifact,
)
from nomotic.audit import AuditRecord, AuditTrail


# ── Helpers ───────────────────────────────────────────────────────────


def _policy(**overrides) -> SanitizationPolicy:
    """Create an enabled policy with optional overrides."""
    defaults = {"enabled": True}
    defaults.update(overrides)
    return SanitizationPolicy(**defaults)


def _make_record(
    *,
    metadata: dict | None = None,
    justification: str = "",
    action_target: str = "/api/data",
) -> AuditRecord:
    return AuditRecord(
        record_id="rec-00001",
        timestamp=time.time(),
        context_code="GOVERNANCE.ALLOW",
        severity="info",
        agent_id="agent-1",
        owner_id="owner-1",
        user_id="user-1",
        action_id="act-00001",
        action_type="read",
        action_target=action_target,
        verdict="ALLOW",
        ucs=0.85,
        tier=2,
        trust_score=0.7,
        trust_trend="stable",
        justification=justification,
        metadata=metadata or {},
    )


# ── SanitizationPolicy defaults ──────────────────────────────────────


class TestSanitizationPolicy:
    def test_defaults_disabled(self):
        policy = SanitizationPolicy()
        assert policy.enabled is False

    def test_has_default_field_patterns(self):
        policy = SanitizationPolicy()
        assert len(policy.sensitive_field_patterns) > 0
        # Should contain password and api_key patterns
        joined = " ".join(policy.sensitive_field_patterns)
        assert "password" in joined.lower()
        assert "api" in joined.lower()

    def test_has_default_value_patterns(self):
        policy = SanitizationPolicy()
        assert len(policy.sensitive_value_patterns) > 0

    def test_has_default_preserve_patterns(self):
        policy = SanitizationPolicy()
        assert len(policy.preserve_field_patterns) > 0

    def test_deterministic_default(self):
        policy = SanitizationPolicy()
        assert policy.deterministic is True


# ── Field name pattern matching ───────────────────────────────────────


class TestFieldPatternMatching:
    def test_password_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("password") is True
        assert s.is_sensitive_field("user_password") is True
        assert s.is_sensitive_field("Password") is True
        assert s.is_sensitive_field("PASSWORD") is True

    def test_api_key_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("api_key") is True
        assert s.is_sensitive_field("apikey") is True
        assert s.is_sensitive_field("api-key") is True
        assert s.is_sensitive_field("API_KEY") is True

    def test_secret_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("secret") is True
        assert s.is_sensitive_field("client_secret") is True

    def test_token_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("token") is True
        assert s.is_sensitive_field("access_token") is True
        assert s.is_sensitive_field("refresh_token") is True

    def test_credential_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("credential") is True
        assert s.is_sensitive_field("credentials") is True

    def test_ssn_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("ssn") is True
        assert s.is_sensitive_field("SSN") is True

    def test_credit_card_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("credit_card") is True
        assert s.is_sensitive_field("credit_card_number") is True

    def test_account_number_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("account_number") is True

    def test_routing_number_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("routing_number") is True

    def test_non_sensitive_field(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("username") is False
        assert s.is_sensitive_field("email") is False
        assert s.is_sensitive_field("action_type") is False
        assert s.is_sensitive_field("verdict") is False


# ── Value pattern matching ────────────────────────────────────────────


class TestValuePatternMatching:
    def test_ssn_format(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("123-45-6789") is True

    def test_credit_card_format(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("4111 1111 1111 1111") is True
        assert s.is_sensitive_value("4111-1111-1111-1111") is True
        assert s.is_sensitive_value("4111111111111111") is True

    def test_sk_prefix(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("sk-abc123def456") is True
        assert s.is_sensitive_value("sk_live_abcdef123456") is True

    def test_ak_prefix(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("ak-myaccesskey123") is True
        assert s.is_sensitive_value("ak_test_something") is True

    def test_akia_prefix(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("AKIAIOSFODNN7EXAMPLE") is True

    def test_non_sensitive_value(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_value("hello world") is False
        assert s.is_sensitive_value("12345") is False
        assert s.is_sensitive_value("normal text") is False


# ── Shannon entropy detection ─────────────────────────────────────────


class TestShannonEntropy:
    def test_empty_string(self):
        assert Sanitizer.shannon_entropy("") == 0.0

    def test_single_char_repeated(self):
        # All same character -> zero entropy
        assert Sanitizer.shannon_entropy("aaaaaaaaaa") == 0.0

    def test_low_entropy(self):
        # Simple repeated pattern
        entropy = Sanitizer.shannon_entropy("abababababababab")
        assert entropy < 2.0

    def test_high_entropy(self):
        # Random-looking string
        high_entropy_str = "aB3$xK9!mN2@pQ7&"
        entropy = Sanitizer.shannon_entropy(high_entropy_str)
        assert entropy > 3.5

    def test_known_value(self):
        # "ab" has exactly 1.0 bit of entropy
        assert Sanitizer.shannon_entropy("ab") == pytest.approx(1.0, abs=0.01)

    def test_high_entropy_string_detected_as_sensitive(self):
        s = Sanitizer(_policy())
        # A long random-looking string should be flagged
        high_entropy = "xK9mN2pQ7aB3jR5tW8yU0eH4gI6fL1"
        assert len(high_entropy) >= 16
        assert Sanitizer.shannon_entropy(high_entropy) >= 4.5
        assert s.is_sensitive_value(high_entropy) is True

    def test_low_entropy_long_string_not_detected(self):
        s = Sanitizer(_policy())
        # Repetitive long string — low entropy
        low_entropy = "abcabcabcabcabcabc"
        assert len(low_entropy) >= 16
        assert Sanitizer.shannon_entropy(low_entropy) < 4.5
        assert s.is_sensitive_value(low_entropy) is False

    def test_short_string_skips_entropy_check(self):
        s = Sanitizer(_policy())
        # Short high-entropy string should NOT be flagged via entropy
        # (below entropy_min_length)
        short = "xK9!mN2@"
        assert len(short) < 16
        # Only flagged if it matches a value pattern
        assert s.is_sensitive_value(short) is False


# ── Preserve-field patterns ───────────────────────────────────────────


class TestPreserveFieldPatterns:
    def test_record_hash_preserved(self):
        s = Sanitizer(_policy())
        assert s.is_sensitive_field("record_hash") is False
        assert s._is_preserved_field("record_hash") is True

    def test_previous_hash_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("previous_hash") is True

    def test_agent_id_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("agent_id") is True
        assert s.is_sensitive_field("agent_id") is False

    def test_action_id_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("action_id") is True

    def test_certificate_id_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("certificate_id") is True

    def test_hash_suffix_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("artifact_hash") is True
        assert s._is_preserved_field("some_hash") is True

    def test_digest_suffix_preserved(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("sha256_digest") is True

    def test_non_preserved_field(self):
        s = Sanitizer(_policy())
        assert s._is_preserved_field("password") is False
        assert s._is_preserved_field("api_key") is False


# ── Deep dict walking ─────────────────────────────────────────────────


class TestDictSanitization:
    def test_simple_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"username": "alice", "password": "s3cret"}
        result = s.sanitize_dict(data)
        assert result["username"] == "alice"
        assert "REDACTED" in result["password"]
        assert result["password"] != "s3cret"

    def test_nested_dict(self):
        s = Sanitizer(_policy())
        data = {
            "user": {
                "name": "bob",
                "credentials": {
                    "api_key": "sk-live-123456",
                    "enabled": True,
                },
            },
        }
        result = s.sanitize_dict(data)
        assert result["user"]["name"] == "bob"
        assert "REDACTED" in result["user"]["credentials"]

    def test_list_of_dicts(self):
        s = Sanitizer(_policy())
        data = {
            "users": [
                {"name": "alice", "password": "pass1"},
                {"name": "bob", "password": "pass2"},
            ]
        }
        result = s.sanitize_dict(data)
        assert result["users"][0]["name"] == "alice"
        assert "REDACTED" in result["users"][0]["password"]
        assert "REDACTED" in result["users"][1]["password"]

    def test_sensitive_value_in_non_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"description": "User SSN is 123-45-6789"}
        result = s.sanitize_dict(data)
        # The field name is not sensitive, but the value contains an SSN pattern
        # sanitize_dict checks values for patterns too
        assert "123-45-6789" not in result["description"]

    def test_preserves_non_sensitive_data(self):
        s = Sanitizer(_policy())
        data = {
            "agent_id": "agent-1",
            "action_type": "read",
            "verdict": "ALLOW",
            "ucs": 0.85,
            "record_hash": "abc123def456",
        }
        result = s.sanitize_dict(data)
        assert result["agent_id"] == "agent-1"
        assert result["action_type"] == "read"
        assert result["verdict"] == "ALLOW"
        assert result["ucs"] == 0.85
        assert result["record_hash"] == "abc123def456"

    def test_numeric_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"account_number": 12345678}
        result = s.sanitize_dict(data)
        assert "REDACTED" in result["account_number"]

    def test_none_value_in_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"password": None}
        result = s.sanitize_dict(data)
        # None is left as-is (no string to redact)
        assert result["password"] is None

    def test_boolean_value_in_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"has_password": True}
        result = s.sanitize_dict(data)
        # "has_password" matches "password" pattern
        # But booleans are left as-is
        assert result["has_password"] is True

    def test_empty_dict(self):
        s = Sanitizer(_policy())
        result = s.sanitize_dict({})
        assert result == {}

    def test_original_dict_not_mutated(self):
        s = Sanitizer(_policy())
        original = {"password": "secret123", "name": "test"}
        result = s.sanitize_dict(original)
        assert original["password"] == "secret123"
        assert "REDACTED" in result["password"]

    def test_deeply_nested_lists(self):
        s = Sanitizer(_policy())
        data = {
            "levels": [
                [{"password": "nested_deep"}]
            ]
        }
        result = s.sanitize_dict(data)
        assert "REDACTED" in result["levels"][0][0]["password"]


# ── String sanitization ───────────────────────────────────────────────


class TestStringSanitization:
    def test_ssn_in_text(self):
        s = Sanitizer(_policy())
        text = "The user's SSN is 123-45-6789 and they live in NYC."
        result = s.sanitize_string(text)
        assert "123-45-6789" not in result
        assert "REDACTED" in result
        assert "NYC" in result

    def test_credit_card_in_text(self):
        s = Sanitizer(_policy())
        text = "Charged card 4111-1111-1111-1111 for $100."
        result = s.sanitize_string(text)
        assert "4111-1111-1111-1111" not in result
        assert "REDACTED" in result

    def test_api_key_in_text(self):
        s = Sanitizer(_policy())
        text = "Using key sk-abc123def456 for auth."
        result = s.sanitize_string(text)
        assert "sk-abc123def456" not in result

    def test_no_sensitive_data(self):
        s = Sanitizer(_policy())
        text = "Normal governance decision with no sensitive info."
        result = s.sanitize_string(text)
        assert result == text

    def test_empty_string(self):
        s = Sanitizer(_policy())
        assert s.sanitize_string("") == ""

    def test_multiple_sensitive_values(self):
        s = Sanitizer(_policy())
        text = "SSN 123-45-6789 and card 4111 1111 1111 1111"
        result = s.sanitize_string(text)
        assert "123-45-6789" not in result
        assert "4111 1111 1111 1111" not in result


# ── Deterministic redaction ───────────────────────────────────────────


class TestDeterministicRedaction:
    def test_same_input_same_output(self):
        s = Sanitizer(_policy(deterministic=True))
        r1 = s.redact("my-secret-key")
        r2 = s.redact("my-secret-key")
        assert r1 == r2

    def test_different_input_different_output(self):
        s = Sanitizer(_policy(deterministic=True))
        r1 = s.redact("secret-a")
        r2 = s.redact("secret-b")
        assert r1 != r2

    def test_format_with_hash(self):
        s = Sanitizer(_policy(deterministic=True))
        result = s.redact("my-secret")
        assert result.startswith("[REDACTED:")
        assert result.endswith("]")
        # 6 hex chars between colon and bracket
        inner = result[len("[REDACTED:"):-1]
        assert len(inner) == 6
        assert all(c in "0123456789abcdef" for c in inner)

    def test_same_key_produces_consistent_results(self):
        key = b"fixed-key-for-testing"
        s1 = Sanitizer(_policy(deterministic=True, hmac_key=key))
        s2 = Sanitizer(_policy(deterministic=True, hmac_key=key))
        assert s1.redact("test-value") == s2.redact("test-value")

    def test_different_keys_produce_different_results(self):
        s1 = Sanitizer(_policy(deterministic=True, hmac_key=b"key-1"))
        s2 = Sanitizer(_policy(deterministic=True, hmac_key=b"key-2"))
        assert s1.redact("test-value") != s2.redact("test-value")


# ── Non-deterministic redaction ───────────────────────────────────────


class TestNonDeterministicRedaction:
    def test_always_returns_placeholder(self):
        s = Sanitizer(_policy(deterministic=False))
        r1 = s.redact("secret-a")
        r2 = s.redact("secret-b")
        assert r1 == "[REDACTED]"
        assert r2 == "[REDACTED]"

    def test_same_input_same_placeholder(self):
        s = Sanitizer(_policy(deterministic=False))
        r1 = s.redact("my-secret")
        r2 = s.redact("my-secret")
        assert r1 == r2 == "[REDACTED]"

    def test_custom_placeholder(self):
        s = Sanitizer(_policy(deterministic=False, redaction_placeholder="***"))
        assert s.redact("secret") == "***"


# ── Audit record sanitization end-to-end ──────────────────────────────


class TestAuditRecordSanitization:
    def test_metadata_sanitized(self):
        policy = _policy()
        record = _make_record(
            metadata={
                "session_id": "sess-123",
                "parameters": {
                    "api_key": "sk-live-abc123",
                    "amount": 100,
                },
            },
        )
        sanitize_audit_record(record, policy)
        assert "REDACTED" in record.metadata["parameters"]["api_key"]
        assert record.metadata["session_id"] == "sess-123"
        assert record.metadata["parameters"]["amount"] == 100

    def test_justification_sanitized(self):
        policy = _policy()
        record = _make_record(
            justification="User with SSN 123-45-6789 requested access.",
        )
        sanitize_audit_record(record, policy)
        assert "123-45-6789" not in record.justification
        assert "REDACTED" in record.justification

    def test_action_target_sensitive_value(self):
        policy = _policy()
        record = _make_record(action_target="sk-live-mykey123456")
        sanitize_audit_record(record, policy)
        assert "REDACTED" in record.action_target

    def test_action_target_non_sensitive(self):
        policy = _policy()
        record = _make_record(action_target="/api/users/123")
        sanitize_audit_record(record, policy)
        assert record.action_target == "/api/users/123"

    def test_empty_metadata(self):
        policy = _policy()
        record = _make_record(metadata={})
        sanitize_audit_record(record, policy)
        assert record.metadata == {}

    def test_preserves_record_id(self):
        policy = _policy()
        record = _make_record()
        original_id = record.record_id
        sanitize_audit_record(record, policy)
        assert record.record_id == original_id


# ── Export sanitization ───────────────────────────────────────────────


class TestExportSanitization:
    def test_dict_export(self):
        policy = _policy()
        data = {"password": "s3cret", "name": "test"}
        result = sanitize_for_export(data, policy)
        assert isinstance(result, dict)
        assert "REDACTED" in result["password"]
        assert result["name"] == "test"

    def test_list_export(self):
        policy = _policy()
        data = [
            {"password": "pass1", "name": "alice"},
            {"password": "pass2", "name": "bob"},
        ]
        result = sanitize_for_export(data, policy)
        assert isinstance(result, list)
        assert len(result) == 2
        assert "REDACTED" in result[0]["password"]
        assert "REDACTED" in result[1]["password"]

    def test_string_export(self):
        policy = _policy()
        data = "SSN is 123-45-6789"
        result = sanitize_for_export(data, policy)
        assert isinstance(result, str)
        assert "123-45-6789" not in result

    def test_list_of_strings(self):
        policy = _policy()
        data = ["normal text", "SSN 123-45-6789"]
        result = sanitize_for_export(data, policy)
        assert result[0] == "normal text"
        assert "123-45-6789" not in result[1]

    def test_list_with_non_dict_non_str(self):
        policy = _policy()
        data = [42, True, None]
        result = sanitize_for_export(data, policy)
        assert result == [42, True, None]


# ── Reasoning artifact sanitization ───────────────────────────────────


class TestReasoningArtifactSanitization:
    def test_goal_sanitized(self):
        policy = _policy()
        artifact = {
            "task": {"goal": "Process SSN 123-45-6789 for user"},
            "reasoning": {"factors": [], "narrative": ""},
            "decision": {"intended_action": {"method": "read", "target": "x"}},
        }
        result = sanitize_reasoning_artifact(artifact, policy)
        assert "123-45-6789" not in result["task"]["goal"]

    def test_factors_sanitized(self):
        policy = _policy()
        artifact = {
            "task": {"goal": "test"},
            "reasoning": {
                "factors": [
                    {
                        "id": "f1",
                        "description": "Contains SSN 123-45-6789",
                        "assessment": "Key sk-live-abc is valid",
                        "source": "data://test",
                    },
                ],
                "narrative": "",
            },
            "decision": {"intended_action": {"method": "read", "target": "x"}},
        }
        result = sanitize_reasoning_artifact(artifact, policy)
        factor = result["reasoning"]["factors"][0]
        assert "123-45-6789" not in factor["description"]
        assert "sk-live-abc" not in factor["assessment"]

    def test_narrative_sanitized(self):
        policy = _policy()
        artifact = {
            "task": {"goal": "test"},
            "reasoning": {
                "factors": [],
                "narrative": "User card 4111-1111-1111-1111 was charged.",
            },
            "decision": {"intended_action": {"method": "read", "target": "x"}},
        }
        result = sanitize_reasoning_artifact(artifact, policy)
        assert "4111-1111-1111-1111" not in result["reasoning"]["narrative"]

    def test_decision_parameters_sanitized(self):
        policy = _policy()
        artifact = {
            "task": {"goal": "test"},
            "reasoning": {"factors": [], "narrative": ""},
            "decision": {
                "intended_action": {
                    "method": "write",
                    "target": "db/users",
                    "parameters": {
                        "api_key": "sk-live-123",
                        "amount": 100,
                    },
                },
            },
        }
        result = sanitize_reasoning_artifact(artifact, policy)
        params = result["decision"]["intended_action"]["parameters"]
        assert "REDACTED" in params["api_key"]
        assert params["amount"] == 100

    def test_original_not_mutated(self):
        policy = _policy()
        original = {
            "task": {"goal": "SSN 123-45-6789"},
            "reasoning": {"factors": [], "narrative": ""},
            "decision": {"intended_action": {"method": "read", "target": "x"}},
        }
        sanitize_reasoning_artifact(original, policy)
        # Original should be untouched
        assert "123-45-6789" in original["task"]["goal"]

    def test_missing_sections_handled(self):
        policy = _policy()
        artifact = {}
        result = sanitize_reasoning_artifact(artifact, policy)
        assert result == {}


# ── AuditTrail integration ────────────────────────────────────────────


class TestAuditTrailSanitization:
    def test_append_sanitizes_when_policy_enabled(self):
        policy = _policy()
        trail = AuditTrail(sanitization_policy=policy)
        record = _make_record(
            metadata={"password": "s3cret", "name": "test"},
        )
        trail.append(record)
        stored = trail.records[0]
        assert "REDACTED" in stored.metadata["password"]
        assert stored.metadata["name"] == "test"

    def test_append_no_sanitization_when_disabled(self):
        policy = SanitizationPolicy(enabled=False)
        trail = AuditTrail(sanitization_policy=policy)
        record = _make_record(
            metadata={"password": "s3cret"},
        )
        trail.append(record)
        stored = trail.records[0]
        assert stored.metadata["password"] == "s3cret"

    def test_append_no_sanitization_when_no_policy(self):
        trail = AuditTrail()
        record = _make_record(
            metadata={"password": "s3cret"},
        )
        trail.append(record)
        stored = trail.records[0]
        assert stored.metadata["password"] == "s3cret"

    def test_export_sanitizes(self):
        policy = _policy()
        trail = AuditTrail(sanitization_policy=policy)
        record = _make_record(
            metadata={"api_key": "sk-live-test123"},
        )
        trail.append(record)
        exported = trail.export("dicts")
        # The record was already sanitized on append, so export
        # should contain the redacted form
        meta = exported[0]["metadata"]
        assert "REDACTED" in meta["api_key"]

    def test_export_json_format_sanitized(self):
        policy = _policy()
        trail = AuditTrail(sanitization_policy=policy)
        record = _make_record(
            metadata={"password": "s3cret"},
        )
        trail.append(record)
        exported_json = trail.export("json")
        assert isinstance(exported_json, str)
        parsed = json.loads(exported_json)
        assert "REDACTED" in parsed[0]["metadata"]["password"]

    def test_hash_chain_valid_after_sanitization(self):
        """Hashes should be computed AFTER sanitization, so the chain is valid."""
        from nomotic.audit import verify_chain

        policy = _policy()
        trail = AuditTrail(sanitization_policy=policy)
        for i in range(5):
            record = _make_record(
                metadata={"password": f"secret-{i}"},
            )
            trail.append(record)

        # Get records in chronological order (oldest first)
        records = list(reversed(trail.records))
        valid, msg = verify_chain(records)
        assert valid, f"Hash chain broken: {msg}"


# ── GovernanceRuntime integration ─────────────────────────────────────


class TestRuntimeIntegration:
    def test_runtime_with_sanitization(self):
        """Create a GovernanceRuntime with sanitization enabled, evaluate
        an action with sensitive parameters, verify the audit trail is
        sanitized."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.types import Action, AgentContext, TrustProfile

        policy = _policy()
        config = RuntimeConfig(sanitization=policy)
        runtime = GovernanceRuntime(config)

        # Configure minimal scope so the action is evaluated
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("agent-1", {"read"})

        action = Action(
            agent_id="agent-1",
            action_type="read",
            target="/api/data",
            parameters={
                "query": "SELECT * FROM users",
                "api_key": "sk-live-realkey123",
            },
        )
        context = AgentContext(
            agent_id="agent-1",
            trust_profile=TrustProfile(agent_id="agent-1", overall_trust=0.8),
        )

        verdict = runtime.evaluate(action, context)
        assert verdict is not None

        # Check audit trail for sanitization
        if runtime.audit_trail is not None:
            records = runtime.audit_trail.records
            if records:
                # The audit record metadata may contain the parameters
                # indirectly through the runtime's _record_audit; the
                # sanitization policy should have been applied.
                export = runtime.audit_trail.export("dicts")
                export_str = json.dumps(export)
                # The raw API key should not appear
                assert "sk-live-realkey123" not in export_str


# ── Edge cases ────────────────────────────────────────────────────────


class TestEdgeCases:
    def test_empty_string_field_value(self):
        s = Sanitizer(_policy())
        data = {"password": ""}
        result = s.sanitize_dict(data)
        # Empty string for a sensitive field — still redact it
        assert "REDACTED" in result["password"]

    def test_none_values_passthrough(self):
        s = Sanitizer(_policy())
        data = {"name": None, "value": None}
        result = s.sanitize_dict(data)
        assert result["name"] is None
        assert result["value"] is None

    def test_numeric_values_passthrough(self):
        s = Sanitizer(_policy())
        data = {"count": 42, "rate": 3.14}
        result = s.sanitize_dict(data)
        assert result["count"] == 42
        assert result["rate"] == 3.14

    def test_boolean_values_passthrough(self):
        s = Sanitizer(_policy())
        data = {"enabled": True, "active": False}
        result = s.sanitize_dict(data)
        assert result["enabled"] is True
        assert result["active"] is False

    def test_mixed_types_in_list(self):
        s = Sanitizer(_policy())
        data = {"items": [1, "text", None, True, {"password": "x"}]}
        result = s.sanitize_dict(data)
        assert result["items"][0] == 1
        assert result["items"][1] == "text"
        assert result["items"][2] is None
        assert result["items"][3] is True
        assert "REDACTED" in result["items"][4]["password"]

    def test_very_long_string_not_sensitive(self):
        s = Sanitizer(_policy())
        # Long but low-entropy
        long_str = "a" * 1000
        assert s.is_sensitive_value(long_str) is False

    def test_custom_field_patterns(self):
        policy = _policy(
            sensitive_field_patterns=[r"(?i)bank_info"],
        )
        s = Sanitizer(policy)
        assert s.is_sensitive_field("bank_info") is True
        assert s.is_sensitive_field("password") is False  # removed from patterns

    def test_custom_preserve_patterns(self):
        policy = _policy(
            preserve_field_patterns=[r"^my_special_field$"],
        )
        s = Sanitizer(policy)
        assert s._is_preserved_field("my_special_field") is True
        # Default preserves no longer apply
        assert s._is_preserved_field("record_hash") is False

    def test_list_value_in_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"token": ["val1", "val2"]}
        result = s.sanitize_dict(data)
        assert "REDACTED" in result["token"]

    def test_dict_value_in_sensitive_field(self):
        s = Sanitizer(_policy())
        data = {"secret": {"key": "value"}}
        result = s.sanitize_dict(data)
        assert "REDACTED" in result["secret"]
