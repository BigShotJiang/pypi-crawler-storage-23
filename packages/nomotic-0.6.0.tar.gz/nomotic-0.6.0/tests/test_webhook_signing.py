"""Tests for webhook HMAC signing, delivery queue, and new event types."""

from __future__ import annotations

import hashlib
import hmac
import json
import tempfile
import time
from pathlib import Path
from unittest import TestCase
from unittest.mock import MagicMock, patch

from nomotic.webhooks import (
    WEBHOOK_EVENT_TYPES,
    WebhookConfig,
    WebhookDispatcher,
    WebhookEvent,
    _BACKOFF_SCHEDULE,
    _QueuedEvent,
    _backoff_seconds,
    _compute_signature,
)


def _make_event(
    event_type: str = "DENY",
    agent_id: str = "agent-1",
    event_id: str = "nmevt-abc123",
    payload: dict | None = None,
) -> WebhookEvent:
    return WebhookEvent(
        event_type=event_type,
        event_id=event_id,
        timestamp=1700000000.0,
        agent_id=agent_id,
        payload=payload or {"action_id": "act-1"},
    )


def _mock_response(status: int = 200) -> MagicMock:
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


# ── TestWebhookSignature ────────────────────────────────────────────


class TestWebhookSignature(TestCase):
    """Tests for _compute_signature()."""

    def test_returns_sha256_prefix(self) -> None:
        sig = _compute_signature("secret", b"body")
        self.assertTrue(sig.startswith("sha256="))

    def test_deterministic_same_input(self) -> None:
        sig1 = _compute_signature("secret", b"body")
        sig2 = _compute_signature("secret", b"body")
        self.assertEqual(sig1, sig2)

    def test_different_body_different_signature(self) -> None:
        sig1 = _compute_signature("secret", b"body1")
        sig2 = _compute_signature("secret", b"body2")
        self.assertNotEqual(sig1, sig2)

    def test_different_secret_different_signature(self) -> None:
        sig1 = _compute_signature("secret1", b"body")
        sig2 = _compute_signature("secret2", b"body")
        self.assertNotEqual(sig1, sig2)

    def test_verifiable_with_hmac_compare_digest(self) -> None:
        secret = "my-key"
        body = b'{"event":"test"}'
        sig = _compute_signature(secret, body)
        # Strip "sha256=" prefix
        hex_digest = sig[len("sha256="):]
        expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
        self.assertTrue(hmac.compare_digest(hex_digest, expected))

    def test_empty_body(self) -> None:
        sig = _compute_signature("secret", b"")
        self.assertTrue(sig.startswith("sha256="))
        self.assertGreater(len(sig), len("sha256="))


# ── TestWebhookConfigSigning ───────────────────────────────────────


class TestWebhookConfigSigning(TestCase):
    """Tests for WebhookConfig signing_secret field."""

    def test_to_dict_includes_signing_secret(self) -> None:
        config = WebhookConfig(
            url="https://example.com",
            events=["DENY"],
            signing_secret="my-secret",
        )
        d = config.to_dict()
        self.assertIn("signing_secret", d)
        self.assertEqual(d["signing_secret"], "my-secret")

    def test_to_dict_excludes_signing_secret_when_none(self) -> None:
        config = WebhookConfig(url="https://example.com", events=["DENY"])
        d = config.to_dict()
        self.assertNotIn("signing_secret", d)

    def test_from_dict_restores_signing_secret(self) -> None:
        d = {
            "url": "https://example.com",
            "events": ["DENY"],
            "signing_secret": "restored-secret",
        }
        config = WebhookConfig.from_dict(d)
        self.assertEqual(config.signing_secret, "restored-secret")

    def test_from_dict_no_signing_secret_key_gives_none(self) -> None:
        d = {"url": "https://example.com", "events": ["DENY"]}
        config = WebhookConfig.from_dict(d)
        self.assertIsNone(config.signing_secret)

    def test_roundtrip_with_secret(self) -> None:
        original = WebhookConfig(
            url="https://example.com",
            events=["DENY", "SUSPEND"],
            signing_secret="round-trip-key",
        )
        restored = WebhookConfig.from_dict(original.to_dict())
        self.assertEqual(restored.signing_secret, "round-trip-key")
        self.assertEqual(restored.url, original.url)
        self.assertEqual(restored.events, original.events)


# ── TestWebhookDeliverySigning ──────────────────────────────────────


class TestWebhookDeliverySigning(TestCase):
    """Tests for HMAC signature headers on delivery."""

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_signature_header_present_with_secret(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(
            url="https://example.com",
            events=["DENY"],
            signing_secret="test-secret",
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))

        req = mock_urlopen.call_args[0][0]
        self.assertIsNotNone(req.get_header("X-nomotic-signature"))
        self.assertTrue(req.get_header("X-nomotic-signature").startswith("sha256="))

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_signature_header_absent_without_secret(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"])
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))

        req = mock_urlopen.call_args[0][0]
        self.assertIsNone(req.get_header("X-nomotic-signature"))

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_signature_version_header_present(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(
            url="https://example.com",
            events=["DENY"],
            signing_secret="test-secret",
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))

        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_header("X-nomotic-signature-version"), "v1")

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_signature_matches_compute_signature(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        secret = "verify-me"
        hook = WebhookConfig(
            url="https://example.com",
            events=["DENY"],
            signing_secret=secret,
        )
        dispatcher = WebhookDispatcher([hook])
        event = _make_event("DENY")
        dispatcher.dispatch(event)

        req = mock_urlopen.call_args[0][0]
        body = req.data
        expected_sig = _compute_signature(secret, body)
        actual_sig = req.get_header("X-nomotic-signature")
        self.assertEqual(actual_sig, expected_sig)


# ── TestDeliveryQueue ───────────────────────────────────────────────


class TestDeliveryQueue(TestCase):
    """Tests for the delivery queue system."""

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_failed_delivery_adds_to_queue(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("Connection refused")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0,
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(dispatcher.queue_size(), 1)

    def test_queue_size_initially_zero(self) -> None:
        dispatcher = WebhookDispatcher()
        self.assertEqual(dispatcher.queue_size(), 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_queue_status_returns_serialized(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0,
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))

        status = dispatcher.queue_status()
        self.assertEqual(len(status), 1)
        self.assertEqual(status[0]["config_url"], "https://example.com")
        self.assertEqual(status[0]["event"]["event_type"], "DENY")
        self.assertGreater(status[0]["queued_at"], 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_queue_maxlen_1000(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0,
        )
        dispatcher = WebhookDispatcher([hook])
        # Override rate limiter for this test
        dispatcher._rate_limiters["https://example.com"] = MagicMock(allow=MagicMock(return_value=True))

        for i in range(1001):
            dispatcher.dispatch(_make_event("DENY", event_id=f"nmevt-{i}"))

        self.assertEqual(dispatcher.queue_size(), 1000)
        # Oldest event should have been dropped
        first = dispatcher.queue_status()[0]
        self.assertEqual(first["event"]["event_id"], "nmevt-1")

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_drain_queue_success(self, mock_urlopen: MagicMock) -> None:
        # First call fails, queueing the event
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0,
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(dispatcher.queue_size(), 1)

        # Now make delivery succeed
        mock_urlopen.side_effect = None
        mock_urlopen.return_value = _mock_response(200)
        delivered = dispatcher.drain_queue()
        self.assertEqual(delivered, 1)
        self.assertEqual(dispatcher.queue_size(), 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_drain_queue_failure_keeps_in_queue(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(
            url="https://example.com", events=["DENY"], max_retries=0,
        )
        dispatcher = WebhookDispatcher([hook])
        dispatcher.dispatch(_make_event("DENY"))
        self.assertEqual(dispatcher.queue_size(), 1)

        # Drain also fails
        delivered = dispatcher.drain_queue()
        self.assertEqual(delivered, 0)
        self.assertEqual(dispatcher.queue_size(), 1)
        # Attempt count should be incremented
        status = dispatcher.queue_status()
        self.assertEqual(status[0]["attempt_count"], 2)  # 1 initial + 1 drain

    def test_set_queue_path_persists(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            qpath = Path(td) / "webhooks" / "webhook_queue.jsonl"
            dispatcher = WebhookDispatcher()
            dispatcher.set_queue_path(qpath)

            # Manually add a queued event
            qe = _QueuedEvent(
                event=_make_event("DENY"),
                config_url="https://example.com",
                queued_at=time.time(),
                attempt_count=1,
                last_error="test error",
            )
            dispatcher._queue.append(qe)
            dispatcher._persist_queue()

            # Verify JSONL file exists
            self.assertTrue(qpath.exists())
            lines = [l for l in qpath.read_text().splitlines() if l.strip()]
            self.assertEqual(len(lines), 1)

    def test_set_queue_path_loads_existing(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            qpath = Path(td) / "webhooks" / "webhook_queue.jsonl"
            qpath.parent.mkdir(parents=True)

            # Write a queued event to the file
            qe = _QueuedEvent(
                event=_make_event("DENY"),
                config_url="https://example.com",
                queued_at=1700000000.0,
                attempt_count=2,
                last_error="timeout",
            )
            qpath.write_text(json.dumps(qe.to_dict()) + "\n")

            # Create dispatcher and load
            dispatcher = WebhookDispatcher()
            dispatcher.set_queue_path(qpath)
            self.assertEqual(dispatcher.queue_size(), 1)
            status = dispatcher.queue_status()
            self.assertEqual(status[0]["attempt_count"], 2)
            self.assertEqual(status[0]["config_url"], "https://example.com")

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_failed_delivery_appends_to_queue_file(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        with tempfile.TemporaryDirectory() as td:
            qpath = Path(td) / "webhooks" / "webhook_queue.jsonl"
            hook = WebhookConfig(
                url="https://example.com", events=["DENY"], max_retries=0,
            )
            dispatcher = WebhookDispatcher([hook])
            dispatcher.set_queue_path(qpath)
            dispatcher.dispatch(_make_event("DENY"))

            self.assertTrue(qpath.exists())
            lines = [l for l in qpath.read_text().splitlines() if l.strip()]
            self.assertEqual(len(lines), 1)


# ── TestQueuedEvent ─────────────────────────────────────────────────


class TestQueuedEvent(TestCase):
    """Tests for _QueuedEvent serialization."""

    def test_to_dict_roundtrip(self) -> None:
        event = _make_event("DENY")
        qe = _QueuedEvent(
            event=event,
            config_url="https://example.com",
            queued_at=1700000000.0,
            attempt_count=3,
            last_error="timeout",
        )
        d = qe.to_dict()
        restored = _QueuedEvent.from_dict(d)
        self.assertEqual(restored.config_url, "https://example.com")
        self.assertEqual(restored.queued_at, 1700000000.0)
        self.assertEqual(restored.attempt_count, 3)
        self.assertEqual(restored.last_error, "timeout")
        self.assertEqual(restored.event.event_type, "DENY")

    def test_from_dict_defaults(self) -> None:
        d = {
            "event": _make_event("DENY").to_dict(),
            "config_url": "https://example.com",
            "queued_at": 1700000000.0,
        }
        qe = _QueuedEvent.from_dict(d)
        self.assertEqual(qe.attempt_count, 0)
        self.assertEqual(qe.last_error, "")


# ── TestNewEventTypes ───────────────────────────────────────────────


class TestNewEventTypes(TestCase):
    """Verify new event types are in WEBHOOK_EVENT_TYPES."""

    def test_test_ping_in_event_types(self) -> None:
        self.assertIn("TEST_PING", WEBHOOK_EVENT_TYPES)

    def test_output_blocked_in_event_types(self) -> None:
        self.assertIn("OUTPUT_BLOCKED", WEBHOOK_EVENT_TYPES)

    def test_output_redacted_in_event_types(self) -> None:
        self.assertIn("OUTPUT_REDACTED", WEBHOOK_EVENT_TYPES)

    def test_output_escalated_in_event_types(self) -> None:
        self.assertIn("OUTPUT_ESCALATED", WEBHOOK_EVENT_TYPES)

    def test_drift_alert_still_present(self) -> None:
        self.assertIn("DRIFT_ALERT", WEBHOOK_EVENT_TYPES)

    def test_all_original_types_present(self) -> None:
        for et in ["DENY", "SUSPEND", "DRIFT_ALERT", "TRUST_DROP", "SEAL_EXPIRED",
                    "OVERRIDE_APPROVE", "OVERRIDE_REVOKE", "CHAIN_BREAK", "LOOP_DETECTED"]:
            self.assertIn(et, WEBHOOK_EVENT_TYPES)


# ── TestFromConfigWithSecret ────────────────────────────────────────


class TestFromConfigWithSecret(TestCase):
    """from_config() loads signing_secret from config dict."""

    def test_from_config_loads_signing_secret(self) -> None:
        config = {
            "webhooks": [
                {
                    "url": "https://example.com",
                    "events": ["DENY"],
                    "signing_secret": "config-secret",
                }
            ]
        }
        dispatcher = WebhookDispatcher.from_config(config)
        self.assertEqual(dispatcher._webhooks[0].signing_secret, "config-secret")

    def test_from_config_no_secret(self) -> None:
        config = {
            "webhooks": [
                {"url": "https://example.com", "events": ["DENY"]}
            ]
        }
        dispatcher = WebhookDispatcher.from_config(config)
        self.assertIsNone(dispatcher._webhooks[0].signing_secret)


# ── TestBackoffSchedule ────────────────────────────────────────────


class TestBackoffSchedule(TestCase):
    """Tests for _BACKOFF_SCHEDULE and _backoff_seconds()."""

    def test_backoff_seconds_attempt_0_is_1s_base(self) -> None:
        result = _backoff_seconds(0, jitter=False)
        self.assertEqual(result, 1.0)

    def test_backoff_seconds_grows_with_attempts(self) -> None:
        prev = 0.0
        for attempt in range(len(_BACKOFF_SCHEDULE)):
            val = _backoff_seconds(attempt, jitter=False)
            self.assertGreater(val, prev)
            prev = val

    def test_backoff_capped_at_60s(self) -> None:
        for attempt in [6, 7, 10, 50, 100]:
            result = _backoff_seconds(attempt, jitter=False)
            self.assertEqual(result, 60.0, f"Expected 60.0 for attempt {attempt}")

    def test_jitter_within_50_to_150_percent(self) -> None:
        # Run many samples and verify they fall within [base*0.5, base*1.5)
        for attempt in range(len(_BACKOFF_SCHEDULE)):
            base = float(_BACKOFF_SCHEDULE[attempt])
            low = base * 0.5
            high = base * 1.5
            for _ in range(100):
                val = _backoff_seconds(attempt, jitter=True)
                self.assertGreaterEqual(val, low)
                self.assertLess(val, high)


# ── TestQueuedEventBackoff ─────────────────────────────────────────


class TestQueuedEventBackoff(TestCase):
    """Tests for _QueuedEvent backoff fields."""

    def test_queued_event_default_attempt_count_zero(self) -> None:
        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
        )
        self.assertEqual(qe.attempt_count, 0)

    def test_queued_event_default_next_attempt_zero(self) -> None:
        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
        )
        self.assertEqual(qe.next_attempt_at, 0.0)

    def test_queued_event_to_dict_includes_backoff_fields(self) -> None:
        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=1700000000.0,
            attempt_count=3,
            next_attempt_at=1700000005.0,
            last_error="timeout",
        )
        d = qe.to_dict()
        self.assertEqual(d["attempt_count"], 3)
        self.assertEqual(d["next_attempt_at"], 1700000005.0)
        self.assertEqual(d["last_error"], "timeout")

    def test_queued_event_from_dict_backward_compat_missing_fields(self) -> None:
        """v0.5.0 queue files lack next_attempt_at — from_dict must handle this."""
        d = {
            "event": _make_event("DENY").to_dict(),
            "config_url": "https://example.com",
            "queued_at": 1700000000.0,
            # No attempt_count, next_attempt_at, or last_error keys
        }
        qe = _QueuedEvent.from_dict(d)
        self.assertEqual(qe.attempt_count, 0)
        self.assertEqual(qe.next_attempt_at, 0.0)
        self.assertEqual(qe.last_error, "")


# ── TestDrainWithBackoff ───────────────────────────────────────────


class TestDrainWithBackoff(TestCase):
    """Tests for drain_queue() respecting backoff windows."""

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_event_not_retried_before_backoff_window(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])

        # Manually add event with next_attempt_at far in the future
        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
            attempt_count=1,
            next_attempt_at=time.time() + 9999,
        )
        dispatcher._queue.append(qe)

        delivered = dispatcher.drain_queue()
        self.assertEqual(delivered, 0)
        # urlopen should NOT have been called — event was skipped
        mock_urlopen.assert_not_called()
        self.assertEqual(dispatcher.queue_size(), 1)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_event_retried_after_backoff_window(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])

        # Event with next_attempt_at in the past — should be retried
        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
            attempt_count=1,
            next_attempt_at=time.time() - 1,  # already past
        )
        dispatcher._queue.append(qe)

        delivered = dispatcher.drain_queue()
        self.assertEqual(delivered, 1)
        self.assertEqual(dispatcher.queue_size(), 0)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_attempt_count_incremented_on_failure(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])

        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
            attempt_count=2,
            next_attempt_at=0.0,
        )
        dispatcher._queue.append(qe)

        dispatcher.drain_queue()
        status = dispatcher.queue_status()
        self.assertEqual(status[0]["attempt_count"], 3)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_next_attempt_at_set_on_failure(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = Exception("fail")
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])

        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
            attempt_count=0,
            next_attempt_at=0.0,
        )
        dispatcher._queue.append(qe)

        now = time.time()
        dispatcher.drain_queue()
        status = dispatcher.queue_status()
        # next_attempt_at should be set to a time in the future
        self.assertGreater(status[0]["next_attempt_at"], now)

    @patch("nomotic.webhooks.urllib.request.urlopen")
    def test_successful_delivery_removes_from_queue(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response(200)
        hook = WebhookConfig(url="https://example.com", events=["DENY"], max_retries=0)
        dispatcher = WebhookDispatcher([hook])

        qe = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=time.time(),
            attempt_count=3,
            next_attempt_at=0.0,
        )
        dispatcher._queue.append(qe)

        delivered = dispatcher.drain_queue()
        self.assertEqual(delivered, 1)
        self.assertEqual(dispatcher.queue_size(), 0)


# ── TestDrainQueueStats ───────────────────────────────────────────


class TestDrainQueueStats(TestCase):
    """Tests for drain_queue_stats() method."""

    def test_stats_empty_queue(self) -> None:
        dispatcher = WebhookDispatcher()
        stats = dispatcher.drain_queue_stats()
        self.assertEqual(stats["total_queued"], 0)
        self.assertEqual(stats["due_now"], 0)
        self.assertEqual(stats["backoff_pending"], 0)
        self.assertEqual(stats["max_attempts"], 0)

    def test_stats_due_vs_pending_counts(self) -> None:
        dispatcher = WebhookDispatcher()
        now = time.time()

        # Two events due now
        for _ in range(2):
            qe = _QueuedEvent(
                event=_make_event("DENY"),
                config_url="https://example.com",
                queued_at=now,
                next_attempt_at=0.0,
            )
            dispatcher._queue.append(qe)

        # One event in backoff
        qe_pending = _QueuedEvent(
            event=_make_event("DENY"),
            config_url="https://example.com",
            queued_at=now,
            next_attempt_at=now + 9999,
            attempt_count=3,
        )
        dispatcher._queue.append(qe_pending)

        stats = dispatcher.drain_queue_stats()
        self.assertEqual(stats["total_queued"], 3)
        self.assertEqual(stats["due_now"], 2)
        self.assertEqual(stats["backoff_pending"], 1)

    def test_stats_max_attempts(self) -> None:
        dispatcher = WebhookDispatcher()
        now = time.time()

        for count in [1, 5, 3]:
            qe = _QueuedEvent(
                event=_make_event("DENY"),
                config_url="https://example.com",
                queued_at=now,
                attempt_count=count,
            )
            dispatcher._queue.append(qe)

        stats = dispatcher.drain_queue_stats()
        self.assertEqual(stats["max_attempts"], 5)
