"""Tests for cost projection and monitoring."""

import json

import pytest

from nomotic.cost import CostProfile, CostTracker


# ── CostProfile tests ───────────────────────────────────────────────────


class TestCostProfile:
    def test_record_execution_updates_totals(self):
        p = CostProfile()
        cost = p.record_execution(100.0)
        assert p.total_runs == 1
        assert p.total_execution_ms == 100.0
        assert p.average_execution_ms == 100.0
        assert p.total_estimated_cost == cost

    def test_record_execution_updates_averages(self):
        p = CostProfile()
        p.record_execution(100.0)
        p.record_execution(200.0)
        assert p.total_runs == 2
        assert p.total_execution_ms == 300.0
        assert p.average_execution_ms == 150.0

    def test_estimate_with_user_set_cost_per_run(self):
        p = CostProfile(estimated_cost_per_run=0.50)
        cost = p.record_execution(999.0)
        assert cost == 0.50
        # Duration doesn't matter when cost_per_run is set
        cost2 = p.record_execution(1.0)
        assert cost2 == 0.50

    def test_estimate_without_cost_per_run_uses_duration(self):
        p = CostProfile(cost_per_ms=0.001)
        cost = p.record_execution(100.0)
        assert cost == pytest.approx(0.1)

    def test_default_cost_per_ms(self):
        p = CostProfile()
        cost = p.record_execution(1000.0)
        # Default: $0.0001/ms => 1000ms = $0.10
        assert cost == pytest.approx(0.1)

    def test_project_daily_with_runs_today(self):
        p = CostProfile()
        p.record_execution(100.0)  # $0.01 at default rate
        p.record_execution(100.0)  # $0.01
        # avg cost = $0.01, runs_today=10 => $0.10
        daily = p.project_daily(runs_today=10)
        assert daily == pytest.approx(0.1)

    def test_project_daily_without_runs_today(self):
        p = CostProfile()
        p.record_execution(100.0)
        p.record_execution(100.0)
        # avg cost = $0.01, total_runs=2 => $0.02
        daily = p.project_daily()
        assert daily == pytest.approx(0.02)

    def test_project_daily_zero_runs(self):
        p = CostProfile()
        assert p.project_daily() == 0.0

    def test_project_monthly(self):
        p = CostProfile()
        p.record_execution(100.0)
        daily = p.project_daily()
        monthly = p.project_monthly()
        assert monthly == pytest.approx(daily * 30)

    def test_project_monthly_with_daily_projection(self):
        p = CostProfile()
        monthly = p.project_monthly(daily_projection=10.0)
        assert monthly == pytest.approx(300.0)

    def test_check_advisories_empty_when_under_budget(self):
        p = CostProfile(daily_budget_advisory=1000.0, monthly_budget_advisory=30000.0)
        p.record_execution(100.0)
        alerts = p.check_advisories()
        assert alerts == []

    def test_check_advisories_daily_exceeded(self):
        p = CostProfile(daily_budget_advisory=0.001)
        p.record_execution(100.0)  # $0.01 > $0.001
        alerts = p.check_advisories()
        assert len(alerts) >= 1
        daily_alert = [a for a in alerts if a["type"] == "daily"]
        assert len(daily_alert) == 1
        assert daily_alert[0]["threshold"] == 0.001
        assert daily_alert[0]["currency"] == "USD"

    def test_check_advisories_monthly_exceeded(self):
        p = CostProfile(monthly_budget_advisory=0.001)
        p.record_execution(100.0)  # $0.01 projected > $0.001
        alerts = p.check_advisories()
        monthly_alert = [a for a in alerts if a["type"] == "monthly"]
        assert len(monthly_alert) == 1
        assert monthly_alert[0]["threshold"] == 0.001

    def test_check_advisories_no_thresholds_set(self):
        p = CostProfile()
        p.record_execution(100.0)
        alerts = p.check_advisories()
        assert alerts == []

    def test_to_dict_from_dict_roundtrip(self):
        p = CostProfile(
            estimated_cost_per_run=0.25,
            cost_per_ms=0.0005,
            currency="EUR",
            daily_budget_advisory=50.0,
            monthly_budget_advisory=1500.0,
        )
        p.record_execution(200.0)
        p.record_execution(300.0)

        d = p.to_dict()
        p2 = CostProfile.from_dict(d)

        assert p2.estimated_cost_per_run == p.estimated_cost_per_run
        assert p2.cost_per_ms == p.cost_per_ms
        assert p2.currency == p.currency
        assert p2.total_runs == p.total_runs
        assert p2.total_estimated_cost == pytest.approx(p.total_estimated_cost)
        assert p2.total_execution_ms == pytest.approx(p.total_execution_ms)
        assert p2.average_execution_ms == pytest.approx(p.average_execution_ms)
        assert p2.daily_budget_advisory == p.daily_budget_advisory
        assert p2.monthly_budget_advisory == p.monthly_budget_advisory

    def test_to_dict_is_json_serializable(self):
        p = CostProfile()
        p.record_execution(100.0)
        d = p.to_dict()
        serialized = json.dumps(d)
        assert isinstance(serialized, str)
        assert json.loads(serialized) == d

    def test_from_dict_with_defaults(self):
        p = CostProfile.from_dict({})
        assert p.cost_per_ms == 0.0001
        assert p.currency == "USD"
        assert p.total_runs == 0
        assert p.estimated_cost_per_run is None

    def test_summary_has_all_expected_keys(self):
        p = CostProfile(daily_budget_advisory=100.0, monthly_budget_advisory=3000.0)
        p.record_execution(50.0)
        s = p.summary()
        expected_keys = {
            "total_runs",
            "average_cost_per_run",
            "average_execution_ms",
            "total_estimated_cost",
            "currency",
            "daily_projection",
            "monthly_projection",
            "daily_budget_advisory",
            "monthly_budget_advisory",
        }
        assert set(s.keys()) == expected_keys

    def test_summary_zero_runs(self):
        p = CostProfile()
        s = p.summary()
        assert s["total_runs"] == 0
        assert s["average_cost_per_run"] == 0.0
        assert s["daily_projection"] == 0.0
        assert s["monthly_projection"] == 0.0


# ── CostTracker tests ───────────────────────────────────────────────────


class TestCostTracker:
    def test_get_profile_creates_new(self, tmp_path):
        tracker = CostTracker(tmp_path)
        profile = tracker.get_profile("agent-1")
        assert isinstance(profile, CostProfile)
        assert profile.total_runs == 0

    def test_record_execution_persists_to_disk(self, tmp_path):
        tracker = CostTracker(tmp_path)
        cost = tracker.record_execution("agent-1", 100.0)
        assert cost > 0

        # Verify file was written
        cost_dir = tmp_path / "cost"
        files = list(cost_dir.glob("*.json"))
        assert len(files) == 1

        # Read it back
        data = json.loads(files[0].read_text())
        assert data["total_runs"] == 1

    def test_configure_updates_profile(self, tmp_path):
        tracker = CostTracker(tmp_path)
        tracker.configure("agent-1", daily_budget_advisory=500.0, cost_per_ms=0.001)
        profile = tracker.get_profile("agent-1")
        assert profile.daily_budget_advisory == 500.0
        assert profile.cost_per_ms == 0.001

    def test_load_from_disk_preserves_data(self, tmp_path):
        tracker1 = CostTracker(tmp_path)
        tracker1.record_execution("agent-1", 100.0)
        tracker1.record_execution("agent-1", 200.0)
        tracker1.configure("agent-1", daily_budget_advisory=50.0)

        # Create a new tracker instance (simulates restart)
        tracker2 = CostTracker(tmp_path)
        profile = tracker2.get_profile("agent-1")
        assert profile.total_runs == 2
        assert profile.total_execution_ms == pytest.approx(300.0)
        assert profile.daily_budget_advisory == 50.0

    def test_multiple_agents(self, tmp_path):
        tracker = CostTracker(tmp_path)
        tracker.record_execution("agent-a", 100.0)
        tracker.record_execution("agent-b", 200.0)

        pa = tracker.get_profile("agent-a")
        pb = tracker.get_profile("agent-b")
        assert pa.total_runs == 1
        assert pb.total_runs == 1
        assert pa.total_execution_ms == 100.0
        assert pb.total_execution_ms == 200.0

    def test_configure_ignores_unknown_fields(self, tmp_path):
        tracker = CostTracker(tmp_path)
        # Should not raise
        tracker.configure("agent-1", nonexistent_field=42)
        profile = tracker.get_profile("agent-1")
        assert not hasattr(profile, "nonexistent_field") or True

    def test_agent_path_normalizes_name(self, tmp_path):
        tracker = CostTracker(tmp_path)
        tracker.record_execution("My/Agent", 100.0)
        cost_dir = tmp_path / "cost"
        files = list(cost_dir.glob("*.json"))
        assert len(files) == 1
        # Slashes should be replaced with underscores
        assert "my_agent" in files[0].name


# ── Executor integration tests ──────────────────────────────────────────


class TestExecutorIntegration:
    def test_execution_result_has_cost_fields(self):
        from nomotic.executor import ExecutionResult

        result = ExecutionResult(
            allowed=True,
            verdict="ALLOW",
            reason="ok",
            data=None,
            ucs=0.9,
            tier=1,
            trust_before=0.5,
            trust_after=0.5,
            trust_delta=0.0,
            dimension_scores={},
            vetoed_by=[],
            action_id="test",
            duration_ms=10.0,
        )
        # Default values
        assert result.estimated_cost == 0.0
        assert result.cost_alerts == []

    def test_execution_result_with_cost(self):
        from nomotic.executor import ExecutionResult

        result = ExecutionResult(
            allowed=True,
            verdict="ALLOW",
            reason="ok",
            data=None,
            ucs=0.9,
            tier=1,
            trust_before=0.5,
            trust_after=0.5,
            trust_delta=0.0,
            dimension_scores={},
            vetoed_by=[],
            action_id="test",
            duration_ms=10.0,
            estimated_cost=0.05,
            cost_alerts=[{"type": "daily", "projected": 100.0, "threshold": 50.0, "currency": "USD"}],
        )
        assert result.estimated_cost == 0.05
        assert len(result.cost_alerts) == 1

    def test_execution_result_to_dict_includes_cost(self):
        from nomotic.executor import ExecutionResult

        result = ExecutionResult(
            allowed=True,
            verdict="ALLOW",
            reason="ok",
            data=None,
            ucs=0.9,
            tier=1,
            trust_before=0.5,
            trust_after=0.5,
            trust_delta=0.0,
            dimension_scores={},
            vetoed_by=[],
            action_id="test",
            duration_ms=10.0,
            estimated_cost=0.12,
            cost_alerts=[],
        )
        d = result.to_dict()
        assert "estimated_cost" in d
        assert d["estimated_cost"] == 0.12
        assert "cost_alerts" in d

    def test_persistent_log_record_has_estimated_cost(self):
        from nomotic.audit_store import PersistentLogRecord

        record = PersistentLogRecord(
            record_id="test",
            timestamp=0.0,
            agent_id="test",
            action_type="read",
            action_target="db",
            verdict="ALLOW",
            ucs=0.9,
            tier=1,
            trust_score=0.5,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="ok",
            estimated_cost=0.05,
        )
        assert record.estimated_cost == 0.05
        d = record.to_dict()
        assert d["estimated_cost"] == 0.05

    def test_persistent_log_record_default_cost(self):
        from nomotic.audit_store import PersistentLogRecord

        record = PersistentLogRecord(
            record_id="test",
            timestamp=0.0,
            agent_id="test",
            action_type="read",
            action_target="db",
            verdict="ALLOW",
            ucs=0.9,
            tier=1,
            trust_score=0.5,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification="ok",
        )
        assert record.estimated_cost == 0.0
        # Zero cost should be excluded from to_dict for backward compat
        d = record.to_dict()
        assert "estimated_cost" not in d
