"""Tests for the Config Editor API and UI (F-14)."""

from __future__ import annotations

import json
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


# ── Test fixtures ───────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class ConfigEditorTestClient:
    """HTTP client for testing config editor endpoints."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str, accept: str = "application/json") -> tuple[int, Any, dict[str, str]]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("Accept", accept)
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                headers = dict(resp.headers)
                ct = resp.headers.get("Content-Type", "")
                if "json" in ct:
                    return resp.status, json.loads(raw), headers
                return resp.status, raw, headers
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = raw
            return e.code, body, {}

    def post(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        accept: str = "application/json",
    ) -> tuple[int, Any, dict[str, str]]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Accept": accept,
                },
            )
            with urllib.request.urlopen(req) as resp:
                raw = resp.read()
                headers = dict(resp.headers)
                ct = resp.headers.get("Content-Type", "")
                if "json" in ct:
                    return resp.status, json.loads(raw), headers
                return resp.status, raw, headers
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = raw
            return e.code, body, {}


def _make_server(base_dir: Path, ui_enabled: bool = True) -> tuple[ConfigEditorTestClient, NomoticAPIServer]:
    """Create a server with configurable base_dir and return (client, server)."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=port,
        ui_enabled=ui_enabled,
        playground_enabled=True,
        base_dir=base_dir,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.5)

    client = ConfigEditorTestClient(f"http://127.0.0.1:{port}")
    return client, server


@pytest.fixture(scope="module")
def config_editor_server() -> ConfigEditorTestClient:
    """Start a test API server with UI enabled and a temp base_dir."""
    tmp = Path(tempfile.mkdtemp())
    client, server = _make_server(tmp)
    yield client
    server.shutdown()


@pytest.fixture(scope="module")
def config_editor_with_yaml() -> ConfigEditorTestClient:
    """Start a test API server with a nomotic.yaml in base_dir."""
    tmp = Path(tempfile.mkdtemp())
    yaml_content = """\
version: '1.0'

agent:
  name: test-agent
  archetype: healthcare-agent
  organization: test-org
  zone: prod/main

compliance:
  preset: hipaa_aligned

governance:
  trust_low_threshold: 0.35
  trust_high_threshold: 0.65

dimension_weights:
  scope_compliance: 2.0
  ethical_alignment: 2.5
"""
    (tmp / "nomotic.yaml").write_text(yaml_content, encoding="utf-8")
    client, server = _make_server(tmp)
    yield client
    server.shutdown()


# ── Helper: standard config payload ─────────────────────────────────────


def _valid_config_payload(
    name: str = "my-agent",
    archetype: str = "data-processor",
    preset: str = "standard",
    trust_low: float = 0.35,
    trust_high: float = 0.65,
    weights: dict[str, float] | None = None,
) -> dict[str, Any]:
    return {
        "agent": {
            "name": name,
            "archetype": archetype,
        },
        "compliance": {
            "preset": preset,
        },
        "governance": {
            "trust_low_threshold": trust_low,
            "trust_high_threshold": trust_high,
        },
        "dimension_weights": weights or {},
    }


# ── Tests ───────────────────────────────────────────────────────────────


class TestConfigEditorUI:
    """Test 1: GET /ui/config-editor returns 200 when --ui enabled."""

    def test_config_editor_page_returns_200(self, config_editor_server: ConfigEditorTestClient) -> None:
        status, body, headers = config_editor_server.get("/ui/config-editor", accept="text/html")
        assert status == 200
        assert b"Config Editor" in body


class TestGetConfig:
    """Tests for GET /v1/ui/config."""

    def test_get_config_returns_json_with_sections(self, config_editor_with_yaml: ConfigEditorTestClient) -> None:
        """Test 2: GET /v1/ui/config returns JSON with agent, compliance, governance sections."""
        status, body, headers = config_editor_with_yaml.get("/v1/ui/config")
        assert status == 200
        assert "agent" in body
        assert "compliance" in body
        assert "governance" in body
        assert "dimension_weights" in body
        assert "raw_yaml" in body
        # Check parsed values
        assert body["agent"]["name"] == "test-agent"
        assert body["agent"]["archetype"] == "healthcare-agent"

    def test_get_config_returns_404_when_absent(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 3: GET /v1/ui/config returns 404 with no_config when nomotic.yaml absent."""
        status, body, headers = config_editor_server.get("/v1/ui/config")
        assert status == 404
        assert body["error"] == "no_config"


class TestValidateConfig:
    """Tests for POST /v1/ui/config/validate."""

    def test_valid_config_returns_valid_true(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 4: POST /v1/ui/config/validate with valid config returns valid=true, errors=[]."""
        payload = _valid_config_payload()
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert body["valid"] is True
        assert body["errors"] == []

    def test_unknown_archetype_returns_error(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 5: POST /v1/ui/config/validate with unknown archetype returns valid=false with error."""
        payload = _valid_config_payload(archetype="unknown-robot-9000")
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert body["valid"] is False
        assert any("unknown" in e.lower() or "archetype" in e.lower() for e in body["errors"])

    def test_missing_agent_name_returns_error(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 6: POST /v1/ui/config/validate with missing agent.name returns valid=false."""
        payload = _valid_config_payload(name="")
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert body["valid"] is False
        assert any("agent.name" in e for e in body["errors"])

    def test_high_weight_returns_warning(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 7: POST /v1/ui/config/validate with weight > 5.0 returns warning (not error)."""
        payload = _valid_config_payload(weights={"scope_compliance": 6.0})
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        # Weight > 5.0 is a warning, not an error
        assert any("scope_compliance" in w and "outside" in w for w in body["warnings"])

    def test_strict_equivalent_weight_warning(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 8: Strict check -- weight warning produces a warning entry."""
        payload = _valid_config_payload(weights={"ethical_alignment": 7.5})
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert len(body["warnings"]) > 0
        assert any("ethical_alignment" in w for w in body["warnings"])


class TestDownloadConfig:
    """Tests for POST /v1/ui/config/download."""

    def test_download_returns_content_disposition(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 9: POST /v1/ui/config/download returns Content-Disposition attachment."""
        payload = _valid_config_payload()
        status, body, headers = config_editor_server.post(
            "/v1/ui/config/download", data=payload, accept="application/x-yaml",
        )
        assert status == 200
        cd = headers.get("Content-Disposition", headers.get("content-disposition", ""))
        assert "attachment" in cd
        assert "nomotic.yaml" in cd

    def test_download_returns_valid_yaml(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Test 10: POST /v1/ui/config/download returns valid YAML."""
        import yaml

        payload = _valid_config_payload(name="test-dl-agent", archetype="security-monitor")
        status, body, headers = config_editor_server.post(
            "/v1/ui/config/download", data=payload, accept="application/x-yaml",
        )
        assert status == 200
        # Body should be bytes (raw YAML)
        if isinstance(body, bytes):
            parsed = yaml.safe_load(body.decode("utf-8"))
        else:
            parsed = yaml.safe_load(str(body))
        assert isinstance(parsed, dict)
        # Should contain valid YAML structure
        assert "version" in parsed or "agents" in parsed or "governance" in parsed


class TestAdditionalEdgeCases:
    """Extra tests beyond the required 10."""

    def test_negative_weight_returns_error(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Negative dimension weight is an error."""
        payload = _valid_config_payload(weights={"scope_compliance": -1.0})
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert body["valid"] is False
        assert any("negative" in e.lower() or "non-negative" in e.lower() for e in body["errors"])

    def test_unknown_dimension_returns_error(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Unknown dimension name in weights is an error."""
        payload = _valid_config_payload(weights={"nonexistent_dimension": 1.0})
        status, body, headers = config_editor_server.post("/v1/ui/config/validate", data=payload)
        assert status == 200
        assert body["valid"] is False
        assert any("unknown" in e.lower() or "nonexistent" in e.lower() for e in body["errors"])

    def test_download_includes_dimension_weights(self, config_editor_server: ConfigEditorTestClient) -> None:
        """Downloaded YAML includes dimension weight overrides."""
        import yaml

        payload = _valid_config_payload(weights={"scope_compliance": 3.0})
        status, body, headers = config_editor_server.post(
            "/v1/ui/config/download", data=payload, accept="application/x-yaml",
        )
        assert status == 200
        if isinstance(body, bytes):
            text = body.decode("utf-8")
        else:
            text = str(body)
        assert "scope_compliance" in text
