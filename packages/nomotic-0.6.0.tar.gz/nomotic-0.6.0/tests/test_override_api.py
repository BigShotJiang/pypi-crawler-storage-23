"""Tests for the Override REST API (F-05 Part A).

Minimum 18 tests covering all 6 endpoints:
  GET  /v1/overrides/pending
  GET  /v1/overrides/pending/{id}
  POST /v1/overrides/pending/{id}/approve
  POST /v1/overrides/pending/{id}/deny
  GET  /v1/overrides/history
  GET  /v1/overrides/pending/{id}/status
"""

from __future__ import annotations

import json
import threading
import time
import uuid
import urllib.error
import urllib.request
from typing import Any

import pytest

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.store import MemoryCertificateStore
from nomotic.types import (
    Action,
    AgentContext,
    GovernanceVerdict,
    MultiSigOverridePolicy,
    OverrideSignature,
    PendingOverride,
    TrustProfile,
    Verdict,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _find_free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(agent_id: str = "agent-1") -> Action:
    return Action(agent_id=agent_id, action_type="read", target="db")


def _create_pending(runtime: GovernanceRuntime) -> PendingOverride:
    """Create a PendingOverride for testing by setting up the runtime state."""
    now = time.time()
    pending = PendingOverride(
        override_id=f"nmpo-{uuid.uuid4()}",
        action_id="test-action-001",
        agent_id="agent-1",
        override_type="APPROVE",
        policy_id="test-policy",
        required_signatures=2,
        status="PENDING",
        created_at=now,
        expires_at=now + 3600,
        original_verdict="DENY",
        initial_authority="admin-1",
        initial_reason="Test override",
    )
    sig = OverrideSignature(
        signature_id=f"nmosig-{uuid.uuid4()}",
        authority="admin-1",
        role_id=None,
        reason="Initial signature",
        signed_at=now,
        signature_hash=OverrideSignature.compute_hash(
            pending.override_id, "admin-1", "Initial signature", now
        ),
    )
    pending.signatures.append(sig)
    runtime._pending_overrides[pending.override_id] = pending
    return pending


class APIClient:
    """Minimal HTTP client for testing."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def get(self, path: str) -> tuple[int, Any]:
        url = f"{self.base_url}{path}"
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body

    def post(self, path: str, data: dict | None = None, headers: dict | None = None) -> tuple[int, Any]:
        url = f"{self.base_url}{path}"
        payload = json.dumps(data or {}).encode("utf-8")
        try:
            req = urllib.request.Request(
                url, data=payload, method="POST",
                headers={"Content-Type": "application/json"},
            )
            if headers:
                for k, v in headers.items():
                    req.add_header(k, v)
            with urllib.request.urlopen(req) as resp:
                body = json.loads(resp.read())
                return resp.status, body
        except urllib.error.HTTPError as e:
            body = json.loads(e.read())
            return e.code, body


@pytest.fixture(scope="module")
def server_and_runtime():
    """Start a test API server with a runtime and return client + runtime."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    runtime = GovernanceRuntime(RuntimeConfig())
    # Add a multi-sig policy so cosign_override works
    policy = MultiSigOverridePolicy(
        policy_id="test-policy",
        name="Test Policy",
        required_signatures=2,
        eligible_roles=["admin"],
    )
    runtime._multisig_policies.append(policy)

    port = _find_free_port()
    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        runtime=runtime,
        host="127.0.0.1",
        port=port,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    client = APIClient(f"http://127.0.0.1:{port}")
    return client, runtime


# ── Test 1: GET /v1/overrides/pending returns empty array ───────────────


def test_pending_list_empty(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    status, body = client.get("/v1/overrides/pending")
    assert status == 200
    assert body == []


# ── Test 2: GET /v1/overrides/pending returns array with structure ──────


def test_pending_list_with_overrides(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.get("/v1/overrides/pending")
    assert status == 200
    assert len(body) == 1
    assert body[0]["pending_id"] == pending.override_id


# ── Test 3: GET /v1/overrides/pending/{id} returns single override ──────


def test_pending_get_known(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.get(f"/v1/overrides/pending/{pending.override_id}")
    assert status == 200
    assert body["pending_id"] == pending.override_id


# ── Test 4: GET /v1/overrides/pending/{id} returns 404 for unknown ──────


def test_pending_get_unknown(server_and_runtime):
    client, runtime = server_and_runtime
    status, body = client.get("/v1/overrides/pending/nmpo-nonexistent")
    assert status == 404


# ── Test 5: Serialized pending contains all required fields ─────────────


def test_pending_serialization_fields(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    _create_pending(runtime)
    status, body = client.get("/v1/overrides/pending")
    assert status == 200
    item = body[0]
    required_fields = [
        "pending_id", "agent_id", "action_type",
        "signatures_required", "signatures_collected",
        "ttl_seconds_remaining", "expires_at", "status",
    ]
    for field in required_fields:
        assert field in item, f"Missing field: {field}"


# ── Test 6: POST approve with valid authority returns 200 ───────────────


def test_approve_valid(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2", "reason": "Looks good"},
    )
    assert status == 200
    assert body["pending_id"] == pending.override_id


# ── Test 7: POST approve increments signatures_collected ────────────────


def test_approve_increments_signatures(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    # Increase required so it stays pending
    pending.required_signatures = 3
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2", "reason": "Co-sign"},
    )
    assert status == 200
    assert body["signatures_collected"] == 2


# ── Test 8: POST approve completing threshold returns COMPLETE ──────────


def test_approve_completes_threshold(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    # Create pending with required_signatures=2 and 1 sig already
    pending = _create_pending(runtime)
    # Need to set up verdicts/history so execute doesn't fail
    # We just need cosign to succeed; execution may raise but we catch it
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2", "reason": "Approve"},
    )
    assert status == 200
    assert body["status"] == "COMPLETE"
    assert body["completed"] is True


# ── Test 9: POST approve with already-signed authority returns 409 ──────


def test_approve_duplicate_authority(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    pending.required_signatures = 3
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-1", "reason": "Duplicate"},
    )
    assert status == 409


# ── Test 10: POST approve for expired override returns 400 ──────────────


def test_approve_expired(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    pending.expires_at = time.time() - 10  # expired
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2", "reason": "Too late"},
    )
    assert status == 400


# ── Test 11: POST approve missing authority returns 400 ─────────────────


def test_approve_missing_authority(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"reason": "Missing authority"},
    )
    assert status == 400


# ── Test 12: POST approve missing reason returns 400 ────────────────────


def test_approve_missing_reason(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/approve",
        {"authority": "admin-2"},
    )
    assert status == 400


# ── Test 13: POST approve for unknown pending_id returns 404 ────────────


def test_approve_unknown_id(server_and_runtime):
    client, runtime = server_and_runtime
    status, body = client.post(
        "/v1/overrides/pending/nmpo-nonexistent/approve",
        {"authority": "admin-2", "reason": "Missing"},
    )
    assert status == 404


# ── Test 14: POST deny with valid body returns DENIED ───────────────────


def test_deny_valid(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/deny",
        {"authority": "admin-2", "reason": "Not acceptable"},
    )
    assert status == 200
    assert body["status"] == "DENIED"
    assert body["denied_by"] == "admin-2"


# ── Test 15: POST deny writes audit record ──────────────────────────────


def test_deny_removes_from_pending(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    pid = pending.override_id
    client.post(
        f"/v1/overrides/pending/{pid}/deny",
        {"authority": "admin-2", "reason": "Denied"},
    )
    assert pid not in runtime._pending_overrides


# ── Test 16: POST deny for unknown pending_id returns 404 ───────────────


def test_deny_unknown_id(server_and_runtime):
    client, runtime = server_and_runtime
    status, body = client.post(
        "/v1/overrides/pending/nmpo-nonexistent/deny",
        {"authority": "admin-2", "reason": "Missing"},
    )
    assert status == 404


# ── Test 17: GET /v1/overrides/history returns records ──────────────────


def test_history_returns_records(server_and_runtime):
    client, runtime = server_and_runtime
    # History depends on persistent audit store — test empty case
    status, body = client.get("/v1/overrides/history")
    assert status == 200
    assert isinstance(body, list)


# ── Test 18: GET /v1/overrides/pending/{id}/status lightweight ──────────


def test_status_lightweight(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.get(
        f"/v1/overrides/pending/{pending.override_id}/status"
    )
    assert status == 200
    assert body["pending_id"] == pending.override_id
    assert isinstance(body["ttl_seconds_remaining"], int)
    assert "signatures_collected" in body
    assert "signatures_required" in body
    assert "is_expired" in body


# ── Test 19: GET /v1/overrides/pending/{id}/status returns 404 ──────────


def test_status_unknown_id(server_and_runtime):
    client, runtime = server_and_runtime
    status, body = client.get("/v1/overrides/pending/nmpo-nonexistent/status")
    assert status == 404


# ── Test 20: POST deny missing fields returns 400 ───────────────────────


def test_deny_missing_fields(server_and_runtime):
    client, runtime = server_and_runtime
    runtime._pending_overrides.clear()
    pending = _create_pending(runtime)
    status, body = client.post(
        f"/v1/overrides/pending/{pending.override_id}/deny",
        {"authority": "admin-2"},  # missing reason
    )
    assert status == 400
