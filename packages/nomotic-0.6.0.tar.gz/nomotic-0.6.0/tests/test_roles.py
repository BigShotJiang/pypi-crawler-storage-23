"""Tests for role-based override permissions.

Covers:
- OverrideRole creation, hashing, roundtrip
- RoleRegistry: register, list, get, check_permission
- Glob matching for zones, archetypes, action types
- Risk tier ordering
- Irreversible override gating
- File loading (JSON, malformed, missing fields)
- Runtime integration (role_check flag, warnings, permission denied)
- PermissionDeniedError attributes
"""

import hashlib
import json
import time
import uuid
import warnings

import pytest

from nomotic.roles import (
    OverrideRole,
    PermissionDeniedError,
    PermissionResult,
    RoleConfigError,
    RoleRegistry,
    _compute_role_hash,
    _glob_match,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import (
    Action,
    AgentContext,
    GovernanceOverrideRecord,
    GovernanceVerdict,
    GovernanceWarning,
    TrustProfile,
    Verdict,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_role(**overrides) -> OverrideRole:
    """Create a test role with sensible defaults."""
    defaults = {
        "role_id": f"nmr-{uuid.uuid4()}",
        "name": "Test Role",
        "authorities": ["admin@acme.com"],
        "permitted_override_types": ["APPROVE", "REVOKE"],
        "permitted_zones": ["*"],
        "permitted_archetypes": ["*"],
        "permitted_action_types": ["*"],
        "max_risk_tier": "critical",
        "can_override_irreversible": False,
        "created_by": "test@acme.com",
        "created_at": time.time(),
        "role_hash": "",
    }
    defaults.update(overrides)
    if not defaults["role_hash"]:
        defaults["role_hash"] = _compute_role_hash(defaults)
    return OverrideRole(**defaults)


def _ctx(agent_id: str = "agent-1", trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=trust),
    )


def _action(action_type: str = "read", target: str = "db", agent_id: str = "agent-1") -> Action:
    return Action(agent_id=agent_id, action_type=action_type, target=target)


# ── TestOverrideRole ─────────────────────────────────────────────────────


class TestOverrideRole:
    def test_creation_with_all_fields(self):
        role = _make_role(name="Full Role", role_id="nmr-test-123")
        assert role.role_id == "nmr-test-123"
        assert role.name == "Full Role"
        assert role.authorities == ["admin@acme.com"]
        assert role.permitted_override_types == ["APPROVE", "REVOKE"]
        assert role.permitted_zones == ["*"]
        assert role.permitted_archetypes == ["*"]
        assert role.permitted_action_types == ["*"]
        assert role.max_risk_tier == "critical"
        assert role.can_override_irreversible is False
        assert role.created_by == "test@acme.com"
        assert isinstance(role.created_at, float)
        assert isinstance(role.role_hash, str)

    def test_role_hash_computed_correctly(self):
        role_dict = {
            "role_id": "nmr-fixed",
            "name": "Hash Test",
            "authorities": ["user@acme.com"],
            "permitted_override_types": ["APPROVE"],
            "permitted_zones": ["eu/*"],
            "permitted_archetypes": ["*"],
            "permitted_action_types": ["*"],
            "max_risk_tier": "high",
            "can_override_irreversible": False,
            "created_by": "admin@acme.com",
            "created_at": 1740268800.0,
        }
        expected = hashlib.sha256(
            json.dumps(role_dict, sort_keys=True).encode()
        ).hexdigest()
        assert _compute_role_hash(role_dict) == expected

    def test_to_dict_roundtrip(self):
        role = _make_role(role_id="nmr-roundtrip", name="Roundtrip")
        d = role.to_dict()
        assert d["role_id"] == "nmr-roundtrip"
        assert d["name"] == "Roundtrip"
        assert "role_hash" in d
        # All fields present
        for field_name in [
            "role_id", "name", "authorities", "permitted_override_types",
            "permitted_zones", "permitted_archetypes", "permitted_action_types",
            "max_risk_tier", "can_override_irreversible", "created_by",
            "created_at", "role_hash",
        ]:
            assert field_name in d


# ── TestRoleRegistry ─────────────────────────────────────────────────────


class TestRoleRegistry:
    def test_register_and_get_role(self):
        registry = RoleRegistry()
        role = _make_role(role_id="nmr-get")
        registry.register(role)
        assert registry.get_role("nmr-get") is role

    def test_list_roles(self):
        registry = RoleRegistry()
        r1 = _make_role(role_id="nmr-1")
        r2 = _make_role(role_id="nmr-2")
        registry.register(r1)
        registry.register(r2)
        roles = registry.list_roles()
        assert len(roles) == 2
        assert roles[0].role_id == "nmr-1"
        assert roles[1].role_id == "nmr-2"

    def test_has_roles_empty(self):
        registry = RoleRegistry()
        assert registry.has_roles() is False

    def test_has_roles_after_register(self):
        registry = RoleRegistry()
        registry.register(_make_role())
        assert registry.has_roles() is True

    def test_get_role_not_found(self):
        registry = RoleRegistry()
        assert registry.get_role("nonexistent") is None

    def test_check_permission_permitted(self):
        registry = RoleRegistry()
        registry.register(_make_role(authorities=["admin@acme.com"]))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="moderate",
        )
        assert result.permitted is True
        assert result.role_id is not None
        assert result.authority == "admin@acme.com"

    def test_check_permission_denied_wrong_authority(self):
        registry = RoleRegistry()
        registry.register(_make_role(authorities=["admin@acme.com"]))
        result = registry.check_permission(
            authority="rando@evil.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is False
        assert result.role_id is None

    def test_check_permission_denied_wrong_override_type(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            permitted_override_types=["APPROVE"],
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="REVOKE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is False

    def test_check_permission_denied_zone_mismatch(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            permitted_zones=["eu/*"],
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is False

    def test_check_permission_denied_risk_tier_exceeds(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            max_risk_tier="moderate",
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="critical",
        )
        assert result.permitted is False

    def test_check_permission_denied_irreversible_not_allowed(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            can_override_irreversible=False,
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=True,
            risk_tier="low",
        )
        assert result.permitted is False

    def test_check_permission_irreversible_allowed(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            can_override_irreversible=True,
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=True,
            risk_tier="low",
        )
        assert result.permitted is True

    def test_check_permission_wildcard_zone(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            permitted_zones=["*"],
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="any/zone/here",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is True

    def test_check_permission_wildcard_archetype(self):
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["admin@acme.com"],
            permitted_archetypes=["*"],
        ))
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="any-archetype-here",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is True

    def test_check_permission_first_matching_role_wins(self):
        registry = RoleRegistry()
        r1 = _make_role(
            role_id="nmr-first",
            authorities=["admin@acme.com"],
            name="First Role",
        )
        r2 = _make_role(
            role_id="nmr-second",
            authorities=["admin@acme.com"],
            name="Second Role",
        )
        registry.register(r1)
        registry.register(r2)
        result = registry.check_permission(
            authority="admin@acme.com",
            override_type="APPROVE",
            action_type="read",
            zone_path="us/east",
            archetype="data-reader",
            is_irreversible=False,
            risk_tier="low",
        )
        assert result.permitted is True
        assert result.role_id == "nmr-first"

    def test_load_from_file_json(self, tmp_path):
        roles_data = {
            "roles": [
                {
                    "role_id": "nmr-json-test",
                    "name": "JSON Test Role",
                    "authorities": ["admin@acme.com"],
                    "permitted_override_types": ["APPROVE"],
                    "permitted_zones": ["*"],
                    "permitted_archetypes": ["*"],
                    "permitted_action_types": ["*"],
                    "max_risk_tier": "high",
                    "can_override_irreversible": False,
                    "created_by": "admin@acme.com",
                    "created_at": 1740268800.0,
                }
            ]
        }
        f = tmp_path / "roles.json"
        f.write_text(json.dumps(roles_data))

        registry = RoleRegistry()
        count = registry.load_from_file(f)
        assert count == 1
        role = registry.get_role("nmr-json-test")
        assert role is not None
        assert role.name == "JSON Test Role"

    def test_load_from_file_missing_role_id_generates_uuid(self, tmp_path):
        roles_data = {
            "roles": [
                {
                    "name": "Auto ID Role",
                    "authorities": ["user@acme.com"],
                    "permitted_override_types": ["APPROVE"],
                }
            ]
        }
        f = tmp_path / "roles.json"
        f.write_text(json.dumps(roles_data))

        registry = RoleRegistry()
        count = registry.load_from_file(f)
        assert count == 1
        roles = registry.list_roles()
        assert len(roles) == 1
        assert roles[0].role_id.startswith("nmr-")

    def test_load_from_file_malformed_json(self, tmp_path):
        f = tmp_path / "roles.json"
        f.write_text("{invalid json")

        registry = RoleRegistry()
        with pytest.raises(RoleConfigError, match="Invalid JSON"):
            registry.load_from_file(f)

    def test_load_from_file_missing_required_field(self, tmp_path):
        roles_data = {
            "roles": [
                {
                    "role_id": "nmr-incomplete",
                    # Missing "name", "authorities", "permitted_override_types"
                }
            ]
        }
        f = tmp_path / "roles.json"
        f.write_text(json.dumps(roles_data))

        registry = RoleRegistry()
        with pytest.raises(RoleConfigError, match="missing required field"):
            registry.load_from_file(f)

    def test_load_from_file_no_roles_key(self, tmp_path):
        f = tmp_path / "roles.json"
        f.write_text(json.dumps({"something": "else"}))

        registry = RoleRegistry()
        with pytest.raises(RoleConfigError, match="'roles' key"):
            registry.load_from_file(f)

    def test_load_from_file_yaml_without_pyyaml(self, tmp_path, monkeypatch):
        f = tmp_path / "roles.yaml"
        f.write_text("roles: []")

        import builtins
        original_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "yaml":
                raise ImportError("No module named 'yaml'")
            return original_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)

        registry = RoleRegistry()
        with pytest.raises(RoleConfigError, match="PyYAML"):
            registry.load_from_file(f)


# ── TestRoleIntegration ──────────────────────────────────────────────────


class TestRoleIntegration:
    def _setup_runtime_with_override(self, verdict_type=Verdict.DENY):
        """Create a runtime with an action evaluated and stored in memory."""
        runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
        action = _action()
        ctx = _ctx()
        # Force a verdict into the runtime's internal storage
        v = GovernanceVerdict(
            action_id=action.id,
            verdict=verdict_type,
            ucs=0.4,
            tier=2,
        )
        runtime._verdicts[action.id] = v
        # Store in action history so agent_id can be found
        from nomotic.types import ActionRecord, ActionState
        state = ActionState.DENIED if verdict_type == Verdict.DENY else ActionState.COMPLETED
        record = ActionRecord(action=action, verdict=v, state=state)
        runtime._action_history.setdefault(action.agent_id, []).append(record)
        return runtime, action

    def test_override_role_check_false_skips(self):
        runtime, action = self._setup_runtime_with_override(Verdict.DENY)

        # Register a role that would deny
        registry = RoleRegistry()
        registry.register(_make_role(
            authorities=["other@acme.com"],  # different authority
        ))
        runtime.set_role_registry(registry)

        # With role_check=False, should succeed even though authority doesn't match
        result = runtime.override(
            action_id=action.id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Testing",
            role_check=False,
        )
        assert result.override_id.startswith("nmo-")

    def test_override_no_registry_proceeds_with_warning(self):
        runtime, action = self._setup_runtime_with_override(Verdict.DENY)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = runtime.override(
                action_id=action.id,
                override_type="APPROVE",
                authority="admin@acme.com",
                reason="Testing",
            )
            assert result.override_id.startswith("nmo-")
            governance_warnings = [x for x in w if issubclass(x.category, GovernanceWarning)]
            assert len(governance_warnings) >= 1
            assert "not enforced" in str(governance_warnings[0].message)

    def test_override_with_registry_permitted(self):
        runtime, action = self._setup_runtime_with_override(Verdict.DENY)

        registry = RoleRegistry()
        registry.register(_make_role(authorities=["admin@acme.com"]))
        runtime.set_role_registry(registry)

        result = runtime.override(
            action_id=action.id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Authorized override",
        )
        assert result.override_id.startswith("nmo-")
        assert result.role_id is not None

    def test_override_with_registry_denied(self):
        runtime, action = self._setup_runtime_with_override(Verdict.DENY)

        registry = RoleRegistry()
        registry.register(_make_role(authorities=["other@acme.com"]))
        runtime.set_role_registry(registry)

        with pytest.raises(PermissionDeniedError) as exc_info:
            runtime.override(
                action_id=action.id,
                override_type="APPROVE",
                authority="admin@acme.com",
                reason="Should fail",
            )
        assert exc_info.value.result.permitted is False

    def test_override_record_role_id_populated(self):
        runtime, action = self._setup_runtime_with_override(Verdict.DENY)

        role = _make_role(role_id="nmr-tracked", authorities=["admin@acme.com"])
        registry = RoleRegistry()
        registry.register(role)
        runtime.set_role_registry(registry)

        result = runtime.override(
            action_id=action.id,
            override_type="APPROVE",
            authority="admin@acme.com",
            reason="Tracked override",
        )
        assert result.role_id == "nmr-tracked"

    def test_load_roles_convenience_method(self, tmp_path):
        roles_data = {
            "roles": [
                {
                    "name": "Convenience Role",
                    "authorities": ["admin@acme.com"],
                    "permitted_override_types": ["APPROVE"],
                }
            ]
        }
        f = tmp_path / "roles.json"
        f.write_text(json.dumps(roles_data))

        runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
        count = runtime.load_roles(f)
        assert count == 1
        assert runtime._role_registry is not None
        assert runtime._role_registry.has_roles() is True

    def test_set_role_registry(self):
        runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
        registry = RoleRegistry()
        runtime.set_role_registry(registry)
        assert runtime._role_registry is registry


# ── TestPermissionDeniedError ────────────────────────────────────────────


class TestPermissionDeniedError:
    def test_exception_message_contains_reason(self):
        result = PermissionResult(
            permitted=False,
            role_id=None,
            reason="No role grants authority 'bob@evil.com' permission to APPROVE",
            authority="bob@evil.com",
            override_type="APPROVE",
        )
        exc = PermissionDeniedError(result)
        assert "bob@evil.com" in str(exc)
        assert "APPROVE" in str(exc)

    def test_result_attribute_accessible(self):
        result = PermissionResult(
            permitted=False,
            role_id=None,
            reason="Denied",
            authority="bob@evil.com",
            override_type="REVOKE",
        )
        exc = PermissionDeniedError(result)
        assert exc.result is result
        assert exc.result.authority == "bob@evil.com"
        assert exc.result.override_type == "REVOKE"


# ── TestGlobMatch ────────────────────────────────────────────────────────


class TestGlobMatch:
    def test_wildcard_matches_anything(self):
        assert _glob_match("*", "anything") is True
        assert _glob_match("*", "eu/de") is True
        assert _glob_match("*", "") is True

    def test_eu_glob_matches_eu_zones(self):
        assert _glob_match("eu/*", "eu/de") is True
        assert _glob_match("eu/*", "eu/fr/paris") is True  # fnmatch: * matches / in Python
        assert _glob_match("eu/*", "us/east") is False

    def test_exact_match(self):
        assert _glob_match("us/east", "us/east") is True
        assert _glob_match("us/east", "us/west") is False

    def test_suffix_glob(self):
        assert _glob_match("*/production", "eu/production") is True
        assert _glob_match("*/production", "us/production") is True
        assert _glob_match("*/production", "us/staging") is False


# ── TestGovernanceOverrideRecord ─────────────────────────────────────────


class TestGovernanceOverrideRecordRoleId:
    def test_to_dict_includes_role_id_when_set(self):
        record = GovernanceOverrideRecord(
            override_id="nmo-test",
            action_id="act-1",
            override_type="APPROVE",
            original_verdict="DENY",
            authority="admin@acme.com",
            reason="Test",
            agent_id="agent-1",
            trust_before=0.5,
            trust_after=0.5,
            role_id="nmr-123",
        )
        d = record.to_dict()
        assert d["role_id"] == "nmr-123"

    def test_to_dict_excludes_role_id_when_none(self):
        record = GovernanceOverrideRecord(
            override_id="nmo-test",
            action_id="act-1",
            override_type="APPROVE",
            original_verdict="DENY",
            authority="admin@acme.com",
            reason="Test",
            agent_id="agent-1",
            trust_before=0.5,
            trust_after=0.5,
        )
        d = record.to_dict()
        assert "role_id" not in d


# ── TestImports ──────────────────────────────────────────────────────────


class TestImports:
    def test_import_from_roles_module(self):
        from nomotic.roles import RoleRegistry
        assert RoleRegistry is not None

    def test_import_from_nomotic_package(self):
        from nomotic import RoleRegistry
        assert RoleRegistry is not None

    def test_governance_warning_importable(self):
        from nomotic.types import GovernanceWarning
        assert issubclass(GovernanceWarning, UserWarning)
