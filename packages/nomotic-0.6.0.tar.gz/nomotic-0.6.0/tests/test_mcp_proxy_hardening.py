"""Tests for MCP proxy hardening — health, metrics, logging, timeouts, shutdown."""

import io
import json
import signal
import sys
import time
from http.server import HTTPServer
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.executor import ExecutionResult, GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.mcp_proxy import MCPHTTPGovernanceProxy
from nomotic.otel_exporter import PrometheusMetrics
from nomotic.proxy import GovernanceProxyHandler, start_proxy
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=[],
    )
    save_agent_config(tmp_path, config)
    return cert.certificate_id


# ── Health check tests ────────────────────────────────────────────────


class TestHealthCheck:
    def test_health_returns_expected_fields(self, tmp_path):
        """GET /health returns 200 with expected fields."""
        _setup_agent(tmp_path, "HealthBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HealthBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        health = proxy._health_check()
        assert health["agent_id"] == "HealthBot"
        assert health["upstream_url"] == "http://localhost:19999"
        assert "uptime_seconds" in health
        assert "requests_total" in health
        assert "denials_total" in health
        assert health["requests_total"] == 0
        assert health["denials_total"] == 0

    def test_health_includes_upstream_status(self, tmp_path):
        """Health check includes upstream_status field."""
        _setup_agent(tmp_path, "HealthBot2")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="HealthBot2",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        health = proxy._health_check()
        assert "upstream_status" in health

    def test_health_includes_request_denial_counts(self, tmp_path):
        """Health check includes request/denial counts after operations."""
        _setup_agent(tmp_path, "CountBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="CountBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        proxy._request_count = 10
        proxy._denial_count = 3

        health = proxy._health_check()
        assert health["requests_total"] == 10
        assert health["denials_total"] == 3

    def test_health_degraded_when_upstream_unreachable(self, tmp_path):
        """GET /health returns degraded status when upstream is unreachable."""
        _setup_agent(tmp_path, "DegradedBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="DegradedBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        # Upstream on port 19999 should be unreachable
        health = proxy._health_check()
        assert health["status"] == "degraded"
        assert health["upstream_status"] == "unreachable"

    @patch("nomotic.mcp_proxy.urllib.request.urlopen")
    def test_health_ok_when_upstream_reachable(self, mock_urlopen, tmp_path):
        """GET /health returns ok when upstream responds."""
        _setup_agent(tmp_path, "OkBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="OkBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        mock_urlopen.return_value.__enter__ = MagicMock()
        mock_urlopen.return_value.__exit__ = MagicMock(return_value=False)

        health = proxy._health_check()
        assert health["status"] == "ok"
        assert health["upstream_status"] == "reachable"


# ── Metrics tests ─────────────────────────────────────────────────────


class TestMetrics:
    def test_metrics_returns_prometheus_format(self, tmp_path):
        """GET /metrics returns Prometheus text format."""
        _setup_agent(tmp_path, "MetricsBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="MetricsBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        # Record some metrics
        proxy._metrics.inc(
            "nomotic_proxy_requests_total",
            labels={"agent_id": "MetricsBot"},
        )

        text = proxy._metrics.format_prometheus()
        assert "nomotic_proxy_requests_total" in text
        assert "# TYPE" in text

    def test_request_count_increments(self, tmp_path):
        """Request count increments with each call to inc."""
        _setup_agent(tmp_path, "CountBot2")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="CountBot2",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        proxy._metrics.inc("nomotic_proxy_requests_total", labels={"agent_id": "CountBot2"})
        proxy._metrics.inc("nomotic_proxy_requests_total", labels={"agent_id": "CountBot2"})

        text = proxy._metrics.format_prometheus()
        assert "2" in text  # counter should be 2

    def test_denial_count_increments(self, tmp_path):
        """Denial count increments."""
        _setup_agent(tmp_path, "DenialBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="DenialBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        proxy._metrics.inc("nomotic_proxy_denials_total", labels={"agent_id": "DenialBot"})

        text = proxy._metrics.format_prometheus()
        assert "nomotic_proxy_denials_total" in text

    def test_latency_histogram_recorded(self, tmp_path):
        """Latency histogram observation is recorded."""
        _setup_agent(tmp_path, "LatencyBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="LatencyBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
        )

        proxy._metrics.observe("nomotic_proxy_latency_seconds", 0.15)
        proxy._metrics.observe("nomotic_proxy_latency_seconds", 0.25)

        text = proxy._metrics.format_prometheus()
        assert "nomotic_proxy_latency_seconds_count 2" in text
        assert "nomotic_proxy_latency_seconds_sum" in text


# ── Structured logging tests ──────────────────────────────────────────


class TestStructuredLogging:
    def test_log_entries_are_valid_json(self, tmp_path, capsys):
        """Log entries are valid JSON on stderr."""
        _setup_agent(tmp_path, "LogBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="LogBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="info",
        )

        proxy._log("info", "test_message", extra="value")
        captured = capsys.readouterr()
        entry = json.loads(captured.err.strip())
        assert entry["message"] == "test_message"
        assert entry["extra"] == "value"

    def test_log_includes_timestamp_level_agent_id(self, tmp_path, capsys):
        """Log entries include timestamp, level, and agent_id."""
        _setup_agent(tmp_path, "LogBot2")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="LogBot2",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="info",
        )

        proxy._log("info", "test_fields")
        captured = capsys.readouterr()
        entry = json.loads(captured.err.strip())
        assert "timestamp" in entry
        assert entry["level"] == "info"
        assert entry["agent_id"] == "LogBot2"

    def test_quiet_mode_suppresses_info(self, tmp_path, capsys):
        """Quiet mode suppresses info logs."""
        _setup_agent(tmp_path, "QuietBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="QuietBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="quiet",
        )

        proxy._log("info", "should_be_suppressed")
        captured = capsys.readouterr()
        assert captured.err.strip() == ""

    def test_quiet_mode_allows_errors(self, tmp_path, capsys):
        """Quiet mode still outputs error logs."""
        _setup_agent(tmp_path, "QuietErrBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="QuietErrBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="quiet",
        )

        proxy._log("error", "this_should_appear")
        captured = capsys.readouterr()
        entry = json.loads(captured.err.strip())
        assert entry["level"] == "error"

    def test_debug_mode_includes_all(self, tmp_path, capsys):
        """Debug mode includes all log levels."""
        _setup_agent(tmp_path, "DebugBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="DebugBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="debug",
        )

        proxy._log("debug", "debug_msg")
        proxy._log("info", "info_msg")
        proxy._log("error", "error_msg")
        captured = capsys.readouterr()
        lines = [l for l in captured.err.strip().split("\n") if l]
        assert len(lines) == 3

    def test_info_mode_suppresses_debug(self, tmp_path, capsys):
        """Info mode suppresses debug logs."""
        _setup_agent(tmp_path, "InfoBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="InfoBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="info",
        )

        proxy._log("debug", "should_not_appear")
        captured = capsys.readouterr()
        assert captured.err.strip() == ""


# ── Configurable timeouts tests ───────────────────────────────────────


class TestConfigurableTimeouts:
    def test_default_timeout_used(self, tmp_path):
        """Default timeout used when no tool-specific timeout."""
        _setup_agent(tmp_path, "TimeoutBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="TimeoutBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            default_timeout=45.0,
        )

        assert proxy._default_timeout == 45.0
        # For an unknown tool, should use default
        assert proxy._tool_timeouts.get("unknown_tool", proxy._default_timeout) == 45.0

    def test_tool_specific_timeout(self, tmp_path):
        """Tool-specific timeout used when configured."""
        _setup_agent(tmp_path, "TimeoutBot2")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="TimeoutBot2",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            tool_timeouts={"slow_tool": 120.0, "fast_tool": 5.0},
            default_timeout=30.0,
        )

        assert proxy._tool_timeouts["slow_tool"] == 120.0
        assert proxy._tool_timeouts["fast_tool"] == 5.0
        assert proxy._tool_timeouts.get("other", proxy._default_timeout) == 30.0

    def test_timeout_configuration_accepted(self, tmp_path):
        """Timeout configuration accepted in constructor."""
        _setup_agent(tmp_path, "TimeoutBot3")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="TimeoutBot3",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            tool_timeouts={"read": 10.0},
            default_timeout=60.0,
        )

        assert proxy._tool_timeouts == {"read": 10.0}
        assert proxy._default_timeout == 60.0


# ── Graceful shutdown tests ───────────────────────────────────────────


class TestGracefulShutdown:
    def test_signal_handler_registered(self, tmp_path):
        """Signal handler is registered during run()."""
        _setup_agent(tmp_path, "ShutdownBot")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="ShutdownBot",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="quiet",
        )

        original_sigterm = signal.getsignal(signal.SIGTERM)
        original_sigint = signal.getsignal(signal.SIGINT)

        with patch.object(HTTPServer, "serve_forever", side_effect=KeyboardInterrupt):
            with patch.object(HTTPServer, "server_close"):
                try:
                    proxy.run()
                except KeyboardInterrupt:
                    pass

        # Verify signal handlers were changed from defaults
        new_sigterm = signal.getsignal(signal.SIGTERM)
        new_sigint = signal.getsignal(signal.SIGINT)

        # The handlers should have been set (they may or may not still be set
        # after run exits, but we verify the run method sets them by checking
        # they changed)
        assert new_sigterm != signal.SIG_DFL or original_sigterm != signal.SIG_DFL

        # Restore original signals
        signal.signal(signal.SIGTERM, original_sigterm)
        signal.signal(signal.SIGINT, original_sigint)

    def test_shutdown_flag_set_on_sigterm(self, tmp_path):
        """Shutdown flag set when signal handler fires."""
        _setup_agent(tmp_path, "ShutdownBot2")
        proxy = MCPHTTPGovernanceProxy(
            agent_id="ShutdownBot2",
            upstream_url="http://localhost:19999",
            base_dir=tmp_path,
            test_mode=True,
            log_level="quiet",
        )

        assert proxy._shutting_down is False

        # Simulate what the signal handler does
        captured_handler = None

        original_sigterm = signal.getsignal(signal.SIGTERM)

        def capture_signal(signum, handler):
            nonlocal captured_handler
            if signum == signal.SIGTERM:
                captured_handler = handler

        with patch("signal.signal", side_effect=capture_signal):
            with patch.object(HTTPServer, "serve_forever", side_effect=KeyboardInterrupt):
                with patch.object(HTTPServer, "server_close"):
                    try:
                        proxy.run()
                    except KeyboardInterrupt:
                        pass

        # The handler should have been captured
        if captured_handler and callable(captured_handler):
            with patch.object(HTTPServer, "shutdown"):
                captured_handler(signal.SIGTERM, None)
            assert proxy._shutting_down is True

        signal.signal(signal.SIGTERM, original_sigterm)


# ── proxy.py GovernanceProxyHandler health/metrics tests ──────────────


class TestGovernanceProxyHandlerHealth:
    def test_handler_has_health_fields(self):
        """GovernanceProxyHandler has the expected class-level fields."""
        assert hasattr(GovernanceProxyHandler, "metrics")
        assert hasattr(GovernanceProxyHandler, "start_time")
        assert hasattr(GovernanceProxyHandler, "request_count")
        assert hasattr(GovernanceProxyHandler, "denial_count")
        assert hasattr(GovernanceProxyHandler, "agent_id")


# ── CLI argument tests ────────────────────────────────────────────────


class TestCLIHardeningArgs:
    def test_mcp_proxy_timeout_arg(self):
        """mcp-proxy accepts --timeout."""
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "test-bot",
            "--upstream", "python server.py",
            "--timeout", "60",
        ])
        assert args.timeout == 60.0

    def test_mcp_proxy_timeout_default(self):
        """mcp-proxy --timeout defaults to 30."""
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
        ])
        assert args.timeout == 30.0

    def test_mcp_proxy_log_format_arg(self):
        """mcp-proxy accepts --log-format."""
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "mcp-proxy",
            "--agent-id", "bot",
            "--upstream", "cmd",
            "--log-format", "text",
        ])
        assert args.log_format == "text"

    def test_proxy_timeout_arg(self):
        """proxy accepts --timeout."""
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "proxy",
            "--agent-id", "bot",
            "--upstream", "http://localhost:3000",
            "--timeout", "45",
        ])
        assert args.timeout == 45.0

    def test_proxy_log_format_arg(self):
        """proxy accepts --log-format."""
        from nomotic.cli import build_parser

        parser = build_parser()
        args = parser.parse_args([
            "proxy",
            "--agent-id", "bot",
            "--upstream", "http://localhost:3000",
            "--log-format", "json",
        ])
        assert args.log_format == "json"
