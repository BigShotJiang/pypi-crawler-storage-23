"""Tests for the governance scorecard generator (F-19)."""

import json
import time
from datetime import datetime, timezone
from pathlib import Path

import pytest

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.certificate import AgentCertificate, CertStatus
from nomotic.scorecard import (
    ArchetypeBenchmark,
    GovernanceScorecard,
    GovernanceScorecardGenerator,
    ScorecardControlGap,
    ScorecardControlMapping,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_certificate(
    agent_id: str = "test-agent",
    archetype: str = "sales-agent",
    trust_score: float = 0.75,
) -> AgentCertificate:
    """Create a minimal agent certificate for testing."""
    return AgentCertificate(
        certificate_id="nmc-test-0001",
        agent_id=agent_id,
        owner="test-owner",
        archetype=archetype,
        organization="test-org",
        zone_path="/test",
        issued_at=datetime(2025, 1, 1, tzinfo=timezone.utc),
        trust_score=trust_score,
        behavioral_age=10,
        status=CertStatus.ACTIVE,
        public_key=b"fake-key",
        fingerprint="test-fingerprint",
        governance_hash="test-hash",
        lineage=None,
        issuer_signature=b"fake-sig",
    )


def _write_certificate(base_dir: Path, cert: AgentCertificate) -> None:
    """Persist a certificate to the certs directory."""
    certs_dir = base_dir / "certs"
    certs_dir.mkdir(parents=True, exist_ok=True)
    cert_path = certs_dir / f"{cert.certificate_id}.json"
    cert_path.write_text(json.dumps(cert.to_dict()), encoding="utf-8")


def _make_audit_record(
    agent_id: str = "test-agent",
    verdict: str = "ALLOW",
    ucs: float = 0.75,
    ts_offset: float = 0.0,
) -> PersistentLogRecord:
    """Create a minimal audit record for testing."""
    return PersistentLogRecord(
        record_id=f"rec-{time.time()}-{ts_offset}",
        timestamp=time.time() - ts_offset,
        agent_id=agent_id,
        action_type="test-action",
        action_target="test-target",
        verdict=verdict,
        ucs=ucs,
        tier=1,
        trust_score=0.75,
        trust_delta=0.0,
        trust_trend="stable",
        severity="info",
        justification="test",
        record_hash=f"sha256:fakehash{ts_offset}",
    )


def _setup_agent_with_records(
    tmp_path: Path,
    agent_id: str = "test-agent",
    archetype: str = "sales-agent",
    records: list[PersistentLogRecord] | None = None,
) -> tuple[LogStore, GovernanceScorecardGenerator]:
    """Set up a test agent with certificate and audit records."""
    cert = _make_certificate(agent_id=agent_id, archetype=archetype)
    _write_certificate(tmp_path, cert)

    store = LogStore(tmp_path, "audit")
    if records:
        for r in records:
            store.append(r)

    generator = GovernanceScorecardGenerator(tmp_path, store)
    return store, generator


# ── Test 1: generate() returns GovernanceScorecard ───────────────────────


def test_generate_returns_governance_scorecard(tmp_path: Path) -> None:
    records = [_make_audit_record() for _ in range(5)]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard, GovernanceScorecard)


# ── Test 2: agent_id matches ─────────────────────────────────────────────


def test_scorecard_agent_id_matches(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert scorecard.agent_id == "test-agent"


# ── Test 3: archetype matches certificate ────────────────────────────────


def test_scorecard_archetype_matches_certificate(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(
        tmp_path, archetype="healthcare-agent", records=records
    )
    scorecard = gen.generate("test-agent")
    assert scorecard.archetype == "healthcare-agent"


# ── Test 4: evaluation_summary contains required keys ────────────────────


def test_evaluation_summary_keys(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    required = {"total", "allow", "deny", "escalate", "block"}
    assert required <= set(scorecard.evaluation_summary.keys())


# ── Test 5: rates sum <= 1.0 ─────────────────────────────────────────────


def test_rates_sum_lte_one(tmp_path: Path) -> None:
    records = [
        _make_audit_record(verdict="ALLOW"),
        _make_audit_record(verdict="DENY"),
        _make_audit_record(verdict="ESCALATE"),
        _make_audit_record(verdict="ALLOW"),
    ]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    total_rate = scorecard.allow_rate + scorecard.deny_rate + scorecard.escalate_rate
    assert total_rate <= 1.0 + 1e-9  # allow floating point


# ── Test 6: trust_trajectory_30d is list of floats ───────────────────────


def test_trust_trajectory_is_float_list(tmp_path: Path) -> None:
    records = [_make_audit_record(ucs=0.6 + i * 0.01) for i in range(5)]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard.trust_trajectory_30d, list)
    assert all(isinstance(v, float) for v in scorecard.trust_trajectory_30d)


# ── Test 7: compliance_mapping is non-empty list of ScorecardControlMapping


def test_compliance_mapping_non_empty(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert len(scorecard.compliance_mapping) > 0
    assert all(
        isinstance(cm, ScorecardControlMapping)
        for cm in scorecard.compliance_mapping
    )


# ── Test 8: ControlMapping coverage values are valid ─────────────────────


def test_control_mapping_coverage_values(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    valid_coverages = {"full", "partial", "indirect", "none"}
    for cm in scorecard.compliance_mapping:
        assert cm.coverage in valid_coverages, (
            f"{cm.control_id}: invalid coverage {cm.coverage!r}"
        )


# ── Test 9: gap_analysis is a list ───────────────────────────────────────


def test_gap_analysis_is_list(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard.gap_analysis, list)


# ── Test 10: ControlGap severity values are valid ────────────────────────


def test_control_gap_severity_values(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    valid_severities = {"critical", "high", "medium", "low"}
    for gap in scorecard.gap_analysis:
        assert isinstance(gap, ScorecardControlGap)
        assert gap.severity in valid_severities


# ── Test 11: archetype_benchmark.within_normal_range is bool ─────────────


def test_benchmark_within_normal_range_is_bool(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard.archetype_benchmark.within_normal_range, bool)


# ── Test 12: audit_record_hash is non-empty ──────────────────────────────


def test_audit_record_hash_non_empty(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard.audit_record_hash, str)
    assert len(scorecard.audit_record_hash) > 0


# ── Test 13: nomotic_version is non-empty ────────────────────────────────


def test_nomotic_version_non_empty(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert isinstance(scorecard.nomotic_version, str)
    assert len(scorecard.nomotic_version) > 0


# ── Test 14: to_json() produces valid JSON ───────────────────────────────


def test_to_json_valid(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    result = scorecard.to_json()
    parsed = json.loads(result)  # should not raise
    assert isinstance(parsed, dict)


# ── Test 15: to_json() contains agent_id ─────────────────────────────────


def test_to_json_contains_agent_id(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    result = scorecard.to_json()
    parsed = json.loads(result)
    assert parsed["agent_id"] == "test-agent"


# ── Test 16: to_html() returns a non-empty string ────────────────────────


def test_to_html_non_empty(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    html = scorecard.to_html()
    assert isinstance(html, str)
    assert len(html) > 0


# ── Test 17: to_html() contains "Scorecard" ──────────────────────────────


def test_to_html_contains_scorecard(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    html = scorecard.to_html()
    assert "Scorecard" in html


# ── Test 18: to_html() contains agent_id ─────────────────────────────────


def test_to_html_contains_agent_id(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    html = scorecard.to_html()
    assert "test-agent" in html


# ── Test 19: to_html() contains all 7 required sections ─────────────────


def test_to_html_contains_all_sections(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    html = scorecard.to_html()
    assert "Governance Scorecard" in html
    assert "Agent Identity" in html
    assert "Behavioral Summary" in html
    assert "Compliance Framework Mapping" in html
    assert "Gap Analysis" in html
    assert "Archetype Benchmark" in html
    assert "Generated by Nomotic" in html


# ── Test 20: generate() with no evaluations handles gracefully ───────────


def test_generate_no_evaluations(tmp_path: Path) -> None:
    _store, gen = _setup_agent_with_records(tmp_path, records=[])
    scorecard = gen.generate("test-agent")
    assert scorecard.evaluation_summary["total"] == 0
    assert scorecard.allow_rate == 0.0
    assert scorecard.deny_rate == 0.0
    assert scorecard.escalate_rate == 0.0
    assert scorecard.average_ucs == 0.0


# ── Additional tests ─────────────────────────────────────────────────────


def test_generate_raises_for_unknown_agent(tmp_path: Path) -> None:
    store = LogStore(tmp_path, "audit")
    gen = GovernanceScorecardGenerator(tmp_path, store)
    with pytest.raises(ValueError, match="Agent not found"):
        gen.generate("nonexistent-agent")


def test_hipaa_framework(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent", framework="hipaa")
    assert all(cm.framework == "hipaa" for cm in scorecard.compliance_mapping)


def test_to_dict_datetime_serialized(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    d = scorecard.to_dict()
    # datetimes should be ISO strings
    assert isinstance(d["generated_at"], str)
    assert isinstance(d["certificate_issued_at"], str)
    # Should be parseable
    datetime.fromisoformat(d["generated_at"])
    datetime.fromisoformat(d["certificate_issued_at"])


def test_verdict_counting_accuracy(tmp_path: Path) -> None:
    records = [
        _make_audit_record(verdict="ALLOW", ts_offset=1),
        _make_audit_record(verdict="ALLOW", ts_offset=2),
        _make_audit_record(verdict="DENY", ts_offset=3),
        _make_audit_record(verdict="ESCALATE", ts_offset=4),
        _make_audit_record(verdict="BLOCK", ts_offset=5),
    ]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    assert scorecard.evaluation_summary["total"] == 5
    assert scorecard.evaluation_summary["allow"] == 2
    assert scorecard.evaluation_summary["deny"] == 1
    assert scorecard.evaluation_summary["escalate"] == 1
    assert scorecard.evaluation_summary["block"] == 1


def test_average_ucs_computation(tmp_path: Path) -> None:
    records = [
        _make_audit_record(ucs=0.5, ts_offset=1),
        _make_audit_record(ucs=0.7, ts_offset=2),
        _make_audit_record(ucs=0.9, ts_offset=3),
    ]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    expected_avg = (0.5 + 0.7 + 0.9) / 3
    assert abs(scorecard.average_ucs - expected_avg) < 1e-9


def test_benchmark_uses_archetype_baseline(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(
        tmp_path, archetype="healthcare-agent", records=records
    )
    scorecard = gen.generate("test-agent")
    assert scorecard.archetype_benchmark.baseline_deny_rate == 0.12
    assert scorecard.archetype_benchmark.baseline_ucs_avg == 0.71


def test_benchmark_default_archetype(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(
        tmp_path, archetype="unknown-archetype", records=records
    )
    scorecard = gen.generate("test-agent")
    # Should fall back to "default"
    assert scorecard.archetype_benchmark.baseline_deny_rate == 0.10


def test_to_html_print_media(tmp_path: Path) -> None:
    records = [_make_audit_record()]
    _store, gen = _setup_agent_with_records(tmp_path, records=records)
    scorecard = gen.generate("test-agent")
    html = scorecard.to_html()
    assert "@media print" in html


def test_cli_parser_scorecard_command() -> None:
    from nomotic.cli import build_parser

    parser = build_parser()
    args = parser.parse_args([
        "scorecard",
        "--agent", "test-agent",
        "--framework", "hipaa",
        "--days", "7",
        "--format", "json",
        "--output", "out.json",
    ])
    assert args.command == "scorecard"
    assert args.agent == "test-agent"
    assert args.framework == "hipaa"
    assert args.days == 7
    assert args.output_format == "json"
    assert args.output == "out.json"


def test_cli_parser_scorecard_defaults() -> None:
    from nomotic.cli import build_parser

    parser = build_parser()
    args = parser.parse_args(["scorecard", "--agent", "my-agent"])
    assert args.command == "scorecard"
    assert args.agent == "my-agent"
    assert args.framework == "soc2"
    assert args.days == 30
    assert args.output_format == "html"
    assert args.output is None
