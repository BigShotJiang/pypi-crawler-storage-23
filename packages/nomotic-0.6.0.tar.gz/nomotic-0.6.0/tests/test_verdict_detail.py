"""Tests for the Decision Explainability verdict detail endpoint (F-04).

Covers: GET /v1/ui/verdict/{record_id} JSON responses, dimension breakdown,
action-to-pass logic for all verdict types, trust trajectory, and modifiers.
"""

import json
import threading
import time
import uuid
import urllib.request
import urllib.error
from pathlib import Path
from tempfile import mkdtemp

from nomotic.api import NomoticAPIServer, _DIMENSION_META
from nomotic.audit_store import AuditStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator
from nomotic.store import MemoryCertificateStore


def _setup_server(base_dir: Path | None = None):
    """Create a running API server for testing verdict detail."""
    sk, _vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(issuer_id="test", signing_key=sk, store=store)

    if base_dir is None:
        base_dir = Path(mkdtemp())

    server = NomoticAPIServer(
        ca,
        archetype_registry=ArchetypeRegistry.with_defaults(),
        zone_validator=ZoneValidator(),
        org_registry=OrganizationRegistry(),
        host="127.0.0.1",
        port=0,
        base_dir=base_dir,
        ui_enabled=True,
    )
    httpd = server._build_server()
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    return httpd, port, base_dir


def _get_json(port: int, path: str) -> tuple[int, dict | list]:
    """GET request that parses JSON response."""
    url = f"http://127.0.0.1:{port}{path}"
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def _seed_record(
    base_dir: Path,
    *,
    record_id: str = "",
    agent_id: str = "test-agent",
    verdict: str = "ALLOW",
    ucs: float = 0.85,
    action_type: str = "file.read",
    action_target: str = "/data/test.txt",
    tier: int = 1,
    trust_score: float = 0.7,
    dimension_scores: dict | None = None,
    vetoed_by: list | None = None,
    parameters: dict | None = None,
) -> str:
    """Seed a single audit record and return the record_id."""
    audit = AuditStore(base_dir)
    rid = record_id or f"rec-{uuid.uuid4().hex[:12]}"
    record = PersistentLogRecord(
        record_id=rid,
        timestamp=time.time(),
        agent_id=agent_id,
        action_type=action_type,
        action_target=action_target,
        verdict=verdict,
        ucs=ucs,
        tier=tier,
        trust_score=trust_score,
        trust_delta=0.01,
        trust_trend="stable",
        severity="info" if verdict == "ALLOW" else "alert",
        justification=f"Test {verdict} evaluation",
        vetoed_by=vetoed_by or [],
        dimension_scores=dimension_scores or {},
        parameters=parameters or {"archetype": "test-archetype", "latency_ms": 1.5},
    )
    prev_hash = audit.get_last_hash(agent_id)
    record.previous_hash = prev_hash
    record.record_hash = audit.compute_hash(record.to_dict(), prev_hash)
    audit.append(record)
    return rid


def _seed_veto_record(base_dir: Path, agent_id: str = "test-agent") -> str:
    """Seed a DENY record with a veto dimension (scope_compliance=0.0)."""
    dim_scores = {m["name"]: 0.8 for m in _DIMENSION_META}
    dim_scores["scope_compliance"] = 0.0
    return _seed_record(
        base_dir,
        agent_id=agent_id,
        verdict="DENY",
        ucs=0.0,
        action_target="patient_records",
        dimension_scores=dim_scores,
        vetoed_by=["scope_compliance"],
    )


def _seed_ucs_shortfall_record(base_dir: Path, agent_id: str = "test-agent") -> str:
    """Seed a DENY record with UCS shortfall (no veto)."""
    dim_scores = {m["name"]: 0.4 for m in _DIMENSION_META}
    dim_scores["scope_compliance"] = 0.3
    dim_scores["authority_verification"] = 0.2
    dim_scores["behavioral_consistency"] = 0.5
    return _seed_record(
        base_dir,
        agent_id=agent_id,
        verdict="DENY",
        ucs=0.31,
        dimension_scores=dim_scores,
        vetoed_by=[],
    )


def _seed_escalate_record(base_dir: Path, agent_id: str = "test-agent") -> str:
    """Seed an ESCALATE record."""
    dim_scores = {m["name"]: 0.6 for m in _DIMENSION_META}
    return _seed_record(
        base_dir,
        agent_id=agent_id,
        verdict="ESCALATE",
        ucs=0.55,
        dimension_scores=dim_scores,
        vetoed_by=[],
    )


def _seed_block_record(base_dir: Path, agent_id: str = "test-agent") -> str:
    """Seed a BLOCK record (constitutional rule)."""
    dim_scores = {m["name"]: 0.7 for m in _DIMENSION_META}
    return _seed_record(
        base_dir,
        agent_id=agent_id,
        verdict="BLOCK",
        ucs=0.0,
        dimension_scores=dim_scores,
        vetoed_by=[],
    )


# ── Test class ──────────────────────────────────────────────────────────


class TestVerdictDetail:
    """Tests for GET /v1/ui/verdict/{record_id}."""

    def test_01_returns_200_for_existing_record(self):
        """Test 1: GET /v1/ui/verdict/{id} returns 200 for existing record."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            status, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            assert status == 200
            assert data["record_id"] == rid
        finally:
            httpd.shutdown()

    def test_02_returns_404_for_unknown_record(self):
        """Test 2: GET /v1/ui/verdict/{id} returns 404 for unknown record_id."""
        httpd, port, _ = _setup_server()
        try:
            status, data = _get_json(port, "/v1/ui/verdict/nonexistent-id")
            assert status == 404
            assert data["error"] == "not_found"
        finally:
            httpd.shutdown()

    def test_03_response_contains_14_dimensions(self):
        """Test 3: Response contains exactly 14 dimensions."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            status, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            assert status == 200
            assert len(data["dimensions"]) == 14
        finally:
            httpd.shutdown()

    def test_04_dimension_required_fields(self):
        """Test 4: Each dimension has required fields."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            required = {"name", "score", "weight", "is_veto", "veto_triggered", "reasoning"}
            for dim in data["dimensions"]:
                assert required.issubset(dim.keys()), (
                    f"Dimension {dim.get('name')} missing fields: "
                    f"{required - set(dim.keys())}"
                )
        finally:
            httpd.shutdown()

    def test_05_veto_dimension_has_veto_triggered(self):
        """Test 5: Veto dimension with score=0.0 has veto_triggered=True."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_veto_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            scope_dim = next(
                d for d in data["dimensions"] if d["name"] == "scope_compliance"
            )
            assert scope_dim["score"] == 0.0
            assert scope_dim["veto_triggered"] is True
            assert scope_dim["is_veto"] is True
        finally:
            httpd.shutdown()

    def test_06_action_to_pass_veto(self):
        """Test 6: action_to_pass.type = 'veto' when veto_triggered."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_veto_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            atp = data["action_to_pass"]
            assert atp["type"] == "veto"
            assert atp["primary_dimension"] == "scope_compliance"
            assert len(atp["explanation"]) > 0
        finally:
            httpd.shutdown()

    def test_07_action_to_pass_ucs_shortfall(self):
        """Test 7: action_to_pass.type = 'ucs_shortfall' for DENY without veto."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_ucs_shortfall_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            atp = data["action_to_pass"]
            assert atp["type"] == "ucs_shortfall"
            assert "top_gaps" in atp
            assert len(atp["top_gaps"]) == 3
        finally:
            httpd.shutdown()

    def test_08_action_to_pass_escalation(self):
        """Test 8: action_to_pass.type = 'escalation' for ESCALATE verdict."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_escalate_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            atp = data["action_to_pass"]
            assert atp["type"] == "escalation"
            assert "deliberation range" in atp["explanation"]
        finally:
            httpd.shutdown()

    def test_09_action_to_pass_constitutional(self):
        """Test 9: action_to_pass.type = 'constitutional' for BLOCK verdict."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_block_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            atp = data["action_to_pass"]
            assert atp["type"] == "constitutional"
            assert "constitutional rule" in atp["explanation"]
        finally:
            httpd.shutdown()

    def test_10_ucs_shortfall_top3_sorted(self):
        """Test 10: UCS shortfall top-3 gaps are sorted (highest gap first)."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_ucs_shortfall_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            atp = data["action_to_pass"]
            gaps = atp["top_gaps"]
            gap_values = [g["gap"] for g in gaps]
            assert gap_values == sorted(gap_values, reverse=True), (
                f"Gaps not sorted: {gap_values}"
            )
        finally:
            httpd.shutdown()

    def test_11_trust_trajectory_list_of_floats(self):
        """Test 11: trust_trajectory is a list of floats, length >= 1."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            traj = data["trust_trajectory"]
            assert isinstance(traj, list)
            assert len(traj) >= 1
            assert all(isinstance(v, (int, float)) for v in traj)
        finally:
            httpd.shutdown()

    def test_12_weighted_contribution_math(self):
        """Test 12: weighted_contribution = weight * score for each dimension."""
        httpd, port, base_dir = _setup_server()
        try:
            dim_scores = {m["name"]: round(0.1 * (i + 1), 2) for i, m in enumerate(_DIMENSION_META)}
            rid = _seed_record(base_dir, dimension_scores=dim_scores)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            for dim in data["dimensions"]:
                expected = round(dim["weight"] * dim["score"], 4)
                assert dim["weighted_contribution"] == expected, (
                    f"{dim['name']}: expected {expected}, "
                    f"got {dim['weighted_contribution']}"
                )
        finally:
            httpd.shutdown()

    def test_13_contextual_modifiers_list(self):
        """Test 13: contextual_modifiers is a list (empty when no modifiers)."""
        httpd, port, base_dir = _setup_server()
        try:
            # Without modifiers
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            assert isinstance(data["contextual_modifiers"], list)
            assert data["contextual_modifiers"] == []

            # With modifiers
            rid2 = _seed_record(
                base_dir,
                parameters={
                    "archetype": "test",
                    "latency_ms": 1.0,
                    "contextual_modifiers": ["after_hours", "falling_trust"],
                },
            )
            _, data2 = _get_json(port, f"/v1/ui/verdict/{rid2}")
            assert isinstance(data2["contextual_modifiers"], list)
            assert "after_hours" in data2["contextual_modifiers"]
            assert "falling_trust" in data2["contextual_modifiers"]
        finally:
            httpd.shutdown()

    def test_14_action_to_pass_explanation_nonempty(self):
        """Test 14: action_to_pass.explanation is non-empty string for all verdict types."""
        httpd, port, base_dir = _setup_server()
        try:
            # ALLOW
            rid_allow = _seed_record(base_dir, verdict="ALLOW")
            _, d1 = _get_json(port, f"/v1/ui/verdict/{rid_allow}")
            assert isinstance(d1["action_to_pass"]["explanation"], str)
            assert len(d1["action_to_pass"]["explanation"]) > 0

            # DENY with veto
            rid_veto = _seed_veto_record(base_dir)
            _, d2 = _get_json(port, f"/v1/ui/verdict/{rid_veto}")
            assert isinstance(d2["action_to_pass"]["explanation"], str)
            assert len(d2["action_to_pass"]["explanation"]) > 0

            # DENY without veto
            rid_short = _seed_ucs_shortfall_record(base_dir)
            _, d3 = _get_json(port, f"/v1/ui/verdict/{rid_short}")
            assert isinstance(d3["action_to_pass"]["explanation"], str)
            assert len(d3["action_to_pass"]["explanation"]) > 0

            # ESCALATE
            rid_esc = _seed_escalate_record(base_dir)
            _, d4 = _get_json(port, f"/v1/ui/verdict/{rid_esc}")
            assert isinstance(d4["action_to_pass"]["explanation"], str)
            assert len(d4["action_to_pass"]["explanation"]) > 0

            # BLOCK
            rid_block = _seed_block_record(base_dir)
            _, d5 = _get_json(port, f"/v1/ui/verdict/{rid_block}")
            assert isinstance(d5["action_to_pass"]["explanation"], str)
            assert len(d5["action_to_pass"]["explanation"]) > 0
        finally:
            httpd.shutdown()

    def test_15_response_contains_all_top_level_fields(self):
        """Bonus: Response contains all expected top-level fields."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            expected_fields = {
                "record_id", "verdict", "ucs_score", "evaluation_tier",
                "latency_ms", "agent_id", "archetype", "timestamp",
                "action_type", "target", "dimensions",
                "contextual_modifiers", "trust_at_evaluation",
                "trust_trajectory", "action_to_pass",
                "chain_verified", "chain_position",
            }
            assert expected_fields.issubset(data.keys()), (
                f"Missing fields: {expected_fields - set(data.keys())}"
            )
        finally:
            httpd.shutdown()

    def test_16_dimension_names_match_dimensions_py(self):
        """Bonus: All 14 dimension names match those defined in dimensions.py."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            expected_names = {m["name"] for m in _DIMENSION_META}
            actual_names = {d["name"] for d in data["dimensions"]}
            assert actual_names == expected_names
        finally:
            httpd.shutdown()

    def test_17_htmx_returns_html(self):
        """Bonus: HTMX request returns HTML content."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            url = f"http://127.0.0.1:{port}/v1/ui/verdict/{rid}"
            req = urllib.request.Request(url)
            req.add_header("HX-Request", "true")
            with urllib.request.urlopen(req) as resp:
                assert resp.status == 200
                ct = resp.headers.get("Content-Type", "")
                assert "text/html" in ct
                body = resp.read().decode("utf-8")
                assert "verdict-detail" in body
                assert rid in body
        finally:
            httpd.shutdown()

    def test_18_chain_verification_present(self):
        """Bonus: chain_verified and chain_position are in the response."""
        httpd, port, base_dir = _setup_server()
        try:
            rid = _seed_record(base_dir)
            _, data = _get_json(port, f"/v1/ui/verdict/{rid}")
            assert isinstance(data["chain_verified"], bool)
            assert isinstance(data["chain_position"], int)
            assert data["chain_position"] >= 1
        finally:
            httpd.shutdown()
