"""OpenAI SDK + Nomotic: governed function-calling example.

Shows how to use GovernedAgentBase to wrap OpenAI function/tool calls
with governance evaluation before execution.

Requires: pip install openai nomotic
"""

from __future__ import annotations

from typing import Any, Callable

from nomotic.governed_agent import GovernedAgentBase, GovernanceVetoError


def governed_tool_call(
    governed_agent: GovernedAgentBase,
    tool_name: str,
    tool_args: dict[str, Any],
    tool_fn: Callable[..., str],
) -> str:
    """Govern an OpenAI function/tool call before execution.

    Wrap your tool call dispatch loop with this function.
    """
    try:
        return governed_agent.governed_run(
            action_type=tool_name,
            target=tool_args.get("target", tool_name),
            parameters=tool_args,
            execute_fn=lambda: tool_fn(**tool_args),
        )
    except GovernanceVetoError as e:
        # Return the veto as a tool result so the model can explain it
        return (
            f"[GOVERNANCE VETO: {e.verdict}] "
            f"This action was blocked by governance policy. "
            f"UCS score: {e.ucs_score:.2f}."
        )


# See https://docs.nomotic.ai/guides/openai for complete guide.
