"""CrewAI + Nomotic: governed crew task example.

Shows how to use GovernedAgentBase to wrap CrewAI tasks with
pre-execution governance and output validation.

Requires: pip install crewai nomotic
"""

from __future__ import annotations

from typing import Any, Callable, TYPE_CHECKING

from nomotic.governed_agent import GovernedAgentBase, GovernanceVetoError

if TYPE_CHECKING:
    from crewai import Agent, Task


class GovernedCrewTask:
    """Wraps a CrewAI task with pre-execution governance."""

    def __init__(self, governed_agent: GovernedAgentBase):
        self.governed = governed_agent

    def execute(
        self,
        action_type: str,
        target: str,
        task_fn: Callable[[], str],
        parameters: dict[str, Any] | None = None,
    ) -> str:
        try:
            return self.governed.governed_run(
                action_type=action_type,
                target=target,
                parameters=parameters,
                execute_fn=task_fn,
            )
        except GovernanceVetoError as e:
            raise RuntimeError(
                f"Task blocked by governance: {e.verdict} "
                f"(UCS {e.ucs_score:.2f})"
            ) from e


# See https://docs.nomotic.ai/guides/crewai for complete guide.
