# Nomotic Demo Script (7 minutes)

## Setup (before the demo)

```bash
pip install anthropic
export ANTHROPIC_API_KEY=sk-...
bash examples/setup_demo.sh
```

## Minute 0-1: Setup (show while talking)

- Show `nomotic setup` and `nomotic birth --name demo-agent`
- Show `nomotic scope demo-agent set --actions read,write --boundaries customers,orders`
- Point: "This agent can read and write to customers and orders. Nothing else."

## Minute 1-3: Normal Operations

- Run the agent with normal customer queries
- Show trust rising: 0.500 → 0.510 → 0.520 → 0.530
- Point: "The agent is doing exactly what it should. Trust builds."

## Minute 3-5: Boundary Pushing

- Run the agent with boundary-pushing tasks
- Show the first denial: "read → employee_salaries — DENY by isolation_integrity"
- Show trust dropping: 0.530 → 0.480 → 0.430
- Point: "Each denial costs 5x more than a success earns. Two denials erased everything."
- Show the agent adapting: "I can't access that table. Let me work with what I have."

## Minute 5-6: Audit Trail

- Run `nomotic audit demo-agent` — show the full record
- Run `nomotic audit demo-agent --verify` — show chain integrity
- Point: "Every action is recorded with a hash chain. Tamper with one record and the whole chain breaks."

## Minute 6-7: The Tamper Test

- Open the JSONL file, change a DENY to ALLOW
- Run `nomotic audit demo-agent --verify` again
- Show: "TAMPERING DETECTED at record #7"
- Point: "This is immutable history. You can't rewrite it."

## Close

"Nomotic governs agent actions at runtime. Trust evolves based on behavior.
The audit trail is tamper-proof. And the agent never knew we were there."
