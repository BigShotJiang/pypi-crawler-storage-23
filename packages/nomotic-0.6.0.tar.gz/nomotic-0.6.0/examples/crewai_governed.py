#!/usr/bin/env python3
"""CrewAI + Nomotic Governance Example.

Shows how to add Nomotic governance to an existing CrewAI agent
with a single function call. Every tool invocation is evaluated
through the 14-dimension governance pipeline before execution.

Prerequisites:
    pip install nomotic crewai

Usage:
    python examples/crewai_governed.py
"""

from __future__ import annotations

# ── Step 1: Define your tools as usual ───────────────────────────────

# In a real project these would be crewai.tools.BaseTool subclasses.
# Here we use simple mock tools to demonstrate the pattern.


class MockTool:
    """Minimal stand-in for a CrewAI tool."""

    def __init__(self, name: str):
        self.name = name

    def _run(self, *args, **kwargs):
        return f"[{self.name}] executed with args={args} kwargs={kwargs}"


search_tool = MockTool("web_search")
file_tool = MockTool("read_file")
db_tool = MockTool("query_db")

# Your original tools list
tools = [search_tool, file_tool, db_tool]

# ── Step 2: Add governance (3 lines) ────────────────────────────────

from nomotic.integrations.crewai_adapter import govern_crewai_tools  # noqa: E402

# One call wraps every tool in governance evaluation.
# In production, omit test_mode to use real certificates and audit logs.
governed_tools = govern_crewai_tools(
    "claims-bot",         # Nomotic agent identity
    tools,                # your existing CrewAI tools
    test_mode=True,       # use simulated trust (no config files needed)
)

# ── Step 3: Use governed tools exactly like before ───────────────────

# In a real CrewAI project:
#   agent = Agent(role="Researcher", tools=governed_tools, ...)
#
# Here we call the tools directly to show what happens:

if __name__ == "__main__":
    print("CrewAI + Nomotic Governance Demo")
    print("=" * 50)

    for tool in governed_tools:
        result = tool._run("test-query")
        print(f"\n  Tool: {tool.name}")
        print(f"  Result: {result}")

    print()
    print("Each tool call above was evaluated through Nomotic's")
    print("14-dimension governance pipeline before execution.")
