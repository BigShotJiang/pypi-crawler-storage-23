"""LangGraph + Nomotic: governed state-machine agent example.

Shows how to use GovernedAgentBase to wrap LangGraph graph nodes
with pre-execution governance and post-generation output validation.

Requires: pip install langgraph nomotic
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from nomotic.governed_agent import GovernedAgentBase, GovernanceVetoError
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.store import MemoryCertificateStore
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey

if TYPE_CHECKING:
    from langgraph.graph import StateGraph


def build_governed_graph(governed_agent: GovernedAgentBase):
    """Build a LangGraph StateGraph where each tool node is governed."""
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        raise ImportError("pip install langgraph")

    # Example: two-node graph — read node, write node

    def governed_read_node(state: dict) -> dict:
        try:
            result = governed_agent.governed_run(
                action_type="read",
                target=state.get("target", "data_source"),
                execute_fn=lambda: f"[Data from {state.get('target')}]",
            )
            return {**state, "read_result": result}
        except GovernanceVetoError as e:
            return {**state, "error": str(e), "vetoed": True}

    def governed_write_node(state: dict) -> dict:
        if state.get("vetoed"):
            return state
        try:
            result = governed_agent.governed_run(
                action_type="write",
                target=state.get("target", "data_sink"),
                execute_fn=lambda: "write complete",
            )
            return {**state, "write_result": result}
        except GovernanceVetoError as e:
            return {**state, "error": str(e), "vetoed": True}

    graph = StateGraph(dict)
    graph.add_node("read", governed_read_node)
    graph.add_node("write", governed_write_node)
    graph.set_entry_point("read")
    graph.add_edge("read", "write")
    graph.add_edge("write", END)
    return graph.compile()


# See https://docs.nomotic.ai/guides/langgraph for complete guide.
