#!/bin/bash
# Setup Nomotic for the demo agent.
#
# Run this before running the demo:
#   bash examples/setup_demo.sh
#   python examples/demo_agent.py

set -e

echo "Setting up Nomotic demo agent..."
echo ""

# Create the agent
nomotic birth --name demo-agent

# Set scope: can read and write to customers and orders only
nomotic scope demo-agent set \
    --actions read,write \
    --boundaries customers,orders

# Show the agent
nomotic inspect demo-agent

echo ""
echo "Demo agent ready. Run: python examples/demo_agent.py"
