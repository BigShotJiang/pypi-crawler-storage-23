# Changelog

All notable changes to Nomotic will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] — 2026-02-27

**Theme: Organizational Governance**
**PRs:** 33 (#68–#100) | **Tests:** 4,002 | **New modules:** 10

### New Features

- **Dimension 14: Jurisdictional Compliance** — Data residency and cross-border
  transfer governance with GDPR, CCPA, HIPAA, PIPL, PDPA, DPDPA support
- **Constitutional Rules Engine** — Immutable hard constraints layer, HMAC-signed,
  tamper-evident, enforced before all other governance
- **Governance Authority Registry** — Formal executable decision rights with 6 roles;
  all config changes attributed and enforced
- **Role-Based Override Permissions** — Scoped by zone, archetype, action type, risk tier
- **Multi-Signature Override Authorization** — M-of-N co-signature with TTL windows
- **Output Validation Governor** — PII detection, scope validation, content safety,
  confidence and instruction checks on agent outputs
- **Agent Lifecycle Hooks** — BIRTH, DEGRADED, CRITICAL, RETIREMENT, REVOCATION events
- **Fleet Governance API** — Fleet-wide health, trust distribution, denial analytics
- **Fleet Cost Aggregation** — Per-agent and group cost tracking, projections,
  7-day trends, acceleration alerts
- **UAHS Auto-Integration** — Configurable health scoring, drift alerting,
  per-archetype thresholds, and reset capability
- **Pre-Evaluation State Continuity Checks** — Governance infrastructure integrity
  probes before each evaluation
- **Pre-Execution Budget Gate** — Cost reservations with TTL, UAHS health adjustment
- **Immutable Pre-Execution Record** — Hash-chained ledger bridging approval to execution
- **Workflow Seal Chaining** — Cryptographic continuity across multi-step workflows
- **Cross-Workflow Dependency Checking** — Prerequisite enforcement with age constraints
- **Foundation Model Provenance** — Model identity bound to agent certificates
- **Webhook HMAC Signing + Delivery Queue** — Signed delivery, exponential backoff
  retry, drain queue stats
- **Custom Compliance Framework Loading** — Organization-defined regulatory mappings
- **Policy Dry-Run + Override Simulation** — Historical what-if analysis
- **Constitutional Rules Dry-Run** — Pre-deployment ruleset simulation
- **Delegation Chain Visualization** — ASCII/DOT rendering, violation detection
- **Compliance Gap Analysis** — Per-control scoring against framework thresholds
- **Tamper-Resistant Config Backups** — HMAC-signed backups with Doctor integration

### Breaking Changes
None. All new features are opt-in via RuntimeConfig.

Note: Existing code expecting 13 dimension scores should be updated to handle 14.


## [0.4.0] — 2026-02-23

**Release Theme: Authority and Evidence**

v0.4.0 transforms Nomotic from a governance evaluation engine into a complete runtime governance infrastructure. Every approved action now produces a signed, verifiable authorization artifact. Governance decisions are exportable as examiner-ready compliance evidence. Irreversible actions face stricter gates automatically. A new meta-level monitoring layer detects behavioral drift invisible to raw action tracking. 17 pull requests. 2,995 tests passing.

### New Modules

- **`seal.py`** — Governance Seal: cryptographically signed authorization artifacts proving governance approval. Seals carry agent identity, verdict context, trust level, reversibility classification, and TTL. Single-use enforcement via `SealRegistry`. Compact Base64 form for HTTP header transport.
- **`cost.py`** — Cost Projection: per-agent execution cost estimation from observed duration. `CostProfile` and `CostTracker` with advisory threshold alerts. Non-blocking monitoring signal only.
- **`compliance_report.py`** — Compliance Report Generator: maps Nomotic's 14 governance dimensions to 40+ controls across 7 regulatory frameworks (SOC 2, HIPAA, EU AI Act, ISO 27001, NIST AI RMF, NIST CSF for AI, IMDA Agentic AI). Markdown and JSON output. Includes governance stack layer coverage summary.
- **`doctor.py`** — Infrastructure Health Diagnostics: `nomotic doctor` validates installation, configuration, certificate store, audit trail hash-chain integrity, and signing keys. `--fix`, `--json`, and `--quiet` flags. Exit code 1 on errors for CI/CD integration.
- **`loop_detector.py`** — Loop Detection Monitor: tracks repetitive action patterns within a sliding time window. Trust decay at configurable warning threshold; execution halt at halt threshold. Exempt action types (read, list, get, query) configurable. Integrates with `InterruptAuthority`.
- **`policy.py`** — Policy-as-Code: declarative YAML/JSON governance policies evaluated as a Tier 0 pre-filter before dimensional evaluation. Policies can DENY or ESCALATE — they cannot ALLOW. Field matching supports wildcards, dotted-path resolution, numeric comparisons, and list membership. JSON-native (no required dependencies); YAML requires optional PyYAML.
- **`webhooks.py`** — Governance Event Webhooks: push governance events to external systems (Slack, PagerDuty, SIEM) in real time. 9 event types: `DENY`, `SUSPEND`, `DRIFT_ALERT`, `TRUST_DROP`, `SEAL_EXPIRED`, `OVERRIDE_APPROVE`, `OVERRIDE_REVOKE`, `CHAIN_BREAK`, `LOOP_DETECTED`. Fire-and-forget with retry and per-endpoint rate limiting.
- **`delegation.py`** — Multi-Agent Delegation Tracking: `DelegationRecord` and `DelegationTracker` capture delegation chains between agents. Scope validation (delegating agent cannot grant scope it doesn't hold). Certificate validation for both parties. Target pattern matching (exact, wildcard, prefix). Hash-chained audit records.
- **`drift.py`** (additions) — Ambiguity Drift Detection and Unified Agent Health Score: `AmbiguityDriftObserver` monitors the distribution of governance decision confidence scores as an independent meta-level drift dimension. `UnifiedHealthScoreCalculator` synthesizes behavioral drift, oversight quality drift, and ambiguity health into a 0–100 composite score with named status classifications. `FeedbackLoopManager` closes the loop: UAHS threshold crossings trigger trust calibration adjustments and ambiguity band narrowing. Dynamic weight boost (ambiguity → 45%) when compound erosion alarm is active.
- **`ucs_tracker.py`** — Thin integration wrapper connecting governance evaluation outputs to `AmbiguityDriftObserver`. Supports per-agent registration with delegation chain band inheritance.
- **`integrations/agicomply.py`** — AGICOMPLY Integration: push hash-chained audit records to AGICOMPLY's runtime governance ingestion API. `nomotic audit --push-agicomply` CLI flag.

### Modified Modules

- **`reversibility.py`** — `ReversibilityConfig` dataclass. Irreversible actions: UCS threshold +0.15, mandatory Tier 3 deliberation, seal TTL capped at 10s. `TIME_BOUNDED` actions: UCS threshold +0.05, seal TTL capped at reversibility window. `UNKNOWN` treated as `IRREVERSIBLE` by default.
- **`seal.py`** — Certificate cross-verification: `cert_id` and `cert_fingerprint` embedded in signed payload. `verify_seal()` checks live certificate status — revoking or suspending an agent immediately invalidates outstanding seals. New `SealVerificationResult` dataclass with cross-verify fields. New `CertificateStatusError` exception.
- **`runtime.py`** — `seal()` method; reversibility-aware governance modifiers; `override()` method for post-hoc APPROVE/REVOKE; `delegate()` and `get_delegation_chain()` methods; `PolicyEngine` pre-filter integration (Tier 0); `WebhookDispatcher` initialization and `configure_webhooks()`.
- **`executor.py`** — `execute_sealed()` method; `require_seal` parameter; seal validation (signature, TTL, agent match, single-use); cost tracking via `CostTracker`; `loop_detected` and `loop_count` fields on `ExecutionResult`.
- **`async_executor.py`** — `execute_sealed()` async method.
- **`audit_store.py`** — `seal_id` field on `PersistentLogRecord`; `find_by_action_id()` on `AuditStore`; `GovernanceHealthRecord` dataclass with hash chain fields and UAHS delta tracking; `GovernanceHealthStore` class with `append_health_event()`, `query_health()`, `verify_health_chain()`.
- **`proxy.py`** — Certificate-required mode: `require_certificate` flag, `_resolve_agent_identity()` via headers or static IP map, 403 with specific reason codes.
- **`mcp_proxy.py`** — Certificate-required mode; `/health` endpoint (HTTP 503 when upstream unreachable); `/metrics` endpoint (Prometheus text format); structured JSON logging with request IDs; per-tool configurable timeouts; graceful shutdown with 5-second drain on SIGTERM/SIGINT.
- **`cli.py`** — New commands: `nomotic doctor`, `nomotic cost`, `nomotic compliance-report`, `nomotic override`, `nomotic policy-validate`. New flags: `audit --delegations`, `audit --push-agicomply`, `status --policies`, `mcp-proxy --require-certificate`, `proxy --require-certificate`, `mcp-proxy --timeout`, `proxy --timeout`.
- **`certificate.py`** — `CertificateStatusError` exception.
- **`types.py`** — `GovernanceOverrideRecord`, `DelegationRecord` dataclasses.
- **`__init__.py`** — Version bump to 0.4.0. New exports: `GovernanceSeal`, `SealRegistry`, `seal_action`, `CertificateStatusError`, `SealVerificationResult`, `verify_seal`, `CostProfile`, `CostTracker`, `ComplianceReport`, `ComplianceReportGenerator`, `DoctorCheck`, `DoctorReport`, `LoopDetector`, `LoopDetectorConfig`, `LoopEvent`, `PolicyEngine`, `PolicyResult`, `PolicyRule`, `WebhookConfig`, `WebhookDispatcher`, `WebhookEvent`, `WEBHOOK_EVENT_TYPES`, `DelegationRecord`, `DelegationTracker`, `GovernanceOverrideRecord`, `AGICOMPLYClient`, `AGICOMPLYConfig`, `AGICOMPLYError`, `AmbiguityDriftObserver`, `AmbiguityDriftConfig`, `AmbiguityDriftProfile`, `UnifiedAgentHealthScore`, `UnifiedHealthScoreCalculator`, `FeedbackLoopManager`, `compute_ambiguity_health_score`, `UCSTracker`, `GovernanceHealthRecord`, `GovernanceHealthStore`, `persist_health_events`.
- **`Chart.yaml`** — Version bump to 0.4.0.

### Doctor Fix — Audit Trail Forensic Protection (#56)

`nomotic doctor --fix` will not auto-modify audit trail errors. Audit trail data is forensic evidence. Chain breaks and tampering detections require manual investigation. A dedicated warning is shown when `--fix` encounters audit errors, distinguishing them from fixable configuration issues.

### Breaking Changes

None. All changes are additive. Existing `evaluate()` calls, executor usage, audit records, and certificate operations are backward compatible.

- `seal_id` field in `PersistentLogRecord` defaults to `""` — existing audit records deserialize correctly.
- `GovernanceSeal.from_dict()` handles legacy JSON without `cert_id`/`cert_fingerprint` fields.
- `execute()` behavior unchanged when `require_seal=False` (default).
- Policy pre-filter is inactive by default — no `nomotic-policies/` directory means no policy evaluation.

### Test Coverage

2,995 tests passing across 72 test files. Target was 2,800+.

---

## [0.3.2] - 2026-02-19

### Added
- `nomotic new` command to generate project-level `nomotic.yaml` files interactively or via flags
- `nomotic inspect --brief` flag for quick agent operational summary
- `nomotic inspect --raw` flag for raw certificate JSON dump

### Changed
- **CLI rename:** `nomotic settings` → `nomotic status` (global system/org/preset display)
- **CLI consolidation:** `nomotic config <agent-id>`, `nomotic inspect <cert-id>`, and `nomotic status <cert-id>` are now unified under `nomotic inspect <agent-id>` with `--brief` and `--raw` flags
- `nomotic config` now only handles `nomotic config set` (global configuration changes)

### Removed
- `nomotic configure` command (was alias for `config`, no longer needed)
- `nomotic config <agent-id>` display mode (replaced by `nomotic inspect <agent-id>`)
- `nomotic status <cert-id>` as a separate command (replaced by `nomotic inspect --brief`)
- `nomotic settings` command name (replaced by `nomotic status`)

---

## [0.3.1] - 2026-02-18

### Fixed
- Added missing org_governance module exports to public API (`OrgGovernanceConfig`, `enforce_org_policy`, `load_org_config`, `save_org_config`, `generate_org_config_from_preset`, `OrgViolation`)
- Synced `__version__` in `nomotic/__init__.py` with package version

### Added
- Example governance configs in `examples/configs/` (simple agent, healthcare/HIPAA, fintech/SOC2+PCI-DSS, org governance)
- This changelog

---

## [0.3.0] - 2026-02-18

### Added
- **Compliance-aligned governance presets** (`nomotic/presets.py`)
  - 4 compliance framework presets: `soc2_aligned`, `hipaa_aligned`, `pci_dss_aligned`, `iso27001_aligned`
  - 3 severity tier presets: `standard`, `strict`, `ultra_strict`
  - `GovernancePreset` dataclass with validation, disclaimers, and framework metadata
  - `merge_presets()` for combining multiple presets (max weights, union vetoes, strictest thresholds)
  - `RuntimeConfig.from_preset()` class method for runtime integration
  - Legal protection: `_aligned` suffix naming, `PRESET_DISCLAIMER`, `certified=False` metadata

- **YAML configuration loader** (`nomotic/config_loader.py`)
  - `nomotic.yaml` file format with `extends` support for preset inheritance
  - Resolution order: standard defaults → preset chain → explicit YAML overrides
  - Weight merging (partial override) and veto replacement (full override) semantics
  - Helpful error messages with suggestions for invalid preset names
  - `GovernanceConfig` and `AgentDefinition` dataclasses
  - File discovery with recursive search (max depth 3)

- **Organization-level governance** (`nomotic/org_governance.py`)
  - Two-tier system: org minimums (enforced) + agent configs (must comply)
  - `OrgGovernanceConfig` with minimum weights, required vetoes, threshold floors, trust constraints
  - `enforce_org_policy()` checks across 8 violation categories
  - Directory-walking config discovery (`nomotic-org.yaml`)
  - Preset-based org config generation

- **`nomotic validate` CLI command**
  - 11-check validation pipeline: YAML parse, schema, preset resolution, dimensions, thresholds, trust, agent scope, logical checks, org policy, simulation
  - Logical checks: veto-weight contradictions, overprivileged agents, trust floor issues
  - Compliance preset disclaimers in output
  - `--strict`, `--preset`, `--org`, `--json`, `--quiet` flags
  - Exit codes: 0 (pass), 1 (fail), 2 (parse error)

- **`nomotic settings` CLI command**
  - Read-only inspection of effective governance configuration
  - Preset listing by category with compliance disclaimers
  - Detailed preset view with all 13 weights, vetoes, thresholds, trust settings
  - Org governance display with minimum weights and required vetoes

- **Extended `nomotic setup` wizard**
  - Compliance framework selection (SOC2, HIPAA, PCI-DSS, ISO27001, multiple)
  - Default severity tier selection (standard, strict, ultra_strict)
  - Optional org governance config generation from selected presets
  - Re-run preservation of previous selections

### Removed
- Backward compatibility aliases for preset names (PR #40). Only canonical `_aligned` names accepted.

---

## [0.2.0] - 2026-02-10

### Added
- nomotic-ci GitHub Action integration
- CI/CD validation pipeline
- Initial CLI commands (`birth`, `audit`, `config`, `setup`)

---

## [0.1.0] - 2026-01-31

### Added
- Initial release
- 14-dimension governance evaluation framework
- Three-tier evaluation pipeline (UCS gate, evaluator, deliberator)
- GovernanceRuntime with full evaluation, execution monitoring, and audit trail
- Trust calibration system with dynamic trust scores
- Interrupt authority with execution handles
- Agent certificates and certificate authority
- Behavioral fingerprinting and drift detection
- Bidirectional drift detection (agent + human oversight)
- Nomotic Protocol with governance tokens and reasoning artifacts
- Equity analysis and bias detection
- Cross-dimensional signal detection
- Contextual modifier for dynamic weight adjustment
- Workflow governor for multi-step action sequences
- Context profiles for rich evaluation context
- Reversibility-aware governance
- MCP governance proxy
- HTTP governance proxy
- OpenTelemetry and Prometheus observability exporters
- SDK with GovernedAgent wrapper
- GovernedToolExecutor and async variant
- NomoticGateway middleware
- Hash-chained audit trail with provenance tracking
- Agent identity registry
- Framework adapters (LangGraph, CrewAI, AutoGen)

---

## [0.0.1] - 2026-01-01

### Added
- Setup