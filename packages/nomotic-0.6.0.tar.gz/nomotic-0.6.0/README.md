# Nomotic

**Behavioral Control Plane™ for AI Agents.**

[![PyPI version](https://img.shields.io/pypi/v/nomotic.svg)](https://pypi.org/project/nomotic/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Tests](https://git.nomotic.ai/nomotic/core/badges/main/pipeline.svg)](https://git.nomotic.ai/nomotic/core/-/pipelines)
[![Coverage](https://git.nomotic.ai/nomotic/core/badges/main/coverage.svg)](https://git.nomotic.ai/nomotic/core/-/commits/main)
[![Latest Release](https://git.nomotic.ai/nomotic/core/-/badges/release.svg)](https://git.nomotic.ai/nomotic/core/-/releases)

Nomotic™ is the Behavioral Control Plane™ for AI agents — governing how agents behave across 14 dimensions in real time, before every action, throughout the full governance lifecycle. Most governance operates before deployment or after incidents. Nomotic operates during execution, continuously, at agent speed. It prevents unauthorized decisions, unauthorized actions, and unauthorized costs by evaluating every action, enforcing authority boundaries with hard vetoes, and maintaining mechanical authority to interrupt execution mid-action. If you cannot stop it, you do not control it.

## The Problem

AI agents don't just answer questions anymore. They execute transactions, modify records, call external APIs, delegate to other agents, and make decisions that carry real consequences. Governing this requires more than access controls and audit logs.

Most governance operates at the wrong time. Permissions are set before deployment. Incidents are reviewed after the fact. Nothing governs the moment an agent decides to act — the millisecond between intent and execution where real risk lives.

Nomotic fills that gap with multidimensional behavioral governance that operates continuously across the full agent lifecycle: before every action, during execution, and across the behavioral trajectory of each agent over time.

## Why Behavioral

Other control planes govern *requests* — they evaluate what an agent is asking to do and issue a verdict. Nomotic governs *behavior* — how an agent acts, how its behavior evolves, whether it's drifting from its established baseline, and whether the humans overseeing it are actually paying attention.

That distinction matters because the most dangerous failures in agentic AI aren't single unauthorized requests. They're patterns: gradual trust erosion, behavioral drift that compounds over hundreds of evaluations, human oversight that becomes rubber-stamping. Static rules and binary allow/deny verdicts can't detect or respond to those patterns. Behavioral governance can.

## Why Runtime

Static rules can't govern systems that learn and adapt. Nomotic uses [Dynamic Trust Calibration](https://git.nomotic.ai/nomotic/core/-/wikis/Trust-Calibration) that expands and contracts agent authority based on behavioral evidence — not configuration set once at deployment.

Pattern matching recognizes form but misses intent. Nomotic uses [14-Dimensional Simultaneous Evaluation](https://git.nomotic.ai/nomotic/core/-/wikis/14-Dimensions) across security, ethics, compliance, behavior, and authority — a multidimensional verdict on every action, not a binary rule check.

Post-incident review doesn't undo irreversible actions. Nomotic uses [Interrupt Authority](https://git.nomotic.ai/nomotic/core/-/wikis/Interrupt-Authority) to halt execution mid-action, with rollback and state recovery — governance that participates throughout the action lifecycle, not just at the start.

Human-in-the-loop fails when the human stops paying attention. Nomotic uses [Bidirectional Drift Detection](https://git.nomotic.ai/nomotic/core/-/wikis/Bidirectional-Drift-Detection) that monitors when agents drift *and* when human oversight degrades — the only governance system that watches both sides of the oversight relationship.

## Quick Start

```bash
pip install nomotic
```

### CLI Workflow

```bash
# 1. One-time setup: configure your org and compliance requirements
nomotic setup

# 2. Generate a governance config for your agent project
nomotic new

# 3. Validate before deploying
nomotic validate
```

`nomotic new` generates a `nomotic.yaml` in your project directory. Here's what a minimal config looks like:

```yaml
version: "1.0"
extends: "strict"

agents:
  my-agent:
    scope:
      actions: [read, write, query]
      targets: [customer_records]
      boundaries: [customer_records]
    trust:
      initial: 0.5
      minimum_for_action: 0.3
    owner: "team@company.com"
    reason: "Customer service agent"
```

This config inherits from the `strict` preset, which sets all 14 dimension weights, veto authorities, thresholds, and trust parameters. You only define what's unique to your agent.

### Python API

```python
from nomotic import GovernanceRuntime, RuntimeConfig, Action

# Create runtime from a preset — all 14 dimensions configured automatically
config = RuntimeConfig.from_preset("strict")
runtime = GovernanceRuntime(config)

# Every agent starts with a cryptographically signed birth certificate
cert = runtime.birth(
    agent_id="my-agent",
    agent_name="Customer Service Agent",
    archetype="customer-experience",
    scope=["read", "write", "query"],
    initial_trust=0.5,
)

# Every action goes through governance — before execution
action = Action(agent_id="my-agent", action_type="write", target="customer_records")
verdict = runtime.evaluate(action)

print(verdict.verdict)       # ALLOW, DENY, ESCALATE, or BLOCK
print(f"UCS: {verdict.ucs_score:.3f}")  # Unified compliance score (0.0–1.0)
print(f"Dimensions evaluated: {len(verdict.dimension_scores)}")  # 14
```

## What Nomotic Enforces

Nomotic governs AI agents at every level of the behavioral stack. Unauthorized actions are vetoed before execution — not logged for review afterward. Cost overruns are blocked before they happen. Agents that drift from expected behavior lose trust and autonomy automatically. Every governance decision is recorded in a cryptographic, hash-chained audit trail that proves what happened and why.

Every action is evaluated across 14 governance dimensions simultaneously:

| # | Dimension | What It Checks |
|---|-----------|---------------|
| 1 | Scope Compliance | Is this action within the agent's authorized scope? |
| 2 | Authority Verification | Does the agent have delegated authority for this? |
| 3 | Resource Boundaries | Does the action stay within resource limits? |
| 4 | Behavioral Consistency | Does this match the agent's established patterns? |
| 5 | Cascading Impact | Could this trigger downstream consequences? |
| 6 | Stakeholder Impact | Who is affected and how severely? |
| 7 | Incident Detection | Are there anomalous patterns suggesting problems? |
| 8 | Isolation Integrity | Does the action respect data and system isolation? |
| 9 | Temporal Compliance | Is the timing appropriate — rate limits, schedules? |
| 10 | Precedent Alignment | Is this consistent with prior governance decisions? |
| 11 | Transparency | Can the action and its reasoning be explained? |
| 12 | Human Override | Is human intervention required or available? |
| 13 | Ethical Alignment | Is the action justifiable beyond procedural compliance? |
| 14 | Jurisdictional Compliance | Does the action respect data residency and cross-border requirements? |

Each dimension scores independently from 0.0 to 1.0, weighted by configuration. Dimensions with **veto authority** enforce hard boundaries: if a veto dimension scores 0.0, the action is denied regardless of the overall score. No gray area, no debate, no exceptions.

Evaluation runs through a multi-stage pipeline. A constitutional rules gate and state continuity check run before any dimensional scoring. Full 14-dimension evaluation completes in under 1ms at p99. A pre-execution budget gate enforces cost limits before execution is authorized. Governance adds less than a millisecond to any agent decision.

## Key Capabilities

**Agent Birth Certificate** — Every agent starts with a cryptographically signed identity: human owner, governance zone, behavioral archetype, and lifecycle management. Authority is issued, never assumed. No anonymous agents. Foundation model provenance can be cryptographically bound to the certificate, enabling verifiable tracking of which model powers each agent.

**Interrupt Authority** — Governance can halt actions mid-execution, not just approve or deny them upfront. Execution handles provide real-time interrupt checks with rollback support at four granularities: single action, agent, workflow, or global. Governance participates throughout the action lifecycle.

**Dynamic Trust** — Trust scores evolve based on agent behavior. Successful actions build trust incrementally; violations reduce it sharply (5:1 asymmetry). Trust influences governance strictness — new agents face more scrutiny, proven agents earn more autonomy. Trust scores have configurable floors, ceilings, and decay rates.

**Behavioral Fingerprinting and Drift Detection** — Builds behavioral profiles from agent action patterns using Jensen-Shannon divergence. Detects when agent behavior drifts from established baselines. Includes bidirectional drift detection that monitors both agent drift and human oversight degradation — rubber-stamping, reviewer fatigue, and approval rate spikes are governance failures too.

**Constitutional Rules Engine** — An immutable hard constraints layer enforced before all dimensional scoring begins. Constitutional rules are HMAC-SHA256 signed at runtime initialization and verified on every evaluation. No override, trust level, or role can bypass a constitutional rule. Any tampered ruleset halts all evaluations until the runtime is reinitialized with a valid signed set.

**Governance Authority Registry** — Formalizes who has the right to change governance configuration. Six explicit roles — Constitutional Guardian, Policy Author, Scope Owner, Trust Administrator, Runtime Administrator, and Observer — cover the full governance lifecycle. Unauthorized configuration changes are rejected in code, not logged as warnings.

**Output Validation** — A governance layer between what an agent produces and what reaches users or downstream systems. Five built-in checks: PII detection and redaction, scope boundary validation, content safety scoring, output confidence assessment, and instruction constraint verification. Outputs are passed, blocked, redacted, or escalated.

**Fleet Governance** — Aggregate behavioral visibility across multi-agent fleets: health summaries, trust distribution bands, denial rate analytics, and top denied action types with cross-agent pattern detection. Fleet cost aggregation tracks per-agent and group spending with daily/monthly projections, 7-day trend analysis, and acceleration alerts that fire before budget overruns occur.

**Agent Lifecycle Hooks** — Five lifecycle milestones — BIRTH, DEGRADED, CRITICAL, RETIREMENT, and REVOCATION — each trigger registered hook callbacks and corresponding webhook events. Hooks are isolated: a failing hook never prevents others from firing or affects governance decisions. All lifecycle events are recorded in the audit trail.

**Hash-Chained Audit Trail** — Every governance decision is recorded with cryptographic hash chains. Tamper-evident by design. Tamper with one record and the whole chain breaks. Full provenance tracking traces decisions back to responsible humans. Compliance evidence bundles map governance records to specific framework controls.

**Workflow Governance** — Governs multi-step workflows, not just individual actions. Workflow seal chaining binds governance seals cryptographically across steps, creating tamper-evident proof of continuous oversight. Cross-workflow dependency checking enforces prerequisite relationships — a downstream workflow cannot begin until its upstream prerequisites have complete, verifiable seal chains.

**Pre-Execution Budget Gate** — Cost enforcement before execution begins, not after. Creates time-limited cost reservations against daily and monthly limits. If budget is exhausted, execution is denied regardless of the governance verdict. UAHS health integration automatically reduces per-action limits for agents with declining health scores.

**Immutable Pre-Execution Record** — A hash-chained JSONL ledger that records every governance-approved action before execution and settles the record on completion. Closes the evidence gap between "governance approved this" and "execution actually happened."

**Compliance Presets** — Pre-built governance profiles aligned to SOC2, HIPAA, PCI-DSS, and ISO 27001, plus severity tiers (standard, strict, ultra_strict). Each preset configures all 14 dimension weights, veto authorities, thresholds, and trust parameters. Merge multiple presets for combined compliance requirements with `merge_presets()`, which takes the strictest value from each.

**Compliance Gap Analysis** — For each control in a compliance framework, analyzes real audit records to compute actual dimension scores, identifies controls below the acceptable threshold, classifies severity (critical/high/medium), and generates actionable per-control recommendations. Supports seven built-in frameworks and custom organization-defined frameworks.

**Organization Governance** — Org-level minimums that no agent can go below. Set minimum dimension weights, required vetoes, threshold floors, and trust constraints centrally. Individual agent configs can be stricter but cannot weaken org-mandated protections.

**Framework Integrations** — Governed tool executors wrap any tool with governance evaluation. Works with LangGraph, CrewAI, and AutoGen. The `GovernedToolExecutor` and `AsyncGovernedToolExecutor` provide drop-in governance for existing tool pipelines.

## CLI Reference

```
Getting Started:
  nomotic setup                            Configure org, compliance, and owner
  nomotic new                              Generate nomotic.yaml for your project

Validation & Status:
  nomotic validate [path]                  Validate a governance config
  nomotic status                           Show global settings and presets
  nomotic status --presets                 List all available presets
  nomotic status --preset <n>              Show preset details
  nomotic hello                            Interactive governance tutorial
  nomotic doctor                           Governance infrastructure health check

Agent Management:
  nomotic birth --name <n>                 Create a governed agent with certificate
  nomotic inspect <agent-id>               View agent governance configuration
  nomotic inspect <agent-id> --brief       Quick operational summary
  nomotic inspect <agent-id> --raw         Raw certificate JSON

Testing & Simulation:
  nomotic test <id> --action <action>      Simulate a governance decision
  nomotic test <id> --adversarial          Run adversarial red team scenarios
  nomotic simulate fleet --agents <n>      Run a governed fleet simulation
  nomotic simulate fleet --watch           Live stats table during simulation
  nomotic simulate stop                    Stop simulation and clean up state

Audit & Trust:
  nomotic audit <agent-id>                 View audit trail
  nomotic trust <agent-id>                 View trust history
  nomotic oversight --team                 Human oversight health metrics
  nomotic uahs <agent-id>                  View unified agent health score
  nomotic uahs reset <agent-id>            Reset accumulated UAHS data

Organization Governance:
  nomotic authority-registry list          List governance authorities and roles
  nomotic authority-registry add           Add a governance authority
  nomotic constitution list                View loaded constitutional rules
  nomotic constitution dry-run <path>      Test ruleset against audit history

Override Management:
  nomotic override pending                 List pending multi-signature overrides
  nomotic override cosign <id>             Add a co-signature to a pending override

Fleet & Cost:
  nomotic fleet health                     Fleet-wide governance health summary
  nomotic fleet trust-distribution         Trust band distribution across agents
  nomotic cost fleet                       Fleet cost summary and projections
  nomotic cost agent <id>                  Per-agent cost breakdown and trends

Policy & Compliance:
  nomotic policy validate --dry-run        Test policy against audit history
  nomotic compliance-report <framework>    Generate compliance evidence report
  nomotic compliance gaps <framework>      Identify compliance coverage gaps
  nomotic scorecard --agent <id>           Generate auditor-ready governance scorecard

Diagnostics:
  nomotic diagnose <error-code>            Explain a governance error with fix steps
  nomotic archetype browse                 Browse community archetype registry
  nomotic archetype pull <n>               Install a community archetype

Lifecycle & Monitoring:
  nomotic lifecycle hooks                  List registered lifecycle hooks
  nomotic lifecycle events <agent-id>      Agent lifecycle event history

Workflow:
  nomotic workflow dependencies list       List cross-workflow dependency rules
  nomotic workflow dependencies check <id> Check dependency satisfaction status
  nomotic delegation visualize <id>        Render delegation chain (ASCII or DOT)
  nomotic delegation violations <id>       List delegation depth violations

Webhooks:
  nomotic webhook status                   Delivery queue status and stats
  nomotic webhook drain                    Retry queued webhook deliveries

Configuration & Backup:
  nomotic export dashboard                 Export HTML/JSON governance dashboard
  nomotic config backup                    Create signed configuration backups
  nomotic config backup list               List available backups with status
  nomotic config backup verify             Verify backup signature integrity
  nomotic config backup restore <type>     Restore content from verified backup
  nomotic config set --retention <p>       Set audit retention period
  nomotic config set --telemetry on|off    Enable or disable anonymous telemetry
```

## Configuration

Nomotic uses a three-level configuration hierarchy:

```
~/.nomotic/config.json          ← Org defaults (from nomotic setup)
~/.nomotic/org-governance.yaml  ← Org-level minimums (enforced)
./nomotic.yaml                  ← Per-project agent governance
```

Agent configs inherit from presets via `extends` and must comply with org-level minimums. Explicit YAML values override inherited preset values — weights merge (only specified dimensions override), vetoes replace entirely.

## Available Presets

| Preset | Category | Description |
|--------|----------|-------------|
| `standard` | Severity | Reasonable defaults for general use |
| `strict` | Severity | Elevated security, recommended for production |
| `ultra_strict` | Severity | Maximum governance for regulated environments |
| `soc2_aligned` | Compliance | Aligned to SOC2 security controls |
| `hipaa_aligned` | Compliance | Aligned to HIPAA privacy and safety concerns |
| `pci_dss_aligned` | Compliance | Aligned to PCI-DSS payment card requirements |
| `iso27001_aligned` | Compliance | Aligned to ISO 27001 information security |

Compliance-aligned presets are Nomotic's interpretation of governance weights aligned to the concerns of the referenced frameworks. They are not certified, endorsed, or approved by any standards body and do not constitute compliance with any regulatory framework.

> **Compliance reporting frameworks** — The `nomotic compliance-report` and `nomotic compliance gaps` commands support additional frameworks beyond the preset-aligned list above: GDPR, EU AI Act, NIST AI RMF, NIST CSF for AI, and IMDA Agentic AI. Custom frameworks can be loaded from JSON using `load_custom_framework()` or `discover_frameworks()`.

## Examples

```
examples/configs/simple-agent.yaml        # Basic agent with strict preset
examples/configs/healthcare-agent.yaml    # HIPAA-aligned multi-agent setup
examples/configs/fintech-agent.yaml       # SOC2 + PCI-DSS dual compliance
examples/configs/nomotic-org-example.yaml # Organization governance template
```

See the [Jupyter notebooks](notebooks/) for interactive walkthroughs of governance evaluation, tool execution, drift detection, and adversarial testing.

## Architecture

Nomotic is The Governance Runtime™ — a stateful, deterministic execution environment in which governed agents operate. It uses a multi-stage governance pipeline: a constitutional rules gate and state continuity check before evaluation, a three-tier dimensional evaluator that scores all 14 dimensions with weighted aggregation, a pre-execution budget gate that enforces cost limits before execution is authorized, and an interrupt authority that monitors execution after approval. The same inputs produce the same governance decisions. See [docs/architecture.md](docs/architecture.md) for the full design.

## Development

```bash
git clone https://git.nomotic.ai/nomotic/core.git
cd core
pip install -e ".[dev]"
pytest tests/ -v
```

4,000+ tests across 100+ test files. Zero external runtime dependencies. Python 3.11+.

## Contributing

We welcome contributions. See [CONTRIBUTING.md](CONTRIBUTING.md) for development workflow, code style, project structure, and areas where help is needed.

## License

[Apache 2.0](LICENSE)

## Links

- [Website](https://nomotic.ai)
- [Documentation](https://docs.nomotic.ai)
- [Wiki](https://git.nomotic.ai/nomotic/core/-/wikis/home)
- [Changelog](CHANGELOG.md)
- [PyPI](https://pypi.org/project/nomotic/)
- [Position Paper](https://chrishood.com/nomotic-ai/) — *Nomotic AI: The Governance Counterpart to Agentic AI*
- [SSRN Preprint](https://dx.doi.org/10.2139/ssrn.6069888)
