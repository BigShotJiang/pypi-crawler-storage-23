/* htmx SSE extension placeholder for Nomotic Governance Dashboard */
