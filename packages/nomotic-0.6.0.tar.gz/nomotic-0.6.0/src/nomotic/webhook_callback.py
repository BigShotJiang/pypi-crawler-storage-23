"""Generic webhook callback for Nomotic approval queue.

Generates signed, time-limited callback tokens that external systems
(PagerDuty, Microsoft Teams, custom ticketing) can use to approve or deny
pending overrides by POSTing back to the Nomotic server.

Uses HMAC-SHA256 with the webhook signing secret.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any

__all__ = [
    "_generate_callback_token",
    "_verify_callback_token",
    "fire_approval_webhook",
]

logger = logging.getLogger(__name__)


def _generate_callback_token(
    pending_id: str, expires_at: float, webhook_secret: str
) -> str:
    """HMAC-SHA256 of '{pending_id}:{expires_at}' using webhook_secret."""
    expires_iso = datetime.fromtimestamp(expires_at, tz=timezone.utc).isoformat()
    message = f"{pending_id}:{expires_iso}"
    return hmac.new(
        webhook_secret.encode(),
        message.encode(),
        hashlib.sha256,
    ).hexdigest()


def _verify_callback_token(
    pending_id: str, expires_at: float, token: str, webhook_secret: str
) -> bool:
    """Verify a callback token. Returns True if valid."""
    expected = _generate_callback_token(pending_id, expires_at, webhook_secret)
    return hmac.compare_digest(expected, token)


def fire_approval_webhook(
    runtime: Any,
    pending: Any,
    approval_webhook_url: str,
    server_host: str,
    webhook_secret: str,
) -> None:
    """Fire an outbound webhook when a PendingOverride is created.

    Runs in a daemon thread to avoid blocking the caller.
    """
    threading.Thread(
        target=_send_approval_webhook,
        args=(runtime, pending, approval_webhook_url, server_host, webhook_secret),
        daemon=True,
    ).start()


def _send_approval_webhook(
    runtime: Any,
    pending: Any,
    approval_webhook_url: str,
    server_host: str,
    webhook_secret: str,
) -> None:
    """Send the actual approval webhook (runs in background thread)."""
    try:
        callback_token = _generate_callback_token(
            pending.override_id, pending.expires_at, webhook_secret
        )
        callback_url = (
            f"https://{server_host}/v1/overrides/{pending.override_id}/callback"
        )
        expires_iso = datetime.fromtimestamp(
            pending.expires_at, tz=timezone.utc
        ).isoformat()

        payload = {
            "event": "ESCALATION_PENDING_APPROVAL",
            "pending_id": pending.override_id,
            "agent_id": pending.agent_id,
            "action_type": pending.override_type,
            "target": pending.action_id,
            "escalation_reason": pending.initial_reason,
            "signatures_required": pending.required_signatures,
            "signatures_collected": pending.signature_count,
            "expires_at": expires_iso,
            "callback_url": callback_url,
            "callback_token": callback_token,
            "callback_expires_at": expires_iso,
        }

        runtime._dispatch_webhook(
            "ESCALATION_PENDING_APPROVAL",
            pending.agent_id,
            payload,
        )
    except Exception as e:
        logger.warning(f"Approval webhook failed: {e}")
