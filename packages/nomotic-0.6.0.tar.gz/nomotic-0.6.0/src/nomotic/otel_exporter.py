"""OpenTelemetry exporter for Nomotic governance telemetry.

Publishes governance events as OpenTelemetry spans and metrics,
enabling enterprise observability stacks to consume governance
data natively.

Usage::

    from nomotic.otel_exporter import NomoticOtelExporter

    exporter = NomoticOtelExporter(service_name="nomotic-governance")
    exporter.record_evaluation(verdict, trust_before, trust_after, duration_ms)
    exporter.record_drift(agent_id, drift_score, category)
    exporter.record_interrupt(agent_id, reason)

Requires: opentelemetry-api, opentelemetry-sdk (optional dependencies).
Falls back to no-ops when these packages are not installed.
"""

from __future__ import annotations

import threading
from typing import Any

__all__ = ["NomoticOtelExporter", "PrometheusMetrics"]


class NomoticOtelExporter:
    """Exports governance telemetry as OpenTelemetry spans and metrics.

    Gracefully degrades if opentelemetry packages are not installed —
    all methods become no-ops.
    """

    def __init__(self, service_name: str = "nomotic-governance"):
        self._service_name = service_name
        self._otel_available = False

        try:
            from opentelemetry import trace, metrics  # type: ignore[import-untyped]
            from opentelemetry.sdk.trace import TracerProvider  # noqa: F401
            from opentelemetry.sdk.metrics import MeterProvider  # noqa: F401

            self._tracer = trace.get_tracer(service_name)
            self._meter = metrics.get_meter(service_name)
            self._otel_available = True

            # Define metrics
            self._eval_counter = self._meter.create_counter(
                "nomotic.evaluation.count",
                description="Total governance evaluations",
                unit="1",
            )
            self._eval_duration = self._meter.create_histogram(
                "nomotic.evaluation.duration_ms",
                description="Governance evaluation duration",
                unit="ms",
            )
            self._ucs_histogram = self._meter.create_histogram(
                "nomotic.evaluation.ucs",
                description="Unified Compliance Score distribution",
                unit="1",
            )
            self._trust_gauge = self._meter.create_up_down_counter(
                "nomotic.trust.score",
                description="Agent trust score",
                unit="1",
            )
            self._drift_gauge = self._meter.create_histogram(
                "nomotic.drift.deviation",
                description="Agent behavioral drift score",
                unit="1",
            )
            self._deny_counter = self._meter.create_counter(
                "nomotic.evaluation.denied",
                description="Denied evaluations",
                unit="1",
            )
            self._veto_counter = self._meter.create_counter(
                "nomotic.evaluation.vetoed",
                description="Vetoed evaluations (tier 1)",
                unit="1",
            )
            self._interrupt_counter = self._meter.create_counter(
                "nomotic.interrupt.count",
                description="Agent interruptions",
                unit="1",
            )

        except ImportError:
            pass  # OpenTelemetry not installed — all methods become no-ops

    def record_evaluation(
        self,
        agent_id: str,
        action: str,
        target: str,
        verdict: str,
        ucs: float,
        tier: int,
        trust_before: float,
        trust_after: float,
        duration_ms: float,
        dimension_scores: dict[str, float] | None = None,
        vetoed_by: list[str] | None = None,
    ) -> None:
        """Record a governance evaluation as a span + metrics."""
        if not self._otel_available:
            return

        attributes: dict[str, Any] = {
            "nomotic.agent_id": agent_id,
            "nomotic.action": action,
            "nomotic.target": target,
            "nomotic.verdict": verdict,
            "nomotic.ucs": ucs,
            "nomotic.tier": tier,
            "nomotic.trust.before": trust_before,
            "nomotic.trust.after": trust_after,
        }

        if vetoed_by:
            attributes["nomotic.vetoed_by"] = ",".join(vetoed_by)

        # Record span
        with self._tracer.start_as_current_span(
            "nomotic.evaluate",
            attributes=attributes,
        ) as span:
            if dimension_scores:
                for dim, score in dimension_scores.items():
                    span.set_attribute(f"nomotic.dimension.{dim}", score)

        # Record metrics
        metric_attrs = {"agent_id": agent_id, "verdict": verdict, "tier": str(tier)}
        self._eval_counter.add(1, metric_attrs)
        self._eval_duration.record(duration_ms, metric_attrs)
        self._ucs_histogram.record(ucs, metric_attrs)

        if verdict == "DENY":
            self._deny_counter.add(1, metric_attrs)
        if tier == 1:
            self._veto_counter.add(1, metric_attrs)

    def record_trust_change(
        self, agent_id: str, new_trust: float, delta: float
    ) -> None:
        """Record a trust score change."""
        if not self._otel_available:
            return
        self._trust_gauge.add(delta, {"agent_id": agent_id})

    def record_drift(
        self, agent_id: str, drift_score: float, category: str
    ) -> None:
        """Record a behavioral drift observation."""
        if not self._otel_available:
            return
        self._drift_gauge.record(
            drift_score, {"agent_id": agent_id, "category": category}
        )

    def record_interrupt(self, agent_id: str, reason: str) -> None:
        """Record an agent interruption event."""
        if not self._otel_available:
            return
        self._interrupt_counter.add(1, {"agent_id": agent_id, "reason": reason})


class PrometheusMetrics:
    """Lightweight Prometheus metrics endpoint without requiring OpenTelemetry.

    Maintains in-memory counters and gauges that are exposed in
    Prometheus text exposition format at ``/metrics``.
    """

    def __init__(self) -> None:
        self._counters: dict[str, dict[str, float]] = {}
        self._gauges: dict[str, dict[str, float]] = {}
        self._histograms: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def inc(
        self,
        name: str,
        labels: dict[str, str] | None = None,
        value: float = 1.0,
    ) -> None:
        """Increment a counter."""
        key = self._label_key(name, labels)
        with self._lock:
            if name not in self._counters:
                self._counters[name] = {}
            self._counters[name][key] = self._counters[name].get(key, 0) + value

    def set_gauge(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> None:
        """Set a gauge value."""
        key = self._label_key(name, labels)
        with self._lock:
            if name not in self._gauges:
                self._gauges[name] = {}
            self._gauges[name][key] = value

    def observe(self, name: str, value: float) -> None:
        """Record a histogram observation."""
        with self._lock:
            if name not in self._histograms:
                self._histograms[name] = []
            self._histograms[name].append(value)

    def format_prometheus(self) -> str:
        """Format all metrics in Prometheus text exposition format."""
        lines: list[str] = []
        with self._lock:
            for name, label_vals in self._counters.items():
                lines.append(f"# TYPE {name} counter")
                for label_key, val in label_vals.items():
                    lines.append(f"{label_key} {val}")

            for name, label_vals in self._gauges.items():
                lines.append(f"# TYPE {name} gauge")
                for label_key, val in label_vals.items():
                    lines.append(f"{label_key} {val}")

            for name, values in self._histograms.items():
                if values:
                    lines.append(f"# TYPE {name} summary")
                    lines.append(f"{name}_count {len(values)}")
                    lines.append(f"{name}_sum {sum(values)}")

        return "\n".join(lines) + "\n"

    @staticmethod
    def _label_key(name: str, labels: dict[str, str] | None) -> str:
        """Build a Prometheus metric key with optional labels."""
        if not labels:
            return name
        label_str = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"

    # ── Convenience methods for common governance metrics ────────────

    def record_evaluation(
        self,
        agent_id: str,
        verdict: str,
        ucs: float,
        tier: int,
        duration_ms: float,
    ) -> None:
        """Record a governance evaluation in Prometheus format."""
        labels = {"agent_id": agent_id, "verdict": verdict}
        self.inc("nomotic_evaluation_total", labels)
        self.observe("nomotic_evaluation_duration_ms", duration_ms)
        self.observe("nomotic_evaluation_ucs", ucs)
        if verdict == "DENY":
            self.inc("nomotic_evaluation_denied_total", labels)

    def record_trust(self, agent_id: str, trust: float) -> None:
        """Set current trust score for an agent."""
        self.set_gauge("nomotic_trust_score", trust, {"agent_id": agent_id})

    def record_drift(self, agent_id: str, drift: float) -> None:
        """Set current drift score for an agent."""
        self.set_gauge("nomotic_drift_score", drift, {"agent_id": agent_id})
