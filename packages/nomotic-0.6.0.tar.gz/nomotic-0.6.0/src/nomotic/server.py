"""Nomotic governance server -- containerized entry point.

Reads configuration from environment variables and starts the
Nomotic API server with persistent storage.

Usage:
    python -m nomotic.server

Environment:
    NOMOTIC_PORT       API port (default: 8420)
    NOMOTIC_HOST       Bind address (default: 0.0.0.0)
    NOMOTIC_DATA_DIR   Data directory (default: ~/.nomotic)
    NOMOTIC_METRICS    Enable Prometheus /metrics (default: false)
    NOMOTIC_LOG_LEVEL  Logging level (default: info)
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from nomotic.api import NomoticAPIServer
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.registry import (
    ArchetypeRegistry,
    FileOrgStore,
    OrganizationRegistry,
    ZoneValidator,
)
from nomotic.store import FileCertificateStore


def _load_or_create_issuer(data_dir: Path) -> tuple[SigningKey, str]:
    """Load the issuer key pair, or generate one on first run.

    Returns the signing key and issuer ID string.
    """
    issuer_dir = data_dir / "issuer"
    issuer_dir.mkdir(parents=True, exist_ok=True)
    key_path = issuer_dir / "issuer.key"
    pub_path = issuer_dir / "issuer.pub"
    meta_path = issuer_dir / "issuer.json"

    if key_path.exists():
        sk = SigningKey.from_bytes(key_path.read_bytes())
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return sk, meta["issuer_id"]

    # First run -- generate new issuer identity
    sk, vk = SigningKey.generate()
    key_path.write_bytes(sk.to_bytes())
    os.chmod(key_path, 0o600)
    pub_path.write_bytes(vk.to_bytes())

    issuer_id = f"nomotic-server-{vk.fingerprint()[:16]}"
    meta = {
        "issuer_id": issuer_id,
        "fingerprint": vk.fingerprint(),
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return sk, issuer_id


def main() -> None:
    port = int(os.environ.get("NOMOTIC_PORT", "8420"))
    host = os.environ.get("NOMOTIC_HOST", "0.0.0.0")
    data_dir = Path(
        os.environ.get("NOMOTIC_DATA_DIR", str(Path.home() / ".nomotic"))
    )
    metrics_enabled = os.environ.get("NOMOTIC_METRICS", "false").lower() in (
        "true",
        "1",
        "yes",
    )
    log_level = os.environ.get("NOMOTIC_LOG_LEVEL", "info").upper()

    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    logger = logging.getLogger("nomotic.server")

    # Ensure data directories exist
    for subdir in (
        "certs",
        "revoked",
        "audit",
        "testlog",
        "agents",
        "revocations",
        "issuer",
        "orgs",
    ):
        (data_dir / subdir).mkdir(parents=True, exist_ok=True)

    # Load or create issuer identity
    issuer_sk, issuer_id = _load_or_create_issuer(data_dir)

    # Initialize certificate authority with file store
    store = FileCertificateStore(data_dir)
    ca = CertificateAuthority(
        issuer_id=issuer_id,
        signing_key=issuer_sk,
        store=store,
    )

    # Build registries
    archetype_reg = ArchetypeRegistry.with_defaults()
    zone_val = ZoneValidator()
    org_store = FileOrgStore(data_dir)
    org_reg = OrganizationRegistry(store=org_store)

    # Optional Prometheus metrics
    prometheus = None
    if metrics_enabled:
        from nomotic.otel_exporter import PrometheusMetrics

        prometheus = PrometheusMetrics()

    logger.info("Starting Nomotic governance server on %s:%d", host, port)
    logger.info("Data directory: %s", data_dir)
    logger.info("Issuer: %s", issuer_id)
    logger.info("Metrics: %s", "enabled" if metrics_enabled else "disabled")

    # Build server
    server = NomoticAPIServer(
        ca,
        archetype_registry=archetype_reg,
        zone_validator=zone_val,
        org_registry=org_reg,
        base_dir=data_dir,
        prometheus=prometheus,
        host=host,
        port=port,
    )

    logger.info("Nomotic governance server running at http://%s:%d", host, port)
    logger.info("Health check: http://%s:%d/v1/health", host, port)
    if metrics_enabled:
        logger.info("Metrics: http://%s:%d/metrics", host, port)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        server.shutdown()


if __name__ == "__main__":
    main()
