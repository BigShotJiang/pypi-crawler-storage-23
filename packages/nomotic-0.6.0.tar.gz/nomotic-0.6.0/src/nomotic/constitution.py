"""Constitutional Rules Engine — immutable hard constraints.

Constitutional rules are categorically different from policies and governance
dimensions.  They are **immutable hard constraints** evaluated before any
dimensional scoring begins.  No multi-party override, no role permission, no
trust level can bypass a constitutional rule.  They are the floor beneath the
floor.

Policies can be dry-run, updated, and versioned.  Constitutional rules cannot
be modified at runtime — they are signed by the Certificate Authority at
runtime initialization and hash-verified on every evaluation.  Any tampering
with the constitutional ruleset causes the runtime to refuse all evaluations
until reinitialized with a valid signed set.

The distinction maps directly to the governance architecture:
- Tier 1 (deterministic gate): blocks known-bad patterns
- Constitutional rules: block actions that no configuration could ever permit
"""

from __future__ import annotations

import fnmatch
import hashlib
import hmac
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nomotic.types import Action, AgentContext

__all__ = [
    "ConstitutionalDryRunResult",
    "ConstitutionalDryRunner",
    "ConstitutionalEngine",
    "ConstitutionalIntegrityError",
    "ConstitutionalRule",
    "ConstitutionalRuleSet",
    "ConstitutionalViolation",
    "ConstitutionalViolationError",
    "build_default_constitutional_rules",
]

_log = logging.getLogger(__name__)


# ── Exceptions ──────────────────────────────────────────────────────────


class ConstitutionalViolationError(Exception):
    """Raised when a constitutional rule is violated."""

    def __init__(self, violation: ConstitutionalViolation) -> None:
        self.violation = violation
        super().__init__(
            f"Constitutional violation: {violation.rule_name} "
            f"(rule {violation.rule_id}): {violation.reason}"
        )


class ConstitutionalIntegrityError(Exception):
    """Raised when the ruleset signature fails verification."""


# ── Data types ──────────────────────────────────────────────────────────


@dataclass
class ConstitutionalRule:
    """A single constitutional rule — an immutable hard constraint.

    Fields:
        rule_id: Unique identifier in the format ``nmcr-<uuid4>``.
        name: Human-readable name for the rule.
        description: Longer explanation of what this rule enforces.
        rule_type: One of ``"deny_always"``, ``"require_certificate"``,
            ``"trust_floor"``, ``"scope_hard_limit"``,
            ``"archetype_restriction"``.
        condition: Rule-specific condition parameters (dict).
        created_by: Authority who authored this rule.
        created_at: Unix timestamp of creation.
        rule_hash: SHA-256 hex digest of the canonical JSON of all fields
            except ``rule_hash`` itself.
    """

    rule_id: str
    name: str
    description: str
    rule_type: str
    condition: dict[str, Any]
    created_by: str
    created_at: float
    rule_hash: str = ""

    def compute_hash(self) -> str:
        """Compute the SHA-256 hash of the canonical representation.

        The hash covers all fields except ``rule_hash`` itself, serialised
        as sorted-key JSON with no whitespace.
        """
        payload = {
            "rule_id": self.rule_id,
            "name": self.name,
            "description": self.description,
            "rule_type": self.rule_type,
            "condition": self.condition,
            "created_by": self.created_by,
            "created_at": self.created_at,
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict."""
        return {
            "rule_id": self.rule_id,
            "name": self.name,
            "description": self.description,
            "rule_type": self.rule_type,
            "condition": self.condition,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "rule_hash": self.rule_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConstitutionalRule:
        """Deserialise from a plain dict."""
        return cls(
            rule_id=data["rule_id"],
            name=data["name"],
            description=data["description"],
            rule_type=data["rule_type"],
            condition=data["condition"],
            created_by=data["created_by"],
            created_at=data["created_at"],
            rule_hash=data.get("rule_hash", ""),
        )


@dataclass
class ConstitutionalRuleSet:
    """A signed set of constitutional rules.

    The ruleset is signed by the Certificate Authority at runtime
    initialization.  The signature is an HMAC-SHA256 over the
    ``ruleset_hash`` using the CA's verify key bytes.

    Fields:
        ruleset_id: Unique identifier in the format ``nmcrs-<uuid4>``.
        rules: Ordered list of constitutional rules.
        signed_by: CA authority identifier that signed this set.
        signed_at: Unix timestamp of signing.
        signature: Hex-encoded HMAC-SHA256 of ``ruleset_hash`` using the
            CA signing key bytes.
        ruleset_hash: SHA-256 hex digest of all ``rule_hash`` values
            joined with ``":"``.
    """

    ruleset_id: str
    rules: list[ConstitutionalRule]
    signed_by: str
    signed_at: float
    signature: str
    ruleset_hash: str = ""

    def compute_ruleset_hash(self) -> str:
        """Compute the SHA-256 hash over all rule hashes joined with ':'."""
        joined = ":".join(r.rule_hash for r in self.rules)
        return hashlib.sha256(joined.encode("utf-8")).hexdigest()

    def verify_signature(self, verify_key_bytes: bytes) -> bool:
        """Verify the HMAC-SHA256 signature using the given key bytes.

        Returns ``True`` if the signature matches, ``False`` otherwise.
        """
        expected = hmac.new(
            verify_key_bytes,
            self.ruleset_hash.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(self.signature, expected)

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict."""
        return {
            "ruleset_id": self.ruleset_id,
            "rules": [r.to_dict() for r in self.rules],
            "signed_by": self.signed_by,
            "signed_at": self.signed_at,
            "signature": self.signature,
            "ruleset_hash": self.ruleset_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConstitutionalRuleSet:
        """Deserialise from a plain dict."""
        rules = [ConstitutionalRule.from_dict(r) for r in data.get("rules", [])]
        return cls(
            ruleset_id=data["ruleset_id"],
            rules=rules,
            signed_by=data["signed_by"],
            signed_at=data["signed_at"],
            signature=data["signature"],
            ruleset_hash=data.get("ruleset_hash", ""),
        )

    @classmethod
    def from_file(cls, path: Path) -> ConstitutionalRuleSet:
        """Load a constitutional ruleset from a JSON file."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)


@dataclass
class ConstitutionalViolation:
    """Record of a single constitutional rule violation.

    Produced by :meth:`ConstitutionalEngine.evaluate` when an action
    violates a constitutional rule.
    """

    rule_id: str
    rule_name: str
    rule_type: str
    reason: str
    action_id: str
    agent_id: str
    evaluated_at: float


# ── Engine ──────────────────────────────────────────────────────────────


class ConstitutionalEngine:
    """Evaluates constitutional rules before dimensional scoring.

    The engine is initialized with a signed ruleset and the CA's verify
    key.  On every :meth:`evaluate` call it checks all constitutional
    rules against the action and context.  If any rule is violated the
    violation is returned (the engine does not raise — callers decide
    whether to raise).

    If constructed without a ruleset the engine operates in **passthrough
    mode**: no rules are enforced and :meth:`has_rules` returns ``False``.
    """

    def __init__(
        self,
        ruleset: ConstitutionalRuleSet | None = None,
        verify_key_bytes: bytes | None = None,
        strict_mode: bool = True,
    ) -> None:
        """
        Args:
            ruleset: The signed constitutional ruleset.  If ``None``,
                engine operates in passthrough mode (no rules enforced).
            verify_key_bytes: CA verify key for signature verification.
                If ``None`` and a ruleset is provided, raises
                :class:`ConstitutionalIntegrityError`.
            strict_mode: If ``True`` (default), signature failure raises
                :class:`ConstitutionalIntegrityError`.  If ``False``,
                logs a warning and continues (dev/test only).
        """
        self._ruleset: ConstitutionalRuleSet | None = None
        self._strict_mode = strict_mode

        if ruleset is not None:
            if verify_key_bytes is None:
                raise ConstitutionalIntegrityError(
                    "Cannot initialize constitutional engine: "
                    "ruleset provided but no verify_key_bytes given."
                )
            if not ruleset.verify_signature(verify_key_bytes):
                if strict_mode:
                    raise ConstitutionalIntegrityError(
                        "Constitutional ruleset signature verification failed. "
                        "The ruleset may have been tampered with."
                    )
                _log.warning(
                    "Constitutional ruleset signature verification failed "
                    "(strict_mode=False, continuing in dev/test mode)."
                )
            self._ruleset = ruleset

    # ── Public API ─────────────────────────────────────────────────

    def evaluate(
        self,
        action: Action,
        context: AgentContext,
    ) -> list[ConstitutionalViolation]:
        """Evaluate all constitutional rules against an action.

        Returns a list of violations (empty means all rules passed).
        Does NOT raise — callers decide whether to raise.
        """
        if self._ruleset is None:
            return []

        violations: list[ConstitutionalViolation] = []
        now = time.time()

        for rule in self._ruleset.rules:
            violation = self._evaluate_rule(rule, action, context, now)
            if violation is not None:
                violations.append(violation)

        return violations

    def evaluate_passthrough(
        self,
        action: Action,
        context: AgentContext,
    ) -> ConstitutionalViolation | None:
        """Evaluate constitutional rules WITHOUT signature verification.

        For use in dry-run simulation only.  Standard :meth:`evaluate`
        always requires a verified signature.  This method skips that
        check so dry-runs can test rulesets before they are signed by
        the CA.

        This method is for simulation only.  Never use
        ``evaluate_passthrough()`` in the governance evaluation pipeline.

        Returns the first :class:`ConstitutionalViolation` found, or
        ``None`` if no rule matches.
        """
        if self._ruleset is None:
            return None

        now = time.time()
        for rule in self._ruleset.rules:
            violation = self._evaluate_rule(rule, action, context, now)
            if violation is not None:
                return violation
        return None

    def load_file(self, path: Path) -> None:
        """Load and verify a constitutional ruleset from a JSON file.

        Raises :class:`ConstitutionalIntegrityError` if verification
        fails (and strict_mode is ``True``).
        """
        ruleset = ConstitutionalRuleSet.from_file(path)
        # Re-initialize with the loaded ruleset — constructor handles
        # verification.  We need verify_key_bytes from the original
        # initialization, but since load_file is a convenience method
        # we store them on first init.
        raise NotImplementedError(
            "load_file requires verify_key_bytes stored at init; "
            "use the constructor directly."
        )

    def has_rules(self) -> bool:
        """Returns ``True`` if a verified ruleset is loaded."""
        return self._ruleset is not None and len(self._ruleset.rules) > 0

    def rule_count(self) -> int:
        """Number of active constitutional rules."""
        if self._ruleset is None:
            return 0
        return len(self._ruleset.rules)

    # ── Rule evaluation dispatch ───────────────────────────────────

    def _evaluate_rule(
        self,
        rule: ConstitutionalRule,
        action: Action,
        context: AgentContext,
        now: float,
    ) -> ConstitutionalViolation | None:
        """Evaluate a single constitutional rule.  Returns a violation
        if the rule is violated, ``None`` otherwise."""
        evaluator = _RULE_EVALUATORS.get(rule.rule_type)
        if evaluator is None:
            # Unknown rule types are treated as pass (forward compatibility).
            return None
        return evaluator(rule, action, context, now)


# ── Rule evaluator functions ────────────────────────────────────────────


def _evaluate_deny_always(
    rule: ConstitutionalRule,
    action: Action,
    context: AgentContext,
    now: float,
) -> ConstitutionalViolation | None:
    """``deny_always``: unconditionally deny matching actions.

    condition:
        action_types: list[str]  — glob patterns for action_type
        targets: list[str]       — glob patterns for target

    Matches if ``action.action_type`` matches any ``action_types`` pattern
    AND ``action.target`` matches any ``targets`` pattern.  Either list may
    be omitted (matches all).
    """
    cond = rule.condition
    action_types = cond.get("action_types")
    targets = cond.get("targets")

    # Check action_type match
    type_match = True
    if action_types:
        type_match = any(
            fnmatch.fnmatch(action.action_type, pat) for pat in action_types
        )

    # Check target match
    target_match = True
    if targets:
        target_match = any(
            fnmatch.fnmatch(action.target, pat) for pat in targets
        )

    if type_match and target_match:
        matched_parts = []
        if action_types:
            matched_parts.append(f"action_type={action.action_type}")
        if targets:
            matched_parts.append(f"target={action.target}")
        return ConstitutionalViolation(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            reason=f"Action denied by constitutional rule: {', '.join(matched_parts) or 'all actions'}",
            action_id=action.id,
            agent_id=context.agent_id,
            evaluated_at=now,
        )

    return None


def _evaluate_require_certificate(
    rule: ConstitutionalRule,
    action: Action,
    context: AgentContext,
    now: float,
) -> ConstitutionalViolation | None:
    """``require_certificate``: require a valid agent certificate.

    condition:
        min_trust: float          — minimum trust score on the cert
        required_fields: list[str] — fields that must be present in cert metadata
    """
    cond = rule.condition
    min_trust = cond.get("min_trust", 0.0)
    required_fields = cond.get("required_fields", [])

    # Check if context has a certificate ID
    cert_id = context.metadata.get("cert_id")
    if not cert_id:
        return ConstitutionalViolation(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            reason="No agent certificate found in context",
            action_id=action.id,
            agent_id=context.agent_id,
            evaluated_at=now,
        )

    # Check cert trust
    cert_trust = context.metadata.get("cert_trust", 0.0)
    if cert_trust < min_trust:
        return ConstitutionalViolation(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            reason=(
                f"Certificate trust {cert_trust:.3f} below constitutional "
                f"minimum {min_trust:.3f}"
            ),
            action_id=action.id,
            agent_id=context.agent_id,
            evaluated_at=now,
        )

    # Check required fields in cert metadata
    cert_metadata = context.metadata.get("cert_metadata", {})
    for field_name in required_fields:
        if field_name not in cert_metadata:
            return ConstitutionalViolation(
                rule_id=rule.rule_id,
                rule_name=rule.name,
                rule_type=rule.rule_type,
                reason=f"Required certificate field missing: {field_name}",
                action_id=action.id,
                agent_id=context.agent_id,
                evaluated_at=now,
            )

    return None


def _evaluate_trust_floor(
    rule: ConstitutionalRule,
    action: Action,
    context: AgentContext,
    now: float,
) -> ConstitutionalViolation | None:
    """``trust_floor``: enforce a minimum trust level for agents.

    condition:
        min_trust: float                  — minimum trust score
        applies_to_irreversible: bool     — if True, only applies to
            irreversible actions (action.metadata.get("irreversible", False))
    """
    cond = rule.condition
    min_trust = cond.get("min_trust", 0.0)
    applies_to_irreversible = cond.get("applies_to_irreversible", False)

    # If only applies to irreversible actions, check the flag
    if applies_to_irreversible:
        if not action.metadata.get("irreversible", False):
            return None

    agent_trust = context.trust_profile.overall_trust
    if agent_trust < min_trust:
        return ConstitutionalViolation(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            reason=(
                f"Agent trust {agent_trust:.3f} below constitutional "
                f"floor {min_trust:.3f}"
            ),
            action_id=action.id,
            agent_id=context.agent_id,
            evaluated_at=now,
        )

    return None


def _evaluate_scope_hard_limit(
    rule: ConstitutionalRule,
    action: Action,
    context: AgentContext,
    now: float,
) -> ConstitutionalViolation | None:
    """``scope_hard_limit``: forbid specific actions or targets.

    condition:
        forbidden_action_types: list[str] — action types to deny (glob)
        forbidden_targets: list[str]      — targets to deny (glob)

    Violation if action.action_type in forbidden_action_types OR
    action.target matches any forbidden_target.
    """
    cond = rule.condition
    forbidden_types = cond.get("forbidden_action_types", [])
    forbidden_targets = cond.get("forbidden_targets", [])

    # Check forbidden action types
    for pat in forbidden_types:
        if fnmatch.fnmatch(action.action_type, pat):
            return ConstitutionalViolation(
                rule_id=rule.rule_id,
                rule_name=rule.name,
                rule_type=rule.rule_type,
                reason=f"Action type '{action.action_type}' is constitutionally forbidden",
                action_id=action.id,
                agent_id=context.agent_id,
                evaluated_at=now,
            )

    # Check forbidden targets
    for pat in forbidden_targets:
        if fnmatch.fnmatch(action.target, pat):
            return ConstitutionalViolation(
                rule_id=rule.rule_id,
                rule_name=rule.name,
                rule_type=rule.rule_type,
                reason=f"Target '{action.target}' is constitutionally forbidden",
                action_id=action.id,
                agent_id=context.agent_id,
                evaluated_at=now,
            )

    return None


def _evaluate_archetype_restriction(
    rule: ConstitutionalRule,
    action: Action,
    context: AgentContext,
    now: float,
) -> ConstitutionalViolation | None:
    """``archetype_restriction``: deny actions for specific archetypes.

    condition:
        archetypes: list[str]        — archetypes this restriction applies to
        denied_action_types: list[str] — action types denied for those archetypes

    Violation if agent archetype in archetypes AND action.action_type in
    denied_action_types.
    """
    cond = rule.condition
    archetypes = cond.get("archetypes", [])
    denied_types = cond.get("denied_action_types", [])

    agent_archetype = context.metadata.get("archetype", "")
    if agent_archetype not in archetypes:
        return None

    if action.action_type in denied_types:
        return ConstitutionalViolation(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            reason=(
                f"Archetype '{agent_archetype}' is constitutionally "
                f"forbidden from action type '{action.action_type}'"
            ),
            action_id=action.id,
            agent_id=context.agent_id,
            evaluated_at=now,
        )

    return None


# ── Evaluator dispatch table ────────────────────────────────────────────

_RULE_EVALUATORS: dict[
    str,
    Any,  # Callable signature matches _evaluate_*
] = {
    "deny_always": _evaluate_deny_always,
    "require_certificate": _evaluate_require_certificate,
    "trust_floor": _evaluate_trust_floor,
    "scope_hard_limit": _evaluate_scope_hard_limit,
    "archetype_restriction": _evaluate_archetype_restriction,
}


# ── Builder ─────────────────────────────────────────────────────────────


def _make_rule(
    name: str,
    description: str,
    rule_type: str,
    condition: dict[str, Any],
    authority: str,
) -> ConstitutionalRule:
    """Helper to create a rule with auto-generated ID and hash."""
    rule = ConstitutionalRule(
        rule_id=f"nmcr-{uuid.uuid4()}",
        name=name,
        description=description,
        rule_type=rule_type,
        condition=condition,
        created_by=authority,
        created_at=time.time(),
    )
    rule.rule_hash = rule.compute_hash()
    return rule


def _sign_ruleset(
    rules: list[ConstitutionalRule],
    signing_key_bytes: bytes,
    authority: str,
) -> ConstitutionalRuleSet:
    """Create and sign a ConstitutionalRuleSet.

    The signature is HMAC-SHA256 of ``ruleset_hash`` using the
    *signing_key_bytes* (the CA verify key bytes, matching the
    verification path).
    """
    ruleset = ConstitutionalRuleSet(
        ruleset_id=f"nmcrs-{uuid.uuid4()}",
        rules=rules,
        signed_by=authority,
        signed_at=time.time(),
        signature="",
    )
    ruleset.ruleset_hash = ruleset.compute_ruleset_hash()
    ruleset.signature = hmac.new(
        signing_key_bytes,
        ruleset.ruleset_hash.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return ruleset


def build_default_constitutional_rules(
    signing_key_bytes: bytes,
    authority: str = "system",
) -> ConstitutionalRuleSet:
    """Build and sign a minimal default ruleset for new deployments.

    Default rules:
    1. ``trust_floor``: ``min_trust=0.1`` applies to all actions
       (prevents completely untrusted agents from acting).
    2. ``require_certificate``: ``min_trust=0.0``, ``required_fields=[]``
       (no cert at all = constitutional violation).

    These are minimal — real deployments should define their own.
    """
    rules = [
        _make_rule(
            name="minimum-trust-floor",
            description=(
                "Prevents completely untrusted agents from performing any "
                "action. Agents must have at least 0.1 trust."
            ),
            rule_type="trust_floor",
            condition={"min_trust": 0.1, "applies_to_irreversible": False},
            authority=authority,
        ),
        _make_rule(
            name="require-agent-certificate",
            description=(
                "All agents must have a valid certificate. No anonymous "
                "agents may act within the governance framework."
            ),
            rule_type="require_certificate",
            condition={"min_trust": 0.0, "required_fields": []},
            authority=authority,
        ),
    ]

    return _sign_ruleset(rules, signing_key_bytes, authority)


# ── Dry-Run Support ────────────────────────────────────────────────────


@dataclass
class ConstitutionalDryRunResult:
    """Result of simulating a constitutional ruleset against audit history."""

    ruleset_path: str
    ruleset_id: str
    records_evaluated: int
    would_block_count: int
    already_denied_count: int
    """Records already DENY in audit — rules would have caught them too."""
    new_blocks_count: int
    """Would-block records NOT already denied — net new blocks introduced."""
    would_block: list[dict[str, Any]]
    """Per-record details of would-block matches.

    Each entry::

        {
            "record_id": str,
            "agent_id": str,
            "action_type": str,
            "action_target": str,
            "rule_id": str,
            "rule_name": str,
            "reason": str,
            "original_verdict": str,
        }
    """
    evaluated_agents: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "ruleset_path": self.ruleset_path,
            "ruleset_id": self.ruleset_id,
            "records_evaluated": self.records_evaluated,
            "would_block_count": self.would_block_count,
            "already_denied_count": self.already_denied_count,
            "new_blocks_count": self.new_blocks_count,
            "would_block": self.would_block,
            "evaluated_agents": self.evaluated_agents,
        }


class ConstitutionalDryRunner:
    """Simulates constitutional rule evaluation against audit history.

    Pattern mirrors :class:`~nomotic.policy.PolicyDryRunner` — loads
    records from audit store, synthesises Action/AgentContext objects,
    evaluates through the constitutional engine in passthrough mode,
    and reports results.
    """

    def __init__(self, audit_store: Any) -> None:
        self._audit_store = audit_store

    def run(
        self,
        ruleset_path: str,
        agent_id: str | None = None,
        days: int = 7,
        max_records: int = 500,
    ) -> ConstitutionalDryRunResult:
        """Load ruleset from JSON file and simulate against audit history.

        Steps:
            1. Load :class:`ConstitutionalRuleSet` from JSON.
            2. Build :class:`ConstitutionalEngine` (passthrough — no
               signing required).
            3. Fetch audit records filtered by *agent_id* and *days*.
            4. For each record, synthesise Action + AgentContext.
            5. Call :meth:`ConstitutionalEngine.evaluate_passthrough`.
            6. Classify: already_denied vs new_block.
            7. Return :class:`ConstitutionalDryRunResult`.
        """
        path = Path(ruleset_path)
        ruleset = ConstitutionalRuleSet.from_file(path)
        # Build engine in passthrough mode, then inject the ruleset
        # directly — bypasses signature verification for simulation.
        engine = ConstitutionalEngine()
        engine._ruleset = ruleset
        return self._evaluate(
            engine=engine,
            ruleset_label=str(ruleset_path),
            ruleset_id=ruleset.ruleset_id,
            agent_id=agent_id,
            days=days,
            max_records=max_records,
        )

    def run_with_engine(
        self,
        engine: ConstitutionalEngine,
        ruleset_label: str = "",
        agent_id: str | None = None,
        days: int = 7,
        max_records: int = 500,
    ) -> ConstitutionalDryRunResult:
        """Simulate with a pre-built engine."""
        ruleset_id = ""
        if engine._ruleset is not None:
            ruleset_id = engine._ruleset.ruleset_id
        return self._evaluate(
            engine=engine,
            ruleset_label=ruleset_label,
            ruleset_id=ruleset_id,
            agent_id=agent_id,
            days=days,
            max_records=max_records,
        )

    # ── Internal helpers ──────────────────────────────────────────────

    def _evaluate(
        self,
        engine: ConstitutionalEngine,
        ruleset_label: str,
        ruleset_id: str,
        agent_id: str | None,
        days: int,
        max_records: int,
    ) -> ConstitutionalDryRunResult:
        """Core evaluation logic shared by run() and run_with_engine()."""
        records = self._fetch_records(agent_id, days, max_records)

        would_block: list[dict[str, Any]] = []
        already_denied = 0
        evaluated_agents: set[str] = set()

        for record in records:
            evaluated_agents.add(record.agent_id)

            action = self._synthesize_action(record)
            context = self._synthesize_context(record)
            violation = engine.evaluate_passthrough(action, context)

            if violation is not None:
                entry = {
                    "record_id": record.record_id,
                    "agent_id": record.agent_id,
                    "action_type": record.action_type,
                    "action_target": record.action_target,
                    "rule_id": violation.rule_id,
                    "rule_name": violation.rule_name,
                    "reason": violation.reason,
                    "original_verdict": record.verdict,
                }
                would_block.append(entry)
                if record.verdict == "DENY":
                    already_denied += 1

        new_blocks = [
            wb for wb in would_block if wb["original_verdict"] != "DENY"
        ]

        return ConstitutionalDryRunResult(
            ruleset_path=ruleset_label,
            ruleset_id=ruleset_id,
            records_evaluated=len(records),
            would_block_count=len(would_block),
            already_denied_count=already_denied,
            new_blocks_count=len(new_blocks),
            would_block=would_block,
            evaluated_agents=sorted(evaluated_agents),
        )

    def _synthesize_action(self, record: Any) -> Action:
        """Build Action from PersistentLogRecord fields."""
        return Action(
            id=record.record_id,
            agent_id=record.agent_id,
            action_type=record.action_type,
            target=record.action_target,
            parameters=record.parameters or {},
            metadata={"dry_run": True},
        )

    def _synthesize_context(self, record: Any) -> AgentContext:
        """Build minimal AgentContext from PersistentLogRecord fields."""
        from nomotic.types import TrustProfile

        return AgentContext(
            agent_id=record.agent_id,
            trust_profile=TrustProfile(
                agent_id=record.agent_id,
                overall_trust=record.trust_score,
            ),
        )

    def _fetch_records(
        self,
        agent_id: str | None,
        days: int,
        max_records: int,
    ) -> list[Any]:
        """Fetch audit records from store, filtered and limited."""
        import time as _time

        cutoff = _time.time() - days * 86400

        if agent_id is not None:
            agent_ids = [agent_id]
        else:
            agent_ids = self._audit_store.list_agents()

        all_records = []
        for aid in agent_ids:
            for record in self._audit_store.query_all(aid):
                if record.timestamp >= cutoff:
                    all_records.append(record)

        all_records.sort(key=lambda r: r.timestamp)
        if len(all_records) > max_records:
            all_records = all_records[-max_records:]

        return all_records
