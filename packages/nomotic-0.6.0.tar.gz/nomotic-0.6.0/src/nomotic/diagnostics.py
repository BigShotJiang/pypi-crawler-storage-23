"""Nomotic Diagnostics — error code lookup and plain-language explanations.

Provides a registry of all Nomotic error classes with descriptions, common
causes, and fix suggestions.  The ``resolve_diagnostic`` function supports
exact, alias, and substring matching for user-friendly lookups.

Used by ``nomotic diagnose <error-code>`` in the CLI.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "DiagnosticEntry",
    "DIAGNOSTIC_REGISTRY",
    "resolve_diagnostic",
    "list_known_errors",
]


@dataclass
class DiagnosticEntry:
    error_class: str
    aliases: list[str]          # alternate names user might type
    what_it_means: str
    common_causes: list[str]
    how_to_fix: list[str]
    doctor_check: str | None    # doctor category to highlight, or None


DIAGNOSTIC_REGISTRY: dict[str, DiagnosticEntry] = {}


def _register(entry: DiagnosticEntry) -> None:
    DIAGNOSTIC_REGISTRY[entry.error_class.lower()] = entry
    for alias in entry.aliases:
        DIAGNOSTIC_REGISTRY[alias.lower()] = entry


# ── Error class registrations ────────────────────────────────────────────

_register(DiagnosticEntry(
    error_class="ConstitutionalViolationError",
    aliases=["constitutional", "constitution", "CVE", "constitutional_violation"],
    what_it_means=(
        "An action was blocked by a constitutional rule. Constitutional rules "
        "are immutable hard constraints defined in the governance configuration. "
        "They cannot be overridden by UCS scores, human override, multi-sig "
        "approval, or any other mechanism."
    ),
    common_causes=[
        "The agent attempted an action type that is constitutionally prohibited",
        "The action target matched a constitutionally blocked pattern",
        "A constitutional ruleset update made previously allowed actions "
        "non-compliant — existing agent code now violates the new rules",
    ],
    how_to_fix=[
        "Run: nomotic constitution list  — to see all active constitutional rules",
        "Identify which rule was violated from the full error message (the rule "
        "name and violated condition are included)",
        "If the rule is incorrect: update the constitutional ruleset "
        "(requires CONSTITUTIONAL_GUARDIAN authority). Restart runtime after update.",
        "If the agent action is incorrect: modify the agent to avoid the "
        "prohibited action type or target pattern",
    ],
    doctor_check="Constitutional Engine",
))

_register(DiagnosticEntry(
    error_class="ConstitutionalIntegrityError",
    aliases=["integrity", "ruleset_signature", "constitutional_integrity"],
    what_it_means=(
        "The constitutional ruleset signature failed verification. This means "
        "the ruleset file may have been tampered with or corrupted since it was "
        "last signed. The governance engine refuses to load unsigned or "
        "incorrectly signed rulesets."
    ),
    common_causes=[
        "The ruleset file was edited manually without re-signing",
        "The signing key was rotated but the ruleset was not re-signed",
        "File corruption during transfer or storage",
    ],
    how_to_fix=[
        "Run: nomotic doctor  — check the Constitutional Engine section for details",
        "Re-sign the ruleset: nomotic constitution sign",
        "If the signing key was rotated: re-sign with the current key",
        "Restore the ruleset from a known-good backup if corruption is suspected",
    ],
    doctor_check="Constitutional Engine",
))

_register(DiagnosticEntry(
    error_class="BudgetExhaustedError",
    aliases=["budget", "budget_exhausted", "cost_limit"],
    what_it_means=(
        "The agent exceeded its configured budget limit for this action. "
        "The pre-execution budget gate blocked the action before it ran."
    ),
    common_causes=[
        "The action's estimated cost exceeds budget_per_action in nomotic.yaml",
        "Accumulated session cost exceeded the session budget limit",
        "The budget gate threshold was set too low for this use case",
    ],
    how_to_fix=[
        "Check current budget config: nomotic budget show",
        "Increase budget_per_action in nomotic.yaml if the limit is too restrictive",
        "If session budget: check if budget resets per session or is cumulative",
        "If the cost estimate is wrong: review how the action cost is being computed",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="ContinuityViolationError",
    aliases=["continuity", "continuity_violation", "state_continuity"],
    what_it_means=(
        "A pre-execution state continuity check failed. The agent's state "
        "changed in an unexpected way between the last evaluation and now, "
        "violating the continuity guarantee required for safe execution."
    ),
    common_causes=[
        "Agent state was modified outside of Nomotic's governance path",
        "A context profile was invalidated between evaluation steps",
        "Concurrent modification of shared agent state",
    ],
    how_to_fix=[
        "Check: nomotic continuity show <agent_id>  for current agent state",
        "Ensure all agent state changes go through GovernanceRuntime.evaluate()",
        "If running concurrent workflows: check for shared mutable state",
        "Re-evaluate the action from a clean state context",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="DelegationDepthError",
    aliases=["delegation", "delegation_depth", "delegation_limit"],
    what_it_means=(
        "The agent delegation chain exceeded the configured maximum depth. "
        "An agent attempted to delegate to a sub-agent, but the chain of "
        "delegations is already at the maximum allowed depth."
    ),
    common_causes=[
        "Circular delegation: agent A delegates to B, which delegates back to A",
        "Delegation depth limit set too low for a legitimate multi-step workflow",
        "An agent is unintentionally re-delegating actions it should execute directly",
    ],
    how_to_fix=[
        "Check delegation chain: nomotic delegation show <agent_id>",
        "Review the delegation_depth_limit in nomotic.yaml — increase if legitimate",
        "Check for circular delegation patterns in the agent workflow",
        "Consider flattening the delegation chain if depth is genuinely excessive",
    ],
    doctor_check="Delegation Depths",
))

_register(DiagnosticEntry(
    error_class="CertificateStatusError",
    aliases=["cert_status", "certificate_status", "cert_inactive"],
    what_it_means=(
        "The agent's governance certificate is not in ACTIVE status. "
        "All governed operations require a certificate with ACTIVE status. "
        "The certificate may be REVOKED, EXPIRED, or PENDING."
    ),
    common_causes=[
        "The certificate reached its configured expiry date",
        "The certificate was explicitly revoked by an administrator",
        "The certificate is newly issued and still in PENDING status",
        "Clock skew between the issuing system and the runtime",
    ],
    how_to_fix=[
        "Check certificate status: nomotic inspect <agent_id>",
        "If expired: renew with nomotic renew <certificate_id>",
        "If revoked: investigate why and issue a new certificate",
        "If pending: complete the certificate activation process",
        "If clock skew: verify system time is synchronized (NTP)",
    ],
    doctor_check="Certificate Store",
))

_register(DiagnosticEntry(
    error_class="PermissionDeniedError",
    aliases=["permission", "permission_denied", "role_denied", "unauthorized"],
    what_it_means=(
        "A governance override was attempted by an authority that does not have "
        "the required role permissions. The role-based access control system "
        "blocked the override."
    ),
    common_causes=[
        "The authority attempting the override lacks the required role",
        "The override scope (zone, archetype, risk tier) is outside the role's permissions",
        "The roles configuration file is missing or not loaded",
    ],
    how_to_fix=[
        "Check roles: nomotic roles list",
        "Check authority's roles: nomotic roles check --authority <name>",
        "Review the roles configuration file (nomotic-roles.yaml)",
        "Contact an administrator to assign the appropriate role",
    ],
    doctor_check="Role Registry",
))

_register(DiagnosticEntry(
    error_class="RoleConfigError",
    aliases=["role_config", "roles_config", "role_configuration"],
    what_it_means=(
        "The role configuration file is invalid. It could not be loaded or "
        "parsed due to malformed YAML/JSON or missing required fields."
    ),
    common_causes=[
        "Syntax error in the nomotic-roles.yaml file",
        "Missing required fields (role name, permissions) in a role definition",
        "Invalid permission scope format in a role entry",
    ],
    how_to_fix=[
        "Run: nomotic doctor  — check the Role Registry section for details",
        "Validate the roles file syntax: nomotic roles list",
        "Review nomotic-roles.yaml for YAML syntax errors",
        "Ensure all role entries have the required fields (name, permissions, scope)",
    ],
    doctor_check="Role Registry",
))

_register(DiagnosticEntry(
    error_class="WorkflowDependencyError",
    aliases=["workflow", "workflow_dependency", "dependency"],
    what_it_means=(
        "A workflow step attempted to execute before its required dependencies "
        "were satisfied. The cross-workflow dependency checker blocked the step."
    ),
    common_causes=[
        "A dependent workflow step was skipped or failed without being recorded",
        "Out-of-order step execution in a governed workflow",
        "The dependency graph was misconfigured in the workflow definition",
    ],
    how_to_fix=[
        "Run: nomotic workflow status <workflow_id>  to see which steps are complete",
        "Verify the step execution order matches the declared dependency graph",
        "If a prerequisite step failed: resolve it before retrying this step",
        "Check workflow configuration for missing or incorrect dependency declarations",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="GovernanceVetoError",
    aliases=["veto", "governance_veto", "denied", "blocked"],
    what_it_means=(
        "The governance runtime vetoed (DENY or BLOCK) an agent action. "
        "The action did not pass the governance evaluation and was prevented "
        "from executing. The verdict includes the UCS score and audit record ID."
    ),
    common_causes=[
        "The action's UCS score fell below the configured threshold",
        "A policy rule explicitly denied the action type or target",
        "The action risk tier exceeded the agent's allowed risk level",
    ],
    how_to_fix=[
        "Check the audit record for details: nomotic inspect <record_id>",
        "Review which policy or threshold caused the denial",
        "If the action should be allowed: adjust the policy or threshold",
        "If an override is needed: use nomotic override with appropriate authority",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="GovernanceDeniedError",
    aliases=["governance_denied", "tool_denied", "tool_governance"],
    what_it_means=(
        "A tool call was denied by governance when the tool adapter is "
        "configured with on_denied='raise'. The tool was not executed. "
        "The error includes the full ExecutionResult with governance details."
    ),
    common_causes=[
        "The tool call's governance evaluation returned a DENY or BLOCK verdict",
        "The tool adapter is configured to raise on denial rather than returning a result",
        "The tool action type or arguments violated a governance policy",
    ],
    how_to_fix=[
        "Review the ExecutionResult attached to the error for governance details",
        "Check the tool adapter configuration (on_denied setting)",
        "Adjust the governance policy if the tool call should be permitted",
        "Consider using on_denied='result' to receive denials as return values instead",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="PolicyLoadError",
    aliases=["policy_load", "policy_file", "policy_parse"],
    what_it_means=(
        "A governance policy file could not be loaded or parsed. The policy "
        "engine cannot apply rules from this file."
    ),
    common_causes=[
        "Syntax error in the policy file (malformed YAML or JSON)",
        "The policy file path does not exist or is not readable",
        "The policy file schema does not match the expected format",
    ],
    how_to_fix=[
        "Validate the policy file: nomotic policy-validate",
        "Check the file path and permissions",
        "Review the policy file for YAML/JSON syntax errors",
        "Compare the file against the policy schema documentation",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="FrameworkLoadError",
    aliases=["framework_load", "compliance_framework", "framework_file"],
    what_it_means=(
        "A compliance framework file could not be loaded or validated. "
        "The compliance report generator cannot include this framework "
        "in its analysis."
    ),
    common_causes=[
        "The framework file path does not exist or is not readable",
        "The framework file has invalid structure or missing required fields",
        "A custom framework definition references unknown control families",
    ],
    how_to_fix=[
        "Check the framework file path and permissions",
        "Validate the file format against the compliance framework schema",
        "Run: nomotic compliance-report --list-frameworks  to see available frameworks",
        "If custom: compare against a built-in framework for correct structure",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="AGICOMPLYError",
    aliases=["agicomply", "agicomply_push", "agicomply_integration"],
    what_it_means=(
        "A push to the AGICOMPLY external compliance platform failed. "
        "Audit logs or governance data could not be transmitted to the "
        "AGICOMPLY API endpoint."
    ),
    common_causes=[
        "The AGICOMPLY API endpoint is unreachable or returned an error",
        "The AGICOMPLY API key or credentials are invalid or expired",
        "Network connectivity issues between the runtime and the AGICOMPLY service",
    ],
    how_to_fix=[
        "Check AGICOMPLY API connectivity and credentials in nomotic.yaml",
        "Verify the AGICOMPLY endpoint URL is correct",
        "Check network connectivity to the AGICOMPLY service",
        "Review the AGICOMPLY API response for specific error details",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="NomoticSDKError",
    aliases=["sdk", "sdk_error", "nomotic_sdk"],
    what_it_means=(
        "A base SDK-level error occurred. This is the parent class for "
        "SDK-specific exceptions (CertificateLoadError, GovernedRequestError). "
        "Check the specific subclass for more details."
    ),
    common_causes=[
        "A certificate or key file failed to load",
        "An HTTP request to the governance API failed at the network level",
        "The SDK was not properly initialized or configured",
    ],
    how_to_fix=[
        "Check the specific error subclass for targeted guidance",
        "Run: nomotic diagnose CertificateLoadError  if cert-related",
        "Run: nomotic diagnose GovernedRequestError  if network-related",
        "Verify SDK initialization and configuration in your application",
    ],
    doctor_check=None,
))

_register(DiagnosticEntry(
    error_class="CertificateLoadError",
    aliases=["cert_load", "certificate_load", "key_load"],
    what_it_means=(
        "A certificate or cryptographic key failed to load from file "
        "during SDK operations. The SDK cannot authenticate or sign "
        "governance requests without valid credentials."
    ),
    common_causes=[
        "The certificate file path does not exist",
        "The certificate file is corrupted or in an unexpected format",
        "File permissions prevent reading the certificate or key",
        "The cryptography dependency is not installed or is incompatible",
    ],
    how_to_fix=[
        "Verify the certificate file path in your SDK configuration",
        "Check file permissions: the runtime user must be able to read the file",
        "Run: nomotic doctor  — check the Certificate Store section",
        "Reinstall dependencies: pip install nomotic[crypto]",
    ],
    doctor_check="Certificate Store",
))

_register(DiagnosticEntry(
    error_class="GovernedRequestError",
    aliases=["governed_request", "http_error", "network_error", "request_error"],
    what_it_means=(
        "An HTTP request made through the governed SDK failed at the network "
        "level. The request could not reach the governance API endpoint."
    ),
    common_causes=[
        "The governance API endpoint is unreachable or down",
        "Network connectivity issues (DNS, firewall, proxy)",
        "Request timeout due to slow or unresponsive API",
        "Invalid or expired TLS certificates on the API endpoint",
    ],
    how_to_fix=[
        "Check network connectivity to the governance API endpoint",
        "Verify the API endpoint URL in your SDK configuration",
        "Check for firewall or proxy rules blocking the connection",
        "If TLS error: verify the API endpoint's TLS certificate is valid",
    ],
    doctor_check=None,
))


# ── Lookup functions ─────────────────────────────────────────────────────


def resolve_diagnostic(query: str) -> DiagnosticEntry | None:
    """Fuzzy lookup: exact match -> alias match -> substring match.

    Case-insensitive throughout.
    """
    q = query.lower().strip()

    # Exact match (error class name or alias)
    if q in DIAGNOSTIC_REGISTRY:
        return DIAGNOSTIC_REGISTRY[q]

    # Substring match on error class names
    for key, entry in DIAGNOSTIC_REGISTRY.items():
        if q in key or q in entry.error_class.lower():
            return entry

    return None


def list_known_errors() -> list[str]:
    """Returns deduplicated list of error class names."""
    seen: set[str] = set()
    result: list[str] = []
    for entry in DIAGNOSTIC_REGISTRY.values():
        if entry.error_class not in seen:
            seen.add(entry.error_class)
            result.append(entry.error_class)
    return sorted(result)
