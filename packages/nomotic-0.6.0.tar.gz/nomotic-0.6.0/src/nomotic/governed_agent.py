"""GovernedAgent base class — governance wrapper for framework-integrated agents.

Provides a clean interface for any AI agent framework (LangGraph, CrewAI,
OpenAI, etc.) to integrate Nomotic governance into its execution lifecycle.

Three entry points:
  - govern_action()   — pre-action governance evaluation
  - validate_output() — post-generation output validation
  - governed_run()    — full lifecycle: govern → execute → validate

Usage:
    from nomotic.governed_agent import GovernedAgent, GovernanceVetoError

    governed = GovernedAgent(runtime, certificate, output_governor)

    result = governed.govern_action("read", "patient_records")
    if result.allowed:
        output = execute_the_action()
        output_result = governed.validate_output(output, "read")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.runtime import GovernanceRuntime
    from nomotic.certificate import AgentCertificate
    from nomotic.output_governor import OutputGovernor

__all__ = [
    "GovernanceVetoError",
    "GovernedAgentBase",
    "GovResult",
    "OutputResult",
]


class GovernanceVetoError(Exception):
    """Raised by governed_run() when an action is DENY or BLOCK."""

    def __init__(
        self,
        verdict: str,
        ucs_score: float,
        record_id: str,
        action_to_pass: str | None = None,
    ):
        self.verdict = verdict
        self.ucs_score = ucs_score
        self.record_id = record_id
        self.action_to_pass = action_to_pass
        super().__init__(
            f"Governance veto: {verdict} (UCS {ucs_score:.2f}). "
            f"Record: {record_id}"
        )


@dataclass
class GovResult:
    """Result of a pre-action governance evaluation."""

    verdict: str          # "ALLOW", "DENY", "ESCALATE", "BLOCK"
    ucs_score: float
    record_id: str
    allowed: bool         # True only for ALLOW verdict

    @classmethod
    def from_evaluation(cls, eval_result: Any) -> GovResult:
        verdict_str = (
            eval_result.verdict.name
            if hasattr(eval_result.verdict, "name")
            else str(eval_result.verdict)
        )
        return cls(
            verdict=verdict_str,
            ucs_score=eval_result.ucs,
            record_id=getattr(eval_result, "action_id", ""),
            allowed=(verdict_str == "ALLOW"),
        )


@dataclass
class OutputResult:
    """Result of post-generation output validation."""

    verdict: str          # OutputVerdict value as string
    output: str           # Original or (if REDACT) redacted output
    redacted: bool = False


class GovernedAgentBase:
    """Base class for framework-governed agents.

    Wraps GovernanceRuntime and OutputGovernor to provide:
      - Pre-action governance (govern_action)
      - Post-generation output validation (validate_output)
      - Full governed execution lifecycle (governed_run)

    Usage::

        governed = GovernedAgentBase(runtime, certificate, output_governor)
        result = governed.govern_action("read", "patient_records", {})
        if result.allowed:
            output = execute_the_action()
            output_result = governed.validate_output(output, "read")
    """

    def __init__(
        self,
        runtime: GovernanceRuntime,
        certificate: AgentCertificate,
        output_governor: OutputGovernor | None = None,
        default_zone: str | None = None,
    ):
        self.runtime = runtime
        self.certificate = certificate
        self.output_governor = output_governor
        self.default_zone = default_zone or getattr(
            certificate, "zone_path", "default"
        )

    def govern_action(
        self,
        action_type: str,
        target: str,
        parameters: dict[str, Any] | None = None,
        reversible: bool = True,
        context_overrides: dict[str, Any] | None = None,
    ) -> GovResult:
        """Evaluate an action through governance before executing it.

        Returns GovResult. Does NOT raise on DENY — check result.allowed.
        """
        from nomotic.types import Action, AgentContext, TrustProfile

        action = Action(
            agent_id=self.certificate.agent_id,
            action_type=action_type,
            target=target,
            parameters=parameters or {},
            metadata={"reversible": reversible},
        )

        trust_profile = TrustProfile(
            agent_id=self.certificate.agent_id,
            overall_trust=getattr(self.certificate, "trust_score", 0.5),
        )

        ctx_kwargs: dict[str, Any] = {
            "agent_id": self.certificate.agent_id,
            "trust_profile": trust_profile,
        }
        if context_overrides:
            valid_fields = {
                "session_id",
                "active_constraints",
                "metadata",
                "user_context",
                "context_profile_id",
            }
            for key, val in context_overrides.items():
                if key in valid_fields:
                    ctx_kwargs[key] = val

        ctx = AgentContext(**ctx_kwargs)
        eval_result = self.runtime.evaluate(action, ctx)
        return GovResult.from_evaluation(eval_result)

    def validate_output(
        self,
        output: str,
        action_type: str | None = None,
    ) -> OutputResult:
        """Validate agent output through OutputGovernor if configured.

        If no OutputGovernor: returns OUTPUT_PASS with original output.
        """
        if self.output_governor is None:
            return OutputResult(verdict="OUTPUT_PASS", output=output)

        result = self.output_governor.evaluate(
            output=output,
            agent_id=self.certificate.agent_id,
        )

        verdict_str = result.verdict
        redacted = verdict_str == "REDACT"
        final_output = (
            result.redacted_output
            if redacted and result.redacted_output
            else output
        )

        return OutputResult(
            verdict=verdict_str, output=final_output, redacted=redacted
        )

    def governed_run(
        self,
        action_type: str,
        target: str,
        parameters: dict[str, Any] | None = None,
        execute_fn: Callable[[], str] | None = None,
        reversible: bool = True,
        context_overrides: dict[str, Any] | None = None,
    ) -> str:
        """Full governed execution: pre-action governance -> execute -> output validation.

        execute_fn is a callable that returns a string output.
        Raises GovernanceVetoError if verdict is DENY or BLOCK.
        Returns validated (and possibly redacted) output string.
        """
        gov_result = self.govern_action(
            action_type, target, parameters, reversible, context_overrides
        )

        if not gov_result.allowed:
            raise GovernanceVetoError(
                verdict=gov_result.verdict,
                ucs_score=gov_result.ucs_score,
                record_id=gov_result.record_id,
            )

        if execute_fn is None:
            return ""

        raw_output = execute_fn()
        output_result = self.validate_output(raw_output, action_type)
        return output_result.output
