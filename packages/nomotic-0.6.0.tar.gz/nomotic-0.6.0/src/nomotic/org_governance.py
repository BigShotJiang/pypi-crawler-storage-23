"""Organization-level governance with override protection.

Org-level governance sets minimum standards that all agents must meet.
Agent configs can be stricter but cannot go below org minimums.  This
creates a two-tier system: org rules (set centrally, enforced
automatically) and agent rules (set per-agent, must comply with org
rules).

Org config is optional.  If no ``nomotic-org.yaml`` is found, governance
operates purely at the agent level as before.

YAML format (``nomotic-org.yaml``)::

    org_name: "Acme Corp"

    minimum_weights:
      scope_compliance: 1.5
      authority_verification: 1.5
      human_override: 2.0
      ethical_alignment: 2.0

    required_vetoes:
      - scope_compliance
      - authority_verification
      - human_override

    minimum_allow_threshold: 0.70
    minimum_deny_threshold: 0.30

    trust:
      minimum_violation_decrement: 0.05
      maximum_success_increment: 0.02

    # Optional: restrict which presets agents can extend from
    # allowed_presets: [hipaa_aligned, soc2_aligned, strict, ultra_strict]

    required_frameworks: []
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TYPE_CHECKING

from nomotic.presets import (
    get_preset,
)

if TYPE_CHECKING:
    from nomotic.config_loader import GovernanceConfig

__all__ = [
    "OrgGovernanceConfig",
    "OrgViolation",
    "enforce_org_policy",
    "generate_org_config_from_preset",
    "load_org_config",
    "save_org_config",
]

# File names to search for when walking up the directory tree.
_ORG_CONFIG_FILENAMES = ("nomotic-org.yaml", "nomotic-org.yml")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class OrgGovernanceConfig:
    """Organization-level governance minimums."""

    org_name: str

    # Minimum dimension weights — agents cannot go below these
    minimum_weights: dict[str, float]

    # Required vetoes — agents cannot remove these
    required_vetoes: list[str]

    # Threshold floors
    minimum_allow_threshold: float
    minimum_deny_threshold: float

    # Trust constraints
    minimum_violation_decrement: float
    maximum_success_increment: float

    # Optional: restrict which presets agents can use (canonical names only)
    allowed_presets: list[str] | None = None

    # Required compliance frameworks (descriptive labels, not preset names)
    required_frameworks: list[str] = field(default_factory=list)

    # Source file path
    source_path: str = ""


@dataclass
class OrgViolation:
    """A single org policy violation in an agent's config."""

    field: str          # e.g., "dimensions.weights.scope_compliance"
    requirement: str    # e.g., "Minimum weight: 1.5"
    actual: str         # e.g., "Agent weight: 1.0"
    severity: str = "critical"  # Always "critical" for org violations


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _import_yaml() -> Any:
    """Lazily import PyYAML."""
    try:
        import yaml
        return yaml
    except ImportError:  # pragma: no cover
        raise ImportError(
            "PyYAML is required for loading YAML configs. "
            "Install it with: pip install pyyaml"
        ) from None


def _walk_up(start: Path) -> Path | None:
    """Search for an org config file starting at *start* and walking up."""
    current = start.resolve()
    while True:
        for filename in _ORG_CONFIG_FILENAMES:
            candidate = current / filename
            if candidate.is_file():
                return candidate
        parent = current.parent
        if parent == current:
            # Reached filesystem root
            break
        current = parent
    return None


def _as_str_list(value: Any) -> list[str]:
    """Coerce a value into a list of strings."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


def _parse_org_yaml(raw: dict[str, Any], source_path: str) -> OrgGovernanceConfig:
    """Parse a raw YAML dict into an OrgGovernanceConfig."""
    org_name = str(raw.get("org_name", ""))

    # Minimum weights
    minimum_weights_raw = raw.get("minimum_weights", {})
    minimum_weights: dict[str, float] = {}
    if isinstance(minimum_weights_raw, dict):
        for dim, val in minimum_weights_raw.items():
            minimum_weights[str(dim)] = float(val)

    # Required vetoes
    required_vetoes = _as_str_list(raw.get("required_vetoes", []))

    # Threshold floors
    minimum_allow_threshold = float(raw.get("minimum_allow_threshold", 0.0))
    minimum_deny_threshold = float(raw.get("minimum_deny_threshold", 0.0))

    # Trust constraints
    trust_raw = raw.get("trust", {})
    if not isinstance(trust_raw, dict):
        trust_raw = {}
    minimum_violation_decrement = float(
        trust_raw.get("minimum_violation_decrement", 0.0)
    )
    maximum_success_increment = float(
        trust_raw.get("maximum_success_increment", 1.0)
    )

    # Allowed presets (optional)
    allowed_presets_raw = raw.get("allowed_presets")
    allowed_presets: list[str] | None = None
    if allowed_presets_raw is not None:
        allowed_presets = _as_str_list(allowed_presets_raw)

    # Required frameworks
    required_frameworks = _as_str_list(raw.get("required_frameworks", []))

    return OrgGovernanceConfig(
        org_name=org_name,
        minimum_weights=minimum_weights,
        required_vetoes=required_vetoes,
        minimum_allow_threshold=minimum_allow_threshold,
        minimum_deny_threshold=minimum_deny_threshold,
        minimum_violation_decrement=minimum_violation_decrement,
        maximum_success_increment=maximum_success_increment,
        allowed_presets=allowed_presets,
        required_frameworks=required_frameworks,
        source_path=source_path,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_org_config(path: str | Path | None = None) -> OrgGovernanceConfig | None:
    """Load org config. Search order:

    1. Explicit path if provided
    2. ``nomotic-org.yaml`` in current directory, walking up to filesystem root
    3. ``~/.nomotic/org-governance.yaml``

    Returns ``None`` if no org config found (org governance is optional).
    """
    yaml = _import_yaml()

    # 1. Explicit path
    if path is not None:
        p = Path(path)
        if not p.is_file():
            raise FileNotFoundError(f"Org config not found: {p}")
        raw = yaml.safe_load(p.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError(f"Org config must be a YAML mapping: {p}")
        return _parse_org_yaml(raw, source_path=str(p))

    # 2. Walk up from current directory
    found = _walk_up(Path.cwd())
    if found is not None:
        raw = yaml.safe_load(found.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return _parse_org_yaml(raw, source_path=str(found))

    # 3. User home directory
    home_config = Path.home() / ".nomotic" / "org-governance.yaml"
    if home_config.is_file():
        raw = yaml.safe_load(home_config.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return _parse_org_yaml(raw, source_path=str(home_config))

    return None


def save_org_config(config: OrgGovernanceConfig, path: str | Path) -> None:
    """Write org config to a YAML file."""
    yaml = _import_yaml()

    data: dict[str, Any] = {"org_name": config.org_name}

    if config.minimum_weights:
        data["minimum_weights"] = dict(config.minimum_weights)

    if config.required_vetoes:
        data["required_vetoes"] = list(config.required_vetoes)

    data["minimum_allow_threshold"] = config.minimum_allow_threshold
    data["minimum_deny_threshold"] = config.minimum_deny_threshold

    data["trust"] = {
        "minimum_violation_decrement": config.minimum_violation_decrement,
        "maximum_success_increment": config.maximum_success_increment,
    }

    if config.allowed_presets is not None:
        data["allowed_presets"] = list(config.allowed_presets)

    if config.required_frameworks:
        data["required_frameworks"] = list(config.required_frameworks)
    else:
        data["required_frameworks"] = []

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        yaml.dump(data, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )


def enforce_org_policy(
    agent_config: GovernanceConfig,
    org_config: OrgGovernanceConfig,
) -> list[OrgViolation]:
    """Check agent config against org minimums. Returns list of violations.

    Empty list = compliant.

    Checks:

    - Every dimension in org ``minimum_weights``: agent's weight must be >=
    - Every dimension in org ``required_vetoes``: must be in agent's veto list
    - Agent's ``allow_threshold`` >= org ``minimum_allow_threshold``
    - Agent's ``deny_threshold`` >= org ``minimum_deny_threshold``
    - Agent's trust ``violation_decrement`` >= org ``minimum_violation_decrement``
    - Agent's trust ``success_increment`` <= org ``maximum_success_increment``
    - If org has ``allowed_presets`` and agent uses ``extends``: all agent
      extends must be in allowed list
    - If org has ``required_frameworks``: agent must declare them in
      ``compliance.frameworks``
    """
    violations: list[OrgViolation] = []

    # 1. Minimum weights
    for dim_name, min_weight in org_config.minimum_weights.items():
        agent_weight = agent_config.dimension_weights.get(dim_name, 0.0)
        if agent_weight < min_weight:
            violations.append(OrgViolation(
                field=f"dimensions.weights.{dim_name}",
                requirement=f"Minimum weight: {min_weight}",
                actual=f"Agent weight: {agent_weight}",
                severity="critical",
            ))

    # 2. Required vetoes
    agent_veto_set = set(agent_config.veto_dimensions)
    for veto_dim in org_config.required_vetoes:
        if veto_dim not in agent_veto_set:
            violations.append(OrgViolation(
                field=f"dimensions.vetoes.{veto_dim}",
                requirement=f"Required veto: {veto_dim}",
                actual="Missing from agent veto list",
                severity="critical",
            ))

    # 3. Allow threshold
    if agent_config.allow_threshold < org_config.minimum_allow_threshold:
        violations.append(OrgViolation(
            field="thresholds.allow",
            requirement=f"Minimum allow_threshold: {org_config.minimum_allow_threshold}",
            actual=f"Agent allow_threshold: {agent_config.allow_threshold}",
            severity="critical",
        ))

    # 4. Deny threshold
    if agent_config.deny_threshold < org_config.minimum_deny_threshold:
        violations.append(OrgViolation(
            field="thresholds.deny",
            requirement=f"Minimum deny_threshold: {org_config.minimum_deny_threshold}",
            actual=f"Agent deny_threshold: {agent_config.deny_threshold}",
            severity="critical",
        ))

    # 5. Trust: violation_decrement (must be >= org minimum)
    agent_violation_decrement = agent_config.trust_settings.get(
        "violation_decrement", 0.0
    )
    if agent_violation_decrement < org_config.minimum_violation_decrement:
        violations.append(OrgViolation(
            field="trust.violation_decrement",
            requirement=f"Minimum violation_decrement: {org_config.minimum_violation_decrement}",
            actual=f"Agent violation_decrement: {agent_violation_decrement}",
            severity="critical",
        ))

    # 6. Trust: success_increment (must be <= org maximum)
    agent_success_increment = agent_config.trust_settings.get(
        "success_increment", 0.0
    )
    if agent_success_increment > org_config.maximum_success_increment:
        violations.append(OrgViolation(
            field="trust.success_increment",
            requirement=f"Maximum success_increment: {org_config.maximum_success_increment}",
            actual=f"Agent success_increment: {agent_success_increment}",
            severity="critical",
        ))

    # 7. Allowed presets
    if org_config.allowed_presets is not None and agent_config.extends:
        allowed_set = {p.lower() for p in org_config.allowed_presets}
        for preset_name in agent_config.extends:
            if preset_name.lower() not in allowed_set:
                violations.append(OrgViolation(
                    field=f"extends.{preset_name}",
                    requirement=f"Allowed presets: {org_config.allowed_presets}",
                    actual=f"Agent uses preset: {preset_name}",
                    severity="critical",
                ))

    # 8. Required frameworks
    if org_config.required_frameworks:
        agent_frameworks_set = {
            f.lower() for f in agent_config.compliance_frameworks
        }
        for framework in org_config.required_frameworks:
            if framework.lower() not in agent_frameworks_set:
                violations.append(OrgViolation(
                    field=f"compliance.frameworks.{framework}",
                    requirement=f"Required framework: {framework}",
                    actual="Missing from agent compliance frameworks",
                    severity="critical",
                ))

    return violations


def generate_org_config_from_preset(
    org_name: str,
    preset_name: str,
) -> OrgGovernanceConfig:
    """Generate an org config using a preset's values as the minimums.

    ``preset_name`` must be a canonical name (e.g., ``"hipaa_aligned"``,
    ``"strict"``).
    """
    preset = get_preset(preset_name)  # raises KeyError if not found

    return OrgGovernanceConfig(
        org_name=org_name,
        minimum_weights=dict(preset.dimension_weights),
        required_vetoes=list(preset.veto_dimensions),
        minimum_allow_threshold=preset.allow_threshold,
        minimum_deny_threshold=preset.deny_threshold,
        minimum_violation_decrement=preset.trust_settings["violation_decrement"],
        maximum_success_increment=preset.trust_settings["success_increment"],
        allowed_presets=None,
        required_frameworks=[],
        source_path="",
    )
