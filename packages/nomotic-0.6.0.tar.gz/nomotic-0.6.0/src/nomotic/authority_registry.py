"""Governance Authority Registry — executable decision rights.

Formalizes *who has the right to change governance configuration*.  Every
governance configuration change must be attributed to a named authority with
an explicit role.  Changes made by unrecognised authorities are **rejected**
with :class:`UnauthorizedGovernanceChange`, not logged as warnings.

This implements "executable decision rights": ownership of governance
configuration is enforced code, not a policy document.

Note: This module (``authority_registry.py``) is distinct from
``authority.py`` (the Certificate Authority).  The primary class is
:class:`GovernanceAuthorityRegistry`.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

__all__ = [
    "GovernanceRole",
    "GovernanceAuthority",
    "GovernanceChangeRecord",
    "UnauthorizedGovernanceChange",
    "GovernanceAuthorityRegistry",
]


# ── Roles ───────────────────────────────────────────────────────────────


class GovernanceRole(str, Enum):
    """Roles that govern what configuration changes an authority can make."""

    CONSTITUTIONAL_GUARDIAN = "constitutional_guardian"
    # Can: load/replace constitutional rulesets, add constitutional rules
    # Cannot: change dimensions, policies, scope, trust

    POLICY_AUTHOR = "policy_author"
    # Can: load/update compliance policies, create compliance frameworks
    # Cannot: change constitutional rules, modify trust config

    SCOPE_OWNER = "scope_owner"
    # Can: configure agent scope, set zone validators, update archetype
    #      assignments for specific agents
    # Cannot: change trust config, modify policies, constitutional rules

    TRUST_ADMINISTRATOR = "trust_administrator"
    # Can: configure trust thresholds, reset trust profiles,
    #      modify trust calibration config
    # Cannot: change scope, policies, constitutional rules

    RUNTIME_ADMINISTRATOR = "runtime_administrator"
    # Can: all of the above — superuser governance role
    # Requires: additional audit record with reason

    OBSERVER = "observer"
    # Can: read any governance configuration
    # Cannot: change anything


# ── Data classes ────────────────────────────────────────────────────────


def _canonical_json(obj: dict[str, Any]) -> str:
    """Return deterministic JSON for hashing."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


@dataclass
class GovernanceAuthority:
    """A named authority permitted to make governance configuration changes."""

    authority_id: str  # nma-<uuid4>
    name: str
    roles: list[GovernanceRole]
    created_by: str  # Who granted this authority
    created_at: float
    expires_at: float | None = None  # Optional expiry (Unix timestamp)
    notes: str = ""
    authority_hash: str = ""  # SHA-256 of canonical JSON (computed on init)

    def __post_init__(self) -> None:
        if not self.authority_hash:
            self.authority_hash = self.compute_hash()

    def compute_hash(self) -> str:
        """Compute SHA-256 of the canonical JSON representation."""
        payload = {
            "authority_id": self.authority_id,
            "name": self.name,
            "roles": [r.value for r in self.roles],
            "created_by": self.created_by,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "notes": self.notes,
        }
        digest = hashlib.sha256(_canonical_json(payload).encode()).hexdigest()
        return digest

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    def has_role(self, role: GovernanceRole) -> bool:
        if GovernanceRole.RUNTIME_ADMINISTRATOR in self.roles:
            return True
        return role in self.roles

    def to_dict(self) -> dict[str, Any]:
        return {
            "authority_id": self.authority_id,
            "name": self.name,
            "roles": [r.value for r in self.roles],
            "created_by": self.created_by,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "notes": self.notes,
            "authority_hash": self.authority_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GovernanceAuthority:
        roles = [GovernanceRole(r) for r in data["roles"]]
        return cls(
            authority_id=data["authority_id"],
            name=data["name"],
            roles=roles,
            created_by=data["created_by"],
            created_at=data["created_at"],
            expires_at=data.get("expires_at"),
            notes=data.get("notes", ""),
            authority_hash=data.get("authority_hash", ""),
        )


@dataclass(frozen=True)
class GovernanceChangeRecord:
    """Immutable record of a governance configuration change."""

    change_id: str  # nmgc-<uuid4>
    authority_id: str
    authority_name: str
    role_used: GovernanceRole
    change_type: str  # e.g. "scope_update", "policy_load", "trust_reset", "constitutional_load"
    target: str  # What was changed (agent_id, policy_id, etc.)
    reason: str  # Mandatory reason string
    changed_at: float
    change_hash: str  # SHA-256 of canonical JSON

    def to_dict(self) -> dict[str, Any]:
        return {
            "change_id": self.change_id,
            "authority_id": self.authority_id,
            "authority_name": self.authority_name,
            "role_used": self.role_used.value,
            "change_type": self.change_type,
            "target": self.target,
            "reason": self.reason,
            "changed_at": self.changed_at,
            "change_hash": self.change_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GovernanceChangeRecord:
        return cls(
            change_id=data["change_id"],
            authority_id=data["authority_id"],
            authority_name=data["authority_name"],
            role_used=GovernanceRole(data["role_used"]),
            change_type=data["change_type"],
            target=data["target"],
            reason=data["reason"],
            changed_at=data["changed_at"],
            change_hash=data["change_hash"],
        )


def _compute_change_hash(
    change_id: str,
    authority_id: str,
    role_used: GovernanceRole,
    change_type: str,
    target: str,
    reason: str,
    changed_at: float,
) -> str:
    """Compute SHA-256 hash of a change record."""
    payload = {
        "change_id": change_id,
        "authority_id": authority_id,
        "role_used": role_used.value,
        "change_type": change_type,
        "target": target,
        "reason": reason,
        "changed_at": changed_at,
    }
    return hashlib.sha256(_canonical_json(payload).encode()).hexdigest()


# ── Exception ───────────────────────────────────────────────────────────


class UnauthorizedGovernanceChange(Exception):
    """Raised when an unregistered or insufficiently privileged authority
    attempts a governance configuration change."""

    def __init__(
        self,
        authority_id: str,
        required_role: GovernanceRole,
        change_type: str,
    ) -> None:
        self.authority_id = authority_id
        self.required_role = required_role
        self.change_type = change_type
        super().__init__(
            f"Authority '{authority_id}' is not authorized for "
            f"{change_type} (requires {required_role.value})"
        )


# ── Registry ────────────────────────────────────────────────────────────


class GovernanceAuthorityRegistry:
    """Registry of authorities permitted to change governance configuration.

    Thread-safe.  All mutations produce :class:`GovernanceChangeRecord` instances.
    """

    _BOOTSTRAP_ID = "__bootstrap__"

    def __init__(self, audit_store: Any = None) -> None:
        """
        Args:
            audit_store: Optional PersistentAuditStore for writing
                         change records.  If ``None``, changes are recorded
                         in-memory only.
        """
        self._authorities: dict[str, GovernanceAuthority] = {}
        self._change_history: list[GovernanceChangeRecord] = []
        self._audit_store = audit_store
        self._lock = threading.Lock()
        self._bootstrapped = False

    # ── Bootstrap ───────────────────────────────────────────────────

    def bootstrap(self, authority_id: str, name: str) -> GovernanceAuthority:
        """Create the initial RUNTIME_ADMINISTRATOR authority.

        Can only be called once (when registry is empty).  Subsequent calls
        raise ``RuntimeError``.  The bootstrap authority can then register
        all other authorities.
        """
        with self._lock:
            if self._bootstrapped or self._authorities:
                raise RuntimeError(
                    "Registry already bootstrapped — cannot bootstrap again"
                )

            now = time.time()
            authority = GovernanceAuthority(
                authority_id=authority_id,
                name=name,
                roles=[GovernanceRole.RUNTIME_ADMINISTRATOR],
                created_by="__bootstrap__",
                created_at=now,
            )
            self._authorities[authority_id] = authority
            self._bootstrapped = True

            # Record the bootstrap event
            record = self._make_change_record(
                authority_id=authority_id,
                authority_name=name,
                role_used=GovernanceRole.RUNTIME_ADMINISTRATOR,
                change_type="authority_bootstrap",
                target=authority_id,
                reason="Initial bootstrap of governance authority registry",
            )
            self._change_history.append(record)
            self._persist_change(record)

            return authority

    # ── Authority management ────────────────────────────────────────

    def register_authority(
        self,
        authority: GovernanceAuthority,
        registering_authority_id: str,
        reason: str,
    ) -> None:
        """Register a new governance authority.

        Requires ``registering_authority_id`` to hold
        :attr:`GovernanceRole.RUNTIME_ADMINISTRATOR` (or be the bootstrap
        authority when the registry is empty).
        """
        with self._lock:
            # Validate the registering authority
            self._require_role(
                registering_authority_id,
                GovernanceRole.RUNTIME_ADMINISTRATOR,
                "authority_register",
            )

            if authority.authority_id in self._authorities:
                raise ValueError(
                    f"Authority '{authority.authority_id}' is already registered"
                )

            self._authorities[authority.authority_id] = authority

            record = self._make_change_record(
                authority_id=registering_authority_id,
                authority_name=self._resolve_name(registering_authority_id),
                role_used=GovernanceRole.RUNTIME_ADMINISTRATOR,
                change_type="authority_register",
                target=authority.authority_id,
                reason=reason,
            )
            self._change_history.append(record)
            self._persist_change(record)

    def revoke_authority(
        self,
        authority_id: str,
        revoking_authority_id: str,
        reason: str,
    ) -> None:
        """Revoke a registered authority.  Requires RUNTIME_ADMINISTRATOR."""
        with self._lock:
            self._require_role(
                revoking_authority_id,
                GovernanceRole.RUNTIME_ADMINISTRATOR,
                "authority_revoke",
            )

            if authority_id not in self._authorities:
                raise KeyError(f"Authority '{authority_id}' not found")

            del self._authorities[authority_id]

            record = self._make_change_record(
                authority_id=revoking_authority_id,
                authority_name=self._resolve_name(revoking_authority_id),
                role_used=GovernanceRole.RUNTIME_ADMINISTRATOR,
                change_type="authority_revoke",
                target=authority_id,
                reason=reason,
            )
            self._change_history.append(record)
            self._persist_change(record)

    # ── Permission checking ─────────────────────────────────────────

    def check_permission(
        self,
        authority_id: str,
        required_role: GovernanceRole,
        change_type: str,
        target: str = "",
        reason: str = "",
    ) -> GovernanceChangeRecord:
        """Check if ``authority_id`` holds ``required_role``.

        On success: creates and returns a :class:`GovernanceChangeRecord`,
        writes to audit store if configured.

        On failure: raises :class:`UnauthorizedGovernanceChange`.

        Also raises :class:`UnauthorizedGovernanceChange` if the authority
        is expired.
        """
        with self._lock:
            # Bootstrap escape hatch: when registry is empty, allow
            # __bootstrap__ for RUNTIME_ADMINISTRATOR operations only.
            if (
                authority_id == self._BOOTSTRAP_ID
                and not self._authorities
                and required_role == GovernanceRole.RUNTIME_ADMINISTRATOR
            ):
                record = self._make_change_record(
                    authority_id=self._BOOTSTRAP_ID,
                    authority_name="__bootstrap__",
                    role_used=GovernanceRole.RUNTIME_ADMINISTRATOR,
                    change_type=change_type,
                    target=target,
                    reason=reason or "bootstrap",
                )
                self._change_history.append(record)
                self._persist_change(record)
                return record

            self._require_role(authority_id, required_role, change_type)

            authority = self._authorities[authority_id]
            record = self._make_change_record(
                authority_id=authority_id,
                authority_name=authority.name,
                role_used=required_role,
                change_type=change_type,
                target=target,
                reason=reason,
            )
            self._change_history.append(record)
            self._persist_change(record)
            return record

    # ── Queries ─────────────────────────────────────────────────────

    def get_authority(self, authority_id: str) -> GovernanceAuthority | None:
        """Return the authority for *authority_id*, or ``None``."""
        return self._authorities.get(authority_id)

    def list_authorities(self) -> list[GovernanceAuthority]:
        """Return all registered (non-revoked) authorities."""
        return list(self._authorities.values())

    def get_change_history(
        self,
        authority_id: str | None = None,
        limit: int = 100,
    ) -> list[GovernanceChangeRecord]:
        """Return change history, optionally filtered by authority."""
        records = self._change_history
        if authority_id is not None:
            records = [r for r in records if r.authority_id == authority_id]
        return records[-limit:]

    # ── Persistence ─────────────────────────────────────────────────

    def load_from_file(self, path: Path) -> None:
        """Load authorities from a JSON file."""
        with open(path) as f:
            data = json.load(f)

        with self._lock:
            for entry in data.get("authorities", []):
                authority = GovernanceAuthority.from_dict(entry)
                self._authorities[authority.authority_id] = authority
            if self._authorities:
                self._bootstrapped = True

    def save_to_file(self, path: Path) -> None:
        """Save authorities to a JSON file."""
        data = {
            "authorities": [a.to_dict() for a in self._authorities.values()],
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)

    # ── Internal helpers ────────────────────────────────────────────

    def _require_role(
        self,
        authority_id: str,
        required_role: GovernanceRole,
        change_type: str,
    ) -> None:
        """Validate that *authority_id* holds *required_role*.

        Raises :class:`UnauthorizedGovernanceChange` on any failure.
        """
        authority = self._authorities.get(authority_id)
        if authority is None:
            raise UnauthorizedGovernanceChange(
                authority_id, required_role, change_type
            )
        if authority.is_expired():
            raise UnauthorizedGovernanceChange(
                authority_id, required_role, change_type
            )
        if not authority.has_role(required_role):
            raise UnauthorizedGovernanceChange(
                authority_id, required_role, change_type
            )

    def _resolve_name(self, authority_id: str) -> str:
        authority = self._authorities.get(authority_id)
        if authority is not None:
            return authority.name
        return authority_id

    def _make_change_record(
        self,
        authority_id: str,
        authority_name: str,
        role_used: GovernanceRole,
        change_type: str,
        target: str,
        reason: str,
    ) -> GovernanceChangeRecord:
        change_id = f"nmgc-{uuid.uuid4()}"
        changed_at = time.time()
        change_hash = _compute_change_hash(
            change_id=change_id,
            authority_id=authority_id,
            role_used=role_used,
            change_type=change_type,
            target=target,
            reason=reason,
            changed_at=changed_at,
        )
        return GovernanceChangeRecord(
            change_id=change_id,
            authority_id=authority_id,
            authority_name=authority_name,
            role_used=role_used,
            change_type=change_type,
            target=target,
            reason=reason,
            changed_at=changed_at,
            change_hash=change_hash,
        )

    def _persist_change(self, record: GovernanceChangeRecord) -> None:
        """Write change record to the audit store if configured."""
        if self._audit_store is None:
            return
        try:
            self._audit_store.append(
                "governance-authority-registry", record.to_dict()
            )
        except Exception:
            pass  # Audit store failures must never block governance
