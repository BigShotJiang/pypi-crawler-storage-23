"""Pre-Evaluation State Continuity Check — lightweight integrity probes.

Governance infrastructure can be tampered with between evaluations: audit
records deleted, seals modified, hash chains broken.  Full verification
(``nomotic audit <agent> --verify``) catches this but is too expensive to
run before every evaluation.

The continuity checker runs a small set of **fast probes** before each
evaluation.  Each probe checks a single invariant that should always hold
between consecutive evaluations:

1. **last_record_hash** — the most recent audit record hash matches the
   value cached at the previous evaluation.
2. **record_count_monotone** — the audit record count for an agent never
   decreases.
3. **cert_store_consistency** — the certificate count in the store has not
   decreased (revocations move certs, deletions are not expected).
4. **seal_count_monotone** — the seal count for an agent never decreases
   (if a seal registry with per-agent counting is present).

These probes run in microseconds.  If any probe fails the checker records
the violation and either raises (strict mode) or returns a failing result
so the runtime can issue a DENY verdict.

This module is Item 16 of the Nomotic v0.5.0 roadmap.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

__all__ = [
    "ContinuityChecker",
    "ContinuityCheckResult",
    "ContinuityProbe",
    "ContinuityState",
    "ContinuityViolationError",
]


# ── Types ────────────────────────────────────────────────────────────────


class ContinuityProbe(str, Enum):
    """Identifiers for each continuity invariant probe."""

    LAST_RECORD_HASH = "last_record_hash"
    RECORD_COUNT_MONOTONE = "record_count_monotone"
    CERT_STORE_CONSISTENCY = "cert_store_consistency"
    SEAL_COUNT_MONOTONE = "seal_count_monotone"


@dataclass
class ContinuityCheckResult:
    """Outcome of a single continuity check run."""

    passed: bool
    probes_run: list[ContinuityProbe]
    failed_probes: list[ContinuityProbe]
    violations: list[str]  # Human-readable violation descriptions
    checked_at: float  # Unix timestamp
    agent_id: str

    # Snapshot values captured during this check (used by update_snapshot)
    _last_record_hash: str | None = field(default=None, repr=False)
    _record_count: int = field(default=0, repr=False)
    _cert_count: int = field(default=0, repr=False)
    _seal_count: int | None = field(default=None, repr=False)


@dataclass
class ContinuityState:
    """Cached state snapshot used for comparison on next evaluation."""

    agent_id: str
    last_record_hash: str | None
    record_count: int
    cert_count: int
    seal_count: int | None  # None if no seal registry
    snapshot_at: float


class ContinuityViolationError(Exception):
    """Raised in strict mode when a continuity probe fails."""

    def __init__(self, result: ContinuityCheckResult) -> None:
        self.result = result
        failed = ", ".join(p.value for p in result.failed_probes)
        super().__init__(
            f"Continuity violation for agent {result.agent_id}: "
            f"failed probes: [{failed}]"
        )


# ── Checker ──────────────────────────────────────────────────────────────


class ContinuityChecker:
    """Lightweight pre-evaluation integrity probe for governance infrastructure.

    Runs a configurable set of fast probes against the current state of
    audit stores, certificate stores, and seal registries.  Compares the
    observed values to a cached snapshot from the previous evaluation.

    On first evaluation for an agent (no cached snapshot) all probes pass
    unconditionally — there is nothing to compare against.

    Usage::

        checker = ContinuityChecker(strict_mode=True)
        result = checker.check(
            agent_id="agent-1",
            audit_store=persistent_store,
            cert_store=cert_store,
            seal_registry=seal_registry,
        )
        if not result.passed:
            # strict_mode would have already raised ContinuityViolationError
            ...
    """

    def __init__(
        self,
        enabled_probes: list[ContinuityProbe] | None = None,
        strict_mode: bool = False,
    ) -> None:
        """
        Args:
            enabled_probes: Which probes to run.  Default: all probes.
            strict_mode: If True, failures raise ContinuityViolationError.
                         If False (default), failures are recorded but
                         evaluation proceeds (verdict becomes DENY with
                         continuity violation reason).
        """
        if enabled_probes is not None:
            self._probes = list(enabled_probes)
        else:
            self._probes = list(ContinuityProbe)
        self._strict = strict_mode
        self._snapshots: dict[str, ContinuityState] = {}

    # ── Public API ───────────────────────────────────────────────────

    def check(
        self,
        agent_id: str,
        audit_store: Any | None = None,
        cert_store: Any | None = None,
        seal_registry: Any | None = None,
    ) -> ContinuityCheckResult:
        """Run enabled probes against current infrastructure state.

        Updates internal state snapshot after a passing check.
        On failure, does NOT update snapshot (preserves evidence of
        what was expected vs what was found).

        Args:
            agent_id: The agent being evaluated.
            audit_store: A ``LogStore`` / ``AuditStore`` / ``PersistentAuditStore``
                or None.
            cert_store: A ``MemoryCertificateStore`` or compatible store, or None.
            seal_registry: A ``SealRegistry`` with optional ``count_for_agent``
                method, or None.

        Returns:
            A :class:`ContinuityCheckResult` describing which probes ran,
            which failed, and human-readable violation descriptions.

        Raises:
            ContinuityViolationError: In strict mode when any probe fails.
        """
        now = time.time()
        snapshot = self._snapshots.get(agent_id)

        probes_run: list[ContinuityProbe] = []
        failed_probes: list[ContinuityProbe] = []
        violations: list[str] = []

        # Observed values (to cache after a passing check)
        obs_last_hash: str | None = None
        obs_record_count: int = 0
        obs_cert_count: int = 0
        obs_seal_count: int | None = None

        # ── Probe: LAST_RECORD_HASH ─────────────────────────────────
        if ContinuityProbe.LAST_RECORD_HASH in self._probes:
            if audit_store is not None and hasattr(audit_store, "get_last_hash"):
                probes_run.append(ContinuityProbe.LAST_RECORD_HASH)
                obs_last_hash = audit_store.get_last_hash(agent_id)
                if snapshot is not None and snapshot.last_record_hash is not None:
                    if obs_last_hash != snapshot.last_record_hash:
                        failed_probes.append(ContinuityProbe.LAST_RECORD_HASH)
                        violations.append(
                            f"Last record hash mismatch for agent '{agent_id}': "
                            f"expected '{_trunc(snapshot.last_record_hash)}', "
                            f"found '{_trunc(obs_last_hash)}'"
                        )

        # ── Probe: RECORD_COUNT_MONOTONE ─────────────────────────────
        if ContinuityProbe.RECORD_COUNT_MONOTONE in self._probes:
            if audit_store is not None and hasattr(audit_store, "query_all"):
                probes_run.append(ContinuityProbe.RECORD_COUNT_MONOTONE)
                obs_record_count = len(audit_store.query_all(agent_id))
                if snapshot is not None:
                    if obs_record_count < snapshot.record_count:
                        failed_probes.append(ContinuityProbe.RECORD_COUNT_MONOTONE)
                        violations.append(
                            f"Audit record count decreased for agent '{agent_id}': "
                            f"was {snapshot.record_count}, now {obs_record_count}"
                        )

        # ── Probe: CERT_STORE_CONSISTENCY ────────────────────────────
        if ContinuityProbe.CERT_STORE_CONSISTENCY in self._probes:
            if cert_store is not None and hasattr(cert_store, "list"):
                probes_run.append(ContinuityProbe.CERT_STORE_CONSISTENCY)
                obs_cert_count = len(cert_store.list())
                if snapshot is not None:
                    if obs_cert_count < snapshot.cert_count:
                        failed_probes.append(ContinuityProbe.CERT_STORE_CONSISTENCY)
                        violations.append(
                            f"Certificate count decreased: "
                            f"was {snapshot.cert_count}, now {obs_cert_count}"
                        )

        # ── Probe: SEAL_COUNT_MONOTONE ───────────────────────────────
        if ContinuityProbe.SEAL_COUNT_MONOTONE in self._probes:
            if seal_registry is not None and hasattr(seal_registry, "count_for_agent"):
                probes_run.append(ContinuityProbe.SEAL_COUNT_MONOTONE)
                obs_seal_count = seal_registry.count_for_agent(agent_id)
                if snapshot is not None and snapshot.seal_count is not None:
                    if obs_seal_count < snapshot.seal_count:
                        failed_probes.append(ContinuityProbe.SEAL_COUNT_MONOTONE)
                        violations.append(
                            f"Seal count decreased for agent '{agent_id}': "
                            f"was {snapshot.seal_count}, now {obs_seal_count}"
                        )

        # ── Build result ─────────────────────────────────────────────
        passed = len(failed_probes) == 0
        result = ContinuityCheckResult(
            passed=passed,
            probes_run=probes_run,
            failed_probes=failed_probes,
            violations=violations,
            checked_at=now,
            agent_id=agent_id,
            _last_record_hash=obs_last_hash,
            _record_count=obs_record_count,
            _cert_count=obs_cert_count,
            _seal_count=obs_seal_count,
        )

        # Update snapshot only on success
        if passed:
            self._snapshots[agent_id] = ContinuityState(
                agent_id=agent_id,
                last_record_hash=obs_last_hash,
                record_count=obs_record_count,
                cert_count=obs_cert_count,
                seal_count=obs_seal_count,
                snapshot_at=now,
            )

        # Strict mode: raise on failure
        if not passed and self._strict:
            raise ContinuityViolationError(result)

        return result

    def update_snapshot(
        self, agent_id: str, result: ContinuityCheckResult | None = None
    ) -> None:
        """Force-update the cached snapshot for an agent.

        Used after intentional governance operations that change counts
        (e.g., audit export+clear, deliberate chain reset).
        Requires explicit call — never called implicitly on failure.

        If *result* is provided, the snapshot is built from its observed
        values.  Otherwise, the existing snapshot is simply cleared so the
        next ``check()`` starts fresh (first-check semantics).
        """
        if result is not None:
            self._snapshots[agent_id] = ContinuityState(
                agent_id=agent_id,
                last_record_hash=result._last_record_hash,
                record_count=result._record_count,
                cert_count=result._cert_count,
                seal_count=result._seal_count,
                snapshot_at=result.checked_at,
            )
        else:
            self._snapshots.pop(agent_id, None)

    def get_snapshot(self, agent_id: str) -> ContinuityState | None:
        """Return the cached state snapshot for an agent, or None."""
        return self._snapshots.get(agent_id)

    def clear_snapshot(self, agent_id: str) -> None:
        """Remove the cached snapshot for an agent.

        The next ``check()`` call for this agent will behave as though it
        is the first evaluation (all probes pass, new snapshot recorded).
        """
        self._snapshots.pop(agent_id, None)


# ── Helpers ──────────────────────────────────────────────────────────────


def _trunc(h: str | None, length: int = 24) -> str:
    """Truncate a hash string for readable error messages."""
    if h is None:
        return "<none>"
    if len(h) <= length:
        return h
    return h[:length] + "..."
