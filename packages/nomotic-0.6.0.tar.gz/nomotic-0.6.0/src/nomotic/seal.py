"""Governance Seal — cryptographically signed authorization artifact.

A governance seal is an immutable proof that governance approved an action.
It is produced when a GovernanceVerdict is ALLOW and carries the full
authorization context: who, what, when, why, and under what conditions.

The seal travels with the action and proves to any third party that
governance occurred, who authorized it, and under what conditions.

Certificate Cross-Verification (v0.4.0):
The seal embeds the issuing agent's certificate fingerprint in the signed
payload. Validation verifies the certificate is still ACTIVE in the store,
creating a chained root of trust: Birth Certificate → Governance Seal.

Design constraints:
- Zero new dependencies (stdlib only: json, base64, uuid, time)
- Uses the existing SigningKey/VerifyKey HMAC-SHA256 backend from keys.py
- Importable independently — no circular imports
- Deterministic canonical form for signing and verification
"""

from __future__ import annotations

import base64
import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.certificate import AgentCertificate
    from nomotic.keys import SigningKey, VerifyKey
    from nomotic.store import CertificateStore
    from nomotic.audit import AuditTrail
    from nomotic.types import GovernanceVerdict

__all__ = [
    "ChainedSeal",
    "DependencyCheckResult",
    "GovernanceSeal",
    "SealRegistry",
    "SealVerificationResult",
    "WorkflowChainVerification",
    "WorkflowDependency",
    "WorkflowDependencyChecker",
    "WorkflowDependencyError",
    "WorkflowSealChain",
    "seal_action",
    "verify_seal",
    "verify_workflow_chain",
]


@dataclass
class GovernanceSeal:
    """Cryptographically signed, timestamped authorization artifact.

    Produced when governance approves an action. The seal is the proof
    artifact that regulators ask for — it proves governance occurred,
    who authorized it, and under what conditions.
    """

    # Identity
    seal_id: str  # Format: "nms-<uuid4>"
    action_id: str  # From the GovernanceVerdict
    agent_id: str  # Who was authorized
    verdict: str  # Always "ALLOW" — seals only produced for approvals

    # Governance scores
    ucs: float  # Unified confidence score at authorization time
    tier: int  # Which tier decided (1, 2, or 3)
    dimension_summary: dict[str, float]  # dimension_name → score
    vetoed_by: list[str]  # Should be empty for ALLOW

    # Authority chain
    agent_owner: str  # Human responsible (from birth certificate)
    organization: str  # Org from birth certificate
    preset: str  # Governance preset in effect (or "default")
    risk_tier: str  # "low", "moderate", "high", "critical"
    org_policy_hash: str  # SHA256 of org-governance.yaml (or "" if none)

    # Conditions
    trust_level: float  # Agent trust at authorization time
    reversibility: str  # From ReversibilityAssessment.level.value

    # Temporal
    issued_at: float  # time.time() epoch
    expires_at: float  # issued_at + ttl_seconds
    ttl_seconds: int  # How long this seal lives

    # Cryptographic
    signature: bytes  # Signed by issuer key
    issuer_fingerprint: str  # Which key signed this

    # Certificate binding (cross-verification, v0.4.0)
    cert_id: str = ""  # certificate_id from the agent's Birth Certificate
    cert_fingerprint: str = ""  # fingerprint from the Birth Certificate

    # Model provenance binding
    model_provenance_hash: str = ""  # provenance_hash from ModelProvenance (if present)

    def canonical_bytes(self) -> bytes:
        """Produce the canonical JSON bytes for signing and verification.

        Deterministic: sorted keys, compact separators, UTF-8.
        Excludes 'signature' and 'issuer_fingerprint' from the canonical dict.
        Converts bytes fields to base64 strings in the canonical form.
        """
        d = self._canonical_dict()
        return json.dumps(d, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _canonical_dict(self) -> dict[str, Any]:
        """Build the dict used for canonical serialization (excludes crypto fields).

        Certificate binding fields (cert_id, cert_fingerprint) are included
        in the signed payload when present, so they cannot be tampered with.
        """
        d: dict[str, Any] = {
            "seal_id": self.seal_id,
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "verdict": self.verdict,
            "ucs": self.ucs,
            "tier": self.tier,
            "dimension_summary": self.dimension_summary,
            "vetoed_by": self.vetoed_by,
            "agent_owner": self.agent_owner,
            "organization": self.organization,
            "preset": self.preset,
            "risk_tier": self.risk_tier,
            "org_policy_hash": self.org_policy_hash,
            "trust_level": self.trust_level,
            "reversibility": self.reversibility,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "ttl_seconds": self.ttl_seconds,
        }
        # Include certificate binding in signed payload when present
        if self.cert_id:
            d["cert_id"] = self.cert_id
        if self.cert_fingerprint:
            d["cert_fingerprint"] = self.cert_fingerprint
        if self.model_provenance_hash:
            d["model_provenance_hash"] = self.model_provenance_hash
        return d

    def verify(self, verify_key: VerifyKey) -> bool:
        """Verify the seal's signature and check expiration.

        Returns True only if the signature is valid AND the seal
        has not expired.
        """
        if self.is_expired():
            return False
        canonical = self.canonical_bytes()
        return verify_key.verify(self.signature, canonical)

    def is_expired(self) -> bool:
        """Check whether this seal has expired."""
        return time.time() >= self.expires_at

    def to_dict(self) -> dict[str, Any]:
        """Convert to a JSON-serializable dict. Signature as base64."""
        d = self._canonical_dict()
        d["signature"] = base64.b64encode(self.signature).decode("ascii")
        d["issuer_fingerprint"] = self.issuer_fingerprint
        # Always include cert binding fields in serialized form
        if "cert_id" not in d:
            d["cert_id"] = self.cert_id
        if "cert_fingerprint" not in d:
            d["cert_fingerprint"] = self.cert_fingerprint
        # Always include model provenance hash in serialized form
        if "model_provenance_hash" not in d:
            d["model_provenance_hash"] = self.model_provenance_hash
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GovernanceSeal:
        """Reconstruct a GovernanceSeal from a dict (inverse of to_dict)."""
        sig = data["signature"]
        if isinstance(sig, str):
            sig = base64.b64decode(sig)
        return cls(
            seal_id=data["seal_id"],
            action_id=data["action_id"],
            agent_id=data["agent_id"],
            verdict=data["verdict"],
            ucs=data["ucs"],
            tier=data["tier"],
            dimension_summary=data["dimension_summary"],
            vetoed_by=data["vetoed_by"],
            agent_owner=data["agent_owner"],
            organization=data["organization"],
            preset=data["preset"],
            risk_tier=data["risk_tier"],
            org_policy_hash=data["org_policy_hash"],
            trust_level=data["trust_level"],
            reversibility=data["reversibility"],
            issued_at=data["issued_at"],
            expires_at=data["expires_at"],
            ttl_seconds=data["ttl_seconds"],
            signature=sig,
            issuer_fingerprint=data["issuer_fingerprint"],
            cert_id=data.get("cert_id", ""),
            cert_fingerprint=data.get("cert_fingerprint", ""),
            model_provenance_hash=data.get("model_provenance_hash", ""),
        )

    def to_compact(self) -> str:
        """Base64url-encode the JSON dict for HTTP header transport."""
        json_bytes = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(json_bytes).decode("ascii").rstrip("=")

    @classmethod
    def from_compact(cls, compact_str: str) -> GovernanceSeal:
        """Reconstruct from a compact base64url string (inverse of to_compact)."""
        # Restore padding
        padding = 4 - (len(compact_str) % 4)
        if padding != 4:
            compact_str += "=" * padding
        json_bytes = base64.urlsafe_b64decode(compact_str)
        data = json.loads(json_bytes)
        return cls.from_dict(data)


@dataclass
class SealVerificationResult:
    """Result of seal verification including certificate cross-verification.

    All new fields have sensible defaults so existing code using only
    the basic fields (valid, expired, error) continues to work.
    """

    valid: bool
    expired: bool = False
    error: str = ""

    # Certificate cross-verification fields
    cert_verified: bool = False
    cert_id: str | None = None
    cert_fingerprint: str | None = None
    cert_status: str | None = None
    cross_verify_error: str | None = None


class SealRegistry:
    """Tracks consumed seals to prevent reuse."""

    def __init__(self, max_entries: int = 10000):
        self._consumed: dict[str, float] = {}  # seal_id -> consumed_at timestamp
        self._max = max_entries

    def consume(self, seal_id: str) -> bool:
        """Mark seal as consumed. Returns False if already consumed."""
        if seal_id in self._consumed:
            return False
        self._consumed[seal_id] = time.time()
        self._evict_expired()
        return True

    def is_consumed(self, seal_id: str) -> bool:
        """Check whether a seal has been consumed."""
        return seal_id in self._consumed

    def _evict_expired(self) -> None:
        """Remove entries older than 1 hour (well past any TTL)."""
        cutoff = time.time() - 3600
        self._consumed = {k: v for k, v in self._consumed.items() if v > cutoff}


def seal_action(
    verdict: GovernanceVerdict,
    context: Any,
    signing_key: SigningKey,
    certificate: AgentCertificate | None = None,
    *,
    ttl_seconds: int = 30,
    preset: str = "default",
    risk_tier: str = "moderate",
    org_policy_hash: str = "",
    cert_store: CertificateStore | None = None,
    require_cert: bool = False,
) -> GovernanceSeal | None:
    """Produce a signed governance seal for an ALLOW verdict.

    Module-level function — keeps seal.py self-contained (not on runtime).

    Returns None if verdict.verdict != Verdict.ALLOW.

    When a certificate is provided (or looked up via cert_store), the seal
    embeds cert_id and cert_fingerprint in the signed payload, creating a
    cryptographic binding between the seal and the agent's identity.

    Args:
        verdict: The GovernanceVerdict to seal.
        context: AgentContext for the agent.
        signing_key: The issuer's SigningKey (from CertificateAuthority).
        certificate: Optional AgentCertificate for authority chain fields.
        ttl_seconds: How long the seal is valid (default 30s).
        preset: Governance preset name in effect.
        risk_tier: Risk tier classification.
        org_policy_hash: SHA256 of org-governance.yaml (or "").
        cert_store: Optional CertificateStore for auto-lookup by agent_id.
        require_cert: If True, raise CertificateStatusError when no active
            certificate is available. Default False for backward compatibility.

    Returns:
        GovernanceSeal if verdict is ALLOW, None otherwise.

    Raises:
        CertificateStatusError: If the certificate is SUSPENDED or REVOKED.
        ValueError: If the certificate's agent_id doesn't match context.agent_id.
    """
    from nomotic.certificate import CertificateStatusError, CertStatus
    from nomotic.types import Verdict

    if verdict.verdict != Verdict.ALLOW:
        return None

    # Auto-lookup certificate from store if not provided
    if certificate is None and cert_store is not None:
        certs = cert_store.list()
        for c in certs:
            if c.agent_id == context.agent_id:
                certificate = c
                break

    # Validate certificate if present
    cert_id = ""
    cert_fingerprint = ""
    if certificate is not None:
        # Check certificate status
        if certificate.status != CertStatus.ACTIVE:
            raise CertificateStatusError(certificate.agent_id, certificate.status)

        # Check agent_id match
        if certificate.agent_id != context.agent_id:
            raise ValueError(
                f"Certificate agent_id '{certificate.agent_id}' does not match "
                f"context agent_id '{context.agent_id}'"
            )

        cert_id = certificate.certificate_id
        cert_fingerprint = certificate.fingerprint

    # Extract model provenance hash from certificate if available
    model_provenance_hash = ""
    if certificate is not None and getattr(certificate, "model_provenance", None) is not None:
        model_provenance_hash = certificate.model_provenance.provenance_hash

    now = time.time()

    # Extract dimension scores into flat dict
    dimension_summary: dict[str, float] = {}
    if verdict.dimension_scores:
        for ds in verdict.dimension_scores:
            dimension_summary[ds.dimension_name] = ds.score

    # Extract authority chain from certificate
    agent_owner = ""
    organization = ""
    if certificate is not None:
        agent_owner = certificate.owner
        organization = certificate.organization

    # Extract reversibility level
    reversibility = "unknown"
    if verdict.reversibility and isinstance(verdict.reversibility, dict):
        level = verdict.reversibility.get("level", "unknown")
        if isinstance(level, str):
            reversibility = level
        else:
            # It might be an enum value string
            reversibility = str(level)

    # Extract trust level from context
    trust_level = 0.5
    if hasattr(context, "trust_profile") and context.trust_profile is not None:
        trust_level = context.trust_profile.overall_trust

    seal = GovernanceSeal(
        seal_id=f"nms-{uuid.uuid4()}",
        action_id=verdict.action_id,
        agent_id=context.agent_id,
        verdict="ALLOW",
        ucs=verdict.ucs,
        tier=verdict.tier,
        dimension_summary=dimension_summary,
        vetoed_by=list(verdict.vetoed_by) if verdict.vetoed_by else [],
        agent_owner=agent_owner,
        organization=organization,
        preset=preset,
        risk_tier=risk_tier,
        org_policy_hash=org_policy_hash,
        trust_level=trust_level,
        reversibility=reversibility,
        issued_at=now,
        expires_at=now + ttl_seconds,
        ttl_seconds=ttl_seconds,
        signature=b"",  # placeholder — signed below
        issuer_fingerprint="",  # placeholder — set below
        cert_id=cert_id,
        cert_fingerprint=cert_fingerprint,
        model_provenance_hash=model_provenance_hash,
    )

    # Sign the canonical form (cert_id and cert_fingerprint are included)
    canonical = seal.canonical_bytes()
    seal.signature = signing_key.sign(canonical)
    seal.issuer_fingerprint = signing_key.verify_key().fingerprint()

    return seal


def verify_seal(
    seal: GovernanceSeal,
    verify_key: VerifyKey,
    cert_store: CertificateStore | None = None,
    audit_trail: AuditTrail | None = None,
) -> SealVerificationResult:
    """Verify a governance seal with optional certificate cross-verification.

    Performs:
    1. Expiration check
    2. Signature verification
    3. Certificate cross-verification (if cert binding fields present and store available)

    Cross-verification error codes:
    - CERT_NOT_FOUND: certificate not in store
    - CERT_FINGERPRINT_MISMATCH: fingerprint doesn't match (potential forgery)
    - CERT_NOT_ACTIVE: certificate suspended or revoked since seal issuance
    - CERT_BINDING_INCOMPLETE: only one of cert_id/cert_fingerprint present

    Args:
        seal: The GovernanceSeal to verify.
        verify_key: The issuer's VerifyKey for signature verification.
        cert_store: Optional CertificateStore for cross-verification lookup.
        audit_trail: Optional AuditTrail for recording verification results.

    Returns:
        SealVerificationResult with full verification details.
    """
    from nomotic.certificate import CertStatus

    # Step 1: Expiration check
    if seal.is_expired():
        result = SealVerificationResult(valid=False, expired=True, error="EXPIRED_SEAL")
        _audit_verification(audit_trail, seal, result)
        return result

    # Step 2: Signature verification
    canonical = seal.canonical_bytes()
    if not verify_key.verify(seal.signature, canonical):
        result = SealVerificationResult(valid=False, error="INVALID_SIGNATURE")
        _audit_verification(audit_trail, seal, result)
        return result

    # Step 3: Certificate cross-verification
    has_cert_id = bool(seal.cert_id)
    has_cert_fp = bool(seal.cert_fingerprint)

    if not has_cert_id and not has_cert_fp:
        # Legacy seal without certificate binding — valid but not cert-verified
        result = SealVerificationResult(valid=True, cert_verified=False)
        _audit_verification(audit_trail, seal, result)
        return result

    if has_cert_id != has_cert_fp:
        # Incomplete binding — one field present but not the other
        result = SealVerificationResult(
            valid=False,
            error="CERT_BINDING_INCOMPLETE",
            cert_id=seal.cert_id or None,
            cert_fingerprint=seal.cert_fingerprint or None,
            cross_verify_error="CERT_BINDING_INCOMPLETE",
        )
        _audit_verification(audit_trail, seal, result)
        return result

    # Both cert_id and cert_fingerprint are present — perform cross-verification
    result = SealVerificationResult(
        valid=True,  # signature is valid; may be overridden below
        cert_id=seal.cert_id,
        cert_fingerprint=seal.cert_fingerprint,
    )

    if cert_store is None:
        # No store available — cannot cross-verify, but signature is valid
        result.cert_verified = False
        _audit_verification(audit_trail, seal, result)
        return result

    # Look up the certificate
    cert = cert_store.get(seal.cert_id)
    if cert is None:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_NOT_FOUND"
        result.error = "CERT_NOT_FOUND"
        _audit_verification(audit_trail, seal, result)
        return result

    result.cert_status = cert.status.name

    # Verify fingerprint match
    if cert.fingerprint != seal.cert_fingerprint:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_FINGERPRINT_MISMATCH"
        result.error = "CERT_FINGERPRINT_MISMATCH"
        _audit_verification(audit_trail, seal, result)
        return result

    # Verify certificate is still ACTIVE
    if cert.status != CertStatus.ACTIVE:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_NOT_ACTIVE"
        result.error = "CERT_NOT_ACTIVE"
        _audit_verification(audit_trail, seal, result)
        return result

    # All checks passed
    result.cert_verified = True
    _audit_verification(audit_trail, seal, result)
    return result


def _audit_verification(
    audit_trail: AuditTrail | None,
    seal: GovernanceSeal,
    result: SealVerificationResult,
) -> None:
    """Record seal verification result in the audit trail."""
    if audit_trail is None:
        return

    from nomotic.audit import AuditRecord

    context_code = (
        "SEAL.VERIFY_OK" if result.valid else "SEAL.VERIFY_FAIL"
    )
    severity = "info" if result.valid else "warning"

    metadata: dict[str, Any] = {
        "seal_id": seal.seal_id,
        "cert_verified": result.cert_verified,
    }
    if result.cross_verify_error:
        metadata["cross_verify_error"] = result.cross_verify_error
    if result.cert_id:
        metadata["cert_id"] = result.cert_id
    if result.cert_fingerprint:
        metadata["cert_fingerprint"] = result.cert_fingerprint
    if result.cert_status:
        metadata["cert_status"] = result.cert_status

    record = AuditRecord(
        record_id=f"seal-verify-{uuid.uuid4()}",
        timestamp=time.time(),
        context_code=context_code,
        severity=severity,
        agent_id=seal.agent_id,
        owner_id=seal.agent_owner,
        user_id="",
        action_id=seal.action_id,
        action_type="seal_verification",
        action_target=seal.seal_id,
        verdict=seal.verdict,
        ucs=seal.ucs,
        tier=seal.tier,
        justification=(
            f"Seal verification {'passed' if result.valid else 'failed'}"
            + (f": {result.cross_verify_error}" if result.cross_verify_error else "")
        ),
        metadata=metadata,
    )
    audit_trail.append(record)


# ── Workflow Seal Chaining ──────────────────────────────────────────────


@dataclass
class ChainedSeal:
    """A governance seal bound to its position in a workflow seal chain.

    Each seal's position_hash binds it to the previous seal, creating
    a cryptographic proof of governance continuity.
    """

    seal_id: str
    step_number: int
    action_id: str
    previous_seal_hash: str
    # SHA-256 of the previous seal's position_hash (or genesis hash for first).

    position_hash: str
    # SHA-256 of (previous_seal_hash + ":" + seal_id)
    # Binds this seal's position in the workflow irreversibly.

    added_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "seal_id": self.seal_id,
            "step_number": self.step_number,
            "action_id": self.action_id,
            "previous_seal_hash": self.previous_seal_hash,
            "position_hash": self.position_hash,
            "added_at": self.added_at,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ChainedSeal:
        return cls(
            seal_id=d["seal_id"],
            step_number=d["step_number"],
            action_id=d["action_id"],
            previous_seal_hash=d["previous_seal_hash"],
            position_hash=d["position_hash"],
            added_at=d.get("added_at", 0.0),
        )


@dataclass
class WorkflowChainVerification:
    """Result of verifying a workflow seal chain."""

    chain_id: str
    intact: bool                        # True if all hashes verify correctly
    seal_count: int
    broken_at_step: int | None          # Step number where chain breaks, None if intact
    coverage: str                       # "complete" | "partial" | "none"
    issues: list[str] = field(default_factory=list)


@dataclass
class WorkflowSealChain:
    """Cryptographically chained seals proving continuous governance
    across all steps of a multi-step workflow.

    Usage:
        chain = runtime.begin_workflow_sealing("workflow-abc")
        # ... workflow step 1 ...
        verdict1 = runtime.evaluate(action1, ctx)
        seal1 = runtime.seal(verdict1, workflow_chain=chain)
        # ... workflow step 2 ...
        verdict2 = runtime.evaluate(action2, ctx)
        seal2 = runtime.seal(verdict2, workflow_chain=chain)
        # ... all steps done ...
        runtime.complete_workflow_sealing(chain.chain_id)
    """

    chain_id: str              # "nmwc-<uuid4>"
    workflow_id: str           # User-provided workflow identifier
    agent_id: str
    seals: list[ChainedSeal] = field(default_factory=list)
    chain_hash: str = ""       # SHA-256 of all seal_ids joined with ":"
    created_at: float = field(default_factory=time.time)
    completed_at: float | None = None
    status: str = "ACTIVE"     # "ACTIVE" | "COMPLETE"

    @property
    def step_count(self) -> int:
        return len(self.seals)

    @property
    def latest_seal_id(self) -> str | None:
        return self.seals[-1].seal_id if self.seals else None

    @property
    def latest_position_hash(self) -> str | None:
        return self.seals[-1].position_hash if self.seals else None

    def _compute_chain_hash(self) -> str:
        """Compute hash of all seal_ids in order."""
        seal_ids = ":".join(s.seal_id for s in self.seals)
        return hashlib.sha256(seal_ids.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return {
            "chain_id": self.chain_id,
            "workflow_id": self.workflow_id,
            "agent_id": self.agent_id,
            "seals": [s.to_dict() for s in self.seals],
            "chain_hash": self.chain_hash,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "status": self.status,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> WorkflowSealChain:
        return cls(
            chain_id=d["chain_id"],
            workflow_id=d["workflow_id"],
            agent_id=d["agent_id"],
            seals=[ChainedSeal.from_dict(s) for s in d.get("seals", [])],
            chain_hash=d.get("chain_hash", ""),
            created_at=d.get("created_at", 0.0),
            completed_at=d.get("completed_at"),
            status=d.get("status", "COMPLETE"),
        )


def verify_workflow_chain(chain: WorkflowSealChain) -> WorkflowChainVerification:
    """Verify the cryptographic integrity of a workflow seal chain.

    Checks:
    1. Each ChainedSeal's position_hash matches SHA-256(previous_seal_hash + ":" + seal_id)
    2. The first seal's previous_seal_hash matches the chain_id (genesis)
    3. chain_hash matches SHA-256 of all seal_ids in order
    """
    if not chain.seals:
        return WorkflowChainVerification(
            chain_id=chain.chain_id,
            intact=True,
            seal_count=0,
            broken_at_step=None,
            coverage="none",
        )

    issues: list[str] = []

    # Check genesis hash
    first = chain.seals[0]
    genesis_hash = hashlib.sha256(chain.chain_id.encode("utf-8")).hexdigest()
    if first.previous_seal_hash != genesis_hash:
        issues.append(f"Step {first.step_number}: genesis hash mismatch")

    # Check each position hash
    for i, chained in enumerate(chain.seals):
        expected_position_hash = hashlib.sha256(
            f"{chained.previous_seal_hash}:{chained.seal_id}".encode("utf-8")
        ).hexdigest()
        if chained.position_hash != expected_position_hash:
            issues.append(f"Step {chained.step_number}: position_hash mismatch")
            return WorkflowChainVerification(
                chain_id=chain.chain_id,
                intact=False,
                seal_count=len(chain.seals),
                broken_at_step=chained.step_number,
                coverage="partial" if i > 0 else "none",
                issues=issues,
            )

    # Check chain_hash
    expected_chain_hash = chain._compute_chain_hash()
    if chain.chain_hash and chain.chain_hash != expected_chain_hash:
        issues.append("chain_hash mismatch — seal list may have been modified")
        return WorkflowChainVerification(
            chain_id=chain.chain_id,
            intact=False,
            seal_count=len(chain.seals),
            broken_at_step=None,
            coverage="partial",
            issues=issues,
        )

    return WorkflowChainVerification(
        chain_id=chain.chain_id,
        intact=True,
        seal_count=len(chain.seals),
        broken_at_step=None,
        coverage="complete" if chain.status == "COMPLETE" else "partial",
    )


# ── Cross-Workflow Dependency Checking ─────────────────────────────────


@dataclass
class WorkflowDependency:
    """A dependency rule between two workflows.

    Before ``dependent_workflow_id`` can begin sealing, the runtime
    verifies that ``required_workflow_id`` has a completed chain
    meeting all specified constraints.

    Fields:
        dependent_workflow_id:  The workflow requiring a prerequisite.
        required_workflow_id:   The workflow that must complete first.
        required_status:        Required chain status (default: "COMPLETE").
        max_age_seconds:        If set, prerequisite chain must be younger
                                than this many seconds when checked.
                                None = no age constraint.
        description:            Why this dependency exists (for audit trail).
    """

    dependent_workflow_id: str
    required_workflow_id: str
    required_status: str = "COMPLETE"
    max_age_seconds: float | None = None
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "dependent_workflow_id": self.dependent_workflow_id,
            "required_workflow_id": self.required_workflow_id,
            "required_status": self.required_status,
            "description": self.description,
        }
        if self.max_age_seconds is not None:
            d["max_age_seconds"] = self.max_age_seconds
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "WorkflowDependency":
        return cls(
            dependent_workflow_id=d["dependent_workflow_id"],
            required_workflow_id=d["required_workflow_id"],
            required_status=d.get("required_status", "COMPLETE"),
            max_age_seconds=d.get("max_age_seconds"),
            description=d.get("description", ""),
        )


@dataclass
class DependencyCheckResult:
    """Result of a single dependency rule check."""

    satisfied: bool
    dependent_workflow_id: str
    required_workflow_id: str
    failure_reason: str | None = None
    prerequisite_chain_id: str | None = None
    prerequisite_chain_status: str | None = None
    prerequisite_completed_at: float | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "satisfied": self.satisfied,
            "dependent_workflow_id": self.dependent_workflow_id,
            "required_workflow_id": self.required_workflow_id,
        }
        if self.failure_reason is not None:
            d["failure_reason"] = self.failure_reason
        if self.prerequisite_chain_id is not None:
            d["prerequisite_chain_id"] = self.prerequisite_chain_id
        if self.prerequisite_chain_status is not None:
            d["prerequisite_chain_status"] = self.prerequisite_chain_status
        if self.prerequisite_completed_at is not None:
            d["prerequisite_completed_at"] = self.prerequisite_completed_at
        return d


class WorkflowDependencyError(Exception):
    """Raised when a workflow's dependencies are not satisfied."""

    def __init__(
        self,
        workflow_id: str,
        failures: list[DependencyCheckResult],
    ) -> None:
        self.workflow_id = workflow_id
        self.failures = failures
        reasons = "; ".join(
            r.failure_reason or "unknown"
            for r in failures if not r.satisfied
        )
        super().__init__(
            f"Workflow '{workflow_id}' has {len(failures)} unsatisfied "
            f"dependencies: {reasons}"
        )


class WorkflowDependencyChecker:
    """Checks workflow dependency rules before allowing workflows to begin.

    Thread-safe. Dependencies are registered at configuration time.
    check() is called at runtime before begin_workflow_sealing().
    """

    def __init__(self) -> None:
        self._dependencies: list[WorkflowDependency] = []
        self._lock = threading.Lock()

    def add_dependency(self, dep: WorkflowDependency) -> None:
        """Register a dependency rule."""
        with self._lock:
            self._dependencies.append(dep)

    def remove_dependency(
        self, dependent_id: str, required_id: str
    ) -> bool:
        """Remove a dependency rule. Returns True if found and removed."""
        with self._lock:
            for i, dep in enumerate(self._dependencies):
                if (dep.dependent_workflow_id == dependent_id
                        and dep.required_workflow_id == required_id):
                    self._dependencies.pop(i)
                    return True
        return False

    def check(
        self,
        workflow_id: str,
        available_chains: dict[str, "WorkflowSealChain"],
    ) -> list[DependencyCheckResult]:
        """Check all applicable dependency rules for workflow_id.

        Looks up all dependencies where dependent_workflow_id == workflow_id.
        For each dependency, finds matching chains in available_chains where
        the chain's workflow_id matches required_workflow_id.

        Returns a list of DependencyCheckResult — one per applicable rule.
        Empty list = no dependencies (always allowed to proceed).
        """
        with self._lock:
            applicable = [
                dep for dep in self._dependencies
                if dep.dependent_workflow_id == workflow_id
            ]

        results: list[DependencyCheckResult] = []
        now = time.time()

        for dep in applicable:
            # Find matching completed chains for the required workflow
            matching = [
                chain for chain in available_chains.values()
                if chain.workflow_id == dep.required_workflow_id
                   and chain.status == dep.required_status
            ]

            if not matching:
                results.append(DependencyCheckResult(
                    satisfied=False,
                    dependent_workflow_id=dep.dependent_workflow_id,
                    required_workflow_id=dep.required_workflow_id,
                    failure_reason=(
                        f"No {dep.required_status} chain found for "
                        f"required workflow '{dep.required_workflow_id}'"
                    ),
                ))
                continue

            # Use the most recent matching chain
            best = max(matching, key=lambda c: c.completed_at or 0.0)

            # Check age constraint
            if dep.max_age_seconds is not None:
                chain_age = now - (best.completed_at or 0.0)
                if chain_age > dep.max_age_seconds:
                    results.append(DependencyCheckResult(
                        satisfied=False,
                        dependent_workflow_id=dep.dependent_workflow_id,
                        required_workflow_id=dep.required_workflow_id,
                        failure_reason=(
                            f"Required chain '{best.chain_id}' is too old: "
                            f"{chain_age:.0f}s > max {dep.max_age_seconds:.0f}s"
                        ),
                        prerequisite_chain_id=best.chain_id,
                        prerequisite_chain_status=best.status,
                    ))
                    continue

            results.append(DependencyCheckResult(
                satisfied=True,
                dependent_workflow_id=dep.dependent_workflow_id,
                required_workflow_id=dep.required_workflow_id,
                prerequisite_chain_id=best.chain_id,
                prerequisite_chain_status=best.status,
                prerequisite_completed_at=best.completed_at,
            ))

        return results

    def all_satisfied(
        self,
        workflow_id: str,
        available_chains: dict[str, "WorkflowSealChain"],
    ) -> bool:
        """Return True only if all dependency rules are satisfied."""
        results = self.check(workflow_id, available_chains)
        return all(r.satisfied for r in results)

    def list_dependencies(self) -> list[WorkflowDependency]:
        """Return all registered dependencies."""
        with self._lock:
            return list(self._dependencies)
