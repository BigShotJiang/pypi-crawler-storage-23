"""YAML configuration loader for nomotic.yaml governance files.

Loads ``nomotic.yaml`` configuration files with support for ``extends`` to
inherit settings from compliance presets (e.g. ``hipaa_aligned``,
``soc2_aligned``) or severity tiers (``standard``, ``strict``,
``ultra_strict``).

This module is consumed by both the Nomotic runtime and by ``nomotic-ci``.

Resolution order (inheritance):

1. Start with Nomotic defaults (``standard`` preset).
2. Apply each preset in the ``extends`` list, in order (later overrides
   earlier).
3. Apply any explicit values from the YAML file (overrides presets).

Weight merging: explicit YAML weights merge on top of preset weights (only
specified dimensions override; unspecified ones keep preset values).

Veto replacement: if the YAML specifies ``vetoes``, they **replace** the
preset vetoes entirely (not merge).

Threshold / trust override: explicit values override preset values;
unspecified values keep preset values.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from difflib import get_close_matches
from pathlib import Path
from typing import Any

from nomotic.presets import (
    DIMENSION_NAMES,
    TRUST_SETTING_KEYS,
    get_preset,
    get_preset_names,
)

__all__ = [
    "AgentDefinition",
    "GovernanceConfig",
    "load_governance_config",
    "load_governance_config_from_string",
    "validate_governance_config",
]

# File names to search for when given a directory.
_CONFIG_FILENAMES = ("nomotic.yaml", "nomotic.yml")
_MAX_SEARCH_DEPTH = 3


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class AgentDefinition:
    """A single agent's governance scope from ``nomotic.yaml``."""

    agent_id: str
    actions: list[str]
    targets: list[str]
    boundaries: list[str]
    initial_trust: float = 0.5
    min_trust_for_action: float = 0.3
    owner: str = ""
    reason: str = ""


@dataclass
class GovernanceConfig:
    """Complete parsed governance configuration."""

    version: str
    extends: list[str]
    agents: list[AgentDefinition]
    dimension_weights: dict[str, float]
    veto_dimensions: list[str]
    allow_threshold: float
    deny_threshold: float
    trust_settings: dict[str, float]
    compliance_frameworks: list[str]
    source_path: str
    raw: dict[str, Any]

    def to_runtime_config(self) -> "RuntimeConfig":
        """Convert to a :class:`RuntimeConfig` for runtime use."""
        from nomotic.runtime import RuntimeConfig
        from nomotic.trust import TrustConfig

        ts = self.trust_settings
        trust_config = TrustConfig(
            success_increment=ts["success_increment"],
            violation_decrement=ts["violation_decrement"],
            interrupt_decrement=ts["interrupt_cost"],
            decay_rate=ts["decay_rate"],
            min_trust=ts["floor"],
            max_trust=ts["ceiling"],
        )

        return RuntimeConfig(
            allow_threshold=self.allow_threshold,
            deny_threshold=self.deny_threshold,
            trust_config=trust_config,
            dimension_weights=dict(self.dimension_weights),
            veto_dimensions=list(self.veto_dimensions),
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_presets(extends_raw: str | list[str] | None) -> list[str]:
    """Normalize the ``extends`` field to a list of strings."""
    if extends_raw is None:
        return []
    if isinstance(extends_raw, str):
        return [extends_raw]
    if isinstance(extends_raw, list):
        return [str(e) for e in extends_raw]
    raise ValueError(
        f"'extends' must be a string or list of strings, got {type(extends_raw).__name__}"
    )


def _suggest_preset(name: str) -> str:
    """Return a helpful error message for an unknown preset name."""
    canonical = get_preset_names()
    # Try case-insensitive match against canonical names
    lower_map = {n.lower(): n for n in canonical}
    key = name.lower()
    if key in lower_map:
        # This is a valid canonical name (case-insensitive match)
        return ""  # No error

    # Find close matches
    close = get_close_matches(key, [n.lower() for n in canonical], n=1, cutoff=0.4)
    available = ", ".join(canonical)
    if close:
        suggestion = lower_map[close[0]]
        return (
            f"Unknown preset '{name}' in extends. "
            f"Did you mean '{suggestion}'? "
            f"Available presets: {available}"
        )
    return (
        f"Unknown preset '{name}' in extends. "
        f"Available presets: {available}"
    )


def _apply_preset_chain(
    extends: list[str],
) -> tuple[dict[str, float], list[str], float, float, dict[str, float]]:
    """Resolve the preset chain and return merged values.

    Returns (weights, vetoes, allow_threshold, deny_threshold, trust_settings).
    """
    # Start from the standard preset as the base.
    base = get_preset("standard")
    weights = dict(base.dimension_weights)
    vetoes = list(base.veto_dimensions)
    allow_threshold = base.allow_threshold
    deny_threshold = base.deny_threshold
    trust_settings = dict(base.trust_settings)

    # Apply each extends preset in order (later overrides earlier).
    # Skip unknown names here; validation catches them later.
    for name in extends:
        try:
            preset = get_preset(name)  # case-insensitive lookup
        except KeyError:
            continue
        # Weights: full override from each preset
        weights = dict(preset.dimension_weights)
        # Vetoes: full override from each preset
        vetoes = list(preset.veto_dimensions)
        # Thresholds: override
        allow_threshold = preset.allow_threshold
        deny_threshold = preset.deny_threshold
        # Trust settings: override
        trust_settings = dict(preset.trust_settings)

    return weights, vetoes, allow_threshold, deny_threshold, trust_settings


def _parse_agents(agents_raw: dict[str, Any] | None) -> list[AgentDefinition]:
    """Parse the ``agents`` section of the YAML."""
    if not agents_raw or not isinstance(agents_raw, dict):
        return []

    agents: list[AgentDefinition] = []
    for agent_id, agent_data in agents_raw.items():
        if not isinstance(agent_data, dict):
            continue

        scope = agent_data.get("scope", {})
        trust = agent_data.get("trust", {})

        agents.append(
            AgentDefinition(
                agent_id=str(agent_id),
                actions=_as_str_list(scope.get("actions", [])),
                targets=_as_str_list(scope.get("targets", [])),
                boundaries=_as_str_list(scope.get("boundaries", [])),
                initial_trust=float(trust.get("initial", 0.5)),
                min_trust_for_action=float(trust.get("minimum_for_action", 0.3)),
                owner=str(agent_data.get("owner", "")),
                reason=str(agent_data.get("reason", "")),
            )
        )
    return agents


def _as_str_list(value: Any) -> list[str]:
    """Coerce a value into a list of strings."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


def _import_yaml() -> Any:
    """Lazily import PyYAML — only needed when actually loading YAML."""
    try:
        import yaml
        return yaml
    except ImportError:  # pragma: no cover
        raise ImportError(
            "PyYAML is required for loading YAML configs. "
            "Install it with: pip install pyyaml"
        ) from None


def _find_config_file(path: Path, max_depth: int = _MAX_SEARCH_DEPTH) -> Path:
    """Find a nomotic.yaml file starting from *path*.

    If *path* is a file, return it directly.
    If *path* is a directory, search recursively up to *max_depth*.
    """
    if path.is_file():
        return path

    if not path.is_dir():
        raise FileNotFoundError(f"Path does not exist: {path}")

    # Breadth-first search up to max_depth
    for depth in range(max_depth + 1):
        for root, dirs, files in os.walk(path):
            # Calculate depth relative to starting path
            rel = Path(root).relative_to(path)
            current_depth = len(rel.parts)
            if current_depth > max_depth:
                dirs.clear()
                continue
            for filename in _CONFIG_FILENAMES:
                if filename in files:
                    return Path(root) / filename
            if current_depth >= max_depth:
                dirs.clear()

    raise FileNotFoundError(
        f"No nomotic.yaml found in {path} (searched up to depth {max_depth})"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_governance_config(path: str | Path) -> GovernanceConfig:
    """Load a ``nomotic.yaml`` from a file path.

    If *path* is a directory, searches for ``nomotic.yaml`` recursively
    (max depth 3).

    Raises :class:`FileNotFoundError` if not found.
    Raises :class:`ValueError` for invalid configs.
    """
    resolved = _find_config_file(Path(path))
    yaml_string = resolved.read_text(encoding="utf-8")
    config = load_governance_config_from_string(yaml_string, source_path=str(resolved))

    errors = validate_governance_config(config)
    if errors:
        raise ValueError(
            f"Invalid governance config at {resolved}:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return config


def load_governance_config_from_string(
    yaml_string: str,
    source_path: str = "<string>",
) -> GovernanceConfig:
    """Load from a YAML string (useful for testing and CI)."""
    yaml = _import_yaml()
    try:
        raw = yaml.safe_load(yaml_string)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise ValueError("YAML content must be a mapping (dictionary)")

    version = str(raw.get("version", ""))

    # Parse extends
    extends_names = _resolve_presets(raw.get("extends"))

    # Resolve preset chain
    weights, vetoes, allow_threshold, deny_threshold, trust_settings = (
        _apply_preset_chain(extends_names)
    )

    # Apply explicit dimension overrides from YAML
    dimensions_raw = raw.get("dimensions", {})
    if isinstance(dimensions_raw, dict):
        explicit_weights = dimensions_raw.get("weights", {})
        if isinstance(explicit_weights, dict):
            for dim_name, weight_val in explicit_weights.items():
                weights[str(dim_name)] = float(weight_val)

        explicit_vetoes = dimensions_raw.get("vetoes")
        if explicit_vetoes is not None:
            # Vetoes REPLACE entirely when specified in YAML
            vetoes = _as_str_list(explicit_vetoes)

    # Apply explicit threshold overrides
    thresholds_raw = raw.get("thresholds", {})
    if isinstance(thresholds_raw, dict):
        if "allow" in thresholds_raw:
            allow_threshold = float(thresholds_raw["allow"])
        if "deny" in thresholds_raw:
            deny_threshold = float(thresholds_raw["deny"])

    # Apply explicit trust overrides
    trust_raw = raw.get("trust", {})
    if isinstance(trust_raw, dict):
        trust_key_map = {
            "success_increment": "success_increment",
            "violation_decrement": "violation_decrement",
            "interrupt_cost": "interrupt_cost",
            "decay_rate": "decay_rate",
            "floor": "floor",
            "ceiling": "ceiling",
        }
        for yaml_key, setting_key in trust_key_map.items():
            if yaml_key in trust_raw:
                trust_settings[setting_key] = float(trust_raw[yaml_key])

    # Parse agents
    agents = _parse_agents(raw.get("agents"))

    # Parse compliance frameworks
    compliance_raw = raw.get("compliance", {})
    frameworks: list[str] = []
    if isinstance(compliance_raw, dict):
        frameworks = _as_str_list(compliance_raw.get("frameworks", []))

    return GovernanceConfig(
        version=version,
        extends=extends_names,
        agents=agents,
        dimension_weights=weights,
        veto_dimensions=vetoes,
        allow_threshold=allow_threshold,
        deny_threshold=deny_threshold,
        trust_settings=trust_settings,
        compliance_frameworks=frameworks,
        source_path=source_path,
        raw=raw,
    )


def validate_governance_config(config: GovernanceConfig) -> list[str]:
    """Return a list of validation error messages.  Empty list = valid.

    Checks:

    - ``version`` is ``"1.0"``
    - At least one agent defined
    - All ``extends`` references resolve to known preset names (canonical
      names only, case-insensitive)
    - All dimension weight keys are valid dimension names
    - All veto dimension names are valid
    - ``allow_threshold`` > ``deny_threshold``
    - Trust settings have required keys and valid ranges (all positive,
      scores between 0 and 1)
    - Agent scopes have non-empty actions
    """
    errors: list[str] = []
    valid_dims = set(DIMENSION_NAMES)

    # Version check
    if config.version != "1.0":
        errors.append(
            f"Unsupported version '{config.version}'. Only '1.0' is supported."
        )

    # At least one agent
    if not config.agents:
        errors.append("At least one agent must be defined.")

    # Validate extends references
    for name in config.extends:
        msg = _suggest_preset(name)
        if msg:
            errors.append(msg)

    # Validate dimension weight keys
    for dim_name in config.dimension_weights:
        if dim_name not in valid_dims:
            errors.append(
                f"Unknown dimension weight '{dim_name}'. "
                f"Valid dimensions: {', '.join(sorted(valid_dims))}"
            )

    # Validate veto dimension names
    for dim_name in config.veto_dimensions:
        if dim_name not in valid_dims:
            errors.append(
                f"Unknown veto dimension '{dim_name}'. "
                f"Valid dimensions: {', '.join(sorted(valid_dims))}"
            )

    # Threshold ordering
    if config.allow_threshold <= config.deny_threshold:
        errors.append(
            f"allow_threshold ({config.allow_threshold}) must be greater "
            f"than deny_threshold ({config.deny_threshold})."
        )

    # Trust settings: required keys
    missing_trust = TRUST_SETTING_KEYS - set(config.trust_settings)
    if missing_trust:
        errors.append(
            f"Missing trust settings: {', '.join(sorted(missing_trust))}."
        )

    # Trust settings: valid ranges
    for key, value in config.trust_settings.items():
        if key in TRUST_SETTING_KEYS:
            if value < 0:
                errors.append(
                    f"Trust setting '{key}' must be positive, got {value}."
                )
            if key in ("floor", "ceiling") and not (0 <= value <= 1):
                errors.append(
                    f"Trust setting '{key}' must be between 0 and 1, got {value}."
                )

    # Agent scopes: non-empty actions
    for agent in config.agents:
        if not agent.actions:
            errors.append(
                f"Agent '{agent.agent_id}' must have at least one action."
            )

    return errors
