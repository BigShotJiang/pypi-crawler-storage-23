"""HTTP Governance Proxy -- intercepts and governs HTTP requests.

Sits between an agent and its target service. Every request is
evaluated through Nomotic governance before being forwarded.

Usage:
    nomotic proxy --agent-id claims-bot --listen 0.0.0.0:8421 --upstream https://api.target.com

The proxy intercepts:
    - The HTTP method -> governance action (GET=read, POST=write, DELETE=delete)
    - The URL path -> governance target
    - Request headers and body -> governance parameters

**Scope limitation**: Certificate-required mode only enforces identity for
traffic routed through this proxy. Nomotic cannot detect arbitrary code
executing on the network that bypasses governed tool endpoints. The
enforcement boundary is the proxy, not the network.
"""

from __future__ import annotations

import json
import signal
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, ClassVar

from nomotic.executor import GovernedToolExecutor
from nomotic.otel_exporter import PrometheusMetrics

__all__ = [
    "GovernanceProxyHandler",
    "METHOD_ACTION_MAP",
    "start_proxy",
    "verify_certificate_status",
]


# Map HTTP methods to governance actions
METHOD_ACTION_MAP: dict[str, str] = {
    "GET": "read",
    "POST": "write",
    "PUT": "write",
    "PATCH": "write",
    "DELETE": "delete",
    "HEAD": "read",
    "OPTIONS": "read",
}


# ── Shared certificate verification helper ──────────────────────────────


def verify_certificate_status(cert_store: Any, agent_id: str) -> str | None:
    """Verify that *agent_id* has a valid, ACTIVE certificate.

    Looks up the certificate by ``certificate_id`` first (via ``get``),
    then falls back to scanning all certificates for a matching
    ``agent_id`` field.

    Returns ``None`` when the certificate is valid, or an error string
    describing why access should be denied.
    """
    if cert_store is None:
        return "Certificate store not configured"

    from nomotic.certificate import CertStatus

    # Try direct lookup (agent_id might be the certificate_id)
    cert = cert_store.get(agent_id)

    if cert is None:
        # Scan all certificates for one whose agent_id matches
        all_certs = cert_store.list()
        for c in all_certs:
            if c.agent_id == agent_id:
                cert = c
                break

    if cert is None:
        return f"NO_VALID_CERTIFICATE: No certificate found for '{agent_id}'"

    if cert.status == CertStatus.SUSPENDED:
        return f"CERTIFICATE_SUSPENDED: Certificate for '{agent_id}' is suspended"
    if cert.status == CertStatus.REVOKED:
        return f"CERTIFICATE_REVOKED: Certificate for '{agent_id}' is revoked"
    if cert.status == CertStatus.EXPIRED:
        return f"CERTIFICATE_EXPIRED: Certificate for '{agent_id}' is expired"
    if cert.status != CertStatus.ACTIVE:
        return f"CERTIFICATE_INVALID: Certificate for '{agent_id}' status: {cert.status.name}"

    return None  # Valid


class GovernanceProxyHandler(BaseHTTPRequestHandler):
    """HTTP request handler that applies governance before proxying."""

    executor: ClassVar[GovernedToolExecutor | None] = None
    upstream_url: ClassVar[str] = ""
    require_certificate: ClassVar[bool] = False
    cert_store: ClassVar[Any] = None  # FileCertificateStore
    agent_id_map: ClassVar[dict[str, str]] = {}  # IP/key -> agent_id mapping
    metrics: ClassVar[PrometheusMetrics | None] = None
    start_time: ClassVar[float] = 0.0
    request_count: ClassVar[int] = 0
    denial_count: ClassVar[int] = 0
    agent_id: ClassVar[str] = ""

    def do_GET(self) -> None:
        if self.path == "/health":
            self._handle_health()
            return
        if self.path == "/metrics":
            self._handle_metrics()
            return
        self._handle()

    def do_POST(self) -> None:
        self._handle()

    def do_PUT(self) -> None:
        self._handle()

    def do_PATCH(self) -> None:
        self._handle()

    def do_DELETE(self) -> None:
        self._handle()

    def _handle(self) -> None:
        assert self.executor is not None, "executor must be set before handling requests"

        # Certificate verification (if required) — fail fast before governance
        if self.require_certificate:
            agent_id = self._resolve_agent_identity()
            if agent_id is None:
                self._deny_no_certificate("No agent identification in request")
                return

            cert_status = verify_certificate_status(self.cert_store, agent_id)
            if cert_status is not None:
                self._deny_no_certificate(cert_status)
                return

        method = self.command
        path = self.path
        action = METHOD_ACTION_MAP.get(method, "read")
        target = path.strip("/").split("/")[0] if path.strip("/") else "root"

        # Read request body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length else b""

        # Evaluate governance
        result = self.executor.check(
            action=action,
            target=target,
            params={"method": method, "path": path, "body_size": len(body)},
        )

        if not result.allowed:
            # Return 403 with governance denial
            response = json.dumps({
                "error": "governance_denied",
                "reason": result.reason,
                "verdict": result.verdict,
                "trust": result.trust_after,
                "action": action,
                "target": target,
            }).encode("utf-8")

            self.send_response(403)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Nomotic-Verdict", "DENY")
            self.send_header("X-Nomotic-Reason", result.reason[:200])
            self.send_header("Content-Length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)
            return

        # Forward to upstream
        upstream = f"{self.upstream_url}{path}"
        req = urllib.request.Request(
            upstream, data=body if body else None, method=method
        )

        # Copy relevant headers
        for header, value in self.headers.items():
            if header.lower() not in ("host", "content-length"):
                req.add_header(header, value)

        # Add governance headers
        req.add_header("X-Nomotic-Verdict", "ALLOW")
        req.add_header("X-Nomotic-Trust", str(result.trust_after))
        req.add_header("X-Nomotic-Agent", self.executor.agent_id)

        try:
            with urllib.request.urlopen(req) as resp:
                resp_body = resp.read()
                self.send_response(resp.status)
                for header, value in resp.headers.items():
                    if header.lower() != "transfer-encoding":
                        self.send_header(header, value)
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            resp_body = e.read()
            self.send_response(e.code)
            for header, value in e.headers.items():
                if header.lower() != "transfer-encoding":
                    self.send_header(header, value)
            self.end_headers()
            self.wfile.write(resp_body)

    # ── Certificate helpers ──────────────────────────────────────────

    def _resolve_agent_identity(self) -> str | None:
        """Extract agent identity from the request.

        Checks in order:
        1. ``X-Nomotic-Agent-Id`` header
        2. ``X-Nomotic-Certificate-Id`` header
        3. Static IP-to-agent mapping (for environments where agents
           cannot set custom headers)
        """
        agent_id = self.headers.get("X-Nomotic-Agent-Id")
        if agent_id:
            return agent_id
        cert_id = self.headers.get("X-Nomotic-Certificate-Id")
        if cert_id:
            return cert_id
        # Check IP mapping
        client_ip = self.client_address[0]
        return self.agent_id_map.get(client_ip)

    def _deny_no_certificate(self, reason: str) -> None:
        """Return 403 with certificate denial."""
        response = json.dumps({
            "error": "certificate_required",
            "reason": reason,
        }).encode("utf-8")
        self.send_response(403)
        self.send_header("Content-Type", "application/json")
        self.send_header("X-Nomotic-Verdict", "CERTIFICATE_DENIED")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def _handle_health(self) -> None:
        """Return health status."""
        health: dict[str, Any] = {
            "status": "ok",
            "agent_id": self.agent_id,
            "upstream_url": self.upstream_url,
            "require_certificate": self.require_certificate,
            "uptime_seconds": time.time() - self.start_time,
            "requests_total": self.request_count,
            "denials_total": self.denial_count,
        }

        # Check upstream connectivity
        try:
            req = urllib.request.Request(self.upstream_url, method="HEAD")
            urllib.request.urlopen(req, timeout=2)
            health["upstream_status"] = "reachable"
        except Exception:
            health["upstream_status"] = "unreachable"
            health["status"] = "degraded"

        status = 200 if health["status"] == "ok" else 503
        response = json.dumps(health).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def _handle_metrics(self) -> None:
        """Return Prometheus text format metrics."""
        if self.metrics is None:
            self.send_response(503)
            self.end_headers()
            return
        metrics_text = self.metrics.format_prometheus()
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; version=0.0.4")
        self.send_header("Content-Length", str(len(metrics_text)))
        self.end_headers()
        self.wfile.write(metrics_text.encode())

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging -- we log through governance."""
        pass


def start_proxy(
    agent_id: str,
    listen: str,
    upstream: str,
    *,
    test_mode: bool = False,
    base_dir: str | None = None,
    require_certificate: bool = False,
    agent_id_map: dict[str, str] | None = None,
    default_timeout: float = 30.0,
) -> None:
    """Start the governance proxy server.

    Args:
        agent_id: Nomotic agent identity (must have an existing certificate).
        listen: Address to bind to, e.g. ``"0.0.0.0:8421"``.
        upstream: Upstream service URL, e.g. ``"https://api.target.com"``.
        test_mode: If True, use testlog and simulated trust.
        base_dir: Nomotic data directory (default: ~/.nomotic).
        require_certificate: If True, require a valid birth certificate
            for every request. Only enforced for traffic routed through
            this proxy — Nomotic cannot detect traffic that bypasses
            governed endpoints.
        agent_id_map: Optional mapping of client IPs to agent IDs for
            environments where agents cannot set custom HTTP headers.
        default_timeout: Default upstream timeout in seconds.
    """
    host, port_str = listen.rsplit(":", 1)
    port = int(port_str)

    from pathlib import Path

    kwargs: dict[str, Any] = {"test_mode": test_mode}
    if base_dir is not None:
        kwargs["base_dir"] = Path(base_dir)

    executor = GovernedToolExecutor.connect(agent_id, **kwargs)

    GovernanceProxyHandler.executor = executor
    GovernanceProxyHandler.upstream_url = upstream.rstrip("/")
    GovernanceProxyHandler.require_certificate = require_certificate
    GovernanceProxyHandler.agent_id_map = agent_id_map or {}
    GovernanceProxyHandler.agent_id = agent_id
    GovernanceProxyHandler.metrics = PrometheusMetrics()
    GovernanceProxyHandler.start_time = time.time()
    GovernanceProxyHandler.request_count = 0
    GovernanceProxyHandler.denial_count = 0

    if require_certificate:
        from nomotic.store import FileCertificateStore

        bd = Path(base_dir) if base_dir else Path.home() / ".nomotic"
        GovernanceProxyHandler.cert_store = FileCertificateStore(bd)
    else:
        GovernanceProxyHandler.cert_store = None

    server = HTTPServer((host, port), GovernanceProxyHandler)

    def _shutdown_handler(signum: int, frame: Any) -> None:
        print(f"\nShutdown initiated (signal {signum})...", file=sys.stderr)
        threading.Timer(5.0, server.shutdown).start()

    signal.signal(signal.SIGTERM, _shutdown_handler)
    signal.signal(signal.SIGINT, _shutdown_handler)

    print(f"Nomotic governance proxy running on {listen}")
    print(f"Upstream: {upstream}")
    print(f"Agent: {agent_id} (trust: {executor.trust:.3f})")
    if require_certificate:
        print("Certificate-required mode: ENABLED")

    try:
        server.serve_forever()
    finally:
        server.server_close()
