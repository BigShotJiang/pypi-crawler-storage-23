"""Archetype Marketplace — browse and install community archetypes (F-20).

Uses only stdlib ``urllib.request`` for HTTP. The remote registry is at
``github.com/nomotic-ai/archetype-registry`` (may not exist yet — the
client handles connection errors gracefully).
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

try:
    import yaml  # pyyaml — likely already a dependency

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


# ── Exceptions ─────────────────────────────────────────────────────────


class MarketplaceConnectionError(Exception):
    """Raised when the registry cannot be reached."""


class ArchetypeValidationError(Exception):
    """Raised when a community archetype fails schema validation."""


# ── Data classes ───────────────────────────────────────────────────────


@dataclass
class ArchetypeEntry:
    """Summary entry from the registry index."""

    name: str
    description: str
    resolves_to: str
    author: str
    version: str
    compliance_tags: list[str] = field(default_factory=list)


@dataclass
class CommunityArchetype:
    """Full archetype definition from a YAML file."""

    name: str
    version: str
    resolves_to: str
    weight_overrides: dict[str, float]
    description: str
    use_cases: list[str]
    compliance_tags: list[str]
    author: str
    license: str

    def to_yaml(self) -> str:
        """Serialize to a human-readable YAML string."""
        lines = [
            f"name: {self.name}",
            f"version: {self.version}",
            f"resolves_to: {self.resolves_to}",
            f"description: {self.description}",
            f"author: {self.author}",
            f"license: {self.license}",
            "weight_overrides:",
        ]
        for k, v in self.weight_overrides.items():
            lines.append(f"  {k}: {v}")
        lines.append("use_cases:")
        for u in self.use_cases:
            lines.append(f"  - {u}")
        lines.append("compliance_tags:")
        for t in self.compliance_tags:
            lines.append(f"  - {t}")
        return "\n".join(lines) + "\n"


# ── Marketplace client ─────────────────────────────────────────────────


class ArchetypeMarketplace:
    """Client for the community archetype registry."""

    REGISTRY_INDEX_URL = (
        "https://raw.githubusercontent.com/nomotic-ai/"
        "archetype-registry/main/index.json"
    )
    REGISTRY_ARCHETYPE_URL = (
        "https://raw.githubusercontent.com/nomotic-ai/"
        "archetype-registry/main/archetypes/{name}.yaml"
    )

    # All archetype names recognized as valid base archetypes.
    VALID_BASE_ARCHETYPES = {
        "customer-experience",
        "sales-assistant",
        "data-processing",
        "analytics",
        "financial-transactions",
        "underwriting",
        "system-administration",
        "workflow-orchestration",
        "supply-chain",
        "content-generation",
        "content-moderation",
        "security-monitoring",
        "compliance-audit",
        "clinical-support",
        "research-assistant",
        "general-purpose",
        "legal-assistant",
        "hr-agent",
        "procurement-agent",
        "devops-agent",
        "fraud-detection",
        "document-processor",
    }

    def __init__(self, timeout: int = 10) -> None:
        self.timeout = timeout

    # ── Index ───────────────────────────────────────────────────────

    def fetch_index(self) -> list[ArchetypeEntry]:
        """Download and parse the registry index."""
        try:
            with urllib.request.urlopen(
                self.REGISTRY_INDEX_URL, timeout=self.timeout
            ) as resp:
                data = json.loads(resp.read().decode())
            return [ArchetypeEntry(**entry) for entry in data.get("archetypes", [])]
        except (urllib.error.URLError, urllib.error.HTTPError, OSError) as exc:
            raise MarketplaceConnectionError(
                f"Could not reach archetype registry: {exc}"
            ) from exc

    # ── Single archetype ────────────────────────────────────────────

    def fetch_archetype(self, name: str) -> CommunityArchetype:
        """Download and parse a single archetype YAML."""
        url = self.REGISTRY_ARCHETYPE_URL.format(name=name)
        try:
            with urllib.request.urlopen(url, timeout=self.timeout) as resp:
                content = resp.read().decode()
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise ArchetypeValidationError(
                    f"Archetype '{name}' not found in registry"
                ) from exc
            raise MarketplaceConnectionError(
                f"Registry error: {exc}"
            ) from exc
        except (urllib.error.URLError, OSError) as exc:
            raise MarketplaceConnectionError(
                f"Could not reach registry: {exc}"
            ) from exc

        if not YAML_AVAILABLE:
            raise RuntimeError(
                "pyyaml required for archetype parsing: pip install pyyaml"
            )

        raw = yaml.safe_load(content)
        return CommunityArchetype(
            name=raw["name"],
            version=raw.get("version", "0.0.1"),
            resolves_to=raw["resolves_to"],
            weight_overrides=raw.get("weight_overrides", {}),
            description=raw.get("description", ""),
            use_cases=raw.get("use_cases", []),
            compliance_tags=raw.get("compliance_tags", []),
            author=raw.get("author", "unknown"),
            license=raw.get("license", "MIT"),
        )

    # ── Validation ──────────────────────────────────────────────────

    def validate_archetype(self, arch: CommunityArchetype) -> None:
        """Raise ``ArchetypeValidationError`` if *arch* is invalid."""
        errors: list[str] = []

        if not arch.name or not arch.name.replace("-", "").isalnum():
            errors.append("name must be alphanumeric with hyphens only")

        if arch.resolves_to not in self.VALID_BASE_ARCHETYPES:
            errors.append(
                f"resolves_to '{arch.resolves_to}' is not a valid base archetype"
            )

        for dim, val in arch.weight_overrides.items():
            if not isinstance(val, (int, float)) or not (0.0 <= val <= 5.0):
                errors.append(
                    f"weight_overrides.{dim} = {val} is outside range [0.0, 5.0]"
                )

        if errors:
            raise ArchetypeValidationError(
                "Archetype validation failed:\n"
                + "\n".join(f"  - {e}" for e in errors)
            )

    # ── Install ─────────────────────────────────────────────────────

    def install_archetype(
        self,
        arch: CommunityArchetype,
        install_dir: Path | None = None,
    ) -> Path:
        """Validate and install archetype to local directory."""
        self.validate_archetype(arch)

        if install_dir is None:
            install_dir = Path.home() / ".nomotic" / "community-archetypes"
        install_dir.mkdir(parents=True, exist_ok=True)

        output_path = install_dir / f"{arch.name}.yaml"
        output_path.write_text(arch.to_yaml())
        return output_path
