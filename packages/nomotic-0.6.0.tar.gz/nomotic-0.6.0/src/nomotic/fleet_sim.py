"""Fleet Simulator — demo-quality fleet simulation with real governance evaluations.

Produces a realistic multi-department agent fleet that runs real governance
evaluations through the actual UCS engine. Simulated agents live in an
isolated namespace with separate stores, never touching production data.

Usage::

    from nomotic.fleet_sim import FleetSimulator, SimulationConfig

    config = SimulationConfig(agent_count=1000)
    sim = FleetSimulator(config)
    sim.provision_agents()
    sim.start()
    # ... later ...
    snap = sim.stats_snapshot()
    sim.stop()
"""

from __future__ import annotations

import json
import random
import threading
import time
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

logger = logging.getLogger(__name__)

# ── Department definitions ─────────────────────────────────────────────────

DEPARTMENTS = {
    "CRM": {
        "archetypes": ["customer-experience", "sales-agent"],
        "actions": [
            ("read", "customer_record", 0.30),
            ("update", "crm_record", 0.25),
            ("send", "customer_email", 0.20),
            ("read", "deal_history", 0.15),
            ("export", "contact_list", 0.10),  # intentionally risky
        ],
    },
    "Finance": {
        "archetypes": ["financial-analyst", "fraud-detection"],
        "actions": [
            ("read", "portfolio_data", 0.30),
            ("execute", "market_trade", 0.20),
            ("analyze", "risk_model", 0.20),
            ("read", "client_account", 0.20),
            ("transfer", "funds", 0.10),  # intentionally risky
        ],
    },
    "DevOps": {
        "archetypes": ["devops-agent", "operations-coordinator"],
        "actions": [
            ("deploy", "service", 0.30),
            ("read", "system_log", 0.25),
            ("restart", "container", 0.20),
            ("update", "firewall_rule", 0.15),
            ("delete", "production_volume", 0.10),  # intentionally risky
        ],
    },
    "Data & Analytics": {
        "archetypes": ["data-processor", "document-processor"],
        "actions": [
            ("read", "analytics_db", 0.35),
            ("query", "data_warehouse", 0.30),
            ("export", "dataset", 0.20),
            ("write", "pipeline_output", 0.10),
            ("delete", "raw_data", 0.05),  # intentionally risky
        ],
    },
    "Security": {
        "archetypes": ["security-monitor", "fraud-detection"],
        "actions": [
            ("scan", "network_segment", 0.30),
            ("read", "threat_database", 0.25),
            ("analyze", "incident_log", 0.25),
            ("block", "ip_address", 0.15),
            ("access", "unregistered_endpoint", 0.05),  # intentionally risky
        ],
    },
    "Human Resources": {
        "archetypes": ["hr-agent", "executive-assistant"],
        "actions": [
            ("read", "employee_record", 0.35),
            ("update", "compensation_data", 0.25),
            ("access", "performance_review", 0.20),
            ("export", "org_chart", 0.15),
            ("read", "payroll_db", 0.05),  # intentionally risky
        ],
    },
    "Procurement": {
        "archetypes": ["procurement-agent", "operations-coordinator"],
        "actions": [
            ("read", "vendor_catalog", 0.30),
            ("issue", "purchase_order", 0.30),
            ("approve", "invoice", 0.25),
            ("update", "supplier_contract", 0.10),
            ("execute", "bulk_order", 0.05),  # intentionally risky
        ],
    },
    "Support": {
        "archetypes": ["customer-experience", "sales-agent"],
        "actions": [
            ("read", "ticket_data", 0.35),
            ("update", "ticket_status", 0.30),
            ("issue", "refund", 0.20),
            ("access", "customer_account", 0.10),
            ("export", "support_history", 0.05),  # intentionally risky
        ],
    },
    "Legal": {
        "archetypes": ["legal-assistant", "research-analyst"],
        "actions": [
            ("read", "case_files", 0.35),
            ("search", "legal_database", 0.30),
            ("draft", "contract", 0.20),
            ("access", "court_records", 0.10),
            ("export", "confidential_docs", 0.05),  # intentionally risky
        ],
    },
    "Executive": {
        "archetypes": ["executive-assistant", "financial-analyst"],
        "actions": [
            ("read", "board_materials", 0.35),
            ("schedule", "executive_calendar", 0.30),
            ("read", "financial_summary", 0.20),
            ("access", "strategic_plan", 0.10),
            ("export", "investor_data", 0.05),  # intentionally risky
        ],
    },
}

# Targets considered risky for behavior profile weighting
_RISKY_KEYWORDS = frozenset([
    "bulk", "export", "delete", "transfer", "payroll",
    "investor", "production", "confidential",
])

# ── Agent behavior profiles ────────────────────────────────────────────────

BEHAVIOR_PROFILES = {
    "compliant": {"weight": 0.65, "trust_init": (0.70, 0.90), "risky_multiplier": 0.2},
    "borderline": {"weight": 0.20, "trust_init": (0.45, 0.65), "risky_multiplier": 1.0},
    "drifting": {"weight": 0.10, "trust_init": (0.55, 0.75), "risky_multiplier": 2.5},
    "rogue": {"weight": 0.05, "trust_init": (0.30, 0.50), "risky_multiplier": 4.0},
}


# ── SimulatedAgent dataclass ───────────────────────────────────────────────


@dataclass
class SimulatedAgent:
    agent_id: str
    department: str
    archetype: str
    behavior_profile: str
    certificate_id: str
    initial_trust: float
    evaluations: int = 0
    denials: int = 0
    escalations: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


# ── SimulationConfig ───────────────────────────────────────────────────────


@dataclass
class SimulationConfig:
    name: str = "Enterprise Agent Governance"
    scenario: str = "AcmeCo Q2 Launch"
    agent_count: int = 100
    departments: list[str] = field(default_factory=lambda: list(DEPARTMENTS.keys()))
    evaluations_per_second: float = 10.0
    org_id: str = "simulation"
    zone: str = "sim/production"


# ── FleetSimulator ─────────────────────────────────────────────────────────


class FleetSimulator:
    """Runs a realistic multi-department fleet simulation using real governance.

    All simulation state lives in isolated in-memory stores. The simulation
    state file at ``STATE_PATH`` enables cross-process dashboard access.
    """

    STATE_PATH = Path.home() / ".nomotic" / "fleet-sim-state.json"

    def __init__(self, config: SimulationConfig) -> None:
        self.config = config
        self.agents: list[SimulatedAgent] = []
        self._running = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._total_evaluations = 0
        self._total_denials = 0
        self._total_escalations = 0
        self._started_at: datetime | None = None

        # Simulation stores — isolated from production
        from nomotic.store import MemoryCertificateStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.authority import CertificateAuthority
        from nomotic.keys import SigningKey

        self._cert_store = MemoryCertificateStore()
        issuer_sk, _issuer_vk = SigningKey.generate()
        self._ca = CertificateAuthority("sim-issuer", issuer_sk, self._cert_store)

        rt_config = RuntimeConfig(
            deny_threshold=0.35,
            allow_threshold=0.65,
        )
        self._runtime = GovernanceRuntime(rt_config)

    # ── Agent provisioning ─────────────────────────────────────────────────

    def provision_agents(self) -> None:
        """Create simulated agents with realistic distribution across departments.

        Batched: all certificates issued before simulation starts.
        Shows a progress bar during provisioning.
        """
        dept_names = self.config.departments
        agents_per_dept = self.config.agent_count // len(dept_names)
        remainder = self.config.agent_count % len(dept_names)

        agent_idx = 0
        for di, dept_name in enumerate(dept_names):
            dept = DEPARTMENTS[dept_name]
            count = agents_per_dept + (1 if di < remainder else 0)

            for i in range(count):
                archetype = random.choice(dept["archetypes"])

                profile_name = random.choices(
                    list(BEHAVIOR_PROFILES.keys()),
                    weights=[p["weight"] for p in BEHAVIOR_PROFILES.values()],
                )[0]
                profile = BEHAVIOR_PROFILES[profile_name]
                trust_lo, trust_hi = profile["trust_init"]
                init_trust = round(random.uniform(trust_lo, trust_hi), 3)

                agent_id = f"{dept_name.lower().replace(' & ', '-').replace(' ', '-')}-agent-{i + 1:03d}"

                cert, _agent_sk = self._ca.issue(
                    agent_id=agent_id,
                    archetype=archetype,
                    organization=self.config.org_id,
                    zone_path=self.config.zone,
                    owner=f"sim@{dept_name.lower().replace(' ', '')}.acmeco.com",
                )

                self.agents.append(SimulatedAgent(
                    agent_id=agent_id,
                    department=dept_name,
                    archetype=archetype,
                    behavior_profile=profile_name,
                    certificate_id=cert.certificate_id,
                    initial_trust=init_trust,
                ))

                agent_idx += 1
                pct = agent_idx / self.config.agent_count
                bar = "\u2588" * int(pct * 40) + "\u2591" * (40 - int(pct * 40))
                print(
                    f"\r  Provisioning agents [{bar}] {agent_idx}/{self.config.agent_count}",
                    end="", flush=True,
                )

        print()  # newline after progress bar

    # ── Simulation loop ────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the simulation in a background thread."""
        self._running = True
        self._started_at = datetime.now(timezone.utc)
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self._write_state()

    def stop(self) -> None:
        """Stop the simulation and clean up state."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        if self.STATE_PATH.exists():
            self.STATE_PATH.unlink()

    def _run_loop(self) -> None:
        """Main evaluation loop. Fires evaluations at configured rate."""
        from nomotic.types import Action, AgentContext, TrustProfile

        interval = 1.0 / self.config.evaluations_per_second

        while self._running:
            agent = random.choice(self.agents)
            dept = DEPARTMENTS[agent.department]
            profile = BEHAVIOR_PROFILES[agent.behavior_profile]

            # Pick action — risky actions more likely for rogue/drifting profiles
            actions: list[tuple[str, str]] = []
            weights: list[float] = []
            for act_type, act_target, base_weight in dept["actions"]:
                is_risky = any(r in act_target for r in _RISKY_KEYWORDS)
                adj_weight = base_weight * (profile["risky_multiplier"] if is_risky else 1.0)
                actions.append((act_type, act_target))
                weights.append(adj_weight)

            act_type, act_target = random.choices(actions, weights=weights)[0]
            reversible = act_type not in ("delete", "transfer", "export")

            action = Action(
                agent_id=agent.agent_id,
                action_type=act_type,
                target=act_target,
                parameters={},
                metadata={"reversible": reversible},
            )
            ctx = AgentContext(
                agent_id=agent.agent_id,
                trust_profile=TrustProfile(
                    agent_id=agent.agent_id,
                    overall_trust=agent.initial_trust,
                ),
            )

            try:
                result = self._runtime.evaluate(action, ctx)
                verdict = result.verdict.name if hasattr(result.verdict, "name") else str(result.verdict)

                with self._lock:
                    agent.evaluations += 1
                    self._total_evaluations += 1
                    if verdict == "DENY":
                        agent.denials += 1
                        self._total_denials += 1
                    elif verdict == "ESCALATE":
                        agent.escalations += 1
                        self._total_escalations += 1
            except Exception as e:
                logger.debug("Sim eval error for %s: %s", agent.agent_id, e)

            time.sleep(interval)

    # ── State persistence ──────────────────────────────────────────────────

    def _write_state(self) -> None:
        """Write simulation state to disk for dashboard pickup."""
        self.STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        state = {
            "running": self._running,
            "config": asdict(self.config),
            "started_at": self._started_at.isoformat() if self._started_at else None,
            "agent_count": len(self.agents),
            "departments": list(DEPARTMENTS.keys()),
        }
        self.STATE_PATH.write_text(json.dumps(state, indent=2))

    def stats_snapshot(self) -> dict:
        """Thread-safe stats for dashboard or CLI display."""
        with self._lock:
            deny_rate = (
                self._total_denials / self._total_evaluations
                if self._total_evaluations
                else 0.0
            )

            dept_breakdown: dict[str, dict] = {}
            for agent in self.agents:
                d = agent.department
                if d not in dept_breakdown:
                    dept_breakdown[d] = {
                        "calls": 0,
                        "governed": 0,
                        "refused": 0,
                        "divergence_pct": 0.0,
                    }
                dept_breakdown[d]["calls"] += agent.evaluations
                dept_breakdown[d]["governed"] += agent.evaluations
                dept_breakdown[d]["refused"] += agent.denials

            # Compute divergence % per department (denial rate above fleet avg)
            fleet_denial_rate = deny_rate
            for _dept_name, stats in dept_breakdown.items():
                dept_rate = stats["refused"] / stats["governed"] if stats["governed"] else 0.0
                stats["divergence_pct"] = round(
                    max(0.0, dept_rate - fleet_denial_rate) * 100, 1,
                )

            return {
                "scenario": self.config.scenario,
                "total_agents": len(self.agents),
                "total_evaluations": self._total_evaluations,
                "total_governed": self._total_evaluations,
                "total_refused": self._total_denials,
                "total_escalated": self._total_escalations,
                "denial_rate_pct": round(deny_rate * 100, 2),
                "governance_rate_pct": round(
                    (self._total_evaluations / max(self._total_evaluations, 1)) * 100,
                    1,
                ),
                "department_breakdown": dept_breakdown,
                "top_denied_tools": self._top_denied_tools(),
                "profile_distribution": self._profile_distribution(),
                "elapsed_seconds": (
                    (datetime.now(timezone.utc) - self._started_at).total_seconds()
                    if self._started_at
                    else 0
                ),
            }

    def _top_denied_tools(self) -> list[dict]:
        """Top denied action+target combos across all agents."""
        tool_denials: dict[str, int] = {}
        for agent in self.agents:
            if agent.denials > 0:
                dept = DEPARTMENTS[agent.department]
                risky = [
                    (t, w)
                    for _at, t, w in dept["actions"]
                    if any(r in t for r in _RISKY_KEYWORDS)
                ]
                for tool, _ in risky:
                    key = f"{agent.department.lower()}_{tool}"
                    tool_denials[key] = tool_denials.get(key, 0) + max(
                        1, agent.denials // 3,
                    )
        return sorted(
            [{"tool": k, "count": v} for k, v in tool_denials.items()],
            key=lambda x: -x["count"],
        )[:10]

    def _profile_distribution(self) -> dict:
        """Count of agents per behavior profile."""
        dist: dict[str, int] = {}
        for agent in self.agents:
            dist[agent.behavior_profile] = dist.get(agent.behavior_profile, 0) + 1
        return dist

    def get_runtime(self):
        """Return the simulation GovernanceRuntime for dashboard wiring."""
        return self._runtime

    def get_cert_store(self):
        """Return the simulation certificate store."""
        return self._cert_store

    def get_ca(self):
        """Return the simulation CertificateAuthority."""
        return self._ca
