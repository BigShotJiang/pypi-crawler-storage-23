"""Drift calculator — measures behavioral deviation from baseline.

Compares two fingerprints (baseline and recent window) and produces a
drift score.  Pure computation — no side effects, no state mutation.

The core metric is Jensen-Shannon Divergence (JSD), a symmetric,
bounded distance between probability distributions.  JSD is computed
with basic math (:mod:`math`) — no external dependencies.

Also contains: AmbiguityDriftObserver (meta-level governance decision
monitoring), UnifiedAgentHealthScore (composite health metric), and
FeedbackLoopManager (threshold-crossing trust calibration feedback).
"""

from __future__ import annotations

import math
import time as _time
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from nomotic.fingerprint import BehavioralFingerprint, TemporalPattern

if TYPE_CHECKING:
    from nomotic.audit_store import GovernanceHealthStore
    from nomotic.priors import ArchetypePrior
    from nomotic.trust import TrustCalibrator

__all__ = [
    "AmbiguityDriftConfig",
    "AmbiguityDriftObserver",
    "AmbiguityDriftProfile",
    "DriftCalculator",
    "DriftScore",
    "FeedbackLoopManager",
    "UnifiedAgentHealthScore",
    "UnifiedHealthScoreCalculator",
    "compute_ambiguity_health_score",
    # Audit event type constants
    "AUDIT_ALARM_DETECTED",
    "AUDIT_AMBIGUITY_PROFILE_UPDATE",
    "AUDIT_BAND_WIDTH_MODIFIED",
    "AUDIT_STATUS_BOUNDARY_CROSSED",
    "AUDIT_TRUST_CALIBRATION_APPLIED",
    "AUDIT_UAHS_COMPUTED",
    # Persistence helper
    "persist_health_events",
]

# ── Audit event type constants ─────────────────────────────────────────

AUDIT_AMBIGUITY_PROFILE_UPDATE = "ambiguity_profile_update"
AUDIT_UAHS_COMPUTED = "uahs_computed"
AUDIT_STATUS_BOUNDARY_CROSSED = "status_boundary_crossed"
AUDIT_TRUST_CALIBRATION_APPLIED = "trust_calibration_applied"
AUDIT_ALARM_DETECTED = "alarm_detected"
AUDIT_BAND_WIDTH_MODIFIED = "band_width_modified"

# Tiny smoothing constant to avoid log(0).
_EPS = 1e-12


# ── Distance metrics ────────────────────────────────────────────────────


def _kld(a: dict[str, float], b: dict[str, float], all_keys: set[str]) -> float:
    """Kullback-Leibler divergence KLD(a || b) over *all_keys*.

    Zero entries in *a* contribute 0 (0 * log(0/x) = 0 by convention).
    Zero entries in *b* are smoothed with ``_EPS``.
    """
    total = 0.0
    for k in all_keys:
        ak = a.get(k, 0.0)
        if ak <= 0.0:
            continue
        bk = b.get(k, 0.0) + _EPS
        total += ak * math.log2(ak / bk)
    return total


def _jsd(p: dict[str, float], q: dict[str, float]) -> float:
    """Jensen-Shannon Divergence between two distributions.

    Both *p* and *q* map categories to probabilities.  Categories
    present in one but not the other are treated as 0.0.

    Returns a value in [0.0, 1.0].

    JSD(p, q) = 0.5 * KLD(p || m) + 0.5 * KLD(q || m)
    where m = 0.5 * (p + q).

    Special cases:

    * Both empty → 0.0
    * One empty, other non-empty → 1.0
    * Identical → 0.0
    """
    if not p and not q:
        return 0.0
    if not p or not q:
        return 1.0

    all_keys = set(p) | set(q)

    # Build midpoint distribution m = 0.5*(p + q)
    m: dict[str, float] = {}
    for k in all_keys:
        m[k] = 0.5 * (p.get(k, 0.0) + q.get(k, 0.0))

    jsd_val = 0.5 * _kld(p, m, all_keys) + 0.5 * _kld(q, m, all_keys)
    # Clamp to [0, 1] for numerical safety
    return max(0.0, min(1.0, jsd_val))


def _temporal_distance(
    baseline: TemporalPattern,
    recent: TemporalPattern,
) -> float:
    """Distance between two temporal patterns.

    Combines:

    * JSD of hourly distributions (when the agent is active): weight 0.6
    * Normalised rate deviation (how much activity changed): weight 0.4

    Rate deviation = |recent_mean - baseline_mean| / max(baseline_mean, 1.0),
    clamped to [0.0, 1.0].

    Returns a value in [0.0, 1.0].
    """
    # Hourly distribution distance
    # Convert int keys to str for _jsd compatibility
    p = {str(k): v for k, v in baseline.hourly_distribution.items()}
    q = {str(k): v for k, v in recent.hourly_distribution.items()}
    hourly_jsd = _jsd(p, q)

    # Rate deviation
    baseline_mean = baseline.actions_per_hour_mean
    recent_mean = recent.actions_per_hour_mean
    if baseline_mean <= 0.0 and recent_mean <= 0.0:
        rate_dev = 0.0
    else:
        rate_dev = abs(recent_mean - baseline_mean) / max(baseline_mean, 1.0)
        rate_dev = min(rate_dev, 1.0)

    return 0.6 * hourly_jsd + 0.4 * rate_dev


# ── DriftScore ──────────────────────────────────────────────────────────


@dataclass
class DriftScore:
    """Result of comparing recent behaviour against baseline.

    The overall drift is a weighted combination of per-distribution
    drift scores, where weights come from the archetype's drift_weights.
    """

    overall: float
    """Weighted composite drift.  0.0 = identical to baseline, 1.0 = completely different."""

    action_drift: float
    """How much the action-type distribution has changed."""

    target_drift: float
    """How much the target distribution has changed."""

    temporal_drift: float
    """How much the temporal pattern has changed."""

    outcome_drift: float
    """How much the governance-outcome distribution has changed."""

    confidence: float
    """How confident the drift measurement is, based on observation counts.
    Low confidence means the score is unreliable."""

    window_size: int
    """Number of observations in the recent window."""

    baseline_size: int
    """Number of observations in the baseline."""

    detail: str = ""
    """Human-readable summary of what drifted most."""

    @property
    def severity(self) -> str:
        """Categorise drift severity.

        Returns one of: ``"none"``, ``"low"``, ``"moderate"``, ``"high"``, ``"critical"``.
        """
        if self.overall < 0.05:
            return "none"
        if self.overall < 0.15:
            return "low"
        if self.overall < 0.35:
            return "moderate"
        if self.overall < 0.60:
            return "high"
        return "critical"

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a JSON-friendly dict."""
        return {
            "overall": round(self.overall, 4),
            "action_drift": round(self.action_drift, 4),
            "target_drift": round(self.target_drift, 4),
            "temporal_drift": round(self.temporal_drift, 4),
            "outcome_drift": round(self.outcome_drift, 4),
            "confidence": round(self.confidence, 4),
            "window_size": self.window_size,
            "baseline_size": self.baseline_size,
            "severity": self.severity,
            "detail": self.detail,
        }


# ── DriftCalculator ─────────────────────────────────────────────────────


def _build_detail(
    baseline: BehavioralFingerprint,
    recent: BehavioralFingerprint,
    drifts: dict[str, float],
) -> str:
    """Build the human-readable detail string.

    Identifies the distribution that contributed most to drift and
    reports the two categories with the largest absolute change.
    """
    # Find the distribution with the largest drift
    dist_name = max(drifts, key=lambda k: drifts[k])
    dist_drift = drifts[dist_name]
    if dist_drift < 0.01:
        return "No significant drift detected"

    # Get the two distributions to compare
    dist_map = {
        "action": (baseline.action_distribution, recent.action_distribution),
        "target": (baseline.target_distribution, recent.target_distribution),
        "outcome": (baseline.outcome_distribution, recent.outcome_distribution),
    }

    if dist_name == "temporal":
        return f"Temporal pattern shifted (drift={dist_drift:.2f})"

    base_dist, recent_dist = dist_map.get(dist_name, ({}, {}))
    if not base_dist and not recent_dist:
        return f"{dist_name.title()} distribution shifted (drift={dist_drift:.2f})"

    # Compute deltas for all keys
    all_keys = set(base_dist) | set(recent_dist)
    deltas: list[tuple[str, float, float, float]] = []
    for k in all_keys:
        bv = base_dist.get(k, 0.0)
        rv = recent_dist.get(k, 0.0)
        deltas.append((k, bv, rv, rv - bv))

    # Sort by absolute delta descending
    deltas.sort(key=lambda x: abs(x[3]), reverse=True)

    parts: list[str] = []
    for cat, bv, rv, delta in deltas[:2]:
        direction = "increased" if delta > 0 else "decreased"
        parts.append(f"'{cat}' {direction} from {bv:.0%} to {rv:.0%}")

    label = dist_name.title()
    return f"{label} distribution shifted: {', '.join(parts)}"


class DriftCalculator:
    """Compares recent agent behaviour against baseline fingerprint.

    Pure computation — no side effects, no state mutation.  Takes two
    fingerprints (baseline and recent) and produces a :class:`DriftScore`.

    Usage::

        calculator = DriftCalculator()
        score = calculator.compare(baseline_fp, recent_fp, drift_weights)
    """

    def compare(
        self,
        baseline: BehavioralFingerprint,
        recent: BehavioralFingerprint,
        drift_weights: dict[str, float] | None = None,
    ) -> DriftScore:
        """Compare recent behaviour against baseline.

        Args:
            baseline: The agent's full behavioural fingerprint (all history).
            recent: A fingerprint built from only the last *N* actions.
            drift_weights: Optional per-distribution importance weights.
                Keys: ``"action"``, ``"target"``, ``"temporal"``, ``"outcome"``.
                Values: multipliers (1.0 = normal importance).
                If ``None``, all distributions weighted equally.

        Returns:
            :class:`DriftScore` with per-distribution and overall drift.
        """
        weights = drift_weights or {
            "action": 1.0,
            "target": 1.0,
            "temporal": 1.0,
            "outcome": 1.0,
        }

        # Edge cases
        if baseline.total_observations == 0 and recent.total_observations == 0:
            return DriftScore(
                overall=0.0,
                action_drift=0.0,
                target_drift=0.0,
                temporal_drift=0.0,
                outcome_drift=0.0,
                confidence=0.0,
                window_size=recent.total_observations,
                baseline_size=baseline.total_observations,
                detail="No observations in either fingerprint",
            )

        if baseline.total_observations == 0:
            return DriftScore(
                overall=1.0,
                action_drift=1.0,
                target_drift=1.0,
                temporal_drift=1.0,
                outcome_drift=1.0,
                confidence=0.0,
                window_size=recent.total_observations,
                baseline_size=0,
                detail="No baseline data to compare against",
            )

        if recent.total_observations == 0:
            return DriftScore(
                overall=0.0,
                action_drift=0.0,
                target_drift=0.0,
                temporal_drift=0.0,
                outcome_drift=0.0,
                confidence=0.0,
                window_size=0,
                baseline_size=baseline.total_observations,
                detail="No recent observations",
            )

        # Per-distribution drift
        action_drift = _jsd(baseline.action_distribution, recent.action_distribution)
        target_drift = _jsd(baseline.target_distribution, recent.target_distribution)
        temporal_drift = _temporal_distance(baseline.temporal_pattern, recent.temporal_pattern)
        outcome_drift = _jsd(baseline.outcome_distribution, recent.outcome_distribution)

        # Weighted overall
        drifts = {
            "action": action_drift,
            "target": target_drift,
            "temporal": temporal_drift,
            "outcome": outcome_drift,
        }
        weighted_sum = sum(drifts[k] * weights.get(k, 1.0) for k in drifts)
        weight_total = sum(weights.get(k, 1.0) for k in drifts)
        overall = weighted_sum / weight_total if weight_total > 0 else 0.0
        overall = max(0.0, min(1.0, overall))

        # Confidence — based on observation counts
        min_obs = min(baseline.total_observations, recent.total_observations)
        confidence = min(baseline.confidence, recent.confidence)
        # Reduce further for very small sample sizes
        if min_obs < 50:
            confidence *= min_obs / 50.0

        detail = _build_detail(baseline, recent, drifts)

        return DriftScore(
            overall=overall,
            action_drift=action_drift,
            target_drift=target_drift,
            temporal_drift=temporal_drift,
            outcome_drift=outcome_drift,
            confidence=confidence,
            window_size=recent.total_observations,
            baseline_size=baseline.total_observations,
            detail=detail,
        )

    def compare_against_prior(
        self,
        observed: BehavioralFingerprint,
        prior: ArchetypePrior,
    ) -> DriftScore:
        """Compare observed behaviour against the archetype prior.

        Useful when the agent has no established baseline yet —
        compare against what the archetype says is normal.

        Constructs a synthetic baseline fingerprint from the prior's
        distributions and compares using the prior's drift_weights.
        """
        synthetic = BehavioralFingerprint(agent_id=f"_prior_{prior.archetype_name}")
        synthetic.action_distribution = dict(prior.action_distribution)
        synthetic.target_distribution = dict(prior.target_categories)
        synthetic.outcome_distribution = dict(prior.outcome_expectations)
        # Give the synthetic baseline a nominal observation count so
        # confidence works and we don't hit the "empty baseline" edge case.
        synthetic.total_observations = prior.prior_weight

        return self.compare(
            baseline=synthetic,
            recent=observed,
            drift_weights=prior.drift_weights,
        )


# ── Ambiguity Drift Detection ─────────────────────────────────────────


@dataclass
class AmbiguityDriftConfig:
    """Configuration for ambiguity drift tracking."""

    window_size: int = 100  # Rolling window in SUBSTANTIVE evaluations
    band_low: float = 0.30  # Default ambiguity band lower bound
    band_high: float = 0.70  # Default ambiguity band upper bound
    rise_threshold: float = 0.25  # % above baseline to classify as 'rising'
    fall_threshold: float = 0.25  # % below baseline to classify as 'falling'
    accept_drift_threshold: float = 0.15  # Resolution bias change to classify as 'toward_accept'
    deny_drift_threshold: float = 0.15  # Resolution bias change to classify as 'toward_deny'
    baseline_ema_alpha: float = 0.10  # EMA smoothing for baseline ambiguity rate


@dataclass
class AmbiguityDriftProfile:
    """Per-agent ambiguity drift state."""

    agent_id: str
    window_size: int
    # Ambiguity rate
    ambiguity_rate: float = 0.0
    ambiguity_rate_baseline: float = 0.0
    ambiguity_rate_trend: str = "stable"  # "rising" | "stable" | "falling"
    # Resolution bias
    resolution_bias: float = 0.0  # -1.0 (all deny) to +1.0 (all accept)
    resolution_bias_trend: str = "stable"  # "toward_accept" | "stable" | "toward_deny"
    _prev_resolution_bias: float = field(default=0.0, repr=False)
    # Human override rate in band
    human_override_rate_in_band: float = 0.0
    human_override_rate_trend: str = "stable"  # "rising" | "stable" | "falling"
    _prev_override_rate: float = field(default=0.0, repr=False)
    # Sanity check
    ritual_exclusion_rate: float = 0.0
    # Band config (archetype-parameterized, dynamically adjusted)
    band_low: float = 0.30
    band_high: float = 0.70
    # Counters (internal, rolling window)
    _total_evals: int = field(default=0, repr=False)
    _routine_evals: int = field(default=0, repr=False)
    _in_band_count: int = field(default=0, repr=False)
    _allow_in_band: int = field(default=0, repr=False)
    _deny_in_band: int = field(default=0, repr=False)
    _override_in_band: int = field(default=0, repr=False)
    # Compound alarm
    alert: bool = False
    alert_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "window_size": self.window_size,
            "ambiguity_rate": round(self.ambiguity_rate, 4),
            "ambiguity_rate_baseline": round(self.ambiguity_rate_baseline, 4),
            "ambiguity_rate_trend": self.ambiguity_rate_trend,
            "resolution_bias": round(self.resolution_bias, 4),
            "resolution_bias_trend": self.resolution_bias_trend,
            "human_override_rate_in_band": round(self.human_override_rate_in_band, 4),
            "human_override_rate_trend": self.human_override_rate_trend,
            "ritual_exclusion_rate": round(self.ritual_exclusion_rate, 4),
            "band_low": self.band_low,
            "band_high": self.band_high,
            "alert": self.alert,
            "alert_reason": self.alert_reason,
        }


class AmbiguityDriftObserver:
    """Tracks the rate of ambiguous governance decisions per agent.

    Operates at the meta-level of governance decision outputs —
    monitors UCS score distributions independently of the raw
    behavioral distributions tracked by DriftMonitor.

    Detects the compound boundary erosion by accumulation condition:
    rising ambiguity rate + accept-biased resolution + falling human
    override engagement, all three simultaneously.
    """

    def __init__(self) -> None:
        # Per-agent circular buffers: deque of (ucs, verdict, was_override)
        self._buffers: dict[str, deque[tuple[float, str, bool]]] = {}
        # Per-agent profiles
        self._profiles: dict[str, AmbiguityDriftProfile] = {}
        # Per-agent alarm detection records (populated on False→True edge)
        self._alarm_events: dict[str, dict[str, Any]] = {}

    def observe(
        self,
        agent_id: str,
        ucs: float,
        verdict: str,
        action_class: str = "substantive",
        was_human_override: bool = False,
        config: AmbiguityDriftConfig | None = None,
    ) -> AmbiguityDriftProfile:
        """Record a single governance evaluation.

        Args:
            agent_id: The agent being observed.
            ucs: The Unified Confidence Score.
            verdict: "ALLOW", "DENY", or "ESCALATE".
            action_class: "routine" or "substantive".
            was_human_override: True if a human changed the autonomous verdict.
            config: Configuration for drift tracking.

        Returns:
            Updated AmbiguityDriftProfile for the agent.
        """
        cfg = config or AmbiguityDriftConfig()

        # Ensure profile exists
        if agent_id not in self._profiles:
            self._profiles[agent_id] = AmbiguityDriftProfile(
                agent_id=agent_id,
                window_size=cfg.window_size,
                band_low=cfg.band_low,
                band_high=cfg.band_high,
            )
        if agent_id not in self._buffers:
            self._buffers[agent_id] = deque(maxlen=cfg.window_size)

        profile = self._profiles[agent_id]
        profile._total_evals += 1

        if action_class == "routine":
            profile._routine_evals += 1
            # Routine evaluations do not enter the rolling window
            profile.ritual_exclusion_rate = (
                profile._routine_evals / profile._total_evals
                if profile._total_evals > 0
                else 0.0
            )
            return profile

        # Substantive evaluation — add to circular buffer
        self._buffers[agent_id].append((ucs, verdict, was_human_override))

        return self._recompute(agent_id, cfg)

    def _recompute(
        self, agent_id: str, config: AmbiguityDriftConfig
    ) -> AmbiguityDriftProfile:
        """Recompute the ambiguity drift profile from the circular buffer."""
        profile = self._profiles[agent_id]
        buf = self._buffers[agent_id]

        substantive_total = len(buf)
        if substantive_total == 0:
            return profile

        band_low = profile.band_low
        band_high = profile.band_high

        # Count in-band, allow/deny in band, overrides in band
        in_band = 0
        allow_in_band = 0
        deny_in_band = 0
        override_in_band = 0

        for ucs_val, verdict_val, was_override in buf:
            if band_low <= ucs_val <= band_high:
                in_band += 1
                # ESCALATE treated as ALLOW for bias computation
                if verdict_val in ("ALLOW", "ESCALATE"):
                    allow_in_band += 1
                elif verdict_val == "DENY":
                    deny_in_band += 1
                if was_override:
                    override_in_band += 1

        profile._in_band_count = in_band
        profile._allow_in_band = allow_in_band
        profile._deny_in_band = deny_in_band
        profile._override_in_band = override_in_band

        # Ambiguity rate
        profile.ambiguity_rate = in_band / substantive_total

        # Update baseline with EMA
        alpha = config.baseline_ema_alpha
        if profile.ambiguity_rate_baseline == 0.0:
            profile.ambiguity_rate_baseline = profile.ambiguity_rate
        else:
            profile.ambiguity_rate_baseline = (
                alpha * profile.ambiguity_rate
                + (1.0 - alpha) * profile.ambiguity_rate_baseline
            )

        # Classify ambiguity rate trend
        if profile.ambiguity_rate_baseline > 0:
            rise_pct = (
                (profile.ambiguity_rate - profile.ambiguity_rate_baseline)
                / profile.ambiguity_rate_baseline
            )
            if rise_pct > config.rise_threshold:
                profile.ambiguity_rate_trend = "rising"
            elif rise_pct < -config.fall_threshold:
                profile.ambiguity_rate_trend = "falling"
            else:
                profile.ambiguity_rate_trend = "stable"
        else:
            if profile.ambiguity_rate > config.rise_threshold:
                profile.ambiguity_rate_trend = "rising"
            else:
                profile.ambiguity_rate_trend = "stable"

        # Resolution bias
        total_in_band = max(in_band, 1)
        prev_bias = profile.resolution_bias
        profile._prev_resolution_bias = prev_bias
        profile.resolution_bias = (allow_in_band - deny_in_band) / total_in_band

        # Classify resolution bias trend
        bias_delta = profile.resolution_bias - profile._prev_resolution_bias
        if bias_delta > config.accept_drift_threshold:
            profile.resolution_bias_trend = "toward_accept"
        elif bias_delta < -config.deny_drift_threshold:
            profile.resolution_bias_trend = "toward_deny"
        else:
            profile.resolution_bias_trend = "stable"

        # Human override rate in band
        prev_override = profile.human_override_rate_in_band
        profile._prev_override_rate = prev_override
        profile.human_override_rate_in_band = override_in_band / total_in_band

        # Classify override trend
        override_delta = profile.human_override_rate_in_band - profile._prev_override_rate
        if override_delta > config.rise_threshold:
            profile.human_override_rate_trend = "rising"
        elif override_delta < -config.fall_threshold:
            profile.human_override_rate_trend = "falling"
        else:
            profile.human_override_rate_trend = "stable"

        # Ritual exclusion rate
        if profile._total_evals > 0:
            profile.ritual_exclusion_rate = profile._routine_evals / profile._total_evals

        # Compound alarm check — sticky: once fired, stays until explicitly cleared.
        # The compound alarm detects "boundary erosion by accumulation" — a pattern,
        # not a continuous condition. Once detected, it must be addressed.
        if not profile.alert:
            newly_firing, reason = self._check_compound_alarm(profile)
            if newly_firing:
                profile.alert = True
                profile.alert_reason = reason
                self._alarm_events[agent_id] = {
                    "event_type": AUDIT_ALARM_DETECTED,
                    "agent_id": agent_id,
                    "timestamp": _time.time(),
                    "ambiguity_rate_at_detection": profile.ambiguity_rate,
                    "resolution_bias_at_detection": profile.resolution_bias,
                    "human_override_rate_at_detection": profile.human_override_rate_in_band,
                    "alert_reason": profile.alert_reason,
                    # Populated later when UAHS is computed and delta is known:
                    "uahs_delta_at_detection": None,
                }

        return profile

    def _check_compound_alarm(
        self, profile: AmbiguityDriftProfile
    ) -> tuple[bool, str]:
        """Check for compound boundary erosion by accumulation.

        Returns (True, reason) only when ALL THREE simultaneously:
        - ambiguity_rate_trend == "rising"
        - resolution_bias_trend == "toward_accept"
        - human_override_rate_trend == "falling"
        """
        if (
            profile.ambiguity_rate_trend == "rising"
            and profile.resolution_bias_trend == "toward_accept"
            and profile.human_override_rate_trend == "falling"
        ):
            reason = (
                f"Compound alarm: ambiguity rate rising "
                f"({profile.ambiguity_rate:.0%} vs baseline "
                f"{profile.ambiguity_rate_baseline:.0%}), "
                f"resolution bias toward accept "
                f"(+{profile.resolution_bias:.2f}), "
                f"human override rate falling "
                f"({profile.human_override_rate_in_band:.0%})"
            )
            return True, reason
        return False, ""

    def get_profile(self, agent_id: str) -> AmbiguityDriftProfile | None:
        """Get the current ambiguity drift profile for an agent."""
        return self._profiles.get(agent_id)

    def get_alerts(self) -> list[AmbiguityDriftProfile]:
        """Returns profiles where alert == True."""
        return [p for p in self._profiles.values() if p.alert]

    def get_alarm_event(self, agent_id: str) -> dict[str, Any] | None:
        """Return the immutable alarm detection record for this agent, if any."""
        return self._alarm_events.get(agent_id)

    def set_alarm_uahs_delta(self, agent_id: str, uahs_delta: int) -> None:
        """Called after UAHS computation to link the health consequence to the alarm record."""
        if agent_id in self._alarm_events and self._alarm_events[agent_id]["uahs_delta_at_detection"] is None:
            self._alarm_events[agent_id]["uahs_delta_at_detection"] = uahs_delta

    def adjust_band(
        self,
        agent_id: str,
        new_band_low: float,
        new_band_high: float,
        floor_low: float,
        floor_high: float,
    ) -> None:
        """Adjust the ambiguity band for an agent with floor constraints.

        Args:
            agent_id: The agent whose band to adjust.
            new_band_low: Desired new lower bound.
            new_band_high: Desired new upper bound.
            floor_low: Archetype floor for band_low.
            floor_high: Archetype floor for band_high.
        """
        profile = self._profiles.get(agent_id)
        if profile is None:
            return

        # Apply floor constraints: max narrowing = 0.10 from floor
        effective_band_low = min(new_band_low, floor_low + 0.10)
        effective_band_high = max(new_band_high, floor_high - 0.10)

        profile.band_low = effective_band_low
        profile.band_high = effective_band_high


# ── Unified Agent Health Score ─────────────────────────────────────────


@dataclass
class UnifiedAgentHealthScore:
    """Composite 0-100 governance health score. High = healthy, always."""

    agent_id: str
    timestamp: float

    # Component scores, each in [0.0, 1.0], 1.0 = healthy
    behavioral_score: float  # 1.0 - behavioral_drift_score
    oversight_score: float  # 1.0 - oversight_degradation_score
    ambiguity_score: float  # From compute_ambiguity_health_score

    # Component weights (must sum to 1.0)
    behavioral_weight: float = 0.40
    oversight_weight: float = 0.30
    ambiguity_weight: float = 0.30

    # Composite
    unified_score: int = 0  # 0-100, rounded integer
    health_status: str = ""  # "excellent"|"good"|"watch"|"warning"|"critical"
    primary_signal: str = ""  # "behavioral"|"oversight"|"ambiguity" (or "" if healthy)
    trend: str = "stable"  # "improving"|"stable"|"degrading"
    _prev_score: int = field(default=-1, repr=False)

    def __post_init__(self) -> None:
        self.unified_score = self._compute_score()
        self.health_status = self._classify_status()
        self.primary_signal = self._identify_primary_signal()

    def _compute_score(self) -> int:
        raw = (
            self.behavioral_weight * self.behavioral_score
            + self.oversight_weight * self.oversight_score
            + self.ambiguity_weight * self.ambiguity_score
        )
        return round(max(0, min(100, raw * 100)))

    def _classify_status(self) -> str:
        if self.unified_score >= 90:
            return "excellent"
        elif self.unified_score >= 75:
            return "good"
        elif self.unified_score >= 55:
            return "watch"
        elif self.unified_score >= 35:
            return "warning"
        else:
            return "critical"

    def _identify_primary_signal(self) -> str:
        """Component with the largest weighted deficit."""
        if self.unified_score >= 75:
            return ""
        deficits = {
            "behavioral": self.behavioral_weight * (1.0 - self.behavioral_score),
            "oversight": self.oversight_weight * (1.0 - self.oversight_score),
            "ambiguity": self.ambiguity_weight * (1.0 - self.ambiguity_score),
        }
        return max(deficits, key=lambda k: deficits[k])

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
            "unified_score": self.unified_score,
            "health_status": self.health_status,
            "primary_signal": self.primary_signal,
            "trend": self.trend,
            "components": {
                "behavioral": {
                    "score": round(self.behavioral_score, 4),
                    "weight": self.behavioral_weight,
                    "contribution": round(
                        self.behavioral_weight * self.behavioral_score * 100, 1
                    ),
                },
                "oversight": {
                    "score": round(self.oversight_score, 4),
                    "weight": self.oversight_weight,
                    "contribution": round(
                        self.oversight_weight * self.oversight_score * 100, 1
                    ),
                },
                "ambiguity": {
                    "score": round(self.ambiguity_score, 4),
                    "weight": self.ambiguity_weight,
                    "contribution": round(
                        self.ambiguity_weight * self.ambiguity_score * 100, 1
                    ),
                },
            },
        }

    def to_audit_event(self) -> dict[str, Any]:
        """Produce an audit event dict from a computed UAHS."""
        return {
            "event_type": AUDIT_UAHS_COMPUTED,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
            "unified_score": self.unified_score,
            "health_status": self.health_status,
            "primary_signal": self.primary_signal,
            "trend": self.trend,
            "behavioral_score": round(self.behavioral_score, 4),
            "oversight_score": round(self.oversight_score, 4),
            "ambiguity_score": round(self.ambiguity_score, 4),
            "behavioral_weight": self.behavioral_weight,
            "oversight_weight": self.oversight_weight,
            "ambiguity_weight": self.ambiguity_weight,
            "alarm_mode_weights_active": self.ambiguity_weight == 0.45,
        }


def compute_ambiguity_health_score(profile: AmbiguityDriftProfile) -> float:
    """Compute the Ambiguity Health Score from an AmbiguityDriftProfile.

    Returns a float in [0.0, 1.0] where 1.0 = fully healthy.

    Sub-weights:
    - Ambiguity rate sub-score: 0.35
    - Resolution bias sub-score: 0.30
    - Override engagement sub-score: 0.35
    """
    # Ambiguity rate sub-score
    if profile.ambiguity_rate_trend == "rising":
        if profile.ambiguity_rate_baseline > 0:
            rise_pct = (
                (profile.ambiguity_rate - profile.ambiguity_rate_baseline)
                / profile.ambiguity_rate_baseline
            )
            rate_sub = max(0.0, 1.0 - rise_pct)
        else:
            rate_sub = max(0.0, 1.0 - profile.ambiguity_rate)
    elif profile.ambiguity_rate_trend == "falling":
        rate_sub = 1.0
    else:  # stable
        rate_sub = 1.0

    # Resolution bias sub-score
    bias_penalty = max(0.0, profile.resolution_bias)  # only penalize accept-bias
    bias_sub = 1.0 - bias_penalty
    if profile.resolution_bias_trend == "toward_accept":
        bias_sub *= 0.80

    # Override engagement sub-score
    if profile.human_override_rate_trend == "falling":
        override_sub = max(0.0, profile.human_override_rate_in_band)
    elif profile.human_override_rate_trend == "rising":
        override_sub = 1.0
    else:  # stable
        override_sub = 0.7 + (0.3 * profile.human_override_rate_in_band)

    ahs = 0.35 * rate_sub + 0.30 * bias_sub + 0.35 * override_sub
    return max(0.0, min(1.0, ahs))


class UnifiedHealthScoreCalculator:
    """Synthesizes behavioral, oversight, and ambiguity drift into UAHS.

    High score = healthy. Always. Convention is invariant.
    """

    def compute(
        self,
        agent_id: str,
        behavioral_drift_score: float,
        oversight_degradation_score: float,
        ambiguity_profile: AmbiguityDriftProfile,
        *,
        archetype_weights: dict[str, float] | None = None,
        prev_score: int = -1,
    ) -> UnifiedAgentHealthScore:
        """Compute the Unified Agent Health Score.

        Args:
            behavioral_drift_score: 0.0 = no drift (healthy), 1.0 = max drift.
            oversight_degradation_score: 0.0 = good oversight, 1.0 = fully degraded.
            ambiguity_profile: Current AmbiguityDriftProfile for the agent.
            archetype_weights: Optional dict with keys "behavioral","oversight","ambiguity".
            prev_score: Previous UAHS for trend computation (-1 = unknown).

        Returns:
            UnifiedAgentHealthScore with composite score and status.
        """
        behavioral_score = max(0.0, min(1.0, 1.0 - behavioral_drift_score))
        oversight_score = max(0.0, min(1.0, 1.0 - oversight_degradation_score))
        ambiguity_score = compute_ambiguity_health_score(ambiguity_profile)

        # Weight selection — dynamic boost when compound alarm is active
        if ambiguity_profile.alert:
            weights = {"behavioral": 0.30, "oversight": 0.25, "ambiguity": 0.45}
        elif archetype_weights:
            weights = archetype_weights
        else:
            weights = {"behavioral": 0.40, "oversight": 0.30, "ambiguity": 0.30}

        score = UnifiedAgentHealthScore(
            agent_id=agent_id,
            timestamp=_time.time(),
            behavioral_score=behavioral_score,
            oversight_score=oversight_score,
            ambiguity_score=ambiguity_score,
            behavioral_weight=weights["behavioral"],
            oversight_weight=weights["oversight"],
            ambiguity_weight=weights["ambiguity"],
            _prev_score=prev_score,
        )

        # Compute trend
        if prev_score >= 0:
            diff = score.unified_score - prev_score
            if diff >= 5:
                score.trend = "improving"
            elif diff <= -5:
                score.trend = "degrading"
            else:
                score.trend = "stable"

        return score


# ── Feedback Loop Manager ──────────────────────────────────────────────


class FeedbackLoopManager:
    """Detects UAHS threshold crossings and applies trust calibration adjustments.

    Closes the governance feedback loop:
    UAHS degradation -> trust penalty -> band narrowing -> future UCS shift

    Produces asymptotic resistance to persistent boundary probing:
    each cycle of probing triggers band narrowing for the next cycle.
    """

    # Status boundary trust penalties (applied * confidence)
    PENALTIES: dict[tuple[str, str], float] = {
        ("good", "watch"): -0.05,
        ("watch", "warning"): -0.10,
        ("warning", "critical"): -0.20,
    }
    RECOVERY_CREDIT: float = 0.03
    BAND_NARROWING: dict[tuple[str, str], float] = {
        ("good", "watch"): 0.01,
        ("watch", "warning"): 0.02,
        ("warning", "critical"): 0.04,
    }
    BAND_RECOVERY: float = 0.01

    # Ordered statuses from best to worst
    _STATUS_ORDER = ["excellent", "good", "watch", "warning", "critical"]

    def _detect_crossing(
        self, prev_status: str, current_status: str
    ) -> tuple[str, str] | None:
        """Detect a status boundary crossing.

        Returns crossing key like ("good", "watch") or None.
        """
        if prev_status == current_status:
            return None

        prev_idx = self._STATUS_ORDER.index(prev_status) if prev_status in self._STATUS_ORDER else -1
        curr_idx = self._STATUS_ORDER.index(current_status) if current_status in self._STATUS_ORDER else -1

        if prev_idx < 0 or curr_idx < 0:
            return None

        # Downward crossing: current is worse (higher index)
        if curr_idx > prev_idx:
            # Find the specific boundary crossed
            for i in range(prev_idx, curr_idx):
                key = (self._STATUS_ORDER[i], self._STATUS_ORDER[i + 1])
                if key in self.PENALTIES:
                    return key
        return None

    def process(
        self,
        agent_id: str,
        current_score: UnifiedAgentHealthScore,
        prev_score: UnifiedAgentHealthScore | None,
        ambiguity_observer: AmbiguityDriftObserver,
        trust_calibrator: TrustCalibrator | None = None,
        confidence: float = 1.0,
        floor_low: float = 0.30,
        floor_high: float = 0.70,
    ) -> list[dict[str, Any]]:
        """Detect status boundary crossings and apply trust adjustments.

        Args:
            agent_id: The agent being evaluated.
            current_score: Current UAHS.
            prev_score: Previous UAHS (None if first computation).
            ambiguity_observer: For band adjustments.
            trust_calibrator: For trust penalty/recovery application.
            confidence: Confidence multiplier for penalties.
            floor_low: Archetype floor for band_low.
            floor_high: Archetype floor for band_high.

        Returns:
            List of audit event dicts.
        """
        events: list[dict[str, Any]] = []
        now = _time.time()

        if prev_score is None:
            return events

        # Detect downward crossing
        crossing = self._detect_crossing(
            prev_score.health_status, current_score.health_status
        )

        if crossing is not None:
            # Emit crossing event
            events.append({
                "event_type": AUDIT_STATUS_BOUNDARY_CROSSED,
                "agent_id": agent_id,
                "timestamp": now,
                "prev_status": prev_score.health_status,
                "current_status": current_score.health_status,
                "prev_score": prev_score.unified_score,
                "current_score": current_score.unified_score,
                "crossing": f"{crossing[0]}->{crossing[1]}",
                "uahs_delta": current_score.unified_score - prev_score.unified_score,
                "primary_signal": current_score.primary_signal,
                "alarm_active": current_score.ambiguity_weight == 0.45,
            })

            # Apply trust penalty
            penalty = self.PENALTIES.get(crossing, 0.0)
            if penalty != 0.0 and trust_calibrator is not None:
                adjusted_penalty = penalty * confidence
                profile = trust_calibrator.get_profile(agent_id)
                old_trust = profile.overall_trust
                profile.overall_trust = max(
                    trust_calibrator.config.min_trust,
                    profile.overall_trust + adjusted_penalty,
                )
                events.append({
                    "event_type": AUDIT_TRUST_CALIBRATION_APPLIED,
                    "agent_id": agent_id,
                    "timestamp": now,
                    "adjustment": adjusted_penalty,
                    "trust_before": old_trust,
                    "trust_after": profile.overall_trust,
                    "reason": f"UAHS crossing {crossing[0]}->{crossing[1]}",
                    "uahs_at_trigger": current_score.unified_score,
                    "adjustment_type": "penalty",
                    "confidence_scaled": True,
                })

            # Apply band narrowing
            narrowing = self.BAND_NARROWING.get(crossing, 0.0)
            if narrowing > 0.0:
                amb_profile = ambiguity_observer.get_profile(agent_id)
                if amb_profile is not None:
                    prior_band_low = amb_profile.band_low
                    prior_band_high = amb_profile.band_high
                    requested_low = amb_profile.band_low + narrowing
                    requested_high = amb_profile.band_high - narrowing
                    ambiguity_observer.adjust_band(
                        agent_id, requested_low, requested_high, floor_low, floor_high
                    )
                    updated = ambiguity_observer.get_profile(agent_id)
                    floor_applied = (
                        updated is not None
                        and (updated.band_low != requested_low or updated.band_high != requested_high)
                    )
                    events.append({
                        "event_type": AUDIT_BAND_WIDTH_MODIFIED,
                        "agent_id": agent_id,
                        "timestamp": now,
                        "direction": "narrowed",
                        "narrowing_amount": narrowing,
                        "new_band_low": updated.band_low if updated else requested_low,
                        "new_band_high": updated.band_high if updated else requested_high,
                        "reason": f"UAHS crossing {crossing[0]}->{crossing[1]}",
                        "uahs_at_modification": current_score.unified_score,
                        "prior_band_low": prior_band_low,
                        "prior_band_high": prior_band_high,
                        "floor_constraint_applied": floor_applied,
                    })

        # Check for recovery: score improved >= 10 points
        score_diff = current_score.unified_score - prev_score.unified_score
        if score_diff >= 10:
            # Recovery credit
            if trust_calibrator is not None:
                profile = trust_calibrator.get_profile(agent_id)
                old_trust = profile.overall_trust
                profile.overall_trust = min(
                    trust_calibrator.config.max_trust,
                    profile.overall_trust + self.RECOVERY_CREDIT,
                )
                events.append({
                    "event_type": AUDIT_TRUST_CALIBRATION_APPLIED,
                    "agent_id": agent_id,
                    "timestamp": now,
                    "adjustment": self.RECOVERY_CREDIT,
                    "trust_before": old_trust,
                    "trust_after": profile.overall_trust,
                    "reason": f"UAHS recovery (+{score_diff} points)",
                    "uahs_at_trigger": current_score.unified_score,
                    "adjustment_type": "recovery",
                    "confidence_scaled": False,
                })

            # Band recovery (widening)
            amb_profile = ambiguity_observer.get_profile(agent_id)
            if amb_profile is not None:
                prior_band_low = amb_profile.band_low
                prior_band_high = amb_profile.band_high
                requested_low = amb_profile.band_low - self.BAND_RECOVERY
                requested_high = amb_profile.band_high + self.BAND_RECOVERY
                ambiguity_observer.adjust_band(
                    agent_id, requested_low, requested_high, floor_low, floor_high
                )
                updated = ambiguity_observer.get_profile(agent_id)
                floor_applied = (
                    updated is not None
                    and (updated.band_low != requested_low or updated.band_high != requested_high)
                )
                events.append({
                    "event_type": AUDIT_BAND_WIDTH_MODIFIED,
                    "agent_id": agent_id,
                    "timestamp": now,
                    "direction": "widened",
                    "recovery_amount": self.BAND_RECOVERY,
                    "new_band_low": updated.band_low if updated else requested_low,
                    "new_band_high": updated.band_high if updated else requested_high,
                    "reason": f"UAHS recovery (+{score_diff} points)",
                    "uahs_at_modification": current_score.unified_score,
                    "prior_band_low": prior_band_low,
                    "prior_band_high": prior_band_high,
                    "floor_constraint_applied": floor_applied,
                })

        return events


# ── Persistence helper ─────────────────────────────────────────────────


def persist_health_events(
    events: list[dict[str, Any]],
    store: GovernanceHealthStore,
    current_uahs: UnifiedAgentHealthScore | None = None,
    prev_uahs: UnifiedAgentHealthScore | None = None,
) -> None:
    """Route FeedbackLoopManager audit event dicts into GovernanceHealthStore.

    Converts raw event dicts to GovernanceHealthRecord with appropriate
    uahs_before, uahs_after, and uahs_delta fields, then appends to store.

    Args:
        events: List of event dicts from FeedbackLoopManager.process() or
                AmbiguityDriftObserver.get_alarm_event().
        store: GovernanceHealthStore to append to.
        current_uahs: Current score (for uahs_after).
        prev_uahs: Previous score (for uahs_before).
    """
    import uuid  # noqa: PLC0415

    from nomotic.audit_store import GovernanceHealthRecord  # noqa: PLC0415

    severity_map = {
        AUDIT_UAHS_COMPUTED: "info",
        AUDIT_STATUS_BOUNDARY_CROSSED: "alert",
        AUDIT_TRUST_CALIBRATION_APPLIED: "warning",
        AUDIT_BAND_WIDTH_MODIFIED: "warning",
        AUDIT_ALARM_DETECTED: "alert",
        AUDIT_AMBIGUITY_PROFILE_UPDATE: "info",
    }

    for event in events:
        event_type = event.get("event_type", "unknown")
        rec = GovernanceHealthRecord(
            record_id=str(uuid.uuid4()),
            timestamp=event.get("timestamp", 0.0),
            agent_id=event.get("agent_id", ""),
            event_type=event_type,
            severity=severity_map.get(event_type, "info"),
            uahs_before=prev_uahs.unified_score if prev_uahs else None,
            uahs_after=current_uahs.unified_score if current_uahs else None,
            uahs_delta=(
                current_uahs.unified_score - prev_uahs.unified_score
                if current_uahs and prev_uahs
                else None
            ),
            data=event,
        )
        store.append_health_event(rec)
