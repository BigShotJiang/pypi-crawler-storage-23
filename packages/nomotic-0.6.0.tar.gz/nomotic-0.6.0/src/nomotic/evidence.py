"""Compliance Evidence Bundle — self-contained, independently verifiable
audit packages for regulatory and compliance purposes.

An evidence bundle aggregates governance audit records, agent identity,
trust trajectory, behavioral fingerprints, drift history, and configuration
provenance into a single JSON document with explicit compliance framework
mappings (SOC2, HIPAA, PCI-DSS, ISO 27001).

The bundle is hash-sealed: a SHA-256 digest covers the entire serialized
content, enabling independent tamper detection without access to the
originating system.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from nomotic.audit import AuditRecord, AuditTrail, verify_chain

__all__ = [
    "ControlMapping",
    "EvidenceBundle",
    "EvidenceBundleGenerator",
    "HIPAA_MAPPINGS",
    "ISO27001_MAPPINGS",
    "PCI_DSS_MAPPINGS",
    "SOC2_MAPPINGS",
]


# ── Compliance Mappings ──────────────────────────────────────────────────


@dataclass(frozen=True)
class ControlMapping:
    """Maps a compliance framework control to Nomotic governance evidence.

    Each mapping identifies which Nomotic features provide evidence for
    a specific regulatory control requirement.
    """

    framework: str  # "SOC2", "HIPAA", "PCI-DSS", "ISO27001"
    control_id: str  # "CC6.1", "164.312(a)(1)", "Req 8.3"
    control_name: str  # Human-readable name
    description: str  # What this control requires
    nomotic_evidence: list[str] = field(default_factory=list)
    # Which Nomotic features provide evidence, e.g.:
    # ["audit_trail", "trust_calibration", "scope_compliance"]

    def to_dict(self) -> dict[str, Any]:
        return {
            "framework": self.framework,
            "control_id": self.control_id,
            "control_name": self.control_name,
            "description": self.description,
            "nomotic_evidence": list(self.nomotic_evidence),
        }


# ── SOC 2 Mappings ──────────────────────────────────────────────────────

SOC2_MAPPINGS: list[ControlMapping] = [
    ControlMapping(
        framework="SOC2",
        control_id="CC6.1",
        control_name="Logical Access Security",
        description=(
            "The entity implements logical access security software, "
            "infrastructure, and architectures over protected information "
            "assets to protect them from security events."
        ),
        nomotic_evidence=[
            "scope_compliance",
            "authority_verification",
            "certificates",
            "audit_trail",
        ],
    ),
    ControlMapping(
        framework="SOC2",
        control_id="CC6.3",
        control_name="Role-Based Access Controls",
        description=(
            "The entity authorizes, modifies, or removes access to data, "
            "software, functions, and other protected information assets "
            "based on roles, responsibilities, or the system design and changes."
        ),
        nomotic_evidence=[
            "scope_compliance",
            "config_provenance",
            "delegation_chains",
            "certificates",
        ],
    ),
    ControlMapping(
        framework="SOC2",
        control_id="CC7.2",
        control_name="System Monitoring",
        description=(
            "The entity monitors system components and the operation of "
            "those components for anomalies that are indicative of malicious "
            "acts, natural disasters, and errors affecting the entity's "
            "ability to meet its objectives."
        ),
        nomotic_evidence=[
            "behavioral_fingerprints",
            "drift_detection",
            "audit_trail",
            "trust_calibration",
        ],
    ),
    ControlMapping(
        framework="SOC2",
        control_id="CC7.4",
        control_name="Incident Response",
        description=(
            "The entity responds to identified security incidents by "
            "executing a defined incident response program to understand, "
            "contain, remediate, and communicate security incidents."
        ),
        nomotic_evidence=[
            "interrupt_authority",
            "incident_detection",
            "drift_alerts",
            "audit_trail",
        ],
    ),
    ControlMapping(
        framework="SOC2",
        control_id="CC8.1",
        control_name="Change Management",
        description=(
            "The entity authorizes, designs, develops or acquires, "
            "configures, documents, tests, approves, and implements "
            "changes to infrastructure, data, software, and procedures "
            "to meet its objectives."
        ),
        nomotic_evidence=[
            "config_provenance",
            "governed_adaptation",
            "audit_trail",
            "certificates",
        ],
    ),
]

# ── HIPAA Mappings ───────────────────────────────────────────────────────

HIPAA_MAPPINGS: list[ControlMapping] = [
    ControlMapping(
        framework="HIPAA",
        control_id="164.312(a)(1)",
        control_name="Access Control",
        description=(
            "Implement technical policies and procedures for electronic "
            "information systems that maintain electronic protected health "
            "information to allow access only to those persons or software "
            "programs that have been granted access rights."
        ),
        nomotic_evidence=[
            "scope_compliance",
            "authority_verification",
            "certificates",
            "trust_calibration",
        ],
    ),
    ControlMapping(
        framework="HIPAA",
        control_id="164.312(b)",
        control_name="Audit Controls",
        description=(
            "Implement hardware, software, and/or procedural mechanisms "
            "that record and examine activity in information systems that "
            "contain or use electronic protected health information."
        ),
        nomotic_evidence=[
            "audit_trail",
            "hash_chain_verification",
            "config_provenance",
        ],
    ),
    ControlMapping(
        framework="HIPAA",
        control_id="164.312(c)(1)",
        control_name="Integrity",
        description=(
            "Implement policies and procedures to protect electronic "
            "protected health information from improper alteration or "
            "destruction."
        ),
        nomotic_evidence=[
            "hash_chain_verification",
            "tamper_detection",
            "audit_trail",
        ],
    ),
    ControlMapping(
        framework="HIPAA",
        control_id="164.312(d)",
        control_name="Person or Entity Authentication",
        description=(
            "Implement procedures to verify that a person or entity "
            "seeking access to electronic protected health information "
            "is the one claimed."
        ),
        nomotic_evidence=[
            "certificates",
            "identity_verification",
            "cryptographic_signing",
        ],
    ),
]

# ── PCI-DSS Mappings ────────────────────────────────────────────────────

PCI_DSS_MAPPINGS: list[ControlMapping] = [
    ControlMapping(
        framework="PCI-DSS",
        control_id="Req 7.1",
        control_name="Restrict Access by Business Need",
        description=(
            "Limit access to system components and cardholder data to "
            "only those individuals whose job requires such access."
        ),
        nomotic_evidence=[
            "scope_compliance",
            "trust_calibration",
            "certificates",
        ],
    ),
    ControlMapping(
        framework="PCI-DSS",
        control_id="Req 8.3",
        control_name="Strong Authentication",
        description=(
            "Secure all individual non-console administrative access and "
            "all remote access to the CDE using multi-factor authentication."
        ),
        nomotic_evidence=[
            "certificates",
            "cryptographic_identity",
            "authority_verification",
        ],
    ),
    ControlMapping(
        framework="PCI-DSS",
        control_id="Req 10.1",
        control_name="Audit Trails",
        description=(
            "Implement audit trails to link all access to system "
            "components to each individual user."
        ),
        nomotic_evidence=[
            "audit_trail",
            "hash_chain_verification",
            "config_provenance",
        ],
    ),
    ControlMapping(
        framework="PCI-DSS",
        control_id="Req 10.5",
        control_name="Audit Trail Tamper Protection",
        description=(
            "Secure audit trails so they cannot be altered."
        ),
        nomotic_evidence=[
            "hash_chain_verification",
            "tamper_detection",
            "verify_chain",
        ],
    ),
]

# ── ISO 27001 Mappings ──────────────────────────────────────────────────

ISO27001_MAPPINGS: list[ControlMapping] = [
    ControlMapping(
        framework="ISO27001",
        control_id="A.9.1",
        control_name="Access Control Policy",
        description=(
            "An access control policy shall be established, documented "
            "and reviewed based on business and information security "
            "requirements."
        ),
        nomotic_evidence=[
            "scope_compliance",
            "config_provenance",
            "certificates",
            "authority_verification",
        ],
    ),
    ControlMapping(
        framework="ISO27001",
        control_id="A.9.2",
        control_name="User Access Management",
        description=(
            "Formal user access provisioning process shall be implemented "
            "to assign or revoke access rights for all user types to all "
            "systems and services."
        ),
        nomotic_evidence=[
            "certificates",
            "trust_calibration",
            "scope_compliance",
        ],
    ),
    ControlMapping(
        framework="ISO27001",
        control_id="A.12.4",
        control_name="Logging and Monitoring",
        description=(
            "Event logs recording user activities, exceptions, faults and "
            "information security events shall be produced, kept and "
            "regularly reviewed."
        ),
        nomotic_evidence=[
            "audit_trail",
            "hash_chain_verification",
            "drift_detection",
            "behavioral_fingerprints",
        ],
    ),
    ControlMapping(
        framework="ISO27001",
        control_id="A.12.6",
        control_name="Technical Vulnerability Management",
        description=(
            "Information about technical vulnerabilities of information "
            "systems being used shall be obtained in a timely fashion, "
            "the organization's exposure to such vulnerabilities evaluated "
            "and appropriate measures taken to address the associated risk."
        ),
        nomotic_evidence=[
            "drift_detection",
            "incident_detection",
            "trust_calibration",
            "interrupt_authority",
        ],
    ),
]

# Framework registry for easy lookup
_FRAMEWORK_MAPPINGS: dict[str, list[ControlMapping]] = {
    "SOC2": SOC2_MAPPINGS,
    "HIPAA": HIPAA_MAPPINGS,
    "PCI-DSS": PCI_DSS_MAPPINGS,
    "ISO27001": ISO27001_MAPPINGS,
}

SUPPORTED_FRAMEWORKS = list(_FRAMEWORK_MAPPINGS.keys())


def get_mappings_for_frameworks(
    frameworks: list[str] | None = None,
) -> list[ControlMapping]:
    """Return control mappings for the requested frameworks.

    If *frameworks* is ``None``, returns mappings for all frameworks.
    """
    if frameworks is None:
        frameworks = SUPPORTED_FRAMEWORKS
    result: list[ControlMapping] = []
    for fw in frameworks:
        fw_upper = fw.upper()
        # Normalize common variants
        if fw_upper in ("PCI", "PCIDSS", "PCI_DSS"):
            fw_upper = "PCI-DSS"
        mappings = _FRAMEWORK_MAPPINGS.get(fw_upper, [])
        result.extend(mappings)
    return result


# ── Evidence Bundle ──────────────────────────────────────────────────────


@dataclass
class EvidenceBundle:
    """A self-contained compliance evidence package.

    Contains everything an auditor needs to verify governance decisions:
    audit records, agent identity, trust trajectory, behavioral profile,
    drift history, configuration provenance, and explicit compliance
    framework mappings.

    The bundle is hash-sealed for independent tamper detection.
    """

    # Metadata
    bundle_id: str = ""
    bundle_version: str = "1.0.0"
    created_at: str = ""  # ISO 8601
    created_by: str = "system"

    # Scope
    agent_id: str | None = None  # None = all agents
    time_range: tuple[float, float] = (0.0, 0.0)
    frameworks: list[str] = field(default_factory=list)

    # Governance Configuration Snapshot
    governance_config: dict[str, Any] = field(default_factory=dict)
    config_provenance: list[dict[str, Any]] = field(default_factory=list)

    # Agent Identity
    agent_certificate: dict[str, Any] | None = None
    agent_trust_trajectory: list[dict[str, Any]] = field(default_factory=list)

    # Behavioral Profile
    behavioral_fingerprint: dict[str, Any] | None = None
    drift_history: list[dict[str, Any]] = field(default_factory=list)

    # The Audit Records
    audit_records: list[dict[str, Any]] = field(default_factory=list)
    record_count: int = 0
    chain_verification: dict[str, Any] = field(default_factory=dict)

    # Compliance Mappings
    compliance_evidence: list[dict[str, Any]] = field(default_factory=list)

    # Bundle Integrity
    bundle_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-friendly dict."""
        return {
            "bundle_id": self.bundle_id,
            "bundle_version": self.bundle_version,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "agent_id": self.agent_id,
            "time_range": list(self.time_range),
            "frameworks": self.frameworks,
            "governance_config": self.governance_config,
            "config_provenance": self.config_provenance,
            "agent_certificate": self.agent_certificate,
            "agent_trust_trajectory": self.agent_trust_trajectory,
            "behavioral_fingerprint": self.behavioral_fingerprint,
            "drift_history": self.drift_history,
            "audit_records": self.audit_records,
            "record_count": self.record_count,
            "chain_verification": self.chain_verification,
            "compliance_evidence": self.compliance_evidence,
            "bundle_hash": self.bundle_hash,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> EvidenceBundle:
        """Deserialize from dict."""
        time_range_raw = d.get("time_range", [0.0, 0.0])
        return cls(
            bundle_id=d.get("bundle_id", ""),
            bundle_version=d.get("bundle_version", "1.0.0"),
            created_at=d.get("created_at", ""),
            created_by=d.get("created_by", "system"),
            agent_id=d.get("agent_id"),
            time_range=(time_range_raw[0], time_range_raw[1]),
            frameworks=d.get("frameworks", []),
            governance_config=d.get("governance_config", {}),
            config_provenance=d.get("config_provenance", []),
            agent_certificate=d.get("agent_certificate"),
            agent_trust_trajectory=d.get("agent_trust_trajectory", []),
            behavioral_fingerprint=d.get("behavioral_fingerprint"),
            drift_history=d.get("drift_history", []),
            audit_records=d.get("audit_records", []),
            record_count=d.get("record_count", 0),
            chain_verification=d.get("chain_verification", {}),
            compliance_evidence=d.get("compliance_evidence", []),
            bundle_hash=d.get("bundle_hash", ""),
        )


# ── Evidence Bundle Generator ────────────────────────────────────────────


def _compute_bundle_hash(bundle_dict: dict[str, Any]) -> str:
    """Compute SHA-256 hash of the bundle, excluding the bundle_hash field."""
    d = dict(bundle_dict)
    d.pop("bundle_hash", None)
    canonical = json.dumps(d, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class EvidenceBundleGenerator:
    """Generates compliance evidence bundles from governance components.

    Can be initialized with a :class:`GovernanceRuntime` (which provides
    access to all components), or with individual components directly.
    """

    def __init__(
        self,
        runtime: Any | None = None,
        *,
        audit_trail: AuditTrail | None = None,
        trust_manager: Any | None = None,
        provenance_log: Any | None = None,
    ) -> None:
        self._runtime = runtime
        self._audit_trail = audit_trail
        self._trust_manager = trust_manager
        self._provenance_log = provenance_log

    def _get_audit_trail(self) -> AuditTrail | None:
        if self._audit_trail is not None:
            return self._audit_trail
        if self._runtime is not None:
            return getattr(self._runtime, "audit_trail", None)
        return None

    def _get_trust_manager(self) -> Any | None:
        if self._trust_manager is not None:
            return self._trust_manager
        if self._runtime is not None:
            return getattr(self._runtime, "trust_calibrator", None)
        return None

    def _get_provenance_log(self) -> Any | None:
        if self._provenance_log is not None:
            return self._provenance_log
        if self._runtime is not None:
            return getattr(self._runtime, "provenance_log", None)
        return None

    def generate(
        self,
        agent_id: str | None = None,
        since: float | None = None,
        until: float | None = None,
        frameworks: list[str] | None = None,
        created_by: str = "system",
        include_fingerprint: bool = True,
        sanitizer: Any | None = None,
    ) -> EvidenceBundle:
        """Generate a compliance evidence bundle.

        Args:
            agent_id: Filter to a specific agent. ``None`` includes all.
            since: Start of time range (epoch). ``None`` = no lower bound.
            until: End of time range (epoch). ``None`` = now.
            frameworks: Compliance frameworks to map (e.g. ``["SOC2", "HIPAA"]``).
                ``None`` maps all supported frameworks.
            created_by: Identity of who generated this bundle.
            include_fingerprint: Include behavioral fingerprint snapshot.
            sanitizer: Optional :class:`Sanitizer` to scrub sensitive data.

        Returns:
            A populated :class:`EvidenceBundle` with hash seal.
        """
        now = time.time()
        if until is None:
            until = now

        bundle = EvidenceBundle(
            bundle_id=f"evb-{uuid.uuid4().hex[:16]}",
            created_at=datetime.fromtimestamp(now, tz=timezone.utc).isoformat(),
            created_by=created_by,
            agent_id=agent_id,
            time_range=(since if since is not None else 0.0, until),
            frameworks=frameworks if frameworks is not None else list(SUPPORTED_FRAMEWORKS),
        )

        # Collect audit records
        self._collect_audit_records(bundle, agent_id, since, until)

        # Collect trust trajectory
        self._collect_trust_trajectory(bundle, agent_id)

        # Collect behavioral fingerprint
        if include_fingerprint:
            self._collect_fingerprint(bundle, agent_id)

        # Collect drift history
        self._collect_drift_history(bundle, agent_id)

        # Collect configuration provenance
        self._collect_provenance(bundle, since, until)

        # Collect governance config snapshot
        self._collect_governance_config(bundle)

        # Collect agent certificate
        self._collect_certificate(bundle, agent_id)

        # Build compliance mappings
        bundle.compliance_evidence = [
            m.to_dict() for m in get_mappings_for_frameworks(frameworks)
        ]

        # Apply sanitization if requested
        if sanitizer is not None:
            self._sanitize_bundle(bundle, sanitizer)

        # Seal the bundle
        bundle_dict = bundle.to_dict()
        bundle.bundle_hash = _compute_bundle_hash(bundle_dict)

        return bundle

    def _collect_audit_records(
        self,
        bundle: EvidenceBundle,
        agent_id: str | None,
        since: float | None,
        until: float | None,
    ) -> None:
        trail = self._get_audit_trail()
        if trail is None:
            bundle.audit_records = []
            bundle.record_count = 0
            bundle.chain_verification = {
                "valid": True,
                "message": "No audit trail available",
                "records_verified": 0,
            }
            return

        # Query records — get them in chronological order for chain verification
        query_kwargs: dict[str, Any] = {
            "limit": trail._max_records,
        }
        if agent_id is not None:
            query_kwargs["agent_id"] = agent_id
        if since is not None:
            query_kwargs["since"] = since
        if until is not None:
            query_kwargs["until"] = until

        records = trail.query(**query_kwargs)
        # query returns newest-first; reverse for chronological order
        records.reverse()

        bundle.audit_records = [r.to_dict() for r in records]
        bundle.record_count = len(records)

        # Verify hash chain
        valid, message = verify_chain(records)
        bundle.chain_verification = {
            "valid": valid,
            "message": message,
            "records_verified": len(records),
        }

    def _collect_trust_trajectory(
        self,
        bundle: EvidenceBundle,
        agent_id: str | None,
    ) -> None:
        trust_mgr = self._get_trust_manager()
        if trust_mgr is None:
            return

        if agent_id is not None:
            trajectory = getattr(trust_mgr, "get_trajectory", None)
            if trajectory is not None:
                traj = trajectory(agent_id)
                if hasattr(traj, "events"):
                    bundle.agent_trust_trajectory = [
                        e.to_dict() for e in traj.events
                    ]

    def _collect_fingerprint(
        self,
        bundle: EvidenceBundle,
        agent_id: str | None,
    ) -> None:
        if self._runtime is None or agent_id is None:
            return
        observer = getattr(self._runtime, "_observer", None)
        if observer is None:
            return
        fp = getattr(observer, "get_fingerprint", lambda _: None)(agent_id)
        if fp is not None:
            bundle.behavioral_fingerprint = fp.to_dict()

    def _collect_drift_history(
        self,
        bundle: EvidenceBundle,
        agent_id: str | None,
    ) -> None:
        if self._runtime is None:
            return
        monitor = getattr(self._runtime, "_drift_monitor", None)
        if monitor is None:
            return
        alerts = getattr(monitor, "get_alerts", lambda: [])(agent_id)
        if alerts:
            bundle.drift_history = [
                a.to_dict() if hasattr(a, "to_dict") else {"alert": str(a)}
                for a in alerts
            ]

    def _collect_provenance(
        self,
        bundle: EvidenceBundle,
        since: float | None,
        until: float | None,
    ) -> None:
        prov_log = self._get_provenance_log()
        if prov_log is None:
            return
        query_kwargs: dict[str, Any] = {"limit": 5000}
        if since is not None:
            query_kwargs["since"] = since
        if until is not None:
            query_kwargs["until"] = until
        records = prov_log.query(**query_kwargs)
        bundle.config_provenance = [r.to_dict() for r in records]

    def _collect_governance_config(self, bundle: EvidenceBundle) -> None:
        if self._runtime is None:
            return
        config = getattr(self._runtime, "config", None)
        if config is None:
            return
        # Serialize config fields that are relevant to governance
        bundle.governance_config = {
            "allow_threshold": getattr(config, "allow_threshold", None),
            "deny_threshold": getattr(config, "deny_threshold", None),
            "trust_influence": getattr(config, "trust_influence", None),
            "enable_fingerprints": getattr(config, "enable_fingerprints", None),
            "enable_audit": getattr(config, "enable_audit", None),
        }

    def _collect_certificate(
        self,
        bundle: EvidenceBundle,
        agent_id: str | None,
    ) -> None:
        if self._runtime is None or agent_id is None:
            return
        certs = getattr(self._runtime, "_certificates", None)
        if certs is None:
            return
        cert = certs.get(agent_id)
        if cert is not None and hasattr(cert, "to_dict"):
            bundle.agent_certificate = cert.to_dict()

    def _sanitize_bundle(
        self,
        bundle: EvidenceBundle,
        sanitizer: Any,
    ) -> None:
        """Apply sanitizer to scrub sensitive data from the bundle."""
        if not hasattr(sanitizer, "sanitize_dict"):
            return
        # Sanitize audit records
        bundle.audit_records = [
            sanitizer.sanitize_dict(r) for r in bundle.audit_records
        ]
        # Sanitize provenance
        bundle.config_provenance = [
            sanitizer.sanitize_dict(r) for r in bundle.config_provenance
        ]
        # Sanitize certificate
        if bundle.agent_certificate is not None:
            bundle.agent_certificate = sanitizer.sanitize_dict(
                bundle.agent_certificate
            )
        # Sanitize fingerprint
        if bundle.behavioral_fingerprint is not None:
            bundle.behavioral_fingerprint = sanitizer.sanitize_dict(
                bundle.behavioral_fingerprint
            )

    def to_json(self, bundle: EvidenceBundle) -> str:
        """Serialize an evidence bundle to JSON."""
        return json.dumps(bundle.to_dict(), indent=2, sort_keys=False)

    def to_dict(self, bundle: EvidenceBundle) -> dict[str, Any]:
        """Serialize an evidence bundle to a dict."""
        return bundle.to_dict()

    def verify_bundle(self, bundle_data: dict[str, Any]) -> tuple[bool, str]:
        """Independently verify a bundle's integrity.

        Checks:
        1. Bundle hash matches recomputed hash.
        2. Audit chain integrity (if records present).
        3. Record count matches actual records.

        Returns:
            ``(valid, message)`` — ``valid`` is ``True`` if all checks pass.
        """
        # 1. Verify bundle hash
        stored_hash = bundle_data.get("bundle_hash", "")
        if not stored_hash:
            return False, "Bundle has no hash seal"

        computed_hash = _compute_bundle_hash(bundle_data)
        if computed_hash != stored_hash:
            return False, (
                f"Bundle hash mismatch: expected {computed_hash[:16]}..., "
                f"got {stored_hash[:16]}..."
            )

        # 2. Verify record count
        audit_records = bundle_data.get("audit_records", [])
        record_count = bundle_data.get("record_count", 0)
        if len(audit_records) != record_count:
            return False, (
                f"Record count mismatch: declared {record_count}, "
                f"actual {len(audit_records)}"
            )

        # 3. Verify audit chain integrity
        if audit_records:
            records = [AuditRecord.from_dict(r) for r in audit_records]
            chain_valid, chain_msg = verify_chain(records)
            if not chain_valid:
                return False, f"Audit chain verification failed: {chain_msg}"

        return True, "Bundle integrity verified"
