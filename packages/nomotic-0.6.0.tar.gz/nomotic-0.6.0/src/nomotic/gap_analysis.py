"""Compliance Gap Analysis — compares framework controls to real audit scores.

Gap analysis closes the loop between compliance *mapping* (which controls does
Nomotic address?) and compliance *reality* (do agents actually score well on
the dimensions those controls require?).

For each control in a framework:
1. Identify the mapped nomotic_dimensions
2. Query audit records for actual dimension scores
3. Compute average score per dimension
4. Average across all mapped dimensions for the control
5. Compare to gap_threshold; classify severity
6. Generate actionable recommendation

A GDPR Art5 control mapped to ``ethical_alignment`` with an average score
of 0.24 is not just a coverage gap — it is a live compliance risk.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Any

from nomotic.compliance_report import FRAMEWORK_MAPPINGS, FrameworkMapping

__all__ = [
    "ComplianceGapAnalyzer",
    "ComplianceGapReport",
    "ControlGap",
]


# ── Data Structures ────────────────────────────────────────────────────


@dataclass
class ControlGap:
    """A compliance control with real-world coverage analysis."""

    framework_id: str
    control_id: str
    control_description: str
    nomotic_dimensions: list[str]
    coverage: str  # "full", "partial", "indirect", "none"
    average_dimension_score: float  # Weighted avg of mapped dimensions
    score_threshold: float  # Below this = gap
    is_gap: bool  # True if average_score < threshold
    gap_severity: str  # "low", "medium", "high", "critical"
    sample_size: int  # Audit records analyzed
    recommendation: str  # Actionable suggestion

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ComplianceGapReport:
    """Full gap analysis report for a compliance framework."""

    framework_id: str
    framework_name: str
    generated_at: float
    period_days: int
    agent_id: str | None  # None = fleet-wide
    gap_threshold: float
    total_controls: int
    controls_with_gaps: int
    coverage_percent: float  # % of controls meeting threshold
    critical_gaps: list[ControlGap] = field(default_factory=list)
    high_gaps: list[ControlGap] = field(default_factory=list)
    medium_gaps: list[ControlGap] = field(default_factory=list)
    low_gaps: list[ControlGap] = field(default_factory=list)
    clean_controls: list[ControlGap] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "framework_id": self.framework_id,
            "framework_name": self.framework_name,
            "generated_at": self.generated_at,
            "period_days": self.period_days,
            "agent_id": self.agent_id,
            "gap_threshold": self.gap_threshold,
            "total_controls": self.total_controls,
            "controls_with_gaps": self.controls_with_gaps,
            "coverage_percent": self.coverage_percent,
            "critical_gaps": [g.to_dict() for g in self.critical_gaps],
            "high_gaps": [g.to_dict() for g in self.high_gaps],
            "medium_gaps": [g.to_dict() for g in self.medium_gaps],
            "low_gaps": [g.to_dict() for g in self.low_gaps],
            "clean_controls": [g.to_dict() for g in self.clean_controls],
        }

    def summary(self) -> str:
        """One-paragraph human-readable summary."""
        scope = self.agent_id or "fleet-wide"
        parts = []
        if self.critical_gaps:
            parts.append(f"{len(self.critical_gaps)} critical")
        if self.high_gaps:
            parts.append(f"{len(self.high_gaps)} high")
        if self.medium_gaps:
            parts.append(f"{len(self.medium_gaps)} medium")
        if self.low_gaps:
            parts.append(f"{len(self.low_gaps)} low")

        if not parts:
            return (
                f"{self.framework_name} gap analysis ({scope}, "
                f"{self.period_days} days): All {self.total_controls} controls "
                f"meet the {self.gap_threshold:.0%} threshold. No gaps detected."
            )

        gap_desc = ", ".join(parts)
        return (
            f"{self.framework_name} gap analysis ({scope}, "
            f"{self.period_days} days): {self.controls_with_gaps} of "
            f"{self.total_controls} controls have gaps ({gap_desc}). "
            f"{self.coverage_percent:.0f}% adequate coverage."
        )


# ── Analyzer ───────────────────────────────────────────────────────────


class ComplianceGapAnalyzer:
    """Analyzes compliance gaps by comparing framework controls to audit scores.

    For each control in a framework:
    1. Identify the mapped nomotic_dimensions
    2. Query audit records for actual dimension scores
    3. Compute average score per dimension
    4. Average across all mapped dimensions for the control
    5. Compare to gap_threshold; classify severity
    6. Generate actionable recommendation
    """

    # Per-dimension recommendations
    _RECOMMENDATIONS: dict[str, str] = {
        "scope_compliance": (
            "Review agent permission scopes. High denial rates suggest "
            "overly broad permissions or misconfigured agents."
        ),
        "authority_verification": (
            "Verify delegation chains and authority certificates. "
            "Consider adding explicit authority grants."
        ),
        "resource_boundaries": (
            "Configure explicit resource limits in RuntimeConfig. "
            "Add rate/concurrency/cost boundaries."
        ),
        "behavioral_consistency": (
            "Review agent behavioral fingerprints. Low scores indicate "
            "agents acting outside established patterns."
        ),
        "cascading_impact": (
            "Audit high-impact actions for downstream consequence analysis. "
            "Consider adding human review for cascading operations."
        ),
        "stakeholder_impact": (
            "Assess stakeholder impact configuration for sensitive data. "
            "Enable population weighting for affected users."
        ),
        "incident_detection": (
            "Review incident detection patterns. Update anomaly signatures "
            "for current threat landscape."
        ),
        "isolation_integrity": (
            "Audit cross-boundary access patterns. Enforce strict "
            "isolation policies for sensitive data zones."
        ),
        "temporal_compliance": (
            "Review rate limit configurations and maintenance windows. "
            "Enforce timing constraints for regulated operations."
        ),
        "precedent_alignment": (
            "Review governance precedents for consistency. Consider "
            "explicit precedent policies for common action types."
        ),
        "transparency": (
            "Improve action attribution and reasoning documentation. "
            "Require explicit principal identification for all actions."
        ),
        "human_override": (
            "Configure human-in-the-loop requirements for high-risk actions. "
            "Review override authority registry."
        ),
        "ethical_alignment": (
            "Increase ethical_alignment weight or enable veto mode in "
            "presets. Review ethical reasoning configuration."
        ),
        "jurisdictional_compliance": (
            "Configure JurisdictionalContext for agents handling regulated "
            "data. Verify legal basis and transfer mechanisms."
        ),
    }

    def __init__(
        self,
        report_generator: Any,  # ComplianceReportGenerator
        audit_store: Any,  # LogStore
    ) -> None:
        self._generator = report_generator
        self._audit_store = audit_store

    def analyze(
        self,
        framework_id: str,
        agent_id: str | None = None,
        days: int = 30,
        gap_threshold: float = 0.7,
    ) -> ComplianceGapReport:
        """Run gap analysis for a framework.

        Returns ComplianceGapReport with all controls analyzed.

        Raises:
            ValueError: If the framework ID is not recognized.
        """
        # Resolve the framework mapping (custom first, then built-in)
        mapping: FrameworkMapping | None = None
        if hasattr(self._generator, "_custom_frameworks"):
            mapping = self._generator._custom_frameworks.get(framework_id)
        if mapping is None:
            mapping = FRAMEWORK_MAPPINGS.get(framework_id)
        if mapping is None:
            all_ids = sorted(
                set(FRAMEWORK_MAPPINGS.keys())
                | set(getattr(self._generator, "_custom_frameworks", {}).keys())
            )
            valid = ", ".join(all_ids)
            raise ValueError(
                f"Unknown framework: {framework_id!r}. "
                f"Valid frameworks: {valid}"
            )

        # Collect all dimension names needed across all controls
        all_dims: set[str] = set()
        for ctrl in mapping.controls:
            all_dims.update(ctrl.nomotic_dimensions)

        # Get average dimension scores from audit records
        avg_scores = self._get_avg_dimension_scores(
            list(all_dims), agent_id, days
        )

        # Determine sample size from audit records
        sample_size = self._get_sample_size(agent_id, days)

        # Analyze each control
        critical_gaps: list[ControlGap] = []
        high_gaps: list[ControlGap] = []
        medium_gaps: list[ControlGap] = []
        low_gaps: list[ControlGap] = []
        clean_controls: list[ControlGap] = []

        for ctrl in mapping.controls:
            # Compute average score across this control's dimensions
            dim_scores = [
                avg_scores[d]
                for d in ctrl.nomotic_dimensions
                if d in avg_scores
            ]
            if dim_scores:
                avg_score = sum(dim_scores) / len(dim_scores)
            else:
                avg_score = 0.0

            is_gap = avg_score < gap_threshold
            severity = self._classify_severity(avg_score, gap_threshold)
            recommendation = self._get_recommendation(ctrl.nomotic_dimensions)

            gap = ControlGap(
                framework_id=framework_id,
                control_id=ctrl.control_id,
                control_description=ctrl.description,
                nomotic_dimensions=list(ctrl.nomotic_dimensions),
                coverage=ctrl.coverage,
                average_dimension_score=round(avg_score, 4),
                score_threshold=gap_threshold,
                is_gap=is_gap,
                gap_severity=severity if is_gap else "low",
                sample_size=sample_size,
                recommendation=recommendation,
            )

            if not is_gap:
                clean_controls.append(gap)
            elif severity == "critical":
                critical_gaps.append(gap)
            elif severity == "high":
                high_gaps.append(gap)
            elif severity == "medium":
                medium_gaps.append(gap)
            else:
                low_gaps.append(gap)

        total = len(mapping.controls)
        with_gaps = total - len(clean_controls)
        coverage_pct = (
            (len(clean_controls) / total * 100.0) if total > 0 else 100.0
        )

        return ComplianceGapReport(
            framework_id=framework_id,
            framework_name=mapping.framework_name,
            generated_at=time.time(),
            period_days=days,
            agent_id=agent_id,
            gap_threshold=gap_threshold,
            total_controls=total,
            controls_with_gaps=with_gaps,
            coverage_percent=round(coverage_pct, 1),
            critical_gaps=critical_gaps,
            high_gaps=high_gaps,
            medium_gaps=medium_gaps,
            low_gaps=low_gaps,
            clean_controls=clean_controls,
        )

    def _get_avg_dimension_scores(
        self,
        dimension_names: list[str],
        agent_id: str | None,
        days: int,
    ) -> dict[str, float]:
        """Query audit records and compute average score per dimension.

        Returns {dimension_name: average_score}.
        Dimensions with no data (never scored) are excluded.
        """
        cutoff = time.time() - (days * 86400)

        # Collect records from the audit store
        records: list[Any] = []
        if agent_id is not None:
            all_records = self._audit_store.query_all(agent_id)
            records = [r for r in all_records if r.timestamp >= cutoff]
        else:
            # Fleet-wide: query all agents
            for aid in self._audit_store.list_agents():
                all_records = self._audit_store.query_all(aid)
                records.extend(r for r in all_records if r.timestamp >= cutoff)

        # Accumulate scores per dimension
        dim_totals: dict[str, float] = {}
        dim_counts: dict[str, int] = {}

        for record in records:
            scores = getattr(record, "dimension_scores", {}) or {}
            for dim_name in dimension_names:
                if dim_name in scores:
                    dim_totals[dim_name] = (
                        dim_totals.get(dim_name, 0.0) + scores[dim_name]
                    )
                    dim_counts[dim_name] = dim_counts.get(dim_name, 0) + 1

        # Compute averages
        result: dict[str, float] = {}
        for dim_name in dimension_names:
            count = dim_counts.get(dim_name, 0)
            if count > 0:
                result[dim_name] = dim_totals[dim_name] / count

        return result

    def _get_sample_size(
        self,
        agent_id: str | None,
        days: int,
    ) -> int:
        """Count audit records in the time window."""
        cutoff = time.time() - (days * 86400)

        count = 0
        if agent_id is not None:
            all_records = self._audit_store.query_all(agent_id)
            count = sum(1 for r in all_records if r.timestamp >= cutoff)
        else:
            for aid in self._audit_store.list_agents():
                all_records = self._audit_store.query_all(aid)
                count += sum(1 for r in all_records if r.timestamp >= cutoff)

        return count

    def _classify_severity(self, score: float, threshold: float) -> str:
        """Map score to severity string."""
        if score < 0.3:
            return "critical"
        elif score < 0.5:
            return "high"
        elif score < threshold:
            return "medium"
        else:
            return "low"  # Above threshold but included for completeness

    def _get_recommendation(self, dimensions: list[str]) -> str:
        """Generate recommendation for a control's dimensions."""
        for dim in dimensions:
            if dim in self._RECOMMENDATIONS:
                return self._RECOMMENDATIONS[dim]
        return (
            f"Review configuration for dimensions: "
            f"{', '.join(dimensions)}"
        )
