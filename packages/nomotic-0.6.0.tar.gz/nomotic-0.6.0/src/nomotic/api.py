"""HTTP API server for the Nomotic governance framework.

A thin HTTP layer over :class:`CertificateAuthority`, the validation
registries, and optionally :class:`GovernanceRuntime`.  Uses only
:mod:`http.server` from the standard library — zero extra dependencies.

Start the server::

    from nomotic.api import NomoticAPIServer
    server = NomoticAPIServer(ca)
    server.serve_forever()

Or via the CLI::

    nomotic serve --port 8420
"""

from __future__ import annotations

import json
import re
import time
import traceback
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any

from nomotic.authority import CertificateAuthority
from nomotic.certificate import CertStatus
from nomotic.evaluator import ProtocolEvaluator
from nomotic.protocol import ReasoningArtifact
from nomotic.registry import (
    ArchetypeRegistry,
    OrganizationRegistry,
    OrgStatus,
    ZoneValidator,
)

__all__ = ["NomoticAPIServer"]

_VERSION = "0.1.0"

# Characters forbidden in HTTP header names/values to prevent response splitting
# and header injection. Names are restricted to RFC 7230 token characters.
_HEADER_NAME_SANITIZE_RE = re.compile(r"[^!#$%&'*+\-.^_`|~0-9A-Za-z]")
# Values: strip CR/LF and other control chars (except horizontal tab).
_HEADER_VALUE_SANITIZE_RE = re.compile(r"[\r\n\x00-\x08\x0b-\x1f\x7f]")
_MAX_HEADER_VALUE_LEN = 8192

# Strip CR/LF and other control characters from the request path to
# prevent HTTP response splitting or log injection via a tainted path.
_PATH_SANITIZE_RE = re.compile(r"[\r\n\x00-\x1f\x7f]")


def _normalize_header(name: str, value: str) -> tuple[str, str]:
    """Return a normalized (name, value) safe for use in HTTP headers."""
    # Normalize and sanitize header name: strip whitespace, remove disallowed
    # characters and colon to prevent header injection and response splitting.
    name = str(name).strip()
    name = name.replace(":", "")
    clean_name = _HEADER_NAME_SANITIZE_RE.sub("-", name)
    # Normalize and sanitize header value: strip control characters, including
    # CR/LF, and enforce a maximum length.
    value = str(value).strip()
    clean_value = _HEADER_VALUE_SANITIZE_RE.sub("", value)
    if len(clean_value) > _MAX_HEADER_VALUE_LEN:
        clean_value = clean_value[:_MAX_HEADER_VALUE_LEN]
    return clean_name, clean_value


# ── JSON helpers ────────────────────────────────────────────────────────


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, indent=2).encode("utf-8")


def _error(status_code: int, error: str, message: str, **extra: Any) -> tuple[int, bytes]:
    body: dict[str, Any] = {
        "error": error,
        "message": message,
        "status_code": status_code,
    }
    body.update(extra)
    return status_code, _json_bytes(body)


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Route matching ──────────────────────────────────────────────────────

_CERT_ID_RE = re.compile(r"^/v1/certificates/(nmc-[^/]+)$")
_CERT_ACTION_RE = re.compile(r"^/v1/certificates/(nmc-[^/]+)/(verify|verify/live|suspend|reactivate|revoke|renew|zone|reputation)$")
_VERIFY_RE = re.compile(r"^/v1/verify/(nmc-[^/]+)$")
_ARCHETYPE_NAME_RE = re.compile(r"^/v1/archetypes/([a-z0-9][a-z0-9-]*[a-z0-9])$")
_ORG_NAME_RE = re.compile(r"^/v1/organizations/([a-z0-9][a-z0-9-]*[a-z0-9])$")
_ORG_ACTION_RE = re.compile(r"^/v1/organizations/([a-z0-9][a-z0-9-]*[a-z0-9])/(suspend|revoke)$")
_FINGERPRINT_RE = re.compile(r"^/v1/fingerprint/(.+)$")
_DRIFT_RE = re.compile(r"^/v1/drift/(.+)$")
_ALERT_ACK_RE = re.compile(r"^/v1/alerts/([^/]+)/(\d+)/acknowledge$")
_TRUST_RE = re.compile(r"^/v1/trust/([^/]+)$")
_TRUST_TRAJECTORY_RE = re.compile(r"^/v1/trust/([^/]+)/trajectory$")
_PROVENANCE_HISTORY_RE = re.compile(r"^/v1/provenance/history/([^/]+)/(.+)$")
_OWNER_ACTIVITY_RE = re.compile(r"^/v1/owner/([^/]+)/activity$")
_OWNER_ENGAGEMENT_RE = re.compile(r"^/v1/owner/([^/]+)/engagement$")
_USER_STATS_RE = re.compile(r"^/v1/user/([^/]+)/stats$")
_CONTEXT_PROFILE_RE = re.compile(r"^/v1/context/(cp-[a-f0-9]+)$")
_CONTEXT_PROFILE_ACTION_RE = re.compile(r"^/v1/context/(cp-[a-f0-9]+)/(summary|risks|feedback|signal|modifications)$")
_CONTEXT_PROFILE_STEP_RE = re.compile(r"^/v1/context/(cp-[a-f0-9]+)/workflow/step$")
_WORKFLOW_GOV_RE = re.compile(r"^/v1/workflow/([^/]+)/(assessment|dependencies|projection|drift)$")
_WORKFLOW_GOV_STEP_RE = re.compile(r"^/v1/workflow/([^/]+)/assess-step$")
_ETHICS_REASONING_RE = re.compile(r"^/v1/ethics/reasoning/([^/]+)$")

# Persistent audit API (Phase 10A)
_AUDIT_AGENT_RECORDS_RE = re.compile(r"^/v1/audit/([^/]+)/records$")
_AUDIT_AGENT_SUMMARY_RE = re.compile(r"^/v1/audit/([^/]+)/summary$")
_AUDIT_AGENT_VERIFY_RE = re.compile(r"^/v1/audit/([^/]+)/verify$")
_AUDIT_AGENT_EXPORT_RE = re.compile(r"^/v1/audit/([^/]+)/export$")
_AUDIT_AGENT_SEAL_RE = re.compile(r"^/v1/audit/([^/]+)/seal$")

# Test log API (Phase 10B)
_TESTLOG_AGENT_RECORDS_RE = re.compile(r"^/v1/testlog/([^/]+)/records$")
_TESTLOG_AGENT_SUMMARY_RE = re.compile(r"^/v1/testlog/([^/]+)/summary$")
_TESTLOG_AGENT_VERIFY_RE = re.compile(r"^/v1/testlog/([^/]+)/verify$")
_TESTLOG_AGENT_EXPORT_RE = re.compile(r"^/v1/testlog/([^/]+)/export$")

# Human engagement API
_HUMAN_ENGAGEMENT_RE = re.compile(r"^/v1/human-engagement/([^/]+)$")
_HUMAN_ENGAGEMENT_DRIFT_RE = re.compile(r"^/v1/human-engagement/([^/]+)/drift$")
_HUMAN_ENGAGEMENT_ROUTING_RE = re.compile(r"^/v1/human-engagement/([^/]+)/routing$")

# Fleet Governance API
_FLEET_AGENT_RE = re.compile(r"^/v1/fleet/agents/([^/]+)$")

# Constitutional Rules API
_CONSTITUTION_RULE_ID_RE = re.compile(r"^/v1/constitution/rules/(nmcr-[^/]+)$")

# Pre-Execution Budget Gate API (Item 17)
_BUDGET_GROUP_STATUS_RE = re.compile(r"^/v1/budget/groups/([^/]+)/status$")
_BUDGET_RESERVATION_SETTLE_RE = re.compile(r"^/v1/budget/reservations/([^/]+)/settle$")

# Governance Authority Registry API (Item 15)
_AUTHORITY_REGISTRY_ID_RE = re.compile(r"^/v1/authority-registry/authorities/(nma-[^/]+)$")

# Immutable Pre-Execution Record API (Item 18)
_PRE_EXEC_RECORDS_RE = re.compile(r"^/v1/pre-execution/([^/]+)/records$")
_PRE_EXEC_UNSETTLED_RE = re.compile(r"^/v1/pre-execution/([^/]+)/unsettled$")
_PRE_EXEC_VERIFY_RE = re.compile(r"^/v1/pre-execution/([^/]+)/verify$")

# Playground API (F-17)
_PLAYGROUND_EVAL_RE = re.compile(r"^/v1/playground/evaluate$")
_PLAYGROUND_ARCHETYPES_RE = re.compile(r"^/v1/playground/archetypes$")
_PLAYGROUND_PRESETS_RE = re.compile(r"^/v1/playground/presets$")
_PLAYGROUND_EXPORT_RE = re.compile(r"^/v1/playground/export-config$")

# Config Editor API (F-14)
_UI_CONFIG_RE = re.compile(r"^/v1/ui/config$")
_UI_CONFIG_VALIDATE_RE = re.compile(r"^/v1/ui/config/validate$")
_UI_CONFIG_DOWNLOAD_RE = re.compile(r"^/v1/ui/config/download$")

# Dashboard UI API (F-01)
_UI_STATIC_RE = re.compile(r"^/ui(/.*)?$")
_UI_OVERVIEW_RE = re.compile(r"^/v1/ui/overview$")
_UI_FEED_RE = re.compile(r"^/v1/ui/feed$")
_UI_EVENTS_RE = re.compile(r"^/v1/ui/events$")
_UI_EXPORT_RE = re.compile(r"^/v1/ui/export$")

# Override Approval Queue API (F-05)
_OVERRIDE_PENDING_RE = re.compile(r"^/v1/overrides/pending$")
_OVERRIDE_PENDING_ID_RE = re.compile(r"^/v1/overrides/pending/([^/]+)$")
_OVERRIDE_APPROVE_RE = re.compile(r"^/v1/overrides/pending/([^/]+)/approve$")
_OVERRIDE_DENY_RE = re.compile(r"^/v1/overrides/pending/([^/]+)/deny$")
_OVERRIDE_HISTORY_RE = re.compile(r"^/v1/overrides/history$")
_OVERRIDE_STATUS_RE = re.compile(r"^/v1/overrides/pending/([^/]+)/status$")
_OVERRIDE_CALLBACK_RE = re.compile(r"^/v1/overrides/([^/]+)/callback$")

# Slack Integration (F-05 Part C)
_SLACK_INTERACTION_RE = re.compile(r"^/v1/slack/interaction$")

# Approval Queue UI Panel (F-05 Part B)
_UI_PANEL_APPROVAL_QUEUE_RE = re.compile(r"^/v1/ui/panels/approval-queue$")

# Decision Explainability (F-04)
_UI_VERDICT_RE = re.compile(r"^/v1/ui/verdict/([^/]+)$")
_UI_PANEL_FEED_RE = re.compile(r"^/v1/ui/panels/evaluation-feed$")

# Agent Live Status Panel (F-10)
_UI_AGENTS_RE = re.compile(r"^/v1/ui/agents$")
_UI_AGENT_RE = re.compile(r"^/v1/ui/agent/([^/]+)$")
_UI_PANEL_AGENTS_RE = re.compile(r"^/v1/ui/panels/agent-roster$")

# Drift Alert Surface (F-11)
_UI_DRIFT_RE = re.compile(r"^/v1/ui/drift-alerts$")
_UI_DRIFT_DISMISS_RE = re.compile(r"^/v1/ui/drift-alerts/([^/]+)/dismiss$")
_UI_PANEL_DRIFT_ALERTS_RE = re.compile(r"^/v1/ui/panels/drift-alerts$")

# Audit Trail Viewer (F-12)
_UI_AUDIT_RE = re.compile(r"^/v1/ui/audit$")
_UI_AUDIT_EXPORT_RE = re.compile(r"^/v1/ui/audit/export$")
_UI_AUDIT_VERIFY_RE = re.compile(r"^/v1/ui/audit/verify/([^/]+)$")
_UI_PANEL_AUDIT_RE = re.compile(r"^/v1/ui/panels/audit-trail$")

# ── Dimension metadata (from dimensions.py) ───────────────────────────
_DIMENSION_META = [
    {"name": "scope_compliance", "display_name": "Scope Compliance", "weight": 1.5, "is_veto": True},
    {"name": "authority_verification", "display_name": "Authority Verification", "weight": 1.5, "is_veto": True},
    {"name": "resource_boundaries", "display_name": "Resource Boundaries", "weight": 1.2, "is_veto": True},
    {"name": "behavioral_consistency", "display_name": "Behavioral Consistency", "weight": 1.0, "is_veto": False},
    {"name": "cascading_impact", "display_name": "Cascading Impact", "weight": 1.3, "is_veto": False},
    {"name": "stakeholder_impact", "display_name": "Stakeholder Impact", "weight": 1.2, "is_veto": False},
    {"name": "incident_detection", "display_name": "Incident Detection", "weight": 1.5, "is_veto": True},
    {"name": "isolation_integrity", "display_name": "Isolation Integrity", "weight": 1.4, "is_veto": True},
    {"name": "temporal_compliance", "display_name": "Temporal Compliance", "weight": 0.8, "is_veto": True},
    {"name": "precedent_alignment", "display_name": "Precedent Alignment", "weight": 0.7, "is_veto": False},
    {"name": "transparency", "display_name": "Transparency", "weight": 0.6, "is_veto": False},
    {"name": "human_override", "display_name": "Human Override", "weight": 2.0, "is_veto": True},
    {"name": "ethical_alignment", "display_name": "Ethical Alignment", "weight": 2.0, "is_veto": True},
    {"name": "jurisdictional_compliance", "display_name": "Jurisdictional Compliance", "weight": 1.4, "is_veto": True},
]

_DIMENSION_CONCERNS = {
    "scope_compliance": "Action target outside declared scope boundaries",
    "authority_verification": "Agent lacks verified authority for this action",
    "resource_boundaries": "Action exceeds resource allocation limits",
    "behavioral_consistency": "Action deviates from established behavioral patterns",
    "cascading_impact": "Significant cascading impact risk detected",
    "stakeholder_impact": "Potential negative stakeholder impact",
    "incident_detection": "Action matches known failure patterns",
    "isolation_integrity": "Containment boundary breach risk",
    "temporal_compliance": "Action timing violates temporal constraints",
    "precedent_alignment": "Inconsistent with past governance decisions",
    "transparency": "Insufficient auditability for this action",
    "human_override": "Human intervention required for this action",
    "ethical_alignment": "Action does not meet ethical constraints",
    "jurisdictional_compliance": "Jurisdictional or data residency violation",
}


def _dimension_reasoning(name: str, score: float, vetoed_by: list[str]) -> str:
    """Generate per-dimension reasoning based on score."""
    concern = _DIMENSION_CONCERNS.get(name, "Governance concern detected")
    if name in vetoed_by:
        return f"VETO: {concern}"
    if score < 0.3:
        return concern
    if score < 0.7:
        return f"Moderate — approaching acceptable threshold"
    return "No governance concerns"


def _compute_action_to_pass(
    verdict: str,
    ucs: float,
    target: str,
    dimensions: list[dict],
) -> dict:
    """Compute the action-to-pass explanation for a verdict."""
    # 1. Check for veto
    veto_dims = [d for d in dimensions if d["veto_triggered"]]
    if veto_dims:
        d = veto_dims[0]
        return {
            "type": "veto",
            "primary_dimension": d["name"],
            "explanation": (
                f"This action was blocked because {d['display_name']} triggered "
                f"a veto (score: {d['score']:.1f}). The agent attempted to access "
                f"'{target}' but {_DIMENSION_CONCERNS.get(d['name'], 'a governance rule was violated').lower()}. "
                f"To pass: address the {d['display_name'].lower()} issue and retry."
            ),
        }

    # 2. DENY without veto — UCS shortfall
    if verdict == "DENY":
        gaps = [(d["weight"] * (1.0 - d["score"]), d) for d in dimensions]
        gaps.sort(key=lambda x: x[0], reverse=True)
        top3 = gaps[:3]
        gap_lines = []
        for gap_val, d in top3:
            gap_lines.append(
                f"  - {d['display_name']}: gap={gap_val:.2f} "
                f"(score={d['score']:.2f}, weight={d['weight']:.1f})"
            )
        return {
            "type": "ucs_shortfall",
            "top_gaps": [
                {"dimension": d["name"], "gap": round(g, 4)}
                for g, d in top3
            ],
            "explanation": (
                f"This action was denied because the UCS score ({ucs:.2f}) "
                f"fell below the governance threshold. Top contributing gaps:\n"
                + "\n".join(gap_lines)
                + "\nTo pass: improve scores in these dimensions."
            ),
        }

    # 3. ESCALATE
    if verdict == "ESCALATE":
        return {
            "type": "escalation",
            "explanation": (
                f"UCS score {ucs:.2f} is within the deliberation range. "
                f"Human review required. Approve or deny in the approval queue."
            ),
        }

    # 4. BLOCK
    if verdict == "BLOCK":
        return {
            "type": "constitutional",
            "explanation": (
                "This action was blocked by a constitutional rule that cannot "
                "be overridden by any governance mechanism."
            ),
        }

    # 5. ALLOW / other
    return {
        "type": "none",
        "explanation": "This action passed governance evaluation.",
    }


# ── Request handler ─────────────────────────────────────────────────────


class _Handler(BaseHTTPRequestHandler):
    """HTTP request handler that delegates to the shared server state."""

    server: NomoticHTTPServer  # type: ignore[assignment]

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default stderr logging."""
        pass

    # ── Dispatch ────────────────────────────────────────────────────

    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def do_PATCH(self) -> None:
        self._dispatch("PATCH")

    def do_DELETE(self) -> None:
        self._dispatch("DELETE")

    def _dispatch(self, method: str) -> None:
        try:
            result = self._route(method)
        except Exception:
            result = _error(500, "internal_error", traceback.format_exc())
        extra_headers: dict[str, str] = {}
        if len(result) == 4:
            status, body, content_type, extra_headers = result  # type: ignore[misc]
        elif len(result) == 3:
            status, body, content_type = result  # type: ignore[misc]
        else:
            status, body = result
            content_type = "application/json"
        # Sanitize header values to prevent HTTP response splitting (CWE-113).
        safe_ct_name, safe_ct_value = _normalize_header("Content-Type", content_type)
        safe_cl_name, safe_cl_value = _normalize_header("Content-Length", str(len(body)))
        self.send_response(status)
        self.send_header(safe_ct_name, safe_ct_value)
        self.send_header(safe_cl_name, safe_cl_value)
        for hdr_name, hdr_val in extra_headers.items():
            safe_name, safe_val = _normalize_header(hdr_name, hdr_val)
            self.send_header(safe_name, safe_val)
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw)

    def _query_params(self) -> dict[str, str]:
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        return {k: v[0] for k, v in qs.items()}

    def _clean_path(self) -> str:
        from urllib.parse import urlparse
        raw = urlparse(self.path).path
        # Strip CR/LF and other control chars to prevent HTTP response splitting
        # or log injection via a tainted path.
        return _PATH_SANITIZE_RE.sub("", raw)

    # ── Router ──────────────────────────────────────────────────────

    def _route(self, method: str) -> tuple[int, bytes] | tuple[int, bytes, str]:
        path = self._clean_path()
        ctx = self.server.ctx

        # ── API key auth check (when configured, non-localhost) ────
        if ctx.api_key:
            client_host = self.client_address[0] if self.client_address else "unknown"
            if client_host not in ("127.0.0.1", "::1", "localhost"):
                req_key = self.headers.get("X-Api-Key")
                if req_key != ctx.api_key:
                    return _error(401, "unauthorized", "Unauthorized")

        # ── Playground UI (F-17) — must match before general /ui/* ─
        if ctx.playground_enabled and (path == "/ui/playground" or path == "/ui/playground/"):
            return self._serve_static(ctx.ui_dir / "playground.html", "text/html")

        # ── Config Editor UI (F-14) — must match before general /ui/* ─
        if ctx.ui_enabled and (path == "/ui/config-editor" or path == "/ui/config-editor/"):
            return self._serve_static(ctx.ui_dir / "config-editor.html", "text/html")

        # ── Dashboard UI static files ──────────────────────────────
        if ctx.ui_enabled and (path == "/ui" or path == "/ui/"):
            return self._serve_static(ctx.ui_dir / "index.html", "text/html")
        if ctx.ui_enabled and _UI_STATIC_RE.match(path):
            file_path = ctx.ui_dir / path[4:].lstrip("/")
            return self._serve_static(file_path)

        # ── Dashboard UI API endpoints ─────────────────────────────
        if _UI_OVERVIEW_RE.match(path) and method == "GET":
            return self._handle_ui_overview(ctx)
        if _UI_FEED_RE.match(path) and method == "GET":
            return self._handle_ui_feed(ctx)
        if _UI_EVENTS_RE.match(path) and method == "GET":
            return self._handle_ui_events(ctx)
        if _UI_EXPORT_RE.match(path) and method == "POST":
            return self._handle_ui_export(ctx)
        m = _UI_VERDICT_RE.match(path)
        if m and method == "GET":
            return self._handle_ui_verdict(ctx, m.group(1))
        if _UI_PANEL_FEED_RE.match(path) and method == "GET":
            return self._handle_ui_panel_feed(ctx)
        if _UI_AGENTS_RE.match(path) and method == "GET":
            return self._handle_ui_agents(ctx)
        m = _UI_AGENT_RE.match(path)
        if m and method == "GET":
            return self._handle_ui_agent_detail(ctx, m.group(1))
        if _UI_PANEL_AGENTS_RE.match(path) and method == "GET":
            return self._handle_ui_panel_agents(ctx)

        # Drift Alert Surface (F-11)
        if _UI_DRIFT_RE.match(path) and method == "GET":
            return self._handle_ui_drift_alerts(ctx)
        m = _UI_DRIFT_DISMISS_RE.match(path)
        if m and method == "POST":
            return self._handle_ui_drift_dismiss(ctx, m.group(1))
        if _UI_PANEL_DRIFT_ALERTS_RE.match(path) and method == "GET":
            return self._handle_ui_panel_drift_alerts(ctx)

        # Audit Trail Viewer (F-12)
        if _UI_AUDIT_EXPORT_RE.match(path) and method == "GET":
            return self._handle_ui_audit_export(ctx)
        m = _UI_AUDIT_VERIFY_RE.match(path)
        if m and method == "POST":
            return self._handle_ui_audit_verify(ctx, m.group(1))
        if _UI_AUDIT_RE.match(path) and method == "GET":
            return self._handle_ui_audit(ctx)
        if _UI_PANEL_AUDIT_RE.match(path) and method == "GET":
            return self._handle_ui_panel_audit(ctx)

        # Health
        if path == "/v1/health" and method == "GET":
            return self._handle_health(ctx)
        if path == "/v1/info" and method == "GET":
            return self._handle_info(ctx)

        # Revocations
        if path == "/v1/revocations" and method == "GET":
            return self._handle_revocations(ctx)

        # Certificates collection
        if path == "/v1/certificates":
            if method == "GET":
                return self._handle_list_certs(ctx)
            if method == "POST":
                return self._handle_issue_cert(ctx)

        # Single certificate
        m = _CERT_ID_RE.match(path)
        if m and method == "GET":
            return self._handle_get_cert(ctx, m.group(1))

        # Certificate actions
        m = _CERT_ACTION_RE.match(path)
        if m:
            cert_id, action = m.group(1), m.group(2)
            if action == "verify" and method == "POST":
                return self._handle_verify_cert(ctx, cert_id)
            if action == "verify/live" and method == "POST":
                return self._handle_verify_live(ctx, cert_id)
            if action == "suspend" and method == "PATCH":
                return self._handle_suspend_cert(ctx, cert_id)
            if action == "reactivate" and method == "PATCH":
                return self._handle_reactivate_cert(ctx, cert_id)
            if action == "revoke" and method == "PATCH":
                return self._handle_revoke_cert(ctx, cert_id)
            if action == "renew" and method == "POST":
                return self._handle_renew_cert(ctx, cert_id)
            if action == "zone" and method == "PATCH":
                return self._handle_transfer_zone(ctx, cert_id)
            if action == "reputation" and method == "GET":
                return self._handle_reputation(ctx, cert_id)

        # Quick verify
        m = _VERIFY_RE.match(path)
        if m and method == "GET":
            return self._handle_quick_verify(ctx, m.group(1))

        # Archetypes
        if path == "/v1/archetypes":
            if method == "GET":
                return self._handle_list_archetypes(ctx)
            if method == "POST":
                return self._handle_register_archetype(ctx)
        if path == "/v1/archetypes/validate" and method == "POST":
            return self._handle_validate_archetype(ctx)
        m = _ARCHETYPE_NAME_RE.match(path)
        if m and method == "GET":
            return self._handle_get_archetype(ctx, m.group(1))

        # Organizations
        if path == "/v1/organizations":
            if method == "GET":
                return self._handle_list_orgs(ctx)
            if method == "POST":
                return self._handle_register_org(ctx)
        if path == "/v1/organizations/validate" and method == "POST":
            return self._handle_validate_org(ctx)
        m = _ORG_ACTION_RE.match(path)
        if m:
            org_name, action = m.group(1), m.group(2)
            if action == "suspend" and method == "PATCH":
                return self._handle_suspend_org(ctx, org_name)
            if action == "revoke" and method == "PATCH":
                return self._handle_revoke_org(ctx, org_name)
        m = _ORG_NAME_RE.match(path)
        if m and method == "GET":
            return self._handle_get_org(ctx, m.group(1))

        # Zones
        if path == "/v1/zones/validate" and method == "POST":
            return self._handle_validate_zone(ctx)

        # Fingerprints
        m = _FINGERPRINT_RE.match(path)
        if m and method == "GET":
            return self._handle_get_fingerprint(ctx, m.group(1))

        # Drift
        m = _DRIFT_RE.match(path)
        if m and method == "GET":
            return self._handle_get_drift(ctx, m.group(1))

        # Alerts
        if path == "/v1/alerts" and method == "GET":
            return self._handle_get_alerts(ctx)

        m = _ALERT_ACK_RE.match(path)
        if m and method == "POST":
            return self._handle_acknowledge_alert(ctx, m.group(1), int(m.group(2)))

        # Trust
        m = _TRUST_TRAJECTORY_RE.match(path)
        if m and method == "GET":
            return self._handle_get_trust_trajectory(ctx, m.group(1))

        m = _TRUST_RE.match(path)
        if m and method == "GET":
            return self._handle_get_trust(ctx, m.group(1))

        # Persistent audit API (file-based, Phase 10A)
        m = _AUDIT_AGENT_RECORDS_RE.match(path)
        if m and method == "GET":
            return self._handle_audit_agent_records(ctx, m.group(1))
        m = _AUDIT_AGENT_SUMMARY_RE.match(path)
        if m and method == "GET":
            return self._handle_audit_agent_summary(ctx, m.group(1))
        m = _AUDIT_AGENT_VERIFY_RE.match(path)
        if m and method == "GET":
            return self._handle_audit_agent_verify(ctx, m.group(1))
        m = _AUDIT_AGENT_EXPORT_RE.match(path)
        if m and method == "GET":
            return self._handle_audit_agent_export(ctx, m.group(1))
        m = _AUDIT_AGENT_SEAL_RE.match(path)
        if m and method == "GET":
            return self._handle_audit_agent_seal(ctx, m.group(1))

        # Testlog routes (persistent, file-based, Phase 10B)
        m = _TESTLOG_AGENT_RECORDS_RE.match(path)
        if m and method == "GET":
            return self._handle_log_records(ctx, m.group(1), "testlog")
        m = _TESTLOG_AGENT_SUMMARY_RE.match(path)
        if m and method == "GET":
            return self._handle_log_summary(ctx, m.group(1), "testlog")
        m = _TESTLOG_AGENT_VERIFY_RE.match(path)
        if m and method == "GET":
            return self._handle_log_verify(ctx, m.group(1), "testlog")
        m = _TESTLOG_AGENT_EXPORT_RE.match(path)
        if m and method == "GET":
            return self._handle_log_export(ctx, m.group(1), "testlog")

        # In-memory audit (Phase 5, backward compatibility)
        if path == "/v1/audit" and method == "GET":
            return self._handle_audit_query(ctx)
        if path == "/v1/audit/summary" and method == "GET":
            return self._handle_audit_summary(ctx)

        # Provenance (Phase 5)
        if path == "/v1/provenance" and method == "GET":
            return self._handle_provenance_query(ctx)
        m = _PROVENANCE_HISTORY_RE.match(path)
        if m and method == "GET":
            return self._handle_provenance_history(ctx, m.group(1), m.group(2))

        # Owner (Phase 5)
        m = _OWNER_ACTIVITY_RE.match(path)
        if m and method == "GET":
            return self._handle_owner_activity(ctx, m.group(1))
        m = _OWNER_ENGAGEMENT_RE.match(path)
        if m and method == "GET":
            return self._handle_owner_engagement(ctx, m.group(1))

        # User stats (Phase 5)
        m = _USER_STATS_RE.match(path)
        if m and method == "GET":
            return self._handle_user_stats(ctx, m.group(1))

        # ── Nomotic Protocol endpoints ─────────────────────────────
        if path == "/v1/reason" and method == "POST":
            return self._handle_reason(ctx)
        if path == "/v1/reason/summary" and method == "POST":
            return self._handle_reason_summary(ctx)
        if path == "/v1/reason/posthoc" and method == "POST":
            return self._handle_reason_posthoc(ctx)
        if path == "/v1/token/validate" and method == "POST":
            return self._handle_token_validate(ctx)
        if path == "/v1/token/introspect" and method == "POST":
            return self._handle_token_introspect(ctx)
        if path == "/v1/token/revoke" and method == "POST":
            return self._handle_token_revoke(ctx)
        if path == "/v1/schema" and method == "GET":
            return self._handle_schema(ctx)
        if path == "/v1/schema/version" and method == "GET":
            return self._handle_schema_version(ctx)

        # ── Workflow Governance (Phase 7C) ───────────────────────────
        m = _WORKFLOW_GOV_STEP_RE.match(path)
        if m and method == "POST":
            return self._handle_workflow_assess_step(ctx, m.group(1))

        m = _WORKFLOW_GOV_RE.match(path)
        if m and method == "GET":
            workflow_id, action = m.group(1), m.group(2)
            if action == "assessment":
                return self._handle_workflow_assessment(ctx, workflow_id)
            if action == "dependencies":
                return self._handle_workflow_dependencies(ctx, workflow_id)
            if action == "projection":
                return self._handle_workflow_projection(ctx, workflow_id)
            if action == "drift":
                return self._handle_workflow_drift(ctx, workflow_id)

        # ── Context Profiles (Phase 7A) ──────────────────────────────
        if path == "/v1/context":
            if method == "GET":
                return self._handle_list_context_profiles(ctx)
            if method == "POST":
                return self._handle_create_context_profile(ctx)

        m = _CONTEXT_PROFILE_STEP_RE.match(path)
        if m and method == "POST":
            return self._handle_context_workflow_step(ctx, m.group(1))

        m = _CONTEXT_PROFILE_ACTION_RE.match(path)
        if m:
            profile_id, action = m.group(1), m.group(2)
            if action == "summary" and method == "GET":
                return self._handle_context_summary(ctx, profile_id)
            if action == "risks" and method == "GET":
                return self._handle_context_risks(ctx, profile_id)
            if action == "feedback" and method == "POST":
                return self._handle_context_feedback(ctx, profile_id)
            if action == "signal" and method == "POST":
                return self._handle_context_signal(ctx, profile_id)
            if action == "modifications" and method == "GET":
                return self._handle_context_modifications(ctx, profile_id)

        m = _CONTEXT_PROFILE_RE.match(path)
        if m:
            profile_id = m.group(1)
            if method == "GET":
                return self._handle_get_context_profile(ctx, profile_id)
            if method == "PATCH":
                return self._handle_update_context_profile(ctx, profile_id)
            if method == "DELETE":
                return self._handle_close_context_profile(ctx, profile_id)

        # ── Phase 8: Ethical Governance Infrastructure ─────────────────
        if path == "/v1/equity/report" and method == "GET":
            return self._handle_equity_report(ctx)
        if path == "/v1/equity/config" and method == "GET":
            return self._handle_equity_config_get(ctx)
        if path == "/v1/equity/config" and method == "PUT":
            return self._handle_equity_config_put(ctx)
        if path == "/v1/bias/report" and method == "GET":
            return self._handle_bias_report(ctx)
        m = _ETHICS_REASONING_RE.match(path)
        if m and method == "GET":
            return self._handle_ethics_reasoning(ctx, m.group(1))
        if path == "/v1/signals/cross-dimensional" and method == "GET":
            return self._handle_cross_dimensional_signals(ctx)
        if path == "/v1/signals/patterns" and method == "GET":
            return self._handle_list_patterns(ctx)
        if path == "/v1/signals/patterns" and method == "POST":
            return self._handle_add_pattern(ctx)
        if path == "/v1/anonymization/policy" and method == "GET":
            return self._handle_anonymization_policy_get(ctx)
        if path == "/v1/anonymization/policy" and method == "PUT":
            return self._handle_anonymization_policy_put(ctx)

        # ── Human Engagement (Bidirectional Drift) ──────────────────
        m = _HUMAN_ENGAGEMENT_DRIFT_RE.match(path)
        if m and method == "GET":
            return self._handle_human_engagement_drift(ctx, m.group(1))

        m = _HUMAN_ENGAGEMENT_ROUTING_RE.match(path)
        if m and method == "GET":
            return self._handle_human_engagement_routing(ctx, m.group(1))

        m = _HUMAN_ENGAGEMENT_RE.match(path)
        if m and method == "GET":
            return self._handle_human_engagement(ctx, m.group(1))

        if path == "/v1/human-engagement/event" and method == "POST":
            return self._handle_human_engagement_event(ctx)

        if path == "/v1/human-engagement/alerts" and method == "GET":
            return self._handle_human_engagement_alerts(ctx)

        if path == "/v1/human-engagement/team/overview" and method == "GET":
            return self._handle_human_engagement_team(ctx)

        # ── Fleet Governance API ──────────────────────────────────────
        if path == "/v1/fleet/health" and method == "GET":
            return self._handle_fleet_health(ctx)
        if path == "/v1/fleet/trust" and method == "GET":
            return self._handle_fleet_trust(ctx)
        if path == "/v1/fleet/denials" and method == "GET":
            return self._handle_fleet_denials(ctx)
        if path == "/v1/fleet/critical" and method == "GET":
            return self._handle_fleet_critical(ctx)
        if path == "/v1/fleet/agents" and method == "GET":
            return self._handle_fleet_agents(ctx)
        m = _FLEET_AGENT_RE.match(path)
        if m and method == "GET":
            return self._handle_fleet_agent(ctx, m.group(1))

        # ── Constitutional Rules API ─────────────────────────────────
        if path == "/v1/constitution/rules" and method == "GET":
            return self._handle_constitution_list_rules(ctx)
        m = _CONSTITUTION_RULE_ID_RE.match(path)
        if m and method == "GET":
            return self._handle_constitution_get_rule(ctx, m.group(1))
        if path == "/v1/constitution/verify" and method == "POST":
            return self._handle_constitution_verify(ctx)

        # ── Governance Authority Registry (Item 15) ──────────────────
        if path == "/v1/authority-registry/authorities":
            if method == "GET":
                return self._handle_authority_registry_list(ctx)
            if method == "POST":
                return self._handle_authority_registry_register(ctx)
        if path == "/v1/authority-registry/changes" and method == "GET":
            return self._handle_authority_registry_changes(ctx)
        if path == "/v1/authority-registry/bootstrap" and method == "POST":
            return self._handle_authority_registry_bootstrap(ctx)
        m = _AUTHORITY_REGISTRY_ID_RE.match(path)
        if m and method == "DELETE":
            return self._handle_authority_registry_revoke(ctx, m.group(1))

        # ── Pre-Execution Budget Gate (Item 17) ──────────────────────
        m = _BUDGET_GROUP_STATUS_RE.match(path)
        if m and method == "GET":
            return self._handle_budget_group_status(ctx, m.group(1))
        if path == "/v1/budget/reservations" and method == "GET":
            return self._handle_budget_reservations(ctx)
        m = _BUDGET_RESERVATION_SETTLE_RE.match(path)
        if m and method == "POST":
            return self._handle_budget_settle(ctx, m.group(1))

        # ── Immutable Pre-Execution Record (Item 18) ────────────────
        m = _PRE_EXEC_RECORDS_RE.match(path)
        if m and method == "GET":
            return self._handle_pre_exec_records(ctx, m.group(1))
        m = _PRE_EXEC_UNSETTLED_RE.match(path)
        if m and method == "GET":
            return self._handle_pre_exec_unsettled(ctx, m.group(1))
        m = _PRE_EXEC_VERIFY_RE.match(path)
        if m and method == "GET":
            return self._handle_pre_exec_verify(ctx, m.group(1))

        # ── Override Approval Queue API (F-05) ────────────────────────
        if _OVERRIDE_PENDING_RE.match(path) and method == "GET":
            return self._handle_overrides_pending_list(ctx)
        m = _OVERRIDE_APPROVE_RE.match(path)
        if m and method == "POST":
            return self._handle_overrides_approve(ctx, m.group(1))
        m = _OVERRIDE_DENY_RE.match(path)
        if m and method == "POST":
            return self._handle_overrides_deny(ctx, m.group(1))
        if _OVERRIDE_HISTORY_RE.match(path) and method == "GET":
            return self._handle_overrides_history(ctx)
        m = _OVERRIDE_STATUS_RE.match(path)
        if m and method == "GET":
            return self._handle_overrides_status(ctx, m.group(1))
        m = _OVERRIDE_PENDING_ID_RE.match(path)
        if m and method == "GET":
            return self._handle_overrides_pending_get(ctx, m.group(1))
        m = _OVERRIDE_CALLBACK_RE.match(path)
        if m and method == "POST":
            return self._handle_override_callback(ctx, m.group(1))
        if _SLACK_INTERACTION_RE.match(path) and method == "POST":
            return self._handle_slack_interaction(ctx)
        if _UI_PANEL_APPROVAL_QUEUE_RE.match(path) and method == "GET":
            return self._handle_ui_panel_approval_queue(ctx)

        # ── Playground API (F-17) ────────────────────────────────────
        if ctx.playground_enabled:
            if _PLAYGROUND_EVAL_RE.match(path) and method == "POST":
                return self._handle_playground_evaluate(ctx)
            if _PLAYGROUND_ARCHETYPES_RE.match(path) and method == "GET":
                return self._handle_playground_archetypes(ctx)
            if _PLAYGROUND_PRESETS_RE.match(path) and method == "GET":
                return self._handle_playground_presets(ctx)
            if _PLAYGROUND_EXPORT_RE.match(path) and method == "POST":
                return self._handle_playground_export(ctx)

        # ── Config Editor API (F-14) ──────────────────────────────────
        if ctx.ui_enabled:
            if _UI_CONFIG_RE.match(path) and method == "GET":
                return self._handle_ui_config_get(ctx)
            if _UI_CONFIG_VALIDATE_RE.match(path) and method == "POST":
                return self._handle_ui_config_validate(ctx)
            if _UI_CONFIG_DOWNLOAD_RE.match(path) and method == "POST":
                return self._handle_ui_config_download(ctx)

        # ── Prometheus Metrics ───────────────────────────────────────
        if path == "/metrics" and method == "GET":
            return self._handle_metrics(ctx)

        # ── Fleet Simulation API ────────────────────────────────────
        if path == "/v1/sim/stats" and method == "GET":
            return self._handle_sim_stats()
        if path == "/v1/sim/status" and method == "GET":
            return self._handle_sim_status()

        return _error(404, "not_found", f"No route for {method} {path}")

    # ── Health / Info ───────────────────────────────────────────────

    def _handle_health(self, ctx: _ServerContext) -> tuple[int, bytes]:
        return 200, _json_bytes({"status": "ok"})

    def _handle_info(self, ctx: _ServerContext) -> tuple[int, bytes]:
        certs = ctx.ca.list()
        return 200, _json_bytes({
            "version": _VERSION,
            "issuer_id": ctx.ca.issuer_id,
            "issuer_fingerprint": ctx.ca.issuer_fingerprint,
            "uptime_seconds": round(time.time() - ctx.started_at, 1),
            "certificate_count": len(certs),
        })

    # ── Prometheus Metrics ────────────────────────────────────────

    def _handle_metrics(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """Prometheus-compatible metrics endpoint."""
        if ctx.prometheus is None:
            return _error(
                404, "not_found", "Metrics not enabled. Start with --metrics flag."
            )
        body = ctx.prometheus.format_prometheus().encode("utf-8")
        return 200, body, "text/plain; version=0.0.4; charset=utf-8"  # type: ignore[return-value]

    # ── Fleet Simulation ──────────────────────────────────────────

    def _handle_sim_stats(self) -> tuple[int, bytes]:
        """Return fleet simulation stats snapshot as JSON."""
        fleet_sim = getattr(self.server.ctx, "_fleet_sim", None)
        if fleet_sim is None:
            return _error(404, "not_found", "No fleet simulation active. Start with --sim-mode.")
        return 200, _json_bytes(fleet_sim.stats_snapshot())

    def _handle_sim_status(self) -> tuple[int, bytes]:
        """Return whether a fleet simulation is running."""
        from nomotic.fleet_sim import FleetSimulator
        running = FleetSimulator.STATE_PATH.exists()
        return 200, _json_bytes({"running": running})

    # ── Revocations ─────────────────────────────────────────────────

    def _handle_revocations(self, ctx: _ServerContext) -> tuple[int, bytes]:
        revoked = ctx.ca.get_revocation_list()
        return 200, _json_bytes({
            "revoked": revoked,
            "generated_at": _utcnow_iso(),
        })

    # ── Certificates ────────────────────────────────────────────────

    def _handle_issue_cert(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        required = ["agent_id", "archetype", "organization", "zone_path"]
        missing = [k for k in required if k not in data]
        if missing:
            return _error(400, "validation_error", f"Missing fields: {', '.join(missing)}")
        try:
            cert, _sk = ctx.ca.issue(
                agent_id=data["agent_id"],
                archetype=data["archetype"],
                organization=data["organization"],
                zone_path=data["zone_path"],
            )
        except ValueError as exc:
            suggestion = None
            msg = str(exc)
            if "did you mean" in msg:
                import re as _re
                m = _re.search(r"did you mean '([^']+)'", msg)
                if m:
                    suggestion = m.group(1)
            kwargs: dict[str, Any] = {}
            if suggestion:
                kwargs["suggestion"] = suggestion
            return _error(400, "validation_error", str(exc), **kwargs)
        return 201, _json_bytes(cert.to_dict())

    def _handle_list_certs(self, ctx: _ServerContext) -> tuple[int, bytes]:
        params = self._query_params()
        org = params.get("org")
        status_str = params.get("status")
        archetype = params.get("archetype")
        status = CertStatus[status_str.upper()] if status_str else None
        certs = ctx.ca.list(org=org, status=status, archetype=archetype)
        return 200, _json_bytes([c.to_dict() for c in certs])

    def _handle_get_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        cert = ctx.ca.get(cert_id)
        if cert is None:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        return 200, _json_bytes(cert.to_dict())

    def _handle_verify_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        cert = ctx.ca.get(cert_id)
        if cert is None:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        result = ctx.ca.verify_certificate(cert)
        return 200, _json_bytes({
            "valid": result.valid,
            "certificate_id": result.certificate_id,
            "issues": result.issues,
            "status": result.status.name if result.status else None,
        })

    def _handle_verify_live(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        cert = ctx.ca.get(cert_id)
        if cert is None:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        result = ctx.ca.verify_live(cert)
        return 200, _json_bytes({
            "valid": result.valid,
            "certificate_id": result.certificate_id,
            "issues": result.issues,
            "status": result.status.name if result.status else None,
            "trust_score": result.trust_score,
            "behavioral_age": result.behavioral_age,
            "governance_hash": result.governance_hash,
            "healthy": result.healthy,
        })

    def _handle_suspend_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        data = self._read_json()
        reason = data.get("reason", "no reason given")
        try:
            cert = ctx.ca.suspend(cert_id, reason)
        except KeyError:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(cert.to_dict())

    def _handle_reactivate_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        try:
            cert = ctx.ca.reactivate(cert_id)
        except KeyError:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(cert.to_dict())

    def _handle_revoke_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        data = self._read_json()
        reason = data.get("reason", "no reason given")
        try:
            cert = ctx.ca.revoke(cert_id, reason)
        except KeyError:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(cert.to_dict())

    def _handle_renew_cert(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        try:
            cert, _sk = ctx.ca.renew(cert_id)
        except KeyError:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        return 200, _json_bytes(cert.to_dict())

    def _handle_transfer_zone(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        data = self._read_json()
        zone_path = data.get("zone_path")
        if not zone_path:
            return _error(400, "validation_error", "Missing 'zone_path' field")
        try:
            cert = ctx.ca.transfer_zone(cert_id, zone_path)
        except KeyError:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        return 200, _json_bytes(cert.to_dict())

    def _handle_reputation(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        cert = ctx.ca.get(cert_id)
        if cert is None:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        return 200, _json_bytes({
            "certificate_id": cert.certificate_id,
            "agent_id": cert.agent_id,
            "trust_score": cert.trust_score,
            "behavioral_age": cert.behavioral_age,
            "status": cert.status.name,
            "archetype": cert.archetype,
            "issued_at": cert.issued_at.isoformat(),
            "lineage": cert.lineage,
        })

    # ── Quick verify ────────────────────────────────────────────────

    def _handle_quick_verify(self, ctx: _ServerContext, cert_id: str) -> tuple[int, bytes]:
        cert = ctx.ca.get(cert_id)
        if cert is None:
            return _error(404, "not_found", f"Certificate not found: {cert_id}")
        result = ctx.ca.verify_live(cert)
        return 200, _json_bytes({
            "valid": result.valid,
            "certificate_id": cert.certificate_id,
            "status": cert.status.name,
            "trust_score": result.trust_score,
            "behavioral_age": result.behavioral_age,
            "archetype": cert.archetype,
            "organization": cert.organization,
            "zone_path": cert.zone_path,
            "governance_hash": result.governance_hash,
            "healthy": result.healthy,
        })

    # ── Archetypes ──────────────────────────────────────────────────

    def _handle_list_archetypes(self, ctx: _ServerContext) -> tuple[int, bytes]:
        params = self._query_params()
        category = params.get("category")
        archetypes = ctx.archetype_registry.list(category=category)
        return 200, _json_bytes([
            {"name": a.name, "description": a.description, "category": a.category, "builtin": a.builtin}
            for a in archetypes
        ])

    def _handle_register_archetype(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        required = ["name", "description", "category"]
        missing = [k for k in required if k not in data]
        if missing:
            return _error(400, "validation_error", f"Missing fields: {', '.join(missing)}")
        try:
            defn = ctx.archetype_registry.register(
                data["name"], data["description"], data["category"],
            )
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 201, _json_bytes({
            "name": defn.name, "description": defn.description,
            "category": defn.category, "builtin": defn.builtin,
        })

    def _handle_get_archetype(self, ctx: _ServerContext, name: str) -> tuple[int, bytes]:
        defn = ctx.archetype_registry.get(name)
        if defn is None:
            return _error(404, "not_found", f"Archetype not found: {name}")
        return 200, _json_bytes({
            "name": defn.name, "description": defn.description,
            "category": defn.category, "builtin": defn.builtin,
        })

    def _handle_validate_archetype(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        name = data.get("name", "")
        result = ctx.archetype_registry.validate(name)
        body: dict[str, Any] = {
            "valid": result.valid,
            "name": result.name,
            "warnings": result.warnings,
            "errors": result.errors,
        }
        if result.suggestion:
            body["suggestion"] = result.suggestion
        return 200, _json_bytes(body)

    # ── Organizations ───────────────────────────────────────────────

    def _handle_list_orgs(self, ctx: _ServerContext) -> tuple[int, bytes]:
        params = self._query_params()
        status_str = params.get("status")
        status = OrgStatus[status_str.upper()] if status_str else None
        orgs = ctx.org_registry.list(status=status)
        return 200, _json_bytes([o.to_dict() for o in orgs])

    def _handle_register_org(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        name = data.get("name")
        if not name:
            return _error(400, "validation_error", "Missing 'name' field")
        issuer_fp = ctx.ca.issuer_fingerprint
        try:
            org = ctx.org_registry.register(
                name,
                issuer_fp,
                contact_email=data.get("contact_email"),
            )
        except ValueError as exc:
            msg = str(exc)
            if "already registered" in msg:
                return _error(409, "conflict", msg)
            return _error(400, "validation_error", msg)
        return 201, _json_bytes(org.to_dict())

    def _handle_get_org(self, ctx: _ServerContext, name: str) -> tuple[int, bytes]:
        org = ctx.org_registry.get(name)
        if org is None:
            return _error(404, "not_found", f"Organization not found: {name}")
        return 200, _json_bytes(org.to_dict())

    def _handle_validate_org(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        name = data.get("name", "")
        result = ctx.org_registry.validate(name)
        return 200, _json_bytes({
            "valid": result.valid,
            "name": result.name,
            "warnings": result.warnings,
            "errors": result.errors,
        })

    def _handle_suspend_org(self, ctx: _ServerContext, name: str) -> tuple[int, bytes]:
        data = self._read_json()
        reason = data.get("reason", "no reason given")
        try:
            org = ctx.org_registry.suspend(name, reason)
        except KeyError:
            return _error(404, "not_found", f"Organization not found: {name}")
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(org.to_dict())

    def _handle_revoke_org(self, ctx: _ServerContext, name: str) -> tuple[int, bytes]:
        data = self._read_json()
        reason = data.get("reason", "no reason given")
        try:
            org = ctx.org_registry.revoke(name, reason)
        except KeyError:
            return _error(404, "not_found", f"Organization not found: {name}")
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(org.to_dict())

    # ── Zones ───────────────────────────────────────────────────────

    def _handle_validate_zone(self, ctx: _ServerContext) -> tuple[int, bytes]:
        data = self._read_json()
        zone_path = data.get("zone_path", "")
        result = ctx.zone_validator.validate(zone_path)
        return 200, _json_bytes({
            "valid": result.valid,
            "name": result.name,
            "warnings": result.warnings,
            "errors": result.errors,
        })

    # ── Fingerprints ───────────────────────────────────────────────

    def _handle_get_fingerprint(self, ctx: _ServerContext, agent_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Fingerprints require a GovernanceRuntime")
        fp = ctx.runtime.get_fingerprint(agent_id)
        if fp is None:
            return _error(404, "not_found", f"No fingerprint for agent: {agent_id}")
        return 200, _json_bytes({
            "agent_id": fp.agent_id,
            "total_observations": fp.total_observations,
            "confidence": fp.confidence,
            "action_distribution": fp.action_distribution,
            "target_distribution": fp.target_distribution,
            "temporal_pattern": fp.temporal_pattern.to_dict(),
            "outcome_distribution": fp.outcome_distribution,
        })

    # ── Drift ──────────────────────────────────────────────────────

    def _handle_get_drift(self, ctx: _ServerContext, agent_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Drift detection requires a GovernanceRuntime")
        drift = ctx.runtime.get_drift(agent_id)
        if drift is None:
            return _error(404, "not_found", f"No drift data for agent: {agent_id}")
        alerts = ctx.runtime.get_drift_alerts(agent_id)
        return 200, _json_bytes({
            "agent_id": agent_id,
            "drift": drift.to_dict(),
            "alerts": [a.to_dict() for a in alerts],
        })

    def _handle_get_alerts(self, ctx: _ServerContext) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Drift detection requires a GovernanceRuntime")
        params = self._query_params()
        agent_id = params.get("agent_id")
        alerts = ctx.runtime.get_drift_alerts(agent_id)
        unacked = sum(1 for a in alerts if not a.acknowledged)
        return 200, _json_bytes({
            "alerts": [a.to_dict() for a in alerts],
            "total": len(alerts),
            "unacknowledged": unacked,
        })

    def _handle_acknowledge_alert(self, ctx: _ServerContext, agent_id: str, index: int) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Drift detection requires a GovernanceRuntime")
        if ctx.runtime._fingerprint_observer is None:
            return _error(404, "not_found", "Drift detection is not enabled")
        ok = ctx.runtime._fingerprint_observer.drift_monitor.acknowledge_alert(agent_id, index)
        if not ok:
            return _error(404, "not_found", f"Alert not found: agent={agent_id}, index={index}")
        return 200, _json_bytes({"acknowledged": True})

    # ── Trust ─────────────────────────────────────────────────────────

    def _handle_get_trust(self, ctx: _ServerContext, agent_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Trust reports require a GovernanceRuntime")
        profile = ctx.runtime.get_trust_profile(agent_id)
        # Return 404 if the agent has never been evaluated (baseline profile
        # with no actions indicates no evaluation has occurred).
        if profile.successful_actions == 0 and profile.violation_count == 0:
            trajectory = ctx.runtime.trust_calibrator.get_trajectory(agent_id)
            if len(trajectory) == 0:
                return _error(404, "not_found", f"No trust data for agent: {agent_id}")
        report = ctx.runtime.get_trust_report(agent_id)
        return 200, _json_bytes(report)

    def _handle_get_trust_trajectory(self, ctx: _ServerContext, agent_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None:
            return _error(404, "not_found", "Trust reports require a GovernanceRuntime")
        trajectory = ctx.runtime.trust_calibrator.get_trajectory(agent_id)
        params = self._query_params()

        events = trajectory.events

        # Filter by since
        since_str = params.get("since")
        if since_str is not None:
            try:
                since = float(since_str)
                events = [e for e in events if e.timestamp > since]
            except ValueError:
                pass

        # Filter by source prefix
        source_prefix = params.get("source")
        if source_prefix is not None:
            events = [e for e in events if e.source.startswith(source_prefix)]

        # Limit
        limit_str = params.get("limit")
        if limit_str is not None:
            try:
                limit = min(int(limit_str), 500)
                events = events[-limit:]
            except ValueError:
                pass

        return 200, _json_bytes({
            "agent_id": agent_id,
            "events": [e.to_dict() for e in events],
            "total": len(events),
        })

    # ── Audit (Phase 5) ─────────────────────────────────────────────

    def _handle_audit_query(self, ctx: _ServerContext) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.audit_trail is None:
            return _error(404, "not_found", "Audit trail requires a GovernanceRuntime with audit enabled")
        params = self._query_params()
        kwargs: dict[str, Any] = {}
        for key in ("agent_id", "severity", "category", "verdict", "context_code", "owner_id", "user_id"):
            if key in params:
                kwargs[key] = params[key]
        if "since" in params:
            try:
                kwargs["since"] = float(params["since"])
            except ValueError:
                pass
        if "until" in params:
            try:
                kwargs["until"] = float(params["until"])
            except ValueError:
                pass
        if "limit" in params:
            try:
                kwargs["limit"] = min(int(params["limit"]), 500)
            except ValueError:
                pass
        records = ctx.runtime.audit_trail.query(**kwargs)
        return 200, _json_bytes({
            "records": [r.to_dict() for r in records],
            "total": len(records),
        })

    def _handle_audit_summary(self, ctx: _ServerContext) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.audit_trail is None:
            return _error(404, "not_found", "Audit trail requires a GovernanceRuntime with audit enabled")
        params = self._query_params()
        kwargs: dict[str, Any] = {}
        if "agent_id" in params:
            kwargs["agent_id"] = params["agent_id"]
        if "since" in params:
            try:
                kwargs["since"] = float(params["since"])
            except ValueError:
                pass
        summary = ctx.runtime.audit_trail.summary(**kwargs)
        return 200, _json_bytes(summary)

    # ── Provenance (Phase 5) ─────────────────────────────────────────

    def _handle_provenance_query(self, ctx: _ServerContext) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.provenance_log is None:
            return _error(404, "not_found", "Provenance log requires a GovernanceRuntime with audit enabled")
        params = self._query_params()
        kwargs: dict[str, Any] = {}
        for key in ("actor", "target_type", "target_id", "change_type"):
            if key in params:
                kwargs[key] = params[key]
        if "since" in params:
            try:
                kwargs["since"] = float(params["since"])
            except ValueError:
                pass
        if "limit" in params:
            try:
                kwargs["limit"] = min(int(params["limit"]), 500)
            except ValueError:
                pass
        records = ctx.runtime.provenance_log.query(**kwargs)
        return 200, _json_bytes({
            "records": [r.to_dict() for r in records],
            "total": len(records),
        })

    def _handle_provenance_history(self, ctx: _ServerContext, target_type: str, target_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.provenance_log is None:
            return _error(404, "not_found", "Provenance log requires a GovernanceRuntime with audit enabled")
        records = ctx.runtime.provenance_log.history(target_type, target_id)
        return 200, _json_bytes({
            "target_type": target_type,
            "target_id": target_id,
            "records": [r.to_dict() for r in records],
            "total": len(records),
        })

    # ── Owner (Phase 5) ──────────────────────────────────────────────

    def _handle_owner_activity(self, ctx: _ServerContext, owner_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.owner_activity is None:
            return _error(404, "not_found", "Owner tracking requires a GovernanceRuntime with audit enabled")
        params = self._query_params()
        kwargs: dict[str, Any] = {}
        if "activity_type" in params:
            kwargs["activity_type"] = params["activity_type"]
        if "since" in params:
            try:
                kwargs["since"] = float(params["since"])
            except ValueError:
                pass
        if "limit" in params:
            try:
                kwargs["limit"] = min(int(params["limit"]), 500)
            except ValueError:
                pass
        activities = ctx.runtime.owner_activity.get_activities(owner_id, **kwargs)
        return 200, _json_bytes({
            "owner_id": owner_id,
            "activities": [a.to_dict() for a in activities],
            "total": len(activities),
        })

    def _handle_owner_engagement(self, ctx: _ServerContext, owner_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.owner_activity is None:
            return _error(404, "not_found", "Owner tracking requires a GovernanceRuntime with audit enabled")
        params = self._query_params()
        window_days = 30
        if "window_days" in params:
            try:
                window_days = int(params["window_days"])
            except ValueError:
                pass
        score = ctx.runtime.owner_activity.engagement_score(owner_id, window_days=window_days)
        return 200, _json_bytes(score)

    # ── User stats (Phase 5) ─────────────────────────────────────────

    def _handle_user_stats(self, ctx: _ServerContext, user_id: str) -> tuple[int, bytes]:
        if ctx.runtime is None or ctx.runtime.user_tracker is None:
            return _error(404, "not_found", "User tracking requires a GovernanceRuntime with audit enabled")
        stats = ctx.runtime.user_tracker.get_stats(user_id)
        if stats is None:
            return _error(404, "not_found", f"No interaction data for user: {user_id}")
        return 200, _json_bytes(stats.to_dict())

    # ── Nomotic Protocol ──────────────────────────────────────────────

    def _handle_reason(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/reason — Full Deliberation Flow."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        try:
            artifact = ReasoningArtifact.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid reasoning artifact: {exc}")
        response = ctx.evaluator.evaluate(artifact)
        return 200, _json_bytes(response.to_dict())

    def _handle_reason_summary(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/reason/summary — Summary Flow."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        try:
            artifact = ReasoningArtifact.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid reasoning artifact: {exc}")
        response = ctx.evaluator.evaluate_summary(artifact)
        return 200, _json_bytes(response.to_dict())

    def _handle_reason_posthoc(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/reason/posthoc — Post-Hoc Flow."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        artifact_data = data.get("artifact", data)
        action_result = data.get("action_result")
        try:
            artifact = ReasoningArtifact.from_dict(artifact_data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid reasoning artifact: {exc}")
        assessment = ctx.evaluator.evaluate_posthoc(artifact, action_result)
        return 200, _json_bytes(assessment.to_dict())

    def _handle_token_validate(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/token/validate — Validate a Governance Token."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        token = data.get("token")
        if not token:
            return _error(400, "validation_error", "Missing 'token' field")
        result = ctx.evaluator.validate_token(token)
        return 200, _json_bytes(result.to_dict())

    def _handle_token_introspect(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/token/introspect — Full governance context for a token."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        token = data.get("token")
        if not token:
            return _error(400, "validation_error", "Missing 'token' field")
        result = ctx.evaluator.introspect_token(token)
        if result is None:
            return _error(400, "validation_error", "Invalid or expired token")
        return 200, _json_bytes(result)

    def _handle_token_revoke(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/token/revoke — Revoke a token before expiration."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        data = self._read_json()
        token_id = data.get("token_id")
        if not token_id:
            return _error(400, "validation_error", "Missing 'token_id' field")
        revoked = ctx.evaluator.revoke_token(token_id)
        return 200, _json_bytes({"revoked": revoked, "token_id": token_id})

    def _handle_schema(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/schema — Returns the current Reasoning Artifact JSON Schema."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        schema = ctx.evaluator.get_schema()
        return 200, _json_bytes(schema)

    def _handle_schema_version(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/schema/version — Returns supported schema versions."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        versions = ctx.evaluator.get_supported_versions()
        return 200, _json_bytes({"supported_versions": versions})

    # ── Workflow Governance (Phase 7C) ──────────────────────────────────

    def _handle_workflow_assessment(self, ctx: _ServerContext, workflow_id: str) -> tuple[int, bytes]:
        """GET /v1/workflow/{workflow_id}/assessment — Full workflow risk assessment."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Workflow governance requires a GovernanceRuntime")
        if ctx.runtime.workflow_governor is None:
            return _error(404, "not_found", "Workflow Governor is not enabled")

        # Find profile by workflow_id
        profile = self._find_workflow_profile(ctx, workflow_id)
        if profile is None:
            return _error(404, "not_found", f"No profile found for workflow: {workflow_id}")

        assessment = ctx.runtime.workflow_governor.assess_workflow(workflow_id, profile)
        return 200, _json_bytes(assessment.to_dict())

    def _handle_workflow_dependencies(self, ctx: _ServerContext, workflow_id: str) -> tuple[int, bytes]:
        """GET /v1/workflow/{workflow_id}/dependencies — Dependency graph data."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Workflow governance requires a GovernanceRuntime")

        profile = self._find_workflow_profile(ctx, workflow_id)
        if profile is None:
            return _error(404, "not_found", f"No profile found for workflow: {workflow_id}")
        if profile.workflow is None:
            return _error(400, "validation_error", "Profile has no workflow context")

        from nomotic.workflow_governor import DependencyGraph
        graph = DependencyGraph.from_workflow_context(profile.workflow)

        # Build visualization data
        nodes = sorted(graph._all_steps)
        edges = []
        for from_step, fwd_list in graph._forward.items():
            for to_step, dep_type, desc in fwd_list:
                edges.append({
                    "from": from_step,
                    "to": to_step,
                    "type": dep_type,
                    "description": desc,
                })

        cp = graph.critical_path()
        return 200, _json_bytes({
            "workflow_id": workflow_id,
            "nodes": nodes,
            "edges": edges,
            "critical_path": cp,
        })

    def _handle_workflow_projection(self, ctx: _ServerContext, workflow_id: str) -> tuple[int, bytes]:
        """GET /v1/workflow/{workflow_id}/projection — Projected risks."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Workflow governance requires a GovernanceRuntime")
        if ctx.runtime.workflow_governor is None:
            return _error(404, "not_found", "Workflow Governor is not enabled")

        profile = self._find_workflow_profile(ctx, workflow_id)
        if profile is None:
            return _error(404, "not_found", f"No profile found for workflow: {workflow_id}")

        assessment = ctx.runtime.workflow_governor.assess_workflow(workflow_id, profile)
        return 200, _json_bytes({
            "workflow_id": workflow_id,
            "projected_risks": [r.to_dict() for r in assessment.projected_risks],
            "total": len(assessment.projected_risks),
        })

    def _handle_workflow_drift(self, ctx: _ServerContext, workflow_id: str) -> tuple[int, bytes]:
        """GET /v1/workflow/{workflow_id}/drift — Cross-step drift analysis."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Workflow governance requires a GovernanceRuntime")
        if ctx.runtime.workflow_governor is None:
            return _error(404, "not_found", "Workflow Governor is not enabled")

        profile = self._find_workflow_profile(ctx, workflow_id)
        if profile is None:
            return _error(404, "not_found", f"No profile found for workflow: {workflow_id}")

        drift = ctx.runtime.workflow_governor.detect_cross_step_drift(profile)
        if drift is None:
            return 200, _json_bytes({
                "workflow_id": workflow_id,
                "drift_detected": False,
                "message": "Insufficient data for drift analysis (< 6 completed steps)",
            })
        return 200, _json_bytes(drift.to_dict())

    def _handle_workflow_assess_step(self, ctx: _ServerContext, workflow_id: str) -> tuple[int, bytes]:
        """POST /v1/workflow/{workflow_id}/assess-step — Assess a specific step."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Workflow governance requires a GovernanceRuntime")
        if ctx.runtime.workflow_governor is None:
            return _error(404, "not_found", "Workflow Governor is not enabled")

        data = self._read_json()
        step_number = data.get("step_number")
        method = data.get("method", "unknown")
        target = data.get("target", "unknown")

        if step_number is None:
            return _error(400, "validation_error", "Missing 'step_number' field")

        profile = self._find_workflow_profile(ctx, workflow_id)
        if profile is None:
            return _error(404, "not_found", f"No profile found for workflow: {workflow_id}")

        from nomotic.types import Action, AgentContext
        action = Action(agent_id=profile.agent_id, action_type=method, target=target)
        trust_profile = ctx.runtime.get_trust_profile(profile.agent_id)
        agent_context = AgentContext(
            agent_id=profile.agent_id,
            trust_profile=trust_profile,
        )

        assessment = ctx.runtime.workflow_governor.assess_step(
            step_number, action, agent_context, profile,
        )
        return 200, _json_bytes(assessment.to_dict())

    def _find_workflow_profile(self, ctx: _ServerContext, workflow_id: str) -> Any:
        """Find a context profile by workflow_id."""
        if ctx.runtime is None:
            return None
        profiles = ctx.runtime.context_profiles.list_profiles(active_only=False)
        for p in profiles:
            if p.workflow is not None and p.workflow.workflow_id == workflow_id:
                return p
        return None

    # ── Context Profiles (Phase 7A) ──────────────────────────────────

    def _handle_create_context_profile(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/context — Create a new context profile."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        data = self._read_json()
        agent_id = data.get("agent_id")
        profile_type = data.get("profile_type", "workflow")
        if not agent_id:
            return _error(400, "validation_error", "Missing 'agent_id' field")

        from nomotic.context_profile import (
            WorkflowContext, SituationalContext, RelationalContext,
            TemporalContext, HistoricalContext, InputContext,
            OutputContext, ExternalContext, MetaContext, FeedbackContext,
            JurisdictionalContext,
        )

        kwargs: dict[str, Any] = {}
        _SECTION_MAP = {
            "workflow": WorkflowContext,
            "situational": SituationalContext,
            "relational": RelationalContext,
            "temporal": TemporalContext,
            "historical": HistoricalContext,
            "input_context": InputContext,
            "output": OutputContext,
            "external": ExternalContext,
            "meta": MetaContext,
            "feedback": FeedbackContext,
            "jurisdictional": JurisdictionalContext,
        }
        for key, cls in _SECTION_MAP.items():
            if key in data:
                try:
                    kwargs[key] = cls.from_dict(data[key])
                except (KeyError, TypeError, ValueError) as exc:
                    return _error(400, "validation_error", f"Invalid {key}: {exc}")

        profile = ctx.runtime.context_profiles.create_profile(
            agent_id=agent_id,
            profile_type=profile_type,
            **kwargs,
        )
        return 201, _json_bytes(profile.to_dict())

    def _handle_get_context_profile(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """GET /v1/context/{profile_id} — Retrieve a context profile."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        return 200, _json_bytes(profile.to_dict())

    def _handle_update_context_profile(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """PATCH /v1/context/{profile_id} — Update specific context sections."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")

        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")

        data = self._read_json()

        from nomotic.context_profile import (
            WorkflowContext, SituationalContext, RelationalContext,
            TemporalContext, HistoricalContext, InputContext,
            OutputContext, ExternalContext, MetaContext, FeedbackContext,
            JurisdictionalContext,
        )

        kwargs: dict[str, Any] = {}
        _SECTION_MAP = {
            "workflow": WorkflowContext,
            "situational": SituationalContext,
            "relational": RelationalContext,
            "temporal": TemporalContext,
            "historical": HistoricalContext,
            "input_context": InputContext,
            "output": OutputContext,
            "external": ExternalContext,
            "meta": MetaContext,
            "feedback": FeedbackContext,
            "jurisdictional": JurisdictionalContext,
        }
        for key, cls in _SECTION_MAP.items():
            if key in data:
                try:
                    kwargs[key] = cls.from_dict(data[key])
                except (KeyError, TypeError, ValueError) as exc:
                    return _error(400, "validation_error", f"Invalid {key}: {exc}")

        updated = ctx.runtime.context_profiles.update_profile(profile_id, **kwargs)
        if updated is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        return 200, _json_bytes(updated.to_dict())

    def _handle_context_summary(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """GET /v1/context/{profile_id}/summary — Compact summary."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        return 200, _json_bytes(profile.summary())

    def _handle_context_risks(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """GET /v1/context/{profile_id}/risks — Risk signals."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        signals = profile.risk_signals()
        return 200, _json_bytes({"profile_id": profile_id, "risk_signals": signals, "count": len(signals)})

    def _handle_context_workflow_step(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """POST /v1/context/{profile_id}/workflow/step — Record a completed workflow step."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        if profile.workflow is None:
            return _error(400, "validation_error", "Profile has no workflow context")

        data = self._read_json()
        from nomotic.context_profile import CompletedStep
        try:
            step = CompletedStep.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid step: {exc}")

        profile.update_workflow_step(step)
        return 200, _json_bytes(profile.workflow.to_dict())

    def _handle_context_feedback(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """POST /v1/context/{profile_id}/feedback — Add feedback."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")

        data = self._read_json()
        from nomotic.context_profile import FeedbackRecord
        try:
            feedback = FeedbackRecord.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid feedback: {exc}")

        profile.add_feedback(feedback)
        return 200, _json_bytes({"added": True, "feedback_count": len(profile.feedback.feedback_received)})

    def _handle_context_signal(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """POST /v1/context/{profile_id}/signal — Add external signal."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")

        data = self._read_json()
        from nomotic.context_profile import ExternalSignal
        try:
            signal = ExternalSignal.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid signal: {exc}")

        profile.add_external_signal(signal)
        return 200, _json_bytes({"added": True, "signal_count": len(profile.external.external_signals)})

    def _handle_context_modifications(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """GET /v1/context/{profile_id}/modifications — Preview contextual modifications.

        Takes optional query params: method, target to construct a hypothetical action.
        """
        if ctx.runtime is None:
            return _error(404, "not_found", "Context modifications require a GovernanceRuntime")
        if ctx.runtime.contextual_modifier is None:
            return _error(404, "not_found", "Contextual modifier is not enabled")
        profile = ctx.runtime.context_profiles.get_profile(profile_id)
        if profile is None:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")

        params = self._query_params()
        action_method = params.get("method", "unknown")
        action_target = params.get("target", "unknown")

        from nomotic.types import Action, AgentContext
        action = Action(
            agent_id=profile.agent_id,
            action_type=action_method,
            target=action_target,
        )
        trust_profile = ctx.runtime.get_trust_profile(profile.agent_id)
        agent_context = AgentContext(
            agent_id=profile.agent_id,
            trust_profile=trust_profile,
            context_profile_id=profile_id,
        )
        modification = ctx.runtime.contextual_modifier.modify(action, agent_context, profile)
        return 200, _json_bytes(modification.to_dict())

    def _handle_close_context_profile(self, ctx: _ServerContext, profile_id: str) -> tuple[int, bytes]:
        """DELETE /v1/context/{profile_id} — Close/archive a profile."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        closed = ctx.runtime.context_profiles.close_profile(profile_id)
        if not closed:
            return _error(404, "not_found", f"Context profile not found: {profile_id}")
        return 200, _json_bytes({"closed": True, "profile_id": profile_id})

    # ── Phase 8: Ethical Governance Infrastructure ──────────────────────

    def _handle_equity_report(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/equity/report — Run equity analysis."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Equity analysis requires a GovernanceRuntime")
        if ctx.runtime.equity_analyzer is None:
            return _error(404, "not_found", "Equity analysis not configured (provide equity_config)")
        params = self._query_params()
        agent_id = params.get("agent_id")
        method = params.get("method")
        window_hours = None
        if "window_hours" in params:
            try:
                window_hours = int(params["window_hours"])
            except ValueError:
                pass
        try:
            report = ctx.runtime.run_equity_analysis(
                agent_id=agent_id, method=method, window_hours=window_hours,
            )
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(report.to_dict())

    def _handle_equity_config_get(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/equity/config — Current equity configuration."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Equity config requires a GovernanceRuntime")
        if ctx.runtime.equity_analyzer is None:
            return _error(404, "not_found", "Equity analysis not configured")
        return 200, _json_bytes(ctx.runtime.equity_analyzer.config.to_dict())

    def _handle_equity_config_put(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """PUT /v1/equity/config — Update equity configuration."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Equity config requires a GovernanceRuntime")
        if ctx.runtime.equity_analyzer is None:
            return _error(404, "not_found", "Equity analysis not configured")
        data = self._read_json()
        from nomotic.equity import EquityConfig
        try:
            config = EquityConfig.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid equity config: {exc}")
        ctx.runtime.equity_analyzer.update_config(config)
        # Record provenance
        if hasattr(ctx.runtime, '_record_provenance'):
            ctx.runtime._record_provenance(
                actor="api",
                target_type="equity_config",
                target_id="equity",
                change_type="modify",
                new_value=data,
                reason="Updated via API",
                context_code="CONFIG.THRESHOLD_CHANGED",
            )
        return 200, _json_bytes(config.to_dict())

    def _handle_bias_report(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/bias/report — Run governance bias assessment."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Bias detection requires a GovernanceRuntime")
        if ctx.runtime.bias_detector is None:
            return _error(404, "not_found", "Bias detection not configured (provide equity_config)")
        try:
            report = ctx.runtime.run_bias_assessment()
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(report.to_dict())

    def _handle_ethics_reasoning(self, ctx: _ServerContext, artifact_id: str) -> tuple[int, bytes]:
        """GET /v1/ethics/reasoning/{artifact_id} — Ethical reasoning assessment."""
        if ctx.evaluator is None:
            return _error(404, "not_found", "Protocol evaluator not configured")
        if ctx.evaluator._ethical_reasoning_config is None:
            return _error(404, "not_found", "Ethical reasoning evaluation not configured")
        # Look up artifact by hash
        artifact = ctx.evaluator._artifact_store.get(artifact_id)
        if artifact is None:
            return _error(404, "not_found", f"Artifact not found: {artifact_id}")
        assessment = ctx.evaluator._assess_ethical_reasoning(
            artifact, ctx.evaluator._ethical_reasoning_config,
        )
        return 200, _json_bytes(assessment.to_dict())

    def _handle_cross_dimensional_signals(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/signals/cross-dimensional — Aggregate cross-dimensional signals."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Cross-dimensional analysis requires a GovernanceRuntime")
        if ctx.runtime.cross_dimensional_detector is None:
            return _error(404, "not_found", "Cross-dimensional detection not enabled")
        params = self._query_params()
        agent_id = params.get("agent_id")
        window_hours = 168
        if "window_hours" in params:
            try:
                window_hours = int(params["window_hours"])
            except ValueError:
                pass
        try:
            report = ctx.runtime.get_cross_dimensional_signals(
                agent_id=agent_id, window_hours=window_hours,
            )
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 200, _json_bytes(report.to_dict())

    def _handle_list_patterns(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/signals/patterns — List active cross-dimensional patterns."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Patterns require a GovernanceRuntime")
        if ctx.runtime.cross_dimensional_detector is None:
            return _error(404, "not_found", "Cross-dimensional detection not enabled")
        patterns = ctx.runtime.cross_dimensional_detector.list_patterns()
        return 200, _json_bytes({"patterns": patterns, "total": len(patterns)})

    def _handle_add_pattern(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/signals/patterns — Add custom cross-dimensional pattern."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Patterns require a GovernanceRuntime")
        if ctx.runtime.cross_dimensional_detector is None:
            return _error(404, "not_found", "Cross-dimensional detection not enabled")
        data = self._read_json()
        try:
            ctx.runtime.cross_dimensional_detector.add_pattern(data)
        except ValueError as exc:
            return _error(400, "validation_error", str(exc))
        return 201, _json_bytes({"added": True, "pattern": data.get("name", "")})

    def _handle_anonymization_policy_get(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/anonymization/policy — Current anonymization policy."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Anonymization requires a GovernanceRuntime")
        if ctx.runtime.anonymization_policy is None:
            return 200, _json_bytes({"rules": [], "default_hide": False})
        return 200, _json_bytes(ctx.runtime.anonymization_policy.to_dict())

    def _handle_anonymization_policy_put(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """PUT /v1/anonymization/policy — Update anonymization policy."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Anonymization requires a GovernanceRuntime")
        data = self._read_json()
        from nomotic.equity import AnonymizationPolicy
        try:
            policy = AnonymizationPolicy.from_dict(data)
        except (KeyError, TypeError, ValueError) as exc:
            return _error(400, "validation_error", f"Invalid anonymization policy: {exc}")
        ctx.runtime.anonymization_policy = policy
        # Record provenance
        if hasattr(ctx.runtime, '_record_provenance'):
            ctx.runtime._record_provenance(
                actor="api",
                target_type="anonymization_policy",
                target_id="anonymization",
                change_type="modify",
                new_value=data,
                reason="Updated via API",
                context_code="CONFIG.THRESHOLD_CHANGED",
            )
        return 200, _json_bytes(policy.to_dict())

    def _handle_list_context_profiles(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/context — List profiles with filters."""
        if ctx.runtime is None:
            return _error(404, "not_found", "Context profiles require a GovernanceRuntime")
        params = self._query_params()
        agent_id = params.get("agent_id")
        profile_type = params.get("profile_type")
        active_str = params.get("active", "true")
        active_only = active_str.lower() != "false"
        profiles = ctx.runtime.context_profiles.list_profiles(
            agent_id=agent_id,
            profile_type=profile_type,
            active_only=active_only,
        )
        return 200, _json_bytes({
            "profiles": [p.summary() for p in profiles],
            "total": len(profiles),
        })

    # ── Persistent audit API (Phase 10A) ─────────────────────────────

    def _resolve_audit_agent(self, identifier: str) -> str:
        """Resolve a URL path segment to an agent name for audit lookup.

        Case-insensitive.  Accepts agent name or cert-id.
        Returns the agent name (as stored in certs) for audit file lookup.
        """
        ctx = self.server.ctx
        if identifier.startswith("nmc-"):
            cert = ctx.ca.get(identifier) if ctx.ca else None
            if cert:
                return cert.agent_id
            return identifier
        return identifier

    def _handle_audit_agent_records(
        self, ctx: _ServerContext, identifier: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        from nomotic.audit_store import AuditStore

        agent_id = self._resolve_audit_agent(identifier)
        store = AuditStore(ctx.base_dir)

        params = self._query_params()
        limit = min(int(params.get("limit", "20")), 500)
        severity = params.get("severity")
        fmt = params.get("format", "json")

        records = store.query(agent_id, limit=limit, severity=severity)

        since = params.get("since")
        if since:
            try:
                since_ts = float(since)
                records = [r for r in records if r.timestamp > since_ts]
            except ValueError:
                pass

        if fmt == "jsonl":
            lines = [json.dumps(r.to_dict(), separators=(",", ":")) for r in records]
            body = ("\n".join(lines) + "\n").encode("utf-8") if lines else b""
            return 200, body, "application/x-ndjson"

        return 200, _json_bytes({
            "agent_id": agent_id,
            "records": [r.to_dict() for r in records],
            "total": len(records),
            "chain_fields_included": True,
        })

    def _handle_audit_agent_summary(
        self, ctx: _ServerContext, identifier: str,
    ) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore

        agent_id = self._resolve_audit_agent(identifier)
        store = AuditStore(ctx.base_dir)
        summary = store.summary(agent_id)

        if summary.get("total", 0) == 0:
            return _error(404, "not_found", f"No audit records found for '{agent_id}'")

        summary["agent_id"] = agent_id
        return 200, _json_bytes(summary)

    def _handle_audit_agent_verify(
        self, ctx: _ServerContext, identifier: str,
    ) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore

        agent_id = self._resolve_audit_agent(identifier)
        store = AuditStore(ctx.base_dir)

        is_valid, count, message = store.verify_chain(agent_id)

        if count == 0:
            return _error(404, "not_found", f"No audit records found for '{agent_id}'")

        result: dict[str, Any] = {
            "agent_id": agent_id,
            "valid": is_valid,
            "record_count": count,
            "message": message,
            "verified_at": datetime.now(timezone.utc).isoformat(),
        }

        if is_valid:
            records = store.query_all(agent_id)
            result["chain_head"] = records[-1].record_hash if records else ""

        return 200, _json_bytes(result)

    def _handle_audit_agent_export(
        self, ctx: _ServerContext, identifier: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        from nomotic.audit_store import AuditStore

        agent_id = self._resolve_audit_agent(identifier)
        store = AuditStore(ctx.base_dir)

        records = store.query_all(agent_id)
        if not records:
            return _error(404, "not_found", f"No audit records found for '{agent_id}'")

        lines = [json.dumps(r.to_dict(), separators=(",", ":")) for r in records]
        body = ("\n".join(lines) + "\n").encode("utf-8")
        return 200, body, "application/x-ndjson"

    def _handle_audit_agent_seal(
        self, ctx: _ServerContext, identifier: str,
    ) -> tuple[int, bytes]:
        agent_id = self._resolve_audit_agent(identifier)

        revocations_dir = ctx.base_dir / "revocations"
        if not revocations_dir.exists():
            return _error(404, "not_found", "Agent is not revoked or no seal found")

        for rev_file in revocations_dir.glob("*.json"):
            try:
                data = json.loads(rev_file.read_text(encoding="utf-8"))
                if data.get("agent_name", "").lower() == agent_id.lower():
                    from nomotic.audit_store import AuditStore

                    store = AuditStore(ctx.base_dir)
                    is_valid, _, _ = store.verify_chain(agent_id)
                    data["chain_valid"] = is_valid
                    return 200, _json_bytes(data)
            except (json.JSONDecodeError, KeyError):
                continue

        return _error(404, "not_found", "Agent is not revoked or no seal found")

    # ── Shared log handlers (audit + testlog) ────────────────────────

    def _handle_log_records(
        self, ctx: _ServerContext, identifier: str, log_type: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        from nomotic.audit_store import LogStore

        agent_id = self._resolve_audit_agent(identifier)
        store = LogStore(ctx.base_dir, log_type)

        params = self._query_params()
        limit = min(int(params.get("limit", "20")), 500)
        severity = params.get("severity")
        fmt = params.get("format", "json")

        records = store.query(agent_id, limit=limit, severity=severity)

        since = params.get("since")
        if since:
            try:
                since_ts = float(since)
                records = [r for r in records if r.timestamp > since_ts]
            except ValueError:
                pass

        if fmt == "jsonl":
            lines = [json.dumps(r.to_dict(), separators=(",", ":")) for r in records]
            body = ("\n".join(lines) + "\n").encode("utf-8") if lines else b""
            return 200, body, "application/x-ndjson"

        return 200, _json_bytes({
            "agent_id": agent_id,
            "log_type": log_type,
            "records": [r.to_dict() for r in records],
            "total": len(records),
            "chain_fields_included": True,
        })

    def _handle_log_summary(
        self, ctx: _ServerContext, identifier: str, log_type: str,
    ) -> tuple[int, bytes]:
        from nomotic.audit_store import LogStore

        agent_id = self._resolve_audit_agent(identifier)
        store = LogStore(ctx.base_dir, log_type)
        summary = store.summary(agent_id)

        if summary.get("total", 0) == 0:
            return _error(404, "not_found", f"No {log_type} records found for '{agent_id}'")

        summary["agent_id"] = agent_id
        summary["log_type"] = log_type
        return 200, _json_bytes(summary)

    def _handle_log_verify(
        self, ctx: _ServerContext, identifier: str, log_type: str,
    ) -> tuple[int, bytes]:
        from nomotic.audit_store import LogStore

        agent_id = self._resolve_audit_agent(identifier)
        store = LogStore(ctx.base_dir, log_type)

        is_valid, count, message = store.verify_chain(agent_id)

        if count == 0:
            return _error(404, "not_found", f"No {log_type} records found for '{agent_id}'")

        result: dict[str, Any] = {
            "agent_id": agent_id,
            "log_type": log_type,
            "valid": is_valid,
            "record_count": count,
            "message": message,
            "verified_at": datetime.now(timezone.utc).isoformat(),
        }

        if is_valid:
            records = store.query_all(agent_id)
            result["chain_head"] = records[-1].record_hash if records else ""

        return 200, _json_bytes(result)

    def _handle_log_export(
        self, ctx: _ServerContext, identifier: str, log_type: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        from nomotic.audit_store import LogStore

        agent_id = self._resolve_audit_agent(identifier)
        store = LogStore(ctx.base_dir, log_type)

        records = store.query_all(agent_id)
        if not records:
            return _error(404, "not_found", f"No {log_type} records found for '{agent_id}'")

        lines = [json.dumps(r.to_dict(), separators=(",", ":")) for r in records]
        body = ("\n".join(lines) + "\n").encode("utf-8")
        return 200, body, "application/x-ndjson"

    # ── Human Engagement handlers ──────────────────────────────────

    def _handle_human_engagement(
        self, ctx: _ServerContext, reviewer_id: str,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import HumanAuditStore, HumanInteractionProfile

        store = HumanAuditStore(ctx.base_dir)
        events = store.query_all(reviewer_id)
        if not events:
            return _error(404, "not_found", f"No events found for reviewer '{reviewer_id}'")

        profile = HumanInteractionProfile.from_events(reviewer_id, events)
        return 200, _json_bytes({
            "reviewer_id": reviewer_id,
            "profile": profile.to_dict(),
            "total_events": len(events),
        })

    def _handle_human_engagement_drift(
        self, ctx: _ServerContext, reviewer_id: str,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import (
            HumanAuditStore,
            HumanDriftCalculator,
            HumanInteractionProfile,
        )

        store = HumanAuditStore(ctx.base_dir)
        events = store.query_all(reviewer_id)
        if not events:
            return _error(404, "not_found", f"No events found for reviewer '{reviewer_id}'")

        # Need enough events for baseline + recent
        baseline_window = 200
        recent_window = 50
        if len(events) < baseline_window + recent_window:
            return _error(400, "insufficient_data", (
                f"Need at least {baseline_window + recent_window} events for drift analysis. "
                f"Have {len(events)}."
            ))

        baseline = HumanInteractionProfile.from_events(
            reviewer_id, events[:baseline_window]
        )
        recent = HumanInteractionProfile.from_events(
            reviewer_id, events[-recent_window:]
        )

        calculator = HumanDriftCalculator()
        result = calculator.calculate(baseline, recent)

        return 200, _json_bytes({
            "reviewer_id": reviewer_id,
            "drift": result.to_dict(),
            "baseline_profile": baseline.to_dict(),
            "recent_profile": recent.to_dict(),
        })

    def _handle_human_engagement_event(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import HumanAuditStore, HumanInteractionEvent

        body = self._read_json()
        required = {"reviewer_id", "agent_id", "action_id", "event_type", "decision",
                     "review_duration_seconds"}
        missing = required - set(body.keys())
        if missing:
            return _error(400, "missing_fields", f"Missing required fields: {missing}")

        event = HumanInteractionEvent(
            timestamp=body.get("timestamp", time.time()),
            reviewer_id=body["reviewer_id"],
            agent_id=body["agent_id"],
            action_id=body["action_id"],
            event_type=body["event_type"],
            decision=body["decision"],
            review_duration_seconds=float(body["review_duration_seconds"]),
            rationale=body.get("rationale", ""),
            rationale_depth=body.get("rationale_depth", len(body.get("rationale", "").split()) if body.get("rationale") else 0),
            context_viewed=body.get("context_viewed", False),
            modifications=body.get("modifications", []),
        )

        store = HumanAuditStore(ctx.base_dir)
        store.append(event)

        return 201, _json_bytes({
            "status": "recorded",
            "event": event.to_dict(),
        })

    def _handle_human_engagement_alerts(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import (
            HumanAuditStore,
            HumanDriftCalculator,
            HumanInteractionProfile,
        )

        store = HumanAuditStore(ctx.base_dir)
        reviewers = store.list_reviewers()
        all_alerts: list[dict[str, Any]] = []
        baseline_window = 200
        recent_window = 50

        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            if len(events) < baseline_window + recent_window:
                continue
            baseline = HumanInteractionProfile.from_events(
                reviewer_id, events[:baseline_window]
            )
            recent = HumanInteractionProfile.from_events(
                reviewer_id, events[-recent_window:]
            )
            calculator = HumanDriftCalculator()
            result = calculator.calculate(baseline, recent)
            if result.alerts:
                all_alerts.append(result.to_dict())

        return 200, _json_bytes({
            "alerts": all_alerts,
            "reviewers_checked": len(reviewers),
        })

    def _handle_human_engagement_team(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import (
            HumanAuditStore,
            HumanDriftMonitor,
            TeamOversightMetrics,
        )

        store = HumanAuditStore(ctx.base_dir)
        reviewers = store.list_reviewers()
        if not reviewers:
            return 200, _json_bytes({"total_reviewers": 0})

        monitor = HumanDriftMonitor()
        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            for event in events:
                monitor.record_event(event)

        metrics = TeamOversightMetrics(monitor).compute()
        return 200, _json_bytes(metrics)

    def _handle_human_engagement_routing(
        self, ctx: _ServerContext, reviewer_id: str,
    ) -> tuple[int, bytes]:
        from nomotic.human_drift import (
            HumanAuditStore,
            HumanDriftCalculator,
            HumanInteractionProfile,
            RoutingRecommendation,
        )

        store = HumanAuditStore(ctx.base_dir)
        events = store.query_all(reviewer_id)
        if not events:
            return _error(404, "not_found", f"No events found for reviewer '{reviewer_id}'")

        baseline_window = 200
        recent_window = 50
        if len(events) < baseline_window + recent_window:
            return 200, _json_bytes({
                "recommendation": "no_change",
                "reason": "Insufficient data for drift analysis",
                "urgency": "low",
                "suggested_for": "none",
            })

        baseline = HumanInteractionProfile.from_events(
            reviewer_id, events[:baseline_window]
        )
        recent = HumanInteractionProfile.from_events(
            reviewer_id, events[-recent_window:]
        )

        calculator = HumanDriftCalculator()
        result = calculator.calculate(baseline, recent)
        rec = RoutingRecommendation.from_drift_result(result)

        return 200, _json_bytes(rec.to_dict())


    # ── Pre-Execution Budget Gate API (Item 17) ────────────────────

    def _handle_budget_group_status(
        self, ctx: _ServerContext, group_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/budget/groups/{group_id}/status"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_budget_gate", None) is None:
            return _error(503, "no_budget_gate", "Budget gate not configured")
        gate = runtime._budget_gate
        spend = gate.get_current_spend(group_id)
        limit = gate._limits.get(group_id)
        active = gate.get_active_reservations(group_id)
        return 200, _json_bytes({
            "group_id": group_id,
            "daily_used_usd": spend["daily_usd"],
            "monthly_used_usd": spend["monthly_usd"],
            "daily_limit_usd": limit.daily_limit_usd if limit else None,
            "monthly_limit_usd": limit.monthly_limit_usd if limit else None,
            "per_action_limit_usd": limit.per_action_limit_usd if limit else None,
            "active_reservation_count": len(active),
        })

    def _handle_budget_reservations(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/budget/reservations"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_budget_gate", None) is None:
            return _error(503, "no_budget_gate", "Budget gate not configured")
        gate = runtime._budget_gate
        params = self._query_params()
        group_id = params.get("group_id")
        reservations = gate.get_active_reservations(group_id)
        return 200, _json_bytes([r.to_dict() for r in reservations])

    def _handle_budget_settle(
        self, ctx: _ServerContext, reservation_id: str,
    ) -> tuple[int, bytes]:
        """POST /v1/budget/reservations/{id}/settle"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_budget_gate", None) is None:
            return _error(503, "no_budget_gate", "Budget gate not configured")
        gate = runtime._budget_gate
        body = self._read_json()
        actual_cost = body.get("actual_cost_usd")
        if actual_cost is None:
            return _error(400, "validation_error", "actual_cost_usd is required")
        try:
            gate.settle(reservation_id, float(actual_cost))
        except ValueError as exc:
            return _error(404, "not_found", str(exc))
        return 200, _json_bytes({"settled": True, "reservation_id": reservation_id})

    # ── Immutable Pre-Execution Record API (Item 18) ─────────────

    def _handle_pre_exec_records(
        self, ctx: _ServerContext, agent_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/pre-execution/{agent_id}/records"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_pre_execution_ledger", None) is None:
            return _error(503, "no_pre_execution_ledger", "Pre-execution ledger not configured")
        ledger = runtime._pre_execution_ledger
        params = self._query_params()
        limit = int(params.get("limit", "20"))
        unsettled_only = params.get("unsettled_only", "").lower() in ("true", "1", "yes")
        if unsettled_only:
            records = ledger.get_unsettled(agent_id=agent_id)
            records = records[:limit]
        else:
            records = ledger.get_agent_records(agent_id, limit=limit)
        return 200, _json_bytes([r.to_dict() for r in records])

    def _handle_pre_exec_unsettled(
        self, ctx: _ServerContext, agent_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/pre-execution/{agent_id}/unsettled"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_pre_execution_ledger", None) is None:
            return _error(503, "no_pre_execution_ledger", "Pre-execution ledger not configured")
        ledger = runtime._pre_execution_ledger
        records = ledger.get_unsettled(agent_id=agent_id)
        return 200, _json_bytes([r.to_dict() for r in records])

    def _handle_pre_exec_verify(
        self, ctx: _ServerContext, agent_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/pre-execution/{agent_id}/verify"""
        runtime = ctx.runtime
        if runtime is None or getattr(runtime, "_pre_execution_ledger", None) is None:
            return _error(503, "no_pre_execution_ledger", "Pre-execution ledger not configured")
        ledger = runtime._pre_execution_ledger
        valid, count, message = ledger.verify_chain(agent_id)
        return 200, _json_bytes({
            "valid": valid,
            "record_count": count,
            "message": message,
        })

    # ── Fleet Governance API ──────────────────────────────────────

    def _handle_fleet_health(self, ctx: _ServerContext) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        return 200, _json_bytes(fleet.health_summary().to_dict())

    def _handle_fleet_trust(self, ctx: _ServerContext) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        return 200, _json_bytes(fleet.trust_distribution())

    def _handle_fleet_denials(self, ctx: _ServerContext) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        params = self._query_params()
        limit = int(params.get("limit", "10"))
        results = fleet.top_denied_action_types(limit=limit)
        return 200, _json_bytes([r.to_dict() for r in results])

    def _handle_fleet_critical(self, ctx: _ServerContext) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        results = fleet.critical_agents()
        return 200, _json_bytes([r.to_dict() for r in results])

    def _handle_fleet_agents(self, ctx: _ServerContext) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        agents = []
        for agent_id in store.list_agents():
            record = fleet.get_agent_record(agent_id)
            if record is not None:
                agents.append(record.to_dict())
        return 200, _json_bytes(agents)

    def _handle_fleet_agent(
        self, ctx: _ServerContext, agent_id: str,
    ) -> tuple[int, bytes]:
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        record = fleet.get_agent_record(agent_id)
        if record is None:
            return _error(404, "not_found", f"No records found for agent '{agent_id}'")
        return 200, _json_bytes(record.to_dict())


    # ── Constitutional Rules API ──────────────────────────────────

    def _handle_constitution_list_rules(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/constitution/rules — list all active constitutional rules."""
        runtime = ctx.runtime
        if runtime is None:
            return _error(503, "no_runtime", "Governance runtime not configured")
        engine = getattr(runtime, "_constitutional_engine", None)
        if engine is None or not engine.has_rules():
            return 200, _json_bytes({"rules": [], "count": 0})
        ruleset = engine._ruleset
        rules = [r.to_dict() for r in ruleset.rules]
        return 200, _json_bytes({
            "rules": rules,
            "count": len(rules),
            "ruleset_id": ruleset.ruleset_id,
            "signed_by": ruleset.signed_by,
        })

    def _handle_constitution_get_rule(
        self, ctx: _ServerContext, rule_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/constitution/rules/{rule_id} — get single rule detail."""
        runtime = ctx.runtime
        if runtime is None:
            return _error(503, "no_runtime", "Governance runtime not configured")
        engine = getattr(runtime, "_constitutional_engine", None)
        if engine is None or not engine.has_rules():
            return _error(404, "not_found", f"Rule {rule_id} not found")
        for rule in engine._ruleset.rules:
            if rule.rule_id == rule_id:
                return 200, _json_bytes(rule.to_dict())
        return _error(404, "not_found", f"Rule {rule_id} not found")

    def _handle_constitution_verify(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/constitution/verify — verify ruleset signature."""
        body = self._read_json()
        ruleset_data = body.get("ruleset")
        if not ruleset_data:
            return _error(400, "bad_request", "Missing 'ruleset' in request body")
        try:
            from nomotic.constitution import ConstitutionalRuleSet
            ruleset = ConstitutionalRuleSet.from_dict(ruleset_data)
        except Exception as exc:
            return _error(400, "bad_request", f"Invalid ruleset: {exc}")

        # Use CA verify key for verification
        verify_key_bytes: bytes | None = None
        if ctx.ca is not None:
            try:
                verify_key_bytes = ctx.ca._verify_key.to_bytes()
            except Exception:
                pass

        if verify_key_bytes is None:
            return _error(
                503, "no_verify_key",
                "No CA verify key available for signature verification",
            )

        valid = ruleset.verify_signature(verify_key_bytes)
        return 200, _json_bytes({
            "valid": valid,
            "rule_count": len(ruleset.rules),
            "signed_by": ruleset.signed_by,
        })

    # ── Governance Authority Registry (Item 15) ────────────────────

    def _get_authority_registry(self, ctx: _ServerContext) -> tuple[Any, tuple[int, bytes] | None]:
        """Return (registry, None) or (None, error_response)."""
        runtime = ctx.runtime
        if runtime is None:
            return None, _error(503, "no_runtime", "Governance runtime not configured")
        registry = getattr(runtime, "_authority_registry", None)
        if registry is None:
            return None, _error(503, "no_authority_registry", "Authority registry not configured")
        return registry, None

    def _handle_authority_registry_list(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/authority-registry/authorities — list registered authorities."""
        registry, err = self._get_authority_registry(ctx)
        if err is not None:
            return err
        authorities = registry.list_authorities()
        return 200, _json_bytes({
            "authorities": [a.to_dict() for a in authorities],
            "count": len(authorities),
        })

    def _handle_authority_registry_register(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/authority-registry/authorities — register new authority."""
        registry, err = self._get_authority_registry(ctx)
        if err is not None:
            return err
        data = self._read_json()
        authority_data = data.get("authority")
        registering_id = data.get("registering_authority_id", "")
        reason = data.get("reason", "")
        if not authority_data:
            return _error(400, "bad_request", "Missing 'authority' in request body")
        if not registering_id:
            return _error(400, "bad_request", "Missing 'registering_authority_id'")
        try:
            from nomotic.authority_registry import GovernanceAuthority
            authority = GovernanceAuthority.from_dict(authority_data)
            registry.register_authority(authority, registering_id, reason)
        except (ValueError, KeyError) as exc:
            return _error(400, "bad_request", str(exc))
        except Exception as exc:
            err_type = type(exc).__name__
            if err_type == "UnauthorizedGovernanceChange":
                return _error(403, "unauthorized", str(exc))
            raise
        return 201, _json_bytes(authority.to_dict())

    def _handle_authority_registry_revoke(
        self, ctx: _ServerContext, authority_id: str,
    ) -> tuple[int, bytes]:
        """DELETE /v1/authority-registry/authorities/{id} — revoke authority."""
        registry, err = self._get_authority_registry(ctx)
        if err is not None:
            return err
        data = self._read_json()
        revoking_id = data.get("revoking_authority_id", "")
        reason = data.get("reason", "")
        if not revoking_id:
            return _error(400, "bad_request", "Missing 'revoking_authority_id'")
        try:
            registry.revoke_authority(authority_id, revoking_id, reason)
        except KeyError as exc:
            return _error(404, "not_found", str(exc))
        except Exception as exc:
            err_type = type(exc).__name__
            if err_type == "UnauthorizedGovernanceChange":
                return _error(403, "unauthorized", str(exc))
            raise
        return 200, _json_bytes({"revoked": authority_id})

    def _handle_authority_registry_changes(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/authority-registry/changes — get change history."""
        registry, err = self._get_authority_registry(ctx)
        if err is not None:
            return err
        params = self._query_params()
        authority_id = params.get("authority_id")
        limit = int(params.get("limit", "50"))
        records = registry.get_change_history(authority_id=authority_id, limit=limit)
        return 200, _json_bytes({
            "changes": [r.to_dict() for r in records],
            "count": len(records),
        })

    def _handle_authority_registry_bootstrap(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """POST /v1/authority-registry/bootstrap — bootstrap first authority."""
        registry, err = self._get_authority_registry(ctx)
        if err is not None:
            return err
        data = self._read_json()
        authority_id = data.get("authority_id", "")
        name = data.get("name", "")
        if not authority_id or not name:
            return _error(400, "bad_request", "Missing 'authority_id' or 'name'")
        try:
            authority = registry.bootstrap(authority_id, name)
        except RuntimeError:
            return _error(409, "conflict", "Registry already bootstrapped")
        return 201, _json_bytes(authority.to_dict())

    # ── Dashboard UI handlers (F-01) ──────────────────────────────

    def _serve_static(
        self, file_path: Path, content_type: str | None = None,
    ) -> tuple[int, bytes, str]:
        """Serve a static file from the UI directory."""
        try:
            # Resolve to prevent path traversal
            resolved = file_path.resolve()
            ui_dir = self.server.ctx.ui_dir.resolve()
            if not str(resolved).startswith(str(ui_dir)):
                return 403, b"Forbidden", "text/plain"
            if not resolved.is_file():
                return 404, b"Not Found", "text/plain"
            body = resolved.read_bytes()
        except (OSError, ValueError):
            return 404, b"Not Found", "text/plain"

        if content_type is None:
            ext = resolved.suffix.lower()
            content_type = {
                ".html": "text/html",
                ".css": "text/css",
                ".js": "application/javascript",
                ".json": "application/json",
                ".png": "image/png",
                ".svg": "image/svg+xml",
                ".ico": "image/x-icon",
            }.get(ext, "application/octet-stream")

        return 200, body, content_type

    def _handle_ui_overview(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/ui/overview — overview stats for the dashboard strip."""
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()

        # Compute allow:deny ratio from today's evaluations
        allow_count = summary.total_evaluations_24h - int(
            summary.fleet_denial_rate * summary.total_evaluations_24h
        )
        deny_count = summary.total_evaluations_24h - allow_count
        if summary.total_evaluations_24h > 0:
            allow_pct = round(100 * allow_count / summary.total_evaluations_24h)
            deny_pct = 100 - allow_pct
            ratio = f"{allow_pct}:{deny_pct}"
        else:
            ratio = "0:0"

        return 200, _json_bytes({
            "active_agents": summary.active_agents,
            "evaluations_today": summary.total_evaluations_24h,
            "allow_deny_ratio": ratio,
            "open_approvals": len(ctx.runtime.get_pending_overrides()) if ctx.runtime else 0,
        })

    def _handle_ui_feed(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/ui/feed — last 50 evaluation verdicts."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(ctx.base_dir)
        items = []
        for agent_id in store.list_agents():
            for r in store.query(agent_id, limit=50):
                items.append({
                    "timestamp": datetime.fromtimestamp(
                        r.timestamp, tz=timezone.utc
                    ).isoformat(),
                    "agent_id": r.agent_id,
                    "archetype": r.parameters.get("archetype", ""),
                    "action_type": r.action_type,
                    "verdict": r.verdict,
                    "ucs_score": r.ucs,
                    "latency_ms": r.parameters.get("latency_ms", 0.0),
                    "record_id": r.record_id,
                })
        # Sort newest first, limit to 50
        items.sort(key=lambda x: x["timestamp"], reverse=True)
        return 200, _json_bytes(items[:50])

    def _handle_ui_events(self, ctx: _ServerContext) -> tuple[int, bytes, str]:
        """GET /v1/ui/events — Server-Sent Events stream.

        Returns initial overview data as an SSE event.
        For a full streaming implementation, this would keep the
        connection open with heartbeats.
        """
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()

        allow_count = summary.total_evaluations_24h - int(
            summary.fleet_denial_rate * summary.total_evaluations_24h
        )
        deny_count = summary.total_evaluations_24h - allow_count
        if summary.total_evaluations_24h > 0:
            allow_pct = round(100 * allow_count / summary.total_evaluations_24h)
            deny_pct = 100 - allow_pct
            ratio = f"{allow_pct}:{deny_pct}"
        else:
            ratio = "0:0"

        overview = {
            "active_agents": summary.active_agents,
            "evaluations_today": summary.total_evaluations_24h,
            "allow_deny_ratio": ratio,
            "open_approvals": len(ctx.runtime.get_pending_overrides()) if ctx.runtime else 0,
        }

        sse_payload = f"event: overview\ndata: {json.dumps(overview)}\n\n"
        return 200, sse_payload.encode("utf-8"), "text/event-stream"

    def _handle_ui_panel_feed(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str]:
        """GET /v1/ui/panels/evaluation-feed — HTML feed with clickable rows."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(ctx.base_dir)
        items = []
        for agent_id in store.list_agents():
            for r in store.query(agent_id, limit=50):
                items.append({
                    "timestamp": datetime.fromtimestamp(
                        r.timestamp, tz=timezone.utc,
                    ).strftime("%H:%M:%S"),
                    "agent_id": r.agent_id,
                    "action_type": r.action_type,
                    "verdict": r.verdict,
                    "ucs": f"{r.ucs:.2f}",
                    "record_id": r.record_id,
                })
        items.sort(key=lambda x: x["timestamp"], reverse=True)
        items = items[:50]

        if not items:
            html = ('<div class="empty-state">No evaluations recorded '
                    '&mdash; run hello_nomotic.py to see governance in action</div>')
            return 200, html.encode("utf-8"), "text/html"

        rows: list[str] = []
        for item in items:
            vcls = f'verdict-{item["verdict"].lower()}'
            rows.append(
                f'<tr hx-get="/v1/ui/verdict/{item["record_id"]}" '
                f'hx-target="#verdict-detail-panel" hx-swap="innerHTML" '
                f'style="cursor:pointer;">'
                f'<td>{item["timestamp"]}</td>'
                f'<td>{item["agent_id"]}</td>'
                f'<td>{item["action_type"]}</td>'
                f'<td><span class="{vcls}">{item["verdict"]}</span></td>'
                f'<td>{item["ucs"]}</td>'
                f'</tr>'
            )

        html = (
            '<table class="feed-table">'
            '<thead><tr>'
            '<th>Time</th><th>Agent</th><th>Action</th>'
            '<th>Verdict</th><th>UCS</th>'
            '</tr></thead>'
            '<tbody>' + "\n".join(rows) + '</tbody>'
            '</table>'
        )
        return 200, html.encode("utf-8"), "text/html"

    def _handle_ui_verdict(
        self, ctx: _ServerContext, record_id: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        """GET /v1/ui/verdict/{record_id} — decision detail for a single evaluation."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(ctx.base_dir)

        # Find record across all agents
        record = None
        for agent_id in store.list_agents():
            for r in store.query_all(agent_id):
                if r.record_id == record_id:
                    record = r
                    break
            if record is not None:
                break

        if record is None:
            return _error(404, "not_found", f"Record not found: {record_id}")

        # Build dimension details
        dimensions = []
        for meta in _DIMENSION_META:
            score = record.dimension_scores.get(meta["name"], 1.0)
            weight = meta["weight"]
            veto_triggered = meta["name"] in record.vetoed_by
            dimensions.append({
                "name": meta["name"],
                "display_name": meta["display_name"],
                "score": score,
                "weight": weight,
                "weighted_contribution": round(weight * score, 4),
                "is_veto": meta["is_veto"],
                "veto_triggered": veto_triggered,
                "reasoning": _dimension_reasoning(
                    meta["name"], score, record.vetoed_by,
                ),
            })

        # Trust trajectory: last 50 trust scores, oldest first
        all_records = store.query_all(record.agent_id)
        trust_trajectory = [r.trust_score for r in all_records[-50:]]

        # Contextual modifiers
        modifiers = record.parameters.get("contextual_modifiers", [])

        # Chain verification
        valid, count, _msg = store.verify_chain(record.agent_id)

        action_to_pass = _compute_action_to_pass(
            record.verdict, record.ucs, record.action_target, dimensions,
        )

        response = {
            "record_id": record.record_id,
            "verdict": record.verdict,
            "ucs_score": record.ucs,
            "evaluation_tier": record.tier,
            "latency_ms": record.parameters.get("latency_ms", 0.0),
            "agent_id": record.agent_id,
            "archetype": record.parameters.get("archetype", ""),
            "timestamp": datetime.fromtimestamp(
                record.timestamp, tz=timezone.utc,
            ).isoformat(),
            "action_type": record.action_type,
            "target": record.action_target,
            "dimensions": dimensions,
            "contextual_modifiers": modifiers,
            "trust_at_evaluation": record.trust_score,
            "trust_trajectory": trust_trajectory,
            "action_to_pass": action_to_pass,
            "chain_verified": valid,
            "chain_position": count,
        }

        # Return HTML for HTMX requests, JSON otherwise
        hx_request = self.headers.get("HX-Request")
        if hx_request == "true":
            return self._render_verdict_html(response)
        return 200, _json_bytes(response)

    def _render_verdict_html(
        self, data: dict,
    ) -> tuple[int, bytes, str]:
        """Render the verdict detail as an HTML partial for HTMX."""
        from string import Template

        template_path = Path(__file__).parent / "ui" / "verdict.html"
        template_str = template_path.read_text(encoding="utf-8")

        # Build dimension rows
        dim_rows: list[str] = []
        for d in data["dimensions"]:
            score_pct = int(d["score"] * 100)
            if d["score"] >= 0.7:
                color_cls = "score-green"
            elif d["score"] >= 0.3:
                color_cls = "score-amber"
            else:
                color_cls = "score-red"

            row_cls = "dimension-row"
            badges = ""
            if d["is_veto"]:
                badges += ' <span class="veto-badge">VETO</span>'
            if d["veto_triggered"]:
                row_cls += " veto-triggered-row"
                badges += ' <span class="triggered-badge">TRIGGERED</span>'
            elif d["is_veto"]:
                row_cls += " veto-row"

            dim_rows.append(
                f'<tr class="{row_cls}">'
                f'<td>{d["display_name"]}{badges}</td>'
                f'<td><div class="score-bar">'
                f'<div class="score-fill {color_cls}" style="width:{score_pct}%"></div>'
                f'</div> {d["score"]:.2f}</td>'
                f'<td>{d["weight"]:.1f}</td>'
                f'<td>{d["weighted_contribution"]:.2f}</td>'
                f'<td class="reasoning-text">{d["reasoning"]}</td>'
                f'</tr>'
            )

        # Build sparkline bars
        sparkline: list[str] = []
        trajectory = data["trust_trajectory"]
        for i, trust in enumerate(trajectory):
            height = max(1, int(trust * 100))
            is_current = (i == len(trajectory) - 1)
            cls = "sparkline-bar sparkline-current" if is_current else "sparkline-bar"
            sparkline.append(
                f'<div class="{cls}" style="height:{height}%" '
                f'title="{trust:.3f}"></div>'
            )

        # Build modifier pills
        mods = data["contextual_modifiers"]
        if mods:
            mod_html = " ".join(
                f'<span class="modifier-pill">{m}</span>' for m in mods
            )
        else:
            mod_html = '<span class="no-modifiers">No active modifiers</span>'

        # Action-to-pass label mapping
        atp = data["action_to_pass"]
        atp_labels = {
            "veto": "VETO VIOLATION",
            "ucs_shortfall": "UCS SHORTFALL",
            "escalation": "ESCALATION REQUIRED",
            "constitutional": "CONSTITUTIONAL BLOCK",
            "none": "PASSED",
        }

        chain_status = (
            '<span class="chain-verified">Chain verified &#10003;</span>'
            if data["chain_verified"]
            else '<span class="chain-unverified">&#9888; Unverified</span>'
        )

        t = Template(template_str)
        html = t.safe_substitute(
            verdict=data["verdict"],
            verdict_lower=data["verdict"].lower(),
            ucs_score=f'{data["ucs_score"]:.2f}',
            evaluation_tier=data["evaluation_tier"],
            latency_ms=f'{data["latency_ms"]:.2f}',
            agent_id=data["agent_id"],
            action_type=data["action_type"],
            target=data["target"],
            atp_label=atp_labels.get(atp["type"], atp["type"].upper()),
            atp_explanation=atp["explanation"],
            dimension_rows="\n".join(dim_rows),
            sparkline_bars="\n".join(sparkline),
            modifier_pills=mod_html,
            record_id=data["record_id"],
            chain_position=data["chain_position"],
            chain_status=chain_status,
        )

        return 200, html.encode("utf-8"), "text/html"

    # ── Agent Live Status Panel (F-10) ─────────────────────────────

    def _gather_agent_status(
        self, ctx: _ServerContext, cert: Any,
    ) -> dict[str, Any]:
        """Build a status dict for a single agent certificate."""
        from nomotic.audit_store import AuditStore

        agent_id = cert.agent_id
        trust_score = cert.trust_score

        # Trust color
        if trust_score > 0.7:
            trust_color = "green"
        elif trust_score >= 0.3:
            trust_color = "amber"
        else:
            trust_color = "red"

        # Drift status from DriftMonitor (if runtime available)
        drift_status = "STABLE"
        if ctx.runtime is not None:
            try:
                monitor = ctx.runtime._fingerprint_observer.drift_monitor
                alerts = monitor.get_alerts(agent_id, unacknowledged_only=True)
                for a in alerts:
                    if a.severity == "critical":
                        drift_status = "CRITICAL"
                        break
                    if a.severity in ("moderate", "high"):
                        drift_status = "WARNING"
            except (AttributeError, TypeError):
                pass

        # Last evaluation timestamp from audit store
        last_evaluation_at = None
        store = AuditStore(ctx.base_dir)
        records = store.query_all(agent_id)
        if records:
            last_evaluation_at = datetime.fromtimestamp(
                records[-1].timestamp, tz=timezone.utc,
            ).isoformat()

        # Compliance preset (from certificate archetype mapping)
        archetype = cert.archetype
        _ARCHETYPE_PRESET_MAP: dict[str, str] = {
            "healthcare-agent": "hipaa_aligned",
            "financial-agent": "sox_aligned",
            "customer-experience": "general",
            "infrastructure-agent": "general",
            "research-agent": "general",
        }
        compliance_preset = _ARCHETYPE_PRESET_MAP.get(archetype, "general")

        return {
            "agent_id": agent_id,
            "trust_score": trust_score,
            "trust_color": trust_color,
            "archetype": archetype,
            "certificate_status": cert.status.name,
            "drift_status": drift_status,
            "last_evaluation_at": last_evaluation_at,
            "compliance_preset": compliance_preset,
        }

    def _handle_ui_agents(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/ui/agents — agent roster listing."""
        params = self._query_params()
        archetype_filter = params.get("archetype")

        # Enumerate all certificates from the CA store
        certs = ctx.ca._store.list(archetype=archetype_filter or None)

        agents = []
        for cert in certs:
            agents.append(self._gather_agent_status(ctx, cert))

        # Sort by trust_score ascending (lowest trust first)
        agents.sort(key=lambda a: a["trust_score"])

        return 200, _json_bytes(agents)

    def _handle_ui_agent_detail(
        self, ctx: _ServerContext, agent_id: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        """GET /v1/ui/agent/{agent_id} — detailed agent view."""
        from nomotic.audit_store import AuditStore

        # Find the certificate for this agent_id
        all_certs = ctx.ca._store.list()
        cert = None
        for c in all_certs:
            if c.agent_id == agent_id:
                cert = c
                break

        if cert is None:
            return _error(404, "not_found", f"Agent not found: {agent_id}")

        # Trust score
        trust_score = cert.trust_score

        # Trust trajectory (last 30 scores from audit records)
        store = AuditStore(ctx.base_dir)
        records = store.query_all(agent_id)
        trust_trajectory_30d = [r.trust_score for r in records[-30:]]

        # Evaluation summary (last 30 days)
        now_ts = time.time()
        cutoff_30d = now_ts - (30 * 86400)
        recent_records = [r for r in records if r.timestamp >= cutoff_30d]

        total = len(recent_records)
        allow_count = sum(1 for r in recent_records if r.verdict == "ALLOW")
        deny_count = sum(1 for r in recent_records if r.verdict == "DENY")
        escalate_count = sum(1 for r in recent_records if r.verdict == "ESCALATE")
        block_count = sum(1 for r in recent_records if r.verdict == "BLOCK")

        evaluation_summary_30d = {
            "total": total,
            "allow": allow_count,
            "deny": deny_count,
            "escalate": escalate_count,
            "block": block_count,
        }

        # Open drift alerts
        open_drift_alerts: list[dict[str, Any]] = []
        if ctx.runtime is not None:
            try:
                monitor = ctx.runtime._fingerprint_observer.drift_monitor
                alerts = monitor.get_alerts(agent_id, unacknowledged_only=True)
                open_drift_alerts = [a.to_dict() for a in alerts]
            except (AttributeError, TypeError):
                pass

        # Compliance preset
        _ARCHETYPE_PRESET_MAP: dict[str, str] = {
            "healthcare-agent": "hipaa_aligned",
            "financial-agent": "sox_aligned",
            "customer-experience": "general",
            "infrastructure-agent": "general",
            "research-agent": "general",
        }
        compliance_preset = _ARCHETYPE_PRESET_MAP.get(cert.archetype, "general")

        # Last evaluation timestamp
        last_evaluation_at = None
        if records:
            last_evaluation_at = datetime.fromtimestamp(
                records[-1].timestamp, tz=timezone.utc,
            ).isoformat()

        return 200, _json_bytes({
            "certificate": cert.to_dict(),
            "trust_score": trust_score,
            "trust_trajectory_30d": trust_trajectory_30d,
            "evaluation_summary_30d": evaluation_summary_30d,
            "open_drift_alerts": open_drift_alerts,
            "compliance_preset": compliance_preset,
            "archetype": cert.archetype,
            "last_evaluation_at": last_evaluation_at,
        })

    def _handle_ui_panel_agents(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str]:
        """GET /v1/ui/panels/agent-roster — HTML agent roster panel."""
        params = self._query_params()
        archetype_filter = params.get("archetype")

        certs = ctx.ca._store.list(archetype=archetype_filter or None)

        agents = []
        for cert in certs:
            agents.append(self._gather_agent_status(ctx, cert))

        # Sort by trust_score ascending
        agents.sort(key=lambda a: a["trust_score"])

        if not agents:
            html = (
                '<div class="empty-state">No agents yet &mdash; run nomotic hello '
                'to take the guided tour, or nomotic init to scaffold your first project</div>'
            )
            return 200, html.encode("utf-8"), "text/html"

        rows: list[str] = []
        for agent in agents:
            # Trust pill
            tc = agent["trust_color"]
            pill_styles = {
                "green": "background:#E8F5E9;color:#375623;",
                "amber": "background:#FFF8E1;color:#C55A11;",
                "red": "background:#FFEBEE;color:#C00000;",
            }
            pill_style = pill_styles.get(tc, "")
            trust_pill = (
                f'<span class="trust-pill" style="{pill_style}'
                f'padding:2px 8px;border-radius:12px;font-weight:600;">'
                f'{agent["trust_score"]:.2f}</span>'
            )

            # Drift badge
            ds = agent["drift_status"]
            if ds == "CRITICAL":
                drift_badge = '<span style="color:#C00000;font-weight:bold;">CRITICAL</span>'
            elif ds == "WARNING":
                drift_badge = '<span style="color:#C55A11;font-weight:bold;">WARNING</span>'
            else:
                drift_badge = '<span style="color:#666;">STABLE</span>'

            # Last seen
            last_seen = agent["last_evaluation_at"] or "Never"
            if last_seen != "Never":
                # Show just the date+time portion
                last_seen = last_seen.replace("T", " ")[:19]

            rows.append(
                f'<tr hx-get="/v1/ui/agent/{agent["agent_id"]}" '
                f'hx-target="#agent-detail-panel" hx-swap="innerHTML" '
                f'style="cursor:pointer;">'
                f'<td>{agent["agent_id"]}</td>'
                f'<td>{agent["archetype"]}</td>'
                f'<td>{trust_pill}</td>'
                f'<td>{agent["certificate_status"]}</td>'
                f'<td>{drift_badge}</td>'
                f'<td>{last_seen}</td>'
                f'</tr>'
            )

        html = (
            '<table class="feed-table">'
            '<thead><tr>'
            '<th>Agent</th><th>Archetype</th><th>Trust</th>'
            '<th>Certificate</th><th>Drift</th><th>Last Seen</th>'
            '</tr></thead>'
            '<tbody>' + "\n".join(rows) + '</tbody>'
            '</table>'
        )
        return 200, html.encode("utf-8"), "text/html"

    # ── Drift Alert Surface (F-11) ──────────────────────────────────

    def _normalize_agent_alerts(self, ctx: _ServerContext) -> list[dict[str, Any]]:
        """Gather agent drift alerts from DriftMonitor and normalize."""
        alerts: list[dict[str, Any]] = []
        if ctx.runtime is None:
            return alerts
        try:
            monitor = ctx.runtime._fingerprint_observer.drift_monitor
        except (AttributeError, TypeError):
            return alerts

        raw_alerts = monitor.get_alerts(unacknowledged_only=True)
        for a in raw_alerts:
            # Map DriftAlert severity to UI severity
            sev = a.severity.upper()
            if sev in ("HIGH", "CRITICAL"):
                ui_severity = "CRITICAL" if sev == "CRITICAL" else "WARNING"
            elif sev == "MODERATE":
                ui_severity = "WARNING"
            else:
                ui_severity = "WARNING"

            # Collect triggered dimensions
            triggered: list[str] = []
            score = a.drift_score
            if score.action_drift > 0.15:
                triggered.append("action_drift")
            if score.target_drift > 0.15:
                triggered.append("target_drift")
            if score.temporal_drift > 0.15:
                triggered.append("temporal_drift")
            if score.outcome_drift > 0.15:
                triggered.append("outcome_drift")
            if not triggered:
                triggered.append("overall")

            alert_id = f"agent-{a.agent_id}-{int(a.timestamp * 1000)}"
            alerts.append({
                "alert_id": alert_id,
                "alert_type": "agent",
                "subject_id": a.agent_id,
                "subject_label": f"Agent: {a.agent_id}",
                "drift_score": round(score.overall, 4),
                "severity": ui_severity,
                "triggered_dimensions": triggered,
                "detected_at": datetime.fromtimestamp(
                    a.timestamp, tz=timezone.utc,
                ).isoformat(),
                "dismissed": False,
            })
        return alerts

    def _normalize_reviewer_alerts(self, ctx: _ServerContext) -> list[dict[str, Any]]:
        """Gather reviewer drift alerts from HumanDriftMonitor and normalize."""
        alerts: list[dict[str, Any]] = []
        if ctx.runtime is None:
            return alerts
        try:
            human_monitor = ctx.runtime._human_drift_monitor
        except AttributeError:
            return alerts
        if human_monitor is None:
            return alerts

        raw_alerts = human_monitor.get_alerts()
        for r in raw_alerts:
            # Map drift_category to UI severity
            if r.drift_category in ("severe", "critical"):
                ui_severity = "CRITICAL"
            else:
                ui_severity = "WARNING"

            # Collect triggered behavior types from component drifts
            triggered: list[str] = []
            if r.timing_drift > 0.1:
                triggered.append("timing_drift")
            if r.decision_drift > 0.1:
                triggered.append("decision_drift")
            if r.engagement_drift > 0.1:
                triggered.append("engagement_drift")
            if r.throughput_drift > 0.1:
                triggered.append("throughput_drift")
            if r.risk_timing_drift > 0.1:
                triggered.append("risk_timing_drift")
            if r.fatigue_score > 0.1:
                triggered.append("fatigue")
            if not triggered:
                triggered.append("overall")

            ts = r.recent_profile.window_end or time.time()
            alert_id = f"reviewer-{r.reviewer_id}-{int(ts * 1000)}"
            alerts.append({
                "alert_id": alert_id,
                "alert_type": "reviewer",
                "subject_id": r.reviewer_id,
                "subject_label": f"Reviewer: {r.reviewer_id}",
                "drift_score": round(r.overall_drift, 4),
                "severity": ui_severity,
                "triggered_dimensions": triggered,
                "detected_at": datetime.fromtimestamp(
                    ts, tz=timezone.utc,
                ).isoformat(),
                "dismissed": False,
            })
        return alerts

    def _get_unified_drift_alerts(self, ctx: _ServerContext) -> list[dict[str, Any]]:
        """Merge and sort all drift alerts.

        Sort: CRITICAL before WARNING, then by drift_score descending.
        Filter out dismissed alerts.
        """
        # Gather dismissed alert IDs from context
        dismissed = getattr(ctx, "_dismissed_drift_alerts", set())

        agent_alerts = self._normalize_agent_alerts(ctx)
        reviewer_alerts = self._normalize_reviewer_alerts(ctx)
        all_alerts = agent_alerts + reviewer_alerts

        # Filter dismissed
        all_alerts = [a for a in all_alerts if a["alert_id"] not in dismissed]

        # Sort: CRITICAL first, then by drift_score desc
        severity_rank = {"CRITICAL": 0, "WARNING": 1}
        all_alerts.sort(
            key=lambda a: (severity_rank.get(a["severity"], 2), -a["drift_score"]),
        )
        return all_alerts

    def _handle_ui_drift_alerts(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/ui/drift-alerts — unified drift alerts JSON."""
        alerts = self._get_unified_drift_alerts(ctx)
        return 200, _json_bytes(alerts)

    def _handle_ui_drift_dismiss(
        self, ctx: _ServerContext, alert_id: str,
    ) -> tuple[int, bytes]:
        """POST /v1/ui/drift-alerts/{alert_id}/dismiss — dismiss a drift alert."""
        body = self._read_json()
        dismissed_by = body.get("dismissed_by", "unknown")
        reason = body.get("reason", "")

        # Check the alert exists in current unified set
        all_alerts = self._get_unified_drift_alerts(ctx)
        target = None
        for a in all_alerts:
            if a["alert_id"] == alert_id:
                target = a
                break

        if target is None:
            return _error(404, "not_found", f"Alert not found: {alert_id}")

        # Mark as dismissed in context
        if not hasattr(ctx, "_dismissed_drift_alerts"):
            ctx._dismissed_drift_alerts = set()  # type: ignore[attr-defined]
        ctx._dismissed_drift_alerts.add(alert_id)  # type: ignore[attr-defined]

        # Write audit record
        from nomotic.audit_store import AuditStore, PersistentLogRecord
        store = AuditStore(ctx.base_dir)
        record = PersistentLogRecord(
            record_id=f"dismiss-{alert_id}",
            timestamp=time.time(),
            agent_id=target["subject_id"],
            action_type="DRIFT_ALERT_DISMISSED",
            action_target=alert_id,
            verdict="ALLOW",
            ucs=0.0,
            tier=0,
            trust_score=0.0,
            trust_delta=0.0,
            trust_trend="stable",
            severity="info",
            justification=reason or "Alert dismissed",
            parameters={
                "action": "DRIFT_ALERT_DISMISSED",
                "subject": target["subject_id"],
                "authority": dismissed_by,
                "reason": reason,
                "alert_type": target["alert_type"],
                "drift_score": target["drift_score"],
            },
        )
        previous_hash = store.get_last_hash(target["subject_id"])
        record.previous_hash = previous_hash
        record.record_hash = store.compute_hash(record.to_dict(), previous_hash)
        store.append(record)

        return 200, _json_bytes({"dismissed": True, "alert_id": alert_id})

    def _handle_ui_panel_drift_alerts(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str]:
        """GET /v1/ui/panels/drift-alerts — HTML drift alerts panel."""
        alerts = self._get_unified_drift_alerts(ctx)

        agent_alerts = [a for a in alerts if a["alert_type"] == "agent"]
        reviewer_alerts = [a for a in alerts if a["alert_type"] == "reviewer"]

        if not alerts:
            html = (
                '<div class="empty-state">No drift alerts &mdash; all agents and '
                'reviewers are operating within expected behavioral baselines</div>'
            )
            return 200, html.encode("utf-8"), "text/html"

        parts: list[str] = []

        # Agent section
        parts.append('<h3 style="margin:0 0 8px 0;">Agent Behavioral Drift</h3>')
        if not agent_alerts:
            parts.append('<p style="color:#888;margin:4px 0 16px;">None detected</p>')
        else:
            for a in agent_alerts:
                parts.append(self._render_drift_alert_card(a))

        # Reviewer section
        parts.append('<h3 style="margin:16px 0 4px 0;">Human Reviewer Drift</h3>')
        parts.append(
            '<p style="color:#888;font-style:italic;margin:0 0 8px;font-size:0.85em;">'
            'These reviewers show patterns of disengagement &mdash; high approval rates, '
            'reduced review time, or rubber-stamping behaviors.</p>'
        )
        if not reviewer_alerts:
            parts.append('<p style="color:#888;margin:4px 0 16px;">None detected</p>')
        else:
            for a in reviewer_alerts:
                parts.append(self._render_drift_alert_card(a))

        return 200, "\n".join(parts).encode("utf-8"), "text/html"

    def _render_drift_alert_card(self, alert: dict[str, Any]) -> str:
        """Render a single drift alert card as HTML."""
        # Severity badge
        if alert["severity"] == "CRITICAL":
            badge = (
                '<span style="background:#FFEBEE;color:#C00000;padding:2px 8px;'
                'border-radius:12px;font-weight:600;font-size:0.8em;">CRITICAL</span>'
            )
        else:
            badge = (
                '<span style="background:#FFF8E1;color:#C55A11;padding:2px 8px;'
                'border-radius:12px;font-weight:600;font-size:0.8em;">WARNING</span>'
            )

        # Dimension/behavior pills
        pills = " ".join(
            f'<span style="background:#E3F2FD;color:#1565C0;padding:1px 6px;'
            f'border-radius:8px;font-size:0.75em;margin-right:4px;">{d}</span>'
            for d in alert["triggered_dimensions"]
        )

        # Time ago
        detected = alert["detected_at"]

        return (
            f'<div class="drift-alert-card" id="alert-{alert["alert_id"]}" '
            f'style="border:1px solid #ddd;border-radius:8px;padding:12px;margin:8px 0;">'
            f'<div style="display:flex;justify-content:space-between;align-items:center;">'
            f'<strong>{alert["subject_label"]}</strong> {badge}'
            f'</div>'
            f'<div style="margin:4px 0;">Drift score: {alert["drift_score"]:.4f} '
            f'&middot; {detected}</div>'
            f'<div style="margin:4px 0;">{pills}</div>'
            f'<button hx-post="/v1/ui/drift-alerts/{alert["alert_id"]}/dismiss" '
            f'hx-vals=\'{{"dismissed_by":"dashboard_user","reason":"dismissed from panel"}}\' '
            f'hx-confirm="Dismiss this drift alert?" '
            f'hx-target="#alert-{alert["alert_id"]}" hx-swap="outerHTML" '
            f'style="margin-top:8px;padding:4px 12px;cursor:pointer;">Dismiss</button>'
            f'</div>'
        )

    # ── Audit Trail Viewer (F-12) ─────────────────────────────────

    def _collect_filtered_audit_records(
        self, ctx: _ServerContext,
    ) -> tuple[list[Any], dict[str, str], dict[str, dict[str, int]]]:
        """Collect and filter audit records across all agents.

        Returns (filtered_records, cert_archetypes, agent_positions).
        """
        from nomotic.audit_store import AuditStore

        params = self._query_params()
        agent_id_filter = params.get("agent_id")
        verdict_filter = params.get("verdict")
        archetype_filter = params.get("archetype")
        date_from = params.get("date_from")
        date_to = params.get("date_to")

        store = AuditStore(ctx.base_dir)

        # Build archetype lookup from certificates
        cert_archetypes: dict[str, str] = {}
        try:
            for cert in ctx.ca._store.list():
                cert_archetypes[cert.agent_id] = cert.archetype
        except Exception:
            pass

        # Collect records and track chain positions per agent
        all_records = []
        agent_positions: dict[str, dict[str, int]] = {}
        agent_ids = [agent_id_filter] if agent_id_filter else store.list_agents()

        for aid in agent_ids:
            agent_records = store.query_all(aid)
            for i, r in enumerate(agent_records):
                agent_positions.setdefault(aid, {})[r.record_id] = i
                all_records.append(r)

        # Apply filters
        if verdict_filter:
            all_records = [r for r in all_records if r.verdict == verdict_filter]
        if archetype_filter:
            all_records = [
                r for r in all_records
                if cert_archetypes.get(
                    r.agent_id, r.parameters.get("archetype", ""),
                ) == archetype_filter
            ]
        if date_from:
            try:
                from_ts = datetime.fromisoformat(date_from).timestamp()
                all_records = [r for r in all_records if r.timestamp >= from_ts]
            except ValueError:
                pass
        if date_to:
            try:
                to_ts = datetime.fromisoformat(date_to).timestamp()
                all_records = [r for r in all_records if r.timestamp <= to_ts]
            except ValueError:
                pass

        # Sort newest first
        all_records.sort(key=lambda r: r.timestamp, reverse=True)
        return all_records, cert_archetypes, agent_positions

    def _format_audit_record(
        self,
        r: Any,
        cert_archetypes: dict[str, str],
        agent_positions: dict[str, dict[str, int]],
    ) -> dict[str, Any]:
        """Format a single PersistentLogRecord for the UI audit response."""
        archetype = cert_archetypes.get(
            r.agent_id, r.parameters.get("archetype", ""),
        )
        chain_pos = agent_positions.get(r.agent_id, {}).get(r.record_id, 0)
        prev_hash = r.previous_hash
        if prev_hash and len(prev_hash) > 8:
            prev_hash_display = prev_hash[:8] + "..."
        else:
            prev_hash_display = prev_hash or ""

        return {
            "timestamp": datetime.fromtimestamp(
                r.timestamp, tz=timezone.utc,
            ).isoformat(),
            "agent_id": r.agent_id,
            "archetype": archetype,
            "action_type": r.action_type,
            "target": r.action_target,
            "verdict": r.verdict,
            "ucs_score": round(r.ucs, 2),
            "record_id": r.record_id,
            "chain_position": chain_pos,
            "previous_hash": prev_hash_display,
        }

    def _handle_ui_audit(self, ctx: _ServerContext) -> tuple[int, bytes]:
        """GET /v1/ui/audit — searchable, filterable audit trail."""
        from nomotic.audit_store import AuditStore

        params = self._query_params()
        limit = min(int(params.get("limit", "100")), 500)
        offset = int(params.get("offset", "0"))

        all_records, cert_archetypes, agent_positions = (
            self._collect_filtered_audit_records(ctx)
        )
        total = len(all_records)
        paginated = all_records[offset:offset + limit]

        # Verify chain integrity across all relevant agents
        store = AuditStore(ctx.base_dir)
        chain_verified = True
        agent_id_filter = params.get("agent_id")
        check_agents = [agent_id_filter] if agent_id_filter else store.list_agents()
        for aid in check_agents:
            is_valid, _, _ = store.verify_chain(aid)
            if not is_valid:
                chain_verified = False
                break

        records = [
            self._format_audit_record(r, cert_archetypes, agent_positions)
            for r in paginated
        ]

        return 200, _json_bytes({
            "records": records,
            "total": total,
            "offset": offset,
            "limit": limit,
            "chain_verified": chain_verified,
        })

    def _handle_ui_audit_export(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str, dict[str, str]]:
        """GET /v1/ui/audit/export — export audit trail as CSV or JSON."""
        import csv
        import io

        params = self._query_params()
        fmt = params.get("format", "csv")

        all_records, cert_archetypes, agent_positions = (
            self._collect_filtered_audit_records(ctx)
        )

        records = [
            self._format_audit_record(r, cert_archetypes, agent_positions)
            for r in all_records
        ]

        datestamp = datetime.now(timezone.utc).strftime("%Y%m%d")

        if fmt == "json":
            body = _json_bytes(records)
            filename = f"nomotic-audit-{datestamp}.json"
            return (
                200, body, "application/json",
                {"Content-Disposition": f'attachment; filename="{filename}"'},
            )

        # CSV export (default)
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "timestamp", "agent_id", "archetype", "action_type",
            "target", "verdict", "ucs_score", "record_id",
        ])
        for rec in records:
            writer.writerow([
                rec["timestamp"], rec["agent_id"], rec["archetype"],
                rec["action_type"], rec["target"], rec["verdict"],
                rec["ucs_score"], rec["record_id"],
            ])
        body = output.getvalue().encode("utf-8")
        filename = f"nomotic-audit-{datestamp}.csv"
        return (
            200, body, "text/csv",
            {"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    def _handle_ui_audit_verify(
        self, ctx: _ServerContext, record_id: str,
    ) -> tuple[int, bytes]:
        """POST /v1/ui/audit/verify/{record_id} — verify chain up to a record."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(ctx.base_dir)

        # Find the record across all agents
        target_agent = None
        target_position = -1
        for aid in store.list_agents():
            agent_records = store.query_all(aid)
            for i, r in enumerate(agent_records):
                if r.record_id == record_id:
                    target_agent = aid
                    target_position = i
                    break
            if target_agent:
                break

        if target_agent is None:
            return _error(404, "not_found", f"Record not found: {record_id}")

        # Verify chain up to this record
        agent_records = store.query_all(target_agent)
        chain_subset = agent_records[:target_position + 1]

        # Manual chain verification on subset
        verified = True
        error_msg: str | None = None
        previous_hash = ""
        for i, rec in enumerate(chain_subset):
            expected = store.compute_hash(rec.to_dict(), previous_hash)
            if rec.record_hash != expected:
                verified = False
                error_msg = (
                    f"Hash mismatch at position {i} ({rec.record_id})"
                )
                break
            if rec.previous_hash != previous_hash:
                verified = False
                error_msg = (
                    f"Chain break at position {i} ({rec.record_id})"
                )
                break
            previous_hash = rec.record_hash

        return 200, _json_bytes({
            "verified": verified,
            "record_id": record_id,
            "chain_position": target_position,
            "error": error_msg,
        })

    def _handle_ui_panel_audit(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str]:
        """GET /v1/ui/panels/audit-trail — HTML audit trail panel."""
        from nomotic.audit_store import AuditStore

        params = self._query_params()
        limit = min(int(params.get("limit", "100")), 500)
        offset = int(params.get("offset", "0"))

        all_records, cert_archetypes, agent_positions = (
            self._collect_filtered_audit_records(ctx)
        )
        total = len(all_records)
        paginated = all_records[offset:offset + limit]

        store = AuditStore(ctx.base_dir)
        chain_verified = True
        agent_id_filter = params.get("agent_id")
        check_agents = (
            [agent_id_filter] if agent_id_filter else store.list_agents()
        )
        for aid in check_agents:
            is_valid, _, _ = store.verify_chain(aid)
            if not is_valid:
                chain_verified = False
                break

        records = [
            self._format_audit_record(r, cert_archetypes, agent_positions)
            for r in paginated
        ]

        # Build filter bar HTML
        parts: list[str] = []

        # Chain status indicator
        if chain_verified:
            chain_badge = (
                '<span style="color:#2E7D32;font-weight:600;">'
                '&#10003; Chain Intact</span>'
            )
        else:
            chain_badge = (
                '<span style="color:#C00000;font-weight:600;">'
                '&#9888; Chain Integrity Issue</span>'
            )

        parts.append(
            '<div style="display:flex;justify-content:space-between;'
            'align-items:center;margin-bottom:12px;">'
            '<div style="display:flex;gap:8px;flex-wrap:wrap;'
            'align-items:center;">'
            '  <select id="audit-agent-filter" style="padding:4px 8px;">'
            '    <option value="">All Agents</option>'
            '  </select>'
            '  <span style="display:inline-flex;gap:2px;">'
            '    <button class="verdict-toggle" data-verdict="" '
            'style="padding:4px 8px;cursor:pointer;">ALL</button>'
            '    <button class="verdict-toggle" data-verdict="ALLOW" '
            'style="padding:4px 8px;cursor:pointer;">ALLOW</button>'
            '    <button class="verdict-toggle" data-verdict="DENY" '
            'style="padding:4px 8px;cursor:pointer;">DENY</button>'
            '    <button class="verdict-toggle" data-verdict="ESCALATE" '
            'style="padding:4px 8px;cursor:pointer;">ESCALATE</button>'
            '    <button class="verdict-toggle" data-verdict="BLOCK" '
            'style="padding:4px 8px;cursor:pointer;">BLOCK</button>'
            '  </span>'
            '  <select id="audit-archetype-filter" '
            'style="padding:4px 8px;">'
            '    <option value="">All Archetypes</option>'
            '  </select>'
            '  <input type="date" id="audit-date-from" '
            'style="padding:4px 8px;" placeholder="From">'
            '  <input type="date" id="audit-date-to" '
            'style="padding:4px 8px;" placeholder="To">'
            '  <button hx-get="/v1/ui/panels/audit-trail" '
            'hx-target="#audit-trail-content" hx-swap="innerHTML" '
            'hx-include="[id^=audit-]" '
            'style="padding:4px 12px;cursor:pointer;">Apply Filters</button>'
            '  <a href="/v1/ui/audit/export?format=csv" '
            'style="padding:4px 12px;text-decoration:none;border:1px solid '
            '#ccc;border-radius:4px;">Export CSV</a>'
            '  <a href="/v1/ui/audit/export?format=json" '
            'style="padding:4px 12px;text-decoration:none;border:1px solid '
            '#ccc;border-radius:4px;">Export JSON</a>'
            '</div>'
            f'{chain_badge}'
            '</div>'
        )

        if not records:
            parts.append(
                '<div class="empty-state">No audit records found for '
                'the selected filters</div>'
            )
            return 200, "\n".join(parts).encode("utf-8"), "text/html"

        # Table
        parts.append(
            '<div style="overflow-x:auto;">'
            '<table style="width:100%;border-collapse:collapse;'
            'font-size:0.9em;">'
            '<thead><tr style="border-bottom:2px solid #ddd;">'
            '<th style="padding:8px;text-align:left;">Time</th>'
            '<th style="padding:8px;text-align:left;">Agent</th>'
            '<th style="padding:8px;text-align:left;">Archetype</th>'
            '<th style="padding:8px;text-align:left;">Action</th>'
            '<th style="padding:8px;text-align:left;">Target</th>'
            '<th style="padding:8px;text-align:left;">Verdict</th>'
            '<th style="padding:8px;text-align:right;">UCS</th>'
            '<th style="padding:8px;text-align:left;">Hash</th>'
            '<th style="padding:8px;text-align:center;">Verify</th>'
            '</tr></thead><tbody>'
        )

        verdict_colors = {
            "ALLOW": "#2E7D32",
            "DENY": "#C00000",
            "ESCALATE": "#C55A11",
            "BLOCK": "#7B1FA2",
        }

        for rec in records:
            v = rec["verdict"]
            vc = verdict_colors.get(v, "#333")
            ts = rec["timestamp"]
            if "T" in ts:
                ts = ts.split("T")[1][:8]
            parts.append(
                f'<tr style="border-bottom:1px solid #eee;">'
                f'<td style="padding:6px 8px;">{ts}</td>'
                f'<td style="padding:6px 8px;">{rec["agent_id"]}</td>'
                f'<td style="padding:6px 8px;">{rec["archetype"]}</td>'
                f'<td style="padding:6px 8px;">{rec["action_type"]}</td>'
                f'<td style="padding:6px 8px;">{rec["target"]}</td>'
                f'<td style="padding:6px 8px;">'
                f'<span style="background:{vc}20;color:{vc};padding:2px 8px;'
                f'border-radius:12px;font-weight:600;font-size:0.85em;">'
                f'{v}</span></td>'
                f'<td style="padding:6px 8px;text-align:right;">'
                f'{rec["ucs_score"]:.2f}</td>'
                f'<td style="padding:6px 8px;font-family:monospace;'
                f'font-size:0.85em;">{rec["record_id"][:8]}</td>'
                f'<td style="padding:6px 8px;text-align:center;">'
                f'<button hx-post="/v1/ui/audit/verify/{rec["record_id"]}" '
                f'hx-swap="innerHTML" hx-target="this" '
                f'style="padding:2px 8px;cursor:pointer;font-size:0.85em;">'
                f'Verify</button></td>'
                f'</tr>'
            )

        parts.append('</tbody></table></div>')

        # Pagination bar
        start = offset + 1
        end = min(offset + limit, total)
        parts.append(
            f'<div style="display:flex;justify-content:space-between;'
            f'align-items:center;margin-top:12px;font-size:0.9em;">'
            f'<span>Records {start}&ndash;{end} of {total}</span>'
            f'<div style="display:flex;gap:8px;">'
        )
        if offset > 0:
            prev_offset = max(0, offset - limit)
            parts.append(
                f'<button hx-get="/v1/ui/panels/audit-trail?'
                f'offset={prev_offset}&limit={limit}" '
                f'hx-target="#audit-trail-content" hx-swap="innerHTML" '
                f'style="padding:4px 12px;cursor:pointer;">Previous</button>'
            )
        if offset + limit < total:
            next_offset = offset + limit
            parts.append(
                f'<button hx-get="/v1/ui/panels/audit-trail?'
                f'offset={next_offset}&limit={limit}" '
                f'hx-target="#audit-trail-content" hx-swap="innerHTML" '
                f'style="padding:4px 12px;cursor:pointer;">Next</button>'
            )
        parts.append('</div></div>')

        return 200, "\n".join(parts).encode("utf-8"), "text/html"

    def _handle_ui_export(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes] | tuple[int, bytes, str, dict[str, str]]:
        """POST /v1/ui/export — export dashboard snapshot as HTML or JSON."""
        from nomotic.audit_store import AuditStore
        from nomotic.fleet import FleetGovernor

        params = self._query_params()
        fmt = params.get("format", "html")

        # Collect overview data
        store = AuditStore(ctx.base_dir)
        fleet = FleetGovernor(audit_store=store)
        summary = fleet.health_summary()

        allow_count = summary.total_evaluations_24h - int(
            summary.fleet_denial_rate * summary.total_evaluations_24h
        )
        deny_count = summary.total_evaluations_24h - allow_count
        if summary.total_evaluations_24h > 0:
            allow_pct = round(100 * allow_count / summary.total_evaluations_24h)
            deny_pct = 100 - allow_pct
            ratio = f"{allow_pct}:{deny_pct}"
        else:
            ratio = "0:0"

        overview = {
            "active_agents": summary.active_agents,
            "evaluations_today": summary.total_evaluations_24h,
            "allow_deny_ratio": ratio,
            "open_approvals": len(ctx.runtime.get_pending_overrides()) if ctx.runtime else 0,
        }

        # Collect feed data
        feed_items: list[dict[str, Any]] = []
        for agent_id in store.list_agents():
            for r in store.query(agent_id, limit=50):
                feed_items.append({
                    "timestamp": datetime.fromtimestamp(
                        r.timestamp, tz=timezone.utc
                    ).isoformat(),
                    "agent_id": r.agent_id,
                    "archetype": r.parameters.get("archetype", ""),
                    "action_type": r.action_type,
                    "verdict": r.verdict,
                    "ucs_score": r.ucs,
                    "latency_ms": r.parameters.get("latency_ms", 0.0),
                    "record_id": r.record_id,
                })
        feed_items.sort(key=lambda x: x["timestamp"], reverse=True)

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

        snapshot = {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "overview": overview,
            "feed": feed_items[:50],
        }

        if fmt == "json":
            body = _json_bytes(snapshot)
            filename = f"nomotic-snapshot-{timestamp}.json"
            return (
                200, body, "application/json",
                {"Content-Disposition": f'attachment; filename="{filename}"'},
            )

        # HTML export (default)
        html_parts = [
            "<!DOCTYPE html>",
            "<html lang='en'><head><meta charset='utf-8'>",
            "<title>Nomotic Dashboard Snapshot</title>",
            "<style>",
            "body{font-family:system-ui,sans-serif;margin:2rem;color:#1a1a2e}",
            "h1{color:#16213e}h2{color:#0f3460;border-bottom:1px solid #ccc;"
            "padding-bottom:.3rem}",
            "table{border-collapse:collapse;width:100%;margin:1rem 0}",
            "th,td{border:1px solid #ddd;padding:8px;text-align:left}",
            "th{background:#f4f4f4}",
            ".stats{display:flex;gap:1rem;margin:1rem 0}",
            ".stat{background:#f0f4ff;padding:1rem;border-radius:6px;"
            "flex:1;text-align:center}",
            ".stat-value{font-size:1.5rem;font-weight:bold}",
            ".verdict-allow{color:#27ae60}.verdict-deny{color:#e74c3c}",
            "</style></head><body>",
            f"<h1>Nomotic Dashboard Snapshot</h1>",
            f"<p>Exported: {snapshot['exported_at']}</p>",
            "<h2>Overview</h2>",
            "<div class='stats'>",
            f"<div class='stat'><div class='stat-value'>"
            f"{overview['active_agents']}</div>Active Agents</div>",
            f"<div class='stat'><div class='stat-value'>"
            f"{overview['evaluations_today']}</div>Evaluations Today</div>",
            f"<div class='stat'><div class='stat-value'>"
            f"{overview['allow_deny_ratio']}</div>Allow/Deny Ratio</div>",
            f"<div class='stat'><div class='stat-value'>"
            f"{overview['open_approvals']}</div>Open Approvals</div>",
            "</div>",
            "<h2>Evaluation Feed</h2>",
        ]
        if feed_items:
            html_parts.append(
                "<table><thead><tr>"
                "<th>Timestamp</th><th>Agent</th><th>Archetype</th>"
                "<th>Action</th><th>Verdict</th><th>UCS</th>"
                "</tr></thead><tbody>"
            )
            for item in feed_items[:50]:
                verdict_class = (
                    "verdict-allow" if item["verdict"] == "ALLOW"
                    else "verdict-deny"
                )
                html_parts.append(
                    f"<tr><td>{item['timestamp']}</td>"
                    f"<td>{item['agent_id']}</td>"
                    f"<td>{item['archetype']}</td>"
                    f"<td>{item['action_type']}</td>"
                    f"<td class='{verdict_class}'>{item['verdict']}</td>"
                    f"<td>{item['ucs_score']:.2f}</td></tr>"
                )
            html_parts.append("</tbody></table>")
        else:
            html_parts.append("<p>No evaluations recorded.</p>")
        html_parts.append("</body></html>")

        body = "\n".join(html_parts).encode("utf-8")
        filename = f"nomotic-snapshot-{timestamp}.html"
        return (
            200, body, "text/html",
            {"Content-Disposition": f'attachment; filename="{filename}"'},
        )


    # ── Override Approval Queue API (F-05) ─────────────────────────────

    def _serialize_pending(self, pending: Any) -> dict[str, Any]:
        """Serialize a PendingOverride for JSON API responses."""
        ttl = max(0, int(pending.expires_at - time.time()))
        return {
            "pending_id": pending.override_id,
            "agent_id": pending.agent_id,
            "action_type": pending.override_type,
            "target": pending.action_id,
            "parameters": {},
            "ucs_score": 0.0,
            "escalation_reason": pending.initial_reason,
            "signatures_required": pending.required_signatures,
            "signatures_collected": pending.signature_count,
            "authorities_signed": list(pending.authorities_signed),
            "ttl_seconds_remaining": ttl,
            "created_at": datetime.fromtimestamp(
                pending.created_at, tz=timezone.utc
            ).isoformat(),
            "expires_at": datetime.fromtimestamp(
                pending.expires_at, tz=timezone.utc
            ).isoformat(),
            "policy_name": pending.policy_id,
            "status": pending.status,
        }

    def _handle_overrides_pending_list(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/overrides/pending — list all pending overrides."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")
        pending = ctx.runtime.get_pending_overrides()
        return 200, _json_bytes([self._serialize_pending(p) for p in pending])

    def _handle_overrides_pending_get(
        self, ctx: _ServerContext, pending_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/overrides/pending/{id} — single pending override."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")
        p = ctx.runtime.get_pending_override(pending_id)
        if p is None:
            return _error(404, "not_found", "Pending override not found")
        return 200, _json_bytes(self._serialize_pending(p))

    def _handle_overrides_approve(
        self, ctx: _ServerContext, pending_id: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        """POST /v1/overrides/pending/{id}/approve — submit approval signature."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")

        body = self._read_json()
        if not body.get("authority") or not body.get("reason"):
            return _error(400, "validation_error", "authority and reason required")

        try:
            result = ctx.runtime.cosign_override(
                pending_id,
                body["authority"],
                body["reason"],
                role_check=False,
            )
        except ValueError as e:
            msg = str(e)
            if "not found" in msg:
                return _error(404, "not_found", msg)
            if "expired" in msg:
                return _error(400, "expired", "Override has expired")
            if "already signed" in msg:
                return _error(409, "duplicate", "Authority has already signed this override")
            return _error(400, "bad_request", msg)

        from nomotic.types import GovernanceOverrideRecord
        completed = result.status == "COMPLETE"

        response = {
            "pending_id": pending_id,
            "status": "COMPLETE" if completed else "PENDING",
            "completed": completed,
            "signatures_collected": result.signature_count,
            "signatures_required": result.required_signatures,
            "authorities_signed": list(result.authorities_signed),
        }

        # Check Accept header for HTMX HTML response
        accept = self.headers.get("Accept", "")
        if "text/html" in accept:
            if completed:
                html = (
                    "<div class='approval-complete'>"
                    "&#10003; Override approved and complete &mdash; action released."
                    "</div>"
                )
            else:
                html = self._render_approval_card(result)
            return 200, html.encode("utf-8"), "text/html"

        return 200, _json_bytes(response)

    def _handle_overrides_deny(
        self, ctx: _ServerContext, pending_id: str,
    ) -> tuple[int, bytes] | tuple[int, bytes, str]:
        """POST /v1/overrides/pending/{id}/deny — deny a pending override."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")

        body = self._read_json()
        if not body.get("authority") or not body.get("reason"):
            return _error(400, "validation_error", "authority and reason required")

        p = ctx.runtime.get_pending_override(pending_id)
        if p is None:
            return _error(404, "not_found", "Pending override not found")

        try:
            ctx.runtime._deny_pending_override(
                pending_id, body["authority"], body["reason"]
            )
        except ValueError as e:
            return _error(404, "not_found", str(e))

        response = {
            "pending_id": pending_id,
            "status": "DENIED",
            "denied_by": body["authority"],
            "denied_at": _utcnow_iso(),
        }

        # Check Accept header for HTMX HTML response
        accept = self.headers.get("Accept", "")
        if "text/html" in accept:
            html = (
                "<div class='approval-denied'>"
                "&#10007; Override denied."
                "</div>"
            )
            return 200, html.encode("utf-8"), "text/html"

        return 200, _json_bytes(response)

    def _handle_overrides_history(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/overrides/history — completed, denied, and expired overrides."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")

        from nomotic.types import (
            AUDIT_OVERRIDE_COMPLETE,
            AUDIT_OVERRIDE_DENIED,
            AUDIT_OVERRIDE_EXPIRED,
        )

        records: list[dict[str, Any]] = []
        store = ctx.runtime._persistent_audit_store
        if store is not None:
            params = self._query_params()
            target_types = {
                AUDIT_OVERRIDE_COMPLETE,
                AUDIT_OVERRIDE_DENIED,
                AUDIT_OVERRIDE_EXPIRED,
            }
            # Filter by status if provided
            status_filter = params.get("status", "").upper()
            if status_filter == "COMPLETE":
                target_types = {AUDIT_OVERRIDE_COMPLETE}
            elif status_filter == "DENIED":
                target_types = {AUDIT_OVERRIDE_DENIED}
            elif status_filter == "EXPIRED":
                target_types = {AUDIT_OVERRIDE_EXPIRED}

            agent_filter = params.get("agent_id")
            agents = [agent_filter] if agent_filter else store.list_agents()

            for agent_id in agents:
                for rec in store.query(agent_id):
                    if rec.verdict in target_types:
                        records.append({
                            "record_id": rec.record_id,
                            "timestamp": rec.timestamp,
                            "agent_id": rec.agent_id,
                            "event_type": rec.verdict,
                            "action_id": rec.action_target,
                            "parameters": rec.parameters,
                        })

        records.sort(key=lambda r: r["timestamp"], reverse=True)
        return 200, _json_bytes(records)

    def _handle_overrides_status(
        self, ctx: _ServerContext, pending_id: str,
    ) -> tuple[int, bytes]:
        """GET /v1/overrides/pending/{id}/status — lightweight status poll."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")
        p = ctx.runtime.get_pending_override(pending_id)
        if p is None:
            return _error(404, "not_found", "Pending override not found")
        ttl = max(0, int(p.expires_at - time.time()))
        return 200, _json_bytes({
            "pending_id": pending_id,
            "status": p.status,
            "signatures_collected": p.signature_count,
            "signatures_required": p.required_signatures,
            "ttl_seconds_remaining": ttl,
            "is_expired": p.is_expired,
        })

    def _handle_override_callback(
        self, ctx: _ServerContext, pending_id: str,
    ) -> tuple[int, bytes]:
        """POST /v1/overrides/{id}/callback — webhook callback approval/deny."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")

        body = self._read_json()
        decision = body.get("decision", "")
        authority = body.get("authority", "")
        reason = body.get("reason", "")
        callback_token = body.get("callback_token", "")

        if decision not in ("approve", "deny"):
            return _error(400, "bad_request", "decision must be 'approve' or 'deny'")
        if not authority or not reason:
            return _error(400, "bad_request", "authority and reason required")

        # Look up pending override
        p = ctx.runtime.get_pending_override(pending_id)
        if p is None:
            return _error(404, "not_found", "Pending override not found or already resolved")

        # Verify callback token
        from nomotic.webhook_callback import _verify_callback_token
        webhook_secret = _get_webhook_secret(ctx.runtime)
        if not _verify_callback_token(pending_id, p.expires_at, callback_token, webhook_secret):
            return _error(401, "unauthorized", "Invalid callback token")

        # Check token expiry
        if time.time() > p.expires_at:
            return _error(410, "gone", "Callback URL has expired")

        # Validate authority
        if ctx.runtime._authority_registry is not None:
            try:
                if not ctx.runtime._authority_registry.is_valid(authority):
                    return _error(403, "forbidden", "Authority not in GovernanceAuthorityRegistry")
            except (AttributeError, TypeError):
                pass

        if decision == "approve":
            try:
                result = ctx.runtime.cosign_override(
                    pending_id, authority, reason, role_check=False,
                )
                completed = result.status == "COMPLETE"
                return 200, _json_bytes({
                    "pending_id": pending_id,
                    "decision": "approve",
                    "status": "COMPLETE" if completed else "PENDING",
                    "completed": completed,
                })
            except ValueError as e:
                return _error(400, "bad_request", str(e))
        else:
            try:
                ctx.runtime._deny_pending_override(pending_id, authority, reason)
                return 200, _json_bytes({
                    "pending_id": pending_id,
                    "decision": "deny",
                    "status": "DENIED",
                })
            except ValueError as e:
                return _error(404, "not_found", str(e))

    def _handle_slack_interaction(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """POST /v1/slack/interaction — Slack interactive component callback."""
        if ctx.runtime is None:
            return _error(503, "unavailable", "Runtime not configured")

        slack_notifier = getattr(ctx.runtime, "_slack_notifier", None)
        if slack_notifier is None:
            return _error(503, "unavailable", "Slack integration not configured")

        # Read raw body for signature verification
        length = int(self.headers.get("Content-Length", "0"))
        body_raw = self.rfile.read(length) if length > 0 else b""
        body_str = body_raw.decode("utf-8")

        # Verify Slack signature
        timestamp = self.headers.get("X-Slack-Request-Timestamp", "")
        signature = self.headers.get("X-Slack-Signature", "")
        if not slack_notifier.verify_slack_signature(body_str, timestamp, signature):
            return _error(401, "unauthorized", "Invalid Slack signature")

        # Parse payload
        from urllib.parse import parse_qs
        parsed = parse_qs(body_str)
        payload_str = parsed.get("payload", ["{}"])[0]
        payload = json.loads(payload_str)

        result = slack_notifier.handle_interaction(payload)
        return 200, _json_bytes(result)

    # ── Approval Queue UI Panel (F-05 Part B) ────────────────────────

    def _render_approval_card(self, pending: Any) -> str:
        """Render a single approval card as HTML."""
        ttl = max(0, int(pending.expires_at - time.time()))
        sig_pct = (
            int(pending.signature_count / pending.required_signatures * 100)
            if pending.required_signatures > 0 else 0
        )
        minutes = ttl // 60
        seconds = ttl % 60
        formatted_ttl = f"{minutes}:{seconds:02d}"
        expires_at_iso = datetime.fromtimestamp(
            pending.expires_at, tz=timezone.utc
        ).isoformat()
        signed_by = ", ".join(pending.authorities_signed) or "No signatures yet"

        return (
            f"<div class='approval-card' id='approval-{pending.override_id}'>"
            f"<div class='approval-header'>"
            f"<span class='agent-name'>{pending.agent_id}</span>"
            f"<span class='action-badge'>{pending.override_type} &rarr; {pending.action_id}</span>"
            f"</div>"
            f"<div class='approval-reason'>{pending.initial_reason}</div>"
            f"<div class='approval-signatures'>"
            f"<div class='sig-progress'>"
            f"<div class='sig-bar' style='width: {sig_pct}%'></div>"
            f"</div>"
            f"<span>{pending.signature_count} of {pending.required_signatures} signatures</span>"
            f"</div>"
            f"<div class='approval-signers'>Signed by: {signed_by}</div>"
            f"<div class='approval-timer' data-expires='{expires_at_iso}' data-ttl='{ttl}'>"
            f"Expires in <span class='countdown'>{formatted_ttl}</span>"
            f"</div>"
            f"<div class='approval-actions'>"
            f"<button class='btn-approve' "
            f"hx-post='/v1/overrides/pending/{pending.override_id}/approve' "
            f"hx-target='#approval-{pending.override_id}' "
            f"hx-swap='outerHTML' "
            f"""hx-vals='{{"authority": "", "reason": ""}}' """
            f"onclick=\"return collectApprovalInput(this, '{pending.override_id}')\">"
            f"Approve</button>"
            f"<button class='btn-deny' "
            f"hx-post='/v1/overrides/pending/{pending.override_id}/deny' "
            f"hx-target='#approval-{pending.override_id}' "
            f"hx-swap='outerHTML' "
            f"""hx-vals='{{"authority": "", "reason": ""}}' """
            f"onclick=\"return collectDenyInput(this, '{pending.override_id}')\">"
            f"Deny</button>"
            f"</div>"
            f"</div>"
        )

    def _handle_ui_panel_approval_queue(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str]:
        """GET /v1/ui/panels/approval-queue — HTML approval queue panel."""
        if ctx.runtime is None:
            html = (
                "<div class='empty-state'>"
                "No pending approvals &mdash; all escalated actions have been resolved"
                "</div>"
            )
            return 200, html.encode("utf-8"), "text/html"

        pending = ctx.runtime.get_pending_overrides()
        if not pending:
            html = (
                "<div class='empty-state'>"
                "No pending approvals &mdash; all escalated actions have been resolved"
                "</div>"
            )
            return 200, html.encode("utf-8"), "text/html"

        parts: list[str] = []
        for p in pending:
            parts.append(self._render_approval_card(p))

        # Add countdown timer script
        parts.append(
            "<script>"
            "function startCountdowns() {"
            "  document.querySelectorAll('.approval-timer').forEach(function(el) {"
            "    var ttl = parseInt(el.dataset.ttl, 10);"
            "    var span = el.querySelector('.countdown');"
            "    var tick = setInterval(function() {"
            "      ttl--;"
            "      if (ttl <= 0) { clearInterval(tick); span.textContent = 'Expired'; return; }"
            "      var m = Math.floor(ttl / 60), s = ttl % 60;"
            "      span.textContent = m + ':' + s.toString().padStart(2, '0');"
            "      if (ttl < 120) span.style.color = '#C00000';"
            "    }, 1000);"
            "  });"
            "}"
            "document.body.addEventListener('htmx:afterSwap', startCountdowns);"
            "startCountdowns();"
            "</script>"
        )

        # Add approve/deny input collection scripts
        parts.append(
            "<script>"
            "function collectApprovalInput(btn, pendingId) {"
            "  var authority = prompt('Your name or ID (required):');"
            "  if (!authority) return false;"
            "  var reason = prompt('Approval reason (optional):') || 'Approved via dashboard';"
            "  btn.setAttribute('hx-vals', JSON.stringify({authority: authority, reason: reason}));"
            "  return true;"
            "}"
            "function collectDenyInput(btn, pendingId) {"
            "  var authority = prompt('Your name or ID (required):');"
            "  if (!authority) return false;"
            "  var reason = prompt('Denial reason (required):');"
            "  if (!reason) return false;"
            "  btn.setAttribute('hx-vals', JSON.stringify({authority: authority, reason: reason}));"
            "  return true;"
            "}"
            "</script>"
        )

        return 200, "\n".join(parts).encode("utf-8"), "text/html"

    # ── Playground handlers (F-17) ──────────────────────────────────

    def _handle_playground_evaluate(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str] | tuple[int, bytes]:
        """POST /v1/playground/evaluate — ephemeral governance evaluation."""
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig
        from nomotic.types import Action, AgentContext, TrustProfile
        from nomotic.priors import PriorRegistry, ARCHETYPE_PRIOR_MAP

        data = self._read_json()

        # Validate required fields
        action_data = data.get("action", {})
        agent_data = data.get("agent", {})
        config_data = data.get("config", {})

        if not action_data.get("type"):
            return _error(400, "validation_error", "Missing required field: action.type")
        if not action_data.get("target"):
            return _error(400, "validation_error", "Missing required field: action.target")
        archetype = agent_data.get("archetype")
        if not archetype:
            return _error(400, "validation_error", "Missing required field: agent.archetype")
        trust_score = agent_data.get("trust_score")
        if trust_score is None:
            return _error(400, "validation_error", "Missing required field: agent.trust_score")

        # Validate archetype exists
        registry = PriorRegistry.with_defaults()
        prior = registry.get(archetype)
        if prior is None and archetype not in ARCHETYPE_PRIOR_MAP and archetype != "general-purpose":
            return _error(400, "validation_error", f"Unknown archetype: {archetype}")

        # Build thresholds
        trust_low = float(config_data.get("trust_low_threshold", 0.35))
        trust_high = float(config_data.get("trust_high_threshold", 0.65))
        weight_overrides = config_data.get("dimension_weight_overrides", {})

        # Build ephemeral runtime
        ephemeral_config = RuntimeConfig(
            allow_threshold=trust_high,
            deny_threshold=trust_low,
        )
        ephemeral_runtime = GovernanceRuntime(ephemeral_config)

        # Apply archetype weight hints
        if prior is not None and prior.weight_hints:
            for dim_name, delta in prior.weight_hints.items():
                dim = ephemeral_runtime.registry.get(dim_name)
                if dim is not None:
                    dim.weight += delta

        # Build effective weights map (before overrides, for reporting)
        effective_weights: dict[str, float] = {}
        for dim in ephemeral_runtime.registry.dimensions:
            effective_weights[dim.name] = dim.weight

        # Apply user weight overrides
        for dim_name, weight_val in weight_overrides.items():
            dim = ephemeral_runtime.registry.get(dim_name)
            if dim is not None:
                dim.weight = float(weight_val)
                effective_weights[dim_name] = float(weight_val)

        # Configure scope for the playground agent so simple reads aren't vetoed
        scope_dim = ephemeral_runtime.registry.get("scope_compliance")
        if scope_dim is not None:
            allowed_types = {"read", "write", "query", "create", "send",
                             "delete", "escalate", "update", "execute"}
            allowed_types.add(action_data["type"])
            scope_dim.configure_agent_scope("playground-agent", allowed_types)

        # Create Action and AgentContext
        action = Action(
            agent_id="playground-agent",
            action_type=action_data["type"],
            target=action_data["target"],
            parameters=action_data.get("parameters", {}),
            metadata={"reversible": action_data.get("reversible", True)},
        )

        trust_profile = TrustProfile(
            agent_id="playground-agent",
            overall_trust=float(trust_score),
        )
        agent_ctx = AgentContext(
            agent_id="playground-agent",
            trust_profile=trust_profile,
        )

        # Evaluate
        try:
            verdict_obj = ephemeral_runtime.evaluate(action, agent_ctx)
        except Exception as exc:
            return _error(500, "evaluation_error", str(exc))

        result = _build_playground_evaluate_response(
            verdict_obj, action_data["target"],
            archetype, trust_low, trust_high, effective_weights,
        )

        # Store in playground audit (FIFO, max 100)
        ctx.playground_audit.append(result)
        if len(ctx.playground_audit) > 100:
            ctx.playground_audit.pop(0)

        # Check Accept header — return HTML for HTMX or JSON
        accept = self.headers.get("Accept", "")
        if "text/html" in accept:
            html = _render_playground_evaluate_html(result)
            return 200, html.encode("utf-8"), "text/html"

        return 200, _json_bytes(result)

    def _handle_playground_archetypes(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/playground/archetypes — list all archetypes with weights."""
        from nomotic.priors import (
            PriorRegistry, ARCHETYPE_PRIOR_MAP, ARCHETYPE_WEIGHT_HINTS,
        )
        from nomotic.presets import DIMENSION_NAMES

        registry = PriorRegistry.with_defaults()
        archetypes: list[dict[str, Any]] = []

        seen: set[str] = set()
        for alias_name, base_name in ARCHETYPE_PRIOR_MAP.items():
            if alias_name in seen:
                continue
            seen.add(alias_name)

            prior = registry.get(alias_name)
            # Build dimension weights from default metadata + hints
            dim_weights: dict[str, float] = {}
            for dm in _DIMENSION_META:
                dim_weights[dm["name"]] = dm["weight"]

            if prior is not None and prior.weight_hints:
                for k, v in prior.weight_hints.items():
                    if k in dim_weights:
                        dim_weights[k] = round(dim_weights[k] + v, 2)

            preset = _ARCHETYPE_PRESET_MAPPING.get(
                base_name or alias_name, "standard",
            )

            archetypes.append({
                "name": alias_name,
                "display_name": alias_name.replace("-", " ").title(),
                "resolves_to": base_name if base_name != alias_name else None,
                "compliance_preset": preset,
                "dimension_weights": dim_weights,
            })

        return 200, _json_bytes(archetypes)

    def _handle_playground_presets(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/playground/presets — list compliance presets."""
        from nomotic.presets import list_presets, DIMENSION_NAMES

        presets: list[dict[str, Any]] = []
        for p in list_presets():
            # Compute dimension overrides as deltas from default weights
            default_weights = {dm["name"]: dm["weight"] for dm in _DIMENSION_META}
            overrides: dict[str, float] = {}
            for dim_name, preset_weight in p.dimension_weights.items():
                default_w = default_weights.get(dim_name, 1.0)
                delta = round(preset_weight - default_w, 2)
                if abs(delta) > 0.01:
                    overrides[dim_name] = delta

            presets.append({
                "name": p.name,
                "display_name": p.display_name,
                "description": p.description,
                "category": p.category,
                "dimension_overrides": overrides,
                "dimension_weights": dict(p.dimension_weights),
                "allow_threshold": p.allow_threshold,
                "deny_threshold": p.deny_threshold,
                "veto_dimensions": list(p.veto_dimensions),
            })

        return 200, _json_bytes(presets)

    def _handle_playground_export(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str, dict[str, str]]:
        """POST /v1/playground/export-config — export as nomotic.yaml."""
        data = self._read_json()

        agent_data = data.get("agent", {})
        config_data = data.get("config", {})
        action_data = data.get("action", {})

        archetype = agent_data.get("archetype", "general-purpose")
        trust_score = agent_data.get("trust_score", 0.5)
        preset = agent_data.get("compliance_preset", "")
        trust_low = config_data.get("trust_low_threshold", 0.35)
        trust_high = config_data.get("trust_high_threshold", 0.65)
        weight_overrides = config_data.get("dimension_weight_overrides", {})

        lines = [
            "# Nomotic Governance Configuration",
            "# Generated by Nomotic Playground",
            f"# Archetype: {archetype}",
            "",
            "version: '1'",
            "",
            "governance:",
        ]
        if preset:
            lines.append(f"  extends: {preset}")
        lines.extend([
            f"  allow_threshold: {trust_high}",
            f"  deny_threshold: {trust_low}",
            "",
            "agents:",
            f"  playground-agent:",
            f"    archetype: {archetype}",
            f"    trust_score: {trust_score}",
            "    scope:",
            "      actions:",
            f"        - {action_data.get('type', 'read')}",
            "      targets:",
            f"        - {action_data.get('target', '*')}",
        ])

        if weight_overrides:
            lines.extend([
                "",
                "  dimension_weights:",
            ])
            for dim_name, w in weight_overrides.items():
                lines.append(f"    {dim_name}: {w}")

        yaml_content = "\n".join(lines) + "\n"
        headers = {
            "Content-Disposition": 'attachment; filename="nomotic.yaml"',
        }
        return 200, yaml_content.encode("utf-8"), "application/x-yaml", headers

    # ── Config Editor API (F-14) ────────────────────────────────────

    def _handle_ui_config_get(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """GET /v1/ui/config — return current nomotic.yaml as parsed JSON."""
        config_path = ctx.base_dir / "nomotic.yaml"
        if not config_path.is_file():
            return _error(404, "no_config", "nomotic.yaml not found. Use the editor to create one from defaults.")

        try:
            raw_yaml = config_path.read_text(encoding="utf-8")
        except OSError as exc:
            return _error(500, "read_error", f"Cannot read config: {exc}")

        try:
            import yaml as _yaml
            parsed = _yaml.safe_load(raw_yaml) or {}
        except Exception as exc:
            return _error(500, "parse_error", f"Cannot parse config: {exc}")

        agent = parsed.get("agent", {})
        if not isinstance(agent, dict):
            agent = {}
        compliance = parsed.get("compliance", {})
        if not isinstance(compliance, dict):
            compliance = {}
        governance = parsed.get("governance", {})
        if not isinstance(governance, dict):
            governance = {}
        dimension_weights = parsed.get("dimension_weights", {})
        if not isinstance(dimension_weights, dict):
            dimension_weights = {}

        result = {
            "agent": agent,
            "compliance": compliance,
            "dimension_weights": dimension_weights,
            "governance": governance,
            "raw_yaml": raw_yaml,
        }
        return 200, _json_bytes(result)

    def _handle_ui_config_validate(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes]:
        """POST /v1/ui/config/validate — validate a config JSON payload."""
        from nomotic.config_loader import (
            load_governance_config_from_string,
            validate_governance_config,
        )
        from nomotic.presets import DIMENSION_NAMES

        data = self._read_json()
        errors: list[str] = []
        warnings: list[str] = []

        # Build a nomotic.yaml string from the JSON payload
        agent = data.get("agent", {})
        compliance = data.get("compliance", {})
        governance = data.get("governance", {})
        dimension_weights = data.get("dimension_weights", {})

        # Validate agent.name is present
        if not agent.get("name"):
            errors.append("agent.name is required")

        # Validate archetype is known
        archetype = agent.get("archetype", "")
        if archetype:
            from nomotic.priors import ARCHETYPE_PRIOR_MAP
            known_archetypes = set(ARCHETYPE_PRIOR_MAP.keys())
            # Also add names from the preset mapping and registry
            known_archetypes.update(_ARCHETYPE_PRESET_MAPPING.keys())
            arch_reg = ctx.archetype_registry
            for arch_def in arch_reg.list():
                known_archetypes.add(arch_def.name)
            if archetype not in known_archetypes:
                errors.append(f"Unknown archetype '{archetype}'")

        # Check dimension weights for warnings
        valid_dims = set(DIMENSION_NAMES)
        for dim_name, weight in dimension_weights.items():
            if dim_name not in valid_dims:
                errors.append(f"Unknown dimension '{dim_name}'")
            else:
                try:
                    w = float(weight)
                    if w > 5.0:
                        warnings.append(
                            f"dimension_weights.{dim_name} = {w} outside normal range (0-5)"
                        )
                    elif w < 0:
                        errors.append(
                            f"dimension_weights.{dim_name} = {w} must be non-negative"
                        )
                except (TypeError, ValueError):
                    errors.append(f"dimension_weights.{dim_name} is not a number")

        # Check governance thresholds
        trust_low = governance.get("trust_low_threshold")
        trust_high = governance.get("trust_high_threshold")
        if trust_low is not None and trust_high is not None:
            try:
                tl = float(trust_low)
                th = float(trust_high)
                if tl >= th:
                    errors.append(
                        f"trust_low_threshold ({tl}) must be less than trust_high_threshold ({th})"
                    )
            except (TypeError, ValueError):
                errors.append("trust thresholds must be numbers")

        # Try to build and validate a full config if basic checks pass
        if not errors:
            try:
                yaml_str = _build_yaml_from_editor_data(data)
                config = load_governance_config_from_string(yaml_str)
                schema_errors = validate_governance_config(config)
                for e in schema_errors:
                    errors.append(e)
            except ValueError as exc:
                errors.append(str(exc))
            except Exception:
                pass  # Don't fail on unexpected errors during deep validation

        valid = len(errors) == 0
        result = {
            "valid": valid,
            "errors": errors,
            "warnings": warnings,
        }
        return 200, _json_bytes(result)

    def _handle_ui_config_download(
        self, ctx: _ServerContext,
    ) -> tuple[int, bytes, str, dict[str, str]]:
        """POST /v1/ui/config/download — generate and download nomotic.yaml."""
        data = self._read_json()
        yaml_content = _build_yaml_from_editor_data(data)
        headers = {
            "Content-Disposition": 'attachment; filename="nomotic.yaml"',
        }
        return 200, yaml_content.encode("utf-8"), "application/x-yaml", headers


def _build_yaml_from_editor_data(data: dict[str, Any]) -> str:
    """Build a nomotic.yaml string from config editor JSON payload."""
    agent = data.get("agent", {})
    compliance = data.get("compliance", {})
    governance = data.get("governance", {})
    dimension_weights = data.get("dimension_weights", {})

    lines = [
        "# nomotic.yaml — Governance configuration",
        "# Generated by Nomotic Config Editor",
        "",
        "version: '1.0'",
        "",
    ]

    # Agent section
    lines.append("agents:")
    agent_name = agent.get("name", "my-agent")
    lines.append(f"  {agent_name}:")
    if agent.get("archetype"):
        lines.append(f"    archetype: {agent['archetype']}")
    lines.append("    scope:")
    lines.append("      actions:")
    lines.append("        - '*'")
    lines.append("      targets:")
    lines.append("        - '*'")
    if agent.get("owner"):
        lines.append(f"    owner: {agent['owner']}")
    lines.append("")

    # Governance section
    lines.append("governance:")
    preset = compliance.get("preset", "")
    if preset:
        lines.append(f"  extends: {preset}")
    trust_low = governance.get("trust_low_threshold", 0.35)
    trust_high = governance.get("trust_high_threshold", 0.65)
    lines.append(f"  allow_threshold: {trust_high}")
    lines.append(f"  deny_threshold: {trust_low}")
    budget = governance.get("budget_per_action")
    if budget is not None:
        lines.append(f"  budget_per_action: {budget}")
    interrupt = governance.get("interrupt_threshold")
    if interrupt is not None:
        lines.append(f"  interrupt_threshold: {interrupt}")
    lines.append("")

    # Dimension weights (only non-default)
    if dimension_weights:
        lines.append("dimensions:")
        lines.append("  weights:")
        for dim_name, w in dimension_weights.items():
            lines.append(f"    {dim_name}: {w}")
        lines.append("")

    return "\n".join(lines) + "\n"


def _get_webhook_secret(runtime: Any) -> str:
    """Get the webhook secret from runtime configuration."""
    dispatcher = getattr(runtime, "_webhook_dispatcher", None)
    if dispatcher is not None:
        configs = getattr(dispatcher, "_configs", [])
        for cfg in configs:
            secret = getattr(cfg, "signing_secret", "")
            if secret:
                return secret
    return getattr(runtime.config, "config_backup_signing_secret", "") or "nomotic-webhook-secret"


# ── Playground helpers ──────────────────────────────────────────────────

_ARCHETYPE_PRESET_MAPPING: dict[str, str] = {
    "healthcare-agent": "hipaa_aligned",
    "financial-analyst": "pci_dss_aligned",
    "security-monitor": "soc2_aligned",
    "data-processor": "soc2_aligned",
    "customer-experience": "standard",
    "operations-coordinator": "standard",
    "content-creator": "standard",
    "research-analyst": "standard",
    "sales-agent": "standard",
    "executive-assistant": "standard",
}


def _build_playground_evaluate_response(
    verdict_obj: Any,
    action_target: str,
    archetype: str,
    trust_low: float,
    trust_high: float,
    effective_weights: dict[str, float],
) -> dict[str, Any]:
    """Build the full playground evaluate response dict."""
    verdict_name = verdict_obj.verdict.name
    dimensions = []
    for ds in verdict_obj.dimension_scores:
        dim_meta = next(
            (d for d in _DIMENSION_META if d["name"] == ds.dimension_name),
            None,
        )
        eff_weight = effective_weights.get(ds.dimension_name, ds.weight)
        dimensions.append({
            "name": ds.dimension_name,
            "display_name": dim_meta["display_name"] if dim_meta else ds.dimension_name,
            "score": round(ds.score, 4),
            "weight": round(eff_weight, 2),
            "weighted_contribution": round(ds.score * eff_weight, 4),
            "is_veto": dim_meta["is_veto"] if dim_meta else ds.veto,
            "veto_triggered": ds.dimension_name in verdict_obj.vetoed_by,
            "reasoning": ds.reasoning or _dimension_reasoning(
                ds.dimension_name, ds.score, verdict_obj.vetoed_by,
            ),
        })

    action_to_pass = _compute_action_to_pass(
        verdict_name, verdict_obj.ucs, action_target, dimensions,
    )

    return {
        "verdict": verdict_name,
        "ucs_score": round(verdict_obj.ucs, 4),
        "evaluation_tier": verdict_obj.tier,
        "latency_ms": round(verdict_obj.evaluation_time_ms, 2),
        "dimensions": dimensions,
        "action_to_pass": action_to_pass,
        "config_used": {
            "archetype": archetype,
            "trust_low_threshold": trust_low,
            "trust_high_threshold": trust_high,
            "effective_weights": {
                k: round(v, 2) for k, v in effective_weights.items()
            },
        },
    }


def _render_playground_evaluate_html(result: dict[str, Any]) -> str:
    """Render playground evaluation result as an HTML fragment for HTMX."""
    verdict = result["verdict"]
    ucs = result["ucs_score"]
    tier = result["evaluation_tier"]
    latency = result["latency_ms"]

    verdict_colors = {
        "ALLOW": "#10b981", "DENY": "#ef4444",
        "ESCALATE": "#f59e0b", "SUSPEND": "#8b5cf6",
        "MODIFY": "#3b82f6",
    }
    vc = verdict_colors.get(verdict, "#6b7280")

    ucs_color = "#ef4444" if ucs < 0.35 else ("#f59e0b" if ucs < 0.65 else "#10b981")

    atp = result.get("action_to_pass", {})
    atp_explanation = atp.get("explanation", "")

    dim_rows = ""
    for d in result["dimensions"]:
        bar_w = int(d["score"] * 100)
        bar_color = "#ef4444" if d["score"] < 0.3 else ("#f59e0b" if d["score"] < 0.7 else "#10b981")
        veto_badge = ""
        if d["veto_triggered"]:
            veto_badge = '<span style="background:#ef4444;color:#fff;padding:1px 6px;border-radius:3px;font-size:0.7rem;margin-left:4px;">TRIGGERED</span>'
        elif d["is_veto"]:
            veto_badge = '<span style="background:#374151;color:#9ca3af;padding:1px 6px;border-radius:3px;font-size:0.7rem;margin-left:4px;">VETO</span>'
        bg = "background:rgba(239,68,68,0.1);" if d["veto_triggered"] else ""
        dim_rows += (
            f'<tr style="{bg}">'
            f'<td style="padding:6px 8px;font-size:0.85rem;">{d["display_name"]}{veto_badge}</td>'
            f'<td style="padding:6px 8px;text-align:center;">{d["score"]:.2f}</td>'
            f'<td style="padding:6px 8px;text-align:center;">{d["weight"]:.1f}</td>'
            f'<td style="padding:6px 8px;"><div style="background:#1f2937;border-radius:4px;height:16px;overflow:hidden;">'
            f'<div style="width:{bar_w}%;height:100%;background:{bar_color};border-radius:4px;"></div></div></td>'
            f'</tr>'
        )

    config_used = result.get("config_used", {})
    config_json = json.dumps(config_used, indent=2)

    return f'''
    <div style="margin-bottom:24px;">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;">
        <span style="background:{vc};color:#fff;padding:8px 20px;border-radius:8px;font-size:1.4rem;font-weight:700;">{verdict}</span>
        <div>
          <div style="font-size:2rem;font-weight:700;color:{ucs_color};">{ucs:.4f}</div>
          <div style="color:#9ca3af;font-size:0.8rem;">UCS Score</div>
        </div>
        <div style="margin-left:auto;text-align:right;">
          <div style="color:#9ca3af;font-size:0.8rem;">Tier {tier} &middot; {latency:.2f}ms</div>
        </div>
      </div>
    </div>

    <div style="background:#1c1917;border-left:4px solid #f59e0b;padding:16px;border-radius:0 8px 8px 0;margin-bottom:24px;">
      <div style="color:#f59e0b;font-size:0.85rem;font-weight:600;margin-bottom:4px;">Action to Pass</div>
      <div style="color:#d1d5db;font-size:0.85rem;white-space:pre-wrap;">{atp_explanation}</div>
    </div>

    <h3 style="color:#f3f4f6;margin-bottom:12px;font-size:1rem;">Dimension Breakdown</h3>
    <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
      <thead>
        <tr style="border-bottom:1px solid #374151;">
          <th style="text-align:left;padding:8px;color:#9ca3af;font-size:0.75rem;text-transform:uppercase;">Dimension</th>
          <th style="text-align:center;padding:8px;color:#9ca3af;font-size:0.75rem;text-transform:uppercase;">Score</th>
          <th style="text-align:center;padding:8px;color:#9ca3af;font-size:0.75rem;text-transform:uppercase;">Weight</th>
          <th style="padding:8px;color:#9ca3af;font-size:0.75rem;text-transform:uppercase;">Bar</th>
        </tr>
      </thead>
      <tbody>{dim_rows}</tbody>
    </table>

    <details style="margin-bottom:16px;">
      <summary style="color:#9ca3af;cursor:pointer;font-size:0.85rem;">Configuration Used</summary>
      <pre style="background:#1f2937;padding:12px;border-radius:6px;color:#d1d5db;font-size:0.8rem;overflow-x:auto;margin-top:8px;">{config_json}</pre>
    </details>
    '''


# ── Server context ──────────────────────────────────────────────────────


class _ServerContext:
    """Shared state accessible to all request handlers."""

    def __init__(
        self,
        ca: CertificateAuthority,
        archetype_registry: ArchetypeRegistry,
        zone_validator: ZoneValidator,
        org_registry: OrganizationRegistry,
        runtime: Any = None,
        evaluator: ProtocolEvaluator | None = None,
        base_dir: Path | None = None,
        prometheus: Any = None,
        ui_enabled: bool = False,
        poll_interval: int = 15,
        api_key: str | None = None,
        playground_enabled: bool = False,
    ) -> None:
        self.ca = ca
        self.archetype_registry = archetype_registry
        self.zone_validator = zone_validator
        self.org_registry = org_registry
        self.runtime = runtime
        self.evaluator = evaluator
        self.base_dir: Path = base_dir or Path.home() / ".nomotic"
        self.prometheus = prometheus
        self.started_at = time.time()
        self.ui_enabled = ui_enabled
        self.ui_dir = Path(__file__).parent / "ui"
        self.poll_interval = poll_interval
        self.api_key = api_key
        self.playground_enabled = playground_enabled
        self.playground_audit: list[dict[str, Any]] = []


class NomoticHTTPServer(HTTPServer):
    """HTTPServer subclass that carries the shared context."""

    ctx: _ServerContext


# ── Public API ──────────────────────────────────────────────────────────


class NomoticAPIServer:
    """HTTP API server for the Nomotic governance framework.

    Wraps :class:`CertificateAuthority`, registries, and optionally
    :class:`GovernanceRuntime` to expose governance operations over HTTP.
    """

    def __init__(
        self,
        ca: CertificateAuthority,
        *,
        archetype_registry: ArchetypeRegistry | None = None,
        zone_validator: ZoneValidator | None = None,
        org_registry: OrganizationRegistry | None = None,
        runtime: Any = None,
        evaluator: ProtocolEvaluator | None = None,
        base_dir: Path | None = None,
        prometheus: Any = None,
        host: str = "0.0.0.0",
        port: int = 8420,
        ui_enabled: bool = False,
        poll_interval: int = 15,
        api_key: str | None = None,
        playground_enabled: bool = False,
    ) -> None:
        self._ca = ca
        self._archetype_registry = archetype_registry or ArchetypeRegistry.with_defaults()
        self._zone_validator = zone_validator or ZoneValidator()
        self._org_registry = org_registry or OrganizationRegistry()
        self._runtime = runtime
        self._evaluator = evaluator
        self._base_dir = base_dir or Path.home() / ".nomotic"
        self._prometheus = prometheus
        self._host = host
        self._port = port
        self._ui_enabled = ui_enabled
        self._poll_interval = poll_interval
        self._api_key = api_key
        self._playground_enabled = playground_enabled
        self._server: NomoticHTTPServer | None = None

    def _build_server(self) -> NomoticHTTPServer:
        server = NomoticHTTPServer((self._host, self._port), _Handler)
        server.ctx = _ServerContext(
            ca=self._ca,
            archetype_registry=self._archetype_registry,
            zone_validator=self._zone_validator,
            org_registry=self._org_registry,
            runtime=self._runtime,
            evaluator=self._evaluator,
            base_dir=self._base_dir,
            prometheus=self._prometheus,
            ui_enabled=self._ui_enabled,
            poll_interval=self._poll_interval,
            api_key=self._api_key,
            playground_enabled=self._playground_enabled,
        )
        # Wire fleet simulation if attached
        fleet_sim = getattr(self, "_fleet_sim", None)
        if fleet_sim is not None:
            server.ctx._fleet_sim = fleet_sim  # type: ignore[attr-defined]
        return server

    def serve_forever(self) -> None:
        """Start serving requests (blocks)."""
        self._server = self._build_server()
        self._server.serve_forever()

    def shutdown(self) -> None:
        """Shut down the server."""
        if self._server is not None:
            self._server.shutdown()

    @property
    def server_address(self) -> tuple[str, int]:
        """Return the bound (host, port) tuple."""
        if self._server is not None:
            return self._server.server_address  # type: ignore[return-value]
        return (self._host, self._port)
