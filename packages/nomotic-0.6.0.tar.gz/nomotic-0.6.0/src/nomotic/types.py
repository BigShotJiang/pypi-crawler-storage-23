"""Core types for the Nomotic governance framework.

Every component speaks this vocabulary. Actions describe what agents want to do.
Contexts describe who is doing it and under what circumstances. Verdicts carry
governance decisions. Trust profiles track calibrated confidence in agents.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any

__all__ = [
    "Action",
    "ActionRecord",
    "ActionState",
    "AgentContext",
    "DimensionScore",
    "GovernanceOverrideRecord",
    "GovernanceVerdict",
    "GovernanceWarning",
    "InterruptRequest",
    "MultiSigOverridePolicy",
    "OverrideSignature",
    "PendingOverride",
    "Severity",
    "TrustProfile",
    "UAHSConfig",
    "UserContext",
    "Verdict",
]


class GovernanceWarning(UserWarning):
    """Warning emitted when governance safeguards are not fully configured."""


class Verdict(Enum):
    """The outcome of a governance evaluation."""

    ALLOW = auto()
    DENY = auto()
    MODIFY = auto()
    ESCALATE = auto()
    SUSPEND = auto()


class Severity(Enum):
    """How serious a governance violation is."""

    INFO = auto()
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    CRITICAL = auto()


class ActionState(Enum):
    """Lifecycle state of an action under governance."""

    PENDING = auto()
    EVALUATING = auto()
    APPROVED = auto()
    EXECUTING = auto()
    INTERRUPTED = auto()
    COMPLETED = auto()
    DENIED = auto()
    ROLLED_BACK = auto()


@dataclass(frozen=True)
class Action:
    """An action an agent wants to perform.

    This is the unit of governance. Every action passes through the governance
    runtime before, during, and after execution.
    """

    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    agent_id: str = ""
    action_type: str = ""
    target: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    parent_action_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class UserContext:
    """Information about the user who triggered an agent action.

    Optional — not all agent actions are user-triggered.
    Batch processing, scheduled tasks, and autonomous workflows
    may have no user context.
    """

    user_id: str = ""           # Identifier for the user (email, ID, session)
    session_id: str = ""        # User's session (for tracking repeated interactions)
    request_hash: str = ""      # Hash of user's input (NOT the input itself — privacy)
    classification: str = ""    # "normal", "out_of_scope", "suspicious", "manipulation"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class UAHSConfig:
    """Configuration for UAHS auto-integration in GovernanceRuntime.

    When enable_uahs=True is passed to GovernanceRuntime, the ambiguity drift
    system, unified health scoring, and feedback loop management are
    automatically wired into the post-evaluation pipeline.
    """

    scoring_interval: int = 50
    # Compute UAHS every N evaluations per agent (not every evaluation —
    # health scoring has ~0.5ms overhead and is not needed every call)

    feedback_enabled: bool = True
    # Wire FeedbackLoopManager to apply trust calibration adjustments
    # when UAHS crosses status boundaries

    health_store_enabled: bool = True
    # Persist health events to GovernanceHealthStore in the audit directory

    drift_config: Any | None = None
    # Optional AmbiguityDriftConfig to override defaults for all agents

    drift_alert_threshold: float = 0.3
    """Minimum drift score to trigger a DRIFT_ALARM webhook.
    Range 0.0-1.0. Lower = more sensitive.
    Default 0.3: fire alarm when drift score exceeds 30%.
    """

    archetype_thresholds: dict[str, float] = field(default_factory=dict)
    """Per-archetype override thresholds.
    Keys are archetype names (e.g. "decision_maker", "executor").
    Values override drift_alert_threshold for that archetype.
    Archetypes not present fall back to drift_alert_threshold.
    """

    min_evaluations_before_alert: int = 10
    """Suppress drift alerts until at least N evaluations recorded.
    Prevents false positives on newly created agents with limited history.
    """

    def to_dict(self) -> dict[str, Any]:
        return {
            "scoring_interval": self.scoring_interval,
            "feedback_enabled": self.feedback_enabled,
            "health_store_enabled": self.health_store_enabled,
            "drift_alert_threshold": self.drift_alert_threshold,
            "archetype_thresholds": dict(self.archetype_thresholds),
            "min_evaluations_before_alert": self.min_evaluations_before_alert,
        }


@dataclass
class AgentContext:
    """Everything governance knows about the agent requesting an action.

    This includes identity, current trust level, session history, and
    any active constraints.
    """

    agent_id: str
    trust_profile: TrustProfile
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    action_history: list[ActionRecord] = field(default_factory=list)
    active_constraints: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    user_context: UserContext | None = None
    context_profile_id: str | None = None  # reference to active ContextProfile


@dataclass
class TrustProfile:
    """Calibrated trust in an agent, updated continuously based on behavior.

    Trust is not binary. It is a set of scores across dimensions, with an
    overall level that determines what the agent is permitted to do.
    """

    agent_id: str
    overall_trust: float = 0.5  # 0.0 = no trust, 1.0 = full trust
    dimension_trust: dict[str, float] = field(default_factory=dict)
    violation_count: int = 0
    successful_actions: int = 0
    last_violation_time: float | None = None
    last_updated: float = field(default_factory=time.time)

    @property
    def violation_rate(self) -> float:
        total = self.violation_count + self.successful_actions
        if total == 0:
            return 0.0
        return self.violation_count / total


@dataclass
class DimensionScore:
    """A single governance dimension's assessment of an action."""

    dimension_name: str
    score: float  # 0.0 = maximum concern, 1.0 = no concern
    weight: float = 1.0
    confidence: float = 1.0
    veto: bool = False
    reasoning: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class GovernanceVerdict:
    """The complete governance decision for an action.

    Includes the verdict, the unified confidence score, individual dimension
    scores, which tier made the decision, and whether any dimension vetoed.
    """

    action_id: str
    verdict: Verdict
    ucs: float  # Unified Confidence Score: 0.0 = deny, 1.0 = full confidence
    dimension_scores: list[DimensionScore] = field(default_factory=list)
    tier: int = 1  # Which tier (1, 2, or 3) made the final decision
    vetoed_by: list[str] = field(default_factory=list)
    modifications: dict[str, Any] = field(default_factory=dict)
    reasoning: str = ""
    timestamp: float = field(default_factory=time.time)
    evaluation_time_ms: float = 0.0
    context_modification: Any = None  # ContextModification from Phase 7B, if present
    cross_dimensional_signals: list[Any] = field(default_factory=list)  # Phase 8 signals
    reversibility: dict[str, Any] | None = None  # ReversibilityAssessment.to_dict()


@dataclass
class ActionRecord:
    """A completed action with its governance verdict and outcome."""

    action: Action
    verdict: GovernanceVerdict
    state: ActionState = ActionState.COMPLETED
    outcome: dict[str, Any] = field(default_factory=dict)
    interrupted: bool = False
    interrupt_reason: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class InterruptRequest:
    """A request to interrupt an action in progress."""

    action_id: str
    reason: str
    source: str  # Which dimension or system triggered the interrupt
    severity: Severity = Severity.HIGH
    scope: str = "action"  # "action", "agent", or "workflow"
    timestamp: float = field(default_factory=time.time)


@dataclass
class GovernanceOverrideRecord:
    """Record of a post-hoc human override of a governance decision.

    APPROVE overrides reverse a DENY — the human reviewed and accepted the risk.
    REVOKE overrides reverse an ALLOW — the action should not have been permitted.

    This is distinct from OverrideRecord in context_profile.py, which tracks
    step-level workflow overrides within a context profile.
    """

    override_id: str                 # Format: "nmo-<uuid4>"
    action_id: str                   # The original action being overridden
    override_type: str               # "APPROVE" or "REVOKE"
    original_verdict: str            # "ALLOW" or "DENY" from original evaluation
    authority: str                   # Who issued the override
    reason: str                      # Why
    agent_id: str                    # Which agent's action
    trust_before: float              # Agent trust before override
    trust_after: float               # Agent trust after override
    timestamp: float = field(default_factory=time.time)
    role_id: str | None = None       # Role that granted permission (if role check was used)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "override_id": self.override_id,
            "action_id": self.action_id,
            "override_type": self.override_type,
            "original_verdict": self.original_verdict,
            "authority": self.authority,
            "reason": self.reason,
            "agent_id": self.agent_id,
            "trust_before": self.trust_before,
            "trust_after": self.trust_after,
            "timestamp": self.timestamp,
        }
        if self.role_id is not None:
            d["role_id"] = self.role_id
        return d


@dataclass
class MultiSigOverridePolicy:
    """M-of-N threshold policy for override authorization."""

    policy_id: str                           # "nmpol-<uuid4>"
    name: str

    # Threshold
    required_signatures: int                 # M — minimum signatures to execute
    eligible_roles: list[str]               # Role IDs whose holders can sign
    max_same_role_signatures: int = 1       # Prevent all sigs from same role

    # Scope — which overrides this policy applies to
    applies_to_override_types: list[str] = field(default_factory=lambda: ["APPROVE", "REVOKE"])
    applies_to_risk_tiers: list[str] = field(default_factory=lambda: ["critical", "high"])
    applies_to_reversibilities: list[str] = field(default_factory=list)  # empty = all
    applies_to_zones: list[str] = field(default_factory=lambda: ["*"])

    # Window
    authorization_window_seconds: int = 3600  # 1 hour default

    def to_dict(self) -> dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "name": self.name,
            "required_signatures": self.required_signatures,
            "eligible_roles": self.eligible_roles,
            "max_same_role_signatures": self.max_same_role_signatures,
            "applies_to_override_types": self.applies_to_override_types,
            "applies_to_risk_tiers": self.applies_to_risk_tiers,
            "applies_to_reversibilities": self.applies_to_reversibilities,
            "applies_to_zones": self.applies_to_zones,
            "authorization_window_seconds": self.authorization_window_seconds,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MultiSigOverridePolicy:
        return cls(
            policy_id=data["policy_id"],
            name=data["name"],
            required_signatures=data["required_signatures"],
            eligible_roles=data["eligible_roles"],
            max_same_role_signatures=data.get("max_same_role_signatures", 1),
            applies_to_override_types=data.get("applies_to_override_types", ["APPROVE", "REVOKE"]),
            applies_to_risk_tiers=data.get("applies_to_risk_tiers", ["critical", "high"]),
            applies_to_reversibilities=data.get("applies_to_reversibilities", []),
            applies_to_zones=data.get("applies_to_zones", ["*"]),
            authorization_window_seconds=data.get("authorization_window_seconds", 3600),
        )


# ── Multi-sig override audit event types ─────────────────────────────
AUDIT_OVERRIDE_PENDING_CREATED = "OVERRIDE_PENDING_CREATED"
AUDIT_OVERRIDE_COSIGNED = "OVERRIDE_COSIGNED"
AUDIT_OVERRIDE_COMPLETE = "OVERRIDE_COMPLETE"
AUDIT_OVERRIDE_EXPIRED = "OVERRIDE_EXPIRED"
AUDIT_OVERRIDE_DENIED = "OVERRIDE_DENIED"

import hashlib as _hashlib


@dataclass
class OverrideSignature:
    """A single authority's signature on a pending override."""

    signature_id: str         # "nmosig-<uuid4>"
    authority: str            # Who signed
    role_id: str | None       # Which role authorized this signature
    reason: str               # Justification
    signed_at: float          # Unix timestamp
    signature_hash: str       # SHA-256 of (pending_override_id + authority + reason + str(signed_at))

    def to_dict(self) -> dict[str, Any]:
        return {
            "signature_id": self.signature_id,
            "authority": self.authority,
            "role_id": self.role_id,
            "reason": self.reason,
            "signed_at": self.signed_at,
            "signature_hash": self.signature_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OverrideSignature:
        return cls(
            signature_id=data["signature_id"],
            authority=data["authority"],
            role_id=data.get("role_id"),
            reason=data["reason"],
            signed_at=data["signed_at"],
            signature_hash=data["signature_hash"],
        )

    @staticmethod
    def compute_hash(pending_override_id: str, authority: str, reason: str, signed_at: float) -> str:
        payload = pending_override_id + authority + reason + str(signed_at)
        return _hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass
class PendingOverride:
    """An override awaiting M-of-N signature threshold."""

    override_id: str           # "nmpo-<uuid4>"
    action_id: str
    agent_id: str
    override_type: str         # "APPROVE" or "REVOKE"
    policy_id: str             # Which MultiSigOverridePolicy applies
    required_signatures: int   # M
    signatures: list[OverrideSignature] = field(default_factory=list)
    status: str = "PENDING"    # "PENDING" | "COMPLETE" | "EXPIRED"
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0    # Computed at creation: created_at + window
    completed_at: float | None = None
    original_verdict: str = ""
    initial_authority: str = ""
    initial_reason: str = ""

    @property
    def signature_count(self) -> int:
        return len(self.signatures)

    @property
    def signatures_remaining(self) -> int:
        return max(0, self.required_signatures - self.signature_count)

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at and self.status == "PENDING"

    @property
    def authorities_signed(self) -> list[str]:
        return [s.authority for s in self.signatures]

    def to_dict(self) -> dict[str, Any]:
        return {
            "override_id": self.override_id,
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "override_type": self.override_type,
            "policy_id": self.policy_id,
            "required_signatures": self.required_signatures,
            "signatures": [s.to_dict() for s in self.signatures],
            "status": self.status,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "completed_at": self.completed_at,
            "original_verdict": self.original_verdict,
            "initial_authority": self.initial_authority,
            "initial_reason": self.initial_reason,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PendingOverride:
        sigs = [OverrideSignature.from_dict(s) for s in data.get("signatures", [])]
        return cls(
            override_id=data["override_id"],
            action_id=data["action_id"],
            agent_id=data["agent_id"],
            override_type=data["override_type"],
            policy_id=data["policy_id"],
            required_signatures=data["required_signatures"],
            signatures=sigs,
            status=data.get("status", "PENDING"),
            created_at=data.get("created_at", 0.0),
            expires_at=data.get("expires_at", 0.0),
            completed_at=data.get("completed_at"),
            original_verdict=data.get("original_verdict", ""),
            initial_authority=data.get("initial_authority", ""),
            initial_reason=data.get("initial_reason", ""),
        )
