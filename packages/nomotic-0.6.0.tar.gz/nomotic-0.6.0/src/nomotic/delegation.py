"""Multi-Agent Handoff Reporting — delegation chain tracking.

When Agent A delegates work to Agent B, this module captures the
delegation chain: who delegated, under what authority, and whether
Agent B's certificate authorizes the delegated scope.

Delegations are session-scoped (in-memory) for v0.4.0. Each delegation
produces a DelegationRecord that can be written to the audit trail.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "DEFAULT_DELEGATION_DEPTH_LIMITS",
    "DelegationChainVisualizer",
    "DelegationDepthConfig",
    "DelegationDepthError",
    "DelegationRecord",
    "DelegationTracker",
]


# ── Delegation depth limits ────────────────────────────────────────────

DEFAULT_DELEGATION_DEPTH_LIMITS: dict[str, int] = {
    "decision_maker": 3,
    "specialist": 2,
    "gatekeeper": 1,
    "observer": 0,       # Observers cannot delegate at all
    "executor": 2,
    "*": 3,              # Fallback for any unconfigured archetype
}


class DelegationDepthError(Exception):
    """Raised when a delegation would exceed the archetype depth limit.

    This is a hard enforcement error — the delegation is not created.
    """

    def __init__(
        self,
        agent_id: str,
        archetype: str,
        current_depth: int,
        attempted_depth: int,
        limit: int,
        chain: list[str],
    ):
        self.agent_id = agent_id
        self.archetype = archetype
        self.current_depth = current_depth
        self.attempted_depth = attempted_depth
        self.limit = limit
        self.chain = chain  # List of agent_ids in the current chain
        super().__init__(
            f"Delegation depth limit exceeded for {agent_id} ({archetype}): "
            f"attempted depth {attempted_depth}, limit {limit}. "
            f"Chain: {' -> '.join(chain)}"
        )


@dataclass
class DelegationDepthConfig:
    """Configuration for delegation depth enforcement."""

    max_depths: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_DELEGATION_DEPTH_LIMITS))
    # archetype -> max depth. "*" is the fallback.

    enforce_at_delegation: bool = True
    # When True, DelegationTracker.delegate() raises DelegationDepthError
    # if the new delegation would exceed the limit.

    enforce_at_evaluation: bool = True
    # When True, actions from agents at over-limit depth receive a UCS reduction
    # via the contextual modifier (does not block, but signals concern).

    def get_limit(self, archetype: str) -> int:
        """Get depth limit for archetype, falling back to '*' if not found."""
        return self.max_depths.get(archetype, self.max_depths.get("*", 3))


@dataclass
class DelegationRecord:
    """Record of an inter-agent delegation."""

    delegation_id: str  # Format: "nmd-<uuid4>"
    from_agent: str  # Delegating agent ID
    to_agent: str  # Receiving agent ID
    delegated_scope: set[str]  # Action types being delegated (e.g., {"read", "write"})
    delegated_targets: set[str]  # Targets being delegated (e.g., {"customers/*"})
    authority_basis: str  # Why from_agent can delegate ("certificate", "human_override")
    timestamp: float = field(default_factory=time.time)
    seal_id: str | None = None  # Governance seal for the delegation action itself
    expires_at: float | None = None  # When this delegation expires (None = session-scoped)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "delegation_id": self.delegation_id,
            "from_agent": self.from_agent,
            "to_agent": self.to_agent,
            "delegated_scope": sorted(self.delegated_scope),
            "delegated_targets": sorted(self.delegated_targets),
            "authority_basis": self.authority_basis,
            "timestamp": self.timestamp,
            "seal_id": self.seal_id,
            "expires_at": self.expires_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DelegationRecord:
        data = dict(data)
        data["delegated_scope"] = set(data.get("delegated_scope", []))
        data["delegated_targets"] = set(data.get("delegated_targets", []))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at


class DelegationTracker:
    """Tracks inter-agent delegations.

    Validates that delegating agents hold the scope they're delegating,
    and that receiving agents have valid certificates.
    """

    def __init__(
        self,
        cert_store: Any = None,
        base_dir: Path | None = None,
        depth_config: DelegationDepthConfig | None = None,
    ):
        self._cert_store = cert_store
        self._base_dir = base_dir or Path.home() / ".nomotic"
        self._depth_config = depth_config or DelegationDepthConfig()
        # Active delegations: to_agent -> list of DelegationRecords
        self._active: dict[str, list[DelegationRecord]] = {}
        # History: all delegations ever created
        self._history: list[DelegationRecord] = []

    def delegate(
        self,
        from_agent: str,
        to_agent: str,
        scope: set[str],
        targets: set[str],
        *,
        authority_basis: str = "certificate",
        seal_id: str | None = None,
        expires_at: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DelegationRecord:
        """Create a delegation from one agent to another.

        Validates:
        1. from_agent has a valid certificate
        2. to_agent has a valid certificate
        3. from_agent holds the scope being delegated (scope is subset of from_agent's allowed actions)

        Raises:
            ValueError: If validation fails
        """
        # Validate certificates
        self._validate_certificate(from_agent, "delegating")
        self._validate_certificate(to_agent, "receiving")

        # Validate scope (from_agent can only delegate what it holds)
        self._validate_scope(from_agent, scope)

        # Enforce delegation depth limits
        if self._depth_config.enforce_at_delegation:
            current_from_depth = self.get_depth(from_agent)
            resulting_depth = current_from_depth + 1
            archetype = self._get_agent_archetype(from_agent)
            limit = self._depth_config.get_limit(archetype)
            if resulting_depth > limit:
                chain_records = self.get_delegation_chain(from_agent)
                chain_ids = [r.from_agent for r in chain_records]
                if not chain_ids or chain_ids[-1] != from_agent:
                    chain_ids.append(from_agent)
                chain_ids.append(to_agent)
                raise DelegationDepthError(
                    agent_id=from_agent,
                    archetype=archetype,
                    current_depth=current_from_depth,
                    attempted_depth=resulting_depth,
                    limit=limit,
                    chain=chain_ids,
                )

        record = DelegationRecord(
            delegation_id=f"nmd-{uuid.uuid4()}",
            from_agent=from_agent,
            to_agent=to_agent,
            delegated_scope=scope,
            delegated_targets=targets,
            authority_basis=authority_basis,
            seal_id=seal_id,
            expires_at=expires_at,
            metadata=metadata or {},
        )

        if to_agent not in self._active:
            self._active[to_agent] = []
        self._active[to_agent].append(record)
        self._history.append(record)

        return record

    def get_active_delegations(self, agent_id: str) -> list[DelegationRecord]:
        """Get active (non-expired) delegations TO this agent."""
        self._evict_expired(agent_id)
        return list(self._active.get(agent_id, []))

    def get_delegations_from(self, agent_id: str) -> list[DelegationRecord]:
        """Get all delegations FROM this agent (active and historical)."""
        return [d for d in self._history if d.from_agent == agent_id]

    def get_delegation_chain(self, agent_id: str) -> list[DelegationRecord]:
        """Trace the full delegation chain for an agent.

        If A delegated to B and B delegated to C, calling this for C
        returns [A->B delegation, B->C delegation].
        """
        chain: list[DelegationRecord] = []
        visited: set[str] = set()
        current = agent_id
        while current not in visited:
            visited.add(current)
            delegations = self.get_active_delegations(current)
            if not delegations:
                break
            # Take most recent delegation
            latest = max(delegations, key=lambda d: d.timestamp)
            chain.insert(0, latest)
            current = latest.from_agent
        return chain

    def has_delegated_scope(self, agent_id: str, action_type: str, target: str) -> bool:
        """Check if an agent has been delegated scope for this action+target."""
        for delegation in self.get_active_delegations(agent_id):
            if action_type in delegation.delegated_scope:
                if self._target_matches(target, delegation.delegated_targets):
                    return True
        return False

    def get_depth(self, agent_id: str) -> int:
        """Return the delegation depth of *agent_id*.

        Root agents (not delegated to by anyone) return 0.
        """
        chain = self.get_delegation_chain(agent_id)
        return len(chain)

    def _get_agent_archetype(self, agent_id: str) -> str:
        """Look up the archetype for *agent_id* from the cert store.

        Returns ``"*"`` if no cert store is attached or no active cert is found.
        """
        if self._cert_store is None:
            return "*"
        try:
            from nomotic.certificate import CertStatus
            all_certs = self._cert_store.list(status=CertStatus.ACTIVE)
            for cert in all_certs:
                if cert.agent_id == agent_id:
                    return getattr(cert, "archetype", "*") or "*"
        except Exception:
            pass
        return "*"

    def _validate_certificate(self, agent_id: str, role: str) -> None:
        """Validate agent has an active certificate."""
        if self._cert_store is None:
            return  # No store = no validation
        from nomotic.certificate import CertStatus

        all_certs = self._cert_store.list(status=CertStatus.ACTIVE)
        active = [c for c in all_certs if c.agent_id == agent_id]
        if not active:
            raise ValueError(f"Cannot {role}: agent '{agent_id}' has no active certificate")

    def _validate_scope(self, agent_id: str, scope: set[str]) -> None:
        """Validate agent holds the scope being delegated.

        For now, this checks the agent's archetype-based scope if available.
        If no scope information is available, validation passes (permissive default).
        """
        # Scope validation is best-effort — if we can't determine the agent's scope,
        # we allow the delegation. The governance evaluation will catch unauthorized
        # actions when the receiving agent tries to execute.
        pass

    def _target_matches(self, target: str, delegated_targets: set[str]) -> bool:
        """Check if a target matches any of the delegated target patterns."""
        for pattern in delegated_targets:
            if pattern == "*":
                return True
            if pattern.endswith("/*"):
                prefix = pattern[:-2]
                if target.startswith(prefix):
                    return True
            if target == pattern:
                return True
        return False

    def _evict_expired(self, agent_id: str) -> None:
        """Remove expired delegations."""
        if agent_id in self._active:
            self._active[agent_id] = [
                d for d in self._active[agent_id] if not d.is_expired()
            ]


class DelegationChainVisualizer:
    """Renders delegation chains as ASCII trees or Graphviz DOT format.

    Uses an existing DelegationTracker for chain data and an optional
    cert store for archetype lookups.
    """

    def __init__(
        self,
        tracker: DelegationTracker,
        cert_store: Any = None,
        depth_config: DelegationDepthConfig | None = None,
    ) -> None:
        self._tracker = tracker
        self._cert_store = cert_store
        self._depth_config = depth_config or DelegationDepthConfig()

    def build_tree(self, root_agent_id: str) -> dict[str, Any]:
        """Build a nested dict tree structure rooted at *root_agent_id*.

        Returns::

            {
              "agent_id": "root-agent",
              "archetype": "decision_maker",
              "depth": 0,
              "depth_limit": 3,
              "exceeds_limit": False,
              "children": [ ... same structure recursively ... ]
            }
        """
        return self._build_node(root_agent_id, depth=0, visited=set())

    def render_ascii(
        self,
        root_agent_id: str,
        show_depth_limits: bool = True,
    ) -> str:
        """Render delegation chain as an ASCII tree.

        Example::

            decision_maker: root-agent (depth=0)
            ├── specialist: child-a (depth=1)
            │   ├── executor: grandchild-1 (depth=2)
            │   └── executor: grandchild-2 (depth=2) ⚠ LIMIT EXCEEDED
            └── specialist: child-b (depth=1)

            Depth limits (decision_maker=3, specialist=2, executor=2)
        """
        tree = self.build_tree(root_agent_id)
        lines: list[str] = []
        self._render_ascii_node(tree, lines, prefix="", is_last=True, is_root=True)
        if show_depth_limits:
            archetypes = self._collect_archetypes(tree)
            if archetypes:
                limits_parts = [f"{a}={self._get_depth_limit(a)}" for a in sorted(archetypes)]
                lines.append("")
                lines.append(f"Depth limits ({', '.join(limits_parts)})")
        return "\n".join(lines)

    def render_dot(self, root_agent_id: str) -> str:
        """Render delegation chain as Graphviz DOT format.

        Nodes are labeled with archetype and depth.  Edges are labeled
        ``"delegates"``.  Nodes exceeding their depth limit use
        ``fillcolor=red``; nodes at the limit use ``fillcolor=orange``;
        all others use ``fillcolor=palegreen``.
        """
        tree = self.build_tree(root_agent_id)
        lines = [
            "digraph DelegationChain {",
            "    rankdir=TB;",
        ]
        self._render_dot_node(tree, lines)
        lines.append("}")
        return "\n".join(lines)

    def find_violations(self, root_agent_id: str) -> list[dict[str, Any]]:
        """Find all agents in the chain that exceed their depth limit.

        Returns a list of dicts::

            [
              {
                "agent_id": "...",
                "archetype": "...",
                "depth": 3,
                "limit": 2,
                "excess": 1,
              },
              ...
            ]
        """
        tree = self.build_tree(root_agent_id)
        violations: list[dict[str, Any]] = []
        self._collect_violations(tree, violations)
        return violations

    # ── Internal helpers ──────────────────────────────────────────────

    def _get_archetype(self, agent_id: str) -> str:
        """Look up archetype from cert store, default to ``'*'``."""
        if self._cert_store is not None:
            try:
                from nomotic.certificate import CertStatus

                all_certs = self._cert_store.list(status=CertStatus.ACTIVE)
                for cert in all_certs:
                    if cert.agent_id == agent_id:
                        return getattr(cert, "archetype", "*") or "*"
            except Exception:
                pass
        return "*"

    def _get_depth_limit(self, archetype: str) -> int:
        """Get depth limit for *archetype* from depth_config."""
        return self._depth_config.get_limit(archetype)

    def _build_node(self, agent_id: str, depth: int, visited: set[str]) -> dict[str, Any]:
        """Recursively build a tree node."""
        visited.add(agent_id)
        archetype = self._get_archetype(agent_id)
        limit = self._get_depth_limit(archetype)
        children: list[dict[str, Any]] = []

        # Find agents this agent delegated to
        delegations_from = self._tracker.get_delegations_from(agent_id)
        for record in delegations_from:
            if not record.is_expired() and record.to_agent not in visited:
                children.append(self._build_node(record.to_agent, depth + 1, visited))

        return {
            "agent_id": agent_id,
            "archetype": archetype,
            "depth": depth,
            "depth_limit": limit,
            "exceeds_limit": depth > limit,
            "children": children,
        }

    def _render_ascii_node(
        self,
        node: dict[str, Any],
        lines: list[str],
        prefix: str,
        is_last: bool,
        is_root: bool,
    ) -> None:
        """Render a single node and its children as ASCII lines."""
        archetype = node["archetype"]
        agent_id = node["agent_id"]
        depth = node["depth"]
        violation = " \u26a0 LIMIT EXCEEDED" if node["exceeds_limit"] else ""

        if is_root:
            lines.append(f"{archetype}: {agent_id} (depth={depth}){violation}")
        else:
            connector = "\u2514\u2500\u2500 " if is_last else "\u251c\u2500\u2500 "
            lines.append(f"{prefix}{connector}{archetype}: {agent_id} (depth={depth}){violation}")

        children = node["children"]
        for i, child in enumerate(children):
            child_is_last = i == len(children) - 1
            if is_root:
                child_prefix = ""
            elif is_last:
                child_prefix = prefix + "    "
            else:
                child_prefix = prefix + "\u2502   "
            self._render_ascii_node(child, lines, child_prefix, child_is_last, is_root=False)

    def _collect_archetypes(self, node: dict[str, Any]) -> set[str]:
        """Collect all archetypes present in the tree."""
        archetypes = {node["archetype"]}
        for child in node["children"]:
            archetypes |= self._collect_archetypes(child)
        return archetypes

    def _render_dot_node(self, node: dict[str, Any], lines: list[str]) -> None:
        """Render DOT node definitions and edges recursively."""
        agent_id = node["agent_id"]
        archetype = node["archetype"]
        depth = node["depth"]
        limit = node["depth_limit"]

        if depth > limit:
            color = "red"
        elif depth == limit:
            color = "orange"
        else:
            color = "palegreen"

        safe_id = agent_id.replace("-", "_").replace(".", "_")
        label = f"{archetype}\\n{agent_id}\\ndepth={depth}"
        lines.append(f'    {safe_id} [label="{label}" shape=box style=filled fillcolor={color}];')

        for child in node["children"]:
            child_safe = child["agent_id"].replace("-", "_").replace(".", "_")
            lines.append(f'    {safe_id} -> {child_safe} [label="delegates"];')
            self._render_dot_node(child, lines)

    def _collect_violations(self, node: dict[str, Any], violations: list[dict[str, Any]]) -> None:
        """Recursively collect all violation nodes."""
        if node["exceeds_limit"]:
            violations.append({
                "agent_id": node["agent_id"],
                "archetype": node["archetype"],
                "depth": node["depth"],
                "limit": node["depth_limit"],
                "excess": node["depth"] - node["depth_limit"],
            })
        for child in node["children"]:
            self._collect_violations(child, violations)
