"""Opt-in anonymous telemetry for Nomotic CLI.

Privacy guarantees:
  - Default OFF. Never collects without explicit opt-in.
  - Collects ONLY: archetype names (hashed), CLI command names (hashed),
    framework names (hashed), Nomotic version, Python version, OS platform.
  - NEVER collects: agent IDs, action types, targets, UCS scores, audit
    content, or any customer data.
  - All collected identifiers hashed with SHA-256 before transmission.
  - Never crashes the main flow. All telemetry errors are silently swallowed.
  - Zero new runtime dependencies.
"""

from __future__ import annotations

import hashlib
import logging
import platform
import threading
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

TELEMETRY_ENDPOINT = "https://telemetry.nomotic.ai/v1/events"

_CONFIG_PATH = Path.home() / ".nomotic" / "config.json"

_instance: TelemetryClient | None = None


class TelemetryClient:
    def __init__(self, enabled: bool, endpoint: str | None = None):
        self.enabled = enabled
        self.endpoint = endpoint or TELEMETRY_ENDPOINT
        self._session_id = self._load_or_create_session_id()

    def _load_or_create_session_id(self) -> str:
        """Load or create a stable session ID for this installation.

        The ID is a SHA-256 hash stored in ~/.nomotic/telemetry_session.
        The raw value it was derived from is never stored.
        """
        session_file = Path.home() / ".nomotic" / "telemetry_session"
        try:
            if session_file.exists():
                return session_file.read_text().strip()
            import secrets

            raw = secrets.token_hex(32)
            hashed = hashlib.sha256(raw.encode()).hexdigest()
            session_file.parent.mkdir(parents=True, exist_ok=True)
            session_file.write_text(hashed)
            return hashed
        except Exception:
            return hashlib.sha256(b"fallback").hexdigest()

    def _hash(self, value: str) -> str:
        """SHA-256 hash, first 16 hex chars. Non-reversible."""
        return hashlib.sha256(value.encode()).hexdigest()[:16]

    def record_archetype(self, archetype_name: str) -> None:
        self._send_event("archetype_declared", {"archetype": archetype_name})

    def record_cli_command(self, command_name: str) -> None:
        """Record command NAME only -- never arguments."""
        self._send_event("cli_command_invoked", {"command": command_name})

    def record_framework_detected(self, framework_name: str) -> None:
        self._send_event("framework_detected", {"framework": framework_name})

    def _send_event(self, event_type: str, properties: dict) -> None:
        if not self.enabled:
            return
        try:
            from nomotic import __version__

            payload = {
                "event": event_type,
                "session_id": self._session_id,
                "nomotic_version": __version__,
                "python_version": platform.python_version(),
                "os_platform": platform.system(),
                "properties": {
                    k: self._hash(str(v)) for k, v in properties.items()
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            threading.Thread(
                target=self._deliver,
                args=(payload,),
                daemon=True,
            ).start()
        except Exception:
            pass  # Never crash. Telemetry is entirely optional.

    def _deliver(self, payload: dict) -> None:
        """Fire and forget delivery. All errors silently swallowed."""
        try:
            import json
            import urllib.request

            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                self.endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # Silently swallow all delivery errors


def _load_telemetry_setting() -> bool:
    """Read telemetry opt-in from ~/.nomotic/config.json. Returns False if absent."""
    try:
        if not _CONFIG_PATH.exists():
            return False
        import json

        data = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
        value = data.get("telemetry_enabled", "")
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("y", "yes", "true", "1")
    except Exception:
        return False


def get_telemetry() -> TelemetryClient:
    """Returns the singleton TelemetryClient. Creates it on first call."""
    global _instance
    if _instance is None:
        _instance = TelemetryClient(enabled=_load_telemetry_setting())
    return _instance


def reset_telemetry_singleton() -> None:
    """For testing only -- resets the singleton so tests are isolated."""
    global _instance
    _instance = None
