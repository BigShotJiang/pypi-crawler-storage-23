"""Governance Event Webhooks — push governance events to external systems.

Nomotic (L5 runtime governance) feeds events to operating governance (L2)
and outcome monitoring (L6) systems via HTTP webhooks.  Enables integration
with Slack, PagerDuty, SIEM systems, and custom monitoring.

Fire-and-forget delivery with optional retry.  Webhook failures are logged
but never block governance operations.

Configuration example (JSON or YAML)::

    {
      "webhooks": [
        {"url": "https://hooks.slack.com/...", "events": ["DENY", "SUSPEND"]},
        {"url": "https://pagerduty.com/...", "events": ["SUSPEND", "TRUST_DROP"]}
      ]
    }
"""

from __future__ import annotations

import collections
import hashlib
import hmac as _hmac_mod
import json
import random
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ── Valid event types ────────────────────────────────────────────────

WEBHOOK_EVENT_TYPES = frozenset({
    "DENY",              # Action denied by governance
    "SUSPEND",           # Agent certificate suspended
    "DRIFT_ALERT",       # Behavioral drift detected
    "TRUST_DROP",        # Trust score dropped below threshold
    "SEAL_EXPIRED",      # A seal expired (should not happen with enforcement)
    "OVERRIDE_APPROVE",  # Human overrode a denial
    "OVERRIDE_REVOKE",   # Human revoked an approval
    "OVERRIDE_EXPIRING", # Pending override is approaching its expiry window
    "OVERRIDE_EXPIRED",  # Pending override expired without reaching threshold
    "CHAIN_BREAK",       # Audit hash chain integrity failure
    "LOOP_DETECTED",     # Loop/doom loop detected
    "TEST_PING",         # Synthetic test event
    "OUTPUT_BLOCKED",    # Output blocked by governance
    "OUTPUT_REDACTED",   # Output redacted by governance
    "OUTPUT_ESCALATED",  # Output escalated for review
    # Agent Lifecycle Events
    "LIFECYCLE_BIRTH",       # Agent certificate issued
    "LIFECYCLE_DEGRADED",    # UAHS dropped below warning threshold
    "LIFECYCLE_CRITICAL",    # UAHS dropped below critical threshold
    "LIFECYCLE_RETIREMENT",  # Trust floor reached or certificate expired
    "LIFECYCLE_REVOCATION",  # Certificate explicitly revoked
})


# ── Data classes ─────────────────────────────────────────────────────

@dataclass
class WebhookConfig:
    """Configuration for a single webhook endpoint."""

    url: str
    events: list[str]            # Event types to subscribe to
    format: str = "json"         # "json" only for now
    timeout_seconds: float = 5.0
    max_retries: int = 1
    enabled: bool = True
    signing_secret: str | None = None
    # If set, every delivery includes X-Nomotic-Signature: sha256=<hmac>
    # HMAC-SHA256 over the request body bytes using this secret.
    # Receivers verify: hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "url": self.url,
            "events": list(self.events),
            "format": self.format,
            "timeout_seconds": self.timeout_seconds,
            "max_retries": self.max_retries,
            "enabled": self.enabled,
        }
        if self.signing_secret is not None:
            d["signing_secret"] = self.signing_secret
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> WebhookConfig:
        return cls(
            url=d["url"],
            events=d.get("events", []),
            format=d.get("format", "json"),
            timeout_seconds=d.get("timeout_seconds", 5.0),
            max_retries=d.get("max_retries", 1),
            enabled=d.get("enabled", True),
            signing_secret=d.get("signing_secret"),
        )


@dataclass
class WebhookEvent:
    """A governance event to be delivered via webhook."""

    event_type: str              # DENY, SUSPEND, DRIFT_ALERT, TRUST_DROP, etc.
    event_id: str                # Unique ID for this event
    timestamp: float
    agent_id: str
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "payload": self.payload,
            "source": "nomotic",
            "version": "0.4.0",
        }


# ── Rate limiter ─────────────────────────────────────────────────────

class _RateLimiter:
    """Simple token bucket rate limiter — max N events/second."""

    def __init__(self, max_per_second: int = 10) -> None:
        self._max = max_per_second
        self._tokens: list[float] = []

    def allow(self) -> bool:
        now = time.time()
        self._tokens = [t for t in self._tokens if now - t < 1.0]
        if len(self._tokens) >= self._max:
            return False
        self._tokens.append(now)
        return True


# ── HMAC signing ─────────────────────────────────────────────────────

def _compute_signature(secret: str, body: bytes) -> str:
    """Compute HMAC-SHA256 signature for webhook delivery verification.

    Returns the signature string in the format expected by the header:
    'sha256=<hex_digest>'
    """
    digest = _hmac_mod.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


# ── Backoff schedule ─────────────────────────────────────────────────

_BACKOFF_SCHEDULE: list[int] = [1, 2, 4, 8, 16, 32, 60]
"""Seconds to wait before retry attempt N (0-indexed).
Attempt 0 = 1s, attempt 1 = 2s, ..., attempt 6+ = 60s (capped).
"""


def _backoff_seconds(attempt: int, jitter: bool = True) -> float:
    """Compute backoff delay for retry attempt number.

    Args:
        attempt: Number of previous failed attempts (0-indexed).
        jitter:  If True, apply ±50% random jitter to base delay.
                 Prevents thundering herd on mass retry.

    Returns:
        Delay in seconds before next retry attempt.
    """
    base = float(_BACKOFF_SCHEDULE[min(attempt, len(_BACKOFF_SCHEDULE) - 1)])
    if jitter:
        # Jitter: 50%–150% of base
        return base * (0.5 + random.random())
    return base


# ── Queued event ─────────────────────────────────────────────────────

@dataclass
class _QueuedEvent:
    """A failed webhook delivery queued for retry."""

    event: WebhookEvent
    config_url: str          # Which endpoint this is queued for
    queued_at: float         # Unix timestamp
    attempt_count: int = 0
    """Number of failed delivery attempts made so far. 0 = never attempted."""
    last_error: str = ""
    next_attempt_at: float = 0.0
    """Unix timestamp before which this event must not be retried.
    0.0 = available immediately (no backoff yet applied).
    """

    def to_dict(self) -> dict[str, Any]:
        return {
            "event": self.event.to_dict(),
            "config_url": self.config_url,
            "queued_at": self.queued_at,
            "attempt_count": self.attempt_count,
            "last_error": self.last_error,
            "next_attempt_at": self.next_attempt_at,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> _QueuedEvent:
        event_data = d["event"]
        # WebhookEvent.to_dict() adds 'source' and 'version' which aren't
        # constructor params — strip them before unpacking.
        event_fields = {
            k: v for k, v in event_data.items()
            if k in ("event_type", "event_id", "timestamp", "agent_id", "payload")
        }
        return cls(
            event=WebhookEvent(**event_fields),
            config_url=d["config_url"],
            queued_at=d["queued_at"],
            attempt_count=d.get("attempt_count", 0),
            last_error=d.get("last_error", ""),
            next_attempt_at=d.get("next_attempt_at", 0.0),
        )


# ── Webhook dispatcher ───────────────────────────────────────────────

class WebhookDispatcher:
    """Dispatches governance events to configured webhook endpoints.

    Fire-and-forget delivery with optional retry.  Webhook failures
    are logged but do not block governance operations.
    """

    def __init__(self, webhooks: list[WebhookConfig] | None = None) -> None:
        self._webhooks = webhooks or []
        self._rate_limiters: dict[str, _RateLimiter] = {}
        # Delivery stats
        self._delivered: int = 0
        self._failed: int = 0
        self._last_errors: list[dict[str, Any]] = []  # Last 10 errors
        # Delivery queue for failed events
        self._queue: collections.deque[_QueuedEvent] = collections.deque(maxlen=1000)
        self._queue_path: Path | None = None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> WebhookDispatcher:
        """Create from configuration dict (e.g., from YAML config).

        Expected format::

            {
                "webhooks": [
                    {"url": "https://...", "events": ["DENY", "SUSPEND"]},
                    {"url": "https://...", "events": ["TRUST_DROP"]}
                ]
            }
        """
        hooks: list[WebhookConfig] = []
        for hook_data in config.get("webhooks", []):
            if not isinstance(hook_data, dict):
                continue
            url = hook_data.get("url")
            if not url:
                continue
            hooks.append(WebhookConfig(
                url=url,
                events=hook_data.get("events", []),
                format=hook_data.get("format", "json"),
                timeout_seconds=hook_data.get("timeout_seconds", 5.0),
                max_retries=hook_data.get("max_retries", 1),
                enabled=hook_data.get("enabled", True),
                signing_secret=hook_data.get("signing_secret"),
            ))
        return cls(hooks)

    # ── Queue management ──────────────────────────────────────────

    def set_queue_path(self, path: Path) -> None:
        """Set path for persistent queue storage and load existing events."""
        self._queue_path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            for line in path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    self._queue.append(_QueuedEvent.from_dict(json.loads(line)))
                except Exception:
                    continue

    def queue_size(self) -> int:
        """Return number of events in the delivery queue."""
        return len(self._queue)

    def queue_status(self) -> list[dict[str, Any]]:
        """Return serialized view of all queued events."""
        return [qe.to_dict() for qe in self._queue]

    def drain_queue(self) -> int:
        """Attempt to deliver all queued events, respecting backoff.

        Events where next_attempt_at > now are skipped (not yet due).
        Returns count of successfully delivered events.
        """
        now = time.time()
        delivered = 0
        remaining: list[_QueuedEvent] = []
        for qe in self._queue:
            # Skip if backoff window not elapsed
            if qe.next_attempt_at > now:
                remaining.append(qe)
                continue

            config = self._find_config(qe.config_url)
            if config is None:
                remaining.append(qe)
                continue
            success = self._deliver_once(config, qe.event)
            if success:
                delivered += 1
            else:
                qe.attempt_count += 1
                delay = _backoff_seconds(qe.attempt_count, jitter=True)
                qe.next_attempt_at = now + delay
                qe.last_error = (
                    self._last_errors[-1]["error"] if self._last_errors else "Delivery failed"
                )
                remaining.append(qe)
        self._queue.clear()
        for qe in remaining:
            self._queue.append(qe)
        self._persist_queue()
        return delivered

    def drain_queue_stats(self) -> dict[str, int]:
        """Return statistics about the current delivery queue state.

        Returns:
            {
                "total_queued":    Total events in queue,
                "due_now":         Events with next_attempt_at <= now,
                "backoff_pending": Events waiting for backoff window,
                "max_attempts":    Highest attempt_count in queue,
            }
        """
        now = time.time()
        due = sum(1 for e in self._queue if e.next_attempt_at <= now)
        pending = len(self._queue) - due
        max_attempts = max((e.attempt_count for e in self._queue), default=0)
        return {
            "total_queued": len(self._queue),
            "due_now": due,
            "backoff_pending": pending,
            "max_attempts": max_attempts,
        }

    def _find_config(self, url: str) -> WebhookConfig | None:
        """Find a WebhookConfig by URL."""
        for wh in self._webhooks:
            if wh.url == url:
                return wh
        return None

    def _persist_queue(self) -> None:
        """Rewrite the JSONL queue file from current queue contents."""
        if self._queue_path is None:
            return
        self._queue_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [json.dumps(qe.to_dict()) for qe in self._queue]
        self._queue_path.write_text("\n".join(lines) + "\n" if lines else "")

    def _append_to_queue_file(self, qe: _QueuedEvent) -> None:
        """Append a single queued event to the JSONL file."""
        if self._queue_path is None:
            return
        self._queue_path.parent.mkdir(parents=True, exist_ok=True)
        with self._queue_path.open("a") as f:
            f.write(json.dumps(qe.to_dict()) + "\n")

    # ── Dispatch ──────────────────────────────────────────────────

    def dispatch(self, event: WebhookEvent) -> None:
        """Dispatch an event to all subscribed webhooks.

        Fire-and-forget.  Failures are logged but do not raise.
        Rate limited to 10 events/second per endpoint.
        If there are queued events for the same endpoint, drain them first
        to preserve delivery order.
        """
        for webhook in self._webhooks:
            if not webhook.enabled:
                continue
            if event.event_type not in webhook.events:
                continue
            if not self._check_rate_limit(webhook.url):
                continue

            # Drain queued events for this endpoint first
            if self._queue:
                self._drain_for_url(webhook.url)

            self._send(webhook, event)

    def _drain_for_url(self, url: str) -> int:
        """Attempt delivery of queued events for url, respecting backoff.

        Events where next_attempt_at > now are skipped (not yet due).
        On failure: increments attempt_count, sets next_attempt_at.
        On success: removes event from queue.
        Returns count of successfully delivered events.
        """
        now = time.time()
        delivered = 0
        remaining: list[_QueuedEvent] = []

        for qe in list(self._queue):
            if qe.config_url != url:
                remaining.append(qe)
                continue

            # Skip if backoff window not elapsed
            if qe.next_attempt_at > now:
                remaining.append(qe)
                continue

            config = self._find_config(qe.config_url)
            if config is None:
                remaining.append(qe)
                continue

            success = self._deliver_once(config, qe.event)
            if success:
                delivered += 1
                # Drop from queue — delivery succeeded
            else:
                qe.attempt_count += 1
                delay = _backoff_seconds(qe.attempt_count, jitter=True)
                qe.next_attempt_at = now + delay
                qe.last_error = (
                    self._last_errors[-1]["error"] if self._last_errors else "Delivery failed"
                )
                remaining.append(qe)

        # Rebuild queue with remaining events
        self._queue.clear()
        for qe in remaining:
            self._queue.append(qe)
        self._persist_queue()
        return delivered

    def _deliver_once(self, webhook: WebhookConfig, event: WebhookEvent) -> bool:
        """Attempt a single delivery (no retries). Returns True on success."""
        payload = json.dumps(event.to_dict()).encode("utf-8")
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "nomotic-webhook/0.4.0",
            "X-Nomotic-Event": event.event_type,
            "X-Nomotic-Event-Id": event.event_id,
        }
        if webhook.signing_secret:
            sig = _compute_signature(webhook.signing_secret, payload)
            headers["X-Nomotic-Signature"] = sig
            headers["X-Nomotic-Signature-Version"] = "v1"
        try:
            req = urllib.request.Request(
                webhook.url, data=payload, method="POST", headers=headers,
            )
            with urllib.request.urlopen(req, timeout=webhook.timeout_seconds) as resp:
                if resp.status < 300:
                    self._delivered += 1
                    return True
        except Exception as e:
            self._failed += 1
            error = {
                "url": webhook.url,
                "event_type": event.event_type,
                "error": str(e),
                "timestamp": time.time(),
            }
            self._last_errors.append(error)
            if len(self._last_errors) > 10:
                self._last_errors = self._last_errors[-10:]
        return False

    def _send(self, webhook: WebhookConfig, event: WebhookEvent) -> None:
        """Send event to a single webhook endpoint with retries."""
        payload = json.dumps(event.to_dict()).encode("utf-8")

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "nomotic-webhook/0.4.0",
            "X-Nomotic-Event": event.event_type,
            "X-Nomotic-Event-Id": event.event_id,
        }
        if webhook.signing_secret:
            sig = _compute_signature(webhook.signing_secret, payload)
            headers["X-Nomotic-Signature"] = sig
            headers["X-Nomotic-Signature-Version"] = "v1"

        for attempt in range(1 + webhook.max_retries):
            try:
                req = urllib.request.Request(
                    webhook.url,
                    data=payload,
                    method="POST",
                    headers=headers,
                )
                with urllib.request.urlopen(req, timeout=webhook.timeout_seconds) as resp:
                    if resp.status < 300:
                        self._delivered += 1
                        return
            except Exception as e:
                if attempt == webhook.max_retries:
                    self._failed += 1
                    error = {
                        "url": webhook.url,
                        "event_type": event.event_type,
                        "error": str(e),
                        "timestamp": time.time(),
                    }
                    self._last_errors.append(error)
                    if len(self._last_errors) > 10:
                        self._last_errors = self._last_errors[-10:]
                    # Queue the failed event for later retry
                    qe = _QueuedEvent(
                        event=event,
                        config_url=webhook.url,
                        queued_at=time.time(),
                        attempt_count=1,
                        last_error=str(e),
                    )
                    self._queue.append(qe)
                    self._append_to_queue_file(qe)

    def _check_rate_limit(self, url: str) -> bool:
        """Rate limit: max 10 events/second per endpoint."""
        if url not in self._rate_limiters:
            self._rate_limiters[url] = _RateLimiter(max_per_second=10)
        return self._rate_limiters[url].allow()

    def stats(self) -> dict[str, Any]:
        """Return delivery statistics."""
        return {
            "delivered": self._delivered,
            "failed": self._failed,
            "webhooks_configured": len(self._webhooks),
            "last_errors": list(self._last_errors),
            "queued": len(self._queue),
        }
