"""Slack integration for Nomotic governance approval queue.

Provides outbound notifications (escalation messages with Approve/Deny buttons)
and inbound interaction handling (button clicks → cosign or deny overrides).

``slack-sdk`` is an optional dependency — ``pip install nomotic[slack]``.
If Slack is configured but ``slack-sdk`` is not installed, a warning is logged
and the integration is silently disabled.
"""

from __future__ import annotations

import hashlib
import hmac
import importlib.util
import logging
import threading
from datetime import datetime, timezone
from typing import Any

__all__ = ["SlackGovernanceNotifier"]

logger = logging.getLogger(__name__)


def _slack_available() -> bool:
    return importlib.util.find_spec("slack_sdk") is not None


class SlackGovernanceNotifier:
    """Send governance escalation notifications to Slack and handle responses.

    Args:
        bot_token: Slack bot OAuth token.
        channel_id: Channel ID to post escalation messages to.
        signing_secret: Slack app signing secret for verifying inbound requests.
        runtime: The :class:`GovernanceRuntime` instance.
        authority_registry: Optional authority registry for validation.
    """

    def __init__(
        self,
        bot_token: str,
        channel_id: str,
        signing_secret: str,
        runtime: Any,
        authority_registry: Any = None,
    ) -> None:
        if not _slack_available():
            logger.warning(
                "slack-sdk not installed. Slack notifications disabled. "
                "Install with: pip install nomotic[slack]"
            )
        self.bot_token = bot_token
        self.channel_id = channel_id
        self.signing_secret = signing_secret
        self.runtime = runtime
        self.authority_registry = authority_registry

    def notify_escalation(self, pending: Any) -> None:
        """Post escalation message to Slack. Called asynchronously — never blocks."""
        if not _slack_available():
            return
        threading.Thread(
            target=self._post_message, args=(pending,), daemon=True
        ).start()

    def _post_message(self, pending: Any) -> None:
        try:
            from slack_sdk import WebClient

            client = WebClient(token=self.bot_token)
            ttl_minutes = max(
                0,
                int(
                    (pending.expires_at - datetime.now(timezone.utc).timestamp())
                    / 60
                ),
            )
            blocks = [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": "Governance Escalation — Approval Required",
                    },
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": f"*Agent:* {pending.agent_id}",
                        },
                        {
                            "type": "mrkdwn",
                            "text": f"*Action:* {pending.override_type} -> {pending.action_id}",
                        },
                        {
                            "type": "mrkdwn",
                            "text": f"*Reason:* {pending.initial_reason}",
                        },
                        {
                            "type": "mrkdwn",
                            "text": (
                                f"*Signatures:* {pending.signature_count} of "
                                f"{pending.required_signatures} required"
                            ),
                        },
                        {
                            "type": "mrkdwn",
                            "text": f"*Expires:* in {ttl_minutes} minutes",
                        },
                    ],
                },
                {
                    "type": "actions",
                    "block_id": f"override_{pending.override_id}",
                    "elements": [
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "Approve"},
                            "style": "primary",
                            "action_id": "approve_override",
                            "value": pending.override_id,
                        },
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "Deny"},
                            "style": "danger",
                            "action_id": "deny_override",
                            "value": pending.override_id,
                        },
                    ],
                },
            ]
            client.chat_postMessage(channel=self.channel_id, blocks=blocks)
        except Exception as e:
            logger.warning(f"Slack notification failed: {e}")

    def verify_slack_signature(
        self, request_body: str, timestamp: str, signature: str
    ) -> bool:
        """Verify Slack signing secret. Returns False if invalid or stale."""
        try:
            request_ts = int(timestamp)
            now_ts = int(datetime.now(timezone.utc).timestamp())
            if abs(now_ts - request_ts) > 300:
                return False
            base_string = f"v0:{timestamp}:{request_body}"
            computed = "v0=" + hmac.new(
                self.signing_secret.encode(),
                base_string.encode(),
                hashlib.sha256,
            ).hexdigest()
            return hmac.compare_digest(computed, signature)
        except Exception:
            return False

    def handle_interaction(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Slack interactive component payload.

        Returns a Slack response_action dict.
        """
        try:
            action = (payload.get("actions") or [{}])[0]
            action_id = action.get("action_id", "")
            pending_id = action.get("value", "")
            user = payload.get("user", {})
            authority = user.get("name") or user.get("id", "unknown")

            if action_id == "approve_override":
                result = self.runtime.cosign_override(
                    pending_id,
                    authority=authority,
                    reason=f"Approved via Slack by {authority}",
                    role_check=False,
                )
                completed = result.status == "COMPLETE"
                text = (
                    "Approved"
                    if completed
                    else f"Signature added ({authority})"
                )
            elif action_id == "deny_override":
                self.runtime._deny_pending_override(
                    pending_id,
                    authority=authority,
                    reason=f"Denied via Slack by {authority}",
                )
                text = f"Denied by {authority}"
            else:
                text = f"Unknown action: {action_id}"

            return {
                "response_action": "update",
                "view": None,
                "text": text,
            }
        except Exception as e:
            logger.error(f"Slack interaction handling failed: {e}")
            return {"text": "Governance action failed. Check Nomotic logs."}
