"""Framework integrations for Nomotic governance.

Each integration wraps a specific agent framework's tool execution
in Nomotic governance evaluation. Import the one matching your framework:

    from nomotic.integrations.crewai_adapter import govern_crewai_tools
    from nomotic.integrations.langgraph_adapter import governance_node
    from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent
"""
