"""CrewAI integration -- governed tool execution for CrewAI agents.

Usage:
    from crewai import Agent, Task, Crew
    from nomotic.integrations.crewai_adapter import govern_crewai_tools

    # Your existing tools
    tools = [search_tool, file_tool, db_tool]

    # Wrap them in Nomotic governance (one line)
    governed_tools = govern_crewai_tools("claims-bot", tools)

    # Use governed tools in your CrewAI agent
    agent = Agent(role="Researcher", tools=governed_tools)
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.executor import GovernedToolExecutor


def govern_crewai_tools(
    agent_id: str,
    tools: list,
    *,
    test_mode: bool = False,
    base_dir: str | None = None,
) -> list:
    """Wrap CrewAI tools in Nomotic governance.

    Each tool call is evaluated through the governance pipeline before execution.
    Denied calls return an error message instead of executing.

    Args:
        agent_id: Nomotic agent identity (name or ID)
        tools: List of CrewAI Tool objects
        test_mode: If True, use simulated trust and testlog
        base_dir: Nomotic config directory (default ~/.nomotic)

    Returns:
        List of governed CrewAI Tool objects (same interface, governance added)
    """
    from nomotic.executor import GovernedToolExecutor
    from pathlib import Path

    kwargs: dict[str, Any] = {"test_mode": test_mode}
    if base_dir:
        kwargs["base_dir"] = Path(base_dir)

    executor = GovernedToolExecutor.connect(agent_id, **kwargs)

    governed = []
    for tool in tools:
        governed.append(_wrap_crewai_tool(tool, executor))
    return governed


def _wrap_crewai_tool(tool: Any, executor: GovernedToolExecutor) -> Any:
    """Wrap a single CrewAI tool with governance."""
    original_run = tool._run if hasattr(tool, "_run") else tool.run
    tool_name = getattr(tool, "name", str(tool))

    def governed_run(*args: Any, **kwargs: Any) -> Any:
        # Determine target from arguments
        target = ""
        if args:
            target = str(args[0])
        elif kwargs:
            for key in ("query", "path", "table", "url", "target", "resource"):
                if key in kwargs:
                    target = str(kwargs[key])
                    break

        result = executor.execute(
            action=tool_name,
            target=target,
            params=kwargs,
            tool_fn=lambda: original_run(*args, **kwargs),
        )

        if result.allowed:
            return result.data
        else:
            return f"[GOVERNANCE DENIED] {result.reason}"

    # Replace the tool's run method
    if hasattr(tool, "_run"):
        tool._run = governed_run
    else:
        tool.run = governed_run

    return tool
