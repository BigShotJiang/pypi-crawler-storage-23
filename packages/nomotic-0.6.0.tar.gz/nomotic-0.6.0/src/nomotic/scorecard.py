"""Governance Scorecard Generator (F-19).

Generates auditor-ready governance compliance scorecards that map
Nomotic behavioral governance data against compliance frameworks
(SOC2, HIPAA, PCI-DSS, ISO27001). Output as JSON or self-contained
print-ready HTML.
"""

from __future__ import annotations

import dataclasses
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.audit_store import LogStore
    from nomotic.fleet import FleetGovernor

__all__ = [
    "ArchetypeBenchmark",
    "GovernanceScorecard",
    "GovernanceScorecardGenerator",
    "ScorecardControlGap",
    "ScorecardControlMapping",
]


@dataclass
class ScorecardControlMapping:
    """Maps a compliance control to a Nomotic feature for scorecard display."""

    control_id: str
    control_name: str
    framework: str
    coverage: str  # "full" | "partial" | "indirect" | "none"
    nomotic_feature: str  # which Nomotic component provides coverage


@dataclass
class ScorecardControlGap:
    """A compliance control gap identified during scorecard generation."""

    control_id: str
    control_name: str
    framework: str
    severity: str  # "critical" | "high" | "medium" | "low"
    gap_description: str
    recommendation: str


@dataclass
class ArchetypeBenchmark:
    """Comparison of agent metrics against archetype baseline."""

    archetype: str
    agent_deny_rate: float
    baseline_deny_rate: float
    agent_ucs_avg: float
    baseline_ucs_avg: float
    drift_frequency: float
    baseline_drift_frequency: float
    within_normal_range: bool


@dataclass
class GovernanceScorecard:
    """Complete governance compliance scorecard for an agent."""

    agent_id: str
    archetype: str
    certificate_id: str
    certificate_issued_at: datetime
    trust_score: float
    compliance_preset: str
    governance_config: dict
    evaluation_summary: dict  # {total, allow, deny, escalate, block}
    allow_rate: float
    deny_rate: float
    escalate_rate: float
    average_ucs: float
    trust_trajectory_30d: list[float]
    compliance_mapping: list[ScorecardControlMapping]
    gap_analysis: list[ScorecardControlGap]
    archetype_benchmark: ArchetypeBenchmark
    generated_at: datetime
    nomotic_version: str
    audit_record_hash: str

    def to_dict(self) -> dict[str, Any]:
        """Serialize all fields to JSON-safe dict."""
        d = dataclasses.asdict(self)
        d["generated_at"] = self.generated_at.isoformat()
        d["certificate_issued_at"] = self.certificate_issued_at.isoformat()
        return d

    def to_json(self) -> str:
        """Serialize to formatted JSON string."""
        return json.dumps(self.to_dict(), indent=2, default=str)

    def to_html(self) -> str:
        """Self-contained, print-ready HTML scorecard.

        All CSS inline (except a small @media print block).
        No external dependencies.
        """
        summary = self.evaluation_summary
        total = summary.get("total", 0)

        def _pct(val: float) -> str:
            return f"{val * 100:.1f}%"

        def _coverage_color(cov: str) -> str:
            return {
                "full": "#22c55e",
                "partial": "#f59e0b",
                "indirect": "#9ca3af",
                "none": "#ef4444",
            }.get(cov, "#9ca3af")

        def _severity_color(sev: str) -> str:
            return {
                "critical": "#ef4444",
                "high": "#f97316",
                "medium": "#eab308",
                "low": "#9ca3af",
            }.get(sev, "#9ca3af")

        # Build compliance mapping rows
        mapping_rows = ""
        for cm in self.compliance_mapping:
            cc = _coverage_color(cm.coverage)
            mapping_rows += (
                f'<tr>'
                f'<td style="padding:6px 12px;border:1px solid #e5e7eb;">{cm.control_id}</td>'
                f'<td style="padding:6px 12px;border:1px solid #e5e7eb;">{cm.control_name}</td>'
                f'<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:center;">'
                f'<span style="display:inline-block;padding:2px 10px;border-radius:9999px;'
                f'background:{cc};color:#fff;font-size:12px;font-weight:600;">'
                f'{cm.coverage}</span></td>'
                f'<td style="padding:6px 12px;border:1px solid #e5e7eb;font-size:13px;">'
                f'{cm.nomotic_feature}</td>'
                f'</tr>\n'
            )

        # Build gap analysis items
        gap_items = ""
        if self.gap_analysis:
            for gap in self.gap_analysis:
                sc = _severity_color(gap.severity)
                gap_items += (
                    f'<div style="margin-bottom:12px;padding:10px 14px;border-left:4px solid {sc};'
                    f'background:#f9fafb;">'
                    f'<div style="font-weight:600;">{gap.control_id} — {gap.control_name}'
                    f'<span style="display:inline-block;margin-left:8px;padding:1px 8px;'
                    f'border-radius:9999px;background:{sc};color:#fff;font-size:11px;'
                    f'font-weight:600;">{gap.severity}</span></div>'
                    f'<div style="margin-top:4px;color:#4b5563;">{gap.gap_description}</div>'
                    f'<div style="margin-top:4px;color:#1d4ed8;font-size:13px;">'
                    f'Recommendation: {gap.recommendation}</div>'
                    f'</div>\n'
                )
        else:
            gap_items = '<div style="color:#22c55e;font-weight:600;">No gaps identified.</div>'

        # Benchmark comparison
        bm = self.archetype_benchmark
        range_icon = "\u2713" if bm.within_normal_range else "\u2717"
        range_color = "#22c55e" if bm.within_normal_range else "#ef4444"

        # Allow/Deny/Escalate bar widths (percentage)
        allow_w = self.allow_rate * 100
        deny_w = self.deny_rate * 100
        esc_w = self.escalate_rate * 100

        # Build the trust trajectory sparkline as a simple inline SVG
        trajectory = self.trust_trajectory_30d
        sparkline_svg = ""
        if len(trajectory) >= 2:
            min_v = min(trajectory)
            max_v = max(trajectory)
            range_v = max_v - min_v if max_v != min_v else 1.0
            w = 300
            h = 40
            points = []
            for i, v in enumerate(trajectory):
                x = (i / (len(trajectory) - 1)) * w
                y = h - ((v - min_v) / range_v) * h
                points.append(f"{x:.1f},{y:.1f}")
            sparkline_svg = (
                f'<svg width="{w}" height="{h}" style="display:block;margin:4px 0;">'
                f'<polyline points="{" ".join(points)}" '
                f'fill="none" stroke="#3b82f6" stroke-width="2"/></svg>'
            )

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Governance Scorecard — {self.agent_id}</title>
<style>
@media print {{
  .no-print {{ display: none; }}
  body {{ font-size: 11pt; }}
}}
</style>
</head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:900px;margin:0 auto;padding:32px;color:#1f2937;line-height:1.5;">

<!-- Section 1: Header -->
<div style="border-bottom:3px solid #1e3a5f;padding-bottom:16px;margin-bottom:24px;">
<h1 style="margin:0;font-size:24px;color:#1e3a5f;">Governance Scorecard \u2014 {self.agent_id}</h1>
<div style="margin-top:6px;color:#6b7280;font-size:14px;">Generated {self.generated_at.strftime("%Y-%m-%d %H:%M:%S UTC")} | Nomotic v{self.nomotic_version}</div>
</div>

<!-- Section 2: Agent Identity -->
<div style="margin-bottom:28px;">
<h2 style="font-size:18px;color:#1e3a5f;margin:0 0 12px 0;">Agent Identity</h2>
<table style="border-collapse:collapse;width:100%;">
<tr><td style="padding:4px 12px;font-weight:600;width:180px;">Certificate ID</td><td style="padding:4px 12px;font-family:monospace;font-size:13px;">{self.certificate_id}</td></tr>
<tr><td style="padding:4px 12px;font-weight:600;">Archetype</td><td style="padding:4px 12px;">{self.archetype}</td></tr>
<tr><td style="padding:4px 12px;font-weight:600;">Issued</td><td style="padding:4px 12px;">{self.certificate_issued_at.strftime("%Y-%m-%d")}</td></tr>
<tr><td style="padding:4px 12px;font-weight:600;">Trust Score</td><td style="padding:4px 12px;">{self.trust_score:.2f}</td></tr>
<tr><td style="padding:4px 12px;font-weight:600;">Compliance Preset</td><td style="padding:4px 12px;">{self.compliance_preset}</td></tr>
</table>
</div>

<!-- Section 3: Behavioral Summary -->
<div style="margin-bottom:28px;">
<h2 style="font-size:18px;color:#1e3a5f;margin:0 0 12px 0;">Behavioral Summary (30 days)</h2>
<div style="margin-bottom:8px;"><strong>Total evaluations:</strong> {total}</div>
<div style="margin-bottom:6px;">
<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
<span style="width:80px;font-size:13px;">Allow</span>
<div style="flex:1;background:#e5e7eb;border-radius:4px;height:18px;overflow:hidden;">
<div style="width:{allow_w:.1f}%;background:#22c55e;height:100%;border-radius:4px;"></div>
</div>
<span style="font-size:13px;width:50px;text-align:right;">{_pct(self.allow_rate)}</span>
</div>
<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
<span style="width:80px;font-size:13px;">Deny</span>
<div style="flex:1;background:#e5e7eb;border-radius:4px;height:18px;overflow:hidden;">
<div style="width:{deny_w:.1f}%;background:#ef4444;height:100%;border-radius:4px;"></div>
</div>
<span style="font-size:13px;width:50px;text-align:right;">{_pct(self.deny_rate)}</span>
</div>
<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
<span style="width:80px;font-size:13px;">Escalate</span>
<div style="flex:1;background:#e5e7eb;border-radius:4px;height:18px;overflow:hidden;">
<div style="width:{esc_w:.1f}%;background:#f59e0b;height:100%;border-radius:4px;"></div>
</div>
<span style="font-size:13px;width:50px;text-align:right;">{_pct(self.escalate_rate)}</span>
</div>
</div>
<div><strong>Average UCS:</strong> {self.average_ucs:.3f}</div>
<div style="margin-top:8px;"><strong>Trust Trajectory (30d):</strong></div>
{sparkline_svg}
</div>

<!-- Section 4: Compliance Framework Mapping -->
<div style="margin-bottom:28px;">
<h2 style="font-size:18px;color:#1e3a5f;margin:0 0 12px 0;">Compliance Framework Mapping</h2>
<table style="border-collapse:collapse;width:100%;font-size:14px;">
<thead>
<tr style="background:#f3f4f6;">
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:left;">Control ID</th>
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:left;">Control Name</th>
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:center;">Coverage</th>
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:left;">Nomotic Feature</th>
</tr>
</thead>
<tbody>
{mapping_rows}
</tbody>
</table>
</div>

<!-- Section 5: Gap Analysis -->
<div style="margin-bottom:28px;">
<h2 style="font-size:18px;color:#1e3a5f;margin:0 0 12px 0;">Gap Analysis</h2>
{gap_items}
</div>

<!-- Section 6: Archetype Benchmark -->
<div style="margin-bottom:28px;">
<h2 style="font-size:18px;color:#1e3a5f;margin:0 0 12px 0;">Archetype Benchmark</h2>
<table style="border-collapse:collapse;width:100%;font-size:14px;">
<thead>
<tr style="background:#f3f4f6;">
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:left;">Metric</th>
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:right;">Agent</th>
<th style="padding:8px 12px;border:1px solid #e5e7eb;text-align:right;">Baseline ({bm.archetype})</th>
</tr>
</thead>
<tbody>
<tr>
<td style="padding:6px 12px;border:1px solid #e5e7eb;">Deny Rate</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{_pct(bm.agent_deny_rate)}</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{_pct(bm.baseline_deny_rate)}</td>
</tr>
<tr>
<td style="padding:6px 12px;border:1px solid #e5e7eb;">UCS Average</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{bm.agent_ucs_avg:.3f}</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{bm.baseline_ucs_avg:.3f}</td>
</tr>
<tr>
<td style="padding:6px 12px;border:1px solid #e5e7eb;">Drift Frequency</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{_pct(bm.drift_frequency)}</td>
<td style="padding:6px 12px;border:1px solid #e5e7eb;text-align:right;">{_pct(bm.baseline_drift_frequency)}</td>
</tr>
</tbody>
</table>
<div style="margin-top:8px;font-size:14px;">
Within normal range: <span style="color:{range_color};font-weight:700;">{range_icon}</span>
</div>
</div>

<!-- Section 7: Signature Block -->
<div style="margin-top:32px;padding:12px 16px;background:#f3f4f6;border:1px solid #e5e7eb;font-family:monospace;font-size:12px;color:#6b7280;">
Generated by Nomotic v{self.nomotic_version} on {self.generated_at.strftime("%Y-%m-%dT%H:%M:%SZ")} | Audit record: {self.audit_record_hash[:16]}...
</div>

</body>
</html>"""
        return html


class GovernanceScorecardGenerator:
    """Generates governance scorecards from audit data and certificates."""

    # Baseline deny rates by archetype (rough defaults for comparison)
    ARCHETYPE_BASELINES: dict[str, dict[str, float]] = {
        "healthcare-agent": {"deny_rate": 0.12, "ucs_avg": 0.71, "drift_freq": 0.08},
        "financial-analyst": {"deny_rate": 0.09, "ucs_avg": 0.74, "drift_freq": 0.06},
        "security-monitor": {"deny_rate": 0.18, "ucs_avg": 0.68, "drift_freq": 0.12},
        "sales-agent": {"deny_rate": 0.07, "ucs_avg": 0.76, "drift_freq": 0.05},
        "default": {"deny_rate": 0.10, "ucs_avg": 0.72, "drift_freq": 0.07},
    }

    # SOC2 Trust Services Criteria -> Nomotic feature mapping
    SOC2_CONTROLS = [
        ScorecardControlMapping(
            "CC6.1", "Logical and Physical Access Controls",
            "soc2", "full",
            "GovernanceAuthorityRegistry + role-based override",
        ),
        ScorecardControlMapping(
            "CC6.6", "Security Threats from Outside Systems",
            "soc2", "partial",
            "14-dimensional evaluation including scope_compliance",
        ),
        ScorecardControlMapping(
            "CC7.2", "System Monitoring",
            "soc2", "full",
            "Hash-chained audit trail + DriftMonitor",
        ),
        ScorecardControlMapping(
            "CC7.3", "Evaluation of Security Events",
            "soc2", "full",
            "UCS evaluation engine + ESCALATE verdict routing",
        ),
        ScorecardControlMapping(
            "CC7.4", "Incident Response",
            "soc2", "partial",
            "Interrupt authority + approval queue",
        ),
        ScorecardControlMapping(
            "CC9.2", "Vendor and Business Partner Management",
            "soc2", "indirect",
            "Delegation chain enforcement",
        ),
    ]

    # HIPAA Safeguards -> Nomotic feature mapping
    HIPAA_CONTROLS = [
        ScorecardControlMapping(
            "164.312(a)(1)", "Access Control",
            "hipaa", "full",
            "Scope compliance dimension + GovernanceAuthorityRegistry",
        ),
        ScorecardControlMapping(
            "164.312(b)", "Audit Controls",
            "hipaa", "full",
            "Hash-chained immutable audit trail",
        ),
        ScorecardControlMapping(
            "164.312(c)(1)", "Integrity",
            "hipaa", "partial",
            "Constitutional Rules Engine + output validation",
        ),
        ScorecardControlMapping(
            "164.312(d)", "Person Authentication",
            "hipaa", "indirect",
            "Agent Birth Certificate cryptographic identity",
        ),
        ScorecardControlMapping(
            "164.312(e)(2)(ii)", "Encryption",
            "hipaa", "none",
            "Not provided \u2014 use transport-layer encryption",
        ),
    ]

    FRAMEWORK_CONTROLS: dict[str, list[ScorecardControlMapping]] = {
        "soc2": SOC2_CONTROLS,
        "hipaa": HIPAA_CONTROLS,
    }

    def __init__(
        self,
        base_dir: Path,
        audit_store: "LogStore",
        fleet_governor: "FleetGovernor | None" = None,
    ) -> None:
        self.base_dir = Path(base_dir)
        self.audit_store = audit_store
        self.fleet_governor = fleet_governor

    def _load_certificate(self, agent_id: str) -> Any:
        """Load an agent certificate from the certs directory."""
        from nomotic.certificate import AgentCertificate

        certs_dir = self.base_dir / "certs"
        if not certs_dir.exists():
            return None

        # Try scanning cert files for the agent_id
        for cert_file in certs_dir.glob("nmc-*.json"):
            try:
                data = json.loads(cert_file.read_text(encoding="utf-8"))
                if data.get("agent_id", "").lower() == agent_id.lower():
                    return AgentCertificate.from_dict(data)
            except (json.JSONDecodeError, KeyError):
                continue
        return None

    def generate(
        self,
        agent_id: str,
        framework: str = "soc2",
        days: int = 30,
    ) -> GovernanceScorecard:
        """Generate a governance scorecard for the given agent."""
        from nomotic import __version__

        # Load certificate
        cert = self._load_certificate(agent_id)
        if cert is None:
            raise ValueError(f"Agent not found: {agent_id}")

        # Get evaluation history using the 30-day query pattern
        cutoff = time.time() - (days * 86400)
        all_records = self.audit_store.query_all(agent_id)
        records = [r for r in all_records if r.timestamp >= cutoff]

        total = len(records)
        allow_count = sum(1 for r in records if r.verdict.upper() == "ALLOW")
        deny_count = sum(1 for r in records if r.verdict.upper() == "DENY")
        esc_count = sum(1 for r in records if r.verdict.upper() == "ESCALATE")
        block_count = sum(1 for r in records if r.verdict.upper() == "BLOCK")

        allow_rate = allow_count / total if total else 0.0
        deny_rate = deny_count / total if total else 0.0
        escalate_rate = esc_count / total if total else 0.0

        avg_ucs = (sum(r.ucs for r in records) / total) if total else 0.0

        # Trust trajectory: UCS scores in chronological order
        sorted_records = sorted(records, key=lambda r: r.timestamp)
        trust_trajectory = [r.ucs for r in sorted_records]

        # Compliance mapping from framework
        controls = self.FRAMEWORK_CONTROLS.get(framework, self.SOC2_CONTROLS)

        # Gap analysis
        gap_analysis = self._compute_gaps(agent_id, framework, controls)

        # Archetype benchmark
        archetype = cert.archetype
        baseline = self.ARCHETYPE_BASELINES.get(
            archetype, self.ARCHETYPE_BASELINES["default"]
        )
        benchmark = ArchetypeBenchmark(
            archetype=archetype,
            agent_deny_rate=deny_rate,
            baseline_deny_rate=baseline["deny_rate"],
            agent_ucs_avg=avg_ucs,
            baseline_ucs_avg=baseline["ucs_avg"],
            drift_frequency=0.0,  # populate from DriftMonitor if available
            baseline_drift_frequency=baseline["drift_freq"],
            within_normal_range=(
                abs(deny_rate - baseline["deny_rate"]) < 0.10
                and abs(avg_ucs - baseline["ucs_avg"]) < 0.15
            ),
        )

        # Audit record hash for tamper evidence
        latest_record = max(sorted_records, key=lambda r: r.timestamp) if sorted_records else None
        audit_hash = (latest_record.record_hash if latest_record else "no-records")[:32]

        return GovernanceScorecard(
            agent_id=agent_id,
            archetype=archetype,
            certificate_id=cert.certificate_id,
            certificate_issued_at=cert.issued_at,
            trust_score=cert.trust_score,
            compliance_preset=getattr(cert, "compliance_preset", "standard"),
            governance_config={},
            evaluation_summary={
                "total": total,
                "allow": allow_count,
                "deny": deny_count,
                "escalate": esc_count,
                "block": block_count,
            },
            allow_rate=allow_rate,
            deny_rate=deny_rate,
            escalate_rate=escalate_rate,
            average_ucs=avg_ucs,
            trust_trajectory_30d=trust_trajectory[-30:],
            compliance_mapping=controls,
            gap_analysis=gap_analysis,
            archetype_benchmark=benchmark,
            generated_at=datetime.now(timezone.utc),
            nomotic_version=__version__,
            audit_record_hash=audit_hash,
        )

    def _compute_gaps(
        self,
        agent_id: str,
        framework: str,
        controls: list[ScorecardControlMapping],
    ) -> list[ScorecardControlGap]:
        """Derive gaps from controls with no or partial coverage.

        Uses ComplianceGapAnalyzer if available, otherwise flags
        controls with 'none' coverage as gaps.
        """
        try:
            from nomotic.gap_analysis import ComplianceGapAnalyzer
            from nomotic.compliance_report import ComplianceReportGenerator

            report_gen = ComplianceReportGenerator(base_dir=self.base_dir)
            analyzer = ComplianceGapAnalyzer(report_gen, self.audit_store)
            report = analyzer.analyze(
                framework_id=framework,
                agent_id=agent_id,
            )
            # Convert gap_analysis ControlGap objects to ScorecardControlGap
            gaps: list[ScorecardControlGap] = []
            for gap in report.all_gaps:
                gaps.append(ScorecardControlGap(
                    control_id=gap.control_id,
                    control_name=gap.control_description,
                    framework=gap.framework_id,
                    severity=gap.gap_severity,
                    gap_description=(
                        f"Average dimension score {gap.average_dimension_score:.2f} "
                        f"below threshold {gap.score_threshold:.2f}"
                    ),
                    recommendation=gap.recommendation,
                ))
            return gaps
        except (ImportError, AttributeError, ValueError):
            # Fallback: flag "none" coverage controls as gaps
            return [
                ScorecardControlGap(
                    control_id=c.control_id,
                    control_name=c.control_name,
                    framework=c.framework,
                    severity="medium",
                    gap_description=(
                        f"{c.control_name} has no coverage in current configuration"
                    ),
                    recommendation=(
                        "Review nomotic.yaml and enable relevant governance features"
                    ),
                )
                for c in controls
                if c.coverage == "none"
            ]
