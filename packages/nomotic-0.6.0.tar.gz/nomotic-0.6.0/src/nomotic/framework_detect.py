"""Detect installed AI/ML frameworks.

Provides a fast, side-effect-free check for which supported frameworks
are available in the current Python environment.  Used by onboarding
and setup commands to tailor recommendations.
"""

from __future__ import annotations

import importlib.util

__all__ = ["detect_installed_frameworks", "SUPPORTED_FRAMEWORKS", "FRAMEWORK_DISPLAY_NAMES"]

SUPPORTED_FRAMEWORKS = ["langgraph", "crewai", "openai", "anthropic"]

FRAMEWORK_DISPLAY_NAMES: dict[str, str] = {
    "langgraph": "LangGraph",
    "crewai": "CrewAI",
    "openai": "OpenAI SDK",
    "anthropic": "Claude SDK (anthropic)",
}


def detect_installed_frameworks() -> list[str]:
    """Return list of supported framework names that are currently installed.

    Uses ``importlib.util.find_spec`` — no imports, no side effects.  Fast.

    Example return::

        ["langgraph", "openai"]
    """
    detected: list[str] = []
    for framework in SUPPORTED_FRAMEWORKS:
        if importlib.util.find_spec(framework) is not None:
            detected.append(framework)
    return detected
