"""Agent Birth Certificate — the foundational identity primitive.

A birth certificate is a signed, structured identity document for a governed
AI agent. It carries the agent's identity, behavioral archetype, governance
zone, trust score, behavioral age, and cryptographic proof of issuance.

Certificates are the authoritative source of agent identity and trust.
Everything else in Nomotic builds on them.
"""

from __future__ import annotations

import base64
import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any

__all__ = [
    "AgentCertificate",
    "CertStatus",
    "CertificateStatusError",
    "CertVerifyResult",
    "LiveVerifyResult",
    "ModelProvenance",
]


class CertificateStatusError(Exception):
    """Raised when a certificate is not in ACTIVE status."""

    def __init__(self, agent_id: str, status: CertStatus):
        self.agent_id = agent_id
        self.status = status
        super().__init__(
            f"Certificate for agent '{agent_id}' is {status.name}, not ACTIVE"
        )


class CertStatus(Enum):
    """Lifecycle status of an agent certificate."""

    ACTIVE = auto()
    SUSPENDED = auto()
    REVOKED = auto()
    EXPIRED = auto()


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _generate_cert_id() -> str:
    return f"nmc-{uuid.uuid4()}"


@dataclass
class ModelProvenance:
    """Foundation model identity embedded in an agent birth certificate.

    When present, the provenance_hash is included in the certificate's
    signed payload, cryptographically binding the model to the agent.
    Modifying provenance after issuance breaks signature verification.
    """

    model_provider: str  # "anthropic" | "openai" | "meta" | "mistral" | "google" | "custom"
    model_name: str  # "claude-sonnet-4-6" | "gpt-4o" | "llama-3.1-70b" etc.
    model_version: str  # "20250514" | "2024-08-06" | commit SHA for custom

    model_hash: str | None = None
    # SHA-256 of model card or weights manifest (if available/verifiable)

    fine_tune_id: str | None = None
    # Fine-tune run ID if this model is a fine-tune

    fine_tune_base: str | None = None
    # What was fine-tuned from, e.g. "claude-sonnet-4-6-20250514"

    safety_evaluation_id: str | None = None
    # External safety evaluation reference (e.g. MLCommons evaluation ID)

    training_data_summary: str | None = None
    # Brief human-readable note on training data provenance

    known_limitations: list[str] = field(default_factory=list)
    # Declared limitations relevant to governance (e.g. "No real-time data")

    provenance_hash: str = ""
    # SHA-256 of canonical JSON of this record (computed on creation, not user-set)

    def compute_hash(self) -> str:
        """Compute SHA-256 of canonical JSON of this record (excluding provenance_hash)."""
        d = self.to_dict()
        d.pop("provenance_hash", None)
        canonical = json.dumps(d, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "model_provider": self.model_provider,
            "model_name": self.model_name,
            "model_version": self.model_version,
            "known_limitations": self.known_limitations,
            "provenance_hash": self.provenance_hash,
        }
        if self.model_hash is not None:
            d["model_hash"] = self.model_hash
        if self.fine_tune_id is not None:
            d["fine_tune_id"] = self.fine_tune_id
        if self.fine_tune_base is not None:
            d["fine_tune_base"] = self.fine_tune_base
        if self.safety_evaluation_id is not None:
            d["safety_evaluation_id"] = self.safety_evaluation_id
        if self.training_data_summary is not None:
            d["training_data_summary"] = self.training_data_summary
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ModelProvenance:
        return cls(
            model_provider=d["model_provider"],
            model_name=d["model_name"],
            model_version=d["model_version"],
            model_hash=d.get("model_hash"),
            fine_tune_id=d.get("fine_tune_id"),
            fine_tune_base=d.get("fine_tune_base"),
            safety_evaluation_id=d.get("safety_evaluation_id"),
            training_data_summary=d.get("training_data_summary"),
            known_limitations=d.get("known_limitations", []),
            provenance_hash=d.get("provenance_hash", ""),
        )


@dataclass
class AgentCertificate:
    """A Nomotic agent birth certificate.

    This is the agent's identity. The certificate is signed by the Nomotic
    instance's issuer key and carries the agent's public key, trust score,
    behavioral age, and governance configuration hash.

    The JSON serialization (sorted keys) is the canonical form used for
    hashing and signing.
    """

    certificate_id: str
    agent_id: str
    owner: str
    archetype: str
    organization: str
    zone_path: str
    issued_at: datetime
    trust_score: float
    behavioral_age: int
    status: CertStatus
    public_key: bytes
    fingerprint: str
    governance_hash: str
    lineage: str | None
    issuer_signature: bytes
    expires_at: datetime | None = None
    agent_numeric_id: int = 0  # Sequential ID from registry
    model_provenance: ModelProvenance | None = None

    # ── Serialization ────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Convert to a JSON-serializable dict with sorted keys."""
        return {
            "agent_id": self.agent_id,
            "agent_numeric_id": self.agent_numeric_id,
            "archetype": self.archetype,
            "behavioral_age": self.behavioral_age,
            "certificate_id": self.certificate_id,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "fingerprint": self.fingerprint,
            "governance_hash": self.governance_hash,
            "issued_at": self.issued_at.isoformat(),
            "issuer_signature": base64.b64encode(self.issuer_signature).decode("ascii"),
            "lineage": self.lineage,
            "model_provenance": self.model_provenance.to_dict() if self.model_provenance else None,
            "organization": self.organization,
            "owner": self.owner,
            "public_key": base64.b64encode(self.public_key).decode("ascii"),
            "status": self.status.name,
            "trust_score": self.trust_score,
            "zone_path": self.zone_path,
        }

    def to_json(self) -> str:
        """Canonical JSON (sorted keys, no extra whitespace)."""
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))

    def to_signing_bytes(self) -> bytes:
        """Bytes used for issuer signature — immutable identity fields only.

        The signature proves *who this agent is* and *who issued it*, not
        the agent's current behavioral state.  Mutable fields (trust_score,
        behavioral_age, status, governance_hash) are deliberately excluded
        so that routine state updates don't invalidate the signature.

        Signed fields: certificate_id, agent_id, owner, archetype,
        organization, zone_path, issued_at, public_key, fingerprint,
        lineage, expires_at.
        """
        d = {
            "agent_id": self.agent_id,
            "archetype": self.archetype,
            "certificate_id": self.certificate_id,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "fingerprint": self.fingerprint,
            "issued_at": self.issued_at.isoformat(),
            "lineage": self.lineage,
            "organization": self.organization,
            "owner": self.owner,
            "public_key": base64.b64encode(self.public_key).decode("ascii"),
            "zone_path": self.zone_path,
        }
        if self.model_provenance is not None:
            d["provenance_hash"] = self.model_provenance.provenance_hash
        return json.dumps(d, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def to_binary(self) -> bytes:
        """Compact binary representation (UTF-8 encoded canonical JSON)."""
        return self.to_json().encode("utf-8")

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AgentCertificate:
        """Reconstruct a certificate from a dict (e.g. parsed JSON)."""
        expires_raw = d.get("expires_at")
        mp_raw = d.get("model_provenance")
        return cls(
            certificate_id=d["certificate_id"],
            agent_id=d["agent_id"],
            owner=d.get("owner", ""),
            archetype=d["archetype"],
            organization=d["organization"],
            zone_path=d["zone_path"],
            issued_at=datetime.fromisoformat(d["issued_at"]),
            trust_score=d["trust_score"],
            behavioral_age=d["behavioral_age"],
            status=CertStatus[d["status"]],
            public_key=base64.b64decode(d["public_key"]),
            fingerprint=d["fingerprint"],
            governance_hash=d["governance_hash"],
            lineage=d.get("lineage"),
            issuer_signature=base64.b64decode(d["issuer_signature"]),
            expires_at=datetime.fromisoformat(expires_raw) if expires_raw else None,
            agent_numeric_id=d.get("agent_numeric_id", 0),
            model_provenance=ModelProvenance.from_dict(mp_raw) if mp_raw else None,
        )

    @classmethod
    def from_json(cls, data: str) -> AgentCertificate:
        """Parse a certificate from canonical JSON."""
        return cls.from_dict(json.loads(data))

    @classmethod
    def from_binary(cls, data: bytes) -> AgentCertificate:
        """Parse a certificate from compact binary (UTF-8 JSON)."""
        return cls.from_json(data.decode("utf-8"))


# ── Verification result types ────────────────────────────────────────────


@dataclass
class CertVerifyResult:
    """Result of Level 2 certificate verification.

    Checks issuer signature validity, certificate status, and expiration.
    """

    valid: bool
    certificate_id: str
    issues: list[str] = field(default_factory=list)
    status: CertStatus | None = None


@dataclass
class LiveVerifyResult:
    """Result of Level 3 live certificate verification.

    Full verification plus current trust score, behavioral age, and health.
    """

    valid: bool
    certificate_id: str
    issues: list[str] = field(default_factory=list)
    status: CertStatus | None = None
    trust_score: float = 0.0
    behavioral_age: int = 0
    governance_hash: str = ""
    healthy: bool = False
