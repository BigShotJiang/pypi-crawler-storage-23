"""Governance Runtime — the orchestrator.

This is where everything comes together. The runtime is the single entry
point for all governance. Every action passes through it. Every governance
decision flows from it.

The pipeline for every action:
1. Receive action + agent context
2. Apply time decay to trust profile
3. Evaluate all 14 dimensions simultaneously
4. Pass through Tier 1 (deterministic gate — vetoes checked)
5. If Tier 1 doesn't decide, compute UCS and pass through Tier 2
6. If Tier 2 doesn't decide, pass through Tier 3 (deliberation)
7. Record the verdict in trust calibration
8. If ALLOW, register execution with interrupt authority
9. During execution, governance monitors run continuously
10. On completion, update trust based on outcome

Governance is not something that happens before execution. It is something
that happens throughout execution. The runtime ensures this.
"""

from __future__ import annotations

import fnmatch
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from nomotic.types import (
    AUDIT_OVERRIDE_COMPLETE,
    AUDIT_OVERRIDE_COSIGNED,
    AUDIT_OVERRIDE_DENIED,
    AUDIT_OVERRIDE_EXPIRED,
    AUDIT_OVERRIDE_PENDING_CREATED,
    Action,
    ActionRecord,
    ActionState,
    AgentContext,
    GovernanceOverrideRecord,
    GovernanceVerdict,
    MultiSigOverridePolicy,
    OverrideSignature,
    PendingOverride,
    TrustProfile,
    UAHSConfig,
    Verdict,
)
from nomotic.dimensions import DimensionRegistry
from nomotic.ucs import UCSEngine
from nomotic.tiers import TierOneGate, TierTwoEvaluator, TierThreeDeliberator
from nomotic.interrupt import ExecutionHandle, InterruptAuthority, InterruptScope
from nomotic.trust import TrustCalibrator, TrustConfig
from nomotic.certificate import AgentCertificate, CertStatus
from nomotic.keys import SigningKey
from nomotic.authority import CertificateAuthority
from nomotic.store import MemoryCertificateStore
from nomotic.registry import ArchetypeRegistry, OrganizationRegistry, ZoneValidator

__all__ = ["GovernanceRuntime", "RuntimeConfig"]


@dataclass
class RuntimeConfig:
    """Configuration for the governance runtime."""

    allow_threshold: float = 0.7
    deny_threshold: float = 0.3
    trust_influence: float = 0.2
    trust_config: TrustConfig = field(default_factory=TrustConfig)
    max_history_per_agent: int = 1000
    enable_fingerprints: bool = True
    drift_config: Any = None
    """Optional :class:`DriftConfig`.  If ``None``, uses DriftConfig defaults.
    Passed to :class:`FingerprintObserver`."""
    enable_audit: bool = True
    audit_max_records: int = 10000
    provenance_max_records: int = 5000
    enable_contextual_modifier: bool = True
    modifier_config: Any = None  # ModifierConfig from contextual_modifier
    enable_workflow_governor: bool = True
    workflow_governor_config: Any = None  # WorkflowGovernorConfig from workflow_governor
    # Phase 8: Ethical Governance Infrastructure
    enable_equity_analysis: bool = True
    equity_config: Any = None  # EquityConfig — org must configure for equity analysis
    enable_bias_detection: bool = True
    enable_ethical_reasoning: bool = True
    ethical_reasoning_config: Any = None  # EthicalReasoningConfig
    enable_cross_dimensional: bool = True
    anonymization_policy: Any = None  # AnonymizationPolicy
    sanitization: Any = None  # SanitizationPolicy from sanitize module
    llm_deliberation: Any = None  # LLMDeliberationConfig from llm_deliberator
    # Preset-driven dimension weights (applied to registry on init)
    dimension_weights: dict[str, float] | None = None
    # Preset-driven veto overrides (dimensions that should have veto authority)
    veto_dimensions: list[str] | None = None
    # Reversibility-aware governance configuration
    reversibility_config: Any = None  # ReversibilityConfig — if None, uses defaults
    risk_tier: str = "moderate"  # "low", "moderate", "high", "critical"
    # Constitutional Rules Engine (pre-governance layer)
    constitutional_ruleset: Any = None      # ConstitutionalRuleSet | None
    constitutional_strict_mode: bool = True
    # Governance Authority Registry (Item 15)
    authority_registry: Any = None  # GovernanceAuthorityRegistry | None
    # Pre-Evaluation State Continuity Check (Item 16)
    enable_continuity_checks: bool = False  # Off by default — opt-in
    continuity_strict_mode: bool = False
    continuity_probes: list | None = None  # None = all probes
    # Pre-Execution Budget Gate (Item 17)
    budget_gate: Any = None  # BudgetGate | None
    # Immutable Pre-Execution Record (Item 18)
    enable_pre_execution_ledger: bool = False
    pre_execution_base_dir: Any = None  # Path | None — uses default_dir if None

    # Agent Lifecycle Hooks (v0.6.0 Item 11)
    enable_lifecycle_hooks: bool = True
    lifecycle_degraded_threshold: float = 0.5
    """UAHS score below which DEGRADED event fires."""
    lifecycle_critical_threshold: float = 0.2
    """UAHS score below which CRITICAL event fires."""
    lifecycle_retirement_trust_floor: float = 0.1
    """Trust score below which RETIREMENT event fires."""

    # Multi-sig override expiry warnings (v0.5.1 Item 3)
    override_expiry_warning_seconds: float = 300.0
    """Fire OVERRIDE_EXPIRING webhook when this many seconds remain before
    a pending override expires. Default 5 minutes.
    Set to 0.0 to disable expiry warnings entirely.
    """

    # Slack integration (F-05 Part C)
    slack_bot_token: str | None = None
    slack_channel_id: str | None = None
    slack_signing_secret: str | None = None

    # Webhook callback (F-05 Part D)
    approval_webhook_url: str | None = None
    server_host: str = "localhost:8080"

    # Configuration Backups (v0.6.0 Item 15)
    enable_config_backups: bool = False
    config_backup_signing_secret: str = ""
    config_backup_max_per_type: int = 5

    @classmethod
    def from_preset(cls, preset_name: str, **overrides: Any) -> "RuntimeConfig":
        """Create a RuntimeConfig from a named preset with optional overrides.

        The preset's thresholds, trust settings, dimension weights, and veto
        configuration are used.  Any keyword arguments override the
        corresponding ``RuntimeConfig`` field.

        Examples::

            config = RuntimeConfig.from_preset("hipaa_aligned")
            config = RuntimeConfig.from_preset("soc2_aligned", allow_threshold=0.85)
        """
        from nomotic.presets import get_preset
        from nomotic.trust import TrustConfig

        preset = get_preset(preset_name)

        # Build TrustConfig from preset trust_settings
        ts = preset.trust_settings
        trust_config = TrustConfig(
            success_increment=ts["success_increment"],
            violation_decrement=ts["violation_decrement"],
            interrupt_decrement=ts["interrupt_cost"],
            decay_rate=ts["decay_rate"],
            min_trust=ts["floor"],
            max_trust=ts["ceiling"],
        )

        kwargs: dict[str, Any] = {
            "allow_threshold": preset.allow_threshold,
            "deny_threshold": preset.deny_threshold,
            "trust_config": trust_config,
            "dimension_weights": dict(preset.dimension_weights),
            "veto_dimensions": list(preset.veto_dimensions),
        }
        kwargs.update(overrides)
        return cls(**kwargs)


class GovernanceRuntime:
    """The complete nomotic governance runtime.

    This is the system. Every action goes through evaluate(). Every
    execution is monitored through the interrupt authority. Trust is
    calibrated continuously. Governance is not advisory — it is
    authoritative.

    Usage:
        runtime = GovernanceRuntime()

        # Configure dimensions
        scope = runtime.registry.get("scope_compliance")
        scope.configure_agent_scope("agent-1", {"read", "write"})

        # Evaluate an action
        verdict = runtime.evaluate(action, context)

        if verdict.verdict == Verdict.ALLOW:
            # Execute with governance oversight
            handle = runtime.begin_execution(action, context)

            # Execution code checks for interrupts
            for step in workflow:
                if handle.check_interrupt():
                    break
                do_work(step)

            runtime.complete_execution(action.id, context)
    """

    def __init__(
        self,
        config: RuntimeConfig | None = None,
        *,
        enable_uahs: bool = False,
        uahs_config: UAHSConfig | None = None,
    ) -> None:
        self.config = config or RuntimeConfig()
        if self.config.allow_threshold <= self.config.deny_threshold:
            raise ValueError(
                f"allow_threshold must be greater than deny_threshold, "
                f"got allow={self.config.allow_threshold}, deny={self.config.deny_threshold}"
            )
        self.registry = DimensionRegistry.create_default()

        # Apply preset dimension weights if configured
        if self.config.dimension_weights:
            for dim_name, weight in self.config.dimension_weights.items():
                dim = self.registry.get(dim_name)
                if dim is not None:
                    dim.weight = weight

        # Apply preset veto overrides if configured
        if self.config.veto_dimensions is not None:
            veto_set = set(self.config.veto_dimensions)
            for dim in self.registry.dimensions:
                dim.can_veto = dim.name in veto_set

        self.ucs_engine = UCSEngine(trust_influence=self.config.trust_influence)
        self.tier_one = TierOneGate()
        self.tier_two = TierTwoEvaluator(
            allow_threshold=self.config.allow_threshold,
            deny_threshold=self.config.deny_threshold,
        )
        self.tier_three = TierThreeDeliberator()
        self.interrupt_authority = InterruptAuthority()
        self.trust_calibrator = TrustCalibrator(config=self.config.trust_config)
        self._action_history: dict[str, list[ActionRecord]] = {}
        self._verdicts: dict[str, GovernanceVerdict] = {}
        self._listeners: list[Callable[[GovernanceVerdict], None]] = []

        # Behavioral fingerprint observer (opt-in, default: enabled)
        if self.config.enable_fingerprints:
            from nomotic.observer import FingerprintObserver
            from nomotic.priors import PriorRegistry
            self._fingerprint_observer: FingerprintObserver | None = FingerprintObserver(
                prior_registry=PriorRegistry.with_defaults(),
                drift_config=self.config.drift_config,
            )
        else:
            self._fingerprint_observer = None

        # Wire fingerprint and drift accessors into dimensions
        if self._fingerprint_observer is not None:
            behavioral = self.registry.get("behavioral_consistency")
            if behavioral is not None:
                behavioral.set_fingerprint_accessor(self._fingerprint_observer.get_fingerprint)
                behavioral.set_drift_accessor(self._fingerprint_observer.get_drift)
            incident = self.registry.get("incident_detection")
            if incident is not None:
                incident.set_drift_accessor(self._fingerprint_observer.get_drift)

        # Wire jurisdictional context accessor
        jc_dim = self.registry.get("jurisdictional_compliance")
        if jc_dim is not None:
            jc_dim.set_jurisdictional_accessor(
                lambda agent_id: self._get_jurisdictional_context(agent_id)
            )

        # Audit trail (Phase 5)
        if self.config.enable_audit:
            from nomotic.audit import AuditTrail
            from nomotic.provenance import ProvenanceLog
            from nomotic.accountability import OwnerActivityLog, UserActivityTracker
            self._audit_trail: AuditTrail | None = AuditTrail(
                max_records=self.config.audit_max_records,
                sanitization_policy=self.config.sanitization,
            )
            self._provenance_log: ProvenanceLog | None = ProvenanceLog(
                max_records=self.config.provenance_max_records,
            )
            self._owner_activity: OwnerActivityLog | None = OwnerActivityLog()
            self._user_tracker: UserActivityTracker | None = UserActivityTracker()
        else:
            self._audit_trail = None
            self._provenance_log = None
            self._owner_activity = None
            self._user_tracker = None

        # Context profiles (Phase 7A)
        from nomotic.context_profile import ContextProfileManager
        self.context_profiles = ContextProfileManager()

        # Contextual modifier (Phase 7B)
        if self.config.enable_contextual_modifier:
            from nomotic.contextual_modifier import ContextualModifier
            self.contextual_modifier: ContextualModifier | None = ContextualModifier(
                config=self.config.modifier_config,
            )
        else:
            self.contextual_modifier = None

        # Workflow Governor (Phase 7C)
        if self.config.enable_workflow_governor:
            from nomotic.workflow_governor import WorkflowGovernor
            self.workflow_governor: WorkflowGovernor | None = WorkflowGovernor(
                config=self.config.workflow_governor_config,
            )
        else:
            self.workflow_governor = None

        # Phase 8: Ethical Governance Infrastructure
        if self.config.enable_equity_analysis and self.config.equity_config is not None:
            from nomotic.equity import EquityAnalyzer
            self.equity_analyzer: Any = EquityAnalyzer(self.config.equity_config)
        else:
            self.equity_analyzer = None

        if self.config.enable_bias_detection and self.config.equity_config is not None:
            from nomotic.bias import BiasDetector
            self.bias_detector: Any = BiasDetector(self.config.equity_config)
        else:
            self.bias_detector = None

        if self.config.enable_cross_dimensional:
            from nomotic.cross_dimensional import CrossDimensionalDetector
            self.cross_dimensional_detector: Any = CrossDimensionalDetector()
        else:
            self.cross_dimensional_detector = None

        self.anonymization_policy: Any = self.config.anonymization_policy

        # LLM Deliberation (auto-register if enabled)
        if self.config.llm_deliberation is not None:
            from nomotic.llm_deliberator import LLMDeliberator
            llm_cfg = self.config.llm_deliberation
            if llm_cfg.enabled:
                self._llm_deliberator: LLMDeliberator | None = LLMDeliberator(llm_cfg)
                self.tier_three.add_deliberator(self._llm_deliberator)
            else:
                self._llm_deliberator = None
        else:
            self._llm_deliberator = None

        # Certificate authority — initialized lazily or explicitly
        self._ca: CertificateAuthority | None = None
        self._cert_map: dict[str, str] = {}  # agent_id -> certificate_id

        # Loop detection monitor
        from nomotic.loop_detector import LoopDetector

        self._loop_detector = LoopDetector()
        self.interrupt_authority.add_monitor(self._loop_detector.check)

        # Registries — initialized lazily
        self._archetype_registry: ArchetypeRegistry | None = None
        self._zone_validator: ZoneValidator | None = None
        self._org_registry: OrganizationRegistry | None = None

        # Role-based override permissions
        self._role_registry: Any = None  # RoleRegistry (lazily imported)

        # Persistent audit store — set via set_audit_store() for override support
        self._persistent_audit_store: Any = None  # LogStore

        # Multi-sig override infrastructure
        self._multisig_policies: list[MultiSigOverridePolicy] = []
        self._pending_overrides: dict[str, PendingOverride] = {}  # override_id -> PendingOverride
        self._pending_lock = threading.Lock()
        self._expiry_warned: set[str] = set()
        # Tracks override_ids that have already received OVERRIDE_EXPIRING webhook
        # to prevent duplicate warnings.

        # Delegation tracking (Multi-Agent Handoff Reporting)
        from nomotic.delegation import DelegationTracker
        self._delegation_tracker = DelegationTracker()

        # Webhook dispatcher (Governance Event Webhooks)
        from nomotic.webhooks import WebhookDispatcher
        self._webhook_dispatcher: WebhookDispatcher = WebhookDispatcher()

        # Slack governance notifier (F-05 Part C)
        self._slack_notifier: Any = None
        if (
            self.config.slack_bot_token
            and self.config.slack_channel_id
            and self.config.slack_signing_secret
        ):
            from nomotic.slack_integration import SlackGovernanceNotifier
            self._slack_notifier = SlackGovernanceNotifier(
                bot_token=self.config.slack_bot_token,
                channel_id=self.config.slack_channel_id,
                signing_secret=self.config.slack_signing_secret,
                runtime=self,
                authority_registry=self.config.authority_registry,
            )

        # Policy-as-Code pre-filter engine
        from nomotic.policy import PolicyEngine
        self._policy_engine = PolicyEngine()

        # Constitutional Rules Engine (pre-governance layer)
        self._constitutional_engine: Any = None
        if self.config.constitutional_ruleset is not None:
            from nomotic.constitution import ConstitutionalEngine
            verify_key_bytes = (
                self._ca._verify_key.encode()
                if self._ca is not None
                else None
            )
            self._constitutional_engine = ConstitutionalEngine(
                ruleset=self.config.constitutional_ruleset,
                verify_key_bytes=verify_key_bytes,
                strict_mode=self.config.constitutional_strict_mode,
            )

        # Governance Authority Registry (Item 15)
        self._authority_registry: Any = self.config.authority_registry

        # Pre-Evaluation State Continuity Check (Item 16)
        self._continuity_checker: Any = None
        if self.config.enable_continuity_checks:
            from nomotic.continuity import ContinuityChecker
            self._continuity_checker = ContinuityChecker(
                enabled_probes=self.config.continuity_probes,
                strict_mode=self.config.continuity_strict_mode,
            )

        # Pre-Execution Budget Gate (Item 17)
        self._budget_gate: Any = self.config.budget_gate
        self._active_reservations: dict[str, str] = {}  # action_id -> reservation_id

        # Immutable Pre-Execution Record (Item 18)
        self._pre_execution_ledger: Any = None
        if self.config.enable_pre_execution_ledger:
            from nomotic.pre_execution import PreExecutionLedger
            base = self.config.pre_execution_base_dir or (
                Path.home() / ".nomotic"
            )
            self._pre_execution_ledger = PreExecutionLedger(base)

        # Output governor — lazily initialized
        self._output_governor: Any = None  # OutputGovernor

        # Workflow seal chains
        self._workflow_chains: dict[str, Any] = {}  # chain_id -> WorkflowSealChain

        # Cross-workflow dependency checker (Item 13, v0.6.0)
        self._workflow_dependency_checker: Any = None  # WorkflowDependencyChecker | None

        # UAHS auto-integration (opt-in)
        self._enable_uahs = enable_uahs
        self._uahs_config = uahs_config or UAHSConfig()
        self._ucs_tracker: Any = None  # UCSTracker
        self._uahs_calculator: Any = None  # UnifiedHealthScoreCalculator
        self._uahs_feedback: Any = None  # FeedbackLoopManager
        self._uahs_health_store: Any = None  # GovernanceHealthStore
        self._uahs_eval_counts: dict[str, int] = {}  # agent_id -> count since last scoring
        self._uahs_prev_scores: dict[str, int] = {}  # agent_id -> previous unified_score
        self._uahs_prev_uahs: dict[str, Any] = {}  # agent_id -> previous UnifiedAgentHealthScore

        if self._enable_uahs:
            self._init_uahs()

        # Wire UAHS health into budget gate (both must be enabled)
        if (
            self._budget_gate is not None
            and self._ucs_tracker is not None  # UAHS enabled
        ):
            def _uahs_health_accessor(agent_id: str) -> float | None:
                score = self.get_uahs(agent_id)
                return score.unified_score / 100.0 if score is not None else None

            self._budget_gate.set_uahs_accessor(_uahs_health_accessor)

        # Agent Lifecycle Hooks (v0.6.0 Item 11)
        from nomotic.lifecycle import LifecycleManager
        self._lifecycle_manager = LifecycleManager(
            webhook_dispatcher=self._webhook_dispatcher,
        )
        # Track last-known lifecycle state per agent to avoid duplicate events
        self._lifecycle_state: dict[str, str] = {}

        # Configuration Backups (v0.6.0 Item 15)
        self._backup_manager: Any = None
        if (
            self.config.enable_config_backups
            and self.config.config_backup_signing_secret
        ):
            from nomotic.config_backup import ConfigBackupManager

            self._backup_manager = ConfigBackupManager(
                base_dir=self._base_dir if hasattr(self, "_base_dir") else Path.home() / ".nomotic",
                signing_secret=self.config.config_backup_signing_secret,
                max_backups_per_type=self.config.config_backup_max_per_type,
            )
            self._create_startup_backups()

    def _create_startup_backups(self) -> None:
        """Create backups of all configured governance artifacts."""
        if self._backup_manager is None:
            return
        # Constitutional ruleset
        if self._constitutional_engine is not None:
            try:
                rs = self._constitutional_engine._ruleset
                if rs is not None:
                    self._backup_manager.backup(
                        "constitutional_ruleset", rs.to_dict()
                    )
            except Exception:
                pass
        # Authority registry
        if hasattr(self, "_authority_registry") and self._authority_registry:
            try:
                self._backup_manager.backup(
                    "authority_registry",
                    {"authorities": [
                        a.to_dict()
                        for a in self._authority_registry.list_authorities()
                    ]},
                )
            except Exception:
                pass
        # Role registry
        if hasattr(self, "_role_registry") and self._role_registry:
            try:
                self._backup_manager.backup(
                    "role_registry",
                    {"roles": [
                        r.to_dict()
                        for r in self._role_registry.list_roles()
                    ]},
                )
            except Exception:
                pass

    def shutdown(self) -> None:
        """Graceful shutdown: create final backups, flush webhook queue."""
        self._create_startup_backups()  # Final backup on shutdown
        if hasattr(self, "_webhook_dispatcher") and self._webhook_dispatcher:
            try:
                self._webhook_dispatcher.drain_queue()
            except Exception:
                pass

    def _init_uahs(self) -> None:
        """Initialize UAHS components. Called once when enable_uahs=True."""
        from nomotic.drift import (
            AmbiguityDriftConfig,
            FeedbackLoopManager,
            UnifiedHealthScoreCalculator,
        )
        from nomotic.ucs_tracker import UCSTracker

        drift_config = self._uahs_config.drift_config or AmbiguityDriftConfig()
        self._ucs_tracker = UCSTracker(default_config=drift_config)
        self._uahs_calculator = UnifiedHealthScoreCalculator()
        self._uahs_feedback = FeedbackLoopManager()

        if (
            self._uahs_config.health_store_enabled
            and self._persistent_audit_store is not None
        ):
            from nomotic.audit_store import GovernanceHealthStore

            self._uahs_health_store = GovernanceHealthStore(
                base_dir=self._persistent_audit_store._dir.parent
            )

    def _post_evaluate_uahs(
        self, agent_id: str, verdict: GovernanceVerdict
    ) -> None:
        """Post-evaluation UAHS pipeline. Called after every evaluate() when enabled.

        UAHS is observational — failures must never propagate to callers.
        """
        try:
            if self._ucs_tracker is None:
                return

            # 1. Record the evaluation output in UCSTracker
            is_override = verdict.verdict == Verdict.ESCALATE
            self._ucs_tracker.record(
                agent_id=agent_id,
                ucs=verdict.ucs,
                verdict=verdict.verdict.name,
                was_human_override=is_override,
            )

            # 2. Increment eval count; check if it's time to score
            count = self._uahs_eval_counts.get(agent_id, 0) + 1
            self._uahs_eval_counts[agent_id] = count

            if count % self._uahs_config.scoring_interval != 0:
                return  # Not time to score yet

            # 3. Compute UAHS
            if self._uahs_calculator is None:
                return

            ambiguity_profile = self._ucs_tracker.get_profile(agent_id)
            if ambiguity_profile is None:
                return

            # Behavioral drift score from fingerprint observer
            behavioral_drift = 0.0
            if self._fingerprint_observer is not None:
                drift = self._fingerprint_observer.get_drift(agent_id)
                if drift is not None:
                    behavioral_drift = drift.overall

            # Oversight degradation from trust profile violation rate
            trust_profile = self.trust_calibrator.get_profile(agent_id)
            oversight_degradation = trust_profile.violation_rate

            # Previous score for trend computation
            prev_score = self._uahs_prev_scores.get(agent_id, -1)

            uahs = self._uahs_calculator.compute(
                agent_id=agent_id,
                behavioral_drift_score=behavioral_drift,
                oversight_degradation_score=oversight_degradation,
                ambiguity_profile=ambiguity_profile,
                prev_score=prev_score,
            )

            self._uahs_prev_scores[agent_id] = uahs.unified_score

            # 4. Run feedback loop if enabled
            if (
                self._uahs_config.feedback_enabled
                and self._uahs_feedback is not None
            ):
                prev_uahs = self._uahs_prev_uahs.get(agent_id)
                events = self._uahs_feedback.process(
                    agent_id=agent_id,
                    current_score=uahs,
                    prev_score=prev_uahs,
                    ambiguity_observer=self._ucs_tracker.observer,
                    trust_calibrator=self.trust_calibrator,
                )
                self._uahs_prev_uahs[agent_id] = uahs

                # Persist health events if store is configured
                if self._uahs_health_store is not None and events:
                    from nomotic.drift import persist_health_events

                    try:
                        persist_health_events(
                            events=events,
                            store=self._uahs_health_store,
                            current_uahs=uahs,
                            prev_uahs=prev_uahs,
                        )
                    except Exception:
                        pass  # Health store failures must never affect governance
            else:
                # Still track prev UAHS even without feedback
                self._uahs_prev_uahs[agent_id] = uahs

            # 5. Threshold-aware drift alert dispatch
            drift_profile = self._ucs_tracker.get_profile(agent_id)
            if drift_profile is not None:
                drift_score = getattr(drift_profile, "drift_score", 0.0)
                eval_count = self._uahs_eval_counts.get(agent_id, 0)

                # Look up per-archetype threshold if configured
                archetype = self._get_agent_archetype_safe(agent_id)
                threshold = self._uahs_config.archetype_thresholds.get(
                    archetype, self._uahs_config.drift_alert_threshold
                )

                # Suppress until minimum evaluations reached
                sufficient_history = (
                    eval_count >= self._uahs_config.min_evaluations_before_alert
                )

                if drift_score > threshold and sufficient_history:
                    self._dispatch_webhook("DRIFT_ALARM", agent_id, {
                        "agent_id": agent_id,
                        "drift_score": drift_score,
                        "threshold": threshold,
                        "archetype": archetype,
                        "evaluations_recorded": eval_count,
                    })

        except Exception:
            pass  # UAHS observational — must never affect governance

    def _get_agent_archetype_safe(self, agent_id: str) -> str:
        """Look up archetype without raising. Returns '*' on any failure."""
        try:
            cert = self._cert_store.get(agent_id) if hasattr(self, "_cert_store") and self._cert_store is not None else None
            return getattr(cert, "archetype", "*") if cert else "*"
        except Exception:
            return "*"

    def evaluate(self, action: Action, context: AgentContext) -> GovernanceVerdict:
        """Evaluate an action through the full governance pipeline.

        This is the primary entry point. Returns a GovernanceVerdict
        that tells the caller what to do.
        """
        start = time.time()

        # Step 0: Constitutional Rules — pre-governance hard constraints
        if self._constitutional_engine is not None and self._constitutional_engine.has_rules():
            violations = self._constitutional_engine.evaluate(action, context)
            if violations:
                # Write audit record for constitutional violation
                self._write_constitutional_violation_audit(action, context, violations)
                # Raise — constitutional violations are non-negotiable
                from nomotic.constitution import ConstitutionalViolationError
                raise ConstitutionalViolationError(violations[0])

        # Step 0b: Pre-evaluation state continuity check
        if self._continuity_checker is not None:
            _continuity_result = self._continuity_checker.check(
                agent_id=context.agent_id,
                audit_store=self._persistent_audit_store,
                cert_store=self._cert_store if hasattr(self, "_cert_store") else None,
                seal_registry=self._seal_registry if hasattr(self, "_seal_registry") else None,
            )
            if not _continuity_result.passed:
                self._write_continuity_violation_audit(action, context, _continuity_result)
                if not self.config.continuity_strict_mode:
                    # Non-strict: return DENY with continuity reason
                    return self._make_continuity_deny_verdict(
                        action, context, _continuity_result,
                    )
                # Strict mode: ContinuityChecker already raised

        # Step 0c: Policy pre-filter
        policy_result = self._policy_engine.evaluate(action, context)
        if policy_result is not None:
            if policy_result.verdict == "DENY":
                p_verdict = Verdict.DENY
            else:
                p_verdict = Verdict.ESCALATE
            verdict = GovernanceVerdict(
                action_id=action.id,
                verdict=p_verdict,
                tier=0,
                ucs=0.0,
                reasoning=policy_result.reason,
                dimension_scores=[],
                modifications={"policy_match": policy_result.matched_policy},
            )
            verdict.evaluation_time_ms = (time.time() - start) * 1000
            self._record_verdict(action, context, verdict)
            return verdict

        # Step 1: Apply time decay to trust
        self.trust_calibrator.apply_time_decay(context.agent_id)
        context.trust_profile = self.trust_calibrator.get_profile(context.agent_id)

        # Step 1b: Apply workflow governor (Phase 7C) and contextual modifier (Phase 7B)
        context_modification = None
        original_weights: dict[str, float] = {}
        if (
            self.contextual_modifier is not None
            and context.context_profile_id is not None
        ):
            profile = self.context_profiles.get_profile(context.context_profile_id)
            if profile is not None:
                # Workflow Governor: assess step before modifier
                if (
                    self.workflow_governor is not None
                    and profile.workflow is not None
                ):
                    step_assessment = self.workflow_governor.assess_step(
                        profile.workflow.current_step,
                        action,
                        context,
                        profile,
                    )
                    # Store assessment on profile metadata for modifier consumption
                    if not hasattr(profile, '_step_assessment'):
                        object.__setattr__(profile, '_step_assessment', step_assessment)
                    else:
                        profile._step_assessment = step_assessment  # type: ignore[attr-defined]

                context_modification = self.contextual_modifier.modify(
                    action, context, profile,
                )
                # Apply weight adjustments temporarily
                if context_modification.weight_adjustments:
                    original_weights = self._apply_weight_adjustments(
                        context_modification.weight_adjustments,
                    )
                # Apply trust modifier
                if context_modification.trust_modifier != 0.0:
                    context.trust_profile.overall_trust = max(
                        0.0,
                        min(
                            1.0,
                            context.trust_profile.overall_trust
                            + context_modification.trust_modifier,
                        ),
                    )

        # Step 1c: Assess reversibility (always, even without context profile)
        from nomotic.reversibility import CommitPointDetector

        _rev_detector = CommitPointDetector()
        _rev_context = context.metadata if context.metadata else None
        rev_assessment = _rev_detector.assess(
            action.action_type, action.target, context=_rev_context,
        )

        # Step 1d: Compute reversibility-based threshold adjustment
        rev_config = self._get_reversibility_config()
        rev_ucs_increase = self._compute_reversibility_ucs_increase(
            rev_assessment, rev_config,
        )

        try:
            # Step 2: Evaluate all 14 dimensions simultaneously
            scores = self.registry.evaluate_all(action, context)

            # Step 2b: Cross-dimensional signal detection (Phase 8)
            cross_dim_signals: list[Any] = []
            if self.cross_dimensional_detector is not None:
                cross_dim_signals = self.cross_dimensional_detector.detect_signals(
                    scores,
                    trust_state=context.trust_profile.overall_trust,
                    action=action,
                )

            # Step 3: Tier 1 — deterministic gate
            tier1_result = self.tier_one.evaluate(action, context, scores)
            if tier1_result.decided:
                verdict = tier1_result.verdict
                assert verdict is not None
                verdict.evaluation_time_ms = (time.time() - start) * 1000
                verdict.context_modification = context_modification
                verdict.cross_dimensional_signals = cross_dim_signals
                verdict.reversibility = rev_assessment.to_dict()
                self._record_verdict(action, context, verdict)
                return verdict

            # Step 4: Compute UCS for Tier 2
            ucs = self.ucs_engine.compute(scores, context.trust_profile)

            # Step 4b: Cross-dimensional signals influence ambiguous decisions
            if cross_dim_signals:
                critical_signals = [
                    s for s in cross_dim_signals if s.severity == "critical"
                ]
                if critical_signals and self.config.deny_threshold < ucs < self.config.allow_threshold:
                    # Push ambiguous UCS toward ESCALATE
                    ucs = max(ucs - 0.1, 0.0)

            # Step 4c: Reversibility-based tier escalation
            # If the action requires escalation (irreversible on sensitive target),
            # skip tier 2 and go directly to tier 3 (full deliberation)
            force_tier3 = (
                rev_assessment.requires_escalation
                or rev_assessment.level.value in rev_config.force_tier3_levels
            )

            # Step 4d: Reversibility threshold adjustment
            # Instead of raising the threshold, lower the UCS by the same amount.
            # Effect is identical: action needs higher confidence to pass.
            effective_ucs = ucs - rev_ucs_increase

            # Step 5: Tier 2 — weighted evaluation (skip if escalation forced)
            if not force_tier3:
                tier2_result = self.tier_two.evaluate(action, context, scores, effective_ucs)
                if tier2_result.decided:
                    verdict = tier2_result.verdict
                    assert verdict is not None
                    verdict.evaluation_time_ms = (time.time() - start) * 1000
                    verdict.context_modification = context_modification
                    verdict.cross_dimensional_signals = cross_dim_signals
                    verdict.reversibility = rev_assessment.to_dict()
                    verdict.modifications["reversibility_ucs_adjustment"] = rev_ucs_increase
                    verdict.modifications["effective_ucs"] = effective_ucs
                    self._record_verdict(action, context, verdict)
                    return verdict

            # Step 6: Tier 3 — deliberative review
            tier3_result = self.tier_three.evaluate(action, context, scores, effective_ucs)
            verdict = tier3_result.verdict
            assert verdict is not None
            verdict.evaluation_time_ms = (time.time() - start) * 1000
            verdict.context_modification = context_modification
            verdict.cross_dimensional_signals = cross_dim_signals
            verdict.reversibility = rev_assessment.to_dict()
            verdict.modifications["reversibility_ucs_adjustment"] = rev_ucs_increase
            verdict.modifications["effective_ucs"] = effective_ucs
            self._record_verdict(action, context, verdict)
            return verdict
        finally:
            # Restore original weights — per-evaluation only, never persistent
            if original_weights:
                self._restore_weights(original_weights)

    def begin_execution(
        self,
        action: Action,
        context: AgentContext,
        rollback: Callable[[], None] | None = None,
        workflow_id: str | None = None,
    ) -> ExecutionHandle:
        """Register an approved action for execution with governance oversight.

        Returns an ExecutionHandle that the execution layer uses to check
        for interrupts. The governance layer can interrupt through the
        interrupt_authority at any time.
        """
        # Budget gate: check pre-execution budget before issuing handle
        if self._budget_gate is not None:
            estimated_cost = (
                action.metadata.get("estimated_cost_usd", 0.0)
                if action.metadata
                else 0.0
            )
            gate_result = self._budget_gate.check_and_reserve(
                agent_id=context.agent_id,
                action_id=action.id,
                estimated_cost_usd=estimated_cost,
            )
            if not gate_result.approved:
                from nomotic.budget_gate import BudgetExhaustedError
                raise BudgetExhaustedError(gate_result)
            # Store reservation_id for settlement on completion
            if gate_result.reservation:
                self._active_reservations[action.id] = (
                    gate_result.reservation.reservation_id
                )

        # Pre-execution record — immutable commitment before handle issuance
        _pe_record_id: str | None = None
        if self._pre_execution_ledger is not None:
            _seal_id = getattr(action, "_seal_id", None)  # Set by seal() if called
            pe_record = self._pre_execution_ledger.write_pre_execution(
                agent_id=context.agent_id,
                action_id=action.id,
                action_type=action.action_type,
                action_target=action.target,
                governance_seal_id=_seal_id,
                approved_at=time.time(),
                context_profile_id=context.context_profile_id,
                estimated_cost_usd=action.metadata.get("estimated_cost_usd", 0.0)
                    if action.metadata else 0.0,
                budget_reservation_id=self._active_reservations.get(action.id),
            )
            _pe_record_id = pe_record.record_id

        return self.interrupt_authority.register_execution(
            action=action,
            agent_id=context.agent_id,
            workflow_id=workflow_id,
            rollback=rollback,
        )

    def complete_execution(
        self,
        action_id: str,
        context: AgentContext,
        outcome: dict[str, Any] | None = None,
    ) -> ActionRecord | None:
        """Record successful completion of an action.

        Updates trust calibration and action history.
        """
        verdict = self._verdicts.get(action_id)
        if not verdict:
            return None

        self.interrupt_authority.complete_execution(action_id)

        # Settle budget reservation if one exists
        if self._budget_gate is not None and action_id in self._active_reservations:
            reservation_id = self._active_reservations.pop(action_id)
            actual_cost = (outcome or {}).get("actual_cost_usd", 0.0)
            try:
                self._budget_gate.settle(reservation_id, actual_cost)
            except (ValueError, Exception):
                pass  # Settlement failures must not block completion

        # Settle pre-execution record
        if self._pre_execution_ledger is not None:
            try:
                from nomotic.pre_execution import ExecutionOutcome
                self._pre_execution_ledger.settle(
                    action_id=action_id,
                    outcome=ExecutionOutcome.SUCCESS,
                    actual_cost_usd=(outcome or {}).get("actual_cost_usd", 0.0),
                    actual_tokens=(outcome or {}).get("actual_tokens", 0),
                )
            except (KeyError, RuntimeError):
                pass  # Settlement failures must not block completion

        record = ActionRecord(
            action=Action(id=action_id, agent_id=context.agent_id),
            verdict=verdict,
            state=ActionState.COMPLETED,
            outcome=outcome or {},
        )

        self.trust_calibrator.record_completion(context.agent_id, record)
        self._append_history(context.agent_id, record)
        return record

    def interrupt_action(
        self,
        action_id: str,
        reason: str,
        source: str = "governance",
        scope: InterruptScope = InterruptScope.ACTION,
    ) -> bool:
        """Interrupt a running action.

        This is governance with teeth. Returns True if the interrupt
        was issued, False if the action wasn't found.
        """
        records = self.interrupt_authority.interrupt(
            action_id=action_id,
            reason=reason,
            source=source,
            scope=scope,
        )
        # Update trust for interrupted agent(s)
        for record in records:
            agent_id = record.handle.agent_id
            action_record = ActionRecord(
                action=record.handle.action,
                verdict=self._verdicts.get(record.handle.action.id, GovernanceVerdict(
                    action_id=record.handle.action.id,
                    verdict=Verdict.SUSPEND,
                    ucs=0.0,
                )),
                state=ActionState.INTERRUPTED,
                interrupted=True,
                interrupt_reason=reason,
            )
            self.trust_calibrator.record_completion(agent_id, action_record)
            self._append_history(agent_id, action_record)

            # Settle pre-execution record as interrupted
            if self._pre_execution_ledger is not None:
                try:
                    from nomotic.pre_execution import ExecutionOutcome
                    self._pre_execution_ledger.settle(
                        action_id=record.handle.action.id,
                        outcome=ExecutionOutcome.INTERRUPTED,
                        error_message=reason,
                    )
                except (KeyError, RuntimeError):
                    pass  # Settlement failures must not block interrupt

        return len(records) > 0

    def add_verdict_listener(
        self, listener: Callable[[GovernanceVerdict], None]
    ) -> None:
        """Register a listener called after every governance verdict."""
        self._listeners.append(listener)

    def get_agent_history(self, agent_id: str) -> list[ActionRecord]:
        return list(self._action_history.get(agent_id, []))

    def get_trust_profile(self, agent_id: str) -> TrustProfile:
        return self.trust_calibrator.get_profile(agent_id)

    def get_uahs(self, agent_id: str) -> Any | None:
        """Get the current UnifiedAgentHealthScore for an agent.

        Returns None if UAHS is not enabled or the agent has not yet
        reached the scoring interval threshold.
        """
        if not self._enable_uahs or self._ucs_tracker is None:
            return None
        ambiguity_profile = self._ucs_tracker.get_profile(agent_id)
        if ambiguity_profile is None:
            return None
        if self._uahs_calculator is None:
            return None

        # Behavioral drift score from fingerprint observer
        behavioral_drift = 0.0
        if self._fingerprint_observer is not None:
            drift = self._fingerprint_observer.get_drift(agent_id)
            if drift is not None:
                behavioral_drift = drift.overall

        # Oversight degradation from trust profile violation rate
        trust_profile = self.trust_calibrator.get_profile(agent_id)
        oversight_degradation = trust_profile.violation_rate

        prev_score = self._uahs_prev_scores.get(agent_id, -1)

        return self._uahs_calculator.compute(
            agent_id=agent_id,
            behavioral_drift_score=behavioral_drift,
            oversight_degradation_score=oversight_degradation,
            ambiguity_profile=ambiguity_profile,
            prev_score=prev_score,
        )

    def get_ambiguity_profile(self, agent_id: str) -> Any | None:
        """Get the AmbiguityDriftProfile for an agent."""
        if not self._enable_uahs or self._ucs_tracker is None:
            return None
        return self._ucs_tracker.get_profile(agent_id)

    def reset_uahs(self, agent_id: str) -> None:
        """Clear all accumulated UAHS data for an agent.

        Use after model updates, agent reconfiguration, or in testing.
        Clears: UCSTracker history, health calculator state, feedback
        manager state, evaluation count.

        Does NOT clear audit records — those are immutable.

        Raises ValueError if UAHS is not enabled on this runtime.
        """
        if self._ucs_tracker is None:
            raise ValueError(
                "UAHS is not enabled on this runtime. "
                "Set enable_uahs=True in RuntimeConfig to use reset_uahs()."
            )
        # Reset each component — use .reset(agent_id) if the method exists,
        # otherwise remove the agent's key from internal dicts
        for component in [
            self._ucs_tracker,
            self._uahs_calculator,
            self._uahs_feedback,
        ]:
            if component is not None and hasattr(component, "reset"):
                component.reset(agent_id)

        # Reset evaluation count and cached scores
        self._uahs_eval_counts.pop(agent_id, None)
        self._uahs_prev_scores.pop(agent_id, None)
        self._uahs_prev_uahs.pop(agent_id, None)

    # ── Webhook configuration ─────────────────────────────────────────

    def configure_webhooks(self, config: dict[str, Any]) -> None:
        """Configure webhook endpoints from config dict.

        Expected format::

            {
                "webhooks": [
                    {"url": "https://...", "events": ["DENY", "SUSPEND"]},
                    {"url": "https://...", "events": ["TRUST_DROP"]}
                ]
            }
        """
        from nomotic.webhooks import WebhookDispatcher
        self._webhook_dispatcher = WebhookDispatcher.from_config(config)

    def _dispatch_webhook(
        self, event_type: str, agent_id: str, payload: dict[str, Any]
    ) -> None:
        """Dispatch a governance event to configured webhooks."""
        if self._webhook_dispatcher is not None:
            from nomotic.webhooks import WebhookEvent
            event = WebhookEvent(
                event_type=event_type,
                event_id=f"nme-{uuid.uuid4().hex[:12]}",
                timestamp=time.time(),
                agent_id=agent_id,
                payload=payload,
            )
            self._webhook_dispatcher.dispatch(event)

    @property
    def webhook_dispatcher(self) -> Any:
        """The webhook dispatcher for governance events."""
        return self._webhook_dispatcher

    @property
    def policy_engine(self) -> Any:
        """The policy-as-code pre-filter engine."""
        return self._policy_engine

    @property
    def loop_detector(self) -> Any:
        """The loop detection monitor for this runtime."""
        return self._loop_detector

    @property
    def output_governor(self) -> Any:
        """Lazily initialized output governor."""
        if self._output_governor is None:
            from nomotic.output_governor import OutputGovernor
            self._output_governor = OutputGovernor(
                audit_store=self._persistent_audit_store,
                webhook_dispatcher=self._webhook_dispatcher,
            )
        return self._output_governor

    # ── Registry accessors ────────────────────────────────────────────

    @property
    def archetype_registry(self) -> ArchetypeRegistry:
        """Lazily initialized archetype registry with defaults."""
        if self._archetype_registry is None:
            self._archetype_registry = ArchetypeRegistry.with_defaults()
        return self._archetype_registry

    @property
    def zone_validator(self) -> ZoneValidator:
        """Lazily initialized zone validator."""
        if self._zone_validator is None:
            self._zone_validator = ZoneValidator()
        return self._zone_validator

    @property
    def org_registry(self) -> OrganizationRegistry:
        """Lazily initialized organization registry."""
        if self._org_registry is None:
            self._org_registry = OrganizationRegistry()
        return self._org_registry

    # ── Certificate integration ──────────────────────────────────────

    def _ensure_ca(self) -> CertificateAuthority:
        """Lazily initialize the certificate authority.

        The auto-created CA does not attach registries — it is a bare
        authority for programmatic use.  Attach registries explicitly via
        :meth:`set_certificate_authority` or by passing a pre-configured
        CA.
        """
        if self._ca is None:
            sk, _vk = SigningKey.generate()
            self._ca = CertificateAuthority(
                issuer_id="runtime-auto",
                signing_key=sk,
                store=MemoryCertificateStore(),
            )
        return self._ca

    def set_certificate_authority(self, ca: CertificateAuthority) -> None:
        """Attach an external certificate authority to this runtime."""
        self._ca = ca

    def set_audit_store(self, store: Any) -> None:
        """Attach a persistent audit store (LogStore) for override support."""
        self._persistent_audit_store = store

    def set_role_registry(self, registry: Any) -> None:
        """Attach an external role registry for override permission checks."""
        self._role_registry = registry

    def load_roles(self, path: str | Path) -> int:
        """Load roles from a file, creating a RoleRegistry if needed.

        Returns the count of roles loaded.
        """
        from nomotic.roles import RoleRegistry

        if self._role_registry is None:
            self._role_registry = RoleRegistry()
        count = self._role_registry.load_from_file(path)
        return count

    # ── Delegation (Multi-Agent Handoff Reporting) ────────────────

    def delegate(
        self,
        from_agent: str,
        to_agent: str,
        scope: set[str],
        targets: set[str],
        **kwargs: Any,
    ) -> "DelegationRecord":
        """Create a delegation between agents. Writes audit record."""
        from nomotic.delegation import DelegationRecord

        record: DelegationRecord = self._delegation_tracker.delegate(
            from_agent, to_agent, scope, targets, **kwargs
        )
        self._record_delegation_audit(record)
        return record

    def get_delegation_chain(self, agent_id: str) -> list["DelegationRecord"]:
        """Trace the full delegation chain for an agent."""
        return self._delegation_tracker.get_delegation_chain(agent_id)

    def configure_delegation_depth(self, depth_config: "DelegationDepthConfig") -> None:
        """Configure delegation depth limits."""
        if self._delegation_tracker is not None:
            self._delegation_tracker._depth_config = depth_config

    def _record_delegation_audit(self, record: "DelegationRecord") -> None:
        """Write delegation to audit trail."""
        if self._persistent_audit_store is not None:
            from nomotic.audit_store import PersistentLogRecord

            store = self._persistent_audit_store
            previous_hash = store.get_last_hash(record.from_agent)

            log_record_data = {
                "record_id": record.delegation_id,
                "timestamp": record.timestamp,
                "agent_id": record.from_agent,
                "action_type": "delegate",
                "action_target": record.to_agent,
                "verdict": "ALLOW",
                "ucs": 1.0,
                "tier": 0,
                "trust_score": 0.0,
                "trust_delta": 0.0,
                "trust_trend": "stable",
                "severity": "info",
                "justification": f"Delegated {sorted(record.delegated_scope)} to {record.to_agent}",
                "vetoed_by": [],
                "dimension_scores": {},
                "parameters": {
                    "delegation_id": record.delegation_id,
                    "delegated_scope": sorted(record.delegated_scope),
                    "delegated_targets": sorted(record.delegated_targets),
                    "authority_basis": record.authority_basis,
                },
                "source": "delegation",
                "previous_hash": previous_hash,
                "record_hash": "",
            }
            log_record_data["record_hash"] = store.compute_hash(
                log_record_data, previous_hash
            )
            log_record = PersistentLogRecord(**log_record_data)
            store.append(log_record)

    # ── Multi-sig override policy management ────────────────────────

    def add_multisig_policy(self, policy: MultiSigOverridePolicy) -> None:
        """Add a multi-sig override policy. Thread-safe."""
        with self._pending_lock:
            self._multisig_policies.append(policy)

    def _find_applicable_policy(
        self,
        override_type: str,
        risk_tier: str,
        is_irreversible: bool,
        zone_path: str,
    ) -> MultiSigOverridePolicy | None:
        """Find the first multi-sig policy matching these override parameters."""
        for policy in self._multisig_policies:
            if override_type not in policy.applies_to_override_types:
                continue
            if risk_tier not in policy.applies_to_risk_tiers:
                continue
            # Reversibility filter: empty list = match all
            if policy.applies_to_reversibilities:
                if is_irreversible and "IRREVERSIBLE" not in policy.applies_to_reversibilities:
                    continue
                if not is_irreversible and "REVERSIBLE" not in policy.applies_to_reversibilities:
                    continue
            # Zone glob match
            if not any(fnmatch.fnmatch(zone_path, z) for z in policy.applies_to_zones):
                continue
            return policy
        return None

    def _derive_action_context(
        self, action_id: str, agent_id: str, in_mem_verdict: GovernanceVerdict | None,
    ) -> tuple[str, str, str, bool, str]:
        """Derive (action_type, zone_path, archetype, is_irreversible, risk_tier)
        from action history, persistent store, and certificates."""
        action_type = "unknown"
        zone_path = "unknown"
        archetype = "unknown"
        is_irreversible = False
        risk_tier = "moderate"

        # Try in-memory action history for action_type
        for _aid, records in self._action_history.items():
            for rec in records:
                if rec.action.id == action_id:
                    action_type = rec.action.action_type or "unknown"
                    break

        # Try persistent store for action_type if still unknown
        if action_type == "unknown" and self._persistent_audit_store is not None:
            for _aid in self._persistent_audit_store.list_agents():
                prec = self._persistent_audit_store.find_by_action_id(_aid, action_id)
                if prec is not None:
                    action_type = getattr(prec, "action_type", "unknown") or "unknown"
                    break

        # Get zone and archetype from certificate
        cert = self.get_certificate(agent_id)
        if cert is not None:
            zone_path = getattr(cert, "zone_path", "unknown") or "unknown"
            archetype = getattr(cert, "archetype", "unknown") or "unknown"

        # Check reversibility from verdict metadata
        if in_mem_verdict is not None and in_mem_verdict.reversibility:
            rev_level = in_mem_verdict.reversibility.get("level", "")
            if rev_level == "irreversible":
                is_irreversible = True

        # Derive risk tier from UCS
        if in_mem_verdict is not None:
            ucs = in_mem_verdict.ucs
            if ucs >= 0.7:
                risk_tier = "low"
            elif ucs >= 0.5:
                risk_tier = "moderate"
            elif ucs >= 0.3:
                risk_tier = "high"
            else:
                risk_tier = "critical"

        return action_type, zone_path, archetype, is_irreversible, risk_tier

    def _apply_override(
        self,
        action_id: str,
        override_type: str,
        authority: str,
        reason: str,
        agent_id: str,
        original_verdict_str: str,
        trust_penalty: float = 0.10,
        role_id: str | None = None,
    ) -> GovernanceOverrideRecord:
        """Execute the override logic (trust adjustment, seal revocation, audit write).

        This is the shared execution path used by both immediate overrides
        and multi-sig overrides once the signature threshold is met.
        """
        # Get current trust state
        profile = self.trust_calibrator.get_profile(agent_id)
        trajectory = self.trust_calibrator.get_trajectory(agent_id)
        trust_before = profile.overall_trust

        if override_type == "REVOKE":
            # Apply trust penalty
            profile.overall_trust = max(
                self.trust_calibrator.config.min_trust,
                profile.overall_trust - trust_penalty,
            )
            profile.last_updated = time.time()

            trajectory.record(
                trust_before=trust_before,
                trust_after=profile.overall_trust,
                source="override_revoke",
                reason=f"Override REVOKE by {authority}: {reason}",
                metadata={"action_id": action_id, "authority": authority},
            )

            # Attempt to invalidate seal if seal infrastructure exists
            try:
                from nomotic.seal import SealRegistry
                if hasattr(self, "_seal_registry") and self._seal_registry is not None:
                    self._seal_registry.consume(action_id)
            except (ImportError, AttributeError):
                pass
        else:
            # APPROVE — no trust change, but record trajectory for completeness
            trajectory.record(
                trust_before=trust_before,
                trust_after=trust_before,
                source="override_approve",
                reason=f"Override APPROVE by {authority}: {reason}",
                metadata={"action_id": action_id, "authority": authority},
            )

        trust_after = profile.overall_trust

        # Build the override record
        override_id = f"nmo-{uuid.uuid4()}"
        record = GovernanceOverrideRecord(
            override_id=override_id,
            action_id=action_id,
            override_type=override_type,
            original_verdict=original_verdict_str,
            authority=authority,
            reason=reason,
            agent_id=agent_id,
            trust_before=trust_before,
            trust_after=trust_after,
            role_id=role_id,
        )

        # Write to persistent audit store if available
        if self._persistent_audit_store is not None:
            from nomotic.audit_store import PersistentLogRecord

            store = self._persistent_audit_store
            previous_hash = store.get_last_hash(agent_id)

            log_record_data = {
                "record_id": override_id,
                "timestamp": time.time(),
                "agent_id": agent_id,
                "action_type": "override",
                "action_target": action_id,
                "verdict": f"OVERRIDE_{override_type}",
                "ucs": 0.0,
                "tier": 0,
                "trust_score": trust_after,
                "trust_delta": trust_after - trust_before,
                "trust_trend": trajectory.trend,
                "severity": "alert",
                "justification": reason,
                "vetoed_by": [],
                "dimension_scores": {},
                "parameters": {
                    "authority": authority,
                    "override_id": override_id,
                    "original_verdict": original_verdict_str,
                },
                "source": "override",
                "previous_hash": previous_hash,
                "record_hash": "",
            }
            log_record_data["record_hash"] = store.compute_hash(
                log_record_data, previous_hash
            )
            log_record = PersistentLogRecord(**log_record_data)
            store.append(log_record)

        # Webhook: OVERRIDE_APPROVE or OVERRIDE_REVOKE
        webhook_event_type = f"OVERRIDE_{override_type}"
        self._dispatch_webhook(webhook_event_type, agent_id, {
            "override_id": override_id,
            "action_id": action_id,
            "override_type": override_type,
            "original_verdict": original_verdict_str,
            "authority": authority,
            "reason": reason,
            "trust_before": trust_before,
            "trust_after": trust_after,
        })

        return record

    def _write_multisig_audit(
        self,
        event_type: str,
        pending: PendingOverride,
        *,
        signing_authority: str = "",
        signature_id: str = "",
        execution_time: float | None = None,
    ) -> None:
        """Write a multi-sig audit record to the persistent audit store."""
        if self._persistent_audit_store is None:
            return

        from nomotic.audit_store import PersistentLogRecord

        store = self._persistent_audit_store
        previous_hash = store.get_last_hash(pending.agent_id)

        params: dict[str, Any] = {
            "override_id": pending.override_id,
            "policy_id": pending.policy_id,
            "signatures_count": pending.signature_count,
            "required_signatures": pending.required_signatures,
            "status": pending.status,
        }
        if event_type == AUDIT_OVERRIDE_COSIGNED:
            params["signing_authority"] = signing_authority
            params["signature_id"] = signature_id
        elif event_type == AUDIT_OVERRIDE_COMPLETE:
            params["authorities"] = pending.authorities_signed
            params["execution_time"] = execution_time
        elif event_type == AUDIT_OVERRIDE_EXPIRED:
            params["signatures_at_expiry"] = pending.signature_count
        elif event_type == AUDIT_OVERRIDE_DENIED:
            params["denied_by"] = signing_authority

        log_record_data = {
            "record_id": f"nmms-{uuid.uuid4().hex[:12]}",
            "timestamp": time.time(),
            "agent_id": pending.agent_id,
            "action_type": "multisig_override",
            "action_target": pending.action_id,
            "verdict": event_type,
            "ucs": 0.0,
            "tier": 0,
            "trust_score": 0.0,
            "trust_delta": 0.0,
            "trust_trend": "stable",
            "severity": "alert",
            "justification": f"{event_type}: {pending.override_id}",
            "vetoed_by": [],
            "dimension_scores": {},
            "parameters": params,
            "source": "multisig_override",
            "previous_hash": previous_hash,
            "record_hash": "",
        }
        log_record_data["record_hash"] = store.compute_hash(
            log_record_data, previous_hash
        )
        log_record = PersistentLogRecord(**log_record_data)
        store.append(log_record)

    def _execute_pending_override(self, pending: PendingOverride) -> None:
        """Execute a pending override once the signature threshold is met."""
        pending.status = "COMPLETE"
        pending.completed_at = time.time()

        # Run the actual override logic
        self._apply_override(
            action_id=pending.action_id,
            override_type=pending.override_type,
            authority=pending.initial_authority,
            reason=pending.initial_reason,
            agent_id=pending.agent_id,
            original_verdict_str=pending.original_verdict,
        )

        # Write OVERRIDE_COMPLETE audit record
        self._write_multisig_audit(
            AUDIT_OVERRIDE_COMPLETE,
            pending,
            execution_time=pending.completed_at,
        )

    def _expire_pending_override(self, pending: PendingOverride) -> None:
        """Expire a pending override that has passed its authorization window."""
        pending.status = "EXPIRED"

        # Write OVERRIDE_EXPIRED audit record
        self._write_multisig_audit(AUDIT_OVERRIDE_EXPIRED, pending)

        # Remove from pending overrides
        self._pending_overrides.pop(pending.override_id, None)

        # Dispatch OVERRIDE_EXPIRED webhook
        policy_name = ""
        signatures_required = pending.required_signatures
        for p in self._multisig_policies:
            if p.policy_id == pending.policy_id:
                policy_name = p.name
                signatures_required = p.required_signatures
                break
        self._dispatch_webhook("OVERRIDE_EXPIRED", pending.agent_id, {
            "pending_id": pending.override_id,
            "action_id": pending.action_id,
            "agent_id": pending.agent_id,
            "policy_name": policy_name,
            "signatures_collected": pending.signature_count,
            "signatures_required": signatures_required,
            "expired_at": time.time(),
        })

        # Remove from warned set — it's done
        self._expiry_warned.discard(pending.override_id)

    def _check_expiry_warnings(self) -> None:
        """Dispatch OVERRIDE_EXPIRING for overrides approaching expiry.

        Called from get_pending_overrides() and cosign_override().
        Each override receives at most one OVERRIDE_EXPIRING webhook.
        """
        if self.config.override_expiry_warning_seconds <= 0:
            return

        now = time.time()
        for pending_id, override in self._pending_overrides.items():
            if override.status != "PENDING":
                continue
            if pending_id in self._expiry_warned:
                continue
            time_remaining = override.expires_at - now
            if 0 < time_remaining <= self.config.override_expiry_warning_seconds:
                self._expiry_warned.add(pending_id)
                policy_name = ""
                signatures_required = override.required_signatures
                for p in self._multisig_policies:
                    if p.policy_id == override.policy_id:
                        policy_name = p.name
                        signatures_required = p.required_signatures
                        break
                self._dispatch_webhook("OVERRIDE_EXPIRING", override.agent_id, {
                    "pending_id": pending_id,
                    "action_id": override.action_id,
                    "agent_id": override.agent_id,
                    "policy_name": policy_name,
                    "seconds_remaining": int(time_remaining),
                    "signatures_collected": override.signature_count,
                    "signatures_required": signatures_required,
                })

    def override(
        self,
        action_id: str,
        override_type: str,
        authority: str,
        reason: str,
        *,
        trust_penalty: float = 0.10,
        role_check: bool = True,
    ) -> GovernanceOverrideRecord | PendingOverride:
        """Override a governance decision after the fact.

        APPROVE: Override a DENY. Records that a human reviewed and approved
        the denied action. Does NOT automatically execute the action — the
        developer must re-submit. Trust is NOT changed (governance correctly
        identified risk; the human accepted it).

        REVOKE: Override an ALLOW. Records that a previously approved action
        should not have been allowed. Applies trust_penalty to the agent
        (governance should have caught this). If a governance seal exists for
        this action and hasn't been consumed, invalidates it.

        When a MultiSigOverridePolicy applies, returns a PendingOverride
        instead of immediately executing. Use cosign_override() to add
        additional signatures until the threshold is met.

        Args:
            action_id: The action_id from the original governance verdict
            override_type: "APPROVE" or "REVOKE"
            authority: Identity of the human issuing the override
            reason: Justification for the override
            trust_penalty: Trust decrease for REVOKE (default 0.10)
            role_check: Whether to enforce role-based permission checks
                (default True). Set to False to skip.

        Returns:
            GovernanceOverrideRecord if immediate, PendingOverride if multi-sig

        Raises:
            ValueError: If override_type is invalid or action_id not found
            PermissionDeniedError: If role check fails
        """
        if override_type not in ("APPROVE", "REVOKE"):
            raise ValueError(
                f"override_type must be 'APPROVE' or 'REVOKE', got '{override_type}'"
            )

        # Look up the original action — in-memory first, then persistent store
        agent_id: str | None = None
        original_verdict_str: str | None = None

        # Check in-memory verdicts
        in_mem_verdict = self._verdicts.get(action_id)
        if in_mem_verdict is not None:
            original_verdict_str = in_mem_verdict.verdict.name
            # Find agent_id from action history
            for aid, records in self._action_history.items():
                for rec in records:
                    if rec.action.id == action_id:
                        agent_id = aid
                        break
                if agent_id:
                    break
            # Fallback: check verdicts action_id matches
            if agent_id is None:
                # Try trust profiles — the verdict was recorded for some agent
                for aid in self.trust_calibrator._profiles:
                    agent_id = aid
                    break

        # Check persistent audit store if not found in memory
        if original_verdict_str is None and self._persistent_audit_store is not None:
            store = self._persistent_audit_store
            for aid in store.list_agents():
                record = store.find_by_action_id(aid, action_id)
                if record is not None:
                    agent_id = record.agent_id
                    original_verdict_str = record.verdict
                    break

        if original_verdict_str is None or agent_id is None:
            raise ValueError(f"Action '{action_id}' not found in audit trail")

        # Validate override type matches original verdict
        if override_type == "APPROVE" and original_verdict_str != "DENY":
            raise ValueError(
                f"APPROVE override only valid for DENY verdicts, "
                f"but action '{action_id}' had verdict '{original_verdict_str}'"
            )
        if override_type == "REVOKE" and original_verdict_str != "ALLOW":
            raise ValueError(
                f"REVOKE override only valid for ALLOW verdicts, "
                f"but action '{action_id}' had verdict '{original_verdict_str}'"
            )

        # ── Role-based permission check ────────────────────────────────
        permission_role_id: str | None = None

        if role_check and self._role_registry is not None and self._role_registry.has_roles():
            from nomotic.roles import PermissionDeniedError

            action_type, zone_path, archetype, is_irreversible, risk_tier = (
                self._derive_action_context(action_id, agent_id, in_mem_verdict)
            )

            result = self._role_registry.check_permission(
                authority=authority,
                override_type=override_type,
                action_type=action_type,
                zone_path=zone_path,
                archetype=archetype,
                is_irreversible=is_irreversible,
                risk_tier=risk_tier,
            )

            if not result.permitted:
                raise PermissionDeniedError(result)
            permission_role_id = result.role_id

        elif role_check:
            # No registry or no roles — warn but proceed
            import warnings
            from nomotic.types import GovernanceWarning
            warnings.warn(
                "No role registry configured — override permissions are not enforced",
                GovernanceWarning,
                stacklevel=2,
            )

        # ── Multi-sig policy check ────────────────────────────────────
        action_type, zone_path, archetype, is_irreversible, risk_tier = (
            self._derive_action_context(action_id, agent_id, in_mem_verdict)
        )

        policy = self._find_applicable_policy(
            override_type, risk_tier, is_irreversible, zone_path,
        )

        if policy is not None:
            # Multi-sig path: create PendingOverride
            now = time.time()
            pending = PendingOverride(
                override_id=f"nmpo-{uuid.uuid4()}",
                action_id=action_id,
                agent_id=agent_id,
                override_type=override_type,
                policy_id=policy.policy_id,
                required_signatures=policy.required_signatures,
                status="PENDING",
                created_at=now,
                expires_at=now + policy.authorization_window_seconds,
                original_verdict=original_verdict_str,
                initial_authority=authority,
                initial_reason=reason,
            )

            # Create first signature
            sig_time = now
            sig = OverrideSignature(
                signature_id=f"nmosig-{uuid.uuid4()}",
                authority=authority,
                role_id=permission_role_id,
                reason=reason,
                signed_at=sig_time,
                signature_hash=OverrideSignature.compute_hash(
                    pending.override_id, authority, reason, sig_time,
                ),
            )
            pending.signatures.append(sig)

            with self._pending_lock:
                self._pending_overrides[pending.override_id] = pending

            # Write OVERRIDE_PENDING_CREATED audit record
            self._write_multisig_audit(AUDIT_OVERRIDE_PENDING_CREATED, pending)

            # Edge case: M=1 — immediately execute
            if pending.signature_count >= policy.required_signatures:
                self._execute_pending_override(pending)

            # Fire Slack notification if configured (F-05 Part C)
            if self._slack_notifier is not None and pending.status == "PENDING":
                self._slack_notifier.notify_escalation(pending)

            # Fire outbound approval webhook if configured (F-05 Part D)
            if self.config.approval_webhook_url and pending.status == "PENDING":
                from nomotic.webhook_callback import fire_approval_webhook
                from nomotic.api import _get_webhook_secret
                fire_approval_webhook(
                    runtime=self,
                    pending=pending,
                    approval_webhook_url=self.config.approval_webhook_url,
                    server_host=self.config.server_host,
                    webhook_secret=_get_webhook_secret(self),
                )

            return pending

        # ── Immediate override (no multi-sig policy) ──────────────────
        return self._apply_override(
            action_id=action_id,
            override_type=override_type,
            authority=authority,
            reason=reason,
            agent_id=agent_id,
            original_verdict_str=original_verdict_str,
            trust_penalty=trust_penalty,
            role_id=permission_role_id,
        )

    def cosign_override(
        self,
        pending_override_id: str,
        authority: str,
        reason: str,
        role_check: bool = True,
    ) -> PendingOverride:
        """Add a co-signature to a pending multi-sig override.

        Args:
            pending_override_id: The override_id of the PendingOverride
            authority: Identity of the co-signer
            reason: Justification for the co-signature
            role_check: Whether to enforce role-based permission checks

        Returns:
            The updated PendingOverride

        Raises:
            ValueError: If override not found, not PENDING, expired,
                duplicate authority, or max same-role signatures exceeded
            PermissionDeniedError: If role check fails
        """
        with self._pending_lock:
            pending = self._pending_overrides.get(pending_override_id)

        if pending is None:
            raise ValueError(f"Pending override not found: {pending_override_id}")

        if pending.status != "PENDING":
            raise ValueError(
                f"Override {pending_override_id} is not in PENDING state "
                f"(status: {pending.status})"
            )

        if pending.is_expired:
            self._expire_pending_override(pending)
            raise ValueError(f"Pending override {pending_override_id} has expired")

        if authority in pending.authorities_signed:
            raise ValueError(
                f"Authority '{authority}' has already signed override {pending_override_id}"
            )

        # ── Role-based permission check for cosigner ──────────────────
        permission_role_id: str | None = None

        if role_check and self._role_registry is not None and self._role_registry.has_roles():
            from nomotic.roles import PermissionDeniedError

            in_mem_verdict = self._verdicts.get(pending.action_id)
            action_type, zone_path, archetype, is_irreversible, risk_tier = (
                self._derive_action_context(
                    pending.action_id, pending.agent_id, in_mem_verdict,
                )
            )

            result = self._role_registry.check_permission(
                authority=authority,
                override_type=pending.override_type,
                action_type=action_type,
                zone_path=zone_path,
                archetype=archetype,
                is_irreversible=is_irreversible,
                risk_tier=risk_tier,
            )

            if not result.permitted:
                raise PermissionDeniedError(result)
            permission_role_id = result.role_id

        # ── max_same_role_signatures check ────────────────────────────
        policy: MultiSigOverridePolicy | None = None
        for p in self._multisig_policies:
            if p.policy_id == pending.policy_id:
                policy = p
                break

        if policy is not None and permission_role_id is not None:
            same_role_count = sum(
                1 for s in pending.signatures if s.role_id == permission_role_id
            )
            if same_role_count >= policy.max_same_role_signatures:
                raise ValueError(
                    f"Maximum signatures from role '{permission_role_id}' "
                    f"already reached for override {pending_override_id}"
                )

        # ── Create and append signature ───────────────────────────────
        sig_time = time.time()
        sig = OverrideSignature(
            signature_id=f"nmosig-{uuid.uuid4()}",
            authority=authority,
            role_id=permission_role_id,
            reason=reason,
            signed_at=sig_time,
            signature_hash=OverrideSignature.compute_hash(
                pending.override_id, authority, reason, sig_time,
            ),
        )
        pending.signatures.append(sig)

        # Write OVERRIDE_COSIGNED audit record
        self._write_multisig_audit(
            AUDIT_OVERRIDE_COSIGNED,
            pending,
            signing_authority=authority,
            signature_id=sig.signature_id,
        )

        # Check if threshold met
        if pending.signature_count >= pending.required_signatures:
            self._execute_pending_override(pending)

        self._check_expiry_warnings()

        return pending

    def get_pending_overrides(self) -> list[PendingOverride]:
        """Return all PENDING overrides, expiring any that have timed out."""
        with self._pending_lock:
            expired = [p for p in self._pending_overrides.values() if p.is_expired]
            for p in expired:
                self._expire_pending_override(p)
            self._check_expiry_warnings()
            return [
                p for p in self._pending_overrides.values()
                if p.status == "PENDING"
            ]

    def get_pending_override(self, override_id: str) -> PendingOverride | None:
        """Get a single pending override by ID."""
        with self._pending_lock:
            return self._pending_overrides.get(override_id)

    def _deny_pending_override(
        self, pending_id: str, authority: str, reason: str
    ) -> None:
        """Deny a pending override, removing it from the pending queue.

        Args:
            pending_id: The override_id of the PendingOverride
            authority: Identity of the person denying
            reason: Justification for the denial

        Raises:
            ValueError: If pending override not found
        """
        with self._pending_lock:
            pending = self._pending_overrides.get(pending_id)
            if pending is None:
                raise ValueError(f"Pending override not found: {pending_id}")

            pending.status = "DENIED"

            # Write audit record
            self._write_multisig_audit(
                event_type=AUDIT_OVERRIDE_DENIED,
                pending=pending,
                signing_authority=authority,
            )

            # Remove from pending
            del self._pending_overrides[pending_id]

        # Remove from warned set
        self._expiry_warned.discard(pending_id)

    def birth(
        self,
        agent_id: str,
        archetype: str,
        organization: str,
        zone_path: str,
        *,
        owner: str = "",
        **opts: Any,
    ) -> AgentCertificate:
        """Issue a birth certificate for an agent through the runtime.

        Delegates to CertificateAuthority.issue() and maps the agent_id
        to the new certificate.
        """
        ca = self._ensure_ca()
        cert, _agent_sk = ca.issue(
            agent_id=agent_id,
            archetype=archetype,
            organization=organization,
            zone_path=zone_path,
            owner=owner,
            **opts,
        )
        self._cert_map[agent_id] = cert.certificate_id
        # Sync trust: seed the trust calibrator with baseline
        profile = self.trust_calibrator.get_profile(agent_id)
        profile.overall_trust = cert.trust_score

        # Lifecycle: BIRTH event
        if self.config.enable_lifecycle_hooks:
            from nomotic.lifecycle import LifecycleContext, LifecycleEvent
            ctx = LifecycleContext(
                event=LifecycleEvent.BIRTH,
                agent_id=agent_id,
                agent_name=cert.agent_id,
                archetype=archetype,
                trust_score=cert.trust_score,
                timestamp=time.time(),
                certificate_id=cert.certificate_id,
                trigger_reason="Certificate issued",
            )
            self._lifecycle_manager.trigger(LifecycleEvent.BIRTH, ctx)
            self._lifecycle_state[agent_id] = "active"

        return cert

    def revoke(self, agent_id: str, reason: str = "") -> AgentCertificate | None:
        """Revoke an agent's certificate and trigger REVOCATION lifecycle event.

        Returns the revoked certificate, or None if the agent has no certificate.
        """
        ca = self._ensure_ca()
        cert_id = self._cert_map.get(agent_id)
        if cert_id is None:
            return None
        cert = ca.revoke(cert_id, reason)

        # Lifecycle: REVOCATION event
        if self.config.enable_lifecycle_hooks:
            from nomotic.lifecycle import LifecycleContext, LifecycleEvent

            trust = self.trust_calibrator.get_profile(agent_id).overall_trust
            ctx = LifecycleContext(
                event=LifecycleEvent.REVOCATION,
                agent_id=agent_id,
                agent_name=cert.agent_id,
                archetype=cert.archetype,
                trust_score=trust,
                timestamp=time.time(),
                certificate_id=cert.certificate_id,
                trigger_reason=reason or "Certificate revoked",
            )
            self._lifecycle_manager.trigger(LifecycleEvent.REVOCATION, ctx)
            self._lifecycle_state[agent_id] = "revoked"

        return cert

    def get_certificate(self, agent_id: str) -> AgentCertificate | None:
        """Get the current certificate for an agent."""
        ca = self._ensure_ca()
        cert_id = self._cert_map.get(agent_id)
        if cert_id is None:
            return None
        return ca.get(cert_id)

    def seal(
        self,
        verdict: GovernanceVerdict,
        context: AgentContext | None = None,
        certificate: AgentCertificate | None = None,
        ttl_seconds: int = 30,
        preset: str = "default",
        risk_tier: str = "moderate",
        org_policy_hash: str = "",
        *,
        workflow_chain: Any = None,
    ) -> "GovernanceSeal | None":
        """Produce a signed governance seal for an ALLOW verdict.

        Returns None if verdict is not ALLOW.

        When *workflow_chain* is provided (a :class:`WorkflowSealChain`),
        the seal is appended to the chain with cryptographic position binding.
        """
        from nomotic.seal import GovernanceSeal, seal_action

        ca = self._ensure_ca()

        # Build a minimal context if none provided (for workflow-chain convenience)
        if context is None:
            agent_id = verdict.action_id.split("-")[0] if "-" in verdict.action_id else "unknown"
            # Try to infer agent_id from the verdict's dimension scores or action
            context = AgentContext(
                agent_id=agent_id,
                trust_profile=TrustProfile(agent_id=agent_id),
            )

        # If no certificate provided, try to look up from cert map
        if certificate is None:
            certificate = self.get_certificate(context.agent_id)

        # Determine effective TTL based on reversibility
        rev_config = self._get_reversibility_config()
        effective_ttl = ttl_seconds  # caller's default

        if verdict.reversibility:
            rev_level = verdict.reversibility.get("level", "unknown")
            if rev_level == "irreversible":
                effective_ttl = min(effective_ttl, rev_config.irreversible_seal_ttl)
            elif rev_level == "difficult_to_reverse":
                effective_ttl = min(effective_ttl, rev_config.difficult_to_reverse_seal_ttl)
            elif rev_level == "time_bounded" and rev_config.time_bounded_seal_ttl_cap:
                window = verdict.reversibility.get("window_seconds")
                if window and window > 0:
                    effective_ttl = min(effective_ttl, window)

        seal = seal_action(
            verdict=verdict,
            context=context,
            signing_key=ca._signing_key,
            certificate=certificate,
            ttl_seconds=effective_ttl,
            preset=preset,
            risk_tier=risk_tier,
            org_policy_hash=org_policy_hash,
        )

        if seal is not None and workflow_chain is not None:
            self._append_to_workflow_chain(workflow_chain, seal, verdict.action_id)

        return seal

    # ── Workflow Seal Chaining ──────────────────────────────────────

    def begin_workflow_sealing(self, workflow_id: str, agent_id: str = "") -> Any:
        """Begin tracking a workflow seal chain.

        Returns a WorkflowSealChain that can be passed to seal() for each step.
        The chain accumulates ChainedSeal entries as steps complete.

        Raises WorkflowDependencyError if any registered dependency rules
        for this workflow_id are not satisfied.
        """
        # Dependency check — BEFORE creating the chain
        if self._workflow_dependency_checker is not None:
            failures = [
                r for r in self._workflow_dependency_checker.check(
                    workflow_id, self._workflow_chains
                )
                if not r.satisfied
            ]
            if failures:
                from nomotic.seal import WorkflowDependencyError
                raise WorkflowDependencyError(workflow_id, failures)

        from nomotic.seal import WorkflowSealChain

        chain = WorkflowSealChain(
            chain_id=f"nmwc-{uuid.uuid4()}",
            workflow_id=workflow_id,
            agent_id=agent_id,
        )
        self._workflow_chains[chain.chain_id] = chain
        return chain

    def _append_to_workflow_chain(
        self,
        chain: Any,
        seal: Any,
        action_id: str,
    ) -> None:
        """Append a seal to a workflow chain with cryptographic position binding."""
        from nomotic.seal import ChainedSeal
        import hashlib

        step_number = len(chain.seals) + 1

        # Compute previous_seal_hash
        if chain.seals:
            # Use the previous seal's position_hash
            prev = chain.seals[-1]
            previous_seal_hash = prev.position_hash
        else:
            # Genesis: hash the chain_id
            previous_seal_hash = hashlib.sha256(
                chain.chain_id.encode("utf-8")
            ).hexdigest()

        # Compute position_hash: SHA-256(previous_seal_hash + ":" + seal_id)
        position_hash = hashlib.sha256(
            f"{previous_seal_hash}:{seal.seal_id}".encode("utf-8")
        ).hexdigest()

        chained = ChainedSeal(
            seal_id=seal.seal_id,
            step_number=step_number,
            action_id=action_id or "",
            previous_seal_hash=previous_seal_hash,
            position_hash=position_hash,
        )
        chain.seals.append(chained)

    def complete_workflow_sealing(self, chain_id: str) -> Any:
        """Finalize a workflow seal chain."""
        chain = self._workflow_chains.get(chain_id)
        if chain is None:
            raise ValueError(f"Workflow chain not found: {chain_id}")
        chain.status = "COMPLETE"
        chain.completed_at = time.time()
        chain.chain_hash = chain._compute_chain_hash()
        return chain

    def get_workflow_chain(self, chain_id: str) -> Any:
        """Retrieve a workflow seal chain by ID, or None if not found."""
        return self._workflow_chains.get(chain_id)

    # ── Cross-Workflow Dependency Checking ─────────────────────────

    def set_workflow_dependency_checker(
        self, checker: Any,
    ) -> None:
        """Register a dependency checker for workflow governance."""
        self._workflow_dependency_checker = checker

    def add_workflow_dependency(self, dep: Any) -> None:
        """Add a workflow dependency rule.

        Auto-creates a WorkflowDependencyChecker if not already set.
        """
        if self._workflow_dependency_checker is None:
            from nomotic.seal import WorkflowDependencyChecker
            self._workflow_dependency_checker = WorkflowDependencyChecker()
        self._workflow_dependency_checker.add_dependency(dep)

    def evaluate_with_cert(
        self,
        action: Action,
        context: AgentContext,
        certificate_id: str | None = None,
    ) -> GovernanceVerdict:
        """Evaluate an action, integrating with the certificate system.

        If a certificate_id is provided (or the agent has one mapped),
        the certificate's trust score is used, its status is checked,
        and its behavioral_age and trust_score are updated afterward.
        """
        ca = self._ensure_ca()

        # Resolve certificate
        cid = certificate_id or self._cert_map.get(context.agent_id)
        cert: AgentCertificate | None = None
        if cid:
            cert = ca.get(cid)

        if cert is not None:
            # Verify certificate is ACTIVE
            if cert.status != CertStatus.ACTIVE:
                return GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.DENY,
                    ucs=0.0,
                    reasoning=f"certificate status is {cert.status.name}",
                    tier=1,
                )

            # Use certificate's trust as the authoritative source
            context.trust_profile.overall_trust = cert.trust_score

        # Run the normal evaluation pipeline
        verdict = self.evaluate(action, context)

        # Update certificate post-evaluation (single store write)
        if cert is not None:
            new_trust = self.trust_calibrator.get_profile(context.agent_id).overall_trust
            ca.record_action(cert.certificate_id, new_trust)

        return verdict

    def get_fingerprint(self, agent_id: str) -> Any:
        """Get the behavioral fingerprint for an agent.

        Returns None if fingerprints are disabled or if no fingerprint
        exists for the agent.
        """
        if self._fingerprint_observer is None:
            return None
        return self._fingerprint_observer.get_fingerprint(agent_id)

    def get_drift(self, agent_id: str) -> Any:
        """Get the latest behavioral drift score for an agent.

        Returns None if fingerprints/drift are disabled or if drift
        has never been computed for this agent.
        """
        if self._fingerprint_observer is None:
            return None
        return self._fingerprint_observer.get_drift(agent_id)

    def get_drift_alerts(
        self, agent_id: str | None = None, **kwargs: bool,
    ) -> list[Any]:
        """Get drift alerts, optionally filtered by agent."""
        if self._fingerprint_observer is None:
            return []
        return self._fingerprint_observer.get_alerts(agent_id, **kwargs)

    def get_trust_trajectory(self, agent_id: str) -> Any:
        """Get the trust trajectory for an agent."""
        return self.trust_calibrator.get_trajectory(agent_id)

    def get_trust_report(self, agent_id: str) -> dict[str, Any]:
        """Get a comprehensive trust report for an agent.

        Combines current trust, trajectory summary, fingerprint status,
        and drift status into a single report.
        """
        profile = self.get_trust_profile(agent_id)
        trajectory = self.trust_calibrator.get_trajectory(agent_id)

        report: dict[str, Any] = {
            "agent_id": agent_id,
            "current_trust": profile.overall_trust,
            "successful_actions": profile.successful_actions,
            "violation_count": profile.violation_count,
            "violation_rate": profile.violation_rate,
            "trajectory": trajectory.summary(),
        }

        if self._fingerprint_observer is not None:
            fp = self._fingerprint_observer.get_fingerprint(agent_id)
            if fp is not None:
                report["fingerprint"] = {
                    "total_observations": fp.total_observations,
                    "confidence": fp.confidence,
                }

            drift = self._fingerprint_observer.get_drift(agent_id)
            if drift is not None:
                report["drift"] = drift.to_dict()

            alerts = self._fingerprint_observer.get_alerts(agent_id)
            if alerts:
                report["active_alerts"] = len(
                    [a for a in alerts if not a.acknowledged]
                )

        return report

    def _get_reversibility_config(self) -> "ReversibilityConfig":
        """Get reversibility config, using defaults if not configured."""
        from nomotic.reversibility import ReversibilityConfig

        if self.config.reversibility_config is not None:
            return self.config.reversibility_config
        return ReversibilityConfig()

    def _compute_reversibility_ucs_increase(
        self,
        assessment: Any,
        config: Any,
    ) -> float:
        """Compute UCS threshold increase based on reversibility level."""
        level = assessment.level.value

        # Handle unknown by mapping to configured level
        if level == "unknown":
            level = config.unknown_treated_as

        increases = {
            "irreversible": config.irreversible_ucs_increase,
            "difficult_to_reverse": config.difficult_to_reverse_ucs_increase,
            "partially_reversible": config.partially_reversible_ucs_increase,
            "time_bounded": config.time_bounded_ucs_increase,
            "fully_reversible": 0.0,
        }
        return increases.get(level, config.irreversible_ucs_increase)

    def _record_verdict(
        self, action: Action, context: AgentContext, verdict: GovernanceVerdict
    ) -> None:
        """Record a verdict and update trust."""
        self._verdicts[action.id] = verdict
        self.trust_calibrator.record_verdict(context.agent_id, verdict)

        # Update behavioral fingerprint
        if self._fingerprint_observer is not None:
            archetype = None
            cert = self.get_certificate(action.agent_id)
            if cert:
                archetype = cert.archetype
            self._fingerprint_observer.observe(
                agent_id=context.agent_id,
                action=action,
                verdict=verdict.verdict,
                archetype=archetype,
            )

            # Drift-based trust adjustment (Phase 4C)
            drift = self._fingerprint_observer.get_drift(context.agent_id)
            if drift is not None:
                self.trust_calibrator.apply_drift(context.agent_id, drift)

                # Sync trust back to certificate
                if cert is not None:
                    new_trust = self.trust_calibrator.get_profile(
                        context.agent_id
                    ).overall_trust
                    ca = self._ensure_ca()
                    ca.update_trust(cert.certificate_id, new_trust)

        # Audit trail (Phase 5)
        if self._audit_trail is not None:
            self._record_audit(action, context, verdict)

        # Webhook: DENY events
        if verdict.verdict == Verdict.DENY:
            self._dispatch_webhook("DENY", action.agent_id or context.agent_id, {
                "action_id": verdict.action_id,
                "action_type": action.action_type,
                "target": action.target,
                "ucs": verdict.ucs,
                "reasoning": verdict.reasoning,
            })

        # Webhook: DRIFT_ALERT when drift severity is moderate or above
        if self._fingerprint_observer is not None:
            drift = self._fingerprint_observer.get_drift(context.agent_id)
            if drift is not None and drift.severity in (
                "moderate", "high", "critical"
            ):
                self._dispatch_webhook("DRIFT_ALERT", context.agent_id, {
                    "drift_overall": drift.overall,
                    "drift_severity": drift.severity,
                    "action_drift": drift.action_drift,
                    "target_drift": drift.target_drift,
                    "temporal_drift": drift.temporal_drift,
                    "outcome_drift": drift.outcome_drift,
                })

        # Webhook: TRUST_DROP when trust falls below 0.3
        profile = self.trust_calibrator.get_profile(context.agent_id)
        if profile.overall_trust < 0.3:
            self._dispatch_webhook("TRUST_DROP", context.agent_id, {
                "trust_score": profile.overall_trust,
                "threshold": 0.3,
            })

        # Update context history for future evaluations
        if verdict.verdict == Verdict.DENY:
            record = ActionRecord(
                action=action,
                verdict=verdict,
                state=ActionState.DENIED,
            )
            self._append_history(context.agent_id, record)
            context.action_history.append(record)

        for listener in self._listeners:
            listener(verdict)

        # UAHS post-evaluation pipeline (opt-in)
        if self._enable_uahs:
            self._post_evaluate_uahs(context.agent_id, verdict)

        # Lifecycle event detection (v0.6.0 Item 11)
        if self.config.enable_lifecycle_hooks:
            self._check_lifecycle_transitions(action.agent_id or context.agent_id, context)

    # ── Agent Lifecycle Hooks (v0.6.0 Item 11) ────────────────────

    def _check_lifecycle_transitions(
        self,
        agent_id: str,
        context: AgentContext,
    ) -> None:
        """Detect and fire lifecycle events based on current agent state."""
        from nomotic.lifecycle import LifecycleContext, LifecycleEvent

        trust = context.trust_profile.overall_trust
        uahs = None
        if self._ucs_tracker is not None:
            try:
                score = self.get_uahs(agent_id)
                if score is not None:
                    uahs = score.overall_health if hasattr(score, "overall_health") else None
            except Exception:
                pass  # UAHS failures must never affect lifecycle checks

        prev_state = self._lifecycle_state.get(agent_id, "active")

        # Determine current state
        if trust < self.config.lifecycle_retirement_trust_floor:
            new_state = "retirement"
        elif uahs is not None and uahs < self.config.lifecycle_critical_threshold:
            new_state = "critical"
        elif uahs is not None and uahs < self.config.lifecycle_degraded_threshold:
            new_state = "degraded"
        else:
            new_state = "active"

        if new_state == prev_state:
            return  # No transition

        self._lifecycle_state[agent_id] = new_state

        event_map = {
            "retirement": LifecycleEvent.RETIREMENT,
            "critical": LifecycleEvent.CRITICAL,
            "degraded": LifecycleEvent.DEGRADED,
        }
        event = event_map.get(new_state)
        if event is None:
            return

        cert = self.get_certificate(agent_id)
        cert_id = cert.certificate_id if cert else None
        archetype = cert.archetype if cert else self._get_agent_archetype_safe(agent_id)
        agent_name = cert.agent_id if cert else agent_id

        ctx = LifecycleContext(
            event=event,
            agent_id=agent_id,
            agent_name=agent_name,
            archetype=archetype,
            trust_score=trust,
            timestamp=time.time(),
            certificate_id=cert_id,
            uahs_score=uahs,
            trigger_reason=f"State transition: {prev_state} -> {new_state}",
        )
        self._lifecycle_manager.trigger(event, ctx)

    @property
    def lifecycle_manager(self) -> Any:
        """Access the lifecycle hook manager."""
        return self._lifecycle_manager

    def register_lifecycle_hook(
        self,
        event: Any,
        hook: Callable,
        name: str = "",
    ) -> str:
        """Register a lifecycle hook. Returns hook_id."""
        return self._lifecycle_manager.register(event, hook, name)

    # ── Governance Authority Registry (Item 15) ────────────────────

    def _check_governance_authority(
        self,
        authority_id: str,
        required_role: Any,  # GovernanceRole
        change_type: str,
        target: str = "",
        reason: str = "",
    ) -> None:
        """Check authority if registry is configured.  No-op if no registry."""
        if self._authority_registry is None:
            return
        from nomotic.authority_registry import GovernanceRole

        self._authority_registry.check_permission(
            authority_id=authority_id,
            required_role=required_role,
            change_type=change_type,
            target=target,
            reason=reason,
        )

    # ── Constitutional Rules Engine ─────────────────────────────────

    def set_constitutional_engine(
        self,
        engine: Any,
        *,
        authority_id: str = "__bootstrap__",
        reason: str = "",
    ) -> None:
        """Replace the constitutional engine (requires restart in production)."""
        from nomotic.authority_registry import GovernanceRole

        self._check_governance_authority(
            authority_id=authority_id,
            required_role=GovernanceRole.CONSTITUTIONAL_GUARDIAN,
            change_type="constitutional_load",
            target="constitutional_engine",
            reason=reason,
        )
        self._constitutional_engine = engine

    def _write_constitutional_violation_audit(
        self,
        action: Action,
        context: AgentContext,
        violations: list[Any],
    ) -> None:
        """Write an audit record for a constitutional violation."""
        if self._audit_trail is None:
            return

        from nomotic.audit import AuditRecord

        violation = violations[0]
        record = AuditRecord(
            record_id=uuid.uuid4().hex[:12],
            timestamp=time.time(),
            context_code="GOVERNANCE.CONSTITUTIONAL_VIOLATION",
            severity="critical",
            agent_id=context.agent_id,
            owner_id="",
            user_id=(
                context.user_context.user_id
                if context.user_context is not None
                else ""
            ),
            action_id=action.id,
            action_type=action.action_type,
            action_target=action.target,
            verdict="DENY",
            ucs=0.0,
            tier=0,
            dimension_scores=[],
            trust_score=context.trust_profile.overall_trust,
            trust_trend="stable",
            justification=(
                f"Constitutional violation: {violation.rule_name} — "
                f"{violation.reason}"
            ),
            metadata={
                "constitutional_rule_id": violation.rule_id,
                "constitutional_rule_type": violation.rule_type,
                "violation_count": len(violations),
            },
        )
        self._audit_trail.append(record)

        # Also persist to persistent audit store if available
        if self._persistent_audit_store is not None:
            try:
                self._persistent_audit_store.append(
                    context.agent_id, record.to_dict()
                )
            except Exception:
                pass

    # ── Continuity violation helpers (Item 16) ──────────────────────

    def _write_continuity_violation_audit(
        self,
        action: Action,
        context: AgentContext,
        result: Any,
    ) -> None:
        """Write an audit record for a continuity violation."""
        if self._audit_trail is None:
            return

        from nomotic.audit import AuditRecord

        failed = ", ".join(p.value for p in result.failed_probes)
        record = AuditRecord(
            record_id=uuid.uuid4().hex[:12],
            timestamp=time.time(),
            context_code="GOVERNANCE.CONTINUITY_VIOLATION",
            severity="critical",
            agent_id=context.agent_id,
            owner_id="",
            user_id=(
                context.user_context.user_id
                if context.user_context is not None
                else ""
            ),
            action_id=action.id,
            action_type=action.action_type,
            action_target=action.target,
            verdict="DENY",
            ucs=0.0,
            tier=0,
            dimension_scores=[],
            trust_score=context.trust_profile.overall_trust,
            trust_trend="stable",
            justification=(
                f"Continuity violation: failed probes [{failed}]. "
                + "; ".join(result.violations)
            ),
            metadata={
                "continuity_probes_run": [p.value for p in result.probes_run],
                "continuity_failed_probes": [p.value for p in result.failed_probes],
                "continuity_violations": result.violations,
            },
        )
        self._audit_trail.append(record)

    def _make_continuity_deny_verdict(
        self,
        action: Action,
        context: AgentContext,
        result: Any,
    ) -> GovernanceVerdict:
        """Construct a DENY verdict for a continuity violation."""
        failed = ", ".join(p.value for p in result.failed_probes)
        return GovernanceVerdict(
            action_id=action.id,
            verdict=Verdict.DENY,
            ucs=0.0,
            tier=0,
            reasoning=(
                f"Pre-evaluation continuity check failed: [{failed}]. "
                + "; ".join(result.violations)
            ),
            dimension_scores=[],
            modifications={"continuity_violation": True},
        )

    # ── Audit trail integration (Phase 5) ────────────────────────────

    def _record_audit(
        self, action: Action, context: AgentContext, verdict: GovernanceVerdict,
    ) -> None:
        """Create an audit record for a governance decision."""
        from nomotic.audit import AuditRecord, build_justification
        from nomotic.context import CODES

        # Determine context code
        if verdict.verdict == Verdict.ALLOW:
            code = CODES.GOVERNANCE_ALLOW
        elif verdict.verdict == Verdict.DENY:
            if verdict.vetoed_by:
                code = CODES.GOVERNANCE_VETO
            else:
                code = CODES.GOVERNANCE_DENY
        elif verdict.verdict == Verdict.ESCALATE:
            code = CODES.GOVERNANCE_ESCALATE
        elif verdict.verdict == Verdict.MODIFY:
            code = CODES.GOVERNANCE_MODIFY
        else:
            code = CODES.GOVERNANCE_ALLOW

        # Resolve owner from certificate
        owner_id = ""
        cert = self.get_certificate(action.agent_id)
        if cert:
            owner_id = cert.owner

        # Resolve user from context
        user_id = ""
        if context.user_context is not None:
            user_id = context.user_context.user_id

        # Get trust state
        profile = self.trust_calibrator.get_profile(context.agent_id)
        trajectory = self.trust_calibrator.get_trajectory(context.agent_id)

        # Get drift state
        drift = self.get_drift(context.agent_id)

        # Build justification
        justification = build_justification(verdict, action, context, drift)

        record = AuditRecord(
            record_id=uuid.uuid4().hex[:12],
            timestamp=time.time(),
            context_code=code.code,
            severity=code.severity,
            agent_id=context.agent_id,
            owner_id=owner_id,
            user_id=user_id,
            action_id=action.id,
            action_type=action.action_type,
            action_target=action.target,
            verdict=verdict.verdict.name,
            ucs=verdict.ucs,
            tier=verdict.tier,
            dimension_scores=[
                {
                    "name": s.dimension_name,
                    "score": round(s.score, 4),
                    "weight": s.weight,
                    "veto": s.veto,
                    "reasoning": s.reasoning,
                }
                for s in verdict.dimension_scores
            ],
            trust_score=profile.overall_trust,
            trust_trend=trajectory.trend,
            drift_overall=drift.overall if drift else None,
            drift_severity=drift.severity if drift else None,
            justification=justification,
            metadata={
                "session_id": context.session_id,
                "config_version": (
                    self._provenance_log.current_config_version()
                    if self._provenance_log else ""
                ),
                "user_request_hash": (
                    context.user_context.request_hash
                    if context.user_context else ""
                ),
                "context_modification": (
                    verdict.context_modification.to_dict()
                    if verdict.context_modification is not None
                    else None
                ),
            },
        )
        assert self._audit_trail is not None
        self._audit_trail.append(record)

        # Track user activity
        if (
            context.user_context is not None
            and context.user_context.user_id
            and self._user_tracker is not None
        ):
            self._user_tracker.record_interaction(
                user_id=context.user_context.user_id,
                agent_id=context.agent_id,
                verdict=verdict.verdict.name,
                context_code=code.code,
            )

    def _record_provenance(
        self,
        actor: str,
        target_type: str,
        target_id: str,
        change_type: str,
        **kwargs: Any,
    ) -> None:
        """Record a configuration change in the provenance log."""
        if self._provenance_log is not None:
            self._provenance_log.record(
                actor=actor,
                target_type=target_type,
                target_id=target_id,
                change_type=change_type,
                **kwargs,
            )

    # ── Provenance-tracked configuration wrappers ─────────────────

    def configure_scope(
        self,
        agent_id: str,
        scope: set[str],
        *,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
        authority_id: str = "__bootstrap__",
    ) -> None:
        """Configure agent scope with provenance tracking."""
        from nomotic.authority_registry import GovernanceRole

        self._check_governance_authority(
            authority_id=authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
            target=agent_id,
            reason=reason,
        )
        dim = self.registry.get("scope_compliance")
        previous = dim._allowed_scopes.get(agent_id)
        dim.configure_agent_scope(agent_id, scope)
        self._record_provenance(
            actor=actor,
            target_type="scope",
            target_id=agent_id,
            change_type="modify" if previous else "add",
            previous_value=sorted(previous) if previous else None,
            new_value=sorted(scope),
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.SCOPE_CHANGED",
        )

    def configure_boundaries(
        self,
        agent_id: str,
        allowed_targets: set[str],
        *,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
        authority_id: str = "__bootstrap__",
    ) -> None:
        """Configure isolation boundaries with provenance tracking."""
        from nomotic.authority_registry import GovernanceRole

        self._check_governance_authority(
            authority_id=authority_id,
            required_role=GovernanceRole.SCOPE_OWNER,
            change_type="scope_update",
            target=agent_id,
            reason=reason,
        )
        dim = self.registry.get("isolation_integrity")
        previous = dim._boundaries.get(agent_id)
        dim.set_boundaries(agent_id, allowed_targets)
        self._record_provenance(
            actor=actor,
            target_type="boundary",
            target_id=agent_id,
            change_type="modify" if previous else "add",
            previous_value=sorted(previous) if previous else None,
            new_value=sorted(allowed_targets),
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.BOUNDARY_CHANGED",
        )

    def configure_time_window(
        self,
        action_type: str,
        start_hour: int,
        end_hour: int,
        *,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
    ) -> None:
        """Configure temporal compliance window with provenance tracking."""
        dim = self.registry.get("temporal_compliance")
        previous = dim._time_windows.get(action_type)
        dim.set_time_window(action_type, start_hour, end_hour)
        self._record_provenance(
            actor=actor,
            target_type="time_window",
            target_id=action_type,
            change_type="modify" if previous else "add",
            previous_value=list(previous) if previous else None,
            new_value=[start_hour, end_hour],
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.THRESHOLD_CHANGED",
        )

    def configure_human_override(
        self,
        *action_types: str,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
    ) -> None:
        """Configure human override requirements with provenance tracking."""
        dim = self.registry.get("human_override")
        previous = set(dim._require_human)
        dim.require_human_for(*action_types)
        self._record_provenance(
            actor=actor,
            target_type="override",
            target_id=",".join(action_types),
            change_type="add",
            previous_value=sorted(previous) if previous else None,
            new_value=sorted(dim._require_human),
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.THRESHOLD_CHANGED",
        )

    def add_ethical_rule(
        self,
        rule: Callable,
        *,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
        rule_name: str = "",
    ) -> None:
        """Add an ethical rule with provenance tracking."""
        dim = self.registry.get("ethical_alignment")
        dim.add_rule(rule)
        self._record_provenance(
            actor=actor,
            target_type="rule",
            target_id=rule_name or "ethical_rule",
            change_type="add",
            new_value=rule_name or repr(rule),
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.RULE_ADDED",
        )

    def set_dimension_weight(
        self,
        dimension_name: str,
        weight: float,
        *,
        actor: str = "system",
        reason: str = "",
        ticket: str = "",
    ) -> None:
        """Set a dimension weight with provenance tracking."""
        dim = self.registry.get(dimension_name)
        if dim is None:
            raise ValueError(f"Unknown dimension: {dimension_name}")
        previous = dim.weight
        dim.weight = weight
        self._record_provenance(
            actor=actor,
            target_type="weight",
            target_id=dimension_name,
            change_type="modify",
            previous_value=previous,
            new_value=weight,
            reason=reason,
            ticket=ticket,
            context_code="CONFIG.WEIGHT_CHANGED",
        )

    # ── Phase 5 property accessors ────────────────────────────────

    @property
    def audit_trail(self) -> Any:
        """The audit trail, or None if auditing is disabled."""
        return self._audit_trail

    @property
    def provenance_log(self) -> Any:
        """The provenance log, or None if auditing is disabled."""
        return self._provenance_log

    @property
    def owner_activity(self) -> Any:
        """The owner activity log, or None if auditing is disabled."""
        return self._owner_activity

    @property
    def user_tracker(self) -> Any:
        """The user activity tracker, or None if auditing is disabled."""
        return self._user_tracker

    # ── Context Profile convenience methods (Phase 7A) ────────────

    def get_context_profile(self, profile_id: str) -> Any:
        """Retrieve a context profile by ID."""
        return self.context_profiles.get_profile(profile_id)

    def create_context_profile(self, agent_id: str, **kwargs: Any) -> Any:
        """Create a new context profile for an agent."""
        return self.context_profiles.create_profile(agent_id, **kwargs)

    def _get_jurisdictional_context(self, agent_id: str) -> Any:
        """Retrieve jurisdictional context for an agent from active context profiles."""
        profile = self.context_profiles.get_active_profile(agent_id)
        if profile is not None:
            return profile.jurisdictional
        return None

    def set_jurisdictional_context(self, agent_id: str, jctx: Any) -> None:
        """Set jurisdictional context for an agent directly without a full context profile."""
        profile = self.context_profiles.get_active_profile(agent_id)
        if profile is None:
            profile = self.context_profiles.create_profile(
                agent_id=agent_id, profile_type="operational_period",
            )
        self.context_profiles.update_profile(profile.profile_id, jurisdictional=jctx)

    # ── Contextual modifier helpers (Phase 7B) ─────────────────────

    def _apply_weight_adjustments(
        self,
        adjustments: list[Any],
    ) -> dict[str, float]:
        """Apply weight adjustments from the contextual modifier.

        Returns a dict of original weights so they can be restored after
        evaluation. Adjustments to the same dimension accumulate (the
        deltas are summed). Final weights are clamped to [0.1, 3.0].
        """
        # Collect per-dimension deltas
        deltas: dict[str, float] = {}
        for adj in adjustments:
            delta = adj.adjusted_weight - adj.original_weight
            deltas[adj.dimension_name] = deltas.get(adj.dimension_name, 0.0) + delta

        originals: dict[str, float] = {}
        for dim_name, total_delta in deltas.items():
            dim = self.registry.get(dim_name)
            if dim is not None:
                originals[dim_name] = dim.weight
                new_weight = dim.weight + total_delta
                dim.weight = max(0.1, min(3.0, new_weight))
        return originals

    def _restore_weights(self, original_weights: dict[str, float]) -> None:
        """Restore dimension weights after a context-modified evaluation."""
        for dim_name, original_weight in original_weights.items():
            dim = self.registry.get(dim_name)
            if dim is not None:
                dim.weight = original_weight

    # ── Phase 8: Ethical Governance convenience methods ──────────────

    def run_equity_analysis(
        self,
        agent_id: str | None = None,
        method: str | None = None,
        window_hours: int | None = None,
    ) -> Any:
        """Run equity analysis on the audit trail.

        Requires equity_config in RuntimeConfig and audit enabled.
        """
        if self.equity_analyzer is None:
            raise ValueError(
                "Equity analysis requires equity_config in RuntimeConfig"
            )
        if self._audit_trail is None:
            raise ValueError("Equity analysis requires audit trail enabled")
        return self.equity_analyzer.analyze(
            self._audit_trail,
            agent_id=agent_id,
            method=method,
            window_hours=window_hours,
        )

    def run_bias_assessment(self) -> Any:
        """Run governance bias assessment on the current configuration."""
        if self.bias_detector is None:
            raise ValueError(
                "Bias detection requires equity_config in RuntimeConfig"
            )
        return self.bias_detector.assess_configuration(self)

    def get_cross_dimensional_signals(
        self,
        agent_id: str | None = None,
        window_hours: int = 168,
    ) -> Any:
        """Get aggregate cross-dimensional signals from the audit trail."""
        if self.cross_dimensional_detector is None:
            raise ValueError("Cross-dimensional detection is not enabled")
        if self._audit_trail is None:
            raise ValueError("Cross-dimensional analysis requires audit trail enabled")
        return self.cross_dimensional_detector.analyze_aggregate(
            self._audit_trail,
            agent_id=agent_id,
            window_hours=window_hours,
        )

    def anonymize_parameters(
        self,
        parameters: dict[str, Any],
        method: str,
    ) -> dict[str, Any]:
        """Apply anonymization policy to action parameters.

        Returns a copy with hidden attributes removed.  Original unchanged.
        """
        if self.anonymization_policy is None:
            return dict(parameters)
        return self.anonymization_policy.apply_to_parameters(parameters, method)

    def _append_history(self, agent_id: str, record: ActionRecord) -> None:
        history = self._action_history.setdefault(agent_id, [])
        history.append(record)
        if len(history) > self.config.max_history_per_agent:
            self._action_history[agent_id] = history[-self.config.max_history_per_agent :]
