# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in Nomotic, please report it responsibly:

- Email: security@nomotic.ai
- Do NOT open a public issue for security vulnerabilities
- Include: description, reproduction steps, potential impact
- We will respond within 48 hours and provide a fix timeline

## Scope

Security issues in these areas are in scope:

- Governance bypass (actions allowed that should be denied)
- Audit trail tampering (hash chain integrity failures)
- Certificate/token forgery or validation bypass
- Privilege escalation between agents
- Trust score manipulation
- Scope assembly attacks (individually-authorized steps achieving unauthorized outcomes)
- Cross-dimensional signal evasion

## Out of Scope

- Issues in dependencies (report these to the dependency maintainers)
- Social engineering attacks
- Denial of service attacks against the governance API

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.x     | Yes       |

## Disclosure Policy

- We will acknowledge receipt within 48 hours
- We will provide an estimated fix timeline within 7 days
- We will notify you when the fix is released
- We request that you do not publicly disclose the vulnerability until a fix is available
