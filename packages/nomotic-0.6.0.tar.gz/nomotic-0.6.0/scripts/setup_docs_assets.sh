#!/bin/bash
# Run this on the VPS to download and place Nomotic logo assets.
# Run from /docker/docusaurus/site/

LOGO_URL="https://nomotic.ai/wp-content/uploads/2026/02/cropped-nomotic-sq-logo-tran.png"
IMG_DIR="/docker/docusaurus/site/static/img"

mkdir -p "$IMG_DIR"

curl -o "$IMG_DIR/nomotic-logo.png" "$LOGO_URL"
curl -o "$IMG_DIR/nomotic-favicon.png" "$LOGO_URL"

echo "Assets downloaded to $IMG_DIR"
echo "Now rebuild: cd /docker/docusaurus/site && npm run build"
echo "Then restart: docker compose -f /docker/traefik/docker-compose.yml restart docusaurus"
