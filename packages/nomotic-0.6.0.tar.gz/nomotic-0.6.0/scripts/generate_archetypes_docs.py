"""Generates docs/reference/archetypes.md from src/nomotic/priors.py and src/nomotic/registry.py.

Imports the actual modules to extract archetype data from source.
Run from repo root: python scripts/generate_archetypes_docs.py
"""

import os
import sys

sys.path.insert(0, "src")

from nomotic.priors import ARCHETYPE_PRIOR_MAP, ARCHETYPE_WEIGHT_HINTS
from nomotic.registry import BUILT_IN_ARCHETYPES

# Try importing the preset map from cli
try:
    from nomotic.cli import ARCHETYPE_PRESET_MAP
except ImportError:
    ARCHETYPE_PRESET_MAP = {}

# Separate built-in originals from vertical aliases
VERTICAL_ALIASES = {
    "legal-assistant", "hr-agent", "procurement-agent",
    "devops-agent", "fraud-detection", "document-processor",
}

lines = [
    "---",
    "sidebar_position: 3",
    "title: Archetypes Reference",
    "---",
    "",
    "# Archetypes Reference",
    "",
    ":::info Auto-generated",
    "This page is auto-generated from source. Run `python scripts/generate_archetypes_docs.py` to update.",
    ":::",
    "",
    "Nomotic ships with 22 built-in archetypes — behavioral templates that drive",
    "governance intelligence. Each archetype has a behavioral prior (expected",
    "operational signature) and optionally maps to a compliance preset.",
    "",
    "## Summary Table",
    "",
    "| Archetype | Category | Compliance Preset | Resolves To |",
    "|-----------|----------|-------------------|-------------|",
]

for name in sorted(BUILT_IN_ARCHETYPES.keys()):
    info = BUILT_IN_ARCHETYPES[name]
    category = info.get("category", "")
    preset = ARCHETYPE_PRESET_MAP.get(name, "strict")
    prior = ARCHETYPE_PRIOR_MAP.get(name)
    resolves_to = prior if prior and prior != name else "(self)"
    lines.append(f"| `{name}` | {category} | `{preset}` | {resolves_to} |")

lines += ["", "---", "", "## Built-in Archetypes", ""]

for name in sorted(BUILT_IN_ARCHETYPES.keys()):
    if name in VERTICAL_ALIASES:
        continue

    info = BUILT_IN_ARCHETYPES[name]
    preset = ARCHETYPE_PRESET_MAP.get(name, "strict")
    prior_name = ARCHETYPE_PRIOR_MAP.get(name)

    lines += [
        f"### {name}",
        "",
        f"**Category:** {info.get('category', '')}",
        f"**Description:** {info.get('description', '')}",
        f"**Compliance preset:** `{preset}`",
        f"**Prior:** `{prior_name}`" if prior_name else "**Prior:** None (general-purpose)",
        "",
    ]

lines += ["---", "", "## Vertical Aliases (F-03)", ""]

for name in sorted(VERTICAL_ALIASES):
    if name not in BUILT_IN_ARCHETYPES:
        continue

    info = BUILT_IN_ARCHETYPES[name]
    preset = ARCHETYPE_PRESET_MAP.get(name, "strict")
    prior_name = ARCHETYPE_PRIOR_MAP.get(name)
    hints = ARCHETYPE_WEIGHT_HINTS.get(name, {})

    lines += [
        f"### {name}",
        "",
        f"**Category:** {info.get('category', '')}",
        f"**Description:** {info.get('description', '')}",
        f"**Compliance preset:** `{preset}`",
        f"**Resolves to:** `{prior_name}`",
        "",
    ]

    if hints:
        lines += ["**Weight hints:**", ""]
        lines.append("| Dimension | Suggested Adjustment |")
        lines.append("|-----------|---------------------|")
        for dim, delta in hints.items():
            lines.append(f"| `{dim}` | +{delta} |")
        lines.append("")

lines += [
    "---",
    "",
    "## Community Archetypes",
    "",
    "Install community-contributed archetypes from the marketplace:",
    "",
    "```bash",
    "nomotic archetype browse",
    "nomotic archetype pull <archetype-name>",
    "nomotic archetype info <archetype-name>",
    "```",
    "",
    "Community archetypes install to `~/.nomotic/community-archetypes/`.",
    "See [Archetype Marketplace](/tools/marketplace) for details.",
]

output_path = "docs/reference/archetypes.md"
os.makedirs(os.path.dirname(output_path), exist_ok=True)

with open(output_path, "w") as f:
    f.write("\n".join(lines))

print(f"Generated {output_path}")
