"""Generates docs/reference/dimensions.md from src/nomotic/dimensions.py.

Imports the actual module to extract dimension data from source.
Run from repo root: python scripts/generate_dimensions_docs.py
"""

import inspect
import os
import sys

sys.path.insert(0, "src")

from nomotic import dimensions as dim_module
from nomotic.dimensions import GovernanceDimension, DimensionRegistry


def get_dimension_instances():
    """Get all registered dimension instances from a default registry."""
    registry = DimensionRegistry()
    # Find and instantiate all GovernanceDimension subclasses in the module
    dims = []
    for name, obj in inspect.getmembers(dim_module, inspect.isclass):
        if (
            issubclass(obj, GovernanceDimension)
            and obj is not GovernanceDimension
            and not name.startswith("_")
        ):
            try:
                instance = obj()
                dims.append(instance)
            except Exception:
                pass
    return dims


dims = get_dimension_instances()

lines = [
    "---",
    "sidebar_position: 2",
    "title: Dimensions Reference",
    "---",
    "",
    "# Governance Dimensions Reference",
    "",
    ":::info Auto-generated",
    "This page is auto-generated from source. Run `python scripts/generate_dimensions_docs.py` to update.",
    ":::",
    "",
    "Nomotic evaluates every agent action across 14 governance dimensions simultaneously.",
    "Each dimension assesses one aspect of whether an action should proceed. Dimensions",
    "can score, veto, or modify actions independently. The UCS engine combines their",
    "signals into a unified decision.",
    "",
    "See [Trust Model](/architecture/trust-model) for how the UCS calculation works.",
    "",
    "## Summary Table",
    "",
    "| # | Dimension | Default Weight | Veto | Description |",
    "|---|-----------|---------------|------|-------------|",
]

# Sort dimensions by weight descending for the summary
sorted_dims = sorted(dims, key=lambda d: getattr(d, "weight", getattr(d, "default_weight", 1.0)), reverse=True)

for i, dim in enumerate(sorted_dims, 1):
    name = getattr(dim, "name", dim.__class__.__name__)
    weight = getattr(dim, "weight", getattr(dim, "default_weight", 1.0))
    can_veto = getattr(dim, "can_veto", getattr(dim, "is_veto", False))
    desc = (dim.__class__.__doc__ or "").strip().split("\n")[0] if dim.__class__.__doc__ else ""
    veto_str = "Yes" if can_veto else "No"
    lines.append(f"| {i} | {name} | {weight} | {veto_str} | {desc} |")

lines.append("")

# Detailed sections for each dimension
for dim in sorted_dims:
    name = getattr(dim, "name", dim.__class__.__name__)
    class_name = dim.__class__.__name__
    weight = getattr(dim, "weight", getattr(dim, "default_weight", 1.0))
    can_veto = getattr(dim, "can_veto", getattr(dim, "is_veto", False))
    doc = (dim.__class__.__doc__ or "").strip()

    lines += [
        f"## {class_name}",
        "",
        f"**Dimension ID:** `{name}`",
        f"**Default weight:** {weight} | **Veto dimension:** {'Yes' if can_veto else 'No'}",
        "",
    ]

    if doc:
        lines += [doc, ""]

lines += [
    "## Custom Dimensions",
    "",
    "Create custom dimensions by subclassing `GovernanceDimension`:",
    "",
    "```python",
    "from nomotic.dimensions import GovernanceDimension",
    "from nomotic.types import Action, AgentContext, DimensionScore",
    "",
    "",
    "class MyCustomDimension(GovernanceDimension):",
    '    name = "my_custom_dimension"',
    "    weight = 1.0",
    "    can_veto = False",
    "",
    "    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:",
    "        # Your evaluation logic here",
    "        score = 0.8  # 0.0 (bad) to 1.0 (good)",
    '        return DimensionScore(dimension=self.name, score=score, details="Custom check passed")',
    "```",
    "",
    "Register custom dimensions with the `DimensionRegistry`:",
    "",
    "```python",
    "from nomotic.dimensions import DimensionRegistry",
    "",
    "registry = DimensionRegistry()",
    "registry.register(MyCustomDimension())",
    "```",
]

output_path = "docs/reference/dimensions.md"
os.makedirs(os.path.dirname(output_path), exist_ok=True)

with open(output_path, "w") as f:
    f.write("\n".join(lines))

print(f"Generated {output_path}")
