// @ts-check

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Nomotic',
  tagline: 'The Behavioral Control Plane\u2122 for AI Agents',
  favicon: 'img/nomotic-favicon.png',

  url: 'https://docs.nomotic.ai',
  baseUrl: '/',

  organizationName: 'nomotic-ai',
  projectName: 'nomotic',

  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',

  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js',
          routeBasePath: '/',
          editUrl: 'https://git.nomotic.ai/nomotic/nomotic/-/edit/main/',
        },
        blog: false,
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      image: 'img/nomotic-social.png',
      navbar: {
        title: 'Nomotic',
        logo: {
          alt: 'Nomotic',
          src: 'img/nomotic-logo.png',
        },
        items: [
          { to: '/quickstart', label: 'Quickstart', position: 'left' },
          { to: '/guides/governed-agent-base', label: 'Guides', position: 'left' },
          { to: '/reference/cli', label: 'CLI Reference', position: 'left' },
          { to: '/dashboard/', label: 'Dashboard', position: 'left' },
          { to: '/architecture/overview', label: 'Architecture', position: 'left' },
          {
            href: 'https://git.nomotic.ai/nomotic/nomotic',
            label: 'GitLab',
            position: 'right',
          },
          {
            href: 'https://pypi.org/project/nomotic/',
            label: 'PyPI',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Docs',
            items: [
              { label: 'Quickstart', to: '/quickstart' },
              { label: 'CLI Reference', to: '/reference/cli' },
              { label: 'API Reference', to: '/reference/api' },
            ],
          },
          {
            title: 'Architecture',
            items: [
              { label: 'Overview', to: '/architecture/overview' },
              { label: 'Trust Model', to: '/architecture/trust-model' },
              { label: 'Behavioral Control Plane', to: '/architecture/behavioral-control-plane' },
            ],
          },
          {
            title: 'Community',
            items: [
              { label: 'GitLab', href: 'https://git.nomotic.ai/nomotic/nomotic' },
              { label: 'PyPI', href: 'https://pypi.org/project/nomotic/' },
              { label: 'nomotic.ai', href: 'https://nomotic.ai' },
            ],
          },
        ],
        copyright: `Copyright \u00a9 ${new Date().getFullYear()} Nomotic AI\u2122. Behavioral Control Plane\u2122 \u00b7 Runtime AI Governance\u2122 \u00b7 The Should Layer\u2122`,
      },
      prism: {
        theme: require('prism-react-renderer').themes.github,
        darkTheme: require('prism-react-renderer').themes.dracula,
        additionalLanguages: ['python', 'bash', 'yaml', 'json'],
      },
      colorMode: {
        defaultMode: 'light',
        disableSwitch: false,
      },
    }),
};

module.exports = config;
