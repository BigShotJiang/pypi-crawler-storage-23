/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  docs: [
    { type: 'doc', id: 'intro', label: 'What is Nomotic?' },
    { type: 'doc', id: 'quickstart', label: 'Quickstart' },
    { type: 'doc', id: 'installation', label: 'Installation' },
    {
      type: 'category',
      label: 'Integration Guides',
      collapsed: false,
      items: [
        'guides/index',
        'guides/governed-agent-base',
        'guides/langgraph',
        'guides/crewai',
        'guides/openai',
        'guides/claude',
      ],
    },
    {
      type: 'category',
      label: 'Governance Dashboard',
      items: [
        'dashboard/index',
        'dashboard/agent-roster',
        'dashboard/drift-alerts',
        'dashboard/audit-trail',
        'dashboard/approval-queue',
        'dashboard/playground',
        'dashboard/config-editor',
      ],
    },
    {
      type: 'category',
      label: 'CLI Tools',
      items: [
        'tools/fleet-simulator',
        'tools/scorecard',
        'tools/diagnostics',
        'tools/marketplace',
        'tools/telemetry',
      ],
    },
    {
      type: 'category',
      label: 'Reference',
      items: [
        'reference/cli',
        'reference/dimensions',
        'reference/archetypes',
        'reference/configuration',
        'reference/api',
        'reference/governance-token',
      ],
    },
    {
      type: 'category',
      label: 'Architecture',
      items: [
        'architecture/overview',
        'architecture/behavioral-control-plane',
        'architecture/trust-model',
        'architecture/audit-trail',
        'architecture/drift-detection',
      ],
    },
    {
      type: 'category',
      label: 'Security',
      items: [
        'security/owasp-alignment',
        'security/adversarial-testing',
      ],
    },
  ],
};

module.exports = sidebars;
