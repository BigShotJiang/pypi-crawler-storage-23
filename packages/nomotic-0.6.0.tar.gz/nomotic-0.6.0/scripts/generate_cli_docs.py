"""Generates docs/reference/cli.md from src/nomotic/cli.py.

Run from repo root: python scripts/generate_cli_docs.py
Intended for CI: runs on every push, keeps CLI docs in sync with source.
"""

import os
import subprocess
import sys


def get_help_output(*args: str) -> str:
    """Run nomotic [args...] --help and capture output."""
    cmd = [sys.executable, "-m", "nomotic"] + list(args) + ["--help"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout or result.stderr


# Top-level subcommands
SUBCOMMANDS = [
    "setup", "birth", "init", "hello", "tutorial", "serve", "validate",
    "doctor", "diagnose", "scorecard", "export", "override",
    "archetype", "config", "roles", "inspect", "constitution",
    "simulate", "new",
]

# Subcommands that have their own sub-subcommands
SUBCOMMAND_GROUPS = {
    "simulate": ["fleet", "batch", "stop", "status", "report"],
    "archetype": ["browse", "pull", "info"],
    "config": ["set", "get"],
    "roles": ["list", "assign", "revoke"],
}

lines = [
    "---",
    "sidebar_position: 1",
    "title: CLI Reference",
    "---",
    "",
    "# CLI Reference",
    "",
    ":::info Auto-generated",
    "This page is auto-generated from source. Run `python scripts/generate_cli_docs.py` to update.",
    ":::",
    "",
    "## Global help",
    "",
    "```",
    get_help_output().strip(),
    "```",
    "",
]

for cmd in SUBCOMMANDS:
    help_text = get_help_output(cmd)
    if not help_text.strip():
        continue
    lines += [f"## nomotic {cmd}", "", "```", help_text.strip(), "```", ""]

    # Sub-subcommands
    if cmd in SUBCOMMAND_GROUPS:
        for subcmd in SUBCOMMAND_GROUPS[cmd]:
            sub_help = get_help_output(cmd, subcmd)
            if sub_help.strip():
                lines += [
                    f"### nomotic {cmd} {subcmd}",
                    "",
                    "```",
                    sub_help.strip(),
                    "```",
                    "",
                ]

output_path = "docs/reference/cli.md"
os.makedirs(os.path.dirname(output_path), exist_ok=True)

with open(output_path, "w") as f:
    f.write("\n".join(lines))

print(f"Generated {output_path}")
