---
sidebar_position: 3
title: Archetypes Reference
---

# Archetypes Reference

:::info Auto-generated
This page is auto-generated from source. Run `python scripts/generate_archetypes_docs.py` to update.
:::

Nomotic ships with 22 built-in archetypes � behavioral templates that drive
governance intelligence. Each archetype has a behavioral prior (expected
operational signature) and optionally maps to a compliance preset.

## Summary Table

| Archetype | Category | Compliance Preset | Resolves To |
|-----------|----------|-------------------|-------------|
| `analytics` | data | `strict` | research-analyst |
| `clinical-support` | healthcare | `strict` | healthcare-agent |
| `compliance-audit` | security | `strict` | security-monitor |
| `content-generation` | content | `strict` | content-creator |
| `content-moderation` | content | `strict` | security-monitor |
| `customer-experience` | customer-facing | `strict` | (self) |
| `data-processing` | data | `strict` | data-processor |
| `devops-agent` | operations | `strict` | operations-coordinator |
| `document-processor` | data | `standard` | data-processor |
| `financial-transactions` | financial | `strict` | financial-analyst |
| `fraud-detection` | security | `ultra_strict` | security-monitor |
| `general-purpose` | general | `strict` | (self) |
| `hr-agent` | operations | `strict` | executive-assistant |
| `legal-assistant` | research | `soc2_aligned` | research-analyst |
| `procurement-agent` | operations | `strict` | operations-coordinator |
| `research-assistant` | research | `strict` | research-analyst |
| `sales-assistant` | customer-facing | `strict` | sales-agent |
| `security-monitoring` | security | `strict` | security-monitor |
| `supply-chain` | operations | `strict` | operations-coordinator |
| `system-administration` | operations | `strict` | operations-coordinator |
| `underwriting` | financial | `strict` | financial-analyst |
| `workflow-orchestration` | operations | `strict` | operations-coordinator |

---

## Built-in Archetypes

### analytics

**Category:** data
**Description:** Data analysis, reporting, and insight generation agents
**Compliance preset:** `strict`
**Prior:** `research-analyst`

### clinical-support

**Category:** healthcare
**Description:** Clinical decision support and care coordination agents
**Compliance preset:** `strict`
**Prior:** `healthcare-agent`

### compliance-audit

**Category:** security
**Description:** Regulatory compliance checking and reporting agents
**Compliance preset:** `strict`
**Prior:** `security-monitor`

### content-generation

**Category:** content
**Description:** Text, media, and document creation agents
**Compliance preset:** `strict`
**Prior:** `content-creator`

### content-moderation

**Category:** content
**Description:** Content review, filtering, and compliance agents
**Compliance preset:** `strict`
**Prior:** `security-monitor`

### customer-experience

**Category:** customer-facing
**Description:** Customer service, support, and interaction agents
**Compliance preset:** `strict`
**Prior:** `customer-experience`

### data-processing

**Category:** data
**Description:** Data transformation, ETL, and pipeline agents
**Compliance preset:** `strict`
**Prior:** `data-processor`

### financial-transactions

**Category:** financial
**Description:** Payment processing, transfers, and financial operation agents
**Compliance preset:** `strict`
**Prior:** `financial-analyst`

### general-purpose

**Category:** general
**Description:** Unspecialized agents or agents awaiting archetype assignment
**Compliance preset:** `strict`
**Prior:** None (general-purpose)

### research-assistant

**Category:** research
**Description:** Literature review, data gathering, and research support agents
**Compliance preset:** `strict`
**Prior:** `research-analyst`

### sales-assistant

**Category:** customer-facing
**Description:** Sales support, lead qualification, and outreach agents
**Compliance preset:** `strict`
**Prior:** `sales-agent`

### security-monitoring

**Category:** security
**Description:** Threat detection, incident response, and security audit agents
**Compliance preset:** `strict`
**Prior:** `security-monitor`

### supply-chain

**Category:** operations
**Description:** Logistics, inventory, and procurement agents
**Compliance preset:** `strict`
**Prior:** `operations-coordinator`

### system-administration

**Category:** operations
**Description:** Infrastructure management, deployment, and monitoring agents
**Compliance preset:** `strict`
**Prior:** `operations-coordinator`

### underwriting

**Category:** financial
**Description:** Risk assessment, policy evaluation, and approval agents
**Compliance preset:** `strict`
**Prior:** `financial-analyst`

### workflow-orchestration

**Category:** operations
**Description:** Multi-step process coordination and task routing agents
**Compliance preset:** `strict`
**Prior:** `operations-coordinator`

---

## Vertical Aliases (F-03)

### devops-agent

**Category:** operations
**Description:** CI/CD, infrastructure automation, and deployment agents
**Compliance preset:** `strict`
**Resolves to:** `operations-coordinator`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `isolation_integrity` | +0.2 |

### document-processor

**Category:** data
**Description:** Document parsing, extraction, and transformation agents
**Compliance preset:** `standard`
**Resolves to:** `data-processor`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `isolation_integrity` | +0.1 |

### fraud-detection

**Category:** security
**Description:** Transaction monitoring, anomaly detection, and fraud prevention agents
**Compliance preset:** `ultra_strict`
**Resolves to:** `security-monitor`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `incident_detection` | +0.1 |

### hr-agent

**Category:** operations
**Description:** Human resources, recruiting, and employee management agents
**Compliance preset:** `strict`
**Resolves to:** `executive-assistant`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `stakeholder_impact` | +0.1 |

### legal-assistant

**Category:** research
**Description:** Legal research, contract review, and compliance support agents
**Compliance preset:** `soc2_aligned`
**Resolves to:** `research-analyst`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `jurisdictional_compliance` | +0.2 |

### procurement-agent

**Category:** operations
**Description:** Vendor management, purchasing, and procurement workflow agents
**Compliance preset:** `strict`
**Resolves to:** `operations-coordinator`

**Weight hints:**

| Dimension | Suggested Adjustment |
|-----------|---------------------|
| `resource_boundaries` | +0.15 |

---

## Community Archetypes

Install community-contributed archetypes from the marketplace:

```bash
nomotic archetype browse
nomotic archetype pull <archetype-name>
nomotic archetype info <archetype-name>
```

Community archetypes install to `~/.nomotic/community-archetypes/`.
See [Archetype Marketplace](/tools/marketplace) for details.