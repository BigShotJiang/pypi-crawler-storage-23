---
sidebar_position: 1
title: CLI Reference
---

# CLI Reference

:::info Auto-generated
This page is auto-generated from source. Run `python scripts/generate_cli_docs.py` to update.
:::

## Global help

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic setup

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic birth

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic init

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic hello

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic tutorial

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic serve

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic validate

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic doctor

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic diagnose

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic scorecard

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic export

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic override

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic archetype

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype browse

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype pull

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic archetype info

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic config

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic config set

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic config get

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic roles

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles list

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles assign

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic roles revoke

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic inspect

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic constitution

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic simulate

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate fleet

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate batch

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate stop

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate status

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

### nomotic simulate report

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```

## nomotic new

```
C:\Python313\python.exe: No module named nomotic.__main__; 'nomotic' is a package and cannot be directly executed
```
