---
sidebar_position: 4
title: Configuration Reference
---

# Configuration Reference

The `nomotic.yaml` file is the primary configuration for a governed agent. It defines the agent's identity, archetype, compliance preset, governance thresholds, and dimension weight overrides.

## Location

`nomotic.yaml` lives in the project root. Created by `nomotic init` or manually.

## Full Annotated Example

```yaml
# nomotic.yaml — Nomotic Behavioral Control Plane configuration

agent:
  name: my-agent              # required — unique agent identifier
  archetype: customer-experience  # required — governance prior set
  org: acme-corp              # required — organization identifier
  zone: production/us-east    # optional — hierarchical zone path
  owner: team@example.com     # optional — responsible team or email

compliance:
  preset: strict              # strict | standard | ultra_strict | hipaa_aligned |
                              # soc2_aligned | pci_dss_aligned | iso27001_aligned
  jurisdiction: US            # optional — for regulatory alignment

governance:
  trust_low_threshold: 0.35   # below this → ESCALATE or DENY
  trust_high_threshold: 0.65  # above this → fast-path evaluation
  interrupt_threshold: 0.2    # below this → interrupt authority active

dimension_weights:
  # Override default weights for any of the 14 dimensions.
  # Values 0.0 (ignored) to 5.0 (dominant). Default varies by dimension.
  # scope_compliance: 2.0     # uncomment to override
  # ethical_alignment: 2.5

budget_gate:
  budget_per_action: 0        # max cost per action in USD, 0 = disabled

audit:
  retention_days: 90          # how long to keep audit records
```

## Field Reference

| Field | Type | Default | Required | Description |
|---|---|---|---|---|
| `agent.name` | string | — | Yes | Unique agent identifier |
| `agent.archetype` | string | — | Yes | Governance prior set. See [Archetypes Reference](/reference/archetypes). |
| `agent.org` | string | — | Yes | Organization identifier (from `nomotic setup`) |
| `agent.zone` | string | `production` | No | Hierarchical zone path (e.g., `production/us-east`) |
| `agent.owner` | string | — | No | Responsible team or email |
| `compliance.preset` | string | `strict` | No | Compliance framework preset |
| `compliance.jurisdiction` | string | — | No | Geographic jurisdiction for regulatory alignment |
| `governance.trust_low_threshold` | float | `0.35` | No | Trust score below which escalation triggers |
| `governance.trust_high_threshold` | float | `0.65` | No | Trust score above which fast-path applies |
| `governance.interrupt_threshold` | float | `0.2` | No | Trust score below which interrupt authority activates |
| `dimension_weights.*` | float | varies | No | Per-dimension weight override (0.0–5.0) |
| `budget_gate.budget_per_action` | float | `0` | No | Max USD cost per action, 0 = disabled |
| `audit.retention_days` | int | `90` | No | Audit record retention period in days |

## Compliance Presets

| Preset | Description |
|---|---|
| `strict` | Default. Balanced governance with standard thresholds. |
| `standard` | Relaxed thresholds. Suitable for low-risk internal agents. |
| `ultra_strict` | Maximum governance strictness. For security-critical agents. |
| `hipaa_aligned` | Tightened thresholds for healthcare/PHI-handling agents. Elevates ethical_alignment, stakeholder_impact, jurisdictional_compliance weights. |
| `soc2_aligned` | SOC2 Trust Services alignment. Elevates audit, access control, and monitoring dimensions. |
| `pci_dss_aligned` | PCI-DSS alignment for payment-handling agents. |
| `iso27001_aligned` | ISO 27001 information security alignment. |

## Weight Hints

When using vertical archetype aliases (F-03), Nomotic suggests additional dimension weight adjustments:

| Alias | Suggested Weight Adjustment |
|---|---|
| `legal-assistant` | `jurisdictional_compliance: +0.2` |
| `hr-agent` | `stakeholder_impact: +0.1` |
| `procurement-agent` | `resource_boundaries: +0.15` |
| `devops-agent` | `isolation_integrity: +0.2` |
| `fraud-detection` | `incident_detection: +0.1` |
| `document-processor` | `isolation_integrity: +0.1` |

These are suggestions logged at runtime. Apply them in `dimension_weights` to activate.
