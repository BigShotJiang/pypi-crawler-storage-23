---
sidebar_position: 2
title: Dimensions Reference
---

# Governance Dimensions Reference

:::info Auto-generated
This page is auto-generated from source. Run `python scripts/generate_dimensions_docs.py` to update.
:::

Nomotic evaluates every agent action across 14 governance dimensions simultaneously.
Each dimension assesses one aspect of whether an action should proceed. Dimensions
can score, veto, or modify actions independently. The UCS engine combines their
signals into a unified decision.

See [Trust Model](/architecture/trust-model) for how the UCS calculation works.

## Summary Table

| # | Dimension | Default Weight | Veto | Description |
|---|-----------|---------------|------|-------------|
| 1 | ethical_alignment | 2.0 | Yes | Does the action meet ethical constraints? |
| 2 | human_override | 2.0 | Yes | Is human intervention required or requested? |
| 3 | authority_verification | 1.5 | Yes | Does the agent have authority for this specific action? |
| 4 | incident_detection | 1.5 | Yes | Does this action match known failure or attack patterns? |
| 5 | scope_compliance | 1.5 | Yes | Is the action within the agent's authorized scope? |
| 6 | isolation_integrity | 1.4 | Yes | Are containment boundaries maintained? |
| 7 | jurisdictional_compliance | 1.4 | Yes | Dimension 14: Jurisdictional Compliance. |
| 8 | cascading_impact | 1.3 | No | What are the downstream consequences of this action? |
| 9 | resource_boundaries | 1.2 | Yes | Are resource limits respected? |
| 10 | stakeholder_impact | 1.2 | No | Who is affected by this action and how? |
| 11 | behavioral_consistency | 1.0 | No | Does this action match expected behavior patterns? |
| 12 | temporal_compliance | 0.8 | Yes | Is the timing of this action appropriate? |
| 13 | precedent_alignment | 0.7 | No | Is this consistent with past governance decisions? |
| 14 | transparency | 0.6 | No | Is the action auditable and explainable? |

## EthicalAlignment

**Dimension ID:** `ethical_alignment`
**Default weight:** 2.0 | **Veto dimension:** Yes

Does the action meet ethical constraints?

Evaluates against configured ethical rules. These are hard constraints
that cannot be overridden by high trust or other dimension scores.

## HumanOverride

**Dimension ID:** `human_override`
**Default weight:** 2.0 | **Veto dimension:** Yes

Is human intervention required or requested?

Some actions always require human approval. Others require it based on
context (high value, sensitive target, low trust). This dimension
enforces human-in-the-loop requirements.

## AuthorityVerification

**Dimension ID:** `authority_verification`
**Default weight:** 1.5 | **Veto dimension:** Yes

Does the agent have authority for this specific action?

Scope says what types of actions are allowed. Authority says whether
this specific action on this specific target is permitted.

## IncidentDetection

**Dimension ID:** `incident_detection`
**Default weight:** 1.5 | **Veto dimension:** Yes

Does this action match known failure or attack patterns?

Cross-action pattern monitoring. Detects sequences that look like
known incidents � rapid repeated failures, privilege escalation
attempts, data exfiltration patterns.

When drift data is available (Phase 4B), critical drift is treated
as an incident signal � it means the agent's behaviour has
fundamentally changed, which could indicate compromise,
misconfiguration, or environmental issues.

## ScopeCompliance

**Dimension ID:** `scope_compliance`
**Default weight:** 1.5 | **Veto dimension:** Yes

Is the action within the agent's authorized scope?

Checks action type, target, and parameters against the agent's
defined permissions. Hard boundary � out-of-scope actions are vetoed.

## IsolationIntegrity

**Dimension ID:** `isolation_integrity`
**Default weight:** 1.4 | **Veto dimension:** Yes

Are containment boundaries maintained?

Agents should operate within defined boundaries. Actions that cross
isolation boundaries � accessing other agents' resources, modifying
shared state without coordination � score lower or get vetoed.

## JurisdictionalCompliance

**Dimension ID:** `jurisdictional_compliance`
**Default weight:** 1.4 | **Veto dimension:** Yes

Dimension 14: Jurisdictional Compliance.

Evaluates whether the proposed action is permitted under applicable
legal and regulatory jurisdictions. Evaluated per-action at runtime �
not static configuration.

Four evaluation categories:
1. Cross-border transfer legality
2. Data classification against jurisdiction rules
3. Legal basis verification (GDPR/UK_GDPR zones)
4. Inference zone compliance

A missing JurisdictionalContext (no context profile, or profile
has no jurisdictional section) returns 0.7 � caution without veto.
This preserves backward compatibility for deployments that have not
yet configured jurisdictional context.

## CascadingImpact

**Dimension ID:** `cascading_impact`
**Default weight:** 1.3 | **Veto dimension:** No

What are the downstream consequences of this action?

Evaluates whether the action could trigger chains of effects.
Actions that modify shared state, trigger other agents, or affect
external systems score lower.

## ResourceBoundaries

**Dimension ID:** `resource_boundaries`
**Default weight:** 1.2 | **Veto dimension:** Yes

Are resource limits respected?

Tracks rate, concurrency, and cost against configured limits.
Degrades gracefully � approaching limits lowers the score before
hitting them triggers a veto.

## StakeholderImpact

**Dimension ID:** `stakeholder_impact`
**Default weight:** 1.2 | **Veto dimension:** No

Who is affected by this action and how?

Actions that affect more stakeholders, or more sensitive stakeholders,
score lower. External-facing actions score lower than internal ones.

## BehavioralConsistency

**Dimension ID:** `behavioral_consistency`
**Default weight:** 1.0 | **Veto dimension:** No

Does this action match expected behavior patterns?

Compares the action against the agent's established behavioral profile.
Sudden deviations � new action types, unusual targets, parameter
anomalies � lower the score.

When a behavioral fingerprint is available (from the fingerprint
observer), the evaluation checks against the fingerprint's action
distribution for richer scoring.  Without a fingerprint, falls back
to the legacy "have I seen this action type before?" check.

When drift data is available (Phase 4B), high drift modulates the
score downward proportionally to the drift magnitude.

## TemporalCompliance

**Dimension ID:** `temporal_compliance`
**Default weight:** 0.8 | **Veto dimension:** Yes

Is the timing of this action appropriate?

Some actions should only happen during specific windows. Others have
minimum intervals between executions. Rate patterns matter.

## PrecedentAlignment

**Dimension ID:** `precedent_alignment`
**Default weight:** 0.7 | **Veto dimension:** No

Is this consistent with past governance decisions?

Similar actions should get similar governance outcomes. Sudden changes
in how governance treats an action type indicate something unusual.

## Transparency

**Dimension ID:** `transparency`
**Default weight:** 0.6 | **Veto dimension:** No

Is the action auditable and explainable?

Actions must carry enough context to be understood later. Missing
metadata, opaque parameters, or unexplainable targets lower the score.

## Custom Dimensions

Create custom dimensions by subclassing `GovernanceDimension`:

```python
from nomotic.dimensions import GovernanceDimension
from nomotic.types import Action, AgentContext, DimensionScore


class MyCustomDimension(GovernanceDimension):
    name = "my_custom_dimension"
    weight = 1.0
    can_veto = False

    def evaluate(self, action: Action, context: AgentContext) -> DimensionScore:
        # Your evaluation logic here
        score = 0.8  # 0.0 (bad) to 1.0 (good)
        return DimensionScore(dimension=self.name, score=score, details="Custom check passed")
```

Register custom dimensions with the `DimensionRegistry`:

```python
from nomotic.dimensions import DimensionRegistry

registry = DimensionRegistry()
registry.register(MyCustomDimension())
```