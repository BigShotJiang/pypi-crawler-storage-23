---
sidebar_position: 6
title: Governance Token
---

# Governance Token / Agent Certificate

Every governed agent receives a cryptographic birth certificate — a signed governance token that establishes verifiable identity and binds the agent to its governance configuration.

## Certificate Fields

| Field | Type | Description |
|---|---|---|
| `certificate_id` | string | Unique certificate ID (format: `nmc-<hash>`) |
| `agent_id` | string | Agent identifier |
| `archetype` | string | Assigned archetype |
| `organization` | string | Issuing organization |
| `zone_path` | string | Governance zone |
| `owner` | string | Responsible owner |
| `issued_at` | datetime | Issuance timestamp |
| `expires_at` | datetime | Expiration timestamp |
| `status` | enum | ACTIVE, SUSPENDED, REVOKED |
| `trust_score` | float | Current trust score (0.0–1.0) |
| `issuer_id` | string | Issuer identifier |
| `signature` | bytes | Ed25519 signature over certificate data |
| `governance_hash` | string | Hash binding to governance configuration |

## Certificate Lifecycle

```
birth → ACTIVE → (optional) SUSPENDED → ACTIVE
                                       → REVOKED (terminal)
         ACTIVE → REVOKED (terminal)
         ACTIVE → renew → new ACTIVE (with lineage link)
```

### CLI Commands

```bash
# Issue a certificate
nomotic birth --name my-agent --archetype customer-experience --org acme-corp

# Verify
nomotic verify <cert-id>

# Inspect
nomotic inspect <agent-id>
nomotic inspect <agent-id> --brief
nomotic inspect <agent-id> --raw
nomotic inspect <agent-id> --provenance

# Lifecycle management
nomotic suspend <cert-id> --reason "policy violation"
nomotic reactivate <cert-id>
nomotic revoke <cert-id> --reason "decommissioned"
nomotic renew <cert-id>

# Export
nomotic export <cert-id>
```

## Governance Hash Binding

The `governance_hash` field binds the certificate to a specific governance configuration. If the configuration changes, the hash changes, creating an auditable link between identity and governance policy.

## Signature Verification

Certificates are signed with Ed25519. Verification confirms:

1. The certificate was issued by the claimed issuer
2. The certificate data has not been modified since issuance
3. The governance hash matches the current configuration

```bash
nomotic verify <cert-id>
```

## API

```
POST /v1/certificates                      # Issue
GET  /v1/certificates/{cert_id}             # Retrieve
POST /v1/certificates/{cert_id}/verify      # Verify signature
POST /v1/certificates/{cert_id}/verify/live # Live verification
```

## Storage

Certificates are stored in `~/.nomotic/certs/` as JSON files (format: `nmc-<hash>.json`).
