---
sidebar_position: 1
title: Fleet Simulator
---

# Fleet Simulator

The Fleet Simulator (F-22) runs a realistic multi-department agent fleet with **real governance evaluations** through the actual UCS engine. 1,000 governed agents. Real audit trail. Live dashboard integration.

## Quick Start

```bash
nomotic simulate fleet --agents 1000 --watch
```

This provisions 1,000 agents across 10 departments, starts continuous governance evaluations, and opens the dashboard for live monitoring.

## Subcommands

| Command | Description |
|---|---|
| `nomotic simulate fleet` | Start a fleet simulation with live dashboard |
| `nomotic simulate batch` | Run a batch of evaluations without live display |
| `nomotic simulate stop` | Stop a running simulation |
| `nomotic simulate status` | Check simulation status |
| `nomotic simulate report` | Generate a simulation report |

## Departments

The simulator distributes agents across 10 departments, each with realistic action profiles:

| Department | Archetypes | Example Actions |
|---|---|---|
| CRM | customer-experience, sales-agent | read customer_record, update crm_record, export contact_list |
| Finance | financial-analyst, fraud-detection | read portfolio_data, execute market_trade, transfer funds |
| DevOps | devops-agent, operations-coordinator | deploy service, restart container, delete production_volume |
| Data & Analytics | data-processor, document-processor | read analytics_db, query data_warehouse, delete raw_data |
| Security | security-monitor, fraud-detection | scan network_segment, analyze incident_log, block ip_address |
| Human Resources | hr-agent, executive-assistant | read employee_record, update compensation_data, read payroll_db |
| Procurement | procurement-agent, operations-coordinator | read vendor_catalog, issue purchase_order, execute bulk_order |
| Support | customer-experience, sales-agent | read ticket_data, issue refund, export support_history |
| Legal | legal-assistant, research-analyst | read case_files, draft contract, export confidential_docs |
| Executive | executive-assistant, financial-analyst | read board_materials, access strategic_plan, export investor_data |

Each department includes intentionally risky actions (marked with higher-risk targets) to generate realistic deny/escalate verdicts.

## Behavior Profiles

Agents are assigned one of four behavior profiles:

| Profile | Weight | Initial Trust | Risky Action Multiplier |
|---|---|---|---|
| Compliant | 65% | 0.70–0.90 | 0.2x (rarely picks risky actions) |
| Borderline | 20% | 0.45–0.65 | 1.0x (normal distribution) |
| Drifting | 10% | 0.55–0.75 | 2.5x (gravitates toward risky actions) |
| Rogue | 5% | 0.30–0.50 | 4.0x (heavily biased toward risky actions) |

## Dashboard Integration

Use `--sim-mode` with the dashboard to wire simulation data into the UI:

```bash
nomotic serve --ui --sim-mode
```

The dashboard shows live simulation data in the Agent Roster, Evaluation Feed, and Drift Alerts panels.

## API

```
GET /v1/sim/stats    # Current simulation statistics
GET /v1/sim/status   # Simulation running status
```
