---
sidebar_position: 4
title: Archetype Marketplace
---

# Archetype Marketplace

The Archetype Marketplace (F-20) lets you browse, pull, and inspect community-contributed archetypes.

## Commands

```bash
# Browse available archetypes
nomotic archetype browse

# Pull a community archetype
nomotic archetype pull <archetype-name>

# Inspect an archetype's details
nomotic archetype info <archetype-name>
```

## Registry

Community archetypes are hosted at `github.com/nomotic-ai/archetype-registry`. Each archetype is a YAML file defining:

- Archetype name and description
- Base archetype it resolves to (one of the 10 built-in priors)
- Weight overrides for specific governance dimensions
- Use case descriptions

## Install Path

Community archetypes install to:

```
~/.nomotic/community-archetypes/<archetype-name>.yaml
```

## YAML Format

```yaml
name: insurance-claims-agent
description: Insurance claims processing and adjudication agents
resolves_to: financial-analyst
weight_overrides:
  ethical_alignment: 0.2
  stakeholder_impact: 0.15
  jurisdictional_compliance: 0.1
use_cases:
  - Claims intake and triage
  - Policy validation
  - Fraud screening
```

## Validation

Pulled archetypes are validated with `validate_archetype()` before installation:

- Name format validation (lowercase, hyphens, 3–64 chars)
- Base archetype exists (resolves_to must be a known archetype)
- Weight overrides are within valid range (0.0–5.0)
- YAML structure is well-formed

## Built-in Archetypes

Nomotic ships with 22 built-in archetypes (16 originals + 6 vertical aliases from F-03). These don't need to be pulled — they're available immediately. See the [Archetypes Reference](/reference/archetypes) for the full list.
