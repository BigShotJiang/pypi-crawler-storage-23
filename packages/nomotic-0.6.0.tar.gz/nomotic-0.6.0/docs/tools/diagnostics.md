---
sidebar_position: 3
title: Error Diagnostics
---

# Error Diagnostics Wizard

The diagnostics wizard (F-18) explains Nomotic errors in plain language with resolution steps.

## Usage

```bash
nomotic diagnose <error-code-or-alias>
```

Alias matching supports partial strings:

```bash
nomotic diagnose constitutional     # matches ConstitutionalViolationError
nomotic diagnose budget             # matches BudgetExhaustedError
nomotic diagnose veto               # matches GovernanceVetoError
```

## Registered Error Classes

| Error Class | Aliases | Description |
|---|---|---|
| `ConstitutionalViolationError` | constitutional, constitution, CVE | A constitutional rule was violated |
| `ConstitutionalIntegrityError` | integrity, ruleset_signature | Constitutional ruleset integrity check failed |
| `BudgetExhaustedError` | budget, budget_exhausted, cost_limit | Action exceeds cost budget limit |
| `ContinuityViolationError` | continuity, state_continuity | State continuity check failed |
| `DelegationDepthError` | delegation, delegation_depth, delegation_limit | Delegation chain exceeds max depth |
| `CertificateStatusError` | cert_status, certificate_status, cert_inactive | Certificate is not in ACTIVE status |
| `PermissionDeniedError` | permission, permission_denied, role_denied, unauthorized | Insufficient role permissions |
| `RoleConfigError` | role_config, roles_config | Role registry configuration error |
| `WorkflowDependencyError` | workflow, workflow_dependency, dependency | Workflow dependency not satisfied |
| `GovernanceVetoError` | veto, governance_veto, denied, blocked | Action denied by governance evaluation |
| `GovernanceDeniedError` | governance_denied, tool_denied, tool_governance | Tool-level governance denial |
| `PolicyLoadError` | policy_load, policy_file, policy_parse | Failed to load policy file |
| `FrameworkLoadError` | framework_load, compliance_framework | Failed to load compliance framework |
| `AGICOMPLYError` | agicomply, agicomply_push | AGICOMPLY integration error |
| `NomoticSDKError` | sdk, sdk_error, nomotic_sdk | SDK-level error |
| `CertificateLoadError` | cert_load, certificate_load, key_load | Failed to load certificate or key |
| `GovernedRequestError` | governed_request, http_error, network_error | HTTP request governance error |

## Doctor Integration

`nomotic doctor` runs health checks that detect potential issues before they become errors:

```bash
nomotic doctor          # Run all health checks
nomotic doctor --fix    # Auto-repair common issues
nomotic doctor --json   # Machine-readable output
nomotic doctor --quiet  # Exit code only
```

Doctor checks include: certificate store integrity, issuer key validity, audit trail chain verification, role registry configuration, constitutional rule integrity, and delegation depth limits.
