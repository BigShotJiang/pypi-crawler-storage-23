---
sidebar_position: 5
title: Telemetry
---

# Opt-in Anonymous Telemetry

Nomotic includes opt-in anonymous telemetry (F-21) that helps improve the project. Telemetry is **disabled by default** and collects no data unless you explicitly opt in.

## Opting In

During initial setup:

```bash
nomotic setup
# The interactive setup asks if you want to enable telemetry
```

Or at any time:

```bash
nomotic config set --telemetry on
```

## Opting Out

```bash
nomotic config set --telemetry off
```

## What Is Collected

All collected data is **SHA-256 hashed before transmission**. Raw values are never sent.

| Data Point | Example (pre-hash) | Hashed? |
|---|---|---|
| Archetype names | `customer-experience` | Yes |
| CLI command names | `birth`, `serve`, `scorecard` | Yes |
| Framework names | `langgraph`, `crewai` | Yes |

## What Is NEVER Collected

- Agent IDs
- Action types or targets
- UCS scores or governance verdicts
- Audit trail content
- Organization names
- Certificate data
- IP addresses or system identifiers
- Any PII

## Privacy Architecture

1. Data points are SHA-256 hashed locally before leaving your machine
2. Only hashed values are transmitted
3. No correlation between hashed values and source data is possible without brute force
4. No user identification or tracking across sessions
