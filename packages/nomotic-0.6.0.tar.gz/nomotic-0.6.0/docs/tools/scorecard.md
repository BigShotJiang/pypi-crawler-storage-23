---
sidebar_position: 2
title: Governance Scorecard
---

# Governance Scorecard Generator

The Governance Scorecard (F-19) generates auditor-ready compliance reports that map Nomotic governance data against compliance frameworks.

## Usage

```bash
# SOC2 scorecard (HTML)
nomotic scorecard --agent <agent-id> --framework soc2

# HIPAA scorecard (JSON)
nomotic scorecard --agent <agent-id> --framework hipaa --format json
```

## Output Formats

### HTML
Self-contained, print-ready HTML with all CSS inline. No external dependencies. Open in any browser and print to PDF for auditor delivery.

### JSON
Machine-readable format for integration with compliance management platforms.

## Compliance Frameworks

### SOC2 Controls

| Control ID | Control Name | Coverage | Nomotic Feature |
|---|---|---|---|
| CC6.1 | Logical and Physical Access Controls | Full | GovernanceAuthorityRegistry + role-based override |
| CC6.6 | Security Threats from Outside Systems | Partial | 14-dimensional evaluation including scope_compliance |
| CC7.2 | System Monitoring | Full | Hash-chained audit trail + DriftMonitor |
| CC7.3 | Evaluation of Security Events | Full | UCS evaluation engine + ESCALATE verdict routing |
| CC7.4 | Incident Response | Partial | Interrupt authority + approval queue |
| CC9.2 | Vendor and Business Partner Management | Indirect | Delegation chain enforcement |

### HIPAA Controls

| Control ID | Control Name | Coverage | Nomotic Feature |
|---|---|---|---|
| 164.312(a)(1) | Access Control | Full | Scope compliance dimension + GovernanceAuthorityRegistry |
| 164.312(b) | Audit Controls | Full | Hash-chained immutable audit trail |
| 164.312(c)(1) | Integrity | Partial | Constitutional Rules Engine + output validation |
| 164.312(d) | Person Authentication | Indirect | Agent Birth Certificate cryptographic identity |
| 164.312(e)(2)(ii) | Encryption | None | Not provided — use transport-layer encryption |

## Scorecard Sections

1. **Agent Identity** — certificate ID, archetype, trust score, compliance preset
2. **Behavioral Summary (30d)** — evaluation counts, allow/deny/escalate rates, average UCS, trust trajectory sparkline
3. **Compliance Framework Mapping** — control-by-control coverage with Nomotic feature attribution
4. **Gap Analysis** — controls with no or partial coverage, severity levels, recommendations
5. **Archetype Benchmark** — agent metrics compared against archetype baselines (deny rate, UCS average, drift frequency)
6. **Signature Block** — generation timestamp, Nomotic version, audit record hash for provenance

## Audit Hash Provenance

The scorecard includes the latest audit record hash (`audit_record_hash`). Auditors can use this to verify that the scorecard was generated from an unmodified audit chain, establishing a provenance link between the compliance report and the underlying governance data.
