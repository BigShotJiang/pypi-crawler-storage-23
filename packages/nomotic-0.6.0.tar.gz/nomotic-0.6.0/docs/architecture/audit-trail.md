---
sidebar_position: 3
title: Audit Trail
---

# Hash-Chained Audit Trail

Every governance evaluation produces an immutable audit record linked to the previous record via cryptographic hash, creating a tamper-evident chain.

## How It Works

Each audit record contains:
- Agent ID, action type, target, parameters
- Governance verdict (ALLOW, DENY, ESCALATE, MODIFY, SUSPEND)
- UCS score
- Per-dimension scores
- Timestamp
- **`record_hash`** — SHA-256 hash linking this record to the previous

### Hash Chain

```
Record 1: hash = SHA-256(genesis_seed + record_1_data)
Record 2: hash = SHA-256(record_1_hash + record_2_data)
Record 3: hash = SHA-256(record_2_hash + record_3_data)
...
```

If any record is modified, deleted, or reordered, the hash chain breaks. Verification walks the chain from any record back to the genesis record, checking each link.

## Tamper Evidence

The hash chain provides:
- **Insertion detection** — new records between existing ones break the chain
- **Modification detection** — changing any field changes the hash
- **Deletion detection** — removing a record breaks the chain
- **Reordering detection** — records out of order break the chain

## Chain Verification

### CLI

```bash
# Verify a specific agent's audit trail
nomotic audit <agent-id> --verify
```

### API

```
POST /v1/ui/audit/verify/{record_id}
GET  /v1/audit/{agent_id}/verify
```

### Programmatic

```python
from nomotic.audit_store import LogStore

store = LogStore(base_dir)
verification = store.verify_chain(agent_id)
print(f"Chain valid: {verification.valid}")
print(f"Records verified: {verification.count}")
```

## Export Formats

Audit records can be exported for external analysis:

```bash
# CSV
nomotic audit <agent-id> --export csv

# JSON
nomotic audit <agent-id> --export json

# SIEM formats
nomotic siem-export --format cef    # Common Event Format
nomotic siem-export --format syslog # Syslog
nomotic siem-export --format jsonl  # JSON Lines
```

## Governance Scorecard Integration

The governance scorecard (F-19) uses the latest audit record hash as a provenance marker. The scorecard's `audit_record_hash` field lets auditors verify that the scorecard was generated from an unmodified audit trail.
