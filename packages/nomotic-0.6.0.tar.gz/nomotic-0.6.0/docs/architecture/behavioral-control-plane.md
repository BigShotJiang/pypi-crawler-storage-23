---
sidebar_position: 4
title: Behavioral Control Plane
---

# The Behavioral Control Plane

Nomotic is the Behavioral Control Plane for AI agents. This page explains what that means architecturally and why it differs from existing approaches to AI governance.

## What is a Control Plane?

In networking, the control plane makes routing decisions while the data plane moves packets. The control plane doesn't process traffic — it governs how traffic flows.

Nomotic applies this architecture to AI agents. The governance runtime (control plane) makes behavioral decisions while the agent framework (data plane) executes actions. The governance runtime doesn't perform the agent's work — it governs how the agent behaves.

## Why "Behavioral"?

Existing governance tools govern different things:

### Constitutional / Deterministic Systems
Binary allow/deny rules. "If action is DELETE, deny." No behavioral memory, no trust evolution, no context. Every evaluation is independent.

**Nomotic's difference:** Evaluates 14 dimensions simultaneously. Trust evolves over time. Behavioral fingerprints detect drift. Context from prior actions informs current decisions.

### Access Control Layers
Govern identities and permissions. "User X has permission to access resource Y." Identity-centric, not behavior-centric.

**Nomotic's difference:** Governs the agent itself, not just its identity. Two agents with identical permissions can receive different verdicts based on behavioral history, trust trajectory, and current patterns.

### Monitoring Tools
Observe after the fact. Log analysis, anomaly detection, alerting. No authority to prevent actions.

**Nomotic's difference:** Interrupt authority. Nomotic evaluates before every action and can halt execution mid-stream. It's a participant in the execution flow, not an observer.

## The Behavioral Dimension

What makes Nomotic behavioral:

1. **Behavioral fingerprints** — Each agent builds a behavioral signature from its action patterns, targets, timing, and outcomes. Drift from this fingerprint is detected and flagged.

2. **Trust evolution** — Trust isn't static. It changes with every action. Well-behaved agents earn trust incrementally. Violations cost trust disproportionately.

3. **Multidimensional scoring** — Every action is evaluated across 14 independent dimensions. A single score (allow/deny) loses information. 14 scores capture the full behavioral picture.

4. **Archetype priors** — Agents start with a behavioral prior based on their archetype. A healthcare agent has different expected patterns than a DevOps agent. The prior serves as the initial fingerprint until real observations accumulate.

5. **Bidirectional drift detection** — Both agent behavior and human oversight are monitored for drift. The system watches the watchers.

## Architecture Implications

The behavioral control plane architecture means:

- **Every action passes through governance** — there is no bypass, no "admin mode"
- **Governance is sub-millisecond** — the control plane must not become a bottleneck
- **State is continuous** — trust, fingerprints, and drift are maintained across evaluations
- **Interruption is possible** — the control plane can halt the data plane mid-operation
- **Audit is automatic** — every governance decision is recorded in a tamper-evident chain
