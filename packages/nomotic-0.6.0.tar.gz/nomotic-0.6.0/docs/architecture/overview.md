---
sidebar_position: 1
title: Architecture Overview
---

# Architecture Overview

Nomotic's governance runtime is a multi-layered evaluation engine that processes every agent action through 14 dimensions simultaneously, delivering sub-millisecond governance decisions.

## Design Principles

1. **Governance has mechanical authority over execution** — the runtime can interrupt actions mid-stream, not just approve or deny at the gate
2. **Simultaneous multi-dimensional evaluation** — all 14 dimensions evaluate in parallel, not sequentially
3. **Three-tier decision cascade** — deterministic veto checks, weighted UCS scoring, then deliberative analysis
4. **Trust is earned, not granted** — asymmetric calibration: +0.01 per successful completion, -0.05 per violation
5. **Interruption enables deployment** — agents can be deployed earlier because governance can halt them if behavior drifts

## Component Architecture

```
GovernanceRuntime
├── DimensionRegistry
│   └── 14 GovernanceDimension instances
│       evaluate_all() runs all dimensions simultaneously
│
├── UCSEngine (Unified Compliance Scoring)
│   ├── Weighted average of dimension scores
│   ├── Trust modulation (higher trust → higher scores)
│   ├── Floor drag (low dimensions pull score down)
│   └── Clamping to [0.0, 1.0]
│
├── Three-Tier Cascade
│   ├── Tier 1: TierOneGate
│   │   └── Veto dimensions only — microsecond decisions
│   │       Any veto dimension scoring 0.0 → immediate DENY
│   │
│   ├── Tier 2: TierTwoEvaluator
│   │   └── Full UCS calculation
│   │       UCS ≥ 0.7 → ALLOW
│   │       UCS ≤ 0.3 → DENY
│   │       Otherwise → ambiguous, pass to Tier 3
│   │
│   └── Tier 3: TierThreeDeliberator
│       └── Contextual analysis for ambiguous cases
│           High trust → ALLOW
│           Low trust → ESCALATE
│           Critical dimension < 0.4 → MODIFY
│
├── InterruptAuthority
│   ├── register() — register an execution for monitoring
│   ├── interrupt() — 4 granularity levels
│   ├── rollback() — invoke registered rollback handler
│   └── monitor() — continuous behavioral monitoring during execution
│
└── TrustCalibrator
    ├── Per-verdict adjustment (+0.01 ALLOW, -0.05 DENY)
    ├── Completion bonus
    ├── Time decay
    └── Per-dimension trust tracking
```

## Evaluation Flow

```
Action received
  │
  ├─→ Tier 1: Veto check (all veto dimensions)
  │     └─→ Any veto? → DENY (immediate, no UCS calculation)
  │
  ├─→ Tier 2: UCS calculation (all 14 dimensions)
  │     ├─→ UCS ≥ 0.7 → ALLOW
  │     ├─→ UCS ≤ 0.3 → DENY
  │     └─→ 0.3 < UCS < 0.7 → Tier 3
  │
  └─→ Tier 3: Deliberation
        ├─→ High trust (> 0.65) → ALLOW
        ├─→ Low trust (< 0.35) → ESCALATE
        └─→ Critical dim < 0.4 → MODIFY
```

## Execution Flow

```
Verdict: ALLOW
  │
  ├─→ Register with InterruptAuthority
  ├─→ Begin execution
  │     ├─→ check_interrupt() at each step
  │     └─→ If interrupted → rollback()
  ├─→ Complete execution
  └─→ TrustCalibrator.update(+0.01)
```

## Design Decisions

**Why 14 dimensions?** — Each dimension captures a distinct governance concern. Fewer dimensions would conflate independent risks. More would add evaluation overhead without proportional benefit. The 14 dimensions cover scope, authority, resources, behavior, cascading impact, stakeholders, incidents, isolation, timing, precedent, transparency, human oversight, ethics, and jurisdiction.

**Why veto dimensions?** — Some concerns are non-negotiable. An action outside the agent's authorized scope should be denied regardless of how well it scores on other dimensions. Eight of the 14 dimensions have veto authority.

**Why cooperative interruption?** — Preemptive kills can corrupt state. Nomotic's interrupt model is cooperative: the executing code checks `handle.check_interrupt()` at safe points and can invoke registered rollback handlers.

**Why asymmetric trust?** — Building trust should be harder than losing it. A single violation (trust -0.05) costs 5x more than a successful action earns (+0.01). This reflects the reality that a single bad action can cause more damage than five good actions create value.

**Why zero external dependencies?** — The governance runtime is pure Python stdlib. No database, no message queue, no external service required. This eliminates deployment friction and ensures the runtime can evaluate actions in microseconds.
