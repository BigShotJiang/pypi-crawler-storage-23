---
sidebar_position: 5
title: Drift Detection
---

# Bidirectional Drift Detection

Nomotic detects behavioral drift in two directions: agent drift (changes in agent behavior) and human reviewer drift (changes in human oversight patterns). Both matter for governance integrity.

## Agent Behavioral Drift

### How It Works

The `DriftMonitor` maintains a behavioral fingerprint for each agent, built from:

- **Action distribution** — the frequency of each action type (read, write, delete, etc.)
- **Target distribution** — which resources the agent accesses
- **Temporal patterns** — when the agent is active (business hours, overnight, etc.)
- **Outcome distribution** — the ratio of ALLOW/DENY/ESCALATE verdicts

When current behavior diverges from the established fingerprint, drift is detected.

### Archetype Priors

Before an agent has enough history, its fingerprint is seeded from the archetype's behavioral prior. For example, a `customer-experience` agent's prior expects:
- 55% read, 20% write, 12% send, 8% query, 5% escalate
- Peak hours: 10:00–14:00
- Active during business hours only
- 92% ALLOW, 4% MODIFY, 3% ESCALATE, 1% DENY

As real observations accumulate (weighted by `prior_weight`, default 50 synthetic observations), the actual behavior gradually replaces the prior.

### Drift Weights

Not all drift is equally concerning. Each archetype defines `drift_weights` that amplify or dampen drift signals:

```python
# Financial analyst: action and target drift matter more
drift_weights = {
    "action": 1.5,   # Changed action mix is very concerning
    "target": 1.5,   # Accessing new resource types is very concerning
    "temporal": 1.2,  # Off-hours activity is moderately concerning
    "outcome": 1.3,  # Changing denial rates is concerning
}
```

### Thresholds and Severity

| Severity | Description |
|---|---|
| Low | Minor distribution shift within normal variance |
| Medium | Sustained pattern change over multiple evaluations |
| High | Significant behavioral divergence from fingerprint |
| Critical | Extreme deviation — possible compromise or misconfiguration |

## Human Reviewer Drift

### Why It Matters

Human oversight is only effective if humans are actually overseeing. Reviewer drift detects when oversight quality degrades:

- A reviewer who normally handles 50 escalations/week drops to 5
- Approval rate jumps from 70% to 99% (rubber-stamping)
- Response times increase from minutes to days
- A reviewer stops reviewing certain agent types entirely

### HumanDriftMonitor

The `HumanDriftMonitor` tracks reviewer engagement patterns:

- **Review frequency** — how often the reviewer handles escalations
- **Approval rate** — percentage of escalations approved vs. denied
- **Response time** — latency from escalation to resolution
- **Coverage** — which agent types and archetypes the reviewer handles

Drift in any of these patterns triggers alerts visible in the dashboard and via the API.

## API

```
GET /v1/drift/{agent_id}                              # Agent drift report
GET /v1/ui/drift-alerts                               # All drift alerts
POST /v1/ui/drift-alerts/{id}/dismiss                  # Dismiss an alert
GET /v1/human-engagement/{reviewer_id}/drift            # Reviewer drift
GET /v1/human-engagement/alerts                        # Human engagement alerts
```

## CLI

```bash
# View agent drift
nomotic drift <agent-id>

# List drift alerts
nomotic alerts
nomotic alerts --unacknowledged
```
