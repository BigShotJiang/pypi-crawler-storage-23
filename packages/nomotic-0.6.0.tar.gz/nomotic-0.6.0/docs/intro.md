---
slug: /
sidebar_position: 1
title: What is Nomotic?
---

# What is Nomotic?

AI agents act in milliseconds. Humans review in hours. The gap between those timescales is where risk lives.

Traditional governance tools govern **requests** — binary allow/deny decisions at the API boundary. Nomotic governs **agents** — behavioral trajectory, trust evolution, drift detection, and multidimensional scoring across the full agent lifecycle.

Nomotic is the Behavioral Control Plane™ for AI agents. It evaluates every agent action at runtime across 14 dimensions simultaneously, delivering sub-millisecond governance decisions with interrupt authority and dynamic trust calibration.

## Key Capabilities

- **[14-dimensional behavioral evaluation](/reference/dimensions)** — scope, authority, resources, behavior, impact, stakeholders, incidents, isolation, timing, precedent, transparency, human oversight, ethics, and jurisdiction evaluated simultaneously
- **[Verifiable agent identity](/reference/governance-token)** — cryptographic birth certificates with governance hash binding
- **Interrupt authority** — halt agent actions mid-execution with rollback support
- **[Dynamic trust calibration](/architecture/trust-model)** — trust scores evolve with every action (+0.01 per success, -0.05 per violation)
- **[Bidirectional drift detection](/architecture/drift-detection)** — detects both agent behavioral drift AND human reviewer drift
- **[Hash-chained audit trail](/architecture/audit-trail)** — tamper-evident, cryptographically linked evaluation records
- **[Governance dashboard](/dashboard/)** — real-time agent monitoring, approval queues, drift alerts
- **[Compliance scorecards](/tools/scorecard)** — SOC2, HIPAA, PCI-DSS, ISO27001 mapping with gap analysis

## Core Concepts

**Behavioral Control Plane™** — The product category. Where networking has a control plane that governs packet routing, Nomotic provides a control plane that governs agent behavior. Every action is evaluated, every decision is recorded, every drift is detected.

**Runtime AI Governance™** — Describes when governance happens. Not after the fact in a compliance review. Not at deployment in a static policy check. At runtime, before every action, throughout the full agent lifecycle.

**The Should Layer™** — The philosophy. Traditional systems govern what agents *can* do (permissions, access control). Nomotic governs what agents *should* do — behavioral expectations, ethical constraints, stakeholder impact, and organizational values.

## Get Started

```bash
pip install nomotic
```

Then follow the [Quickstart guide](/quickstart) to create your first governed agent in under 5 minutes.
