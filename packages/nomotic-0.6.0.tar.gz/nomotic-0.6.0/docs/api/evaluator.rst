ProtocolEvaluator
=================

.. automodule:: nomotic.evaluator
   :members:
   :show-inheritance:
