---
sidebar_position: 2
title: Adversarial Testing
---

# Adversarial Testing

Nomotic includes built-in support for adversarial testing of governance configurations.

## CLI Testing

```bash
# Standard governance evaluation test
nomotic test --agent <agent-id>

# Adversarial mode — red team scenarios
nomotic test --agent <agent-id> --adversarial
```

Adversarial mode generates test actions designed to probe governance boundaries:
- Actions at the edge of authorized scope
- High-risk action types (delete, transfer, export)
- Actions targeting sensitive resources
- Rapid-fire requests to test rate limiting
- Off-hours activity to test temporal compliance

## Fleet Simulation

The [Fleet Simulator](/tools/fleet-simulator) includes adversarial behavior profiles:

- **Drifting** agents (10% of fleet) gradually shift toward risky actions
- **Rogue** agents (5% of fleet) heavily bias toward risky actions with low initial trust

This creates a realistic adversarial environment for testing governance configurations at scale.

## What to Verify

When running adversarial tests, verify that:

1. **Veto dimensions fire** — scope violations are immediately denied (Tier 1)
2. **UCS scoring is appropriate** — risky actions receive low UCS scores
3. **Escalation triggers** — actions in the deliberation zone route to the approval queue
4. **Drift detection activates** — sustained adversarial behavior triggers drift alerts
5. **Interrupt authority works** — very low trust agents can be interrupted mid-execution
6. **Audit trail captures everything** — all adversarial actions are recorded with full dimension scores

## Test Evaluation History

```bash
# View test evaluation history
nomotic testlog <agent-id>

# Summary only
nomotic testlog <agent-id> --summary

# Verify test log integrity
nomotic testlog <agent-id> --verify

# Clear test history
nomotic testlog <agent-id> --clear
```

Test evaluations are stored separately from production audit records and do not affect production trust scores.
