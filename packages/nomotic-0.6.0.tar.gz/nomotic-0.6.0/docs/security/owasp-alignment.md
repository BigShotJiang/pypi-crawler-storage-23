---
sidebar_position: 1
title: OWASP Alignment
---

# OWASP Security Alignment

Nomotic's governance architecture addresses concerns raised in the OWASP Top 10 for LLM Applications and AI security best practices.

## OWASP Top 10 for LLM Applications

### LLM01: Prompt Injection

**Nomotic coverage:** The 14-dimensional evaluation includes scope compliance and behavioral consistency dimensions that detect actions outside an agent's established patterns, limiting the effectiveness of prompt injection that causes an agent to deviate from expected behavior.

### LLM02: Insecure Output Handling

**Nomotic coverage:** The `OutputGovernor` validates agent outputs before they reach downstream systems. The `validate_output()` method in `GovernedAgentBase` can redact or block outputs that violate governance policies.

### LLM03: Training Data Poisoning

**Nomotic coverage:** Indirect. Nomotic doesn't govern training data, but behavioral drift detection can identify when an agent's behavior shifts in ways consistent with poisoned training data — unexpected action patterns, new target distributions, or anomalous outcomes.

### LLM04: Model Denial of Service

**Nomotic coverage:** The `ResourceBoundaries` dimension enforces rate limits, concurrency limits, and cost budgets per agent. The `budget_gate` configuration prevents individual actions from exceeding cost thresholds.

### LLM06: Sensitive Information Disclosure

**Nomotic coverage:** The `IsolationIntegrity` dimension enforces containment boundaries. Agents cannot access targets outside their configured boundaries. The `OutputGovernor` can redact sensitive content from outputs.

### LLM07: Insecure Plugin Design

**Nomotic coverage:** Every tool/function call passes through governance evaluation. The `ScopeCompliance` dimension verifies the action is within the agent's authorized scope. The `AuthorityVerification` dimension runs custom authority checks.

### LLM08: Excessive Agency

**Nomotic coverage:** Core strength. The entire governance runtime exists to constrain agent agency. 14-dimensional evaluation, trust calibration, interrupt authority, and approval queues collectively prevent agents from taking actions beyond their authorized scope and behavioral expectations.

### LLM09: Overreliance

**Nomotic coverage:** The `HumanOverride` dimension ensures critical actions require human review. The approval queue enforces human-in-the-loop for escalated verdicts. Bidirectional drift detection monitors whether humans are actually providing oversight (not rubber-stamping).

### LLM10: Model Theft

**Nomotic coverage:** Agent Birth Certificates provide verifiable identity with cryptographic signatures. The `AuthorityVerification` dimension can enforce provenance checks. The audit trail creates an immutable record of all agent actions.

## AI Agent-Specific Threats

### Autonomous Action Chains

Agents executing multi-step plans can accumulate risk across steps. Nomotic evaluates every individual action, not just the initial plan. Cascading impact scoring considers downstream consequences.

### Trust Boundary Crossing

Agents interacting with external systems cross trust boundaries. The `IsolationIntegrity` and `JurisdictionalCompliance` dimensions enforce containment. Zone paths provide hierarchical isolation.

### Privilege Escalation

Agents gradually expanding their effective permissions. The `ScopeCompliance` dimension enforces a fixed scope set. Behavioral drift detection identifies agents that begin accessing new resource types outside their historical pattern.

### Human Oversight Degradation

Reviewers who stop reviewing effectively. Nomotic's bidirectional drift detection monitors human reviewer patterns — review frequency, approval rates, response times — and alerts when oversight degrades.
