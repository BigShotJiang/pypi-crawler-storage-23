---
sidebar_position: 2
title: Quickstart
---

# Quickstart

Get up and running with Nomotic in under 5 minutes.

## 1. Install Nomotic

```bash
pip install nomotic
```

For Slack integration with the approval queue:

```bash
pip install nomotic[slack]
```

## 2. Set Up Your Organization

Run the interactive setup (once per machine):

```bash
nomotic setup
```

This creates `~/.nomotic/config.json` with your organization ID, owner info, default zone, and compliance preset. It also generates your issuer key pair for signing agent certificates.

## 3. Create Your First Governed Agent

```bash
nomotic init --name my-agent --archetype customer-experience
```

The `init` command scaffolds a governed agent project with:

- **`nomotic.yaml`** — governance configuration (archetype, compliance preset, dimension weights)
- **`hello_nomotic.py`** — a working example script with governance evaluation
- **`.gitignore`** — excludes local runtime data

Use `--no-interactive` to skip the archetype picker, or run without `--archetype` to get an interactive selection menu with all 22 built-in archetypes.

## 4. Run Governance Locally

```bash
python hello_nomotic.py
```

Sample output:

```
[nomotic] Evaluating: read → customer_records
  Verdict: ALLOW | UCS: 0.847 | Tier: 1

[nomotic] Evaluating: delete → production_database
  Verdict: DENY | UCS: 0.182 | Tier: 1 (veto: scope_compliance)
```

Every action gets a verdict (`ALLOW`, `DENY`, `ESCALATE`, `MODIFY`, or `SUSPEND`) with a Unified Compliance Score (UCS) between 0.0 and 1.0.

## 5. Open the Governance Dashboard

```bash
nomotic serve --ui
```

Open [http://localhost:8420/ui](http://localhost:8420/ui) in your browser. The dashboard shows:

- **Agent Roster** — all governed agents with trust scores and status indicators
- **Evaluation Feed** — real-time stream of governance decisions
- **Drift Alerts** — behavioral anomalies detected across agents and reviewers
- **Audit Trail** — filterable, exportable, chain-verified evaluation history

## 6. Python API

Here's a minimal working example using the Python API directly:

```python
from nomotic import GovernanceRuntime, Action, AgentContext, TrustProfile

# Initialize the governance runtime
runtime = GovernanceRuntime()

# Configure what the agent is allowed to do
runtime.configure_scope(
    agent_id="my-agent",
    scope={"read", "write", "query"},
    boundaries={"customer/*", "order/*"},
)

# Evaluate an action
action = Action(
    agent_id="my-agent",
    action_type="write",
    target="customer/profile",
    parameters={"field": "email"},
)

context = AgentContext(
    agent_id="my-agent",
    trust_profile=TrustProfile(agent_id="my-agent"),
)

result = runtime.evaluate(action, context)
print(f"Verdict: {result.verdict}")  # ALLOW, DENY, ESCALATE, MODIFY, or SUSPEND
print(f"UCS: {result.ucs:.3f}")      # 0.0–1.0 Unified Compliance Score
print(f"Tier: {result.tier}")        # 1 (deterministic), 2 (weighted), 3 (deliberative)
```

For framework integrations, use `GovernedAgentBase` which wraps this API with a simpler interface:

```python
from nomotic import GovernanceRuntime
from nomotic.governed_agent import GovernedAgentBase

runtime = GovernanceRuntime()
# ... configure runtime ...

# GovernedAgentBase provides govern_action(), validate_output(), governed_run()
# See the Integration Guides for framework-specific examples.
```

## 7. Next Steps

- **[Integration Guides](/guides/)** — LangGraph, CrewAI, OpenAI, Claude SDK integration
- **[CLI Reference](/reference/cli)** — all `nomotic` commands
- **[Architecture Overview](/architecture/overview)** — how the governance runtime works
- **[Dashboard Guide](/dashboard/)** — using the governance dashboard
- **[Configuration Reference](/reference/configuration)** — `nomotic.yaml` field reference
