---
sidebar_position: 3
title: Installation
---

# Installation

## Requirements

- Python 3.10 or later
- pip (included with Python)

## Standard Install

```bash
pip install nomotic
```

## Optional Extras

```bash
# Slack integration for the approval queue
pip install nomotic[slack]

# Development tools (testing, linting, docs generation)
pip install nomotic[dev]
```

## Platform Support

Nomotic runs on Linux, macOS, and Windows. The governance runtime is pure Python with zero required external dependencies.

## Verify Installation

```bash
# Check version
nomotic --version

# Run health checks on your governance infrastructure
nomotic doctor
```

`nomotic doctor` verifies your issuer keys, certificate store, audit trail integrity, and configuration files. Use `--fix` to auto-repair common issues.

## Development Install

To install from source for development:

```bash
git clone https://git.nomotic.ai/nomotic/nomotic.git
cd nomotic
pip install -e ".[dev]"
```

## Docker

The governance runtime runs in containers. The API server can be started with:

```bash
nomotic serve --host 0.0.0.0 --port 8420
```

Environment variables for container configuration:

| Variable | Default | Description |
|---|---|---|
| `NOMOTIC_HOST` | `127.0.0.1` | Bind address |
| `NOMOTIC_PORT` | `8420` | Server port |
| `NOMOTIC_DATA_DIR` | `~/.nomotic` | Data directory |
| `NOMOTIC_METRICS` | `false` | Enable Prometheus metrics |
| `NOMOTIC_LOG_LEVEL` | `INFO` | Log level |

## Telemetry

Nomotic includes opt-in anonymous telemetry that is **disabled by default**. No data is collected unless you explicitly enable it. See [Telemetry](/tools/telemetry) for details on what is collected and how to opt in.
