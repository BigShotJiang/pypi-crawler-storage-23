---
sidebar_position: 6
title: Claude SDK
---

# Claude SDK Integration

Govern Anthropic Claude API calls with Nomotic using `GovernedAgentBase`.

## Installation

```bash
pip install nomotic anthropic
```

## Pattern

Wrap Claude API calls with `governed_run()` to evaluate each tool use or generation against your governance policy before execution.

## Example

```python
import anthropic
from nomotic import GovernanceRuntime
from nomotic.governed_agent import GovernedAgentBase, GovernanceVetoError
from nomotic.authority import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.store import MemoryCertificateStore

# Set up Nomotic governance
runtime = GovernanceRuntime()
runtime.configure_scope(
    agent_id="claude-agent",
    scope={"read", "write", "query", "send"},
    boundaries={"customer/*", "internal/*"},
)

store = MemoryCertificateStore()
sk, _vk = SigningKey.generate()
ca = CertificateAuthority("local-issuer", sk, store)
cert, _ = ca.issue(
    agent_id="claude-agent",
    archetype="customer-experience",
    organization="acme-corp",
)

agent = GovernedAgentBase(runtime=runtime, certificate=cert)

# Set up Anthropic client
client = anthropic.Anthropic()


def governed_claude_call(
    prompt: str,
    action_type: str = "query",
    target: str = "internal/knowledge",
) -> str:
    """Make a governed Claude API call."""
    try:
        return agent.governed_run(
            action_type=action_type,
            target=target,
            execute_fn=lambda: client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            ).content[0].text,
        )
    except GovernanceVetoError as e:
        return f"[GOVERNANCE VETO] {e.verdict} (UCS: {e.ucs_score:.3f})"


# Use it
response = governed_claude_call(
    prompt="Summarize the customer's recent orders",
    action_type="read",
    target="customer/orders",
)
print(response)
```

## Tool Use with Governance

For Claude tool use, govern each tool execution:

```python
def handle_tool_use(tool_name: str, tool_input: dict) -> str:
    """Govern Claude tool use through Nomotic."""
    tool_fns = {
        "lookup_customer": lambda **kw: f"Customer: {kw.get('id')}",
        "update_record": lambda **kw: f"Updated: {kw.get('record_id')}",
    }

    if tool_name not in tool_fns:
        return f"Unknown tool: {tool_name}"

    try:
        return agent.governed_run(
            action_type=tool_name,
            target=tool_input.get("target", tool_name),
            parameters=tool_input,
            execute_fn=lambda: tool_fns[tool_name](**tool_input),
        )
    except GovernanceVetoError as e:
        return f"Tool '{tool_name}' denied: {e.verdict}"
```

Every Claude API call and tool execution is governed by Nomotic's 14-dimensional evaluation, with full audit trail coverage and trust score tracking.
