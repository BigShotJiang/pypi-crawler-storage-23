---
sidebar_position: 1
title: Integration Guides
---

# Integration Guides

Nomotic integrates with any AI agent framework through the `GovernedAgentBase` class. All integrations follow the same pattern:

1. **`govern_action()`** — evaluate the action before execution
2. **Execute** — run the action if governance allows it
3. **`validate_output()`** — validate the agent's output after generation

The `governed_run()` method combines all three steps into a single call.

## Available Integrations

| Framework | Guide | Pattern |
|---|---|---|
| [GovernedAgentBase](/guides/governed-agent-base) | Core governance wrapper | Base class for all integrations |
| [LangGraph](/guides/langgraph) | State graph with governed nodes | Governance as graph nodes with conditional edges |
| [CrewAI](/guides/crewai) | Governed crew tasks | Task wrapper with veto handling |
| [OpenAI](/guides/openai) | Function calling governance | Tool dispatch with governance gate |
| [Claude](/guides/claude) | Anthropic SDK integration | Governed API calls with output validation |

## Prerequisites

All integrations require:

```bash
pip install nomotic
```

Plus the framework-specific package (e.g., `langgraph`, `crewai`, `openai`, `anthropic`).

## Core Pattern

Every integration follows this structure:

```python
from nomotic import GovernanceRuntime
from nomotic.governed_agent import GovernedAgentBase

runtime = GovernanceRuntime()
# ... configure runtime with scope, rules, etc.

agent = GovernedAgentBase(runtime=runtime, certificate=cert)

# Option 1: Manual control
result = agent.govern_action("read", "customer/data")
if result.allowed:
    output = do_something()
    validation = agent.validate_output(output, action_type="read")

# Option 2: Full lifecycle
output = agent.governed_run(
    action_type="read",
    target="customer/data",
    execute_fn=lambda: do_something(),
)
```

Start with [GovernedAgentBase](/guides/governed-agent-base) to understand the core API, then see the framework-specific guides.
