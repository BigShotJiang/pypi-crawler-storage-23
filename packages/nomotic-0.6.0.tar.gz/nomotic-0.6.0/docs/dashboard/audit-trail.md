---
sidebar_position: 4
title: Audit Trail Viewer
---

# Audit Trail Viewer

The Audit Trail panel (F-12) provides a filterable, exportable, chain-verified view of all governance evaluation records.

## Features

- **Filtering** — by agent ID, verdict, archetype, date range
- **Pagination** — efficient browsing of large audit histories
- **Export** — CSV or JSON format for external analysis
- **Chain verification** — verify the hash chain integrity of any record

## Hash Chain

Every audit record includes a `record_hash` that links to the previous record's hash, creating a tamper-evident chain. If any record is modified or deleted, the chain breaks and verification fails.

Record hash format:
```
SHA-256(previous_hash + record_data)
```

## Filtering

| Filter | Parameter | Example |
|---|---|---|
| Agent | `agent_id` | `support-bot-001` |
| Verdict | `verdict` | `DENY` |
| Archetype | `archetype` | `healthcare-agent` |
| Date from | `date_from` | `2026-02-01` |
| Date to | `date_to` | `2026-02-28` |

## Export

```bash
# CSV export
curl "http://localhost:8420/v1/ui/audit/export?format=csv" > audit.csv

# JSON export
curl "http://localhost:8420/v1/ui/audit/export?format=json" > audit.json
```

## Chain Verification

Verify the integrity of any specific record:

```
POST /v1/ui/audit/verify/{record_id}
```

Response:
```json
{
  "record_id": "rec-abc123",
  "chain_valid": true,
  "records_verified": 47,
  "first_record": "rec-000001",
  "last_record": "rec-abc123"
}
```

## API

```
GET /v1/ui/audit?agent_id=&verdict=&archetype=&date_from=&date_to=&limit=&offset=
GET /v1/ui/audit/export?format=csv|json
POST /v1/ui/audit/verify/{record_id}
```
