---
sidebar_position: 6
title: Governance Playground
---

# Governance Playground

The Governance Playground (F-17) is an interactive sandbox for testing governance evaluations in real time. These are **real evaluations** through the actual UCS engine — not simulations.

## Starting the Playground

```bash
nomotic serve --ui --playground
```

The playground is available at `/ui/playground` when the `--playground` flag is set.

## Interface

### Configuration Panel

- **Archetype selector** — choose from all 22 built-in archetypes
- **Compliance preset** — select strict, standard, ultra_strict, hipaa_aligned, etc.
- **Dimension weight overrides** — adjust individual dimension weights
- **Trust level** — set the starting trust score for evaluation

### Evaluation Panel

- **Action type** — the action to evaluate (read, write, delete, etc.)
- **Target** — the resource being accessed
- **Parameters** — additional action parameters as JSON
- **Evaluate button** — run the evaluation and see results

### Results Panel

- **Verdict** — ALLOW, DENY, ESCALATE, MODIFY, or SUSPEND with color indicator
- **UCS Score** — 0.0–1.0 with visual gauge
- **Tier** — which tier made the decision (1=deterministic, 2=weighted, 3=deliberative)
- **Per-dimension scores** — all 14 dimension scores with weights
- **Veto dimensions** — which dimensions (if any) triggered a veto

### Export Config

Export the current playground configuration as a `nomotic.yaml` file:

```
POST /v1/playground/export-config
```

This generates a ready-to-use configuration file with the archetype, preset, and weight overrides you configured in the playground.

## API

```
POST /v1/playground/evaluate
GET  /v1/playground/archetypes
GET  /v1/playground/presets
POST /v1/playground/export-config
```

### Evaluate Request

```json
{
  "archetype": "healthcare-agent",
  "preset": "hipaa_aligned",
  "action_type": "read",
  "target": "patient/records",
  "trust_score": 0.7,
  "weight_overrides": {
    "ethical_alignment": 2.5
  }
}
```
