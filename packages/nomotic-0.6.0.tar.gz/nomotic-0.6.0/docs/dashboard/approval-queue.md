---
sidebar_position: 5
title: Approval Queue
---

# Approval Queue

The Approval Queue (F-05) handles actions that require human review — escalated verdicts, override requests, and multi-signature approvals.

## When Actions Escalate

Actions reach the approval queue when:
- The governance verdict is `ESCALATE` (UCS in the deliberation zone with low trust)
- A dimension flags the action for `human_override` review
- The action type is configured to require pre-approval
- An override is requested for a previously denied action

## Multi-Signature Approval

Critical actions can require approval from multiple authorized reviewers before proceeding:

```
POST /v1/overrides/pending/{id}/approve
```

The `cosign` subcommand supports multi-sig workflows where two or more reviewers must approve.

## Slack Integration

Enable Slack notifications for the approval queue:

```bash
pip install nomotic[slack]
```

Configure the Slack webhook in your governance config. Escalated actions post to a designated Slack channel with approve/deny buttons.

## Webhook Callbacks

Register webhooks to receive notifications when actions enter the queue:

```
POST /v1/overrides/{id}/callback
```

Webhook payloads include the action details, agent identity, UCS score, and a callback URL for programmatic approval.

```
POST /v1/slack/interaction
```

Handles Slack interactive message callbacks for in-channel approve/deny.

## API

```
GET  /v1/overrides/pending
GET  /v1/overrides/pending/{id}
POST /v1/overrides/pending/{id}/approve
POST /v1/overrides/pending/{id}/deny
GET  /v1/overrides/history
GET  /v1/overrides/pending/{id}/status
POST /v1/overrides/{id}/callback
POST /v1/slack/interaction
```

### Pending Action Response

```json
{
  "id": "ovr-abc123",
  "agent_id": "finance-bot-007",
  "action_type": "transfer",
  "target": "funds/external",
  "verdict": "ESCALATE",
  "ucs_score": 0.42,
  "submitted_at": "2026-02-28T14:30:00Z",
  "required_approvals": 2,
  "current_approvals": 1,
  "status": "pending"
}
```
