---
sidebar_position: 1
title: Governance Dashboard
---

# Governance Dashboard

The Nomotic governance dashboard provides real-time visibility into agent behavior, trust trajectories, drift alerts, and compliance status.

## Starting the Dashboard

```bash
nomotic serve --ui
```

Open [http://localhost:8420/ui](http://localhost:8420/ui) in your browser.

### Options

```bash
# Dashboard with governance playground
nomotic serve --ui --playground

# Dashboard with fleet simulation mode
nomotic serve --ui --sim-mode

# Custom host and port
nomotic serve --ui --host 0.0.0.0 --port 9000

# Enable Prometheus metrics
nomotic serve --ui --metrics
```

## Dashboard Panels

| Panel | Description | Docs |
|---|---|---|
| [Agent Roster](/dashboard/agent-roster) | Live agent status with trust scores and archetype filtering | F-10 |
| [Drift Alerts](/dashboard/drift-alerts) | Bidirectional drift detection for agents and reviewers | F-11 |
| [Audit Trail](/dashboard/audit-trail) | Filterable, exportable, chain-verified evaluation history | F-12 |
| [Approval Queue](/dashboard/approval-queue) | Escalated actions pending human review | F-05 |
| [Playground](/dashboard/playground) | Interactive governance evaluation sandbox | F-17 |
| [Config Editor](/dashboard/config-editor) | Visual nomotic.yaml configuration editor | F-14 |

## Real-Time Updates

The dashboard uses Server-Sent Events (SSE) via `GET /v1/ui/events` for real-time updates. Governance evaluations, trust score changes, and drift alerts appear instantly without polling.

## Snapshot Export

Export the current dashboard state as a self-contained HTML file or JSON snapshot:

```bash
# Via the dashboard UI export button, or via API:
curl http://localhost:8420/v1/ui/export?format=html > dashboard-snapshot.html
curl http://localhost:8420/v1/ui/export?format=json > dashboard-snapshot.json
```
