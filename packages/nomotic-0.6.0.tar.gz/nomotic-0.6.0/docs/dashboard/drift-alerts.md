---
sidebar_position: 3
title: Drift Alerts
---

# Drift Alert Surface

The Drift Alert panel (F-11) surfaces behavioral anomalies detected across both agents and human reviewers. This bidirectional detection is unique to Nomotic.

## Why Bidirectional?

**Agent drift** detects when an agent's behavioral patterns change from its established baseline — new action types, different targets, unusual timing.

**Human reviewer drift** detects when oversight patterns change — a reviewer who normally reviews 50 escalations per week suddenly drops to 5, or starts rubber-stamping approvals. This matters because degraded oversight is itself a governance risk.

## Alert Types

### Agent Behavioral Drift

Detected by `DriftMonitor`. Compares current behavior against the agent's behavioral fingerprint (built from archetype priors and accumulated history).

Dimensions tracked:
- **Action distribution** — shifts in the types of actions requested
- **Target distribution** — changes in which resources are accessed
- **Temporal patterns** — activity outside expected hours
- **Outcome patterns** — unusual deny/escalate rates

### Human Reviewer Drift

Detected by `HumanDriftMonitor`. Tracks reviewer engagement patterns:

- **Review frequency** — drops in review rate
- **Approval patterns** — rubber-stamping or excessive denial
- **Response time** — increasing delays in escalation handling
- **Coverage** — reviewers skipping certain agent types

## Severity Levels

| Severity | Threshold | Action |
|---|---|---|
| Low | Minor distribution shift | Informational — logged |
| Medium | Sustained pattern change | Dashboard alert |
| High | Significant behavioral divergence | Alert + notification |
| Critical | Extreme deviation | Alert + potential auto-escalation |

## Dismiss Workflow

Alerts can be dismissed after investigation:

```
POST /v1/ui/drift-alerts/{id}/dismiss
```

Dismissed alerts are retained in the audit trail for compliance review.

## API

```
GET /v1/ui/drift-alerts
POST /v1/ui/drift-alerts/{id}/dismiss
```
