---
sidebar_position: 7
title: Config Editor
---

# Visual Config Editor

The Visual Config Editor (F-14) provides a graphical interface for creating and editing `nomotic.yaml` configuration files.

## Access

Available at `/ui/config-editor` when the dashboard is running:

```bash
nomotic serve --ui
```

## Interface

The editor has three panels:

### 1. Agent Configuration Panel

Configure the core agent identity:
- Agent name
- Archetype selection (with descriptions)
- Organization
- Zone path
- Owner

### 2. Governance Configuration Panel

Tune governance parameters:
- Compliance preset selector
- Trust thresholds (low, high, interrupt)
- Per-dimension weight sliders (0.0–5.0)
- Budget gate settings
- Audit retention

### 3. Live YAML Preview

Real-time YAML output that updates as you change settings. The preview shows the complete `nomotic.yaml` that will be generated.

## Validation

The editor validates your configuration in real time:
- Required fields are highlighted if missing
- Weight values are clamped to valid ranges (0.0–5.0)
- Archetype and preset names are validated against the registry
- Invalid configurations show inline error messages

## Download

Click "Download" to save the generated `nomotic.yaml` file, or use the API:

```
POST /v1/ui/config/download
```

## API

```
GET  /v1/ui/config
POST /v1/ui/config/validate
POST /v1/ui/config/download
```
