---
sidebar_position: 2
title: Agent Roster
---

# Agent Live Status Panel

The Agent Roster panel (F-10) displays all governed agents with real-time trust scores, status indicators, and archetype information.

## Trust Score Colors

| Color | Trust Range | Meaning |
|---|---|---|
| Green | > 0.65 | High trust — fast-path evaluation |
| Amber | 0.35 – 0.65 | Deliberation zone — full evaluation |
| Red | < 0.35 | Low trust — escalation or denial likely |

## Features

- **Real-time trust scores** — updated after every governance evaluation
- **Archetype filtering** — filter agents by archetype to focus on specific categories
- **Trust trajectory** — visual sparkline showing trust score evolution over time
- **Status indicators** — ACTIVE, SUSPENDED, REVOKED certificate status
- **Evaluation counts** — total evaluations, denial rate, escalation rate per agent

## API

```
GET /v1/ui/agents
GET /v1/ui/agents?archetype=healthcare-agent
GET /v1/ui/agent/{agent_id}
GET /v1/ui/panels/agent-roster
```

### Query Parameters

| Parameter | Type | Description |
|---|---|---|
| `archetype` | string | Filter by archetype name |

### Response

```json
{
  "agents": [
    {
      "agent_id": "support-bot-001",
      "archetype": "customer-experience",
      "trust_score": 0.82,
      "status": "ACTIVE",
      "evaluations": 1247,
      "deny_rate": 0.03,
      "last_evaluation": "2026-02-28T10:15:00Z"
    }
  ]
}
```
