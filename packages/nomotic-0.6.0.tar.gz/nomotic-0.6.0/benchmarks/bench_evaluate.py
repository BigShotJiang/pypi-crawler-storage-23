"""Performance benchmarks for Nomotic governance evaluation.

Run: python -m benchmarks.bench_evaluate
Output: Markdown table of timings per operation.

Targets:
  - Full 14-dimension evaluation: <50ms
  - Tier-1 veto check: <10ms
  - Trust score update: <1ms
  - Audit record write: <5ms
  - GovernedToolExecutor round-trip: <60ms
"""

from __future__ import annotations

import shutil
import statistics
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.authority import CertificateAuthority
from nomotic.executor import GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.sandbox import AgentConfig, build_sandbox_runtime, save_agent_config
from nomotic.store import FileCertificateStore
from nomotic.types import Action, AgentContext, TrustProfile


def bench(fn: Callable[[], Any], iterations: int = 1000, warmup: int = 100) -> dict[str, float]:
    """Run a function many times and collect timing stats."""
    for _ in range(warmup):
        fn()

    times: list[float] = []
    for _ in range(iterations):
        start = time.perf_counter_ns()
        fn()
        elapsed_ns = time.perf_counter_ns() - start
        times.append(elapsed_ns / 1_000_000)  # convert to ms

    sorted_times = sorted(times)
    return {
        "p50": statistics.median(times),
        "p95": sorted_times[int(len(times) * 0.95)],
        "p99": sorted_times[int(len(times) * 0.99)],
        "mean": statistics.mean(times),
        "min": min(times),
        "max": max(times),
        "stdev": statistics.stdev(times) if len(times) > 1 else 0,
    }


def _setup_agent(base_dir: Path, agent_id: str = "bench-agent") -> None:
    """Create a certificate and config for a benchmark agent."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(base_dir)
    ca = CertificateAuthority(issuer_id="bench-issuer", signing_key=sk, store=store)
    ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="bench-org",
        zone_path="global",
        owner="bench-owner",
    )
    config = AgentConfig(
        agent_id=agent_id,
        actions=["read", "write", "query", "update", "create"],
        boundaries=["customers", "orders", "benchmark_table"],
    )
    save_agent_config(base_dir, config)


def bench_full_evaluation(runtime: GovernanceRuntime, action: Action, context: AgentContext) -> dict[str, float]:
    """Benchmark: Full 14-dimension evaluation."""
    return bench(lambda: runtime.evaluate(action, context))


def bench_trust_update(trust_profile: TrustProfile) -> dict[str, float]:
    """Benchmark: Trust score adjustment (in-memory)."""
    def adjust() -> None:
        trust_profile.overall_trust = min(1.0, trust_profile.overall_trust + 0.001)
        if trust_profile.overall_trust >= 0.99:
            trust_profile.overall_trust = 0.5

    return bench(adjust, iterations=10000)


def bench_audit_write(store: LogStore, agent_id: str) -> dict[str, float]:
    """Benchmark: Audit record append (file I/O)."""
    counter = [0]

    def write_one() -> None:
        counter[0] += 1
        record_data = {
            "record_id": f"bench-{counter[0]:06d}",
            "timestamp": time.time(),
            "agent_id": agent_id,
            "action_type": "read",
            "action_target": "test",
            "verdict": "ALLOW",
            "ucs": 0.85,
            "tier": 2,
            "trust_score": 0.5,
            "trust_delta": 0.01,
            "trust_trend": "rising",
            "severity": "info",
            "justification": "Benchmark record",
            "vetoed_by": [],
            "dimension_scores": {},
            "parameters": {"iteration": counter[0]},
            "source": "benchmark",
            "previous_hash": "",
            "record_hash": "",
        }
        previous_hash = store.get_last_hash(agent_id)
        record_data["previous_hash"] = previous_hash
        record_data["record_hash"] = store.compute_hash(record_data, previous_hash)
        store.append(PersistentLogRecord(**record_data))

    return bench(write_one, iterations=500)


def bench_executor_roundtrip(executor: GovernedToolExecutor) -> dict[str, float]:
    """Benchmark: Full GovernedToolExecutor.execute() including tool call and audit."""
    return bench(
        lambda: executor.execute(
            action="read",
            target="benchmark_table",
            tool_fn=lambda: {"rows": 10},
        ),
        iterations=500,
    )


def bench_check_only(executor: GovernedToolExecutor) -> dict[str, float]:
    """Benchmark: GovernedToolExecutor.check() — governance without execution."""
    return bench(
        lambda: executor.check(action="read", target="benchmark_table"),
        iterations=1000,
    )


def bench_veto_tier(runtime: GovernanceRuntime, agent_id: str) -> dict[str, float]:
    """Benchmark: Tier-1 veto-only evaluation (fastest path).

    Submit an action that is out of configured scope to trigger a veto.
    """
    action = Action(agent_id=agent_id, action_type="launch_missiles", target="pentagon")
    context = AgentContext(
        agent_id=agent_id,
        trust_profile=TrustProfile(agent_id=agent_id, overall_trust=0.5),
    )
    return bench(lambda: runtime.evaluate(action, context))


def format_results(results: dict[str, dict[str, float]]) -> str:
    """Format benchmark results as a Markdown table."""
    lines = [
        "| Benchmark | p50 (ms) | p95 (ms) | p99 (ms) | mean (ms) | stdev |",
        "|-----------|----------|----------|----------|-----------|-------|",
    ]
    for name, stats in results.items():
        lines.append(
            f"| {name} | {stats['p50']:.2f} | {stats['p95']:.2f} | "
            f"{stats['p99']:.2f} | {stats['mean']:.2f} | {stats['stdev']:.2f} |"
        )
    return "\n".join(lines)


def main() -> None:
    """Run all benchmarks and print results."""
    print("Nomotic Performance Benchmarks")
    print("=" * 60)
    print()

    tmp = Path(tempfile.mkdtemp())
    results: dict[str, dict[str, float]] = {}

    try:
        # Setup: create an agent for benchmarks
        agent_id = "bench-agent"
        _setup_agent(tmp, agent_id)

        # Build runtime
        config = AgentConfig(
            agent_id=agent_id,
            actions=["read", "write", "query", "update", "create"],
            boundaries=["customers", "orders", "benchmark_table"],
        )
        runtime = build_sandbox_runtime(
            agent_config=config,
            agent_id=agent_id,
            base_dir=tmp,
        )

        # Standard action and context
        action = Action(agent_id=agent_id, action_type="read", target="customers")
        context = AgentContext(
            agent_id=agent_id,
            trust_profile=TrustProfile(agent_id=agent_id, overall_trust=0.5),
        )

        print("Running: Full 14-dimension evaluation...")
        results["Full evaluation (14 dims)"] = bench_full_evaluation(runtime, action, context)

        print("Running: Veto-tier evaluation...")
        results["Veto tier (fast path)"] = bench_veto_tier(runtime, agent_id)

        print("Running: Trust score update...")
        trust = TrustProfile(agent_id=agent_id, overall_trust=0.5)
        results["Trust update"] = bench_trust_update(trust)

        print("Running: Audit record write...")
        store = LogStore(tmp, "benchmark-audit")
        results["Audit write (file I/O)"] = bench_audit_write(store, agent_id)

        print("Running: Executor check (governance only)...")
        executor = GovernedToolExecutor.connect(agent_id, base_dir=tmp, test_mode=True)
        results["Executor check()"] = bench_check_only(executor)

        print("Running: Executor round-trip (eval + tool + audit)...")
        results["Executor execute() round-trip"] = bench_executor_roundtrip(executor)

        print()
        print(format_results(results))
        print()

        # Performance assertions
        print("Performance Targets:")
        full_p95 = results["Full evaluation (13 dims)"]["p95"]
        veto_p95 = results["Veto tier (fast path)"]["p95"]
        exec_p95 = results["Executor execute() round-trip"]["p95"]

        checks = [
            ("Full evaluation p95 < 50ms", full_p95, 50),
            ("Veto tier p95 < 10ms", veto_p95, 10),
            ("Executor round-trip p95 < 60ms", exec_p95, 60),
        ]

        all_passed = True
        for label, value, target in checks:
            passed = value < target
            status = "PASS" if passed else "FAIL"
            print(f"  {status}: {label} (actual: {value:.2f}ms)")
            if not passed:
                all_passed = False

        if not all_passed:
            print("\nSome performance targets were not met.")
        else:
            print("\nAll performance targets met.")

    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
