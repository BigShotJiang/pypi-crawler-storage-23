"""Async performance benchmarks — concurrent multi-agent evaluation.

Measures the throughput benefit of AsyncGovernedToolExecutor when multiple
agents evaluate actions simultaneously.

Run: python -m benchmarks.bench_async
"""

from __future__ import annotations

import asyncio
import shutil
import tempfile
import time
from pathlib import Path

from nomotic.async_executor import AsyncGovernedToolExecutor
from nomotic.authority import CertificateAuthority
from nomotic.executor import GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(base_dir: Path, agent_id: str) -> None:
    """Create a certificate and config for an agent."""
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(base_dir)
    ca = CertificateAuthority(issuer_id="bench-issuer", signing_key=sk, store=store)
    ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="bench-org",
        zone_path="global",
        owner="bench-owner",
    )
    config = AgentConfig(
        agent_id=agent_id,
        actions=["read", "write", "query"],
        boundaries=["customers", "orders"],
    )
    save_agent_config(base_dir, config)


async def bench_concurrent_agents(
    num_agents: int,
    actions_per_agent: int,
    base_dir: Path,
) -> dict[str, float]:
    """Benchmark N agents evaluating M actions concurrently."""
    executors: list[AsyncGovernedToolExecutor] = []
    for i in range(num_agents):
        name = f"async-agent-{i}"
        _setup_agent(base_dir, name)
        executor = await AsyncGovernedToolExecutor.connect(
            name, base_dir=base_dir, test_mode=True
        )
        executors.append(executor)

    start = time.perf_counter()

    async def agent_workload(executor: AsyncGovernedToolExecutor) -> None:
        for j in range(actions_per_agent):
            await executor.execute(
                action="read",
                target=f"table_{j}",
                tool_fn=lambda: {"rows": 10},
            )

    await asyncio.gather(*[agent_workload(e) for e in executors])

    elapsed = time.perf_counter() - start
    total_actions = num_agents * actions_per_agent

    return {
        "agents": num_agents,
        "actions_per_agent": actions_per_agent,
        "total_actions": total_actions,
        "elapsed_seconds": elapsed,
        "actions_per_second": total_actions / elapsed if elapsed > 0 else 0,
        "ms_per_action": (elapsed * 1000) / total_actions if total_actions > 0 else 0,
    }


def bench_serial_agents(
    num_agents: int,
    actions_per_agent: int,
    base_dir: Path,
) -> dict[str, float]:
    """Benchmark N agents evaluating M actions serially (sync baseline)."""
    executors: list[GovernedToolExecutor] = []
    for i in range(num_agents):
        name = f"sync-agent-{i}"
        _setup_agent(base_dir, name)
        executor = GovernedToolExecutor.connect(
            name, base_dir=base_dir, test_mode=True
        )
        executors.append(executor)

    start = time.perf_counter()

    for executor in executors:
        for j in range(actions_per_agent):
            executor.execute(
                action="read",
                target=f"table_{j}",
                tool_fn=lambda: {"rows": 10},
            )

    elapsed = time.perf_counter() - start
    total_actions = num_agents * actions_per_agent

    return {
        "agents": num_agents,
        "actions_per_agent": actions_per_agent,
        "total_actions": total_actions,
        "elapsed_seconds": elapsed,
        "actions_per_second": total_actions / elapsed if elapsed > 0 else 0,
        "ms_per_action": (elapsed * 1000) / total_actions if total_actions > 0 else 0,
    }


async def main() -> None:
    print("Nomotic Async Performance Benchmarks")
    print("=" * 60)
    print()

    tmp = Path(tempfile.mkdtemp())

    try:
        configs = [
            (1, 50),   # Single agent, many actions
            (5, 10),   # 5 concurrent agents
            (10, 5),   # 10 concurrent agents
        ]

        print("| Agents | Actions/Agent | Total | Sync (act/s) | Async (act/s) | Speedup |")
        print("|--------|---------------|-------|--------------|---------------|---------|")

        for num_agents, actions_per in configs:
            sync_result = bench_serial_agents(num_agents, actions_per, tmp)
            async_result = await bench_concurrent_agents(num_agents, actions_per, tmp)

            sync_aps = sync_result["actions_per_second"]
            async_aps = async_result["actions_per_second"]
            speedup = async_aps / sync_aps if sync_aps > 0 else 0

            print(
                f"| {num_agents:>6} | {actions_per:>13} | {num_agents * actions_per:>5} | "
                f"{sync_aps:>12.1f} | "
                f"{async_aps:>13.1f} | "
                f"{speedup:>6.2f}x |"
            )

        print()
        print("Speedup should increase with more concurrent agents (I/O parallelism).")

    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    asyncio.run(main())
