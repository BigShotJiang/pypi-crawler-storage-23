// Streaming APIs like WatchIPNBus, TailDaemonLogs, StreamDebugCapture
// require long-lived HTTP connections. These stubs define the method
// signatures; full streaming support requires lower-level hyper usage.

// Note: Full streaming implementation is tracked separately.
