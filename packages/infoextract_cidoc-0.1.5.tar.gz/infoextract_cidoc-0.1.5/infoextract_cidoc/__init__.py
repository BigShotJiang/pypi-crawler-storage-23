"""infoextract-cidoc - AI-powered CIDOC CRM information extraction."""

__version__ = "0.1.5"
