# COLLIE Workflow Summary

## Input Text


Albert Einstein was born on March 14, 1879, in Ulm, Württemberg, Germany. He grew up in a secular Jewish family. His father, Hermann Einstein, was a salesman and engineer who, with his brother, found...

## Extraction Results

- Entities extracted: 87
- Relationships extracted: 0

## Network Analysis

- Nodes: 87
- Edges: 0
- Density: 0.000
- Communities: 0

## Output Files

- Canonical JSON: notebook_output/canonical_entities.json
- Markdown reports: notebook_output/markdown
- Network plots: notebook_output/plots
- Cypher script: notebook_output/network.cypher
