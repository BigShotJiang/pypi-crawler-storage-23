### E21 · Person · said she · (d2dc38f9...)

- **Label** (`label`): said she
- **Type** (`type`): ['E21']
- **Notes**: Person mentioned in context: a neuropathologist at the Children's Hospital of Philadelphia, and put them on display. Rorke-Adams said she received the brain slides from Harvey.