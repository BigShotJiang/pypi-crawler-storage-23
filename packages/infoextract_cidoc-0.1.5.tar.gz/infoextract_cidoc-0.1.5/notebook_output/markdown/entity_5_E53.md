### E53 · Place · Munich · (9d34e357...)

- **Label** (`label`): Munich
- **Type** (`type`): ['E53']
- **Notes**: Place mentioned in context: ded Elektrotechnische Fabrik J. Einstein & Cie, a Munich-based company that mass-produced electrical equip