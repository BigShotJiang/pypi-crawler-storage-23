### E21 · Person · Albert Einstein · (797b5fe7...)

- **Label** (`label`): Albert Einstein
- **Type** (`type`): ['E21']
- **Notes**: Person mentioned in context: Albert Einstein was born on March 14, 1879, in Ulm, Württemberg, Germany. He grew up in a secular Jewish family. His father,