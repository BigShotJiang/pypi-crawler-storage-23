### E53 · Place · Ulm · (64502329...)

- **Label** (`label`): Ulm
- **Type** (`type`): ['E53']
- **Notes**: Place mentioned in context: Albert Einstein was born on March 14, 1879, in Ulm, Württemberg, Germany. He grew up in a secular Je