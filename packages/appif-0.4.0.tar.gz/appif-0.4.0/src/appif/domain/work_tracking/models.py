"""Canonical work tracking domain models.

These types are platform-agnostic. No Jira field names, GitHub API
conventions, or Linear-specific concepts appear here. Every work item --
Jira, GitHub Issues, Linear, or any future platform -- arrives in this
shape. No platform SDK types appear here.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum

# ---------------------------------------------------------------------------
# Link types
# ---------------------------------------------------------------------------


class LinkType(Enum):
    """Normalized relationship types between work items."""

    BLOCKS = "blocks"
    BLOCKED_BY = "blocked_by"
    RELATES_TO = "relates_to"
    DUPLICATES = "duplicates"
    DUPLICATED_BY = "duplicated_by"
    PARENT_OF = "parent_of"
    CHILD_OF = "child_of"


# ---------------------------------------------------------------------------
# People
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemAuthor:
    """A person associated with a work item (assignee, reporter, commenter)."""

    id: str
    display_name: str


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemComment:
    """A comment on a work item."""

    id: str
    author: ItemAuthor
    body: str
    created: datetime


# ---------------------------------------------------------------------------
# Links
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemLink:
    """A typed relationship from this item to another."""

    link_type: LinkType
    target_key: str


# ---------------------------------------------------------------------------
# Work item
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WorkItem:
    """Normalized representation of a tracked work item."""

    key: str
    id: str
    title: str
    description: str
    status: str
    item_type: str
    created: datetime
    updated: datetime
    priority: str | None = None
    labels: tuple[str, ...] = ()
    assignee: ItemAuthor | None = None
    reporter: ItemAuthor | None = None
    parent_key: str | None = None
    sub_item_keys: tuple[str, ...] = ()
    links: tuple[ItemLink, ...] = ()
    comments: tuple[ItemComment, ...] = ()


# ---------------------------------------------------------------------------
# Creation
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemIdentifier:
    """Identifier returned after item creation."""

    key: str
    id: str


@dataclass(frozen=True)
class CreateItemRequest:
    """Input for creating a new work item.

    Not a domain entity -- a command object.
    """

    project: str
    title: str
    item_type: str
    description: str = ""
    parent_key: str | None = None
    labels: tuple[str, ...] = ()
    priority: str | None = None
    assignee_id: str | None = None


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TransitionInfo:
    """An available workflow transition for a work item."""

    id: str
    name: str


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SearchCriteria:
    """Structured search parameters for work items."""

    project: str | None = None
    status: str | None = None
    assignee_id: str | None = None
    labels: tuple[str, ...] = ()
    query: str | None = None


@dataclass(frozen=True)
class SearchResult:
    """Paginated search response."""

    items: tuple[WorkItem, ...] = ()
    total: int = 0
    offset: int = 0
    limit: int = 50


# ---------------------------------------------------------------------------
# Issue type discovery
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IssueTypeInfo:
    """Metadata about an issue type available in a project."""

    name: str
    subtask: bool
    description: str = ""


# ---------------------------------------------------------------------------
# Link type discovery
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LinkTypeInfo:
    """Metadata about a link type available in the platform."""

    name: str
    inward: str
    outward: str


# ---------------------------------------------------------------------------
# Instance registry
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstanceInfo:
    """Metadata about a registered platform instance."""

    name: str
    platform: str
    server_url: str
    is_default: bool = False
