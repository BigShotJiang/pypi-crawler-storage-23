"""Jira adapter for the work tracking domain."""

from appif.adapters.jira.adapter import JiraAdapter

__all__ = ["JiraAdapter"]
