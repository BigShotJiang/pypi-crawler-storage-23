"""Unit tests for Slack event → MessageEvent normalizer."""

from datetime import UTC, datetime

from appif.adapters.slack._normalizer import _slack_ts_to_datetime, normalize_message
from appif.domain.messaging.models import Identity


def _make_identity(user_id: str) -> Identity:
    """Fake user resolver."""
    return Identity(id=user_id, display_name=f"User-{user_id}", connector="slack")


class TestNormalizeChannelMessage:
    def test_basic_channel_message(self):
        event = {
            "client_msg_id": "msg-abc",
            "user": "U123",
            "text": "Hello world",
            "ts": "1708257600.000100",
            "channel": "C456",
            "channel_type": "channel",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.message_id == "msg-abc"
        assert result.connector == "slack"
        assert result.account_id == "T001"
        assert result.content.text == "Hello world"
        assert result.author.id == "U123"
        assert result.author.display_name == "User-U123"
        assert result.conversation_ref.type == "channel"
        assert result.conversation_ref.opaque_id == {"channel": "C456"}
        assert result.conversation_ref.connector == "slack"
        assert result.conversation_ref.account_id == "T001"

    def test_falls_back_to_ts_for_message_id(self):
        event = {
            "user": "U123",
            "text": "No client_msg_id",
            "ts": "1708257600.000200",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.message_id == "1708257600.000200"


class TestNormalizeDmMessage:
    def test_dm_message(self):
        event = {
            "user": "U123",
            "text": "Private message",
            "ts": "1708257600.000300",
            "channel": "D789",
            "channel_type": "im",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.conversation_ref.type == "dm"
        assert result.conversation_ref.opaque_id == {"channel": "D789"}


class TestNormalizeThreadReply:
    def test_thread_reply(self):
        event = {
            "user": "U123",
            "text": "Thread reply",
            "ts": "1708257610.000100",
            "thread_ts": "1708257600.000100",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.conversation_ref.type == "thread"
        assert result.conversation_ref.opaque_id == {"channel": "C456", "thread_ts": "1708257600.000100"}
        assert result.metadata.get("thread_ts") == "1708257600.000100"

    def test_parent_message_with_thread_ts_equal_to_ts(self):
        """Parent message in a thread has thread_ts == ts, should be 'channel'."""
        event = {
            "user": "U123",
            "text": "I started a thread",
            "ts": "1708257600.000100",
            "thread_ts": "1708257600.000100",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.conversation_ref.type == "channel"


class TestFilterBotOwnMessages:
    def test_filters_own_user_id(self):
        event = {
            "user": "UBOT",
            "text": "I said something",
            "ts": "1708257600.000400",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)
        assert result is None

    def test_filters_own_bot_id(self):
        event = {
            "bot_id": "UBOT",
            "text": "Bot echo",
            "ts": "1708257600.000500",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)
        assert result is None


class TestFilterSubtypes:
    def test_filters_channel_join(self):
        event = {
            "user": "U123",
            "subtype": "channel_join",
            "text": "joined",
            "ts": "1708257600.000600",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)
        assert result is None

    def test_allows_bot_message_subtype(self):
        event = {
            "bot_id": "B999",
            "subtype": "bot_message",
            "username": "webhook-bot",
            "text": "External bot says hi",
            "ts": "1708257600.000700",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)
        assert result is not None
        assert result.author.id == "B999"
        assert result.author.display_name == "webhook-bot"
        assert result.metadata.get("subtype") == "bot_message"


class TestEditedMessages:
    def test_edited_message_metadata(self):
        event = {
            "user": "U123",
            "text": "Updated text",
            "ts": "1708257600.000800",
            "channel": "C456",
            "edited": {"user": "U123", "ts": "1708257610.000000"},
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert result.metadata.get("edited") is True
        assert result.metadata.get("edited_ts") == "1708257610.000000"


class TestFileShares:
    def test_message_with_files(self):
        event = {
            "user": "U123",
            "text": "Check this file",
            "ts": "1708257600.000900",
            "channel": "C456",
            "files": [
                {
                    "id": "F001",
                    "name": "report.pdf",
                    "mimetype": "application/pdf",
                    "url_private": "https://files.slack.com/report.pdf",
                }
            ],
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)

        assert result is not None
        assert len(result.content.attachments) == 1
        assert result.content.attachments[0]["name"] == "report.pdf"
        assert result.content.attachments[0]["mimetype"] == "application/pdf"


class TestNoAuthor:
    def test_no_user_no_bot_id(self):
        event = {
            "text": "Ghost message",
            "ts": "1708257600.001000",
            "channel": "C456",
        }
        result = normalize_message(event, team_id="T001", bot_user_id="UBOT", resolve_user=_make_identity)
        assert result is None


class TestTimestampConversion:
    def test_valid_timestamp(self):
        dt = _slack_ts_to_datetime("1708257600.000100")
        assert isinstance(dt, datetime)
        assert dt.tzinfo == UTC
        assert dt.year == 2024

    def test_invalid_timestamp(self):
        dt = _slack_ts_to_datetime("not-a-number")
        assert isinstance(dt, datetime)
        assert dt.tzinfo == UTC

    def test_zero_timestamp(self):
        dt = _slack_ts_to_datetime("0")
        assert isinstance(dt, datetime)
        assert dt.year == 1970
