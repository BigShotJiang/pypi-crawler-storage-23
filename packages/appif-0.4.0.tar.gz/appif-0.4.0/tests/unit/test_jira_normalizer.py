"""Unit tests for Jira normalizer functions."""

from appif.adapters.jira._normalizer import (
    normalize_issue_type,
    normalize_link_type_info,
)
from appif.domain.work_tracking.models import IssueTypeInfo, LinkTypeInfo

# ---------------------------------------------------------------------------
# normalize_issue_type
# ---------------------------------------------------------------------------


class TestNormalizeIssueType:
    def test_standard_type(self):
        raw = {"name": "Task", "subtask": False, "description": "A regular task"}
        result = normalize_issue_type(raw)
        assert result == IssueTypeInfo(name="Task", subtask=False, description="A regular task")

    def test_subtask_type(self):
        raw = {"name": "Sub-task", "subtask": True, "description": "A subtask"}
        result = normalize_issue_type(raw)
        assert result == IssueTypeInfo(name="Sub-task", subtask=True, description="A subtask")

    def test_missing_fields_use_defaults(self):
        raw = {}
        result = normalize_issue_type(raw)
        assert result == IssueTypeInfo(name="", subtask=False, description="")

    def test_extra_fields_ignored(self):
        raw = {"name": "Epic", "subtask": False, "description": "", "id": "10000", "iconUrl": "http://..."}
        result = normalize_issue_type(raw)
        assert result.name == "Epic"
        assert result.subtask is False

    def test_subtask_truthy_values(self):
        """Jira may return subtask as various truthy values."""
        for val in (True, 1, "yes"):
            raw = {"name": "Sub-task", "subtask": val}
            result = normalize_issue_type(raw)
            assert result.subtask is True


# ---------------------------------------------------------------------------
# normalize_link_type_info
# ---------------------------------------------------------------------------


class TestNormalizeLinkTypeInfo:
    def test_blocks_link_type(self):
        raw = {"name": "Blocks", "inward": "is blocked by", "outward": "blocks"}
        result = normalize_link_type_info(raw)
        assert result == LinkTypeInfo(name="Blocks", inward="is blocked by", outward="blocks")

    def test_relates_link_type(self):
        raw = {"name": "Relates", "inward": "relates to", "outward": "relates to"}
        result = normalize_link_type_info(raw)
        assert result == LinkTypeInfo(name="Relates", inward="relates to", outward="relates to")

    def test_duplicate_link_type(self):
        raw = {"name": "Duplicate", "inward": "is duplicated by", "outward": "duplicates"}
        result = normalize_link_type_info(raw)
        assert result.name == "Duplicate"
        assert result.inward == "is duplicated by"
        assert result.outward == "duplicates"

    def test_missing_fields_use_defaults(self):
        raw = {}
        result = normalize_link_type_info(raw)
        assert result == LinkTypeInfo(name="", inward="", outward="")

    def test_extra_fields_ignored(self):
        raw = {"name": "Cloners", "inward": "is cloned by", "outward": "clones", "id": "10001", "self": "http://..."}
        result = normalize_link_type_info(raw)
        assert result.name == "Cloners"
        assert result.inward == "is cloned by"
        assert result.outward == "clones"
