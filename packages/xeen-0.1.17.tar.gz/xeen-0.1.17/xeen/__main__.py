"""Allow running as: python -m xeen"""
from xeen.cli import main

main()
