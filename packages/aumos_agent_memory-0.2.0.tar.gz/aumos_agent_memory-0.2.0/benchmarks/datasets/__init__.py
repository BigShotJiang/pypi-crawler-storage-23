"""Synthetic datasets for agent-memory benchmarks."""
