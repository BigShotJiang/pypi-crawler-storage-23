"""Integration adapters for agent-memory.

Optional third-party integrations. Install extras to enable:

    pip install aumos-agent-memory[mem0]
"""
