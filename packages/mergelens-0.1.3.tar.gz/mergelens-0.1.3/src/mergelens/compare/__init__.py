"""Model comparison module — layer-by-layer weight analysis."""

from mergelens.compare.analyzer import compare_models

__all__ = ["compare_models"]
