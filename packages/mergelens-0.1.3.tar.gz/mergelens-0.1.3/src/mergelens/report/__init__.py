"""Report generation module."""

from mergelens.report.generator import generate_report

__all__ = ["generate_report"]
