"""MCP server for AI assistant integration."""
