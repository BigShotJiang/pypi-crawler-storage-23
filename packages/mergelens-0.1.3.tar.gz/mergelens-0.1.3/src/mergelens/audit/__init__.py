"""Model capability auditing module (requires mergelens[audit])."""
