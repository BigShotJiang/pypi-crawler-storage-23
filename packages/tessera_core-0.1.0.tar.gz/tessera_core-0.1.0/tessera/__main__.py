"""Allow running tessera as: python -m tessera"""

from tessera.cli import main

main()
