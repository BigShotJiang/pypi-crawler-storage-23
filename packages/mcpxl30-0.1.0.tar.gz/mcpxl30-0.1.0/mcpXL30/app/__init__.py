"""Application entrypoints for the mcpXL30 server."""
