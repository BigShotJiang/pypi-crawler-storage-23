"""Configuration helpers for mcpXL30."""
