# utils/__init__.py
# Makes the 'utils' folder a Python package.
# Import schemas like: from mcpserver.utils.schemas import ScriptInput
