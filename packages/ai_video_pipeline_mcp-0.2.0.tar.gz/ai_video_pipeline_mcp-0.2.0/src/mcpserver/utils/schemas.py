"""
utils/schemas.py
─────────────────────────────────────────────────────────
PURPOSE:
    Pydantic data models (schemas) for every tool's input and output.
    Pydantic validates data automatically — if you pass the wrong type
    (e.g. a string where an int is expected) it raises a clear error
    message instead of crashing deep in the code.

WHAT IS PYDANTIC?
    Think of it as a "form template" for your data. You define fields
    and their types, and Pydantic makes sure the data matches before
    your code runs.

HOW TO USE:
    from utils.schemas import ScriptInput, ScriptOutput
    validated = ScriptInput(topic="Bubble Sort", duration_minutes=10, ...)
─────────────────────────────────────────────────────────
"""

from pydantic import BaseModel, Field
from typing import List, Optional


# ─────────────────────────────────────────────────────────
# TOOL 1 — Script Generator
# ─────────────────────────────────────────────────────────

class ScriptInput(BaseModel):
    """
    What you send to the Script Generator tool.
    All fields map directly to what Claude will ask you to fill in.
    """
    topic: str = Field(
        ...,
        description="The subject of the video. E.g. 'Dijkstra's Algorithm'",
        example="Dijkstra's Shortest Path Algorithm",
    )
    tagline: str = Field(
        ...,
        description="One punchy sentence that hooks the viewer.",
        example="How GPS finds the fastest route — and why it's beautiful.",
    )
    gist: str = Field(
        ...,
        description=(
            "2-5 sentences explaining the core idea, the problem it solves, "
            "and what makes it interesting. No jargon."
        ),
        example=(
            "Dijkstra's algorithm finds the cheapest path through a graph. "
            "It's used in GPS, internet routing, and game AI. "
            "The key insight is greedily always expanding the cheapest frontier."
        ),
    )
    duration_minutes: int = Field(
        default=10,
        ge=3,
        le=30,
        description="Target video length in minutes.",
    )
    style_reference_scripts: Optional[List[str]] = Field(
        default=[],
        description=(
            "Optional list of past script excerpts to match tone and voice. "
            "Paste 1-3 examples. Leave empty on first use."
        ),
    )
    visual_metaphor_hints: Optional[str] = Field(
        default="",
        description=(
            "Optional rough ideas for cinematic metaphors or visual scenes. "
            "E.g. 'maybe a factory where the bad output causes blame to ripple backward'. "
            "These are just sparks — the model can ignore or riff on them freely."
        ),
    )


class ScriptOutput(BaseModel):
    """
    What the Script Generator returns.
    Parse this from the JSON string the tool produces.
    """
    title: str = Field(description="Final video title.")
    final_script: str = Field(
        description=(
            "Full narration script, ready to read aloud. "
            "Contains inline [VISUAL: ...] cues for the scene planner."
        )
    )
    key_equations: List[str] = Field(
        description="LaTeX equations mentioned in the script. Empty list if none."
    )
    metaphors_used: List[str] = Field(
        description="List of metaphors or analogies used in the script."
    )


# ─────────────────────────────────────────────────────────
# TOOL 2 — Scene Planner
# ─────────────────────────────────────────────────────────

class ScenePlannerInput(BaseModel):
    """What you send to the Scene Planner tool."""
    timestamped_transcript: str = Field(
        ...,
        description=(
            "Full transcript exported from Premiere Pro with timestamps.\n"
            "Format each line as: [HH:MM:SS] spoken words...\n"
            "Example:\n  [00:00:00] Welcome to this video about graphs.\n"
            "  [00:00:12] Imagine you're driving across a city..."
        ),
    )
    preferred_avg_scene_length_seconds: int = Field(
        default=10,
        ge=5,
        le=30,
        description="Ideal seconds per visual scene. 8-12 is recommended for retention.",
    )
    visual_style: str = Field(
        default="cinematic hand drawn digital painting",
        description="Consistent art direction applied to all image scenes.",
    )
    allow_python_animation: bool = Field(
        default=True,
        description=(
            "If True, the planner may mark scenes as 'animation' type "
            "when equations or motion are needed. "
            "If False, everything becomes an image scene."
        ),
    )


class Scene(BaseModel):
    """A single planned scene in the video."""
    scene_number: int = Field(description="Sequential scene index starting at 1.")
    start: str = Field(description="Timestamp when this scene starts. Format: HH:MM:SS")
    end: str = Field(description="Timestamp when this scene ends. Format: HH:MM:SS")
    description: str = Field(
        description="What should be shown visually. Specific and grounded in the transcript."
    )
    type: str = Field(
        description=(
            "'image' for cinematic illustration scenes (most scenes), "
            "'animation' for scenes requiring equations, text overlay, or true motion."
        )
    )


class ScenePlannerOutput(BaseModel):
    """What the Scene Planner returns — a list of scenes."""
    scenes: List[Scene]


# ─────────────────────────────────────────────────────────
# TOOL 3 — Image Prompt Generator
# ─────────────────────────────────────────────────────────

class ImagePromptInput(BaseModel):
    """What you send to the Image Prompt Generator tool."""
    scene_description: str = Field(
        ...,
        description="The cinematic visual description from the scene planner output.",
    )
    audio_context: Optional[str] = Field(
        default="",
        description=(
            "Optional: paste the narrator's words spoken during this scene. "
            "Helps the model anchor the image to the exact emotional/conceptual moment in the audio."
        ),
    )
    visual_style: str = Field(
        default="hand-drawn digital painting, Procreate style, cinematic, painterly",
        description="Art style directive. Keep this identical across all scenes for visual consistency.",
    )
    aspect_ratio: str = Field(
        default="16:9",
        description="Target aspect ratio. Use '16:9' for widescreen YouTube videos.",
    )
    lighting: str = Field(
        default="moody",
        description="Lighting mood. Options: moody, golden hour, firelight, cool moonlight, bright overcast.",
    )


class ImagePromptOutput(BaseModel):
    """What the Image Prompt Generator returns."""
    prompt: str = Field(
        description="A single polished image generation prompt. Paste this into Whisk or any AI image tool."
    )
    negative_prompt: str = Field(
        description="What to exclude. Paste into the 'negative prompt' field if available."
    )


# ─────────────────────────────────────────────────────────
# TOOL 4 — Cinematic Video Compositor
# ─────────────────────────────────────────────────────────

class VideoCompositorInput(BaseModel):
    """
    What you send to the Video Compositor tool.
    This generates a complete Python script that assembles your Whisk images
    into a final cinematic video with motion effects, post-processing, and
    timestamps that precisely match your voiceover.
    """
    scene_list: str = Field(
        ...,
        description=(
            "The full JSON scene list from plan_scenes. "
            "Paste it directly — the compositor uses timestamps and scene types from it."
        ),
    )
    image_folder_path: str = Field(
        ...,
        description=(
            "Absolute path to the folder containing your Whisk images. "
            "Images must be named 1.png, 2.png, ... N.png matching scene numbers."
        ),
        example="C:/Videos/backpropagation/images",
    )
    exception_scene_ids: Optional[List[int]] = Field(
        default=[],
        description=(
            "Scene IDs whose images are 2688×1536 instead of the standard 2816×1536. "
            "All other scenes are assumed to be 2816×1536."
        ),
        example=[1, 22, 27, 30, 49, 55],
    )
    audio_file_path: Optional[str] = Field(
        default="",
        description=(
            "Optional absolute path to your voiceover .mp3 or .wav file. "
            "If provided, the audio will be attached to the final video."
        ),
        example="C:/Videos/backpropagation/voiceover.mp3",
    )
    reference_script: Optional[str] = Field(
        default="",
        description=(
            "Optional — paste your previous working Python compositor script here. "
            "Acts as a few-shot example: the model will match your exact libraries, "
            "effect pipeline, and rendering patterns, and improve on any known issues."
        ),
    )
    previous_issues: Optional[str] = Field(
        default="",
        description=(
            "Optional — describe problems from your last render that must be fixed. "
            "E.g. 'text container became opaque during fade-in', 'motion too subtle', "
            "'transitions degraded in the middle', 'timestamps drifted from audio'. "
            "The model will explicitly address each one."
        ),
    )


class VideoCompositorOutput(BaseModel):
    """What the Video Compositor returns."""
    python_code: str = Field(
        description=(
            "Complete, runnable Python compositor script. "
            "Save as compositor.py and run directly. "
            "Assembles all scene images into a 1920×1080 30FPS cinematic video."
        )
    )
    run_command: str = Field(
        description="The exact terminal command to run the compositor script."
    )
    notes: str = Field(
        description=(
            "pip install commands for required libraries, "
            "and any important caveats or render time estimates."
        )
    )

