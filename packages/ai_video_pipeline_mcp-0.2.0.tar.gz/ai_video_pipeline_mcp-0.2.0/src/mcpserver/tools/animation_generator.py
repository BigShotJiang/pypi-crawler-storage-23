"""
tools/animation_generator.py
─────────────────────────────────────────────────────────
PURPOSE:
    MCP Tool 4: The cinematic video compositor.

    Takes the full scene list (from the Scene Planner) + the folder of
    AI-generated Whisk images and generates a COMPLETE, production-ready
    Python script that assembles the final video.

WHAT THE GENERATED SCRIPT DOES:
    • Loads each scene image (named 1.png, 2.png, ...) from the image folder
    • Applies continuous cinematic motion to every scene (Ken Burns zoom,
      subtle parallax drift, slow pan) — the video is NEVER static
    • Handles two source image sizes:
        - Standard scenes:  2816 × 1536 px
        - Exception scenes: 2688 × 1536 px  (IDs provided by user)
    • Outputs at exactly 1920 × 1080 px, 30 FPS
    • Smooth cinematic transitions between scenes
    • High-end post-processing: film grain, chromatic aberration, vignette,
      colour grade — matching the quality of your Whisk paintings
    • Timestamps PRECISELY match the scene plan — no drift

FEW-SHOT REFERENCE:
    You can paste your previous working Python video script as a reference.
    Claude will use it to match your exact library usage, effect pipeline,
    and rendering approach.

OUTPUT:
    • python_code : Complete, runnable Python file — save and run directly
    • run_command : How to execute it
    • notes       : Dependencies and tips
─────────────────────────────────────────────────────────
"""

import json
from mcp.server.fastmcp import FastMCP
from mcpserver.utils.schemas import VideoCompositorInput


# ─── System Prompt ─────────────────────────────────────────────────────────────
VIDEO_COMPOSITOR_SYSTEM_PROMPT = """
You are an expert Python video compositor specialising in cinematic, high-production-value
YouTube video generation. Your job is to write a complete, error-free Python script that
assembles a series of AI-generated images into a seamless, cinematic video.

## THE VIDEO SPEC (hardcoded — never deviate)
- Output resolution: 1920 × 1080 px
- Frame rate: 30 FPS
- Source images: named 1.png, 2.png, ... N.png in the provided image folder
- Two source image sizes exist:
    • Standard:   2816 × 1536 px  (most scenes)
    • Exception:  2688 × 1536 px  (scene IDs provided by user — handle per-scene)
- Images are intentionally oversized so camera motion NEVER bleeds to black edges

## CORE REQUIREMENT: ALWAYS MOVING
The video must NEVER feel static or dead. Every single scene must have continuous,
perceptible cinematic motion. Choose from:
  • Slow zoom in / zoom out (Ken Burns)
  • Subtle horizontal or vertical drift / pan
  • Slow diagonal tracking shot
  • Gentle parallax (foreground faster than background — simulate with zoom + offset)
  • Combine: zoom + pan together for more dynamism

Motion must be PERCEPTIBLE — not pixel-level. A viewer should clearly feel the camera
is alive. But it must also be SMOOTH and CINEMATIC — not shaky or jarring.

## SCENE TIMING (CRITICAL)
Each scene has an exact start and end timestamp from the voiceover transcript.
The duration of each scene in the video MUST match these timestamps EXACTLY.
Double-check: sum of all scene durations = total video length.
Do NOT round or approximate — use the exact values from the scene list.

## TRANSITIONS
- Use smooth crossfades between scenes (12–18 frames / ~0.4–0.6 sec)
- Maintain motion continuity THROUGH transitions — do not freeze at transition start
- Transitions must be consistent quality throughout the whole video (no quality drop in the middle)
- Avoid hard cuts unless the scene change is intentionally abrupt (emotional shift)

## CINEMATIC POST-PROCESSING (apply to full video)
Apply these effects to every frame — they must match the Procreate/Krita painted aesthetic:
  1. Film grain: subtle, organic. NOT digital noise. Variance around 3–6, varying per frame
  2. Vignette: soft darkening at all four edges. Not heavy — cinematic, not tunnel vision
  3. Chromatic aberration: very subtle RGB channel shift at edges (1–2px max)
  4. Colour grade: very slight warm or cool push. Dark shadows. Slightly desaturated highlights
  5. Letterbox (optional): thin horizontal bars give a cinematic widescreen feel

## TEXT / EQUATION OVERLAY SCENES
For scenes marked type='animation' that have text or equations overlaid:
  - Text containers MUST have a genuinely transparent background — never accidentally opaque
  - Text fades in cleanly, container alpha stays exactly as specified throughout
  - Use RGBA consistently — no accidental alpha collapse during compositing
  - Equations should be pre-rendered (using matplotlib/LaTeX) and composited as RGBA overlays

## CODE QUALITY
- Complete, runnable in a single execution — no placeholders
- Imports at the top, constants defined clearly, functions well-named
- Check that every image file exists before starting the render loop — raise a helpful error if not
- Progress bar (tqdm or similar) highly encouraged for long renders
- Use the SAME libraries as in the reference script provided (if any)
- If no reference is provided, default to: moviepy + PIL/Pillow + numpy + scipy
""".strip()

VIDEO_COMPOSITOR_OUTPUT_FORMAT = """
Respond with ONLY valid JSON with exactly these keys (no markdown, no code fences):
{
  "python_code": "Complete Python file content as a single string. All imports, all functions, all logic.",
  "run_command": "python compositor.py  (or exact filename used in the code)",
  "notes": "List of pip install commands needed and any important caveats."
}
""".strip()


# ─── Register as MCP Tool ──────────────────────────────────────────────────────
def register(mcp: FastMCP):
    """Register generate_video_compositor as an MCP tool. Called from server.py."""

    @mcp.tool(
        name="generate_video_compositor",
        description=(
            "Build a detailed video compositor code-generation prompt. "
            "Takes your full scene list (from plan_scenes) and folder of Whisk images "
            "and returns a structured prompt packet — read it and produce a ready-to-run Python file "
            "that assembles the final video with Ken Burns motion, film grain, chromatic aberration, "
            "vignette, smooth transitions, and timestamps that perfectly match your voiceover. "
            "Paste your previous reference script as reference_script for best results."
        ),
    )
    def generate_video_compositor_tool(
        scene_list: str,
        image_folder_path: str,
        exception_scene_ids: list = [],
        audio_file_path: str = "",
        reference_script: str = "",
        previous_issues: str = "",
    ) -> str:
        """
        Assembles the compositor code-generation prompt packet for Claude to write the Python script directly.

        scene_list           : The JSON scene list from plan_scenes (paste it directly).
        image_folder_path    : Absolute path to the folder containing 1.png, 2.png, etc.
        exception_scene_ids  : Scene IDs that are 2688×1536 instead of the standard 2816×1536.
        audio_file_path      : Optional path to the voiceover .mp3/.wav to attach.
        reference_script     : Optional — paste your previous working Python compositor
                               script here as a few-shot example.
        previous_issues      : Optional — describe problems from the last render
                               (e.g. opacity bug, subtle motion, bad transitions).
        """
        validated = VideoCompositorInput(
            scene_list=scene_list,
            image_folder_path=image_folder_path,
            exception_scene_ids=exception_scene_ids,
            audio_file_path=audio_file_path,
            reference_script=reference_script,
            previous_issues=previous_issues,
        )

        exception_section = ""
        if validated.exception_scene_ids:
            ids = ", ".join(str(i) for i in validated.exception_scene_ids)
            exception_section = (
                f"\nEXCEPTION SCENE IDs (these are 2688×1536 instead of 2816×1536): {ids}"
            )

        audio_section = ""
        if validated.audio_file_path:
            audio_section = (
                f"\nAUDIO FILE: {validated.audio_file_path}\n"
                f"Attach this audio track to the final video output."
            )

        issues_section = ""
        if validated.previous_issues:
            issues_section = (
                f"\n\n## KNOWN ISSUES TO FIX FROM PREVIOUS VERSION\n"
                f"{validated.previous_issues}\n"
                f"Study these carefully and ensure every one of them is resolved."
            )

        reference_section = ""
        if validated.reference_script:
            reference_section = (
                f"\n\n## REFERENCE SCRIPT (few-shot example — match these libraries and patterns)\n"
                f"```python\n{validated.reference_script}\n```\n"
                f"Use the same libraries, same rendering approach, and same effect pipeline "
                f"as this reference. Improve upon it where the known issues (above) apply."
            )

        if isinstance(validated.scene_list, str):
            scene_block = validated.scene_list
        else:
            scene_block = json.dumps(validated.scene_list, indent=2)

        user_task = f"""
Generate a complete, production-ready Python video compositor script for the following video.

IMAGE FOLDER: {validated.image_folder_path}
(Images are named 1.png, 2.png, ... N.png — one per scene){exception_section}{audio_section}

SCENE LIST (timestamps are from the real voiceover — match them EXACTLY):
{scene_block}
{issues_section}
{reference_section}

REQUIREMENTS CHECKLIST (verify every item before returning):
  ✓ Every scene has continuous, perceptible cinematic motion (zoom/pan/drift)
  ✓ Scene durations match the transcript timestamps EXACTLY — double-check
  ✓ Transitions are smooth and consistent quality throughout the whole video
  ✓ Film grain, vignette, chromatic aberration, colour grade applied to all frames
  ✓ Output: 1920×1080 px, 30 FPS
  ✓ Text/overlay scenes: transparent containers, clean alpha compositing
  ✓ Code is complete and runnable — no placeholders, no missing pieces
  ✓ Image existence check at startup with a clear error message if any are missing
""".strip()

        return (
            f"=== SYSTEM INSTRUCTIONS ===\n{VIDEO_COMPOSITOR_SYSTEM_PROMPT}\n\n"
            f"=== YOUR TASK ===\n{user_task}\n\n"
            f"=== OUTPUT FORMAT ===\n{VIDEO_COMPOSITOR_OUTPUT_FORMAT}"
        )
