"""
tools/image_prompt_generator.py
─────────────────────────────────────────────────────────
PURPOSE:
    MCP Tool 3: Turn a scene description into a polished AI image prompt.

    After the Scene Planner identifies your image-type scenes, you run
    each one through this tool. It outputs a prompt ready to paste into
    Whisk, Midjourney, DALL·E, Adobe Firefly, or any image generator.

WHAT MAKES A GOOD IMAGE PROMPT?
    A good AI image prompt has 4 layers:
      1. SUBJECT     — what's in the scene (from your description)
      2. STYLE       — how it looks (hand painted, cinematic, etc.)
      3. TECHNICAL   — aspect ratio, lighting, camera framing
      4. EXCLUSIONS  — a negative prompt telling the model what NOT to include

CONSISTENCY TIP:
    Keep visual_style the same across ALL your scenes. If you change it
    per scene, your video will look like multiple different art styles.
─────────────────────────────────────────────────────────
"""

from mcp.server.fastmcp import FastMCP
from mcpserver.utils.schemas import ImagePromptInput


# ─── Prompt Template ───────────────────────────────────────────────────────────
IMAGE_PROMPT_SYSTEM_PROMPT = """
You are a prompt engineer specializing in Whisk image generation for cinematic YouTube video backgrounds.
Every prompt you write should feel like a frame from a beautiful hand-painted animated film.

## THE ART STYLE (non-negotiable, always apply)
Think Procreate or Krita — a human artist's hand-drawn digital painting.
- Rich, textured painterly brush strokes. The medium is visible.
- NOT photorealistic. NOT a 3D render. NOT stock photography. NOT flat design.
- Cinematic composition: rule of thirds, strong focal point, deliberate framing.
- Atmospheric depth: clear foreground subject, layered background that recedes softly.
- Intentional, moody lighting — a clear single light source (golden hour, lamp, fire, moonlight, etc.).
- Rich, slightly desaturated palette. Deep shadows, warm or cool highlights. NOT oversaturated.
- Silhouettes and implied human figures are fine. NO detailed close-up faces.
- NO text, numbers, labels, arrows, UI elements, charts, or diagrams inside the image.

## YOUR PROMPT'S JOB
The image is a BACKGROUND that plays while the narration carries the explanation.
It must set mood, atmosphere, and visual metaphor — it does NOT need to explain the concept.
A viewer who only sees the image (without audio) should feel an emotion, not read information.

Great image prompts evoke:
  - A sense of place (factory floor, city at night, a classroom, a mountain pass)
  - An emotional tone (tense, hopeful, vast, intimate, melancholic)
  - A visual metaphor (flames of blame traveling backward, a web of glowing threads, a lone figure at a crossroads)

## WHISK PROMPT STRUCTURE
Build the prompt in this order:
  1. Subject / Scene: What's in the frame and where
  2. Key visual metaphor or mood element: The one thing that makes it cinematic
  3. Style: hand-drawn digital painting, Procreate style, painterly, illustrated
  4. Lighting: moody / golden hour / firelight / cool moonlight (match the scene)
  5. Composition: wide-angle / close-up / overhead / eye-level, rule of thirds
  6. Atmosphere: depth of field, texture detail, emotional tone

Prompt length: 80–150 words. Vivid, specific, sensory. No vague words like "beautiful" or "stunning".
""".strip()

IMAGE_PROMPT_OUTPUT_FORMAT = """
Respond with ONLY valid JSON with exactly these two keys (no markdown, no code fences):
{
  "prompt": "Complete Whisk image generation prompt. Rich, specific, cinematic, painterly.",
  "negative_prompt": "Comma-separated list of things to exclude."
}
""".strip()

# Standard negative prompt — pasted into Whisk's negative field every time
BASE_NEGATIVE = (
    "text, words, writing, labels, numbers, watermark, logo, signature, "
    "photorealism, photograph, 3D render, CGI, plastic sheen, ugly, blurry, low quality, "
    "split image, collage, border, frame, UI elements, charts, graphs, diagrams, arrows, "
    "close-up faces, cartoon, anime, manga, flat design, vector art, clipart"
)


# ─── Register as MCP Tool ──────────────────────────────────────────────────────
def register(mcp: FastMCP):
    """Register generate_image_prompt as an MCP tool. Called from server.py."""

    @mcp.tool(
        name="generate_image_prompt",
        description=(
            "Build a detailed image-prompt generation request for a scene. "
            "Outputs a structured prompt packet — read it and produce a Whisk image generation "
            "prompt and negative prompt in Procreate/Krita cinematic painting style. "
            "Optionally provide audio_context (what the narrator says during the scene) "
            "to anchor the image precisely to that voiceover moment. "
            "Paste both prompts directly into Whisk."
        ),
    )
    def generate_image_prompt_tool(
        scene_description: str,
        audio_context: str = "",
        visual_style: str = "hand-drawn digital painting, Procreate style, cinematic, painterly",
        aspect_ratio: str = "16:9",
        lighting: str = "moody",
    ) -> str:
        """Assembles the image prompt packet for Claude to generate the Whisk prompt directly."""
        validated = ImagePromptInput(
            scene_description=scene_description,
            audio_context=audio_context,
            visual_style=visual_style,
            aspect_ratio=aspect_ratio,
            lighting=lighting,
        )

        audio_context_section = ""
        if validated.audio_context:
            audio_context_section = (
                f"\nAUDIO CONTEXT (what the narrator is saying during this scene):\n"
                f"{validated.audio_context}\n"
                f"The image must feel like it belongs to this exact moment in the narration."
            )

        user_task = f"""
Generate a Whisk image prompt for the following scene.
The image will play as a background while a narrator explains an algorithm concept.
It should be atmospheric and metaphorical — mood and story, not explanation.

SCENE DESCRIPTION: {validated.scene_description}
{audio_context_section}
VISUAL STYLE: {validated.visual_style}
  (Procreate / Krita — hand-drawn, painterly digital painting. NOT photorealistic.)
ASPECT RATIO: {validated.aspect_ratio} (YouTube widescreen)
LIGHTING MOOD: {validated.lighting}

Always include this in the negative prompt (merge with any extras you add):
{BASE_NEGATIVE}
""".strip()

        return (
            f"=== SYSTEM INSTRUCTIONS ===\n{IMAGE_PROMPT_SYSTEM_PROMPT}\n\n"
            f"=== YOUR TASK ===\n{user_task}\n\n"
            f"=== OUTPUT FORMAT ===\n{IMAGE_PROMPT_OUTPUT_FORMAT}"
        )
