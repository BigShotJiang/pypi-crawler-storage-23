"""
tools/scene_planner.py
─────────────────────────────────────────────────────────
PURPOSE:
    MCP Tool 2: Turn a timestamped Premiere Pro transcript into a
    structured list of visual scenes — the "storyboard" for your video.

    Each scene gets:
      • An exact start/end timestamp (aligned to the transcript)
      • A specific visual description (what to show on screen)
      • A type: 'image' or 'animation'

WHEN DOES A SCENE BECOME 'animation'?
    Only when one of these is true:
      • An equation must appear on screen
      • Text overlay / step-by-step transformation is needed
      • True motion is conceptually necessary (e.g. graph traversal)
    Otherwise → 'image' (default).

TRANSCRIPT FORMAT (from Premiere Pro):
    [HH:MM:SS] Spoken words here...
    [HH:MM:SS] More words...
─────────────────────────────────────────────────────────
"""

from mcp.server.fastmcp import FastMCP
from mcpserver.utils.schemas import ScenePlannerInput


# ─── Prompt Template ───────────────────────────────────────────────────────────
SCENE_PLANNER_SYSTEM_PROMPT = """
You are a visual director for an algorithm-explanation YouTube channel.
Your job: convert a timestamped voiceover transcript into a perfectly timed, audience-retaining scene list.

## YOUR CORE MISSION
Audience retention. Every scene change must feel purposeful — not too fast (overstimulating),
not too slow (boring). Read the transcript like a director, not a note-taker.
Ask yourself: "At this exact moment, what image would make a viewer lean in?"

## SCENE TIMING — MAKE EDUCATED CALLS
- Aim for roughly 10 seconds per scene ON AVERAGE, but this is a guideline, not a rule.
- Short scenes (5–7s): use when the narration is fast, punchy, or switches concept rapidly.
- Longer scenes (12–18s): use when the narrator is building atmosphere, telling a story beat,
  or the metaphor needs time to land. Do NOT cut a powerful image too early.
- NEVER create a scene just to hit a number. Read the script, feel the pacing.
- Break on: new metaphor, new concept, emotional shift, new equation, new scene in the story.

## SCENE TYPES — STRONG PREFERENCE FOR WHISK IMAGES

### "image" (Whisk/AI-generated cinematic painting) — USE THIS EVERYWHERE POSSIBLE
  Painterly, cinematic, hand-drawn digital paintings in Procreate/Krita style.
  Use for: metaphors, atmosphere, story moments, establishing shots, concept illustrations.
  If in doubt — use image. Most scenes should be this.

### "animation" (Python-generated) — USE SPARINGLY. ONLY WHEN TRULY NECESSARY.
  Use ONLY when ALL of the following are true:
    1. An equation or mathematical notation must appear on screen
    2. OR step-by-step text/data transformation is required
    3. AND a painted image literally cannot do the job
  Do NOT use animation for: "something moving", "arrows pointing", "a path being drawn" —
  those can all be beautifully implied in a cinematic still image.
  Ask yourself: "Can a great painting capture this?" If yes → use image.

## CROSS-CHECK RULE (CRITICAL)
After planning all scenes, go back through EVERY scene and verify:
  ✓ Does this visual make sense given what the narrator is SAYING right now?
  ✓ Is it grounded in the actual transcript at this timestamp — not the scene before or after?
  ✓ Would a viewer watching this image while hearing these words feel it clicks perfectly?
If any scene fails this check, fix it before returning output.

## SCENE DESCRIPTIONS
- Must be SPECIFIC and cinematic — paint a picture in words.
  BAD: "Show a factory"
  GOOD: "A wide-angle view of a dimly lit factory floor at dusk; a single red warning light
         pulses at the far end of a long conveyor belt — one defective product has triggered
         something. Workers in silhouette look up."
- Root every description in what the narration SAYS at that moment.
- No hallucinated visuals — do not invent things the narration doesn't support.
- Scenes must cover the FULL transcript with zero gaps.
- DO NOT alter or invent timestamps — copy them exactly from the transcript.
""".strip()

SCENE_PLANNER_OUTPUT_FORMAT = """
Respond with ONLY valid JSON — a list of scene objects (no markdown, no code fences):
[
  {
    "scene_number": 1,
    "start": "00:00:00",
    "end": "00:00:10",
    "description": "Specific cinematic visual description grounded in the narration at this moment.",
    "type": "image"
  },
  ...
]

Target: as many "image" scenes as possible. Use "animation" only where a painting truly cannot serve.
Cover all timestamps from first to last. No gaps.
""".strip()


# ─── Register as MCP Tool ──────────────────────────────────────────────────────
def register(mcp: FastMCP):
    """Register plan_scenes as an MCP tool. Called from server.py."""

    @mcp.tool(
        name="plan_scenes",
        description=(
            "Build a detailed scene-planning prompt from a timestamped Premiere Pro transcript. "
            "Each scene gets a start/end timestamp, description, and type (image or animation). "
            "Paste your transcript in the format: [HH:MM:SS] spoken words... "
            "Returns a structured prompt packet — read it and produce the full scene list as a JSON array."
        ),
    )
    def plan_scenes_tool(
        timestamped_transcript: str,
        preferred_avg_scene_length_seconds: int = 10,
        visual_style: str = "cinematic hand drawn digital painting",
        allow_python_animation: bool = True,
    ) -> str:
        """Assembles the scene-planning prompt packet for Claude to generate the scene list directly."""
        validated = ScenePlannerInput(
            timestamped_transcript=timestamped_transcript,
            preferred_avg_scene_length_seconds=preferred_avg_scene_length_seconds,
            visual_style=visual_style,
            allow_python_animation=allow_python_animation,
        )

        if not validated.timestamped_transcript.strip():
            raise ValueError(
                "timestamped_transcript cannot be empty.\n"
                "Paste your Premiere Pro transcript with [HH:MM:SS] timestamps."
            )

        animation_rule = (
            "You MAY use 'animation' type when equations, text overlays, or true motion are needed."
            if validated.allow_python_animation
            else "Set ALL scenes to type 'image'. Do not use 'animation'."
        )

        user_task = f"""
You are planning scenes for an algorithm-explanation YouTube video.
This is a real voiceover transcript with exact timestamps. Your scene list must PERFECTLY
sync with the audio — the visual at each timestamp must make sense with what's being SAID
at that exact moment.

SETTINGS:
- Target average scene length: {validated.preferred_avg_scene_length_seconds} seconds
  (Make educated calls — shorter for fast/punchy moments, longer for slow story beats)
- Visual style for all image scenes: {validated.visual_style}
  (Procreate / Krita style — hand-drawn, painterly, cinematic digital paintings)
- {animation_rule}

TRANSCRIPT (with real voiceover timestamps):
{validated.timestamped_transcript}

INSTRUCTIONS:
1. Read the full transcript carefully before planning any scenes.
2. Plan scenes that serve audience retention — purposeful cuts, not mechanical ones.
3. Strongly prefer image (Whisk) scenes. Only use animation where a painting cannot do the job.
4. After planning, double-check every scene: does the visual match what's being SAID at that timestamp?
5. Return the complete scene list as a JSON array following the output format below.
""".strip()

        return (
            f"=== SYSTEM INSTRUCTIONS ===\n{SCENE_PLANNER_SYSTEM_PROMPT}\n\n"
            f"=== YOUR TASK ===\n{user_task}\n\n"
            f"=== OUTPUT FORMAT ===\n{SCENE_PLANNER_OUTPUT_FORMAT}"
        )
