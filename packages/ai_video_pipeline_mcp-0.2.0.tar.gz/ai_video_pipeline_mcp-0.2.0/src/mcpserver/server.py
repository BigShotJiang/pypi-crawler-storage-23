"""
server.py
─────────────────────────────────────────────────────────
PURPOSE:
    The main entry-point for the MCP Video Pipeline server.
    This file:
      1. Creates the FastMCP server instance.
      2. Imports and registers all 4 tools.
      3. Starts the server over stdio (Claude Desktop's required transport).

    Claude Desktop runs this file as a background subprocess and
    communicates with it via stdin/stdout. You don't need to start
    this manually — Claude Desktop handles it automatically after you
    configure claude_desktop_config.json.

HOW TO TEST WITHOUT CLAUDE DESKTOP:
    Run the MCP Inspector (a web UI for testing tools):
        mcp dev src/mcpserver/server.py
    Then open http://localhost:5173 in your browser, select a tool,
    fill in the inputs, and click "Run".

ADDING A NEW TOOL:
    1. Create a new file in tools/ with a register(mcp) function.
    2. Import the tool module here.
    3. Call tool_module.register(mcp).
    That's it — Claude Desktop picks it up on restart.

ARCHITECTURE OVERVIEW:
    Claude Desktop (the LLM host)
        ↓ (stdio)
    server.py  [FastMCP]
        ├── generate_script           (tools/script_generator.py)
        ├── plan_scenes               (tools/scene_planner.py)
        ├── generate_image_prompt     (tools/image_prompt_generator.py)
        └── generate_video_compositor (tools/animation_generator.py)

    Each tool builds a rich prompt packet and returns it.
    Claude Desktop reads the packet and generates the output directly —
    no external API calls, no API keys required.
─────────────────────────────────────────────────────────
"""

from mcp.server.fastmcp import FastMCP

# Import all tool modules (each has a register() function)
from mcpserver.tools import script_generator
from mcpserver.tools import scene_planner
from mcpserver.tools import image_prompt_generator
from mcpserver.tools import animation_generator

# ─── Create the MCP server ────────────────────────────────────────────────────
# The name appears in Claude Desktop's tool list.
# Instructions tell Claude HOW to use the pipeline end-to-end.
mcp = FastMCP(
    name="AI Video Pipeline",
    instructions="""
You are the orchestrator of an AI video production pipeline.
Help the user create high-quality algorithm-explanation YouTube videos using these tools:

## PIPELINE WORKFLOW (follow this order)

1. SCRIPT GENERATION
   - Ask for: topic, tagline, gist, desired duration
   - Ask: "Do you have any previous scripts I can use as style references?"
   - Ask: "Do you have any visual metaphor ideas you'd like me to suggest to the writer?"
   - Call: generate_script
   - Present the script clearly. Ask user to review before proceeding.

2. [HUMAN STEP — no tool needed]
   - User records the voiceover.
   - User exports a timestamped transcript (from Premiere Pro or similar).
   - Format: [HH:MM:SS] spoken words...
   - Tell the user to paste the transcript when ready.

3. SCENE PLANNING
   - Take the pasted transcript.
   - Call: plan_scenes
   - Present the scene list as a numbered table: Scene | Start | End | Type | Description
   - Ask user to review and approve before moving on.

4. IMAGE PROMPTS (one per image-type scene)
   - For each scene where type == "image":
     - Ask: "Would you like to provide the narration text for this scene as audio context?"
     - Call: generate_image_prompt with scene_description + audio_context (if given)
     - Present: positive prompt and negative_prompt clearly labelled.
     - Remind user: keep visual_style identical across all scenes for consistency.

5. VIDEO COMPOSITOR (final assembly)
   - Ask: "Do you have a reference Python compositor script from a previous video?
          If yes, paste it — I'll use it as a style guide and fix any issues."
   - Ask: "Were there any issues with your last render to fix?
          (e.g. opacity bugs, subtle motion, bad transitions, timestamp drift)"
   - Ask: "Please provide the path to your images folder and your voiceover audio file."
   - Ask: "Which scene IDs have the smaller 2688×1536 image size (vs standard 2816×1536)?"
   - Call: generate_video_compositor
   - Present the Python code with the run command and install notes.

## QUALITY RULES
- Always ask for few-shot examples (reference scripts, past scripts) before generating.
- Never skip the user review step between stages.
- Never hallucinate visual content beyond what the transcript supports.
- Present results in a clean, readable format — use tables and code blocks.
- When in doubt, ask the user before proceeding to the next stage.
""".strip(),
)

# ─── Register all tools ───────────────────────────────────────────────────────
# Each register() call adds that tool's MCP-decorated function to the server.
script_generator.register(mcp)
scene_planner.register(mcp)
image_prompt_generator.register(mcp)
animation_generator.register(mcp)

# # ─── Run the server ───────────────────────────────────────────────────────────
# def main():
#     """Main entry point for the MCP server."""
#     # transport="stdio" is required for Claude Desktop.
#     # Do not change this to "http" or "websocket" for Desktop use.
#     mcp.run(transport="stdio")

# if __name__ == "__main__":
#     main()
