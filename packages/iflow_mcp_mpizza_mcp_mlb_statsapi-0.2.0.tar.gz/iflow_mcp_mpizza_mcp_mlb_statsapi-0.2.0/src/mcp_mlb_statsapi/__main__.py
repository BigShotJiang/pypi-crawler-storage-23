from mcp_mlb_statsapi import main

main()