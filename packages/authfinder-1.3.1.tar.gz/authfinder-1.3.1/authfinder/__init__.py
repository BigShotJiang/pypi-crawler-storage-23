"""authfinder: Execute commands across Windows and Linux systems using multiple RCE methods"""

__version__ = "1.3.1"
