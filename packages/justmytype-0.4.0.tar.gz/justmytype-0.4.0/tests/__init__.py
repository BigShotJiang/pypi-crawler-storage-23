"""Tests for JustMyType."""
