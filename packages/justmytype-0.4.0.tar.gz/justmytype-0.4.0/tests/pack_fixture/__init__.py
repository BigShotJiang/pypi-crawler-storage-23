"""Test package providing a minimal pack_manifest.json for font_catalog tests."""
