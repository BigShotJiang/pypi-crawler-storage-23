import pytest
from lisdk import ApiUtils

def test_apiutils_now():
    now = ApiUtils.now()
    print(now)
    assert isinstance(now, str)
    assert "T" in now

def test_apiutils_datetime():
    now = ApiUtils.datetime(hours=1)
    print(now)
    assert isinstance(now, str)
    assert "T" in now

def test_apiutils_numstr():
    num = ApiUtils.numstr(10)
    assert len(num) == 10
    assert num.isdigit()

def test_apiutils_mobiles():
    mobile = ApiUtils.mobiles(1)
    assert isinstance(mobile, str)
    assert len(mobile) > 0

    mobiles = ApiUtils.mobiles(5)
    assert isinstance(mobiles, list)
    assert len(mobiles) == 5

def test_apiutils_deepupdate():
    source = {"a": 1, "b": {"c": 2}}
    target = {"b": {"c": 3}, "d": 4}
    updated = ApiUtils.deepupdate(source, target)
    assert updated["b"]["c"] == 3
    assert updated["d"] == 4
