from faker import Faker
import datetime
import secrets
import time
import pytz


class ApiUtils:
    fake = Faker("zh_CN")

    @classmethod
    def now(cls, tzinfo='Asia/Shanghai'):
        return datetime.datetime.now(pytz.utc).astimezone(pytz.timezone(tzinfo)).isoformat(timespec='seconds')

    @classmethod
    def datetime(cls, weeks=0, days=0, hours=0, minutes=0, seconds=0, microseconds=0, milliseconds=0, tzinfo='Asia/Shanghai'):
        dttd = datetime.timedelta(
            weeks=weeks,
            days=days,
            hours=hours,
            minutes=minutes,
            seconds=seconds,
            microseconds=microseconds,
            milliseconds=milliseconds
        )
        return (datetime.datetime.now(pytz.utc).astimezone(pytz.timezone(tzinfo)) + dttd).isoformat(timespec='seconds')

    @classmethod
    def numstr(cls, l=23):
        timestamp = str(time.time_ns())
        v = timestamp + str(str(secrets.randbits(12)))
        start = len(v) - l
        if start < 0:
            start = 0
        return v[start:len(v)]

    @classmethod
    def mobiles(cls, l=10):
        num = [cls.fake.phone_number() for _ in range(l)]
        if l == 1:
            return num[0]
        return num
    
    @classmethod
    def deepupdate(cls, source_dict, target_dict):
        """
        递归地将目标字典的内容更新到源字典中
        
        支持以下情况：
        1. 嵌套字典的合并
        2. 列表的合并（如果目标字典中的列表不为空，则替换源字典中的列表）
        3. 列表中包含字典的情况（如果列表长度相同，则递归合并对应位置的字典）
        
        Args:
            source_dict: 源字典，将被更新
            target_dict: 目标字典，提供更新内容
            
        Returns:
            更新后的源字典
        """
        for key, value in target_dict.items():
            if key in source_dict:
                if isinstance(source_dict[key], dict) and isinstance(value, dict):
                    # 如果两个都是字典，递归合并
                    cls.deepupdate(source_dict[key], value)
                elif isinstance(source_dict[key], list) and isinstance(value, list):
                    # 如果两个都是列表
                    if len(value) > 0:  # 如果目标列表不为空
                        if len(source_dict[key]) == len(value) and all(isinstance(s, dict) and isinstance(t, dict) for s, t in zip(source_dict[key], value)):
                            # 如果列表长度相同且所有元素都是字典，则递归合并对应位置的字典
                            for i, (source_item, target_item) in enumerate(zip(source_dict[key], value)):
                                cls.deepupdate(source_item, target_item)
                        else:
                            # 否则替换整个列表
                            source_dict[key] = value
                    else:
                        pass
                else:
                    # 其他情况直接更新
                    source_dict[key] = value
            else:
                # 如果键不存在，直接添加
                source_dict[key] = value
        
        return source_dict

    @classmethod
    def ini(cls, path, section=None, option=None):
        """
        读取 ini 配置文件
        
        Args:
            path: ini 文件路径
            section: 选取的配置节（可选）
            option: 选取的配置项（可选）
            
        Returns:
            如果指定了 section 和 option，返回对应的值；
            如果只指定了 section，返回该节的所有项；
            如果不指定，返回所有内容。
        """
        config = cls._readini(path)
        if section and option:
            return config.get(section, option)
        elif section:
            return dict(config.items(section))
        return {s: dict(config.items(s)) for s in config.sections()}

    @classmethod
    def _readini(cls, path):
        import configparser
        config = configparser.ConfigParser()
        config.read(path, encoding='utf-8')
        return config


if __name__ == '__main__':
    pass