# lisdk SDK

一个简单的 Python SDK 示例项目，包含常用的工具类、加密工具和数据库操作封装。

## 功能特性

- **ApiUtils**: 时间处理、随机数据生成、字典深度更新、配置文件读取。
- **Http**: 基于 `requests` 封装的 HTTP 请求类。
- **RSAK**: RSA 签名与验签工具。
- **MySQLConnection**: 灵活的 MySQL 连接构造器与管理器。

## 安装

你可以通过 pip 安装该项目（开发模式）：

```bash
pip install -e .
```

安装所有开发依赖：

```bash
pip install -e ".[dev]"
```

## 快速开始

```python
from lisdk import ApiUtils

# 获取当前格式化时间
print(ApiUtils.now())

# 生成随机手机号
print(ApiUtils.mobiles(1))
```

更多示例请参考 [examples/](examples/) 目录。

## 开发与测试

运行测试：

```bash
pytest tests/
```

代码格式化与检查：

```bash
ruff check .
black .
```

## 发布流程

1. 删除旧的构建文件：`rm -rf dist/`
2. 构建包：`python3 -m build`
3. 上传到 PyPI：`twine upload dist/*`
