# Info for maintainers

Info for maintainers is available in the docs (
[html](https://tifuun.github.io/gateau/maintainers.html),
[source](./doxy/maintainers.dox)
)

