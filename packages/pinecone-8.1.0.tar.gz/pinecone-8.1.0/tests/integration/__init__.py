# dotenv.load_dotenv() removed from here to prevent loading .env when running unit tests
# Integration test conftest.py files handle loading dotenv when needed
