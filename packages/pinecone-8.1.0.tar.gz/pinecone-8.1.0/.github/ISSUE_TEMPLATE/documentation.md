---
name: Documentation
about: Report an issue in our docs
title: "[Docs] "
labels: 'documentation'
assignees: ''

---

**Description**
Describe the issue that you've encountered with our documentation.

**Suggested solution**
Describe how this issue could be fixed or improved. 

**Link to page**
Add a link to the exact documentation page where the issue occurred.
