VectorDictMetadataValue = str | int | float | list[str] | list[int] | list[float]
VectorMetadataTypedDict = dict[str, VectorDictMetadataValue]
