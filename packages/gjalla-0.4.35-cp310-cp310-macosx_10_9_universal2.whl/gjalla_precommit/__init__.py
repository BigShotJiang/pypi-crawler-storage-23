"""Gjalla Pre-commit Analysis CLI."""

__version__ = "0.4.35"
