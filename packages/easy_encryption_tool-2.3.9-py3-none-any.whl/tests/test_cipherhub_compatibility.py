#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
easy_encryption_tool 与 CipherHUB 兼容性测试
验证在相同算法、模式、输入参数下，两者可相互加解密或得到一致的 hash/hmac
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import sys
import subprocess

# 添加项目根目录和 CipherHUB 到 path
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_CIPHERHUB_ROOT = os.path.join(os.path.dirname(_PROJECT_ROOT), "CipherHUB")
sys.path.insert(0, _PROJECT_ROOT)
sys.path.insert(0, _CIPHERHUB_ROOT)

from easy_encryption_tool import cipherhub_defaults

# CipherHUB 默认明文
PLAINTEXT = cipherhub_defaults.DEFAULT_PLAINTEXT
PLAINTEXT_BYTES = PLAINTEXT.encode("utf-8")
PLAINTEXT_HEX = PLAINTEXT_BYTES.hex()

# 测试结果收集
RESULTS = []


def _parse_copyable_block(stdout: str, label: str, is_hex: bool = False):
    """解析 plain_copyable_block 输出：Rule+label 下方第一行非空内容（可能含 ANSI 码）。"""
    import re
    lines = stdout.split("\n")
    found_label = False
    for line in lines:
        if label in line and ("─" in line or "---" in line):
            found_label = True
            continue
        if found_label and line.strip():
            # 提取 hex 或 base64，兼容 ANSI 转义码
            if is_hex:
                m = re.search(r"([a-fA-F0-9]{32,})", line)
            else:
                m = re.search(r"([A-Za-z0-9+/=]{16,})", line)
            if m:
                return m.group(1)
    return None


def _record(name: str, passed: bool, detail: str = ""):
    RESULTS.append({"name": name, "passed": passed, "detail": detail})
    status = "✓ PASS" if passed else "✗ FAIL"
    print(f"  {status}: {name}" + (f" - {detail}" if detail else ""))


def test_block_cipher_aes256_cbc():
    """块密码 AES256-CBC：easy_encryption_tool 加密 -> CipherHUB 解密"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError as e:
        _record(
            "Block Cipher AES256-CBC (enc->dec)", False, f"CipherHUB import failed: {e}"
        )
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")

    # 使用 easy_encryption_tool 加密（通过 CLI）
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "cbc",
            "-A",
            "encrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Block Cipher AES256-CBC (enc)", False, proc.stderr or proc.stdout)
        return

    # 解析输出获取 cipher (base64)，新格式：Rule+cipher 下方为 base64 行
    cipher_b64 = _parse_copyable_block(proc.stdout, "cipher", is_hex=False)
    if not cipher_b64:
        _record(
            "Block Cipher AES256-CBC (parse)",
            False,
            "could not parse cipher from output",
        )
        return

    cipher_bytes = base64.b64decode(cipher_b64)
    decrypted = block_cipher_process(
        cipher_bytes,
        key_bytes,
        iv_bytes,
        ProcessType.Decrypt,
        CBCAlgorithm.AES256,
    )
    passed = decrypted == PLAINTEXT_BYTES
    _record("Block Cipher AES256-CBC (easy_enc->CipherHUB_dec)", passed)


def test_block_cipher_aes256_cbc_reverse():
    """块密码 AES256-CBC：CipherHUB 加密 -> easy_encryption_tool 解密"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError:
        _record(
            "Block Cipher AES256-CBC (CipherHUB_enc->dec)",
            False,
            "CipherHUB import failed",
        )
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
    cipher_bytes = block_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        iv_bytes,
        ProcessType.Encrypt,
        CBCAlgorithm.AES256,
    )
    cipher_b64 = base64.b64encode(cipher_bytes).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "cbc",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record(
            "Block Cipher AES256-CBC (CipherHUB_enc->easy_dec)",
            False,
            proc.stderr or proc.stdout,
        )
        return

    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("Block Cipher AES256-CBC (CipherHUB_enc->easy_dec)", passed)


def test_stream_cipher_aes256_gcm():
    """流密码 AES256-GCM：双向加解密兼容"""
    try:
        from handlers.stream_cipher import (
            stream_cipher_process,
            StreamAlgorithm,
            ProcessType,
        )
    except ImportError as e:
        _record("Stream Cipher AES256-GCM", False, f"CipherHUB import failed: {e}")
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    nonce_bytes = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
    aad_bytes = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")

    # CipherHUB 加密
    cipher_from_ch = stream_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        nonce_bytes,
        aad_bytes,
        ProcessType.Encrypt,
        StreamAlgorithm.AES256GCM,
    )
    cipher_b64 = base64.b64encode(cipher_from_ch).decode("utf-8")

    # easy_encryption_tool 解密：支持 base64(cipher||tag) 不分离格式
    cipher_b64 = base64.b64encode(cipher_from_ch).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "gcm",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_NONCE_12,
            "--aad",
            cipherhub_defaults.DEFAULT_AAD,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record(
            "Stream Cipher AES256-GCM (CipherHUB_enc->easy_dec)",
            False,
            proc.stderr or proc.stdout,
        )
        return

    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("Stream Cipher AES256-GCM (CipherHUB_enc->easy_dec)", passed)


def test_hash_sha256():
    """Hash SHA256：两者结果一致"""
    expected = hashlib.sha256(PLAINTEXT_BYTES).hexdigest()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hash",
            "-a",
            "sha256",
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Hash SHA256", False, proc.stderr or proc.stdout)
        return
    got = _parse_copyable_block(proc.stdout, "hash", is_hex=True)
    passed = got == expected
    _record("Hash SHA256", passed)


def test_hash_sm3():
    """Hash SM3：两者结果一致（需 easy_gmssl）"""
    try:
        from easy_gmssl import EasySM3Digest
    except ImportError:
        _record("Hash SM3", False, "easy_gmssl not installed")
        return
    h = EasySM3Digest()
    h.UpdateData(PLAINTEXT_BYTES)
    expected = h.GetHash()[0].hex()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hash",
            "-a",
            "sm3",
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Hash SM3", False, proc.stderr or proc.stdout)
        return
    got = _parse_copyable_block(proc.stdout, "hash", is_hex=True)
    passed = got == expected
    _record("Hash SM3", passed)


def test_hmac_sha256():
    """HMAC SHA256：两者结果一致"""
    key_bytes = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
    expected = hmac.new(key_bytes, PLAINTEXT_BYTES, hashlib.sha256).hexdigest()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hmac",
            "-a",
            "sha256",
            "-k",
            cipherhub_defaults.DEFAULT_HMAC_KEY,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("HMAC SHA256", False, proc.stderr or proc.stdout)
        return
    got = _parse_copyable_block(proc.stdout, "hmac", is_hex=True)
    passed = got == expected
    _record("HMAC SHA256", passed)


def test_hmac_sm3():
    """HMAC SM3：两者结果一致（需 easy_gmssl）"""
    try:
        from easy_gmssl import EasySM3Hmac
    except ImportError:
        _record("HMAC SM3", False, "easy_gmssl not installed")
        return
    key_bytes = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
    h = EasySM3Hmac(key_bytes)
    h.UpdateData(PLAINTEXT_BYTES)
    expected = h.GetHmac()[0].hex()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hmac",
            "-a",
            "sm3",
            "-k",
            cipherhub_defaults.DEFAULT_HMAC_KEY,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("HMAC SM3", False, proc.stderr or proc.stdout)
        return
    got = _parse_copyable_block(proc.stdout, "hmac", is_hex=True)
    passed = got == expected
    _record("HMAC SM3", passed)


def test_zuc():
    """ZUC：easy_encryption_tool 加密 -> CipherHUB 解密"""
    try:
        from handlers.zuc_cipher import zuc_processing
    except ImportError:
        _record("ZUC (enc->dec)", False, "CipherHUB import failed")
        return
    try:
        from easy_gmssl import EasyZuc
    except ImportError:
        _record("ZUC", False, "easy_gmssl not installed")
        return

    key_bytes = cipherhub_defaults.DEFAULT_ZUC_KEY.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_ZUC_IV.encode("utf-8")

    # easy_encryption_tool 加密
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "zuc",
            "-a",
            "encrypt",
            "-k",
            cipherhub_defaults.DEFAULT_ZUC_KEY,
            "-v",
            cipherhub_defaults.DEFAULT_ZUC_IV,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("ZUC (easy_enc)", False, proc.stderr or proc.stdout)
        return
    cipher_b64 = _parse_copyable_block(proc.stdout, "cipher", is_hex=False)
    if not cipher_b64:
        _record("ZUC (parse)", False, "could not parse cipher")
        return

    cipher_bytes = base64.b64decode(cipher_b64)
    decrypted = zuc_processing(cipher_bytes, key_bytes, iv_bytes)
    passed = decrypted == PLAINTEXT_BYTES
    _record("ZUC (easy_enc->CipherHUB_dec)", passed)


def test_sm4_cbc():
    """SM4-CBC：双向加解密兼容"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError:
        _record("SM4-CBC", False, "CipherHUB import failed")
        return
    try:
        from easy_gmssl import EasySm4CBC
    except ImportError:
        _record("SM4-CBC", False, "easy_gmssl not installed")
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_16.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")

    # CipherHUB 加密
    cipher_bytes = block_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        iv_bytes,
        ProcessType.Encrypt,
        CBCAlgorithm.SM4,
    )
    cipher_b64 = base64.b64encode(cipher_bytes).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "sm4",
            "-m",
            "cbc",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_16,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("SM4-CBC (CipherHUB_enc->easy_dec)", False, proc.stderr or proc.stdout)
        return
    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("SM4-CBC (CipherHUB_enc->easy_dec)", passed)

    # 反向：easy_encryption_tool 加密 -> CipherHUB 解密
    proc_enc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "sm4",
            "-m",
            "cbc",
            "-A",
            "encrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_16,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc_enc.returncode != 0:
        _record("SM4-CBC (easy_enc->CipherHUB_dec)", False, proc_enc.stderr or proc_enc.stdout)
        return
    cipher_b64_from_easy = _parse_copyable_block(proc_enc.stdout, "cipher", is_hex=False)
    if not cipher_b64_from_easy:
        _record("SM4-CBC (easy_enc->CipherHUB_dec)", False, "could not parse cipher from output")
        return
    cipher_bytes_from_easy = base64.b64decode(cipher_b64_from_easy)
    decrypted_by_ch = block_cipher_process(
        cipher_bytes_from_easy,
        key_bytes,
        iv_bytes,
        ProcessType.Decrypt,
        CBCAlgorithm.SM4,
    )
    passed_rev = decrypted_by_ch == PLAINTEXT_BYTES
    _record("SM4-CBC (easy_enc->CipherHUB_dec)", passed_rev)


def test_ecdh_eet_cipherhub():
    """ECC ECDH：eet 与 CipherHUB 使用相同密钥和参数应派生一致密钥"""
    import tempfile
    import uuid
    try:
        from handlers.ecc_key_exchange import EccKeyExchangeHandler
        from api.ecc_key_exchange import EccKeyExchangeRequest
        from api.api_model import ApiSuccess
    except ImportError as e:
        _record("ECC ECDH (eet<->CipherHUB)", False, f"CipherHUB import failed: {e}")
        return

    with tempfile.TemporaryDirectory(dir=_PROJECT_ROOT) as tmpdir:
        # 生成 alice、bob 密钥对
        for name, curve in [("alice", "secp256r1"), ("bob", "secp256r1")]:
            proc = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "easy_encryption_tool.main",
                    "ecc",
                    "generate",
                    "-c",
                    curve,
                    "-f",
                    f"{tmpdir}/{name}",
                ],
                cwd=_PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            if proc.returncode != 0:
                _record("ECC ECDH (keygen)", False, proc.stderr or proc.stdout)
                return

        alice_pri_path = f"{tmpdir}/alice_ecc_private.pem"
        bob_pub_path = f"{tmpdir}/bob_ecc_public.pem"
        with open(alice_pri_path) as f:
            alice_pri_pem = f.read()
        with open(bob_pub_path) as f:
            bob_pub_pem = f.read()

        # EET 执行 ECDH（使用 CipherHUB 默认 salt/context）
        proc = subprocess.run(
            [
                sys.executable,
                "-m",
                "easy_encryption_tool.main",
                "ecc",
                "ecdh",
                "-k",
                alice_pri_path,
                "-b",
                bob_pub_path,
                "-s",
                cipherhub_defaults.DEFAULT_ECC_SALT,
                "-c",
                cipherhub_defaults.DEFAULT_ECC_ADDITIONAL_INFO,
                "-H",
                "sha512",
                "-l",
                "32",
            ],
            cwd=_PROJECT_ROOT,
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            _record("ECC ECDH (eet)", False, proc.stderr or proc.stdout)
            return

        eet_derived_b64 = _parse_copyable_block(proc.stdout, "derived key", is_hex=False)
        if not eet_derived_b64:
            _record("ECC ECDH (eet parse)", False, "could not parse derived key")
            return
        eet_derived_b64 = "".join(c for c in eet_derived_b64 if c in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=")
        # 32 bytes -> 44 base64 chars; fix length if regex captured extra char
        n = len(eet_derived_b64)
        if n % 4 != 0:
            eet_derived_b64 = eet_derived_b64[: (n // 4) * 4]
        pad = 4 - len(eet_derived_b64) % 4
        if pad != 4:
            eet_derived_b64 += "=" * pad
        eet_derived_hex = base64.b64decode(eet_derived_b64).hex()

        # CipherHUB handler 执行 ECDH（相同参数）
        req = EccKeyExchangeRequest(
            request_id=uuid.uuid4().hex,
            alice_ecc_private_key_in_pem=alice_pri_pem,
            alice_ecc_private_key_password="",
            bob_ecc_public_key_in_pem=bob_pub_pem,
            hash_algorithm="Sha512",
            salt=cipherhub_defaults.DEFAULT_ECC_SALT,
            additional_info=cipherhub_defaults.DEFAULT_ECC_ADDITIONAL_INFO,
            derived_key_length=32,
        )
        handler = EccKeyExchangeHandler(request_body=req.model_dump_json().encode("utf-8"))
        resp = handler.do_process(req)

        if resp.code != ApiSuccess.success.value:
            _record("ECC ECDH (CipherHUB)", False, resp.msg or "handler failed")
            return

        ch_derived_hex = resp.derived_key_in_hex
        passed = eet_derived_hex == ch_derived_hex
        _record("ECC ECDH (eet<->CipherHUB)", passed)


def run_all():
    print("=" * 60)
    print("easy_encryption_tool <-> CipherHUB 兼容性测试")
    print("=" * 60)
    print(f"明文: {PLAINTEXT}")
    print()

    test_block_cipher_aes256_cbc()
    test_block_cipher_aes256_cbc_reverse()
    test_stream_cipher_aes256_gcm()
    test_hash_sha256()
    test_hash_sm3()
    test_hmac_sha256()
    test_hmac_sm3()
    test_zuc()
    test_sm4_cbc()
    test_ecdh_eet_cipherhub()

    passed = sum(1 for r in RESULTS if r["passed"])
    total = len(RESULTS)
    print()
    print("=" * 60)
    print(f"结果: {passed}/{total} 通过")
    print("=" * 60)
    return passed == total


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
