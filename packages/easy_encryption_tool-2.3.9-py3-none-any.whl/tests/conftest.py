#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
pytest 共享 fixtures 与配置。
"""
from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path

import pytest


def strip_ansi(text: str) -> str:
    """移除 ANSI 转义序列，便于测试断言"""
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def extract_base64(text: str, min_len: int = 50) -> str | None:
    """从输出中提取 base64 字符串（仅 ASCII 字符），优先返回较长的匹配"""
    matches = re.findall(r"[A-Za-z0-9+/]+=*", text)
    long_matches = [m for m in matches if len(m) >= min_len]
    return max(long_matches, key=len) if long_matches else (matches[0] if matches else None)


def extract_value_after_key(text: str, key: str) -> str | None:
    """
    从 strip_ansi 后的表格输出中提取 key: 后的 value。
    支持 value 因表格换行而跨多行的情况。
    """
    # 匹配完整 key（避免 cipher 匹配到 cipher_mode）
    pattern = re.compile(r"(?<!\w)" + re.escape(key) + r"(?!\w)\s*:\s*", re.IGNORECASE)
    match = pattern.search(text)
    if not match:
        return None
    start = match.end()
    rest = text[start:]
    # 收集到下一个 key: 行（新行开头 + 单词 + :）
    lines = rest.split("\n")
    value_parts = []
    for line in lines:
        if re.match(r"^\s*\w+\s*:", line) and key.lower() not in line.lower():
            break
        value_parts.append(line)
    raw = "".join(value_parts)
    # 只保留 base64 字符
    cleaned = re.sub(r"[^A-Za-z0-9+/=]", "", raw)
    return cleaned if len(cleaned) >= 8 else None


@pytest.fixture
def tmp_dir():
    """临时目录，测试结束后自动清理"""
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def tmp_file(tmp_dir):
    """返回一个可写的临时文件路径"""

    def _make(content: bytes = b""):
        fd, path = tempfile.mkstemp(dir=tmp_dir)
        os.close(fd)
        if content:
            Path(path).write_bytes(content)
        return path

    return _make


@pytest.fixture
def sample_plaintext():
    """测试用明文"""
    return "hello world"


@pytest.fixture
def sample_plaintext_bytes(sample_plaintext):
    return sample_plaintext.encode("utf-8")


@pytest.fixture(autouse=True)
def no_color(monkeypatch):
    """禁用 Rich 颜色输出，便于测试断言"""
    monkeypatch.setenv("NO_COLOR", "1")
    monkeypatch.setenv("TERM", "dumb")
