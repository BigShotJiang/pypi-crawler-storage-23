#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
tool_version 命令单元测试。
"""
from __future__ import annotations

import pytest
from click.testing import CliRunner

from easy_encryption_tool import tool_version


runner = CliRunner()


class TestShowVersion:
    """show_version 命令测试"""

    def test_show_version(self):
        result = runner.invoke(tool_version.show_version)
        assert result.exit_code == 0
        assert "version" in result.output.lower()
        assert "python" in result.output.lower()


class TestSysInfo:
    """sys_info 函数测试"""

    def test_sys_info_returns_dict(self):
        info = tool_version.sys_info()
        assert isinstance(info, dict)
        assert "PythonVersion" in info
        assert "OSPlatform" in info
        assert "BytesEndian" in info
