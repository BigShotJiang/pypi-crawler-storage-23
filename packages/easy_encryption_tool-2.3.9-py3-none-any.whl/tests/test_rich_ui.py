#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
rich_ui 模块单元测试。
"""
from __future__ import annotations

from unittest.mock import patch

import pytest

from .conftest import strip_ansi
from easy_encryption_tool import rich_ui


class TestResultPanel:
    def test_result_panel(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.result_panel("content", "Title")
            mock_print.assert_called_once()


class TestResultSimple:
    def test_result_simple(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.result_simple({"key": "value"})
            mock_print.assert_called_once()


class TestWelcomePanel:
    def test_welcome_panel(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.welcome_panel([("Cmd", "example")])
            mock_print.assert_called_once()


class TestSuggestionPanel:
    def test_suggestion_panel(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.suggestion_panel(["hash", "aes"])
            mock_print.assert_called_once()


class TestTimingFunctions:
    def test_timing_begin(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.timing_begin("flag", "2024-01-01_12:00:00")
            mock_print.assert_called_once()

    def test_timing_end(self):
        with patch.object(rich_ui.console, "print") as mock_print:
            rich_ui.timing_end("flag", 123.45)
            mock_print.assert_called_once()
            assert "123.450" in mock_print.call_args[0][0]
