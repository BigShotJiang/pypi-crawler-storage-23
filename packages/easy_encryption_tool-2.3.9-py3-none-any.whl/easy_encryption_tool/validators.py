#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Centralized parameter validation.
- -e (base64) and -f (file) are mutually exclusive
- Output file required when input is a file
- Input source validation and hints
"""
from __future__ import annotations

import re
from typing import Callable, Optional, Tuple

import click


def validate_b64_or_file(
    is_base64: bool,
    is_file: bool,
    context: str = "",
) -> Tuple[bool, Optional[str]]:
    """
    Validate that -e (base64) and -f (file) are mutually exclusive.
    :return: (passed, error_message)
    """
    if is_base64 and is_file:
        msg = "Input cannot be both base64 and file path; -e and -f are mutually exclusive"
        if context:
            msg = f"{context}: {msg}"
        return False, msg
    return True, None


def validate_file_output_required(
    is_file: bool,
    output_file: str,
    context: str = "",
) -> Tuple[bool, Optional[str]]:
    """
    Validate: when input is a file, output file must be specified.
    """
    if is_file and (not output_file or len(output_file.strip()) == 0):
        msg = "Output file (-o/--output-file) required when input is a file"
        if context:
            msg = f"{context}: {msg}"
        return False, msg
    return True, None


def looks_like_base64(s: str) -> bool:
    """Simple heuristic: whether string might be base64-encoded"""
    if not s or len(s) < 16:
        return False
    s_clean = s.replace("\n", "").replace("\r", "").replace(" ", "")
    if len(s_clean) % 4 not in (0, 2):  # base64 length usually multiple of 4
        return False
    return bool(re.match(r"^[A-Za-z0-9+/]+=*$", s_clean))


def hint_decrypt_maybe_b64(input_preview: str, context: str = "decrypt") -> str:
    """
    When decrypt fails and input might be base64, return hint message.
    """
    if looks_like_base64(
        input_preview[:64] if len(input_preview) > 64 else input_preview
    ):
        return f"  For {context}, -i should be base64 cipher; add -e if input is base64-encoded"
    return ""


# Base64 param: unified as -e/--is-base64-encoded across all commands
