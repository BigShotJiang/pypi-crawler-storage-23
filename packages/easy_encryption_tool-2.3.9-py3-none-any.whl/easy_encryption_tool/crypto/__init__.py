#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Crypto core logic module (reserved for extension).
Currently reuses process_key_iv etc. from common for future migration of aes_operator, rsa_ops.
"""
from __future__ import annotations

from easy_encryption_tool.common import process_key_iv

__all__ = ["process_key_iv"]
