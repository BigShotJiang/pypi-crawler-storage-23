#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
SM2 asymmetric algorithm (Chinese standard, similar to RSA).
Supports encrypt/decrypt (multiple cipher formats) and sign/verify (multiple signature formats).
"""
from __future__ import annotations

import base64
import time

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import command_perf
from easy_encryption_tool import common
from easy_encryption_tool import shell_completion
from easy_encryption_tool import hints
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

try:
    from easy_gmssl import (
        EasySm2EncryptionKey,
        EasySM2SignKey,
        EasySM2VerifyKey,
        SM2CipherMode,
        SM2CipherFormat,
        SignatureMode,
    )
    from easy_gmssl.gmssl import SM2_DEFAULT_ID, SM3_DIGEST_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False
    SM3_DIGEST_SIZE = 32  # SM3 digest is 32 bytes

sm2_cipher_modes = ["C1C3C2_ASN1", "C1C3C2", "C1C2C3_ASN1", "C1C2C3"]
sm2_cipher_format_choices = ["base64", "hex"]
sm2_signature_modes = ["RS_ASN1", "RS"]


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM2")
        return False
    return True


def _cipher_mode_from_str(s: str) -> SM2CipherMode:
    return SM2CipherMode(s)


def _cipher_format_from_str(s: str) -> SM2CipherFormat:
    return SM2CipherFormat.Base64Str if s == "base64" else SM2CipherFormat.HexStr


def _signature_mode_from_str(s: str) -> SignatureMode:
    return SignatureMode.RS_ASN1 if s == "RS_ASN1" else SignatureMode.RS


def _format_sm2_signature(sig_asn1: bytes, signature_mode: str) -> bytes:
    """Format ASN1 signature from SignDigest according to signature_mode.
    RS format: r||s must be 32 bytes each (SM2 standard).
    """
    if signature_mode == "RS_ASN1":
        return sig_asn1
    # RS format: parse ASN1 to get r||s (32 bytes each)
    from pyasn1.codec.der import decoder
    from easy_gmssl import SM2_RS_ASN1_Signature

    decoded, _ = decoder.decode(sig_asn1, asn1Spec=SM2_RS_ASN1_Signature())
    r_int, s_int = int(decoded["r"]), int(decoded["s"])
    if r_int.bit_length() > 256 or s_int.bit_length() > 256:
        raise ValueError("SM2 r/s must fit in 32 bytes (256 bits).")
    return r_int.to_bytes(32, "big") + s_int.to_bytes(32, "big")


def _normalize_hex_input(s: str) -> str:
    """Strip 0x/0X prefix and whitespace from hex string for bytes.fromhex"""
    s = s.strip()
    if s.lower().startswith("0x"):
        s = s[2:].strip()
    return s


def _sig_bytes_to_asn1_for_verify(sig_bytes: bytes, signature_mode: str) -> bytes:
    """Convert RS format signature to ASN1 for verify (VerifyDigestSignature needs ASN1)"""
    if signature_mode == "RS_ASN1":
        return sig_bytes
    if len(sig_bytes) != 64:
        raise ValueError("RS format signature must be 64 bytes")
    from pyasn1.codec.der import encoder
    from easy_gmssl import SM2_RS_ASN1_Signature

    r_int = int.from_bytes(sig_bytes[:32], "big")
    s_int = int.from_bytes(sig_bytes[32:], "big")
    sig_obj = SM2_RS_ASN1_Signature()
    sig_obj.setComponentByName("r", r_int)
    sig_obj.setComponentByName("s", s_int)
    return encoder.encode(sig_obj)


@click.group(name="sm2", short_help="SM2 encrypt/decrypt and sign/verify")
def sm2_group():
    pass


@click.command(name="generate")
@click.option(
    "-f",
    "--file-name",
    required=False,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="Output file name prefix for key pair",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default=None,
    help="Private key password, 1-32 bytes; omit when -r is used",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Generate random private key password (32 bytes); omit -p when used",
)
@output_format_options
@command_perf.timing_decorator
def sm2_generate(
    file_name: str, password: str, random_password: bool, output_format: str | None
):
    """Generate SM2 key pair (private key random; -r adds random password)"""
    request_id = create_request_id()
    start = time.perf_counter()

    if not _check_gmssl():
        return
    if random_password and password:
        error("SM2: -p/--password and -r/--random-password are mutually exclusive")
        raise SystemExit(1)
    if random_password:
        from easy_encryption_tool import random_str

        password = random_str.generate_random_str(32)
    if password is None or len(password) <= 0 or len(password) > 32:
        error(
            "SM2 private key password must be 1-32 bytes (use -r to auto-generate)"
        )
        raise SystemExit(1)
    try:
        key = EasySm2EncryptionKey()
        key.NewKey()
        key.ExportToPemFile(file_name_prefix=file_name, pri_key_password=password)
        public_file = "{}_sm2_public.pem".format(file_name)
        private_file = "{}_sm2_private.pem".format(file_name)

        duration_ms = (time.perf_counter() - start) * 1000
        metadata = build_metadata(
            operation="generate",
            algorithm="sm2",
            parameters={"encoding": "pem"},
        )
        result_data = {"public_file": public_file, "private_file": private_file}
        if random_password:
            result_data["password"] = password
        result = build_result(**result_data)
        output = build_output(
            metadata=metadata,
            result=result,
            request_id=request_id,
            duration_ms=duration_ms,
        )
        render(output, mode=resolve_output_format(output_format), primary_key="public_file")
    except BaseException as e:
        error("sm2 generate failed: {}".format(e))


@click.command(name="encrypt")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="Public key file path (PEM format)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: string or base64 (use -e for base64)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-m",
    "--cipher-mode",
    required=False,
    type=click.Choice(sm2_cipher_modes),
    default="C1C3C2_ASN1",
    show_default=True,
    help="Cipher format",
)
@click.option(
    "-o",
    "--cipher-format",
    "cipher_format",
    required=False,
    type=click.Choice(sm2_cipher_format_choices),
    default="base64",
    show_default=True,
    help="Cipher output format: base64 or hex",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length (MB)",
)
@output_format_options
@command_perf.timing_decorator
def sm2_encrypt(
    public_key: str,
    input_data: str,
    is_base64_encoded: bool,
    cipher_mode: str,
    cipher_format: str,
    input_limit: int,
    output_format: str | None,
):
    """SM2 public key encrypt"""
    request_id = create_request_id()
    start = time.perf_counter()

    if not _check_gmssl():
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except Exception as e:
            error("invalid b64 encoded data: {}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error("input exceeds limit: {} MB".format(input_limit))
        return
    try:
        enc_key = EasySm2EncryptionKey()
        enc_key.LoadSm2PubKey(public_key)
        cipher = enc_key.Encrypt(
            plain_data=input_raw_bytes,
            cipher_mode=_cipher_mode_from_str(cipher_mode),
            cipher_format=_cipher_format_from_str(cipher_format),
        )

        duration_ms = (time.perf_counter() - start) * 1000
        metadata = build_metadata(
            operation="encrypt",
            algorithm="sm2",
            encoding=cipher_format,
            input_type="binary" if is_base64_encoded else "text",
            input_size=len(input_raw_bytes),
            parameters={
                "cipher_mode": cipher_mode,
                "cipher_size": len(cipher),
            },
        )
        result = build_result(cipher=cipher)
        output = build_output(
            metadata=metadata,
            result=result,
            request_id=request_id,
            duration_ms=duration_ms,
        )
        render(output, mode=resolve_output_format(output_format), primary_key="cipher")
    except BaseException as e:
        error("sm2 encrypt failed: {}".format(e))


@click.command(name="decrypt")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path (PEM format)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Cipher data, base64 or hex encoded",
)
@click.option(
    "-x",
    "--hex-input",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is hex-encoded (default base64)",
)
@click.option(
    "-m",
    "--cipher-mode",
    required=False,
    type=click.Choice(sm2_cipher_modes),
    default="C1C3C2_ASN1",
    show_default=True,
    help="Cipher format, must match encrypt",
)
@click.option(
    "-p", "--password", required=True, type=click.STRING, help="Private key password"
)
@output_format_options
@command_perf.timing_decorator
def sm2_decrypt(
    private_key: str,
    input_data: str,
    hex_input: bool,
    cipher_mode: str,
    password: str,
    output_format: str | None,
):
    """SM2 private key decrypt"""
    request_id = create_request_id()
    start = time.perf_counter()

    if not _check_gmssl():
        return
    if not password or len(password.strip()) <= 0:
        error("SM2 private key password is required (cannot be empty)")
        return
    try:
        if hex_input:
            cipher_bytes = bytes.fromhex(_normalize_hex_input(input_data))
        else:
            cipher_bytes = common.decode_b64_data(input_data)
    except ValueError as e:
        hint = "hex must be even length, 0-9a-fA-F only" if hex_input else "base64"
        error("invalid input data ({}): {}".format(hint, e))
        return
    except BaseException as e:
        error("invalid input data: {}".format(e))
        return
    try:
        dec_key = EasySm2EncryptionKey()
        dec_key.LoadSm2PrivateKey(pri_key_file=private_key, password=password)
        plain = dec_key.Decrypt(
            cipher_data=cipher_bytes,
            cipher_mode=_cipher_mode_from_str(cipher_mode),
        )
        be_str, ret = common.bytes_to_str(plain)

        duration_ms = (time.perf_counter() - start) * 1000
        metadata = build_metadata(
            operation="decrypt",
            algorithm="sm2",
            encoding="utf-8" if be_str else "base64",
            input_type="binary",
            input_size=len(cipher_bytes),
            parameters={
                "cipher_mode": cipher_mode,
                "input_format": "hex" if hex_input else "base64",
                "plain_size": len(plain),
            },
        )
        result = build_result(plain=ret)
        output = build_output(
            metadata=metadata,
            result=result,
            request_id=request_id,
            duration_ms=duration_ms,
        )
        render(output, mode=resolve_output_format(output_format), primary_key="plain")
    except BaseException as e:
        error("sm2 decrypt failed: {}".format(e))


@click.command(name="sign")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Data to sign (raw or SM3 digest, use -d for digest)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is SM3 pre-computed digest (32 bytes), not raw data; CipherHUB sign_raw_data_mode=False compatible",
)
@click.option(
    "-m",
    "--signature-mode",
    required=False,
    type=click.Choice(sm2_signature_modes),
    default="RS_ASN1",
    show_default=True,
    help="Signature format: RS_ASN1(DER) or RS(64 bytes r||s)",
)
@click.option(
    "-p", "--password", required=True, type=click.STRING, help="Private key password"
)
@click.option(
    "--signer-id",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_SM2_SIGNER_ID,
    show_default=True,
    help="SM2 signer ID, CipherHUB default compatible",
)
@output_format_options
@command_perf.timing_decorator
def sm2_sign(
    private_key: str,
    input_data: str,
    is_base64_encoded: bool,
    signature_mode: str,
    password: str,
    signer_id: str,
    input_is_digest: bool,
    output_format: str | None,
):
    """SM2 private key sign (raw or SM3 digest, CipherHUB compatible)"""
    request_id = create_request_id()
    start = time.perf_counter()

    if not _check_gmssl():
        return
    if not password or len(password.strip()) <= 0:
        error("SM2 private key password is required (cannot be empty)")
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except Exception as e:
            error("invalid b64 encoded data: {}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    # input-is-digest: only SM3 fixed 32 bytes (SM2 standard)
    if input_is_digest:
        if len(input_raw_bytes) != SM3_DIGEST_SIZE:
            error(
                "input-is-digest mode requires SM3 digest ({} bytes), got: {} bytes".format(
                    SM3_DIGEST_SIZE, len(input_raw_bytes)
                )
            )
            return

    try:
        if input_is_digest:
            # Sign digest: EasySm2EncryptionKey.SignDigest, CipherHUB compatible
            key = EasySm2EncryptionKey()
            key.LoadSm2PrivateKey(pri_key_file=private_key, password=password)
            sig_asn1 = key.SignDigest(input_raw_bytes)
            sig = _format_sm2_signature(sig_asn1, signature_mode)
        else:
            # Sign raw data: EasySM2SignKey
            sign_key = EasySM2SignKey(
                signer_id=signer_id,
                pem_private_key_file=private_key,
                password=password,
            )
            sign_key.UpdateData(input_raw_bytes)
            sig = sign_key.GetSignValue(
                signature_mode=_signature_mode_from_str(signature_mode)
            )
        sig_b64 = base64.b64encode(sig).decode("utf-8")
        duration_ms = (time.perf_counter() - start) * 1000
        metadata = build_metadata(
            operation="sign",
            algorithm="sm2",
            encoding="base64",
            input_type="binary" if is_base64_encoded else "text",
            input_size=len(input_raw_bytes),
            parameters={
                "signature_mode": signature_mode,
                "input_type": "SM3 digest" if input_is_digest else "raw data",
                "signature_size": len(sig),
            },
        )
        result = build_result(signature=sig_b64)
        output = build_output(
            metadata=metadata,
            result=result,
            request_id=request_id,
            duration_ms=duration_ms,
        )
        render(output, mode=resolve_output_format(output_format), primary_key="signature")
    except BaseException as e:
        error("sm2 sign failed: {}".format(e))


@click.command(name="verify")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="Public key file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Data to verify (raw or SM3 digest, use -d for digest)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is SM3 pre-computed digest (32 bytes), not raw data; CipherHUB sign_raw_data_mode=False compatible",
)
@click.option(
    "-s",
    "--signature",
    required=True,
    type=click.STRING,
    help="Signature value, base64 or hex (required)",
)
@click.option(
    "-m",
    "--signature-mode",
    required=False,
    type=click.Choice(sm2_signature_modes),
    default="RS_ASN1",
    show_default=True,
    help="Signature format",
)
@click.option(
    "--sig-b64/--sig-hex", default=True, help="Signature is base64 (default) or hex"
)
@click.option(
    "--signer-id",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_SM2_SIGNER_ID,
    show_default=True,
    help="SM2 signer ID, CipherHUB default compatible",
)
@output_format_options
@command_perf.timing_decorator
def sm2_verify(
    public_key: str,
    input_data: str,
    is_base64_encoded: bool,
    signature: str,
    signature_mode: str,
    sig_b64: bool,
    signer_id: str,
    input_is_digest: bool,
    output_format: str | None,
):
    """SM2 public key verify (raw or SM3 digest, CipherHUB compatible)"""
    request_id = create_request_id()
    start = time.perf_counter()

    if not _check_gmssl():
        return
    if not signature or len(signature.strip()) <= 0:
        error("signature cannot be empty")
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except Exception as e:
            error("invalid b64 encoded data: {}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    if input_is_digest:
        if len(input_raw_bytes) != SM3_DIGEST_SIZE:
            error(
                "input-is-digest mode requires SM3 digest ({} bytes), got: {} bytes".format(
                    SM3_DIGEST_SIZE, len(input_raw_bytes)
                )
            )
            return

    try:
        if sig_b64:
            sig_bytes = common.decode_b64_data(signature)
        else:
            sig_bytes = bytes.fromhex(_normalize_hex_input(signature))
    except ValueError as e:
        hint = "hex must be even length, 0-9a-fA-F only" if not sig_b64 else "base64"
        error("invalid signature ({}): {}".format(hint, e))
        return
    except BaseException as e:
        error("invalid signature: {}".format(e))
        return
    if len(sig_bytes) <= 0:
        error("signature is empty after decode")
        return
    try:
        if input_is_digest:
            # Verify digest: EasySm2EncryptionKey.VerifyDigestSignature
            key = EasySm2EncryptionKey()
            key.LoadSm2PubKey(public_key)
            sig_asn1 = _sig_bytes_to_asn1_for_verify(sig_bytes, signature_mode)
            ok = key.VerifyDigestSignature(input_raw_bytes, sig_asn1)
        else:
            verify_key = EasySM2VerifyKey(
                signer_id=signer_id,
                pem_public_key_file=public_key,
            )
            verify_key.UpdateData(input_raw_bytes)
            ok = verify_key.VerifySignature(
                signature_data=sig_bytes,
                signature_mode=_signature_mode_from_str(signature_mode),
            )
        if ok:
            duration_ms = (time.perf_counter() - start) * 1000
            metadata = build_metadata(
                operation="verify",
                algorithm="sm2",
                input_type="binary" if is_base64_encoded else "text",
                input_size=len(input_raw_bytes),
                parameters={"signature_mode": signature_mode},
            )
            result = build_result(valid=True)
            output = build_output(
                metadata=metadata,
                result=result,
                request_id=request_id,
                duration_ms=duration_ms,
            )
            render(output, mode=resolve_output_format(output_format), primary_key="valid")
        else:
            error("verify failed | signature_mode: {}".format(signature_mode))
    except BaseException as e:
        error("sm2 verify failed: {}".format(e))


sm2_group.add_command(sm2_generate)
sm2_group.add_command(sm2_encrypt)
sm2_group.add_command(sm2_decrypt)
sm2_group.add_command(sm2_sign)
sm2_group.add_command(sm2_verify)
