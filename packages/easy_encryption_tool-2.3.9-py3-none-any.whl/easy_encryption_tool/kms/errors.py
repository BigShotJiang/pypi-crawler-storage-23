#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""KMS error types."""

from __future__ import annotations


class KMSError(Exception):
    """Base exception for KMS operations."""

    pass


class KMSNotAvailableError(KMSError):
    """Raised when KMS extras are not installed."""

    pass
