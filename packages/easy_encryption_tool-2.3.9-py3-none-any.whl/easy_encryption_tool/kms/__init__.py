#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""KMS integration for envelope encryption."""

from __future__ import annotations

from easy_encryption_tool.kms.availability import is_kms_available
from easy_encryption_tool.kms.backends import get_backend
from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError, KMSNotAvailableError

__all__ = [
    "get_backend",
    "is_kms_available",
    "KMSError",
    "KMSNotAvailableError",
    "KMSConfig",
    "get_default_kms_config",
]
