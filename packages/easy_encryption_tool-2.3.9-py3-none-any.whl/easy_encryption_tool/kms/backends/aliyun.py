#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""Alibaba Cloud (Aliyun) KMS backend implementation."""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass

_ALIYUN_CONFIG_PATH = Path.home() / ".aliyun" / "config.json"


def _load_credential_from_config_file() -> tuple[str, str] | None:
    """Load credential from ~/.aliyun/config.json (aliyun-cli format).
    Returns (access_key_id, access_key_secret) or None.
    """
    try:
        if not _ALIYUN_CONFIG_PATH.exists():
            return None
        data = json.loads(_ALIYUN_CONFIG_PATH.read_text(encoding="utf-8"))
        current = data.get("current", "default")
        profiles = data.get("profiles") or []
        for p in profiles:
            if p.get("name") == current:
                access_key_id = p.get("access_key_id")
                access_key_secret = p.get("access_key_secret")
                if access_key_id and access_key_secret:
                    return (str(access_key_id), str(access_key_secret))
                return None
    except (OSError, json.JSONDecodeError, KeyError):
        pass
    return None


def _get_credential() -> tuple[str, str]:
    """Get Alibaba Cloud credential. Priority:
    1. Env vars ALIBABA_CLOUD_ACCESS_KEY_ID/SECRET or ACCESS_KEY_ID/SECRET
    2. ~/.aliyun/config.json (aliyun-cli format)
    """
    access_key_id = os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_ID") or os.environ.get("ACCESS_KEY_ID")
    access_key_secret = (
        os.environ.get("ALIBABA_CLOUD_ACCESS_KEY_SECRET") or os.environ.get("ACCESS_KEY_SECRET")
    )
    if access_key_id and access_key_secret:
        return (access_key_id, access_key_secret)

    file_cred = _load_credential_from_config_file()
    if file_cred:
        return file_cred

    raise KMSError(
        "Alibaba Cloud KMS requires credentials. Set ALIBABA_CLOUD_ACCESS_KEY_ID and "
        "ALIBABA_CLOUD_ACCESS_KEY_SECRET env vars, or use ~/.aliyun/config.json (aliyun-cli format)"
    )


def _get_request_id_from_exception(exc: Exception) -> str | None:
    """Extract Alibaba Cloud RequestId from exception if present."""
    try:
        if hasattr(exc, "data") and isinstance(exc.data, dict):
            return exc.data.get("RequestId")
        if hasattr(exc, "message") and "RequestId" in str(exc.message):
            return None  # Could parse, but skip for simplicity
    except Exception:
        pass
    return None


class AliyunKMSBackend:
    """Alibaba Cloud (Aliyun) KMS backend for envelope encryption.

    Uses GenerateDataKey and Decrypt APIs. Credentials from (in order):
    1. Env vars ALIBABA_CLOUD_ACCESS_KEY_ID, ALIBABA_CLOUD_ACCESS_KEY_SECRET;
       or legacy ACCESS_KEY_ID, ACCESS_KEY_SECRET
    2. ~/.aliyun/config.json (aliyun-cli format)
    See: https://help.aliyun.com/document_detail/28948.html
    """

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._config = config or get_default_kms_config()

    def _get_client(self):
        try:
            from alibabacloud_kms20160120.client import Client
            from alibabacloud_tea_openapi import models as openapi_models
        except ImportError as e:
            raise KMSError(
                "Alibaba Cloud KMS requires alibabacloud-kms20160120. "
                "Install: pip install easy_encryption_tool[kms]"
            ) from e

        access_key_id, access_key_secret = _get_credential()
        endpoint = None
        if self.endpoint_url:
            endpoint = self.endpoint_url.replace("https://", "").replace("http://", "")
        openapi_config = openapi_models.Config(
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            region_id=self.region,
            endpoint=endpoint,
            read_timeout=int(self._config.read_timeout * 1000),  # ms
            connect_timeout=int(self._config.connect_timeout * 1000),  # ms
        )
        return Client(openapi_config)

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        Alibaba Cloud returns Plaintext and CiphertextBlob as base64 strings.
        Store ciphertext_blob as UTF-8 bytes for envelope; pass string to Decrypt.
        """
        try:
            from alibabacloud_kms20160120 import models

            client = self._get_client()
            req = models.GenerateDataKeyRequest()
            req.key_id = key_id
            req.number_of_bytes = number_of_bytes
            resp = client.generate_data_key(req)
            body = resp.body
            plaintext_b64 = body.plaintext
            ciphertext_b64 = body.ciphertext_blob
            request_id = body.request_id if body else None
            plaintext = base64.b64decode(plaintext_b64)
            # Store ciphertext as UTF-8 bytes (base64 string); Decrypt expects base64 string
            ciphertext_blob = ciphertext_b64.encode("utf-8")
            return (plaintext, ciphertext_blob, request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Alibaba Cloud KMS GenerateDataKey failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        key_id is optional - Alibaba Cloud KMS extracts from CiphertextBlob metadata.
        CiphertextBlob is base64 string; pass as UTF-8 decoded string.
        """
        try:
            from alibabacloud_kms20160120 import models

            client = self._get_client()
            req = models.DecryptRequest()
            req.ciphertext_blob = ciphertext_blob.decode("utf-8")
            resp = client.decrypt(req)
            body = resp.body
            plaintext_b64 = body.plaintext
            request_id = body.request_id if body else None
            plaintext = base64.b64decode(plaintext_b64)
            return (plaintext, request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Alibaba Cloud KMS Decrypt failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e
