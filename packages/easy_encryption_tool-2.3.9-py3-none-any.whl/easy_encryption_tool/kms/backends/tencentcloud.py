#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""Tencent Cloud KMS backend implementation."""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass

_TC_CLI_CREDENTIAL_PATH = Path.home() / ".tccli" / "default.credential"


def _load_credential_from_file() -> tuple[str, str] | None:
    """Load credential from ~/.tccli/default.credential. Returns (secret_id, secret_key) or None."""
    try:
        if not _TC_CLI_CREDENTIAL_PATH.exists():
            return None
        data = json.loads(_TC_CLI_CREDENTIAL_PATH.read_text(encoding="utf-8"))
        secret_id = data.get("secretId") or data.get("secret_id")
        secret_key = data.get("secretKey") or data.get("secret_key")
        if secret_id and secret_key:
            return (str(secret_id), str(secret_key))
    except (OSError, json.JSONDecodeError, KeyError):
        pass
    return None


def _get_credential():
    """Get Tencent Cloud credential from env vars or ~/.tccli/default.credential."""
    try:
        from tencentcloud.common import credential
    except ImportError as e:
        raise KMSError(
            "Tencent Cloud KMS requires tencentcloud-sdk-python-kms. "
            "Install: pip install easy_encryption_tool[kms]"
        ) from e

    secret_id = os.environ.get("TENCENTCLOUD_SECRET_ID")
    secret_key = os.environ.get("TENCENTCLOUD_SECRET_KEY")
    if secret_id and secret_key:
        return credential.Credential(secret_id, secret_key)

    file_cred = _load_credential_from_file()
    if file_cred:
        return credential.Credential(file_cred[0], file_cred[1])

    raise KMSError(
        "Tencent Cloud KMS requires credentials. Set TENCENTCLOUD_SECRET_ID and "
        "TENCENTCLOUD_SECRET_KEY env vars, or use ~/.tccli/default.credential file"
    )


def _get_request_id_from_exception(exc: Exception) -> str | None:
    """Extract Tencent Cloud RequestId from exception if present."""
    try:
        if hasattr(exc, "get_request_id"):
            return exc.get_request_id()
        if hasattr(exc, "requestId"):
            return getattr(exc, "requestId", None)
    except Exception:
        pass
    return None


class TencentCloudKMSBackend:
    """Tencent Cloud KMS backend for envelope encryption.

    Uses GenerateDataKey and Decrypt APIs. Credentials from (in order):
    1. Env vars TENCENTCLOUD_SECRET_ID, TENCENTCLOUD_SECRET_KEY
    2. ~/.tccli/default.credential (JSON: secretId, secretKey)
    See: https://cloud.tencent.com/document/product/573/34419
    """

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._config = config or get_default_kms_config()

    def _get_client(self):
        try:
            from tencentcloud.common.profile.client_profile import ClientProfile
            from tencentcloud.common.profile.http_profile import HttpProfile
            from tencentcloud.kms.v20190118 import kms_client
        except ImportError as e:
            raise KMSError(
                "Tencent Cloud KMS requires tencentcloud-sdk-python-kms. "
                "Install: pip install easy_encryption_tool[kms]"
            ) from e

        cred = _get_credential()
        http_profile = HttpProfile(reqTimeout=int(self._config.read_timeout))
        if self.endpoint_url:
            http_profile.endpoint = self.endpoint_url.replace("https://", "").replace("http://", "")
        profile = ClientProfile(httpProfile=http_profile)
        return kms_client.KmsClient(cred, self.region, profile)

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        Tencent Cloud CiphertextBlob uses "-k-" separator format (string), NOT raw base64.
        Store as UTF-8 bytes for envelope; pass string to Decrypt.
        """
        try:
            from tencentcloud.kms.v20190118 import models

            client = self._get_client()
            req = models.GenerateDataKeyRequest()
            req.KeyId = key_id
            req.NumberOfBytes = number_of_bytes
            resp = client.GenerateDataKey(req)
            plaintext_b64 = resp.Plaintext
            ciphertext_str = resp.CiphertextBlob  # "-k-" separator format, do NOT base64 decode
            request_id = getattr(resp, "RequestId", None)
            plaintext = base64.b64decode(plaintext_b64)
            ciphertext_blob = ciphertext_str.encode("utf-8")  # store string as bytes for envelope
            return (plaintext, ciphertext_blob, request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Tencent Cloud KMS GenerateDataKey failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        key_id is optional - Tencent Cloud KMS extracts from CiphertextBlob metadata.
        CiphertextBlob is "-k-" separator format string; pass as-is, do NOT base64 encode.
        """
        try:
            from tencentcloud.kms.v20190118 import models

            client = self._get_client()
            req = models.DecryptRequest()
            req.CiphertextBlob = ciphertext_blob.decode("utf-8")  # "-k-" format string, pass directly
            resp = client.Decrypt(req)
            plaintext_b64 = resp.Plaintext
            request_id = getattr(resp, "RequestId", None)
            plaintext = base64.b64decode(plaintext_b64)
            return (plaintext, request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Tencent Cloud KMS Decrypt failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e
