#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""KMS backends."""

from __future__ import annotations

from typing import Union

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.backends.aliyun import AliyunKMSBackend
from easy_encryption_tool.kms.backends.aws import AWSKMSBackend
from easy_encryption_tool.kms.backends.tencentcloud import TencentCloudKMSBackend


def get_backend(
    backend_name: str,
    region: str,
    endpoint_url: str | None = None,
    config: KMSConfig | None = None,
) -> Union[AliyunKMSBackend, AWSKMSBackend, TencentCloudKMSBackend]:
    """Get KMS backend instance. Supports 'aws', 'tencentcloud', 'aliyun'.
    config: KMS timeout config; default 5s connect/read. All backends enforce timeout.
    """
    kms_config = config or get_default_kms_config()
    if backend_name == "aws":
        return AWSKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    if backend_name == "tencentcloud":
        return TencentCloudKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    if backend_name == "aliyun":
        return AliyunKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    raise ValueError(f"Unsupported KMS backend: {backend_name}")
