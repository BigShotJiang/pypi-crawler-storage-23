#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""Check if KMS backend dependencies are available."""

from __future__ import annotations


def is_kms_available() -> bool:
    """Check if any KMS backend SDK is installed (boto3 for AWS, tencentcloud for Tencent Cloud, alibabacloud for Alibaba Cloud)."""
    try:
        import boto3  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import tencentcloud.kms.v20190118  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import alibabacloud_kms20160120  # noqa: F401
        return True
    except ImportError:
        pass
    return False
