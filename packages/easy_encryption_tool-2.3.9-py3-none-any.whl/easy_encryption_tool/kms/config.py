#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""KMS backend-agnostic configuration. Timeout is mandatory for all vendors."""

from __future__ import annotations

from dataclasses import dataclass

# Default timeout 5 seconds (connect + read). All KMS backends MUST enforce this.
KMS_DEFAULT_TIMEOUT_SECONDS = 5


@dataclass(frozen=True)
class KMSConfig:
    """
    KMS configuration applicable to all backends (AWS, etc.).
    Timeout is mandatory to avoid hanging on network issues.
    """

    connect_timeout: float = KMS_DEFAULT_TIMEOUT_SECONDS
    read_timeout: float = KMS_DEFAULT_TIMEOUT_SECONDS

    def __post_init__(self) -> None:
        if self.connect_timeout <= 0 or self.read_timeout <= 0:
            raise ValueError("KMS connect_timeout and read_timeout must be positive")


def get_default_kms_config() -> KMSConfig:
    """Return default KMS config with 5s timeout."""
    return KMSConfig()
