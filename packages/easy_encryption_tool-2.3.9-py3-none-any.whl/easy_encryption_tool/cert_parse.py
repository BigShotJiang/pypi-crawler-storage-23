#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-05 15:16:05
from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict

import click
import requests
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding
from cryptography.x509 import Extensions
from OpenSSL import crypto
from OpenSSL.crypto import X509

from easy_encryption_tool import command_perf, common, hints, shell_completion
from easy_encryption_tool.rich_ui import echo, error, success

try:
    from easy_gmssl import EasySm2Certificate

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

version = "version"
serial_number = "serial_number"
signature_algorithm = "signature_algorithm"
signature_hash_algorithm = "signature_hash_algorithm"
tbs_certificate_bytes = "tbs_certificate_bytes"
issuer = "issuer"
valid_before = "valid_before"
valid_after = "valid_after"
subject = "subject"
public_key_bits = "public_key_bits"
public_key_modules = "public_key_modules"
public_key_exponent = "public_key_exponent"
public_key_type = "public_key_type"
public_key_fingerprints = "public_key_fingerprints"
signature = "signature"
certificate_fingerprints = "certificate_fingerprints"
extension_count = "extension_count"
extensions = "extensions_detail"

ca_issuer = None
ocsp = None

# RFC 5280 Authority Information Access method OIDs (use dotted_string, not _name)
OID_AD_CA_ISSUERS = "1.3.6.1.5.5.7.48.2"
OID_AD_OCSP = "1.3.6.1.5.5.7.48.1"

AuthorityInformationAccessCAIssuers = "caIssuers"
AuthorityInformationAccessOCSP = "OCSP"
AuthorityInformationAccess = (
    "x509.AuthorityInformationAccess",
    x509.AuthorityInformationAccess,
)
BasicConstraints = ("x509.BasicConstraints", x509.BasicConstraints)
KeyUsage = ("x509.KeyUsage", x509.KeyUsage)
SubjectKeyIdentifier = ("x509.SubjectKeyIdentifier", x509.SubjectKeyIdentifier)
SubjectAlternativeName = ("x509.SubjectAlternativeName", x509.SubjectAlternativeName)
CRLDistributionPoints = ("x509.CRLDistributionPoints", x509.CRLDistributionPoints)
ExtendedKeyUsage = ("x509.ExtendedKeyUsage", x509.ExtendedKeyUsage)
FreshestCR = ("x509.FreshestCRL", x509.FreshestCRL)
NameConstraints = ("x509.NameConstraints", x509.NameConstraints)
PolicyConstraints = ("x509.PolicyConstraints", x509.PolicyConstraints)

cert_extensions = [
    AuthorityInformationAccess,
    BasicConstraints,
    KeyUsage,
    SubjectKeyIdentifier,
    SubjectAlternativeName,
    CRLDistributionPoints,
    ExtendedKeyUsage,
    FreshestCR,
    NameConstraints,
    PolicyConstraints,
]

verbose_info_keys = [
    tbs_certificate_bytes,
    public_key_exponent,
    public_key_modules,
    public_key_fingerprints,
    signature,
    certificate_fingerprints,
    extension_count,
    extensions,
]

cert_info_keys = [
    version,
    serial_number,
    signature_algorithm,
    signature_hash_algorithm,
    issuer,
    valid_before,
    valid_after,
    subject,
    public_key_bits,
    public_key_type,
]


def _safe_name_attr(name_obj, attr: str, default: str = "") -> str:
    """Safely get X509Name attribute, handling None/missing/bytes."""
    try:
        val = getattr(name_obj, attr, None)
        if val is None:
            return default
        if isinstance(val, bytes):
            return val.decode("utf-8", errors="replace")
        return str(val)
    except (AttributeError, TypeError, UnicodeDecodeError):
        return default


def _safe_decode_time(val) -> str:
    """Safely decode notBefore/notAfter (bytes or object) to string."""
    if val is None:
        return ""
    try:
        if isinstance(val, bytes):
            return val.decode("utf-8", errors="replace")
        return str(val)
    except (TypeError, UnicodeDecodeError):
        return ""


def parse_cert_extensions(cert_extensions_raw: Extensions) -> Dict[str, Any]:
    ret = {}
    for i in cert_extensions:
        try:
            ext_value = cert_extensions_raw.get_extension_for_class(i[1])
        except x509.ExtensionNotFound:
            ret[i[0]] = {
                "ERROR": "x509.ExtensionNotFound",
                "oid": "",
                "value": {},
                "critical": False,
            }
            continue
        else:
            ret[i[0]] = {
                "oid": ext_value.oid.dotted_string,
                "critical": ext_value.critical,
                "value": ext_value.value.__repr__(),
            }
            if i[0] == AuthorityInformationAccess[0]:
                ret[i[0]]["value"] = {
                    AuthorityInformationAccessCAIssuers: "",
                    AuthorityInformationAccessOCSP: "",
                }
                for v in ext_value.value:
                    method_oid = v.access_method.dotted_string
                    if method_oid == OID_AD_CA_ISSUERS:
                        ret[i[0]]["value"][
                            AuthorityInformationAccessCAIssuers
                        ] = v.access_location.value
                    elif method_oid == OID_AD_OCSP:
                        ret[i[0]]["value"][
                            AuthorityInformationAccessOCSP
                        ] = v.access_location.value

    return ret


def get_cert_info(cert: X509):
    issuer_obj = cert.get_issuer()
    subject_obj = cert.get_subject()
    cert_info_map = {
        version: "{}-{}".format(
            cert.to_cryptography().version.name, cert.to_cryptography().version.value
        ),
        serial_number: cert.get_serial_number(),
        signature_hash_algorithm: (
            cert.to_cryptography().signature_hash_algorithm.name
            if cert.to_cryptography().signature_hash_algorithm
            else "unknown"
        ),
        issuer: "{}|{}|{}".format(
            _safe_name_attr(issuer_obj, "organizationName"),
            _safe_name_attr(issuer_obj, "commonName"),
            _safe_name_attr(issuer_obj, "countryName"),
        ),
        valid_before: _safe_decode_time(cert.get_notBefore()),
        valid_after: _safe_decode_time(cert.get_notAfter()),
        subject: "{}|{}|{}".format(
            _safe_name_attr(subject_obj, "organizationName"),
            _safe_name_attr(subject_obj, "countryName"),
            _safe_name_attr(subject_obj, "commonName"),
        ),
        public_key_bits: cert.get_pubkey().bits(),
        public_key_type: "{}({}:RSA|{}:DSA|{}:EC|{}:DH)".format(
            cert.get_pubkey().type(),
            crypto.TYPE_RSA,
            crypto.TYPE_DSA,
            crypto.TYPE_EC,
            crypto.TYPE_DH,
        ),
        public_key_fingerprints: hashlib.sha256(
            cert.get_pubkey()
            .to_cryptography_key()
            .public_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            )
        )
        .hexdigest()
        .upper(),
        signature: hex(
            int.from_bytes(cert.to_cryptography().signature, byteorder="big")
        ).upper(),
        certificate_fingerprints: cert.digest(hashes.SHA256.name).hex().upper(),
        extension_count: str(cert.get_extension_count()),
    }

    if cert.get_pubkey().type() == crypto.TYPE_RSA:
        cert_info_map[signature_algorithm] = "PKCS #1 RSA Encryption"
        cert_info_map[public_key_modules] = (
            format(
                cert.get_pubkey().to_cryptography_key().public_numbers().n, "x"
            ).upper(),
        )
        cert_info_map[public_key_exponent] = (
            format(
                cert.get_pubkey().to_cryptography_key().public_numbers().e, "x"
            ).upper(),
        )
    elif cert.get_pubkey().type() == crypto.TYPE_EC:
        cert_info_map[signature_algorithm] = "Elliptic Curve Public Key"
    cert_info_map[extensions] = parse_cert_extensions(cert.to_cryptography().extensions)
    return cert_info_map


CERT_FILE_MAX_SIZE = 1024 * 10  # 10KB


def load_cert_data(cert_file: str) -> bytes:
    """
    Load raw certificate data. Reads within with-block to avoid TOCTOU race,
    then validates size to prevent OOM from oversized files.
    """
    try:
        with common.read_from_file(cert_file) as input_file:
            cert_raw_bytes = input_file.read_n_bytes(CERT_FILE_MAX_SIZE + 1)
        if len(cert_raw_bytes) > CERT_FILE_MAX_SIZE:
            error(
                "cert file {} size > {} Bytes, too large (max {} KB)".format(
                    cert_file, CERT_FILE_MAX_SIZE, CERT_FILE_MAX_SIZE // 1024
                )
            )
            raise ValueError("cert file too large (max 10KB)")
        if len(cert_raw_bytes) == 0:
            error("cert file {} is empty".format(cert_file))
            raise ValueError("cert file is empty")
        return cert_raw_bytes
    except ValueError:
        raise
    except BaseException as e:
        error("read cert file {} failed: {}".format(cert_file, e))
        raise


def read_file_from_url(url: str) -> tuple[bytes | None, str | None]:
    """
    Fetch content from URL. Returns (content, error_hint).
    - (bytes, None): success
    - (None, "empty_url"): url empty or None
    - (None, "http_NNN"): non-200 status
    - (None, "network"): timeout or connection error
    """
    if url is None or not str(url).strip():
        return None, "empty_url"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.content, None
        return None, "http_{}".format(response.status_code)
    except requests.Timeout:
        return None, "timeout"
    except requests.RequestException:
        return None, "network"


def verify_cert_signature(cert: X509, ca_cert: X509):
    try:
        cert_signature = cert.to_cryptography().signature
        hash_alg = cert.to_cryptography().signature_hash_algorithm
        cert_tbs_certificate_bytes = cert.to_cryptography().tbs_certificate_bytes
        signature_algorithm_oid = cert.to_cryptography().signature_algorithm_oid
        ca_pub_key = ca_cert.to_cryptography().public_key()
        if ca_cert.get_pubkey().type() == crypto.TYPE_RSA:
            rsa_padding = None
            if signature_algorithm_oid in (
                x509.OID_RSA_WITH_SHA1,
                x509.OID_RSA_WITH_SHA224,
                x509.OID_RSA_WITH_SHA256,
                x509.OID_RSA_WITH_SHA384,
                x509.OID_RSA_WITH_SHA512,
            ):
                rsa_padding = padding.PKCS1v15()
                # print('pkcs1v15 padding')
            elif signature_algorithm_oid in (x509.OID_RSASSA_PSS,):
                rsa_padding = padding.PSS(
                    mgf=padding.MGF1(algorithm=hash_alg),
                    salt_length=padding.PSS.MAX_LENGTH,
                )
                # print('pss padding')
            ca_pub_key.verify(
                signature=cert_signature,
                data=cert_tbs_certificate_bytes,
                algorithm=hash_alg,
                padding=rsa_padding,
            )
        elif ca_cert.get_pubkey().type() == crypto.TYPE_EC:
            ca_pub_key.verify(
                cert_signature, cert_tbs_certificate_bytes, ec.ECDSA(hash_alg)
            )
        else:
            raise ValueError(
                "Unsupported CA key type for signature verification: {}".format(
                    ca_cert.get_pubkey().type()
                )
            )
    except InvalidSignature as e:
        raise InvalidSignature("signature verified failed")


def verify_cert_file_signature_from_ca_issuer(cert: X509, ca_issuer_url: str):
    ca_issuer_cert_raw, fetch_err = read_file_from_url(ca_issuer_url)
    if ca_issuer_cert_raw is None:
        if fetch_err == "empty_url":
            raise ValueError("AIA caIssuers URL is empty, cannot verify signature")
        if fetch_err == "timeout":
            raise ValueError(
                "fetch CA issuer cert timeout (10s): {}".format(ca_issuer_url)
            )
        if fetch_err and fetch_err.startswith("http_"):
            raise ValueError(
                "fetch CA issuer cert failed, HTTP {}: {}".format(
                    fetch_err.replace("http_", ""), ca_issuer_url
                )
            )
        raise ValueError(
            "fetch CA issuer cert failed (network error): {}".format(ca_issuer_url)
        )
    for i in [crypto.FILETYPE_PEM, crypto.FILETYPE_ASN1]:
        try:
            ca_cert = crypto.load_certificate(i, ca_issuer_cert_raw)
        except BaseException:
            if i == crypto.FILETYPE_ASN1:  # All formats tried but still failed
                raise ValueError(
                    "ca issuer cert load failed, tried PEM and DER, issuer: {}".format(
                        ca_issuer_url
                    )
                )
            continue
        try:
            verify_cert_signature(cert, ca_cert)
        except BaseException:
            raise InvalidSignature(
                "verify cert signature failed, ca issuer: {}".format(
                    ca_issuer_url
                )
            )
        return


def _parse_sm2_cert(cert_file: str, verbose: bool):
    """Parse GM/T SM2 certificate (PEM format only)"""
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("GM cert parse")
        return
    try:
        sm2_cert = EasySm2Certificate(pem_file=cert_file)
    except BaseException as e:
        error("loading sm2 cert file {} failed: {}".format(cert_file, e))
        return
    try:
        serial = sm2_cert.GetSerialNumber()
        issuer = sm2_cert.GetIssuer()
        subject = sm2_cert.GetSubject()
        validity = sm2_cert.GetValidity()
        pub_key = sm2_cert.GetSubjectPublicKey()
        echo("------- basic info (SM2 GM cert) -------")
        echo("serial_number: {}".format(serial.hex() if serial else ""))
        echo(
            "issuer: {}".format(
                json.dumps(issuer, ensure_ascii=False) if issuer else ""
            )
        )
        echo(
            "subject: {}".format(
                json.dumps(subject, ensure_ascii=False) if subject else ""
            )
        )
        if validity:
            echo("valid_before: {}".format(validity.not_before))
            echo("valid_after: {}".format(validity.not_after))
        echo("public_key_type: SM2")
        if verbose and pub_key:
            try:
                pub_hex = (
                    pub_key.get_public_key_hex()
                    if hasattr(pub_key, "get_public_key_hex")
                    else ""
                )
                if pub_hex:
                    echo("public_key_hex: {}".format(pub_hex))
            except BaseException:
                pass
    except BaseException as e:
        error("parse sm2 cert info error: {}".format(e))


@click.command(
    name="cert-parse", short_help="Parse PEM/DER certs, international + GM SM2"
)
@click.option(
    "-f",
    "--cert-file",
    required=True,
    type=click.STRING,
    help="Certificate file path",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-e",
    "--encoding",
    required=False,
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Certificate format",
)
@click.option(
    "-g",
    "--gm-cert",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Parse as GM SM2 certificate (PEM only)",
)
@click.option(
    "-v",
    "--verbose",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Show verbose details",
)
@command_perf.timing_decorator
def parse_x509_cert_file(
    cert_file: click.STRING,
    encoding: click.STRING,
    gm_cert: click.BOOL,
    verbose: click.BOOL,
):
    if not cert_file or not str(cert_file).strip():
        error("cert file path cannot be empty")
        return

    if gm_cert:
        if encoding != "pem":
            error("GM cert parse supports PEM only, use -e pem")
            return
        _parse_sm2_cert(cert_file, verbose)
        return

    try:
        cert_raw_bytes = load_cert_data(cert_file)
    except BaseException as e:
        return
    else:
        try:
            if encoding == "pem":
                cert_type = crypto.FILETYPE_PEM
            else:
                cert_type = crypto.FILETYPE_ASN1
            cert = crypto.load_certificate(cert_type, cert_raw_bytes)
        except BaseException as e:
            if EASY_GMSSL_AVAILABLE and encoding == "pem":
                error(
                    "loading as standard cert failed: {}, try with -g for GM cert".format(
                        e
                    )
                )
            else:
                error(
                    "loading cert file {} as format {} failed: {}".format(
                        cert_file, encoding, e
                    )
                )
            return
        else:
            try:
                # Parse cert data, especially AIA (Authority Information Access)
                # Use it to fetch root cert and get root public key
                data = get_cert_info(cert)
            except BaseException as e:
                error("parse cert file info error: {}".format(e))
            else:
                exts = data[extensions]
                if AuthorityInformationAccess[0] in exts.keys():
                    echo("------- verify signature: -------")
                    try:
                        ca_issuer_url = exts[AuthorityInformationAccess[0]]["value"].get(
                            AuthorityInformationAccessCAIssuers, ""
                        )
                        if not ca_issuer_url or not str(ca_issuer_url).strip():
                            error(
                                "AIA caIssuers URL is empty, skip signature verification"
                            )
                        else:
                            try:
                                verify_cert_file_signature_from_ca_issuer(
                                    cert, ca_issuer_url
                                )
                            except BaseException as e:
                                error(
                                    "verify cert signature failed: {}, ca issuer: {}".format(
                                        e, ca_issuer_url
                                    )
                                )
                            else:
                                success(
                                    "verify cert signature success | ca issuer: {}".format(
                                        ca_issuer_url
                                    )
                                )
                    except BaseException:
                        error("NO CA ISSUER FOUND")

                echo("------- basic info: -------")
                for i in cert_info_keys:
                    if i in data.keys():
                        ret = data[i]
                        if isinstance(data[i], dict):
                            ret = json.dumps(data[i], indent="    ")
                        echo("{}: {}".format(i, ret))

                if verbose:
                    echo("\n------- verbose info: -------")
                    for i in verbose_info_keys:
                        if i in data.keys():
                            ret = data[i]
                            if isinstance(data[i], dict):
                                ret = json.dumps(data[i], indent="    ")
                            echo("{}: {}".format(i, ret))


if __name__ == "__main__":
    parse_x509_cert_file()
