#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
Unified hash command: SM3 (GM/T) and SHA256, SHA384, SHA512.
"""
from __future__ import annotations

import hashlib
import time

import click

from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

try:
    from easy_gmssl import EasySM3Digest

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

hash_alg_map = {
    "sha256": hashlib.sha256,
    "sha384": hashlib.sha384,
    "sha512": hashlib.sha512,
}
if EASY_GMSSL_AVAILABLE:
    hash_alg_map["sm3"] = "sm3"


# --- Crypto logic (unchanged) ---
def _compute_hash_fixed(alg: str, data: bytes) -> bytes:
    if alg == "sm3":
        return EasySM3Digest.Hash(data)
    h = hash_alg_map[alg]()
    h.update(data)
    return h.digest()


def _hash_bytes(alg: str, data: bytes) -> bytes:
    """Hash in-memory data."""
    return _compute_hash_fixed(alg, data)


def _hash_file(alg: str, file_path: str) -> tuple[bytes, int]:
    """Hash file. Returns (digest, size_bytes)."""
    with common.read_from_file(file_path) as input_file:
        if alg == "sm3":
            ctx = EasySM3Digest()
            data_len = 0
            while True:
                chunk = input_file.read_n_bytes(4096)
                if not chunk:
                    break
                ctx.UpdateData(chunk)
                data_len += len(chunk)
            digest, _, _ = ctx.GetHash()
        else:
            h = hash_alg_map[alg]()
            data_len = 0
            while True:
                chunk = input_file.read_n_bytes(4096)
                if not chunk:
                    break
                h.update(chunk)
                data_len += len(chunk)
            digest = h.digest()
    return digest, data_len


@click.command(name="hash", short_help="Hash digest: SM3, SHA256, SHA384, SHA512")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input: string, base64, or file path",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    type=click.Choice(list(hash_alg_map.keys())),
    default="sha256",
    show_default=True,
    help="Hash algorithm",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), applies when -i is not a file; use -l N for larger data",
)
@output_format_options
def hash_command(
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    hash_alg: str,
    input_limit: int = 1,
    output_format: str | None = None,
):
    """Compute hash digest. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if hash_alg == "sm3" and not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM3")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "hash")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    request_id = create_request_id()
    start = time.perf_counter()

    digest: bytes | None = None
    input_size: int = 0

    if not is_a_file:
        if not is_base64_encoded:
            try:
                input_raw_bytes = input_data.encode("utf-8")
            except UnicodeEncodeError:
                error("input contains invalid UTF-8 characters")
                return
            if len(input_raw_bytes) > input_limit * 1024 * 1024:
                error(
                    "data exceeds limit: {} Bytes (max {} MB, use -l to increase)".format(
                        len(input_raw_bytes), input_limit
                    )
                )
                return
        else:
            try:
                input_raw_bytes = common.decode_b64_data(input_data)
            except BaseException as e:
                error("invalid b64 encoded data: {}".format(e))
                hints.hint_invalid_b64("hash")
                return
            if len(input_raw_bytes) > input_limit * 1024 * 1024:
                error(
                    "data exceeds limit: {} Bytes (max {} MB, use -l to increase)".format(
                        len(input_raw_bytes), input_limit
                    )
                )
                return
        input_size = len(input_raw_bytes)
        digest = _hash_bytes(hash_alg, input_raw_bytes)
    else:
        try:
            digest, input_size = _hash_file(hash_alg, input_data)
        except OSError:
            error("file {} may not exist or may not be readable".format(input_data))
            return

    duration_ms = (time.perf_counter() - start) * 1000

    # Output building
    input_type = "file" if is_a_file else ("binary" if is_base64_encoded else "text")
    metadata = build_metadata(
        operation="hash",
        algorithm=hash_alg,
        formats={"digest": "hex"},
        input_type=input_type,
        input_size=input_size,
        parameters={"digest_size": len(digest)},
    )
    result = build_result(digest=digest.hex())
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )

    # Rendering
    mode = resolve_output_format(output_format)
    render(output, mode=mode, primary_key="digest")


if __name__ == "__main__":
    hash_command()
