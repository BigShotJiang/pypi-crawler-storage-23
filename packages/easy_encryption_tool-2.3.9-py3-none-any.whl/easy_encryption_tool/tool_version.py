#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 22:02:07

import platform
import sys
from typing import Dict

import click

from easy_encryption_tool import __version__, command_perf
from easy_encryption_tool.rich_ui import result_table


def sys_info() -> Dict[str, str]:
    return {
        "PythonVersion": sys.version,
        "ApiVersion": sys.api_version,
        "OSPlatform": sys.platform,
        "OSProcessor": platform.platform(),
        "BytesEndian": sys.byteorder,
    }


# Get version from package, keep in sync with setup.py
tool_version_info = (
    __version__ if str(__version__).startswith("v") else "v{}".format(__version__)
)
info = sys_info()


# Author website and tagline (from https://cipherhub.cloud/about)
CIPHERHUB_WEBSITE = "https://cipherhub.cloud"
CIPHERHUB_TAGLINE = "Serious Cryptography · Creative Solutions · Mapping Digital Trust"

# Core stack description
CORE_STACK = "click+rich (interaction & styling), cryptography+easy_gmssl (crypto)"


@click.command(
    name="version",
    short_help="Show version and runtime info",
    help="Show tool version, runtime info and core stack (click+rich, cryptography+easy_gmssl).",
)
@command_perf.timing_decorator
def show_version():
    # Block 1: Current running environment info
    result_table(
        {
            "PythonVersion": info["PythonVersion"],
            "ApiVersion": info["ApiVersion"],
            "OSPlatform": info["OSPlatform"],
            "OSProcessor": info["OSProcessor"],
            "BytesEndian": info["BytesEndian"],
        },
        title="Your current running environment info",
    )
    # Block 2: Package version info
    result_table(
        {
            "version": tool_version_info,
            "core": CORE_STACK,
        },
        title="Package version info",
    )
    # Block 3: Author personal info
    result_table(
        {
            "website": CIPHERHUB_WEBSITE,
            "tagline": CIPHERHUB_TAGLINE,
        },
        title="Author info",
    )
