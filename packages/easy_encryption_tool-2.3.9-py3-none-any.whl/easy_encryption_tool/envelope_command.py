#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Envelope encryption: asymmetric key wraps DEK, DEK encrypts data.
Single envelope format with issuer metadata, struct checksum, plaintext binding.
V2: mode (local/kms), symmetric algo (aes-256-gcm/sm4-gcm/chacha20-poly1305), format (json/blob).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import struct
import tempfile
import time

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import random_str
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error
from easy_encryption_tool import shell_completion
from easy_encryption_tool import hints

# Envelope format constants
EET_MAGIC = b"EET"
FORMAT_VERSION = 0x01
FORMAT_VERSION_CHUNKED = 0x02  # Chunked, 4-byte ciphertext_len (max 4GB)
FORMAT_VERSION_CHUNKED_LARGE = 0x03  # Chunked, 8-byte ciphertext_len (support > 4GB)
ALGO_AES_256_GCM = 0x01
ALGO_SM4_GCM = 0x02
ALGO_CHACHA20_POLY1305 = 0x03
WRAP_RSA = 0x01
WRAP_KMS = 0x02

# RSA key sizes allowed
RSA_ALLOWED_SIZES = (2048, 3072, 4096)

# Unified error for all decrypt failures (no padding oracle)
DECRYPT_FAILED_MSG = "Decryption failed: invalid envelope or wrong key."

# Symmetric params
GCM_NONCE_LEN = 12
GCM_TAG_LEN = 16
HMAC_LEN = 32
SHA256_LEN = 32

# Symmetric algo registry: id -> (key_len, nonce_len, tag_len)
SYMMETRIC_ALGO_REGISTRY: dict[str, tuple[int, int, int, int]] = {
    "aes-256-gcm": (ALGO_AES_256_GCM, 32, GCM_NONCE_LEN, GCM_TAG_LEN),
    "sm4-gcm": (ALGO_SM4_GCM, 16, GCM_NONCE_LEN, GCM_TAG_LEN),
    "chacha20-poly1305": (ALGO_CHACHA20_POLY1305, 32, GCM_NONCE_LEN, GCM_TAG_LEN),
}

# Wrap key type names for output
WRAP_KEY_TYPE_NAMES = {WRAP_RSA: "rsa", WRAP_KMS: "kms"}

# KMS backends (for list-algorithms)
KMS_BACKENDS = ["aws", "tencentcloud", "aliyun"]

# Chunk size for streaming encryption (32MB)
STREAM_CHUNK_SIZE = 32 * 1024 * 1024

# Threshold: use v3 (8-byte ciphertext_len) when > 4GB
CIPHERTEXT_LEN_4BYTE_MAX = 0xFFFFFFFF


def _get_eet_version() -> str:
    from easy_encryption_tool import __version__

    v = __version__
    return v if str(v).startswith("v") else f"v{v}"


def _load_rsa_public_key(file_path: str) -> tuple[object | None, str | None]:
    """
    Load RSA public key. Returns (key, None) on success, (None, error_msg) on failure.
    """
    try:
        with open(file_path, "rb") as f:
            data = f.read()
    except FileNotFoundError:
        return None, "Public key file not found: {}".format(file_path)
    except OSError as e:
        return None, "Cannot read public key file: {} ({})".format(file_path, e)

    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.backends import default_backend

        key = serialization.load_pem_public_key(data, backend=default_backend())
    except Exception as e:
        return None, "Invalid public key format: {} ({})".format(file_path, e)

    if not isinstance(key, rsa.RSAPublicKey):
        key_type = type(key).__name__.replace("PublicKey", "").lower() or "unknown"
        return None, "Public key must be RSA (got {} key)".format(key_type)

    if key.key_size not in RSA_ALLOWED_SIZES:
        return None, "Public key must be 2048, 3072, or 4096 bits (got {} bits)".format(key.key_size)

    return key, None


def _load_rsa_private_key(file_path: str, password: bytes | None):
    """Load RSA private key. Returns (key_obj,) or None."""
    try:
        from cryptography.hazmat.primitives.asymmetric import rsa

        pri = common.load_private_key(
            encoding="pem", file_path=file_path, password_bytes=password
        )
        if pri is not None and isinstance(pri, rsa.RSAPrivateKey) and pri.key_size in RSA_ALLOWED_SIZES:
            return pri
    except Exception:
        pass
    return None


def _rsa_encrypt_dek(pub_key, dek: bytes) -> bytes:
    """Encrypt DEK with RSA OAEP-SHA256."""
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes

    pad = padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None,
    )
    return pub_key.encrypt(plaintext=dek, padding=pad)


def _rsa_decrypt_dek(pri_key, enc_dek: bytes) -> bytes:
    """Decrypt DEK with RSA OAEP-SHA256."""
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes

    pad = padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None,
    )
    return pri_key.decrypt(ciphertext=enc_dek, padding=pad)


def _aes_gcm_encrypt(key: bytes, nonce: bytes, aad: bytes, plaintext: bytes) -> bytes:
    """AES-256-GCM encrypt. Returns ciphertext||tag."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    aes = AESGCM(key)
    return aes.encrypt(nonce=nonce, data=plaintext, associated_data=aad)


def _aes_gcm_decrypt(key: bytes, nonce: bytes, aad: bytes, cipher_with_tag: bytes) -> bytes:
    """AES-256-GCM decrypt."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    aes = AESGCM(key)
    return aes.decrypt(nonce=nonce, data=cipher_with_tag, associated_data=aad)


def _sm4_gcm_encrypt(key: bytes, nonce: bytes, aad: bytes, plaintext: bytes) -> bytes:
    """SM4-GCM encrypt. Returns ciphertext||tag. Requires easy_gmssl."""
    from easy_gmssl import EasySm4GCM

    sm4 = EasySm4GCM(key=key, iv=nonce, aad=aad, do_encrypt=True)
    return sm4.Update(plaintext) + sm4.Finish()


def _sm4_gcm_decrypt(key: bytes, nonce: bytes, aad: bytes, cipher_with_tag: bytes) -> bytes:
    """SM4-GCM decrypt. Requires easy_gmssl."""
    from easy_gmssl import EasySm4GCM

    sm4 = EasySm4GCM(key=key, iv=nonce, aad=aad, do_encrypt=False)
    return sm4.Update(cipher_with_tag) + sm4.Finish()


def _chacha20_poly1305_encrypt(key: bytes, nonce: bytes, aad: bytes, plaintext: bytes) -> bytes:
    """ChaCha20-Poly1305 encrypt. Returns ciphertext||tag."""
    from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

    cipher = ChaCha20Poly1305(key)
    return cipher.encrypt(nonce=nonce, data=plaintext, associated_data=aad)


def _chacha20_poly1305_decrypt(key: bytes, nonce: bytes, aad: bytes, cipher_with_tag: bytes) -> bytes:
    """ChaCha20-Poly1305 decrypt."""
    from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

    cipher = ChaCha20Poly1305(key)
    return cipher.decrypt(nonce=nonce, data=cipher_with_tag, associated_data=aad)


def _symmetric_encrypt(algo_id: int, key: bytes, nonce: bytes, aad: bytes, plaintext: bytes) -> bytes:
    """Encrypt with symmetric algo. Returns ciphertext||tag."""
    if algo_id == ALGO_AES_256_GCM:
        return _aes_gcm_encrypt(key, nonce, aad, plaintext)
    if algo_id == ALGO_SM4_GCM:
        return _sm4_gcm_encrypt(key, nonce, aad, plaintext)
    if algo_id == ALGO_CHACHA20_POLY1305:
        return _chacha20_poly1305_encrypt(key, nonce, aad, plaintext)
    raise ValueError("unsupported algo_id")


def _symmetric_decrypt(algo_id: int, key: bytes, nonce: bytes, aad: bytes, cipher_with_tag: bytes) -> bytes:
    """Decrypt with symmetric algo."""
    if algo_id == ALGO_AES_256_GCM:
        return _aes_gcm_decrypt(key, nonce, aad, cipher_with_tag)
    if algo_id == ALGO_SM4_GCM:
        return _sm4_gcm_decrypt(key, nonce, aad, cipher_with_tag)
    if algo_id == ALGO_CHACHA20_POLY1305:
        return _chacha20_poly1305_decrypt(key, nonce, aad, cipher_with_tag)
    raise ValueError("unsupported algo_id")


def _derive_chunk_nonce(dek: bytes, main_nonce: bytes, chunk_index: int) -> bytes:
    """Derive unique nonce for chunk. HMAC-SHA256(dek, main_nonce || index)[:12]."""
    data = main_nonce + struct.pack(">I", chunk_index)
    return hmac.new(dek, data, hashlib.sha256).digest()[:GCM_NONCE_LEN]


def _chunk_aad(base_aad: bytes, chunk_index: int) -> bytes:
    """AAD for chunk: base_aad || chunk_index to bind index."""
    return base_aad + struct.pack(">I", chunk_index)


def _build_envelope_header(
    algo_id: int,
    wrap_key_type: int,
    eet_version: str,
    request_id: str,
    aad: bytes,
    nonce: bytes,
    enc_dek: bytes,
    plaintext_binding: bytes,
    ciphertext_len: int,
    format_version: int = FORMAT_VERSION,
) -> bytes:
    """Build envelope header bytes (up to and including ciphertext_len). For streaming write."""
    eet_ver_bytes = eet_version.encode("utf-8")
    req_id_bytes = request_id.encode("utf-8")
    if format_version == FORMAT_VERSION_CHUNKED_LARGE:
        ct_len_bytes = struct.pack(">Q", ciphertext_len)
    else:
        ct_len_bytes = struct.pack(">I", ciphertext_len)
    parts = [
        EET_MAGIC,
        bytes([format_version, algo_id, wrap_key_type]),
        bytes([len(eet_ver_bytes)]),
        eet_ver_bytes,
        bytes([len(req_id_bytes)]),
        req_id_bytes,
        struct.pack(">H", len(aad)),
        aad,
        nonce,
        struct.pack(">H", len(enc_dek)),
        enc_dek,
        plaintext_binding,
        ct_len_bytes,
    ]
    return b"".join(parts)


def _encrypt_stream_to_file(
    input_path: str,
    output_path: str,
    algo_id: int,
    wrap_key_type: int,
    eet_version: str,
    request_id: str,
    aad_bytes: bytes,
    nonce: bytes,
    enc_dek: bytes,
    dek: bytes,
    no_force: bool,
) -> tuple[bytes, int]:
    """
    Stream encrypt: read plaintext in chunks, encrypt, write ciphertext to temp,
    then build envelope by streaming to output. O(1) memory for ciphertext.
    Returns (plaintext_binding, total_plain_len).
    """
    parent = os.path.dirname(os.path.abspath(output_path)) or "."
    fd, tmp_path = tempfile.mkstemp(dir=parent, prefix=".env_ct_")
    try:
        with os.fdopen(fd, "wb") as tmp:
            tmp.write(struct.pack(">I", 0))
            h = hmac.new(dek, digestmod=hashlib.sha256)
            total_len = 0
            chunk_count = 0
            with open(input_path, "rb") as fin:
                for i, chunk in enumerate(
                    iter(lambda: fin.read(STREAM_CHUNK_SIZE), b"")
                ):
                    if not chunk:
                        continue
                    total_len += len(chunk)
                    chunk_count += 1
                    h.update(chunk)
                    nonce_i = _derive_chunk_nonce(dek, nonce, i)
                    aad_i = _chunk_aad(aad_bytes, i)
                    ct = _symmetric_encrypt(algo_id, dek, nonce_i, aad_i, chunk)
                    tmp.write(struct.pack(">I", len(ct)) + ct)
            tmp.seek(0)
            tmp.write(struct.pack(">I", chunk_count))
            plaintext_binding = h.digest()

        ciphertext_len = os.path.getsize(tmp_path)
        format_ver = (
            FORMAT_VERSION_CHUNKED_LARGE
            if ciphertext_len > CIPHERTEXT_LEN_4BYTE_MAX
            else FORMAT_VERSION_CHUNKED
        )
        header = _build_envelope_header(
            algo_id=algo_id,
            wrap_key_type=wrap_key_type,
            eet_version=eet_version,
            request_id=request_id,
            aad=aad_bytes,
            nonce=nonce,
            enc_dek=enc_dek,
            plaintext_binding=plaintext_binding,
            ciphertext_len=ciphertext_len,
            format_version=format_ver,
        )
        sha = hashlib.sha256()
        sha.update(header)
        with common.write_to_file(output_path, force=not no_force) as out:
            out.write_bytes(header)
            with open(tmp_path, "rb") as tmp:
                for chunk in iter(lambda: tmp.read(65536), b""):
                    if chunk:
                        out.write_bytes(chunk)
                        sha.update(chunk)
            out.write_bytes(sha.digest())
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    return plaintext_binding, total_len


def _decrypt_stream(
    algo_id: int,
    dek: bytes,
    main_nonce: bytes,
    aad_bytes: bytes,
    ciphertext_blob: bytes,
    writer=None,
) -> tuple[bytes, bytes | None, int]:
    """
    Decrypt chunked ciphertext. If writer is provided, write chunks to it; else collect.
    Returns (plaintext_binding, plaintext_collected, total_size).
    plaintext_collected is None when writer used.
    """
    if len(ciphertext_blob) < 4:
        raise ValueError("chunked ciphertext too short")
    num_chunks = struct.unpack(">I", ciphertext_blob[:4])[0]
    if num_chunks > 0x7FFFFFFF:
        raise ValueError("invalid chunk count")
    off = 4
    h = hmac.new(dek, digestmod=hashlib.sha256)
    collected: list[bytes] = [] if writer is None else None
    total_size = 0
    for i in range(num_chunks):
        if off + 4 > len(ciphertext_blob):
            raise ValueError("chunk length truncated")
        chunk_len = struct.unpack(">I", ciphertext_blob[off : off + 4])[0]
        off += 4
        if chunk_len > 0x7FFFFFFF or off + chunk_len > len(ciphertext_blob):
            raise ValueError("chunk data truncated")
        chunk_ct = ciphertext_blob[off : off + chunk_len]
        off += chunk_len
        nonce_i = _derive_chunk_nonce(dek, main_nonce, i)
        aad_i = _chunk_aad(aad_bytes, i)
        plain_chunk = _symmetric_decrypt(algo_id, dek, nonce_i, aad_i, chunk_ct)
        total_size += len(plain_chunk)
        h.update(plain_chunk)
        if writer is not None:
            writer(plain_chunk)
        else:
            collected.append(plain_chunk)
    binding = h.digest()
    plaintext = b"".join(collected) if collected is not None else None
    return binding, plaintext, total_size


def _build_envelope(
    algo_id: int,
    wrap_key_type: int,
    eet_version: str,
    request_id: str,
    aad: bytes,
    nonce: bytes,
    enc_dek: bytes,
    plaintext_binding: bytes,
    ciphertext: bytes,
    format_version: int = FORMAT_VERSION,
) -> bytes:
    """Build envelope binary. ciphertext = cipher||tag for GCM (v1) or chunked blob (v2)."""
    eet_ver_bytes = eet_version.encode("utf-8")
    req_id_bytes = request_id.encode("utf-8")

    parts = [
        EET_MAGIC,
        bytes([format_version, algo_id, wrap_key_type]),
        bytes([len(eet_ver_bytes)]),
        eet_ver_bytes,
        bytes([len(req_id_bytes)]),
        req_id_bytes,
        struct.pack(">H", len(aad)),
        aad,
        nonce,
        struct.pack(">H", len(enc_dek)),
        enc_dek,
        plaintext_binding,
    ]
    body = b"".join(parts)
    body += struct.pack(">I", len(ciphertext))
    body += ciphertext

    checksum = hashlib.sha256(body).digest()
    return body + checksum


def _parse_envelope(data: bytes) -> dict | None:
    """
    Parse envelope. Returns dict with fields or None on any error.
    All errors lead to generic decrypt failure - no specific messages.
    """
    if data[:3] != EET_MAGIC:
        return None
    fmt_ver = data[3]
    if fmt_ver not in (FORMAT_VERSION, FORMAT_VERSION_CHUNKED, FORMAT_VERSION_CHUNKED_LARGE):
        return None
    ct_len_size = 8 if fmt_ver == FORMAT_VERSION_CHUNKED_LARGE else 4
    min_len = 3 + 1 + 1 + 1 + 1 + 1 + 2 + 12 + 2 + 32 + 32 + ct_len_size
    if len(data) < min_len:
        return None

    off = 6
    eet_ver_len = data[off]
    off += 1
    if off + eet_ver_len > len(data):
        return None
    eet_version = data[off : off + eet_ver_len].decode("utf-8", errors="replace")
    off += eet_ver_len

    req_id_len = data[off]
    off += 1
    if off + req_id_len > len(data):
        return None
    request_id = data[off : off + req_id_len].decode("utf-8", errors="replace")
    off += req_id_len

    aad_len = struct.unpack(">H", data[off : off + 2])[0]
    off += 2
    if aad_len > 4096 or off + aad_len > len(data):
        return None
    aad = data[off : off + aad_len]
    off += aad_len

    nonce = data[off : off + GCM_NONCE_LEN]
    off += GCM_NONCE_LEN

    enc_dek_len = struct.unpack(">H", data[off : off + 2])[0]
    off += 2
    if enc_dek_len > 4096 or off + enc_dek_len > len(data):
        return None
    enc_dek = data[off : off + enc_dek_len]
    off += enc_dek_len

    plaintext_binding = data[off : off + HMAC_LEN]
    off += HMAC_LEN

    if fmt_ver == FORMAT_VERSION_CHUNKED_LARGE:
        ciphertext_len = struct.unpack(">Q", data[off : off + 8])[0]
        off += 8
    else:
        ciphertext_len = struct.unpack(">I", data[off : off + 4])[0]
        off += 4
    if ciphertext_len > 0x7FFFFFFFFFFFFFFF or off + ciphertext_len > len(data):
        return None
    ciphertext = data[off : off + ciphertext_len]
    off += ciphertext_len

    if off + SHA256_LEN != len(data):
        return None
    stored_checksum = data[off : off + SHA256_LEN]

    body_for_checksum = data[:off]
    computed = hashlib.sha256(body_for_checksum).digest()
    if not hmac.compare_digest(computed, stored_checksum):
        return None

    return {
        "format_version": fmt_ver,
        "algo_id": data[4],
        "wrap_key_type": data[5],
        "eet_version": eet_version,
        "request_id": request_id,
        "aad": aad,
        "nonce": nonce,
        "enc_dek": enc_dek,
        "plaintext_binding": plaintext_binding,
        "ciphertext": ciphertext,
    }


def _algo_id_to_name(algo_id: int) -> str:
    """Map algo_id to symmetric algo name."""
    for name, (aid, _, _, _) in SYMMETRIC_ALGO_REGISTRY.items():
        if aid == algo_id:
            return name
    return "unknown"


def _try_decode_envelope_b64(text: str) -> bytes | None:
    """Decode base64 to bytes; add padding if needed. Returns None on failure."""
    text = text.strip()
    if not text:
        return None
    # Add padding for base64 (len % 4)
    missing = len(text) % 4
    if missing:
        text = text + "=" * (4 - missing)
    try:
        raw = common.decode_b64_data(text)
        return raw if len(raw) >= 3 and raw[:3] == EET_MAGIC else None
    except Exception:
        return None


def _parse_envelope_header_from_file(
    file_path: str,
) -> tuple[dict, bytes, int, int] | None:
    """
    Stream parse envelope header from file. Returns (parsed_dict, header_bytes, ciphertext_start, ciphertext_len) or None.
    Does not load ciphertext into memory.
    """
    MAX_HEADER = 64 * 1024
    try:
        with open(file_path, "rb") as f:
            buf = f.read(MAX_HEADER)
    except OSError:
        return None
    if len(buf) < 63:
        return None
    if buf[:3] != EET_MAGIC:
        return None
    fmt_ver = buf[3]
    if fmt_ver not in (FORMAT_VERSION, FORMAT_VERSION_CHUNKED, FORMAT_VERSION_CHUNKED_LARGE):
        return None
    ct_len_size = 8 if fmt_ver == FORMAT_VERSION_CHUNKED_LARGE else 4
    off = 6
    if off + 1 > len(buf):
        return None
    eet_ver_len = buf[off]
    off += 1
    if off + eet_ver_len > len(buf):
        return None
    eet_version = buf[off : off + eet_ver_len].decode("utf-8", errors="replace")
    off += eet_ver_len
    if off + 1 > len(buf):
        return None
    req_id_len = buf[off]
    off += 1
    if off + req_id_len > len(buf):
        return None
    request_id = buf[off : off + req_id_len].decode("utf-8", errors="replace")
    off += req_id_len
    if off + 2 > len(buf):
        return None
    aad_len = struct.unpack(">H", buf[off : off + 2])[0]
    off += 2
    if aad_len > 4096 or off + aad_len > len(buf):
        return None
    aad = buf[off : off + aad_len]
    off += aad_len
    if off + 12 > len(buf):
        return None
    nonce = buf[off : off + 12]
    off += 12
    if off + 2 > len(buf):
        return None
    enc_dek_len = struct.unpack(">H", buf[off : off + 2])[0]
    off += 2
    if enc_dek_len > 4096 or off + enc_dek_len > len(buf):
        return None
    enc_dek = buf[off : off + enc_dek_len]
    off += enc_dek_len
    if off + 32 + ct_len_size > len(buf):
        return None
    plaintext_binding = buf[off : off + 32]
    off += 32
    if fmt_ver == FORMAT_VERSION_CHUNKED_LARGE:
        ciphertext_len = struct.unpack(">Q", buf[off : off + 8])[0]
        off += 8
    else:
        ciphertext_len = struct.unpack(">I", buf[off : off + 4])[0]
        off += 4
    if ciphertext_len > 0x7FFFFFFFFFFFFFFF:
        return None
    header_bytes = buf[:off]
    return {
        "format_version": fmt_ver,
        "algo_id": buf[4],
        "wrap_key_type": buf[5],
        "eet_version": eet_version,
        "request_id": request_id,
        "aad": aad,
        "nonce": nonce,
        "enc_dek": enc_dek,
        "plaintext_binding": plaintext_binding,
        "ciphertext": None,
    }, header_bytes, off, ciphertext_len


def _decrypt_stream_from_file(
    input_path: str,
    output_path: str,
    parsed: dict,
    header_bytes: bytes,
    ciphertext_start: int,
    ciphertext_len: int,
    algo_id: int,
    dek: bytes,
    no_force: bool,
) -> int:
    """
    Stream decrypt from file: read ciphertext record-by-record, update checksum, decrypt, write.
    O(1) memory for ciphertext. Returns plain_size.
    """
    file_size = os.path.getsize(input_path)
    if file_size < ciphertext_start + ciphertext_len + SHA256_LEN:
        raise ValueError("envelope truncated")
    sha = hashlib.sha256()
    sha.update(header_bytes)
    parent = os.path.dirname(os.path.abspath(output_path)) or "."
    fd, tmp_path = tempfile.mkstemp(dir=parent, prefix=".env_pt_")
    try:
        with os.fdopen(fd, "wb") as tmp:
            with open(input_path, "rb") as fin:
                fin.seek(ciphertext_start)
                h = hmac.new(dek, digestmod=hashlib.sha256)
                total_plain = 0
                num_chunks_b = fin.read(4)
                if len(num_chunks_b) < 4:
                    raise ValueError("envelope truncated")
                sha.update(num_chunks_b)
                num_chunks = struct.unpack(">I", num_chunks_b)[0]
                if num_chunks > 0x7FFFFFFF:
                    raise ValueError("invalid chunk count")
                for chunk_idx in range(num_chunks):
                    chunk_len_b = fin.read(4)
                    if len(chunk_len_b) < 4:
                        raise ValueError("envelope truncated")
                    sha.update(chunk_len_b)
                    chunk_len = struct.unpack(">I", chunk_len_b)[0]
                    if chunk_len > 0x7FFFFFFF:
                        raise ValueError("invalid chunk length")
                    chunk_ct = fin.read(chunk_len)
                    if len(chunk_ct) < chunk_len:
                        raise ValueError("envelope truncated")
                    sha.update(chunk_ct)
                    nonce_i = _derive_chunk_nonce(dek, parsed["nonce"], chunk_idx)
                    aad_i = _chunk_aad(parsed["aad"], chunk_idx)
                    plain_chunk = _symmetric_decrypt(algo_id, dek, nonce_i, aad_i, chunk_ct)
                    h.update(plain_chunk)
                    tmp.write(plain_chunk)
                    total_plain += len(plain_chunk)
                binding = h.digest()
                if not hmac.compare_digest(binding, parsed["plaintext_binding"]):
                    raise ValueError("plaintext binding mismatch")
        with open(input_path, "rb") as fin:
            fin.seek(ciphertext_start + ciphertext_len)
            stored_checksum = fin.read(SHA256_LEN)
        computed = sha.digest()
        if not hmac.compare_digest(computed, stored_checksum):
            raise ValueError("checksum mismatch")
        with common.write_to_file(output_path, force=not no_force) as out:
            with open(tmp_path, "rb") as tmp:
                for chunk in iter(lambda: tmp.read(65536), b""):
                    if chunk:
                        out.write_bytes(chunk)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    return total_plain


def _parse_envelope_blob(input_data: str, from_file: bool) -> dict | None:
    """
    Parse envelope blob input. Returns parsed dict or None.
    Supports: binary blob (EET magic), base64-encoded blob, or "prefix~envelope" format
    (e.g. CipherHUB style where envelope is after the last "~").
    """
    if from_file:
        try:
            with common.read_from_file(input_data) as f:
                raw_content = f.read_n_bytes(64 * 1024 * 1024)
        except OSError:
            return None
        if len(raw_content) >= 3 and raw_content[:3] == EET_MAGIC:
            return _parse_envelope(raw_content)
        try:
            text = raw_content.decode("utf-8").strip()
        except UnicodeDecodeError:
            return None
        if "~" in text:
            text = text.split("~")[-1].strip()
        raw_decoded = _try_decode_envelope_b64(text)
        if raw_decoded is not None:
            return _parse_envelope(raw_decoded)
        return None
    text = input_data.strip()
    if "~" in text:
        text = text.split("~")[-1].strip()
    raw_content = _try_decode_envelope_b64(text)
    if raw_content is not None:
        return _parse_envelope(raw_content)
    return None


KMS_CREDENTIALS_EPILOG = """
KMS credential configuration (when --mode kms):
  AWS: env vars AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY; or ~/.aws/credentials
  Tencent Cloud: env vars TENCENTCLOUD_SECRET_ID, TENCENTCLOUD_SECRET_KEY;
    or ~/.tccli/default.credential (JSON: secretId, secretKey)
  Alibaba Cloud: env vars ALIBABA_CLOUD_ACCESS_KEY_ID, ALIBABA_CLOUD_ACCESS_KEY_SECRET;
    or ~/.aliyun/config.json (aliyun-cli format)
"""


@click.group(name="envelope", short_help="Envelope encryption (asymmetric wraps DEK)", epilog=KMS_CREDENTIALS_EPILOG)
def envelope_group():
    """Envelope encryption: public key encrypts DEK, DEK encrypts data.

    Modes: local (RSA key) | kms (cloud KMS, e.g. AWS).
    KMS requires: pip install easy_encryption_tool[kms] and cloud credentials.
    """
    pass


@click.command(name="list-algorithms")
def envelope_list_algorithms():
    """List supported wrap_key_types, kms_backends, and symmetric_algos."""
    output = {
        "wrap_key_types": [
            {"id": "rsa", "description": "Local RSA public key encrypts DEK"},
            {"id": "kms", "description": "Cloud KMS generates DEK"},
        ],
        "kms_backends": KMS_BACKENDS,
        "symmetric_algos": [
            {"id": k, "key_len": v[1], "nonce_len": v[2]}
            for k, v in SYMMETRIC_ALGO_REGISTRY.items()
        ],
    }
    from easy_encryption_tool.output_renderer import console
    console.print_json(json.dumps(output, ensure_ascii=False, indent=2))


@click.command(name="encrypt")
@click.option(
    "--mode",
    type=click.Choice(["local", "kms"]),
    default="local",
    show_default=True,
    help="local: RSA key; kms: cloud KMS",
)
@click.option(
    "-f",
    "--public-key",
    required=False,
    type=click.STRING,
    help="RSA public key file path (required when mode=local)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--kms-backend",
    type=click.Choice(KMS_BACKENDS),
    help="KMS backend (required when mode=kms)",
)
@click.option(
    "--kms-key-id",
    type=click.STRING,
    help="KMS key ID or ARN (required when mode=kms encrypt). AWS and Aliyun support both plain key ID and ARN format.",
)
@click.option(
    "--kms-region",
    type=click.STRING,
    help="KMS region (required when mode=kms)",
)
@click.option(
    "--kms-endpoint",
    type=click.STRING,
    default=None,
    help="KMS custom endpoint (optional)",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Plaintext, base64 (-e), or file path (--from-file)",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    is_flag=True,
    default=False,
    help="Input is base64-encoded; -e and --from-file are mutually exclusive",
)
@click.option(
    "--from-file",
    is_flag=True,
    default=False,
    help="Input is file path; -e and --from-file are mutually exclusive",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file; default stdout (base64)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--symmetric-algo",
    type=click.Choice(list(SYMMETRIC_ALGO_REGISTRY.keys())),
    default="aes-256-gcm",
    show_default=True,
    help="Symmetric encryption algorithm",
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    show_default=True,
    help="GCM AAD",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=64,
    show_default=True,
    help="Max input size in MB when not file",
)
@click.option("--no-force", is_flag=True, default=False, help="Do not overwrite output file")
@output_format_options
def envelope_encrypt(
    mode: str,
    public_key: str | None,
    kms_backend: str | None,
    kms_key_id: str | None,
    kms_region: str | None,
    kms_endpoint: str | None,
    input_data: str,
    is_base64_encoded: bool,
    from_file: bool,
    output_file: str,
    symmetric_algo: str,
    aad: str,
    input_limit: int,
    no_force: bool,
    output_format: str | None,
):
    """Encrypt with envelope: DEK encrypted by public key or KMS, data by DEK."""
    request_id = create_request_id()
    start = time.perf_counter()
    kms_calls: list[dict] = []

    # Mode validation
    if mode == "local":
        if kms_backend or kms_key_id or kms_region or kms_endpoint:
            error("--kms-* not allowed when mode is local")
            return
        if not public_key:
            error("-f/--public-key required when mode is local")
            return
    else:  # kms
        if public_key:
            error("-f/--public-key not allowed when mode is kms")
            return
        if not kms_backend or not kms_region:
            error("--kms-backend and --kms-region required when mode is kms (encrypt)")
            return
        if not kms_key_id:
            error("--kms-key-id required when mode is kms (encrypt)")
            return
        try:
            from easy_encryption_tool.kms import is_kms_available
            if not is_kms_available():
                error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
                return
        except ImportError:
            error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
            return

    algo_id, key_len, nonce_len, _ = SYMMETRIC_ALGO_REGISTRY[symmetric_algo]
    if algo_id == ALGO_SM4_GCM:
        try:
            from easy_gmssl import EasySm4GCM
        except ImportError:
            hints.hint_missing_gmssl("SM4-GCM in envelope")
            return

    if mode == "local":
        pub_key, load_err = _load_rsa_public_key(public_key)
        if pub_key is None:
            error(load_err or "Public key must be RSA 2048/3072/4096 bits")
            return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, from_file, "envelope")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    use_stream_encrypt = False
    plaintext: bytes | None = None
    if from_file:
        if len(output_file) == 0:
            error("Output file required when input is file")
            return
        use_stream_encrypt = True
    elif is_base64_encoded:
        valid, plaintext = common.check_b64_data(input_data)
        if not valid:
            error("invalid base64 encoded input")
            hints.hint_invalid_b64("envelope")
            return
        if len(plaintext) > input_limit * 1024 * 1024:
            error("Input exceeds {} MB limit".format(input_limit))
            return
    else:
        try:
            plaintext = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("Input contains invalid UTF-8")
            return
        if len(plaintext) > input_limit * 1024 * 1024:
            error("Input exceeds {} MB limit".format(input_limit))
            return

    if not use_stream_encrypt and len(plaintext) == 0:
        error("Empty input")
        return

    aad_bytes = aad.encode("utf-8")

    if mode == "local":
        nonce = random_str.generate_random_bytes(nonce_len)
        dek = random_str.generate_random_bytes(key_len)
        enc_dek = _rsa_encrypt_dek(pub_key, dek)
        wrap_key_type = WRAP_RSA
    else:  # kms
        try:
            from easy_encryption_tool.kms import get_backend
            from easy_encryption_tool.kms.errors import KMSError
        except ImportError:
            error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
            return
        backend = get_backend(
            backend_name=kms_backend,
            region=kms_region,
            endpoint_url=kms_endpoint,
        )
        num_bytes = key_len + nonce_len
        try:
            plaintext_dek, enc_dek, kms_req_id = backend.generate_data_key(
                key_id=kms_key_id,
                number_of_bytes=num_bytes,
            )
        except KMSError as e:
            kms_calls.append({
                "step": "generate_data_key",
                "api": "GenerateDataKey",
                "request_id": None,
                "status": "failed",
                "error_code": str(e),
            })
            error(str(e))
            return
        dek = plaintext_dek[:key_len]
        nonce = plaintext_dek[key_len : key_len + nonce_len]
        wrap_key_type = WRAP_KMS
        kms_calls.append({
            "step": "generate_data_key",
            "api": "GenerateDataKey",
            "request_id": kms_req_id,
            "status": "success",
        })

    if use_stream_encrypt:
        try:
            plaintext_binding, input_size = _encrypt_stream_to_file(
                input_path=input_data,
                output_path=output_file,
                algo_id=algo_id,
                wrap_key_type=wrap_key_type,
                eet_version=_get_eet_version(),
                request_id=request_id,
                aad_bytes=aad_bytes,
                nonce=nonce,
                enc_dek=enc_dek,
                dek=dek,
                no_force=no_force,
            )
        except OSError as e:
            error("Cannot read/write file: {}".format(e))
            return
        except ValueError as e:
            error(str(e))
            return
        if input_size == 0:
            error("Empty input file")
            return
        envelope_b64 = None
    else:
        ciphertext = _symmetric_encrypt(algo_id, dek, nonce, aad_bytes, plaintext)
        plaintext_binding = hmac.new(dek, plaintext, hashlib.sha256).digest()
        input_size = len(plaintext)
        envelope = _build_envelope(
            algo_id=algo_id,
            wrap_key_type=wrap_key_type,
            eet_version=_get_eet_version(),
            request_id=request_id,
            aad=aad_bytes,
            nonce=nonce,
            enc_dek=enc_dek,
            plaintext_binding=plaintext_binding,
            ciphertext=ciphertext,
            format_version=FORMAT_VERSION,
        )
        envelope_b64 = base64.b64encode(envelope).decode("utf-8")
        if output_file:
            try:
                with common.write_to_file(output_file, force=not no_force) as w:
                    w.write_bytes(envelope)
            except OSError as e:
                error("Cannot write output: {}".format(e))
                return

    duration_ms = (time.perf_counter() - start) * 1000

    blob_params = {"request_id": request_id}
    if mode == "local":
        blob_params["key_size"] = pub_key.key_size
    else:
        blob_params["symmetric_algo"] = symmetric_algo
        blob_params["wrap_key_type"] = WRAP_KEY_TYPE_NAMES[wrap_key_type]
    enc_fmts = {"envelope_desc": "enc_dek, nonce, aad, ciphertext+tag"}
    if output_file:
        enc_fmts["output_file"] = "path"
    else:
        enc_fmts["envelope"] = "base64"
    metadata = build_metadata(
        operation="encrypt",
        algorithm="envelope",
        formats=enc_fmts,
        input_type="file" if from_file else ("binary" if is_base64_encoded else "text"),
        input_size=input_size,
        parameters=blob_params,
    )
    result_data = {"output_file": output_file} if output_file else {"envelope": envelope_b64}

    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
        kms_calls=kms_calls if kms_calls else None,
    )
    mode_fmt = resolve_output_format(output_format)
    primary = "output_file" if output_file else "envelope"
    render(output, mode=mode_fmt, primary_key=primary)


@click.command(name="decrypt")
@click.option(
    "--mode",
    type=click.Choice(["local", "kms"]),
    default="local",
    show_default=True,
    help="local: RSA key; kms: cloud KMS",
)
@click.option(
    "-f",
    "--private-key",
    required=False,
    type=click.STRING,
    help="RSA private key file path (required when mode=local)",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password (optional for unencrypted key)",
)
@click.option(
    "--kms-backend",
    type=click.Choice(KMS_BACKENDS),
    help="KMS backend (required when mode=kms)",
)
@click.option(
    "--kms-key-id",
    type=click.STRING,
    help="KMS key ID or ARN (optional when mode=kms decrypt; envelope contains reference). AWS and Aliyun support both formats.",
)
@click.option(
    "--kms-region",
    type=click.STRING,
    help="KMS region (required when mode=kms)",
)
@click.option(
    "--kms-endpoint",
    type=click.STRING,
    default=None,
    help="KMS custom endpoint (optional)",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Ciphertext envelope (base64 blob), file path (--from-file), or '-' for stdin",
)
@click.option(
    "--from-file",
    is_flag=True,
    default=False,
    help="Input is file path",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file; default stdout",
    shell_complete=shell_completion.complete_file_path,
)
@click.option("--no-force", is_flag=True, default=False, help="Do not overwrite output file")
@output_format_options
def envelope_decrypt(
    mode: str,
    private_key: str | None,
    password: str,
    kms_backend: str | None,
    kms_key_id: str | None,
    kms_region: str | None,
    kms_endpoint: str | None,
    input_data: str,
    from_file: bool,
    output_file: str,
    no_force: bool,
    output_format: str | None,
):
    """Decrypt envelope: private key or KMS decrypts DEK, DEK decrypts data."""
    request_id = create_request_id()
    start = time.perf_counter()
    kms_calls: list[dict] = []

    # Mode validation
    if mode == "local":
        if kms_backend or kms_key_id or kms_region or kms_endpoint:
            error("--kms-* not allowed when mode is local")
            return
        if not private_key:
            error("-f/--private-key required when mode is local")
            return
    else:  # kms
        if private_key:
            error("-f/--private-key not allowed when mode is kms")
            return
        if not kms_backend or not kms_region:
            error("--kms-backend and --kms-region required when mode is kms (decrypt)")
            return
        try:
            from easy_encryption_tool.kms import is_kms_available
            if not is_kms_available():
                error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
                return
        except ImportError:
            error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
            return

    stream_ctx = None
    if input_data == "-" or input_data == "/dev/stdin":
        import sys
        raw = sys.stdin.buffer.read(64 * 1024 * 1024)
        if len(raw) >= 3 and raw[:3] == EET_MAGIC:
            parsed = _parse_envelope(raw)
        else:
            try:
                input_data = raw.decode("utf-8").strip()
            except UnicodeDecodeError:
                input_data = raw.decode("utf-8", errors="replace").strip()
            from_file = False
            parsed = _parse_envelope_blob(input_data, from_file)
    elif from_file:
        header_result = _parse_envelope_header_from_file(input_data)
        if header_result is not None:
            parsed, header_bytes, ciphertext_start, ciphertext_len = header_result
            stream_ctx = (input_data, header_bytes, ciphertext_start, ciphertext_len)
        else:
            parsed = _parse_envelope_blob(input_data, from_file)
    else:
        parsed = _parse_envelope_blob(input_data, from_file)

    if parsed is None:
        error(DECRYPT_FAILED_MSG)
        return
    envelope_wrap_type = parsed["wrap_key_type"]

    if mode == "local" and envelope_wrap_type != WRAP_RSA:
        error("Envelope was encrypted with KMS; use --mode kms to decrypt")
        return
    if mode == "kms" and envelope_wrap_type != WRAP_KMS:
        error("Envelope was encrypted with RSA; use --mode local to decrypt")
        return

    algo_id = parsed["algo_id"]
    if algo_id not in (ALGO_AES_256_GCM, ALGO_SM4_GCM, ALGO_CHACHA20_POLY1305):
        error(DECRYPT_FAILED_MSG)
        return

    _, key_len, _, _ = SYMMETRIC_ALGO_REGISTRY.get(
        _algo_id_to_name(algo_id), ("", 32, GCM_NONCE_LEN, GCM_TAG_LEN)
    )

    if algo_id == ALGO_SM4_GCM:
        try:
            from easy_gmssl import EasySm4GCM
        except ImportError:
            hints.hint_missing_gmssl("SM4-GCM in envelope")
            return

    if mode == "local":
        pw = password.encode("utf-8") if password else None
        pri_key = _load_rsa_private_key(private_key, pw)
        if pri_key is None:
            error(DECRYPT_FAILED_MSG)
            return
        try:
            dek = _rsa_decrypt_dek(pri_key, parsed["enc_dek"])
        except Exception:
            error(DECRYPT_FAILED_MSG)
            return
    else:  # kms
        try:
            from easy_encryption_tool.kms import get_backend
            from easy_encryption_tool.kms.errors import KMSError
        except ImportError:
            error("KMS mode requires easy_encryption_tool[kms] extras. Install: pip install easy_encryption_tool[kms]")
            return
        backend = get_backend(
            backend_name=kms_backend,
            region=kms_region,
            endpoint_url=kms_endpoint,
        )
        try:
            plaintext_dek, kms_req_id = backend.decrypt(
                ciphertext_blob=parsed["enc_dek"],
                key_id=kms_key_id,
            )
        except KMSError as e:
            kms_calls.append({
                "step": "decrypt",
                "api": "Decrypt",
                "request_id": None,
                "status": "failed",
                "error_code": str(e),
            })
            error(str(e))
            return
        dek = plaintext_dek[:key_len]
        kms_calls.append({
            "step": "decrypt",
            "api": "Decrypt",
            "request_id": kms_req_id,
            "status": "success",
        })

    aad = parsed["aad"]
    nonce = parsed["nonce"]
    ciphertext = parsed.get("ciphertext")
    fmt_ver = parsed.get("format_version", FORMAT_VERSION)

    if fmt_ver in (FORMAT_VERSION_CHUNKED, FORMAT_VERSION_CHUNKED_LARGE) and not output_file:
        error("Output file (-o) required for chunked envelope (large file)")
        return

    plain_size = 0
    plaintext = None
    try:
        if stream_ctx is not None and fmt_ver in (FORMAT_VERSION_CHUNKED, FORMAT_VERSION_CHUNKED_LARGE):
            input_path, header_bytes, ciphertext_start, ciphertext_len = stream_ctx
            plain_size = _decrypt_stream_from_file(
                input_path=input_path,
                output_path=output_file,
                parsed=parsed,
                header_bytes=header_bytes,
                ciphertext_start=ciphertext_start,
                ciphertext_len=ciphertext_len,
                algo_id=algo_id,
                dek=dek,
                no_force=no_force,
            )
        elif stream_ctx is not None and fmt_ver == FORMAT_VERSION:
            input_path, header_bytes, ciphertext_start, ciphertext_len = stream_ctx
            if ciphertext_len > 64 * 1024 * 1024:
                error("Envelope too large for in-memory decrypt (ciphertext > 64MB)")
                return
            with open(input_path, "rb") as f:
                f.seek(ciphertext_start)
                ciphertext = f.read(ciphertext_len)
            if len(ciphertext) < ciphertext_len:
                error(DECRYPT_FAILED_MSG)
                return
            sha = hashlib.sha256()
            sha.update(header_bytes)
            sha.update(ciphertext)
            with open(input_path, "rb") as f:
                f.seek(ciphertext_start + ciphertext_len)
                stored_checksum = f.read(SHA256_LEN)
            if not hmac.compare_digest(sha.digest(), stored_checksum):
                error(DECRYPT_FAILED_MSG)
                return
            plaintext = _symmetric_decrypt(algo_id, dek, nonce, aad, ciphertext)
            expected_binding = hmac.new(dek, plaintext, hashlib.sha256).digest()
            if not hmac.compare_digest(expected_binding, parsed["plaintext_binding"]):
                error(DECRYPT_FAILED_MSG)
                return
            plain_size = len(plaintext)
            if output_file:
                try:
                    with common.write_to_file(output_file, force=not no_force) as w:
                        if not w.write_bytes(plaintext):
                            error(DECRYPT_FAILED_MSG)
                            return
                except OSError:
                    error("Cannot write output file")
                    return
        elif fmt_ver in (FORMAT_VERSION_CHUNKED, FORMAT_VERSION_CHUNKED_LARGE):
            if output_file:
                with common.write_to_file(output_file, force=not no_force) as w:
                    def write_chunk(b: bytes) -> None:
                        w.write_bytes(b)

                    expected_binding, _, plain_size = _decrypt_stream(
                        algo_id, dek, nonce, aad, ciphertext, writer=write_chunk
                    )
            else:
                expected_binding, plaintext, plain_size = _decrypt_stream(
                    algo_id, dek, nonce, aad, ciphertext, writer=None
                )
                if plaintext is None:
                    error(DECRYPT_FAILED_MSG)
                    return
            if not hmac.compare_digest(expected_binding, parsed["plaintext_binding"]):
                error(DECRYPT_FAILED_MSG)
                return
        else:
            plaintext = _symmetric_decrypt(algo_id, dek, nonce, aad, ciphertext)
            expected_binding = hmac.new(dek, plaintext, hashlib.sha256).digest()
            if not hmac.compare_digest(expected_binding, parsed["plaintext_binding"]):
                error(DECRYPT_FAILED_MSG)
                return
            plain_size = len(plaintext)

            if output_file:
                try:
                    with common.write_to_file(output_file, force=not no_force) as w:
                        if not w.write_bytes(plaintext):
                            error(DECRYPT_FAILED_MSG)
                            return
                except OSError:
                    error("Cannot write output file")
                    return
    except Exception:
        error(DECRYPT_FAILED_MSG)
        return

    duration_ms = (time.perf_counter() - start) * 1000

    be_str, ret = common.bytes_to_str(plaintext) if plaintext else (False, "")

    dec_fmts = {"plain": "utf-8" if be_str else "base64"}
    if output_file:
        dec_fmts["output_file"] = "path"
    metadata = build_metadata(
        operation="decrypt",
        algorithm="envelope",
        formats=dec_fmts,
        input_type="file" if from_file else "binary",
        input_size=plain_size,
        parameters={
            "request_id": parsed["request_id"],
            "eet_version": parsed["eet_version"],
        },
    )
    result_data = {"output_file": output_file, "plain_size": plain_size} if output_file else {"plain": ret}
    result = build_result(**result_data)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
        kms_calls=kms_calls if kms_calls else None,
    )
    mode_fmt = resolve_output_format(output_format)
    render(output, mode=mode_fmt, primary_key="output_file" if output_file else "plain")


envelope_group.add_command(envelope_list_algorithms)
envelope_group.add_command(envelope_encrypt)
envelope_group.add_command(envelope_decrypt)
