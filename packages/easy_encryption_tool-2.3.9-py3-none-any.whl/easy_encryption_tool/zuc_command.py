#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
ZUC stream cipher for encrypt/decrypt.
Key and IV are both 16 bytes.
"""
from __future__ import annotations

import base64
import os
import time
from typing import Tuple

import click
from click.core import ParameterSource

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import random_str
from easy_encryption_tool import shell_completion
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error, warning

try:
    from easy_gmssl import EasyZuc
    from easy_gmssl.gmssl import ZUC_KEY_SIZE, ZUC_IV_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False
    ZUC_KEY_SIZE = 16
    ZUC_IV_SIZE = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("ZUC")
        return False
    return True


def process_key_iv(is_random: bool, key: str, iv: str) -> tuple:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=ZUC_KEY_SIZE,
        iv_len=ZUC_IV_SIZE,
        mode=None,
    )


def check_b64_input_data(input_data: str, input_limit: int) -> Tuple[bool, bytes]:
    """Validate and decode base64 input. Returns (success, decoded_bytes). Align with AES/SM4."""
    if input_data is None:
        error("need input data")
        return False, b""
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        error("invalid b64 encoded data")
        hints.hint_invalid_b64("ZUC")
        return False, b""
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error(
            "data exceeds limit: {} Bytes (max {} Bytes)".format(
                len(input_raw_bytes), input_limit * 1024 * 1024
            )
        )
        return False, b""
    if len(input_raw_bytes) <= 0:
        error("got empty after base64 decode")
        return False, b""
    return True, input_raw_bytes


@click.command(name="zuc", short_help="ZUC stream cipher encrypt/decrypt")
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ZUC_KEY,
    help="Key 16 bytes, CipherHUB compatible; pad or truncate as needed",
)
@click.option(
    "-v",
    "--iv",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ZUC_IV,
    help="IV 16 bytes, CipherHUB compatible; pad or truncate as needed",
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and IV",
)
@click.option(
    "--key-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] Key as base64-encoded bytes (16 bytes). Mutually exclusive with -k when used.",
)
@click.option(
    "--iv-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] IV as base64-encoded bytes (16 bytes). Mutually exclusive with -v when used.",
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice(["encrypt", "decrypt"]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: string, base64, or file path",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB, applies when input is not a file",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file",
)
@output_format_options
@click.pass_context
def zuc_command(
    ctx: click.Context,
    key: str,
    iv: str,
    random_key_iv: bool,
    key_b64: str | None,
    iv_b64: str | None,
    action: str,
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    input_limit: int,
    output_file: str,
    no_force: bool = False,
    output_format: str | None = None,
):
    """ZUC stream cipher encrypt/decrypt, cipher length equals plain length. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if not _check_gmssl():
        return

    request_id = create_request_id()
    start = time.perf_counter()

    key_bytes: bytes
    iv_bytes: bytes
    key_display: str
    iv_display: str

    if random_key_iv:
        if key_b64 is not None or iv_b64 is not None:
            error("ZUC: -r/--random-key-iv cannot be used with --key-b64 or --iv-b64")
            return
        key, iv, _, _, _, _ = process_key_iv(random_key_iv, key, iv)
        key_bytes = key.encode("utf-8")
        iv_bytes = iv.encode("utf-8")
        key_display = key
        iv_display = iv
    else:
        key_from_cli = ctx.get_parameter_source("key") == ParameterSource.COMMANDLINE
        iv_from_cli = ctx.get_parameter_source("iv") == ParameterSource.COMMANDLINE
        if key_b64 is not None and key_from_cli:
            error("ZUC: -k/--key and --key-b64 are mutually exclusive; specify one only")
            return
        if iv_b64 is not None and iv_from_cli:
            error("ZUC: -v/--iv and --iv-b64 are mutually exclusive; specify one only")
            return
        key_str, iv_str, key_padded, iv_padded, key_truncated, iv_truncated = process_key_iv(
            False, key, iv
        )
        if key_b64 is not None or iv_b64 is not None:
            ok, err, kb, ib = common.decode_key_iv_b64(
                key_b64,
                iv_b64,
                key_len=ZUC_KEY_SIZE,
                iv_len=ZUC_IV_SIZE,
                nonce_len=None,
                mode=None,
            )
            if not ok:
                error("ZUC: {}".format(err or ""))
                return
            key_bytes = kb if kb is not None else key_str.encode("utf-8")
            iv_bytes = ib if ib is not None else iv_str.encode("utf-8")
        else:
            key_bytes = key_str.encode("utf-8")
            iv_bytes = iv_str.encode("utf-8")
        key_display = key_str
        iv_display = iv_str
        # Security warnings
        if (
            not key_from_cli
            and not iv_from_cli
            and key_b64 is None
            and iv_b64 is None
        ):
            warning(
                "Using default key/IV. Insecure for production. Use -r or provide explicit -k/-v."
            )
        if (key_padded or iv_padded) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was padded (short input). Ensure compatibility with peer; consider using full-length key/IV."
            )
        if (key_truncated or iv_truncated) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was truncated (long input). Ensure compatibility with peer; consider using exact-length key/IV."
            )

    if len(input_data) <= 0:
        error("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "ZUC")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "ZUC")
    if not ok:
        error(err or "")
        return

    if (
        action == "decrypt"
        and not is_base64_encoded
        and not is_a_file
    ):
        error("decrypt requires base64 cipher or file; use -e for base64 input")
        hints.hint_invalid_b64("ZUC")
        return

    input_raw_bytes = b""
    input_from_file = None
    output_to_file = None

    if is_base64_encoded:
        ok, input_raw_bytes = check_b64_input_data(input_data, input_limit)
        if not ok:
            return

    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            error(
                "data exceeds limit: {} Bytes (max {} Bytes)".format(
                    len(input_data), input_limit * 1024 * 1024
                )
            )
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("input contains invalid UTF-8 characters")
            return

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            error(
                "{} may not exist or may not be writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    zuc_op = EasyZuc(key=key_bytes, iv=iv_bytes)

    if not is_a_file:
        result = zuc_op.Update(input_raw_bytes) + zuc_op.Finish()
        if output_to_file is not None and not output_to_file.write_bytes(result):
            output_to_file.abort()
            return
        duration_ms = (time.perf_counter() - start) * 1000
        input_type = "binary" if is_base64_encoded else "text"
        if action == "encrypt":
            result_str = base64.b64encode(result).decode("utf-8")
            metadata = build_metadata(
                operation="encrypt",
                algorithm="zuc",
                encoding="base64",
                input_type=input_type,
                input_size=len(input_raw_bytes),
                parameters={"key_size": ZUC_KEY_SIZE, "iv_size": ZUC_IV_SIZE},
            )
            result_data = {"cipher": result_str}
            if random_key_iv:
                result_data["key"] = key_display
                result_data["iv"] = iv_display
            out_result = build_result(**result_data)
        else:
            be_str, ret = common.bytes_to_str(result)
            metadata = build_metadata(
                operation="decrypt",
                algorithm="zuc",
                encoding="utf-8" if be_str else "base64",
                input_type=input_type,
                input_size=len(input_raw_bytes),
                parameters={"key_size": ZUC_KEY_SIZE, "iv_size": ZUC_IV_SIZE},
            )
            out_result = build_result(plain=ret)
        output = build_output(
            metadata=metadata,
            result=out_result,
            request_id=request_id,
            duration_ms=duration_ms,
        )
        primary_key = "cipher" if action == "encrypt" else "plain"
        render(output, mode=resolve_output_format(output_format), primary_key=primary_key)
    else:
        if output_to_file is None:
            error("output file is required for file input (-o/--output-file)")
            return
        try:
            with common.read_from_file(input_data) as input_from_file:
                file_size = os.stat(input_data).st_size
                output_size = 0
                read_size = common.FILE_READ_CHUNK_SIZE
                while True:
                    chunk = input_from_file.read_n_bytes(read_size)
                    if not chunk:
                        break
                    out_chunk = zuc_op.Update(chunk)
                    output_size += len(out_chunk)
                    if not output_to_file.write_bytes(out_chunk):
                        output_to_file.abort()
                        return
                final = zuc_op.Finish()
                if final:
                    output_size += len(final)
                    if not output_to_file.write_bytes(final):
                        output_to_file.abort()
                        return
                duration_ms = (time.perf_counter() - start) * 1000
                metadata = build_metadata(
                    operation=action,
                    algorithm="zuc",
                    encoding="binary",
                    input_type="file",
                    input_size=file_size,
                    parameters={"key_size": ZUC_KEY_SIZE, "iv_size": ZUC_IV_SIZE},
                )
                result_data = {"output_file": output_file, "output_size": output_size}
                if random_key_iv:
                    result_data["key"] = key_display
                    result_data["iv"] = iv_display
                out_result = build_result(**result_data)
                output = build_output(
                    metadata=metadata,
                    result=out_result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                render(output, mode=resolve_output_format(output_format), primary_key="output_file")
        except OSError:
            if output_to_file is not None:
                output_to_file.abort()
            error("{} may not exist or may not be readable".format(input_data))
        except BaseException as e:
            if output_to_file is not None:
                output_to_file.abort()
            error("file operation failed: {}".format(e))


if __name__ == "__main__":
    zuc_command()
