"""Save and load FormGraph to/from JSON files."""

import json
from pathlib import Path

from .models import FormGraph


def save_graph(graph: FormGraph, file_path: str) -> None:
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    json_data = graph.model_dump(mode="json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2, ensure_ascii=False)


def load_graph(file_path: str) -> FormGraph:
    path = Path(file_path)
    with open(path, encoding="utf-8") as f:
        json_data = json.load(f)
    return FormGraph.model_validate(json_data)
