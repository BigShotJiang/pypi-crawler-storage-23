"""Tests for OAGI Socket.IO server."""
