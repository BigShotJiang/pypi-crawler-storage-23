from notifications.models import Notification

def serialize_notification(notification: Notification):
    return {
        "id": notification.pk,
        "actor": str(notification.actor),
        "verb": notification.verb,
        "level": notification.level,
        "description": notification.description,
        "timestamp": notification.timestamp.isoformat(),
        "timesince": notification.timesince(),
        "unread" : notification.unread,
        "data": notification.data,
    }


def serialize_notifications(notifications):
    notification_data = []
    for notification in notifications:
       instance = serialize_notification(notification)
       notification_data.append(instance)
    return notification_data

