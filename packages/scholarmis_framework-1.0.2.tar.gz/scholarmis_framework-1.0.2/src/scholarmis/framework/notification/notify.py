from django.contrib.auth import get_user_model
from django_tenants.utils import schema_context, connection
from notifications.models import Notification
from scholarmis.framework.asynco.broadcast import Broadcast 
from .serializers import serialize_notification 

VERB_NOTIFICATION = "Notification"
VERB_MESSAGE = "Message"
VERB_ANNOUNCEMENT = "Announcement"
VERB_ALERT = "Alert"
VERB_REMINDER = "Reminder"

LEVEL_INFO = "info"
LEVEL_SUCCESS = "success"
LEVEL_ERROR = "error"
LEVEL_WARNING = "warning"


User = get_user_model()


class Notify:
    """
    A class for sending different types of notifications to one or more users.

    The Notify class allows sending different types of notifications (messages, 
    announcements, reminders, etc.) to one or multiple users using Django"s notifications framework.
    
    Attributes:
        users (list): A list of User instances to send notifications to.
    """

    def __init__(self, users, tenant_schema=None):
        """
        Initialize the Notify with one or more users.

        :param users: A single User instance or a list of User instances.
        """
        self.tenant_schema = tenant_schema or connection.schema_name
        self.users = self._get_users(users)
        
    def _get_users(self, users):
        """
        Retrieve a list of User objects based on the provided user IDs.

        :param users: A single user ID or a list of user IDs to filter the users.
        :type users: int or list[int]

        :return: A queryset of active User objects corresponding to the provided user IDs,
                or an empty queryset if no users are found.
        :rtype: QuerySet[User]
        """

        # Ensure users is a list
        if users and not isinstance(users, list):
            users = [users]

        if users:
            with schema_context(self.tenant_schema):
                # Return a queryset of active users based on the user IDs
                user_list = User.objects.filter(pk__in=users)
                return user_list

        # If users is empty or invalid, return an empty queryset
        return User.objects.none()
    
    
    def send(self, message, verb, level, **kwargs):
        """
        Send a notification to the users.

        :param message: The message content of the notification.
        :param verb: The type of notification, e.g., "Message", "Alert".
        :param level: The severity level of the notification, e.g., "info", "warning".
        :param kwargs: Additional optional fields for the notification.
        """
        if self.users:
            
            for user in self.users:

                notification = Notification.objects.create(
                    actor=user,
                    recipient=user,
                    verb=verb,
                    description=message,
                    level=level,
                    **kwargs
                )
                
                if notification:
                    self.broadcast(user, notification)
                    self.email(user, notification)
                    self.push(user, notification)

    def broadcast(self, user, notification: Notification):
        payload = serialize_notification(notification)
        
        broadcast = Broadcast(self.tenant_schema)
        broadcast.to_user( 
            user_id=user.id, 
            data=payload
        )

    def email(self, user, notification: Notification):
        pass
    
    
    def push(self, user, notification: Notification):
        pass
    

    def message(self, message, **kwargs):
        """
        Send a message-type notification.

        :param message: The message content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_INFO, verb=VERB_MESSAGE, **kwargs)

    def notification(self, message, **kwargs):
        """
        Send a general notification.

        :param message: The message content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_INFO, verb=VERB_NOTIFICATION, **kwargs)

    def announcement(self, message, **kwargs):
        """
        Send an announcement-type notification.

        :param message: The announcement content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_INFO, verb=VERB_ANNOUNCEMENT, **kwargs)

    def reminder(self, message, **kwargs):
        """
        Send a reminder-type notification.

        :param message: The reminder content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_INFO, verb=VERB_REMINDER, **kwargs)

    def success(self, message, **kwargs):
        """
        Send a success alert notification.

        :param message: The success message content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_SUCCESS, verb=VERB_ALERT, **kwargs)

    def warning(self, message,  **kwargs):
        """
        Send a warning alert notification.

        :param message: The warning message content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_WARNING, verb=VERB_ALERT, **kwargs)

    def error(self, message, **kwargs):
        """
        Send an error alert notification.

        :param message: The error message content.
        :param kwargs: Additional optional fields for the notification.
        """
        return self.send(message, level=LEVEL_ERROR, verb=VERB_ALERT, **kwargs)

    @staticmethod
    def instance(users, tenant_schema=None):
        """
        Static method to instantiate the Notify class with the provided users.

        :param users: A single User instance or a list of User instances.
        :return: An instance of Notify.
        """
        return Notify(users, tenant_schema)

