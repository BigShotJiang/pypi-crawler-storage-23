from django.core.cache import cache
from notifications.models import Notification
from .notify import Notify


def send_notification(users, message, **kwargs):
    """
    Send a notification to a single user via both Django Notifications and WebSockets.
    
    :param users: The user to send the notification to.
    :param message: The notification message.
    :param verb: The action of the notification, e.g., "Message", "Alert".
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).notification(message, **kwargs)
    

def send_message(users, message, **kwargs):
    """
    Utility function to send a "Message" notification to a user.

    :param users: The user to send the message to.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).message(message, **kwargs)


def send_announcement(users, message, **kwargs):
    """
    Utility function to send an "Announcement" notification to a user.

    :param users: The user to notify.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).announcement(message, **kwargs)


def send_reminder(users, message, **kwargs):
    """
    Utility function to send an "Reminder" notification to a user.

    :param users: The user to notify.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).reminder(message, **kwargs)


def alert_success(users, message, **kwargs):
    """
    Utility function to send an "Alert" notification to a user.

    :param users: The user to notify.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).success(message, **kwargs)


def alert_warning(users, message, **kwargs):
    """
    Utility function to send an "Alert" notification to a user.

    :param users: The user to notify.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).warming(message, **kwargs)


def alert_error(users, message, **kwargs):
    """
    Utility function to send an "Alert" notification to a user.

    :param users: The user to notify.
    :param message: The notification message.
    :param kwargs: Additional key-value pairs to send along with the message.
    """
    return Notify.instance(users).error(message, **kwargs)


def get_unread_notifications(user):
    return Notification.objects.filter(recipient=user, unread=True).order_by("-timestamp")


def get_unread_notifications_count(user):
    count = user.notifications.unread().count
    return cache.get_or_set("unread_notifications_count", count, 2)