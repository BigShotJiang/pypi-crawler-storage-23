PDF_MIMETYPE = "application/pdf"
MS_WORD_MIMETYPE = "application/msword"
MS_DOC_MIMETYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
MS_EXCEL_MIMETYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"