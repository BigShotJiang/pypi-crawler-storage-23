import hashlib
from typing import Any
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.utils.text import slugify

# Constants
MAX_GROUP_LENGTH = 100
HASH_LENGTH = 16
SCHEMA_MAX = 20
SCOPE_MAX = 20


def build_channel_group_name(schema_name:str, scope:str, identifiers:list=None, max_length=MAX_GROUP_LENGTH, hash_length=HASH_LENGTH):
    """
    Builds a deterministic, safe Django Channels group name.
    """
    
    def _get_hash(items):
        combined = ":".join(map(str, items))
        return hashlib.sha1(combined.encode()).hexdigest()[:hash_length]
    
    identifiers = identifiers or []

    # 1. Standardize Schema and Scope
    # slugify handles whitespace/special chars; we provide fallbacks for empty results
    clean_schema = slugify(str(schema_name or "public"))[:SCHEMA_MAX] or "default"
    clean_scope = slugify(str(scope))[:SCOPE_MAX] or "noscope"

    # 2. Generate Hash for Identifiers
    # We hash identifiers separately so they never cause the string to exceed length
    id_hash = _get_hash(identifiers) if identifiers else ""

    # 3. Assemble
    parts = ["ws", clean_schema, clean_scope]
    if id_hash:
        parts.append(id_hash)
    
    group_name = "_".join(parts)

    # Optional: truncate in production
    if len(group_name) > max_length:
        group_name = group_name[:max_length]

    return group_name


def dispatch_channel_message(target_group:str, method_name:str, data:Any):
    """
    Sends a message to the channel layer.
    """
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        target_group,
        {
            "type": method_name, # This must match the 'async def' in your consumer
            "data": data         # The payload (HTML/JSON)
        }
    )
 
    
def channel_broadcast(tenant_schema:str, scope:str, method_name:str, data:Any, identifiers:list=None):
    """
    The 'Easy Button' for all channels.
    """
    # Build the specific target string
    target = build_channel_group_name(
        schema_name=tenant_schema, 
        scope=scope, 
        identifiers=identifiers
    )
    
    # Dispatch
    dispatch_channel_message(target, method_name, data)
    
