from typing import Any
from django_tenants.utils import connection
from .channels import channel_broadcast


class Broadcast:
    
    def __init__(self, tenant_schema="public"):
        
        self.tenant_schema = tenant_schema or connection.schema_name
        
    def to_system(self, data:Any, method_name="broadcast_message"):
        """
        Sends a message to EVERYONE currently connected in this tenant.
        """
        channel_broadcast(
            tenant_schema=self.tenant_schema,
            scope="system",
            method_name=method_name,
            data=data
        )

    def to_user(self, user_id:str, data:Any, method_name="user_message"):
        """
        Sends a message to a specific user.
        """
        channel_broadcast(
            tenant_schema=self.tenant_schema,
            scope="user",
            method_name=method_name,
            data=data,
            identifiers=[user_id]
        )

    def to_group(self, group_name:str, data:Any, method_name="group_message"):
        """
        Sends a message to a specific group/role (e.g., all 'admins').
        """
        channel_broadcast(
            tenant_schema=self.tenant_schema,
            scope="group",
            method_name=method_name,
            data=data,
            identifiers=[group_name]
        )
        
    @staticmethod
    def instance(tenant_schema=None):
        """
        Static method to instantiate the Notify class with the provided users.

        :param users: A single User instance or a list of User instances.
        :return: An instance of Notify.
        """
        return Broadcast(tenant_schema)


def system_broadcast(data:Any):
    """
    Sends a message to EVERYONE currently connected in this tenant.
    """
    return Broadcast.instance().to_system(data)


def user_broadcast(user_id:str, data:Any):
    """
    Sends a message to a specific user (e.g., Export Finished).
    """
    return Broadcast.instance().to_user(user_id, data)


def group_broadcast(group_name:str, data:Any):
    """
    Sends a message to a specific group/role (e.g., all 'admins').
    """
    return Broadcast.instance().to_group(group_name, data)

