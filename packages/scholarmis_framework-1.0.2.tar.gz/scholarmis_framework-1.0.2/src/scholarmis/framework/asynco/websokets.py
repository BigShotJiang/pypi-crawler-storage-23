import json
import uuid
from datetime import datetime, date
from channels.generic.websocket import AsyncWebsocketConsumer

class SmartJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        if isinstance(obj, uuid.UUID):
            return str(obj)
        return super().default(obj)


class WebsocketConsumer(AsyncWebsocketConsumer):

    async def send_data(self, event):
        # Extract data from Channels event dict or use raw input
        data = event.get("data", event) if isinstance(event, dict) else event

        if isinstance(data, (dict, list)):
            # THE ENCODER IS USED HERE:
            json_payload = json.dumps(data, cls=SmartJSONEncoder)
            await self.send(text_data=json_payload)
        elif isinstance(data, str):
            await self.send(text_data=data)
        elif isinstance(data, (bytes, bytearray)):
            await self.send(bytes_data=data)

    async def receive(self, text_data=None, bytes_data=None):
        """
        Interacts with incoming WebSocket messages. 
        If it's JSON text, it converts it to a dict before calling handle_data.
        """
        if text_data:
            try:
                data = json.loads(text_data)
            except json.JSONDecodeError:
                data = text_data # Keep as raw string if not JSON
            
            await self.receive_data(data)

    async def receive_data(self, data):
        """
        Override this method in your child classes to process 
        the already-parsed dictionary.
        """
        pass