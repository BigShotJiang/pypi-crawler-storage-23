from django.db import models

class ProcessStatus(models.TextChoices):
    PENDING = "Pending"
    PROCESSING = "Processing"
    READY = "Ready"
    ERROR = "Error"

class TaskStatus(models.TextChoices):
    PROGRESS = "Progress"
    SUCCESS = "Success"
    FAILURE = "Failure"
    ERROR = "Error"