from django.db import models

class IDType(models.TextChoices):
    NATIONAL_ID = "National ID"
    PASSPORT = "Passport"
    DRIVING_LICENSE = "Driving License"

class Status(models.TextChoices):
    ACTIVE = "Active"
    INACTIVE = "Inactive"

class Gender(models.TextChoices):
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non Binary"
    PREFER_NOT_TO_SAY = "Prefer not to say"
    OTHER = "Other"

class Sex(models.TextChoices):
    MALE = "Male"
    FEMALE = "Female"

class MaritalStatus(models.TextChoices):
    SINGLE = "Single"
    MARRIED = "Married"
    DIVORCED = "Divorced"
    WIDOWED = "Widowed"

class Title(models.TextChoices):
    MISS = "Miss"
    MR = "Mr"
    MRS = "Mrs"
    DR = "Dr"
    PROF = "Prof"

class Relation(models.TextChoices):
    FATHER = "Father"
    MOTHER = "Mother"
    SON = "Son"
    DAUGHTER = "Daughter"
    HUSBAND = "Husband"
    WIFE = "Wife"
    BROTHER = "Brother"
    SISTER = "Sister"
    UNCLE = "Uncle"
    AUNT = "Aunt"
    NEPHEW = "Nephew"
    NIECE = "Niece"
    GRANDFATHER = "Grandfather"
    GRANDMOTHER = "Grandmother"