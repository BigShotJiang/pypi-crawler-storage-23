import os
import tablib
import io
import traceback
from celery import Task
from scholarmis.framework.choices.process import TaskStatus
from scholarmis.framework.notification.helpers import send_notification
from .resources import BaseResource


class ResourceImport:

    def __init__(self, task: Task, resource: BaseResource, file_path: str, user_id, raise_errors=True):
        """
        Initialize ResourceImport with resource instance, file path, and user_id.

        :param resource: The resource instance to handle data import.
        :param file_path: Path to the file to be processed.
        :param user_id: The user_id who initiated the task.
        """
        self.task = task
        self.resource = resource
        self.file_path = file_path
        self.user_id = user_id
        self.raise_errors = raise_errors
        self.file_content, self.file_format = self.read_excel_file(file_path)  # Read file content
        self.dataset = tablib.Dataset().load(self.file_content, self.file_format)  # Load the dataset

        self.dataset = self.filter_dataset(self.dataset)
        self.headers = self.dataset.headers
    

    def read_excel_file(self, file_path, size=None):
        # Get the file extension
        file_extension = os.path.splitext(file_path)[1].lower()
        
        # Read the file and load into an appropriate in-memory stream
        if file_extension in ['.xlsx', '.xls']:
            with open(file_path, 'rb') as f:
                in_stream = io.BytesIO(f.read(size))
            file_format = file_extension.lstrip('.')
        elif file_extension == '.csv':
            with open(file_path, 'r', encoding='utf-8') as f:
                in_stream = io.StringIO(f.read(size))
            file_format = 'csv'
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
        
        return in_stream, file_format


    def filter_dataset(self, dataset: tablib.Dataset):
        # Filter out empty rows
        return tablib.Dataset(
            *[row for row in dataset if any(cell not in (None, '', ' ') for cell in row)],
            headers=dataset.headers
        )

    def run(self):
        try:
            batch_size = 500
            total_rows = len(self.dataset)

            for start in range(0, total_rows, batch_size):
                end = min(start + batch_size, total_rows)
                batch = self.dataset[start:end]

                dataset = tablib.Dataset(headers=self.headers)
                dataset.extend(batch)

                self.resource.import_data(
                    dataset=dataset, 
                    raise_errors=self.raise_errors
                )
                
                progress = round((end / total_rows) * 100)
                message = f"Importing records. {progress}% completed."
                self.task.update_state(state=TaskStatus.PROGRESS, meta={"progress": progress, "message": message})

            message = f"Task completed. Imported {total_rows} records."
            self.task.update_state(state=TaskStatus.SUCCESS, meta={"progress": 100, "message": message})
            
            send_notification(self.user_id, message)
            self.clean_up()

        except ImportError as e:
            error_trace = traceback.format_exc()
            message = f"Error during import: {e}"

            self.task.update_state(
                state=TaskStatus.FAILURE,
                meta={
                    "exc_type": type(e).__name__,
                    "exc_message": str(e),
                    "traceback": error_trace,
                    "progress": 100,
                    "message": message
                }
            )
            self.clean_up()

    def clean_up(self):
        """
        Clean up the uploaded file after processing.
        """
        if os.path.exists(self.file_path):
            try:
                # Delete the file from the file system
                os.remove(self.file_path)
            except Exception as e:
                print(f"Error deleting file: {e}")

