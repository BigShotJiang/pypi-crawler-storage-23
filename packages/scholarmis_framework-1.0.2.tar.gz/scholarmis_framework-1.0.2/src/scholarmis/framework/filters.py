import django_filters
from django.db.models import Q, QuerySet, Model # type: ignore


class OptionFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(field_name="name", lookup_expr="icontains")
    value = django_filters.CharFilter(field_name="value", lookup_expr="icontains")
    slug = django_filters.CharFilter(field_name="slug", lookup_expr="icontains")
    code = django_filters.CharFilter(field_name="code", lookup_expr="icontains")

    class Meta:
        model = None  # to be defined in subclass
        fields = ["id", "name", "value", "slug", "code"]



def dynamic_filter(model_class: Model, filters, **kwargs) -> QuerySet:
    """
    Dynamically filters a queryset for a given model class based on required and optional filters.
    
    - Supports Django-style field lookups (e.g., field__gte, program__division__name).
    - Skips filters where value is empty (None, "", or []).
    - Applies filters only if corresponding DB field has non-null values that can match.

    Args:
        model_class (models.Model): The model class to query.
        filters (Q | dict | QuerySet): Required conditions.
        **kwargs: Optional filters with lookup support.

    Returns:
        QuerySet: Filtered queryset.
    """
    # Step 1: Base queryset
    if isinstance(filters, Q):
        queryset = model_class.objects.filter(filters)
    elif isinstance(filters, dict):
        queryset = model_class.objects.filter(**filters)
    elif isinstance(filters, QuerySet):
        queryset = filters
    else:
        raise ValueError("Expected 'filters' to be a Q object, dict, or QuerySet.")

    # Step 2: Get nullable fields
    nullable_fields = {
        field.name for field in model_class._meta.get_fields()
        if hasattr(field, 'null') and field.null
    }

    # Step 3: Apply optional filters
    for key, value in kwargs.items():
        if value in [None, "", []]:
            continue  # skip empty values

        # Extract base field name (before any lookups)
        base_field = key.split("__")[0]

        # More precise: apply only if this value exists in non-null rows
        if base_field in nullable_fields:
            if queryset.filter(**{key: value}).exclude(**{base_field: None}).exists():
                queryset = queryset.filter(**{key: value})
        else:
            queryset = queryset.filter(**{key: value})

    return queryset

