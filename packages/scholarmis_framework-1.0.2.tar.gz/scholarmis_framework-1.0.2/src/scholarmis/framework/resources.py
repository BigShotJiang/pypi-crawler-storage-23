from typing import Dict
from datetime import date, datetime, timedelta
from tablib import Dataset
from django.core.exceptions import ValidationError
from django.db.models import  QuerySet
from import_export.resources import ModelResource
from import_export.widgets import DateWidget, ForeignKeyWidget as BaseForeignKeyWidget
from .excel import ExcelExporter, ModelInspector, ReferenceFieldHelper


class ExcelDateWidget(DateWidget):
    """
    Handles conversion between Excel serial dates, various string formats, 
    and Python date objects.
    """
    INPUT_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"]
    EXCEL_BASE_DATE = datetime(1899, 12, 30)

    def clean(self, value, row=None, *args, **kwargs):
        if value in (None, "", "NULL"):
            return None

        if isinstance(value, (datetime, date)):
            return value.date() if isinstance(value, datetime) else value

        # Handle Excel Serial Numbers
        if isinstance(value, (int, float)):
            try:
                return (self.EXCEL_BASE_DATE + timedelta(days=float(value))).date()
            except Exception as e:
                raise ValidationError(f"Invalid Excel serial date '{value}': {e}")

        # Fallback to string parsing
        value = str(value).strip()
        for fmt in self.INPUT_FORMATS:
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue

        return super().clean(value, row, *args, **kwargs)


class ForeignKeyWidget(BaseForeignKeyWidget):
    """
    A safer ForeignKey widget that returns None if a record isn't found
    instead of crashing the import process.
    """
    def clean(self, value, row=None, **kwargs):
        if not value:
            return None
        try:
            return super().clean(value, row, **kwargs)
        except self.model.DoesNotExist:
            return None
        
        
class BaseResource(ModelResource):
    """The orchestration layer connecting Django Models to the Excel Engine."""
    class Meta:
        abstract = True
        export_data = False
        protect = True
        hidden_fields = []
        foreign_fields = {}
        choice_fields = {}

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.model = kwargs.get('model', getattr(self._meta, 'model', None))
        self.queryset = kwargs.get('queryset', None)
        self.config = {
            'export_data': kwargs.get('export_data', getattr(self._meta, 'export_data', False)),
            'protect': kwargs.get('protect', getattr(self._meta, 'protect', True)),
            'hidden_fields': kwargs.get('hidden_fields', getattr(self._meta, 'hidden_fields', [])),
            'export_name': kwargs.get('export_name', getattr(self._meta, 'export_name', None)),
        }
        self.custom_foreign = kwargs.get('foreign_fields', getattr(self._meta, 'foreign_fields', {}))
        self.custom_choices = kwargs.get('choice_fields', getattr(self._meta, 'choice_fields', {}))

    def set_queryset(self, queryset: QuerySet) -> 'BaseResource':
        self.queryset = queryset
        return self
    
    def allow_data_export(self, allow: bool = True) -> 'BaseResource':
        self.config['export_data'] = allow
        return self

    def set_export_name(self, name: str) -> 'BaseResource':
        self.config['export_name'] = name
        return self

    def _get_reference_map(self) -> Dict:
        refs = {}
        fks = ReferenceFieldHelper.get_foreign_fields(self.model, self.fields, self.custom_foreign)
        for f in fks:
            qs = getattr(f, "_custom_queryset", f.remote_field.model.objects.all())
            refs[f.name.lower()] = (ModelInspector.get_sheet_name(f.remote_field.model), ModelInspector.get_relation_dataset(qs))
        chs = ReferenceFieldHelper.get_choice_fields(self.model, self.fields, self.custom_choices)
        for f in chs:
            refs[f.name.lower()] = (f.name[:31], ModelInspector.get_relation_dataset(f.choices))
        return refs

    def get_exporter(self, *args, **kwargs) -> ExcelExporter:
        if self.config['export_data']: 
            dataset = super().export(self.queryset, *args, **kwargs)
        else: 
            dataset =  Dataset(headers=self.fields)
        return ExcelExporter(self.model, dataset, self._get_reference_map(), **self.config)

    def export(self, *args, **kwargs):
        return self.get_exporter(*args, **kwargs).generate_response(streaming=False)

    def stream(self, *args, **kwargs):
        return self.get_exporter(*args, **kwargs).generate_response(streaming=True)

    def save_file(self, path="exports", rename=False):
        return self.get_exporter().save_to_storage(path, rename)

    def is_blank(self) -> bool: return not self.model.objects.exists()
    def is_filled(self) -> bool: return self.model.objects.exists()
    
    
    
