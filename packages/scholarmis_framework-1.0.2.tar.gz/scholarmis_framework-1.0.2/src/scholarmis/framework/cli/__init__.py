import click # type: ignore
from scholarmis.framework.cli.project import createproject
from scholarmis.framework.cli.plugin import createplugin
from scholarmis.framework.cli.plugin import plugin
from scholarmis.framework.cli.system import system

@click.group()
def cli():
    """Scholarmis CLI"""
    pass

cli.add_command(createproject)
cli.add_command(createplugin)
cli.add_command(plugin)
cli.add_command(system)

if __name__ == "__main__":
    cli()