class WizardExit(Exception):
    """Raised when the user chooses to exit the wizard."""


class WizardRestart(Exception):
    """Raised when the user chooses to restart the wizard."""
