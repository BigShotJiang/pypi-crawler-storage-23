import os
import uuid
import decimal
import json
from io import BytesIO
from datetime import date, datetime
from typing import Dict, List, Tuple, Any

from django.core.files.storage import default_storage
from django.db.models import Field, Model
from django.http import HttpResponse, StreamingHttpResponse

from slugify import slugify 
from tablib import Dataset
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet


class DataFormatter:
    """Handles data sanitization and type conversion for Excel output."""
    @staticmethod
    def to_excel_value(value: Any) -> Any:
        if value is None: return ""
        if isinstance(value, (datetime, date)):
            return value.strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(value, uuid.UUID):
            return str(value)
        if isinstance(value, (list, dict, set, tuple)):
            try:
                return json.dumps(value, default=str)
            except (TypeError, ValueError):
                return str(value)
        if isinstance(value, decimal.Decimal):
            return float(value)
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float, str)):
            return value
        return str(value)


class ExcelStyleManager:
    """Encapsulates styling and worksheet protection logic."""
    @staticmethod
    def apply_header_style(sheet: Worksheet):
        sheet.freeze_panes = "A2"
        for cell in sheet[1]:
            cell.font = Font(size=12, bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")

    @staticmethod
    def hide_columns_by_name(sheet: Worksheet, column_names: List[str]):
        header_map = {cell.value: cell.column for cell in sheet[1] if cell.value}
        for name in column_names:
            if name in header_map:
                col_letter = get_column_letter(header_map[name])
                sheet.column_dimensions[col_letter].hidden = True

    @staticmethod
    def protect_sheet(sheet: Worksheet, password: str):
        sheet.sheet_state = 'hidden'
        sheet.protection.sheet = True
        sheet.protection.set_password(password)


class ModelInspector:
    """Handles Django Meta-programming and dataset extraction logic."""
    @staticmethod
    def get_sheet_name(model: Model) -> str:
        return model._meta.verbose_name_plural.replace(" ", "_")[:31]

    @staticmethod
    def get_file_name(name: str) -> str:
        return f"{slugify(name, separator='-').upper()}.xlsx"

    @staticmethod
    def get_relation_dataset(queryset: Any) -> Dataset:
        dataset = Dataset(headers=["ID", "Value"])
        for index, obj in enumerate(queryset):
            if isinstance(obj, (tuple, list)) and len(obj) >= 2:
                dataset.append([obj[0], str(obj[1])])
            elif hasattr(obj, "pk"):
                dataset.append([obj.pk, str(obj)])
            else:
                dataset.append([index, str(obj)])
        return dataset


class ReferenceFieldHelper:
    """Utility class to extract relationship fields from Django models."""
    @staticmethod
    def get_foreign_fields(model: Model, fields: List[str], custom_qs: Dict) -> List[Field]:
        model_fks = {f.name: f for f in model._meta.get_fields() 
                     if f.is_relation and f.many_to_one and f.name in fields}
        result = []
        for name in fields:
            if name in model_fks:
                field = model_fks[name]
                if name in custom_qs:
                    field._custom_queryset = custom_qs[name]
                result.append(field)
        return result

    @staticmethod
    def get_choice_fields(model: Model, fields: List[str], custom_choices: Dict) -> List[Field]:
        model_choices = {f.name: f for f in model._meta.get_fields() 
                         if not f.is_relation and f.choices and f.name in fields}
        for name, choices in custom_choices.items():
            if name in model_choices:
                model_choices[name].choices = choices
        return list(model_choices.values())


class ExcelExporter:
    """Independent engine for Workbook construction."""
    PASSWORD = "password"
    MAX_ROW = 1048576

    def __init__(self, model: Model, dataset: Dataset, reference_sheets: Dict, **kwargs):
        self.model = model
        self.dataset = dataset
        self.reference_sheets = reference_sheets
        self.hidden_fields = kwargs.get('hidden_fields', [])
        self.export_data = kwargs.get('export_data', False)
        self.protect = kwargs.get('protect', True)
        self.filename = ModelInspector.get_file_name(
            kwargs.get('export_name') or str(model._meta.verbose_name_plural)
        )

    def _write_to_sheet(self, ws: Worksheet, dataset: Dataset, include_data: bool):
        for col, header in enumerate(dataset.headers, 1):
            ws.cell(row=1, column=col, value=header)
        if include_data:
            for r_idx, row in enumerate(dataset.dict, 2):
                for c_idx, val in enumerate(row.values(), 1):
                    ws.cell(row=r_idx, column=c_idx, value=DataFormatter.to_excel_value(val))

    def build_workbook(self) -> Workbook:
        wb = Workbook()
        main_ws = wb.active
        main_ws.title = ModelInspector.get_sheet_name(self.model)

        self._write_to_sheet(main_ws, self.dataset, self.export_data)
        ExcelStyleManager.apply_header_style(main_ws)
        
        if self.hidden_fields:
            ExcelStyleManager.hide_columns_by_name(main_ws, self.hidden_fields)

        for field_name, (title, ds) in self.reference_sheets.items():
            ref_ws = wb.create_sheet(title)
            self._write_to_sheet(ref_ws, ds, True)
            if self.protect:
                ExcelStyleManager.protect_sheet(ref_ws, self.PASSWORD)
            self._apply_validation(main_ws, field_name, title, len(ds))

        return wb

    def _apply_validation(self, ws: Worksheet, field_name: str, ref_title: str, row_count: int):
        headers = [str(cell.value).lower() for cell in ws[1]]
        if field_name.lower() in headers:
            col_idx = headers.index(field_name.lower()) + 1
            letter = get_column_letter(col_idx)
            dv = DataValidation(type="list", formula1=f"='{ref_title}'!$B$2:$B${row_count + 1}", allow_blank=True)
            dv.sqref = f"{letter}2:{letter}{self.MAX_ROW}"
            ws.add_data_validation(dv)

    def generate_response(self, streaming=False) -> HttpResponse:
        buffer = BytesIO()
        self.build_workbook().save(buffer)
        buffer.seek(0)
        klass = StreamingHttpResponse if streaming else HttpResponse
        response = klass(buffer, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = f"attachment; filename={self.filename}"
        return response

    def save_to_storage(self, folder_path: str, rename=False) -> Tuple[str, str]:
        wb = self.build_workbook()
        fname = f"{uuid.uuid4()}.xlsx" if rename else self.filename
        full_dir = default_storage.path(folder_path)
        if not os.path.exists(full_dir): os.makedirs(full_dir)
        file_path = os.path.join(full_dir, fname)
        wb.save(file_path)
        return file_path, default_storage.url(os.path.join(folder_path, fname))
