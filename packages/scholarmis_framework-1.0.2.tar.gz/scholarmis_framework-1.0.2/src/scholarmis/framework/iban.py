
def get_checksum(bban: str) -> str:
    """
    Calculate ISO 7064 mod-97-10 checksum (IBAN style).
    Accepts BBAN with letters or digits.
    A=10, ..., Z=35 before calculating.
    """
    # Step 1: Add placeholder check digits "00"
    temp = bban.upper() + "00"

    # Step 2: Convert letters to numbers (A=10...Z=35)
    converted = []
    for ch in temp:
        if ch.isalpha():
            converted.append(str(ord(ch) - 55))  # ord('A')=65 → 10
        else:
            converted.append(ch)
    numeric_str = "".join(converted)

    # Step 3: Mod 97
    remainder = int(numeric_str) % 97
    check_digits = 98 - remainder

    # Step 4: Return two-digit checksum
    return str(check_digits).zfill(2)

