from django.utils.html import format_html

class BooleanFieldMixin:

    def render_boolean(self, value):
        if value:
            icon_class = "fa fa-check"
        else:
            icon_class = "fa fa-times"
        return format_html(
            "<i class='{}'></i>",icon_class
        )

