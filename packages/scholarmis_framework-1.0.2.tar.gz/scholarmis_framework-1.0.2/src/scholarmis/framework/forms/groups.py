from typing import List, Optional

class FieldGroup:
    """Configuration for a group of fields"""

    def __init__(
        self,
        title: str,
        fields: List[str],
        description: Optional[str] = None,
        icon: Optional[str] = None,
        icon_color: str = 'bg-blue-100',
        grid_class: str = 'md:grid-cols-2',
    ):
        self.title = title
        self.fields = fields
        self.description = description
        self.icon = icon
        self.icon_color = icon_color
        self.grid_class = grid_class

    def to_dict(self):
        return {
            'title': self.title,
            'fields': self.fields,
            'description': self.description,
            'icon': self.icon,
            'icon_color': self.icon_color,
            'grid_class': self.grid_class,
        }