from typing import List, Optional, Type
from django import forms
from .mixins import FormFieldMixin
from .groups import FieldGroup
from .fields import DocumentField, MultipleDocumentsField


class DynamicForm(FormFieldMixin, forms.Form):
    """
    Base class for ScholarMIS dynamic forms.
    Integrates FormFieldMixin (dynamic queryset/value assignment),
    FieldGroup (UI grouping), and supports document fields.
    """

    field_groups: List[FieldGroup] = []

    def __init__(self, *args, **kwargs):
        """
        Initialize dynamic form.
        Supports dynamic field creation and group assignment.
        """
        super().__init__(*args, **kwargs)
        self._assign_field_groups()

    def _assign_field_groups(self):
        """
        Assign form fields to configured groups.
        Each FieldGroup contains a list of field names.
        """
        for group in self.field_groups:
            # Only keep fields that exist in the form
            group.fields = [f for f in group.fields if f in self.fields]

    def add_field(
        self,
        name: str,
        field_class: Type[forms.Field],
        label: Optional[str] = None,
        required: bool = False,
        initial=None,
        **kwargs
    ):
        """
        Dynamically add a field to the form.
        """
        self.fields[name] = field_class(label=label, required=required, initial=initial, **kwargs)
        return self.fields[name]

    def add_document_field(
        self,
        name: str,
        multiple: bool = False,
        label: Optional[str] = None,
        required: bool = False,
        allowed_extensions: Optional[List[str]] = None,
    ):
        """
        Add a DocumentField or MultipleDocumentsField to the form.
        """
        field_class = MultipleDocumentsField if multiple else DocumentField
        return self.add_field(
            name,
            field_class,
            label=label,
            required=required,
            allowed_extensions=allowed_extensions,
        )

    def set_field_group(self, group: FieldGroup):
        """
        Add a field group to the form.
        """
        self.field_groups.append(group)
        self._assign_field_groups()