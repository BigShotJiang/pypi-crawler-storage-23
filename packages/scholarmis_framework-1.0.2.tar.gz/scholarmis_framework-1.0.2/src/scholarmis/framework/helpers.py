import os

def get_template_name(template_path, app_name=None):
    if app_name:
        return os.path.join(app_name, template_path)
    else:
        return template_path
    

def get_user_from_context(context):
    request = context['request']
    user = request.user
    try:
        user_is_anonymous = user.is_anonymous()
    except TypeError:
        user_is_anonymous = user.is_anonymous

    if user_is_anonymous:
        return None
    return user


def get_instance(model_class, instance):
    if instance:
        if not isinstance(instance, model_class):
            # If instance is not of model_class type, assume it's a primary key and fetch the object
            return model_class.objects.get(pk=instance)
        return instance  # Return the object if it's already an instance of model_class
    return None  # Return None if the instance is None

