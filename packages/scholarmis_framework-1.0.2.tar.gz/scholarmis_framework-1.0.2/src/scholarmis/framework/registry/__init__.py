from .apps import app_registry
from .services import service_registry

__all__ = [
    "app_registry",
    "service_registry"
]