import uuid
import base64
import random
import string
from random import randint
from django.utils import timezone

def random_number(length):
    return str(randint(0, 10**length-1)).zfill(length)

def random_string(length):
    letters = string.ascii_uppercase
    return ''.join(random.choice(letters) for i in range(length))

def reference_number(length=16, date_format='%Y%m%d'):
    unique_id = uuid.uuid4()
    ref_number = base64.urlsafe_b64encode(unique_id.bytes).decode('utf-8').rstrip('=\n').replace('-', '').replace('_', '')
    date_str = timezone.now().strftime(date_format)
    return (date_str + ref_number.upper())[:length]


def generate_years(start_year=1950):
    current_year = timezone.now().year
    return [(y, y) for y in range(current_year, start_year - 1, -1)]