import uuid
import logging
from abc import ABC, abstractmethod
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.db import DatabaseError
from django.http import HttpResponse
from django.shortcuts import render
from django_tables2.export import TableExport, ExportMixin
from django_renderpdf import helpers
from .filters import dynamic_filter
from .resources import BaseResource


logger = logging.getLogger(__name__)


class ExportError(Exception):
    """Custom exception for export-related failures."""
    pass


class BaseExport(ABC):
    export_dir = "exports"

    def __init__(self, **filters):
        self.filters = filters
        self.file_path = None
        self.file_url = None
        
    def get_file_path(self):
        return self.file_path
    
    def get_file_url(self):
        return self.file_url

    def get_query_set(self, model):
        qs = model.objects.all()

        # No filters? Return normal queryset
        if not self.filters:
            return qs

        try:
            return dynamic_filter(qs, self.filters)
        except Exception as e:
            logger.error(
                f"Filtering failed for {model.__name__} with filters {self.filters}: {e}"
            )
            return qs
        
    def run(self):
        """
        The Template Method: Defines the flow and handles errors globally.
        """
        try:
            logger.info(f"Starting export: {self.__class__.__name__}")
            return self._execute_export()
        except DatabaseError as e:
            logger.error(f"Database error during export: {e}")
            raise ExportError("A database error occurred while fetching data.")
        except IOError as e:
            logger.error(f"File storage error: {e}")
            raise ExportError("Failed to save the export file to storage.")
        except Exception as e:
            logger.critical(f"Unexpected export failure: {e}")
            raise ExportError(f"An unexpected error occurred: {e}")

    @abstractmethod
    def _execute_export(self):
        """Child classes implement the specific export logic here."""
        pass

    def _generate_filename(self, extension):
        return f"{self.export_dir}/{uuid.uuid4()}.{extension}"


class ResourceExport(BaseExport):
    resource: BaseResource = None
    
    def __init__(self, resource_class, export_data=True, **filters):
        super().__init__(**filters)
        self.resource_class = resource_class
        self.export_data = export_data

    def _execute_export(self):
        self.resource = self.resource_class()
        queryset = self.get_query_set(self.resource.model)
        self.resource.set_queryset(queryset)
        self.resource.allow_data_export(self.export_data)
        
        # Resource internal logic
        self.file_path, self.file_url = self.resource.save_file(self.export_dir, True)
        return self.file_path, self.file_url


class RawTableExport(BaseExport):
    def __init__(self, table_class, model_class, export_format, **filters):
        super().__init__(**filters)
        self.table_class = table_class
        self.model_class = model_class
        self.export_format = export_format

    def _execute_export(self):
        queryset = self.get_query_set(self.model_class)
        table = self.table_class(queryset)
        
        exporter = TableExport(self.export_format, table)
        file_content = exporter.export()

        filename = self._generate_filename(self.export_format)
        
        self.file_path = default_storage.save(filename, ContentFile(file_content))
        self.file_url = default_storage.url(self.file_path)
        
        return self.file_path, self.file_url


class TableExportMixin(ExportMixin):
    """
    Handles table export (CSV, XLSX, etc.) without PDF.
    """

    export_formats = ["xlsx", "csv"]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Optional: applied filters, verbose labels
        if hasattr(self, 'filterset') and self.filterset.form.is_valid():
            filter_params = {
                k: v for k, v in self.filterset.form.cleaned_data.items()
                if v not in [None, '', [], (), {}]
            }
            filter_labels = {f: fld.label for f, fld in self.filterset.form.fields.items()}
            context["applied_filters"] = {filter_labels[k]: v for k, v in filter_params.items()}

        return context
    

class PDFExportMixin:
    """
    Handles PDF rendering for a view, including applied filters context.
    """

    pdf_template = None
    prompt_download: bool = False
    download_name: str = None
    allow_force_html: bool = True

    def get_download_name(self) -> str:
        return self.download_name or "document.pdf"

    def url_fetcher(self, url):
        return helpers.django_url_fetcher(url)

    def get_applied_filters_context(self, context: dict) -> dict:
        """
        Extract filterset form data and verbose labels to include in PDF context.
        """
        if hasattr(self, 'filterset') and self.filterset.form.is_valid():
            # Filter values
            filter_params = {
                k: v
                for k, v in self.filterset.form.cleaned_data.items()
                if v not in [None, '', [], (), {}]
            }
            # Field labels
            filter_labels = {
                f: fld.label
                for f, fld in self.filterset.form.fields.items()
            }
            # Combine label + value
            context["applied_filters"] = {filter_labels[k]: v for k, v in filter_params.items()}
        return context

    def generate_pdf(self, context: dict) -> HttpResponse:
        """
        Render PDF using django_renderpdf, injecting applied filters.
        """
        context = self.get_applied_filters_context(context)

        response = HttpResponse(content_type="application/pdf")
        if self.prompt_download:
            response["Content-Disposition"] = f'attachment; filename="{self.get_download_name()}"'
        helpers.render_pdf(
            template=self.pdf_template,
            file_=response,
            url_fetcher=self.url_fetcher,
            context=context,
        )
        return response

    def render_to_response(self, context: dict, **response_kwargs):
        """
        Decide PDF rendering or normal template rendering based on request GET parameter.
        """
        export_format = self.request.GET.get('export', None)
        if export_format == "pdf":
            return self.generate_pdf(context)
        return render(self.request, self.template_name, context)