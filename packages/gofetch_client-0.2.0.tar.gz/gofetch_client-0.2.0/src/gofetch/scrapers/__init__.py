"""
Platform-specific scraper utilities.
"""

from gofetch.scrapers.base import BaseScraper

__all__ = ["BaseScraper"]
