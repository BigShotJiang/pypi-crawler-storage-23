// A constraint is a set of constraints that can be applied to pushable
