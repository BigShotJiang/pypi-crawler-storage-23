# gmccc

[![PyPI](https://img.shields.io/pypi/v/gmccc)](https://pypi.org/project/gmccc/)
[![npm](https://img.shields.io/npm/v/gmccc)](https://www.npmjs.com/package/gmccc)

CLI to install Guan-Ming's Claude Code Skills.

## Install Skills

```bash
npx gmccc install
npx gmccc uninstall
```
