---
name: tvm-ffi-build
description: Build TVM FFI C++ project.
---

# TVM FFI Build

## Command
```bash
cmake --build build -j$(nproc)
```
