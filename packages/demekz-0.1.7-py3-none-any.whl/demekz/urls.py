from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('applications/', views.applications_view, name='applications'),
    path('applications/create/', views.create_application_view, name='create_application'),
    path('admin-panel/', views.admin_applications_view, name='admin_applications'),
]