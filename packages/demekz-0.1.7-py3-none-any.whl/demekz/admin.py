from django.contrib import admin
from .models import User, Application, Feedback

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['username', 'full_name', 'email', 'phone', 'is_staff']
    search_fields = ['username', 'full_name', 'email']

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ['course_name', 'user', 'start_date', 'payment_method', 'status', 'created_at']
    list_editable = ['status']
    list_filter = ['status', 'payment_method']
    search_fields = ['course_name', 'user__username']

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['user', 'created_at', 'text']
    list_filter = ['created_at']