import re
from django import forms
from django.core.exceptions import ValidationError
from .models import User, Application, Feedback


class RegistrationForm(forms.ModelForm):
    """Форма регистрации нового пользователя."""
    password = forms.CharField(
        widget=forms.PasswordInput,
        min_length=8,
        label='Пароль'
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput,
        label='Подтверждение пароля'
    )

    class Meta:
        model = User
        fields = ['username', 'full_name', 'phone', 'email', 'password']

    def clean_username(self):
        username = self.cleaned_data['username']
        if not re.match(r'^[a-zA-Z0-9]{6,}$', username):
            raise ValidationError('Логин должен содержать только латиницу и цифры, не менее 6 символов.')
        return username

    def clean_full_name(self):
        full_name = self.cleaned_data['full_name']
        # Разрешены кириллица, пробелы и дефисы (для двойных фамилий)
        if not re.match(r'^[а-яА-ЯёЁ\s\-]+$', full_name):
            raise ValidationError('ФИО должно содержать только кириллицу, пробелы и дефисы.')
        return full_name

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        # Формат: 8(XXX)XXX-XX-XX
        pattern = r'^8\(\d{3}\)\d{3}-\d{2}-\d{2}$'
        if not re.match(pattern, phone):
            raise ValidationError('Телефон должен быть в формате 8(XXX)XXX-XX-XX')
        return phone

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm = cleaned_data.get('confirm_password')
        if password and confirm and password != confirm:
            self.add_error('confirm_password', 'Пароли не совпадают')
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    """Форма входа (используется для отображения, но можно и стандартную AuthenticationForm)."""
    username = forms.CharField(max_length=150, label='Логин')
    password = forms.CharField(widget=forms.PasswordInput, label='Пароль')


class ApplicationForm(forms.ModelForm):
    """Форма создания заявки."""
    start_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        label='Желаемая дата начала'
    )

    class Meta:
        model = Application
        fields = ['course_name', 'start_date', 'payment_method']
        widgets = {
            'course_name': forms.TextInput(attrs={'class': 'form-control'}),
            'payment_method': forms.RadioSelect(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'course_name': 'Наименование курса',
            'payment_method': 'Способ оплаты',
        }


class FeedbackForm(forms.ModelForm):
    """Форма отправки отзыва."""
    class Meta:
        model = Feedback
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'class': 'form-control', 'placeholder': 'Ваш отзыв...'}),
        }
        labels = {
            'text': '',
        }