from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from .forms import RegistrationForm, LoginForm, ApplicationForm, FeedbackForm
from .models import Application, Feedback
from django.contrib.auth import get_user_model

User = get_user_model()


def index(request):
    """Главная страница со слайдером."""
    return render(request, 'demekz/index.html')


def register_view(request):
    """Регистрация нового пользователя."""
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Регистрация прошла успешно! Теперь вы можете войти.')
            return redirect('login')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = RegistrationForm()
    return render(request, 'demekz/register.html', {'form': form})


def login_view(request):
    """Авторизация пользователя."""
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('applications')
            else:
                messages.error(request, 'Неверный логин или пароль.')
    else:
        form = LoginForm()
    return render(request, 'demekz/login.html', {'form': form})


def logout_view(request):
    """Выход из системы."""
    logout(request)
    return redirect('index')


@login_required
def applications_view(request):
    """Страница со списком заявок текущего пользователя и формой отзыва."""
    user_applications = Application.objects.filter(user=request.user)
    if request.method == 'POST':
        feedback_form = FeedbackForm(request.POST)
        if feedback_form.is_valid():
            feedback = feedback_form.save(commit=False)
            feedback.user = request.user
            feedback.save()
            messages.success(request, 'Спасибо за ваш отзыв!')
            return redirect('applications')
    else:
        feedback_form = FeedbackForm()
    return render(request, 'demekz/applications.html', {
        'applications': user_applications,
        'feedback_form': feedback_form
    })


@login_required
def create_application_view(request):
    """Создание новой заявки."""
    if request.method == 'POST':
        form = ApplicationForm(request.POST)
        if form.is_valid():
            application = form.save(commit=False)
            application.user = request.user
            application.save()
            messages.success(request, 'Заявка успешно отправлена!')
            return redirect('applications')
    else:
        form = ApplicationForm()
    return render(request, 'demekz/application_form.html', {'form': form})


@staff_member_required
def admin_applications_view(request):
    """Панель администратора: список всех заявок с возможностью смены статуса."""
    applications = Application.objects.all()
    if request.method == 'POST':
        app_id = request.POST.get('application_id')
        new_status = request.POST.get('status')
        if app_id and new_status:
            application = get_object_or_404(Application, id=app_id)
            application.status = new_status
            application.save()
            messages.success(request, f'Статус заявки "{application.course_name}" обновлён.')
        return redirect('admin_applications')
    return render(request, 'demekz/admin/change_status.html', {'applications': applications})