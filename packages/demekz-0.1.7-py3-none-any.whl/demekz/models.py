from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    """
    Кастомная модель пользователя.
    Добавлены поля: full_name (ФИО), phone (телефон).
    """
    username = models.CharField(
        max_length=150,
        unique=True,
        verbose_name='Логин',
        help_text='Только латиница и цифры, не менее 6 символов.'
    )
    full_name = models.CharField(max_length=255, verbose_name='ФИО')
    phone = models.CharField(max_length=15, verbose_name='Телефон')
    email = models.EmailField(unique=True, verbose_name='Email')

    # Переопределим, чтобы поле password было обязательным
    password = models.CharField(max_length=128, verbose_name='Пароль')

    # Поле first_name/last_name нам не нужно, но можно оставить
    first_name = None
    last_name = None

    REQUIRED_FIELDS = ['full_name', 'phone', 'email']

    def __str__(self):
        return self.username


class Application(models.Model):
    """Заявка на курс."""
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('ongoing', 'Идет обучение'),
        ('completed', 'Обучение завершено'),
    ]
    PAYMENT_CHOICES = [
        ('cash', 'Наличными'),
        ('transfer', 'Перевод по номеру телефона'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='applications',
        verbose_name='Пользователь'
    )
    course_name = models.CharField(max_length=255, verbose_name='Наименование курса')
    start_date = models.DateField(verbose_name='Желаемая дата начала')
    payment_method = models.CharField(
        max_length=10,
        choices=PAYMENT_CHOICES,
        verbose_name='Способ оплаты'
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='new',
        verbose_name='Статус'
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')

    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.course_name} - {self.user.username}"


class Feedback(models.Model):
    """Отзыв пользователя о качестве услуг."""
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='feedbacks',
        verbose_name='Пользователь'
    )
    text = models.TextField(verbose_name='Отзыв')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата')

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
        ordering = ['-created_at']

    def __str__(self):
        return f"Отзыв от {self.user.username} от {self.created_at:%d.%m.%Y}"