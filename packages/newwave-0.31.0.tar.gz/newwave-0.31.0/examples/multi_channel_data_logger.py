#!/usr/bin/env python3
"""Multi-channel data logging using newwave.

This example demonstrates using WAV files for scientific/industrial
data logging where channels represent arbitrary data streams rather
than speaker positions.

Key concept: Setting channel_mask=0 indicates that channels have no
speaker assignment and should be treated as generic data channels.
This is spec-compliant per the WAVEFORMATEXTENSIBLE documentation.

Use cases:
- Laboratory equipment with multiple sensors
- Industrial data acquisition systems
- Multi-channel oscilloscope recordings
- Any application where channels != speakers
"""

import struct
import math
import newwave as wave


def simulate_sensor_data(sample_rate: int, duration: float, num_channels: int) -> bytes:
    """Generate simulated multi-channel sensor data.

    Creates different waveforms for each channel to simulate
    different sensor types:
    - Channel 0: Slow sine wave (temperature-like)
    - Channel 1: Fast sine wave (vibration-like)
    - Channel 2: Sawtooth wave (ramp signal)
    - Channel 3: Square wave (digital trigger)
    - Channel 4: Noise + DC offset (pressure-like)
    - Channel 5: Exponential decay (discharge curve)
    """
    import random

    num_samples = int(sample_rate * duration)
    frames = []

    for i in range(num_samples):
        t = i / sample_rate
        frame = []

        for ch in range(num_channels):
            if ch == 0:
                # Slow temperature-like sine
                value = 0.5 + 0.3 * math.sin(2 * math.pi * 0.1 * t)
            elif ch == 1:
                # Fast vibration-like sine
                value = 0.5 * math.sin(2 * math.pi * 100 * t)
            elif ch == 2:
                # Sawtooth ramp
                value = (t % 1.0) - 0.5
            elif ch == 3:
                # Square wave
                value = 0.8 if (int(t * 10) % 2 == 0) else -0.8
            elif ch == 4:
                # Noisy pressure signal
                value = 0.3 + 0.1 * random.gauss(0, 1)
            else:
                # Exponential decay
                value = math.exp(-t) * math.sin(2 * math.pi * 5 * t)

            # Scale to 24-bit integer range
            sample = int(value * 8388607)
            sample = max(-8388608, min(8388607, sample))
            frame.append(sample)

        # Pack as 24-bit samples (3 bytes each, little-endian)
        for sample in frame:
            # Convert signed 24-bit to 3 bytes
            sample_bytes = struct.pack('<i', sample)[:3]
            frames.append(sample_bytes)

    return b''.join(frames)


def write_data_log(filename: str, data: bytes, channels: int, sample_rate: int):
    """Write multi-channel data to a WAV file with no speaker assignment.

    Args:
        filename: Output WAV file path
        data: Raw sample data (interleaved channels)
        channels: Number of data channels
        sample_rate: Samples per second per channel
    """
    # channel_mask=0 means "no speaker assignment"
    # This tells software these are generic data channels, not audio
    with wave.write(filename,
                    channels=channels,
                    sampwidth=3,  # 24-bit for good dynamic range
                    framerate=sample_rate,
                    channel_mask=0) as w:
        w.writeframes(data)


def read_data_log(filename: str) -> tuple:
    """Read multi-channel data from a WAV file.

    Returns:
        Tuple of (data_bytes, num_channels, sample_rate, num_frames)
    """
    with wave.read(filename) as r:
        return (
            r.readframes(r.getnframes()),
            r.getnchannels(),
            r.getframerate(),
            r.getnframes()
        )


def main():
    # Configuration
    FILENAME = 'sensor_log.wav'
    CHANNELS = 6
    SAMPLE_RATE = 10000  # 10 kHz sampling
    DURATION = 2.0       # 2 seconds of data

    print("Multi-Channel Data Logger Example")
    print("=" * 50)
    print()
    print(f"Configuration:")
    print(f"  Channels: {CHANNELS}")
    print(f"  Sample rate: {SAMPLE_RATE} Hz")
    print(f"  Duration: {DURATION} s")
    print(f"  Bit depth: 24-bit")
    print(f"  Channel mask: 0 (no speaker assignment)")
    print()

    # Generate simulated sensor data
    print("Generating simulated sensor data...")
    data = simulate_sensor_data(SAMPLE_RATE, DURATION, CHANNELS)
    print(f"  Generated {len(data)} bytes of data")
    print()

    # Write to WAV file
    print(f"Writing to {FILENAME}...")
    write_data_log(FILENAME, data, CHANNELS, SAMPLE_RATE)
    print(f"  File written successfully")
    print()

    # Read it back to verify
    print("Reading back to verify...")
    read_data, num_ch, rate, frames = read_data_log(FILENAME)
    print(f"  Channels: {num_ch}")
    print(f"  Sample rate: {rate} Hz")
    print(f"  Frames: {frames}")
    print(f"  Data matches: {read_data == data}")
    print()

    # Show the file structure
    print("WAV file structure:")
    with open(FILENAME, 'rb') as f:
        # RIFF header
        riff = f.read(4)
        size = struct.unpack('<L', f.read(4))[0]
        wave_id = f.read(4)
        print(f"  {riff.decode()} size={size} {wave_id.decode()}")

        while True:
            chunk_id = f.read(4)
            if len(chunk_id) < 4:
                break
            chunk_size = struct.unpack('<L', f.read(4))[0]

            if chunk_id == b'fmt ':
                fmt_data = f.read(chunk_size)
                fmt_tag = struct.unpack('<H', fmt_data[:2])[0]
                nch = struct.unpack('<H', fmt_data[2:4])[0]

                if fmt_tag == 0xFFFE:  # EXTENSIBLE
                    channel_mask = struct.unpack('<L', fmt_data[20:24])[0]
                    print(f"  fmt  size={chunk_size} format=EXTENSIBLE channels={nch} mask=0x{channel_mask:X}")
                else:
                    print(f"  fmt  size={chunk_size} format=0x{fmt_tag:04X} channels={nch}")
            else:
                print(f"  {chunk_id.decode()} size={chunk_size}")
                f.seek(chunk_size + (chunk_size & 1), 1)

    print()
    print("=" * 50)
    print("Example complete!")


if __name__ == '__main__':
    main()
