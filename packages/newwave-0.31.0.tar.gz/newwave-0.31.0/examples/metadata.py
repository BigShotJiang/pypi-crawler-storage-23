#!/usr/bin/env python3
"""Examples demonstrating LIST INFO metadata support in newwave.

This example shows how to:
- Write metadata tags to WAVE files
- Read metadata from WAVE files
- Use both string tag names and MetadataTag enums
"""

import math
import struct
import newwave as wave


def generate_audio_data(duration=1.0, sample_rate=44100, frequency=440):
    """Generate a simple stereo sine wave for demonstration."""
    num_samples = int(sample_rate * duration)
    samples = []
    for i in range(num_samples):
        t = i / sample_rate
        value = 0.7 * math.sin(2 * math.pi * frequency * t)
        sample = int(value * 32767)
        samples.append(sample)
        samples.append(sample)  # Stereo
    return struct.pack(f'<{len(samples)}h', *samples)


def example_write_metadata_dict():
    """Write metadata using setmetadata() with a dictionary."""
    print("Example 1: Writing metadata with setmetadata()")

    audio_data = generate_audio_data()

    with wave.write('tagged_song.wav', channels=2, sampwidth=2, framerate=44100) as w:
        w.setmetadata({
            'title': 'My Awesome Song',
            'artist': 'The Artist',
            'album': 'Greatest Hits',
            'date': '2026',
            'genre': 'Electronic',
            'comment': 'Created with newwave',
            'copyright': '(c) 2026 The Artist',
            'software': 'newwave Python library',
        })
        w.writeframes(audio_data)

    print("  Written: tagged_song.wav")


def example_write_metadata_individual():
    """Write metadata using settag() for individual tags."""
    print("Example 2: Writing metadata with settag()")

    audio_data = generate_audio_data(frequency=523)  # C5 note

    with wave.write('tagged_individual.wav', channels=2, sampwidth=2, framerate=44100) as w:
        # Using string tag names
        w.settag('title', 'Another Song')
        w.settag('artist', 'Another Artist')

        # Using MetadataTag enum (recommended for IDE autocomplete)
        w.settag(wave.MetadataTag.ALBUM, 'Debut Album')
        w.settag(wave.MetadataTag.DATE, '2026-02-10')
        w.settag(wave.MetadataTag.GENRE, 'Ambient')

        w.writeframes(audio_data)

    print("  Written: tagged_individual.wav")


def example_read_metadata():
    """Read metadata from a WAVE file."""
    print("Example 3: Reading metadata")

    with wave.read('tagged_song.wav') as r:
        # Get all metadata as a dictionary
        metadata = r.getmetadata()
        print(f"  All metadata: {metadata}")

        # Get individual tags using string names
        title = r.gettag('title')
        artist = r.gettag('artist')
        print(f"  Title: {title}")
        print(f"  Artist: {artist}")

        # Get tags using MetadataTag enum
        album = r.gettag(wave.MetadataTag.ALBUM)
        date = r.gettag(wave.MetadataTag.DATE)
        print(f"  Album: {album}")
        print(f"  Date: {date}")

        # Non-existent tags return None
        nonexistent = r.gettag('tracknumber')
        print(f"  Tracknumber (not set): {nonexistent}")


def example_unicode_metadata():
    """Demonstrate Unicode support in metadata.

    Note: newwave writes metadata as UTF-8. Modern tools like ffprobe and
    Audacity handle this correctly, but some older tools (like mediainfo)
    may misinterpret UTF-8 as Latin-1, showing garbled text.

    The RIFF LIST INFO format predates Unicode, so encoding support varies.
    For maximum compatibility with legacy tools, stick to ASCII characters.
    """
    print("Example 4: Unicode metadata")
    print("  Note: UTF-8 encoding - works with ffprobe/Audacity, may be garbled in mediainfo")

    audio_data = generate_audio_data(frequency=880)

    with wave.write('unicode_tags.wav', channels=2, sampwidth=2, framerate=44100) as w:
        w.setmetadata({
            'title': 'Café Müsik',
            'artist': 'Björk & 日本語アーティスト',
            'comment': 'Ελληνικά, Русский, 中文',
        })
        w.writeframes(audio_data)

    print("  Written: unicode_tags.wav")

    # Read it back
    with wave.read('unicode_tags.wav') as r:
        print(f"  Title: {r.gettag('title')}")
        print(f"  Artist: {r.gettag('artist')}")
        print(f"  Comment: {r.gettag('comment')}")


def example_available_tags():
    """Show all available MetadataTag enum values."""
    print("Example 5: Available MetadataTag values")

    print("  Available tags:")
    for tag in wave.MetadataTag:
        print(f"    {tag.name:15} -> '{tag.tag_name}' (INFO chunk: {tag.chunk_id})")


if __name__ == '__main__':
    print("newwave Metadata Examples")
    print("=" * 50)
    print()

    example_write_metadata_dict()
    print()

    example_write_metadata_individual()
    print()

    example_read_metadata()
    print()

    example_unicode_metadata()
    print()

    example_available_tags()
    print()

    print("Done! Check the generated .wav files.")
