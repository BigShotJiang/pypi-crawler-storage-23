#!/usr/bin/env python3
"""Generate a 1kHz sine wave using newwave.

This example demonstrates the basic usage of newwave to create
a simple audio file. It generates a pure sine wave tone and
writes it as a standard 16-bit stereo WAV file.
"""

import math
import struct
import newwave as wave

# Audio parameters
SAMPLE_RATE = 44100  # 44.1 kHz
CHANNELS = 2         # Stereo
DURATION = 1.0       # seconds
FREQUENCY = 1000     # 1 kHz
AMPLITUDE = 0.8      # 80% of max to avoid clipping

# Generate samples
num_samples = int(SAMPLE_RATE * DURATION)
samples = []

for i in range(num_samples):
    t = i / SAMPLE_RATE
    value = AMPLITUDE * math.sin(2 * math.pi * FREQUENCY * t)
    # Convert to 16-bit signed integer
    sample = int(value * 32767)
    # Duplicate for both channels (stereo)
    samples.append(sample)
    samples.append(sample)

# Pack samples as 16-bit signed little-endian
data = struct.pack(f'<{len(samples)}h', *samples)

# Write the wave file using the modern API
with wave.write('sine_1khz.wav', channels=CHANNELS, sampwidth=2, framerate=SAMPLE_RATE) as w:
    w.writeframes(data)

print(f"Created sine_1khz.wav")
print(f"  Duration: {DURATION}s")
print(f"  Sample rate: {SAMPLE_RATE} Hz")
print(f"  Channels: {CHANNELS}")
print(f"  Frequency: {FREQUENCY} Hz")
