"""Examples demonstrating WAVEFORMATEXTENSIBLE writing with newwave.

These examples show how to write various wave file formats including:
- Standard PCM (16-bit stereo)
- High-resolution audio (24-bit, 32-bit)
- Multi-channel surround sound
- IEEE Float format
"""

import newwave
import struct
import math


def example_standard_stereo():
    """Standard 16-bit stereo PCM - uses simple PCMWAVEFORMAT header."""
    print("Example 1: Standard 16-bit stereo PCM")

    # Generate a simple sine wave
    sample_rate = 44100
    duration = 1.0  # seconds
    frequency = 440  # Hz (A4 note)

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        # Generate stereo samples (left and right identical)
        sample = int(32767 * math.sin(2 * math.pi * frequency * t))
        samples.append(struct.pack('<hh', sample, sample))

    audio_data = b''.join(samples)

    with newwave.write('example_stereo_16bit.wav',
                       channels=2, sampwidth=2, framerate=sample_rate) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_stereo_16bit.wav ({len(audio_data)} bytes of audio)")


def example_high_resolution():
    """24-bit stereo - automatically uses WAVEFORMATEXTENSIBLE."""
    print("Example 2: 24-bit high-resolution audio")

    sample_rate = 96000
    duration = 1.0
    frequency = 440

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        # 24-bit sample range: -8388608 to 8388607
        sample = int(8388607 * math.sin(2 * math.pi * frequency * t))
        # Pack as 3 bytes little-endian (for both channels)
        sample_bytes = struct.pack('<i', sample)[:3]
        samples.append(sample_bytes + sample_bytes)

    audio_data = b''.join(samples)

    with newwave.write('example_stereo_24bit.wav',
                       channels=2, sampwidth=3, framerate=sample_rate) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_stereo_24bit.wav ({len(audio_data)} bytes of audio)")
    print("  Format: WAVEFORMATEXTENSIBLE (auto-selected for >16-bit)")


def example_surround_51():
    """5.1 surround sound with explicit channel mask."""
    print("Example 3: 5.1 surround sound")

    # Channel mask for 5.1: FL, FR, FC, LFE, BL, BR
    # Bits: 0x01 (FL) | 0x02 (FR) | 0x04 (FC) | 0x08 (LFE) | 0x10 (BL) | 0x20 (BR) = 0x3F
    CHANNEL_MASK_5_1 = 0x3F

    sample_rate = 48000
    duration = 1.0

    # Generate 6 channels of audio (different frequencies for each)
    frequencies = [440, 554, 659, 100, 440, 554]  # A4, C#5, E5, bass, A4, C#5

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        frame = b''
        for freq in frequencies:
            sample = int(32767 * 0.5 * math.sin(2 * math.pi * freq * t))
            frame += struct.pack('<h', sample)
        samples.append(frame)

    audio_data = b''.join(samples)

    with newwave.write('example_surround_51.wav',
                       channels=6, sampwidth=2, framerate=sample_rate,
                       channel_mask=CHANNEL_MASK_5_1) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_surround_51.wav ({len(audio_data)} bytes of audio)")
    print(f"  Channel mask: 0x{CHANNEL_MASK_5_1:02X} (FL, FR, FC, LFE, BL, BR)")


def example_ieee_float():
    """32-bit IEEE Float format."""
    print("Example 4: 32-bit IEEE Float")

    sample_rate = 44100
    duration = 1.0
    frequency = 440

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        # Float samples are typically in range [-1.0, 1.0]
        sample = 0.8 * math.sin(2 * math.pi * frequency * t)
        # Stereo
        samples.append(struct.pack('<ff', sample, sample))

    audio_data = b''.join(samples)

    with newwave.write('example_float32.wav',
                       channels=2, sampwidth=4, framerate=sample_rate,
                       format=newwave.WaveFormat.IEEE_FLOAT) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_float32.wav ({len(audio_data)} bytes of audio)")
    print("  Format: WAVEFORMATEXTENSIBLE with IEEE_FLOAT subformat")


def example_quad():
    """Quadraphonic (4-channel) audio."""
    print("Example 5: Quadraphonic (4-channel)")

    # Channel mask for quad: FL, FR, BL, BR
    # Bits: 0x01 (FL) | 0x02 (FR) | 0x10 (BL) | 0x20 (BR) = 0x33
    CHANNEL_MASK_QUAD = 0x33

    sample_rate = 48000
    duration = 1.0

    # Different frequencies for each corner
    frequencies = [440, 554, 659, 880]  # A4, C#5, E5, A5

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        frame = b''
        for freq in frequencies:
            sample = int(32767 * 0.5 * math.sin(2 * math.pi * freq * t))
            frame += struct.pack('<h', sample)
        samples.append(frame)

    audio_data = b''.join(samples)

    with newwave.write('example_quad.wav',
                       channels=4, sampwidth=2, framerate=sample_rate,
                       channel_mask=CHANNEL_MASK_QUAD) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_quad.wav ({len(audio_data)} bytes of audio)")
    print(f"  Channel mask: 0x{CHANNEL_MASK_QUAD:02X} (FL, FR, BL, BR)")


def example_explicit_extensible():
    """Force WAVEFORMATEXTENSIBLE even for stereo 16-bit."""
    print("Example 6: Explicit WAVEFORMATEXTENSIBLE for stereo 16-bit")

    sample_rate = 44100
    duration = 1.0
    frequency = 440

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        sample = int(32767 * math.sin(2 * math.pi * frequency * t))
        samples.append(struct.pack('<hh', sample, sample))

    audio_data = b''.join(samples)

    # Explicitly request EXTENSIBLE format
    with newwave.write('example_extensible_explicit.wav',
                       channels=2, sampwidth=2, framerate=sample_rate,
                       format=newwave.WaveFormat.EXTENSIBLE) as w:
        w.writeframes(audio_data)

    print(f"  Written: example_extensible_explicit.wav ({len(audio_data)} bytes of audio)")
    print("  Format: WAVEFORMATEXTENSIBLE (explicitly requested)")


def example_using_wave_write_class():
    """Using Wave_write class directly with more control."""
    print("Example 7: Using Wave_write class directly")

    sample_rate = 48000
    duration = 0.5
    frequency = 880

    w = newwave.Wave_write('example_direct.wav')
    w.setnchannels(2)
    w.setsampwidth(3)  # 24-bit
    w.setframerate(sample_rate)
    w.setchannelmask(0x03)  # FL + FR

    samples = []
    for i in range(int(sample_rate * duration)):
        t = i / sample_rate
        sample = int(8388607 * math.sin(2 * math.pi * frequency * t))
        sample_bytes = struct.pack('<i', sample)[:3]
        samples.append(sample_bytes + sample_bytes)

    audio_data = b''.join(samples)
    w.writeframes(audio_data)
    w.close()

    print(f"  Written: example_direct.wav ({len(audio_data)} bytes of audio)")


def example_roundtrip():
    """Write and read back a WAVEFORMATEXTENSIBLE file."""
    print("Example 8: Round-trip (write then read)")

    sample_rate = 48000

    # Write a 24-bit file
    original_data = bytes([i % 256 for i in range(48000 * 2 * 3)])  # 1 second stereo 24-bit

    with newwave.write('example_roundtrip.wav',
                       channels=2, sampwidth=3, framerate=sample_rate) as w:
        w.writeframes(original_data)

    # Read it back
    with newwave.read('example_roundtrip.wav') as r:
        print(f"  Channels: {r.getnchannels()}")
        print(f"  Sample width: {r.getsampwidth()} bytes")
        print(f"  Frame rate: {r.getframerate()} Hz")
        print(f"  Format: {r.getformat().name}")
        print(f"  Frames: {r.getnframes()}")

        read_data = r.readframes(r.getnframes())
        print(f"  Data matches: {read_data == original_data}")


if __name__ == '__main__':
    print("WAVEFORMATEXTENSIBLE Examples")
    print("=" * 50)
    print()

    example_standard_stereo()
    print()

    example_high_resolution()
    print()

    example_surround_51()
    print()

    example_ieee_float()
    print()

    example_quad()
    print()

    example_explicit_extensible()
    print()

    example_using_wave_write_class()
    print()

    example_roundtrip()
    print()

    print("=" * 50)
    print("All examples completed!")
