# Developing this module

We keep all code and issue tracking for this module on Codeberg.
See [https://codeberg.org/michielb/newwave](https://codeberg.org/michielb/newwave).

If you would like to develop code for this module, you're welcome!
Please feel free to open [https://codeberg.org/michielb/newwave/issues](issues)
on Codeberg to discuss any issues or ideas you might have.


## Prerequisites

This project uses [uv](https://docs.astral.sh/uv/) for dependency management and running tests.
Please make sure you have it installed. We use GNU Make as a task runner, please make sure you have that installed as well although you can also do without,
as specified below.

## Development

As the purpose of this module is to be as close to a testing ground to
stdlib's `wave` as possible, we don't do linters in this repository.
So no code formatting or stuff like that!
And we do typing, but by providing a separate `.pyi` file.

## Running tests

A `Makefile` is provided for common development tasks:

```bash
make test       # Run tests with the default Python version
make typecheck  # Run type checker (ty)
make fulltest   # Run type checker + tests on Python 3.10–3.15
make clean      # Remove cache directories
```

Or run tests directly:

```bash
uv run pytest
uvx ty check
```
