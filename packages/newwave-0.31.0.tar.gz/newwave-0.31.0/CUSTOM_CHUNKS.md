# Custom RIFF Chunks in newwave

## Overview

WAVE files use the RIFF (Resource Interchange File Format) container, which supports arbitrary custom chunks beyond the standard `fmt `, `data`, and LIST chunks. This allows storing application-specific metadata while maintaining compatibility with standard WAVE players.

## Why Use Custom Chunks?

1. **Arbitrary Metadata**: Store data that doesn't fit the 13 standard LIST INFO tags
2. **Encoding Metadata**: Preserve FLAC compression parameters, codec settings
3. **Processing History**: Track signal processing applied to audio
4. **Application State**: Save application-specific parameters
5. **Extensibility**: Future-proof your audio files with new metadata types

## RIFF Chunk Structure

Each chunk in a RIFF file has:
- **Chunk ID**: 4-byte ASCII identifier (e.g., `b'INFO'`, `b'junk'`)
- **Chunk Size**: 4-byte little-endian size (data only, not including ID and size fields)
- **Chunk Data**: The actual data (padded to word boundary with null byte if odd-length)

## Using Custom Chunks with newwave

### Writing Custom Chunks

```python
import newwave as wave
import json

with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
    # Standard audio
    w.writeframes(audio_data)

    # Add custom metadata as JSON
    metadata = {
        'encoder': 'Custom App v1.0',
        'processing': ['normalize', 'eq'],
        'timestamp': '2026-02-14T10:00:00',
    }
    w.addchunk(b'APP\x00', json.dumps(metadata).encode('utf-8'))

    # Add custom binary data
    processing_params = struct.pack('<ff', 0.5, 1.2)
    w.addchunk(b'PROC', processing_params)
```

### Reading Custom Chunks

```python
with wave.read('output.wav') as r:
    # Get all custom chunks (excluding standard ones)
    chunks = r.getchunks()

    for chunk_id, data in chunks.items():
        print(f"Chunk {chunk_id}: {len(data)} bytes")

    # Get specific chunk
    if b'APP\x00' in chunks:
        metadata = json.loads(chunks[b'APP\x00'].decode('utf-8'))
        print(metadata)
```

## Preserving Metadata Through FLAC Encoding

When converting WAV to FLAC and back, use custom chunks to preserve application metadata:

```python
import newwave as wave
import flac_encoder

# Read WAV with custom metadata
with wave.read('input.wav') as r:
    audio_data = r.readframes(r.getnframes())
    params = r.getparams()
    custom_chunks = r.getchunks()

# Encode to FLAC (preserve metadata in Vorbis comments or custom sections)
flac_path = encode_to_flac(audio_data, params)

# Later: Decode back from FLAC
wav_path = 'restored.wav'
audio_data = decode_from_flac(flac_path)

# Write WAV with restored metadata
with wave.write(wav_path, **params._asdict()) as w:
    w.writeframes(audio_data)

    # Restore custom chunks
    for chunk_id, data in custom_chunks.items():
        w.addchunk(chunk_id, data)
```

## Chunk ID Conventions

Standard chunk IDs:
- `fmt ` - Format (managed by newwave)
- `data` - Audio data (managed by newwave)
- `fact` - Fact chunk for non-PCM (managed by newwave)
- `LIST` - LIST container (includes INFO subchunks)
- `junk` - Padding (not recommended)

Custom chunk recommendations:
- Use 4-byte ASCII IDs
- Avoid IDs used by known formats
- Document your chunk format
- Examples: `APPL`, `PROC`, `META`, `APP\x00`

## Chunk ID Namespace

To avoid conflicts:
- Register with Microsoft for official chunk IDs
- Or use application-specific prefixes: `MY00`, `APP1`, etc.
- Or use your organization's abbreviation: `ABC1`, `XYZ2`

## Examples

See [examples/custom_chunks.py](examples/custom_chunks.py) for:
- Custom binary metadata
- JSON metadata storage
- FLAC integration
- Chunk preservation patterns

## References

- RIFF Specification: https://www.adobe.io/content/dam/udp/assets/open/audio/riffnewmedia.pdf
- WAV Format Specs: http://www.ambisonia.com/Members/geller/WAVE%20PCM%20soundfile%20format/WaveFormat.html
- FLAC Format: https://xiph.org/flac/format.html
