# CHANGES for newwave

## 0.31.0 - 2026-02-19

- **Bug Fix**: `setframerate()` now correctly rejects unlikely values like `0.5` that round to `0` ([GH-132445](https://github.com/python/cpython/issues/132445), reported by ygerlach)

## 0.30 - 2026-02-14

(oops, versioning mistake, should have been 0.3.0)

- **WAVEFORMATEXTENSIBLE Write Support**: Handle multi-channel and high bit-depth audio with proper speaker position masks
- **LIST INFO Metadata Support**: Read and write standard RIFF metadata tags (title, artist, album, etc.)
- **IEEE Float Format Support**: Read and write 32-bit and 64-bit floating-point audio
- **Custom RIFF Chunks Support**: Added `addchunk()`, `getchunk()`, and `getchunks()` methods to store arbitrary application-specific data in WAVE files beyond the 13 standard LIST INFO tags
- **Convenience Functions**: Added `wave.read()` and `wave.write()` for simpler API usage
- **WaveFormat Enum**: Proper format type handling for PCM, IEEE Float, and Extensible formats
- **Public wave_params**: Named tuple with format field for typed parameter handling
- **Improved Documentation**: Comprehensive docstrings and examples

## 0.2.0 - 2026-02-03

- Second iteration with improvements to package setup and including type hints

## 0.1.1 - 2026-01-31

- First properly marked version, backports wave from python 3.15 stdlib all the way back to python 3.10
