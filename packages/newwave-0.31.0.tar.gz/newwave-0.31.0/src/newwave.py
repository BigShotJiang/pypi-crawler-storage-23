"""Read and write WAVE audio files.

newwave is a drop-in replacement for Python's standard library wave module,
with additional features for modern audio formats.

Features:
    - Read/write standard PCM WAVE files (8, 16, 24, 32-bit)
    - IEEE Float format support (32-bit and 64-bit float)
    - WAVEFORMATEXTENSIBLE for >2 channels or >16-bit audio
    - Configurable channel masks for surround sound layouts
    - Fact chunk support for non-PCM formats

Quick Start:
    Reading::

        import newwave as wave
        with wave.read('input.wav') as w:
            data = w.readframes(w.getnframes())
            print(f"{w.getnchannels()} channels, {w.getframerate()} Hz")

    Writing::

        import newwave as wave
        with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(audio_data)

    Multi-channel with speaker layout::

        with wave.write('surround.wav', channels=6, sampwidth=3, framerate=48000,
                        channel_mask=wave.ChannelMask.SURROUND_5_1) as w:
            w.writeframes(surround_data)

    Data logging (no speaker assignment)::

        with wave.write('sensors.wav', channels=8, sampwidth=3, framerate=10000,
                        channel_mask=0) as w:
            w.writeframes(sensor_data)

Formats:
    WaveFormat.PCM (0x0001)
        Standard integer PCM. Sample values are signed integers
        (except 8-bit which is unsigned). This is the default format.

    WaveFormat.IEEE_FLOAT (0x0003)
        IEEE 754 floating-point samples. Values typically range from
        -1.0 to 1.0 with full scale at ±1.0.

    WaveFormat.EXTENSIBLE (0xFFFE)
        Extended format that supports channel masks and sub-formats.
        Automatically used when:
        - More than 2 channels
        - More than 16 bits per sample (sampwidth > 2)
        - Explicit channel_mask is set
        - Explicitly requested via format=WaveFormat.EXTENSIBLE

Channel Masks:
    When using WAVEFORMATEXTENSIBLE, the channel_mask indicates which
    speaker positions are used. Common values:

    - ChannelMask.STEREO (0x03): Front Left + Front Right
    - ChannelMask.SURROUND_5_1 (0x3F): FL, FR, FC, LFE, BL, BR
    - ChannelMask.SURROUND_7_1 (0xFF): 5.1 + Side Left + Side Right
    - 0: No speaker assignment (for data logging, lab equipment, etc.)

Compatibility:
    For compatibility with the standard library wave module, you can also
    use wave.open() with the traditional setter-based API::

        with wave.open('output.wav', 'wb') as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(44100)
            w.writeframes(audio_data)
"""

from collections import namedtuple
from enum import IntEnum, IntFlag, Enum
import builtins
import os
import struct
import sys


__all__ = ["open", "read", "write", "Error", "Wave_read", "Wave_write", "wave_params", "WaveFormat", "ChannelMask", "MetadataTag"]

class Error(Exception):
    pass

class WaveFormat(IntEnum):
    """Wave file format types.

    These values correspond to the wFormatTag field in the WAVE file header.

    Attributes:
        PCM: Standard integer PCM format (0x0001). Sample values are signed
            integers (two's complement), except for 8-bit which uses
            unsigned integers (0-255 with 128 as center).

        IEEE_FLOAT: IEEE 754 floating-point format (0x0003). Sample values
            are 32-bit or 64-bit floats, typically ranging from -1.0 to 1.0.
            Requires a Fact chunk in the file.

        EXTENSIBLE: Extended format (0xFFFE) that includes a channel mask
            for speaker assignment and a SubFormat GUID. Automatically used
            for >2 channels, >16-bit samples, or explicit channel masks.

    Example::

        import newwave as wave

        # Write a 32-bit float file
        with wave.write('float.wav', channels=2, sampwidth=4, framerate=48000,
                        format=wave.WaveFormat.IEEE_FLOAT) as w:
            w.writeframes(float_data)

        # Read and check format
        with wave.read('input.wav') as r:
            if r.getformat() == wave.WaveFormat.IEEE_FLOAT:
                print("This is a float file")
    """
    PCM = 0x0001
    IEEE_FLOAT = 0x0003
    EXTENSIBLE = 0xFFFE

class ChannelMask(IntFlag):
    """Speaker position flags for WAVEFORMATEXTENSIBLE channel masks.

    These flags indicate which speaker positions are present in the audio.
    Multiple flags can be combined with the | operator to create a channel
    mask for multichannel audio.

    The order of channels in the audio data must match the order of bits
    in the mask, from least significant to most significant. For example,
    5.1 surround (SURROUND_5_1 = 0x3F) has channels in this order:
    Front Left, Front Right, Front Center, LFE, Back Left, Back Right.

    Example:
        # Create a custom quad layout
        mask = ChannelMask.FRONT_LEFT | ChannelMask.FRONT_RIGHT | \
               ChannelMask.BACK_LEFT | ChannelMask.BACK_RIGHT

        # Use a predefined layout
        with wave.write('surround.wav', channels=6, sampwidth=3,
                        framerate=48000, channel_mask=ChannelMask.SURROUND_5_1) as w:
            w.writeframes(audio_data)
    """
    # Individual speaker positions (bits 0-17)
    FRONT_LEFT = 0x1
    FRONT_RIGHT = 0x2
    FRONT_CENTER = 0x4
    LOW_FREQUENCY = 0x8  # Subwoofer / LFE
    BACK_LEFT = 0x10
    BACK_RIGHT = 0x20
    FRONT_LEFT_OF_CENTER = 0x40
    FRONT_RIGHT_OF_CENTER = 0x80
    BACK_CENTER = 0x100
    SIDE_LEFT = 0x200
    SIDE_RIGHT = 0x400
    TOP_CENTER = 0x800
    TOP_FRONT_LEFT = 0x1000
    TOP_FRONT_CENTER = 0x2000
    TOP_FRONT_RIGHT = 0x4000
    TOP_BACK_LEFT = 0x8000
    TOP_BACK_CENTER = 0x10000
    TOP_BACK_RIGHT = 0x20000

    # Common speaker configurations
    MONO = FRONT_CENTER
    STEREO = FRONT_LEFT | FRONT_RIGHT
    STEREO_LFE = FRONT_LEFT | FRONT_RIGHT | LOW_FREQUENCY  # 2.1
    QUAD = FRONT_LEFT | FRONT_RIGHT | BACK_LEFT | BACK_RIGHT
    SURROUND_5_1 = (FRONT_LEFT | FRONT_RIGHT | FRONT_CENTER |
                   LOW_FREQUENCY | BACK_LEFT | BACK_RIGHT)
    SURROUND_5_1_SIDE = (FRONT_LEFT | FRONT_RIGHT | FRONT_CENTER |
                        LOW_FREQUENCY | SIDE_LEFT | SIDE_RIGHT)
    SURROUND_7_1 = (FRONT_LEFT | FRONT_RIGHT | FRONT_CENTER |
                   LOW_FREQUENCY | BACK_LEFT | BACK_RIGHT |
                   SIDE_LEFT | SIDE_RIGHT)

# Derived from uuid.UUID("00000001-0000-0010-8000-00aa00389b71").bytes_le
KSDATAFORMAT_SUBTYPE_PCM = b'\x01\x00\x00\x00\x00\x00\x10\x00\x80\x00\x00\xaa\x008\x9bq'
# Derived from uuid.UUID("00000003-0000-0010-8000-00aa00389b71").bytes_le
KSDATAFORMAT_SUBTYPE_IEEE_FLOAT = b'\x03\x00\x00\x00\x00\x00\x10\x00\x80\x00\x00\xaa\x008\x9bq'


class MetadataTag(Enum):
    """Standard LIST INFO metadata tags for WAVE files.

    WAVE files support only a predefined set of 13 metadata tags from the standard
    RIFF INFO chunk specification. Custom or non-standard tag names are not
    supported and will raise ValueError if used.

    Supported tags (case-insensitive):
        - title: Song or description title
        - artist: Performance artist(s)
        - album: Album/collection name
        - tracknumber: Track number in a series
        - date: Date of creation (YYYY-MM-DD format recommended)
        - genre: Genre classification
        - comment: General comments about the work
        - copyright: Copyright information
        - software: Name/version of software used to create the file
        - engineer: Sound engineer/technician name
        - technician: Technician who performed the work
        - source: Source medium or instrument
        - subject: Subject description
        - keywords: Keywords/search terms

    Each tag is stored in the WAVE file as a 4-byte binary chunk ID according
    to the RIFF specification (e.g., 'title' → b'INAM').

    For the complete RIFF/INFO specification, see:
    https://www.adobe.io/content/dam/udp/assets/open/audio/riffnewmedia.pdf

    Example::

        import newwave as wave

        with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
            w.settag(wave.MetadataTag.TITLE, 'My Song')
            w.settag(wave.MetadataTag.ARTIST, 'The Artist')
            w.writeframes(audio_data)

        with wave.read('output.wav') as r:
            print(r.gettag(wave.MetadataTag.TITLE))
    """
    TITLE = ('title', b'INAM')
    ARTIST = ('artist', b'IART')
    ALBUM = ('album', b'IPRD')
    TRACKNUMBER = ('tracknumber', b'ITRK')
    DATE = ('date', b'ICRD')
    GENRE = ('genre', b'IGNR')
    COMMENT = ('comment', b'ICMT')
    COPYRIGHT = ('copyright', b'ICOP')
    SOFTWARE = ('software', b'ISFT')
    ENGINEER = ('engineer', b'IENG')
    TECHNICIAN = ('technician', b'ITCH')
    SOURCE = ('source', b'ISRC')
    SUBJECT = ('subject', b'ISBJ')
    KEYWORDS = ('keywords', b'IKEY')

    def __init__(self, tag_name, chunk_id):
        self._tag_name = tag_name
        self._chunk_id = chunk_id

    @property
    def tag_name(self):
        """The string tag name (e.g., 'title')."""
        return self._tag_name

    @property
    def chunk_id(self):
        """The 4-byte RIFF chunk ID (e.g., b'INAM')."""
        return self._chunk_id


# Build lookup dicts from the enum
_INFO_CHUNK_MAP = {tag.chunk_id: tag.tag_name for tag in MetadataTag}
_TAG_TO_INFO_CHUNK = {tag.tag_name: tag.chunk_id for tag in MetadataTag}


def _normalize_tag(tag):
    """Normalize a metadata tag to its string name.

    Args:
        tag: Either a MetadataTag enum value or a string tag name.

    Returns:
        The string tag name (lowercase).

    Raises:
        ValueError: If the tag is a string but not a known tag name.
        TypeError: If the tag is neither a MetadataTag nor a string.
    """
    if isinstance(tag, MetadataTag):
        return tag.tag_name
    elif isinstance(tag, str):
        tag_lower = tag.lower()
        if tag_lower not in _TAG_TO_INFO_CHUNK:
            valid_tags = ', '.join(sorted(_TAG_TO_INFO_CHUNK.keys()))
            raise ValueError(f"Unknown metadata tag: {tag!r}. "
                           f"Valid tags are: {valid_tags}")
        return tag_lower
    else:
        raise TypeError(f"tag must be MetadataTag or str, not {type(tag).__name__}")


def _channel_mask(channels: int) -> int:
    """Generate a default channel mask for the given number of channels.

    According to the WAVEFORMATEXTENSIBLE spec, if channels > 18,
    extra channels are not assigned to any physical speaker location.
    This returns a bitmask with the lowest `min(channels, 18)` bits set.
    """
    # Clamp to 0-18 to stay within the 18 non-reserved speaker position bits
    clamped = min(channels, 18)
    return (1 << clamped) - 1 if clamped > 0 else 0


_array_fmts = None, 'b', 'h', None, 'i'

wave_params = namedtuple('wave_params',
                    'nchannels sampwidth framerate nframes comptype compname format',
                    defaults=(WaveFormat.PCM,))
wave_params.__doc__ = """\
Parameters for a WAVE audio file.

This named tuple is returned by Wave_read.getparams() and Wave_write.getparams(),
and can be passed to Wave_write.setparams().

Attributes:
    nchannels: Number of audio channels (1 for mono, 2 for stereo).
    sampwidth: Sample width in bytes (1, 2, 3, or 4).
    framerate: Sampling frequency in Hz.
    nframes: Number of audio frames.
    comptype: Compression type ('NONE' is the only supported type).
    compname: Human-readable compression type name ('not compressed').
    format: Wave format type (WaveFormat.PCM or WaveFormat.IEEE_FLOAT).
"""
_wave_params = wave_params  # alias to keep compatibility


def _byteswap(data, width):
    swapped_data = bytearray(len(data))

    for i in range(0, len(data), width):
        for j in range(width):
            swapped_data[i + width - 1 - j] = data[i + j]

    try:
        return swapped_data.take_bytes()  # type: ignore[unresolved-attribute]
    except AttributeError:
        return bytes(swapped_data)


class _Chunk:
    def __init__(self, file, align=True, bigendian=True, inclheader=False):
        self.closed = False
        self.align = align      # whether to align to word (2-byte) boundaries
        if bigendian:
            strflag = '>'
        else:
            strflag = '<'
        self.file = file
        self.chunkname = file.read(4)
        if len(self.chunkname) < 4:
            raise EOFError
        try:
            self.chunksize = struct.unpack_from(strflag+'L', file.read(4))[0]
        except struct.error:
            raise EOFError from None
        if inclheader:
            self.chunksize = self.chunksize - 8 # subtract header
        self.size_read = 0
        try:
            self.offset = self.file.tell()
        except (AttributeError, OSError):
            self.seekable = False
        else:
            self.seekable = True

    def getname(self):
        """Return the name (ID) of the current chunk."""
        return self.chunkname

    def close(self):
        if not self.closed:
            try:
                self.skip()
            finally:
                self.closed = True

    def seek(self, pos, whence=0):
        """Seek to specified position into the chunk.
        Default position is 0 (start of chunk).
        If the file is not seekable, this will result in an error.
        """

        if self.closed:
            raise ValueError("I/O operation on closed file")
        if not self.seekable:
            raise OSError("cannot seek")
        if whence == 1:
            pos = pos + self.size_read
        elif whence == 2:
            pos = pos + self.chunksize
        if pos < 0 or pos > self.chunksize:
            raise RuntimeError
        self.file.seek(self.offset + pos, 0)
        self.size_read = pos

    def tell(self):
        if self.closed:
            raise ValueError("I/O operation on closed file")
        return self.size_read

    def read(self, size=-1):
        """Read at most size bytes from the chunk.
        If size is omitted or negative, read until the end
        of the chunk.
        """

        if self.closed:
            raise ValueError("I/O operation on closed file")
        if self.size_read >= self.chunksize:
            return b''
        if size < 0:
            size = self.chunksize - self.size_read
        if size > self.chunksize - self.size_read:
            size = self.chunksize - self.size_read
        data = self.file.read(size)
        self.size_read = self.size_read + len(data)
        if self.size_read == self.chunksize and \
           self.align and \
           (self.chunksize & 1):
            dummy = self.file.read(1)
            self.size_read = self.size_read + len(dummy)
        return data

    def skip(self):
        """Skip the rest of the chunk.
        If you are not interested in the contents of the chunk,
        this method should be called so that the file points to
        the start of the next chunk.
        """

        if self.closed:
            raise ValueError("I/O operation on closed file")
        if self.seekable:
            try:
                n = self.chunksize - self.size_read
                # maybe fix alignment
                if self.align and (self.chunksize & 1):
                    n = n + 1
                self.file.seek(n, 1)
                self.size_read = self.size_read + n
                return
            except OSError:
                pass
        while self.size_read < self.chunksize:
            n = min(8192, self.chunksize - self.size_read)
            dummy = self.read(n)
            if not dummy:
                raise EOFError


class Wave_read:
    """WAVE file reader.

    Use this class to read audio data from WAVE files. Supports standard
    PCM, IEEE float, and WAVEFORMATEXTENSIBLE formats.

    The recommended way to create a Wave_read instance is using wave.read()::

        import newwave as wave
        with wave.read('input.wav') as w:
            print(f"Format: {w.getformat().name}")
            print(f"Channels: {w.getnchannels()}")
            print(f"Sample rate: {w.getframerate()} Hz")
            print(f"Bit depth: {w.getsampwidth() * 8}-bit")
            data = w.readframes(w.getnframes())

    For stdlib compatibility, wave.open() also works::

        with wave.open('input.wav', 'rb') as w:
            data = w.readframes(w.getnframes())

    Methods:
        getnchannels() -> int
            Number of audio channels (1=mono, 2=stereo, etc.)

        getsampwidth() -> int
            Sample width in bytes (1=8-bit, 2=16-bit, 3=24-bit, 4=32-bit)

        getframerate() -> int
            Sample rate in Hz (e.g., 44100, 48000)

        getnframes() -> int
            Total number of audio frames in the file

        getformat() -> WaveFormat
            Format type (PCM, IEEE_FLOAT, or EXTENSIBLE)

        getcomptype() -> str
            Compression type (always 'NONE' for WAVE files)

        getcompname() -> str
            Compression name (always 'not compressed')

        getparams() -> wave_params
            Named tuple with all parameters

        readframes(n) -> bytes
            Read and return at most n frames of audio data

        rewind()
            Rewind to the beginning of the audio data

        setpos(pos)
            Seek to the specified frame position

        tell() -> int
            Return the current frame position

        close()
            Close the file (called automatically in context manager)
    """

    def initfp(self, file):
        self._convert = None
        self._soundpos = 0
        self._metadata = {}
        self._custom_chunks = {}
        self._file = _Chunk(file, bigendian = 0)
        if self._file.getname() != b'RIFF':
            raise Error('file does not start with RIFF id')
        if self._file.read(4) != b'WAVE':
            raise Error('not a WAVE file')
        self._fmt_chunk_read = 0
        self._data_chunk = None
        while 1:
            self._data_seek_needed = 1
            try:
                chunk = _Chunk(self._file, bigendian = 0)
            except EOFError:
                break
            chunkname = chunk.getname()
            if chunkname == b'fmt ':
                self._read_fmt_chunk(chunk)
                self._fmt_chunk_read = 1
            elif chunkname == b'data':
                if not self._fmt_chunk_read:
                    raise Error('data chunk before fmt chunk')
                self._data_chunk = chunk
                self._nframes = chunk.chunksize // self._framesize
                self._data_seek_needed = 0
                # For unseekable files, stop here - can't parse metadata after data
                if not self._file.seekable:
                    break
                # Otherwise continue parsing for metadata chunks after data
            elif chunkname == b'LIST':
                self._read_list_chunk(chunk)
            else:
                # Capture unknown chunks as custom chunks
                try:
                    chunk_data = chunk.read()
                    if len(chunk_data) > 0:
                        self._custom_chunks[chunkname] = chunk_data
                except (IOError, EOFError):
                    # If we can't read the chunk, skip it
                    pass
            chunk.skip()
        if not self._fmt_chunk_read or not self._data_chunk:
            raise Error('fmt chunk and/or data chunk missing')

    def __init__(self, f):
        self._i_opened_the_file = None
        if isinstance(f, (bytes, str, os.PathLike)):
            f = builtins.open(f, 'rb')
            self._i_opened_the_file = f
        # else, assume it is an open file object already
        try:
            self.initfp(f)
        except:
            if self._i_opened_the_file:
                f.close()
            raise

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    #
    # User visible methods.
    #
    def getfp(self):
        return self._file

    def rewind(self):
        self._data_seek_needed = 1
        self._soundpos = 0

    def close(self):
        self._file = None
        file = self._i_opened_the_file
        if file:
            self._i_opened_the_file = None
            file.close()

    def tell(self):
        return self._soundpos

    def getnchannels(self):
        return self._nchannels

    def getnframes(self):
        return self._nframes

    def getsampwidth(self):
        return self._sampwidth

    def getframerate(self):
        return self._framerate

    def getcomptype(self):
        return self._comptype

    def getcompname(self):
        return self._compname

    def getparams(self):
        return wave_params(self.getnchannels(), self.getsampwidth(),
                      self.getframerate(), self.getnframes(),
                      self.getcomptype(), self.getcompname(),
                      self.getformat())

    def getformat(self):
        return self._format

    def getmetadata(self):
        """Return all LIST INFO metadata as a dictionary.

        Returns a dictionary with keys like 'title', 'artist', 'album', etc.
        Supported tags: title, artist, album, tracknumber, date, genre,
        comment, copyright, software, engineer, technician, source, subject, keywords.
        """
        return self._metadata.copy()

    def gettag(self, tag):
        """Get a single metadata tag, or None if not present.

        Args:
            tag: MetadataTag enum value or string tag name
                 (e.g., MetadataTag.TITLE, 'title', 'artist').

        Raises:
            ValueError: If the tag is a string but not a known tag name.
        """
        return self._metadata.get(_normalize_tag(tag))

    def getchunk(self, chunk_id):
        """Get a custom RIFF chunk by ID, or None if not present.

        Args:
            chunk_id: 4-byte chunk identifier (bytes, e.g., b'APP0', b'PROC').

        Returns:
            The chunk data as bytes, or None if the chunk is not present.

        Note:
            Custom chunks are arbitrary data stored in RIFF containers and are
            separate from standard LIST INFO metadata. They can be used to store
            application-specific data, encoding parameters, or other metadata
            beyond the 13 standard WAVE tags.

        Example:
            with wave.read('file.wav') as w:
                if b'APP0' in w.getchunks():
                    data = w.getchunk(b'APP0')
        """
        return self._custom_chunks.get(chunk_id)

    def getchunks(self):
        """Get all custom RIFF chunks as a dictionary.

        Returns:
            Dictionary mapping chunk IDs (bytes) to chunk data (bytes).
            This includes all chunks except standard ones (fmt, data, LIST).

        Example:
            with wave.read('file.wav') as w:
                for chunk_id, data in w.getchunks().items():
                    print(f"Chunk {chunk_id}: {len(data)} bytes")
        """
        return self._custom_chunks.copy()

    def setpos(self, pos):
        if pos < 0 or pos > self._nframes:
            raise Error('position not in range')
        self._soundpos = pos
        self._data_seek_needed = 1

    def readframes(self, nframes):
        if self._data_seek_needed:
            self._data_chunk.seek(0, 0)
            pos = self._soundpos * self._framesize
            if pos:
                self._data_chunk.seek(pos, 0)
            self._data_seek_needed = 0
        if nframes == 0:
            return b''
        data = self._data_chunk.read(nframes * self._framesize)
        if self._sampwidth != 1 and sys.byteorder == 'big':
            data = _byteswap(data, self._sampwidth)
        if self._convert and data:
            data = self._convert(data)
        self._soundpos = self._soundpos + len(data) // (self._nchannels * self._sampwidth)
        return data

    #
    # Internal methods.
    #

    def _read_fmt_chunk(self, chunk):
        try:
            self._format, self._nchannels, self._framerate, dwAvgBytesPerSec, wBlockAlign = struct.unpack_from('<HHLLH', chunk.read(14))
        except struct.error:
            raise EOFError from None
        try:
            self._format = WaveFormat(self._format)
        except ValueError:
            raise Error('unknown format: %r' % (self._format,))
        try:
            sampwidth = struct.unpack_from('<H', chunk.read(2))[0]
        except struct.error:
            raise EOFError from None
        if self._format == WaveFormat.EXTENSIBLE:
            try:
                cbSize, wValidBitsPerSample, dwChannelMask = struct.unpack_from('<HHL', chunk.read(8))
                # Read the entire UUID from the chunk
                SubFormat = chunk.read(16)
                if len(SubFormat) < 16:
                    raise EOFError
            except struct.error:
                raise EOFError from None
            # Check subformat and set the effective format for data interpretation
            if SubFormat == KSDATAFORMAT_SUBTYPE_PCM:
                pass  # Keep format as EXTENSIBLE, data is PCM
            elif SubFormat == KSDATAFORMAT_SUBTYPE_IEEE_FLOAT:
                pass  # Keep format as EXTENSIBLE, data is IEEE float
            else:
                try:
                    import uuid
                    subformat_msg = f'unknown extended format: {uuid.UUID(bytes_le=SubFormat)}'
                except Exception:
                    subformat_msg = 'unknown extended format'
                raise Error(subformat_msg)
        self._sampwidth = (sampwidth + 7) // 8
        if not self._sampwidth:
            raise Error('bad sample width')
        if not self._nchannels:
            raise Error('bad # of channels')
        self._framesize = self._nchannels * self._sampwidth
        self._comptype = 'NONE'
        self._compname = 'not compressed'

    def _read_list_chunk(self, chunk):
        """Read a LIST chunk and extract INFO metadata if present."""
        list_type = chunk.read(4)
        if list_type != b'INFO':
            return  # Not an INFO list, skip

        # Parse INFO sub-chunks
        bytes_remaining = chunk.chunksize - 4  # Already read 'INFO'
        while bytes_remaining >= 8:
            sub_id = chunk.read(4)
            sub_size_data = chunk.read(4)
            if len(sub_size_data) < 4:
                break
            sub_size = struct.unpack('<I', sub_size_data)[0]
            bytes_remaining -= 8

            # Read the string data
            if sub_size > bytes_remaining:
                break
            data = chunk.read(sub_size)
            bytes_remaining -= sub_size

            # Handle padding (chunks are word-aligned)
            if sub_size % 2 == 1 and bytes_remaining > 0:
                chunk.read(1)
                bytes_remaining -= 1

            # Decode and store known tags
            if sub_id in _INFO_CHUNK_MAP:
                # Remove null terminator and decode
                text = data.rstrip(b'\x00')
                try:
                    text = text.decode('utf-8')
                except UnicodeDecodeError:
                    text = text.decode('latin-1')
                self._metadata[_INFO_CHUNK_MAP[sub_id]] = text

class Wave_write:
    """WAVE file writer.

    Use this class to write audio data to WAVE files. Supports standard
    PCM, IEEE float, and WAVEFORMATEXTENSIBLE formats.

    The recommended way to create a Wave_write instance is using wave.write()::

        import newwave as wave

        # Standard stereo file
        with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(audio_data)

        # IEEE float format
        with wave.write('float.wav', channels=2, sampwidth=4, framerate=48000,
                        format=wave.WaveFormat.IEEE_FLOAT) as w:
            w.writeframes(float_data)

        # 5.1 surround with explicit channel layout
        with wave.write('surround.wav', channels=6, sampwidth=3, framerate=48000,
                        channel_mask=wave.ChannelMask.SURROUND_5_1) as w:
            w.writeframes(surround_data)

        # Multi-channel data (no speaker assignment)
        with wave.write('sensors.wav', channels=8, sampwidth=3, framerate=10000,
                        channel_mask=0) as w:
            w.writeframes(sensor_data)

    For stdlib compatibility, wave.open() also works::

        with wave.open('output.wav', 'wb') as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(44100)
            w.writeframes(audio_data)

    Methods:
        setnchannels(n)
            Set number of channels before writing

        setsampwidth(n)
            Set sample width in bytes (1-4) before writing

        setframerate(n)
            Set sample rate in Hz before writing

        setformat(format)
            Set format type (WaveFormat.PCM, IEEE_FLOAT, or EXTENSIBLE)

        setchannelmask(mask)
            Set speaker position mask (enables EXTENSIBLE format)
            Use 0 for generic data channels without speaker assignment.

        writeframes(data)
            Write audio frames and update the file header

        writeframesraw(data)
            Write audio frames without updating header (for streaming)

        tell() -> int
            Return number of frames written so far

        close()
            Finalize header and close file (automatic in context manager)

    Automatic Format Selection:
        WAVEFORMATEXTENSIBLE is automatically used when:
        - channels > 2 (multi-channel audio)
        - sampwidth > 2 (more than 16 bits per sample)
        - channel_mask is explicitly set (including 0)
        - format=WaveFormat.EXTENSIBLE is specified
    """

    _file = None

    def __init__(self, f):
        self._i_opened_the_file = None
        if isinstance(f, (bytes, str, os.PathLike)):
            f = builtins.open(f, 'wb')
            self._i_opened_the_file = f
        try:
            self.initfp(f)
        except:
            if self._i_opened_the_file:
                f.close()
            raise

    def initfp(self, file):
        self._file = file
        self._convert = None
        self._nchannels = 0
        self._sampwidth = 0
        self._framerate = 0
        self._nframes = 0
        self._nframeswritten = 0
        self._datawritten = 0
        self._datalength = 0
        self._headerwritten = False
        self._format = WaveFormat.PCM
        self._format_set_explicitly = False
        self._channel_mask = None  # None means auto-generate from channel count
        self._fact_chunk_pos = None  # Position of sample count in fact chunk
        self._metadata = {}  # LIST INFO metadata tags
        self._custom_chunks = {}  # Custom RIFF chunks

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    #
    # User visible methods.
    #
    def setnchannels(self, nchannels):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if nchannels < 1:
            raise Error('bad # of channels')
        self._nchannels = nchannels

    def getnchannels(self):
        if not self._nchannels:
            raise Error('number of channels not set')
        return self._nchannels

    def setsampwidth(self, sampwidth):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if sampwidth < 1 or sampwidth > 4:
            raise Error('bad sample width')
        self._sampwidth = sampwidth

    def getsampwidth(self):
        if not self._sampwidth:
            raise Error('sample width not set')
        return self._sampwidth

    def setframerate(self, framerate):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        # Round before validating so that values like 0.5, which round to 0,
        # are properly rejected. (cpython GH-132445)
        framerate = int(round(framerate))
        if framerate <= 0:
            raise Error('bad frame rate')
        self._framerate = framerate

    def getframerate(self):
        if not self._framerate:
            raise Error('frame rate not set')
        return self._framerate

    def setnframes(self, nframes):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        self._nframes = nframes

    def getnframes(self):
        return self._nframeswritten

    def setcomptype(self, comptype, compname):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if comptype not in ('NONE',):
            raise Error('unsupported compression type')
        self._comptype = comptype
        self._compname = compname

    def getcomptype(self):
        return self._comptype

    def getcompname(self):
        return self._compname

    def setformat(self, format):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if format not in WaveFormat:
            raise Error('unsupported wave format')
        self._format = WaveFormat(format)
        self._format_set_explicitly = True

    def getformat(self):
        return self._format

    def setchannelmask(self, mask):
        """Set the channel mask for WAVEFORMATEXTENSIBLE output.

        The channel mask is a bitmask indicating which speaker positions
        are present. If not set, a default mask will be generated based
        on the number of channels.

        Use the ChannelMask IntFlag for predefined layouts:
            - ChannelMask.MONO: Front Center
            - ChannelMask.STEREO: Front Left + Front Right
            - ChannelMask.QUAD: FL + FR + BL + BR
            - ChannelMask.SURROUND_5_1: FL, FR, FC, LFE, BL, BR
            - ChannelMask.SURROUND_7_1: 5.1 + Side Left + Side Right

        Individual speaker positions can be combined with |:
            mask = ChannelMask.FRONT_LEFT | ChannelMask.FRONT_RIGHT
        """
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if self._format_set_explicitly and self._format != WaveFormat.EXTENSIBLE:
            raise Error('channel mask requires EXTENSIBLE format')
        self._channel_mask = mask

    def getchannelmask(self):
        """Get the channel mask, or None if not explicitly set."""
        return self._channel_mask

    def setparams(self, params):
        if self._datawritten:
            raise Error('cannot change parameters after starting to write')
        if len(params) == 6:
            nchannels, sampwidth, framerate, nframes, comptype, compname = params
            format = WaveFormat.PCM
        else:
            nchannels, sampwidth, framerate, nframes, comptype, compname, format = params
        self.setnchannels(nchannels)
        self.setsampwidth(sampwidth)
        self.setframerate(framerate)
        self.setnframes(nframes)
        self.setcomptype(comptype, compname)
        self.setformat(format)

    def getparams(self):
        if not self._nchannels or not self._sampwidth or not self._framerate:
            raise Error('not all parameters set')
        return wave_params(self._nchannels, self._sampwidth, self._framerate,
              self._nframes, self._comptype, self._compname, self._format)

    def setmetadata(self, metadata):
        """Set metadata tags to be written when the file is closed.

        Only standard WAVE metadata tags are supported. Attempting to use custom
        or non-standard tag names will raise ValueError. Use MetadataTag enum
        values or string names from the supported list: title, artist, album,
        tracknumber, date, genre, comment, copyright, software, engineer,
        technician, source, subject, keywords.

        For details, see the RIFF specification:
        https://www.adobe.io/content/dam/udp/assets/open/audio/riffnewmedia.pdf

        Args:
            metadata: Dictionary with keys that are either MetadataTag enum values
                     or string tag names from the supported list (case-insensitive).

        Example:
            w.setmetadata({
                'title': 'My Recording',
                'artist': 'The Artist',
                'date': '2026',
                'software': 'newwave',
            })

            # Or using enum values:
            w.setmetadata({
                MetadataTag.TITLE: 'My Recording',
                MetadataTag.ARTIST: 'The Artist',
            })

        Raises:
            ValueError: If any key is not a recognized standard tag name.
            TypeError: If any key is not a MetadataTag enum or string.
        """
        self._metadata = {_normalize_tag(k): v for k, v in metadata.items()}

    def settag(self, tag, value):
        """Set a single metadata tag.

        Only standard WAVE metadata tags are supported. Attempting to use custom
        or non-standard tag names will raise ValueError.

        For details on supported tags and the RIFF specification, see:
        https://www.adobe.io/content/dam/udp/assets/open/audio/riffnewmedia.pdf

        Args:
            tag: MetadataTag enum value or string tag name (case-insensitive).
                 Valid string names: title, artist, album, tracknumber, date,
                 genre, comment, copyright, software, engineer, technician,
                 source, subject, keywords.
            value: Tag value as a string.

        Raises:
            ValueError: If the tag is not a recognized standard tag name.
            TypeError: If the tag is neither a MetadataTag enum nor a string.

        Example:
            w.settag(MetadataTag.TITLE, 'My Song')  # Using enum
            w.settag('artist', 'The Artist')        # Using string
        """
        self._metadata[_normalize_tag(tag)] = value

    def getmetadata(self):
        """Return all metadata tags as a dictionary."""
        return self._metadata.copy()

    def gettag(self, tag):
        """Get a single metadata tag, or None if not set.

        Args:
            tag: MetadataTag enum value or string tag name.

        Raises:
            ValueError: If the tag is a string but not a known tag name.
        """
        return self._metadata.get(_normalize_tag(tag))

    def addchunk(self, chunk_id, data):
        """Add a custom RIFF chunk to be written to the file.

        Custom chunks can store arbitrary application-specific data in the
        WAVE file. They are written after the audio data and LIST INFO metadata.

        Args:
            chunk_id: 4-byte chunk identifier, e.g., b'APP0', b'PROC', b'junk'.
                     Must be exactly 4 bytes of ASCII-compatible characters.
            data: Chunk data as bytes.

        Raises:
            ValueError: If chunk_id is not exactly 4 bytes or if chunk size exceeds limits.
            TypeError: If chunk_id is not bytes.

        Note:
            - Chunk IDs should follow RIFF conventions (alphanumeric 4-byte IDs)
            - Custom chunks are written after audio data and metadata
            - Data will be automatically padded to word boundary in the file
            - The same chunk_id can be called multiple times; the latest data replaces previous

        Example:
            import json
            with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
                w.writeframes(audio_data)

                # Store application metadata as JSON
                app_data = {'encoder': 'my-app', 'version': '1.0'}
                w.addchunk(b'APP\x00', json.dumps(app_data).encode('utf-8'))

                # Store binary processing parameters
                w.addchunk(b'PROC', struct.pack('<ff', 0.5, 1.2))
        """
        if not isinstance(chunk_id, bytes):
            raise TypeError(f"chunk_id must be bytes, not {type(chunk_id).__name__}")
        if len(chunk_id) != 4:
            raise ValueError(f"chunk_id must be exactly 4 bytes, not {len(chunk_id)}")
        if self._datawritten and chunk_id in (b'fmt ', b'data'):
            raise ValueError("Cannot override standard chunks (fmt, data)")
        self._custom_chunks[chunk_id] = data

    def getchunk(self, chunk_id):
        """Get a custom chunk that was added, or None if not present.

        Args:
            chunk_id: 4-byte chunk identifier (bytes).

        Returns:
            The chunk data as bytes, or None if not found.

        Example:
            with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
                w.addchunk(b'APP0', b'custom data')
                if w.getchunk(b'APP0'):
                    print("APP0 chunk added")
        """
        return self._custom_chunks.get(chunk_id)

    def tell(self):
        return self._nframeswritten

    def writeframesraw(self, data):
        if not isinstance(data, (bytes, bytearray)):
            data = memoryview(data).cast('B')
        self._ensure_header_written(len(data))
        nframes = len(data) // (self._sampwidth * self._nchannels)
        if self._convert:
            data = self._convert(data)
        if self._sampwidth != 1 and sys.byteorder == 'big':
            data = _byteswap(data, self._sampwidth)
        self._file.write(data)
        self._datawritten += len(data)
        self._nframeswritten = self._nframeswritten + nframes

    def writeframes(self, data):
        self.writeframesraw(data)
        if self._datalength != self._datawritten:
            self._patchheader()

    def close(self):
        try:
            if self._file:
                self._ensure_header_written(0)
                # Write pad byte if data size is odd (RIFF requires word alignment)
                if self._datawritten & 1:
                    self._file.write(b'\x00')
                # Write metadata and custom chunks after data
                self._metadata_length = self._write_metadata_chunks()
                if self._datalength != self._datawritten or self._metadata_length:
                    self._patchheader()
                self._file.flush()
        finally:
            self._file = None
            file = self._i_opened_the_file
            if file:
                self._i_opened_the_file = None
                file.close()

    #
    # Internal methods.
    #

    def _ensure_header_written(self, datasize):
        if not self._headerwritten:
            if not self._nchannels:
                raise Error('# channels not specified')
            if not self._sampwidth:
                raise Error('sample width not specified')
            if not self._framerate:
                raise Error('sampling rate not specified')
            self._write_header(datasize)

    def _use_extensible(self):
        """Determine if WAVEFORMATEXTENSIBLE format should be used.

        WAVEFORMATEXTENSIBLE is required for:
        - More than 2 channels
        - More than 16 bits per sample
        - Explicitly requested via setformat(WaveFormat.EXTENSIBLE)
        - Channel mask explicitly set via setchannelmask()
        """
        if self._format == WaveFormat.EXTENSIBLE:
            return True
        if self._nchannels > 2:
            return True
        if self._sampwidth > 2:  # > 16 bits
            return True
        if self._channel_mask is not None:
            return True
        return False

    def _needs_fact_chunk(self):
        """Determine if a Fact chunk is required.

        Per the WAVE spec, non-PCM formats must have a Fact chunk.
        This includes IEEE_FLOAT and EXTENSIBLE with IEEE_FLOAT subformat.
        """
        return self._format == WaveFormat.IEEE_FLOAT

    def _build_info_chunk(self):
        """Build a LIST INFO chunk from metadata dictionary.

        Returns:
            Complete LIST INFO chunk as bytes, or empty bytes if no metadata.

        Raises:
            KeyError: If an unknown tag is found (indicates a bug in metadata validation).
        """
        if not self._metadata:
            return b''

        sub_chunks = b''

        for tag_name, value in self._metadata.items():
            tag_lower = tag_name.lower()
            if tag_lower not in _TAG_TO_INFO_CHUNK:
                raise KeyError(f"Unknown metadata tag: {tag_name!r}. This should have "
                             f"been caught during settag/setmetadata.")

            chunk_id = _TAG_TO_INFO_CHUNK[tag_lower]

            # Encode to bytes with null terminator
            encoded = str(value).encode('utf-8') + b'\x00'
            size = len(encoded)

            # Build sub-chunk
            sub_chunk = chunk_id + struct.pack('<I', size) + encoded

            # Add padding if needed (word alignment)
            if size % 2 == 1:
                sub_chunk += b'\x00'

            sub_chunks += sub_chunk

        if not sub_chunks:
            return b''

        # Build complete LIST chunk
        list_data = b'INFO' + sub_chunks
        list_chunk = b'LIST' + struct.pack('<I', len(list_data)) + list_data

        return list_chunk

    def _write_metadata_chunks(self):
        """Write LIST INFO metadata and custom chunks after the data chunk.

        Returns:
            Total bytes written (for RIFF header size calculation).
        """
        total_bytes = 0

        # Write LIST INFO metadata chunk
        info_chunk = self._build_info_chunk()
        if info_chunk:
            self._file.write(info_chunk)
            total_bytes += len(info_chunk)

        # Write custom chunks
        for chunk_id, data in self._custom_chunks.items():
            # Build chunk: ID + size + data + optional padding
            chunk_size = len(data)
            chunk = chunk_id + struct.pack('<I', chunk_size) + data

            # Add padding if chunk size is odd (word alignment)
            if chunk_size % 2 == 1:
                chunk += b'\x00'

            self._file.write(chunk)
            total_bytes += len(chunk)

        return total_bytes

    def _write_header(self, initlength):
        assert not self._headerwritten
        self._file.write(b'RIFF')
        if not self._nframes:
            self._nframes = initlength // (self._nchannels * self._sampwidth)
        self._datalength = self._nframes * self._nchannels * self._sampwidth
        try:
            self._form_length_pos = self._file.tell()
        except (AttributeError, OSError):
            self._form_length_pos = None

        if self._use_extensible():
            self._write_header_extensible()
        else:
            self._write_header_pcm()

        if self._form_length_pos is not None:
            self._data_length_pos = self._file.tell()
        self._file.write(struct.pack('<L', self._datalength))
        self._headerwritten = True

    def _write_header_pcm(self):
        """Write a standard PCMWAVEFORMAT header (16-byte fmt chunk)."""
        # Determine the format tag to write
        if self._format == WaveFormat.EXTENSIBLE:
            # If EXTENSIBLE was requested but we're writing PCM header,
            # use the underlying format (shouldn't happen, but be safe)
            fmt_tag = WaveFormat.PCM
        else:
            fmt_tag = self._format

        # Calculate header overhead
        # fmt chunk: 4 ("fmt ") + 4 (size) + 16 (data) = 24 bytes
        # fact chunk (if needed): 4 ("fact") + 4 (size) + 4 (samples) = 12 bytes
        # data header: 4 ("data") + 4 (size) = 8 bytes
        # RIFF size = 4 (WAVE) + fmt + fact (optional) + data header + datalength
        has_fact = self._needs_fact_chunk()
        header_overhead = 36 + (12 if has_fact else 0)

        self._file.write(struct.pack('<L4s4sLHHLLHH',
            header_overhead + self._datalength + (self._datalength & 1),
            b'WAVE', b'fmt ', 16,
            fmt_tag, self._nchannels, self._framerate,
            self._nchannels * self._framerate * self._sampwidth,
            self._nchannels * self._sampwidth,
            self._sampwidth * 8))

        # Write fact chunk for non-PCM formats
        if has_fact:
            self._file.write(b'fact')
            self._file.write(struct.pack('<L', 4))  # chunk size
            self._fact_chunk_pos = self._file.tell()
            self._file.write(struct.pack('<L', self._nframes))  # sample count

        self._file.write(b'data')

    def _write_header_extensible(self):
        """Write a WAVEFORMATEXTENSIBLE header (40-byte fmt chunk).

        The WAVEFORMATEXTENSIBLE structure contains:
        - WAVEFORMATEX (18 bytes): format tag, channels, sample rate, etc.
        - cbSize (2 bytes): size of extension = 22
        - wValidBitsPerSample (2 bytes): actual bits per sample
        - dwChannelMask (4 bytes): speaker position mask
        - SubFormat (16 bytes): GUID indicating PCM or IEEE_FLOAT
        """
        bits_per_sample = self._sampwidth * 8
        block_align = self._nchannels * self._sampwidth
        bytes_per_sec = self._framerate * block_align

        # Determine the subformat GUID based on the underlying format
        if self._format == WaveFormat.IEEE_FLOAT:
            subformat = KSDATAFORMAT_SUBTYPE_IEEE_FLOAT
        else:
            # PCM or EXTENSIBLE with PCM subformat
            subformat = KSDATAFORMAT_SUBTYPE_PCM

        # Get channel mask (auto-generate if not set)
        if self._channel_mask is not None:
            channel_mask = self._channel_mask
        else:
            channel_mask = _channel_mask(self._nchannels)

        # fmt chunk size for WAVEFORMATEXTENSIBLE = 40 bytes
        # fact chunk (if needed): 4 ("fact") + 4 (size) + 4 (samples) = 12 bytes
        # RIFF size = 4 (WAVE) + 8 (fmt header) + 40 (fmt data) + fact (optional) + 8 (data header) + datalength
        has_fact = self._needs_fact_chunk()
        header_overhead = 60 + (12 if has_fact else 0)
        riff_size = header_overhead + self._datalength + (self._datalength & 1)

        # Write RIFF header
        self._file.write(struct.pack('<L4s4sL',
            riff_size,
            b'WAVE', b'fmt ', 40))

        # Write WAVEFORMATEX portion
        self._file.write(struct.pack('<HHLLHH',
            WaveFormat.EXTENSIBLE,  # wFormatTag
            self._nchannels,         # nChannels
            self._framerate,         # nSamplesPerSec
            bytes_per_sec,           # nAvgBytesPerSec
            block_align,             # nBlockAlign
            bits_per_sample))        # wBitsPerSample (container size)

        # Write WAVEFORMATEXTENSIBLE extension
        self._file.write(struct.pack('<HHL',
            22,                      # cbSize (size of extension)
            bits_per_sample,         # wValidBitsPerSample (actual bits)
            channel_mask))           # dwChannelMask

        # Write SubFormat GUID
        self._file.write(subformat)

        # Write fact chunk for non-PCM formats (IEEE_FLOAT)
        if has_fact:
            self._file.write(b'fact')
            self._file.write(struct.pack('<L', 4))  # chunk size
            self._fact_chunk_pos = self._file.tell()
            self._file.write(struct.pack('<L', self._nframes))  # sample count

        # Write data chunk header
        self._file.write(b'data')

    def _patchheader(self):
        assert self._headerwritten
        if self._datawritten == self._datalength and not getattr(self, '_metadata_length', 0):
            return
        curpos = self._file.tell()
        self._file.seek(self._form_length_pos, 0)
        # RIFF size differs based on header type:
        # - Standard: 36 + data (4 WAVE + 24 fmt + 8 data header)
        # - Extensible: 60 + data (4 WAVE + 48 fmt + 8 data header)
        # - Add 12 bytes if fact chunk is present
        # - Add metadata chunk sizes if any
        if self._use_extensible():
            header_overhead = 60
        else:
            header_overhead = 36
        if self._needs_fact_chunk():
            header_overhead += 12
        # Include pad byte in RIFF size if data size is odd
        metadata_size = getattr(self, '_metadata_length', 0)
        riff_size = header_overhead + self._datawritten + (self._datawritten & 1) + metadata_size
        self._file.write(struct.pack('<L', riff_size))
        # Patch fact chunk sample count if present
        if self._fact_chunk_pos is not None:
            self._file.seek(self._fact_chunk_pos, 0)
            nframes = self._datawritten // (self._nchannels * self._sampwidth)
            self._file.write(struct.pack('<L', nframes))
        self._file.seek(self._data_length_pos, 0)
        self._file.write(struct.pack('<L', self._datawritten))
        self._file.seek(curpos, 0)
        self._datalength = self._datawritten


def open(f, mode=None):
    if mode is None:
        if hasattr(f, 'mode'):
            mode = f.mode
        else:
            mode = 'rb'
    if mode in ('r', 'rb'):
        return Wave_read(f)
    elif mode in ('w', 'wb'):
        return Wave_write(f)
    else:
        raise Error("mode must be 'r', 'rb', 'w', or 'wb'")


def read(f):
    """Open a WAVE file for reading.

    Args:
        f: Either a filename (str, bytes, or path-like) or an open file object.

    Returns:
        A Wave_read instance. Use as a context manager or call close() when done.

    Example:
        with wave.read('sound.wav') as w:
            data = w.readframes(w.getnframes())
    """
    return Wave_read(f)


def write(f, *, channels, sampwidth, framerate, format=WaveFormat.PCM, channel_mask=None):
    """Open a WAVE file for writing with pre-configured parameters.

    Args:
        f: Either a filename (str, bytes, or path-like) or an open file object.
        channels: Number of audio channels (1 for mono, 2 for stereo).
        sampwidth: Sample width in bytes (1, 2, 3, or 4).
        framerate: Sampling frequency in Hz.
        format: Wave format type (WaveFormat.PCM, WaveFormat.IEEE_FLOAT,
                or WaveFormat.EXTENSIBLE).
        channel_mask: Optional channel mask for WAVEFORMATEXTENSIBLE.
                     If None, a default mask is auto-generated.
                     Use ChannelMask IntFlag for predefined layouts:
                       - ChannelMask.MONO: Front Center
                       - ChannelMask.STEREO: Front Left + Front Right
                       - ChannelMask.SURROUND_5_1: 5.1 surround
                       - ChannelMask.SURROUND_7_1: 7.1 surround

    Returns:
        A Wave_write instance ready for writing frames.

    Note:
        WAVEFORMATEXTENSIBLE format is automatically used when:
        - channels > 2
        - sampwidth > 2 (> 16 bits per sample)
        - format=WaveFormat.EXTENSIBLE is explicitly set
        - channel_mask is explicitly set

    Example:
        with wave.write('output.wav', channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(audio_data)

        # 5.1 surround with explicit channel mask
        with wave.write('surround.wav', channels=6, sampwidth=3, framerate=48000,
                        channel_mask=0x3F) as w:
            w.writeframes(audio_data)
    """
    w = Wave_write(f)
    w.setnchannels(channels)
    w.setsampwidth(sampwidth)
    w.setframerate(framerate)
    if channel_mask is not None:
        w.setchannelmask(channel_mask)
    w.setformat(format)
    return w
