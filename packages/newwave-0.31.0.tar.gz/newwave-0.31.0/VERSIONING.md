# Versioning and Release Process

## Version Management

newwave uses **hatch-vcs** to manage version numbers dynamically from git tags. This ensures the version is always in sync with git history and eliminates the need to manually update version strings in multiple places.

### How It Works

1. **Version Source**: The version is read from git tags matching the pattern `v*.*.*` (e.g., `v0.3.0`)
2. **Build Hook**: During package build, hatch-vcs generates `src/_version.py` with the current version
3. **Local Builds**: When not in a git repository or on a commit without a tag, the package falls back to a development version

### Configuration

The `pyproject.toml` includes:

```toml
[project]
dynamic = ["version"]

[build-system]
requires = ["hatchling", "hatch-vcs"]

[tool.hatch.version]
source = "vcs"

[tool.hatch.build.hooks.vcs]
version-file = "src/_version.py"
```

## Release Process

### To Release a New Version:

1. **Update CHANGES.md** with the new version and release notes
2. **Commit the changes** to the repository
3. **Create a git tag** for the release:
   ```bash
   git tag -a v0.3.0 -m "Release 0.3.0: Custom RIFF chunks support"
   ```
4. **Push the tag** to the remote repository:
   ```bash
   git push origin v0.3.0
   ```
5. **Build and publish** (e.g., to PyPI):
   ```bash
   python -m build
   python -m twine upload dist/*
   ```

### Version Format

newwave uses **Semantic Versioning**:
- **MAJOR**: Incompatible API changes
- **MINOR**: New features (backwards compatible)
- **PATCH**: Bug fixes (backwards compatible)

Examples:
- `v0.1.0` - Initial release
- `v0.2.0` - Added LIST INFO metadata support
- `v0.3.0` - Added custom RIFF chunks support

## Development Version

When building from a commit that doesn't have a tag, hatch-vcs generates a development version like `0.3.0.dev5+g1234567`, indicating:
- Base version: 0.3.0
- Number of commits since last tag: 5
- Current commit hash: g1234567

This is useful for distinguishing development builds from official releases.

## Checking the Current Version

```bash
# From installed package
python -c "import newwave; print(newwave.__version__)"

# From git
git describe --tags

# From build output
python -m build --wheel
```

## References

- [hatch-vcs Documentation](https://pypi.org/project/hatch-vcs/)
- [Semantic Versioning](https://semver.org/)
- [PEP 440 - Version Identification](https://www.python.org/dev/peps/pep-0440/)
