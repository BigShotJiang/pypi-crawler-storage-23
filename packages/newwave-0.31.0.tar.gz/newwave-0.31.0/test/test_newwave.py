import unittest
from test import audiotests
from test import support
from test.support.os_helper import FakePath, TESTFN, unlink
import io
import os
import struct
import sys
import newwave as wave


class WaveTest(audiotests.AudioWriteTests,
               audiotests.AudioTestsWithSourceFile):
    module = wave


class WavePCM8Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm8.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 1
    framerate = 11025
    nframes = 48
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      827F CB80 B184 0088 4B86 C883 3F81 837E 387A 3473 A96B 9A66 \
      6D64 4662 8E60 6F60 D762 7B68 936F 5877 177B 757C 887B 5F7B \
      917A BE7B 3C7C E67F 4F84 C389 418E D192 6E97 0296 FF94 0092 \
      C98E D28D 6F8F 4E8F 648C E38A 888A AB8B D18E 0B91 368E C48A \
      """)


class WavePCM16Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm16.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 2
    framerate = 11025
    nframes = 48
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022EFFEA 4B5C00F9 311404EF 80DC0843 CBDF06B2 48AA03F3 BFE701B2 036BFE7C \
      B857FA3E B4B2F34F 2999EBCA 1A5FE6D7 EDFCE491 C626E279 0E05E0B8 EF27E02D \
      5754E275 FB31E843 1373EF89 D827F72C 978BFB7A F5F7FC11 0866FB9C DF30FB42 \
      117FFA36 3EE4FB5D BC75FCB6 66D5FF5F CF16040E 43220978 C1BC0EC8 511F12A4 \
      EEDF1755 82061666 7FFF1446 80001296 499C0EB2 52BA0DB9 EFB70F5C CE400FBC \
      E4B50CEB 63440A5A 08CA0A1F 2BBA0B0B 51460E47 8BCB113C B6F50EEA 44150A59 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 2)


class WavePCM24Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm24.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 3
    framerate = 11025
    nframes = 48
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65FFEB9D 4B5A0F00FA54 3113C304EE2B 80DCD6084303 \
      CBDEC006B261 48A99803F2F8 BFE82401B07D 036BFBFE7B5D \
      B85756FA3EC9 B4B055F3502B 299830EBCB62 1A5CA7E6D99A \
      EDFA3EE491BD C625EBE27884 0E05A9E0B6CF EF2929E02922 \
      5758D8E27067 FB3557E83E16 1377BFEF8402 D82C5BF7272A \
      978F16FB7745 F5F865FC1013 086635FB9C4E DF30FCFB40EE \
      117FE0FA3438 3EE6B8FB5AC3 BC77A3FCB2F4 66D6DAFF5F32 \
      CF13B9041275 431D69097A8C C1BB600EC74E 5120B912A2BA \
      EEDF641754C0 8207001664B7 7FFFFF14453F 8000001294E6 \
      499C1B0EB3B2 52B73E0DBCA0 EFB2B20F5FD8 CE3CDB0FBE12 \
      E4B49C0CEA2D 6344A80A5A7C 08C8FE0A1FFE 2BB9860B0A0E \
      51486F0E44E1 8BCC64113B05 B6F4EC0EEB36 4413170A5B48 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 3)


class WavePCM24ExtTest(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm24-ext.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 3
    framerate = 11025
    nframes = 48
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65FFEB9D 4B5A0F00FA54 3113C304EE2B 80DCD6084303 \
      CBDEC006B261 48A99803F2F8 BFE82401B07D 036BFBFE7B5D \
      B85756FA3EC9 B4B055F3502B 299830EBCB62 1A5CA7E6D99A \
      EDFA3EE491BD C625EBE27884 0E05A9E0B6CF EF2929E02922 \
      5758D8E27067 FB3557E83E16 1377BFEF8402 D82C5BF7272A \
      978F16FB7745 F5F865FC1013 086635FB9C4E DF30FCFB40EE \
      117FE0FA3438 3EE6B8FB5AC3 BC77A3FCB2F4 66D6DAFF5F32 \
      CF13B9041275 431D69097A8C C1BB600EC74E 5120B912A2BA \
      EEDF641754C0 8207001664B7 7FFFFF14453F 8000001294E6 \
      499C1B0EB3B2 52B73E0DBCA0 EFB2B20F5FD8 CE3CDB0FBE12 \
      E4B49C0CEA2D 6344A80A5A7C 08C8FE0A1FFE 2BB9860B0A0E \
      51486F0E44E1 8BCC64113B05 B6F4EC0EEB36 4413170A5B48 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 3)


class WavePCM32Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm32.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 4
    framerate = 11025
    nframes = 48
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65BCFFEB9D92 4B5A0F8000FA549C 3113C34004EE2BC0 80DCD680084303E0 \
      CBDEC0C006B26140 48A9980003F2F8FC BFE8248001B07D92 036BFB60FE7B5D34 \
      B8575600FA3EC920 B4B05500F3502BC0 29983000EBCB6240 1A5CA7A0E6D99A60 \
      EDFA3E80E491BD40 C625EB80E27884A0 0E05A9A0E0B6CFE0 EF292940E0292280 \
      5758D800E2706700 FB3557D8E83E1640 1377BF00EF840280 D82C5B80F7272A80 \
      978F1600FB774560 F5F86510FC101364 086635A0FB9C4E20 DF30FC40FB40EE28 \
      117FE0A0FA3438B0 3EE6B840FB5AC3F0 BC77A380FCB2F454 66D6DA80FF5F32B4 \
      CF13B980041275B0 431D6980097A8C00 C1BB60000EC74E00 5120B98012A2BAA0 \
      EEDF64C01754C060 820700001664B780 7FFFFFFF14453F40 800000001294E6E0 \
      499C1B000EB3B270 52B73E000DBCA020 EFB2B2E00F5FD880 CE3CDB400FBE1270 \
      E4B49CC00CEA2D90 6344A8800A5A7CA0 08C8FE800A1FFEE0 2BB986C00B0A0E00 \
      51486F800E44E190 8BCC6480113B0580 B6F4EC000EEB3630 441317800A5B48A0 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 4)


class WaveIeeeFloatingPointTest(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-float32.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 4
    framerate = 11025
    nframes = 48
    encoding = wave.WaveFormat.IEEE_FLOAT
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      60598B3C001423BA 1FB4163F8054FA3B 0E4FC43E80C51D3D 53467EBF4030843D \
      FC84D0BE304C563D 3053113F40BEFC3C B72F00BFC03E583C E0FEDA3C805142BC \
      54510FBFE02638BD 569F16BF40FDCABD C060A63EECA421BE 3CE5523E2C3349BE \
      0C2E10BE14725BBE 5268E7BEDC3B6CBE 985AE03D80497ABE B4B606BEECB67EBE \
      B0B12E3FC87C6CBE 005519BD4C0F3EBE F8BD1B3EECDF03BE 924E9FBE588D8DBD \
      D4E150BF501711BD B079A0BD20FBFBBC 5863863D40760CBD 0E3C83BE40E217BD \
      04FF0B3EF07839BD E29AFB3E80A714BD B91007BFE042D3BC B5AD4D3F80CDA0BB \
      1AB1C3BEB04E023D D33A063FC0A8973D 8012F9BEE074EC3D 7341223FD415153E \
      D80409BE04A63A3E 00F27BBFBC25333E 0000803FFC29223E 000080BF38A7143E \
      3638133F283BEB3D 7C6E253F00CADB3D 686A02BE88FDF53D 920CC7BE28E1FB3D \
      185B5ABED8A2CE3D 5189463FC8A7A53D E88F8C3DF0FFA13D 1CE6AE3EE0A0B03D \
      DF90223F184EE43D 376768BF2CD8093E 281612BF60B3EE3D 2F26083F88B4A53D \
      """)


class MiscTestCase(unittest.TestCase):
    def test__all__(self):
        not_exported = {'KSDATAFORMAT_SUBTYPE_PCM', 'KSDATAFORMAT_SUBTYPE_IEEE_FLOAT', '_wave_params'}
        support.check__all__(self, wave, not_exported=not_exported)

class WaveParamsTest(unittest.TestCase):
    """Tests for the public wave_params named tuple."""

    def tearDown(self):
        unlink(TESTFN)

    def test_wave_params_is_public(self):
        # wave_params should be importable from the module
        self.assertTrue(hasattr(wave, 'wave_params'))
        self.assertIn('wave_params', wave.__all__)

    def test_wave_params_alias(self):
        # _wave_params should be an alias for backward compatibility
        self.assertTrue(hasattr(wave, '_wave_params'))
        self.assertIs(wave._wave_params, wave.wave_params)

    def test_wave_params_creation(self):
        # wave_params should be a named tuple with the expected fields
        # Test with explicit format
        params = wave.wave_params(
            nchannels=2,
            sampwidth=2,
            framerate=44100,
            nframes=0,
            comptype='NONE',
            compname='not compressed',
            format=wave.WaveFormat.PCM
        )
        self.assertEqual(params.nchannels, 2)
        self.assertEqual(params.sampwidth, 2)
        self.assertEqual(params.framerate, 44100)
        self.assertEqual(params.nframes, 0)
        self.assertEqual(params.comptype, 'NONE')
        self.assertEqual(params.compname, 'not compressed')
        self.assertEqual(params.format, wave.WaveFormat.PCM)

        # Test positional construction without format (uses default)
        params2 = wave.wave_params(1, 2, 22050, 10, 'NONE', 'not compressed')
        self.assertEqual(params2.format, wave.WaveFormat.PCM)

    def test_getparams_returns_wave_params(self):
        # getparams() should return a wave_params instance
        with wave.open(TESTFN, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(22050)
            w.writeframes(b'\x00\x00' * 10)
        with wave.open(TESTFN, 'rb') as r:
            params = r.getparams()
            self.assertIsInstance(params, wave.wave_params)
            self.assertEqual(params.nchannels, 1)
            self.assertEqual(params.sampwidth, 2)
            self.assertEqual(params.framerate, 22050)
            self.assertEqual(params.nframes, 10)

    def test_setparams_accepts_wave_params(self):
        # setparams() should accept a wave_params instance
        params = wave.wave_params(
            nchannels=2,
            sampwidth=2,
            framerate=48000,
            nframes=0,
            comptype='NONE',
            compname='not compressed',
            format=wave.WaveFormat.PCM
        )
        with wave.open(TESTFN, 'wb') as w:
            w.setparams(params)
            w.writeframes(b'\x00\x00\x00\x00' * 5)
        with wave.open(TESTFN, 'rb') as r:
            result = r.getparams()
            self.assertEqual(result.nchannels, 2)
            self.assertEqual(result.sampwidth, 2)
            self.assertEqual(result.framerate, 48000)
            self.assertEqual(result.format, wave.WaveFormat.PCM)

    def test_setframerate_rejects_near_zero_float(self):
        # Regression test: framerate values that round to 0 must be rejected.
        # Previously, setframerate(0.5) would pass the <= 0 check (on the raw
        # float) but then store int(round(0.5)) == 0. (cpython GH-132445)
        with wave.open(TESTFN, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(1)
            with self.assertRaises(wave.Error):
                w.setframerate(0.5)
            with self.assertRaises(wave.Error):
                w.setframerate(0.4)
            # 0.51 rounds to 1, which is valid
            w.setframerate(0.51)
            self.assertEqual(w.getframerate(), 1)


class WavePadByteTest(unittest.TestCase):
    """Tests for pad byte handling with odd-sized data chunks (GH-117716)."""

    def test_write_odd_size_data_includes_pad_byte(self):
        # RIFF spec requires pad byte when data chunk size is odd
        # Test with 1 byte of 8-bit mono audio
        w = io.BytesIO()
        with wave.open(w, mode='wb') as ww:
            ww.setnchannels(1)
            ww.setsampwidth(1)
            ww.setframerate(48000)
            ww.writeframes(b'\x80')  # 1 byte - odd

        value = w.getvalue()
        # File should end with data byte + pad byte
        self.assertEqual(value[-2:], b'\x80\x00')
        # RIFF size should include pad byte (44 header + 1 data + 1 pad - 8 = 38)
        riff_size = int.from_bytes(value[4:8], 'little')
        self.assertEqual(riff_size, 38)

    def test_write_even_size_data_no_pad_byte(self):
        # Even-sized data should not have pad byte
        w = io.BytesIO()
        with wave.open(w, mode='wb') as ww:
            ww.setnchannels(1)
            ww.setsampwidth(2)
            ww.setframerate(48000)
            ww.writeframes(b'\x00\x00')  # 2 bytes - even

        value = w.getvalue()
        # File should end with just the data bytes
        self.assertEqual(value[-2:], b'\x00\x00')
        # RIFF size should be 44 header + 2 data - 8 = 38
        riff_size = int.from_bytes(value[4:8], 'little')
        self.assertEqual(riff_size, 38)

    def test_roundtrip_odd_size_data(self):
        # Write odd-sized data and read it back
        original_frames = b'\x80'
        w = io.BytesIO()
        with wave.open(w, mode='wb') as ww:
            ww.setnchannels(1)
            ww.setsampwidth(1)
            ww.setframerate(48000)
            ww.writeframes(original_frames)

        w.seek(0)
        with wave.open(w, mode='rb') as rw:
            read_frames = rw.readframes(-1)
            self.assertEqual(read_frames, original_frames)
            self.assertEqual(rw.getnframes(), 1)


class WaveLowLevelTest(unittest.TestCase):

    def test_read_no_chunks(self):
        b = b'SPAM'
        with self.assertRaises(EOFError):
            wave.open(io.BytesIO(b))

    def test_read_no_riff_chunk(self):
        b = b'SPAM' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error,
                                    'file does not start with RIFF id'):
            wave.open(io.BytesIO(b))

    def test_read_not_wave(self):
        b = b'RIFF' + struct.pack('<L', 4) + b'SPAM'
        with self.assertRaisesRegex(wave.Error,
                                    'not a WAVE file'):
            wave.open(io.BytesIO(b))

    def test_read_no_fmt_no_data_chunk(self):
        b = b'RIFF' + struct.pack('<L', 4) + b'WAVE'
        with self.assertRaisesRegex(wave.Error,
                                    'fmt chunk and/or data chunk missing'):
            wave.open(io.BytesIO(b))

    def test_read_no_data_chunk(self):
        b = b'RIFF' + struct.pack('<L', 28) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 1, 11025, 11025, 1, 8)
        with self.assertRaisesRegex(wave.Error,
                                    'fmt chunk and/or data chunk missing'):
            wave.open(io.BytesIO(b))

    def test_read_no_fmt_chunk(self):
        b = b'RIFF' + struct.pack('<L', 12) + b'WAVE'
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'data chunk before fmt chunk'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_form(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 2, 1, 11025, 11025, 1, 1)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'unknown format: 2'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_number_of_channels(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 0, 11025, 11025, 1, 8)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'bad # of channels'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_sample_width(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 1, 11025, 11025, 1, 0)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'bad sample width'):
            wave.open(io.BytesIO(b))

    def test_open_in_write_raises(self):
        # gh-136523: Wave_write.__del__ should not throw
        with support.catch_unraisable_exception() as cm:
            with self.assertRaises(OSError):
                wave.open(os.curdir, "wb")
            support.gc_collect()
            self.assertIsNone(cm.unraisable)


class WaveOpen(unittest.TestCase):
    def tearDown(self):
        unlink(TESTFN)

    def test_open_pathlike(self):
        """It is possible to use `wave.read` and `wave.write` with a path-like object"""
        cases = (
            FakePath(TESTFN),
            FakePath(os.fsencode(TESTFN)),
            os.fsencode(TESTFN),
            )
        for fake_path in cases:
            with self.subTest(fake_path):
                with wave.open(fake_path, 'wb') as f:
                    f.setnchannels(1)
                    f.setsampwidth(2)
                    f.setframerate(44100)

                with wave.open(fake_path, 'rb') as f:
                    pass


class WaveReadWriteFunctionsTest(unittest.TestCase):
    """Tests for the convenience read() and write() functions."""

    def tearDown(self):
        unlink(TESTFN)

    def test_read_returns_wave_read(self):
        # Create a test file first
        with wave.open(TESTFN, 'wb') as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(44100)
            w.writeframes(b'\x00\x00\x00\x00' * 10)

        # Test read() function
        with wave.read(TESTFN) as r:
            self.assertIsInstance(r, wave.Wave_read)
            self.assertEqual(r.getnchannels(), 2)
            self.assertEqual(r.getsampwidth(), 2)
            self.assertEqual(r.getframerate(), 44100)
            self.assertEqual(r.getnframes(), 10)

    def test_write_returns_configured_wave_write(self):
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=48000) as w:
            self.assertIsInstance(w, wave.Wave_write)
            self.assertEqual(w.getnchannels(), 2)
            self.assertEqual(w.getsampwidth(), 2)
            self.assertEqual(w.getframerate(), 48000)
            self.assertEqual(w.getformat(), wave.WaveFormat.PCM)
            w.writeframes(b'\x00\x00\x00\x00' * 5)

        # Verify the written file
        with wave.read(TESTFN) as r:
            self.assertEqual(r.getnchannels(), 2)
            self.assertEqual(r.getsampwidth(), 2)
            self.assertEqual(r.getframerate(), 48000)
            self.assertEqual(r.getnframes(), 5)

    def test_write_with_ieee_float_format(self):
        # Use sampwidth=2 to get simple WAVEFORMAT header (not EXTENSIBLE)
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050,
                       format=wave.WaveFormat.IEEE_FLOAT) as w:
            self.assertEqual(w.getformat(), wave.WaveFormat.IEEE_FLOAT)
            w.writeframes(b'\x00\x00' * 10)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.IEEE_FLOAT)

    def test_ieee_float_has_fact_chunk(self):
        """IEEE_FLOAT format files should include a Fact chunk per spec."""
        import struct
        nframes = 100
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050,
                       format=wave.WaveFormat.IEEE_FLOAT) as w:
            w.writeframes(b'\x00\x00' * nframes)

        # Examine the raw file to find the fact chunk
        with open(TESTFN, 'rb') as f:
            # Skip RIFF header
            f.read(12)  # 'RIFF' + size + 'WAVE'
            fact_found = False
            fact_samples = None
            while True:
                chunk_id = f.read(4)
                if len(chunk_id) < 4:
                    break
                chunk_size = struct.unpack('<L', f.read(4))[0]
                if chunk_id == b'fact':
                    fact_found = True
                    fact_samples = struct.unpack('<L', f.read(4))[0]
                    break
                f.seek(chunk_size + (chunk_size & 1), 1)  # skip + align

            self.assertTrue(fact_found, "Fact chunk not found in IEEE_FLOAT file")
            self.assertEqual(fact_samples, nframes)

    def test_pcm_no_fact_chunk(self):
        """PCM format files should NOT include a Fact chunk."""
        import struct
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            w.writeframes(b'\x00\x00' * 100)

        # Examine the raw file - should NOT have fact chunk
        with open(TESTFN, 'rb') as f:
            f.read(12)  # Skip RIFF header
            while True:
                chunk_id = f.read(4)
                if len(chunk_id) < 4:
                    break
                chunk_size = struct.unpack('<L', f.read(4))[0]
                self.assertNotEqual(chunk_id, b'fact', "PCM file should not have Fact chunk")
                f.seek(chunk_size + (chunk_size & 1), 1)

    def test_metadata_write_and_read(self):
        """Test writing and reading LIST INFO metadata."""
        metadata = {
            'title': 'Test Track',
            'artist': 'Test Artist',
            'album': 'Test Album',
            'date': '2026',
            'genre': 'Electronic',
            'comment': 'Created with newwave',
        }
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.setmetadata(metadata)
            w.writeframes(b'\x00\x00' * 100)

        with wave.read(TESTFN) as r:
            read_metadata = r.getmetadata()
            self.assertEqual(read_metadata['title'], 'Test Track')
            self.assertEqual(read_metadata['artist'], 'Test Artist')
            self.assertEqual(read_metadata['album'], 'Test Album')
            self.assertEqual(read_metadata['date'], '2026')
            self.assertEqual(read_metadata['genre'], 'Electronic')
            self.assertEqual(read_metadata['comment'], 'Created with newwave')

    def test_metadata_set_tag(self):
        """Test setting individual metadata tags."""
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            w.settag('title', 'My Song')
            w.settag('ARTIST', 'My Artist')  # Test case-insensitivity
            w.writeframes(b'\x00\x00' * 50)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.gettag('title'), 'My Song')
            self.assertEqual(r.gettag('artist'), 'My Artist')
            # Unknown tags raise ValueError
            with self.assertRaises(ValueError):
                r.gettag('nonexistent')

    def test_metadata_enum_tags(self):
        """Test using MetadataTag enum for metadata."""
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            # Use setmetadata with enum keys
            w.setmetadata({
                wave.MetadataTag.TITLE: 'Enum Title',
                wave.MetadataTag.ARTIST: 'Enum Artist',
                wave.MetadataTag.ALBUM: 'Enum Album',
            })
            # Add more with settag
            w.settag(wave.MetadataTag.DATE, '2026')
            w.writeframes(b'\x00\x00' * 50)

        with wave.read(TESTFN) as r:
            # Can read with enum
            self.assertEqual(r.gettag(wave.MetadataTag.TITLE), 'Enum Title')
            self.assertEqual(r.gettag(wave.MetadataTag.ARTIST), 'Enum Artist')
            # Can read with string
            self.assertEqual(r.gettag('album'), 'Enum Album')
            self.assertEqual(r.gettag('date'), '2026')
            # Metadata dict uses string keys
            metadata = r.getmetadata()
            self.assertEqual(metadata['title'], 'Enum Title')
            self.assertIn('title', metadata)
            self.assertNotIn(wave.MetadataTag.TITLE, metadata)

    def test_metadata_utf8(self):
        """Test UTF-8 encoded metadata."""
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            w.settag('artist', 'Björk')
            w.settag('comment', '日本語テスト')
            w.writeframes(b'\x00\x00' * 50)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.gettag('artist'), 'Björk')
            self.assertEqual(r.gettag('comment'), '日本語テスト')

    def test_no_metadata(self):
        """Test that files without metadata work correctly."""
        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            w.writeframes(b'\x00\x00' * 50)

        with wave.read(TESTFN) as r:
            metadata = r.getmetadata()
            self.assertEqual(metadata, {})
            self.assertIsNone(r.gettag('title'))

    def test_write_requires_keyword_args(self):
        # All parameters after file must be keyword-only
        with self.assertRaises(TypeError):
            wave.write(TESTFN, 2, 2, 44100)

    def test_read_and_write_roundtrip(self):
        # Write some audio data
        original_data = b'\x00\x01\x02\x03' * 100
        with wave.write(TESTFN, channels=1, sampwidth=1, framerate=8000) as w:
            w.writeframes(original_data)

        # Read it back
        with wave.read(TESTFN) as r:
            read_data = r.readframes(r.getnframes())
            self.assertEqual(read_data, original_data)


class WaveExtensibleWriteTest(unittest.TestCase):
    """Tests for WAVEFORMATEXTENSIBLE write support."""

    def tearDown(self):
        unlink(TESTFN)

    def test_auto_extensible_more_than_2_channels(self):
        # >2 channels should auto-upgrade to EXTENSIBLE
        original_data = b'\x00\x00' * 6 * 10  # 10 frames of 6-channel 16-bit
        with wave.write(TESTFN, channels=6, sampwidth=2, framerate=48000) as w:
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getnchannels(), 6)
            self.assertEqual(r.getsampwidth(), 2)
            self.assertEqual(r.getframerate(), 48000)
            self.assertEqual(r.getnframes(), 10)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_auto_extensible_more_than_16_bits(self):
        # >16 bits (sampwidth > 2) should auto-upgrade to EXTENSIBLE
        original_data = b'\x00\x00\x00' * 2 * 10  # 10 frames of stereo 24-bit
        with wave.write(TESTFN, channels=2, sampwidth=3, framerate=96000) as w:
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getnchannels(), 2)
            self.assertEqual(r.getsampwidth(), 3)
            self.assertEqual(r.getframerate(), 96000)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_explicit_extensible_format(self):
        # Explicit EXTENSIBLE request
        original_data = b'\x00\x00' * 2 * 10  # 10 frames of stereo 16-bit
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100,
                       format=wave.WaveFormat.EXTENSIBLE) as w:
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_extensible_with_ieee_float(self):
        # IEEE float with sampwidth > 2 uses EXTENSIBLE with IEEE_FLOAT subformat
        original_data = b'\x00\x00\x00\x00' * 2 * 10  # 10 frames of stereo 32-bit float
        with wave.write(TESTFN, channels=2, sampwidth=4, framerate=48000,
                       format=wave.WaveFormat.IEEE_FLOAT) as w:
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            # Format tag is EXTENSIBLE, but data is IEEE float
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getsampwidth(), 4)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_custom_channel_mask(self):
        # Test custom channel mask via write() function
        original_data = b'\x00\x00\x00' * 6 * 10  # 10 frames of 5.1 24-bit
        # 5.1 channel mask: FL, FR, FC, LFE, BL, BR = 0x3F
        with wave.write(TESTFN, channels=6, sampwidth=3, framerate=48000,
                       channel_mask=0x3F) as w:
            self.assertEqual(w.getchannelmask(), 0x3F)
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getnchannels(), 6)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_setchannelmask_method(self):
        # Test setchannelmask/getchannelmask methods on Wave_write
        with wave.open(TESTFN, 'wb') as w:
            w.setnchannels(4)
            w.setsampwidth(2)
            w.setframerate(44100)
            # Quad channel mask: FL, FR, BL, BR = 0x33
            w.setchannelmask(0x33)
            self.assertEqual(w.getchannelmask(), 0x33)
            w.writeframes(b'\x00\x00' * 4 * 10)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getnchannels(), 4)

    def test_32bit_pcm_roundtrip(self):
        # 32-bit PCM should use EXTENSIBLE and roundtrip correctly
        original_data = b'\x00\x01\x02\x03' * 2 * 50  # 50 frames of stereo 32-bit
        with wave.write(TESTFN, channels=2, sampwidth=4, framerate=44100) as w:
            w.writeframes(original_data)

        with wave.read(TESTFN) as r:
            self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
            self.assertEqual(r.getsampwidth(), 4)
            self.assertEqual(r.getnframes(), 50)
            self.assertEqual(r.readframes(r.getnframes()), original_data)

    def test_copy_extensible_file(self):
        # Copy an EXTENSIBLE file using getparams/setparams
        original_data = b'\x00\x00\x00' * 8 * 20  # 20 frames of 8-channel 24-bit

        # Write original
        with wave.write(TESTFN, channels=8, sampwidth=3, framerate=96000) as w:
            w.writeframes(original_data)

        # Copy it
        TESTFN2 = TESTFN + '.copy'
        try:
            with wave.read(TESTFN) as r:
                with wave.open(TESTFN2, 'wb') as w:
                    w.setparams(r.getparams())
                    w.writeframes(r.readframes(r.getnframes()))

            # Verify copy
            with wave.read(TESTFN2) as r:
                self.assertEqual(r.getformat(), wave.WaveFormat.EXTENSIBLE)
                self.assertEqual(r.getnchannels(), 8)
                self.assertEqual(r.getsampwidth(), 3)
                self.assertEqual(r.readframes(r.getnframes()), original_data)
        finally:
            unlink(TESTFN2)

    def test_custom_chunk_write_and_read(self):
        # Test writing and reading a custom chunk
        custom_data = b'Hello, World!'
        chunk_id = b'TEST'

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x01' * 100)
            w.addchunk(chunk_id, custom_data)

        with wave.read(TESTFN) as r:
            chunks = r.getchunks()
            self.assertIn(chunk_id, chunks)
            self.assertEqual(chunks[chunk_id], custom_data)

    def test_custom_chunk_getchunk_method(self):
        # Test getchunk method for retrieving individual chunks
        chunk_id = b'APP0'
        custom_data = b'Test application data'

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x01' * 100)
            w.addchunk(chunk_id, custom_data)

        with wave.read(TESTFN) as r:
            result = r.getchunk(chunk_id)
            self.assertEqual(result, custom_data)

            # Non-existent chunk returns None
            self.assertIsNone(r.getchunk(b'NOPE'))

    def test_multiple_custom_chunks(self):
        # Test writing and reading multiple custom chunks
        chunks_to_write = {
            b'CHK1': b'First chunk',
            b'CHK2': b'\x00\x01\x02\x03',
            b'CHK3': b'Third chunk with more data' * 10,
        }

        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=22050) as w:
            w.writeframes(b'\x00\x00' * 50)
            for chunk_id, data in chunks_to_write.items():
                w.addchunk(chunk_id, data)

        with wave.read(TESTFN) as r:
            chunks = r.getchunks()
            for chunk_id, expected_data in chunks_to_write.items():
                self.assertIn(chunk_id, chunks)
                self.assertEqual(chunks[chunk_id], expected_data)

    def test_custom_chunk_odd_size_padding(self):
        # Test that odd-sized chunks are padded correctly (word alignment)
        chunk_id = b'ODD '
        custom_data = b'1'  # 1 byte - odd size

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            w.addchunk(chunk_id, custom_data)

        with wave.read(TESTFN) as r:
            # Should read back the original data (padding is handled internally)
            result = r.getchunk(chunk_id)
            self.assertEqual(result, custom_data)

    def test_custom_chunk_id_validation_length(self):
        # Chunk IDs must be exactly 4 bytes
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)

            # Too short
            with self.assertRaises(ValueError):
                w.addchunk(b'AB', b'data')

            # Too long
            with self.assertRaises(ValueError):
                w.addchunk(b'ABCDE', b'data')

    def test_custom_chunk_id_validation_type(self):
        # Chunk IDs must be bytes
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)

            # String instead of bytes
            with self.assertRaises(TypeError):
                w.addchunk('TEST', b'data')

            # Integer instead of bytes
            with self.assertRaises(TypeError):
                w.addchunk(1234, b'data')

    def test_custom_chunks_with_metadata(self):
        # Test custom chunks alongside standard metadata
        custom_chunk = b'CUST'
        custom_data = b'Custom chunk data'

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x01' * 100)

            # Add standard metadata
            w.settag('title', 'Test Title')
            w.settag('artist', 'Test Artist')

            # Add custom chunk
            w.addchunk(custom_chunk, custom_data)

        with wave.read(TESTFN) as r:
            # Verify metadata
            self.assertEqual(r.gettag('title'), 'Test Title')
            self.assertEqual(r.gettag('artist'), 'Test Artist')

            # Verify custom chunk
            self.assertEqual(r.getchunk(custom_chunk), custom_data)

    def test_custom_chunks_roundtrip(self):
        # Test that custom chunks survive a read-modify-write cycle
        original_chunk = b'ORIG'
        original_data = b'Original data here'

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            w.addchunk(original_chunk, original_data)

        # Read and copy to new file
        TESTFN2 = TESTFN + '.copy'
        try:
            with wave.read(TESTFN) as r:
                audio = r.readframes(r.getnframes())
                params = r.getparams()
                custom_chunks = r.getchunks()

            with wave.write(TESTFN2, channels=params.nchannels,
                           sampwidth=params.sampwidth,
                           framerate=params.framerate) as w:
                w.writeframes(audio)
                for chunk_id, data in custom_chunks.items():
                    w.addchunk(chunk_id, data)
                # Add new chunk
                w.addchunk(b'NEW ', b'New data in copy')

            # Verify both chunks in copy
            with wave.read(TESTFN2) as r:
                chunks = r.getchunks()
                self.assertEqual(chunks[original_chunk], original_data)
                self.assertEqual(chunks[b'NEW '], b'New data in copy')
        finally:
            unlink(TESTFN2)

    def test_custom_chunk_binary_data(self):
        # Test storing and retrieving binary data in custom chunks
        chunk_id = b'BIN '
        # Binary data with various byte values
        binary_data = bytes(range(256))

        with wave.write(TESTFN, channels=1, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            w.addchunk(chunk_id, binary_data)

        with wave.read(TESTFN) as r:
            result = r.getchunk(chunk_id)
            self.assertEqual(result, binary_data)
            self.assertEqual(len(result), 256)

    def test_custom_chunk_struct_data(self):
        # Test storing structured data (e.g., floats) in custom chunks
        chunk_id = b'STRU'
        # Pack some float data
        struct_data = struct.pack('<ff', 0.5, 1.5)

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            w.addchunk(chunk_id, struct_data)

        with wave.read(TESTFN) as r:
            result = r.getchunk(chunk_id)
            unpacked = struct.unpack('<ff', result)
            self.assertAlmostEqual(unpacked[0], 0.5)
            self.assertAlmostEqual(unpacked[1], 1.5)

    def test_empty_custom_chunks_dict(self):
        # Test that files without custom chunks have empty dict from getchunks()
        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            # Don't add any custom chunks

        with wave.read(TESTFN) as r:
            chunks = r.getchunks()
            self.assertEqual(chunks, {})
            self.assertIsNone(r.getchunk(b'NONE'))

    def test_getchunk_returns_none_for_missing(self):
        # Verify getchunk returns None for chunks that don't exist
        chunk_id = b'REAL'

        with wave.write(TESTFN, channels=2, sampwidth=2, framerate=44100) as w:
            w.writeframes(b'\x00\x00' * 100)
            w.addchunk(chunk_id, b'Real data')

        with wave.read(TESTFN) as r:
            # Existing chunk
            self.assertIsNotNone(r.getchunk(chunk_id))

            # Non-existing chunks
            self.assertIsNone(r.getchunk(b'FAKE'))
            self.assertIsNone(r.getchunk(b'NONE'))


if __name__ == '__main__':
    unittest.main()
