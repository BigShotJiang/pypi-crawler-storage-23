import pytest
import time
from unittest.mock import Mock, MagicMock

import numpy as np

from rl_llm_toolkit.distributed.parallel_rollout import ParallelRolloutManager, RolloutResult
from rl_llm_toolkit.distributed.worker_pool import WorkerPool, WorkerConfig, Task, TaskResult


class TestParallelRolloutManager:
    def test_manager_start_stop(self):
        manager = ParallelRolloutManager(num_workers=2)
        
        assert not manager._active
        
        manager.start()
        assert manager._active
        assert manager._pool is not None
        
        manager.stop()
        assert not manager._active
    
    def test_context_manager(self):
        with ParallelRolloutManager(num_workers=2) as manager:
            assert manager._active
        
        assert not manager._active
    
    def test_collect_rollouts(self):
        def create_env():
            env = Mock()
            env.reset = Mock(return_value=(np.array([0.0]), {}))
            env.step = Mock(return_value=(
                np.array([0.0]),
                1.0,
                True,
                False,
                {}
            ))
            env.close = Mock()
            return env
        
        def create_agent():
            agent = Mock()
            agent.predict = Mock(return_value=(0, None))
            return agent
        
        with ParallelRolloutManager(num_workers=2) as manager:
            results = manager.collect_rollouts(
                env_fn=create_env,
                agent_fn=create_agent,
                num_episodes=4,
            )
        
        assert len(results) == 4
        assert all(isinstance(r, RolloutResult) for r in results)


class TestWorkerPool:
    def test_pool_start_stop(self):
        config = WorkerConfig(num_workers=2)
        pool = WorkerPool(config)
        
        assert not pool._active
        
        pool.start()
        assert pool._active
        assert len(pool._workers) == 2
        
        pool.stop()
        assert not pool._active
    
    def test_context_manager(self):
        config = WorkerConfig(num_workers=2)
        
        with WorkerPool(config) as pool:
            assert pool._active
        
        assert not pool._active
    
    def test_submit_and_get_result(self):
        def simple_task(x):
            return x * 2
        
        with WorkerPool(WorkerConfig(num_workers=2)) as pool:
            task_id = pool.submit(simple_task, 5)
            
            result = pool.get_result(timeout=5.0)
            
            assert result is not None
            assert result.success
            assert result.result == 10
    
    def test_map_function(self):
        def square(x):
            return x ** 2
        
        items = [1, 2, 3, 4, 5]
        
        with WorkerPool(WorkerConfig(num_workers=2)) as pool:
            results = pool.map(square, items, timeout=10.0)
        
        assert results == [1, 4, 9, 16, 25]
    
    def test_error_handling(self):
        def failing_task():
            raise ValueError("Test error")
        
        with WorkerPool(WorkerConfig(num_workers=2)) as pool:
            pool.submit(failing_task)
            
            result = pool.get_result(timeout=5.0)
            
            assert result is not None
            assert not result.success
            assert "Test error" in result.error
    
    def test_get_stats(self):
        def simple_task(x):
            return x
        
        with WorkerPool(WorkerConfig(num_workers=2)) as pool:
            pool.submit(simple_task, 1)
            pool.submit(simple_task, 2)
            
            pool.get_result(timeout=5.0)
            pool.get_result(timeout=5.0)
            
            stats = pool.get_stats()
            
            assert stats['active']
            assert stats['num_workers'] == 2
            assert stats['tasks_submitted'] == 2
            assert stats['tasks_completed'] == 2
    
    def test_multiple_tasks(self):
        def add(a, b):
            return a + b
        
        with WorkerPool(WorkerConfig(num_workers=2)) as pool:
            pool.submit(add, 1, 2)
            pool.submit(add, 3, 4)
            pool.submit(add, 5, 6)
            
            results = pool.get_all_results(timeout=10.0)
            
            assert len(results) == 3
            assert all(r.success for r in results)
            assert sum(r.result for r in results) == 21


class TestTask:
    def test_task_creation(self):
        def dummy_func():
            pass
        
        task = Task(
            task_id="test_1",
            func=dummy_func,
            args=(1, 2),
            kwargs={'key': 'value'},
            priority=5,
        )
        
        assert task.task_id == "test_1"
        assert task.func == dummy_func
        assert task.args == (1, 2)
        assert task.kwargs == {'key': 'value'}
        assert task.priority == 5


class TestTaskResult:
    def test_result_creation(self):
        result = TaskResult(
            task_id="test_1",
            success=True,
            result=42,
            error=None,
            worker_id=0,
            execution_time=1.5,
        )
        
        assert result.task_id == "test_1"
        assert result.success
        assert result.result == 42
        assert result.error is None
        assert result.worker_id == 0
        assert result.execution_time == 1.5
