import pytest
import tempfile
from pathlib import Path

from rl_llm_toolkit.core.reproducibility import ReproducibilityManager, ReproducibilityMetadata


class TestReproducibilityManager:
    def test_get_git_commit_hash(self):
        commit_hash = ReproducibilityManager.get_git_commit_hash()
        assert isinstance(commit_hash, str)
        assert len(commit_hash) > 0
    
    def test_get_package_version(self):
        version = ReproducibilityManager.get_package_version()
        assert isinstance(version, str)
        assert len(version) > 0
    
    def test_get_python_version(self):
        version = ReproducibilityManager.get_python_version()
        assert isinstance(version, str)
        parts = version.split('.')
        assert len(parts) >= 2
    
    def test_get_platform_info(self):
        platform_info = ReproducibilityManager.get_platform_info()
        assert isinstance(platform_info, str)
        assert len(platform_info) > 0
    
    def test_compute_config_hash(self):
        config1 = {"key": "value", "number": 42}
        config2 = {"number": 42, "key": "value"}
        config3 = {"key": "different", "number": 42}
        
        hash1 = ReproducibilityManager.compute_config_hash(config1)
        hash2 = ReproducibilityManager.compute_config_hash(config2)
        hash3 = ReproducibilityManager.compute_config_hash(config3)
        
        assert hash1 == hash2
        assert hash1 != hash3
    
    def test_compute_template_hash(self):
        template1 = "This is a template"
        template2 = "This is a template"
        template3 = "Different template"
        
        hash1 = ReproducibilityManager.compute_template_hash(template1)
        hash2 = ReproducibilityManager.compute_template_hash(template2)
        hash3 = ReproducibilityManager.compute_template_hash(template3)
        
        assert hash1 == hash2
        assert hash1 != hash3
        
        assert ReproducibilityManager.compute_template_hash(None) is None
    
    def test_create_metadata(self):
        config = {"env": "CartPole-v1", "algorithm": "ppo"}
        
        metadata = ReproducibilityManager.create_metadata(
            seed=42,
            config=config,
            llm_backend="openai",
            llm_model="gpt-4",
            reward_template="Test template",
        )
        
        assert metadata.seed == 42
        assert metadata.llm_backend == "openai"
        assert metadata.llm_model == "gpt-4"
        assert metadata.config_hash is not None
        assert metadata.reward_template_hash is not None
        assert metadata.resolved_config == config
    
    def test_save_and_load_metadata(self):
        config = {"env": "CartPole-v1"}
        
        metadata = ReproducibilityManager.create_metadata(
            seed=42,
            config=config,
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "metadata.yaml"
            metadata.save(path)
            
            assert path.exists()
            
            loaded_metadata = ReproducibilityMetadata.load(path)
            
            assert loaded_metadata.seed == metadata.seed
            assert loaded_metadata.commit_hash == metadata.commit_hash
            assert loaded_metadata.package_version == metadata.package_version


class TestReproducibilityMetadata:
    def test_to_dict(self):
        metadata = ReproducibilityMetadata(
            seed=42,
            commit_hash="abc123",
            package_version="0.2.0",
            python_version="3.11.0",
            platform_info="Linux",
            torch_version="2.0.0",
            numpy_version="1.24.0",
            gymnasium_version="0.29.0",
            llm_backend="openai",
            llm_model="gpt-4",
            reward_template_hash="hash123",
            config_hash="confighash",
            resolved_config={"key": "value"},
            timestamp="2024-01-01T00:00:00",
            hostname="test-host",
            cuda_available=False,
            cuda_version=None,
        )
        
        data = metadata.to_dict()
        
        assert data['seed'] == 42
        assert data['commit_hash'] == "abc123"
        assert data['llm_backend'] == "openai"
        assert data['resolved_config'] == {"key": "value"}
