import pytest
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

import numpy as np

from rl_llm_toolkit.tracking.tracker import MetricsTracker, TrackingBackend, MetricRecord
from rl_llm_toolkit.tracking.backends import (
    TensorBoardBackend,
    CSVBackend,
    JSONBackend,
)


class MockBackend(TrackingBackend):
    def __init__(self):
        self.scalars = []
        self.histograms = []
        self.texts = []
        self.config = None
        self.closed = False
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.scalars.append((name, value, step))
    
    def log_scalars(self, metrics: dict, step: int) -> None:
        for name, value in metrics.items():
            self.scalars.append((name, value, step))
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.histograms.append((name, values, step))
    
    def log_text(self, name: str, text: str, step: int) -> None:
        self.texts.append((name, text, step))
    
    def log_config(self, config: dict) -> None:
        self.config = config
    
    def close(self) -> None:
        self.closed = True


class TestMetricsTracker:
    def test_tracker_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker(
                experiment_name="test",
                output_dir=Path(tmpdir),
            )
            
            assert tracker.experiment_name == "test"
            assert tracker.output_dir == Path(tmpdir)
    
    def test_add_backend(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker("test", Path(tmpdir))
            backend = MockBackend()
            
            tracker.add_backend(backend)
            
            assert backend in tracker.backends
    
    def test_log_scalar(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = MockBackend()
            tracker = MetricsTracker("test", Path(tmpdir), backends=[backend])
            
            tracker.log_scalar("loss", 0.5, step=1)
            
            assert len(backend.scalars) == 1
            assert backend.scalars[0] == ("loss", 0.5, 1)
    
    def test_log_scalars(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = MockBackend()
            tracker = MetricsTracker("test", Path(tmpdir), backends=[backend])
            
            tracker.log_scalars({"loss": 0.5, "reward": 10.0}, step=1)
            
            assert len(backend.scalars) == 2
            assert len(tracker.records) == 1
    
    def test_log_episode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = MockBackend()
            tracker = MetricsTracker("test", Path(tmpdir), backends=[backend])
            
            tracker.log_episode(1, {"reward": 100.0, "length": 50})
            
            assert len(backend.scalars) == 2
    
    def test_log_llm_metrics(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = MockBackend()
            tracker = MetricsTracker("test", Path(tmpdir), backends=[backend])
            
            tracker.log_llm_metrics(
                step=1,
                latency_ms=100.0,
                tokens_used=500,
                cache_hit=True,
                estimated_cost=0.01,
            )
            
            assert len(backend.scalars) == 4
    
    def test_get_summary(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker("test", Path(tmpdir))
            
            tracker.log_scalar("loss", 0.5, 1)
            tracker.log_scalar("loss", 0.4, 2)
            tracker.log_scalar("loss", 0.3, 3)
            
            summary = tracker.get_summary()
            
            assert "step_metrics" in summary
            assert "loss" in summary["step_metrics"]
            assert summary["step_metrics"]["loss"]["mean"] == pytest.approx(0.4, 0.01)
    
    def test_save_summary(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker("test", Path(tmpdir))
            tracker.log_scalar("loss", 0.5, 1)
            
            summary_path = Path(tmpdir) / "summary.json"
            tracker.save_summary(summary_path)
            
            assert summary_path.exists()
    
    def test_export_records_json(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker("test", Path(tmpdir))
            tracker.log_scalars({"loss": 0.5}, 1)
            
            tracker.export_records('json')
            
            json_path = Path(tmpdir) / "test_records.json"
            assert json_path.exists()
    
    def test_export_records_csv(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = MetricsTracker("test", Path(tmpdir))
            tracker.log_scalars({"loss": 0.5}, 1)
            
            tracker.export_records('csv')
            
            csv_path = Path(tmpdir) / "test_records.csv"
            assert csv_path.exists()
    
    def test_close(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = MockBackend()
            tracker = MetricsTracker("test", Path(tmpdir), backends=[backend])
            
            tracker.close()
            
            assert backend.closed


class TestCSVBackend:
    def test_csv_backend_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.csv"
            backend = CSVBackend(output_path)
            
            assert backend.output_path == output_path
    
    def test_csv_log_scalar(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.csv"
            backend = CSVBackend(output_path)
            
            backend.log_scalar("loss", 0.5, 1)
            backend.close()
            
            assert output_path.exists()
    
    def test_csv_log_scalars(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.csv"
            backend = CSVBackend(output_path)
            
            backend.log_scalars({"loss": 0.5, "reward": 10.0}, 1)
            backend.close()
            
            assert output_path.exists()


class TestJSONBackend:
    def test_json_backend_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.json"
            backend = JSONBackend(output_path)
            
            assert backend.output_path == output_path
    
    def test_json_log_scalar(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.json"
            backend = JSONBackend(output_path)
            
            backend.log_scalar("loss", 0.5, 1)
            backend.close()
            
            assert output_path.exists()
    
    def test_json_log_config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "metrics.json"
            backend = JSONBackend(output_path)
            
            backend.log_config({"key": "value"})
            backend.close()
            
            import json
            with open(output_path) as f:
                data = json.load(f)
            
            assert data['config'] == {"key": "value"}


class TestTensorBoardBackend:
    @patch('rl_llm_toolkit.tracking.backends.SummaryWriter')
    def test_tensorboard_backend_creation(self, mock_writer):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = TensorBoardBackend(Path(tmpdir))
            
            mock_writer.assert_called_once()
    
    @patch('rl_llm_toolkit.tracking.backends.SummaryWriter')
    def test_tensorboard_log_scalar(self, mock_writer):
        with tempfile.TemporaryDirectory() as tmpdir:
            backend = TensorBoardBackend(Path(tmpdir))
            
            backend.log_scalar("loss", 0.5, 1)
            
            backend.writer.add_scalar.assert_called_once_with("loss", 0.5, 1)


class TestMetricRecord:
    def test_metric_record_creation(self):
        record = MetricRecord(
            step=1,
            timestamp="2024-01-01T00:00:00",
            metrics={"loss": 0.5}
        )
        
        assert record.step == 1
        assert record.metrics["loss"] == 0.5
    
    def test_metric_record_to_dict(self):
        record = MetricRecord(
            step=1,
            timestamp="2024-01-01T00:00:00",
            metrics={"loss": 0.5}
        )
        
        data = record.to_dict()
        
        assert data['step'] == 1
        assert data['metrics']['loss'] == 0.5
