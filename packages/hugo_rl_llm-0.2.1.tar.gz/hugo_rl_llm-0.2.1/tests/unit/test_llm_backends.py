"""
Unit tests for LLM Backends.
Tests OpenAI, Ollama, and Anthropic backends with mocked API calls.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import json


class TestOpenAIBackend:
    """Comprehensive tests for OpenAI backend."""

    @pytest.fixture
    def mock_openai_client(self):
        """Create mock OpenAI client."""
        client = Mock()
        response = Mock()
        response.choices = [Mock()]
        response.choices[0].message.content = "This is a good action"
        client.chat.completions.create = Mock(return_value=response)
        return client

    @pytest.fixture
    def openai_backend(self, mock_openai_client):
        """Create OpenAI backend with mocked client."""
        with patch('openai.OpenAI', return_value=mock_openai_client):
            from rl_llm_toolkit.llm.openai import OpenAIBackend
            return OpenAIBackend(api_key="test_key", model="gpt-4")

    def test_initialization(self, openai_backend):
        """Test OpenAI backend initialization."""
        assert openai_backend is not None
        assert openai_backend.model == "gpt-4"

    def test_generate_response(self, openai_backend, mock_openai_client):
        """Test generating response."""
        prompt = "Evaluate this action"
        response = openai_backend.generate(prompt)
        
        assert response is not None
        assert isinstance(response, str)
        mock_openai_client.chat.completions.create.assert_called_once()

    def test_generate_with_system_message(self, openai_backend, mock_openai_client):
        """Test generating with system message."""
        prompt = "Evaluate this action"
        system_message = "You are a helpful RL assistant"
        
        response = openai_backend.generate(
            prompt,
            system_message=system_message
        )
        
        assert response is not None

    def test_generate_with_temperature(self, openai_backend, mock_openai_client):
        """Test generating with custom temperature."""
        prompt = "Evaluate this action"
        
        response = openai_backend.generate(prompt, temperature=0.7)
        
        assert response is not None
        call_args = mock_openai_client.chat.completions.create.call_args
        assert call_args[1]['temperature'] == 0.7

    def test_generate_with_max_tokens(self, openai_backend, mock_openai_client):
        """Test generating with max tokens."""
        prompt = "Evaluate this action"
        
        response = openai_backend.generate(prompt, max_tokens=100)
        
        assert response is not None

    def test_api_error_handling(self, openai_backend, mock_openai_client):
        """Test API error handling."""
        mock_openai_client.chat.completions.create.side_effect = Exception("API Error")
        
        with pytest.raises(Exception):
            openai_backend.generate("Test prompt")

    def test_rate_limit_handling(self, openai_backend, mock_openai_client):
        """Test rate limit error handling."""
        from openai import RateLimitError
        
        mock_openai_client.chat.completions.create.side_effect = RateLimitError(
            "Rate limit exceeded",
            response=Mock(status_code=429),
            body={}
        )
        
        with pytest.raises(RateLimitError):
            openai_backend.generate("Test prompt")

    def test_token_counting(self, openai_backend):
        """Test token counting."""
        text = "This is a test prompt"
        token_count = openai_backend.count_tokens(text)
        
        assert isinstance(token_count, int)
        assert token_count > 0

    def test_cost_estimation(self, openai_backend):
        """Test cost estimation."""
        prompt_tokens = 100
        completion_tokens = 50
        
        cost = openai_backend.estimate_cost(prompt_tokens, completion_tokens)
        
        assert isinstance(cost, float)
        assert cost > 0


class TestOllamaBackend:
    """Comprehensive tests for Ollama backend."""

    @pytest.fixture
    def mock_ollama_client(self):
        """Create mock Ollama client."""
        client = Mock()
        client.generate = Mock(return_value={
            'response': 'This is a good action'
        })
        return client

    @pytest.fixture
    def ollama_backend(self, mock_ollama_client):
        """Create Ollama backend with mocked client."""
        with patch('ollama.Client', return_value=mock_ollama_client):
            from rl_llm_toolkit.llm.ollama import OllamaBackend
            return OllamaBackend(model="llama3")

    def test_initialization(self, ollama_backend):
        """Test Ollama backend initialization."""
        assert ollama_backend is not None
        assert ollama_backend.model == "llama3"

    def test_generate_response(self, ollama_backend, mock_ollama_client):
        """Test generating response."""
        prompt = "Evaluate this action"
        response = ollama_backend.generate(prompt)
        
        assert response is not None
        assert isinstance(response, str)
        mock_ollama_client.generate.assert_called_once()

    def test_generate_with_context(self, ollama_backend, mock_ollama_client):
        """Test generating with context."""
        prompt = "Evaluate this action"
        context = "Previous context"
        
        response = ollama_backend.generate(prompt, context=context)
        
        assert response is not None

    def test_local_model_availability(self, ollama_backend):
        """Test checking local model availability."""
        is_available = ollama_backend.is_model_available()
        
        assert isinstance(is_available, bool)

    def test_connection_error_handling(self, ollama_backend, mock_ollama_client):
        """Test connection error handling."""
        mock_ollama_client.generate.side_effect = ConnectionError("Cannot connect to Ollama")
        
        with pytest.raises(ConnectionError):
            ollama_backend.generate("Test prompt")


class TestLLMRewardShaper:
    """Test LLM reward shaping functionality."""

    @pytest.fixture
    def mock_llm_backend(self):
        """Create mock LLM backend."""
        backend = Mock()
        backend.generate = Mock(return_value="Reward: 0.8\nReasoning: Good action")
        return backend

    @pytest.fixture
    def reward_shaper(self, mock_llm_backend):
        """Create LLM reward shaper."""
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        return LLMRewardShaper(llm_backend=mock_llm_backend)

    def test_initialization(self, reward_shaper):
        """Test reward shaper initialization."""
        assert reward_shaper is not None

    def test_shape_reward(self, reward_shaper, mock_llm_backend):
        """Test reward shaping."""
        state = [0.1, 0.2, 0.3, 0.4]
        action = 1
        base_reward = 1.0
        
        shaped_reward = reward_shaper.shape_reward(state, action, base_reward)
        
        assert shaped_reward is not None
        assert isinstance(shaped_reward, float)
        mock_llm_backend.generate.assert_called_once()

    def test_parse_llm_response(self, reward_shaper):
        """Test parsing LLM response."""
        llm_response = "Reward: 0.8\nReasoning: Good action"
        
        reward, reasoning = reward_shaper.parse_response(llm_response)
        
        assert reward == 0.8
        assert "Good action" in reasoning

    def test_reward_caching(self, reward_shaper, mock_llm_backend):
        """Test reward caching for same states."""
        state = [0.1, 0.2, 0.3, 0.4]
        action = 1
        
        # First call
        reward1 = reward_shaper.shape_reward(state, action, 1.0)
        
        # Second call with same state/action
        reward2 = reward_shaper.shape_reward(state, action, 1.0)
        
        # Should use cache
        assert reward1 == reward2
        assert mock_llm_backend.generate.call_count == 1

    def test_reward_clipping(self, reward_shaper):
        """Test reward clipping to valid range."""
        mock_backend = Mock()
        mock_backend.generate = Mock(return_value="Reward: 2.5")
        
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        shaper = LLMRewardShaper(llm_backend=mock_backend, clip_range=(-1, 1))
        
        shaped_reward = shaper.shape_reward([0.1], 0, 1.0)
        
        # Should be clipped to max 1.0
        assert shaped_reward <= 1.0

    def test_invalid_llm_response(self, reward_shaper):
        """Test handling invalid LLM response."""
        mock_backend = Mock()
        mock_backend.generate = Mock(return_value="Invalid response")
        
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        shaper = LLMRewardShaper(llm_backend=mock_backend)
        
        # Should fallback to base reward
        shaped_reward = shaper.shape_reward([0.1], 0, 1.0)
        
        assert shaped_reward == 1.0  # Fallback to base


class TestPromptTemplates:
    """Test prompt template functionality."""

    @pytest.fixture
    def prompt_template(self):
        """Create prompt template."""
        from rl_llm_toolkit.rewards.prompts import PromptTemplate
        return PromptTemplate()

    def test_default_template(self, prompt_template):
        """Test default prompt template."""
        state = [0.1, 0.2, 0.3, 0.4]
        action = 1
        
        prompt = prompt_template.format(state=state, action=action)
        
        assert isinstance(prompt, str)
        assert str(action) in prompt

    def test_custom_template(self):
        """Test custom prompt template."""
        from rl_llm_toolkit.rewards.prompts import PromptTemplate
        
        custom_template = "State: {state}, Action: {action}, Evaluate!"
        template = PromptTemplate(template=custom_template)
        
        prompt = template.format(state=[0.1], action=0)
        
        assert "Evaluate!" in prompt

    def test_template_with_context(self, prompt_template):
        """Test template with additional context."""
        state = [0.1, 0.2]
        action = 1
        context = {"env_name": "CartPole-v1", "episode": 10}
        
        prompt = prompt_template.format(
            state=state,
            action=action,
            context=context
        )
        
        assert isinstance(prompt, str)


class TestLLMBackendEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_prompt(self):
        """Test handling empty prompt."""
        mock_client = Mock()
        mock_client.chat.completions.create = Mock(return_value=Mock(
            choices=[Mock(message=Mock(content=""))]
        ))
        
        with patch('openai.OpenAI', return_value=mock_client):
            from rl_llm_toolkit.llm.openai import OpenAIBackend
            backend = OpenAIBackend(api_key="test")
            
            response = backend.generate("")
            assert response == ""

    def test_very_long_prompt(self):
        """Test handling very long prompt."""
        mock_client = Mock()
        mock_client.chat.completions.create = Mock(return_value=Mock(
            choices=[Mock(message=Mock(content="Response"))]
        ))
        
        with patch('openai.OpenAI', return_value=mock_client):
            from rl_llm_toolkit.llm.openai import OpenAIBackend
            backend = OpenAIBackend(api_key="test")
            
            long_prompt = "Test " * 10000
            response = backend.generate(long_prompt)
            
            assert response is not None

    def test_special_characters_in_prompt(self):
        """Test handling special characters."""
        mock_client = Mock()
        mock_client.chat.completions.create = Mock(return_value=Mock(
            choices=[Mock(message=Mock(content="Response"))]
        ))
        
        with patch('openai.OpenAI', return_value=mock_client):
            from rl_llm_toolkit.llm.openai import OpenAIBackend
            backend = OpenAIBackend(api_key="test")
            
            special_prompt = "Test\n\t\r\x00Special"
            response = backend.generate(special_prompt)
            
            assert response is not None

    def test_timeout_handling(self):
        """Test timeout handling."""
        mock_client = Mock()
        mock_client.chat.completions.create.side_effect = TimeoutError("Request timeout")
        
        with patch('openai.OpenAI', return_value=mock_client):
            from rl_llm_toolkit.llm.openai import OpenAIBackend
            backend = OpenAIBackend(api_key="test")
            
            with pytest.raises(TimeoutError):
                backend.generate("Test", timeout=1)


class TestLLMCostTracking:
    """Test LLM cost tracking functionality."""

    @pytest.fixture
    def cost_tracker(self):
        """Create cost tracker."""
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        return CostTracker()

    def test_track_openai_cost(self, cost_tracker):
        """Test tracking OpenAI costs."""
        cost_tracker.track_call(
            provider="openai",
            model="gpt-4",
            prompt_tokens=100,
            completion_tokens=50
        )
        
        total_cost = cost_tracker.get_total_cost()
        assert total_cost > 0

    def test_track_multiple_calls(self, cost_tracker):
        """Test tracking multiple API calls."""
        for _ in range(5):
            cost_tracker.track_call(
                provider="openai",
                model="gpt-4",
                prompt_tokens=100,
                completion_tokens=50
            )
        
        call_count = cost_tracker.get_call_count()
        assert call_count == 5

    def test_cost_by_model(self, cost_tracker):
        """Test getting cost breakdown by model."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        cost_tracker.track_call("openai", "gpt-3.5-turbo", 100, 50)
        
        breakdown = cost_tracker.get_cost_breakdown()
        
        assert "gpt-4" in breakdown
        assert "gpt-3.5-turbo" in breakdown

    def test_reset_tracker(self, cost_tracker):
        """Test resetting cost tracker."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        cost_tracker.reset()
        
        total_cost = cost_tracker.get_total_cost()
        assert total_cost == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
