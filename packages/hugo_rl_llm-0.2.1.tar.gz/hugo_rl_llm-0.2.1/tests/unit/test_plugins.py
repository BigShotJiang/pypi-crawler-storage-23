"""
Unit tests for Plugin system.
Tests plugin discovery, loading, and execution.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import sys


class TestPluginBase:
    """Test plugin base functionality."""

    @pytest.fixture
    def mock_plugin(self):
        """Create mock plugin."""
        from rl_llm_toolkit.plugins.base import BasePlugin
        
        class MockPlugin(BasePlugin):
            def __init__(self):
                super().__init__()
                self.name = "mock_plugin"
                self.version = "1.0.0"
            
            def execute(self, *args, **kwargs):
                return "executed"
        
        return MockPlugin()

    def test_plugin_initialization(self, mock_plugin):
        """Test plugin initialization."""
        assert mock_plugin is not None
        assert mock_plugin.name == "mock_plugin"
        assert mock_plugin.version == "1.0.0"

    def test_plugin_execution(self, mock_plugin):
        """Test plugin execution."""
        result = mock_plugin.execute()
        assert result == "executed"

    def test_plugin_metadata(self, mock_plugin):
        """Test plugin metadata."""
        metadata = mock_plugin.get_metadata()
        
        assert isinstance(metadata, dict)
        assert 'name' in metadata
        assert 'version' in metadata


class TestPluginDiscovery:
    """Test plugin discovery system."""

    @pytest.fixture
    def plugin_discovery(self):
        """Create plugin discovery."""
        from rl_llm_toolkit.plugins.discovery import PluginDiscovery
        return PluginDiscovery()

    def test_initialization(self, plugin_discovery):
        """Test discovery initialization."""
        assert plugin_discovery is not None

    def test_discover_installed_plugins(self, plugin_discovery):
        """Test discovering installed plugins."""
        plugins = plugin_discovery.discover()
        
        assert isinstance(plugins, list)

    def test_discover_by_entry_point(self, plugin_discovery):
        """Test discovering plugins by entry point."""
        with patch('importlib.metadata.entry_points') as mock_entry_points:
            mock_entry_points.return_value = []
            
            plugins = plugin_discovery.discover_by_entry_point("hugo.plugins")
            
            assert isinstance(plugins, list)

    def test_discover_by_path(self, plugin_discovery, tmp_path):
        """Test discovering plugins by path."""
        plugin_dir = tmp_path / "plugins"
        plugin_dir.mkdir()
        
        # Create mock plugin file
        plugin_file = plugin_dir / "test_plugin.py"
        plugin_file.write_text("""
from rl_llm_toolkit.plugins.base import BasePlugin

class TestPlugin(BasePlugin):
    def __init__(self):
        self.name = "test"
        self.version = "1.0.0"
""")
        
        plugins = plugin_discovery.discover_by_path(str(plugin_dir))
        
        assert isinstance(plugins, list)

    def test_filter_plugins_by_type(self, plugin_discovery):
        """Test filtering plugins by type."""
        mock_plugins = [
            Mock(plugin_type="agent"),
            Mock(plugin_type="environment"),
            Mock(plugin_type="agent")
        ]
        
        filtered = plugin_discovery.filter_by_type(mock_plugins, "agent")
        
        assert len(filtered) == 2

    def test_validate_plugin(self, plugin_discovery):
        """Test plugin validation."""
        mock_plugin = Mock()
        mock_plugin.name = "test"
        mock_plugin.version = "1.0.0"
        mock_plugin.execute = Mock()
        
        is_valid = plugin_discovery.validate(mock_plugin)
        
        assert is_valid is True

    def test_invalid_plugin_detection(self, plugin_discovery):
        """Test detecting invalid plugins."""
        invalid_plugin = Mock()
        # Missing required attributes
        
        is_valid = plugin_discovery.validate(invalid_plugin)
        
        assert is_valid is False


class TestPluginLoader:
    """Test plugin loading system."""

    @pytest.fixture
    def plugin_loader(self):
        """Create plugin loader."""
        from rl_llm_toolkit.plugins.discovery import PluginLoader
        return PluginLoader()

    def test_initialization(self, plugin_loader):
        """Test loader initialization."""
        assert plugin_loader is not None

    def test_load_plugin_by_name(self, plugin_loader):
        """Test loading plugin by name."""
        with patch('importlib.import_module') as mock_import:
            mock_module = Mock()
            mock_module.Plugin = Mock
            mock_import.return_value = mock_module
            
            plugin = plugin_loader.load("test_plugin")
            
            assert plugin is not None

    def test_load_plugin_from_file(self, plugin_loader, tmp_path):
        """Test loading plugin from file."""
        plugin_file = tmp_path / "plugin.py"
        plugin_file.write_text("""
class Plugin:
    def __init__(self):
        self.name = "file_plugin"
""")
        
        plugin = plugin_loader.load_from_file(str(plugin_file))
        
        assert plugin is not None

    def test_load_multiple_plugins(self, plugin_loader):
        """Test loading multiple plugins."""
        plugin_names = ["plugin1", "plugin2", "plugin3"]
        
        with patch('importlib.import_module') as mock_import:
            mock_module = Mock()
            mock_module.Plugin = Mock
            mock_import.return_value = mock_module
            
            plugins = plugin_loader.load_multiple(plugin_names)
            
            assert len(plugins) == 3

    def test_handle_loading_error(self, plugin_loader):
        """Test handling plugin loading errors."""
        with patch('importlib.import_module', side_effect=ImportError("Module not found")):
            with pytest.raises(ImportError):
                plugin_loader.load("nonexistent_plugin")

    def test_lazy_loading(self, plugin_loader):
        """Test lazy plugin loading."""
        plugin = plugin_loader.lazy_load("test_plugin")
        
        # Should return proxy or placeholder
        assert plugin is not None


class TestPluginManager:
    """Test plugin management system."""

    @pytest.fixture
    def plugin_manager(self):
        """Create plugin manager."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        return PluginManager()

    def test_initialization(self, plugin_manager):
        """Test manager initialization."""
        assert plugin_manager is not None

    def test_register_plugin(self, plugin_manager):
        """Test registering plugin."""
        mock_plugin = Mock()
        mock_plugin.name = "test_plugin"
        
        plugin_manager.register(mock_plugin)
        
        assert plugin_manager.get("test_plugin") is not None

    def test_unregister_plugin(self, plugin_manager):
        """Test unregistering plugin."""
        mock_plugin = Mock()
        mock_plugin.name = "test_plugin"
        
        plugin_manager.register(mock_plugin)
        plugin_manager.unregister("test_plugin")
        
        assert plugin_manager.get("test_plugin") is None

    def test_list_plugins(self, plugin_manager):
        """Test listing all plugins."""
        mock_plugin1 = Mock(name="plugin1")
        mock_plugin2 = Mock(name="plugin2")
        
        plugin_manager.register(mock_plugin1)
        plugin_manager.register(mock_plugin2)
        
        plugins = plugin_manager.list()
        
        assert len(plugins) >= 2

    def test_get_plugin_by_name(self, plugin_manager):
        """Test getting plugin by name."""
        mock_plugin = Mock()
        mock_plugin.name = "test_plugin"
        
        plugin_manager.register(mock_plugin)
        
        retrieved = plugin_manager.get("test_plugin")
        
        assert retrieved == mock_plugin

    def test_execute_plugin(self, plugin_manager):
        """Test executing plugin."""
        mock_plugin = Mock()
        mock_plugin.name = "test_plugin"
        mock_plugin.execute = Mock(return_value="result")
        
        plugin_manager.register(mock_plugin)
        
        result = plugin_manager.execute("test_plugin", arg1="value1")
        
        assert result == "result"
        mock_plugin.execute.assert_called_once()

    def test_plugin_dependencies(self, plugin_manager):
        """Test plugin dependency resolution."""
        plugin_a = Mock(name="plugin_a", dependencies=[])
        plugin_b = Mock(name="plugin_b", dependencies=["plugin_a"])
        
        plugin_manager.register(plugin_a)
        plugin_manager.register(plugin_b)
        
        # Should resolve dependencies
        order = plugin_manager.resolve_dependencies()
        
        assert order.index("plugin_a") < order.index("plugin_b")

    def test_circular_dependency_detection(self, plugin_manager):
        """Test detecting circular dependencies."""
        plugin_a = Mock(name="plugin_a", dependencies=["plugin_b"])
        plugin_b = Mock(name="plugin_b", dependencies=["plugin_a"])
        
        plugin_manager.register(plugin_a)
        plugin_manager.register(plugin_b)
        
        with pytest.raises(ValueError):
            plugin_manager.resolve_dependencies()


class TestPluginHooks:
    """Test plugin hook system."""

    @pytest.fixture
    def hook_manager(self):
        """Create hook manager."""
        from rl_llm_toolkit.plugins.discovery import HookManager
        return HookManager()

    def test_register_hook(self, hook_manager):
        """Test registering hook."""
        def test_hook(data):
            return data + 1
        
        hook_manager.register("pre_train", test_hook)
        
        assert hook_manager.has_hook("pre_train")

    def test_execute_hooks(self, hook_manager):
        """Test executing hooks."""
        def hook1(data):
            return data + 1
        
        def hook2(data):
            return data * 2
        
        hook_manager.register("process", hook1)
        hook_manager.register("process", hook2)
        
        result = hook_manager.execute("process", 5)
        
        # Should apply both hooks
        assert result == 12  # (5 + 1) * 2

    def test_hook_priority(self, hook_manager):
        """Test hook execution priority."""
        results = []
        
        def hook_low(data):
            results.append("low")
            return data
        
        def hook_high(data):
            results.append("high")
            return data
        
        hook_manager.register("test", hook_low, priority=1)
        hook_manager.register("test", hook_high, priority=10)
        
        hook_manager.execute("test", None)
        
        # High priority should execute first
        assert results == ["high", "low"]

    def test_remove_hook(self, hook_manager):
        """Test removing hook."""
        def test_hook(data):
            return data
        
        hook_manager.register("test", test_hook)
        hook_manager.remove("test", test_hook)
        
        assert not hook_manager.has_hook("test")


class TestPluginSecurity:
    """Test plugin security features."""

    @pytest.fixture
    def security_validator(self):
        """Create security validator."""
        from rl_llm_toolkit.plugins.discovery import PluginSecurityValidator
        return PluginSecurityValidator()

    def test_validate_safe_plugin(self, security_validator):
        """Test validating safe plugin."""
        safe_code = """
class SafePlugin:
    def execute(self):
        return "safe"
"""
        
        is_safe = security_validator.validate_code(safe_code)
        
        assert is_safe is True

    def test_detect_dangerous_imports(self, security_validator):
        """Test detecting dangerous imports."""
        dangerous_code = """
import os
os.system('rm -rf /')
"""
        
        is_safe = security_validator.validate_code(dangerous_code)
        
        assert is_safe is False

    def test_detect_eval_usage(self, security_validator):
        """Test detecting eval usage."""
        dangerous_code = """
eval('malicious code')
"""
        
        is_safe = security_validator.validate_code(dangerous_code)
        
        assert is_safe is False

    def test_sandbox_execution(self, security_validator):
        """Test sandboxed plugin execution."""
        plugin = Mock()
        plugin.execute = Mock(return_value="result")
        
        result = security_validator.execute_sandboxed(plugin)
        
        assert result == "result"

    def test_resource_limits(self, security_validator):
        """Test plugin resource limits."""
        def resource_intensive_plugin():
            # Simulate resource-intensive operation
            data = [i for i in range(10000000)]
            return sum(data)
        
        # Should enforce limits
        try:
            security_validator.execute_with_limits(
                resource_intensive_plugin,
                memory_limit=100_000_000,  # 100MB
                time_limit=1.0  # 1 second
            )
        except Exception:
            pass  # Expected if limits exceeded


class TestPluginVersioning:
    """Test plugin versioning."""

    def test_version_compatibility(self):
        """Test version compatibility checking."""
        from rl_llm_toolkit.plugins.discovery import check_version_compatibility
        
        plugin_version = "1.2.3"
        required_version = ">=1.0.0,<2.0.0"
        
        is_compatible = check_version_compatibility(plugin_version, required_version)
        
        assert is_compatible is True

    def test_version_incompatibility(self):
        """Test version incompatibility detection."""
        from rl_llm_toolkit.plugins.discovery import check_version_compatibility
        
        plugin_version = "2.0.0"
        required_version = ">=1.0.0,<2.0.0"
        
        is_compatible = check_version_compatibility(plugin_version, required_version)
        
        assert is_compatible is False

    def test_semantic_versioning(self):
        """Test semantic versioning parsing."""
        from rl_llm_toolkit.plugins.discovery import parse_version
        
        version = parse_version("1.2.3-beta.1")
        
        assert version.major == 1
        assert version.minor == 2
        assert version.patch == 3


class TestPluginEdgeCases:
    """Test plugin edge cases."""

    def test_load_corrupted_plugin(self):
        """Test loading corrupted plugin."""
        from rl_llm_toolkit.plugins.discovery import PluginLoader
        
        loader = PluginLoader()
        
        with pytest.raises(Exception):
            loader.load("corrupted_plugin_that_does_not_exist")

    def test_plugin_name_collision(self):
        """Test handling plugin name collisions."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        
        manager = PluginManager()
        
        plugin1 = Mock(name="duplicate")
        plugin2 = Mock(name="duplicate")
        
        manager.register(plugin1)
        
        # Should handle collision
        with pytest.raises(ValueError):
            manager.register(plugin2)

    def test_plugin_without_required_methods(self):
        """Test plugin missing required methods."""
        from rl_llm_toolkit.plugins.discovery import PluginDiscovery
        
        discovery = PluginDiscovery()
        
        incomplete_plugin = Mock()
        incomplete_plugin.name = "incomplete"
        # Missing execute method
        
        is_valid = discovery.validate(incomplete_plugin)
        
        assert is_valid is False

    def test_concurrent_plugin_execution(self):
        """Test concurrent plugin execution."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        import threading
        
        manager = PluginManager()
        
        plugin = Mock()
        plugin.name = "concurrent_plugin"
        plugin.execute = Mock(return_value="result")
        
        manager.register(plugin)
        
        results = []
        
        def execute_plugin():
            result = manager.execute("concurrent_plugin")
            results.append(result)
        
        threads = [threading.Thread(target=execute_plugin) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(results) == 5

    def test_plugin_cleanup(self):
        """Test plugin cleanup on unregister."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        
        manager = PluginManager()
        
        plugin = Mock()
        plugin.name = "cleanup_plugin"
        plugin.cleanup = Mock()
        
        manager.register(plugin)
        manager.unregister("cleanup_plugin")
        
        # Should call cleanup
        plugin.cleanup.assert_called_once()


class TestPluginIntegration:
    """Test plugin integration with core system."""

    def test_agent_plugin_integration(self):
        """Test agent plugin integration."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        
        manager = PluginManager()
        
        # Mock agent plugin
        agent_plugin = Mock()
        agent_plugin.name = "custom_agent"
        agent_plugin.plugin_type = "agent"
        agent_plugin.create_agent = Mock(return_value=Mock())
        
        manager.register(agent_plugin)
        
        # Should be able to create agent
        agent = manager.execute("custom_agent", "create_agent")
        
        assert agent is not None

    def test_environment_plugin_integration(self):
        """Test environment plugin integration."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        
        manager = PluginManager()
        
        # Mock environment plugin
        env_plugin = Mock()
        env_plugin.name = "custom_env"
        env_plugin.plugin_type = "environment"
        env_plugin.create_env = Mock(return_value=Mock())
        
        manager.register(env_plugin)
        
        # Should be able to create environment
        env = manager.execute("custom_env", "create_env")
        
        assert env is not None

    def test_reward_shaper_plugin_integration(self):
        """Test reward shaper plugin integration."""
        from rl_llm_toolkit.plugins.discovery import PluginManager
        
        manager = PluginManager()
        
        # Mock reward shaper plugin
        shaper_plugin = Mock()
        shaper_plugin.name = "custom_shaper"
        shaper_plugin.plugin_type = "reward_shaper"
        shaper_plugin.shape_reward = Mock(return_value=1.5)
        
        manager.register(shaper_plugin)
        
        # Should be able to shape rewards
        shaped_reward = manager.execute("custom_shaper", "shape_reward", 1.0)
        
        assert shaped_reward == 1.5


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
