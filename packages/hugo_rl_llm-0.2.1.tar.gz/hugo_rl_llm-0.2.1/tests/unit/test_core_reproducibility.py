"""
Unit tests for Reproducibility core module.
Tests seed management, version tracking, and deterministic behavior.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import random
import numpy as np


class TestReproducibilityManager:
    """Comprehensive tests for ReproducibilityManager class."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_initialization(self, reproducibility_manager):
        """Test ReproducibilityManager initialization."""
        assert reproducibility_manager is not None

    def test_set_seed(self, reproducibility_manager):
        """Test setting global seed."""
        seed = 42
        reproducibility_manager.set_seed(seed)
        
        # Verify seed is set
        assert reproducibility_manager.seed == seed

    def test_deterministic_random(self, reproducibility_manager):
        """Test deterministic random number generation."""
        seed = 42
        
        # First run
        reproducibility_manager.set_seed(seed)
        random1 = [random.random() for _ in range(10)]
        
        # Second run with same seed
        reproducibility_manager.set_seed(seed)
        random2 = [random.random() for _ in range(10)]
        
        # Should be identical
        assert random1 == random2

    def test_deterministic_numpy(self, reproducibility_manager):
        """Test deterministic numpy random generation."""
        seed = 42
        
        # First run
        reproducibility_manager.set_seed(seed)
        np_random1 = np.random.randn(10)
        
        # Second run with same seed
        reproducibility_manager.set_seed(seed)
        np_random2 = np.random.randn(10)
        
        # Should be identical
        np.testing.assert_array_equal(np_random1, np_random2)

    @patch('torch.manual_seed')
    @patch('torch.cuda.manual_seed_all')
    def test_deterministic_pytorch(self, mock_cuda_seed, mock_torch_seed, reproducibility_manager):
        """Test deterministic PyTorch seeding."""
        seed = 42
        reproducibility_manager.set_seed(seed)
        
        mock_torch_seed.assert_called_once_with(seed)
        mock_cuda_seed.assert_called_once_with(seed)

    def test_get_version_info(self, reproducibility_manager):
        """Test getting version information."""
        version_info = reproducibility_manager.get_version_info()
        
        assert isinstance(version_info, dict)
        assert 'python' in version_info
        assert 'numpy' in version_info
        assert 'torch' in version_info

    def test_get_git_commit(self, reproducibility_manager):
        """Test getting git commit hash."""
        with patch('git.Repo') as mock_repo:
            mock_repo.return_value.head.commit.hexsha = 'abc123'
            
            commit = reproducibility_manager.get_git_commit()
            assert commit == 'abc123'

    def test_save_metadata(self, reproducibility_manager, tmp_path):
        """Test saving reproducibility metadata."""
        metadata_path = tmp_path / "metadata.json"
        
        reproducibility_manager.set_seed(42)
        reproducibility_manager.save_metadata(str(metadata_path))
        
        assert metadata_path.exists()

    def test_load_metadata(self, reproducibility_manager, tmp_path):
        """Test loading reproducibility metadata."""
        metadata_path = tmp_path / "metadata.json"
        
        # Save first
        reproducibility_manager.set_seed(42)
        reproducibility_manager.save_metadata(str(metadata_path))
        
        # Load
        loaded_metadata = reproducibility_manager.load_metadata(str(metadata_path))
        assert loaded_metadata['seed'] == 42

    def test_verify_reproducibility(self, reproducibility_manager):
        """Test reproducibility verification."""
        seed = 42
        
        # Run 1
        reproducibility_manager.set_seed(seed)
        results1 = reproducibility_manager.run_deterministic_test()
        
        # Run 2
        reproducibility_manager.set_seed(seed)
        results2 = reproducibility_manager.run_deterministic_test()
        
        # Should be identical
        assert results1 == results2


class TestSeedManagement:
    """Test seed management and propagation."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_seed_propagation_to_env(self, reproducibility_manager):
        """Test seed propagation to environment."""
        mock_env = Mock()
        mock_env.reset = Mock()
        
        seed = 42
        reproducibility_manager.set_seed(seed)
        reproducibility_manager.seed_environment(mock_env, seed)
        
        # Environment should be seeded
        mock_env.reset.assert_called()

    def test_seed_propagation_to_agent(self, reproducibility_manager):
        """Test seed propagation to agent."""
        mock_agent = Mock()
        
        seed = 42
        reproducibility_manager.set_seed(seed)
        reproducibility_manager.seed_agent(mock_agent, seed)
        
        # Agent should have seed set
        assert hasattr(mock_agent, 'seed') or mock_agent.seed.called

    def test_different_seeds_different_results(self, reproducibility_manager):
        """Test different seeds produce different results."""
        # Seed 1
        reproducibility_manager.set_seed(42)
        random1 = [random.random() for _ in range(10)]
        
        # Seed 2
        reproducibility_manager.set_seed(123)
        random2 = [random.random() for _ in range(10)]
        
        # Should be different
        assert random1 != random2

    def test_auto_seed_generation(self, reproducibility_manager):
        """Test automatic seed generation."""
        seed = reproducibility_manager.generate_seed()
        
        assert isinstance(seed, int)
        assert 0 <= seed < 2**32


class TestVersionTracking:
    """Test version tracking and dependency management."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_track_python_version(self, reproducibility_manager):
        """Test Python version tracking."""
        version_info = reproducibility_manager.get_version_info()
        
        assert 'python' in version_info
        assert isinstance(version_info['python'], str)

    def test_track_package_versions(self, reproducibility_manager):
        """Test package version tracking."""
        version_info = reproducibility_manager.get_version_info()
        
        expected_packages = ['numpy', 'torch', 'gymnasium']
        for package in expected_packages:
            assert package in version_info

    def test_track_custom_versions(self, reproducibility_manager):
        """Test tracking custom package versions."""
        custom_versions = {
            'custom_package': '1.0.0',
            'another_package': '2.1.0'
        }
        
        reproducibility_manager.add_custom_versions(custom_versions)
        version_info = reproducibility_manager.get_version_info()
        
        assert 'custom_package' in version_info
        assert version_info['custom_package'] == '1.0.0'

    def test_version_compatibility_check(self, reproducibility_manager):
        """Test version compatibility checking."""
        required_versions = {
            'numpy': '>=1.20.0',
            'torch': '>=2.0.0'
        }
        
        is_compatible = reproducibility_manager.check_compatibility(required_versions)
        assert isinstance(is_compatible, bool)


class TestDeterministicBehavior:
    """Test deterministic behavior enforcement."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_deterministic_mode(self, reproducibility_manager):
        """Test enabling deterministic mode."""
        reproducibility_manager.enable_deterministic_mode()
        
        assert reproducibility_manager.is_deterministic is True

    @patch('torch.use_deterministic_algorithms')
    def test_pytorch_deterministic_mode(self, mock_deterministic, reproducibility_manager):
        """Test PyTorch deterministic mode."""
        reproducibility_manager.enable_deterministic_mode()
        
        mock_deterministic.assert_called_once_with(True)

    def test_disable_deterministic_mode(self, reproducibility_manager):
        """Test disabling deterministic mode."""
        reproducibility_manager.enable_deterministic_mode()
        reproducibility_manager.disable_deterministic_mode()
        
        assert reproducibility_manager.is_deterministic is False

    def test_deterministic_hash(self, reproducibility_manager):
        """Test deterministic hash generation."""
        data = {'key': 'value', 'number': 42}
        
        hash1 = reproducibility_manager.compute_hash(data)
        hash2 = reproducibility_manager.compute_hash(data)
        
        assert hash1 == hash2


class TestReproducibilityMetadata:
    """Test reproducibility metadata management."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_metadata_creation(self, reproducibility_manager):
        """Test metadata creation."""
        reproducibility_manager.set_seed(42)
        metadata = reproducibility_manager.create_metadata()
        
        assert isinstance(metadata, dict)
        assert 'seed' in metadata
        assert 'timestamp' in metadata
        assert 'versions' in metadata

    def test_metadata_with_git_info(self, reproducibility_manager):
        """Test metadata with git information."""
        with patch('git.Repo') as mock_repo:
            mock_repo.return_value.head.commit.hexsha = 'abc123'
            mock_repo.return_value.is_dirty.return_value = False
            
            metadata = reproducibility_manager.create_metadata(include_git=True)
            
            assert 'git_commit' in metadata
            assert metadata['git_commit'] == 'abc123'

    def test_metadata_with_environment_info(self, reproducibility_manager):
        """Test metadata with environment information."""
        metadata = reproducibility_manager.create_metadata(include_env=True)
        
        assert 'environment' in metadata
        assert 'platform' in metadata['environment']

    def test_metadata_serialization(self, reproducibility_manager, tmp_path):
        """Test metadata serialization to JSON."""
        import json
        
        metadata_path = tmp_path / "metadata.json"
        reproducibility_manager.set_seed(42)
        reproducibility_manager.save_metadata(str(metadata_path))
        
        # Verify JSON is valid
        with open(metadata_path, 'r') as f:
            loaded = json.load(f)
            assert 'seed' in loaded


class TestReproducibilityEdgeCases:
    """Test edge cases and error handling."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_invalid_seed(self, reproducibility_manager):
        """Test handling of invalid seed."""
        with pytest.raises((ValueError, TypeError)):
            reproducibility_manager.set_seed("invalid_seed")

    def test_negative_seed(self, reproducibility_manager):
        """Test handling of negative seed."""
        # Should handle gracefully or raise error
        try:
            reproducibility_manager.set_seed(-1)
        except ValueError:
            pass  # Expected

    def test_very_large_seed(self, reproducibility_manager):
        """Test handling of very large seed."""
        large_seed = 2**32 + 1
        
        # Should handle gracefully
        try:
            reproducibility_manager.set_seed(large_seed)
        except (ValueError, OverflowError):
            pass  # Expected

    def test_missing_git_repo(self, reproducibility_manager):
        """Test handling when git repo is not available."""
        with patch('git.Repo', side_effect=Exception("Not a git repository")):
            commit = reproducibility_manager.get_git_commit()
            assert commit is None or commit == "unknown"

    def test_metadata_without_seed(self, reproducibility_manager):
        """Test creating metadata without setting seed."""
        metadata = reproducibility_manager.create_metadata()
        
        # Should still create metadata
        assert isinstance(metadata, dict)


class TestReproducibilityComparison:
    """Test reproducibility comparison and verification."""

    @pytest.fixture
    def reproducibility_manager(self):
        """Create ReproducibilityManager instance."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        return ReproducibilityManager()

    def test_compare_runs(self, reproducibility_manager):
        """Test comparing two runs for reproducibility."""
        seed = 42
        
        # Run 1
        reproducibility_manager.set_seed(seed)
        metadata1 = reproducibility_manager.create_metadata()
        results1 = [random.random() for _ in range(10)]
        
        # Run 2
        reproducibility_manager.set_seed(seed)
        metadata2 = reproducibility_manager.create_metadata()
        results2 = [random.random() for _ in range(10)]
        
        # Compare
        is_reproducible = reproducibility_manager.compare_runs(
            metadata1, results1,
            metadata2, results2
        )
        
        assert is_reproducible is True

    def test_detect_non_reproducibility(self, reproducibility_manager):
        """Test detecting non-reproducible runs."""
        # Run 1
        reproducibility_manager.set_seed(42)
        metadata1 = reproducibility_manager.create_metadata()
        results1 = [random.random() for _ in range(10)]
        
        # Run 2 with different seed
        reproducibility_manager.set_seed(123)
        metadata2 = reproducibility_manager.create_metadata()
        results2 = [random.random() for _ in range(10)]
        
        # Compare
        is_reproducible = reproducibility_manager.compare_runs(
            metadata1, results1,
            metadata2, results2
        )
        
        assert is_reproducible is False

    def test_version_mismatch_detection(self, reproducibility_manager):
        """Test detecting version mismatches."""
        metadata1 = {
            'versions': {'numpy': '1.20.0', 'torch': '2.0.0'}
        }
        metadata2 = {
            'versions': {'numpy': '1.21.0', 'torch': '2.0.0'}
        }
        
        has_mismatch = reproducibility_manager.detect_version_mismatch(
            metadata1, metadata2
        )
        
        assert has_mismatch is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
