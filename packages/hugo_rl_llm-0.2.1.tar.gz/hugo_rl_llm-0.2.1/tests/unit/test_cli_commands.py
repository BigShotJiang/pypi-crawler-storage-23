"""
Unit tests for CLI commands.
Tests all CLI functionality with mocked dependencies.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch, mock_open
from click.testing import CliRunner
import json


class TestCLIBasics:
    """Test basic CLI functionality."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_cli_help(self, cli_runner):
        """Test CLI help command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['--help'])
        
        assert result.exit_code == 0
        assert 'Hugo' in result.output or 'RL-LLM' in result.output

    def test_cli_version(self, cli_runner):
        """Test CLI version command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['--version'])
        
        assert result.exit_code == 0
        assert '0.2.0' in result.output


class TestQuickstartCommand:
    """Test quickstart command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_quickstart_basic(self, cli_runner):
        """Test basic quickstart."""
        from rl_llm_toolkit.cli.main import cli
        
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, [
                'quickstart',
                '--env', 'CartPole-v1',
                '--algorithm', 'ppo'
            ])
            
            assert result.exit_code == 0
            # Should create config file
            import os
            assert os.path.exists('config_quickstart.yaml')

    def test_quickstart_custom_output(self, cli_runner):
        """Test quickstart with custom output."""
        from rl_llm_toolkit.cli.main import cli
        
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, [
                'quickstart',
                '--env', 'CartPole-v1',
                '--algorithm', 'dqn',
                '--output', 'my_config.yaml'
            ])
            
            assert result.exit_code == 0
            import os
            assert os.path.exists('my_config.yaml')

    def test_quickstart_with_llm(self, cli_runner):
        """Test quickstart with LLM backend."""
        from rl_llm_toolkit.cli.main import cli
        
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, [
                'quickstart',
                '--env', 'CartPole-v1',
                '--algorithm', 'ppo',
                '--llm-backend', 'ollama'
            ])
            
            assert result.exit_code == 0


class TestListCommands:
    """Test list commands."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_list_envs(self, cli_runner):
        """Test list environments command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-envs'])
        
        assert result.exit_code == 0
        assert 'CartPole' in result.output or 'Available' in result.output

    def test_list_agents(self, cli_runner):
        """Test list agents command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-agents'])
        
        assert result.exit_code == 0
        assert 'PPO' in result.output or 'DQN' in result.output

    def test_list_backends(self, cli_runner):
        """Test list LLM backends command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-backends'])
        
        assert result.exit_code == 0
        assert 'OpenAI' in result.output or 'Ollama' in result.output


class TestDoctorCommand:
    """Test doctor diagnostic command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_doctor_basic(self, cli_runner):
        """Test basic doctor command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['doctor'])
        
        assert result.exit_code == 0
        # Should show system diagnostics
        assert 'Python' in result.output or 'System' in result.output

    def test_doctor_verbose(self, cli_runner):
        """Test doctor command with verbose output."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['doctor', '--verbose'])
        
        assert result.exit_code == 0


class TestPluginsCommand:
    """Test plugins command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_plugins_list(self, cli_runner):
        """Test listing plugins."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['plugins'])
        
        assert result.exit_code == 0

    def test_plugins_discover(self, cli_runner):
        """Test discovering plugins."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['plugins', '--discover'])
        
        assert result.exit_code == 0


class TestFoundationStatusCommand:
    """Test foundation-status command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_foundation_status(self, cli_runner):
        """Test foundation status command."""
        from rl_llm_toolkit.cli.main import cli
        
        # Mock file existence
        with patch('pathlib.Path.exists', return_value=True):
            with patch('pathlib.Path.read_text', return_value="# Foundation Status\n\nReady!"):
                result = cli_runner.invoke(cli, ['foundation-status'])
                
                assert result.exit_code == 0

    def test_foundation_status_missing_file(self, cli_runner):
        """Test foundation status with missing file."""
        from rl_llm_toolkit.cli.main import cli
        
        with patch('pathlib.Path.exists', return_value=False):
            result = cli_runner.invoke(cli, ['foundation-status'])
            
            assert result.exit_code != 0


class TestVerifyCheckpointCommand:
    """Test verify-checkpoint command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_verify_checkpoint_valid(self, cli_runner):
        """Test verifying valid checkpoint."""
        from rl_llm_toolkit.cli.commands import verify_checkpoint
        
        with cli_runner.isolated_filesystem():
            # Create mock checkpoint
            import torch
            torch.save({'state': 'test'}, 'checkpoint.pt')
            
            result = cli_runner.invoke(verify_checkpoint, ['checkpoint.pt'])
            
            assert result.exit_code == 0

    def test_verify_checkpoint_invalid(self, cli_runner):
        """Test verifying invalid checkpoint."""
        from rl_llm_toolkit.cli.commands import verify_checkpoint
        
        with cli_runner.isolated_filesystem():
            # Create corrupted file
            with open('corrupted.pt', 'w') as f:
                f.write('corrupted data')
            
            result = cli_runner.invoke(verify_checkpoint, ['corrupted.pt'])
            
            assert result.exit_code != 0


class TestCompareRunsCommand:
    """Test compare-runs command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_compare_runs(self, cli_runner):
        """Test comparing two runs."""
        from rl_llm_toolkit.cli.commands import compare_runs
        
        with cli_runner.isolated_filesystem():
            # Create mock run metadata
            run1 = {'seed': 42, 'reward': 100}
            run2 = {'seed': 42, 'reward': 105}
            
            with open('run1.json', 'w') as f:
                json.dump(run1, f)
            with open('run2.json', 'w') as f:
                json.dump(run2, f)
            
            result = cli_runner.invoke(compare_runs, ['run1.json', 'run2.json'])
            
            assert result.exit_code == 0


class TestExportMetricsCommand:
    """Test export-metrics command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_export_metrics_json(self, cli_runner):
        """Test exporting metrics to JSON."""
        from rl_llm_toolkit.cli.commands import export_metrics
        
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(export_metrics, [
                '--format', 'json',
                '--output', 'metrics.json'
            ])
            
            # Should create output file
            import os
            if result.exit_code == 0:
                assert os.path.exists('metrics.json')

    def test_export_metrics_csv(self, cli_runner):
        """Test exporting metrics to CSV."""
        from rl_llm_toolkit.cli.commands import export_metrics
        
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(export_metrics, [
                '--format', 'csv',
                '--output', 'metrics.csv'
            ])
            
            import os
            if result.exit_code == 0:
                assert os.path.exists('metrics.csv')


class TestBenchmarkCommand:
    """Test benchmark command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_benchmark_basic(self, cli_runner):
        """Test basic benchmark."""
        from rl_llm_toolkit.cli.commands import benchmark
        
        with cli_runner.isolated_filesystem():
            # Create mock config
            config = {
                'env': 'CartPole-v1',
                'algorithm': 'ppo',
                'total_timesteps': 100
            }
            
            with open('config.yaml', 'w') as f:
                import yaml
                yaml.dump(config, f)
            
            result = cli_runner.invoke(benchmark, ['config.yaml', '--dry-run'])
            
            # Dry run should succeed
            assert result.exit_code == 0 or 'dry-run' in result.output.lower()


class TestReproduceCommand:
    """Test reproduce command."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_reproduce_from_metadata(self, cli_runner):
        """Test reproducing run from metadata."""
        from rl_llm_toolkit.cli.commands import reproduce
        
        with cli_runner.isolated_filesystem():
            # Create mock metadata
            metadata = {
                'seed': 42,
                'config': {
                    'env': 'CartPole-v1',
                    'algorithm': 'ppo'
                }
            }
            
            with open('metadata.json', 'w') as f:
                json.dump(metadata, f)
            
            result = cli_runner.invoke(reproduce, ['metadata.json', '--dry-run'])
            
            assert result.exit_code == 0 or 'dry-run' in result.output.lower()


class TestCLIErrorHandling:
    """Test CLI error handling."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_invalid_command(self, cli_runner):
        """Test invalid command."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['invalid-command'])
        
        assert result.exit_code != 0

    def test_missing_required_argument(self, cli_runner):
        """Test missing required argument."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['quickstart'])
        
        # Should fail or prompt for required args
        assert result.exit_code != 0 or 'required' in result.output.lower()

    def test_invalid_option_value(self, cli_runner):
        """Test invalid option value."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, [
            'quickstart',
            '--env', 'InvalidEnv-v999',
            '--algorithm', 'ppo'
        ])
        
        # Should handle gracefully
        assert result.exit_code != 0 or 'invalid' in result.output.lower()

    def test_file_not_found(self, cli_runner):
        """Test file not found error."""
        from rl_llm_toolkit.cli.commands import verify_checkpoint
        
        result = cli_runner.invoke(verify_checkpoint, ['nonexistent.pt'])
        
        assert result.exit_code != 0


class TestCLIOutputFormats:
    """Test CLI output formatting."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_json_output(self, cli_runner):
        """Test JSON output format."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-envs', '--format', 'json'])
        
        if result.exit_code == 0:
            # Should be valid JSON
            try:
                json.loads(result.output)
            except json.JSONDecodeError:
                pass  # Format may not be implemented

    def test_table_output(self, cli_runner):
        """Test table output format."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-envs', '--format', 'table'])
        
        assert result.exit_code == 0

    def test_quiet_mode(self, cli_runner):
        """Test quiet mode."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['list-envs', '--quiet'])
        
        # Should have minimal output
        if result.exit_code == 0:
            assert len(result.output) < 1000  # Arbitrary threshold


class TestCLIConfiguration:
    """Test CLI configuration handling."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_config_file_loading(self, cli_runner):
        """Test loading configuration from file."""
        from rl_llm_toolkit.cli.main import cli
        
        with cli_runner.isolated_filesystem():
            # Create config file
            config = {
                'default_env': 'CartPole-v1',
                'default_algorithm': 'ppo'
            }
            
            with open('.hugo.yaml', 'w') as f:
                import yaml
                yaml.dump(config, f)
            
            result = cli_runner.invoke(cli, ['--help'])
            
            assert result.exit_code == 0

    def test_environment_variables(self, cli_runner):
        """Test environment variable configuration."""
        from rl_llm_toolkit.cli.main import cli
        
        import os
        os.environ['HUGO_ENV'] = 'CartPole-v1'
        
        result = cli_runner.invoke(cli, ['--help'])
        
        assert result.exit_code == 0
        
        del os.environ['HUGO_ENV']

    def test_cli_precedence(self, cli_runner):
        """Test CLI argument precedence over config."""
        from rl_llm_toolkit.cli.main import cli
        
        # CLI args should override config file
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, [
                'quickstart',
                '--env', 'LunarLander-v2',
                '--algorithm', 'dqn'
            ])
            
            assert result.exit_code == 0


class TestCLIInteractive:
    """Test CLI interactive features."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_interactive_prompts(self, cli_runner):
        """Test interactive prompts."""
        from rl_llm_toolkit.cli.main import cli
        
        # Simulate user input
        result = cli_runner.invoke(cli, ['quickstart'], input='CartPole-v1\nppo\n')
        
        # Should handle interactive input
        assert result.exit_code == 0 or 'CartPole' in result.output

    def test_confirmation_prompts(self, cli_runner):
        """Test confirmation prompts."""
        from rl_llm_toolkit.cli.main import cli
        
        # Test with --yes flag to skip prompts
        with cli_runner.isolated_filesystem():
            result = cli_runner.invoke(cli, [
                'quickstart',
                '--env', 'CartPole-v1',
                '--algorithm', 'ppo',
                '--yes'
            ])
            
            assert result.exit_code == 0


class TestCLIProgress:
    """Test CLI progress indicators."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_progress_bar(self, cli_runner):
        """Test progress bar display."""
        from rl_llm_toolkit.cli.main import cli
        
        # Progress bars should work in non-TTY mode
        result = cli_runner.invoke(cli, ['--help'])
        
        assert result.exit_code == 0

    def test_spinner(self, cli_runner):
        """Test spinner display."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, ['doctor'])
        
        assert result.exit_code == 0


class TestCLIEdgeCases:
    """Test CLI edge cases."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        return CliRunner()

    def test_very_long_arguments(self, cli_runner):
        """Test very long command line arguments."""
        from rl_llm_toolkit.cli.main import cli
        
        long_path = 'a' * 1000 + '.yaml'
        
        result = cli_runner.invoke(cli, ['quickstart', '--output', long_path])
        
        # Should handle gracefully
        assert result.exit_code != 0 or len(result.output) > 0

    def test_special_characters_in_args(self, cli_runner):
        """Test special characters in arguments."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, [
            'quickstart',
            '--env', 'CartPole-v1',
            '--algorithm', 'ppo',
            '--output', 'config\n\t.yaml'
        ])
        
        # Should sanitize or reject
        assert result.exit_code != 0 or 'config' in result.output

    def test_unicode_in_args(self, cli_runner):
        """Test unicode in arguments."""
        from rl_llm_toolkit.cli.main import cli
        
        result = cli_runner.invoke(cli, [
            'quickstart',
            '--env', 'CartPole-v1',
            '--algorithm', 'ppo',
            '--output', 'config_你好.yaml'
        ])
        
        # Should handle unicode
        assert result.exit_code == 0 or result.exit_code != 0

    def test_concurrent_cli_invocations(self, cli_runner):
        """Test concurrent CLI invocations."""
        from rl_llm_toolkit.cli.main import cli
        import threading
        
        results = []
        
        def invoke_cli():
            result = cli_runner.invoke(cli, ['--version'])
            results.append(result.exit_code)
        
        threads = [threading.Thread(target=invoke_cli) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # All should succeed
        assert all(code == 0 for code in results)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
