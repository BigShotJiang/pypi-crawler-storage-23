"""
Unit tests for Checkpoint core module.
Tests save, load, resume, and verification functionality.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch, mock_open
import tempfile
import json
from pathlib import Path


class TestCheckpointManager:
    """Comprehensive tests for CheckpointManager class."""

    @pytest.fixture
    def temp_checkpoint_dir(self, tmp_path):
        """Create temporary checkpoint directory."""
        checkpoint_dir = tmp_path / "checkpoints"
        checkpoint_dir.mkdir()
        return checkpoint_dir

    @pytest.fixture
    def mock_agent_state(self):
        """Create mock agent state."""
        return {
            'policy_state_dict': {'layer1.weight': [1, 2, 3]},
            'optimizer_state_dict': {'lr': 0.001},
            'episode': 100,
            'total_steps': 10000,
        }

    @pytest.fixture
    def checkpoint_manager(self, temp_checkpoint_dir):
        """Create CheckpointManager instance."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        return CheckpointManager(checkpoint_dir=str(temp_checkpoint_dir))

    def test_initialization(self, checkpoint_manager, temp_checkpoint_dir):
        """Test CheckpointManager initialization."""
        assert checkpoint_manager is not None
        assert Path(checkpoint_manager.checkpoint_dir).exists()

    def test_save_checkpoint(self, checkpoint_manager, mock_agent_state):
        """Test saving checkpoint."""
        checkpoint_path = checkpoint_manager.save(
            agent_state=mock_agent_state,
            episode=100,
            metadata={'env': 'CartPole-v1'}
        )
        
        assert checkpoint_path is not None
        assert Path(checkpoint_path).exists()

    def test_load_checkpoint(self, checkpoint_manager, mock_agent_state):
        """Test loading checkpoint."""
        # Save first
        checkpoint_path = checkpoint_manager.save(
            agent_state=mock_agent_state,
            episode=100
        )
        
        # Load
        loaded_state = checkpoint_manager.load(checkpoint_path)
        assert loaded_state is not None
        assert 'agent_state' in loaded_state
        assert loaded_state['episode'] == 100

    def test_list_checkpoints(self, checkpoint_manager, mock_agent_state):
        """Test listing checkpoints."""
        # Save multiple checkpoints
        for i in range(3):
            checkpoint_manager.save(
                agent_state=mock_agent_state,
                episode=i * 100
            )
        
        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) >= 3

    def test_get_latest_checkpoint(self, checkpoint_manager, mock_agent_state):
        """Test getting latest checkpoint."""
        # Save multiple checkpoints
        for i in range(3):
            checkpoint_manager.save(
                agent_state=mock_agent_state,
                episode=i * 100
            )
        
        latest = checkpoint_manager.get_latest()
        assert latest is not None

    def test_delete_checkpoint(self, checkpoint_manager, mock_agent_state):
        """Test deleting checkpoint."""
        checkpoint_path = checkpoint_manager.save(
            agent_state=mock_agent_state,
            episode=100
        )
        
        checkpoint_manager.delete(checkpoint_path)
        assert not Path(checkpoint_path).exists()

    def test_checkpoint_metadata(self, checkpoint_manager, mock_agent_state):
        """Test checkpoint metadata storage."""
        metadata = {
            'env': 'CartPole-v1',
            'algorithm': 'PPO',
            'hyperparameters': {'lr': 0.001}
        }
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=mock_agent_state,
            episode=100,
            metadata=metadata
        )
        
        loaded = checkpoint_manager.load(checkpoint_path)
        assert 'metadata' in loaded
        assert loaded['metadata']['env'] == 'CartPole-v1'

    def test_checkpoint_versioning(self, checkpoint_manager, mock_agent_state):
        """Test checkpoint versioning."""
        # Save same episode multiple times
        paths = []
        for i in range(3):
            path = checkpoint_manager.save(
                agent_state=mock_agent_state,
                episode=100
            )
            paths.append(path)
        
        # Should create different files
        assert len(set(paths)) == 3

    def test_checkpoint_cleanup(self, checkpoint_manager, mock_agent_state):
        """Test checkpoint cleanup (keep only N latest)."""
        # Save many checkpoints
        for i in range(10):
            checkpoint_manager.save(
                agent_state=mock_agent_state,
                episode=i * 100
            )
        
        # Cleanup to keep only 3
        checkpoint_manager.cleanup(keep_last=3)
        
        remaining = checkpoint_manager.list_checkpoints()
        assert len(remaining) <= 3

    def test_resume_from_checkpoint(self, checkpoint_manager, mock_agent_state):
        """Test resuming training from checkpoint."""
        # Save checkpoint
        checkpoint_path = checkpoint_manager.save(
            agent_state=mock_agent_state,
            episode=100,
            metadata={'total_steps': 10000}
        )
        
        # Resume
        resume_data = checkpoint_manager.resume(checkpoint_path)
        assert resume_data is not None
        assert resume_data['episode'] == 100
        assert resume_data['metadata']['total_steps'] == 10000


class TestCheckpointVerification:
    """Test checkpoint verification and integrity checks."""

    @pytest.fixture
    def checkpoint_manager(self, tmp_path):
        """Create CheckpointManager instance."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        return CheckpointManager(checkpoint_dir=str(tmp_path))

    def test_verify_valid_checkpoint(self, checkpoint_manager):
        """Test verification of valid checkpoint."""
        agent_state = {'policy': [1, 2, 3]}
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100
        )
        
        is_valid = checkpoint_manager.verify(checkpoint_path)
        assert is_valid is True

    def test_verify_corrupted_checkpoint(self, checkpoint_manager, tmp_path):
        """Test verification of corrupted checkpoint."""
        # Create corrupted file
        corrupted_path = tmp_path / "corrupted.pt"
        corrupted_path.write_text("corrupted data")
        
        is_valid = checkpoint_manager.verify(str(corrupted_path))
        assert is_valid is False

    def test_verify_missing_checkpoint(self, checkpoint_manager):
        """Test verification of missing checkpoint."""
        is_valid = checkpoint_manager.verify("/nonexistent/checkpoint.pt")
        assert is_valid is False

    def test_checkpoint_hash(self, checkpoint_manager):
        """Test checkpoint hash generation for integrity."""
        agent_state = {'policy': [1, 2, 3]}
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100
        )
        
        hash1 = checkpoint_manager.compute_hash(checkpoint_path)
        hash2 = checkpoint_manager.compute_hash(checkpoint_path)
        
        # Same file should have same hash
        assert hash1 == hash2


class TestCheckpointFormats:
    """Test different checkpoint formats and serialization."""

    @pytest.fixture
    def checkpoint_manager(self, tmp_path):
        """Create CheckpointManager instance."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        return CheckpointManager(checkpoint_dir=str(tmp_path))

    def test_pytorch_format(self, checkpoint_manager):
        """Test PyTorch checkpoint format."""
        import torch
        
        agent_state = {
            'policy': torch.nn.Linear(4, 2).state_dict(),
            'optimizer': {'lr': 0.001}
        }
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100,
            format='pytorch'
        )
        
        assert checkpoint_path.endswith('.pt')

    def test_json_format(self, checkpoint_manager):
        """Test JSON checkpoint format."""
        agent_state = {
            'config': {'lr': 0.001, 'gamma': 0.99},
            'episode': 100
        }
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100,
            format='json'
        )
        
        assert checkpoint_path.endswith('.json')
        
        # Verify JSON is valid
        with open(checkpoint_path, 'r') as f:
            data = json.load(f)
            assert 'agent_state' in data

    def test_pickle_format(self, checkpoint_manager):
        """Test pickle checkpoint format."""
        agent_state = {
            'policy': [1, 2, 3],
            'custom_object': Mock()
        }
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100,
            format='pickle'
        )
        
        assert checkpoint_path.endswith('.pkl')


class TestCheckpointEdgeCases:
    """Test edge cases and error handling."""

    @pytest.fixture
    def checkpoint_manager(self, tmp_path):
        """Create CheckpointManager instance."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        return CheckpointManager(checkpoint_dir=str(tmp_path))

    def test_save_empty_state(self, checkpoint_manager):
        """Test saving empty agent state."""
        checkpoint_path = checkpoint_manager.save(
            agent_state={},
            episode=0
        )
        
        assert checkpoint_path is not None
        loaded = checkpoint_manager.load(checkpoint_path)
        assert loaded['agent_state'] == {}

    def test_save_large_state(self, checkpoint_manager):
        """Test saving large agent state."""
        import numpy as np
        
        large_state = {
            'weights': np.random.randn(1000, 1000).tolist()
        }
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=large_state,
            episode=100
        )
        
        assert checkpoint_path is not None

    def test_concurrent_saves(self, checkpoint_manager):
        """Test concurrent checkpoint saves."""
        agent_state = {'policy': [1, 2, 3]}
        
        paths = []
        for i in range(5):
            path = checkpoint_manager.save(
                agent_state=agent_state,
                episode=i
            )
            paths.append(path)
        
        # All saves should succeed
        assert len(paths) == 5
        assert all(Path(p).exists() for p in paths)

    def test_disk_full_handling(self, checkpoint_manager, tmp_path):
        """Test handling of disk full scenario."""
        # Mock disk full error
        with patch('builtins.open', side_effect=OSError("No space left on device")):
            with pytest.raises(OSError):
                checkpoint_manager.save(
                    agent_state={'policy': [1, 2, 3]},
                    episode=100
                )

    def test_permission_error_handling(self, checkpoint_manager):
        """Test handling of permission errors."""
        # Mock permission error
        with patch('builtins.open', side_effect=PermissionError("Permission denied")):
            with pytest.raises(PermissionError):
                checkpoint_manager.save(
                    agent_state={'policy': [1, 2, 3]},
                    episode=100
                )


class TestCheckpointCompression:
    """Test checkpoint compression functionality."""

    @pytest.fixture
    def checkpoint_manager(self, tmp_path):
        """Create CheckpointManager instance."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        return CheckpointManager(checkpoint_dir=str(tmp_path))

    def test_compressed_checkpoint(self, checkpoint_manager):
        """Test saving compressed checkpoint."""
        import numpy as np
        
        large_state = {
            'weights': np.random.randn(100, 100).tolist()
        }
        
        # Save compressed
        compressed_path = checkpoint_manager.save(
            agent_state=large_state,
            episode=100,
            compress=True
        )
        
        # Save uncompressed
        uncompressed_path = checkpoint_manager.save(
            agent_state=large_state,
            episode=101,
            compress=False
        )
        
        # Compressed should be smaller
        compressed_size = Path(compressed_path).stat().st_size
        uncompressed_size = Path(uncompressed_path).stat().st_size
        
        assert compressed_size < uncompressed_size

    def test_load_compressed_checkpoint(self, checkpoint_manager):
        """Test loading compressed checkpoint."""
        agent_state = {'policy': [1, 2, 3] * 100}
        
        checkpoint_path = checkpoint_manager.save(
            agent_state=agent_state,
            episode=100,
            compress=True
        )
        
        loaded = checkpoint_manager.load(checkpoint_path)
        assert loaded['agent_state'] == agent_state


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
