"""
Unit tests for RLEnvironment core module.
Tests all functionality with mocked Gymnasium environments.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import numpy as np


class TestRLEnvironment:
    """Comprehensive tests for RLEnvironment class."""

    @pytest.fixture
    def mock_gym_env(self):
        """Create a mock Gymnasium environment."""
        env = Mock()
        env.observation_space = Mock()
        env.observation_space.shape = (4,)
        env.action_space = Mock()
        env.action_space.n = 2
        env.reset = Mock(return_value=(np.array([0.1, 0.2, 0.3, 0.4]), {}))
        env.step = Mock(return_value=(
            np.array([0.2, 0.3, 0.4, 0.5]),
            1.0,
            False,
            False,
            {}
        ))
        env.close = Mock()
        env.render = Mock()
        return env

    @pytest.fixture
    def rl_environment(self, mock_gym_env):
        """Create RLEnvironment with mocked gym."""
        with patch('gymnasium.make', return_value=mock_gym_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            return RLEnvironment("CartPole-v1")

    def test_initialization(self, rl_environment):
        """Test environment initialization."""
        assert rl_environment is not None
        assert rl_environment.env_id == "CartPole-v1"

    def test_reset(self, rl_environment, mock_gym_env):
        """Test environment reset."""
        obs, info = rl_environment.reset()
        assert obs is not None
        assert isinstance(obs, np.ndarray)
        mock_gym_env.reset.assert_called_once()

    def test_step(self, rl_environment, mock_gym_env):
        """Test environment step."""
        action = 0
        obs, reward, terminated, truncated, info = rl_environment.step(action)
        
        assert obs is not None
        assert isinstance(reward, (int, float))
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        mock_gym_env.step.assert_called_once_with(action)

    def test_close(self, rl_environment, mock_gym_env):
        """Test environment close."""
        rl_environment.close()
        mock_gym_env.close.assert_called_once()

    def test_render(self, rl_environment, mock_gym_env):
        """Test environment render."""
        rl_environment.render()
        mock_gym_env.render.assert_called_once()

    def test_observation_space(self, rl_environment):
        """Test observation space access."""
        obs_space = rl_environment.observation_space
        assert obs_space is not None
        assert hasattr(obs_space, 'shape')

    def test_action_space(self, rl_environment):
        """Test action space access."""
        action_space = rl_environment.action_space
        assert action_space is not None
        assert hasattr(action_space, 'n')

    def test_episode_statistics(self, rl_environment, mock_gym_env):
        """Test episode statistics tracking."""
        rl_environment.reset()
        
        # Simulate episode
        for _ in range(5):
            rl_environment.step(0)
        
        stats = rl_environment.episode_statistics()
        assert isinstance(stats, dict)

    def test_seed_setting(self, mock_gym_env):
        """Test seed setting for reproducibility."""
        with patch('gymnasium.make', return_value=mock_gym_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            env = RLEnvironment("CartPole-v1", seed=42)
            assert env is not None

    def test_multiple_episodes(self, rl_environment, mock_gym_env):
        """Test multiple episode handling."""
        for episode in range(3):
            rl_environment.reset()
            for step in range(10):
                rl_environment.step(0)
        
        assert mock_gym_env.reset.call_count == 3

    def test_invalid_action(self, rl_environment):
        """Test handling of invalid actions."""
        rl_environment.reset()
        # Should handle gracefully or raise appropriate error
        try:
            rl_environment.step(999)
        except Exception as e:
            assert isinstance(e, (ValueError, IndexError))

    def test_context_manager(self, mock_gym_env):
        """Test environment as context manager."""
        with patch('gymnasium.make', return_value=mock_gym_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            with RLEnvironment("CartPole-v1") as env:
                env.reset()
                env.step(0)
            mock_gym_env.close.assert_called()


class TestEnvironmentEdgeCases:
    """Test edge cases and error handling."""

    def test_invalid_env_id(self):
        """Test invalid environment ID."""
        with patch('gymnasium.make', side_effect=Exception("Invalid env")):
            from rl_llm_toolkit.core.environment import RLEnvironment
            with pytest.raises(Exception):
                RLEnvironment("InvalidEnv-v999")

    def test_step_before_reset(self):
        """Test stepping before reset."""
        mock_env = Mock()
        mock_env.observation_space = Mock(shape=(4,))
        mock_env.action_space = Mock(n=2)
        
        with patch('gymnasium.make', return_value=mock_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            env = RLEnvironment("CartPole-v1")
            # Should handle gracefully or require reset
            try:
                env.step(0)
            except Exception:
                pass  # Expected behavior

    def test_render_modes(self):
        """Test different render modes."""
        mock_env = Mock()
        mock_env.observation_space = Mock(shape=(4,))
        mock_env.action_space = Mock(n=2)
        mock_env.reset = Mock(return_value=(np.zeros(4), {}))
        mock_env.render = Mock()
        
        with patch('gymnasium.make', return_value=mock_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            env = RLEnvironment("CartPole-v1", render_mode="human")
            env.render()
            mock_env.render.assert_called()


class TestEnvironmentStatistics:
    """Test episode statistics tracking."""

    @pytest.fixture
    def env_with_stats(self):
        """Create environment with statistics tracking."""
        mock_env = Mock()
        mock_env.observation_space = Mock(shape=(4,))
        mock_env.action_space = Mock(n=2)
        mock_env.reset = Mock(return_value=(np.zeros(4), {}))
        
        # Simulate varying rewards
        rewards = [1.0, 0.5, 1.0, 0.0, 1.0]
        mock_env.step = Mock(side_effect=[
            (np.zeros(4), r, False, False, {}) for r in rewards
        ] + [(np.zeros(4), 0.0, True, False, {})])
        
        with patch('gymnasium.make', return_value=mock_env):
            from rl_llm_toolkit.core.environment import RLEnvironment
            return RLEnvironment("CartPole-v1")

    def test_reward_tracking(self, env_with_stats):
        """Test reward accumulation."""
        env_with_stats.reset()
        total_reward = 0
        
        for _ in range(6):
            _, reward, done, _, _ = env_with_stats.step(0)
            total_reward += reward
            if done:
                break
        
        assert total_reward > 0

    def test_step_counting(self, env_with_stats):
        """Test step counting."""
        env_with_stats.reset()
        steps = 0
        
        for _ in range(6):
            _, _, done, _, _ = env_with_stats.step(0)
            steps += 1
            if done:
                break
        
        assert steps > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
