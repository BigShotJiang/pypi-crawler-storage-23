"""
Unit tests for Hugo RL-LLM Toolkit.

This package contains comprehensive unit tests for all core modules,
using mocks and fixtures to avoid external dependencies.
"""
