"""
Unit tests for Tracking modules.
Tests TensorBoard, W&B, MLflow backends with mocked APIs.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import numpy as np


class TestTrackingBackends:
    """Test tracking backend base functionality."""

    @pytest.fixture
    def mock_tracker(self):
        """Create mock tracker."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        return Tracker()

    def test_initialization(self, mock_tracker):
        """Test tracker initialization."""
        assert mock_tracker is not None

    def test_log_scalar(self, mock_tracker):
        """Test logging scalar metric."""
        mock_tracker.log_scalar("reward", 10.5, step=100)
        
        # Should store metric
        assert hasattr(mock_tracker, 'metrics')

    def test_log_multiple_scalars(self, mock_tracker):
        """Test logging multiple scalars."""
        metrics = {
            'reward': 10.5,
            'loss': 0.3,
            'accuracy': 0.95
        }
        
        mock_tracker.log_scalars(metrics, step=100)
        
        assert len(mock_tracker.metrics) >= 3

    def test_log_histogram(self, mock_tracker):
        """Test logging histogram."""
        values = np.random.randn(100)
        
        mock_tracker.log_histogram("weights", values, step=100)
        
        assert hasattr(mock_tracker, 'histograms')

    def test_log_image(self, mock_tracker):
        """Test logging image."""
        image = np.random.randint(0, 255, (64, 64, 3), dtype=np.uint8)
        
        mock_tracker.log_image("observation", image, step=100)
        
        assert hasattr(mock_tracker, 'images')

    def test_log_text(self, mock_tracker):
        """Test logging text."""
        text = "Episode completed with reward 10.5"
        
        mock_tracker.log_text("status", text, step=100)
        
        assert hasattr(mock_tracker, 'texts')


class TestTensorBoardBackend:
    """Test TensorBoard tracking backend."""

    @pytest.fixture
    def mock_writer(self):
        """Create mock TensorBoard writer."""
        writer = Mock()
        writer.add_scalar = Mock()
        writer.add_scalars = Mock()
        writer.add_histogram = Mock()
        writer.add_image = Mock()
        writer.add_text = Mock()
        writer.flush = Mock()
        writer.close = Mock()
        return writer

    @pytest.fixture
    def tensorboard_backend(self, mock_writer):
        """Create TensorBoard backend with mocked writer."""
        with patch('torch.utils.tensorboard.SummaryWriter', return_value=mock_writer):
            from rl_llm_toolkit.tracking.backends import TensorBoardBackend
            return TensorBoardBackend(log_dir="./logs")

    def test_initialization(self, tensorboard_backend):
        """Test TensorBoard backend initialization."""
        assert tensorboard_backend is not None

    def test_log_scalar(self, tensorboard_backend, mock_writer):
        """Test logging scalar to TensorBoard."""
        tensorboard_backend.log_scalar("reward", 10.5, step=100)
        
        mock_writer.add_scalar.assert_called_once_with("reward", 10.5, 100)

    def test_log_scalars(self, tensorboard_backend, mock_writer):
        """Test logging multiple scalars."""
        metrics = {'reward': 10.5, 'loss': 0.3}
        
        tensorboard_backend.log_scalars(metrics, step=100)
        
        assert mock_writer.add_scalar.call_count == 2

    def test_log_histogram(self, tensorboard_backend, mock_writer):
        """Test logging histogram."""
        values = np.random.randn(100)
        
        tensorboard_backend.log_histogram("weights", values, step=100)
        
        mock_writer.add_histogram.assert_called_once()

    def test_flush(self, tensorboard_backend, mock_writer):
        """Test flushing TensorBoard writer."""
        tensorboard_backend.flush()
        
        mock_writer.flush.assert_called_once()

    def test_close(self, tensorboard_backend, mock_writer):
        """Test closing TensorBoard writer."""
        tensorboard_backend.close()
        
        mock_writer.close.assert_called_once()


class TestWandBBackend:
    """Test Weights & Biases tracking backend."""

    @pytest.fixture
    def mock_wandb(self):
        """Create mock W&B module."""
        wandb = Mock()
        wandb.init = Mock(return_value=Mock())
        wandb.log = Mock()
        wandb.finish = Mock()
        wandb.config = {}
        return wandb

    @pytest.fixture
    def wandb_backend(self, mock_wandb):
        """Create W&B backend with mocked module."""
        with patch('wandb', mock_wandb):
            from rl_llm_toolkit.tracking.backends import WandBBackend
            return WandBBackend(project="hugo-test", entity="test-user")

    def test_initialization(self, wandb_backend, mock_wandb):
        """Test W&B backend initialization."""
        assert wandb_backend is not None
        mock_wandb.init.assert_called_once()

    def test_log_scalar(self, wandb_backend, mock_wandb):
        """Test logging scalar to W&B."""
        wandb_backend.log_scalar("reward", 10.5, step=100)
        
        mock_wandb.log.assert_called()

    def test_log_config(self, wandb_backend, mock_wandb):
        """Test logging config to W&B."""
        config = {
            'learning_rate': 0.001,
            'gamma': 0.99,
            'batch_size': 64
        }
        
        wandb_backend.log_config(config)
        
        assert mock_wandb.config == config

    def test_log_artifact(self, wandb_backend, mock_wandb):
        """Test logging artifact to W&B."""
        wandb_backend.log_artifact("model.pt", type="model")
        
        # Should call W&B artifact API
        assert mock_wandb.log.called or hasattr(wandb_backend, 'artifacts')

    def test_finish(self, wandb_backend, mock_wandb):
        """Test finishing W&B run."""
        wandb_backend.finish()
        
        mock_wandb.finish.assert_called_once()


class TestMLflowBackend:
    """Test MLflow tracking backend."""

    @pytest.fixture
    def mock_mlflow(self):
        """Create mock MLflow module."""
        mlflow = Mock()
        mlflow.start_run = Mock(return_value=Mock(__enter__=Mock(), __exit__=Mock()))
        mlflow.log_metric = Mock()
        mlflow.log_param = Mock()
        mlflow.log_artifact = Mock()
        mlflow.end_run = Mock()
        return mlflow

    @pytest.fixture
    def mlflow_backend(self, mock_mlflow):
        """Create MLflow backend with mocked module."""
        with patch('mlflow', mock_mlflow):
            from rl_llm_toolkit.tracking.backends import MLflowBackend
            return MLflowBackend(experiment_name="hugo-test")

    def test_initialization(self, mlflow_backend, mock_mlflow):
        """Test MLflow backend initialization."""
        assert mlflow_backend is not None

    def test_log_metric(self, mlflow_backend, mock_mlflow):
        """Test logging metric to MLflow."""
        mlflow_backend.log_scalar("reward", 10.5, step=100)
        
        mock_mlflow.log_metric.assert_called()

    def test_log_param(self, mlflow_backend, mock_mlflow):
        """Test logging parameter to MLflow."""
        mlflow_backend.log_param("learning_rate", 0.001)
        
        mock_mlflow.log_param.assert_called_once_with("learning_rate", 0.001)

    def test_log_artifact(self, mlflow_backend, mock_mlflow):
        """Test logging artifact to MLflow."""
        mlflow_backend.log_artifact("model.pt")
        
        mock_mlflow.log_artifact.assert_called_once()

    def test_end_run(self, mlflow_backend, mock_mlflow):
        """Test ending MLflow run."""
        mlflow_backend.end_run()
        
        mock_mlflow.end_run.assert_called_once()


class TestMultiBackendTracker:
    """Test multi-backend tracking."""

    @pytest.fixture
    def multi_tracker(self):
        """Create multi-backend tracker."""
        from rl_llm_toolkit.tracking.tracker import MultiBackendTracker
        
        mock_tb = Mock()
        mock_wandb = Mock()
        mock_mlflow = Mock()
        
        return MultiBackendTracker(backends=[mock_tb, mock_wandb, mock_mlflow])

    def test_initialization(self, multi_tracker):
        """Test multi-backend tracker initialization."""
        assert multi_tracker is not None
        assert len(multi_tracker.backends) == 3

    def test_log_to_all_backends(self, multi_tracker):
        """Test logging to all backends."""
        multi_tracker.log_scalar("reward", 10.5, step=100)
        
        # Should call all backends
        for backend in multi_tracker.backends:
            backend.log_scalar.assert_called_once_with("reward", 10.5, step=100)

    def test_selective_backend_logging(self, multi_tracker):
        """Test logging to specific backends."""
        multi_tracker.log_scalar("reward", 10.5, step=100, backends=["tensorboard"])
        
        # Only first backend should be called
        multi_tracker.backends[0].log_scalar.assert_called_once()

    def test_close_all_backends(self, multi_tracker):
        """Test closing all backends."""
        multi_tracker.close()
        
        for backend in multi_tracker.backends:
            if hasattr(backend, 'close'):
                backend.close.assert_called_once()


class TestMetricsAggregation:
    """Test metrics aggregation and statistics."""

    @pytest.fixture
    def metrics_aggregator(self):
        """Create metrics aggregator."""
        from rl_llm_toolkit.tracking.tracker import MetricsAggregator
        return MetricsAggregator()

    def test_add_metric(self, metrics_aggregator):
        """Test adding metric."""
        metrics_aggregator.add("reward", 10.5)
        metrics_aggregator.add("reward", 11.0)
        metrics_aggregator.add("reward", 9.5)
        
        assert len(metrics_aggregator.get("reward")) == 3

    def test_compute_mean(self, metrics_aggregator):
        """Test computing mean."""
        metrics_aggregator.add("reward", 10.0)
        metrics_aggregator.add("reward", 20.0)
        
        mean = metrics_aggregator.mean("reward")
        assert mean == 15.0

    def test_compute_std(self, metrics_aggregator):
        """Test computing standard deviation."""
        metrics_aggregator.add("reward", 10.0)
        metrics_aggregator.add("reward", 20.0)
        
        std = metrics_aggregator.std("reward")
        assert std > 0

    def test_compute_min_max(self, metrics_aggregator):
        """Test computing min and max."""
        values = [10.0, 15.0, 20.0, 5.0]
        for v in values:
            metrics_aggregator.add("reward", v)
        
        assert metrics_aggregator.min("reward") == 5.0
        assert metrics_aggregator.max("reward") == 20.0

    def test_compute_percentiles(self, metrics_aggregator):
        """Test computing percentiles."""
        values = list(range(100))
        for v in values:
            metrics_aggregator.add("reward", v)
        
        p50 = metrics_aggregator.percentile("reward", 50)
        assert 45 <= p50 <= 55

    def test_reset_metrics(self, metrics_aggregator):
        """Test resetting metrics."""
        metrics_aggregator.add("reward", 10.0)
        metrics_aggregator.reset()
        
        assert len(metrics_aggregator.get("reward")) == 0


class TestTrackingEdgeCases:
    """Test edge cases and error handling."""

    def test_log_nan_value(self):
        """Test logging NaN value."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        # Should handle NaN gracefully
        try:
            tracker.log_scalar("reward", float('nan'), step=100)
        except ValueError:
            pass  # Expected

    def test_log_inf_value(self):
        """Test logging infinity value."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        # Should handle infinity gracefully
        try:
            tracker.log_scalar("reward", float('inf'), step=100)
        except ValueError:
            pass  # Expected

    def test_log_negative_step(self):
        """Test logging with negative step."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        with pytest.raises(ValueError):
            tracker.log_scalar("reward", 10.0, step=-1)

    def test_log_empty_metric_name(self):
        """Test logging with empty metric name."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        with pytest.raises(ValueError):
            tracker.log_scalar("", 10.0, step=100)

    def test_backend_failure_handling(self):
        """Test handling backend failures."""
        from rl_llm_toolkit.tracking.tracker import MultiBackendTracker
        
        failing_backend = Mock()
        failing_backend.log_scalar = Mock(side_effect=Exception("Backend error"))
        
        working_backend = Mock()
        
        tracker = MultiBackendTracker(backends=[failing_backend, working_backend])
        
        # Should continue with working backend
        tracker.log_scalar("reward", 10.0, step=100)
        
        working_backend.log_scalar.assert_called_once()

    def test_concurrent_logging(self):
        """Test concurrent logging from multiple threads."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        import threading
        
        tracker = Tracker()
        
        def log_metrics():
            for i in range(10):
                tracker.log_scalar("reward", i, step=i)
        
        threads = [threading.Thread(target=log_metrics) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # Should handle concurrent access
        assert len(tracker.metrics) > 0


class TestTrackingIntegration:
    """Test tracking integration with training."""

    def test_track_training_episode(self):
        """Test tracking complete training episode."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        # Simulate episode
        episode_reward = 0
        for step in range(100):
            reward = 1.0
            episode_reward += reward
            
            tracker.log_scalar("step_reward", reward, step=step)
        
        tracker.log_scalar("episode_reward", episode_reward, step=0)
        
        assert len(tracker.metrics) > 0

    def test_track_hyperparameters(self):
        """Test tracking hyperparameters."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        hyperparameters = {
            'learning_rate': 0.001,
            'gamma': 0.99,
            'batch_size': 64,
            'n_epochs': 10
        }
        
        tracker.log_config(hyperparameters)
        
        assert hasattr(tracker, 'config')

    def test_track_model_checkpoints(self):
        """Test tracking model checkpoints."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        tracker = Tracker()
        
        checkpoint_path = "/path/to/checkpoint.pt"
        tracker.log_artifact(checkpoint_path, type="model")
        
        assert hasattr(tracker, 'artifacts')

    def test_export_metrics(self):
        """Test exporting metrics to file."""
        from rl_llm_toolkit.tracking.tracker import Tracker
        import json
        import tempfile
        
        tracker = Tracker()
        
        for i in range(10):
            tracker.log_scalar("reward", i * 10, step=i)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            metrics = tracker.export_metrics()
            json.dump(metrics, f)
            
        assert len(metrics) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
