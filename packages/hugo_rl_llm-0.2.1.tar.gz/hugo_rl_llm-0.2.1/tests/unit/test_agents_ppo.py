"""
Unit tests for PPO Agent.
Tests training, prediction, save/load with mocked environments.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import numpy as np
import torch


class TestPPOAgent:
    """Comprehensive tests for PPO Agent class."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock()
        env.observation_space.shape = (4,)
        env.action_space = Mock()
        env.action_space.n = 2
        env.reset = Mock(return_value=(np.array([0.1, 0.2, 0.3, 0.4]), {}))
        env.step = Mock(return_value=(
            np.array([0.2, 0.3, 0.4, 0.5]),
            1.0,
            False,
            False,
            {}
        ))
        return env

    @pytest.fixture
    def ppo_agent(self, mock_env):
        """Create PPO agent with mocked environment."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        return PPOAgent(
            env=mock_env,
            learning_rate=3e-4,
            gamma=0.99,
            clip_epsilon=0.2
        )

    def test_initialization(self, ppo_agent):
        """Test PPO agent initialization."""
        assert ppo_agent is not None
        assert ppo_agent.learning_rate == 3e-4
        assert ppo_agent.gamma == 0.99
        assert ppo_agent.clip_epsilon == 0.2

    def test_policy_network_creation(self, ppo_agent):
        """Test policy network is created."""
        assert hasattr(ppo_agent, 'policy')
        assert ppo_agent.policy is not None

    def test_value_network_creation(self, ppo_agent):
        """Test value network is created."""
        assert hasattr(ppo_agent, 'value_network')
        assert ppo_agent.value_network is not None

    def test_optimizer_creation(self, ppo_agent):
        """Test optimizer is created."""
        assert hasattr(ppo_agent, 'optimizer')
        assert ppo_agent.optimizer is not None

    def test_predict_action(self, ppo_agent):
        """Test action prediction."""
        observation = np.array([0.1, 0.2, 0.3, 0.4])
        action = ppo_agent.predict(observation)
        
        assert action is not None
        assert isinstance(action, (int, np.integer))

    def test_predict_deterministic(self, ppo_agent):
        """Test deterministic action prediction."""
        observation = np.array([0.1, 0.2, 0.3, 0.4])
        
        action1 = ppo_agent.predict(observation, deterministic=True)
        action2 = ppo_agent.predict(observation, deterministic=True)
        
        # Should be same action
        assert action1 == action2

    def test_predict_stochastic(self, ppo_agent):
        """Test stochastic action prediction."""
        observation = np.array([0.1, 0.2, 0.3, 0.4])
        
        actions = [ppo_agent.predict(observation, deterministic=False) for _ in range(10)]
        
        # Should have some variation (probabilistic)
        assert len(set(actions)) > 1 or len(actions) == 10

    def test_compute_advantages(self, ppo_agent):
        """Test advantage computation."""
        rewards = [1.0, 0.5, 1.0, 0.0, 1.0]
        values = [0.8, 0.6, 0.9, 0.1, 0.8]
        dones = [False, False, False, False, True]
        
        advantages = ppo_agent.compute_advantages(rewards, values, dones)
        
        assert len(advantages) == len(rewards)
        assert all(isinstance(adv, (float, np.floating)) for adv in advantages)

    def test_compute_returns(self, ppo_agent):
        """Test return computation."""
        rewards = [1.0, 0.5, 1.0, 0.0, 1.0]
        dones = [False, False, False, False, True]
        
        returns = ppo_agent.compute_returns(rewards, dones)
        
        assert len(returns) == len(rewards)
        assert all(isinstance(ret, (float, np.floating)) for ret in returns)

    def test_update_policy(self, ppo_agent):
        """Test policy update."""
        # Collect some fake experience
        states = [np.random.randn(4) for _ in range(10)]
        actions = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        rewards = [1.0] * 10
        dones = [False] * 9 + [True]
        
        # Update policy
        loss = ppo_agent.update(states, actions, rewards, dones)
        
        assert loss is not None
        assert isinstance(loss, (float, np.floating))

    def test_clipped_surrogate_loss(self, ppo_agent):
        """Test PPO clipped surrogate loss."""
        old_log_probs = torch.tensor([0.5, 0.3, 0.7])
        new_log_probs = torch.tensor([0.6, 0.4, 0.8])
        advantages = torch.tensor([1.0, -0.5, 0.8])
        
        loss = ppo_agent.compute_ppo_loss(old_log_probs, new_log_probs, advantages)
        
        assert loss is not None
        assert isinstance(loss, torch.Tensor)

    def test_value_loss(self, ppo_agent):
        """Test value function loss."""
        predicted_values = torch.tensor([0.8, 0.6, 0.9])
        target_values = torch.tensor([1.0, 0.5, 1.0])
        
        loss = ppo_agent.compute_value_loss(predicted_values, target_values)
        
        assert loss is not None
        assert isinstance(loss, torch.Tensor)

    def test_entropy_bonus(self, ppo_agent):
        """Test entropy bonus computation."""
        action_probs = torch.tensor([[0.5, 0.5], [0.7, 0.3], [0.6, 0.4]])
        
        entropy = ppo_agent.compute_entropy(action_probs)
        
        assert entropy is not None
        assert isinstance(entropy, torch.Tensor)


class TestPPOTraining:
    """Test PPO training functionality."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        env.reset = Mock(return_value=(np.random.randn(4), {}))
        env.step = Mock(return_value=(
            np.random.randn(4),
            1.0,
            False,
            False,
            {}
        ))
        return env

    @pytest.fixture
    def ppo_agent(self, mock_env):
        """Create PPO agent."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        return PPOAgent(env=mock_env)

    def test_train_single_episode(self, ppo_agent, mock_env):
        """Test training for single episode."""
        initial_params = [p.clone() for p in ppo_agent.policy.parameters()]
        
        ppo_agent.train(total_timesteps=100)
        
        # Parameters should have changed
        final_params = list(ppo_agent.policy.parameters())
        assert any(not torch.equal(i, f) for i, f in zip(initial_params, final_params))

    def test_train_multiple_episodes(self, ppo_agent, mock_env):
        """Test training for multiple episodes."""
        # Mock episode termination
        step_count = [0]
        def mock_step(action):
            step_count[0] += 1
            done = step_count[0] % 20 == 0
            return np.random.randn(4), 1.0, done, False, {}
        
        mock_env.step = mock_step
        
        ppo_agent.train(total_timesteps=100)
        
        # Should have completed multiple episodes
        assert step_count[0] >= 100

    def test_training_with_callback(self, ppo_agent):
        """Test training with callback function."""
        callback_called = [False]
        
        def callback(episode, reward):
            callback_called[0] = True
        
        ppo_agent.train(total_timesteps=50, callback=callback)
        
        assert callback_called[0] is True

    def test_training_metrics_tracking(self, ppo_agent):
        """Test training metrics are tracked."""
        ppo_agent.train(total_timesteps=100)
        
        assert hasattr(ppo_agent, 'training_metrics')
        assert len(ppo_agent.training_metrics) > 0

    def test_early_stopping(self, ppo_agent):
        """Test early stopping on convergence."""
        ppo_agent.train(
            total_timesteps=1000,
            early_stopping=True,
            target_reward=100.0
        )
        
        # Should stop early if target reached
        assert ppo_agent.total_steps <= 1000


class TestPPOSaveLoad:
    """Test PPO save and load functionality."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        return env

    @pytest.fixture
    def ppo_agent(self, mock_env):
        """Create PPO agent."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        return PPOAgent(env=mock_env)

    def test_save_agent(self, ppo_agent, tmp_path):
        """Test saving agent."""
        save_path = tmp_path / "ppo_agent.pt"
        ppo_agent.save(str(save_path))
        
        assert save_path.exists()

    def test_load_agent(self, ppo_agent, tmp_path):
        """Test loading agent."""
        save_path = tmp_path / "ppo_agent.pt"
        
        # Save first
        ppo_agent.save(str(save_path))
        
        # Load
        loaded_agent = ppo_agent.load(str(save_path))
        
        assert loaded_agent is not None

    def test_save_load_preserves_weights(self, ppo_agent, tmp_path):
        """Test save/load preserves network weights."""
        save_path = tmp_path / "ppo_agent.pt"
        
        # Get original weights
        original_weights = [p.clone() for p in ppo_agent.policy.parameters()]
        
        # Save and load
        ppo_agent.save(str(save_path))
        ppo_agent.load(str(save_path))
        
        # Weights should be same
        loaded_weights = list(ppo_agent.policy.parameters())
        assert all(torch.equal(o, l) for o, l in zip(original_weights, loaded_weights))

    def test_save_load_preserves_hyperparameters(self, ppo_agent, tmp_path):
        """Test save/load preserves hyperparameters."""
        save_path = tmp_path / "ppo_agent.pt"
        
        original_lr = ppo_agent.learning_rate
        original_gamma = ppo_agent.gamma
        
        ppo_agent.save(str(save_path))
        ppo_agent.load(str(save_path))
        
        assert ppo_agent.learning_rate == original_lr
        assert ppo_agent.gamma == original_gamma


class TestPPOEvaluation:
    """Test PPO evaluation functionality."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        env.reset = Mock(return_value=(np.random.randn(4), {}))
        env.step = Mock(return_value=(
            np.random.randn(4),
            1.0,
            False,
            False,
            {}
        ))
        return env

    @pytest.fixture
    def ppo_agent(self, mock_env):
        """Create PPO agent."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        return PPOAgent(env=mock_env)

    def test_evaluate_single_episode(self, ppo_agent, mock_env):
        """Test evaluation for single episode."""
        # Mock episode termination
        step_count = [0]
        def mock_step(action):
            step_count[0] += 1
            done = step_count[0] >= 20
            return np.random.randn(4), 1.0, done, False, {}
        
        mock_env.step = mock_step
        
        mean_reward, std_reward = ppo_agent.evaluate(n_episodes=1)
        
        assert mean_reward is not None
        assert isinstance(mean_reward, (float, np.floating))

    def test_evaluate_multiple_episodes(self, ppo_agent, mock_env):
        """Test evaluation for multiple episodes."""
        step_count = [0]
        def mock_step(action):
            step_count[0] += 1
            done = step_count[0] % 20 == 0
            return np.random.randn(4), 1.0, done, False, {}
        
        mock_env.step = mock_step
        
        mean_reward, std_reward = ppo_agent.evaluate(n_episodes=5)
        
        assert mean_reward is not None
        assert std_reward is not None

    def test_evaluate_deterministic(self, ppo_agent, mock_env):
        """Test deterministic evaluation."""
        step_count = [0]
        def mock_step(action):
            step_count[0] += 1
            done = step_count[0] % 20 == 0
            return np.random.randn(4), 1.0, done, False, {}
        
        mock_env.step = mock_step
        
        mean_reward, _ = ppo_agent.evaluate(n_episodes=3, deterministic=True)
        
        assert mean_reward is not None


class TestPPOHyperparameters:
    """Test PPO hyperparameter configurations."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        return env

    def test_custom_learning_rate(self, mock_env):
        """Test custom learning rate."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env, learning_rate=1e-3)
        assert agent.learning_rate == 1e-3

    def test_custom_gamma(self, mock_env):
        """Test custom discount factor."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env, gamma=0.95)
        assert agent.gamma == 0.95

    def test_custom_clip_epsilon(self, mock_env):
        """Test custom clip epsilon."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env, clip_epsilon=0.1)
        assert agent.clip_epsilon == 0.1

    def test_custom_batch_size(self, mock_env):
        """Test custom batch size."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env, batch_size=128)
        assert agent.batch_size == 128

    def test_custom_n_epochs(self, mock_env):
        """Test custom number of epochs."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env, n_epochs=5)
        assert agent.n_epochs == 5


class TestPPOEdgeCases:
    """Test edge cases and error handling."""

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        env.reset = Mock(return_value=(np.random.randn(4), {}))
        env.step = Mock(return_value=(
            np.random.randn(4),
            1.0,
            False,
            False,
            {}
        ))
        return env

    def test_zero_timesteps_training(self, mock_env):
        """Test training with zero timesteps."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        agent = PPOAgent(env=mock_env)
        agent.train(total_timesteps=0)
        
        # Should handle gracefully
        assert agent.total_steps == 0

    def test_invalid_learning_rate(self, mock_env):
        """Test invalid learning rate."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        with pytest.raises(ValueError):
            PPOAgent(env=mock_env, learning_rate=-0.001)

    def test_invalid_gamma(self, mock_env):
        """Test invalid gamma."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        
        with pytest.raises(ValueError):
            PPOAgent(env=mock_env, gamma=1.5)

    def test_nan_reward_handling(self, mock_env):
        """Test handling of NaN rewards."""
        mock_env.step = Mock(return_value=(
            np.random.randn(4),
            float('nan'),
            False,
            False,
            {}
        ))
        
        from rl_llm_toolkit.agents.ppo import PPOAgent
        agent = PPOAgent(env=mock_env)
        
        # Should handle NaN gracefully
        try:
            agent.train(total_timesteps=10)
        except ValueError:
            pass  # Expected


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
