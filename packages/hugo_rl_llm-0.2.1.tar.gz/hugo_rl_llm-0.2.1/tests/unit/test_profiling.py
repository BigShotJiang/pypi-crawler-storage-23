"""
Unit tests for Profiling modules.
Tests performance profiling, cost tracking, and bottleneck detection.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import time
import numpy as np


class TestPerformanceProfiler:
    """Test performance profiling functionality."""

    @pytest.fixture
    def profiler(self):
        """Create performance profiler."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        return PerformanceProfiler()

    def test_initialization(self, profiler):
        """Test profiler initialization."""
        assert profiler is not None

    def test_profile_function(self, profiler):
        """Test profiling a function."""
        @profiler.profile
        def test_function():
            time.sleep(0.01)
            return "result"
        
        result = test_function()
        
        assert result == "result"
        assert hasattr(profiler, 'timings')

    def test_profile_context_manager(self, profiler):
        """Test profiling with context manager."""
        with profiler.profile_section("test_section"):
            time.sleep(0.01)
        
        assert "test_section" in profiler.timings

    def test_get_timing_statistics(self, profiler):
        """Test getting timing statistics."""
        with profiler.profile_section("test"):
            time.sleep(0.01)
        
        stats = profiler.get_statistics("test")
        
        assert 'mean' in stats
        assert 'std' in stats
        assert 'min' in stats
        assert 'max' in stats

    def test_profile_multiple_calls(self, profiler):
        """Test profiling multiple calls."""
        @profiler.profile
        def test_function():
            time.sleep(0.001)
        
        for _ in range(10):
            test_function()
        
        stats = profiler.get_statistics("test_function")
        assert stats['count'] == 10

    def test_detect_bottlenecks(self, profiler):
        """Test bottleneck detection."""
        with profiler.profile_section("fast"):
            time.sleep(0.001)
        
        with profiler.profile_section("slow"):
            time.sleep(0.1)
        
        bottlenecks = profiler.detect_bottlenecks(threshold=0.05)
        
        assert "slow" in bottlenecks

    def test_export_profile_data(self, profiler):
        """Test exporting profile data."""
        with profiler.profile_section("test"):
            time.sleep(0.01)
        
        data = profiler.export_data()
        
        assert isinstance(data, dict)
        assert "test" in data

    def test_reset_profiler(self, profiler):
        """Test resetting profiler."""
        with profiler.profile_section("test"):
            time.sleep(0.01)
        
        profiler.reset()
        
        assert len(profiler.timings) == 0


class TestCostTracker:
    """Test LLM cost tracking."""

    @pytest.fixture
    def cost_tracker(self):
        """Create cost tracker."""
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        return CostTracker()

    def test_initialization(self, cost_tracker):
        """Test cost tracker initialization."""
        assert cost_tracker is not None

    def test_track_openai_call(self, cost_tracker):
        """Test tracking OpenAI API call."""
        cost_tracker.track_call(
            provider="openai",
            model="gpt-4",
            prompt_tokens=100,
            completion_tokens=50
        )
        
        total_cost = cost_tracker.get_total_cost()
        assert total_cost > 0

    def test_track_multiple_calls(self, cost_tracker):
        """Test tracking multiple calls."""
        for _ in range(5):
            cost_tracker.track_call(
                provider="openai",
                model="gpt-4",
                prompt_tokens=100,
                completion_tokens=50
            )
        
        call_count = cost_tracker.get_call_count()
        assert call_count == 5

    def test_cost_by_model(self, cost_tracker):
        """Test cost breakdown by model."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        cost_tracker.track_call("openai", "gpt-3.5-turbo", 100, 50)
        
        breakdown = cost_tracker.get_cost_breakdown()
        
        assert "gpt-4" in breakdown
        assert "gpt-3.5-turbo" in breakdown

    def test_cost_by_provider(self, cost_tracker):
        """Test cost breakdown by provider."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        cost_tracker.track_call("anthropic", "claude-2", 100, 50)
        
        breakdown = cost_tracker.get_provider_breakdown()
        
        assert "openai" in breakdown
        assert "anthropic" in breakdown

    def test_token_usage_statistics(self, cost_tracker):
        """Test token usage statistics."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        cost_tracker.track_call("openai", "gpt-4", 200, 75)
        
        stats = cost_tracker.get_token_statistics()
        
        assert stats['total_prompt_tokens'] == 300
        assert stats['total_completion_tokens'] == 125

    def test_cost_estimation(self, cost_tracker):
        """Test cost estimation."""
        estimated_cost = cost_tracker.estimate_cost(
            provider="openai",
            model="gpt-4",
            prompt_tokens=1000,
            completion_tokens=500
        )
        
        assert isinstance(estimated_cost, float)
        assert estimated_cost > 0

    def test_budget_tracking(self, cost_tracker):
        """Test budget tracking."""
        cost_tracker.set_budget(10.0)
        
        cost_tracker.track_call("openai", "gpt-4", 1000, 500)
        
        remaining = cost_tracker.get_remaining_budget()
        assert remaining < 10.0

    def test_budget_alert(self, cost_tracker):
        """Test budget alert."""
        cost_tracker.set_budget(1.0)
        
        # Track expensive calls
        for _ in range(100):
            cost_tracker.track_call("openai", "gpt-4", 1000, 500)
        
        is_over_budget = cost_tracker.is_over_budget()
        assert is_over_budget is True

    def test_export_cost_report(self, cost_tracker):
        """Test exporting cost report."""
        cost_tracker.track_call("openai", "gpt-4", 100, 50)
        
        report = cost_tracker.export_report()
        
        assert isinstance(report, dict)
        assert 'total_cost' in report
        assert 'breakdown' in report


class TestMemoryProfiler:
    """Test memory profiling."""

    @pytest.fixture
    def memory_profiler(self):
        """Create memory profiler."""
        from rl_llm_toolkit.profiling.profiler import MemoryProfiler
        return MemoryProfiler()

    def test_initialization(self, memory_profiler):
        """Test memory profiler initialization."""
        assert memory_profiler is not None

    def test_track_memory_usage(self, memory_profiler):
        """Test tracking memory usage."""
        memory_profiler.start_tracking()
        
        # Allocate some memory
        data = [np.random.randn(1000, 1000) for _ in range(10)]
        
        memory_profiler.stop_tracking()
        
        usage = memory_profiler.get_peak_memory()
        assert usage > 0

    def test_detect_memory_leaks(self, memory_profiler):
        """Test memory leak detection."""
        memory_profiler.start_tracking()
        
        # Simulate potential leak
        leaked_data = []
        for _ in range(100):
            leaked_data.append(np.random.randn(100, 100))
        
        memory_profiler.stop_tracking()
        
        has_leak = memory_profiler.detect_leak()
        assert isinstance(has_leak, bool)

    def test_memory_snapshot(self, memory_profiler):
        """Test memory snapshot."""
        snapshot = memory_profiler.take_snapshot()
        
        assert isinstance(snapshot, dict)
        assert 'total' in snapshot or 'used' in snapshot


class TestBottleneckDetector:
    """Test bottleneck detection."""

    @pytest.fixture
    def detector(self):
        """Create bottleneck detector."""
        from rl_llm_toolkit.profiling.profiler import BottleneckDetector
        return BottleneckDetector()

    def test_initialization(self, detector):
        """Test detector initialization."""
        assert detector is not None

    def test_detect_slow_functions(self, detector):
        """Test detecting slow functions."""
        timings = {
            'fast_function': [0.001, 0.002, 0.001],
            'slow_function': [0.1, 0.15, 0.12],
            'medium_function': [0.01, 0.02, 0.015]
        }
        
        bottlenecks = detector.detect_bottlenecks(timings, threshold=0.05)
        
        assert 'slow_function' in bottlenecks
        assert 'fast_function' not in bottlenecks

    def test_suggest_optimizations(self, detector):
        """Test optimization suggestions."""
        timings = {
            'slow_function': [0.1, 0.15, 0.12]
        }
        
        suggestions = detector.suggest_optimizations(timings)
        
        assert isinstance(suggestions, list)
        assert len(suggestions) > 0

    def test_compare_profiles(self, detector):
        """Test comparing two profiles."""
        profile1 = {
            'function_a': [0.1, 0.1, 0.1]
        }
        profile2 = {
            'function_a': [0.05, 0.05, 0.05]
        }
        
        comparison = detector.compare_profiles(profile1, profile2)
        
        assert isinstance(comparison, dict)
        assert 'improvements' in comparison or 'regressions' in comparison


class TestProfilingIntegration:
    """Test profiling integration with training."""

    def test_profile_training_loop(self):
        """Test profiling complete training loop."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        with profiler.profile_section("training"):
            # Simulate training
            for episode in range(10):
                with profiler.profile_section("episode"):
                    # Simulate episode
                    time.sleep(0.001)
        
        stats = profiler.get_statistics("episode")
        assert stats['count'] == 10

    def test_profile_with_cost_tracking(self):
        """Test profiling with cost tracking."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        
        profiler = PerformanceProfiler()
        cost_tracker = CostTracker()
        
        with profiler.profile_section("llm_calls"):
            for _ in range(5):
                cost_tracker.track_call("openai", "gpt-4", 100, 50)
                time.sleep(0.001)
        
        timing_stats = profiler.get_statistics("llm_calls")
        cost_stats = cost_tracker.get_total_cost()
        
        assert timing_stats['count'] == 1
        assert cost_stats > 0

    def test_export_combined_report(self):
        """Test exporting combined profiling report."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        
        profiler = PerformanceProfiler()
        cost_tracker = CostTracker()
        
        # Collect data
        with profiler.profile_section("test"):
            cost_tracker.track_call("openai", "gpt-4", 100, 50)
            time.sleep(0.01)
        
        # Export combined report
        report = {
            'performance': profiler.export_data(),
            'costs': cost_tracker.export_report()
        }
        
        assert 'performance' in report
        assert 'costs' in report


class TestProfilingEdgeCases:
    """Test profiling edge cases."""

    def test_profile_zero_time_function(self):
        """Test profiling instant function."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        @profiler.profile
        def instant_function():
            return "instant"
        
        instant_function()
        
        stats = profiler.get_statistics("instant_function")
        assert stats['mean'] >= 0

    def test_profile_recursive_function(self):
        """Test profiling recursive function."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        @profiler.profile
        def recursive_function(n):
            if n <= 0:
                return 1
            return n * recursive_function(n - 1)
        
        recursive_function(5)
        
        # Should track all calls
        stats = profiler.get_statistics("recursive_function")
        assert stats['count'] >= 1

    def test_profile_exception_handling(self):
        """Test profiling with exceptions."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        @profiler.profile
        def failing_function():
            raise ValueError("Test error")
        
        try:
            failing_function()
        except ValueError:
            pass
        
        # Should still record timing
        stats = profiler.get_statistics("failing_function")
        assert stats['count'] == 1

    def test_concurrent_profiling(self):
        """Test concurrent profiling."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        import threading
        
        profiler = PerformanceProfiler()
        
        def worker():
            with profiler.profile_section("worker"):
                time.sleep(0.001)
        
        threads = [threading.Thread(target=worker) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        stats = profiler.get_statistics("worker")
        assert stats['count'] >= 5

    def test_nested_profiling(self):
        """Test nested profiling sections."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        with profiler.profile_section("outer"):
            time.sleep(0.001)
            with profiler.profile_section("inner"):
                time.sleep(0.001)
        
        outer_stats = profiler.get_statistics("outer")
        inner_stats = profiler.get_statistics("inner")
        
        assert outer_stats['mean'] > inner_stats['mean']

    def test_profile_with_very_large_data(self):
        """Test profiling with large data structures."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        with profiler.profile_section("large_data"):
            large_array = np.random.randn(10000, 10000)
            result = np.sum(large_array)
        
        stats = profiler.get_statistics("large_data")
        assert stats['mean'] > 0


class TestProfilingVisualization:
    """Test profiling visualization."""

    def test_generate_flamegraph_data(self):
        """Test generating flamegraph data."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        with profiler.profile_section("outer"):
            with profiler.profile_section("inner1"):
                time.sleep(0.001)
            with profiler.profile_section("inner2"):
                time.sleep(0.001)
        
        flamegraph_data = profiler.generate_flamegraph_data()
        
        assert isinstance(flamegraph_data, (dict, list))

    def test_generate_timeline(self):
        """Test generating timeline visualization."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        for i in range(5):
            with profiler.profile_section(f"step_{i}"):
                time.sleep(0.001)
        
        timeline = profiler.generate_timeline()
        
        assert isinstance(timeline, (dict, list))

    def test_export_to_chrome_trace(self):
        """Test exporting to Chrome trace format."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        
        profiler = PerformanceProfiler()
        
        with profiler.profile_section("test"):
            time.sleep(0.001)
        
        trace_data = profiler.export_chrome_trace()
        
        assert isinstance(trace_data, (dict, str))


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
