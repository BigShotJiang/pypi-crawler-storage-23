import os
import tempfile
import pytest
import yaml


def _write_temp_config(cfg: dict) -> str:
    temp_dir = tempfile.TemporaryDirectory()
    path = os.path.join(temp_dir.name, "config.yaml")
    with open(path, "w") as f:
        yaml.safe_dump(cfg, f)
    # Keep reference so dir isn't cleaned before consumer is done
    return path, temp_dir


@pytest.fixture()
def temp_config_file():
    cfg = {
        "env_name": "CartPole-v1",
        "algorithm": "ppo",
        "training": {
            "total_timesteps": 1000,
            "learning_rate": 3e-4,
            "batch_size": 32,
            "n_steps": 256,
            "n_epochs": 1,
            "seed": 42,
        },
        "experiment_name": "cli_test",
    }
    path, handle = _write_temp_config(cfg)
    yield path
    handle.cleanup()


@pytest.fixture()
def temp_invalid_config_file():
    """Config missing required env_name to trigger validation error."""
    cfg = {
        "algorithm": "ppo",
        "training": {
            "total_timesteps": 1000,
            "learning_rate": 3e-4,
            "batch_size": 32,
        },
        "experiment_name": "cli_test",
    }
    path, handle = _write_temp_config(cfg)
    yield path
    handle.cleanup()


@pytest.fixture()
def temp_unknown_algo_config_file():
    """Config with unsupported algorithm to test error handling."""
    cfg = {
        "env_name": "CartPole-v1",
        "algorithm": "unknown",
        "training": {
            "total_timesteps": 1000,
            "learning_rate": 3e-4,
            "batch_size": 32,
            "seed": 42,
        },
        "experiment_name": "cli_test",
    }
    path, handle = _write_temp_config(cfg)
    yield path
    handle.cleanup()
