"""
Integration tests for LLM reward shaping.
Tests complete workflow with LLM backends and agents.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
import numpy as np
import tempfile
from pathlib import Path


class TestLLMRewardShapingIntegration:
    """Test LLM reward shaping integration with agents."""

    @pytest.fixture
    def mock_llm_backend(self):
        """Create mock LLM backend."""
        backend = Mock()
        backend.generate = Mock(return_value="Reward: 0.8\nReasoning: Good action")
        return backend

    @pytest.fixture
    def mock_env(self):
        """Create mock environment."""
        env = Mock()
        env.observation_space = Mock(shape=(4,))
        env.action_space = Mock(n=2)
        env.reset = Mock(return_value=(np.array([0.1, 0.2, 0.3, 0.4]), {}))
        env.step = Mock(return_value=(
            np.array([0.2, 0.3, 0.4, 0.5]),
            1.0,
            False,
            False,
            {}
        ))
        return env

    def test_agent_with_llm_reward_shaping(self, mock_env, mock_llm_backend):
        """Test agent training with LLM reward shaping."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        
        # Create agent with LLM reward shaper
        agent = PPOAgent(env=mock_env)
        shaper = LLMRewardShaper(llm_backend=mock_llm_backend)
        
        # Train with shaped rewards
        for episode in range(5):
            obs, _ = mock_env.reset()
            done = False
            episode_reward = 0
            
            for step in range(10):
                action = agent.predict(obs)
                next_obs, base_reward, done, truncated, info = mock_env.step(action)
                
                # Shape reward with LLM
                shaped_reward = shaper.shape_reward(obs, action, base_reward)
                
                episode_reward += shaped_reward
                obs = next_obs
                
                if done:
                    break
        
        # Verify LLM was called
        assert mock_llm_backend.generate.called
        assert episode_reward > 0

    def test_llm_cost_tracking_during_training(self, mock_env, mock_llm_backend):
        """Test tracking LLM costs during training."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        
        agent = PPOAgent(env=mock_env)
        shaper = LLMRewardShaper(llm_backend=mock_llm_backend)
        cost_tracker = CostTracker()
        
        # Simulate training with cost tracking
        for episode in range(3):
            obs, _ = mock_env.reset()
            
            for step in range(5):
                action = agent.predict(obs)
                next_obs, base_reward, done, _, _ = mock_env.step(action)
                
                shaped_reward = shaper.shape_reward(obs, action, base_reward)
                
                # Track cost
                cost_tracker.track_call(
                    provider="openai",
                    model="gpt-4",
                    prompt_tokens=100,
                    completion_tokens=50
                )
                
                obs = next_obs
        
        # Verify costs tracked
        total_cost = cost_tracker.get_total_cost()
        assert total_cost > 0
        assert cost_tracker.get_call_count() == 15  # 3 episodes * 5 steps

    def test_llm_reward_caching(self, mock_env, mock_llm_backend):
        """Test LLM reward caching for efficiency."""
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        
        shaper = LLMRewardShaper(llm_backend=mock_llm_backend, enable_cache=True)
        
        state = np.array([0.1, 0.2, 0.3, 0.4])
        action = 1
        
        # First call
        reward1 = shaper.shape_reward(state, action, 1.0)
        
        # Second call with same state/action
        reward2 = shaper.shape_reward(state, action, 1.0)
        
        # Should use cache
        assert reward1 == reward2
        assert mock_llm_backend.generate.call_count == 1

    def test_fallback_on_llm_failure(self, mock_env):
        """Test fallback to base reward on LLM failure."""
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        
        failing_backend = Mock()
        failing_backend.generate = Mock(side_effect=Exception("LLM Error"))
        
        shaper = LLMRewardShaper(llm_backend=failing_backend, fallback_to_base=True)
        
        state = np.array([0.1, 0.2, 0.3, 0.4])
        action = 1
        base_reward = 1.0
        
        # Should fallback to base reward
        shaped_reward = shaper.shape_reward(state, action, base_reward)
        
        assert shaped_reward == base_reward


class TestMultiBackendIntegration:
    """Test integration with multiple LLM backends."""

    def test_switch_between_backends(self):
        """Test switching between OpenAI and Ollama."""
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        
        # Mock OpenAI
        openai_backend = Mock()
        openai_backend.generate = Mock(return_value="Reward: 0.9")
        
        # Mock Ollama
        ollama_backend = Mock()
        ollama_backend.generate = Mock(return_value="Reward: 0.7")
        
        # Use OpenAI
        shaper = LLMRewardShaper(llm_backend=openai_backend)
        reward1 = shaper.shape_reward([0.1], 0, 1.0)
        
        # Switch to Ollama
        shaper.set_backend(ollama_backend)
        reward2 = shaper.shape_reward([0.1], 0, 1.0)
        
        # Both should work
        assert reward1 is not None
        assert reward2 is not None

    def test_ensemble_backends(self):
        """Test ensemble of multiple LLM backends."""
        from rl_llm_toolkit.rewards.llm_shaper import EnsembleLLMShaper
        
        backend1 = Mock()
        backend1.generate = Mock(return_value="Reward: 0.8")
        
        backend2 = Mock()
        backend2.generate = Mock(return_value="Reward: 0.9")
        
        backend3 = Mock()
        backend3.generate = Mock(return_value="Reward: 0.7")
        
        # Create ensemble
        ensemble = EnsembleLLMShaper(backends=[backend1, backend2, backend3])
        
        # Should average responses
        reward = ensemble.shape_reward([0.1], 0, 1.0)
        
        # All backends called
        assert backend1.generate.called
        assert backend2.generate.called
        assert backend3.generate.called


class TestTrackingIntegration:
    """Test integration with tracking backends."""

    def test_track_llm_metrics(self):
        """Test tracking LLM metrics to TensorBoard."""
        from rl_llm_toolkit.tracking.backends import TensorBoardBackend
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        
        mock_writer = Mock()
        mock_llm = Mock()
        mock_llm.generate = Mock(return_value="Reward: 0.8")
        
        with patch('torch.utils.tensorboard.SummaryWriter', return_value=mock_writer):
            tracker = TensorBoardBackend(log_dir="./logs")
            shaper = LLMRewardShaper(llm_backend=mock_llm)
            
            # Shape rewards and track
            for step in range(10):
                reward = shaper.shape_reward([0.1], 0, 1.0)
                tracker.log_scalar("llm_shaped_reward", reward, step=step)
            
            # Verify tracking
            assert mock_writer.add_scalar.call_count == 10

    def test_track_to_multiple_backends(self):
        """Test tracking to multiple backends simultaneously."""
        from rl_llm_toolkit.tracking.tracker import MultiBackendTracker
        
        tb_backend = Mock()
        wandb_backend = Mock()
        mlflow_backend = Mock()
        
        tracker = MultiBackendTracker(backends=[tb_backend, wandb_backend, mlflow_backend])
        
        # Log metrics
        for step in range(5):
            tracker.log_scalar("reward", step * 10, step=step)
        
        # All backends should receive metrics
        assert tb_backend.log_scalar.call_count == 5
        assert wandb_backend.log_scalar.call_count == 5
        assert mlflow_backend.log_scalar.call_count == 5


class TestCheckpointIntegration:
    """Test integration with checkpoint system."""

    def test_save_load_with_llm_config(self, tmp_path):
        """Test saving and loading checkpoint with LLM config."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        
        manager = CheckpointManager(checkpoint_dir=str(tmp_path))
        
        # Save checkpoint with LLM config
        agent_state = {'policy': [1, 2, 3]}
        llm_config = {
            'backend': 'openai',
            'model': 'gpt-4',
            'temperature': 0.7
        }
        
        path = manager.save(
            agent_state=agent_state,
            episode=100,
            metadata={'llm_config': llm_config}
        )
        
        # Load and verify
        loaded = manager.load(path)
        
        assert loaded['metadata']['llm_config'] == llm_config

    def test_resume_training_with_llm(self, tmp_path):
        """Test resuming training with LLM reward shaping."""
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        
        manager = CheckpointManager(checkpoint_dir=str(tmp_path))
        
        # Save training state
        training_state = {
            'episode': 50,
            'total_steps': 5000,
            'llm_calls': 500,
            'llm_cost': 2.50
        }
        
        path = manager.save(
            agent_state={'policy': [1, 2, 3]},
            episode=50,
            metadata=training_state
        )
        
        # Resume
        resumed = manager.resume(path)
        
        assert resumed['episode'] == 50
        assert resumed['metadata']['llm_calls'] == 500


class TestReproducibilityIntegration:
    """Test reproducibility with LLM backends."""

    def test_reproducible_llm_responses(self):
        """Test reproducible LLM responses with seeding."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        
        repro = ReproducibilityManager()
        
        # Set seed
        repro.set_seed(42)
        
        # Mock deterministic LLM
        mock_llm = Mock()
        responses = ["Reward: 0.8", "Reward: 0.9", "Reward: 0.7"]
        mock_llm.generate = Mock(side_effect=responses)
        
        # First run
        repro.set_seed(42)
        results1 = []
        for _ in range(3):
            response = mock_llm.generate("prompt")
            results1.append(response)
        
        # Second run with same seed
        mock_llm.generate = Mock(side_effect=responses)
        repro.set_seed(42)
        results2 = []
        for _ in range(3):
            response = mock_llm.generate("prompt")
            results2.append(response)
        
        # Should be same
        assert results1 == results2

    def test_save_llm_metadata(self, tmp_path):
        """Test saving LLM metadata for reproducibility."""
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        
        repro = ReproducibilityManager()
        repro.set_seed(42)
        
        # Add LLM metadata
        llm_metadata = {
            'backend': 'openai',
            'model': 'gpt-4',
            'version': '0613',
            'temperature': 0.7,
            'total_calls': 100,
            'total_cost': 5.00
        }
        
        metadata = repro.create_metadata()
        metadata['llm'] = llm_metadata
        
        # Save
        metadata_path = tmp_path / "metadata.json"
        repro.save_metadata(str(metadata_path), custom_data=llm_metadata)
        
        # Load and verify
        loaded = repro.load_metadata(str(metadata_path))
        assert 'llm' in loaded or 'custom_data' in loaded


class TestSecurityIntegration:
    """Test security integration with LLM backends."""

    def test_sanitize_llm_prompts(self):
        """Test sanitizing prompts before sending to LLM."""
        from rl_llm_toolkit.security.sanitizer import PromptSanitizer
        
        sanitizer = PromptSanitizer()
        mock_llm = Mock()
        mock_llm.generate = Mock(return_value="Safe response")
        
        # Potentially malicious prompt
        unsafe_prompt = "Evaluate action && rm -rf /"
        
        # Should sanitize
        with pytest.raises(ValueError):
            sanitizer.sanitize(unsafe_prompt)

    def test_circuit_breaker_with_llm(self):
        """Test circuit breaker protecting LLM calls."""
        from rl_llm_toolkit.security.circuit_breaker import CircuitBreaker
        
        breaker = CircuitBreaker(failure_threshold=3)
        
        failing_llm = Mock()
        failing_llm.generate = Mock(side_effect=Exception("API Error"))
        
        # Fail multiple times
        for _ in range(3):
            try:
                breaker.call(lambda: failing_llm.generate("prompt"))
            except Exception:
                pass
        
        # Circuit should be open
        assert breaker.state == "open"

    def test_rate_limit_llm_calls(self):
        """Test rate limiting LLM API calls."""
        from rl_llm_toolkit.security.circuit_breaker import RateLimiter
        
        limiter = RateLimiter(max_calls=5, time_window=1.0)
        mock_llm = Mock()
        mock_llm.generate = Mock(return_value="Response")
        
        # Make calls
        successful_calls = 0
        for _ in range(10):
            if limiter.allow_request():
                mock_llm.generate("prompt")
                successful_calls += 1
        
        # Should limit to 5
        assert successful_calls == 5


class TestProfilingIntegration:
    """Test profiling integration with LLM backends."""

    def test_profile_llm_calls(self):
        """Test profiling LLM call performance."""
        from rl_llm_toolkit.profiling.profiler import PerformanceProfiler
        import time
        
        profiler = PerformanceProfiler()
        mock_llm = Mock()
        
        def slow_generate(prompt):
            time.sleep(0.01)
            return "Response"
        
        mock_llm.generate = slow_generate
        
        # Profile calls
        for _ in range(5):
            with profiler.profile_section("llm_generate"):
                mock_llm.generate("prompt")
        
        # Check stats
        stats = profiler.get_statistics("llm_generate")
        assert stats['count'] == 5
        assert stats['mean'] > 0.01

    def test_detect_llm_bottlenecks(self):
        """Test detecting LLM as bottleneck."""
        from rl_llm_toolkit.profiling.profiler import BottleneckDetector
        
        detector = BottleneckDetector()
        
        timings = {
            'agent_predict': [0.001, 0.001, 0.001],
            'llm_generate': [0.5, 0.6, 0.55],
            'env_step': [0.002, 0.002, 0.002]
        }
        
        bottlenecks = detector.detect_bottlenecks(timings, threshold=0.1)
        
        # LLM should be identified as bottleneck
        assert 'llm_generate' in bottlenecks


class TestEndToEndWorkflow:
    """Test complete end-to-end workflow."""

    def test_complete_training_workflow(self, tmp_path):
        """Test complete training workflow with all components."""
        from rl_llm_toolkit.agents.ppo import PPOAgent
        from rl_llm_toolkit.rewards.llm_shaper import LLMRewardShaper
        from rl_llm_toolkit.core.checkpoint import CheckpointManager
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        from rl_llm_toolkit.profiling.cost_tracker import CostTracker
        from rl_llm_toolkit.tracking.tracker import Tracker
        
        # Setup
        mock_env = Mock()
        mock_env.observation_space = Mock(shape=(4,))
        mock_env.action_space = Mock(n=2)
        mock_env.reset = Mock(return_value=(np.random.randn(4), {}))
        mock_env.step = Mock(return_value=(
            np.random.randn(4), 1.0, False, False, {}
        ))
        
        mock_llm = Mock()
        mock_llm.generate = Mock(return_value="Reward: 0.8")
        
        # Initialize components
        repro = ReproducibilityManager()
        repro.set_seed(42)
        
        agent = PPOAgent(env=mock_env)
        shaper = LLMRewardShaper(llm_backend=mock_llm)
        checkpoint_mgr = CheckpointManager(checkpoint_dir=str(tmp_path))
        cost_tracker = CostTracker()
        tracker = Tracker()
        
        # Training loop
        for episode in range(3):
            obs, _ = mock_env.reset()
            episode_reward = 0
            
            for step in range(5):
                action = agent.predict(obs)
                next_obs, base_reward, done, _, _ = mock_env.step(action)
                
                # Shape reward
                shaped_reward = shaper.shape_reward(obs, action, base_reward)
                
                # Track cost
                cost_tracker.track_call("openai", "gpt-4", 100, 50)
                
                # Track metrics
                tracker.log_scalar("reward", shaped_reward, step=episode * 5 + step)
                
                episode_reward += shaped_reward
                obs = next_obs
            
            # Save checkpoint
            if episode % 2 == 0:
                checkpoint_mgr.save(
                    agent_state={'policy': [1, 2, 3]},
                    episode=episode,
                    metadata={
                        'episode_reward': episode_reward,
                        'llm_cost': cost_tracker.get_total_cost()
                    }
                )
        
        # Verify all components worked
        assert cost_tracker.get_call_count() == 15
        assert len(checkpoint_mgr.list_checkpoints()) >= 2
        assert len(tracker.metrics) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
