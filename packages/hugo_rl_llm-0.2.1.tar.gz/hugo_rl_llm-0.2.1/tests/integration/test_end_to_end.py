"""
End-to-end integration tests for Hugo v0.2.0.

These tests verify that all production features work together correctly.
"""

import pytest
import tempfile
from pathlib import Path

from rl_llm_toolkit import PPOAgent, RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from rl_llm_toolkit.tracking import MetricsTracker, CSVBackend
from rl_llm_toolkit.profiling import ProfilerContext
from rl_llm_toolkit.evaluation import Evaluator, ReportGenerator, ReportFormat


class TestEndToEnd:
    """End-to-end integration tests."""
    
    def test_complete_training_workflow(self):
        """Test complete training workflow with all features."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            # 1. Setup reproducibility
            SEED = 42
            ReproducibilityManager.set_global_seed(SEED)
            
            config = {
                "env_name": "CartPole-v1",
                "algorithm": "ppo",
                "training": {"total_timesteps": 5000, "seed": SEED}
            }
            
            metadata = ReproducibilityManager.create_metadata(
                seed=SEED,
                config=config,
            )
            metadata.save(output_dir / "reproducibility.yaml")
            
            # 2. Setup tracking
            tracker = MetricsTracker(
                experiment_name="integration_test",
                output_dir=output_dir,
                backends=[CSVBackend(output_path=output_dir / "metrics.csv")]
            )
            
            # 3. Create environment and agent
            env = RLEnvironment("CartPole-v1")
            agent = PPOAgent(env=env, seed=SEED)
            
            # 4. Train with profiling
            with ProfilerContext.profile('training'):
                agent.train(total_timesteps=5000)
            
            # 5. Log metrics
            tracker.log_scalars({"final_step": 5000}, step=5000)
            
            # 6. Save checkpoint
            checkpoint_path = output_dir / "checkpoint.pt"
            CheckpointManager.save_checkpoint(
                path=checkpoint_path,
                agent_type="PPOAgent",
                model_state=agent.policy.state_dict(),
                total_timesteps=5000,
                reproducibility_metadata=metadata,
            )
            
            # 7. Evaluate
            evaluator = Evaluator()
            report = evaluator.evaluate(agent, env, num_episodes=5)
            
            # 8. Generate report
            ReportGenerator.generate(
                report,
                output_dir / "report.html",
                ReportFormat.HTML
            )
            
            # 9. Verify outputs
            assert (output_dir / "reproducibility.yaml").exists()
            assert (output_dir / "metrics.csv").exists()
            assert checkpoint_path.exists()
            assert (output_dir / "report.html").exists()
            
            # 10. Verify checkpoint can be loaded
            loaded = CheckpointManager.load_checkpoint(checkpoint_path)
            assert 'model_state' in loaded
            assert 'metadata' in loaded
            
            # 11. Verify profiling data
            profiler = ProfilerContext.get_profiler()
            summary = profiler.get_summary()
            assert 'training' in summary
            
            # Cleanup
            tracker.close()
            env.close()
    
    def test_reproducibility_workflow(self):
        """Test that runs are reproducible."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            SEED = 42
            
            # Run 1
            ReproducibilityManager.set_global_seed(SEED)
            env1 = RLEnvironment("CartPole-v1")
            agent1 = PPOAgent(env=env1, seed=SEED)
            agent1.train(total_timesteps=1000)
            results1 = agent1.evaluate(episodes=5, deterministic=True)
            env1.close()
            
            # Run 2 with same seed
            ReproducibilityManager.set_global_seed(SEED)
            env2 = RLEnvironment("CartPole-v1")
            agent2 = PPOAgent(env=env2, seed=SEED)
            agent2.train(total_timesteps=1000)
            results2 = agent2.evaluate(episodes=5, deterministic=True)
            env2.close()
            
            # Results should be very similar (allowing for small numerical differences)
            assert abs(results1['mean_reward'] - results2['mean_reward']) < 5.0
    
    def test_checkpoint_resume_workflow(self):
        """Test checkpoint save and resume."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            checkpoint_path = output_dir / "checkpoint.pt"
            
            SEED = 42
            ReproducibilityManager.set_global_seed(SEED)
            
            # Train for 2000 steps
            env = RLEnvironment("CartPole-v1")
            agent = PPOAgent(env=env, seed=SEED)
            agent.train(total_timesteps=2000)
            
            # Save checkpoint
            CheckpointManager.save_checkpoint(
                path=checkpoint_path,
                agent_type="PPOAgent",
                model_state=agent.policy.state_dict(),
                total_timesteps=2000,
            )
            
            initial_reward = agent.evaluate(episodes=5, deterministic=True)['mean_reward']
            env.close()
            
            # Load checkpoint and verify
            loaded = CheckpointManager.load_checkpoint(checkpoint_path)
            
            env2 = RLEnvironment("CartPole-v1")
            agent2 = PPOAgent(env=env2, seed=SEED)
            agent2.policy.load_state_dict(loaded['model_state'])
            
            loaded_reward = agent2.evaluate(episodes=5, deterministic=True)['mean_reward']
            
            # Rewards should be identical
            assert abs(initial_reward - loaded_reward) < 1.0
            
            env2.close()
    
    def test_tracking_workflow(self):
        """Test tracking across multiple backends."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            tracker = MetricsTracker(
                experiment_name="tracking_test",
                output_dir=output_dir,
                backends=[
                    CSVBackend(output_path=output_dir / "metrics.csv"),
                ]
            )
            
            # Log various metrics
            for step in range(10):
                tracker.log_scalars({
                    'loss': 0.5 - step * 0.01,
                    'reward': step * 10,
                }, step=step)
            
            # Export
            tracker.export_records('json')
            tracker.close()
            
            # Verify outputs
            assert (output_dir / "metrics.csv").exists()
            assert (output_dir / "tracking_test_records.json").exists()
    
    def test_evaluation_report_workflow(self):
        """Test evaluation report generation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            env = RLEnvironment("CartPole-v1")
            agent = PPOAgent(env=env, seed=42)
            agent.train(total_timesteps=5000)
            
            evaluator = Evaluator()
            report = evaluator.evaluate(agent, env, num_episodes=10)
            
            # Generate all formats
            ReportGenerator.generate(report, output_dir / "report.html", ReportFormat.HTML)
            ReportGenerator.generate(report, output_dir / "report.json", ReportFormat.JSON)
            ReportGenerator.generate(report, output_dir / "report.md", ReportFormat.MARKDOWN)
            ReportGenerator.generate(report, output_dir / "report.csv", ReportFormat.CSV)
            
            # Verify all generated
            assert (output_dir / "report.html").exists()
            assert (output_dir / "report.json").exists()
            assert (output_dir / "report.md").exists()
            assert (output_dir / "report.csv").exists()
            
            env.close()


class TestProductionFeatures:
    """Test production-specific features."""
    
    def test_profiling_integration(self):
        """Test profiling integration."""
        ProfilerContext.reset()
        
        with ProfilerContext.profile('test_section'):
            import time
            time.sleep(0.01)
        
        profiler = ProfilerContext.get_profiler()
        summary = profiler.get_summary()
        
        assert 'test_section' in summary
        assert summary['test_section']['count'] == 1
        assert summary['test_section']['total'] >= 0.01
    
    def test_metadata_persistence(self):
        """Test reproducibility metadata persistence."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            config = {"env": "CartPole-v1"}
            
            metadata = ReproducibilityManager.create_metadata(
                seed=42,
                config=config,
            )
            
            metadata.save(output_dir / "metadata.yaml")
            
            loaded = ReproducibilityManager.load_metadata(
                output_dir / "metadata.yaml"
            )
            
            assert loaded.seed == 42
            assert loaded.resolved_config == config


@pytest.mark.slow
class TestLongRunning:
    """Long-running integration tests."""
    
    def test_extended_training(self):
        """Test extended training session."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            
            env = RLEnvironment("CartPole-v1")
            agent = PPOAgent(env=env, seed=42)
            
            # Train for longer
            agent.train(total_timesteps=20000)
            
            # Should achieve reasonable performance
            results = agent.evaluate(episodes=20, deterministic=True)
            
            assert results['mean_reward'] > 50.0
            
            env.close()
