# Integration tests for Hugo v0.2.0
