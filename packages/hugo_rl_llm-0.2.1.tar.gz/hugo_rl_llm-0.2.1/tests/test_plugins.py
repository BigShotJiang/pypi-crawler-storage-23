import pytest
from unittest.mock import Mock

from rl_llm_toolkit.plugins.base import (
    BasePlugin,
    AgentPlugin,
    RewardBackendPlugin,
    EnvPlugin,
    CallbackPlugin,
    PluginMetadata,
    PluginCapability,
    PluginType,
)
from rl_llm_toolkit.plugins.discovery import PluginManager
from rl_llm_toolkit.core.exceptions import PluginError


class TestPluginCapability:
    def test_capability_creation(self):
        cap = PluginCapability(
            online=True,
            offline=False,
            single_agent=True,
            multi_agent=False,
            continuous=True,
            discrete=True,
            requires_llm=False,
            supports_cache=True,
            gpu_required=False,
        )
        
        assert cap.online is True
        assert cap.offline is False
        assert cap.supports_cache is True
    
    def test_capability_to_dict(self):
        cap = PluginCapability(online=True, offline=False)
        
        data = cap.to_dict()
        
        assert isinstance(data, dict)
        assert 'online' in data
        assert 'offline' in data


class TestPluginMetadata:
    def test_metadata_creation(self):
        cap = PluginCapability()
        
        metadata = PluginMetadata(
            name="TestPlugin",
            version="1.0.0",
            author="Test Author",
            description="Test plugin",
            plugin_type=PluginType.AGENT,
            capabilities=cap,
            dependencies=["numpy", "torch"],
        )
        
        assert metadata.name == "TestPlugin"
        assert metadata.version == "1.0.0"
        assert metadata.plugin_type == PluginType.AGENT
        assert len(metadata.dependencies) == 2
    
    def test_metadata_to_dict(self):
        cap = PluginCapability()
        
        metadata = PluginMetadata(
            name="TestPlugin",
            version="1.0.0",
            author="Test",
            description="Test",
            plugin_type=PluginType.AGENT,
            capabilities=cap,
            dependencies=[],
        )
        
        data = metadata.to_dict()
        
        assert data['name'] == "TestPlugin"
        assert data['plugin_type'] == "agent"
        assert 'capabilities' in data


class MockAgentPlugin(AgentPlugin):
    def get_metadata(self):
        return PluginMetadata(
            name="MockAgent",
            version="1.0.0",
            author="Test",
            description="Mock agent plugin",
            plugin_type=PluginType.AGENT,
            capabilities=PluginCapability(),
            dependencies=[],
        )
    
    def initialize(self, config=None):
        self.config = config
    
    def validate(self):
        return True
    
    def create_agent(self, **kwargs):
        return Mock()


class TestPluginManager:
    def test_register_plugin(self):
        PluginManager._plugins = {
            'hugo.agents': {},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        
        PluginManager.register_plugin(
            'hugo.agents',
            'mock_agent',
            MockAgentPlugin
        )
        
        assert 'mock_agent' in PluginManager._plugins['hugo.agents']
    
    def test_get_plugin(self):
        PluginManager._plugins = {
            'hugo.agents': {'mock': MockAgentPlugin},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        
        plugin_class = PluginManager.get_plugin('hugo.agents', 'mock')
        
        assert plugin_class == MockAgentPlugin
    
    def test_list_plugins(self):
        PluginManager._plugins = {
            'hugo.agents': {'agent1': MockAgentPlugin, 'agent2': MockAgentPlugin},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        
        plugins = PluginManager.list_plugins('hugo.agents')
        
        assert 'hugo.agents' in plugins
        assert len(plugins['hugo.agents']) == 2
    
    def test_initialize_plugin(self):
        PluginManager._plugins = {
            'hugo.agents': {'mock': MockAgentPlugin},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        PluginManager._initialized_plugins = {}
        
        plugin = PluginManager.initialize_plugin(
            'hugo.agents',
            'mock',
            config={'key': 'value'}
        )
        
        assert isinstance(plugin, MockAgentPlugin)
        assert plugin.config == {'key': 'value'}
    
    def test_validate_plugin(self):
        PluginManager._plugins = {
            'hugo.agents': {'mock': MockAgentPlugin},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        
        is_valid, error = PluginManager.validate_plugin('hugo.agents', 'mock')
        
        assert is_valid is True
        assert error is None
    
    def test_invalid_namespace(self):
        with pytest.raises(PluginError):
            PluginManager.register_plugin(
                'invalid.namespace',
                'plugin',
                MockAgentPlugin
            )
    
    def test_plugin_not_found(self):
        PluginManager._plugins = {
            'hugo.agents': {},
            'hugo.reward_backends': {},
            'hugo.envs': {},
            'hugo.callbacks': {},
        }
        
        with pytest.raises(PluginError):
            PluginManager.initialize_plugin('hugo.agents', 'nonexistent')


class TestBasePlugin:
    def test_base_plugin_abstract(self):
        with pytest.raises(TypeError):
            BasePlugin()


class TestAgentPlugin:
    def test_agent_plugin_creation(self):
        plugin = MockAgentPlugin()
        
        metadata = plugin.get_metadata()
        assert metadata.plugin_type == PluginType.AGENT
        
        plugin.initialize()
        assert plugin.validate()
        
        agent = plugin.create_agent()
        assert agent is not None
