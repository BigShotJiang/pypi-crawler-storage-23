import pytest
import tempfile
from pathlib import Path
from unittest.mock import Mock, MagicMock

import numpy as np

from rl_llm_toolkit.evaluation.evaluator import Evaluator, EvaluationReport, EpisodeResult
from rl_llm_toolkit.evaluation.report_generator import ReportGenerator, ReportFormat


class TestEvaluator:
    def test_basic_evaluation(self):
        agent = Mock()
        agent.predict = Mock(return_value=(0, None))
        
        env = Mock()
        env.reset = Mock(return_value=(np.array([0.0]), {}))
        env.step = Mock(return_value=(
            np.array([0.0]),
            1.0,
            True,
            False,
            {}
        ))
        env.render = Mock()
        
        evaluator = Evaluator(deterministic=True, render=False)
        
        report = evaluator.evaluate(
            agent=agent,
            env=env,
            num_episodes=5,
        )
        
        assert isinstance(report, EvaluationReport)
        assert report.num_episodes == 5
        assert len(report.episode_results) == 5
    
    def test_evaluation_with_success_threshold(self):
        agent = Mock()
        agent.predict = Mock(return_value=(0, None))
        
        env = Mock()
        env.reset = Mock(return_value=(np.array([0.0]), {}))
        env.step = Mock(return_value=(
            np.array([0.0]),
            10.0,
            True,
            False,
            {}
        ))
        
        evaluator = Evaluator()
        
        report = evaluator.evaluate(
            agent=agent,
            env=env,
            num_episodes=3,
            success_threshold=5.0,
        )
        
        assert all(ep.success for ep in report.episode_results)
        assert report.success_rate == 1.0
    
    def test_evaluation_metrics(self):
        agent = Mock()
        agent.predict = Mock(return_value=(0, None))
        
        rewards = [10.0, 20.0, 15.0, 25.0, 18.0]
        step_count = [0]
        
        def step_side_effect(*args):
            reward = rewards[step_count[0] % len(rewards)]
            step_count[0] += 1
            return (np.array([0.0]), reward, True, False, {})
        
        env = Mock()
        env.reset = Mock(return_value=(np.array([0.0]), {}))
        env.step = Mock(side_effect=step_side_effect)
        
        evaluator = Evaluator()
        
        report = evaluator.evaluate(
            agent=agent,
            env=env,
            num_episodes=5,
        )
        
        assert report.mean_reward == np.mean(rewards)
        assert report.min_reward == min(rewards)
        assert report.max_reward == max(rewards)
        assert report.median_reward == np.median(rewards)


class TestEpisodeResult:
    def test_episode_result_creation(self):
        result = EpisodeResult(
            episode_id=0,
            total_reward=100.0,
            episode_length=50,
            success=True,
            metadata={'info': 'test'}
        )
        
        assert result.episode_id == 0
        assert result.total_reward == 100.0
        assert result.episode_length == 50
        assert result.success is True
        assert result.metadata['info'] == 'test'


class TestEvaluationReport:
    def test_report_to_dict(self):
        episode_results = [
            EpisodeResult(0, 10.0, 5, True),
            EpisodeResult(1, 20.0, 10, True),
        ]
        
        report = EvaluationReport(
            agent_type="PPOAgent",
            env_name="CartPole-v1",
            num_episodes=2,
            timestamp="2024-01-01T00:00:00",
            mean_reward=15.0,
            std_reward=5.0,
            min_reward=10.0,
            max_reward=20.0,
            median_reward=15.0,
            mean_length=7.5,
            std_length=2.5,
            success_rate=1.0,
            episode_results=episode_results,
        )
        
        data = report.to_dict()
        
        assert data['agent_type'] == "PPOAgent"
        assert data['env_name'] == "CartPole-v1"
        assert data['num_episodes'] == 2
        assert data['metrics']['mean_reward'] == 15.0
        assert len(data['episode_results']) == 2


class TestReportGenerator:
    def test_generate_json_report(self):
        episode_results = [
            EpisodeResult(0, 10.0, 5, True),
        ]
        
        report = EvaluationReport(
            agent_type="PPOAgent",
            env_name="CartPole-v1",
            num_episodes=1,
            timestamp="2024-01-01T00:00:00",
            mean_reward=10.0,
            std_reward=0.0,
            min_reward=10.0,
            max_reward=10.0,
            median_reward=10.0,
            mean_length=5.0,
            std_length=0.0,
            success_rate=1.0,
            episode_results=episode_results,
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "report.json"
            
            ReportGenerator.generate(
                report=report,
                output_path=output_path,
                format=ReportFormat.JSON,
            )
            
            assert output_path.exists()
            
            import json
            with open(output_path, 'r') as f:
                data = json.load(f)
            
            assert data['agent_type'] == "PPOAgent"
    
    def test_generate_html_report(self):
        episode_results = [
            EpisodeResult(0, 10.0, 5, True),
        ]
        
        report = EvaluationReport(
            agent_type="PPOAgent",
            env_name="CartPole-v1",
            num_episodes=1,
            timestamp="2024-01-01T00:00:00",
            mean_reward=10.0,
            std_reward=0.0,
            min_reward=10.0,
            max_reward=10.0,
            median_reward=10.0,
            mean_length=5.0,
            std_length=0.0,
            success_rate=1.0,
            episode_results=episode_results,
            percentiles={'p50': 10.0, 'p95': 10.0},
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "report.html"
            
            ReportGenerator.generate(
                report=report,
                output_path=output_path,
                format=ReportFormat.HTML,
            )
            
            assert output_path.exists()
            
            with open(output_path, 'r') as f:
                content = f.read()
            
            assert "PPOAgent" in content
            assert "CartPole-v1" in content
    
    def test_generate_markdown_report(self):
        episode_results = [
            EpisodeResult(0, 10.0, 5, True),
        ]
        
        report = EvaluationReport(
            agent_type="PPOAgent",
            env_name="CartPole-v1",
            num_episodes=1,
            timestamp="2024-01-01T00:00:00",
            mean_reward=10.0,
            std_reward=0.0,
            min_reward=10.0,
            max_reward=10.0,
            median_reward=10.0,
            mean_length=5.0,
            std_length=0.0,
            success_rate=1.0,
            episode_results=episode_results,
            percentiles={'p50': 10.0},
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "report.md"
            
            ReportGenerator.generate(
                report=report,
                output_path=output_path,
                format=ReportFormat.MARKDOWN,
            )
            
            assert output_path.exists()
            
            with open(output_path, 'r') as f:
                content = f.read()
            
            assert "# Evaluation Report" in content
            assert "PPOAgent" in content
    
    def test_generate_csv_report(self):
        episode_results = [
            EpisodeResult(0, 10.0, 5, True),
            EpisodeResult(1, 20.0, 10, False),
        ]
        
        report = EvaluationReport(
            agent_type="PPOAgent",
            env_name="CartPole-v1",
            num_episodes=2,
            timestamp="2024-01-01T00:00:00",
            mean_reward=15.0,
            std_reward=5.0,
            min_reward=10.0,
            max_reward=20.0,
            median_reward=15.0,
            mean_length=7.5,
            std_length=2.5,
            success_rate=0.5,
            episode_results=episode_results,
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "report.csv"
            
            ReportGenerator.generate(
                report=report,
                output_path=output_path,
                format=ReportFormat.CSV,
            )
            
            assert output_path.exists()
            
            import csv
            with open(output_path, 'r') as f:
                reader = csv.reader(f)
                rows = list(reader)
            
            assert len(rows) > 0
