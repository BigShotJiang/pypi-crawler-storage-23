"""
Chaos testing suite for Hugo.

Tests resilience under adverse conditions:
- Network failures
- LLM backend outages
- Memory pressure
- Data corruption
- Malicious plugins
- Long-running stability
"""

import pytest

# Chaos test markers
pytest.mark.chaos = pytest.mark.chaos
pytest.mark.slow = pytest.mark.slow
pytest.mark.network = pytest.mark.network
pytest.mark.llm = pytest.mark.llm
pytest.mark.resource = pytest.mark.resource
pytest.mark.corruption = pytest.mark.corruption
