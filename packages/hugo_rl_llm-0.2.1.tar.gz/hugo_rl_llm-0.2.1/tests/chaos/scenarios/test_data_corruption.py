"""
Data corruption chaos tests.
"""

import pytest
import tempfile
from pathlib import Path

from rl_llm_toolkit import PPOAgent, RLEnvironment
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from tests.chaos.injectors.corruption import (
    CorruptionInjector,
    CheckpointCorruptor,
    create_corruption_scenario,
)


@pytest.mark.chaos
@pytest.mark.corruption
def test_checkpoint_corruption_detection():
    """Test detection of corrupted checkpoints."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = Path(tmpdir) / "checkpoint.pt"
        
        # Create valid checkpoint
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        agent.train(total_timesteps=1000)
        
        CheckpointManager.save_checkpoint(
            path=checkpoint_path,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=1000,
        )
        
        # Verify it's valid
        is_valid, error = CheckpointManager.verify_checkpoint(checkpoint_path)
        assert is_valid
        
        # Corrupt checkpoint
        injector = CorruptionInjector(corruption_rate=1.0)
        injector.corrupt_checkpoint(checkpoint_path)
        
        # Should detect corruption
        is_valid, error = CheckpointManager.verify_checkpoint(checkpoint_path)
        assert not is_valid
        assert error is not None
        
        env.close()


@pytest.mark.chaos
@pytest.mark.corruption
def test_corrupted_checkpoint_load_fails():
    """Test that loading corrupted checkpoint fails gracefully."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = Path(tmpdir) / "checkpoint.pt"
        
        # Create and corrupt checkpoint
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        agent.train(total_timesteps=1000)
        
        CheckpointManager.save_checkpoint(
            path=checkpoint_path,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=1000,
        )
        
        # Corrupt by writing garbage
        with open(checkpoint_path, 'wb') as f:
            f.write(b'corrupted data')
        
        # Should fail gracefully
        with pytest.raises(Exception):
            CheckpointManager.load_checkpoint(checkpoint_path)
        
        env.close()


@pytest.mark.chaos
@pytest.mark.corruption
def test_partial_checkpoint_corruption():
    """Test handling of partially corrupted checkpoint."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = Path(tmpdir) / "checkpoint.pt"
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        agent.train(total_timesteps=1000)
        
        CheckpointManager.save_checkpoint(
            path=checkpoint_path,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=1000,
        )
        
        # Corrupt model weights
        CheckpointCorruptor.corrupt_model_weights(checkpoint_path)
        
        # Should load but weights are corrupted
        checkpoint = CheckpointManager.load_checkpoint(checkpoint_path)
        assert 'model_state' in checkpoint
        
        env.close()


@pytest.mark.chaos
@pytest.mark.corruption
def test_missing_checkpoint_key():
    """Test handling of checkpoint with missing required key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = Path(tmpdir) / "checkpoint.pt"
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        agent.train(total_timesteps=1000)
        
        CheckpointManager.save_checkpoint(
            path=checkpoint_path,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=1000,
        )
        
        # Remove required key
        CheckpointCorruptor.remove_required_key(checkpoint_path, 'model_state')
        
        # Should detect missing key
        checkpoint = CheckpointManager.load_checkpoint(checkpoint_path)
        assert 'model_state' not in checkpoint
        
        env.close()


@pytest.mark.chaos
@pytest.mark.corruption
def test_json_config_corruption():
    """Test handling of corrupted JSON config."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = Path(tmpdir) / "config.json"
        
        # Create valid config
        import json
        config = {"env_name": "CartPole-v1", "seed": 42}
        with open(config_path, 'w') as f:
            json.dump(config, f)
        
        # Corrupt JSON
        injector = CorruptionInjector(corruption_rate=1.0)
        injector.corrupt_json(config_path)
        
        # Should fail to load
        with pytest.raises(Exception):
            with open(config_path, 'r') as f:
                json.load(f)


@pytest.mark.chaos
@pytest.mark.corruption
def test_training_with_occasional_corruption():
    """Test training continues despite occasional data corruption."""
    injector = create_corruption_scenario('rare_corruption')
    
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    # Train with occasional corruption
    agent.train(total_timesteps=5000)
    
    # Should complete training
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    # Some corruption should have occurred
    stats = injector.get_stats()
    # Note: In real implementation, would need to integrate injector
    
    env.close()


@pytest.mark.chaos
@pytest.mark.corruption
def test_checkpoint_metadata_corruption():
    """Test handling of corrupted checkpoint metadata."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = Path(tmpdir) / "checkpoint.pt"
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        agent.train(total_timesteps=1000)
        
        from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
        metadata = ReproducibilityManager.create_metadata(seed=42, config={})
        
        CheckpointManager.save_checkpoint(
            path=checkpoint_path,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=1000,
            reproducibility_metadata=metadata,
        )
        
        # Corrupt metadata
        CheckpointCorruptor.corrupt_metadata(checkpoint_path)
        
        # Should load but metadata is corrupted
        checkpoint = CheckpointManager.load_checkpoint(checkpoint_path)
        assert 'metadata' in checkpoint
        
        env.close()


@pytest.mark.chaos
@pytest.mark.corruption
@pytest.mark.slow
def test_recovery_from_corruption():
    """Test recovery strategy when checkpoint is corrupted."""
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_dir = Path(tmpdir)
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        # Train and save multiple checkpoints
        checkpoints = []
        for i in range(3):
            agent.train(total_timesteps=2000)
            
            checkpoint_path = checkpoint_dir / f"checkpoint_{i}.pt"
            CheckpointManager.save_checkpoint(
                path=checkpoint_path,
                agent_type="PPOAgent",
                model_state=agent.policy.state_dict(),
                total_timesteps=(i + 1) * 2000,
            )
            checkpoints.append(checkpoint_path)
        
        # Corrupt latest checkpoint
        with open(checkpoints[-1], 'wb') as f:
            f.write(b'corrupted')
        
        # Should be able to fall back to previous checkpoint
        valid_checkpoint = None
        for checkpoint_path in reversed(checkpoints):
            is_valid, _ = CheckpointManager.verify_checkpoint(checkpoint_path)
            if is_valid:
                valid_checkpoint = checkpoint_path
                break
        
        assert valid_checkpoint is not None
        assert valid_checkpoint == checkpoints[-2]
        
        # Can load and continue training
        checkpoint = CheckpointManager.load_checkpoint(valid_checkpoint)
        assert 'model_state' in checkpoint
        
        env.close()
