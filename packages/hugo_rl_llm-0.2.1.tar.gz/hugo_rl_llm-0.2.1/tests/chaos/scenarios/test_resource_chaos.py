"""
Resource limitation chaos tests.
"""

import pytest
import psutil
import time

from rl_llm_toolkit import PPOAgent, RLEnvironment
from tests.chaos.injectors.resource import (
    ResourceLimiter,
    MemoryPressureSimulator,
    CPUThrottler,
)


@pytest.mark.chaos
@pytest.mark.resource
@pytest.mark.slow
def test_memory_pressure():
    """Test training under memory pressure."""
    limiter = ResourceLimiter()
    
    # Limit memory to 1GB
    with limiter.limit_memory(1024):
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        # Should handle memory pressure gracefully
        try:
            agent.train(total_timesteps=10000)
            
            results = agent.evaluate(episodes=10)
            assert results['mean_reward'] > 0
            
        except MemoryError:
            pytest.fail("Should handle memory pressure without crashing")
        finally:
            env.close()


@pytest.mark.chaos
@pytest.mark.resource
def test_memory_usage_bounded():
    """Test that memory usage stays bounded during training."""
    process = psutil.Process()
    
    initial_memory = process.memory_info().rss / 1024 / 1024
    
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    # Train for extended period
    agent.train(total_timesteps=50000)
    
    final_memory = process.memory_info().rss / 1024 / 1024
    memory_growth = final_memory - initial_memory
    
    # Memory growth should be reasonable (< 500MB)
    assert memory_growth < 500, f"Excessive memory growth: {memory_growth}MB"
    
    env.close()


@pytest.mark.chaos
@pytest.mark.resource
@pytest.mark.slow
def test_cpu_throttling():
    """Test training with CPU throttling."""
    throttler = CPUThrottler()
    
    # Limit to 1 CPU
    with throttler.throttle(num_cpus=1):
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        start_time = time.time()
        agent.train(total_timesteps=5000)
        elapsed = time.time() - start_time
        
        # Should complete (albeit slower)
        assert elapsed > 0
        
        results = agent.evaluate(episodes=5)
        assert results['mean_reward'] > 0
        
        env.close()


@pytest.mark.chaos
@pytest.mark.resource
def test_memory_pressure_simulation():
    """Test training with simulated memory pressure."""
    simulator = MemoryPressureSimulator()
    
    try:
        # Allocate 512MB to create pressure
        simulator.allocate(512)
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        # Should still train
        agent.train(total_timesteps=5000)
        
        results = agent.evaluate(episodes=5)
        assert results['mean_reward'] > 0
        
        env.close()
        
    finally:
        simulator.release()


@pytest.mark.chaos
@pytest.mark.resource
@pytest.mark.slow
def test_file_descriptor_limits():
    """Test training with limited file descriptors."""
    limiter = ResourceLimiter()
    
    # Limit to 256 file descriptors
    with limiter.limit_file_descriptors(256):
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        # Should handle limited FDs
        agent.train(total_timesteps=5000)
        
        results = agent.evaluate(episodes=5)
        assert results['mean_reward'] > 0
        
        env.close()


@pytest.mark.chaos
@pytest.mark.resource
def test_resource_monitoring():
    """Test resource usage monitoring during training."""
    limiter = ResourceLimiter()
    
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    # Monitor resources during training
    usage_samples = []
    
    for _ in range(5):
        agent.train(total_timesteps=1000)
        usage = limiter.get_current_usage()
        usage_samples.append(usage)
    
    # Verify monitoring works
    assert len(usage_samples) == 5
    assert all(s['memory_mb'] > 0 for s in usage_samples)
    assert all(s['cpu_percent'] >= 0 for s in usage_samples)
    
    env.close()


@pytest.mark.chaos
@pytest.mark.resource
@pytest.mark.slow
def test_sustained_high_cpu():
    """Test training under sustained high CPU usage."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    process = psutil.Process()
    
    # Train continuously
    agent.train(total_timesteps=20000)
    
    # CPU usage should be reasonable
    cpu_percent = process.cpu_percent(interval=1.0)
    
    # Should use CPU but not peg at 100%
    assert cpu_percent > 0
    assert cpu_percent < 200  # Allow for multi-core
    
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.resource
def test_memory_leak_detection():
    """Test for memory leaks during repeated training."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    process = psutil.Process()
    memory_samples = []
    
    # Train in multiple iterations
    for i in range(10):
        agent.train(total_timesteps=2000)
        
        memory_mb = process.memory_info().rss / 1024 / 1024
        memory_samples.append(memory_mb)
    
    # Memory should stabilize, not grow linearly
    initial_memory = memory_samples[0]
    final_memory = memory_samples[-1]
    growth = final_memory - initial_memory
    
    # Allow some growth but not excessive
    assert growth < 200, f"Possible memory leak: {growth}MB growth"
    
    env.close()
