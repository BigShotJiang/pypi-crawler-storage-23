"""
LLM backend chaos tests.
"""

import pytest
from unittest.mock import Mock

from rl_llm_toolkit import PPOAgent, RLEnvironment
from rl_llm_toolkit.security import CircuitBreaker
from tests.chaos.injectors.llm_backend import (
    ChaoticLLMBackend,
    CompletelyFailingBackend,
    IntermittentBackend,
    create_chaotic_backend,
)


@pytest.mark.chaos
@pytest.mark.llm
def test_llm_random_failures():
    """Test training survives random LLM failures (30% rate)."""
    env = RLEnvironment("CartPole-v1")
    
    # Create chaotic backend
    real_backend = Mock()
    real_backend.compute_reward.return_value = 1.0
    chaotic_backend = ChaoticLLMBackend(real_backend, failure_rate=0.3)
    
    # Wrap in circuit breaker
    breaker = CircuitBreaker(
        "llm",
        fallback=lambda *args: 0.0,
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Training should complete despite failures
    agent.train(total_timesteps=5000)
    
    # Verify failures occurred
    stats = chaotic_backend.get_stats()
    assert stats['failures'] > 0
    assert stats['failure_rate'] > 0.2
    
    # Training should still produce results
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
def test_llm_complete_outage():
    """Test training continues when LLM completely fails."""
    env = RLEnvironment("CartPole-v1")
    
    # Backend that always fails
    failing_backend = CompletelyFailingBackend()
    
    breaker = CircuitBreaker(
        "llm",
        fallback=lambda *args: 0.0,
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Should fall back to env rewards
    agent.train(total_timesteps=5000)
    
    # Circuit should be open after failures
    stats = breaker.get_stats()
    assert stats['total_failures'] > 0
    
    # Training should complete
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
@pytest.mark.slow
def test_llm_intermittent_failures():
    """Test training with intermittent LLM failures."""
    env = RLEnvironment("CartPole-v1")
    
    real_backend = Mock()
    real_backend.compute_reward.return_value = 1.0
    intermittent_backend = IntermittentBackend(real_backend, fail_every=5)
    
    breaker = CircuitBreaker(
        "llm",
        fallback=lambda *args: 0.0,
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Should handle intermittent failures
    agent.train(total_timesteps=10000)
    
    # Verify periodic failures
    assert intermittent_backend.call_count > 0
    
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
def test_llm_slow_responses():
    """Test training with slow LLM responses."""
    env = RLEnvironment("CartPole-v1")
    
    real_backend = Mock()
    real_backend.compute_reward.return_value = 1.0
    slow_backend = ChaoticLLMBackend(
        real_backend,
        failure_rate=0.0,
        slow_rate=0.5,
        slow_delay=0.5,  # 500ms delay
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Should complete despite slow responses
    agent.train(total_timesteps=2000)
    
    stats = slow_backend.get_stats()
    assert stats['slow_responses'] > 0
    
    results = agent.evaluate(episodes=5)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
def test_llm_malformed_responses():
    """Test handling of malformed LLM responses."""
    env = RLEnvironment("CartPole-v1")
    
    real_backend = Mock()
    real_backend.compute_reward.return_value = 1.0
    malformed_backend = ChaoticLLMBackend(
        real_backend,
        failure_rate=0.0,
        malformed_rate=0.3,
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Should handle NaN/invalid rewards
    agent.train(total_timesteps=3000)
    
    stats = malformed_backend.get_stats()
    assert stats['malformed_responses'] > 0
    
    results = agent.evaluate(episodes=5)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
def test_llm_high_failure_rate():
    """Test training with very high LLM failure rate (90%)."""
    env = RLEnvironment("CartPole-v1")
    
    chaotic_backend = create_chaotic_backend('high_failure')
    
    breaker = CircuitBreaker(
        "llm",
        fallback=lambda *args: 0.0,
        config={'failure_threshold': 3, 'timeout_seconds': 30}
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Should quickly open circuit and use fallback
    agent.train(total_timesteps=5000)
    
    # Circuit should be open
    stats = breaker.get_stats()
    assert stats['state'] == 'OPEN' or stats['total_failures'] > 10
    
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()


@pytest.mark.chaos
@pytest.mark.llm
@pytest.mark.slow
def test_llm_recovery_after_outage():
    """Test LLM backend recovery after outage."""
    env = RLEnvironment("CartPole-v1")
    
    # Start with failing backend
    failing_backend = CompletelyFailingBackend()
    
    breaker = CircuitBreaker(
        "llm",
        fallback=lambda *args: 0.0,
        config={'failure_threshold': 5, 'timeout_seconds': 10}
    )
    
    agent = PPOAgent(env=env, seed=42)
    
    # Train with failures - circuit should open
    agent.train(total_timesteps=2000)
    
    stats_before = breaker.get_stats()
    assert stats_before['total_failures'] > 0
    
    # Simulate recovery by replacing backend
    # In real scenario, circuit breaker would retry after timeout
    
    # Continue training
    agent.train(total_timesteps=3000)
    
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()
