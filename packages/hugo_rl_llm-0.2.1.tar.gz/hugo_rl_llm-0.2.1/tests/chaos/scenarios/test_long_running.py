"""
Long-running stability chaos tests.

These tests run for extended periods to detect:
- Memory leaks
- Performance degradation
- Resource exhaustion
- Stability issues
"""

import pytest
import psutil
import time
from pathlib import Path

from rl_llm_toolkit import PPOAgent, RLEnvironment
from rl_llm_toolkit.core.checkpoint import CheckpointManager


@pytest.mark.chaos
@pytest.mark.slow
@pytest.mark.timeout(3600)  # 1 hour timeout
def test_one_hour_stability():
    """Test 1-hour continuous training."""
    process = psutil.Process()
    initial_memory = process.memory_info().rss / 1024 / 1024
    
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    start_time = time.time()
    target_duration = 3600  # 1 hour
    
    memory_samples = []
    
    # Train continuously
    while time.time() - start_time < target_duration:
        agent.train(total_timesteps=10000)
        
        # Sample memory
        current_memory = process.memory_info().rss / 1024 / 1024
        memory_samples.append(current_memory)
        
        # Check for excessive growth
        memory_growth = current_memory - initial_memory
        if memory_growth > 1000:  # 1GB growth
            pytest.fail(f"Excessive memory growth: {memory_growth}MB")
    
    elapsed = time.time() - start_time
    final_memory = process.memory_info().rss / 1024 / 1024
    total_growth = final_memory - initial_memory
    
    # Verify stability
    assert elapsed >= 3500, "Test didn't run long enough"
    assert total_growth < 1000, f"Memory leak detected: {total_growth}MB growth"
    
    # Should still produce good results
    results = agent.evaluate(episodes=100)
    assert results['mean_reward'] > 50
    
    env.close()


@pytest.mark.chaos
@pytest.mark.slow
@pytest.mark.timeout(7200)  # 2 hour timeout
def test_extended_training_10k_episodes():
    """Test training for 10k episodes."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    process = psutil.Process()
    initial_memory = process.memory_info().rss / 1024 / 1024
    
    # Train for many episodes
    total_episodes = 10000
    episodes_per_batch = 100
    
    for batch in range(total_episodes // episodes_per_batch):
        agent.train(total_timesteps=episodes_per_batch * 200)  # ~200 steps per episode
        
        if batch % 10 == 0:
            current_memory = process.memory_info().rss / 1024 / 1024
            memory_growth = current_memory - initial_memory
            
            print(f"Batch {batch}/{total_episodes // episodes_per_batch}: Memory growth = {memory_growth:.1f}MB")
            
            # Check for memory leak
            if memory_growth > 500:
                pytest.fail(f"Memory leak detected: {memory_growth}MB growth")
    
    final_memory = process.memory_info().rss / 1024 / 1024
    total_growth = final_memory - initial_memory
    
    assert total_growth < 500, f"Memory leak: {total_growth}MB growth"
    
    # Should still work well
    results = agent.evaluate(episodes=100)
    assert results['mean_reward'] > 50
    
    env.close()


@pytest.mark.chaos
@pytest.mark.slow
def test_repeated_checkpoint_save_load():
    """Test repeated checkpoint save/load cycles."""
    import tempfile
    
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_dir = Path(tmpdir)
        
        env = RLEnvironment("CartPole-v1")
        agent = PPOAgent(env=env, seed=42)
        
        # Repeatedly save and load
        for i in range(100):
            agent.train(total_timesteps=1000)
            
            checkpoint_path = checkpoint_dir / f"checkpoint_{i}.pt"
            CheckpointManager.save_checkpoint(
                path=checkpoint_path,
                agent_type="PPOAgent",
                model_state=agent.policy.state_dict(),
                total_timesteps=(i + 1) * 1000,
            )
            
            # Load it back
            checkpoint = CheckpointManager.load_checkpoint(checkpoint_path)
            assert 'model_state' in checkpoint
            
            # Verify checkpoint
            is_valid, error = CheckpointManager.verify_checkpoint(checkpoint_path)
            assert is_valid, f"Checkpoint {i} invalid: {error}"
        
        # Should still work
        results = agent.evaluate(episodes=10)
        assert results['mean_reward'] > 0
        
        env.close()


@pytest.mark.chaos
@pytest.mark.slow
def test_performance_degradation():
    """Test that performance doesn't degrade over time."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    # Measure throughput at different points
    throughputs = []
    
    for i in range(10):
        start_time = time.time()
        agent.train(total_timesteps=5000)
        elapsed = time.time() - start_time
        
        throughput = 5000 / elapsed
        throughputs.append(throughput)
        
        print(f"Iteration {i}: {throughput:.1f} steps/sec")
    
    # Throughput should be relatively stable
    initial_throughput = sum(throughputs[:3]) / 3
    final_throughput = sum(throughputs[-3:]) / 3
    
    degradation = (initial_throughput - final_throughput) / initial_throughput
    
    # Allow up to 20% degradation
    assert degradation < 0.2, f"Performance degraded by {degradation * 100:.1f}%"
    
    env.close()


@pytest.mark.chaos
@pytest.mark.slow
def test_continuous_evaluation():
    """Test continuous evaluation doesn't cause issues."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    # Train and evaluate repeatedly
    for i in range(50):
        agent.train(total_timesteps=2000)
        
        # Evaluate after each training
        results = agent.evaluate(episodes=10)
        assert results['mean_reward'] > 0
    
    # Final comprehensive evaluation
    final_results = agent.evaluate(episodes=100)
    assert final_results['mean_reward'] > 50
    
    env.close()


@pytest.mark.chaos
@pytest.mark.slow
def test_memory_stability_over_time():
    """Test memory usage stabilizes and doesn't grow unbounded."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    process = psutil.Process()
    memory_samples = []
    
    # Train for extended period, sampling memory
    for i in range(100):
        agent.train(total_timesteps=1000)
        
        memory_mb = process.memory_info().rss / 1024 / 1024
        memory_samples.append(memory_mb)
    
    # Analyze memory trend
    import numpy as np
    
    # Memory should stabilize (low variance in second half)
    first_half = memory_samples[:50]
    second_half = memory_samples[50:]
    
    first_half_std = np.std(first_half)
    second_half_std = np.std(second_half)
    
    # Second half should be more stable
    assert second_half_std < first_half_std * 2, "Memory not stabilizing"
    
    # Total growth should be bounded
    total_growth = memory_samples[-1] - memory_samples[0]
    assert total_growth < 300, f"Excessive memory growth: {total_growth}MB"
    
    env.close()


@pytest.mark.chaos
@pytest.mark.slow
@pytest.mark.timeout(1800)  # 30 minutes
def test_stress_test_rapid_iterations():
    """Stress test with rapid training iterations."""
    env = RLEnvironment("CartPole-v1")
    agent = PPOAgent(env=env, seed=42)
    
    start_time = time.time()
    iterations = 0
    
    # Run as many iterations as possible in 30 minutes
    while time.time() - start_time < 1800:
        agent.train(total_timesteps=500)
        iterations += 1
        
        if iterations % 100 == 0:
            print(f"Completed {iterations} iterations")
    
    elapsed = time.time() - start_time
    
    print(f"Completed {iterations} iterations in {elapsed:.1f}s")
    print(f"Average: {iterations / elapsed:.2f} iterations/sec")
    
    # Should complete many iterations
    assert iterations > 1000, f"Only completed {iterations} iterations"
    
    # Should still work
    results = agent.evaluate(episodes=10)
    assert results['mean_reward'] > 0
    
    env.close()
