"""
Data corruption injection for chaos testing.
"""

import random
import json
import pickle
from pathlib import Path
from typing import Any, Optional
import torch


class CorruptionInjector:
    """
    Data corruption injector.
    
    Simulates:
    - Checkpoint corruption
    - Config file corruption
    - Replay buffer corruption
    - Cache corruption
    """
    
    def __init__(self, corruption_rate: float = 0.1):
        """
        Initialize corruption injector.
        
        Args:
            corruption_rate: Probability of corruption (0-1)
        """
        self.corruption_rate = corruption_rate
        self.corruption_count = 0
    
    def corrupt_checkpoint(self, checkpoint_path: Path) -> bool:
        """
        Corrupt a checkpoint file.
        
        Args:
            checkpoint_path: Path to checkpoint file
            
        Returns:
            True if corrupted, False otherwise
        """
        if random.random() > self.corruption_rate:
            return False
        
        self.corruption_count += 1
        
        # Different corruption strategies
        strategy = random.choice([
            'truncate',
            'random_bytes',
            'partial_overwrite',
            'delete_key',
        ])
        
        if strategy == 'truncate':
            # Truncate file
            with open(checkpoint_path, 'rb') as f:
                data = f.read()
            
            truncate_at = len(data) // 2
            with open(checkpoint_path, 'wb') as f:
                f.write(data[:truncate_at])
        
        elif strategy == 'random_bytes':
            # Write random bytes
            with open(checkpoint_path, 'wb') as f:
                f.write(random.randbytes(1024))
        
        elif strategy == 'partial_overwrite':
            # Overwrite part of file
            with open(checkpoint_path, 'rb+') as f:
                data = bytearray(f.read())
                
                # Corrupt middle section
                start = len(data) // 3
                end = 2 * len(data) // 3
                for i in range(start, end):
                    data[i] = random.randint(0, 255)
                
                f.seek(0)
                f.write(data)
        
        elif strategy == 'delete_key':
            # Try to load and delete a key
            try:
                checkpoint = torch.load(checkpoint_path)
                if isinstance(checkpoint, dict) and checkpoint:
                    key_to_delete = random.choice(list(checkpoint.keys()))
                    del checkpoint[key_to_delete]
                    torch.save(checkpoint, checkpoint_path)
            except Exception:
                # If can't load, just write garbage
                with open(checkpoint_path, 'wb') as f:
                    f.write(b'corrupted')
        
        return True
    
    def corrupt_json(self, json_path: Path) -> bool:
        """
        Corrupt a JSON file.
        
        Args:
            json_path: Path to JSON file
            
        Returns:
            True if corrupted, False otherwise
        """
        if random.random() > self.corruption_rate:
            return False
        
        self.corruption_count += 1
        
        strategy = random.choice([
            'invalid_json',
            'missing_bracket',
            'wrong_type',
            'delete_key',
        ])
        
        if strategy == 'invalid_json':
            with open(json_path, 'w') as f:
                f.write('{"invalid": json syntax}')
        
        elif strategy == 'missing_bracket':
            with open(json_path, 'r') as f:
                content = f.read()
            
            # Remove last bracket
            if content.endswith('}'):
                content = content[:-1]
            
            with open(json_path, 'w') as f:
                f.write(content)
        
        elif strategy == 'wrong_type':
            try:
                with open(json_path, 'r') as f:
                    data = json.load(f)
                
                # Change a value to wrong type
                if isinstance(data, dict) and data:
                    key = random.choice(list(data.keys()))
                    data[key] = "wrong_type"
                
                with open(json_path, 'w') as f:
                    json.dump(data, f)
            except Exception:
                with open(json_path, 'w') as f:
                    f.write('corrupted')
        
        elif strategy == 'delete_key':
            try:
                with open(json_path, 'r') as f:
                    data = json.load(f)
                
                if isinstance(data, dict) and data:
                    key_to_delete = random.choice(list(data.keys()))
                    del data[key_to_delete]
                
                with open(json_path, 'w') as f:
                    json.dump(data, f)
            except Exception:
                pass
        
        return True
    
    def corrupt_pickle(self, pickle_path: Path) -> bool:
        """
        Corrupt a pickle file.
        
        Args:
            pickle_path: Path to pickle file
            
        Returns:
            True if corrupted, False otherwise
        """
        if random.random() > self.corruption_rate:
            return False
        
        self.corruption_count += 1
        
        # Write random bytes
        with open(pickle_path, 'wb') as f:
            f.write(random.randbytes(512))
        
        return True
    
    def corrupt_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        """
        Corrupt tensor values.
        
        Args:
            tensor: Input tensor
            
        Returns:
            Corrupted tensor
        """
        if random.random() > self.corruption_rate:
            return tensor
        
        self.corruption_count += 1
        
        corrupted = tensor.clone()
        
        strategy = random.choice([
            'nan',
            'inf',
            'zeros',
            'random',
        ])
        
        if strategy == 'nan':
            corrupted[0] = float('nan')
        elif strategy == 'inf':
            corrupted[0] = float('inf')
        elif strategy == 'zeros':
            corrupted.zero_()
        elif strategy == 'random':
            corrupted = torch.randn_like(tensor)
        
        return corrupted
    
    def get_stats(self) -> dict:
        """Get corruption statistics."""
        return {
            'corruption_count': self.corruption_count,
            'corruption_rate': self.corruption_rate,
        }


class CheckpointCorruptor:
    """Specialized checkpoint corruption."""
    
    @staticmethod
    def corrupt_model_weights(checkpoint_path: Path):
        """Corrupt model weights in checkpoint."""
        checkpoint = torch.load(checkpoint_path)
        
        if 'model_state' in checkpoint:
            # Corrupt first layer weights
            for key in checkpoint['model_state']:
                if 'weight' in key:
                    checkpoint['model_state'][key] = torch.randn_like(
                        checkpoint['model_state'][key]
                    )
                    break
        
        torch.save(checkpoint, checkpoint_path)
    
    @staticmethod
    def corrupt_metadata(checkpoint_path: Path):
        """Corrupt metadata in checkpoint."""
        checkpoint = torch.load(checkpoint_path)
        
        if 'metadata' in checkpoint:
            checkpoint['metadata'] = {'corrupted': True}
        
        torch.save(checkpoint, checkpoint_path)
    
    @staticmethod
    def remove_required_key(checkpoint_path: Path, key: str = 'model_state'):
        """Remove required key from checkpoint."""
        checkpoint = torch.load(checkpoint_path)
        
        if key in checkpoint:
            del checkpoint[key]
        
        torch.save(checkpoint, checkpoint_path)


class ReplayBufferCorruptor:
    """Specialized replay buffer corruption."""
    
    @staticmethod
    def corrupt_observations(buffer: Any):
        """Corrupt observations in replay buffer."""
        if hasattr(buffer, 'observations'):
            buffer.observations = torch.randn_like(buffer.observations)
    
    @staticmethod
    def corrupt_rewards(buffer: Any):
        """Corrupt rewards in replay buffer."""
        if hasattr(buffer, 'rewards'):
            buffer.rewards = torch.full_like(buffer.rewards, float('nan'))
    
    @staticmethod
    def corrupt_actions(buffer: Any):
        """Corrupt actions in replay buffer."""
        if hasattr(buffer, 'actions'):
            buffer.actions = torch.randint_like(buffer.actions, 0, 10)


def create_corruption_scenario(scenario: str) -> CorruptionInjector:
    """
    Factory function to create corruption scenarios.
    
    Args:
        scenario: Corruption scenario name
        
    Returns:
        CorruptionInjector instance
    """
    scenarios = {
        'rare_corruption': CorruptionInjector(corruption_rate=0.01),
        'occasional_corruption': CorruptionInjector(corruption_rate=0.1),
        'frequent_corruption': CorruptionInjector(corruption_rate=0.3),
        'high_corruption': CorruptionInjector(corruption_rate=0.5),
    }
    
    if scenario not in scenarios:
        raise ValueError(f"Unknown scenario: {scenario}")
    
    return scenarios[scenario]
