"""
Resource limitation and chaos injection.
"""

import psutil
import resource
import os
from typing import Optional
from contextlib import contextmanager


class ResourceLimiter:
    """
    Resource limitation for chaos testing.
    
    Simulates:
    - Memory pressure
    - CPU throttling
    - Disk space limits
    - File descriptor exhaustion
    """
    
    def __init__(self):
        self.original_limits = {}
    
    @contextmanager
    def limit_memory(self, max_mb: int):
        """
        Limit memory usage.
        
        Args:
            max_mb: Maximum memory in MB
        """
        try:
            # Get current limit
            soft, hard = resource.getrlimit(resource.RLIMIT_AS)
            self.original_limits['memory'] = (soft, hard)
            
            # Set new limit
            new_limit = max_mb * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (new_limit, hard))
            
            yield
            
        finally:
            # Restore original limit
            if 'memory' in self.original_limits:
                resource.setrlimit(resource.RLIMIT_AS, self.original_limits['memory'])
    
    @contextmanager
    def limit_cpu_time(self, max_seconds: int):
        """
        Limit CPU time.
        
        Args:
            max_seconds: Maximum CPU seconds
        """
        try:
            soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
            self.original_limits['cpu'] = (soft, hard)
            
            resource.setrlimit(resource.RLIMIT_CPU, (max_seconds, hard))
            
            yield
            
        finally:
            if 'cpu' in self.original_limits:
                resource.setrlimit(resource.RLIMIT_CPU, self.original_limits['cpu'])
    
    @contextmanager
    def limit_file_descriptors(self, max_fds: int):
        """
        Limit file descriptors.
        
        Args:
            max_fds: Maximum number of file descriptors
        """
        try:
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            self.original_limits['fds'] = (soft, hard)
            
            resource.setrlimit(resource.RLIMIT_NOFILE, (max_fds, hard))
            
            yield
            
        finally:
            if 'fds' in self.original_limits:
                resource.setrlimit(resource.RLIMIT_NOFILE, self.original_limits['fds'])
    
    def get_current_usage(self) -> dict:
        """Get current resource usage."""
        process = psutil.Process()
        
        return {
            'memory_mb': process.memory_info().rss / 1024 / 1024,
            'cpu_percent': process.cpu_percent(interval=0.1),
            'num_fds': process.num_fds() if hasattr(process, 'num_fds') else 0,
            'num_threads': process.num_threads(),
        }


class MemoryPressureSimulator:
    """Simulate memory pressure by allocating memory."""
    
    def __init__(self):
        self.allocated_blocks = []
    
    def allocate(self, mb: int):
        """
        Allocate memory to create pressure.
        
        Args:
            mb: Megabytes to allocate
        """
        # Allocate in 1MB blocks
        for _ in range(mb):
            block = bytearray(1024 * 1024)  # 1MB
            self.allocated_blocks.append(block)
    
    def release(self):
        """Release all allocated memory."""
        self.allocated_blocks.clear()
    
    def get_allocated_mb(self) -> float:
        """Get total allocated memory in MB."""
        return len(self.allocated_blocks)


class DiskSpaceSimulator:
    """Simulate disk space exhaustion."""
    
    def __init__(self, temp_dir: str = "/tmp"):
        self.temp_dir = temp_dir
        self.temp_files = []
    
    def fill_disk(self, mb: int):
        """
        Fill disk with temporary files.
        
        Args:
            mb: Megabytes to fill
        """
        import tempfile
        
        for i in range(mb):
            fd, path = tempfile.mkstemp(dir=self.temp_dir)
            
            # Write 1MB of data
            os.write(fd, b'\0' * (1024 * 1024))
            os.close(fd)
            
            self.temp_files.append(path)
    
    def cleanup(self):
        """Remove all temporary files."""
        for path in self.temp_files:
            try:
                os.remove(path)
            except Exception:
                pass
        self.temp_files.clear()
    
    def get_disk_usage(self) -> dict:
        """Get disk usage statistics."""
        usage = psutil.disk_usage(self.temp_dir)
        
        return {
            'total_gb': usage.total / (1024**3),
            'used_gb': usage.used / (1024**3),
            'free_gb': usage.free / (1024**3),
            'percent': usage.percent,
        }


class CPUThrottler:
    """Simulate CPU throttling."""
    
    def __init__(self):
        self.original_affinity = None
    
    @contextmanager
    def throttle(self, num_cpus: int = 1):
        """
        Limit to specific number of CPUs.
        
        Args:
            num_cpus: Number of CPUs to allow
        """
        try:
            process = psutil.Process()
            
            # Save original affinity
            if hasattr(process, 'cpu_affinity'):
                self.original_affinity = process.cpu_affinity()
                
                # Set to first N CPUs
                available_cpus = list(range(min(num_cpus, psutil.cpu_count())))
                process.cpu_affinity(available_cpus)
            
            yield
            
        finally:
            # Restore original affinity
            if self.original_affinity is not None and hasattr(process, 'cpu_affinity'):
                process.cpu_affinity(self.original_affinity)


def create_resource_chaos(scenario: str) -> dict:
    """
    Factory function to create resource chaos scenarios.
    
    Args:
        scenario: Chaos scenario name
        
    Returns:
        Dictionary with chaos configuration
    """
    scenarios = {
        'low_memory': {
            'type': 'memory',
            'limit_mb': 512,
        },
        'very_low_memory': {
            'type': 'memory',
            'limit_mb': 256,
        },
        'memory_pressure': {
            'type': 'memory_pressure',
            'allocate_mb': 1024,
        },
        'cpu_throttle': {
            'type': 'cpu',
            'num_cpus': 1,
        },
        'limited_fds': {
            'type': 'file_descriptors',
            'max_fds': 256,
        },
    }
    
    if scenario not in scenarios:
        raise ValueError(f"Unknown scenario: {scenario}")
    
    return scenarios[scenario]
