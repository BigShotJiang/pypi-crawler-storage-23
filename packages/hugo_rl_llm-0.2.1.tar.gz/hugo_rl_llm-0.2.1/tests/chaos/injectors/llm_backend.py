"""
LLM backend fault injection for chaos testing.
"""

import random
import time
from typing import Optional, Callable, Any
from unittest.mock import Mock


class ChaoticLLMBackend:
    """
    LLM backend wrapper that injects failures.
    
    Simulates:
    - Random failures
    - Slow responses
    - Malformed outputs
    - Rate limiting
    """
    
    def __init__(
        self,
        real_backend: Any,
        failure_rate: float = 0.1,
        slow_rate: float = 0.1,
        slow_delay: float = 5.0,
        malformed_rate: float = 0.05,
    ):
        """
        Initialize chaotic backend.
        
        Args:
            real_backend: Actual LLM backend to wrap
            failure_rate: Probability of complete failure (0-1)
            slow_rate: Probability of slow response (0-1)
            slow_delay: Delay in seconds for slow responses
            malformed_rate: Probability of malformed response (0-1)
        """
        self.real_backend = real_backend
        self.failure_rate = failure_rate
        self.slow_rate = slow_rate
        self.slow_delay = slow_delay
        self.malformed_rate = malformed_rate
        
        # Statistics
        self.call_count = 0
        self.failure_count = 0
        self.slow_count = 0
        self.malformed_count = 0
    
    def compute_reward(self, state, action):
        """Compute reward with chaos injection."""
        self.call_count += 1
        
        # Random failure
        if random.random() < self.failure_rate:
            self.failure_count += 1
            raise ConnectionError("Simulated LLM backend failure")
        
        # Slow response
        if random.random() < self.slow_rate:
            self.slow_count += 1
            time.sleep(self.slow_delay)
        
        # Malformed response
        if random.random() < self.malformed_rate:
            self.malformed_count += 1
            return float('nan')  # Invalid reward
        
        # Normal response
        return self.real_backend.compute_reward(state, action)
    
    def get_stats(self) -> dict:
        """Get chaos statistics."""
        return {
            'total_calls': self.call_count,
            'failures': self.failure_count,
            'slow_responses': self.slow_count,
            'malformed_responses': self.malformed_count,
            'failure_rate': self.failure_count / self.call_count if self.call_count > 0 else 0,
        }


class CompletelyFailingBackend:
    """LLM backend that always fails."""
    
    def __init__(self, error_message: str = "Backend completely down"):
        self.error_message = error_message
        self.call_count = 0
    
    def compute_reward(self, state, action):
        """Always raise error."""
        self.call_count += 1
        raise ConnectionError(self.error_message)


class IntermittentBackend:
    """LLM backend that alternates between working and failing."""
    
    def __init__(self, real_backend: Any, fail_every: int = 3):
        """
        Initialize intermittent backend.
        
        Args:
            real_backend: Actual backend
            fail_every: Fail every N calls
        """
        self.real_backend = real_backend
        self.fail_every = fail_every
        self.call_count = 0
    
    def compute_reward(self, state, action):
        """Fail periodically."""
        self.call_count += 1
        
        if self.call_count % self.fail_every == 0:
            raise ConnectionError(f"Intermittent failure (call {self.call_count})")
        
        return self.real_backend.compute_reward(state, action)


class RateLimitedBackend:
    """LLM backend that enforces rate limiting."""
    
    def __init__(
        self,
        real_backend: Any,
        max_calls_per_minute: int = 60,
    ):
        """
        Initialize rate-limited backend.
        
        Args:
            real_backend: Actual backend
            max_calls_per_minute: Maximum calls per minute
        """
        self.real_backend = real_backend
        self.max_calls_per_minute = max_calls_per_minute
        self.call_times = []
    
    def compute_reward(self, state, action):
        """Enforce rate limit."""
        current_time = time.time()
        
        # Remove calls older than 1 minute
        self.call_times = [t for t in self.call_times if current_time - t < 60]
        
        # Check rate limit
        if len(self.call_times) >= self.max_calls_per_minute:
            raise Exception(f"Rate limit exceeded: {self.max_calls_per_minute} calls/min")
        
        self.call_times.append(current_time)
        return self.real_backend.compute_reward(state, action)


class TimeoutBackend:
    """LLM backend that times out."""
    
    def __init__(self, timeout_delay: float = 30.0):
        """
        Initialize timeout backend.
        
        Args:
            timeout_delay: Delay before timeout
        """
        self.timeout_delay = timeout_delay
    
    def compute_reward(self, state, action):
        """Simulate timeout."""
        time.sleep(self.timeout_delay)
        raise TimeoutError(f"Request timed out after {self.timeout_delay}s")


def create_chaotic_backend(
    scenario: str,
    real_backend: Optional[Any] = None
) -> Any:
    """
    Factory function to create chaotic backends.
    
    Args:
        scenario: Chaos scenario name
        real_backend: Real backend to wrap (or Mock if None)
        
    Returns:
        Chaotic backend instance
    """
    if real_backend is None:
        real_backend = Mock()
        real_backend.compute_reward.return_value = 1.0
    
    scenarios = {
        'random_failures': lambda: ChaoticLLMBackend(
            real_backend,
            failure_rate=0.3,
        ),
        'high_failure': lambda: ChaoticLLMBackend(
            real_backend,
            failure_rate=0.9,
        ),
        'slow_responses': lambda: ChaoticLLMBackend(
            real_backend,
            slow_rate=0.5,
            slow_delay=2.0,
        ),
        'complete_failure': lambda: CompletelyFailingBackend(),
        'intermittent': lambda: IntermittentBackend(real_backend, fail_every=5),
        'rate_limited': lambda: RateLimitedBackend(real_backend, max_calls_per_minute=10),
        'timeout': lambda: TimeoutBackend(timeout_delay=10.0),
    }
    
    if scenario not in scenarios:
        raise ValueError(f"Unknown scenario: {scenario}")
    
    return scenarios[scenario]()
