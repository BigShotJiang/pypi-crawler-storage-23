"""
Network fault injection for chaos testing.
"""

import random
import time
from typing import Optional
from unittest.mock import Mock, patch


class NetworkChaos:
    """
    Network fault injector.
    
    Simulates:
    - Connection failures
    - High latency
    - Packet loss
    - DNS failures
    - Timeouts
    """
    
    def __init__(
        self,
        failure_rate: float = 0.1,
        latency_rate: float = 0.2,
        latency_ms: float = 5000,
        packet_loss_rate: float = 0.1,
    ):
        """
        Initialize network chaos.
        
        Args:
            failure_rate: Probability of complete connection failure
            latency_rate: Probability of high latency
            latency_ms: Latency in milliseconds
            packet_loss_rate: Probability of packet loss
        """
        self.failure_rate = failure_rate
        self.latency_rate = latency_rate
        self.latency_ms = latency_ms
        self.packet_loss_rate = packet_loss_rate
        
        self.failure_count = 0
        self.latency_count = 0
        self.packet_loss_count = 0
    
    def inject_before_request(self):
        """Inject chaos before network request."""
        # Connection failure
        if random.random() < self.failure_rate:
            self.failure_count += 1
            raise ConnectionError("Simulated network failure")
        
        # High latency
        if random.random() < self.latency_rate:
            self.latency_count += 1
            time.sleep(self.latency_ms / 1000.0)
        
        # Packet loss (simulated as timeout)
        if random.random() < self.packet_loss_rate:
            self.packet_loss_count += 1
            raise TimeoutError("Simulated packet loss")
    
    def get_stats(self) -> dict:
        """Get chaos statistics."""
        return {
            'failures': self.failure_count,
            'high_latency': self.latency_count,
            'packet_loss': self.packet_loss_count,
        }


class IntermittentNetwork:
    """Network that works intermittently."""
    
    def __init__(self, uptime_ratio: float = 0.7):
        """
        Initialize intermittent network.
        
        Args:
            uptime_ratio: Fraction of time network is up (0-1)
        """
        self.uptime_ratio = uptime_ratio
        self.is_up = True
        self.state_changes = 0
    
    def check_connectivity(self) -> bool:
        """Check if network is currently up."""
        # Randomly flip state
        if random.random() > self.uptime_ratio:
            self.is_up = not self.is_up
            self.state_changes += 1
        
        return self.is_up
    
    def inject_before_request(self):
        """Inject chaos based on current state."""
        if not self.check_connectivity():
            raise ConnectionError("Network is down")


class DNSFailure:
    """Simulate DNS resolution failures."""
    
    def __init__(self, failure_rate: float = 0.2):
        self.failure_rate = failure_rate
        self.failure_count = 0
    
    def inject_before_request(self):
        """Inject DNS failure."""
        if random.random() < self.failure_rate:
            self.failure_count += 1
            raise OSError("DNS resolution failed")


def create_network_chaos(scenario: str) -> NetworkChaos:
    """
    Factory function to create network chaos scenarios.
    
    Args:
        scenario: Chaos scenario name
        
    Returns:
        NetworkChaos instance
    """
    scenarios = {
        'occasional_failures': NetworkChaos(
            failure_rate=0.1,
            latency_rate=0.2,
            latency_ms=1000,
        ),
        'high_latency': NetworkChaos(
            failure_rate=0.05,
            latency_rate=0.8,
            latency_ms=5000,
        ),
        'frequent_failures': NetworkChaos(
            failure_rate=0.5,
            latency_rate=0.3,
            latency_ms=2000,
        ),
        'packet_loss': NetworkChaos(
            failure_rate=0.1,
            packet_loss_rate=0.3,
        ),
    }
    
    if scenario not in scenarios:
        raise ValueError(f"Unknown scenario: {scenario}")
    
    return scenarios[scenario]
