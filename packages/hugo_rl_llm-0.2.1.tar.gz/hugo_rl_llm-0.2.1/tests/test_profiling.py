import pytest
import time
import tempfile
from pathlib import Path

from rl_llm_toolkit.profiling.profiler import PerformanceProfiler, ProfilerContext
from rl_llm_toolkit.profiling.cost_tracker import CostTracker, LLMCostEstimator, LLMCostConfig


class TestPerformanceProfiler:
    def test_basic_profiling(self):
        profiler = PerformanceProfiler()
        
        profiler.start('test_section')
        time.sleep(0.01)
        duration = profiler.stop('test_section')
        
        assert duration >= 0.01
        assert len(profiler.records) == 1
        assert profiler.records[0].name == 'test_section'
    
    def test_context_manager_profiling(self):
        profiler = PerformanceProfiler()
        
        with profiler.profile('context_test'):
            time.sleep(0.01)
        
        assert len(profiler.records) == 1
        assert profiler.records[0].duration >= 0.01
    
    def test_multiple_sections(self):
        profiler = PerformanceProfiler()
        
        for i in range(5):
            with profiler.profile('loop_section'):
                time.sleep(0.001)
        
        assert len(profiler.records) == 5
        summary = profiler.get_summary()
        assert 'loop_section' in summary
        assert summary['loop_section']['count'] == 5
    
    def test_get_bottlenecks(self):
        profiler = PerformanceProfiler()
        
        with profiler.profile('fast'):
            time.sleep(0.001)
        
        with profiler.profile('slow'):
            time.sleep(0.02)
        
        with profiler.profile('medium'):
            time.sleep(0.01)
        
        bottlenecks = profiler.get_bottlenecks(top_n=2)
        
        assert len(bottlenecks) == 2
        assert bottlenecks[0][0] == 'slow'
    
    def test_save_and_load(self):
        profiler = PerformanceProfiler()
        
        with profiler.profile('test'):
            time.sleep(0.001)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "profile.json"
            profiler.save(path)
            
            assert path.exists()
    
    def test_reset(self):
        profiler = PerformanceProfiler()
        
        with profiler.profile('test'):
            pass
        
        assert len(profiler.records) > 0
        
        profiler.reset()
        
        assert len(profiler.records) == 0
        assert len(profiler._section_times) == 0


class TestProfilerContext:
    def test_global_profiler(self):
        ProfilerContext.reset()
        
        profiler1 = ProfilerContext.get_profiler()
        profiler2 = ProfilerContext.get_profiler()
        
        assert profiler1 is profiler2
    
    def test_context_manager(self):
        ProfilerContext.reset()
        
        with ProfilerContext.profile('global_test'):
            time.sleep(0.001)
        
        profiler = ProfilerContext.get_profiler()
        assert len(profiler.records) == 1


class TestLLMCostEstimator:
    def test_get_openai_config(self):
        config = LLMCostEstimator.get_config('openai', 'gpt-4')
        
        assert config is not None
        assert config.provider == 'openai'
        assert config.model == 'gpt-4'
        assert config.cost_per_1k_input_tokens > 0
    
    def test_get_ollama_config(self):
        config = LLMCostEstimator.get_config('ollama', 'llama3')
        
        assert config is not None
        assert config.cost_per_1k_input_tokens == 0.0
        assert config.cost_per_1k_output_tokens == 0.0
    
    def test_estimate_cost(self):
        cost = LLMCostEstimator.estimate('openai', 'gpt-3.5-turbo', 1000, 500)
        
        assert cost is not None
        assert cost > 0
    
    def test_unknown_provider(self):
        config = LLMCostEstimator.get_config('unknown', 'model')
        assert config is None


class TestCostTracker:
    def test_basic_tracking(self):
        tracker = CostTracker('openai', 'gpt-3.5-turbo')
        
        cost = tracker.log_usage(
            input_tokens=1000,
            output_tokens=500,
            step=1,
        )
        
        assert cost > 0
        assert tracker.total_input_tokens == 1000
        assert tracker.total_output_tokens == 500
        assert len(tracker.records) == 1
    
    def test_multiple_logs(self):
        tracker = CostTracker('openai', 'gpt-4')
        
        for i in range(10):
            tracker.log_usage(
                input_tokens=100,
                output_tokens=50,
                step=i,
                episode=i // 2,
            )
        
        assert len(tracker.records) == 10
        assert tracker.total_input_tokens == 1000
        assert tracker.total_output_tokens == 500
    
    def test_get_summary(self):
        tracker = CostTracker('openai', 'gpt-3.5-turbo')
        
        tracker.log_usage(1000, 500, 1)
        tracker.log_usage(2000, 1000, 2)
        
        summary = tracker.get_summary()
        
        assert summary['total_calls'] == 2
        assert summary['total_input_tokens'] == 3000
        assert summary['total_output_tokens'] == 1500
        assert summary['total_estimated_cost'] > 0
    
    def test_get_cost_by_episode(self):
        tracker = CostTracker('openai', 'gpt-4')
        
        tracker.log_usage(100, 50, 1, episode=0)
        tracker.log_usage(100, 50, 2, episode=0)
        tracker.log_usage(100, 50, 3, episode=1)
        
        episode_costs = tracker.get_cost_by_episode()
        
        assert len(episode_costs) == 2
        assert 0 in episode_costs
        assert 1 in episode_costs
    
    def test_estimate_total_cost(self):
        tracker = CostTracker('openai', 'gpt-3.5-turbo')
        
        for i in range(5):
            tracker.log_usage(100, 50, i, episode=i)
        
        estimate = tracker.estimate_total_cost(total_episodes=100)
        
        assert 'estimated_total_cost' in estimate
        assert estimate['estimated_total_cost'] > 0
    
    def test_save_and_load(self):
        tracker = CostTracker('openai', 'gpt-4')
        
        tracker.log_usage(1000, 500, 1)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "costs.json"
            tracker.save(path)
            
            assert path.exists()
            
            new_tracker = CostTracker('openai', 'gpt-4')
            new_tracker.load(path)
            
            assert len(new_tracker.records) == 1
            assert new_tracker.total_input_tokens == 1000


class TestLLMCostConfig:
    def test_estimate_cost(self):
        config = LLMCostConfig(
            provider='test',
            model='test-model',
            cost_per_1k_input_tokens=0.001,
            cost_per_1k_output_tokens=0.002,
        )
        
        cost = config.estimate_cost(1000, 500)
        
        expected = (1000 / 1000) * 0.001 + (500 / 1000) * 0.002
        assert abs(cost - expected) < 0.0001
