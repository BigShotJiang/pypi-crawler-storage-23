import pytest
import tempfile
from pathlib import Path
import torch

from rl_llm_toolkit.core.checkpoint import CheckpointManager, CheckpointMetadata
from rl_llm_toolkit.core.reproducibility import ReproducibilityMetadata, ReproducibilityManager
from rl_llm_toolkit.core.exceptions import CheckpointError


class TestCheckpointManager:
    def test_save_and_load_basic_checkpoint(self):
        model_state = {
            'layer1.weight': torch.randn(10, 5),
            'layer1.bias': torch.randn(10),
        }
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "checkpoint.pt"
            
            CheckpointManager.save_checkpoint(
                path=path,
                agent_type="PPOAgent",
                model_state=model_state,
                total_timesteps=1000,
                episode_count=10,
                checkpoint_step=500,
            )
            
            checkpoint_data = CheckpointManager.load_checkpoint(path)
            
            assert 'metadata' in checkpoint_data
            assert 'model_state' in checkpoint_data
            assert checkpoint_data['metadata']['agent_type'] == "PPOAgent"
            assert checkpoint_data['metadata']['total_timesteps'] == 1000
    
    def test_save_checkpoint_with_all_components(self):
        model_state = {'weight': torch.randn(5, 5)}
        optimizer_state = {'state': {}, 'param_groups': []}
        scheduler_state = {'last_epoch': 10}
        replay_buffer_state = {'buffer': [1, 2, 3]}
        normalization_stats = {'mean': [0.0], 'std': [1.0]}
        reward_cache = {'key1': 'value1'}
        training_stats = {'loss': [0.1, 0.2]}
        
        config = {'env': 'CartPole-v1'}
        reproducibility_metadata = ReproducibilityManager.create_metadata(
            seed=42,
            config=config,
        )
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "checkpoint.pt"
            
            CheckpointManager.save_checkpoint(
                path=path,
                agent_type="DQNAgent",
                model_state=model_state,
                optimizer_state=optimizer_state,
                scheduler_state=scheduler_state,
                replay_buffer_state=replay_buffer_state,
                normalization_stats=normalization_stats,
                reward_cache=reward_cache,
                training_stats=training_stats,
                reproducibility_metadata=reproducibility_metadata,
                total_timesteps=5000,
                episode_count=50,
                checkpoint_step=2500,
            )
            
            checkpoint_data = CheckpointManager.load_checkpoint(path)
            
            assert 'model_state' in checkpoint_data
            assert 'optimizer_state' in checkpoint_data
            assert 'scheduler_state' in checkpoint_data
            assert 'replay_buffer_state' in checkpoint_data
            assert 'normalization_stats' in checkpoint_data
            assert 'reward_cache' in checkpoint_data
            assert 'training_stats' in checkpoint_data
            assert 'reproducibility_metadata' in checkpoint_data
            
            assert checkpoint_data['reward_cache'] == reward_cache
            assert checkpoint_data['training_stats'] == training_stats
    
    def test_verify_checkpoint_valid(self):
        model_state = {'weight': torch.randn(3, 3)}
        
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "checkpoint.pt"
            
            CheckpointManager.save_checkpoint(
                path=path,
                agent_type="PPOAgent",
                model_state=model_state,
            )
            
            assert CheckpointManager.verify_checkpoint(path) is True
    
    def test_verify_checkpoint_invalid(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "nonexistent.pt"
            
            assert CheckpointManager.verify_checkpoint(path) is False
    
    def test_load_nonexistent_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "nonexistent.pt"
            
            with pytest.raises(CheckpointError):
                CheckpointManager.load_checkpoint(path)


class TestCheckpointMetadata:
    def test_metadata_to_dict(self):
        metadata = CheckpointMetadata(
            version="1.0.0",
            agent_type="PPOAgent",
            total_timesteps=10000,
            episode_count=100,
            checkpoint_step=5000,
            timestamp="2024-01-01T00:00:00",
            reproducibility_hash="abc123",
        )
        
        data = metadata.to_dict()
        
        assert data['version'] == "1.0.0"
        assert data['agent_type'] == "PPOAgent"
        assert data['total_timesteps'] == 10000
        assert data['episode_count'] == 100
