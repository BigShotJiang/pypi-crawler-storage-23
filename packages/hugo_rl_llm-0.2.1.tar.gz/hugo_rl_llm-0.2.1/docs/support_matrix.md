# Support Matrix

This document provides comprehensive compatibility information for Hugo RL-LLM Toolkit.

## Platform Support

| Platform | Status | Notes |
|----------|--------|-------|
| **Linux** | ✅ Fully Supported | Tested on Ubuntu 20.04, 22.04 |
| **macOS** | ✅ Fully Supported | Tested on macOS 12+, both Intel and Apple Silicon |
| **Windows** | ✅ Fully Supported | Tested on Windows 10, 11 |

## Python Versions

| Version | Status | Notes |
|---------|--------|-------|
| **3.10** | ✅ Fully Supported | Minimum required version |
| **3.11** | ✅ Fully Supported | Recommended |
| **3.12** | ✅ Fully Supported | Latest tested |
| 3.9 | ❌ Not Supported | EOL approaching |
| 3.13+ | ⚠️ Experimental | May work but not officially tested |

## Core Dependencies

| Package | Minimum Version | Tested Version | Required |
|---------|----------------|----------------|----------|
| **PyTorch** | 2.0.0 | 2.1.0 | ✅ Yes |
| **Gymnasium** | 0.29.0 | 0.29.1 | ✅ Yes |
| **NumPy** | 1.24.0 | 1.26.0 | ✅ Yes |
| **Pydantic** | 2.0.0 | 2.5.0 | ✅ Yes |
| **Click** | 8.1.0 | 8.1.7 | ✅ Yes |
| **Rich** | 13.0.0 | 13.7.0 | ✅ Yes |

## Hardware Support

### CPU

| Feature | Status | Notes |
|---------|--------|-------|
| **x86_64** | ✅ Fully Supported | Intel, AMD |
| **ARM64** | ✅ Fully Supported | Apple Silicon, AWS Graviton |
| **Multi-core** | ✅ Supported | Automatic parallelization where applicable |

### GPU

| Feature | Status | Notes |
|---------|--------|-------|
| **NVIDIA CUDA** | ✅ Fully Supported | CUDA 11.8+ recommended |
| **AMD ROCm** | ⚠️ Experimental | Via PyTorch ROCm builds |
| **Apple Metal** | ✅ Supported | Via PyTorch MPS backend |
| **Multi-GPU** | 🚧 Planned | Coming in v1.0 |

## LLM Backend Support

### OpenAI

| Model | Status | Cost Tracking | Notes |
|-------|--------|---------------|-------|
| **GPT-4** | ✅ Supported | ✅ Yes | Full support |
| **GPT-4 Turbo** | ✅ Supported | ✅ Yes | Recommended for production |
| **GPT-4o** | ✅ Supported | ✅ Yes | Latest model |
| **GPT-4o Mini** | ✅ Supported | ✅ Yes | Cost-effective option |
| **GPT-3.5 Turbo** | ✅ Supported | ✅ Yes | Budget option |

### Anthropic

| Model | Status | Cost Tracking | Notes |
|-------|--------|---------------|-------|
| **Claude 3 Opus** | ✅ Supported | ✅ Yes | Highest capability |
| **Claude 3 Sonnet** | ✅ Supported | ✅ Yes | Balanced |
| **Claude 3 Haiku** | ✅ Supported | ✅ Yes | Fastest, most affordable |

### Ollama (Local)

| Feature | Status | Notes |
|---------|--------|-------|
| **Local Models** | ✅ Supported | Zero cost, full privacy |
| **Llama 3** | ✅ Tested | Recommended |
| **Mistral** | ✅ Tested | Good performance |
| **Custom Models** | ✅ Supported | Any Ollama-compatible model |

## Algorithm Support

| Algorithm | Status | Online | Offline | Multi-Agent | GPU |
|-----------|--------|--------|---------|-------------|-----|
| **PPO** | ✅ Stable | ✅ | ❌ | ❌ | ✅ |
| **DQN** | ✅ Stable | ✅ | ❌ | ❌ | ✅ |
| **CQL** | ✅ Stable | ❌ | ✅ | ❌ | ✅ |
| **IQL** | ✅ Stable | ❌ | ✅ | ❌ | ✅ |
| **MADDPG** | ✅ Beta | ✅ | ❌ | ✅ | ✅ |
| **SAC** | 🚧 Planned | - | - | - | - |
| **TD3** | 🚧 Planned | - | - | - | - |

## Environment Support

### Gymnasium

| Category | Status | Notes |
|----------|--------|-------|
| **Classic Control** | ✅ Fully Supported | CartPole, MountainCar, etc. |
| **Box2D** | ✅ Fully Supported | LunarLander, BipedalWalker |
| **Atari** | ✅ Supported | Requires `gymnasium[atari]` |
| **MuJoCo** | ✅ Supported | Requires MuJoCo license |
| **Custom Envs** | ✅ Supported | Via Gymnasium API |

### Built-in Environments

| Environment | Status | Type |
|-------------|--------|------|
| **GridWorld** | ✅ Stable | Navigation |
| **SimpleReacher** | ✅ Stable | Robotics |
| **CryptoTrading** | ✅ Beta | Finance |
| **StockTrading** | ✅ Beta | Finance |

## Tracking & Observability

| Backend | Status | Notes |
|---------|--------|-------|
| **TensorBoard** | ✅ Fully Supported | Built-in |
| **Weights & Biases** | ✅ Fully Supported | Requires `wandb` package |
| **MLflow** | ✅ Supported | Requires `mlflow` package |
| **CSV Export** | ✅ Fully Supported | Built-in |
| **JSON Export** | ✅ Fully Supported | Built-in |

## Features by Version

### v0.2.0 (Current)

- ✅ Complete reproducibility system
- ✅ Robust checkpointing
- ✅ Official benchmarks
- ✅ Plugin system
- ✅ Multi-backend tracking
- ✅ Performance profiling
- ✅ Cost tracking
- ✅ LLM reward frozen mode
- ✅ Security hardening
- ✅ Evaluation reports

### v0.3.0 (Planned Q2 2026)

- 🚧 Distributed training (multi-GPU)
- 🚧 Advanced benchmarks vs SB3/CleanRL
- 🚧 SAC and TD3 algorithms
- 🚧 Enhanced plugin ecosystem
- 🚧 Real-time dashboard

### v1.0.0 (Planned Q4 2026)

- 🚧 Stable API guarantee
- 🚧 Multi-node distributed training
- 🚧 Production deployment tools
- 🚧 Enterprise support options

## Testing Coverage

| Component | Coverage | Status |
|-----------|----------|--------|
| **Core** | >85% | ✅ Good |
| **Agents** | >80% | ✅ Good |
| **Environments** | >75% | ⚠️ Improving |
| **LLM Backends** | >70% | ⚠️ Improving |
| **Tracking** | >80% | ✅ Good |
| **Overall** | >80% | ✅ Good |

## Known Limitations

### Current Limitations

1. **Single-GPU Training**: Multi-GPU support planned for v0.3.0
2. **Memory Usage**: Large replay buffers may require significant RAM
3. **LLM Latency**: Network-based LLMs add latency to training
4. **Windows Path Handling**: Some edge cases with long paths

### Workarounds

1. **Multi-GPU**: Use multiple training runs in parallel
2. **Memory**: Adjust buffer size or use offline algorithms
3. **LLM Latency**: Use caching or local models (Ollama)
4. **Windows Paths**: Use shorter output directory names

## Compatibility Notes

### Breaking Changes from v0.1.x

- Checkpoint format changed (old checkpoints can be loaded but should be re-saved)
- Configuration structure updated (see migration guide)
- Some internal APIs renamed (public API stable)

### Deprecation Timeline

- **v0.3.0**: Warnings for old checkpoint format
- **v0.4.0**: Warnings for direct save/load methods
- **v1.0.0**: Remove deprecated APIs

## Getting Help

### Compatibility Issues

If you encounter compatibility issues:

1. Check this support matrix
2. Review [migration guides](migration_guides.md)
3. Search [GitHub Issues](https://github.com/tonipcv/hugo/issues)
4. Open a new issue with:
   - Platform and Python version
   - Package versions (`pip list`)
   - Error message and traceback
   - Minimal reproduction example

### Feature Requests

For unsupported features:

1. Check the roadmap in this document
2. Search existing feature requests
3. Open a discussion with the `feature-request` tag

## Verification

To verify your installation supports your requirements:

```bash
# Run system diagnostics
hugo doctor

# Check plugin compatibility
hugo plugins

# Run smoke benchmarks
hugo benchmark --suite ppo_cartpole
```

## Updates

This support matrix is updated with each release. Last updated: **v0.2.0** (March 2026)

For the latest information, always refer to the online documentation.
