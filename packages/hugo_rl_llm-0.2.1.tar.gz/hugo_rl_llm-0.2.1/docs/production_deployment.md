# Production Deployment Guide

This guide covers best practices for deploying Hugo RL-LLM Toolkit in production environments.

## Table of Contents

- [Pre-Deployment Checklist](#pre-deployment-checklist)
- [Environment Setup](#environment-setup)
- [Configuration Management](#configuration-management)
- [Monitoring and Observability](#monitoring-and-observability)
- [Security Hardening](#security-hardening)
- [Performance Optimization](#performance-optimization)
- [Disaster Recovery](#disaster-recovery)
- [Scaling Strategies](#scaling-strategies)

---

## Pre-Deployment Checklist

### Code Quality

- [ ] All tests passing (`pytest`)
- [ ] Code coverage >80% (`pytest --cov`)
- [ ] Type checking clean (`mypy rl_llm_toolkit`)
- [ ] Linting clean (`ruff check`)
- [ ] Pre-commit hooks passing
- [ ] Benchmarks meet thresholds (`hugo benchmark`)

### Documentation

- [ ] API documentation complete
- [ ] Configuration examples provided
- [ ] Troubleshooting guide available
- [ ] Migration guide from previous version

### Security

- [ ] Secrets managed via environment variables or vault
- [ ] API keys not hardcoded
- [ ] Input sanitization enabled
- [ ] Circuit breakers configured
- [ ] Rate limiting implemented

### Reproducibility

- [ ] Seed management strategy defined
- [ ] Git commit hash tracked
- [ ] Dependencies pinned in requirements.txt
- [ ] Configuration versioning in place

---

## Environment Setup

### Production Environment Variables

```bash
# Required
export HUGO_ENV=production
export HUGO_SEED=42
export HUGO_OUTPUT_DIR=/data/hugo/outputs

# LLM Backend (if using)
export OPENAI_API_KEY=sk-...
export ANTHROPIC_API_KEY=sk-ant-...

# Tracking
export WANDB_API_KEY=...
export WANDB_PROJECT=hugo-production
export MLFLOW_TRACKING_URI=http://mlflow.example.com

# Security
export HUGO_MAX_PROMPT_LENGTH=4000
export HUGO_ENABLE_SANITIZATION=true
export HUGO_CIRCUIT_BREAKER_THRESHOLD=5

# Performance
export HUGO_NUM_WORKERS=8
export HUGO_BATCH_SIZE=64
export OMP_NUM_THREADS=4
```

### Docker Deployment

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    git \
    && rm -rf /var/lib/apt/lists/*

# Copy and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .
RUN pip install -e .

# Create output directory
RUN mkdir -p /data/hugo/outputs

# Set environment
ENV HUGO_ENV=production
ENV PYTHONUNBUFFERED=1

# Run
CMD ["hugo", "train", "/config/production.yaml"]
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hugo-training
spec:
  replicas: 1
  selector:
    matchLabels:
      app: hugo-training
  template:
    metadata:
      labels:
        app: hugo-training
    spec:
      containers:
      - name: hugo
        image: hugo-rl:latest
        resources:
          requests:
            memory: "8Gi"
            cpu: "4"
          limits:
            memory: "16Gi"
            cpu: "8"
        env:
        - name: HUGO_ENV
          value: "production"
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: hugo-secrets
              key: openai-api-key
        volumeMounts:
        - name: config
          mountPath: /config
        - name: data
          mountPath: /data
      volumes:
      - name: config
        configMap:
          name: hugo-config
      - name: data
        persistentVolumeClaim:
          claimName: hugo-data
```

---

## Configuration Management

### Production Configuration Template

```yaml
# production.yaml
env_name: "LunarLander-v2"
algorithm: "ppo"

training:
  total_timesteps: 1000000
  seed: ${HUGO_SEED}
  learning_rate: 0.0003
  n_steps: 2048
  batch_size: 64
  n_epochs: 10
  gamma: 0.99
  gae_lambda: 0.95
  
  # Checkpointing
  checkpoint_interval: 50000
  max_checkpoints: 5
  
  # Evaluation
  eval_interval: 25000
  eval_episodes: 100

# LLM Configuration (optional)
llm:
  provider: "openai"
  model: "gpt-4o-mini"
  temperature: 0.0
  max_tokens: 500
  timeout: 30
  max_retries: 3

reward_shaping:
  enabled: true
  llm_weight: 0.3
  env_weight: 0.7
  cache_responses: true
  max_cache_size: 10000

# Tracking
tracking:
  tensorboard: true
  wandb: true
  mlflow: false
  csv: true

# Security
security:
  sanitize_prompts: true
  max_prompt_length: 4000
  circuit_breaker_threshold: 5
  circuit_breaker_timeout: 60

# Performance
performance:
  num_workers: 8
  parallel_rollouts: true
  profile_enabled: true

# Output
output_dir: ${HUGO_OUTPUT_DIR}
experiment_name: "production_run_${TIMESTAMP}"
```

### Configuration Validation

```python
from rl_llm_toolkit.core.config import Config
from pydantic import ValidationError

def validate_production_config(config_path: str):
    """Validate production configuration."""
    try:
        with open(config_path, 'r') as f:
            config_dict = yaml.safe_load(f)
        
        config = Config(**config_dict)
        
        # Additional production checks
        assert config.training.seed is not None, "Seed must be set"
        assert config.training.checkpoint_interval > 0, "Checkpointing required"
        
        if config.llm:
            assert config.llm.timeout > 0, "LLM timeout required"
            assert config.llm.max_retries > 0, "LLM retries required"
        
        print("✓ Configuration valid")
        return True
        
    except ValidationError as e:
        print(f"✗ Configuration invalid: {e}")
        return False
```

---

## Monitoring and Observability

### Metrics to Track

**Training Metrics:**
- Episode reward (mean, std, min, max)
- Episode length
- Loss values
- Learning rate
- Gradient norms
- Training throughput (steps/sec)

**LLM Metrics (if applicable):**
- Request latency (p50, p95, p99)
- Tokens used per request
- Cache hit rate
- Estimated cost
- Error rate

**System Metrics:**
- CPU utilization
- Memory usage
- GPU utilization (if applicable)
- Disk I/O
- Network I/O

### Health Checks

```python
# health_check.py
def health_check():
    """Production health check endpoint."""
    checks = {
        'status': 'healthy',
        'checks': {}
    }
    
    # Check GPU availability
    import torch
    checks['checks']['gpu'] = {
        'available': torch.cuda.is_available(),
        'count': torch.cuda.device_count() if torch.cuda.is_available() else 0,
    }
    
    # Check disk space
    import shutil
    disk = shutil.disk_usage('/')
    checks['checks']['disk'] = {
        'free_gb': disk.free / (1024**3),
        'percent_used': (disk.used / disk.total) * 100,
    }
    
    # Check dependencies
    try:
        import rl_llm_toolkit
        checks['checks']['package'] = {
            'version': rl_llm_toolkit.__version__,
            'status': 'ok',
        }
    except Exception as e:
        checks['checks']['package'] = {
            'status': 'error',
            'error': str(e),
        }
        checks['status'] = 'unhealthy'
    
    return checks
```

### Alerting Rules

```yaml
# alerting_rules.yaml
groups:
  - name: hugo_training
    interval: 30s
    rules:
      - alert: TrainingStalled
        expr: rate(training_steps_total[5m]) == 0
        for: 10m
        annotations:
          summary: "Training has stalled"
          
      - alert: HighLLMLatency
        expr: llm_request_duration_p95 > 5
        for: 5m
        annotations:
          summary: "LLM latency above 5s"
          
      - alert: LowReward
        expr: episode_reward_mean < threshold
        for: 1h
        annotations:
          summary: "Mean reward below threshold"
          
      - alert: HighMemoryUsage
        expr: memory_usage_percent > 90
        for: 5m
        annotations:
          summary: "Memory usage critical"
```

---

## Security Hardening

### Input Sanitization

```python
from rl_llm_toolkit.security import PromptSanitizer, SecurityConfig

# Configure sanitizer
config = SecurityConfig(
    max_prompt_length=4000,
    redact_secrets=True,
    block_injection_patterns=True,
)

sanitizer = PromptSanitizer(config)

# Use in production
prompt = get_prompt_from_state(state)
sanitized_prompt, warnings = sanitizer.sanitize_prompt(prompt)

if warnings:
    logger.warning(f"Prompt sanitization warnings: {warnings}")
```

### API Key Management

```python
import os
from pathlib import Path

def get_api_key(provider: str) -> str:
    """Securely retrieve API key."""
    # Try environment variable first
    env_var = f"{provider.upper()}_API_KEY"
    key = os.getenv(env_var)
    
    if key:
        return key
    
    # Try secrets file (for local dev)
    secrets_file = Path.home() / ".hugo" / "secrets.json"
    if secrets_file.exists():
        import json
        with open(secrets_file) as f:
            secrets = json.load(f)
            return secrets.get(provider)
    
    raise ValueError(f"API key for {provider} not found")
```

### Rate Limiting

```python
from rl_llm_toolkit.security import CircuitBreaker

# Configure circuit breaker for LLM calls
llm_breaker = CircuitBreaker(
    name="llm_backend",
    config=CircuitBreakerConfig(
        failure_threshold=5,
        timeout_seconds=60.0,
    ),
    fallback=lambda *args, **kwargs: default_reward,
)

# Use in production
reward = llm_breaker.call(llm_backend.compute_reward, state, action)
```

---

## Performance Optimization

### Parallel Rollouts

```python
from rl_llm_toolkit.distributed import ParallelRolloutManager

# Use parallel rollouts for faster data collection
with ParallelRolloutManager(num_workers=8) as manager:
    rollouts = manager.collect_rollouts(
        env_fn=create_env,
        agent_fn=create_agent,
        num_episodes=100,
    )
```

### Batch Processing

```python
# Process LLM requests in batches
batch_size = 32
states_batch = []

for state in states:
    states_batch.append(state)
    
    if len(states_batch) >= batch_size:
        rewards = llm_backend.compute_rewards_batch(states_batch)
        states_batch = []
```

### Caching Strategy

```python
from functools import lru_cache

# Cache LLM responses
@lru_cache(maxsize=10000)
def cached_llm_reward(state_hash: str, action_hash: str) -> float:
    return llm_backend.compute_reward(state, action)
```

---

## Disaster Recovery

### Backup Strategy

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups/hugo/$(date +%Y%m%d)"
mkdir -p "$BACKUP_DIR"

# Backup checkpoints
cp -r /data/hugo/outputs/checkpoints "$BACKUP_DIR/"

# Backup configurations
cp -r /config "$BACKUP_DIR/"

# Backup metrics
cp -r /data/hugo/outputs/metrics "$BACKUP_DIR/"

# Upload to S3
aws s3 sync "$BACKUP_DIR" "s3://hugo-backups/$(date +%Y%m%d)/"
```

### Recovery Procedure

```bash
# 1. Restore from backup
aws s3 sync "s3://hugo-backups/20260301/" /restore/

# 2. Verify checkpoint
hugo verify-checkpoint /restore/checkpoints/latest.pt

# 3. Resume training
hugo train /restore/config/production.yaml \
  --resume-from /restore/checkpoints/latest.pt
```

---

## Scaling Strategies

### Horizontal Scaling

```yaml
# Multiple training jobs
apiVersion: batch/v1
kind: Job
metadata:
  name: hugo-training-sweep
spec:
  parallelism: 4
  completions: 4
  template:
    spec:
      containers:
      - name: hugo
        image: hugo-rl:latest
        env:
        - name: HUGO_SEED
          value: "$(JOB_COMPLETION_INDEX)"
```

### Vertical Scaling

```yaml
# GPU-accelerated training
resources:
  limits:
    nvidia.com/gpu: 1
    memory: "32Gi"
    cpu: "16"
```

---

## Troubleshooting

### Common Issues

**Issue: Training stalls**
- Check GPU memory
- Verify data pipeline
- Review logs for errors

**Issue: High LLM costs**
- Enable caching
- Use smaller model
- Reduce call frequency

**Issue: Memory leaks**
- Monitor with profiler
- Check for circular references
- Use memory-efficient data structures

---

## Support

For production support:
- GitHub Issues: https://github.com/tonipcv/hugo/issues
- Documentation: https://github.com/tonipcv/hugo#readme
- Enterprise Support: contact@xaseai.com
