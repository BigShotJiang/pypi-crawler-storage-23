# Migration Guides

This document provides step-by-step migration guides for upgrading between major versions of Hugo.

## Table of Contents

- [Migrating from 0.1.x to 0.2.x](#migrating-from-01x-to-02x)
- [Future: 0.2.x to 1.0.0](#future-02x-to-100)

---

## Migrating from 0.1.x to 0.2.x

### Overview

Version 0.2.0 introduces significant production-grade features including:

- Complete reproducibility system
- Robust checkpointing
- Official benchmarks with regression checks
- Plugin system
- Advanced tracking and observability
- Performance profiling and cost tracking
- API contracts and protocols

### Breaking Changes

#### 1. Checkpoint Format

**Old (0.1.x):**
```python
agent.save("model.pt")
```

**New (0.2.x):**
```python
from rl_llm_toolkit.core.checkpoint import CheckpointManager

CheckpointManager.save_checkpoint(
    path=Path("model.pt"),
    agent_type="PPOAgent",
    model_state=agent.get_model_state(),
    total_timesteps=agent._total_timesteps,
    episode_count=agent._episode_count,
)
```

**Migration:** Old checkpoints can still be loaded but won't have full metadata. Re-save using new format.

#### 2. Configuration Structure

**Old (0.1.x):**
```yaml
env_name: CartPole-v1
algorithm: ppo
```

**New (0.2.x):**
```yaml
env_name: CartPole-v1
algorithm: ppo
training:
  seed: 42
  total_timesteps: 100000
```

**Migration:** Add `training` section with explicit seed for reproducibility.

#### 3. Reproducibility

**New Requirement:** All training runs now automatically save reproducibility metadata.

```python
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager

# Set seed before training
ReproducibilityManager.set_global_seed(42)
```

**Migration:** Update training scripts to use `ReproducibilityManager.set_global_seed()`.

### New Features

#### 1. Benchmarks

Run official benchmarks:

```bash
hugo benchmark --algorithm ppo
hugo list-benchmarks
```

#### 2. Reproducibility

Reproduce any training run:

```bash
hugo reproduce /path/to/run_dir
```

#### 3. Plugin System

Discover and use plugins:

```bash
hugo plugins
hugo doctor
```

#### 4. Advanced Tracking

```python
from rl_llm_toolkit.tracking import MetricsTracker, TensorBoardBackend, WandBBackend

tracker = MetricsTracker(
    experiment_name="my_experiment",
    output_dir=Path("./outputs"),
    backends=[
        TensorBoardBackend(log_dir=Path("./logs")),
        WandBBackend(project="hugo-rl", name="experiment-1"),
    ]
)
```

#### 5. Cost Tracking

```python
from rl_llm_toolkit.profiling import CostTracker

tracker = CostTracker(provider="openai", model="gpt-4")
cost = tracker.log_usage(input_tokens=1000, output_tokens=500, step=1)
tracker.print_summary()
```

#### 6. Performance Profiling

```python
from rl_llm_toolkit.profiling import ProfilerContext

with ProfilerContext.profile('training_step'):
    # Your training code
    pass

profiler = ProfilerContext.get_profiler()
profiler.print_summary()
```

### Deprecations

- **Direct model save/load**: Use `CheckpointManager` instead
- **Manual seed setting**: Use `ReproducibilityManager.set_global_seed()`

### Recommended Actions

1. **Update configuration files** to include explicit seeds
2. **Re-save checkpoints** using new format for full metadata
3. **Run benchmarks** to establish baseline performance
4. **Enable tracking backends** for better observability
5. **Review API contracts** if building custom agents/backends

---

## Future: 0.2.x to 1.0.0

### Planned Changes

1. **Stable API Guarantee**: All `rl_llm_toolkit.api.v1` interfaces will be stable
2. **Distributed Training**: Native support for multi-GPU and multi-node training
3. **Advanced Benchmarks**: Comparative benchmarks with SB3/CleanRL
4. **Versioned Documentation**: Full docs versioning with migration tooling

### Deprecation Timeline

- **0.3.0**: Deprecation warnings for old checkpoint format
- **0.4.0**: Deprecation warnings for direct save/load
- **1.0.0**: Remove deprecated APIs

---

## Getting Help

- **Documentation**: https://github.com/tonipcv/hugo#readme
- **Issues**: https://github.com/tonipcv/hugo/issues
- **Discussions**: https://github.com/tonipcv/hugo/discussions

For migration assistance, please open a discussion with the `migration` tag.
