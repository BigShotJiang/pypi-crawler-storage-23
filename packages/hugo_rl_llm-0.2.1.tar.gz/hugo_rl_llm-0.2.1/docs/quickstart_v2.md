# Quick Start Guide - v0.2.0

Get started with Hugo in 5 minutes! This guide covers the essentials for training your first RL agent with production-grade features.

## Installation

```bash
# Install Hugo with all features
pip install hugo-rl-llm[all]

# Or install from source
git clone https://github.com/tonipcv/hugo.git
cd hugo
pip install -e ".[all]"
```

## 30-Second Example

```python
from rl_llm_toolkit import PPOAgent, RLEnvironment

# Create environment and agent
env = RLEnvironment("CartPole-v1")
agent = PPOAgent(env=env, seed=42)

# Train
agent.train(total_timesteps=50000)

# Evaluate
results = agent.evaluate(episodes=10)
print(f"Mean Reward: {results['mean_reward']:.2f}")
```

## 5-Minute Production Example

```python
from pathlib import Path
from rl_llm_toolkit import PPOAgent, RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from rl_llm_toolkit.tracking import MetricsTracker, TensorBoardBackend

# 1. Setup reproducibility
SEED = 42
OUTPUT_DIR = Path("./outputs/my_experiment")
ReproducibilityManager.set_global_seed(SEED)

# 2. Create tracking
tracker = MetricsTracker(
    experiment_name="my_experiment",
    output_dir=OUTPUT_DIR,
    backends=[TensorBoardBackend(log_dir=OUTPUT_DIR / "tensorboard")]
)

# 3. Create environment and agent
env = RLEnvironment("CartPole-v1")
agent = PPOAgent(env=env, seed=SEED)

# 4. Train with tracking
agent.train(total_timesteps=100000)

# 5. Save checkpoint
CheckpointManager.save_checkpoint(
    path=OUTPUT_DIR / "final_model.pt",
    agent_type="PPOAgent",
    model_state=agent.policy.state_dict(),
    total_timesteps=100000,
)

# 6. Evaluate and generate report
from rl_llm_toolkit.evaluation import Evaluator, ReportGenerator, ReportFormat

evaluator = Evaluator()
report = evaluator.evaluate(agent, env, num_episodes=100)
ReportGenerator.generate(report, OUTPUT_DIR / "report.html", ReportFormat.HTML)

tracker.close()
env.close()

print(f"✓ Training complete! View report: {OUTPUT_DIR / 'report.html'}")
```

## Using the CLI

Hugo provides a powerful CLI for common tasks:

```bash
# Train with configuration file
hugo train config.yaml

# Run benchmarks
hugo benchmark --algorithm ppo

# Check system
hugo doctor

# Reproduce a run
hugo reproduce ./outputs/my_experiment

# List available commands
hugo --help
```

### Example Configuration (config.yaml)

```yaml
env_name: "CartPole-v1"
algorithm: "ppo"

training:
  total_timesteps: 100000
  seed: 42
  learning_rate: 0.0003
  batch_size: 64

output_dir: "./outputs"
experiment_name: "my_experiment"
```

## Key Features (v0.2.0)

### 1. Complete Reproducibility

Every run is fully reproducible:

```python
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager

# Set seed for everything (Python, NumPy, PyTorch, Gymnasium)
ReproducibilityManager.set_global_seed(42)

# Metadata automatically saved with:
# - Git commit hash
# - Package version
# - Python version
# - Platform info
# - Full configuration
```

### 2. Robust Checkpointing

Save complete training state:

```python
from rl_llm_toolkit.core.checkpoint import CheckpointManager

# Save everything
CheckpointManager.save_checkpoint(
    path=Path("model.pt"),
    agent_type="PPOAgent",
    model_state=agent.policy.state_dict(),
    optimizer_state=optimizer.state_dict(),
    total_timesteps=50000,
)

# Load and resume
checkpoint = CheckpointManager.load_checkpoint(Path("model.pt"))
agent.policy.load_state_dict(checkpoint['model_state'])
```

### 3. Multi-Backend Tracking

Track metrics everywhere:

```python
from rl_llm_toolkit.tracking import (
    MetricsTracker, 
    TensorBoardBackend, 
    WandBBackend,
    CSVBackend
)

tracker = MetricsTracker(
    experiment_name="exp",
    output_dir=Path("./outputs"),
    backends=[
        TensorBoardBackend(log_dir=Path("./logs")),
        WandBBackend(project="hugo", name="exp1"),
        CSVBackend(output_path=Path("./metrics.csv")),
    ]
)

tracker.log_scalars({"loss": 0.5, "reward": 100}, step=1000)
```

### 4. Performance Profiling

Find bottlenecks automatically:

```python
from rl_llm_toolkit.profiling import ProfilerContext

with ProfilerContext.profile('training_loop'):
    agent.train(total_timesteps=10000)

profiler = ProfilerContext.get_profiler()
profiler.print_summary()  # Shows bottlenecks
```

### 5. Cost Tracking (for LLM backends)

Track LLM usage and costs:

```python
from rl_llm_toolkit.profiling import CostTracker

tracker = CostTracker(provider="openai", model="gpt-4")
cost = tracker.log_usage(input_tokens=1000, output_tokens=500, step=1)

tracker.print_summary()  # Shows total cost
```

### 6. Beautiful Evaluation Reports

Generate comprehensive reports:

```python
from rl_llm_toolkit.evaluation import Evaluator, ReportGenerator, ReportFormat

evaluator = Evaluator()
report = evaluator.evaluate(agent, env, num_episodes=100)

# Generate HTML report with charts
ReportGenerator.generate(report, Path("report.html"), ReportFormat.HTML)

# Also available: JSON, Markdown, CSV
```

### 7. Distributed Training

Faster data collection with parallel rollouts:

```python
from rl_llm_toolkit.distributed import ParallelRolloutManager

with ParallelRolloutManager(num_workers=4) as manager:
    rollouts = manager.collect_rollouts(
        env_fn=create_env,
        agent_fn=create_agent,
        num_episodes=100,
    )
# 2-4x speedup!
```

### 8. Security Hardening

Protect against prompt injection and secrets:

```python
from rl_llm_toolkit.security import PromptSanitizer, CircuitBreaker

# Sanitize prompts
sanitizer = PromptSanitizer()
safe_prompt, warnings = sanitizer.sanitize_prompt(user_prompt)

# Prevent cascading failures
breaker = CircuitBreaker("llm_backend", fallback=default_reward)
reward = breaker.call(llm.compute_reward, state, action)
```

## Next Steps

### Learn More

- **Examples**: Check `examples/` directory for comprehensive examples
- **Documentation**: Read full docs at `docs/`
- **Support Matrix**: See `docs/support_matrix.md` for compatibility
- **Migration Guide**: Upgrading from v0.1.x? See `docs/migration_guides.md`

### Production Deployment

- **Deployment Guide**: `docs/production_deployment.md`
- **Benchmarks**: Run `hugo benchmark` to establish baselines
- **Monitoring**: Setup tracking backends for observability

### Advanced Features

- **LLM Reward Shaping**: Integrate OpenAI/Ollama for reward engineering
- **Offline RL**: Train on fixed datasets with CQL/IQL
- **Multi-Agent**: Competitive/cooperative scenarios with MADDPG
- **Plugin System**: Extend Hugo with custom components

## Common Workflows

### Research Workflow

```bash
# 1. Train with full reproducibility
hugo train config.yaml

# 2. Run benchmarks
hugo benchmark --algorithm ppo

# 3. Generate evaluation report
python -c "
from rl_llm_toolkit.evaluation import Evaluator, ReportGenerator, ReportFormat
# ... generate report
"

# 4. Reproduce exact results
hugo reproduce ./outputs/experiment_name
```

### Production Workflow

```bash
# 1. Validate configuration
hugo train config.yaml --dry-run

# 2. Check system
hugo doctor

# 3. Train with checkpointing
hugo train config.yaml

# 4. Verify checkpoint
hugo verify-checkpoint ./outputs/final_checkpoint.pt

# 5. Deploy model
# (see production_deployment.md)
```

## Troubleshooting

### Common Issues

**Import errors**
```bash
pip install -e ".[all]"
```

**CUDA not available**
```bash
# Check GPU
hugo doctor

# Install PyTorch with CUDA
pip install torch --index-url https://download.pytorch.org/whl/cu118
```

**Low performance**
```bash
# Use parallel rollouts
# See examples/distributed_training_example.py
```

### Getting Help

- **Documentation**: https://github.com/tonipcv/hugo#readme
- **Issues**: https://github.com/tonipcv/hugo/issues
- **Discussions**: https://github.com/tonipcv/hugo/discussions

## What's New in v0.2.0

✨ **Production-Grade Features**
- Complete reproducibility system
- Robust checkpointing with full state
- Official benchmarks with regression checks
- Plugin system for extensibility
- Multi-backend tracking (TensorBoard, W&B, MLflow)
- Performance profiling and cost tracking
- Security hardening (sanitization, circuit breakers)
- Distributed execution (parallel rollouts)
- Beautiful evaluation reports (HTML/JSON/Markdown)

See `docs/changelog_v0.2.0.md` for full details.

---

**Ready to build intelligent agents?** Start with `examples/quickstart_minimal.py`!
