#!/usr/bin/env python3
"""
Minimal quickstart example - get started with Hugo in 5 minutes.

This is the simplest possible example to train an RL agent.
"""

from rl_llm_toolkit import PPOAgent, RLEnvironment

# 1. Create environment
env = RLEnvironment("CartPole-v1")

# 2. Create agent
agent = PPOAgent(env=env, seed=42)

# 3. Train
print("Training agent...")
agent.train(total_timesteps=50000)

# 4. Evaluate
print("\nEvaluating agent...")
results = agent.evaluate(episodes=10)

print(f"\nResults:")
print(f"  Mean Reward: {results['mean_reward']:.2f}")
print(f"  Std Reward: {results['std_reward']:.2f}")

# 5. Save model
agent.save("cartpole_model.pt")
print("\nModel saved to cartpole_model.pt")

env.close()
