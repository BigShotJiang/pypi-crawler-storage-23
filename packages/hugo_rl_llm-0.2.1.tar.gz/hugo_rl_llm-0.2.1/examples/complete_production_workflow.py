#!/usr/bin/env python3
"""
Complete production workflow example demonstrating all major Hugo features.

This comprehensive example shows:
- Reproducibility setup
- Multi-backend tracking
- Performance profiling
- Cost tracking (for LLM backends)
- Security hardening
- Robust checkpointing
- Evaluation with reports
- Proper error handling
"""

import sys
from pathlib import Path

from rl_llm_toolkit.core.environment import RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from rl_llm_toolkit.agents.ppo import PPOAgent
from rl_llm_toolkit.tracking import MetricsTracker, TensorBoardBackend, CSVBackend, JSONBackend
from rl_llm_toolkit.profiling import ProfilerContext, CostTracker
from rl_llm_toolkit.evaluation import Evaluator, ReportGenerator, ReportFormat
from rl_llm_toolkit.security import PromptSanitizer, CircuitBreaker


def main():
    # Configuration
    SEED = 42
    ENV_NAME = "LunarLander-v2"
    TOTAL_TIMESTEPS = 200000
    OUTPUT_DIR = Path("./outputs/complete_workflow")
    
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    print("=" * 70)
    print("Complete Production Workflow Example")
    print("=" * 70)
    
    # 1. Reproducibility Setup
    print("\n[1/8] Setting up reproducibility...")
    
    config = {
        "env_name": ENV_NAME,
        "algorithm": "ppo",
        "training": {
            "total_timesteps": TOTAL_TIMESTEPS,
            "seed": SEED,
            "learning_rate": 3e-4,
            "n_steps": 2048,
            "batch_size": 64,
            "n_epochs": 10,
            "gamma": 0.99,
            "gae_lambda": 0.95,
        }
    }
    
    ReproducibilityManager.set_global_seed(SEED)
    
    metadata = ReproducibilityManager.create_metadata(
        seed=SEED,
        config=config,
    )
    metadata.save(OUTPUT_DIR / "reproducibility.yaml")
    ReproducibilityManager.save_resolved_config(config, OUTPUT_DIR)
    
    print(f"  ✓ Seed: {SEED}")
    print(f"  ✓ Commit: {metadata.commit_hash[:8]}")
    print(f"  ✓ Version: {metadata.package_version}")
    
    # 2. Tracking Setup
    print("\n[2/8] Setting up tracking backends...")
    
    tracker = MetricsTracker(
        experiment_name="complete_workflow",
        output_dir=OUTPUT_DIR,
        backends=[
            TensorBoardBackend(log_dir=OUTPUT_DIR / "tensorboard"),
            CSVBackend(output_path=OUTPUT_DIR / "metrics.csv"),
            JSONBackend(output_path=OUTPUT_DIR / "metrics.json"),
        ]
    )
    tracker.log_config(config)
    
    print("  ✓ TensorBoard backend")
    print("  ✓ CSV backend")
    print("  ✓ JSON backend")
    
    # 3. Security Setup
    print("\n[3/8] Setting up security...")
    
    sanitizer = PromptSanitizer()
    circuit_breaker = CircuitBreaker("training", fallback=lambda: None)
    
    print("  ✓ Prompt sanitizer")
    print("  ✓ Circuit breaker")
    
    # 4. Environment and Agent Setup
    print("\n[4/8] Creating environment and agent...")
    
    env = RLEnvironment(ENV_NAME)
    
    agent = PPOAgent(
        env=env,
        learning_rate=config["training"]["learning_rate"],
        n_steps=config["training"]["n_steps"],
        batch_size=config["training"]["batch_size"],
        n_epochs=config["training"]["n_epochs"],
        gamma=config["training"]["gamma"],
        gae_lambda=config["training"]["gae_lambda"],
        seed=SEED,
    )
    
    print(f"  ✓ Environment: {ENV_NAME}")
    print(f"  ✓ Agent: PPOAgent")
    
    # 5. Training with Profiling
    print("\n[5/8] Training agent...")
    
    checkpoint_interval = 50000
    eval_interval = 25000
    
    try:
        with ProfilerContext.profile('total_training'):
            for step in range(0, TOTAL_TIMESTEPS, 10000):
                current_steps = min(10000, TOTAL_TIMESTEPS - step)
                
                with ProfilerContext.profile('training_iteration'):
                    def train_step():
                        return agent.train(
                            total_timesteps=current_steps,
                            log_interval=5000,
                        )
                    
                    circuit_breaker.call(train_step)
                
                # Evaluation
                if step % eval_interval == 0 and step > 0:
                    with ProfilerContext.profile('evaluation'):
                        eval_results = agent.evaluate(episodes=10, deterministic=True)
                    
                    tracker.log_scalars({
                        'eval/mean_reward': eval_results['mean_reward'],
                        'eval/std_reward': eval_results['std_reward'],
                        'eval/min_reward': eval_results['min_reward'],
                        'eval/max_reward': eval_results['max_reward'],
                    }, step)
                    
                    print(f"  Step {step:6d}: Reward = {eval_results['mean_reward']:7.2f} ± {eval_results['std_reward']:6.2f}")
                
                # Checkpointing
                if step % checkpoint_interval == 0 and step > 0:
                    with ProfilerContext.profile('checkpointing'):
                        checkpoint_path = OUTPUT_DIR / f"checkpoint_{step}.pt"
                        CheckpointManager.save_checkpoint(
                            path=checkpoint_path,
                            agent_type="PPOAgent",
                            model_state=agent.policy.state_dict(),
                            total_timesteps=step,
                            episode_count=agent._episode_count,
                            checkpoint_step=step,
                            reproducibility_metadata=metadata,
                        )
                    print(f"  Checkpoint saved: {checkpoint_path.name}")
        
        print("\n  ✓ Training completed successfully")
        
    except KeyboardInterrupt:
        print("\n  ⚠ Training interrupted by user")
    except Exception as e:
        print(f"\n  ✗ Training error: {e}")
        raise
    
    # 6. Final Checkpoint
    print("\n[6/8] Saving final checkpoint...")
    
    final_checkpoint = OUTPUT_DIR / "final_checkpoint.pt"
    CheckpointManager.save_checkpoint(
        path=final_checkpoint,
        agent_type="PPOAgent",
        model_state=agent.policy.state_dict(),
        total_timesteps=TOTAL_TIMESTEPS,
        episode_count=agent._episode_count,
        checkpoint_step=TOTAL_TIMESTEPS,
        reproducibility_metadata=metadata,
    )
    
    print(f"  ✓ Saved: {final_checkpoint}")
    
    # 7. Comprehensive Evaluation
    print("\n[7/8] Running comprehensive evaluation...")
    
    evaluator = Evaluator(deterministic=True, render=False)
    
    with ProfilerContext.profile('final_evaluation'):
        eval_report = evaluator.evaluate(
            agent=agent,
            env=env,
            num_episodes=100,
            success_threshold=200.0,
        )
    
    print(f"  ✓ Episodes: {eval_report.num_episodes}")
    print(f"  ✓ Mean Reward: {eval_report.mean_reward:.2f} ± {eval_report.std_reward:.2f}")
    print(f"  ✓ Median: {eval_report.median_reward:.2f}")
    print(f"  ✓ Range: [{eval_report.min_reward:.2f}, {eval_report.max_reward:.2f}]")
    if eval_report.success_rate is not None:
        print(f"  ✓ Success Rate: {eval_report.success_rate * 100:.1f}%")
    
    # Generate reports in multiple formats
    ReportGenerator.generate(eval_report, OUTPUT_DIR / "evaluation_report.html", ReportFormat.HTML)
    ReportGenerator.generate(eval_report, OUTPUT_DIR / "evaluation_report.json", ReportFormat.JSON)
    ReportGenerator.generate(eval_report, OUTPUT_DIR / "evaluation_report.md", ReportFormat.MARKDOWN)
    
    print(f"  ✓ Reports generated in HTML, JSON, and Markdown")
    
    # 8. Performance Analysis
    print("\n[8/8] Analyzing performance...")
    
    profiler = ProfilerContext.get_profiler()
    profiler.save(OUTPUT_DIR / "performance_profile.json")
    
    summary = profiler.get_summary()
    bottlenecks = profiler.get_bottlenecks(top_n=3)
    
    print("\n  Top Bottlenecks:")
    for i, (name, total_time) in enumerate(bottlenecks, 1):
        print(f"    {i}. {name}: {total_time:.2f}s")
    
    # Cleanup
    tracker.close()
    env.close()
    
    # Final Summary
    print("\n" + "=" * 70)
    print("Workflow Complete!")
    print("=" * 70)
    print(f"\nAll outputs saved to: {OUTPUT_DIR}")
    print(f"\nTo reproduce this run:")
    print(f"  hugo reproduce {OUTPUT_DIR}")
    print(f"\nTo view TensorBoard:")
    print(f"  tensorboard --logdir {OUTPUT_DIR / 'tensorboard'}")
    print(f"\nTo view evaluation report:")
    print(f"  open {OUTPUT_DIR / 'evaluation_report.html'}")
    
    # Security stats
    sanitizer_stats = sanitizer.get_stats()
    breaker_stats = circuit_breaker.get_stats()
    
    print(f"\nSecurity Stats:")
    print(f"  Sanitizer redactions: {sanitizer_stats['redacted_count']}")
    print(f"  Circuit breaker state: {breaker_stats['state']}")
    print(f"  Total calls: {breaker_stats['total_calls']}")
    print(f"  Failures: {breaker_stats['total_failures']}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nFatal error: {e}", file=sys.stderr)
        sys.exit(1)
