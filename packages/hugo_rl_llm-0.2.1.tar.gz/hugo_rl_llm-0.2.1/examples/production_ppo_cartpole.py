#!/usr/bin/env python3
"""
Production-grade PPO training example with full reproducibility and tracking.

This example demonstrates:
- Complete reproducibility setup
- Robust checkpointing
- Multi-backend tracking (TensorBoard, W&B, CSV)
- Performance profiling
- Proper error handling
"""

import sys
from pathlib import Path

from rl_llm_toolkit.core.environment import RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from rl_llm_toolkit.agents.ppo import PPOAgent
from rl_llm_toolkit.tracking import MetricsTracker, TensorBoardBackend, CSVBackend
from rl_llm_toolkit.profiling import ProfilerContext


def main():
    SEED = 42
    ENV_NAME = "CartPole-v1"
    TOTAL_TIMESTEPS = 100000
    OUTPUT_DIR = Path("./outputs/production_ppo_cartpole")
    
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    config = {
        "env_name": ENV_NAME,
        "algorithm": "ppo",
        "training": {
            "total_timesteps": TOTAL_TIMESTEPS,
            "seed": SEED,
            "learning_rate": 3e-4,
            "n_steps": 2048,
            "batch_size": 64,
            "n_epochs": 10,
        }
    }
    
    ReproducibilityManager.set_global_seed(SEED)
    
    metadata = ReproducibilityManager.create_metadata(
        seed=SEED,
        config=config,
    )
    metadata.save(OUTPUT_DIR / "reproducibility.yaml")
    
    ReproducibilityManager.save_resolved_config(config, OUTPUT_DIR)
    
    tracker = MetricsTracker(
        experiment_name="production_ppo_cartpole",
        output_dir=OUTPUT_DIR,
        backends=[
            TensorBoardBackend(log_dir=OUTPUT_DIR / "tensorboard"),
            CSVBackend(output_path=OUTPUT_DIR / "metrics.csv"),
        ]
    )
    
    tracker.log_config(config)
    
    print(f"Starting training with seed {SEED}")
    print(f"Output directory: {OUTPUT_DIR}")
    
    env = RLEnvironment(ENV_NAME)
    
    agent = PPOAgent(
        env=env,
        learning_rate=config["training"]["learning_rate"],
        n_steps=config["training"]["n_steps"],
        batch_size=config["training"]["batch_size"],
        n_epochs=config["training"]["n_epochs"],
        seed=SEED,
    )
    
    try:
        with ProfilerContext.profile('total_training'):
            for step in range(0, TOTAL_TIMESTEPS, 1000):
                with ProfilerContext.profile('training_iteration'):
                    agent.train(
                        total_timesteps=min(1000, TOTAL_TIMESTEPS - step),
                        log_interval=500,
                    )
                
                if step % 10000 == 0:
                    eval_results = agent.evaluate(episodes=10, deterministic=True)
                    
                    tracker.log_scalars({
                        'eval/mean_reward': eval_results['mean_reward'],
                        'eval/std_reward': eval_results['std_reward'],
                    }, step)
                    
                    print(f"Step {step}: Mean reward = {eval_results['mean_reward']:.2f}")
                
                if step % 20000 == 0 and step > 0:
                    checkpoint_path = OUTPUT_DIR / f"checkpoint_{step}.pt"
                    CheckpointManager.save_checkpoint(
                        path=checkpoint_path,
                        agent_type="PPOAgent",
                        model_state=agent.policy.state_dict(),
                        total_timesteps=step,
                        episode_count=agent._episode_count,
                        checkpoint_step=step,
                        reproducibility_metadata=metadata,
                    )
                    print(f"Checkpoint saved: {checkpoint_path}")
        
        final_checkpoint = OUTPUT_DIR / "final_checkpoint.pt"
        CheckpointManager.save_checkpoint(
            path=final_checkpoint,
            agent_type="PPOAgent",
            model_state=agent.policy.state_dict(),
            total_timesteps=TOTAL_TIMESTEPS,
            episode_count=agent._episode_count,
            checkpoint_step=TOTAL_TIMESTEPS,
            reproducibility_metadata=metadata,
        )
        
        print("\nFinal evaluation...")
        final_results = agent.evaluate(episodes=100, deterministic=True)
        
        print(f"\nFinal Results:")
        print(f"  Mean Reward: {final_results['mean_reward']:.2f} ± {final_results['std_reward']:.2f}")
        print(f"  Min/Max: {final_results['min_reward']:.2f} / {final_results['max_reward']:.2f}")
        
        tracker.log_scalars({
            'final/mean_reward': final_results['mean_reward'],
            'final/std_reward': final_results['std_reward'],
        }, TOTAL_TIMESTEPS)
        
    except KeyboardInterrupt:
        print("\nTraining interrupted by user")
    except Exception as e:
        print(f"\nError during training: {e}")
        raise
    finally:
        profiler = ProfilerContext.get_profiler()
        profiler.print_summary()
        profiler.save(OUTPUT_DIR / "profile.json")
        
        tracker.close()
        env.close()
        
        print(f"\nAll outputs saved to: {OUTPUT_DIR}")
        print(f"To reproduce this run: hugo reproduce {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
