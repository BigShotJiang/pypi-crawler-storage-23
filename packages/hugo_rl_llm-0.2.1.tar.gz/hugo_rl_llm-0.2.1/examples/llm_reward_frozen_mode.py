#!/usr/bin/env python3
"""
Example demonstrating LLM reward frozen mode for reproducibility and A/B testing.

This example shows:
- Recording LLM reward decisions
- Replaying decisions for exact reproducibility
- Comparing different models (A/B testing)
"""

from pathlib import Path

from rl_llm_toolkit.core.environment import RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.agents.ppo import PPOAgent
from rl_llm_toolkit.llm.ollama import OllamaBackend
from rl_llm_toolkit.rewards.frozen_reward import FrozenRewardBackend


def record_baseline():
    """Record baseline LLM reward decisions."""
    print("=== Recording Baseline ===\n")
    
    SEED = 42
    OUTPUT_DIR = Path("./outputs/frozen_reward_baseline")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    ReproducibilityManager.set_global_seed(SEED)
    
    env = RLEnvironment("CartPole-v1")
    llm = OllamaBackend(model="llama3", temperature=0.0)
    
    frozen_backend = FrozenRewardBackend(
        llm_backend=llm,
        mode="record",
        replay_file=OUTPUT_DIR / "reward_decisions.json"
    )
    
    agent = PPOAgent(env=env, seed=SEED)
    
    print("Training with LLM reward recording...")
    for episode in range(5):
        obs, _ = env.reset()
        done = False
        
        while not done:
            action, _ = agent.predict(obs)
            next_obs, base_reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            prompt = f"State: {obs}, Action: {action}, Next: {next_obs}, Reward: {base_reward}"
            
            shaped_reward, metadata = frozen_backend.compute_reward(
                state=obs,
                action=action,
                next_state=next_obs,
                base_reward=base_reward,
                prompt=prompt,
            )
            
            obs = next_obs
        
        print(f"Episode {episode + 1} completed")
    
    frozen_backend.save()
    print(f"\nBaseline decisions saved to: {OUTPUT_DIR / 'reward_decisions.json'}")
    env.close()


def replay_exact():
    """Replay exact same decisions for reproducibility."""
    print("\n=== Replaying Exact Decisions ===\n")
    
    SEED = 42
    REPLAY_FILE = Path("./outputs/frozen_reward_baseline/reward_decisions.json")
    
    if not REPLAY_FILE.exists():
        print("Baseline not found. Run record_baseline() first.")
        return
    
    ReproducibilityManager.set_global_seed(SEED)
    
    env = RLEnvironment("CartPole-v1")
    
    frozen_backend = FrozenRewardBackend(
        llm_backend=None,
        mode="replay",
        replay_file=REPLAY_FILE
    )
    
    agent = PPOAgent(env=env, seed=SEED)
    
    print("Replaying recorded decisions (no LLM calls)...")
    for episode in range(5):
        obs, _ = env.reset()
        done = False
        cache_hits = 0
        
        while not done:
            action, _ = agent.predict(obs)
            next_obs, base_reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            prompt = f"State: {obs}, Action: {action}, Next: {next_obs}, Reward: {base_reward}"
            
            shaped_reward, metadata = frozen_backend.compute_reward(
                state=obs,
                action=action,
                next_state=next_obs,
                base_reward=base_reward,
                prompt=prompt,
            )
            
            if metadata.get('cache_hit'):
                cache_hits += 1
            
            obs = next_obs
        
        print(f"Episode {episode + 1}: Cache hits = {cache_hits}")
    
    print("\nReplay completed - all decisions matched baseline!")
    env.close()


def compare_models():
    """Compare current model with baseline (A/B testing)."""
    print("\n=== Comparing Models (A/B Test) ===\n")
    
    SEED = 42
    REPLAY_FILE = Path("./outputs/frozen_reward_baseline/reward_decisions.json")
    OUTPUT_DIR = Path("./outputs/frozen_reward_comparison")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    if not REPLAY_FILE.exists():
        print("Baseline not found. Run record_baseline() first.")
        return
    
    ReproducibilityManager.set_global_seed(SEED)
    
    env = RLEnvironment("CartPole-v1")
    llm = OllamaBackend(model="llama3", temperature=0.7)
    
    frozen_backend = FrozenRewardBackend(
        llm_backend=llm,
        mode="compare",
        replay_file=REPLAY_FILE
    )
    
    agent = PPOAgent(env=env, seed=SEED)
    
    print("Comparing new model with baseline...")
    for episode in range(5):
        obs, _ = env.reset()
        done = False
        
        while not done:
            action, _ = agent.predict(obs)
            next_obs, base_reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            prompt = f"State: {obs}, Action: {action}, Next: {next_obs}, Reward: {base_reward}"
            
            shaped_reward, metadata = frozen_backend.compute_reward(
                state=obs,
                action=action,
                next_state=next_obs,
                base_reward=base_reward,
                prompt=prompt,
            )
            
            if 'drift' in metadata:
                if metadata['drift'] > 0.1:
                    print(f"  High drift detected: {metadata['drift']:.4f}")
            
            obs = next_obs
        
        print(f"Episode {episode + 1} completed")
    
    report = frozen_backend.get_comparison_report()
    frozen_backend.save_comparison_report(OUTPUT_DIR / "comparison_report.json")
    
    print(f"\nComparison Report:")
    print(f"  Total comparisons: {report['total_comparisons']}")
    print(f"  Mean drift: {report['mean_drift']:.4f}")
    print(f"  Max drift: {report['max_drift']:.4f}")
    print(f"  Std drift: {report['std_drift']:.4f}")
    print(f"\nFull report saved to: {OUTPUT_DIR / 'comparison_report.json'}")
    
    env.close()


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="LLM Frozen Reward Demo")
    parser.add_argument(
        "mode",
        choices=["record", "replay", "compare", "all"],
        help="Mode to run"
    )
    
    args = parser.parse_args()
    
    if args.mode == "record" or args.mode == "all":
        record_baseline()
    
    if args.mode == "replay" or args.mode == "all":
        replay_exact()
    
    if args.mode == "compare" or args.mode == "all":
        compare_models()


if __name__ == "__main__":
    main()
