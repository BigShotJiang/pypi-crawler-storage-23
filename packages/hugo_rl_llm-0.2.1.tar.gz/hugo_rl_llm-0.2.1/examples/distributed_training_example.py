#!/usr/bin/env python3
"""
Example demonstrating distributed parallel rollouts for faster training.

This example shows:
- Parallel environment rollouts
- Worker pool management
- Significant speedup for data collection
"""

import time
from pathlib import Path

from rl_llm_toolkit.core.environment import RLEnvironment
from rl_llm_toolkit.core.reproducibility import ReproducibilityManager
from rl_llm_toolkit.agents.ppo import PPOAgent
from rl_llm_toolkit.distributed import ParallelRolloutManager


def create_env():
    """Factory function to create environment."""
    return RLEnvironment("CartPole-v1")


def create_agent():
    """Factory function to create agent."""
    env = create_env()
    agent = PPOAgent(env=env, seed=42)
    return agent


def sequential_rollouts(num_episodes: int):
    """Collect rollouts sequentially (baseline)."""
    print(f"\n=== Sequential Rollouts ({num_episodes} episodes) ===")
    
    env = create_env()
    agent = create_agent()
    
    start_time = time.time()
    
    total_reward = 0.0
    for episode in range(num_episodes):
        obs, _ = env.reset()
        done = False
        episode_reward = 0.0
        
        while not done:
            action, _ = agent.predict(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            episode_reward += reward
        
        total_reward += episode_reward
    
    elapsed = time.time() - start_time
    
    print(f"Time: {elapsed:.2f}s")
    print(f"Mean reward: {total_reward / num_episodes:.2f}")
    print(f"Episodes/sec: {num_episodes / elapsed:.2f}")
    
    env.close()
    
    return elapsed


def parallel_rollouts(num_episodes: int, num_workers: int = 4):
    """Collect rollouts in parallel."""
    print(f"\n=== Parallel Rollouts ({num_episodes} episodes, {num_workers} workers) ===")
    
    start_time = time.time()
    
    with ParallelRolloutManager(num_workers=num_workers) as manager:
        results = manager.collect_rollouts(
            env_fn=create_env,
            agent_fn=create_agent,
            num_episodes=num_episodes,
            max_steps_per_episode=500,
        )
    
    elapsed = time.time() - start_time
    
    total_reward = sum(r.total_reward for r in results)
    mean_reward = total_reward / len(results)
    
    print(f"Time: {elapsed:.2f}s")
    print(f"Mean reward: {mean_reward:.2f}")
    print(f"Episodes/sec: {num_episodes / elapsed:.2f}")
    print(f"Workers used: {len(set(r.worker_id for r in results))}")
    
    return elapsed


def main():
    ReproducibilityManager.set_global_seed(42)
    
    num_episodes = 20
    
    print("=" * 60)
    print("Distributed Training Example")
    print("=" * 60)
    
    sequential_time = sequential_rollouts(num_episodes)
    
    parallel_time_2 = parallel_rollouts(num_episodes, num_workers=2)
    parallel_time_4 = parallel_rollouts(num_episodes, num_workers=4)
    
    print("\n" + "=" * 60)
    print("Performance Comparison")
    print("=" * 60)
    print(f"Sequential:        {sequential_time:.2f}s (baseline)")
    print(f"Parallel (2 CPUs): {parallel_time_2:.2f}s ({sequential_time/parallel_time_2:.2f}x speedup)")
    print(f"Parallel (4 CPUs): {parallel_time_4:.2f}s ({sequential_time/parallel_time_4:.2f}x speedup)")
    print("\nNote: Speedup depends on episode length and computation overhead")


if __name__ == "__main__":
    main()
