import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np

from rl_llm_toolkit.llm.base import LLMBackend


class FrozenRewardBackend:
    """LLM reward backend that can record and replay decisions for reproducibility."""
    
    def __init__(
        self,
        llm_backend: Optional[LLMBackend] = None,
        mode: str = "record",
        replay_file: Optional[Path] = None,
    ):
        """
        Args:
            llm_backend: The actual LLM backend (required for 'record' mode)
            mode: 'record' to save decisions, 'replay' to use saved decisions, 'compare' for A/B testing
            replay_file: Path to save/load recorded decisions
        """
        if mode not in ["record", "replay", "compare"]:
            raise ValueError(f"Invalid mode: {mode}. Must be 'record', 'replay', or 'compare'")
        
        if mode == "record" and llm_backend is None:
            raise ValueError("llm_backend required for 'record' mode")
        
        self.llm_backend = llm_backend
        self.mode = mode
        self.replay_file = Path(replay_file) if replay_file else None
        
        self.recorded_decisions: Dict[str, Any] = {}
        self.replay_decisions: Dict[str, Any] = {}
        self.comparison_results: list = []
        
        if mode in ["replay", "compare"] and replay_file:
            self._load_replay_file()
    
    def _compute_state_hash(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        prompt: str,
    ) -> str:
        """Compute deterministic hash of state transition and prompt."""
        state_str = np.array2string(state, precision=6, suppress_small=True)
        action_str = np.array2string(action, precision=6, suppress_small=True)
        next_state_str = np.array2string(next_state, precision=6, suppress_small=True)
        
        combined = f"{state_str}|{action_str}|{next_state_str}|{prompt}"
        return hashlib.sha256(combined.encode()).hexdigest()
    
    def compute_reward(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Compute reward with recording/replay capability.
        
        Returns:
            Tuple of (reward, metadata)
        """
        state_hash = self._compute_state_hash(state, action, next_state, prompt)
        
        if self.mode == "replay":
            return self._replay_decision(state_hash, base_reward)
        
        elif self.mode == "record":
            return self._record_decision(
                state_hash, state, action, next_state, base_reward, prompt, context
            )
        
        elif self.mode == "compare":
            return self._compare_decision(
                state_hash, state, action, next_state, base_reward, prompt, context
            )
        
        raise ValueError(f"Invalid mode: {self.mode}")
    
    def _replay_decision(self, state_hash: str, base_reward: float) -> Tuple[float, Dict[str, Any]]:
        """Replay a previously recorded decision."""
        if state_hash not in self.replay_decisions:
            return base_reward, {
                'source': 'fallback',
                'reason': 'state_hash_not_found',
                'cache_hit': False,
            }
        
        decision = self.replay_decisions[state_hash]
        return decision['llm_reward'], {
            'source': 'replay',
            'cache_hit': True,
            'original_timestamp': decision.get('timestamp'),
            'original_model': decision.get('model'),
        }
    
    def _record_decision(
        self,
        state_hash: str,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        prompt: str,
        context: Optional[Dict[str, Any]],
    ) -> Tuple[float, Dict[str, Any]]:
        """Record a new LLM decision."""
        from datetime import datetime
        
        response = self.llm_backend.generate(prompt)
        llm_reward = self._parse_reward_from_response(response, base_reward)
        
        self.recorded_decisions[state_hash] = {
            'state': state.tolist(),
            'action': action.tolist(),
            'next_state': next_state.tolist(),
            'base_reward': base_reward,
            'llm_reward': llm_reward,
            'prompt': prompt,
            'response': response,
            'timestamp': datetime.utcnow().isoformat(),
            'model': getattr(self.llm_backend, 'model', 'unknown'),
            'context': context,
        }
        
        return llm_reward, {
            'source': 'llm',
            'cache_hit': False,
            'response': response,
        }
    
    def _compare_decision(
        self,
        state_hash: str,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        prompt: str,
        context: Optional[Dict[str, Any]],
    ) -> Tuple[float, Dict[str, Any]]:
        """Compare current LLM decision with recorded baseline."""
        response = self.llm_backend.generate(prompt)
        current_reward = self._parse_reward_from_response(response, base_reward)
        
        if state_hash in self.replay_decisions:
            baseline_reward = self.replay_decisions[state_hash]['llm_reward']
            drift = abs(current_reward - baseline_reward)
            
            comparison = {
                'state_hash': state_hash,
                'baseline_reward': baseline_reward,
                'current_reward': current_reward,
                'drift': drift,
                'baseline_model': self.replay_decisions[state_hash].get('model'),
                'current_model': getattr(self.llm_backend, 'model', 'unknown'),
            }
            
            self.comparison_results.append(comparison)
            
            return current_reward, {
                'source': 'compare',
                'cache_hit': True,
                'drift': drift,
                'baseline_reward': baseline_reward,
            }
        
        return current_reward, {
            'source': 'compare',
            'cache_hit': False,
            'reason': 'no_baseline',
        }
    
    def _parse_reward_from_response(self, response: str, base_reward: float) -> float:
        """Parse reward value from LLM response."""
        try:
            import re
            numbers = re.findall(r'-?\d+\.?\d*', response)
            if numbers:
                return float(numbers[0])
            return base_reward
        except Exception:
            return base_reward
    
    def save(self, path: Optional[Path] = None) -> None:
        """Save recorded decisions to file."""
        if path is None:
            path = self.replay_file
        
        if path is None:
            raise ValueError("No path specified for saving")
        
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, 'w') as f:
            json.dump({
                'decisions': self.recorded_decisions,
                'metadata': {
                    'total_decisions': len(self.recorded_decisions),
                    'mode': self.mode,
                }
            }, f, indent=2)
    
    def _load_replay_file(self) -> None:
        """Load replay decisions from file."""
        if not self.replay_file.exists():
            raise FileNotFoundError(f"Replay file not found: {self.replay_file}")
        
        with open(self.replay_file, 'r') as f:
            data = json.load(f)
            self.replay_decisions = data.get('decisions', {})
    
    def get_comparison_report(self) -> Dict[str, Any]:
        """Generate drift comparison report."""
        if not self.comparison_results:
            return {'error': 'No comparison data available'}
        
        drifts = [r['drift'] for r in self.comparison_results]
        
        return {
            'total_comparisons': len(self.comparison_results),
            'mean_drift': float(np.mean(drifts)),
            'max_drift': float(np.max(drifts)),
            'std_drift': float(np.std(drifts)),
            'comparisons': self.comparison_results,
        }
    
    def save_comparison_report(self, path: Path) -> None:
        """Save comparison report to file."""
        report = self.get_comparison_report()
        
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(report, f, indent=2)
