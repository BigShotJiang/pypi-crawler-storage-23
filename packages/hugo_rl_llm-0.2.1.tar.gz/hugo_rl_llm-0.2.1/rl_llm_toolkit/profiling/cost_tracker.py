import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

import numpy as np


@dataclass
class LLMCostConfig:
    """Cost configuration for different LLM providers and models."""
    
    provider: str
    model: str
    cost_per_1k_input_tokens: float
    cost_per_1k_output_tokens: float
    
    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost for given token counts."""
        input_cost = (input_tokens / 1000) * self.cost_per_1k_input_tokens
        output_cost = (output_tokens / 1000) * self.cost_per_1k_output_tokens
        return input_cost + output_cost


class LLMCostEstimator:
    """Estimate costs for different LLM providers."""
    
    COST_CONFIGS = {
        'openai': {
            'gpt-4': LLMCostConfig('openai', 'gpt-4', 0.03, 0.06),
            'gpt-4-turbo': LLMCostConfig('openai', 'gpt-4-turbo', 0.01, 0.03),
            'gpt-3.5-turbo': LLMCostConfig('openai', 'gpt-3.5-turbo', 0.0005, 0.0015),
            'gpt-4o': LLMCostConfig('openai', 'gpt-4o', 0.005, 0.015),
            'gpt-4o-mini': LLMCostConfig('openai', 'gpt-4o-mini', 0.00015, 0.0006),
        },
        'anthropic': {
            'claude-3-opus': LLMCostConfig('anthropic', 'claude-3-opus', 0.015, 0.075),
            'claude-3-sonnet': LLMCostConfig('anthropic', 'claude-3-sonnet', 0.003, 0.015),
            'claude-3-haiku': LLMCostConfig('anthropic', 'claude-3-haiku', 0.00025, 0.00125),
        },
        'ollama': {
            'default': LLMCostConfig('ollama', 'local', 0.0, 0.0),
        },
    }
    
    @classmethod
    def get_config(cls, provider: str, model: str) -> Optional[LLMCostConfig]:
        """Get cost configuration for a provider and model."""
        provider_configs = cls.COST_CONFIGS.get(provider.lower(), {})
        
        if model in provider_configs:
            return provider_configs[model]
        
        for config_model, config in provider_configs.items():
            if config_model in model.lower():
                return config
        
        if provider.lower() == 'ollama':
            return cls.COST_CONFIGS['ollama']['default']
        
        return None
    
    @classmethod
    def estimate(
        cls,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> Optional[float]:
        """Estimate cost for a single LLM call."""
        config = cls.get_config(provider, model)
        if config is None:
            return None
        
        return config.estimate_cost(input_tokens, output_tokens)


@dataclass
class CostRecord:
    """Record of a single LLM cost event."""
    
    timestamp: str
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    estimated_cost: float
    step: int
    episode: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'provider': self.provider,
            'model': self.model,
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'estimated_cost': self.estimated_cost,
            'step': self.step,
            'episode': self.episode,
            'metadata': self.metadata,
        }


class CostTracker:
    """Track and analyze LLM usage costs during training."""
    
    def __init__(self, provider: str, model: str):
        self.provider = provider
        self.model = model
        self.records: List[CostRecord] = []
        
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_estimated_cost = 0.0
        
        self.cost_config = LLMCostEstimator.get_config(provider, model)
    
    def log_usage(
        self,
        input_tokens: int,
        output_tokens: int,
        step: int,
        episode: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> float:
        """Log LLM usage and return estimated cost."""
        estimated_cost = 0.0
        
        if self.cost_config:
            estimated_cost = self.cost_config.estimate_cost(input_tokens, output_tokens)
        
        record = CostRecord(
            timestamp=datetime.utcnow().isoformat(),
            provider=self.provider,
            model=self.model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            estimated_cost=estimated_cost,
            step=step,
            episode=episode,
            metadata=metadata or {},
        )
        
        self.records.append(record)
        
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.total_estimated_cost += estimated_cost
        
        return estimated_cost
    
    def get_summary(self) -> Dict[str, Any]:
        """Get cost summary statistics."""
        if not self.records:
            return {
                'total_calls': 0,
                'total_cost': 0.0,
                'total_tokens': 0,
            }
        
        costs = [r.estimated_cost for r in self.records]
        input_tokens = [r.input_tokens for r in self.records]
        output_tokens = [r.output_tokens for r in self.records]
        
        return {
            'provider': self.provider,
            'model': self.model,
            'total_calls': len(self.records),
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'total_tokens': self.total_input_tokens + self.total_output_tokens,
            'total_estimated_cost': self.total_estimated_cost,
            'mean_cost_per_call': np.mean(costs) if costs else 0.0,
            'mean_input_tokens': np.mean(input_tokens) if input_tokens else 0.0,
            'mean_output_tokens': np.mean(output_tokens) if output_tokens else 0.0,
            'cost_per_1k_tokens': (
                (self.total_estimated_cost / (self.total_input_tokens + self.total_output_tokens)) * 1000
                if (self.total_input_tokens + self.total_output_tokens) > 0 else 0.0
            ),
        }
    
    def get_cost_by_episode(self) -> Dict[int, float]:
        """Get total cost grouped by episode."""
        episode_costs = {}
        
        for record in self.records:
            if record.episode is not None:
                if record.episode not in episode_costs:
                    episode_costs[record.episode] = 0.0
                episode_costs[record.episode] += record.estimated_cost
        
        return episode_costs
    
    def get_cost_trend(self, window_size: int = 100) -> List[float]:
        """Get moving average of cost per call."""
        if len(self.records) < window_size:
            return [r.estimated_cost for r in self.records]
        
        costs = [r.estimated_cost for r in self.records]
        trend = []
        
        for i in range(len(costs) - window_size + 1):
            window = costs[i:i + window_size]
            trend.append(np.mean(window))
        
        return trend
    
    def estimate_total_cost(self, total_episodes: int) -> Dict[str, float]:
        """Estimate total cost for a full training run."""
        if not self.records:
            return {
                'estimated_total_cost': 0.0,
                'confidence': 'no_data',
            }
        
        episode_costs = self.get_cost_by_episode()
        
        if not episode_costs:
            mean_cost_per_call = np.mean([r.estimated_cost for r in self.records])
            calls_per_episode = len(self.records) / max(1, len(set(r.step for r in self.records)))
            estimated_cost = mean_cost_per_call * calls_per_episode * total_episodes
            
            return {
                'estimated_total_cost': estimated_cost,
                'mean_cost_per_call': mean_cost_per_call,
                'estimated_calls_per_episode': calls_per_episode,
                'confidence': 'low',
            }
        
        mean_cost_per_episode = np.mean(list(episode_costs.values()))
        std_cost_per_episode = np.std(list(episode_costs.values()))
        
        estimated_cost = mean_cost_per_episode * total_episodes
        
        return {
            'estimated_total_cost': estimated_cost,
            'mean_cost_per_episode': mean_cost_per_episode,
            'std_cost_per_episode': std_cost_per_episode,
            'episodes_sampled': len(episode_costs),
            'confidence': 'high' if len(episode_costs) > 10 else 'medium',
        }
    
    def print_summary(self) -> None:
        """Print formatted cost summary."""
        from rich.console import Console
        from rich.table import Table
        
        console = Console()
        summary = self.get_summary()
        
        table = Table(title="LLM Cost Summary")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="magenta")
        
        table.add_row("Provider", summary['provider'])
        table.add_row("Model", summary['model'])
        table.add_row("Total Calls", f"{summary['total_calls']:,}")
        table.add_row("Total Tokens", f"{summary['total_tokens']:,}")
        table.add_row("Input Tokens", f"{summary['total_input_tokens']:,}")
        table.add_row("Output Tokens", f"{summary['total_output_tokens']:,}")
        table.add_row("Total Cost", f"${summary['total_estimated_cost']:.4f}")
        table.add_row("Mean Cost/Call", f"${summary['mean_cost_per_call']:.6f}")
        table.add_row("Cost per 1K Tokens", f"${summary['cost_per_1k_tokens']:.6f}")
        
        console.print(table)
    
    def save(self, path: Path) -> None:
        """Save cost tracking data to file."""
        data = {
            'summary': self.get_summary(),
            'records': [r.to_dict() for r in self.records],
            'episode_costs': {
                str(k): v for k, v in self.get_cost_by_episode().items()
            },
        }
        
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, path: Path) -> None:
        """Load cost tracking data from file."""
        with open(path, 'r') as f:
            data = json.load(f)
        
        self.records = [CostRecord(**r) for r in data.get('records', [])]
        
        self.total_input_tokens = sum(r.input_tokens for r in self.records)
        self.total_output_tokens = sum(r.output_tokens for r in self.records)
        self.total_estimated_cost = sum(r.estimated_cost for r in self.records)
