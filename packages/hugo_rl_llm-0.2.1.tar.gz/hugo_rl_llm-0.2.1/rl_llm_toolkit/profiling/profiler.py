import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from collections import defaultdict
import json
from pathlib import Path

import numpy as np


@dataclass
class ProfileRecord:
    name: str
    start_time: float
    end_time: float
    duration: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'duration': self.duration,
            'metadata': self.metadata,
        }


class PerformanceProfiler:
    """Performance profiler for tracking execution times and bottlenecks."""
    
    def __init__(self):
        self.records: List[ProfileRecord] = []
        self._active_timers: Dict[str, float] = {}
        self._section_times: Dict[str, List[float]] = defaultdict(list)
    
    def start(self, name: str) -> None:
        """Start timing a section."""
        self._active_timers[name] = time.perf_counter()
    
    def stop(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> float:
        """Stop timing a section and record the duration."""
        if name not in self._active_timers:
            raise ValueError(f"Timer '{name}' was not started")
        
        start_time = self._active_timers.pop(name)
        end_time = time.perf_counter()
        duration = end_time - start_time
        
        record = ProfileRecord(
            name=name,
            start_time=start_time,
            end_time=end_time,
            duration=duration,
            metadata=metadata or {},
        )
        
        self.records.append(record)
        self._section_times[name].append(duration)
        
        return duration
    
    @contextmanager
    def profile(self, name: str, metadata: Optional[Dict[str, Any]] = None):
        """Context manager for profiling a code block."""
        self.start(name)
        try:
            yield
        finally:
            self.stop(name, metadata)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics for all profiled sections."""
        summary = {}
        
        for name, times in self._section_times.items():
            if times:
                summary[name] = {
                    'count': len(times),
                    'total': sum(times),
                    'mean': np.mean(times),
                    'std': np.std(times),
                    'min': np.min(times),
                    'max': np.max(times),
                    'p50': np.percentile(times, 50),
                    'p95': np.percentile(times, 95),
                    'p99': np.percentile(times, 99),
                }
        
        return summary
    
    def get_bottlenecks(self, top_n: int = 5) -> List[tuple[str, float]]:
        """Identify the top N bottlenecks by total time."""
        total_times = {
            name: sum(times) 
            for name, times in self._section_times.items()
        }
        
        sorted_times = sorted(
            total_times.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        return sorted_times[:top_n]
    
    def print_summary(self) -> None:
        """Print formatted summary of profiling results."""
        from rich.console import Console
        from rich.table import Table
        
        console = Console()
        summary = self.get_summary()
        
        table = Table(title="Performance Profile")
        table.add_column("Section", style="cyan")
        table.add_column("Count", style="magenta")
        table.add_column("Total (s)", style="yellow")
        table.add_column("Mean (s)", style="green")
        table.add_column("P95 (s)", style="blue")
        
        for name, stats in sorted(summary.items(), key=lambda x: x[1]['total'], reverse=True):
            table.add_row(
                name,
                str(stats['count']),
                f"{stats['total']:.4f}",
                f"{stats['mean']:.4f}",
                f"{stats['p95']:.4f}",
            )
        
        console.print(table)
        
        bottlenecks = self.get_bottlenecks()
        if bottlenecks:
            console.print("\n[bold red]Top Bottlenecks:[/bold red]")
            for i, (name, total_time) in enumerate(bottlenecks, 1):
                console.print(f"{i}. {name}: {total_time:.4f}s")
    
    def save(self, path: Path) -> None:
        """Save profiling data to file."""
        data = {
            'summary': self.get_summary(),
            'records': [r.to_dict() for r in self.records],
            'bottlenecks': [
                {'name': name, 'total_time': time}
                for name, time in self.get_bottlenecks(10)
            ],
        }
        
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def reset(self) -> None:
        """Reset all profiling data."""
        self.records.clear()
        self._active_timers.clear()
        self._section_times.clear()


class ProfilerContext:
    """Global profiler context for easy access."""
    
    _instance: Optional[PerformanceProfiler] = None
    
    @classmethod
    def get_profiler(cls) -> PerformanceProfiler:
        """Get or create the global profiler instance."""
        if cls._instance is None:
            cls._instance = PerformanceProfiler()
        return cls._instance
    
    @classmethod
    def reset(cls) -> None:
        """Reset the global profiler."""
        if cls._instance is not None:
            cls._instance.reset()
    
    @classmethod
    @contextmanager
    def profile(cls, name: str, metadata: Optional[Dict[str, Any]] = None):
        """Profile a code block using the global profiler."""
        profiler = cls.get_profiler()
        with profiler.profile(name, metadata):
            yield
