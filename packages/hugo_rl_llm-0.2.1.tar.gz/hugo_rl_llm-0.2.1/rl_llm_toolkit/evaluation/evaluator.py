from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

import numpy as np

from rl_llm_toolkit.api.v1 import AgentProtocol, EnvAdapterProtocol


@dataclass
class EpisodeResult:
    episode_id: int
    total_reward: float
    episode_length: int
    success: bool
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvaluationReport:
    agent_type: str
    env_name: str
    num_episodes: int
    timestamp: str
    
    mean_reward: float
    std_reward: float
    min_reward: float
    max_reward: float
    median_reward: float
    
    mean_length: float
    std_length: float
    
    success_rate: Optional[float]
    
    episode_results: List[EpisodeResult]
    
    percentiles: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent_type': self.agent_type,
            'env_name': self.env_name,
            'num_episodes': self.num_episodes,
            'timestamp': self.timestamp,
            'metrics': {
                'mean_reward': self.mean_reward,
                'std_reward': self.std_reward,
                'min_reward': self.min_reward,
                'max_reward': self.max_reward,
                'median_reward': self.median_reward,
                'mean_length': self.mean_length,
                'std_length': self.std_length,
                'success_rate': self.success_rate,
                'percentiles': self.percentiles,
            },
            'episode_results': [
                {
                    'episode_id': ep.episode_id,
                    'total_reward': ep.total_reward,
                    'episode_length': ep.episode_length,
                    'success': ep.success,
                    'metadata': ep.metadata,
                }
                for ep in self.episode_results
            ],
            'metadata': self.metadata,
        }


class Evaluator:
    """Comprehensive agent evaluator with detailed reporting."""
    
    def __init__(self, deterministic: bool = True, render: bool = False):
        self.deterministic = deterministic
        self.render = render
    
    def evaluate(
        self,
        agent: AgentProtocol,
        env: EnvAdapterProtocol,
        num_episodes: int,
        success_threshold: Optional[float] = None,
        max_steps_per_episode: Optional[int] = None,
    ) -> EvaluationReport:
        """
        Evaluate agent on environment.
        
        Args:
            agent: Agent to evaluate
            env: Environment to evaluate on
            num_episodes: Number of episodes to run
            success_threshold: Reward threshold for success (optional)
            max_steps_per_episode: Maximum steps per episode (optional)
            
        Returns:
            Detailed evaluation report
        """
        episode_results = []
        
        for episode_id in range(num_episodes):
            result = self._run_episode(
                agent=agent,
                env=env,
                episode_id=episode_id,
                success_threshold=success_threshold,
                max_steps_per_episode=max_steps_per_episode,
            )
            episode_results.append(result)
        
        return self._generate_report(
            agent=agent,
            env=env,
            episode_results=episode_results,
        )
    
    def _run_episode(
        self,
        agent: AgentProtocol,
        env: EnvAdapterProtocol,
        episode_id: int,
        success_threshold: Optional[float],
        max_steps_per_episode: Optional[int],
    ) -> EpisodeResult:
        """Run a single evaluation episode."""
        obs, info = env.reset()
        done = False
        total_reward = 0.0
        episode_length = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=self.deterministic)
            obs, reward, terminated, truncated, info = env.step(action)
            
            total_reward += reward
            episode_length += 1
            
            if self.render:
                env.render()
            
            done = terminated or truncated
            
            if max_steps_per_episode and episode_length >= max_steps_per_episode:
                done = True
        
        success = (
            total_reward >= success_threshold
            if success_threshold is not None
            else info.get('success', False)
        )
        
        return EpisodeResult(
            episode_id=episode_id,
            total_reward=total_reward,
            episode_length=episode_length,
            success=success,
            metadata=info,
        )
    
    def _generate_report(
        self,
        agent: AgentProtocol,
        env: EnvAdapterProtocol,
        episode_results: List[EpisodeResult],
    ) -> EvaluationReport:
        """Generate comprehensive evaluation report."""
        rewards = [ep.total_reward for ep in episode_results]
        lengths = [ep.episode_length for ep in episode_results]
        successes = [ep.success for ep in episode_results]
        
        percentiles = {
            'p25': float(np.percentile(rewards, 25)),
            'p50': float(np.percentile(rewards, 50)),
            'p75': float(np.percentile(rewards, 75)),
            'p90': float(np.percentile(rewards, 90)),
            'p95': float(np.percentile(rewards, 95)),
            'p99': float(np.percentile(rewards, 99)),
        }
        
        agent_type = type(agent).__name__ if hasattr(agent, '__class__') else 'Unknown'
        env_name = getattr(env, 'env_id', 'Unknown')
        
        return EvaluationReport(
            agent_type=agent_type,
            env_name=env_name,
            num_episodes=len(episode_results),
            timestamp=datetime.utcnow().isoformat(),
            mean_reward=float(np.mean(rewards)),
            std_reward=float(np.std(rewards)),
            min_reward=float(np.min(rewards)),
            max_reward=float(np.max(rewards)),
            median_reward=float(np.median(rewards)),
            mean_length=float(np.mean(lengths)),
            std_length=float(np.std(lengths)),
            success_rate=float(np.mean(successes)) if any(successes) else None,
            episode_results=episode_results,
            percentiles=percentiles,
        )
