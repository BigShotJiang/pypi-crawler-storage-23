import json
from enum import Enum
from pathlib import Path
from typing import Optional

from rl_llm_toolkit.evaluation.evaluator import EvaluationReport


class ReportFormat(Enum):
    JSON = "json"
    HTML = "html"
    MARKDOWN = "markdown"
    CSV = "csv"


class ReportGenerator:
    """Generate evaluation reports in various formats."""
    
    @staticmethod
    def generate(
        report: EvaluationReport,
        output_path: Path,
        format: ReportFormat = ReportFormat.HTML,
    ) -> None:
        """Generate report in specified format."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == ReportFormat.JSON:
            ReportGenerator._generate_json(report, output_path)
        elif format == ReportFormat.HTML:
            ReportGenerator._generate_html(report, output_path)
        elif format == ReportFormat.MARKDOWN:
            ReportGenerator._generate_markdown(report, output_path)
        elif format == ReportFormat.CSV:
            ReportGenerator._generate_csv(report, output_path)
    
    @staticmethod
    def _generate_json(report: EvaluationReport, output_path: Path) -> None:
        """Generate JSON report."""
        with open(output_path, 'w') as f:
            json.dump(report.to_dict(), f, indent=2)
    
    @staticmethod
    def _generate_html(report: EvaluationReport, output_path: Path) -> None:
        """Generate HTML report with charts."""
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Evaluation Report - {report.agent_type} on {report.env_name}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            margin: 0 0 10px 0;
        }}
        .header p {{
            margin: 5px 0;
            opacity: 0.9;
        }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .metric-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .metric-card h3 {{
            margin: 0 0 10px 0;
            color: #667eea;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .metric-value {{
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }}
        .metric-subtitle {{
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }}
        .success-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }}
        .success-badge.high {{
            background: #10b981;
            color: white;
        }}
        .success-badge.medium {{
            background: #f59e0b;
            color: white;
        }}
        .success-badge.low {{
            background: #ef4444;
            color: white;
        }}
        table {{
            width: 100%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-collapse: collapse;
        }}
        th {{
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
        }}
        td {{
            padding: 12px;
            border-bottom: 1px solid #eee;
        }}
        tr:hover {{
            background: #f9fafb;
        }}
        .percentiles {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        .percentiles h2 {{
            margin-top: 0;
        }}
        .percentile-bar {{
            display: flex;
            align-items: center;
            margin: 10px 0;
        }}
        .percentile-label {{
            width: 60px;
            font-weight: bold;
            color: #667eea;
        }}
        .percentile-value {{
            flex: 1;
            height: 30px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            border-radius: 4px;
            display: flex;
            align-items: center;
            padding: 0 10px;
            color: white;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Evaluation Report</h1>
        <p><strong>Agent:</strong> {report.agent_type}</p>
        <p><strong>Environment:</strong> {report.env_name}</p>
        <p><strong>Episodes:</strong> {report.num_episodes}</p>
        <p><strong>Timestamp:</strong> {report.timestamp}</p>
    </div>
    
    <div class="metrics-grid">
        <div class="metric-card">
            <h3>Mean Reward</h3>
            <div class="metric-value">{report.mean_reward:.2f}</div>
            <div class="metric-subtitle">± {report.std_reward:.2f}</div>
        </div>
        
        <div class="metric-card">
            <h3>Median Reward</h3>
            <div class="metric-value">{report.median_reward:.2f}</div>
        </div>
        
        <div class="metric-card">
            <h3>Min / Max</h3>
            <div class="metric-value">{report.min_reward:.1f} / {report.max_reward:.1f}</div>
        </div>
        
        <div class="metric-card">
            <h3>Mean Length</h3>
            <div class="metric-value">{report.mean_length:.1f}</div>
            <div class="metric-subtitle">± {report.std_length:.1f}</div>
        </div>
        
        {f'''
        <div class="metric-card">
            <h3>Success Rate</h3>
            <div class="metric-value">{report.success_rate * 100:.1f}%</div>
            <span class="success-badge {
                "high" if report.success_rate >= 0.8 else "medium" if report.success_rate >= 0.5 else "low"
            }">{
                "Excellent" if report.success_rate >= 0.8 else "Good" if report.success_rate >= 0.5 else "Needs Improvement"
            }</span>
        </div>
        ''' if report.success_rate is not None else ''}
    </div>
    
    <div class="percentiles">
        <h2>Reward Distribution (Percentiles)</h2>
        {self._generate_percentile_bars(report.percentiles, report.max_reward)}
    </div>
    
    <h2>Episode Results</h2>
    <table>
        <thead>
            <tr>
                <th>Episode</th>
                <th>Reward</th>
                <th>Length</th>
                <th>Success</th>
            </tr>
        </thead>
        <tbody>
            {self._generate_episode_rows(report.episode_results)}
        </tbody>
    </table>
</body>
</html>
"""
        
        with open(output_path, 'w') as f:
            f.write(html_content)
    
    @staticmethod
    def _generate_percentile_bars(percentiles: dict, max_reward: float) -> str:
        """Generate HTML for percentile visualization."""
        bars = []
        for label, value in percentiles.items():
            width_pct = (value / max_reward * 100) if max_reward > 0 else 0
            bars.append(f"""
            <div class="percentile-bar">
                <div class="percentile-label">{label.upper()}</div>
                <div class="percentile-value" style="width: {width_pct}%;">
                    {value:.2f}
                </div>
            </div>
            """)
        return '\n'.join(bars)
    
    @staticmethod
    def _generate_episode_rows(episode_results: list) -> str:
        """Generate HTML table rows for episodes."""
        rows = []
        for ep in episode_results:
            success_icon = "✓" if ep.success else "✗"
            success_color = "#10b981" if ep.success else "#ef4444"
            rows.append(f"""
            <tr>
                <td>{ep.episode_id + 1}</td>
                <td>{ep.total_reward:.2f}</td>
                <td>{ep.episode_length}</td>
                <td style="color: {success_color}; font-weight: bold;">{success_icon}</td>
            </tr>
            """)
        return '\n'.join(rows)
    
    @staticmethod
    def _generate_markdown(report: EvaluationReport, output_path: Path) -> None:
        """Generate Markdown report."""
        md_content = f"""# Evaluation Report

**Agent:** {report.agent_type}  
**Environment:** {report.env_name}  
**Episodes:** {report.num_episodes}  
**Timestamp:** {report.timestamp}

## Summary Metrics

| Metric | Value |
|--------|-------|
| Mean Reward | {report.mean_reward:.2f} ± {report.std_reward:.2f} |
| Median Reward | {report.median_reward:.2f} |
| Min Reward | {report.min_reward:.2f} |
| Max Reward | {report.max_reward:.2f} |
| Mean Episode Length | {report.mean_length:.1f} ± {report.std_length:.1f} |
{f"| Success Rate | {report.success_rate * 100:.1f}% |" if report.success_rate is not None else ""}

## Reward Distribution (Percentiles)

| Percentile | Reward |
|------------|--------|
"""
        
        for label, value in report.percentiles.items():
            md_content += f"| {label.upper()} | {value:.2f} |\n"
        
        md_content += "\n## Episode Results\n\n"
        md_content += "| Episode | Reward | Length | Success |\n"
        md_content += "|---------|--------|--------|----------|\n"
        
        for ep in report.episode_results:
            success_icon = "✓" if ep.success else "✗"
            md_content += f"| {ep.episode_id + 1} | {ep.total_reward:.2f} | {ep.episode_length} | {success_icon} |\n"
        
        with open(output_path, 'w') as f:
            f.write(md_content)
    
    @staticmethod
    def _generate_csv(report: EvaluationReport, output_path: Path) -> None:
        """Generate CSV report."""
        import csv
        
        with open(output_path, 'w', newline='') as f:
            writer = csv.writer(f)
            
            writer.writerow(['Agent', 'Environment', 'Episodes', 'Timestamp'])
            writer.writerow([report.agent_type, report.env_name, report.num_episodes, report.timestamp])
            writer.writerow([])
            
            writer.writerow(['Metric', 'Value'])
            writer.writerow(['Mean Reward', f"{report.mean_reward:.2f}"])
            writer.writerow(['Std Reward', f"{report.std_reward:.2f}"])
            writer.writerow(['Median Reward', f"{report.median_reward:.2f}"])
            writer.writerow(['Min Reward', f"{report.min_reward:.2f}"])
            writer.writerow(['Max Reward', f"{report.max_reward:.2f}"])
            writer.writerow(['Mean Length', f"{report.mean_length:.1f}"])
            writer.writerow(['Std Length', f"{report.std_length:.1f}"])
            
            if report.success_rate is not None:
                writer.writerow(['Success Rate', f"{report.success_rate * 100:.1f}%"])
            
            writer.writerow([])
            writer.writerow(['Episode', 'Reward', 'Length', 'Success'])
            
            for ep in report.episode_results:
                writer.writerow([
                    ep.episode_id + 1,
                    f"{ep.total_reward:.2f}",
                    ep.episode_length,
                    'Yes' if ep.success else 'No',
                ])
