"""
Distributed execution foundation for Hugo.

This module provides the foundation for distributed training and evaluation,
including parallel rollouts and multi-process coordination.
"""

from rl_llm_toolkit.distributed.parallel_rollout import ParallelRolloutManager
from rl_llm_toolkit.distributed.worker_pool import WorkerPool, WorkerConfig

__all__ = [
    "ParallelRolloutManager",
    "WorkerPool",
    "WorkerConfig",
]
