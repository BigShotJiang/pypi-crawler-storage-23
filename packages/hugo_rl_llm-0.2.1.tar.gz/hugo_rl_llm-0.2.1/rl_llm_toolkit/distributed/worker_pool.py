import logging
import multiprocessing as mp
import queue
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class WorkerStatus(Enum):
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class WorkerConfig:
    """Configuration for worker processes."""
    num_workers: int = 4
    max_queue_size: int = 100
    worker_timeout: float = 300.0
    restart_on_error: bool = True
    max_retries: int = 3


@dataclass
class Task:
    """Task to be executed by worker."""
    task_id: str
    func: Callable
    args: tuple
    kwargs: dict
    priority: int = 0


@dataclass
class TaskResult:
    """Result from task execution."""
    task_id: str
    success: bool
    result: Any
    error: Optional[str]
    worker_id: int
    execution_time: float


class WorkerPool:
    """
    Advanced worker pool with task queue and error handling.
    
    Provides better control than standard multiprocessing.Pool
    with features like priority queues, error recovery, and monitoring.
    """
    
    def __init__(self, config: Optional[WorkerConfig] = None):
        self.config = config or WorkerConfig()
        
        self._task_queue: Optional[mp.Queue] = None
        self._result_queue: Optional[mp.Queue] = None
        self._workers: List[mp.Process] = []
        self._worker_status: Dict[int, WorkerStatus] = {}
        
        self._active = False
        self._tasks_submitted = 0
        self._tasks_completed = 0
        self._tasks_failed = 0
    
    def start(self) -> None:
        """Start worker pool."""
        if self._active:
            return
        
        self._task_queue = mp.Queue(maxsize=self.config.max_queue_size)
        self._result_queue = mp.Queue()
        
        for worker_id in range(self.config.num_workers):
            worker = mp.Process(
                target=_worker_process,
                args=(
                    worker_id,
                    self._task_queue,
                    self._result_queue,
                    self.config.worker_timeout,
                ),
                daemon=True,
            )
            worker.start()
            self._workers.append(worker)
            self._worker_status[worker_id] = WorkerStatus.IDLE
        
        self._active = True
        logger.info(f"Started worker pool with {self.config.num_workers} workers")
    
    def stop(self, timeout: float = 10.0) -> None:
        """Stop worker pool gracefully."""
        if not self._active:
            return
        
        for _ in range(self.config.num_workers):
            self._task_queue.put(None)
        
        start_time = time.time()
        for worker in self._workers:
            remaining = timeout - (time.time() - start_time)
            if remaining > 0:
                worker.join(timeout=remaining)
            
            if worker.is_alive():
                worker.terminate()
                worker.join(timeout=1.0)
        
        self._workers.clear()
        self._worker_status.clear()
        self._active = False
        
        logger.info("Worker pool stopped")
    
    def submit(
        self,
        func: Callable,
        *args,
        task_id: Optional[str] = None,
        priority: int = 0,
        **kwargs,
    ) -> str:
        """
        Submit task to worker pool.
        
        Args:
            func: Function to execute
            *args: Positional arguments
            task_id: Optional task identifier
            priority: Task priority (higher = more important)
            **kwargs: Keyword arguments
            
        Returns:
            Task ID
        """
        if not self._active:
            self.start()
        
        if task_id is None:
            task_id = f"task_{self._tasks_submitted}"
        
        task = Task(
            task_id=task_id,
            func=func,
            args=args,
            kwargs=kwargs,
            priority=priority,
        )
        
        self._task_queue.put(task)
        self._tasks_submitted += 1
        
        return task_id
    
    def get_result(self, timeout: Optional[float] = None) -> Optional[TaskResult]:
        """
        Get next available result.
        
        Args:
            timeout: Maximum time to wait for result
            
        Returns:
            TaskResult or None if timeout
        """
        try:
            result = self._result_queue.get(timeout=timeout)
            
            if result.success:
                self._tasks_completed += 1
            else:
                self._tasks_failed += 1
            
            return result
            
        except queue.Empty:
            return None
    
    def get_all_results(self, timeout: float = 60.0) -> List[TaskResult]:
        """
        Get all pending results.
        
        Args:
            timeout: Maximum time to wait
            
        Returns:
            List of task results
        """
        results = []
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            remaining = timeout - (time.time() - start_time)
            result = self.get_result(timeout=min(remaining, 1.0))
            
            if result is None:
                if self._result_queue.empty():
                    break
                continue
            
            results.append(result)
        
        return results
    
    def map(
        self,
        func: Callable,
        items: List[Any],
        timeout: Optional[float] = None,
    ) -> List[Any]:
        """
        Map function over items in parallel.
        
        Args:
            func: Function to apply
            items: Items to process
            timeout: Maximum time to wait
            
        Returns:
            List of results in same order as items
        """
        task_ids = []
        
        for i, item in enumerate(items):
            task_id = self.submit(func, item, task_id=f"map_{i}")
            task_ids.append(task_id)
        
        results_dict = {}
        
        for _ in range(len(items)):
            result = self.get_result(timeout=timeout)
            
            if result is None:
                raise TimeoutError("Worker pool map operation timed out")
            
            results_dict[result.task_id] = result
        
        ordered_results = []
        for task_id in task_ids:
            result = results_dict[task_id]
            if not result.success:
                raise RuntimeError(f"Task {task_id} failed: {result.error}")
            ordered_results.append(result.result)
        
        return ordered_results
    
    def get_stats(self) -> Dict[str, Any]:
        """Get worker pool statistics."""
        return {
            'active': self._active,
            'num_workers': self.config.num_workers,
            'tasks_submitted': self._tasks_submitted,
            'tasks_completed': self._tasks_completed,
            'tasks_failed': self._tasks_failed,
            'tasks_pending': self._tasks_submitted - self._tasks_completed - self._tasks_failed,
            'worker_status': {
                worker_id: status.value
                for worker_id, status in self._worker_status.items()
            },
        }
    
    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()


def _worker_process(
    worker_id: int,
    task_queue: mp.Queue,
    result_queue: mp.Queue,
    timeout: float,
) -> None:
    """
    Worker process that executes tasks.
    
    Runs in separate process.
    """
    logger.info(f"Worker {worker_id} started")
    
    while True:
        try:
            task = task_queue.get(timeout=timeout)
            
            if task is None:
                logger.info(f"Worker {worker_id} received stop signal")
                break
            
            start_time = time.time()
            
            try:
                result = task.func(*task.args, **task.kwargs)
                execution_time = time.time() - start_time
                
                task_result = TaskResult(
                    task_id=task.task_id,
                    success=True,
                    result=result,
                    error=None,
                    worker_id=worker_id,
                    execution_time=execution_time,
                )
                
            except Exception as e:
                execution_time = time.time() - start_time
                
                logger.error(f"Worker {worker_id} task {task.task_id} failed: {e}")
                
                task_result = TaskResult(
                    task_id=task.task_id,
                    success=False,
                    result=None,
                    error=str(e),
                    worker_id=worker_id,
                    execution_time=execution_time,
                )
            
            result_queue.put(task_result)
            
        except queue.Empty:
            continue
        except Exception as e:
            logger.error(f"Worker {worker_id} error: {e}")
            break
    
    logger.info(f"Worker {worker_id} stopped")
