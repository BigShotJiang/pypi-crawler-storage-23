import multiprocessing as mp
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import numpy as np

from rl_llm_toolkit.api.v1 import AgentProtocol, EnvAdapterProtocol


@dataclass
class RolloutResult:
    """Result from a single rollout."""
    worker_id: int
    episode_id: int
    total_reward: float
    episode_length: int
    observations: List[np.ndarray]
    actions: List[np.ndarray]
    rewards: List[float]
    dones: List[bool]
    infos: List[Dict[str, Any]]


class ParallelRolloutManager:
    """
    Manage parallel environment rollouts for faster data collection.
    
    This enables significant speedup for on-policy algorithms like PPO
    by collecting experience from multiple environments simultaneously.
    """
    
    def __init__(
        self,
        num_workers: int = 4,
        worker_timeout: float = 300.0,
    ):
        """
        Initialize parallel rollout manager.
        
        Args:
            num_workers: Number of parallel workers
            worker_timeout: Timeout for worker processes in seconds
        """
        self.num_workers = num_workers
        self.worker_timeout = worker_timeout
        
        self._pool: Optional[mp.Pool] = None
        self._active = False
    
    def start(self) -> None:
        """Start worker pool."""
        if self._active:
            return
        
        self._pool = mp.Pool(processes=self.num_workers)
        self._active = True
    
    def stop(self) -> None:
        """Stop worker pool and cleanup."""
        if not self._active or self._pool is None:
            return
        
        self._pool.close()
        self._pool.join()
        self._active = False
        self._pool = None
    
    def collect_rollouts(
        self,
        env_fn: Callable[[], EnvAdapterProtocol],
        agent_fn: Callable[[], AgentProtocol],
        num_episodes: int,
        max_steps_per_episode: Optional[int] = None,
    ) -> List[RolloutResult]:
        """
        Collect rollouts in parallel.
        
        Args:
            env_fn: Function that creates environment instance
            agent_fn: Function that creates agent instance
            num_episodes: Total number of episodes to collect
            max_steps_per_episode: Maximum steps per episode
            
        Returns:
            List of rollout results
        """
        if not self._active:
            self.start()
        
        episodes_per_worker = num_episodes // self.num_workers
        remainder = num_episodes % self.num_workers
        
        tasks = []
        episode_id = 0
        
        for worker_id in range(self.num_workers):
            worker_episodes = episodes_per_worker + (1 if worker_id < remainder else 0)
            
            if worker_episodes > 0:
                tasks.append((
                    worker_id,
                    env_fn,
                    agent_fn,
                    list(range(episode_id, episode_id + worker_episodes)),
                    max_steps_per_episode,
                ))
                episode_id += worker_episodes
        
        results = self._pool.starmap(
            _worker_rollout,
            tasks,
            chunksize=1,
        )
        
        all_rollouts = []
        for worker_results in results:
            all_rollouts.extend(worker_results)
        
        return all_rollouts
    
    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()


def _worker_rollout(
    worker_id: int,
    env_fn: Callable,
    agent_fn: Callable,
    episode_ids: List[int],
    max_steps: Optional[int],
) -> List[RolloutResult]:
    """
    Worker function to collect rollouts.
    
    This runs in a separate process.
    """
    env = env_fn()
    agent = agent_fn()
    
    results = []
    
    for episode_id in episode_ids:
        obs, info = env.reset()
        done = False
        
        observations = [obs]
        actions = []
        rewards = []
        dones = []
        infos = [info]
        
        total_reward = 0.0
        steps = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=False)
            
            next_obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            
            observations.append(next_obs)
            actions.append(action)
            rewards.append(reward)
            dones.append(done)
            infos.append(info)
            
            total_reward += reward
            steps += 1
            obs = next_obs
            
            if max_steps and steps >= max_steps:
                done = True
        
        result = RolloutResult(
            worker_id=worker_id,
            episode_id=episode_id,
            total_reward=total_reward,
            episode_length=steps,
            observations=observations,
            actions=actions,
            rewards=rewards,
            dones=dones,
            infos=infos,
        )
        
        results.append(result)
    
    env.close()
    
    return results
