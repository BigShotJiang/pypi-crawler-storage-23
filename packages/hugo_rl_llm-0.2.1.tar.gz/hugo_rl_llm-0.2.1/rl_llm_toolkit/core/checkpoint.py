import json
import shutil
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Optional

import torch
import numpy as np

from rl_llm_toolkit.core.exceptions import CheckpointError
from rl_llm_toolkit.core.reproducibility import ReproducibilityMetadata


@dataclass
class CheckpointMetadata:
    version: str
    agent_type: str
    total_timesteps: int
    episode_count: int
    checkpoint_step: int
    timestamp: str
    reproducibility_hash: str
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CheckpointManager:
    CHECKPOINT_VERSION = "1.0.0"
    
    @classmethod
    def save_checkpoint(
        cls,
        path: Path,
        agent_type: str,
        model_state: Dict[str, Any],
        optimizer_state: Optional[Dict[str, Any]] = None,
        scheduler_state: Optional[Dict[str, Any]] = None,
        replay_buffer_state: Optional[Dict[str, Any]] = None,
        normalization_stats: Optional[Dict[str, Any]] = None,
        reward_cache: Optional[Dict[str, Any]] = None,
        training_stats: Optional[Dict[str, Any]] = None,
        reproducibility_metadata: Optional[ReproducibilityMetadata] = None,
        total_timesteps: int = 0,
        episode_count: int = 0,
        checkpoint_step: int = 0,
    ) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        
        checkpoint_dir = path.parent / f"{path.stem}_checkpoint"
        checkpoint_dir.mkdir(exist_ok=True)
        
        try:
            metadata = CheckpointMetadata(
                version=cls.CHECKPOINT_VERSION,
                agent_type=agent_type,
                total_timesteps=total_timesteps,
                episode_count=episode_count,
                checkpoint_step=checkpoint_step,
                timestamp=reproducibility_metadata.timestamp if reproducibility_metadata else "",
                reproducibility_hash=reproducibility_metadata.config_hash if reproducibility_metadata else "",
            )
            
            with open(checkpoint_dir / "metadata.json", 'w') as f:
                json.dump(metadata.to_dict(), f, indent=2)
            
            torch.save(model_state, checkpoint_dir / "model_state.pt")
            
            if optimizer_state is not None:
                torch.save(optimizer_state, checkpoint_dir / "optimizer_state.pt")
            
            if scheduler_state is not None:
                torch.save(scheduler_state, checkpoint_dir / "scheduler_state.pt")
            
            if replay_buffer_state is not None:
                with open(checkpoint_dir / "replay_buffer.pkl", 'wb') as f:
                    import pickle
                    pickle.dump(replay_buffer_state, f)
            
            if normalization_stats is not None:
                np.savez(checkpoint_dir / "normalization_stats.npz", **normalization_stats)
            
            if reward_cache is not None:
                with open(checkpoint_dir / "reward_cache.json", 'w') as f:
                    json.dump(reward_cache, f, indent=2)
            
            if training_stats is not None:
                with open(checkpoint_dir / "training_stats.json", 'w') as f:
                    json.dump(training_stats, f, indent=2)
            
            if reproducibility_metadata is not None:
                reproducibility_metadata.save(checkpoint_dir / "reproducibility.yaml")
            
            archive_path = path.with_suffix('.checkpoint.tar')
            shutil.make_archive(
                str(archive_path.with_suffix('')),
                'tar',
                checkpoint_dir
            )
            
            shutil.rmtree(checkpoint_dir)
            
        except Exception as e:
            if checkpoint_dir.exists():
                shutil.rmtree(checkpoint_dir)
            raise CheckpointError(f"Failed to save checkpoint: {e}") from e
    
    @classmethod
    def load_checkpoint(
        cls,
        path: Path,
        device: str = "cpu",
    ) -> Dict[str, Any]:
        if not path.exists():
            raise CheckpointError(f"Checkpoint not found: {path}")
        
        checkpoint_dir = path.parent / f"{path.stem}_checkpoint_load"
        checkpoint_dir.mkdir(exist_ok=True)
        
        try:
            shutil.unpack_archive(str(path), checkpoint_dir, 'tar')
            
            with open(checkpoint_dir / "metadata.json", 'r') as f:
                metadata = json.load(f)
            
            if metadata['version'] != cls.CHECKPOINT_VERSION:
                print(f"Warning: Checkpoint version mismatch. Expected {cls.CHECKPOINT_VERSION}, got {metadata['version']}")
            
            checkpoint_data = {
                'metadata': metadata,
                'model_state': torch.load(checkpoint_dir / "model_state.pt", map_location=device),
            }
            
            optimizer_path = checkpoint_dir / "optimizer_state.pt"
            if optimizer_path.exists():
                checkpoint_data['optimizer_state'] = torch.load(optimizer_path, map_location=device)
            
            scheduler_path = checkpoint_dir / "scheduler_state.pt"
            if scheduler_path.exists():
                checkpoint_data['scheduler_state'] = torch.load(scheduler_path, map_location=device)
            
            replay_buffer_path = checkpoint_dir / "replay_buffer.pkl"
            if replay_buffer_path.exists():
                import pickle
                with open(replay_buffer_path, 'rb') as f:
                    checkpoint_data['replay_buffer_state'] = pickle.load(f)
            
            normalization_path = checkpoint_dir / "normalization_stats.npz"
            if normalization_path.exists():
                checkpoint_data['normalization_stats'] = dict(np.load(normalization_path))
            
            reward_cache_path = checkpoint_dir / "reward_cache.json"
            if reward_cache_path.exists():
                with open(reward_cache_path, 'r') as f:
                    checkpoint_data['reward_cache'] = json.load(f)
            
            training_stats_path = checkpoint_dir / "training_stats.json"
            if training_stats_path.exists():
                with open(training_stats_path, 'r') as f:
                    checkpoint_data['training_stats'] = json.load(f)
            
            reproducibility_path = checkpoint_dir / "reproducibility.yaml"
            if reproducibility_path.exists():
                checkpoint_data['reproducibility_metadata'] = ReproducibilityMetadata.load(reproducibility_path)
            
            shutil.rmtree(checkpoint_dir)
            
            return checkpoint_data
            
        except Exception as e:
            if checkpoint_dir.exists():
                shutil.rmtree(checkpoint_dir)
            raise CheckpointError(f"Failed to load checkpoint: {e}") from e
    
    @classmethod
    def verify_checkpoint(cls, path: Path) -> bool:
        try:
            checkpoint_data = cls.load_checkpoint(path)
            return 'model_state' in checkpoint_data and 'metadata' in checkpoint_data
        except CheckpointError:
            return False
