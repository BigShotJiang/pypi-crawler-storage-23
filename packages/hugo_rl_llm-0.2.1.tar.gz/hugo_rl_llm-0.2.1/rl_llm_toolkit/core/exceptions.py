class HugoException(Exception):
    """Base exception for Hugo toolkit."""
    pass


class ConfigError(HugoException):
    """Configuration validation or parsing error."""
    pass


class BackendAuthError(HugoException):
    """LLM backend authentication error."""
    pass


class RewardTemplateError(HugoException):
    """Reward template validation or execution error."""
    pass


class EnvCompatibilityError(HugoException):
    """Environment compatibility error."""
    pass


class CheckpointError(HugoException):
    """Checkpoint save/load error."""
    pass


class ReproducibilityError(HugoException):
    """Reproducibility metadata error."""
    pass


class PluginError(HugoException):
    """Plugin discovery or loading error."""
    pass


class BenchmarkError(HugoException):
    """Benchmark execution or validation error."""
    pass
