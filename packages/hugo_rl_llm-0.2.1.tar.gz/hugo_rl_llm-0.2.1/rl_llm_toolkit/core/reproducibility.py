import hashlib
import json
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch
import yaml


@dataclass
class ReproducibilityMetadata:
    seed: int
    commit_hash: str
    package_version: str
    python_version: str
    platform_info: str
    torch_version: str
    numpy_version: str
    gymnasium_version: str
    llm_backend: Optional[str]
    llm_model: Optional[str]
    reward_template_hash: Optional[str]
    config_hash: str
    resolved_config: Dict[str, Any]
    timestamp: str
    hostname: str
    cuda_available: bool
    cuda_version: Optional[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, sort_keys=False)
    
    @classmethod
    def load(cls, path: Path) -> 'ReproducibilityMetadata':
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
        return cls(**data)


class ReproducibilityManager:
    @staticmethod
    def get_git_commit_hash() -> str:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', 'HEAD'],
                capture_output=True,
                text=True,
                timeout=5,
                check=False
            )
            if result.returncode == 0:
                return result.stdout.strip()
            return "unknown (not a git repo)"
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return "unknown (git not available)"
    
    @staticmethod
    def get_package_version() -> str:
        try:
            from rl_llm_toolkit import __version__
            return __version__
        except ImportError:
            return "unknown"
    
    @staticmethod
    def get_python_version() -> str:
        return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    
    @staticmethod
    def get_platform_info() -> str:
        return f"{platform.system()} {platform.release()} ({platform.machine()})"
    
    @staticmethod
    def get_cuda_info() -> tuple[bool, Optional[str]]:
        cuda_available = torch.cuda.is_available()
        cuda_version = torch.version.cuda if cuda_available else None
        return cuda_available, cuda_version
    
    @staticmethod
    def compute_config_hash(config: Dict[str, Any]) -> str:
        config_str = json.dumps(config, sort_keys=True)
        return hashlib.sha256(config_str.encode()).hexdigest()[:16]
    
    @staticmethod
    def compute_template_hash(template: Optional[str]) -> Optional[str]:
        if template is None:
            return None
        return hashlib.sha256(template.encode()).hexdigest()[:16]
    
    @staticmethod
    def set_global_seed(seed: int) -> None:
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
        os.environ['PYTHONHASHSEED'] = str(seed)
    
    @classmethod
    def create_metadata(
        cls,
        seed: int,
        config: Dict[str, Any],
        llm_backend: Optional[str] = None,
        llm_model: Optional[str] = None,
        reward_template: Optional[str] = None,
    ) -> ReproducibilityMetadata:
        cuda_available, cuda_version = cls.get_cuda_info()
        
        return ReproducibilityMetadata(
            seed=seed,
            commit_hash=cls.get_git_commit_hash(),
            package_version=cls.get_package_version(),
            python_version=cls.get_python_version(),
            platform_info=cls.get_platform_info(),
            torch_version=torch.__version__,
            numpy_version=np.__version__,
            gymnasium_version=cls._get_gymnasium_version(),
            llm_backend=llm_backend,
            llm_model=llm_model,
            reward_template_hash=cls.compute_template_hash(reward_template),
            config_hash=cls.compute_config_hash(config),
            resolved_config=config,
            timestamp=datetime.utcnow().isoformat(),
            hostname=platform.node(),
            cuda_available=cuda_available,
            cuda_version=cuda_version,
        )
    
    @staticmethod
    def _get_gymnasium_version() -> str:
        try:
            import gymnasium
            return gymnasium.__version__
        except (ImportError, AttributeError):
            return "unknown"
    
    @staticmethod
    def save_resolved_config(config: Dict[str, Any], output_dir: Path) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        
        yaml_path = output_dir / "resolved_config.yaml"
        with open(yaml_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
        
        json_path = output_dir / "resolved_config.json"
        with open(json_path, 'w') as f:
            json.dump(config, f, indent=2, sort_keys=False)
