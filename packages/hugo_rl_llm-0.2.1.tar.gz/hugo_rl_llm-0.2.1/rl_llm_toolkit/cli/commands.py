import json
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown

from rl_llm_toolkit.core.reproducibility import ReproducibilityManager, ReproducibilityMetadata
from rl_llm_toolkit.core.checkpoint import CheckpointManager
from rl_llm_toolkit.core.exceptions import CheckpointError, ReproducibilityError
from rl_llm_toolkit.plugins.discovery import PluginManager
from benchmarks.registry import BenchmarkRegistry
from benchmarks.runner import BenchmarkRunner


console = Console()
ROOT_DIR = Path(__file__).resolve().parents[2]


@click.command()
@click.argument("run_dir", type=click.Path(exists=True))
@click.option("--device", "-d", default="cpu", help="Device to use")
def reproduce(run_dir: str, device: str) -> None:
    """Reproduce a previous training run exactly."""
    run_path = Path(run_dir)
    
    console.print(f"[bold cyan]Reproducing run from: {run_path}[/bold cyan]")
    
    metadata_file = run_path / "reproducibility.yaml"
    if not metadata_file.exists():
        raise click.ClickException(f"Reproducibility metadata not found: {metadata_file}")
    
    try:
        metadata = ReproducibilityMetadata.load(metadata_file)
        
        table = Table(title="Reproducibility Information")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="magenta")
        
        table.add_row("Seed", str(metadata.seed))
        table.add_row("Commit Hash", metadata.commit_hash)
        table.add_row("Package Version", metadata.package_version)
        table.add_row("Python Version", metadata.python_version)
        table.add_row("Platform", metadata.platform_info)
        table.add_row("Timestamp", metadata.timestamp)
        
        if metadata.llm_backend:
            table.add_row("LLM Backend", metadata.llm_backend)
            table.add_row("LLM Model", metadata.llm_model or "N/A")
        
        console.print(table)
        
        current_commit = ReproducibilityManager.get_git_commit_hash()
        if current_commit != metadata.commit_hash:
            console.print(f"\n[yellow]Warning: Current commit ({current_commit[:8]}) differs from original ({metadata.commit_hash[:8]})[/yellow]")
        
        current_version = ReproducibilityManager.get_package_version()
        if current_version != metadata.package_version:
            console.print(f"\n[yellow]Warning: Current version ({current_version}) differs from original ({metadata.package_version})[/yellow]")
        
        ReproducibilityManager.set_global_seed(metadata.seed)
        
        resolved_config_file = run_path / "resolved_config.yaml"
        if resolved_config_file.exists():
            console.print(f"\n[green]Resolved config available at: {resolved_config_file}[/green]")
            console.print("\nTo reproduce, run:")
            console.print(f"[bold cyan]hugo train {resolved_config_file} --device {device}[/bold cyan]")
        else:
            console.print("\n[yellow]Warning: Resolved config not found[/yellow]")
        
    except Exception as e:
        raise click.ClickException(f"Failed to load reproducibility metadata: {e}") from e


@click.command(name="benchmark")
@click.option("--suite", "-s", multiple=True, help="Specific benchmark IDs to run")
@click.option("--algorithm", "-a", help="Run all benchmarks for specific algorithm")
@click.option("--output-dir", "-o", default="./benchmark_results", help="Output directory")
@click.option("--seed", type=int, default=42, help="Random seed")
@click.option("--device", "-d", default="cpu", help="Device to use")
def benchmark(suite: tuple, algorithm: Optional[str], output_dir: str, seed: int, device: str) -> None:
    """Run official benchmarks with regression checks."""
    console.print("[bold green]Running Hugo Benchmarks[/bold green]\n")
    
    runner = BenchmarkRunner(output_dir=Path(output_dir))
    
    benchmark_ids = list(suite) if suite else None
    
    results = runner.run_suite(
        benchmark_ids=benchmark_ids,
        algorithm=algorithm,
        seed=seed,
        device=device,
    )
    
    failed = sum(1 for status, _, _ in results.values() if status.value == "failed")
    
    if failed > 0:
        raise click.ClickException(f"{failed} benchmark(s) failed")
    
    console.print("[bold green]All benchmarks passed![/bold green]")


@click.command(name="list-benchmarks")
def list_benchmarks() -> None:
    """List all available benchmarks."""
    specs = BenchmarkRegistry.list_all()
    
    table = Table(title="Available Benchmarks")
    table.add_column("ID", style="cyan")
    table.add_column("Algorithm", style="magenta")
    table.add_column("Environment", style="green")
    table.add_column("Steps", style="yellow")
    table.add_column("Min Reward", style="blue")
    
    for spec in specs:
        table.add_row(
            spec.benchmark_id,
            spec.algorithm.value.upper(),
            spec.env_name,
            f"{spec.total_timesteps:,}",
            f"{spec.threshold.min_mean_reward:.1f}",
        )
    
    console.print(table)


@click.command()
def plugins() -> None:
    """List and validate discovered plugins."""
    console.print("[bold cyan]Discovering plugins...[/bold cyan]\n")
    
    PluginManager.discover_plugins()
    PluginManager.print_plugin_info()
    
    plugin_list = PluginManager.list_plugins()
    total = sum(len(plugins) for plugins in plugin_list.values())
    
    console.print(f"\n[bold]Total plugins discovered: {total}[/bold]")


@click.command()
def doctor() -> None:
    """Run system diagnostics and check Hugo installation."""
    console.print("[bold cyan]Running Hugo Doctor...[/bold cyan]\n")
    
    checks = []
    
    try:
        from rl_llm_toolkit import __version__
        checks.append(("Package Version", __version__, True))
    except Exception as e:
        checks.append(("Package Version", str(e), False))
    
    try:
        import torch
        cuda_available = torch.cuda.is_available()
        checks.append(("PyTorch", torch.__version__, True))
        checks.append(("CUDA Available", str(cuda_available), cuda_available))
    except Exception as e:
        checks.append(("PyTorch", str(e), False))
    
    try:
        import gymnasium
        checks.append(("Gymnasium", gymnasium.__version__, True))
    except Exception as e:
        checks.append(("Gymnasium", str(e), False))
    
    try:
        import numpy as np
        checks.append(("NumPy", np.__version__, True))
    except Exception as e:
        checks.append(("NumPy", str(e), False))
    
    try:
        git_hash = ReproducibilityManager.get_git_commit_hash()
        checks.append(("Git Commit", git_hash[:8], "unknown" not in git_hash))
    except Exception as e:
        checks.append(("Git Commit", str(e), False))
    
    try:
        PluginManager.discover_plugins()
        plugin_list = PluginManager.list_plugins()
        total_plugins = sum(len(p) for p in plugin_list.values())
        checks.append(("Plugins", str(total_plugins), True))
    except Exception as e:
        checks.append(("Plugins", str(e), False))
    
    table = Table(title="System Diagnostics")
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="magenta")
    table.add_column("Check", style="green")
    
    for name, value, passed in checks:
        status_icon = "✓" if passed else "✗"
        status_color = "green" if passed else "red"
        table.add_row(name, value, f"[{status_color}]{status_icon}[/{status_color}]")
    
    console.print(table)
    
    all_passed = all(passed for _, _, passed in checks)
    if all_passed:
        console.print("\n[bold green]All checks passed! Hugo is ready to use.[/bold green]")
    else:
        console.print("\n[bold yellow]Some checks failed. Please review the diagnostics above.[/bold yellow]")


@click.command(name="verify-checkpoint")
@click.argument("checkpoint_path", type=click.Path(exists=True))
def verify_checkpoint(checkpoint_path: str) -> None:
    """Verify checkpoint integrity."""
    path = Path(checkpoint_path)
    
    console.print(f"[bold cyan]Verifying checkpoint: {path}[/bold cyan]\n")
    
    try:
        is_valid = CheckpointManager.verify_checkpoint(path)
        
        if is_valid:
            checkpoint_data = CheckpointManager.load_checkpoint(path)
            metadata = checkpoint_data.get('metadata', {})
            
            table = Table(title="Checkpoint Information")
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="magenta")
            
            table.add_row("Version", metadata.get('version', 'unknown'))
            table.add_row("Agent Type", metadata.get('agent_type', 'unknown'))
            table.add_row("Total Timesteps", str(metadata.get('total_timesteps', 0)))
            table.add_row("Episode Count", str(metadata.get('episode_count', 0)))
            table.add_row("Checkpoint Step", str(metadata.get('checkpoint_step', 0)))
            
            console.print(table)
            
            components = []
            if 'model_state' in checkpoint_data:
                components.append("Model State")
            if 'optimizer_state' in checkpoint_data:
                components.append("Optimizer State")
            if 'scheduler_state' in checkpoint_data:
                components.append("Scheduler State")
            if 'replay_buffer_state' in checkpoint_data:
                components.append("Replay Buffer")
            if 'normalization_stats' in checkpoint_data:
                components.append("Normalization Stats")
            if 'reward_cache' in checkpoint_data:
                components.append("Reward Cache")
            if 'reproducibility_metadata' in checkpoint_data:
                components.append("Reproducibility Metadata")
            
            console.print(f"\n[green]✓ Checkpoint is valid[/green]")
            console.print(f"[cyan]Components: {', '.join(components)}[/cyan]")
        else:
            console.print("[red]✗ Checkpoint is invalid or corrupted[/red]")
            raise click.ClickException("Checkpoint verification failed")
            
    except CheckpointError as e:
        console.print(f"[red]✗ Checkpoint error: {e}[/red]")
        raise click.ClickException(str(e)) from e


@click.command(name="compare-runs")
@click.argument("run_dir_1", type=click.Path(exists=True))
@click.argument("run_dir_2", type=click.Path(exists=True))
def compare_runs(run_dir_1: str, run_dir_2: str) -> None:
    """Compare two training runs."""
    path1 = Path(run_dir_1)
    path2 = Path(run_dir_2)
    
    console.print("[bold cyan]Comparing Training Runs[/bold cyan]\n")
    
    try:
        meta1 = ReproducibilityMetadata.load(path1 / "reproducibility.yaml")
        meta2 = ReproducibilityMetadata.load(path2 / "reproducibility.yaml")
        
        table = Table(title="Run Comparison")
        table.add_column("Property", style="cyan")
        table.add_column("Run 1", style="magenta")
        table.add_column("Run 2", style="yellow")
        table.add_column("Match", style="green")
        
        comparisons = [
            ("Seed", meta1.seed, meta2.seed),
            ("Commit Hash", meta1.commit_hash[:8], meta2.commit_hash[:8]),
            ("Package Version", meta1.package_version, meta2.package_version),
            ("Python Version", meta1.python_version, meta2.python_version),
            ("LLM Backend", meta1.llm_backend or "None", meta2.llm_backend or "None"),
            ("LLM Model", meta1.llm_model or "None", meta2.llm_model or "None"),
            ("Config Hash", meta1.config_hash, meta2.config_hash),
        ]
        
        for prop, val1, val2 in comparisons:
            match = "✓" if val1 == val2 else "✗"
            match_color = "green" if val1 == val2 else "red"
            table.add_row(prop, str(val1), str(val2), f"[{match_color}]{match}[/{match_color}]")
        
        console.print(table)
        
    except Exception as e:
        raise click.ClickException(f"Failed to compare runs: {e}") from e


@click.command(name="export-metrics")
@click.argument("run_dir", type=click.Path(exists=True))
@click.option("--format", "-f", type=click.Choice(["json", "csv", "html"]), default="json")
@click.option("--output", "-o", help="Output file path")
def export_metrics(run_dir: str, format: str, output: Optional[str]) -> None:
    """Export training metrics from a run."""
    run_path = Path(run_dir)
    
    summary_file = None
    for pattern in ["*_summary.json", "summary.json", "training_stats.json"]:
        matches = list(run_path.glob(pattern))
        if matches:
            summary_file = matches[0]
            break
    
    if not summary_file:
        raise click.ClickException(f"No metrics found in {run_dir}")
    
    with open(summary_file, 'r') as f:
        data = json.load(f)
    
    if output is None:
        output = str(run_path / f"metrics.{format}")
    
    output_path = Path(output)
    
    if format == "json":
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
    elif format == "csv":
        import csv
        with open(output_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Metric", "Mean", "Std", "Min", "Max", "Count"])
            
            for category in ['step_metrics', 'episode_metrics']:
                if category in data:
                    for metric, stats in data[category].items():
                        writer.writerow([
                            f"{category}/{metric}",
                            stats.get('mean', ''),
                            stats.get('std', ''),
                            stats.get('min', ''),
                            stats.get('max', ''),
                            stats.get('count', ''),
                        ])
    elif format == "html":
        html_content = f"""
        <html>
        <head><title>Training Metrics - {data.get('experiment_name', 'Unknown')}</title></head>
        <body>
        <h1>Training Metrics</h1>
        <p>Experiment: {data.get('experiment_name', 'Unknown')}</p>
        <p>Start Time: {data.get('start_time', 'Unknown')}</p>
        <pre>{json.dumps(data, indent=2)}</pre>
        </body>
        </html>
        """
        with open(output_path, 'w') as f:
            f.write(html_content)
    
    console.print(f"[green]Metrics exported to: {output_path}[/green]")


@click.command(name="foundation-status")
@click.option(
    "--summary-file",
    "summary_file",
    default=str(ROOT_DIR / "FINAL_SUMMARY_FOUNDATION_LEVEL.md"),
    show_default=True,
    help="Path to the foundation readiness summary markdown file.",
)
def foundation_status(summary_file: str) -> None:
    """Display the foundation readiness summary inside the CLI."""
    summary_path = Path(summary_file)

    if not summary_path.exists():
        raise click.ClickException(
            f"Foundation summary file not found: {summary_path}. Generate FINAL_SUMMARY_FOUNDATION_LEVEL.md first."
        )

    console.print(Panel.fit(
        "Hugo Foundation Readiness — Production Publication",
        style="bold green"
    ))

    try:
        content = summary_path.read_text(encoding="utf-8")
        console.print(Markdown(content))
    except Exception as exc:
        raise click.ClickException(f"Failed to read foundation summary: {exc}") from exc
