from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple, Protocol, runtime_checkable
from pathlib import Path

import numpy as np
from gymnasium import spaces


@runtime_checkable
class AgentProtocol(Protocol):
    """Protocol defining the contract for RL agents."""
    
    def train(self, total_timesteps: int, **kwargs: Any) -> Dict[str, Any]:
        """Train the agent for a specified number of timesteps."""
        ...
    
    def predict(
        self, 
        observation: np.ndarray, 
        deterministic: bool = True
    ) -> Tuple[np.ndarray, Optional[Dict[str, Any]]]:
        """Predict action given observation."""
        ...
    
    def save(self, path: Path) -> None:
        """Save agent to disk."""
        ...
    
    def load(self, path: Path) -> None:
        """Load agent from disk."""
        ...
    
    def evaluate(
        self, 
        episodes: int = 10, 
        render: bool = False, 
        deterministic: bool = True
    ) -> Dict[str, float]:
        """Evaluate agent performance."""
        ...


@runtime_checkable
class EnvAdapterProtocol(Protocol):
    """Protocol for environment adapters."""
    
    observation_space: spaces.Space
    action_space: spaces.Space
    
    def reset(
        self, 
        seed: Optional[int] = None, 
        options: Optional[Dict[str, Any]] = None
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment to initial state."""
        ...
    
    def step(
        self, 
        action: np.ndarray
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Execute one step in the environment."""
        ...
    
    def close(self) -> None:
        """Clean up environment resources."""
        ...
    
    def render(self) -> Optional[np.ndarray]:
        """Render the environment."""
        ...


@runtime_checkable
class RewardBackendProtocol(Protocol):
    """Protocol for reward computation backends (including LLM backends)."""
    
    def compute_reward(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        context: Optional[Dict[str, Any]] = None,
    ) -> float:
        """Compute shaped reward."""
        ...
    
    def reset(self) -> None:
        """Reset backend state."""
        ...


@runtime_checkable
class RewardTemplateProtocol(Protocol):
    """Protocol for reward prompt templates."""
    
    def format(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        **kwargs: Any,
    ) -> str:
        """Format template with current transition data."""
        ...
    
    def validate(self) -> bool:
        """Validate template structure."""
        ...


@runtime_checkable
class ReplayBufferProtocol(Protocol):
    """Protocol for experience replay buffers."""
    
    def add(
        self,
        obs: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_obs: np.ndarray,
        done: bool,
    ) -> None:
        """Add transition to buffer."""
        ...
    
    def sample(self, batch_size: int) -> Dict[str, np.ndarray]:
        """Sample batch of transitions."""
        ...
    
    def __len__(self) -> int:
        """Return current buffer size."""
        ...
    
    def save(self, path: Path) -> None:
        """Save buffer to disk."""
        ...
    
    def load(self, path: Path) -> None:
        """Load buffer from disk."""
        ...


@runtime_checkable
class EvaluatorProtocol(Protocol):
    """Protocol for agent evaluators."""
    
    def evaluate(
        self,
        agent: AgentProtocol,
        env: EnvAdapterProtocol,
        num_episodes: int,
        deterministic: bool = True,
    ) -> Dict[str, float]:
        """Evaluate agent on environment."""
        ...
    
    def generate_report(
        self,
        results: Dict[str, float],
        output_path: Optional[Path] = None,
    ) -> str:
        """Generate evaluation report."""
        ...


class BaseAgent(ABC):
    """Base class implementing AgentProtocol with common functionality."""
    
    @abstractmethod
    def train(self, total_timesteps: int, **kwargs: Any) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    def predict(
        self, 
        observation: np.ndarray, 
        deterministic: bool = True
    ) -> Tuple[np.ndarray, Optional[Dict[str, Any]]]:
        pass
    
    @abstractmethod
    def save(self, path: Path) -> None:
        pass
    
    @abstractmethod
    def load(self, path: Path) -> None:
        pass
    
    def evaluate(
        self, 
        episodes: int = 10, 
        render: bool = False, 
        deterministic: bool = True
    ) -> Dict[str, float]:
        """Default evaluation implementation."""
        from rl_llm_toolkit.core.environment import RLEnvironment
        
        if not hasattr(self, 'env') or not isinstance(self.env, RLEnvironment):
            raise NotImplementedError("Agent must have an 'env' attribute")
        
        episode_rewards = []
        episode_lengths = []
        
        for _ in range(episodes):
            obs, _ = self.env.reset()
            done = False
            episode_reward = 0.0
            episode_length = 0
            
            while not done:
                action, _ = self.predict(obs, deterministic=deterministic)
                obs, reward, terminated, truncated, _ = self.env.step(action)
                done = terminated or truncated
                
                episode_reward += reward
                episode_length += 1
                
                if render:
                    self.env.render()
            
            episode_rewards.append(episode_reward)
            episode_lengths.append(episode_length)
        
        return {
            "mean_reward": float(np.mean(episode_rewards)),
            "std_reward": float(np.std(episode_rewards)),
            "min_reward": float(np.min(episode_rewards)),
            "max_reward": float(np.max(episode_rewards)),
            "mean_length": float(np.mean(episode_lengths)),
        }


class BaseRewardBackend(ABC):
    """Base class for reward backends."""
    
    @abstractmethod
    def compute_reward(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
        base_reward: float,
        context: Optional[Dict[str, Any]] = None,
    ) -> float:
        pass
    
    def reset(self) -> None:
        """Default reset implementation."""
        pass
