import csv
import json
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

from rl_llm_toolkit.tracking.tracker import TrackingBackend


class TensorBoardBackend(TrackingBackend):
    """TensorBoard tracking backend."""
    
    def __init__(self, log_dir: Path):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            from torch.utils.tensorboard import SummaryWriter
            self.writer = SummaryWriter(log_dir=str(self.log_dir))
        except ImportError:
            raise ImportError("TensorBoard backend requires tensorboard package")
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.writer.add_scalar(name, value, step)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        for name, value in metrics.items():
            self.writer.add_scalar(name, value, step)
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.writer.add_histogram(name, values, step)
    
    def log_text(self, name: str, text: str, step: int) -> None:
        self.writer.add_text(name, text, step)
    
    def log_config(self, config: Dict[str, Any]) -> None:
        config_str = json.dumps(config, indent=2)
        self.writer.add_text('config', config_str, 0)
    
    def close(self) -> None:
        self.writer.flush()
        self.writer.close()


class WandBBackend(TrackingBackend):
    """Weights & Biases tracking backend."""
    
    def __init__(
        self,
        project: str,
        entity: Optional[str] = None,
        name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        try:
            import wandb
            self.wandb = wandb
            
            self.run = wandb.init(
                project=project,
                entity=entity,
                name=name,
                config=config or {},
            )
        except ImportError:
            raise ImportError("WandB backend requires wandb package")
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.wandb.log({name: value}, step=step)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        self.wandb.log(metrics, step=step)
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.wandb.log({name: self.wandb.Histogram(values)}, step=step)
    
    def log_text(self, name: str, text: str, step: int) -> None:
        self.wandb.log({name: text}, step=step)
    
    def log_config(self, config: Dict[str, Any]) -> None:
        self.wandb.config.update(config)
    
    def close(self) -> None:
        self.wandb.finish()


class MLflowBackend(TrackingBackend):
    """MLflow tracking backend."""
    
    def __init__(
        self,
        experiment_name: str,
        tracking_uri: Optional[str] = None,
    ):
        try:
            import mlflow
            self.mlflow = mlflow
            
            if tracking_uri:
                mlflow.set_tracking_uri(tracking_uri)
            
            mlflow.set_experiment(experiment_name)
            self.run = mlflow.start_run()
        except ImportError:
            raise ImportError("MLflow backend requires mlflow package")
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.mlflow.log_metric(name, value, step=step)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        self.mlflow.log_metrics(metrics, step=step)
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.mlflow.log_metric(f"{name}_mean", float(np.mean(values)), step=step)
        self.mlflow.log_metric(f"{name}_std", float(np.std(values)), step=step)
        self.mlflow.log_metric(f"{name}_min", float(np.min(values)), step=step)
        self.mlflow.log_metric(f"{name}_max", float(np.max(values)), step=step)
    
    def log_text(self, name: str, text: str, step: int) -> None:
        self.mlflow.log_text(text, f"{name}_{step}.txt")
    
    def log_config(self, config: Dict[str, Any]) -> None:
        self.mlflow.log_params(self._flatten_dict(config))
    
    def _flatten_dict(self, d: Dict[str, Any], parent_key: str = '') -> Dict[str, Any]:
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}.{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key).items())
            else:
                items.append((new_key, v))
        return dict(items)
    
    def close(self) -> None:
        self.mlflow.end_run()


class CSVBackend(TrackingBackend):
    """CSV file tracking backend."""
    
    def __init__(self, output_path: Path):
        self.output_path = Path(output_path)
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.records = []
        self.fieldnames = set(['step'])
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.log_scalars({name: value}, step)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        record = {'step': step, **metrics}
        self.records.append(record)
        self.fieldnames.update(metrics.keys())
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.log_scalars({
            f"{name}_mean": float(np.mean(values)),
            f"{name}_std": float(np.std(values)),
        }, step)
    
    def log_text(self, name: str, text: str, step: int) -> None:
        pass
    
    def log_config(self, config: Dict[str, Any]) -> None:
        config_path = self.output_path.parent / f"{self.output_path.stem}_config.json"
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    def close(self) -> None:
        if not self.records:
            return
        
        with open(self.output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=sorted(self.fieldnames))
            writer.writeheader()
            writer.writerows(self.records)


class JSONBackend(TrackingBackend):
    """JSON file tracking backend."""
    
    def __init__(self, output_path: Path):
        self.output_path = Path(output_path)
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.records = []
        self.config = {}
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        self.log_scalars({name: value}, step)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        self.records.append({
            'step': step,
            'metrics': metrics,
        })
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        self.log_scalars({
            f"{name}_mean": float(np.mean(values)),
            f"{name}_std": float(np.std(values)),
            f"{name}_min": float(np.min(values)),
            f"{name}_max": float(np.max(values)),
        }, step)
    
    def log_text(self, name: str, text: str, step: int) -> None:
        self.records.append({
            'step': step,
            'text': {name: text},
        })
    
    def log_config(self, config: Dict[str, Any]) -> None:
        self.config = config
    
    def close(self) -> None:
        data = {
            'config': self.config,
            'records': self.records,
        }
        
        with open(self.output_path, 'w') as f:
            json.dump(data, f, indent=2)
