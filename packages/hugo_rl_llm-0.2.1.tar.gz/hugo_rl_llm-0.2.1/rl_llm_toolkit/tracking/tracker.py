import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np


@dataclass
class MetricRecord:
    step: int
    timestamp: str
    metrics: Dict[str, Union[float, int, str]]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'step': self.step,
            'timestamp': self.timestamp,
            'metrics': self.metrics,
        }


class TrackingBackend(ABC):
    """Abstract base class for metric tracking backends."""
    
    @abstractmethod
    def log_scalar(self, name: str, value: float, step: int) -> None:
        """Log a scalar metric."""
        pass
    
    @abstractmethod
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        """Log multiple scalar metrics."""
        pass
    
    @abstractmethod
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        """Log a histogram."""
        pass
    
    @abstractmethod
    def log_text(self, name: str, text: str, step: int) -> None:
        """Log text data."""
        pass
    
    @abstractmethod
    def log_config(self, config: Dict[str, Any]) -> None:
        """Log configuration."""
        pass
    
    @abstractmethod
    def close(self) -> None:
        """Close backend and flush data."""
        pass


class MetricsTracker:
    """Central metrics tracking system with multiple backend support."""
    
    def __init__(
        self,
        experiment_name: str,
        output_dir: Path,
        backends: Optional[List[TrackingBackend]] = None,
    ):
        self.experiment_name = experiment_name
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.backends = backends or []
        self.records: List[MetricRecord] = []
        
        self._step_metrics: Dict[str, List[float]] = {}
        self._episode_metrics: Dict[str, List[float]] = {}
        
        self.start_time = datetime.utcnow()
    
    def add_backend(self, backend: TrackingBackend) -> None:
        """Add a tracking backend."""
        self.backends.append(backend)
    
    def log_scalar(self, name: str, value: float, step: int) -> None:
        """Log a scalar metric to all backends."""
        for backend in self.backends:
            try:
                backend.log_scalar(name, value, step)
            except Exception as e:
                print(f"Warning: Backend failed to log scalar {name}: {e}")
        
        if name not in self._step_metrics:
            self._step_metrics[name] = []
        self._step_metrics[name].append(value)
    
    def log_scalars(self, metrics: Dict[str, float], step: int) -> None:
        """Log multiple scalar metrics."""
        for backend in self.backends:
            try:
                backend.log_scalars(metrics, step)
            except Exception as e:
                print(f"Warning: Backend failed to log scalars: {e}")
        
        record = MetricRecord(
            step=step,
            timestamp=datetime.utcnow().isoformat(),
            metrics=metrics,
        )
        self.records.append(record)
        
        for name, value in metrics.items():
            if name not in self._step_metrics:
                self._step_metrics[name] = []
            self._step_metrics[name].append(value)
    
    def log_episode(self, episode: int, metrics: Dict[str, float]) -> None:
        """Log episode-level metrics."""
        prefixed_metrics = {f"episode/{k}": v for k, v in metrics.items()}
        self.log_scalars(prefixed_metrics, episode)
        
        for name, value in metrics.items():
            if name not in self._episode_metrics:
                self._episode_metrics[name] = []
            self._episode_metrics[name].append(value)
    
    def log_histogram(self, name: str, values: np.ndarray, step: int) -> None:
        """Log histogram data."""
        for backend in self.backends:
            try:
                backend.log_histogram(name, values, step)
            except Exception as e:
                print(f"Warning: Backend failed to log histogram {name}: {e}")
    
    def log_text(self, name: str, text: str, step: int) -> None:
        """Log text data."""
        for backend in self.backends:
            try:
                backend.log_text(name, text, step)
            except Exception as e:
                print(f"Warning: Backend failed to log text {name}: {e}")
    
    def log_config(self, config: Dict[str, Any]) -> None:
        """Log configuration to all backends."""
        for backend in self.backends:
            try:
                backend.log_config(config)
            except Exception as e:
                print(f"Warning: Backend failed to log config: {e}")
    
    def log_llm_metrics(
        self,
        step: int,
        latency_ms: float,
        tokens_used: int,
        cache_hit: bool,
        estimated_cost: float,
    ) -> None:
        """Log LLM-specific metrics."""
        metrics = {
            'llm/latency_ms': latency_ms,
            'llm/tokens_used': float(tokens_used),
            'llm/cache_hit': float(cache_hit),
            'llm/estimated_cost': estimated_cost,
        }
        self.log_scalars(metrics, step)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics of tracked metrics."""
        summary = {
            'experiment_name': self.experiment_name,
            'start_time': self.start_time.isoformat(),
            'total_records': len(self.records),
            'step_metrics': {},
            'episode_metrics': {},
        }
        
        for name, values in self._step_metrics.items():
            if values:
                summary['step_metrics'][name] = {
                    'mean': float(np.mean(values)),
                    'std': float(np.std(values)),
                    'min': float(np.min(values)),
                    'max': float(np.max(values)),
                    'count': len(values),
                }
        
        for name, values in self._episode_metrics.items():
            if values:
                summary['episode_metrics'][name] = {
                    'mean': float(np.mean(values)),
                    'std': float(np.std(values)),
                    'min': float(np.min(values)),
                    'max': float(np.max(values)),
                    'count': len(values),
                }
        
        return summary
    
    def save_summary(self, path: Optional[Path] = None) -> None:
        """Save summary to JSON file."""
        if path is None:
            path = self.output_dir / f"{self.experiment_name}_summary.json"
        
        summary = self.get_summary()
        with open(path, 'w') as f:
            json.dump(summary, f, indent=2)
    
    def export_records(self, format: str = 'json') -> None:
        """Export all records to file."""
        if format == 'json':
            path = self.output_dir / f"{self.experiment_name}_records.json"
            with open(path, 'w') as f:
                json.dump([r.to_dict() for r in self.records], f, indent=2)
        elif format == 'csv':
            import csv
            path = self.output_dir / f"{self.experiment_name}_records.csv"
            
            if not self.records:
                return
            
            fieldnames = ['step', 'timestamp'] + list(self.records[0].metrics.keys())
            
            with open(path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                
                for record in self.records:
                    row = {
                        'step': record.step,
                        'timestamp': record.timestamp,
                        **record.metrics,
                    }
                    writer.writerow(row)
    
    def close(self) -> None:
        """Close all backends and save data."""
        for backend in self.backends:
            try:
                backend.close()
            except Exception as e:
                print(f"Warning: Backend failed to close: {e}")
        
        self.save_summary()
        self.export_records('json')
        self.export_records('csv')
