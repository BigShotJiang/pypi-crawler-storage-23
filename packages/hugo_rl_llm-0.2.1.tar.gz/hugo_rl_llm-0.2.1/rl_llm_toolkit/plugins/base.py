from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Type

from rl_llm_toolkit.api.v1 import (
    AgentProtocol,
    RewardBackendProtocol,
    EnvAdapterProtocol,
)


class PluginType(Enum):
    AGENT = "agent"
    REWARD_BACKEND = "reward_backend"
    ENVIRONMENT = "environment"
    CALLBACK = "callback"


@dataclass
class PluginCapability:
    online: bool = True
    offline: bool = False
    single_agent: bool = True
    multi_agent: bool = False
    continuous: bool = True
    discrete: bool = True
    requires_llm: bool = False
    supports_cache: bool = False
    gpu_required: bool = False
    
    def to_dict(self) -> Dict[str, bool]:
        return {
            'online': self.online,
            'offline': self.offline,
            'single_agent': self.single_agent,
            'multi_agent': self.multi_agent,
            'continuous': self.continuous,
            'discrete': self.discrete,
            'requires_llm': self.requires_llm,
            'supports_cache': self.supports_cache,
            'gpu_required': self.gpu_required,
        }


@dataclass
class PluginMetadata:
    name: str
    version: str
    author: str
    description: str
    plugin_type: PluginType
    capabilities: PluginCapability
    dependencies: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'version': self.version,
            'author': self.author,
            'description': self.description,
            'plugin_type': self.plugin_type.value,
            'capabilities': self.capabilities.to_dict(),
            'dependencies': self.dependencies,
        }


class BasePlugin(ABC):
    """Base class for all Hugo plugins."""
    
    @abstractmethod
    def get_metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        pass
    
    @abstractmethod
    def initialize(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize plugin with configuration."""
        pass
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate plugin is properly configured."""
        pass
    
    def cleanup(self) -> None:
        """Cleanup plugin resources."""
        pass


class AgentPlugin(BasePlugin):
    """Plugin for custom RL agents."""
    
    @abstractmethod
    def create_agent(self, **kwargs: Any) -> AgentProtocol:
        """Create and return an agent instance."""
        pass


class RewardBackendPlugin(BasePlugin):
    """Plugin for custom reward backends."""
    
    @abstractmethod
    def create_backend(self, **kwargs: Any) -> RewardBackendProtocol:
        """Create and return a reward backend instance."""
        pass


class EnvPlugin(BasePlugin):
    """Plugin for custom environments."""
    
    @abstractmethod
    def create_env(self, **kwargs: Any) -> EnvAdapterProtocol:
        """Create and return an environment instance."""
        pass


class CallbackPlugin(BasePlugin):
    """Plugin for training callbacks."""
    
    @abstractmethod
    def on_training_start(self, **kwargs: Any) -> None:
        """Called at the start of training."""
        pass
    
    @abstractmethod
    def on_training_end(self, **kwargs: Any) -> None:
        """Called at the end of training."""
        pass
    
    @abstractmethod
    def on_step(self, step: int, **kwargs: Any) -> None:
        """Called after each training step."""
        pass
    
    @abstractmethod
    def on_episode_end(self, episode: int, **kwargs: Any) -> None:
        """Called at the end of each episode."""
        pass
