import importlib
import sys
from pathlib import Path
from typing import Dict, List, Optional, Type

from rich.console import Console
from rich.table import Table

from rl_llm_toolkit.core.exceptions import PluginError
from rl_llm_toolkit.plugins.base import BasePlugin, PluginType, PluginMetadata


console = Console()


class PluginManager:
    """Manages plugin discovery and loading via entry points."""
    
    _plugins: Dict[str, Dict[str, Type[BasePlugin]]] = {
        'hugo.agents': {},
        'hugo.reward_backends': {},
        'hugo.envs': {},
        'hugo.callbacks': {},
    }
    
    _initialized_plugins: Dict[str, BasePlugin] = {}
    
    @classmethod
    def discover_plugins(cls) -> None:
        """Discover plugins via entry points."""
        try:
            if sys.version_info >= (3, 10):
                from importlib.metadata import entry_points
                eps = entry_points()
            else:
                from importlib_metadata import entry_points
                eps = entry_points()
            
            for namespace in cls._plugins.keys():
                if hasattr(eps, 'select'):
                    group = eps.select(group=namespace)
                else:
                    group = eps.get(namespace, [])
                
                for entry_point in group:
                    try:
                        plugin_class = entry_point.load()
                        if issubclass(plugin_class, BasePlugin):
                            cls._plugins[namespace][entry_point.name] = plugin_class
                            console.print(f"[green]Discovered plugin: {entry_point.name} ({namespace})[/green]")
                    except Exception as e:
                        console.print(f"[yellow]Warning: Failed to load plugin {entry_point.name}: {e}[/yellow]")
        
        except ImportError:
            console.print("[yellow]Warning: importlib.metadata not available, plugin discovery disabled[/yellow]")
    
    @classmethod
    def register_plugin(cls, namespace: str, name: str, plugin_class: Type[BasePlugin]) -> None:
        """Manually register a plugin."""
        if namespace not in cls._plugins:
            raise PluginError(f"Invalid namespace: {namespace}")
        
        if not issubclass(plugin_class, BasePlugin):
            raise PluginError(f"Plugin must inherit from BasePlugin")
        
        cls._plugins[namespace][name] = plugin_class
    
    @classmethod
    def get_plugin(cls, namespace: str, name: str) -> Optional[Type[BasePlugin]]:
        """Get a plugin class by namespace and name."""
        return cls._plugins.get(namespace, {}).get(name)
    
    @classmethod
    def list_plugins(cls, namespace: Optional[str] = None) -> Dict[str, List[str]]:
        """List all available plugins."""
        if namespace:
            return {namespace: list(cls._plugins.get(namespace, {}).keys())}
        
        return {ns: list(plugins.keys()) for ns, plugins in cls._plugins.items()}
    
    @classmethod
    def initialize_plugin(
        cls,
        namespace: str,
        name: str,
        config: Optional[Dict] = None,
    ) -> BasePlugin:
        """Initialize a plugin instance."""
        plugin_key = f"{namespace}.{name}"
        
        if plugin_key in cls._initialized_plugins:
            return cls._initialized_plugins[plugin_key]
        
        plugin_class = cls.get_plugin(namespace, name)
        if plugin_class is None:
            raise PluginError(f"Plugin not found: {namespace}.{name}")
        
        try:
            plugin_instance = plugin_class()
            plugin_instance.initialize(config)
            
            if not plugin_instance.validate():
                raise PluginError(f"Plugin validation failed: {namespace}.{name}")
            
            cls._initialized_plugins[plugin_key] = plugin_instance
            return plugin_instance
            
        except Exception as e:
            raise PluginError(f"Failed to initialize plugin {namespace}.{name}: {e}") from e
    
    @classmethod
    def validate_plugin(cls, namespace: str, name: str) -> tuple[bool, Optional[str]]:
        """Validate a plugin without initializing it."""
        plugin_class = cls.get_plugin(namespace, name)
        if plugin_class is None:
            return False, f"Plugin not found: {namespace}.{name}"
        
        try:
            plugin_instance = plugin_class()
            metadata = plugin_instance.get_metadata()
            
            if not isinstance(metadata, PluginMetadata):
                return False, "Invalid metadata format"
            
            return True, None
            
        except Exception as e:
            return False, str(e)
    
    @classmethod
    def print_plugin_info(cls) -> None:
        """Print information about all discovered plugins."""
        table = Table(title="Discovered Hugo Plugins")
        table.add_column("Namespace", style="cyan")
        table.add_column("Name", style="magenta")
        table.add_column("Status", style="green")
        
        for namespace, plugins in cls._plugins.items():
            for name in plugins.keys():
                is_valid, error = cls.validate_plugin(namespace, name)
                status = "✓ Valid" if is_valid else f"✗ {error}"
                table.add_row(namespace, name, status)
        
        console.print(table)
    
    @classmethod
    def cleanup_all(cls) -> None:
        """Cleanup all initialized plugins."""
        for plugin in cls._initialized_plugins.values():
            try:
                plugin.cleanup()
            except Exception as e:
                console.print(f"[yellow]Warning: Plugin cleanup failed: {e}[/yellow]")
        
        cls._initialized_plugins.clear()


PluginCapability = PluginMetadata
