import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Callable, Any
import logging

logger = logging.getLogger(__name__)


class CircuitBreakerState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    timeout_seconds: float = 60.0
    half_open_max_calls: int = 3
    success_threshold: int = 2


class CircuitBreaker:
    """
    Circuit breaker pattern for LLM backend calls.
    
    Prevents cascading failures by temporarily blocking calls to failing backends.
    """
    
    def __init__(
        self,
        name: str,
        config: Optional[CircuitBreakerConfig] = None,
        fallback: Optional[Callable] = None,
    ):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.fallback = fallback
        
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[float] = None
        self.half_open_calls = 0
        
        self._total_calls = 0
        self._total_failures = 0
        self._total_fallbacks = 0
    
    def call(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """
        Execute function with circuit breaker protection.
        
        Args:
            func: Function to call
            *args, **kwargs: Arguments to pass to function
            
        Returns:
            Result from function or fallback
            
        Raises:
            CircuitBreakerError: If circuit is open and no fallback
        """
        self._total_calls += 1
        
        if self.state == CircuitBreakerState.OPEN:
            if self._should_attempt_reset():
                self._transition_to_half_open()
            else:
                return self._handle_open_circuit(*args, **kwargs)
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            if self.half_open_calls >= self.config.half_open_max_calls:
                return self._handle_open_circuit(*args, **kwargs)
        
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
            
        except Exception as e:
            self._on_failure()
            
            if self.fallback:
                logger.warning(f"Circuit breaker {self.name}: Using fallback due to error: {e}")
                self._total_fallbacks += 1
                return self.fallback(*args, **kwargs)
            
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        if self.last_failure_time is None:
            return True
        
        elapsed = time.time() - self.last_failure_time
        return elapsed >= self.config.timeout_seconds
    
    def _transition_to_half_open(self) -> None:
        """Transition to half-open state."""
        logger.info(f"Circuit breaker {self.name}: Transitioning to HALF_OPEN")
        self.state = CircuitBreakerState.HALF_OPEN
        self.half_open_calls = 0
        self.success_count = 0
    
    def _handle_open_circuit(self, *args: Any, **kwargs: Any) -> Any:
        """Handle call when circuit is open."""
        if self.fallback:
            logger.warning(f"Circuit breaker {self.name}: Circuit OPEN, using fallback")
            self._total_fallbacks += 1
            return self.fallback(*args, **kwargs)
        
        raise CircuitBreakerError(
            f"Circuit breaker {self.name} is OPEN. "
            f"Failed {self.failure_count} times. "
            f"Retry after {self.config.timeout_seconds}s"
        )
    
    def _on_success(self) -> None:
        """Handle successful call."""
        self.failure_count = 0
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            self.success_count += 1
            self.half_open_calls += 1
            
            if self.success_count >= self.config.success_threshold:
                logger.info(f"Circuit breaker {self.name}: Transitioning to CLOSED")
                self.state = CircuitBreakerState.CLOSED
                self.half_open_calls = 0
    
    def _on_failure(self) -> None:
        """Handle failed call."""
        self._total_failures += 1
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            logger.warning(f"Circuit breaker {self.name}: Failure in HALF_OPEN, reopening")
            self.state = CircuitBreakerState.OPEN
            self.half_open_calls = 0
            
        elif self.failure_count >= self.config.failure_threshold:
            logger.error(
                f"Circuit breaker {self.name}: Opening circuit after "
                f"{self.failure_count} failures"
            )
            self.state = CircuitBreakerState.OPEN
    
    def reset(self) -> None:
        """Manually reset circuit breaker."""
        logger.info(f"Circuit breaker {self.name}: Manual reset")
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.half_open_calls = 0
        self.last_failure_time = None
    
    def get_stats(self) -> dict:
        """Get circuit breaker statistics."""
        return {
            'name': self.name,
            'state': self.state.value,
            'failure_count': self.failure_count,
            'total_calls': self._total_calls,
            'total_failures': self._total_failures,
            'total_fallbacks': self._total_fallbacks,
            'failure_rate': self._total_failures / max(1, self._total_calls),
        }


class CircuitBreakerError(Exception):
    """Circuit breaker is open."""
    pass
