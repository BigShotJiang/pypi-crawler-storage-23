import re
from dataclasses import dataclass
from typing import Optional, List, Set
import logging

logger = logging.getLogger(__name__)


@dataclass
class SecurityConfig:
    """Security configuration for LLM prompt sanitization."""
    
    max_prompt_length: int = 4000
    max_state_size: int = 10000
    allow_special_chars: bool = True
    redact_secrets: bool = True
    block_injection_patterns: bool = True
    max_numeric_precision: int = 6
    
    secret_patterns: List[str] = None
    injection_patterns: List[str] = None
    
    def __post_init__(self):
        if self.secret_patterns is None:
            self.secret_patterns = [
                r'(?i)(api[_-]?key|token|password|secret)["\s:=]+([a-zA-Z0-9_\-]{20,})',
                r'sk-[a-zA-Z0-9]{20,}',
                r'(?i)bearer\s+[a-zA-Z0-9_\-\.]{20,}',
            ]
        
        if self.injection_patterns is None:
            self.injection_patterns = [
                r'(?i)ignore\s+(previous|all)\s+instructions',
                r'(?i)system\s*:\s*you\s+are',
                r'(?i)disregard\s+(all|previous)',
                r'(?i)<\s*script\s*>',
                r'(?i)eval\s*\(',
                r'(?i)exec\s*\(',
            ]


class PromptSanitizer:
    """Sanitize and validate prompts before sending to LLM backends."""
    
    def __init__(self, config: Optional[SecurityConfig] = None):
        self.config = config or SecurityConfig()
        self._redacted_count = 0
        self._blocked_count = 0
    
    def sanitize_prompt(self, prompt: str) -> tuple[str, List[str]]:
        """
        Sanitize a prompt for safe LLM usage.
        
        Returns:
            Tuple of (sanitized_prompt, warnings)
        """
        warnings = []
        sanitized = prompt
        
        if len(sanitized) > self.config.max_prompt_length:
            sanitized = sanitized[:self.config.max_prompt_length]
            warnings.append(f"Prompt truncated to {self.config.max_prompt_length} chars")
        
        if self.config.redact_secrets:
            sanitized, redacted = self._redact_secrets(sanitized)
            if redacted:
                warnings.append(f"Redacted {redacted} potential secrets")
                self._redacted_count += redacted
        
        if self.config.block_injection_patterns:
            blocked, block_warnings = self._check_injection_patterns(sanitized)
            if blocked:
                warnings.extend(block_warnings)
                self._blocked_count += 1
                raise SecurityError(f"Prompt blocked: {', '.join(block_warnings)}")
        
        if not self.config.allow_special_chars:
            sanitized = self._remove_special_chars(sanitized)
            warnings.append("Special characters removed")
        
        return sanitized, warnings
    
    def sanitize_state(self, state_str: str) -> str:
        """Sanitize state representation."""
        if len(state_str) > self.config.max_state_size:
            return state_str[:self.config.max_state_size] + "..."
        
        return state_str
    
    def sanitize_numeric(self, value: float) -> float:
        """Sanitize numeric values to prevent precision attacks."""
        return round(value, self.config.max_numeric_precision)
    
    def _redact_secrets(self, text: str) -> tuple[str, int]:
        """Redact potential secrets from text."""
        redacted_count = 0
        result = text
        
        for pattern in self.config.secret_patterns:
            matches = re.finditer(pattern, result)
            for match in matches:
                redacted_count += 1
                result = result.replace(match.group(), "[REDACTED]")
        
        return result, redacted_count
    
    def _check_injection_patterns(self, text: str) -> tuple[bool, List[str]]:
        """Check for prompt injection patterns."""
        warnings = []
        
        for pattern in self.config.injection_patterns:
            if re.search(pattern, text):
                warnings.append(f"Detected injection pattern: {pattern}")
        
        return len(warnings) > 0, warnings
    
    def _remove_special_chars(self, text: str) -> str:
        """Remove special characters."""
        return re.sub(r'[^\w\s\-.,!?]', '', text)
    
    def get_stats(self) -> dict:
        """Get sanitization statistics."""
        return {
            'redacted_count': self._redacted_count,
            'blocked_count': self._blocked_count,
        }


class SecurityError(Exception):
    """Security-related error."""
    pass
