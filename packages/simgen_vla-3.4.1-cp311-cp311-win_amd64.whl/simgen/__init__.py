"""
SimGen VLA - TRUE ZERO ERROR GPU Computation
=============================================

Exact arithmetic for PyTorch on GPU.
Zero accumulation error. Deterministic results.

Usage:
    from simgen import vla

    # Exact operations
    result = vla.sum(x)           # Zero-error sum
    result = vla.matmul(a, b)     # Exact matrix multiplication
    result = vla.dot(a, b)        # Exact dot product

    # Enable globally (patches torch ops)
    vla.enable()
    result = torch.sum(x)  # Now uses VLA!
    vla.disable()

    # System info
    vla.info()

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

__version__ = "3.4.1"
__author__ = "Clouthier Simulation Labs"

# Import the VLA package (clean public API)
from . import vla

# Also expose the runtime for advanced usage
from . import vla_runtime

__all__ = [
    "vla",
    "vla_runtime",
    "__version__",
]
