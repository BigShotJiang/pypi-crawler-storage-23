"""
Propagation of values though graphs.
"""

import os
from collections import defaultdict

from william.hotloops import RustGraph
from william.library.base import Value, exec_errors
from william.nvmap import MapEntry, NodeValueMap
from william.utils.helpers import set_trace_up
from william.utils.registry import Registry

level = int(os.environ.get("WILLIAM_DEBUG", 0))


class RandomPropagation:
    """
    This type of propagation randomly chooses nodes to try to fire. If no node can be fired, it continues with other random nodes
    in a recursive manner, until all nodes have fired and the data has propagated through the entire graph, or no more nodes can be fired.
    """

    def __init__(self, registry: Registry, partial=False, unique=True, cache=False):
        self.partial = partial
        self.unique = unique
        self.fire_up = FireUp(registry, cache_enabled=cache)
        self.fire_down = FireDown(registry, cache_enabled=cache)

    def propagate(self, root: RustGraph, mem, debug=False):
        op_nodes = root.nodes(False, True)
        seen = []
        for new_mem in self._propagate(root, mem, op_nodes, debug=debug):
            if self.unique and new_mem in seen:
                continue
            seen.append(new_mem)
            yield new_mem

    def _propagate(
        self, root: RustGraph, mem: NodeValueMap, unsatisfied: list[int], depth: int = 0, debug: bool = False
    ):
        """
        unsatisfied: is a list of operator nodes for which at least one input or the output is not in mem,
        i.e. not computed yet
        """
        if not unsatisfied:
            yield mem
            return
        found = False
        for node in unsatisfied:
            for new_mem in self._try_to_fire(root, node, mem, debug=debug):
                new_unsatisfied = unsatisfied.copy()
                new_unsatisfied.remove(node)
                for res_mem in self._propagate(root, new_mem, new_unsatisfied, depth=depth + 1, debug=debug):
                    found = True
                    yield res_mem
            if found:
                break
        if not found and self.partial:
            yield mem
        if debug:
            root.render(mem=mem)

    def _try_to_fire(self, root: RustGraph, node: int, mem: NodeValueMap, debug: bool = False):
        for fire_instance in (self.fire_up, self.fire_down):
            yield from fire_instance.try_to_fire(root, node, mem, debug=debug)


class FireBase:
    def __init__(self, registry: Registry, cache_enabled=True):
        self.registry = registry
        self.cache = defaultdict(list)
        self.cache_enabled = cache_enabled
        self.num_reuses = 0
        self.num_calls = 0

    def try_to_fire(self, root: RustGraph, node: int, mem: NodeValueMap, debug: bool = False):
        for cond in self.conditions(root, node):
            for inf_nodes, cond_inputs in self.inf_nodes_and_cond_inputs(root, node, mem, cond):
                for inf_values in self._cached_loop(root, node, cond_inputs, cond, len(inf_nodes), debug=debug):
                    yield self._update_mem(root, mem, node, inf_nodes, inf_values, same=False)

    def _cached_loop(
        self,
        root: RustGraph,
        node: int,
        cond_inputs: list[Value],
        cond: tuple[int],
        len_inf_nodes: int,
        debug: bool = False,
    ):
        if self.cache_enabled:
            key = (root.get_op_id(node), tuple(inp.hash for inp in cond_inputs), cond, len_inf_nodes)
            if key in self.cache:
                self.num_reuses += 1
                for inf_values in self.cache[key]:
                    yield inf_values
                return

        self.num_calls += 1
        for inf_values in self.fire(root, node, cond_inputs, cond, len_inf_nodes, debug=debug):
            if self.cache_enabled:
                self.cache[key].append(inf_values)
            yield inf_values

    def _update_mem(
        self,
        root: RustGraph,
        mem: NodeValueMap,
        node: int,
        inf_nodes: list[int],
        inf_values: list[Value],
        same: bool = False,
    ):
        new_mem = mem.copy()

        for val, inf_node in zip(inf_values, inf_nodes):
            new_mem[inf_node] = MapEntry(same=same, val=val)

        op = self.registry.get_obj(root.get_op_id(node))
        new_mem[node] = MapEntry(same=same, val=op)
        return new_mem


class FireUp(FireBase):
    def conditions(self, root: RustGraph, node: int):
        num_children = len(root.get_children(node))
        return (tuple(range(num_children)),)

    def fire(self, root: RustGraph, node: int, inputs: list[Value], *args, debug=False):
        op = self.registry.get_obj(root.get_op_id(node))
        if not debug:
            try:
                output = op(*inputs)
            except exec_errors:
                return
        else:
            output = op(*inputs)
            if output is None:
                set_trace_up()
        yield [output]

    def inf_nodes_and_cond_inputs(self, root: RustGraph, node: int, mem: NodeValueMap, *args):
        parent = root.get_parent(node)
        if parent in mem:  # cannot infer into nodes already in mem
            return
        inputs = []
        for child in root.get_children(node):
            inp_entry = mem.get(child, None)
            if inp_entry is None:
                return
            inputs.append(inp_entry.val)
        yield [parent], inputs


class FireDown(FireBase):
    def conditions(self, root: RustGraph, node: int):
        op = self.registry.get_obj(root.get_op_id(node))
        return op.conditions

    def fire(self, root: RustGraph, node: int, cond_inputs: list[Value], cond: tuple[int], num_inf: int, debug=False):
        success = False
        op = self.registry.get_obj(root.get_op_id(node))
        try:
            for inv in op.inverse(cond_inputs[0], cond_inputs[1:], cond):
                success = True
                yield inv
        except exec_errors:
            pass
        if not success and debug:
            # debug list(node.op.inverse(cond_inputs[0], cond_inputs[1:], cond))
            set_trace_up()

    def inf_nodes_and_cond_inputs(self, root: RustGraph, node: int, mem: NodeValueMap, cond: tuple[int]):
        out_entry = mem.get(root.get_parent(node), None)
        if out_entry is None:
            return
        cond_inputs = [out_entry.val]
        inf_nodes = []
        for i, child in enumerate(root.get_children(node)):
            if i not in cond:
                if child in inf_nodes:  # cannot infer into the same node twice
                    return
                if child in mem:  # cannot infer into nodes already in mem
                    return
                inf_nodes.append(child)
                continue
            inp_entry = mem.get(child, None)
            if inp_entry is None:
                return
            cond_inputs.append(inp_entry.val)
        yield inf_nodes, cond_inputs
