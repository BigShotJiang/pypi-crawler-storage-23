from collections import defaultdict, namedtuple
from copy import copy
from itertools import product

from numpy import inf

from william.nvmap import NodeValueMap
from william.structures import Graph, ValueNode

MinResult = namedtuple("MinResult", "nodes dl seen bottleneck sel")


class DummyNode:
    """Behave like a dummy variable node, for the purpose of minimum description length computation."""

    children = []
    offspring = []
    val = None

    def __init__(self, parent=None):
        self.parent = parent

    def __repr__(self):
        return f"<{type(self).__name__} at 0x{id(self):x}>"

    def __hash__(self):
        """Same hash for every dummy node"""
        return 49289437563


class MDL:
    def __init__(self, section, trace_manager=None):
        self.section = section
        self.tm = trace_manager or TraceManager(section.nodes)

    @property
    def nodes(self):
        return self.section.nodes


class ValueMDL(MDL):
    def _prep_dicts(self):
        return {}

    def min_desc_len(self, return_bottleneck=False, return_selection=False, mem=None):
        """
        Minimal description length computation for a list of value nodes (for a cross section).

        min_dl: the description length of the minimal subgraph
        bottleneck: a cross section consisting of the narrowest part of the subgraph
        sel: a list of option nodes that participate in the minimal subgraph
        """
        self.tm.mem = mem or {}
        traces = self.tm.init_traces(len(self.nodes))
        seen = ()
        kwargs = self._prep_dicts()
        res = self.min_dl(traces, seen, **kwargs)
        sel = [node for node in res.sel if not isinstance(node, DummyNode)]
        result = res.dl
        if return_bottleneck:
            result = (res.dl, Graph(res.bottleneck))
        if return_selection:
            result = result if isinstance(result, tuple) else (result,)
            result += (sel,)
        return result

    def _option_combs(self):
        option_lists = []
        for val_node in self.nodes:
            options_in_mem = [option for option in val_node.options if option in self.tm.mem]
            options = options_in_mem if val_node in self.tm.mem or self.tm.mem and options_in_mem else val_node.options
            options = [DummyNode()] + options  # [option for option in node.options if not mem or option in mem]
            option_lists.append(options)

        for comb in product(*option_lists):
            yield OpMDL(Graph(comb), trace_manager=self.tm)

    def min_dl(self, traces, seen, **kwargs):
        new_traces = self.tm.update_traces(self.nodes, traces)

        seen += tuple(self.nodes)
        min_result = MinResult(nodes=[], dl=inf, seen=(), bottleneck=[], sel=[])
        for ops in self._option_combs():
            result = ops.min_dl(self.nodes, new_traces, seen, **kwargs)
            if result.dl < min_result.dl:
                min_result = result
        return min_result


class OpMDL(MDL):
    val_cls = ValueMDL

    def min_dl(self, parents, traces, seen, **kwargs):
        """Description length computation for a list of operator nodes"""
        traces = self.tm.update_traces(self.nodes, traces)
        self.tm.extend_traces(self.nodes, traces)
        dl = 0
        all_children = []
        trace_store = {}
        bottleneck = []
        for node, parent, trace in zip(self.nodes, parents, traces):
            children, seen, ddl = self._filter_children(node, parent, trace, trace_store, seen, bottleneck)
            dl += ddl
            all_children.extend(children)
        if not all_children:
            return MinResult(nodes=self.nodes, dl=dl, seen=seen, bottleneck=bottleneck, sel=self.nodes)
        val_mdl = self.val_cls(Graph(all_children), trace_manager=self.tm)
        all_traces = [trace_store[child] for child in all_children]
        res = val_mdl.min_dl(all_traces, seen, **kwargs)
        return MinResult(
            nodes=self.nodes,
            dl=dl + res.dl,
            seen=res.seen,
            bottleneck=bottleneck + res.bottleneck,
            sel=self.nodes + res.sel,
        )

    def _filter_children(self, node, parent, trace, trace_store, seen, bottleneck):
        if self._check_stop(node, parent):
            bottleneck.append(parent)
            return [], seen, parent.output_dl(mem=self.tm.mem)

        ch = []
        ddl = 1.0
        for child in node.children:
            # child is in the trace coming from one of its prime_fathers fathers (=cycle detected)
            if self.tm.cycle_detected(child, node, trace):
                bottleneck.append(child)
                ddl += child.output_dl(mem=self.tm.mem)
            if child in seen:
                if child in trace_store:
                    self.tm.merge_trace(trace_store[child], trace)
                continue
            ch.append(child)
            trace_store[child] = copy(trace)
            seen += (child,)

        return ch, seen, ddl

    def _check_stop(self, node, parent):
        if not node.children:
            return True
        mem = self.tm.mem
        some_child_differs = any([child in mem and child.output is not mem[child].val for child in node.children])
        if parent not in mem and some_child_differs:
            return True
        if parent in mem and any([child not in mem for child in node.children]):
            return True
        return False


class TraceManager:
    def __init__(self, root_nodes):
        self._prime_fathers = defaultdict(set)
        for node in root_nodes:
            # trace von first to second node (the same during initialization here)
            self._prime_fathers[node] = {node}
            self._prime_fathers[None].add(node)  # store all original nodes (= prime fathers) here
        self.mem = None
        self.mdl_dict = defaultdict(set)

    def add_mdl(self, mdl):
        for node in mdl.sec.nodes:
            self.mdl_dict[node].add(mdl)

    @staticmethod
    def init_traces(n):
        traces = []
        for _ in range(n):
            traces.append(defaultdict(tuple))
        return traces

    def update_traces(self, nodes, traces):
        new_traces = []
        for node, trace in zip(nodes, traces):
            for offsp in node.offspring:
                self._prime_fathers[offsp].update(self._prime_fathers[node])

            new_trace = copy(trace)
            for pf in self._prime_fathers[node]:
                # meaning that current node is an offspring of prime_fathers father pf (=one of the original self.nodes)
                if node not in new_trace[pf]:
                    new_trace[pf] += (node,)
            new_traces.append(new_trace)
        return new_traces

    def cycle_detected(self, child, node, trace):
        """<child> is a <node>'s child/option. A cycle is detected if the <child> is on the trace between the <node>
        and one of its prime_fathers fathers."""
        for pf in self._prime_fathers[node]:
            if child in trace[pf]:
                return True
        return False

    @staticmethod
    def merge_trace(trace, new_trace):
        for pf, trace_val in new_trace.items():
            if pf not in trace:
                trace[pf] = trace_val

    @staticmethod
    def _find_in_traces(child, traces, all_prime_fathers):
        for trace_dict in traces:
            for target_pf in all_prime_fathers:
                if target_pf not in trace_dict:
                    continue
                # find a trace containing the child
                if child in trace_dict[target_pf]:
                    yield trace_dict, target_pf

    def _merge_into_trace(self, child_trace, target_trace, child_pf):
        # e.g. source_trace = (123, mult, 950, add), target_trace = (123, mult, 850, sub)
        # source trace continues with 850 (=child), which is inside the target_trace. Therefore, we should get a new
        # merged trace: (123, mult, 950, add, 850, sub)
        merged_trace = list(child_trace)
        for node in target_trace:
            if node not in merged_trace:
                merged_trace.append(node)
                self._prime_fathers[node].add(child_pf)
        return tuple(merged_trace)

    def extend_traces(self, nodes, traces):
        replacements = []
        pfs = {}
        for node in nodes:
            pfs[node] = list(self._prime_fathers[node])
        for node, child_trace_dict in zip(nodes, traces):
            for child in node.children:
                for child_pf in pfs[node]:
                    if child_pf not in child_trace_dict:
                        continue
                    ct = child_trace_dict[child_pf]
                    for target_trace_dict, target_pf in self._find_in_traces(child, traces, self._prime_fathers[None]):
                        merged_trace = self._merge_into_trace(ct, target_trace_dict[target_pf], child_pf)
                        replacements.append((target_trace_dict, target_pf, merged_trace))
                        # if target_pf is child_pf:
                        #     continue
                        # update prime fathers here
        for trace_dict, pf, new_trace in replacements:
            trace_dict[pf] = new_trace


def trace_comb_bottleneck(cross_sects: list[list[ValueNode]], mem: NodeValueMap) -> tuple[float, list[ValueNode]]:
    min_dl = float("inf")
    bottleneck = []
    for bn, num_op_nodes in cross_sects:
        dl = sum(mem[node].val.desc_len() for node in bn) + num_op_nodes
        if dl < min_dl:
            min_dl = dl
            bottleneck = bn
    return min_dl, bottleneck


def cross_sections(target_leaf: ValueNode, leaves: list[ValueNode]):
    """Generate all cross-sections through the DAG at the target leaf."""
    traces = list(target_leaf.traces(me_too=True, op_nodes=False, val_nodes=True, above=True, below=False))
    traces_with_nums = [list(enumerate(trace)) for trace in traces]

    seen = set()
    for trace_comb in product(*traces_with_nums):
        trace_comb = list(trace_comb)

        # remove nodes in bottleneck that are below others
        hsh = 0
        index = 0
        num_op_nodes = 0
        bn = []
        for index, (tr_idx, vn) in enumerate(trace_comb):
            nodes_above = traces[index][tr_idx:]
            if not any(other[1] in nodes_above for other in trace_comb[:index] + trace_comb[index + 1 :]):
                bn.append(vn)
                hsh ^= hash(vn)
                num_op_nodes += len(nodes_above) - 1

        for leaf in leaves:
            if not leaf.is_below(bn):
                bn.append(leaf)
                hsh ^= hash(leaf)

        if hsh in seen:
            continue
        seen.add(hsh)

        yield bn, num_op_nodes
