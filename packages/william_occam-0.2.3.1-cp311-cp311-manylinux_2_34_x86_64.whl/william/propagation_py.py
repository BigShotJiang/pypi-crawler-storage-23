"""
Propagation of values though graphs.
"""

import os
from collections import defaultdict

from william.library.base import exec_errors
from william.nvmap import MapEntry
from william.utils.helpers import set_trace_up

level = int(os.environ.get("WILLIAM_DEBUG", 0))


class RandomPropagation:
    """
    This type of propagation randomly chooses nodes to try to fire. If no node can be fired, it continues with other random nodes
    in a recursive manner, until all nodes have fired and the data has propagated through the entire graph, or no more nodes can be fired.
    """

    def __init__(self, partial=False, unique=True, compute=True, cache=False):
        self.partial = partial
        self.unique = unique
        self.fire_up = FireUp(cache_enabled=cache) if compute else FireUpWithoutComputation()
        self.fire_down = FireDown(cache_enabled=cache) if compute else FireDownWithoutComputation()

    def propagate(self, root, mem, debug=False):
        nodes = self._init_nodes(root)
        seen = []
        for new_mem in self._propagate(root, mem, nodes, debug=debug):
            if self.unique and new_mem in seen:
                continue
            seen.append(new_mem)
            yield new_mem

    def _init_nodes(self, root):
        return set(node for node in root.walk(val_nodes=False))

    def _propagate(self, root, mem, unsatisfied, *args, depth=0, debug=False):
        """
        unsatisfied: is a list of operator nodes for which at least one input or the output is not in mem,
        i.e. not computed yet
        """
        if not unsatisfied:
            yield mem
            return
        found = False
        for node in unsatisfied:
            for new_mem in self._try_to_fire(node, mem, debug=debug):
                new_unsatisfied = unsatisfied.copy()
                new_unsatisfied.remove(node)
                for res_mem in self._propagate(root, new_mem, new_unsatisfied, *args, depth=depth + 1, debug=debug):
                    found = True
                    yield res_mem
            if found:
                break
        if not found and self.partial:
            yield mem
        if debug:
            root.render(mem=mem)

    def _try_to_fire(self, node, mem, debug=False):
        for fire_instance in (self.fire_up, self.fire_down):
            yield from fire_instance.try_to_fire(node, mem, debug=debug)


class FireBase:
    def __init__(self, cache_enabled=True):
        self.cache = defaultdict(list)
        self.cache_enabled = cache_enabled
        self.num_reuses = 0
        self.num_calls = 0

    def try_to_fire(self, node, mem, debug=False):
        for cond in self.conditions(node):
            for inf_nodes, cond_inputs in self.inf_nodes_and_cond_inputs(node, mem, cond):
                for inf_values in self._cached_loop(node, cond_inputs, cond, len(inf_nodes), debug=debug):
                    yield _update_mem(mem, node, inf_nodes, inf_values, same=False)

    def _cached_loop(self, node, cond_inputs, cond, len_inf_nodes, debug=False):
        if self.cache_enabled:
            key = (str(node.op), tuple(inp.hash for inp in cond_inputs), cond, len_inf_nodes, isinstance(self, FireUp))
            if key in self.cache:
                self.num_reuses += 1
                for inf_values in self.cache[key]:
                    yield inf_values
                # inf_values_ref = list(self.fire(node, cond_inputs, cond, len_inf_nodes, debug=debug))
                # inf_values_cache = [inf_values for inf_values, _ in self.cache[key]]
                # assert len(inf_values_ref) == len(inf_values_cache)
                # for inf_values1, inf_values2 in zip(inf_values_cache, inf_values_ref):
                #     # sanity check
                #     assert all(v1.hash == v2.hash for v1, v2 in zip(inf_values1, inf_values2))
                #     yield inf_values1
                return

        self.num_calls += 1
        for inf_values in self.fire(node, cond_inputs, cond, len_inf_nodes, debug=debug):
            if self.cache_enabled:
                self.cache[key].append(inf_values)
                # self.cache[key].append((inf_values, (node, cond_inputs, cond, len_inf_nodes)))
            yield inf_values


class FireUp(FireBase):
    @staticmethod
    def conditions(node):
        return (tuple(range(len(node.children))),)

    def fire(self, node, inputs, *args, debug=False):
        if not debug:
            try:
                output = node.op(*inputs)
            except exec_errors:
                return
        else:
            output = node.op(*inputs)
            if output is None:
                set_trace_up()
        yield [output]

    def inf_nodes_and_cond_inputs(self, node, mem, cond):
        if node.parent in mem:  # cannot infer into nodes already in mem
            return
        inputs = []
        for i, child in enumerate(node.children):
            inp_entry = mem.get(child, None)
            if inp_entry is None:
                return
            inputs.append(inp_entry.val)
        yield [node.parent], inputs


class FireDown(FireBase):
    @staticmethod
    def conditions(node):
        return node.op.conditions

    def fire(self, node, cond_inputs, cond, num_inf, debug=False):
        success = False
        try:
            for inv in node.op.inverse(cond_inputs[0], cond_inputs[1:], cond):
                success = True
                yield inv
        except exec_errors:
            pass
        if not success and debug:
            # debug list(node.op.inverse(cond_inputs[0], cond_inputs[1:], cond))
            set_trace_up()

    def inf_nodes_and_cond_inputs(self, node, mem, cond):
        out_entry = mem.get(node.parent, None)
        if out_entry is None:
            return
        cond_inputs = [out_entry.val]
        inf_nodes = []
        for i, child in enumerate(node.children):
            if i not in cond:
                if child in inf_nodes:  # cannot infer into the same node twice
                    return
                if child in mem:  # cannot infer into nodes already in mem
                    return
                inf_nodes.append(child)
                continue
            inp_entry = mem.get(child, None)
            if inp_entry is None:
                return
            cond_inputs.append(inp_entry.val)
        yield inf_nodes, cond_inputs


def _update_mem(mem, node, inf_nodes, inf_values, same=False):
    new_mem = mem.copy()

    for val, inf_node in zip(inf_values, inf_nodes):
        new_mem[inf_node] = MapEntry(same=same, val=val)

    new_mem[node] = MapEntry(same=same, val=node.op)
    return new_mem


class FireUpWithoutComputation(FireUp):
    def _cached_loop(self, node, cond_inputs, cond, len_inf_nodes, debug=False):
        yield from self.fire(node, cond_inputs, cond, len_inf_nodes, debug=debug)

    def fire(self, node, inputs, *args, debug=False):
        output = node.op.call_without_computation(*inputs)
        if output is None:
            if debug:
                set_trace_up()
            return
        yield [output]


class FireDownWithoutComputation(FireDown):
    def _cached_loop(self, node, cond_inputs, cond, len_inf_nodes, debug=False):
        yield from self.fire(node, cond_inputs, cond, len_inf_nodes, debug=debug)

    def fire(self, node, cond_inputs, cond, num_inf, debug=False):
        inf_values = []
        for i in range(num_inf):
            val = node.op.inverse_without_computation(cond_inputs[0], cond_inputs[1:], cond, i)
            if val.is_none:
                if debug:
                    set_trace_up()
                return
            inf_values.append(val)
        yield inf_values
