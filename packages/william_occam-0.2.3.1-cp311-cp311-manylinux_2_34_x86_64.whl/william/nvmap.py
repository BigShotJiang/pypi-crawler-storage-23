from dataclasses import dataclass

from william.library.hashing import sort_anything
from william.library.precision import recursive_match
from william.utils import pretty


@dataclass(slots=True)
class MapEntry:
    same: bool
    val: object


class NodeValueMap(dict):
    @classmethod
    def from_nodes(cls, nodes, same=True):
        nvmap = cls()
        for node in nodes:
            nvmap[node] = MapEntry(same=same, val=node.val)
        return nvmap

    def copy(self):
        return type(self)(super().copy())

    def __str__(self):
        return "\n".join(
            f"{repr(key):29},  {pretty(key.val.value):26}: same={entry.same:1}, val={pretty(entry.val.value)}"
            for key, entry in self.items()
        )

    def __eq__(self, other):
        if len(self) != len(other):
            return False
        for key, entry in self.items():
            if key not in other:
                return False
            other_entry = other[key]
            if entry.same != other_entry.same:
                return False
            # if entry.val is not other_entry.val:
            #     return False
            if not entry.val.equals(other_entry.val):
                return False
        return True

    def __ne__(self, other):
        return not self.__eq__(other)

    def add(self, val_nodes, values, same=False, op_node=None, skip_existing=False):
        if op_node is not None and (not skip_existing or op_node not in self):
            self[op_node] = MapEntry(same=True, val=op_node.op)
        for node, value in zip(val_nodes, values):
            if skip_existing and node in self:
                continue
            self[node] = MapEntry(same=same, val=value)

    def set(self, node, same, value):
        self[node] = MapEntry(same=same, val=value)

    @property
    def sorted_values(self):
        return sort_anything([self._values(node) for node in self.keys() if not node.is_val_node])

    def _values(self, node):
        return tuple(self[c].val.value for c in node.children), self[node.parent].val.value

    def compatible(self, nodes, values):
        for node, value in zip(nodes, values):
            if node not in self:
                continue
            stored_value = self[node].val
            if stored_value is None or value is None:
                continue
            if recursive_match(stored_value, value) and recursive_match(value, stored_value):
                continue
            return False
        return True
