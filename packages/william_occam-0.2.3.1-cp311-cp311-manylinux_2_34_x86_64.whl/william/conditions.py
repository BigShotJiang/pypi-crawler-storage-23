"""
Compute conditions of a composite, i.e. those inputs that have to be given, in order for the composite operator
to become invertible.
"""

from itertools import chain, product

from william.library.base import Operator
from william.utils import everything


class ConditionCombinations:
    @classmethod
    def get(cls, root, mem=None, allowed=everything, invertible=everything):
        blocked = () if mem is None else tuple(id(n) for n in mem.keys())
        op_nodes = [n for n in root.breadth_first_walk(val_nodes=False) if id(n) not in blocked]
        for cond_comb in cls.cond_combs(op_nodes, blocked=blocked, allowed=allowed, invertible=invertible):
            yield dict(zip(op_nodes, cond_comb))

    @classmethod
    def cond_combs(cls, nodes, comb=(), blocked=(), allowed=everything, invertible=everything):
        if not nodes:
            yield comb
            return
        children = [c for c in nodes[0].children if c in allowed]
        for gen_cond in nodes[0].op.generalized_conditions(arity=len(children), invert=nodes[0] in invertible):
            inf_ids = inferred_nodes(nodes[0].parent, children, gen_cond, blocked)
            if inf_ids is None:
                continue
            yield from cls.cond_combs(
                nodes[1:],
                comb=comb + (gen_cond,),
                blocked=blocked + tuple(inf_ids),
                allowed=allowed,
                invertible=invertible,
            )

    @staticmethod
    def color_from_cond_dict(cond_dict):
        color = {}
        for node, gen_cond in cond_dict.items():
            inf_nodes, cond_nodes = inf_cond_nodes(node.parent, node.children, gen_cond)
            for inf in inf_nodes:
                color[(node, inf)] = '"#ff00ff"'
        return color


def _node_set_hash(nodes):
    return hash(tuple(sorted([id(n) for n in nodes])))


def conditioned_nodes(val_node, blocked=()):
    op_nodes = [n for n in val_node.breadth_first_walk(val_nodes=False) if n not in blocked]
    leaves = set(val_node.leaves())
    seen = set()
    for gen_cond_list in ConditionCombinations.cond_combs(op_nodes, blocked=tuple(blocked)):
        result = set()
        for node, gen_cond in zip(op_nodes, gen_cond_list):
            _, _cond_nodes = inf_cond_nodes(node.parent, node.children, gen_cond)
            result.update(leaves.intersection(_cond_nodes))
        if not result:  # all leaves can be inferred given just the target
            result = [val_node]
        hsh = _node_set_hash(result)
        if hsh in seen:
            continue
        seen.add(hsh)
        yield list(result)


def inferred_nodes(root, leaves, gen_cond, blocked):
    nodes = leaves + [root]
    all_ids = [id(n) for n in nodes]
    cond_ids = tuple(all_ids[i] for i in gen_cond)

    impermeable_ids = tuple(id(n) for n in nodes if not n.output.permeable)
    blocked_ids = blocked + cond_ids + impermeable_ids
    # if idx == -1, it will refer to the root
    indices = [-1] + list(range(len(all_ids) - 1))[::-1]  # go backwards in order not to mess up indices during deletion
    inf_ids = all_ids[:]
    for idx in indices:
        # inferred nodes are all that are not conditioned on
        if idx in gen_cond:
            del inf_ids[idx]
            continue
        # conditioned and blocked nodes should not be inferred into
        if all_ids[idx] in blocked_ids:
            return
    return inf_ids


def inf_cond_nodes(root, leaves, gen_cond):
    inf_nodes = []
    cond_nodes = []
    if -1 in gen_cond:
        cond_nodes.append(root)
    else:
        inf_nodes.append(root)
    for i, child in enumerate(leaves):
        if i in gen_cond:
            cond_nodes.append(child)
        else:
            inf_nodes.append(child)
    return inf_nodes, cond_nodes


def get_conditions_py(val_node, adopt_for_callable=True):
    arity = len(list(val_node.leaves()))
    if not val_node.options:
        return [()]
    raw_conds = tree_conditions_py(val_node.options[0], adopt_for_callable=adopt_for_callable)
    conds = filter_constants_and_repeating(val_node.options[0], arity, raw_conds)
    return filter_redundant(conds, arity)


def filter_constants_and_repeating(root, arity, raw_conds):
    """Given the raw tree_conditions filter out constants and repeating leaves (in DAGs)"""
    conds = []
    for cond in raw_conds:
        conditioned_on = {}
        index = 0
        cond_without_constants = []
        for i, leaf in enumerate(_leaves(root.parent)):
            if leaf in conditioned_on:
                if conditioned_on[leaf] != (i in cond):
                    break
                continue
            conditioned_on[leaf] = i in cond
            if i in cond:
                cond_without_constants.append(index)
            index += 1
        else:
            conds.append(tuple(cond_without_constants))
    if not conds:
        conds = [tuple(range(arity))]
    return conds


def _leaves(val_node):
    """Leaves with repetition."""
    if not val_node.options:
        yield val_node
        return
    for option in val_node.options:
        for child in option.children:
            yield from _leaves(child)


def filter_redundant(conds, arity):
    """Remove redundant conditions e.g. (0,), (1,), (0, 1) -> (0, 1) is redundant.
    Or (0, 2), (0, 1, 2) -> (0, 1, 2) is redundant.
    Sort conditions in ascending order and by length."""
    clone = conds[:]
    conds_filtered = []
    clone.sort(key=lambda x: len(x))
    while clone:
        cond = clone.pop()  # pop the last, i.e. longest cond
        # if any cond_tmp is a subset of cond, don't add cond to the conditions
        for cond_tmp in clone:
            if cond_tmp == () and len(cond) < arity:
                continue
            if all(val in cond for val in cond_tmp):
                break
        else:
            conds_filtered.append(cond)

    conds_filtered.sort()
    conds_filtered.sort(key=lambda x: len(x))
    return conds_filtered


def tree_conditions_py(node, adopt_for_callable=True):
    """
    Given the conditions of the nodes in the composite tree, construct the conditions
    for the whole tree.

    The idea is, given the root node, look at the children and at the conditions of the operator
    of the root node. Suppose, it has two inputs and each of them allows the computation of the
    other. Then, conditions=[(0,), (1,)] have to deduce the conditions of the whole tree underneath.
    If the 0th input has to be given, then all input leaves underneath of the left subtree have to
    be given. The other conditions of the right subtree are taken from the conditions of the right
    input node, which then calls conditions recursively.
    """
    if node.is_leaf:
        return [()]

    node_op_conditions = update_callable_conditions_py(node) if adopt_for_callable else node.op.conditions
    offset = node.offset

    conditions = []
    for cond_comb in node_op_conditions:
        conditions_by_child = []
        for i in range(len(node.children)):
            child = node.children[i]
            if i in cond_comb:
                leaves_count = len(list(_leaves(child)))
                child_conds = [tuple(range(leaves_count))]
            elif not child.options:
                child_conds = [()]
            else:
                child_conds = tree_conditions_py(child.options[0])
            conditions_by_child.append(child_conds)
        combos = condition_combinations_py(conditions_by_child, offset)
        conditions.extend(combos)
    return conditions


def update_callable_conditions_py(node):
    """
    Return conditions of the operator of the root node, unless it is a callable operator like Map or Cumop.
    In that case, the conditions depend on the callable function: compute those conditions.
    """
    conditions = node.op.conditions

    if node.op.has_callable and not node.op.cumulative:
        chop = node.children[0].output.value
        if not isinstance(chop, Operator):
            return ()
        conditions = [(0,) + cond for cond in _add_offset(chop.conditions, 1)]
    return conditions


def condition_combinations_py(conditions_by_child, offset_list):
    """
    For example, conditions_by_child = [[(0, 1), (2,)], [(0,), (1,)]] means that the first child
    of the node has the conditions = [(0, 1), (2)] (read as: if 0th and 1st input are given or if
    the 2nd is given, the other inputs can be inferred if the output is given) and the second child
    has [(0,), (1,)]. The Cartesian product is taken for this list, i.e. results in [(0, 1, 0),
    (0, 1, 1), (2, 0), (2, 1)]. Suppose, offset_list = [0, 4]. Then the result is [(0, 1, 4),
    (0, 1, 5), (2, 4), (2, 5)].
    """
    conditions = []
    for comb in product(*conditions_by_child):
        correct_comb = _add_offset(comb, offset_list)
        conditions.append(tuple(chain.from_iterable(correct_comb)))
    return conditions


def _add_offset(tuple_list, offset_list):
    """For example: tuple_list = [(3, 4), (1,)] and offset_list = [2, 4]. Results in [(5, 6), (5,)]."""
    if not offset_list:
        return tuple_list
    if isinstance(offset_list, int):
        offset_list = [offset_list] * len(tuple_list)
    new_tuple_list = []
    for tup, offset in zip(tuple_list, offset_list):
        new_tuple_list.append(tuple(t + offset for t in tup))
    return new_tuple_list


def remove_redundant_conditions(conditions, contained_in=None):
    """Sort operator conditions by length, remove those that are subsets of others or are not contained in <contained_in>."""
    sorted_conds = sorted(conditions, key=lambda x: len(x))
    for i in range(len(sorted_conds) - 1, -1, -1):
        if any(
            set(sorted_conds[i]).issubset(c) and (contained_in is None or set(c).issubset(contained_in))
            for c in sorted_conds[i + 1 :]
        ):
            del sorted_conds[i]
    return tuple(sorted_conds)
