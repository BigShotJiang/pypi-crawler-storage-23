from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
GRAPHS_PATH = PROJECT_ROOT / "william/graphs"
TMP_PATH = PROJECT_ROOT / "tmp"
