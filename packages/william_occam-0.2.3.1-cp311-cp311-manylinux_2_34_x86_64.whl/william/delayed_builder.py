from collections import namedtuple
from typing import Any

from william.hotloops import glue_leaves
from william.structures import ValueNode
from william.structures.rustgraph import RustGraph

DAGBuildInfo = namedtuple("DAGBuildInfo", ["dl", "root", "leaf_num", "num_in_spec_list"])
DAGBuildInfo.__lt__ = lambda self, other: self.dl < getattr(other, "dl", float("inf"))
DAGBuildInfo.__eq__ = lambda self, other: self.dl == getattr(other, "dl", None)


def delayed_dag_build(
    dag_info: DAGBuildInfo,
    elements_by_spec: dict[Any, list[ValueNode]],
    trees_only: bool,
    max_leaves: int | None,
    seen: set[int],
):
    root_leaves = list(dag_info.root.leaves())
    leaf = root_leaves[dag_info.leaf_num]

    elem, _, _ = elements_by_spec[leaf.output.spec][dag_info.num_in_spec_list]
    new_root, new_elem_leaves, candidates = clone_and_attach(elem, dag_info.root, root_leaves, leaf)

    dag_iter = glue_leaves_py(new_root, new_elem_leaves, candidates, trees_only=trees_only, max_leaves=max_leaves)

    for glued_root in dag_iter:
        glued_leaves = list(glued_root.leaves())
        # leaves_hash = hash(tuple(n.output.spec for n in glued_leaves))
        # hsh = glued_root.equality_hash() + leaves_hash
        # if hsh in seen:
        #     continue
        # seen.add(hsh)
        yield glued_root, glued_leaves


def clone_and_attach(
    elem: ValueNode, root: ValueNode, root_leaves: list[ValueNode], leaf: ValueNode
) -> tuple[ValueNode, list[ValueNode], list[ValueNode]]:
    """
    Clone the element and attach it to the leaf, returning the new inner root,
    the leaves of the new element, and the candidates for gluing.
    """
    new_elem = elem.clone()
    new_elem.output = leaf.output
    new_elem_leaves = list(new_elem.leaves())
    corr = {}
    new_root = root.clone(corr=corr, repl={leaf: new_elem}, copy=True)
    candidates = [corr[n] for n in root_leaves if n is not leaf]
    return new_root, new_elem_leaves, candidates


def glue_leaves_py(
    root: ValueNode,
    leaves: list[ValueNode],
    candidates: list[ValueNode],
    seen: set[int] | None = None,
    trees_only: bool = False,
    max_leaves: int | None = None,
):
    """
    Recursively glue leaves to candidates, yielding all combinations.
    """
    if trees_only:
        if max_leaves is None or len(leaves) <= max_leaves:
            yield root
        return

    if seen is None:
        seen = set()

    if max_leaves is None or len(leaves) <= max_leaves:
        hsh = hash(tuple(root.connections()))
        if hsh not in seen:
            yield root
            seen.add(hsh)

    if not leaves:
        return
    found = False
    while not found and leaves:
        first, *rest = leaves
        for c in rest + candidates:
            if c.output.spec != first.output.spec:
                continue
            found = True
            corr = {}
            new_root = root.clone(corr=corr)
            corr[c].merge(corr[first])
            new_rest = [corr[n] for n in rest]
            new_candidates = [corr[n] for n in candidates]
            yield from glue_leaves_py(new_root, new_rest, new_candidates, seen=seen)
        leaves = rest


def speedy_delayed_dag_build(
    dag_info,
    elements_by_spec: dict[int, list[tuple["RustGraph", float, int]]],
    trees_only: bool,
    max_leaves: int | None,
    seen: set[int],
):
    """
    Build the next DAG expansion step by attaching one element
    (in RustGraph form) to the current root RustGraph.

    Args:
        dag_info: DAGBuildInfo containing (dl, root, leaf_num, num_in_spec_list)
                  where root is now a RustGraph.
        elements_by_spec: mapping type_id -> list of (RustGraph, eff_len, count)
        trees_only: (ignored for now)
        max_leaves: (ignored for now)
        seen: set of previously seen DAG hashes (to prevent duplicates)

    Yields:
        (new_root_graph, new_elem_leaves)
    """
    # collect current leaves
    root_leaves = dag_info.root.leaves()
    leaf_id = root_leaves[dag_info.leaf_num]

    # --- Select the element to attach -----------------------------------
    # elements_by_spec uses type_id as key
    leaf_payload = dag_info.root.get_value_payload(leaf_id)
    if leaf_payload is None:
        raise ValueError("Payload in rust graph node missing.")
    _, type_id = leaf_payload

    elem_graph, _, _ = elements_by_spec[type_id][dag_info.num_in_spec_list]

    # --- Attach the element via Rust clone_and_attach -------------------
    new_root_graph, new_elem_leaves, _candidates = dag_info.root.clone_and_attach(elem_graph, leaf_id)

    dag_iter = glue_leaves(new_root_graph, new_elem_leaves, _candidates, trees_only=trees_only, max_leaves=max_leaves)

    for glued_root in dag_iter:
        glued_leaves = glued_root.leaves()
        # use simple tuple of type_ids as hash key
        # leaves_type_ids = tuple(glued_root.get_value_payload(n)[1] for n in glued_leaves)
        # hsh = hash(leaves_type_ids)
        # if hsh in seen:
        #     return
        # seen.add(hsh)
        yield glued_root, glued_leaves
