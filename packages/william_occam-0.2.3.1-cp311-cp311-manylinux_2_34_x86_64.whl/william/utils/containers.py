"""Flexible container types extending inbuilt collections."""

from copy import deepcopy
from dataclasses import dataclass, field
from heapq import heapify, heappop, heappush
from queue import Empty, Full
from typing import Any


class FancyIndexingList(list):
    def __getitem__(self, index):
        if isinstance(index, tuple | list):
            return [self[i] for i in index]
        else:
            return super().__getitem__(index)

    def __setitem__(self, index, item):
        if isinstance(index, tuple | list):
            for i, c in zip(index, item):
                self[i] = c
        else:
            super().__setitem__(index, item)


class UniqueList(list):
    """Maintain a list with unique values, i.e. an ordered set.
    Caution: The runtime is not optimized for frequent inserts."""

    def __init__(self, *args, skip_existing=False):
        super().__init__()
        self.skip_existing = skip_existing
        if args:
            if len(args) != 1:
                raise TypeError(f"UniqueList() takes at most 1 argument ({len(args)} given)")
            for v in args[0]:
                self.append(v)

    def append(self, val):
        if val in self:
            if self.skip_existing:
                return
            raise ValueError(f"Duplicated item: {val}")
        list.append(self, val)

    def extend(self, values):
        for val in values:
            self.add(val)

    def __setitem__(self, i, val):
        if val in self:
            raise ValueError(f"Duplicated item: {val}")
        list.__setitem__(self, i, val)

    def add(self, val):
        """Add a value to the list, if it's not already contained.\
         Don't raise an error if the item is already found."""
        if val not in self:
            super().append(val)

    def copy(self):
        return UniqueList(super().copy())

    def union(self, values):
        x = self.copy()
        x.extend(values)
        return x

    def intersection(self, values):
        x = self.copy()
        for v in x[:]:
            if v not in values:
                x.remove(v)
        return x

    def discard(self, value):
        if value in self:
            self.remove(value)

    def remove_elements(self, values):
        for val in values:
            if val in self:
                self.remove(val)


class Everything:
    def __contains__(self, item):
        return True

    def __getitem__(self, item):
        return item


class EverythingButThis:
    def __init__(self, skip: list[Any]):
        self.skip = skip

    def __contains__(self, item):
        return item not in self.skip

    def __getitem__(self, item):
        return item


everything = Everything()


@dataclass(order=True)
class PrioritizedItem:
    priority: int | float
    item: Any = field(compare=False)


class UniquePrioHeapQueue:
    """Single-threaded heap implementation for batch operations."""

    def __init__(self, maxsize=None, key=lambda x: x, hash=hash, auto_truncate=False):
        self._key_func = key
        self._hash_func = hash
        self._maxsize = maxsize
        self._auto_truncate = auto_truncate
        self._heap = []
        self._seen = set()
        self._min_truncated_priority = 1e15

    def put(self, items):
        if not isinstance(items, list):
            items = [items]

        for item in items:
            item_hash = self._hash_func(item)
            if item_hash not in self._seen:
                self._put_truncate(item)
                self._seen.add(item_hash)

    def _put_truncate(self, item):
        if self._maxsize and len(self) >= self._maxsize:
            if self._auto_truncate:
                self.truncate(int(0.5 * self._maxsize))
            else:
                raise Full(
                    "Priority queue has reached maximum capacity. Can not put more items into it. "
                    "Consider increasing <hq_size>."
                )
        heappush(self._heap, PrioritizedItem(self._key_func(item), item))

    def get(self, item_count=None):
        if item_count is None:
            try:
                return self._pop()
            except IndexError:
                raise Empty

        if item_count < 1:
            raise ValueError("item_count must be a positive integer")
        item_count_available = min(item_count, len(self._heap))
        if item_count_available == 0:
            raise Empty
        return [self._pop() for _ in range(item_count_available)]

    def _pop(self):
        item = heappop(self._heap)
        if item.priority >= self._min_truncated_priority:
            raise RuntimeError(
                """
                Trying to pop item from the heap whose priority is worse than some of the previously truncated items.
                Thus, too much has been truncated. Consider increasing <hq_size>, set it to None, and/or 
                disable auto_truncate.
                """
            )
        return item.item

    def truncate(self, n=None):
        """Trim the heap size down to maxsize."""
        sorted_heap = sorted(self._heap)
        n = n or self._maxsize
        self._min_truncated_priority = min(self._min_truncated_priority, min(sorted_heap[n:]).priority)
        new_heap = sorted_heap[:n]
        heapify(new_heap)
        self._heap = new_heap

    def __bool__(self):
        return bool(self._heap)

    def __len__(self):
        return len(self._heap)

    def clear(self):
        self._heap.clear()

    def __iter__(self):
        while self:
            yield self.get()


class TwoWayDict:
    """Cached two-way dictionary"""

    __slots__ = "_data", "_inv"

    def __init__(self, *args, **kwargs):
        self._data = dict(*args, **kwargs)
        self._inv = None

    def __setitem__(self, key, value):
        self._data[key] = value
        if self._inv is not None:
            self._inv[value] = key

    def __getitem__(self, key):
        return self._data[key]

    def __delitem__(self, key):
        val = self._data.pop(key)
        if self._inv is not None and self._inv[val] is key:
            del self._inv[val]

    def __contains__(self, key):
        return key in self._data

    def __iter__(self):
        return self._data.__iter__()

    def __len__(self):
        return self._data.__len__()

    def keys(self):
        return self._data.keys()

    def values(self):
        return self._data.values()

    def items(self):
        return self._data.items()

    def get(self, key, default=None):
        return self._data.get(key, default)

    def pop(self, key, *args):
        found = key in self._data
        ret = self._data.pop(key, *args)
        if found and self._inv:
            del self._inv[ret]
        return ret

    def __getstate__(self):
        return self._data

    def __setstate__(self, state):
        self._data = state
        self._inv = None

    def clear(self):
        self._data.clear()
        self._inv = None

    @property
    def inv(self):
        if self._inv is None:
            self._inv = dict((n2, n1) for n1, n2 in self._data.items())
        return self._inv

    def get_inv(self, key, default=None):
        return self.inv.get(key, default)

    def add(self, other):
        new_corr = TwoWayDict()
        for org_node, node in self._data.items():
            new_corr[org_node] = other[node]
        return new_corr

    def crop(self, keys):
        """Restrict keys to given keys."""
        for key in list(self._data.keys()):
            if key not in keys:
                del self[key]


class AttrDict(dict):
    """Syntax candy"""

    __setattr__ = dict.__setitem__

    def __getattr__(self, attr):
        try:
            return self[attr]
        except KeyError:
            raise AttributeError(attr)

    def __delattr__(self, attr):
        try:
            del self[attr]
        except KeyError:
            raise AttributeError(attr)

    def copy(self):
        """Copy instance, preserving type"""
        # Unfortunately, it's about a magnitude slower than dict.copy()
        return type(self)(self)

    def __deepcopy__(self, memo):
        return type(self)(deepcopy(dict(self), memo))

    def __getstate__(self):
        return dict(self)

    def __setstate__(self, d):
        self.update(d)


class CustomCycle:
    """Custom cycle class that allows for removal of elements during iteration."""

    def __init__(self, lst, cycle_enabled=True):
        self.lst = lst
        self._counter = 0
        self.cycle_enabled = cycle_enabled

    def run(self, max_iterations=None):
        iter_num = 0
        while self.lst:
            item = self.lst[self._counter]
            yield item
            self._counter += 1
            if self._counter >= len(self.lst):
                self._counter = 0
                if not self.cycle_enabled:
                    break
                iter_num += 1
            if max_iterations is not None and iter_num == max_iterations:
                break

    def remove(self, item):
        index = self.lst.index(item)
        del self.lst[index]
        if index <= self._counter:
            self._counter -= 1

    @property
    def current_item(self):
        return self.lst[self._counter]

    def __str__(self):
        s = f"Number of generators: {len(self.lst)}\n"
        s += f"Current num: {self._counter}\n"
        return s
