import pdb
import sys
import traceback


class MultiprocessPdb(pdb.Pdb):
    """
    A Pdb subclass that may be used
    from a forked multiprocessing child.

    Usage:
    MultiprocessPdb().set_trace()

    For details and discussion see:
    https://stackoverflow.com/questions/4716533/how-to-attach-debugger-to-a-python-subproccess
    """

    def interaction(self, *args, **kwargs):
        _stdin = sys.stdin
        try:
            with open("/dev/stdin") as stdin:
                sys.stdin = stdin
                pdb.Pdb.interaction(self, *args, **kwargs)
        finally:
            sys.stdin = _stdin

    def post_mortem(self, t=None):
        # handling the default
        if t is None:
            # sys.exc_info() returns (type, value, traceback) if an exception is
            # being handled, otherwise it returns None
            t = sys.exc_info()[2]
        if t is None:
            raise ValueError("A valid traceback must be passed if no exception is being handled")
        traceback.print_tb(t)
        self.reset()
        self.interaction(None, t)
