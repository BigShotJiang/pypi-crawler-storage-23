# Requirements for functions and classes to be in utils:
# - functionality is so generic, that it might easily be reusable in another context
# - functionality is used more than once within this package, so that importing might get difficult
from william.utils.containers import (
    Everything,
    FancyIndexingList,
    TwoWayDict,
    UniqueList,
    UniquePrioHeapQueue,
    everything,
)
from william.utils.helpers import (
    DEBUG,
    ERROR,
    INFO,
    NOTSET,
    WARNING,
    debug,
    debugger,
    dispdots,
    get_path,
    ignore_errors,
    memory_usage,
    pretty,
    remove_occurrences,
    replace_occurrences,
    seen_already,
    set_trace_up,
    stop,
    unique,
)

MAX_EXPONENT = 30
MAX_LIST_LEN = 10000
MAX_ARRAY_LEN = 10000000
MAX_INT = 2**31 - 1
