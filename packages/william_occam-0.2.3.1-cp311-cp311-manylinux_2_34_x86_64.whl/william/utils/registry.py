import itertools
from typing import Any


class RegistryBundle:
    """Container that holds all registries (values, operators, specs) for the Python→Rust bridge."""

    def __init__(self):
        self.values = Registry("Value")
        self.operators = Registry("Operator")
        self.specs = Registry("Spec")

    # --- convenience shortcuts ------------------------------------------------

    # Value
    def value_id(self, obj: Any) -> int:
        return self.values.get_id(obj)

    def value(self, id_: int) -> Any:
        return self.values.get_obj(id_)

    # Operator
    def op_id(self, obj: Any) -> int:
        return self.operators.get_id(obj)

    def op(self, id_: int) -> Any:
        return self.operators.get_obj(id_)

    # Spec / Type
    def spec_id(self, obj: Any) -> int:
        return self.specs.get_id(obj)

    def spec(self, id_: int) -> Any:
        return self.specs.get_obj(id_)

    # --- utils ---------------------------------------------------------------

    def clear(self):
        """Clear all registries."""
        self.values.clear()
        self.operators.clear()
        self.specs.clear()

    def __repr__(self):
        return f"<RegistryBundle Values={len(self.values)}, Operators={len(self.operators)}, Specs={len(self.specs)}>"

    def __str__(self):
        s = "\n"
        s += str(self.values)
        s += str(self.operators)
        s += str(self.specs)
        return s


class Registry:
    """Bidirectional registry mapping Python objects to numeric IDs.

    This registry assigns a small integer ID to objects and keeps both
    directions of the mapping (id -> object and object -> id).
    """

    _counter = itertools.count(0)

    def __init__(self, name: str):
        self.name = name
        # id -> obj (strong)
        self._id_to_obj: dict[int, object] = {}
        # obj -> id (strong)
        self._obj_to_id: dict[object, int] = {}
        # weakref.WeakKeyDictionary[object, int] = weakref.WeakKeyDictionary()
        # flat snapshot for Rust:
        self._snapshot: dict[int, dict[str, object]] = {}

    def register(self, obj) -> int:
        """Register the object if not already present and return its numeric ID."""
        if obj in self._obj_to_id:
            return self._obj_to_id[obj]
        new_id = next(self._counter)
        self._id_to_obj[new_id] = obj
        self._obj_to_id[obj] = new_id
        # snapshot gleich aktualisieren
        self._snapshot[new_id] = self._extract_for_rust(obj)
        return new_id

    def _extract_for_rust(self, obj) -> dict[str, object]:
        """Extract relevant fields for operators (conditions, has_callable, cumulative)."""
        return {
            "name": getattr(obj, "name", str(obj)),
            "conditions": getattr(obj, "conditions", ()),
            "has_callable": getattr(obj, "has_callable", False),
            "cumulative": getattr(obj, "cumulative", False),
        }

    def get_rust_snapshot(self) -> dict[int, dict[str, object]]:
        """Liefert den Snapshot aller Operatoren für Rust."""
        return self._snapshot

    def get_id(self, obj) -> int:
        """Return an existing ID for `obj`, registering it if necessary."""
        return self.register(obj)

    def get_obj(self, id_: int):
        """Return the object registered under `id_`, or None if not found."""
        return self._id_to_obj.get(id_)

    def __getitem__(self, id_: int):
        return self._id_to_obj[id_]

    def __contains__(self, obj):
        return obj in self._obj_to_id

    def id(self, obj) -> int:
        """Like `get_id`, but raise KeyError if `obj` is not registered."""
        if obj not in self._obj_to_id:
            raise KeyError(f"{self.name} object not registered: {obj}")
        return self._obj_to_id[obj]

    def __len__(self):
        return len(self._id_to_obj)

    def clear(self):
        self._id_to_obj.clear()
        self._obj_to_id.clear()
        self._snapshot.clear()

    def __repr__(self):
        return f"<Registry {self.name}: {len(self)} entries>"

    def __str__(self):
        s = f"Registry {self.name} contents:\n"
        for id_, obj in self._id_to_obj.items():
            s += f"  ID {id_}: {obj}\n"
        return s
