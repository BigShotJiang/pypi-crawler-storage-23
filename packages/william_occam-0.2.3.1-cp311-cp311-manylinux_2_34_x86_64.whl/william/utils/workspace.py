import threading
from collections import defaultdict

import numpy as np

from william.utils import MAX_ARRAY_LEN


class ArrayPool:
    """
    Pool keyed by (shape, dtype); keeps stacks with multiple buffers per key.

    Usage:
        buf = pool.get(shape, dtype)
        ... fill/use buf ...
        pool.release(buf)

    Optional: provide a context manager per propagation to safely release all buffers at the end.
    """

    def __init__(self):
        self._free = defaultdict(list)  # key -> [buffers]
        self._in_use = set()  # Debug/Optional

    def key(self, shape, dtype):
        return (tuple(shape), np.dtype(dtype).str)

    def get(self, shape, dtype=float, zero=False):
        k = self.key(shape, dtype)
        if self._free[k]:
            buf = self._free[k].pop()
        else:
            buf = np.empty(shape, dtype=dtype)
        self._in_use.add(id(buf))
        if zero:
            buf.fill(0)
        return buf

    def like(self, arr, zero=False):
        return self.get(arr.shape, arr.dtype, zero=zero)

    def release(self, *bufs):
        for buf in bufs:
            if buf is None:
                continue
            # Safety: avoid accidentally releasing the same buffer multiple times
            if id(buf) in self._in_use:
                self._in_use.remove(id(buf))
                k = self.key(buf.shape, buf.dtype)
                self._free[k].append(buf)

    def clear(self):
        self._free.clear()
        self._in_use.clear()


class Workspace:
    """Convenience helper: releases all temporary buffers when finished."""

    __slots__ = ("pool", "hold")

    def __init__(self, pool: ArrayPool):
        self.pool = pool
        self.hold = []

    def tmp(self, shape=None, dtype=None, like=None, zero=False):
        if like is not None:
            buf = self.pool.like(like, zero=zero)
        else:
            if np.prod(shape) > MAX_ARRAY_LEN:
                raise ValueError(f"Requested array size {np.prod(shape)} exceeds MAX_ARRAY_LEN {MAX_ARRAY_LEN}")
            buf = self.pool.get(shape, dtype, zero=zero)
        self.hold.append(buf)
        return buf

    def release_all(self):
        self.pool.release(*self.hold)
        self.hold.clear()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.release_all()


_thread_local = threading.local()
GLOBAL_POOL = ArrayPool()


def get_workspace() -> Workspace:
    ws = getattr(_thread_local, "workspace", None)
    if ws is None:
        ws = Workspace(GLOBAL_POOL)
        _thread_local.workspace = ws
    return ws


def set_workspace(ws: Workspace | None):
    _thread_local.workspace = ws
