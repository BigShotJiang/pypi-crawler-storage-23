from queue import Full

import pytest

from william.utils.containers import CustomCycle, TwoWayDict, UniquePrioHeapQueue


def test_unique_prio_queue(maxsize=100):
    hq = UniquePrioHeapQueue(maxsize=maxsize)
    hq.put([10, 3, 22, 13, 0, 1, 11, 9, 11, 3, 0, 2, 2, 2, 3, 10])
    assert hq.get(item_count=10) == [0, 1, 2, 3, 9, 10, 11, 13, 22]

    with pytest.raises(Full):
        hq.put(list(range(1000)))

    hq = UniquePrioHeapQueue(maxsize=maxsize, auto_truncate=True)
    hq.put(list(range(1000)))
    assert len(hq) <= maxsize


def test_two_way_dict():
    twd = TwoWayDict()
    assert len(twd) == 0

    twd = TwoWayDict({10: 20, 20: 30})
    assert len(twd) == 2

    twd = TwoWayDict(bla=5, blub=10, blubber=20)
    assert len(twd) == 3
    assert twd["bla"] == 5
    assert twd.get("blub") == 10
    assert twd.get("asdf", 11) == 11
    assert "bla" in twd
    assert "blobber" not in twd

    assert twd.get_inv(5) == "bla"
    assert twd.inv == {5: "bla", 10: "blub", 20: "blubber"}

    assert list(twd) == ["bla", "blub", "blubber"]
    assert list(twd.inv) == [5, 10, 20]

    assert twd.pop("bla") == 5
    assert len(twd) == 2
    assert "bla" not in twd
    assert 5 not in twd.inv
    assert twd.pop("asdf", 11) == 11


def test_custom_cycle():
    gens = [range(0, 3), ["a", "b", "c", "d"], range(20, 22)]
    gen1, gen2 = gens[0], gens[2]
    cyc = CustomCycle(gens)

    res = []
    for k, gen in enumerate(cyc.run(max_iterations=5)):
        for z in gen:
            res.append((k, z))
            if k == 2 and len(cyc.lst) == 3:
                cyc.remove(gen1)
        if k == 4:
            cyc.remove(gen2)

    assert res == [
        (0, 0),
        (0, 1),
        (0, 2),
        (1, "a"),
        (1, "b"),
        (1, "c"),
        (1, "d"),
        (2, 20),
        (2, 21),
        (3, "a"),
        (3, "b"),
        (3, "c"),
        (3, "d"),
        (4, 20),
        (4, 21),
        (5, "a"),
        (5, "b"),
        (5, "c"),
        (5, "d"),
        (6, "a"),
        (6, "b"),
        (6, "c"),
        (6, "d"),
        (7, "a"),
        (7, "b"),
        (7, "c"),
        (7, "d"),
    ]
