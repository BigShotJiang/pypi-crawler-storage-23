import numpy as np
import pytest

from william.utils.helpers import ignore_errors, nested_for, pretty


def clumsy_nested_for(f, x0):
    for x1 in f[0](x0):
        for x2 in f[1](x1):
            yield from f[2](x2)


def test_fancy_nesting():
    def f0(s):
        yield s + 1
        yield s + 2

    def f1(s):
        yield s - 2
        yield s - 4

    def f2(s):
        yield s * 2
        yield s * 3
        yield s * 4

    f = [f0, f1, f2]
    x0 = 5
    correct = [8, 12, 16, 4, 6, 8, 10, 15, 20, 6, 9, 12]
    assert list(clumsy_nested_for(f, x0)) == correct
    assert list(nested_for(f, x0)) == correct

    # test empty generator
    def f1(s):
        return
        yield

    f = [f0, f1, f2]
    assert list(nested_for(f, x0)) == [12, 18, 24, 14, 21, 28]


params = [
    (45, True, "45"),
    (np.array([6, 7, 8, 9, 10, 11]), True, "a[6,7,..,11]"),
    ([1, 2, 3], True, "[1,2,3]"),
    ([1, 2, 3, 4], True, "[1,2,..,4]"),
    ([1, 2, 3, 4], False, "[1,2,3,4]"),
    ([[1, 2, 3, 4], [5, 6, 7, 8]], True, "[[1,2,..,4],[5,6,..,8]]"),
    ([[1, 2, 3, 4], [5, 6, 7, 8]], False, "[[1,2,3,4],[5,6,7,8]]"),
    ((np.arange(8), [7, 1, 3, 4, 6, 9]), True, "(a[0,1,..,7],[7,1,..,9])"),
]


@pytest.mark.parametrize("value, abbrev, expected", params)
def test_pretty(value, abbrev, expected):
    assert pretty(value, abbrev=abbrev) == expected


def test_ignore_errors():
    @ignore_errors(ZeroDivisionError)
    def bla(x):
        """asdf"""
        return 1 / x

    assert bla(0) is None
    assert bla(1) == 1
    assert bla.__name__ == "bla"
    assert bla.__doc__ == "asdf"

    with pytest.raises(TypeError):
        bla("asdf")

    @ignore_errors(ZeroDivisionError)
    def bla_gen(x):
        yield 1 / x
        yield 3

    assert list(bla_gen(0)) == []
    assert list(bla_gen(1)) == [1, 3]
