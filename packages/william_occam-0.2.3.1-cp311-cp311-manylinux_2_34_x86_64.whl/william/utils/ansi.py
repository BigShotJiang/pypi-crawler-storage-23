"""ANSI colors taken from https://github.com/tartley/colorama/blob/master/colorama/ansi.py"""


def compute_ansi_sequence(*attributes: int) -> str:
    """Combines multiple ANSI attributes into a single escape sequence."""
    payload = ";".join(str(attribute) for attribute in attributes)
    return f"\033[{payload}m"


RESET = compute_ansi_sequence(0)
BOLD = compute_ansi_sequence(1)

# fmt: off
(
    BLACK,
    RED,
    GREEN,
    YELLOW,
    BLUE,
    MAGENTA,
    CYAN,
    WHITE,
) = (compute_ansi_sequence(c) for c in range(30, 38))
(
    BRIGHT_BLACK,
    BRIGHT_RED,
    BRIGHT_GREEN,
    BRIGHT_YELLOW,
    BRIGHT_BLUE,
    BRIGHT_MAGENTA,
    BRIGHT_CYAN,
    BRIGHT_WHITE,
) = (compute_ansi_sequence(c, 1) for c in range(30, 38))
(
    LIGHT_BLACK,
    LIGHT_RED,
    LIGHT_GREEN,
    LIGHT_YELLOW,
    LIGHT_BLUE,
    LIGHT_MAGENTA,
    LIGHT_CYAN,
    LIGHT_WHITE,
) = (compute_ansi_sequence(c) for c in range(90, 98))

# backgrounds

(
    B_BLACK,
    B_RED,
    B_GREEN,
    B_YELLOW,
    B_BLUE,
    B_MAGENTA,
    B_CYAN,
    B_WHITE,
) = (compute_ansi_sequence(c) for c in range(40, 48))
(
    B_LIGHT_BLACK,
    B_LIGHT_RED,
    B_LIGHT_GREEN,
    B_LIGHT_YELLOW,
    B_LIGHT_BLUE,
    B_LIGHT_MAGENTA,
    B_LIGHT_CYAN,
    B_LIGHT_WHITE,
) = (compute_ansi_sequence(c) for c in range(100, 108))
# fmt: on
