"""Various small helpers depending only on builtins."""

import os
import sys
from functools import wraps
from inspect import isgeneratorfunction
from logging import DEBUG, ERROR, INFO, NOTSET, WARNING
from pathlib import Path
from typing import Any

import numpy as np

from william.utils import ansi

try:
    from ipdb import set_trace
except ImportError:
    import pdb

    set_trace = pdb.Pdb().set_trace

level = int(os.environ.get("WILLIAM_DEBUG", "0"))


def seen_already(item, seen, key=hash):
    item_hash = key(item)
    if item_hash in seen:
        return True
    seen.add(item_hash)
    return False


def dispdots(r, n, char=".", dots_per_line=10):
    """Displays some "I am doing something" dots"""
    if r == 0:
        return
    if r % n == 0:
        print(char, end="")
        sys.stdout.flush()
    if r % (dots_per_line * n) == 0:
        print(r)


def ignore_errors(errors):
    if level >= 10:
        return lambda f: f

    def decorate(func):
        if isgeneratorfunction(func):

            @wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    yield from func(*args, **kwargs)
                except errors:
                    return

            return wrapper
        else:

            @wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except errors:
                    return

            return wrapper

    return decorate


def heat_map(value):
    # convert a number between 0 and 1 to an rgb value corresponding to a heat map between blue and red
    # 0 is blue, 0.5 is green, 1 is red
    # https://stackoverflow.com/questions/20792445/calculate-rgb-value-for-a-range-of-values-to-create-heat-map
    ratio = 2 * value  # (value-minimum) / (maximum - minimum)
    b = int(max(0, 255 * (1 - ratio)))
    r = int(max(0, 255 * (ratio - 1)))
    g = 255 - b - r

    # Convert RGB values to hexadecimal color code
    hex_color = f"#{r:02x}{g:02x}{b:02x}"
    return hex_color


def stop(level, threshold=3):
    if level >= threshold:
        set_trace_up(levels=2)


def debug(message, level=NOTSET, render=None):
    if render and level >= INFO:
        if not isinstance(render, list | tuple):
            render = [render]
        for item in render:
            item.render()
    if level >= ERROR:
        print(f"{ansi.RED}ERROR: {message}{ansi.RESET}")
        set_trace_up(levels=2)
    elif level >= WARNING:
        print(f"{ansi.YELLOW}WARNING: {message}{ansi.RESET}")
    elif level >= INFO:
        print(f"INFO: {message}")
    elif level >= DEBUG:
        print(f"{ansi.BLUE}DEBUG: {message}{ansi.RESET}")


def debugger(level, strings, halt=False, color="white", logger=None):
    smaller_levels = [lev for lev in strings.keys() if lev <= level]
    if not smaller_levels:
        return
    s = strings[max(smaller_levels)]
    if logger:
        logger.info(s)
    else:
        col = getattr(ansi, color.upper())
        print(col + s + ansi.RESET)
    if halt:
        set_trace_up(levels=2)


def set_trace_up(levels: int = 1) -> None:
    """
    Enter debugger if WILLIAM_DEBUG is set in the environment.

    By default jumps `levels` frames up so the stop is at the
    interesting caller, not inside debug_stop() itself.
    """
    frame = sys._getframe().f_back
    for _ in range(levels - 1):
        if frame.f_back is None:
            break
        frame = frame.f_back
    if os.environ.get("WILLIAM_DEBUG"):
        set_trace(frame)


def replace_occurrences(lst: list[Any], a, b, nums=None) -> tuple[int, ...]:
    """Replace all occurrences of element a in list with b"""
    indices = []
    for i, elem in enumerate(lst):
        if nums is not None and i not in nums:
            continue
        if elem is a:
            lst[i] = b
            indices.append(i)
    return tuple(indices)


def remove_occurrences(lst: list[Any], target) -> None:
    lst[:] = [item for item in lst if item is not target]


def replace_items(corr, *items):
    replaced_items = []
    for item in items:
        if isinstance(item, list):
            replaced_item = [corr[i] for i in item]
        elif isinstance(item, set):
            replaced_item = set(item)
            for i in list(replaced_item):  # Convert the set to a list to be able to iterate through it
                replaced_item.update({corr[i]})
                replaced_item.remove(i)
        else:
            raise TypeError("All items must be lists or sets")
        replaced_items.append(replaced_item)
    return replaced_items


def nested_for(gens, x):
    """
    Creates a nested loop of arbitrary depth, where the number of loops is equal to
    the length of the list of functions and the loop variable in each loop is
    determined by the result of calling the corresponding function in the list with
    the loop variable from the previous loop as the argument.

    Parameters:
        gens: a list of functions
        x: an input value

    Yields:
        The loop variable at each level of the nested loop
    """
    return _nested_for(gens, x, len(gens))


def _nested_for(gens, x, depth):
    if depth == 0:
        yield x
        return
    ys = list(gens[-depth](x)) or [x]
    for y in ys:
        yield from _nested_for(gens, y, depth - 1)


def memory_usage():
    try:
        from psutil import Process
    except ImportError:
        import resource

        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    else:
        process = Process(os.getpid())
        return process.memory_info().rss / 1024**2  # returns megabytes


def _brackets(x, abbrev):
    if not abbrev and isinstance(x, np.ndarray):
        return "array([", "])"
    br_open = {list: "[", tuple: "(", set: "{", np.ndarray: "a["}
    br_close = {list: "]", tuple: ")", set: "}", np.ndarray: "]"}
    typ = list if isinstance(x, list) else type(x)
    return br_open[typ], br_close[typ]


def pretty(x, abbrev=True, threshold=3):
    """Make value x pretty for printing (I don't like the prettyprint library)."""
    if isinstance(x, tuple | list | set | np.ndarray):
        if isinstance(x, np.ndarray) and len(x.shape) >= 3:
            threshold = 2
        lx = sorted(x) if isinstance(x, set) else list(x)
        br_open, br_close = _brackets(x, abbrev)
        if abbrev and len(x) > threshold:
            s = pretty(lx[0], abbrev=abbrev, threshold=threshold)
            if len(s) < 10:
                s += "," + ",".join(pretty(v, abbrev=abbrev, threshold=threshold) for v in lx[1 : threshold - 1])
                s += ",..," + pretty(lx[-1], abbrev=abbrev, threshold=threshold)
            else:
                s += ",.."
        else:
            s = ",".join(pretty(v, abbrev=abbrev, threshold=threshold) for v in lx)
        return br_open + s + br_close
    if isinstance(x, str):
        if abbrev and len(x) > threshold:
            return "'" + x[: threshold - 1] + "..." + x[-1] + "'"
        else:
            return "'" + x + "'"
    if isinstance(x, float) or isinstance(x, np.floating):
        return np.format_float_positional(x, trim="-", precision=10)
    return str(x)


def unique(lst: list[Any]) -> list[Any]:
    """Convert list to another list with non-repeating elements, while preserving order."""
    return list(dict.fromkeys(lst))


def get_path(
    filename: Path | str, root: Path | str | None = None, suffix: str | None = None, mkdir: bool = False
) -> Path:
    fpath = Path(filename) if not isinstance(filename, Path) else filename
    if suffix and not fpath.name.endswith(suffix):
        fpath = fpath.with_suffix(suffix)
    if root and not fpath.is_absolute():
        fpath = Path(root) / fpath
    if mkdir:
        fpath.parent.mkdir(exist_ok=True, parents=True)
    return fpath
