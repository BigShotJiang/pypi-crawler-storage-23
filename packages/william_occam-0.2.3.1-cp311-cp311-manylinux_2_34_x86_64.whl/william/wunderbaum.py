import os
from collections import defaultdict
from heapq import heappop, heappush
from time import time
from typing import Any

import numpy as np

from william.bottleneck import cross_sections, trace_comb_bottleneck
from william.composite import Composite
from william.conditions import get_conditions_py
from william.dag_enumerator import DAGItem, InputsEnumerator, eff_len_from_count
from william.delayed_builder import DAGBuildInfo, delayed_dag_build, speedy_delayed_dag_build
from william.discrete_optimizer import AdaptiveOptimizer
from william.hotloops import RustGraph, get_conditions
from william.input_enumerator import BufferedIterator
from william.library.base import Operator, Value
from william.library.description import jelias
from william.library.hashing import unique_hash
from william.library.types import concretize_specs, float_like, int_like
from william.nvmap import MapEntry, NodeValueMap
from william.propagation import RandomPropagation
from william.structures.graphs import Graph
from william.structures.nodes import graph_element
from william.structures.rustgraph import build_rust_graph_from_root, rustgraph_element
from william.structures.value_nodes import ValueNode
from william.utils import ansi
from william.utils.helpers import debugger, memory_usage, set_trace_up
from william.utils.registry import RegistryBundle
from william.utils.workspace import get_workspace

ws = get_workspace()


class DAGCondInputsItem(DAGItem):
    def __init__(self, root: ValueNode, eff_len: float, cond_inputs_gen: BufferedIterator, cond: tuple[int]):
        self.root = root
        self._leaves = list(root.leaves())
        self._dl = eff_len
        self.cond = cond

        self._cond_inputs_gen = cond_inputs_gen
        self._iter_num = 0
        self._add_dl = 0

    def __hash__(self):
        return unique_hash((type(self), self.root.connection_hash, self.dl, self.cond))

    @property
    def leaves(self):
        return self._leaves

    def try_inputs_and_invert(
        self, prop_class: RandomPropagation, target: Value, verbose: bool = False, debug: bool = False
    ) -> tuple[float, NodeValueMap, bool]:
        res_params = ({}, None)
        try:
            _, cond_inputs = self._cond_inputs_gen[self._iter_num]
            self._iter_num += 1
            self._add_dl = jelias(self._iter_num)
            if verbose or debug:
                print(f"Trying cond inputs {repr(cond_inputs)} with iter num {self._iter_num} (DL {self._add_dl:.2f})")
            if debug:
                self.render(view=False)
                set_trace_up()
        except IndexError:
            # generator exhausted, nothing found
            self._cond_inputs_gen = None
            keep_trying = False
            return None, res_params, keep_trying

        # try to invert with these cond inputs
        residual_dl, res_params = self.invert_and_get_best_mem(prop_class, target, self.cond, cond_inputs)
        res_mem = res_params[0]

        if debug:
            self.render(res_mem, view=False)
            set_trace_up()

        if res_mem:
            min_dl, min_params, _ = self.try_to_optimize(
                prop_class, target, np.array(cond_inputs), residual_dl, res_params
            )
            if debug:
                self.render(min_params[0], view=False)
                set_trace_up()
            # release temporary buffers
            # TODO: buffer release deactivated, since it conflicts with propagation caching
            # ws.release_all()
            keep_trying = True
            return min_dl, min_params, keep_trying

        if verbose and not res_mem:
            print("Inversion failed")
        # inversion failed, try next inputs
        keep_trying = True
        return None, res_params, keep_trying

    def try_to_optimize(
        self,
        prop_class: RandomPropagation,
        target: Value,
        cond_inputs: np.ndarray[Value],
        init_fitness: float,
        init_params: tuple[NodeValueMap, Graph],
    ) -> tuple[float, NodeValueMap]:
        verbose = False
        optimizable_indices, x0, is_int, _ = self._extract_scalars(cond_inputs)

        # try to optimize parameters
        def fun(x):
            for xi, idx, is_int_ in zip(x, optimizable_indices, is_int):
                cond_inputs[idx] = Value(int(xi)) if is_int_ else Value(float(xi))
            res_dl, res_params = self.invert_and_get_best_mem(prop_class, target, self.cond, cond_inputs)
            return res_dl, res_params

        opt = AdaptiveOptimizer(is_int=is_int, n_points=5, grow=2.0, shrink=0.5)
        res_x, res_dl, res_params = opt.optimize(
            fun, x0, init_fitness, init_params, jointly_optimize=False, verbose=verbose
        )
        success = np.any(res_x != x0)
        return res_dl, res_params, success

    @staticmethod
    def _extract_scalars(values: list[Value]) -> tuple[list[int], np.ndarray, np.ndarray, float]:
        indices = []
        x = []
        is_int = []
        non_scalar_dl = 0
        for i, v in enumerate(values):
            a, b = isinstance(v.value, int_like), isinstance(v.value, float_like)
            if a or b:
                indices.append(i)
                x.append(v.value)
                is_int.append(True if a else False)
            else:
                non_scalar_dl += v.desc_len()
        return indices, np.array(x, dtype=np.float64), np.asarray(is_int), non_scalar_dl

    def render(self, *args, **kwargs):
        self.root.render(*args, **kwargs)
        print(f"{self.effective_length}, cond: {self.cond}")

    def invert_and_get_best_mem(
        self,
        prop_class: RandomPropagation,
        target: Value,
        cond: tuple[int],
        cond_inputs: np.ndarray[Value],
    ) -> tuple[float | None, NodeValueMap, Graph]:
        deb = False

        mem = NodeValueMap()
        mem[self.root] = MapEntry(same=False, val=target)
        target_leaf = None
        for k, val in zip(cond, cond_inputs):
            if val.is_none:
                continue
            if val is target:
                target_leaf = self._leaves[k]
            mem[self._leaves[k]] = MapEntry(same=False, val=val)

        min_dl = float("inf")
        min_mem = NodeValueMap()
        min_bottleneck = None

        cross_sects = cross_sections(target_leaf, self._leaves)

        for prop_mem in prop_class.propagate(self.root, mem, debug=deb):
            if target_leaf is None:
                bottleneck_dl = sum(prop_mem[node].val.desc_len() for node in self._leaves)
                bottleneck = self._leaves
            else:
                bottleneck_dl, bottleneck = trace_comb_bottleneck(cross_sects, prop_mem)

            if min_dl is None or bottleneck_dl < min_dl:
                min_dl = bottleneck_dl
                min_mem = prop_mem
                min_bottleneck = bottleneck

        return min_dl, (min_mem, min_bottleneck)


class RustDAGCondInputsItem(DAGCondInputsItem):
    def __init__(self, root: RustGraph, eff_len: float, cond_inputs_gen: BufferedIterator, cond: tuple[int]):
        self.root = root
        self._leaves = root.leaves()
        self._dl = eff_len
        self.cond = cond

        self._cond_inputs_gen = cond_inputs_gen
        self._iter_num = 0
        self._add_dl = 0

    def __hash__(self):
        return unique_hash((type(self), self.root.connection_hash(), self.dl, self.cond))

    def invert_and_get_best_mem(
        self,
        prop_class: RandomPropagation,
        target: Value,
        cond: tuple[int],
        cond_inputs: np.ndarray[Value],
    ) -> tuple[float | None, NodeValueMap, Graph]:
        deb = False

        mem = NodeValueMap()

        mem[self.root.get_root()] = MapEntry(same=False, val=target)
        target_leaf = None
        for k, val in zip(cond, cond_inputs):
            if val.is_none:
                continue
            if val is target:
                target_leaf = self._leaves[k]
            mem[self._leaves[k]] = MapEntry(same=False, val=val)

        min_dl = float("inf")
        min_mem = NodeValueMap()
        min_bottleneck = None

        if target_leaf is not None:
            cross_sects = self.root.cross_sections(target_leaf, self._leaves)

        for prop_mem in prop_class.propagate(self.root, mem, debug=deb):
            if target_leaf is None:
                bottleneck_dl = sum(prop_mem[node].val.desc_len() for node in self._leaves)
                bottleneck = self._leaves
            else:
                bottleneck_dl, bottleneck = trace_comb_bottleneck(cross_sects, prop_mem)

            if min_dl is None or bottleneck_dl < min_dl:
                min_dl = bottleneck_dl
                min_mem = prop_mem
                min_bottleneck = bottleneck

        return min_dl, (min_mem, min_bottleneck)


class Wunderbaum:
    """A wonderful tree that grows DAGs from operators and values."""

    _delayed_dag_build = delayed_dag_build
    _dag_item_cls = DAGCondInputsItem

    def __init__(
        self,
        spec: Any,
        ops_with_counts: list[tuple[Operator, int]],
        level: int | None = None,
        free_values: dict[Any, list[Value]] = (),
    ):
        self.elements_by_spec = self.get_elements_by_spec(ops_with_counts)

        self.inputs_enum = InputsEnumerator(elements_by_spec=self.elements_by_spec, free_values=free_values)
        self._inputs_enum_cache = {}

        self.seen = set()
        self.heap = []
        root = ValueNode(output=Value(None, spec=spec))
        leaf = root
        for elem_num, (_, eff_len, _) in enumerate(self.elements_by_spec[leaf.output.spec]):
            ddb = DAGBuildInfo(eff_len, root, 0, elem_num)
            heappush(self.heap, ddb)

        self._max_leaves = None
        self.level = level if level is not None else int(os.environ.get("WILLIAM_DEBUG", 0))
        self.stats = []

    def elements_from_operator(self, op: Operator):
        graph_dl = (
            sum(node.op.desc_len() for node in op.root.walk(val_nodes=False))
            if isinstance(op, Composite)
            else op.desc_len()
        )
        seen = set()
        for specs in op.specs:
            for concrete_specs in concretize_specs(specs, [int, float]):
                if concrete_specs in seen:
                    continue
                seen.add(concrete_specs)
                elem = self._graph_element(op, concrete_specs[0].__args__, concrete_specs[1])
                yield elem, graph_dl

    def _graph_element(self, op, input_specs, output_spec):
        return graph_element(op, input_specs, output_spec)

    def get_elements_by_spec(
        self, ops_with_counts: list[tuple[Operator, int]]
    ) -> dict[Any, list[tuple[ValueNode, float, int]]]:
        elements_by_spec = defaultdict(list)
        rng = np.random.default_rng(seed=42)

        total_count = sum(count for _, count in ops_with_counts)
        for op, count in ops_with_counts:
            for elem, op_dl in self.elements_from_operator(op):
                eff_len = eff_len_from_count(op_dl, count, total_count, rng)
                elements_by_spec[self._elem_spec(elem)].append((elem, eff_len, count))

        return elements_by_spec

    def _elem_spec(self, elem: ValueNode) -> Any:
        return elem.output.spec

    def iterate(
        self,
        prop_class: RandomPropagation,
        target: Value,
        trees_only: bool = False,
        solution: ValueNode | None = None,
        counting_mode: bool = False,
        max_dl: float = float("inf"),
    ):
        solution_op_nodes = len(list(solution.walk(val_nodes=False))) if solution is not None else None
        solution_found = False
        sk = 2
        num_yielded = 0
        num_popped = 0
        t0 = time()
        self.stats = [(0, 0, 0)]
        follow = None
        memory_offset = memory_usage()
        while self.heap:
            if self.level >= 4 and num_popped % 10000 == 0:
                memory = memory_usage()
                delta = memory - memory_offset
                print(
                    f"\nHeap size: {len(self.heap)}, RSS memory: {delta:<.2f} MB, "
                    f"RSS per item: {1024 * delta / len(self.heap) if self.heap else 0:.2f} KB, "
                    f"yielded: {num_yielded}, popped: {num_popped}, first item dl={self.heap[0].dl:.2f}"
                )
                nmax = max([len(it._buffer) for _, it in self._inputs_enum_cache.items()], default=0)
                print(f"Max cached inputs enum size: {nmax}")

            item = heappop(self.heap)

            if counting_mode and self.level >= 4 and num_popped % 100000 == 0:
                yield item, None, None

            num_popped += 1

            if item.dl > self.stats[-1][0]:
                self.stats.append((item.dl, num_popped, time() - t0))

            if follow is not None and item is not follow:
                continue

            if not counting_mode and isinstance(item, self._dag_item_cls):
                min_dl, min_params, keep_trying = item.try_inputs_and_invert(
                    prop_class, target, verbose=self.level >= 7, debug=follow is not None
                )

                # if inversion successful, yield the item
                if min_params[0] and (solution is None or solution_found):
                    yield item, min_dl, min_params
                    num_yielded += 1

                if keep_trying and item.dl <= max_dl:
                    heappush(self.heap, item)
                continue

            ddb: DAGBuildInfo = item
            accepted_root = None

            for new_root, new_root_leaves in self.__class__._delayed_dag_build(
                ddb, self.elements_by_spec, trees_only, self._max_leaves, self.seen
            ):
                if accepted_root is not None and new_root is not accepted_root:
                    continue

                if solution is not None:
                    new_root_op_nodes = len(list(new_root.walk(val_nodes=False)))
                    if new_root_op_nodes > solution_op_nodes:
                        raise RuntimeError("Solution graph not found.")

                    if not new_root.subgraph(solution):
                        continue

                    if new_root_op_nodes == solution_op_nodes:
                        print(ansi.CYAN)
                        print("Solution graph found:")
                        print(solution.to_sexpr())
                        print(f"Item dl = {ddb.dl:.2f}")
                        print(ansi.RESET)
                        self.heap = []
                        accepted_root = new_root
                        solution_found = True

                if not counting_mode:
                    for cond in self._get_conditions(new_root):
                        # since the DAG is the same for various inversion conditions,
                        # only allow growth for one of them
                        cond_inputs_enum = self._get_cond_inputs_enum(self.inputs_enum, new_root, new_root_leaves, cond)
                        item = self._dag_item_cls(new_root, ddb.dl, cond_inputs_enum, cond)

                        if solution is not None and new_root_op_nodes == solution_op_nodes and self.level >= 3:
                            item.render()
                            set_trace_up()

                        if item.dl > max_dl:
                            continue
                        heappush(self.heap, item)

                        if self.level >= 10:
                            print(f"Heap size: {len(self.heap)}")
                            item.render(filename="bush", view=False)
                            unpacked = item.root.clone_and_unpack()
                            unpacked.render(view=False)
                            s = "Keeping"
                            if sk == 1:
                                s = "Skipping this cond"
                            if sk == 2:
                                s = "Skipping this DAG"
                            print(ansi.LIGHT_MAGENTA + s + ansi.RESET)
                            set_trace_up()
                            if sk == 2:
                                break

                if self.level >= 10:
                    if sk > 0:
                        continue
                    sk = 2
                    self.heap = []
                    accepted_root = new_root
                    if follow is not None:
                        self.heap = [follow]
                        break

                if accepted_root is not None:
                    continue

                for leaf_num, leaf in enumerate(new_root_leaves):
                    elements = self.elements_by_spec[self._get_node_spec(new_root, leaf)]
                    for elem_num, (_, elem_eff_dl, _) in enumerate(elements):
                        new_dl = ddb.dl + elem_eff_dl
                        if new_dl > max_dl:
                            continue
                        new_ddb = DAGBuildInfo(new_dl, new_root, leaf_num, elem_num)
                        heappush(self.heap, new_ddb)
        debugger(self.level, {1: "Heap is empty, stopping enumeration."}, color="red")

    def _get_conditions(self, root: ValueNode) -> list[tuple[int]]:
        return get_conditions_py(root, adopt_for_callable=False)

    def _get_node_spec(self, root: ValueNode, leaf: ValueNode) -> Any:
        return leaf.output.spec

    def _get_cond_inputs_enum(
        self,
        inputs_enum: InputsEnumerator,
        root: ValueNode,
        root_leaves: list[ValueNode],
        cond: tuple[int],
    ) -> BufferedIterator:
        cond_specs = tuple([vn.output.spec for k, vn in enumerate(root_leaves) if k in cond])
        if cond_specs not in self._inputs_enum_cache:
            self._inputs_enum_cache[cond_specs] = BufferedIterator(inputs_enum.iterate(cond_specs))
        return self._inputs_enum_cache[cond_specs]


class SpeedyWunderbaum(Wunderbaum):
    """A wonderful tree that grows DAGs from operators and values, backed by a Rust graph."""

    _delayed_dag_build = speedy_delayed_dag_build
    _dag_item_cls = RustDAGCondInputsItem

    def __init__(
        self,
        registry_bundle: RegistryBundle,
        spec: Any,
        ops_with_counts: list[tuple[Operator, int]],
        level: int | None = None,
        free_values: dict[Any, list[Value]] = (),
    ):
        # --- registry for all graph objects ----------------------------------
        self.regs = registry_bundle

        # --- prepare Rust-encoded operator elements --------------------------
        self.elements_by_spec = self.get_elements_by_spec(ops_with_counts)

        # --- input enumerator & core search structures -----------------------
        self.inputs_enum = InputsEnumerator(elements_by_spec=self.elements_by_spec, free_values=free_values)
        self._inputs_enum_cache = {}

        self.seen = set()
        self.heap = []

        # --- root node and initial heap setup --------------------------------
        root_val_node = ValueNode(output=Value(None, spec=spec))
        root, _ = build_rust_graph_from_root(root_val_node, self.regs)

        # select operator elements compatible with this output spec
        spec_id = self.regs.spec_id(spec)
        if spec_id in self.elements_by_spec:
            for elem_num, (_, eff_len, _) in enumerate(self.elements_by_spec[spec_id]):
                ddb = DAGBuildInfo(eff_len, root, 0, elem_num)
                heappush(self.heap, ddb)

        self._max_leaves = None
        self.level = level if level is not None else int(os.environ.get("WILLIAM_DEBUG", 0))
        self.stats = []

    def _graph_element(self, op, input_specs, output_spec):
        """
        Rust-backed primitive element builder.
        Returns (rust_graph, output_rust_id)
        """
        return rustgraph_element(op, input_specs, output_spec, self.regs)

    def _elem_spec(self, rustgraph_elem: RustGraph) -> int:
        root_id = rustgraph_elem.get_root()
        type_info = rustgraph_elem.get_value_payload(root_id)
        if type_info is None:
            raise ValueError(f"Root node {root_id} has no type payload")
        _, type_id = type_info
        return type_id

    def _get_conditions(self, root: RustGraph):
        op_snapshot = self.regs.operators.get_rust_snapshot()
        for cond in get_conditions(root, root.get_root(), op_snapshot, False):
            yield tuple(cond)

    def _get_node_spec(self, root: RustGraph, leaf_id: int) -> int:
        payload = root.get_value_payload(leaf_id)
        if payload is None:
            raise ValueError(f"Leaf {leaf_id} has no payload.")
        _, type_id = payload
        return type_id

    def _get_cond_inputs_enum(
        self,
        inputs_enum: InputsEnumerator,
        root: RustGraph,
        root_leaves: list[int],
        cond: tuple[int],
    ) -> BufferedIterator:
        cond_specs = []
        for k, leaf_id in enumerate(root_leaves):
            if k not in cond:
                continue
            spec_id = self._get_node_spec(root, leaf_id)
            spec_obj = self.regs.spec(spec_id)
            cond_specs.append(spec_obj)
        cond_specs = tuple(cond_specs)

        if cond_specs not in self._inputs_enum_cache:
            self._inputs_enum_cache[cond_specs] = BufferedIterator(inputs_enum.iterate(cond_specs))
        return self._inputs_enum_cache[cond_specs]
