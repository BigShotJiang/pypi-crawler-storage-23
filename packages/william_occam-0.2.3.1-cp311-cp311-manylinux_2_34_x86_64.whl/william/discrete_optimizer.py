from collections.abc import Callable
from itertools import product
from math import isfinite
from typing import Any

import numpy as np


class NewtonOptimizer:
    def __init__(
        self,
        is_int: np.ndarray,
        max_iters: int = 1e6,
        max_attempts: int = 5,
        newton_step_cap: int = 100,
        backtrack_max: int = 4,
    ):
        self.max_iters = max_iters
        self.max_attempts = max_attempts
        self.newton_step_cap = int(newton_step_cap)
        self.backtrack_max = int(backtrack_max)
        self.cache: dict[bytes, float | None] = {}
        self.num_evals = 0

        # Mask indicating which dimensions are integer (True) or float (False).
        self.is_int = np.asarray(is_int, dtype=bool)
        self.dims = self.is_int.size

        # Basis vectors e_i (for integer-step proposals)
        self.E = np.eye(self.dims, dtype=np.int64)

        # Per-dimension float step sizes (used for finite differences and pattern search on float dims).
        # Default step is relative to the magnitude of the variable; can be tuned by caller by setting attribute.
        self.float_step = np.full(self.dims, np.nan, dtype=np.float64)

    def _key(self, x: np.ndarray) -> bytes:
        # dict key ohne Python-Listen/Tuples
        # include dtype/mask information so mixed types map to distinct keys
        xb = np.asarray(x, dtype=np.float64).tobytes()
        mb = self.is_int.tobytes()
        return xb + mb

    def safe_eval(self, f, x: np.ndarray) -> float | None:
        k = self._key(x)
        if k in self.cache:
            return self.cache[k]
        try:
            val, params = f(x)  # f should accept np.ndarray; otherwise: f(tuple(x))
            self.num_evals += 1
            if val is None or not isfinite(float(val)):
                self.cache[k] = None, None
            else:
                self.cache[k] = (float(val), params)
        except Exception:
            self.cache[k] = None, None
        return self.cache[k]

    def finite_diffs(self, f, x: np.ndarray, fx: float):
        # h = 1, zentrale Differenzen wo möglich, sonst einseitig; alles NumPy.
        g = np.zeros(self.dims, dtype=np.float64)
        hdiag = np.full(self.dims, np.nan, dtype=np.float64)

        for i in range(self.dims):
            if self.is_int[i]:
                # integer dimension: +/- 1 steps
                xp = x.copy()
                xm = x.copy()
                xp[i] = np.rint(xp[i]) + 1
                xm[i] = np.rint(xm[i]) - 1
                fp, _ = self.safe_eval(f, xp)
                fm, _ = self.safe_eval(f, xm)

                if fp is not None and fm is not None:
                    g[i] = (fp - fm) * 0.5
                    hdiag[i] = fp - 2.0 * fx + fm
                elif fp is not None:
                    g[i] = fp - fx
                    xm2 = x.copy()
                    xm2[i] = np.rint(xm2[i]) - 2
                    fm2, _ = self.safe_eval(f, xm2)
                    if fm2 is not None:
                        hdiag[i] = fp - 2.0 * fx + fm2
                elif fm is not None:
                    g[i] = fx - fm
                    xp2 = x.copy()
                    xp2[i] = np.rint(xp2[i]) + 2
                    fp2, _ = self.safe_eval(f, xp2)
                    if fp2 is not None:
                        hdiag[i] = fp2 - 2.0 * fx + fm
            else:
                # float dimension: use small relative step
                xi = float(x[i])
                # default step if not set: relative to magnitude
                if np.isnan(self.float_step[i]):
                    h = max(1e-6, abs(xi) * 1e-3)
                else:
                    h = float(self.float_step[i])
                # Try central differences, but if the objective is only defined
                # up to some precision a too-small h will not change f. In that
                # case increase h by factor 10 until the function changes or h >= 1.
                fp = None
                fm = None
                tried_h = h
                while True:
                    xp = x.copy()
                    xm = x.copy()
                    xp[i] = xi + tried_h
                    xm[i] = xi - tried_h
                    fp, _ = self.safe_eval(f, xp)
                    fm, _ = self.safe_eval(f, xm)

                    # If neither evaluation produced a value, increase step
                    if (fp is None and fm is None) and tried_h < 1.0:
                        tried_h *= 10.0
                        continue

                    # If both are present and equal to fx (no change), increase step
                    if fp is not None and fm is not None:
                        if fp == fm == fx and tried_h < 1.0:
                            tried_h *= 10.0
                            continue
                        # we have usable evaluations
                        break

                    # if only one side present but equals fx, try larger step
                    if fp is not None and fp == fx and tried_h < 1.0:
                        tried_h *= 10.0
                        continue
                    if fm is not None and fm == fx and tried_h < 1.0:
                        tried_h *= 10.0
                        continue

                    # otherwise accept what we have (may be one-sided)
                    break

                # Use last tried_h for difference formulas
                h = tried_h
                if fp is not None and fm is not None:
                    g[i] = (fp - fm) / (2 * h)
                    hdiag[i] = (fp - 2.0 * fx + fm) / (h * h)
                elif fp is not None:
                    g[i] = (fp - fx) / h
                elif fm is not None:
                    g[i] = (fx - fm) / h
        return g, hdiag

    def propose_newton_step(self, g: np.ndarray, hdiag: np.ndarray) -> np.ndarray:
        # produce float-valued step; integer dimensions will be rounded when applied
        s = np.zeros_like(g, dtype=np.float64)
        mask = ~np.isnan(hdiag) & (hdiag != 0.0)
        if np.any(mask):
            raw = -g[mask] / hdiag[mask]
            s_mask = raw
            # Clip pro Komponente
            cap = self.newton_step_cap
            s_mask = np.clip(s_mask, -cap, cap)
            s[mask] = s_mask

        # If nothing proposed, take a step of size 1 in the direction of the gradient
        if not np.any(s):
            idx = np.argmax(np.abs(g))
            if g[idx] != 0.0:
                s[idx] = -1.0 if g[idx] > 0 else 1.0
        return s

    def pattern_search_1(self, f, x: np.ndarray, best_f: float, best_params: Any):
        improved = False
        x_best = x
        f_best = best_f
        p_best = best_params
        for i in range(self.dims):
            for d in (-1, 1):
                xn = x.copy()
                if self.is_int[i]:
                    xn[i] = np.rint(xn[i]) + d
                else:
                    step = (
                        self.float_step[i] if not np.isnan(self.float_step[i]) else max(1e-6, abs(float(xn[i])) * 1e-3)
                    )
                    xn[i] = float(xn[i]) + d * step
                fn, pn = self.safe_eval(f, xn)
                if fn is not None and fn < f_best:
                    x_best = xn.copy()  # persist best
                    f_best = fn
                    p_best = pn
                    improved = True
        return improved, x_best, f_best, p_best

    def optimize(self, f, x, fx, init_params):
        if self.dims == 0:
            return x, fx, init_params

        best_x, best_f, best_params = self._local_search(f, x, fx, init_params)
        return best_x, best_f, best_params

    def _local_search(self, f, best_x: np.ndarray, best_f: float, init_params: Any):
        best_params = init_params
        it = 0
        while it < self.max_iters:
            it += 1
            fx = best_f

            g, hdiag = self.finite_diffs(f, best_x, fx)
            step = self.propose_newton_step(g, hdiag)

            # Newton-Schritt + Backtracking (ganzzahlige Reduktion Richtung 0)
            if np.any(step):
                tried = set()
                s = step.copy()
                for _ in range(self.backtrack_max):
                    x_new = best_x + s
                    # round integer dimensions
                    if np.any(self.is_int):
                        idxs = np.where(self.is_int)[0]
                        for ii in idxs:
                            x_new[ii] = np.rint(x_new[ii])
                    k = self._key(x_new)
                    if k not in tried:
                        tried.add(k)
                        f_new, p_new = self.safe_eval(f, x_new)
                        if f_new is not None and f_new < best_f:
                            best_x, best_f, best_params = x_new.copy(), f_new, p_new
                            break
                    # Reduziere jede Komponente um 1 Richtung 0 (diskretes Line-Search)
                    # For float dims, reduce magnitude (half). For int dims, step towards 0 by 1.
                    s_new = s.copy()
                    for ii in range(len(s)):
                        if self.is_int[ii]:
                            s_new[ii] = s_new[ii] - np.sign(s_new[ii])
                        else:
                            s_new[ii] = 0.5 * s_new[ii]
                    s = s_new
                    if not np.any(s):
                        break
                if best_f < fx:
                    continue  # Verbesserung gefunden → nächste Iteration

            # Pattern-Search (±1 an jeder Achse)
            improved, x_ps, f_ps, p_ps = self.pattern_search_1(f, best_x, best_f, best_params)
            if improved:
                best_x, best_f, best_params = x_ps, f_ps, p_ps
            else:
                break  # Stagnation

        return best_x, best_f, best_params


class AdaptiveOptimizer:
    """
    Iterative coordinate-wise adaptive grid search.
    Each dimension is optimized independently at current scale.
    After each full sweep, global scale is expanded or shrunk
    depending on whether improvement occurred.
    """

    def __init__(
        self,
        is_int: np.ndarray,
        n_points: int = 21,
        grow: float = 2.0,
        shrink: float = 0.5,
        max_iter: int = 20,
    ):
        self.is_int = np.asarray(is_int, dtype=bool)
        self.n_points = int(n_points)
        self.grow = float(grow)
        self.shrink = float(shrink)
        self.max_iter = int(max_iter)
        self.num_evals = 0

    def optimize(
        self,
        f: Callable[[np.ndarray], tuple[float, Any]],
        x0: np.ndarray,
        f_best: float,
        p_best: Any,
        jointly_optimize: bool = False,
        verbose: bool = False,
    ) -> tuple[np.ndarray, float, Any]:
        x = np.array(x0, dtype=float)
        self.num_evals = 1
        scale = np.abs(x) * 0.5 + 1
        scale[self.is_int] = np.maximum(1, np.rint(scale[self.is_int]))

        max_scale = 1e6
        for _ in range(self.max_iter):
            modified = False

            for i in range(len(x)):
                if scale[i] < 1 / max_scale or scale[i] > max_scale:
                    continue
                axis = self._make_axis(x[i], scale[i], self.is_int[i])
                if verbose:
                    print(f"Optimizing dimension {i} with scale {scale[i]}, axis: {axis}")
                # track local best value, coordinate and associated params
                best_local, all_equal = self.find_best_local(
                    x.copy(), axis, i, f, (f_best, x[i], p_best), verbose=verbose
                )

                f_val, v_best, p_val = best_local
                # consider this dimension as improved only if it lowered the
                # objective relative to the value before we explored it
                if f_val < f_best:
                    f_best = f_val
                    x[i] = v_best
                    p_best = p_val
                    modified = True
                    # if best value is at edge of axis, increase scale
                    if v_best in [axis[0], axis[-1]]:
                        scale[i] *= self.grow
                    else:
                        scale[i] *= self.shrink
                # else:
                #     scale[i] *= self.grow if all_equal else self.shrink
                #     modified = modified or all_equal

            # ensure integer-dimension scales remain integer-ish and at least 1
            if np.any(self.is_int):
                scale[self.is_int] = np.maximum(1.0, np.rint(scale[self.is_int]))

            if modified:
                continue
            if not modified and not jointly_optimize:
                break

            # Line search / coordinate sweep failed to improve. Try sampling
            # a few points from the Cartesian product of per-dimension axes
            # to escape shallow local minima. If still no improvement, stop.
            axes = []
            sizes = []
            for j in range(len(x)):
                if scale[j] < 1 / max_scale or scale[j] > max_scale:
                    axes.append(np.array([x[j]]))
                else:
                    axes.append(self._make_axis(x[j], scale[j], self.is_int[j]))
                sizes.append(len(axes[-1]))

            total = int(np.prod(sizes)) if sizes else 0
            if total == 0:
                break

            if verbose:
                print(f"Sampling {total} candidate points from grid. Current best f: {f_best}, best x: {x}")
            # Single evaluation loop over chosen candidate value-tuples
            for val_tuple in product(*axes):
                cand = np.array(val_tuple, dtype=float)
                # enforce integer dims
                if np.any(self.is_int):
                    cand[self.is_int] = np.rint(cand[self.is_int])
                fv, pv = f(cand)
                if verbose:
                    print(" Trying candidate:", cand, " f =", fv)
                self.num_evals += 1
                if fv is None or fv >= f_best:
                    continue
                f_best = fv
                x = cand
                p_best = pv
                modified = True
                if verbose:
                    print(f" Found improvement: f = {f_best}, x = {x}")

                # increase scale on dimensions at the edges of the sampled grid
                for i in range(len(x)):
                    if x[i] in [axes[i][0], axes[i][-1]]:
                        scale[i] *= self.grow
                    else:
                        scale[i] *= self.shrink
                break

            # If sampling didn't find any improvement, stop
            if not modified:
                break

        return x, f_best, p_best

    def find_best_local(self, x_try, axis, i, f, best_local, verbose: bool = False):
        if verbose:
            print(f"Current best f: {best_local[0]} at dimension {i}")
        f_init = best_local[0]
        all_equal = True
        num_inf = 0
        for v in axis:
            x_try[i] = v
            if verbose:
                print("x_try:", x_try)
            f_val, p_val = f(x_try)
            if np.isinf(f_val):
                num_inf += 1
            if not np.isinf(f_val) and f_val != f_init:
                all_equal = False
            self.num_evals += 1
            if f_val < best_local[0]:
                best_local = (f_val, v, p_val)
                if verbose:
                    print(f" New best f: {best_local[0]}")
        if num_inf >= len(axis) - 1:
            all_equal = False
        return best_local, all_equal

    def _make_axis(self, center: float, span: float, is_int: bool) -> np.ndarray:
        axis = np.linspace(center - span, center + span, self.n_points)
        if is_int:
            axis = np.unique(axis.astype(int))
        return axis
