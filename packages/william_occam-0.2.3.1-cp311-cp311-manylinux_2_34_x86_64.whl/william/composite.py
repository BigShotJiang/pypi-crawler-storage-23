from collections import defaultdict, namedtuple
from collections.abc import Callable
from functools import cached_property
from itertools import product
from typing import Any

from william.conditions import get_conditions_py
from william.library.base import Operator, Value
from william.library.types import issubspec, sort_specs, typereplace, unify
from william.nvmap import MapEntry, NodeValueMap
from william.propagation_py import RandomPropagation
from william.structures.nodes import Node  # deep import to avoid circular dependency
from william.structures.value_nodes import ValueNode  # deep import to avoid circular dependency


class Composite(Operator):
    primitive = False

    def __init__(
        self,
        root,
        name="",
        output_spec=None,
        prop_class: RandomPropagation | None = None,
        constant_nums=(),
        desc_len: float | None = None,
    ):
        self.root = root  # references the root node of a tree
        self.output_spec = output_spec
        self._name = name
        self.prop_class = prop_class or RandomPropagation(partial=False, cache=False)

        # constant_nums are the indices of leaves whose values are contained in the leaves,
        # they are not part of the inputs
        self.constant_nums = constant_nums
        self._leaves = []
        self._variable_leaves = []
        self._constant_leaves = []
        for k, leaf in enumerate(root.leaves()):
            self._leaves.append(leaf)
            if k in constant_nums:
                self._constant_leaves.append(leaf)
            else:
                self._variable_leaves.append(leaf)

        self._dl = desc_len

    @property
    def name(self):
        return self._name

    @cached_property
    def spec(self):
        """When the composite is inside a value node, this is the spec of the value node content."""
        if self.output_spec is not None:
            return self.output_spec
        # TODO: takes only the first spec, what about others?
        n = 0
        return Callable[[self.specs[n][0]], self.specs[n][1]]

    @cached_property
    def specs(self):
        """Usual specs of an operator."""
        result_specs = []
        for root_specs in self.root.options[0].op.specs:
            trans_specs_dict = synchronize_specs(self.root, fixed_spec=root_specs[1])

            trans_specs = []
            for leaf in self._leaves:
                op_node = leaf.parents[0]
                i = op_node.children.index(leaf)
                # the 0th entry is the output spec of the operator
                trans_specs.append(trans_specs_dict[op_node][i + 1])

            for spec_comb in product(*trans_specs):
                input_specs = tuple(spec for spec in spec_comb)
                new_spec = (tuple[input_specs], root_specs[1])
                if new_spec not in result_specs:
                    result_specs.append(new_spec)
        return result_specs

    def desc_len(self, **kwargs):
        if self._dl is None:
            # description length by the number of nodes in the tree
            self._dl = sum(node.op.desc_len() for node in self.root.walk(val_nodes=False))
        return self._dl

    def __call__(self, *inputs):
        if not self.root.options:
            return self.root.output
        mem = NodeValueMap()  # self._init_mem()
        input_nums = len(self._leaves) - len(self.constant_nums)
        if input_nums != len(inputs):
            raise ValueError("Input number mismatch.")
        self.set_leaves(mem, inputs)
        result = None
        for new_mem in self.prop_class.propagate(self.root, mem):
            result = new_mem[self.root].val
            break
        if result is None:
            raise ValueError("Error from calling composite.")
        return result

    def _call(self, *inputs):
        return self(*[Value(i) for i in inputs]).value

    def __hash__(self):
        return self._hash

    @property
    def hash(self):
        return self._hash

    def __str__(self):
        return f"<composite {self.root.to_sexpr()} dl={self.desc_len():.2f}>"

    def __repr__(self):
        return self.__str__()

    @property
    def commutative(self):
        """Return true if we can expect the same result independent of any permutation of the leaves."""
        return self.root.commutative

    def _typify(self, types):
        return [(tuple[tuple(inp.op.output_specs[0] for inp in self._leaves)], self.output_spec)]

    @property
    def arity(self):
        return len(self._leaves)

    @property
    def _hash(self):
        hsh = hash("__composite__")
        for node in self.root.walk(val_nodes=False):
            hsh ^= hash(node.op)
        hsh ^= hash(tuple(n.output.hash for n in self._constant_leaves))
        return hsh

    def copy(self):
        return Composite(
            self.root.clone(), name=self.name, output_spec=self.output_spec, constant_nums=self.constant_nums
        )

    def resembles(self, other):
        return self.root.resembles(other.root)

    def render(self, *args, **kwargs):
        self.root.render(*args, **kwargs)

    @property
    def conditions(self):
        # without taking into account the constant leaves
        conds = []
        for raw_cond in get_conditions_py(self.root):
            # constant_nums have to be a subset of raw_cond
            if any(i not in raw_cond for i in self.constant_nums):
                continue
            # example: raw_cond = (0, 2, 3, 5, 6, 7, 9) for a composite with 10 leaves
            # constant_nums     = (0,    3,       7   )
            # cond              = (   1,    3, 4,    6) (indices in variable leaves)
            cond = []
            offset = 0
            for i in raw_cond:
                if i in self.constant_nums:
                    offset += 1
                    continue
                cond.append(i - offset)
            conds.append(tuple(cond))
        return conds

    def suitable(self, output):
        node = self.root.options[0]
        if node.op.has_callable:
            formally_suitable = all([node.children[0].output.suitable(t) for t in output])
        else:
            formally_suitable = node.op.suitable(output)
        return formally_suitable

    def inverse(self, output, cond_inputs, cond):
        if not self.root.options:
            yield (self.root.output,)
            return

        mem = self._init_mem()
        mem[self.root] = MapEntry(same=False, val=output)
        self.set_leaves(mem, cond_inputs, cond_indices=cond)
        for new_mem in self.prop_class.propagate(self.root, mem, debug=False):
            yield from self._inferred(new_mem, cond)

    def _inverse(self, output, cond_inputs, cond):
        ci = tuple([Value(c) for c in cond_inputs])
        for inf in self.inverse(Value(output), ci, cond):
            yield tuple(i.value for i in inf)

    def _init_mem(self):
        mem = NodeValueMap()
        for val_node in self._constant_leaves:
            # (not (is None and realized) and realized = (is not None or not realized) and realized =
            # is not None and realized or not realized and realized = is not None and realized or False
            # = is not None and realized
            if not val_node.output.is_none and val_node.output.realized:
                mem[val_node] = MapEntry(same=False, val=val_node.output)
        return mem

    def set_leaves(self, mem, values, cond_indices=None):
        for leaf in self._constant_leaves:
            mem[leaf] = MapEntry(same=True, val=leaf.output)

        if cond_indices is None:
            cond_indices = list(range(len(self._variable_leaves)))

        for k, val in zip(cond_indices, values):
            if val.is_none:
                continue
            mem[self._variable_leaves[k]] = MapEntry(same=False, val=val)

    def _inferred(self, mem, cond):
        inferred = []
        for k, leaf in enumerate(self._variable_leaves):
            if k in cond:
                continue
            if leaf not in mem:
                return
            inferred.append(mem[leaf].val)
        yield tuple(inferred)


def print_transposed_specs(trans_specs_dict: dict[Node, list[list[Any]]]) -> None:
    for op_node in trans_specs_dict.keys():
        print("\nOperator:", op_node.op)
        print_trans(trans_specs_dict[op_node])


def print_trans(trans_specs: list[list[Any]]) -> None:
    if not trans_specs:
        return
    for var_num in range(len(trans_specs[0])):
        actual = tuple([ts[var_num] for ts in trans_specs])
        print("Variant", var_num, "Specs:", actual)


def synchronize_specs(val_node: ValueNode, fixed_spec: Any | None = None) -> dict[Node, list[list[Any]]]:
    trans_specs_dict = {}
    specs_changed = True
    while specs_changed:
        for vn in val_node.walk(op_nodes=False):
            fs = fixed_spec if vn is val_node else None
            new_trans_specs_dict, specs_changed = specs_intersection_at_valuenode(vn, trans_specs_dict, fixed_spec=fs)
            trans_specs_dict.update(new_trans_specs_dict)
    return trans_specs_dict


dummy = namedtuple("dummy", "op")


def specs_intersection_at_valuenode(
    val_node: ValueNode, trans_specs_dict: dict[Node, list[list[Any]]], fixed_spec: Any | None = None
) -> tuple[dict[Node, list[list[Any]]], bool]:
    restriction_found = False
    trans_specs, trans_specs_dict = _collect_trans_specs_at_valuenode(val_node, trans_specs_dict)
    if fixed_spec is not None:
        trans_specs.append([[dummy, 0, fixed_spec]])
        trans_specs_dict[dummy] = [[fixed_spec]]

    new_trans_specs_dict = defaultdict(list)
    hash_dict = defaultdict(list)
    for entry_comb in product(*trans_specs):
        # sort spec combination from specific to general
        sort_idx = sort_specs([spec for _, _, spec in entry_comb])
        if not sort_idx:
            continue

        # most specific op node
        op_node, variant_num, _ = entry_comb[sort_idx[0]]
        _apply_repl_to_op_trans_specs(
            {}, trans_specs_dict[op_node], variant_num, new_trans_specs_dict[op_node], hash_dict[op_node]
        )
        if new_trans_specs_dict[op_node] == []:
            raise ValueError("Specs intersection appears to be empty.")

        entry_comb = list(entry_comb)
        for i, j in zip(sort_idx[:-1], sort_idx[1:]):
            more_specific_spec = entry_comb[i][2]
            op_node, variant_num, less_specific_spec = entry_comb[j]
            repl = unify(less_specific_spec, more_specific_spec)
            if issubspec(less_specific_spec, more_specific_spec) and not issubspec(
                more_specific_spec, less_specific_spec
            ):
                restriction_found = True
            # if repl:
            #     # replace so that it propagates to the more general specs in this combination
            #     entry_comb[j][2] = typereplace(less_specific_spec, repl)
            # take care of all of the operators neighbors specs as well
            _apply_repl_to_op_trans_specs(
                repl, trans_specs_dict[op_node], variant_num, new_trans_specs_dict[op_node], hash_dict[op_node]
            )
            if new_trans_specs_dict[op_node] == []:
                raise ValueError("Specs intersection appears to be empty.")
    return new_trans_specs_dict, restriction_found


def _collect_trans_specs_at_valuenode(
    val_node: ValueNode, trans_specs_dict: dict[Node, list[list[Any]]]
) -> tuple[list[list[Any]], dict[Node, list[list[Any]]]]:
    trans_specs = []
    for op_node in val_node.neighbors():
        if op_node not in trans_specs_dict:
            trans_specs_dict[op_node] = _transposed_specs(op_node)
        for neighbor_num, neighbor in enumerate(op_node.neighbors(unique=True)):
            # figure out which neighbor is the val_node to the op_node
            if neighbor is not val_node:
                continue
            entry = []
            for variant_num, spec in enumerate(trans_specs_dict[op_node][neighbor_num]):
                entry.append([op_node, variant_num, spec])
            if entry == []:
                raise ValueError("Specs intersection appears to be empty.")
            trans_specs.append(entry)
    return trans_specs, trans_specs_dict


def _transposed_specs(node: Node) -> list[list[Any]]:
    """
    Transpose the specs for easier access. Instead of a list of (input_specs, output_spec),
    return a list of specs for each input and output position.
    """
    trans_specs = []
    for spec_tuple in node.op.specs:
        spec_list = [spec_tuple[1]] + list(spec_tuple[0].__args__)
        # neighbor_num = 0
        first_seen_spec = {}
        new_spec_list = []
        for neighbor, neighbor_spec in zip(node.neighbors(), spec_list):
            # make sure that if a neighbor appears multiple times (DAG mode), its specs unify
            if neighbor in first_seen_spec:
                try:
                    unify(first_seen_spec[neighbor], neighbor_spec)
                except TypeError:
                    break
                continue
            first_seen_spec[neighbor] = neighbor_spec
            new_spec_list.append(neighbor_spec)
        else:
            while len(trans_specs) < len(new_spec_list):
                trans_specs.append([])
            for neighbor_num, neighbor_spec in enumerate(new_spec_list):
                trans_specs[neighbor_num].append(neighbor_spec)
    return trans_specs


def _apply_repl_to_op_trans_specs(
    repl: dict,
    op_trans_specs: list[list[Any]],
    var_num: int,
    new_op_trans_specs: list[list[Any]],
    hash_per_var: list[int],
) -> None:
    """Apply repl to all specs in that operator of that variant number. Returns a spec for each neighbor."""
    new_specs = []
    for neighbor_num, neighbor_specs in enumerate(op_trans_specs):
        new_spec = typereplace(neighbor_specs[var_num], repl) if repl else neighbor_specs[var_num]
        new_specs.append(new_spec)
    new_hash = hash(str(new_specs))
    if new_hash in hash_per_var:
        return
    hash_per_var.append(new_hash)
    for neighbor_num, new_spec in enumerate(new_specs):
        if neighbor_num == len(new_op_trans_specs):
            new_op_trans_specs.append([])
        new_op_trans_specs[neighbor_num].append(new_spec)
