import os
from collections.abc import Callable
from itertools import chain
from math import log

import intnan as inn
import numpy as np

from william.library.base import BinOp, Operator, UnaryOp
from william.library.basic_ops import Add, Mult
from william.library.functions import (
    MAX_EXPONENT,
    MAX_INT,
    cumop,
    cumsum,
    diff,
    insert,
    listslice,
    partition_by_frequency,
    partition_given_content,
    partition_given_indices,
    power,
    table,
    trange,
    urange,
)
from william.library.precision import execute, recursive_match
from william.library.types import T1, T2, Array, array_type, convert, float_like, int_like, issubspec, number_like
from william.utils.workspace import get_workspace

exec_errors = (TypeError, ValueError, ZeroDivisionError, IndexError, KeyError, OverflowError)
level = int(os.getenv("WILLIAM_DEBUG", "0"))

ws = get_workspace()


class SoftInvert(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    @staticmethod
    def _adapt_sign(x, y):
        if isinstance(x, np.ndarray):
            y[x < 0] = -y[x < 0]
        if isinstance(x, float_like) and x < 0:
            y = -y
        return y

    def _soft_invert(self, y):
        if isinstance(y, np.ndarray):
            large = np.abs(y) > MAX_INT
            res = np.zeros_like(y)
            res[large] = 1 / MAX_INT
            res[~large] = 1 / np.sqrt(1 + y[~large] ** 2)
        else:
            res = 1 / MAX_INT if np.abs(y) > MAX_INT else 1 / np.sqrt(1 + y**2)
        res = self._adapt_sign(y, res)
        return res

    def _call(self, x):
        return execute(self._soft_invert, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return isinstance(output, number_like) and not np.any(output == 0) and np.all(np.abs(output) < 1)

    def _inverse(self, output, cond_inputs, cond):
        res = np.sqrt(1 / output**2 - 1)
        res = self._adapt_sign(output, res)
        yield (res,)


class Abs(UnaryOp):
    _raw_specs = [(tuple[int], int), (tuple[float], float)]
    conditions = ((),)

    def _call(self, output):
        return abs(output)

    @staticmethod
    def _suitable(output):
        if not isinstance(output, int_like + float_like):
            return False
        return output >= 0  # |x| < 0 can not be satisfied

    def _inverse(self, output, cond_inputs, cond):
        yield (output,)
        if output > 0:
            yield (-output,)


class Sum(UnaryOp):
    _raw_specs = [
        (tuple[list[int]], int),
        (tuple[list[float]], float),
        (tuple[Array[int]], int),
        (tuple[Array[float]], float),
    ]
    conditions = ()

    def _call(self, x):
        return execute(np.sum, (x,), ignore_precision=self.ignore_precision)


class Mean(UnaryOp):
    _raw_specs = [(tuple[Array[int]], float), (tuple[Array[float]], float)]
    conditions = ()

    def _call(self, x):
        if np.all(inn.isnan(x)):
            return np.nan
        return execute(np.nanmean, (x,), ignore_precision=self.ignore_precision)


class Exp(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        if isinstance(x, np.ndarray):
            x2 = x.copy()
            x2[x > MAX_EXPONENT] = MAX_EXPONENT
        else:
            x2 = MAX_EXPONENT if x > MAX_EXPONENT else x
        return execute(np.exp, (x2,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return np.all(output > 0)

    def _inverse(self, output, cond_inputs, cond):
        if np.any(output <= 0):
            return  # Negative value in logarithm
        yield (np.log(output),)


class Log(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        if isinstance(x, np.ndarray):
            result = np.zeros_like(x)  # TODO: built as safe-log. Returns 0 for inputs <= 0!
            valid = x > 0
            if np.any(valid):
                result[valid] = execute(np.log, (x[valid],), ignore_precision=self.ignore_precision)
        else:
            result = 0 if x <= 0 else execute(np.log, (x,), ignore_precision=self.ignore_precision)
        return result

    def _inverse(self, output, cond_inputs, cond):
        if np.nanmax(output) > 50:
            return  # overflow
        yield (np.exp(output),)


class Sqrt(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        return execute(np.sqrt, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return np.all(output >= 0)

    def _inverse(self, output, cond_inputs, cond):
        yield (output**2,)


class Sin(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        return execute(np.sin, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return np.all(-1 <= output) and np.all(output <= 1)

    def _inverse(self, output, cond_inputs, cond):
        yield (np.arcsin(output),)


class Cos(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        return execute(np.cos, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return np.all(-1 <= output) and np.all(output <= 1)

    def _inverse(self, output, cond_inputs, cond):
        yield (np.arccos(output),)


class Tanh(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        return execute(np.tanh, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return np.all(-1 < output) and np.all(output < 1)

    def _inverse(self, output, cond_inputs, cond):
        yield (np.arctanh(output),)


class Isnan(UnaryOp):
    _raw_specs = [(tuple[Array[float]], Array[bool])]
    conditions = ()

    def _call(self, x):
        return np.isnan(x)


class Transpose(UnaryOp):
    _raw_specs = [(tuple[Array[T1]], Array[T1])]
    conditions = ((),)

    def _call(self, x):
        return x.transpose()

    @staticmethod
    def _suitable(output):
        return isinstance(output, np.ndarray)

    def _inverse(self, output, cond_inputs, cond):
        yield (output.transpose(),)


class Shape(UnaryOp):
    _raw_specs = [
        (tuple[Array[T1]], tuple[int]),
        (tuple[Array[T1]], tuple[int, int]),
        (tuple[Array[T1]], tuple[int, int, int]),
    ]
    conditions = ((0,),)

    def _call(self, x):
        return x.shape


class BoolZeros(UnaryOp):
    _raw_specs = [(tuple[int], Array[bool])]
    conditions = ((),)

    def _call(self, x):
        return np.zeros(x, dtype=bool)

    @staticmethod
    def _suitable(output):
        return isinstance(output, np.ndarray) and output.dtype.kind == "b" and not np.any(output)

    def _inverse(self, output, cond_inputs, cond):
        yield (len(output),)


class Conversion(UnaryOp):
    conversion = None

    def _typify(self, types):
        """Avoid pointless ``T->T`` conversions."""
        specs = UnaryOp._typify(self, types)
        return [s for s in specs if s[0].__args__[0] != s[1]]

    def _call(self, x):
        conv = self.conversion[0] if isinstance(self.conversion, tuple) else self.conversion
        if isinstance(x, np.ndarray):
            return x.astype(conv)
        return conv(x)

    def _suitable(self, output):
        conv = self.conversion[0] if isinstance(self.conversion, tuple) else self.conversion
        if isinstance(output, np.ndarray):
            return conv in array_type[output.dtype.kind]
        return isinstance(output, self.conversion)


class ToStr(Conversion):
    # Alloing list->str would not make sense
    conversion = str

    _raw_specs = [(tuple[int], str), (tuple[float], str)]
    conditions = ((),)

    def _suitable(self, output):
        if not isinstance(output, str) or not set(output).issubset("0123456789."):
            return False
        if len(output) > 1 and output[0] == "0":
            return False
        n = len(output)
        try:
            n = output.index(".")
        except ValueError:
            pass
        return n <= 20  # String encodes a too large integer

    def _inverse(self, output, cond_inputs, cond):
        for input_spec, _ in self.specs:
            isp = input_spec.__args__[0]
            if isp == float and "." not in output:
                # If output is not a string representation of a float, then no float can be the result of inversion.
                return
            try:
                yield (isp(output),)
            except ValueError:
                return


class ToChr(Conversion):
    conversion = chr

    _raw_specs = [(tuple[int], str)]
    conditions = ((),)

    def _suitable(self, output):
        if not isinstance(output, str):
            return False  # output has to be a string
        if len(output) != 1:
            return False  # output has to have length 1
        return True

    def _inverse(self, output, cond_inputs, cond):
        yield (ord(output),)


class ToBool(Conversion):
    conversion = bool

    _raw_specs = [(tuple[T1], bool)]
    conditions = ((0,),)

    def _call(self, x):
        return bool(x)


class ToInt(Conversion):
    conversion = int_like

    _raw_specs = [
        (tuple[float], int),
        (tuple[str], int),
        (tuple[bool], int),
        (tuple[Array[float]], Array[int]),
        (tuple[Array[str]], Array[int]),
        (tuple[Array[bool]], Array[int]),
    ]
    conditions = ((),)

    def _inverse(self, output, cond_inputs, cond):
        for input_spec, _ in self.specs:
            input_spec = input_spec.__args__[0]
            if issubspec(input_spec, Array) and isinstance(output, np.ndarray):
                sub_spec = input_spec.__args__[0]
                if sub_spec == bool and np.any(~np.isin(output, [0, 1])):
                    continue
                yield (output.astype(sub_spec),)
            if not issubspec(input_spec, Array) and not isinstance(output, np.ndarray):
                if input_spec == bool and output not in [0, 1]:
                    continue
                yield (input_spec(output),)


class ToFloat(ToInt):
    conversion = float

    _raw_specs = [
        (tuple[int], float),
        (tuple[str], float),
        (tuple[bool], float),
        (tuple[Array[int]], Array[float]),
        (tuple[Array[str]], Array[float]),
        (tuple[Array[bool]], Array[float]),
    ]
    conditions = ((),)

    def _inverse(self, output, cond_inputs, cond):
        for input_spec, _ in self.specs:
            input_spec = input_spec.__args__[0]
            if issubspec(input_spec, Array) and isinstance(output, np.ndarray):
                sub_spec = input_spec.__args__[0]
                if sub_spec == bool and np.any(~np.isin(output, [0, 1])):
                    continue
                if sub_spec == int and np.any(np.round(output) != output):
                    continue
                yield (output.astype(sub_spec),)
            if not issubspec(input_spec, Array) and not isinstance(output, np.ndarray):
                if input_spec == bool and output not in [0, 1]:
                    continue
                if input_spec == int and int(output) != output:
                    continue
                yield (input_spec(output),)


class StrToList(Conversion):
    conversion = list

    _raw_specs = [(tuple[str], list[str])]
    conditions = ((),)

    def _call(self, x):
        return list(x)

    def _suitable(self, output):
        if any(len(s) != 1 for s in output):
            return False
        return True

    def _inverse(self, output, cond_inputs, cond):
        yield ("".join(output),)


class ArrayToList(Conversion):
    _raw_specs = [(tuple[Array[T1]], list[T1])]
    conditions = ((),)

    def _call(self, x):
        return x.tolist()

    def _suitable(self, output):
        return isinstance(output, list)

    def _inverse(self, output, cond_inputs, cond):
        yield (np.array(output),)


class ListWrap(UnaryOp):
    _raw_specs = [(tuple[T1], list[T1])]
    conditions = ((),)

    def _call(self, x):
        return [x]

    @staticmethod
    def _suitable(output):
        return len(output) == 1  # output has to have length 1

    def _inverse(self, output, cond_inputs, cond):
        yield (output[0],)


class Sub(Add):
    _raw_specs = [
        (tuple[int, float], float),
        (tuple[int, int], int),
        (tuple[float, float], float),
        (tuple[Array[int], Array[int]], Array[int]),
        (tuple[Array[float], Array[float]], Array[float]),
        (tuple[Array[float], int], Array[float]),
        (tuple[Array[float], float], Array[float]),
    ]
    conditions = (0,), (1,)
    commutative = False
    arity = 2

    def _call(self, x, y):
        if isinstance(x, np.ndarray) and isinstance(y, np.ndarray) and x.shape != y.shape:
            raise ValueError("Shape mismatch.")
        return execute(lambda a, b: a - b, (x, y), ignore_precision=self.ignore_precision)

    @staticmethod
    def inv_func(cond):
        if cond == (0,):
            return lambda i, t: i - t
        else:
            return lambda i, t: i + t


class Div(Mult):
    _raw_specs = Add.common_specs + [(tuple[int, int], float)]
    conditions = (0,), (1,)
    commutative = False
    arity = 2

    def _call(self, x, y):
        if isinstance(x, np.ndarray) and isinstance(y, np.ndarray) and x.shape != y.shape:
            raise ValueError("Shape mismatch.")
        if np.isscalar(y) and y == 0 or isinstance(y, np.ndarray) and np.any(y == 0):
            raise ZeroDivisionError("Division by zero.")
        return execute(lambda a, b: convert(a / b, float), (x, y), vary=True, ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        if isinstance(output, np.ndarray):
            # a / b = 0 not solvable for b, and not meaningful to solve for a
            return sum(output.shape) > 0 and np.all(output != 0)
        return isinstance(output, float) and output != 0

    @staticmethod
    def inv_func(cond):
        if cond == (0,):
            return lambda i, t: i / t
        else:
            return lambda i, t: i * t

    @staticmethod
    def _check_int(output):
        return True


class Mod(BinOp):
    _raw_specs = [(tuple[int, int], int)]
    conditions = ((0, 1),)
    commutative = False

    def _call(self, x, y):
        return x % y


class Power(BinOp):
    _raw_specs = [(tuple[int, int], int), (tuple[int, int], float), (tuple[float, int], float)]
    conditions = (0,), (1,)
    commutative = False

    def _call(self, x, y):
        return power(x, y)

    @staticmethod
    def _suitable(output):
        if not isinstance(output, int_like + float_like):
            return False
        return output != 0  # output=0, impossible to invert x^y=0

    def _inverse(self, output, cond_inputs, cond):
        if not isinstance(cond_inputs[0], int_like + float_like):
            return  # Has to be a number
        if cond_inputs[0] == 0:
            return  # cond_inputs=0
        if cond == (0,):
            if type(cond_inputs[0]) != type(output):
                return  # type mismatch
            val = Power._log(output, cond_inputs[0])
            if val is None:
                return
            if val != int(val):
                return  # power is a float
            yield (int(val),)
        elif cond == (1,):
            if output == 1:
                yield (type(output)(1),)  # whatever the exponent (=cond_inputs) the base is 1, since 1^anything = 1
                return
            if isinstance(output, float):
                val = Power._pow(output, 1 / float(cond_inputs[0]))
                if val is None:
                    return
                result = pow(val, cond_inputs[0])
                if output != result:
                    return  # precision
                yield (val,)
            elif isinstance(output, int_like):
                val = Power._pow(output, 1 / float(cond_inputs[0]))
                if val is None:
                    return
                if val != int(val):
                    return  # result is float value, but should be int because output is int
                yield (int(val),)

    @staticmethod
    def _pow(x, y):
        try:
            res = pow(x, y)
            if isinstance(res, complex):
                return
            return res
        except Exception:  # noqa
            return

    @staticmethod
    def _log(x, base):
        try:
            return log(x, base)
        except Exception:  # noqa
            return


class Union(BinOp):
    _raw_specs = [
        (tuple[set[T1], set[T1]], set[T1]),
        (tuple[list[T1], list[T1]], set[T1]),
        (tuple[Array[T1], Array[T1]], set[T1]),
    ]
    conditions = (0,), (1,)
    commutative = True
    arity = None  # variable arity

    def _call(self, *args):
        if len(args) == 0:
            raise ValueError("Union takes at least one input.")
        if len(args) == 1:
            return args[0]
        return set.union(*[set(a) for a in args])

    @staticmethod
    def _suitable(output):
        return isinstance(output, set)

    def _inverse(self, output, cond_inputs, cond):
        if not isinstance(cond_inputs[0], set | list):
            return  # Has to be a set
        if any(i not in output for i in cond_inputs[0]):
            return  # Set difference not possible, since not all elements of the subtrahend are in output
        res = output.difference(cond_inputs[0])
        if cond == (1,):
            res = list(res)
        yield (res,)


class CumSum2(BinOp):
    _raw_specs = [(tuple[int, Array[int]], Array[int]), (tuple[float, Array[float]], Array[float])]
    conditions = ((),)
    commutative = False

    def _call(self, start, x):
        return np.cumsum(np.concatenate(([start], x)))

    @staticmethod
    def _suitable(output):
        return (
            isinstance(output, np.ndarray)
            and output.dtype.kind in ["i", "f"]
            and len(output) >= 2
            and len(output.shape) == 1
        )

    def _inverse(self, output, cond_inputs, cond):
        yield output[0], np.diff(output)


class Dot(BinOp):
    """Dot product"""

    _raw_specs = [
        (tuple[Array[float], Array[float]], float),
        (tuple[Array[float], Array[float]], Array[float]),
    ]
    conditions = ((0, 1),)
    commutative = False

    def _call(self, a, b):
        return np.dot(a, b)

    def _inverse(self, output, cond_inputs, cond):
        if isinstance(output, np.ndarray) and cond_inputs[0].shape[-1] != cond_inputs[1].shape[0]:
            return  # Array shape mismatch in dot product
        if isinstance(output, float) and (
            cond_inputs[0].shape != cond_inputs[1].shape or len(cond_inputs[0].shape) != 1
        ):
            return  # Vectors for dot product have to have the same length
        try:
            res = self._call(*cond_inputs)
        except exec_errors:
            return
        if recursive_match(output, res):
            yield ()
        else:
            return  # function output does not match the output


class Full(BinOp):
    _raw_specs = [
        (tuple[tuple[int], T1], Array[T1]),
        (tuple[tuple[int, int], T1], Array[T1]),
        (tuple[tuple[int, int, int], T1], Array[T1]),
    ]
    conditions = ((),)

    def _call(self, shape, fill_value):
        return np.full(shape, fill_value)

    @staticmethod
    def _suitable(output):
        return isinstance(output, np.ndarray) and len(output) > 0 and len(output.shape) <= 3

    def _inverse(self, output, cond_inputs, cond):
        if np.all(np.isnan(output)) or np.all(output[0] == output):
            yield output.shape, output.ravel()[0]
        else:
            return  # All output values have to be equal


class And(BinOp):
    _raw_specs = [(tuple[bool, bool], bool)]
    conditions = (0,), (1,)
    commutative = True

    def _call(self, x, y):
        return x and y

    def _inverse(self, output, cond_inputs, cond):
        for y in [True, False]:
            if (cond_inputs[0] and y) == output:
                yield (y,)


class Or(BinOp):
    _raw_specs = [(tuple[bool, bool], bool)]
    conditions = (0,), (1,)
    commutative = True

    def _call(self, x, y):
        return x or y

    def _inverse(self, output, cond_inputs, cond):
        for y in [True, False]:
            if (cond_inputs[0] or y) == output:
                yield (y,)


class Xor(BinOp):
    _raw_specs = [(tuple[Array[bool], Array[bool]], Array[bool])]
    conditions = (0,), (1,)
    commutative = True

    def _call(self, x, y):
        return np.logical_xor(x, y)

    @staticmethod
    def _suitable(output):
        return isinstance(output, np.ndarray) and output.dtype.kind == "b"

    def _inverse(self, output, cond_inputs, cond):
        if output.shape != cond_inputs[0].shape:
            return  # Shape mismatch
        yield (np.logical_xor(output, cond_inputs[0]),)


class ListSlice(Operator):
    _raw_specs = [(tuple[list[T1], int, int], list[T1])]
    conditions = ((0, 1, 2),)
    commutative = False

    def _call(self, x, i1, i2):
        return listslice(x, i1, i2)


class Join(UnaryOp):
    _raw_specs = [(tuple[list[str]], str)]
    conditions = ((),)
    commutative = True

    def _call(self, x):
        return "".join(x)

    def _inverse(self, output, cond_inputs, cond):
        for n in range(len(output) + 1, 1, -1):
            if len(output) % n == 0:
                sub_len = int(len(output) / n)
                yield ([output[i : i + sub_len] for i in range(0, len(output), sub_len)],)
                return


class Insert(Operator):
    _raw_specs = [
        # (tuple[list[int], str, str], str),
        # (tuple[list[int], T1, list[T1]], list[T1]),
        # (tuple[list[int], T1, Array[T1]], Array[T1]),
        # (tuple[list[int], list[T1], list[T1]], list[T1]),
        # (tuple[list[int], Array[T1], Array[T1]], Array[T1]),
        (tuple[Array[int], T1, Array[T1]], Array[T1]),
        (tuple[Array[int], Array[T1], Array[T1]], Array[T1]),
    ]
    conditions = (), (0,), (1,)
    commutative = False

    cond_inv_functions = {
        (0,): partition_given_indices,
        (1,): partition_given_content,
    }

    def _call(self, indices, source, destination):
        return insert(indices, source, destination)

    def _inverse(self, output, cond_inputs, cond):
        try:
            if cond == ():
                for a, b, c in partition_by_frequency(output):
                    # if (
                    #     (isinstance(a, Iterable) and len(a) == 0)
                    #     or (isinstance(b, Iterable) and len(b) == 0)
                    #     or (isinstance(c, Iterable) and len(c) == 0)
                    # ):
                    #     return  # Empty data couldn't be yielded
                    yield a, b, c
            if len(cond) == 1:
                for a, b in Insert.cond_inv_functions[cond](output, cond_inputs[0]):
                    # if (isinstance(a, Iterable) and len(a) == 0) or (isinstance(b, Iterable) and len(b) == 0):
                    #     return  # Empty data couldn't be yielded
                    yield a, b
        except (ValueError, IndexError, TypeError):
            return


class BMap(Operator):
    _raw_specs = [
        (tuple[Callable[[tuple[T2, T2]], T1], list[T2], list[T2]], list[T1]),
        (tuple[Callable[[tuple[T2, T2]], T1], Array[T2], Array[T2]], Array[T1]),
    ]
    conditions = (0,), (0, 1), (0, 2)
    commutative = False
    has_callable = True

    def _call(self, x, y, z):
        func = getattr(x, "_call", x)
        result = list(map(func, y, z))
        if isinstance(y, np.ndarray) or isinstance(z, np.ndarray):
            result = np.array(result)
        else:
            result = type(y)(result)
        return result

    def _inverse(self, output, cond_inputs, cond):
        """
        :cond_inputs[0]: must be a function
        """
        if any(len(inp) != len(output) for inp in cond_inputs[1:]):
            return  # input list and output list do not match in length
        func = cond_inputs[0]
        if cond[0] != 0:
            return  # First cond has to be the 0th input: the operator has to be present.
        func_cond = tuple(c - 1 for c in cond[1:])
        if func_cond not in func.conditions:
            return  # Condition is not match any of the conditions of the operator inside bmap.

        inv_list = []
        num_inverses = 1
        for i, t in enumerate(output):
            if not func._suitable(t):
                if level > 10:
                    raise ValueError(f"Value {t} not suitable for inversion of callable {func} inside BMap.")
                return  # Unsuitable output for callable
            func_cond_inputs = tuple(k[i] for k in cond_inputs[1:])
            inv = list(func._inverse(t, func_cond_inputs, func_cond))
            if level > 10 and len(inv) == 0:
                raise ValueError(
                    f"callable {func} inside BMap not invertible with output {t}, cond_inputs {func_cond_inputs} and cond {func_cond}."
                )
            inv_list.append(inv)
            num_inverses *= len(inv)
            if num_inverses > 100:  # do not allow more than 100 inversions
                return  # Too many inversions

        for inps in zip(*inv_list):
            if isinstance(output, np.ndarray):
                yield tuple(np.array(list(a)) for a in zip(*inps))
            else:
                yield tuple(list(a) for a in zip(*inps))


class URange(Operator):
    _raw_specs = [(tuple[int], Array[int])]
    conditions = ((),)
    commutative = True

    def _call(self, stop):
        return urange(stop)

    @staticmethod
    def _suitable(output):
        if len(output) == 0:
            return False
        if any(not isinstance(t, int_like) for t in output):
            return False  # output has to be a list of integers
        res = output[-1] + 1
        if len(range(res)) != len(output) or np.any(np.arange(res) != output):
            return False
        return True

    def _inverse(self, output, cond_inputs, cond):
        yield (output[-1] + 1,)


class TRange(Operator):
    _raw_specs = [(tuple[int, int, int], Array[int])]
    conditions = ((),)
    commutative = False

    def _call(self, start, stop, step):
        return trange(start, stop, step)

    @staticmethod
    def _suitable(output):
        if len(output) == 0:
            return False
        if any(not isinstance(t, int_like) for t in output):
            return False  # output has to be a list of integers
        step = output[1] - output[0] if len(output) > 1 else 1
        if step == 0:
            return False  # TRange can not be inverted since range step cannot be zero
        res = (output[0], output[-1] + step, step)
        if len(range(*res)) != len(output) or np.any(np.arange(*res) != output):
            return False
        return True

    def _inverse(self, output, cond_inputs, cond):
        step = output[1] - output[0] if len(output) > 1 else 1
        yield output[0], output[-1] + step, step


class CumSum(Operator):
    _raw_specs = [
        (tuple[list[int]], list[int]),
        (tuple[Array[int]], Array[int]),
        (tuple[Array[float]], Array[float]),
    ]
    conditions = ((),)
    commutative = False

    def _call(self, x):
        if isinstance(x, np.ndarray):
            y = ws.tmp(like=x)
            y[:] = cumsum(x)
        else:
            y = cumsum(x)
        return y

    @staticmethod
    def _suitable(output):
        return (
            isinstance(output, list)
            or (isinstance(output, np.ndarray) and len(output.shape) == 1)
            and output.dtype.kind in ["i", "f"]
        )

    def _inverse(self, output, cond_inputs, cond):
        if isinstance(output, np.ndarray):
            y = ws.tmp(like=output)
            y[:] = diff(output)
        else:
            y = diff(output)
        yield (y,)


class CumOp(Operator):
    """Generalize cumsum for arbitrary (binary) operators, not just a sum."""

    # the output of the function must be of the same type as the first input,
    # since it is reinserted into the first input of the function
    _raw_specs = [(tuple[Callable[[tuple[T1, T2]], T1], T1, Array[T2]], Array[T1])]
    conditions = ((0,),)
    commutative = False
    has_callable = True
    cumulative = True

    def _call(self, func, start, some_list):
        func = getattr(func, "_call", func)
        return cumop(func, start, some_list)

    def _inverse(self, output, cond_inputs, cond):
        """
        :cond_inputs: must be a function
        """
        func = cond_inputs[0]
        if (0,) not in func.conditions:
            return  # Operator inside CumOp has to be invertible when conditioned on first input.
        if len(output) == 0:
            return  # Target is empty
        inv_list = []
        for t0, t1 in zip(output[:-1], output[1:]):
            if not func._suitable(t1):
                if level > 10:
                    raise ValueError(f"Value {t1} not suitable for inversion of callable {func} inside CumOp.")
                return  # Unsuitable output for callable
            inv_list.append(func._inverse(t1, (t0,), (0,)))
        for inps in zip(*inv_list):
            first_type = type(inps[0][0])
            for i in inps:
                if type(i[0]) != first_type:
                    return  # List contains entries with different types
            res = list(chain(*inps))
            if isinstance(output, np.ndarray):
                res = np.array(res)
            yield output[0], res


class Zip2D(Operator):
    _raw_specs = [
        (tuple[list[T1], list[T2]], list[tuple[T1, T2]]),
        (tuple[Array[T1], Array[T2]], Array[tuple[T1, T2]]),
    ]
    conditions = ((),)
    commutative = False

    def _call(self, list1, list2):
        if len(list1) != len(list2):
            raise ValueError("Lists have to be equal in length")
        return list(zip(list1, list2))

    @staticmethod
    def _suitable(output):
        if len(output) == 0:
            return False
        tuple_len = len(output[0])
        if tuple_len == 0 or any(len(x) != tuple_len for x in output):
            return False  # Tuples inside list must have equal length
        return True

    def _inverse(self, output, cond_inputs, cond):
        yield tuple(list(x) for x in zip(*output))


class Diff(Operator):
    _raw_specs = [(tuple[list[int]], list[int])]
    conditions = ((),)
    commutative = True

    def _call(self, output):
        return diff(output)

    def _inverse(self, output, cond_inputs, cond):
        yield (cumsum(output),)


class Table(Operator):
    _raw_specs = [(tuple[list[int], list[int]], list[int])]
    conditions = ((),)
    commutative = False

    def _call(self, values, positions):
        return table(values, positions)

    @staticmethod
    def _suitable(output):
        return len(output) > 0

    def _inverse(self, output, cond_inputs, cond):
        values = sorted(set(output))
        positions = [values.index(val) for val in output]
        yield values, positions
