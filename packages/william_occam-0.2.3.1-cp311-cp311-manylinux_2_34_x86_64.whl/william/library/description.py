import math
from fractions import Fraction

import intnan as inn
import numba as nb
import numpy as np

from william.library.precision import MAX_PRECISION, POW10, jprecision, jprecision_scalar
from william.library.types import convert, py_type


@nb.jit(nopython=True)
def int_tuple_dl(int_tuple):
    """A quick version of the dl computation for integer tuples with non-negative values."""
    s = jelias(len(int_tuple)) if len(int_tuple) > 0 else 0
    for num in int_tuple:
        s += jelias(num + 1)
    return s


def desc_len(x, mode="default"):
    if x is None:
        return 1.0
    if hasattr(x, "function") and hasattr(x, "inputs"):
        return desc_len(x.function.root) + desc_len(x.inputs)
    #                                                  int, float, bool or string array
    if isinstance(x, np.ndarray) and x.dtype.kind in ("i", "f", "b", "U"):
        if len(x) == 0:
            return 0.0
        length_code = sum(jelias(s) for s in x.shape)
        if x.dtype.kind == "b":
            return length_code + np.prod(x.shape)  # _jdesc_len_bool_array(x)
        if x.dtype.kind == "U":
            return length_code + sum(desc_len(py_type(y)) for y in x.ravel())
        decimals = jprecision(x)
        elias_dl, all_nan = _jdesc_len_array_elias(x.ravel(), decimals)
        gauss_dl = np.inf
        if mode == "use_gaussian":  # and x.dtype.kind == "f":
            gauss_dl = desc_len_array_gaussian(x, decimals)[0]
        sig_dl = min(elias_dl, gauss_dl)
        dl = length_code + sig_dl
        dec_dl = 0
        if not all_nan:
            dec_dl = jelias_posneg(decimals) if x.dtype.kind == "f" else jelias(1 - decimals)
        return dl + dec_dl
    if isinstance(x, list | tuple | set):
        length_code = jelias(len(x)) if len(x) > 0 else 0
        return length_code + _sum_desc_len_fast(x)  #  + sum(desc_len(py_type(y)) for y in x)
    if isinstance(x, str):
        length_code = jelias(len(x)) if len(x) > 0 else 0
        return length_code + 8 * len(x)  # sum(elias_posneg(ord(y)) for y in x)
    if isinstance(x, bool | np.bool_):
        return 1
    if isinstance(x, int | np.integer):
        return _jdesc_len_int(x)
    if isinstance(x, float | np.float32 | np.float64):
        return _jdesc_len_float(x)
    if hasattr(x, "is_variable") and x.is_variable:
        return 0
    if hasattr(x, "is_operator") and x.is_operator:
        return x.desc_len()
    if hasattr(x, "desc_len"):
        return x.desc_len()
    if hasattr(x, "value"):
        return desc_len(x.value)

    raise TypeError(f"Unknown input type {type(x)}")


def _sum_desc_len_fast(x):
    if not x:
        return 0.0
    first = next(iter(x))
    # schnelle NumPy-Pfade
    if isinstance(first, (int, np.integer)):
        arr = np.fromiter(x, dtype=np.int64)
        return np.sum(np.vectorize(_jdesc_len_int)(arr))
    if isinstance(first, (float, np.floating)):
        arr = np.fromiter(x, dtype=np.float64)
        return np.sum(np.vectorize(_jdesc_len_float)(arr))
    if isinstance(first, (bool, np.bool_)):
        return float(len(x))  # 1 pro Element
    # Fallback
    return sum(desc_len(y) for y in x)


def elias_discrete(x):
    """Description length of an integer value expressed via Elias delta coding. Requires x >= 1
    See from https://en.wikipedia.org/wiki/Elias_delta_coding"""
    n = convert(np.log2(x), int)
    return n + 2 * convert(np.log2(n + 1), int) + 1


@nb.njit
def jelias(x):
    """A continuous version of the elias_discrete"""
    n = np.log2(x)
    return n + 2 * np.log2(n + 1) + 1


@nb.njit
def jelias_posneg(x):
    """Elias delta length for all integer values, including negatives and zero (only scalars, no arrays)."""
    return jelias(2 * abs(x) + 1)


@nb.njit
def _jdesc_len_int(x, decimals=None):
    """Decompose into mantissa and exponent and return their description length."""
    if x == inn.INTNAN64:  # treat NaNs as place holders, which can be any number -> no description necessary
        return 0
    if decimals is None:
        decimals = jprecision_scalar(x)
    significand = np.round(x * POW10[MAX_PRECISION + decimals])
    return jelias_posneg(significand) + jelias(1 - decimals)


@nb.njit
def _jdesc_len_float(x, decimals=None):
    """Decompose into mantissa and exponent and return their description length."""
    if np.isnan(x):  # treat NaNs as place holders, which can be any number -> no description necessary
        return 0
    if decimals is None:
        decimals = jprecision(x)
    significand = np.round(x * POW10[MAX_PRECISION + decimals])
    return jelias_posneg(significand) + jelias_posneg(decimals)


@nb.njit
def _jdesc_len_array_elias(x, decimals):
    """For integer or float arrays compute the description length of the significand using the Elias code."""
    scale = 10.0**decimals
    sig_dl = 0.0
    all_nan = True
    for i in range(len(x)):
        # treat NaNs as place holders, which can be any number -> no description necessary
        if x[i] == inn.INTNAN64 or np.isnan(x[i]):
            continue
        all_nan = False
        sig_dl += jelias_posneg(round(x[i] * scale))
    return sig_dl, all_nan


@nb.njit
def jgaussian(x, mu, sigma):
    """
    The Shannon-Fano code length of a Gaussian distribution on integers, i.e. -log2(p(x)), where p(x)=norm(x,mu,sigma).
    If x ~ mu, the code length is dominated by log2(2*sigma) which is the number of bits necessary to select one of
    2*sigma numbers. Floats can be treated by separately describing the decimals, see jdesc_len_array_gaussian.
    """
    return max(0.0, (x - mu) ** 2 / (2 * np.log(2) * sigma**2) + np.log2(np.sqrt(np.pi / 2)) + np.log2(2 * sigma))


@nb.njit
def _jdesc_len_1d_array_gaussian(x, scale, mu, sigma):
    """For integer or float arrays compute the description length of the significand using a Gaussian."""
    sig_dl = 0.0
    all_nan = True
    for i in range(len(x)):
        # treat NaNs as place holders, which can be any number -> no description necessary
        if x[i] == inn.INTNAN64 or np.isnan(x[i]):
            continue
        all_nan = False
        sig_dl += jgaussian(x[i] * scale, mu, sigma)
    return sig_dl, all_nan


def desc_len_1d_array_gaussian(x, scale):
    mu = inn.nanmean(x) * scale
    if np.isnan(mu):
        return 0.0, True
    mu_dl = jelias_posneg(round(mu))
    sigma = inn.nanstd(x) * scale
    if sigma == 0:
        return np.inf, False
    sigma_dl = jelias_posneg(round(sigma))
    sig_dl, all_nan = _jdesc_len_1d_array_gaussian(x, scale, mu, sigma)
    return sig_dl + mu_dl + sigma_dl, all_nan


def desc_len_array_gaussian(x, decimals):
    if decimals > MAX_PRECISION:
        return np.inf, False
    scale = 10.0**decimals
    if len(x.shape) < 3:
        return desc_len_1d_array_gaussian(x.ravel(), scale)
    dl = 0.0
    all_nan = False
    for i in range(x.shape[2]):
        sig_dl, _all_nan = desc_len_1d_array_gaussian(x[:, :, i].ravel(), scale)
        all_nan = all_nan and _all_nan
        dl += sig_dl
    return dl, all_nan


@nb.njit
def _jdesc_len_bool_array(x):
    """
    Describe the index of enumerating k True's in an array of length m.
    E.g. the array [False, True, False, False, True] has k=2 True's, length m=5. Thus there are binom(5,2) ways of
    distribution the 2 True's in the array. Return the Elias code of this binomial along with the description
    of k (exclude the description of m).
    """
    m = len(x)
    k = np.sum(x)
    k = min(k, m - k)
    n = log_binomial(m, k)
    dl_index = n + 2 * np.log2(n + 1) + 1  # see Elias code
    dl_km = jelias(k + 1) + jelias(m - k)  # describe k and m-k  (k can be zero, thus k+1; m-k >= 1, thus plain Elias)
    return dl_index + dl_km


MAX_UNIQUE = 10


def _describe_by_permutation_index(x):
    """
    If an array consists of a few values only, compute the Elias code of their permutation index.
    E.g. the array [False, True, False, False, True] has k=2 True's, length m=5. Thus there are binom(5,2) ways of
    distribution the 2 True's in the array. Return the Elias code of this binomial along with the description
    of k and m-k.
    """
    y = x[~inn.isnan(x)] if x.dtype.kind == "f" else x
    unique_elements, counts = np.unique(y, return_counts=True)
    if x.dtype.kind == "f":
        unique_elements = np.append(unique_elements, np.nan)
        counts = np.append(counts, np.sum(inn.isnan(x)))

    if len(counts) >= min(MAX_UNIQUE, x.size):
        return np.inf
    counts.sort()
    num = log_multinomial(x.size, counts)
    dl_index = num + 2 * np.log2(num + 1) + 1  # see Elias code
    # describe the counts list
    dl_counts = sum(jelias(c + 1) for c in counts[:-1]) + jelias(counts[-1])
    dl_uniques = 0 if x.dtype.kind == "b" else desc_len(unique_elements)
    return dl_index + dl_counts + dl_uniques


def _fraction(x, tol=1e-2):
    absx = abs(x)
    absx = Fraction(absx).limit_denominator()
    if absx <= tol:
        return 0, 1
    a = b = 1
    fraction = Fraction(a, b).limit_denominator()
    while math.fabs(fraction - absx) > tol:
        if fraction < absx:
            a += 1
        else:
            b += 1
        fraction = Fraction(a, b).limit_denominator()
    if x < 0:
        a = -a
    return a, b


@nb.njit
def log_fac(m, n):
    s = 0
    for i in range(m, n + 1):
        s += np.log2(i)
    return s


@nb.njit
def log_binomial(n, k):
    if k > n - k:
        return log_fac(n - k + 1, n) - log_fac(2, k)
    else:
        return log_fac(k + 1, n) - log_fac(2, n - k)


@nb.njit
def log_multinomial(n, b):
    """Compute logarithm of n! / b[0]! / b[1]! / ... / b[-1]! avoiding large numbers. sum(b) = n has to hold."""
    s = log_fac(b[0] + 1, n)
    for j in range(1, len(b)):
        s -= log_fac(2, b[j])
    return s
