import numba as nb
import numpy as np
from numba.typed import List as TypedList


class Filler:
    MAX_SIZE = 1000000

    def __init__(self, closed_paths_only=False):
        self.x_ind = np.zeros(self.MAX_SIZE, dtype=int)
        self.y_ind = np.zeros(self.MAX_SIZE, dtype=int)
        self.num = 0
        self.closed_paths_only = closed_paths_only

    def check_borders(self, borders):
        if not self.closed_paths_only:
            return
        if isinstance(borders, list) and can_be_rearranged_into_a_path(borders):
            return
        raise ValueError("Border points do not form a closed path.")


class LineFiller(Filler):
    @staticmethod
    def _scan(points, idx):
        y = points[idx][0]
        min_x, max_x = np.inf, -np.inf
        while True:
            if points[idx][1] < min_x:
                min_x = points[idx][1]
            if points[idx][1] > max_x:
                max_x = points[idx][1]
            idx += 1
            if idx >= len(points) or points[idx][0] != y:
                return y, min_x, max_x, idx

    def _fill(self, borders):
        sorted_borders = sorted(borders, key=lambda p: p[0])
        idx = 0
        while idx < len(sorted_borders):
            y, min_x, max_x, idx = self._scan(sorted_borders, idx)
            for x in range(min_x, max_x + 1):
                yield y, x

    def fill(self, borders):
        self.num = 0
        for y, x in self._fill(borders):
            if self.num == self.MAX_SIZE:
                raise ValueError("Figure can not be filled, due to memory limitations.")
            self.x_ind[self.num] = x
            self.y_ind[self.num] = y
            self.num += 1
        return list(zip(self.y_ind[: self.num], self.x_ind[: self.num]))


class RecursiveFiller(Filler):
    @staticmethod
    def neighbors(point, diagonals=False):
        x, y = point
        yield x + 1, y
        yield x - 1, y
        yield x, y + 1
        yield x, y - 1
        if not diagonals:
            return
        yield x + 1, y + 1
        yield x - 1, y - 1
        yield x - 1, y + 1
        yield x + 1, y - 1

    @classmethod
    def _fill_dfs(cls, start, borders):
        """
        Depth-first search
        A little function that fills an area enclosed by the set of points in the border variable.
        For example, borders = [(3, 5), (4, 6), (5, 7), (5, 8), (5, 9), (6, 9), (7, 9), (7, 8),
        (7, 7), (8, 6), (7, 5), (7, 4), (6, 3), (5, 3), (4, 4)]
        """
        if start in borders:
            return borders
        if start not in borders:
            borders.append(start)
        for n in cls.neighbors(start):
            if n in borders:
                continue
            cls._fill_dfs(n, borders)
        return borders
        # return [start] + list(chain.from_iterable([fill(n, borders.union({start})) for n in neighbors(start)
        #                                            if n not in borders]))

    @classmethod
    def _fill_bfs(cls, start, borders):
        """
        Breadth-first search
        A little function that fills an area enclosed by the set of points in the border variable.
        For example, borders = {(3, 5), (4, 6), (5, 7), (5, 8), (5, 9), (6, 9), (7, 9), (7, 8),
        (7, 7), (8, 6), (7, 5), (7, 4), (6, 3), (5, 3), (4, 4)}
        """
        visited = set(borders).union((start,))
        queue = [start]
        while queue:
            point = queue.pop(0)
            for neighbor in cls.neighbors(point):
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                queue.append(neighbor)
        return list(visited)

    @staticmethod
    def _get_start(points):
        xs, ys = list(zip(*points))
        return int(np.mean(xs)), int(np.mean(ys))

    @classmethod
    def fill(cls, borders):
        start = cls._get_start(borders)
        if len(set(borders)) <= 5:
            return borders
        else:
            return cls._fill_bfs(start, borders)


class ExteriorFiller(RecursiveFiller):
    def __init__(self, shape=(50, 50), closed_paths_only=False):
        self.queue = np.zeros((2, self.MAX_SIZE), dtype=int)
        self.visited = np.ones(shape, dtype=int)
        self.closed_paths_only = closed_paths_only

    def fill(self, borders, cut_borders=False):
        self.check_borders(borders)
        y_lim, x_lim, width, length = get_boundary(borders, offset=(1, 1))
        if width > self.visited.shape[0] or length > self.visited.shape[1]:
            raise IndexError("Image too big for reserved memory")
        rectangle = self._rectangle_fill(y_lim, x_lim)
        exterior = self._exterior_fill_bfs(borders, y_lim, x_lim)
        # if the sum of the number of filled points and border points match the number of rectangle points, then
        # the border has a hole and the interior has been filled by the fill function! Throw exception.
        # Otherwise, the set difference between rectangle and filled points will be the interior + border points.
        if len(set(borders)) + len(exterior) == len(rectangle):
            raise ValueError("There is no interior.")

        closed_interior = rectangle.difference(exterior)  # closed = like closed set, includes the boundary
        # interior = closed_interior.difference(borders)
        # real_borders = set([])
        # for point in borders:
        #     has_in, has_out = self._has_neighbors_in(point, interior, exterior)
        #     if not has_out:  # or not has_in:
        #         raise ValueError(f"Not a real border,since there are no exterior/interior neighbors of point {point}")
        #     if has_in or not cut_borders:
        #         real_borders.add(point)
        # closed_interior = interior.union(real_borders)
        return list(closed_interior)

    @staticmethod
    def _rectangle_fill(y_lim, x_lim):
        rectangle = set([])
        for y in range(y_lim[0], y_lim[1] + 1):
            for x in range(x_lim[0], x_lim[1] + 1):
                rectangle.add((y, x))
        return rectangle

    @classmethod
    def _exterior_fill_bfs(cls, borders, y_lim, x_lim):
        """
        Breadth-first search
        A little function that fills an area given by the rectangle x_lim and y_lim except for a boundary given by
        borders.
        For example, borders = {(3, 5), (4, 6), (5, 7), (5, 8), (5, 9), (6, 9), (7, 9), (7, 8),
        (7, 7), (8, 6), (7, 5), (7, 4), (6, 3), (5, 3), (4, 4)}
        """
        # start at rectangle corner and fill area from outside
        start = (y_lim[0], x_lim[0])
        visited = {start}
        queue = [start]
        while queue:
            point = queue.pop(0)
            for neighbor in cls.neighbors(point):
                if neighbor in visited or neighbor in borders:
                    continue
                y, x = neighbor
                if y < y_lim[0] or y > y_lim[1] or x < x_lim[0] or x > x_lim[1]:
                    continue
                visited.add(neighbor)
                queue.append(neighbor)
        return visited

    @classmethod
    def _has_neighbors_in(cls, point, interior, exterior):
        has_in = False
        has_out = False
        for neighbor in cls.neighbors(point, diagonals=True):
            if neighbor in interior:
                has_in = True
            if neighbor in exterior:
                has_out = True
        return has_in, has_out


class JExteriorFiller(ExteriorFiller):
    def fill(self, borders, cut_borders=False):
        self.check_borders(borders)
        y_lim, x_lim, width, length = get_boundary(borders, offset=(1, 1))
        if width > self.visited.shape[0] or length > self.visited.shape[1]:
            raise IndexError("Image too big for reserved memory")
        initialize_visited(TypedList(borders), y_lim, x_lim, self.visited)
        jitted_exterior_fill_bfs(y_lim, x_lim, self.visited, self.queue)

        # r = 1
        # diffs = set(product(range(-r, r+1), range(-r, r+1)))
        # diffs = diffs.difference(set(product(range(-r+1, r), range(-r+1, r))))
        # diffs = TypedList(sorted(list(diffs)))
        # for point in borders:
        #     has_in, has_out = jitted_has_neighbors_in(point, self.visited, y_lim, x_lim, diffs)
        #     if not has_out:  # or not has_in:
        #         raise ValueError(f"Not a real border,since there are no exterior/interior neighbors of point {point}")
        # closed = like closed set, includes the boundary
        closed_interior = self.visited[: width + 1, : length + 1] >= 1
        y_ind, x_ind = np.where(closed_interior)
        return list(zip(*(y_ind + y_lim[0], x_ind + x_lim[0])))


@nb.njit
def jitted_exterior_fill_bfs(y_lim, x_lim, visited, queue):
    """exterior=0, border=1, interior=2."""
    queue[0, 0] = y_lim[0]
    queue[1, 0] = x_lim[0]
    n0 = 0
    n1 = 1
    while n0 < n1 < queue.shape[1] and n0 < queue.shape[1]:
        point = queue[:, n0]
        n0 += 1
        for neighbor in neighbors(point):
            y, x = neighbor
            a, b = y - y_lim[0], x - x_lim[0]
            if a < 0 or a >= visited.shape[0] or b < 0 or b >= visited.shape[1]:
                continue
            if visited[a, b] < 2:
                continue
            visited[a, b] = 0
            queue[:, n1] = neighbor
            n1 += 1


@nb.njit
def initialize_visited(borders, y_lim, x_lim, visited):
    visited[:, :] = 0
    visited[: y_lim[1] - y_lim[0] + 1, : x_lim[1] - x_lim[0] + 1] = 2
    for y, x in borders:
        a, b = y - y_lim[0], x - x_lim[0]
        if a < 0 or a >= visited.shape[0] or b < 0 or b >= visited.shape[1]:
            raise IndexError("Image too big for reserved memory")
        visited[a, b] = 1


@nb.njit
def neighbors(point, diagonals=False):
    x, y = point
    yield x + 1, y
    yield x - 1, y
    yield x, y + 1
    yield x, y - 1
    if not diagonals:
        return
    yield x + 1, y + 1
    yield x - 1, y - 1
    yield x - 1, y + 1
    yield x + 1, y - 1


@nb.njit
def jitted_has_neighbors_in(point, visited, y_lim, x_lim, diffs):
    has_in = False
    has_out = False
    for d in diffs:
        y, x = point[0] + d[0], point[1] + d[1]
        # for y, x in neighbors(point, diagonals=True):
        v = visited[y - y_lim[0], x - x_lim[0]]
        if v == 2:
            has_in = True
        if v == 0:
            has_out = True
    return has_in, has_out


def get_boundary(points, offset=(0, 1)):
    x_min, y_min = np.inf, np.inf
    x_max, y_max = -np.inf, -np.inf
    for y, x in points:
        if y < y_min:
            y_min = y
        if y > y_max:
            y_max = y
        if x < x_min:
            x_min = x
        if x > x_max:
            x_max = x
    y_lim = int(y_min) - offset[0], int(y_max) + offset[1]
    x_lim = int(x_min) - offset[0], int(x_max) + offset[1]
    return y_lim, x_lim, y_lim[1] - y_lim[0], x_lim[1] - x_lim[0]


def is_a_path(points, closed=False):
    """Check if list of points forms a path, i.e. each point is next to the previous."""
    a, b = (points, points[1:] + points[:1]) if closed else (points[:-1], points[1:])
    for p0, p1 in zip(a, b):
        if not _is_neighbor(p0, p1):
            return False
    return True


def can_be_rearranged_into_a_path(points):
    """
    A path is a list of points, where each two consecutive points are neighbors.
    Determine, if the list of points is a concatenation of paths, i.e. if there exists
    a permutation of segments such that their concatenation becomes a path.
    """
    segments = _get_segments(points)
    # if not segments:  # points is already a path, nothing to rearrange
    #     return True
    if len(segments) > 8:  # computationally prohibitive
        return False
    traces = list(arrange_domino_pieces(segments, connected=_is_neighbor))
    return len(traces) > 0


def _get_segments(points):
    segments = []
    start = points[0]
    for p0, p1 in zip(points[:-1], points[1:]):
        if not _is_neighbor(p0, p1):
            segments.append((start, p0))
            start = p1
    segments.append((start, points[-1]))
    return segments


def _is_neighbor(p0, p1):
    return abs(p0[0] - p1[0]) <= 1 and abs(p0[1] - p1[1]) <= 1


def arrange_domino_pieces(pieces, trace=(), connected=lambda x, y: x == y):
    """
    For example, if pieces = [(4, 7), (9, 4), (9, 7)], then they can be arranged like a closed string of
    domino pieces: ((4, 7), (7, 9), (9, 4)), which will a yielded trace. Yields all ways to arrange them in a loop.
    """
    if not pieces:
        # check for closed-ness: the start have to be connected to the end
        if connected(trace[0][0], trace[-1][1]):
            yield trace
        return
    if not trace:
        yield from arrange_domino_pieces(pieces[1:], trace=(pieces[0],))
        return

    end_point = trace[-1][1]  # end point of last piece
    for k, piece in enumerate(pieces):
        if connected(end_point, piece[0]):
            yield from arrange_domino_pieces(pieces[:k] + pieces[k + 1 :], trace=trace + ((piece[0], piece[1]),))
        elif connected(end_point, piece[1]):
            yield from arrange_domino_pieces(pieces[:k] + pieces[k + 1 :], trace=trace + ((piece[1], piece[0]),))
