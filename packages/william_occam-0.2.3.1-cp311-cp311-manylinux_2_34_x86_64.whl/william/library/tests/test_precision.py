import numba as nb
import numpy as np
import pytest
from intnan import INTNAN64

from william.library.precision import (
    MAX_PRECISION,
    custom_round,
    first_decimal_precision,
    infer_precision,
    jprecision,
    recursive_match,
)

params = [
    (3.5, 0, True, 4.0),
    (3.5, 0, False, 3.0),
    (4.5, 0, True, 5.0),
    (4.5, 0, False, 4.0),
    (np.nan, -3, False, np.nan),
    (
        np.array([32.46, 52.175, -5.385, -6.5, np.nan, 2.174]),
        2,
        True,
        np.array([32.46, 52.18, -5.38, -6.5, np.nan, 2.17]),
    ),
    (
        np.array([32.46, 52.175, -5.385, -6.5, 2.174]),
        2,
        False,
        np.array([32.46, 52.17, -5.39, -6.5, 2.17]),
    ),
    (
        np.array([32.46, 52.175, -5.0, -135.0, 245.0]),
        -1,
        False,
        np.array([30.0, 50.0, -10.0, -140.0, 240.0]),
    ),
]


@pytest.mark.parametrize("x, precision, up, expected", params)
def test_custom_round(x, precision, up, expected):
    actual = custom_round(x, precision, round_halves_up=up)
    np.testing.assert_array_almost_equal(actual, expected)


params = [
    (0.0, 0),
    (0.00542, 5),
    (43.61873, 5),
    (-43.61873, 5),
    (-0.005423452, 9),
    (np.nan, -MAX_PRECISION),
    (INTNAN64, -MAX_PRECISION),
    (347.0, 0),
    (1200.0, -2),
    (1200, -2),
    (28300000, -5),
    (30, -1),
    (3e22, -22),
    (4e-22, 0),
    (1e-28, 0),
    # maximum precision over all numbers in the array
    (np.array([3.44589, -0.05, np.nan]), 5),
    (np.array([94000, INTNAN64, 130]), -1),
    (np.ones(100000) * 345.34, 2),
    (np.array([INTNAN64, INTNAN64]), -MAX_PRECISION),
    (np.array([np.nan, np.nan]), -MAX_PRECISION),
]


@pytest.mark.parametrize("number, prec", params, ids=range(len(params)))
def test_precision(number, prec):
    assert jprecision(number) == prec


@nb.njit
def jprec(x):
    return jprecision(x)


@pytest.mark.parametrize("number, prec", params, ids=range(len(params)))
def test_overload_precision(number, prec):
    assert jprec(number) == prec


params = [
    (0.052, 2),
    (0.1234987, 1),
    (0.00063234, 4),
    (543.74, -2),
    (5.6, 0),
    (np.nan, -MAX_PRECISION),
    (np.array([0.0076, np.nan, 0.017, 9.99]), 3),
    (np.array([np.nan, np.nan]), -MAX_PRECISION),
]


@pytest.mark.parametrize("x, precision", params)
def test_first_decimal_precision(x, precision):
    assert first_decimal_precision(x) == precision


params = [
    (lambda x, y: x + y, (12000, 34.5), 1, 12034.5),
    (lambda x, y: x * y, (12398.4, 1), -3, 12000.0),
    (lambda x, y: x * y, (0.01, 34.5), 1, 0.3),
    (
        np.mean,
        (
            np.array(
                [
                    144.496,
                    142.8106,
                    142.7838,
                    143.0217,
                    140.6155,
                    142.618,
                    142.9917,
                    141.9834,
                    142.3019,
                ]
            ),
        ),
        4,
        142.6247,
    ),
    (
        np.mean,
        (
            np.array(
                [
                    144.496,
                    142.811,
                    142.784,
                    143.022,
                    140.616,
                    142.618,
                    142.992,
                    141.983,
                    142.302,
                ]
            ),
        ),
        3,
        142.625,
    ),
    (
        lambda x, y: x + y,
        (np.array([5.26, 5.451, 5.116, 5.815, 5.712]), -5),
        3,
        np.array([0.26, 0.451, 0.116, 0.815, 0.712]),
    ),
]


@pytest.mark.parametrize("func, inputs, expected_precision, expected_result", params)
def test_infer_precision(func, inputs, expected_precision, expected_result):
    assert infer_precision(func, inputs) == expected_precision
    result = np.round(func(*inputs), expected_precision)
    assert np.all(result == expected_result)


params = [
    ((0,), (0.0,), True),
    ((0.0,), (1.0,), False),
    (np.array([1.0, 0.0, 1.0]), np.array([0.0, 0.0, 0.0]), False),
    (
        np.array([4.5, -3.4, 7.323, -6.78]),
        np.array([4.500357, np.nan, 7.3228974, -6.7797]),
        False,
    ),
    (
        np.array([4.5, np.nan, 7.323, -6.78]),
        np.array([4.500357, -3.4, 7.3228974, -6.7797]),
        True,
    ),
    (np.array([np.nan, np.nan]), np.array([np.nan, np.nan]), True),
    (np.array([4.500357, 7.3228974, -6.7797]), np.array([4.5, 7.323, -6.78]), False),
    (np.array([4.5, 7.323, -6.78]), np.array([4.51, 7.3228974, -6.77]), False),
    (np.array([-14.7432, 14.0687]), np.array([-14.74315, 14.06875]), True),
    ([4.5, 7.323, -6.78], [4.51, 7.3228974, -6.784], True),
    (np.array([3, 65]), np.array([3, 65]), True),
    (np.array([INTNAN64, INTNAN64]), np.array([INTNAN64, INTNAN64]), True),
    (np.array([3, INTNAN64]), np.array([3, 65]), True),
    (np.array([3, INTNAN64]), np.array([3, INTNAN64]), True),
    (np.array([3, 65]), np.array([3, INTNAN64]), False),
    (np.array(["asdf", "fdsa"]), np.array(["asdf", "fdsa"]), True),
]


@pytest.mark.parametrize("a, b, match", params)
def test_recursive_match(a, b, match):
    assert recursive_match(a, b) == match
