import typing as tp
from itertools import chain, islice, product

import numpy as np
import pytest
from intnan import INTNAN64
from typing_inspect import is_tuple_type

from william.library import library
from william.library.base import Value
from william.library.basic_ops import (
    Add,
    BRange,
    Concat,
    Equal,
    GetItem,
    IfElse,
    Len,
    LessThan,
    Map,
    Mult,
    Not,
    Reduce,
    Repeat,
    SetItem,
)
from william.library.complex_ops import (
    And,
    BMap,
    BoolZeros,
    CumOp,
    CumSum,
    CumSum2,
    Diff,
    Div,
    Dot,
    Full,
    Insert,
    Join,
    ListSlice,
    Or,
    Power,
    Shape,
    StrToList,
    Sub,
    Sum,
    Table,
    ToFloat,
    ToInt,
    TRange,
    Transpose,
    Union,
    URange,
    Xor,
    Zip2D,
)
from william.library.functions import join_inputs
from william.library.precision import recursive_match
from william.library.types import Array, get_typevars, issubspec, typereplace

throwing = [
    (GetItem, ([], 2), IndexError),
    (Div, (5.0, 0), ZeroDivisionError),
]


@pytest.mark.parametrize(["op_class", "input_args", "exc"], throwing)
def test_exceptions(op_class, input_args, exc):
    op = op_class()
    with pytest.raises(exc):
        op._call(*input_args)


calculations = [
    (Shape, (np.array([[7.8, 3.4]]),), (1, 2), True),
    (Full, ((2, 4), 3.0), np.ones((2, 4)) * 3.0, True),
    (Full, ((4,), np.nan), np.ones(4) * np.nan, True),
    (Not, (False,), True, True),
    (Not, (True,), False, True),
    (Not, (np.array([True, False]),), np.array([False, True]), True),
    (Transpose, (np.array([7.8, 3.4]),), np.array([7.8, 3.4]), True),
    (Transpose, (np.array([[7.8, 3.4]]),), np.array([[7.8], [3.4]]), True),
    (Transpose, (np.array([[4, 5, 6], [1, 2, 3]]),), np.array([[4, 1], [5, 2], [6, 3]]), True),
    (Len, (np.array([4, 5, 6]),), 3, True),
    (BoolZeros, (5,), np.array([False, False, False, False, False]), True),
    (StrToList, ((1,),), [1], True),
    (StrToList, (["b", "a"],), ["b", "a"], True),
    (ToInt, (7.8,), 7, True),
    (ToInt, (np.array([7.8, 3.4]),), np.array([7, 3]), True),
    (ToInt, (np.array(["45", "-76"]),), np.array([45, -76]), True),
    (ToFloat, (7,), 7.0, True),
    (ToFloat, (np.array([7, 3]),), np.array([7.0, 3.0]), True),
    (ToFloat, (np.array(["45.34", "-76.65"]),), np.array([45.34, -76.65]), True),
    (Add, (1, 2), 3, True),
    (Add, (np.array([5.6, 1.3]), np.array([3.4, 5.9])), np.array([9.0, 7.2]), True),
    (Add, (1.3, np.array([3.4, 5.9])), np.array([4.7, 7.2]), True),
    (Add, (np.array([3.4, 5.9]), 1.3), np.array([4.7, 7.2]), True),
    (Sub, (5, 8), -3, True),
    (Sub, (5, 3.5), 1.5, True),
    (Mult, (0, 1), 0, True),
    (Mult, (np.array([5.6, 1.3]), np.array([3.4, 5.9])), np.array([19.04, 7.67]), True),
    (Mult, (5.6, np.array([3.4, 5.9])), np.array([19.04, 33.04]), True),
    (Mult, (np.array([3.4, 5.9]), 5.6), np.array([19.04, 33.04]), True),
    (Div, (5, 2), 2.5, True),
    (Div, (1.0, 2.0), 0.5, True),
    (Concat, ([4, 3], [9]), [4, 3, 9], True),
    (Concat, (np.array([4, 3]), np.array([9])), np.array([4, 3, 9]), True),
    (Concat, ("Arthur", " Eddington"), "Arthur Eddington", True),
    (Union, ({4, 5}, {5, 7}), {4, 5, 7}, True),
    (Repeat, (False, ["hello", "world"]), [], True),
    (Repeat, (True, ["ababagalamaga"]), ["ababagalamaga"], True),
    (Dot, (np.array([5.6, 1.3]), np.array([13.4, 0.9])), 76.21, True),
    (
        Dot,
        (np.array([5.6, 1.3, -4.1]), np.array([[13.4, 0.9], [3.5, -5.6], [-8.9, 15.56]])),
        np.array([116.08, -66.036]),
        True,
    ),
    (LessThan, (5, 2), False, True),
    (LessThan, (5.4, 9.1), True, True),
    (LessThan, (np.array([5.6, 1.3]), np.array([13.4, 0.9])), np.array([True, False]), True),
    (LessThan, (np.array([5.6, 1.3]), 1.6), np.array([False, True]), True),
    (Equal, (5.6, 5.6), True, True),
    (Equal, (np.array([5.6, 6.7]), np.array([5.6, 8.7])), np.array([True, False]), True),
    (And, (True, True), True, True),
    (And, (True, False), True, False),
    (Or, (False, True), True, True),
    (Or, (False, False), True, False),
    (
        Xor,
        (np.array([True, False, True, False]), np.array([False, True, True, False])),
        np.array([True, True, False, False]),
        True,
    ),
    (GetItem, ([3, 5, 2], 1), 5, True),
    (GetItem, (np.array([3, 5, 2]), np.array([True, False, True])), np.array([3, 2]), True),
    (
        GetItem,
        (np.array(["ab", "cde", "fghj"]), np.array([True, False, True])),
        np.array(["ab", "fghj"]),
        True,
    ),
    (SetItem, ([342, 6, 8, 252], 3, 78), [342, 6, 8, 78], True),
    (
        SetItem,
        (np.array([342, 6, 8, 252]), np.array([False, True, True, False]), np.array([78, 34])),
        np.array([342, 78, 34, 252]),
        True,
    ),
    (SetItem, (["-", "-", "-", "-", "-"], 4, "x"), ["-", "-", "-", "-", "x"], True),
    (ListSlice, ([7, 2, 5, -1, 6, 17], 1, 5), [2, 5, -1, 6], True),
    (Join, (["ab", "cde"],), "abcde", True),
    (IfElse, (True, "gargantua", "pantagruel"), "gargantua", True),
    (IfElse, (False, "gargantua", "pantagruel"), "pantagruel", True),
    (URange, (10,), np.arange(10), True),
    (BRange, (1, 10), np.arange(1, 10), True),
    (TRange, (1, 10, 3), np.arange(1, 10, 3), True),
    (CumSum, (np.arange(5),), np.array([0, 1, 3, 6, 10]), True),
    (CumSum, (np.arange(5),), np.array([0, 1, 3, 6, 11]), False),
    (CumSum2, (3, np.array([5, 7, 10])), np.array([3, 8, 15, 25]), True),
    (Diff, (np.array([0, 1, 3, 6, 10]),), np.arange(5), True),
    (Diff, (np.array([0, 1, 3, 6, 11]),), np.arange(5), False),
    (Map, (lambda x: x**2, np.array([3, 2, -1, 0])), np.array([9, 4, 1, 0]), True),
    # fails when using the quick map implementation, yields 'array([42])' instead of array['42'])
    # (Map, (str, np.array([42])), np.array(["42"]), True),
    # (Map, (id, np.array([])), np.array([]), True),
    (Map, (lambda x: x > 3, np.array([2, 3, -5, 4])), np.array([False, False, False, True]), True),
    (BMap, (lambda x, y: x * y, [6, 5, 2], [7, 3, 4]), [42, 15, 8], True),
    (BMap, (Add(), [68, 3], [-3, 2]), [65, 5], True),
    (BMap, (Add(), (8, 13), (-5, 22)), (3, 35), True),
    (CumOp, (lambda x, y: x * y, 1, [2, 5, -3, 4]), [1, 2, 10, -30, -120], True),
    (Reduce, (lambda x, y: x * y, [2, 5, -3, 4]), -120, True),
    (Sum, ([2, 4, 8],), 14, True),
    (Power, (5, 2), 25, True),
    (Power, (5.0, 2), 25.0, True),
    (Power, (2, [0, 1, 2, 3]), [1, 2, 4, 8], True),
    (Power, (2.0, [0, 1, 2, 3]), [1.0, 2.0, 4.0, 8.0], True),
    (Insert, ([1, 3], [33, 44], [1, 2, 3, 4]), [1, 33, 2, 44, 3, 4], True),
    (Insert, ([1, 3], 33, [1, 2, 3, 4]), [1, 33, 2, 33, 3, 4], True),
    (Insert, ([1, 3], [0.55, 0.66], [1.0, 2.0, 3.0, 4.0]), [1.0, 0.55, 2.0, 0.66, 3.0, 4.0], True),
    (
        Insert,
        ([1, 3], ["k", "m"], ["a", "b", "c", "d", "e"]),
        ["a", "k", "b", "m", "c", "d", "e"],
        True,
    ),
    (
        Insert,
        ([1, 3], "AB", ["a", "b", "c", "d", "e"]),
        ["a", "AB", "b", "AB", "c", "d", "e"],
        True,
    ),
    (Insert, ([1, 3], "AB", "abcde"), "aAbBcde", True),
    (Insert, ([1, 3, 5], "A", "abcde"), "aAbAcAde", True),
    (Insert, ([1, 3], True, [False] * 5), [False, True, False, True, False, False, False], True),
    (Insert, ([0, 0], 0, [3, 4, 5]), [0, 3, 4, 5], True),
    (
        Zip2D,
        ([1, 2, 3, 4, 5], [10, 20, 30, 40, 50]),
        [(1, 10), (2, 20), (3, 30), (4, 40), (5, 50)],
        True,
    ),
    (Zip2D, ([1, 2, 3, 4, 5], [10, 20, 30, 40, 50]), [(1, 10), (2, 20), (3, 30), (4, 40)], False),
    (
        Zip2D,
        ([1, 2, 3, 4, 5], ["a", "b", "c", "d", "e"]),
        [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")],
        True,
    ),
    (Zip2D, ([0.0, 1.0, 2.0], [10, 20, 30]), [(0.0, 10), (1.0, 20), (2.0, 30)], True),
    (Table, ([67, 113, 189, 278], [0, 2, 1, 1, 3, 3, 2]), [67, 189, 113, 113, 278, 278, 189], True),
    (Table, ([100], [0, 0, 0, 0]), [100, 100, 100, 100], True),
]


@pytest.mark.parametrize(["op_class", "input_args", "probe", "match"], calculations)
def test_calculations(op_class, input_args, probe, match):
    input_args = tuple([Value(i) for i in input_args])
    result = op_class()(*input_args).value
    assert recursive_match(result, probe) == match


_rng = np.random.default_rng(42)


def _call_data(spec, samples=10):
    type_vars = list(get_typevars(spec))
    if type_vars:
        data = []
        for repl_type in (int, float, str):
            repl = {tv: repl_type for tv in type_vars}
            data.append(_call_data(typereplace(spec, repl)))
        return chain(*data)
    if is_tuple_type(spec):
        return product(*(_call_data(arg) for arg in spec.__args__))
    if spec == int:
        return [x - 5 for x in range(samples)]
    if spec == float:
        return [(x - 5) / 1.0 for x in range(samples)]
    if spec == str:
        return [chr(x + 65) for x in range(samples)]
    if spec == bool:
        return [False, True]
    if spec == slice:
        return [slice(0, 3, 1), slice(0, -1, 1), slice(7), slice(5, 8), slice(12, 4, -2)]
    if spec == type(None):
        return [None]
    if spec == list[int]:
        return (
            [list(np.arange(x)) for x in range(samples)]
            + [list(np.arange(-x, x)) for x in range(samples)]
            + [list(np.arange(x, -x, -2)) for x in range(samples)]
        )
    if spec == set[int]:
        return (
            [set(list(np.arange(x))) for x in range(samples)]
            + [set(list(np.arange(-x, x))) for x in range(samples)]
            + [set(list(np.arange(x, -x, -2))) for x in range(samples)]
        )
    if spec == list[str]:
        return [[str(x) for x in range(y)] for y in range(samples)]
    if spec == set[str]:
        return [set([str(x) for x in range(y)]) for y in range(samples)]
    if spec == list[float]:
        return [[-1.0, 0.0, 1.0, 5.0]]
    if spec == set[float]:
        return [{-1.0, 0.0, 1.0, 5.0}]
    if spec == Array[float]:
        return [np.round(_rng.random(5), 3) for _ in range(3)] + [np.round(_rng.random((5, 3)), 3) for _ in range(3)]
    if spec == Array[bool]:
        return [_rng.random(5) > 0.5 for _ in range(3)]
    if spec == Array[int]:
        return [_rng.integers(1000, size=5) - 500 for _ in range(3)]
    if issubspec(spec, tp.Callable):
        return []
    raise TypeError(f"Unhandled type spec: {spec}")


def _clean_slice(sl):
    start = 0 if sl.start is None else sl.start
    step = 1 if sl.step is None else sl.step
    return slice(start, sl.stop, step)


@pytest.mark.parametrize("afunc", sorted(library, key=str), ids=lambda x: type(x).__name__)
def test_inverse(afunc):
    inv_data = []

    for cond in afunc.conditions:
        for spec in afunc.specs:
            inv_spec = afunc.inv_specs(spec, cond)
            try:
                test_data = _call_data(inv_spec)
            except TypeError:
                pytest.skip("CallSpec data dummy not implemented.")
            else:
                inv_data.append((cond, test_data))
    for cond, data in inv_data:
        for item in data:
            output, cond_inputs = item[0], item[1:]
            if not afunc._suitable(output):
                continue

            for value in islice(afunc._inverse(output, cond_inputs, cond), 1000):
                inputs = join_inputs(cond, cond_inputs, value)
                try:
                    result = afunc._call(*inputs)
                except (ZeroDivisionError, IndexError, ValueError):
                    continue
                assert recursive_match(output, result) or recursive_match(result, output), "Inverse function error"


params = [
    # func     output                              cond_inputs        cond    expected
    (Power(), 16, (4,), (1,), [(2,)]),
    (Power(), 16.0, (2,), (1,), [(4.0,)]),
    (Power(), 8, (2,), (0,), [(3,)]),
    (Power(), 1, (2,), (0,), [(0,)]),
    (Power(), 32.0, (2.0,), (0,), [(5,)]),
    # output is None or empty
    (Power(), None, ([1, 2, 3, 4],), (1,), []),
    (Power(), [], ([1, 2, 3, 4],), (1,), []),
    # output has unknown type (str)
    (Power(), [2, "a", 8, 16], ([1, 2, 3, 4],), (1,), []),
    # output=0, impossible to invert x^y=0
    (Power(), [0, 4, 8, 16], ([1, 2, 3, 4],), (1,), []),
    # power is float value
    (Power(), [9], (2,), (0,), []),
    # cond_inputs=0
    (Power(), [2], ([0],), (1,), []),
    (Power(), [2], ([0],), (0,), []),
    # output=1, impossible to invert x^y=1
    (Power(), [1], ([4],), (1,), []),
    # result !=output - precision
    (Power(), [2.0], ([-4],), (1,), []),
    # result is float value, but should be int because output is int
    (Power(), [7], ([3],), (1,), []),
    # len(output) != len(cond_inputs) cond=(1,)
    (Power(), [2, 4, 8, 16], ([1, 2],), (1,), []),
    # no condition
    (Power(), [2, 4, 8, 16], ([1, 2, 3, 4],), (), []),
    (Insert(), [2, 3, 4, 2, 3, 2, 4, 1], (3,), (1,), [(np.array([1, 4]), [2, 4, 2, 2, 4, 1])]),
    # (Insert(), [2, 3, 4, 2, 3, 2, 4, 1], ([2, 3, 2, 1],), (2,), [([0, 1, 2, 6], [2, 3, 4, 4])]),
    # (Insert(), [2, 3, 4, 2, 3, 2, 4, 1], ([],), (2,), [(list(np.arange(8)), [2, 3, 4, 2, 3, 2, 4, 1])]),
    (Insert(), [1.0, 2.0, 3.0, 2.0, 5.0], (2.0,), (1,), [(np.array([1, 3]), [1.0, 3.0, 5.0])]),
    # (
    #     Insert(),
    #     [1.0, 2.0, 3.0, 3.0, 3.0],
    #     ([3.0, 3.0, 3.0],),
    #     (2,),
    #     [
    #         (
    #             [0, 1],
    #             [
    #                 1.0,
    #                 2.0,
    #             ],
    #         )
    #     ],
    # ),
    (
        Insert(),
        ["aa", "bb", "cc", "dd", "ee"],
        ([0, 2],),
        (0,),
        [(["aa", "cc"], ["bb", "dd", "ee"])],
    ),
    (Insert(), ["abc", "dd", "ee", "abc", "ff"], ("abc",), (1,), [(np.array([0, 3]), ["dd", "ee", "ff"])]),
    # (
    #     Insert(),
    #     ["aa", "bb", "cc", "dd", "ee", "ff"],
    #     (["cc", "ee", "ff"],),
    #     (2,),
    #     [([0, 1, 3], ["aa", "bb", "dd"])],
    # ),
    (Insert(), "abcdefg", ([1, 2, 3],), (0,), [("bcd", "aefg")]),
    (Insert(), "abcdefg", ("bcf",), (1,), [([1, 2, 5], "adeg")]),
    (Insert(), "abcdbbefg", ("b",), (1,), [([4, 5, 1], "acdefg")]),
    # (Insert(), "abcdefg", ("cdfg",), (2,), [([0, 1, 4], "abe")]),
    # (Insert(), "abcdefg", ("",), (2,), [(list(np.arange(7)), "abcdefg")]),
    # TODO Uncomment in case operators could yield empty lists
    # ([2, 3, 4, 2, 3, 2, 4, 1],           ([],),                       (0,),   [([], [2, 3, 4, 2, 3, 2, 4, 1])]),
    # ([2, 3, 4, 2, 3, 2, 4, 1],           ([],),                       (1,),   [([], [2, 3, 4, 2, 3, 2, 4, 1])]),
    # ([2, 3, 4, 2, 3, 2, 4, 1],           ([2, 3, 4, 2, 3, 2, 4, 1],), (2,),   [([], [])]),
    # ([1.0, 2.0, 3.0, 4.0, 5.0],          ([],),                       (0,),   [([], [1.0, 2.0, 3.0, 4.0, 5.0])]),
    # ('abcdefg',                          ([],),                       (0,),   [('', 'abcdefg')]),
    # ('abcdefg',                          ('abcdefg',),                (2,),   [([], '')])
    # len(indices) > len(output)
]

output_int = [2, 3, 4, 2, 3, 2, 4, 1]
output_str = "abcdefgh"


params += [
    # func     output         cond_inputs                        cond    expected
    (Insert(), output_int, (np.arange(len(output_int) + 1),), (0,), []),
    (Insert(), output_str, (np.arange(len(output_str) + 1),), (0,), []),
    # indices are not unique
    (Insert(), output_int, ([0, 0, 1, 2, 3],), (0,), []),
    (Insert(), output_str, ([0, 0, 1, 2, 3],), (0,), []),
    # index out of output range
    (Insert(), output_int, ([0, 1, 2, len(output_int) + 1],), (0,), []),
    (Insert(), output_str, ([0, 1, 2, len(output_str) + 1],), (0,), []),
    # content doesn't match to the output
    (Insert(), output_int, ([2, 3, 4, 3, 3],), (1,), []),
    (Insert(), output_int, (100,), (1,), []),
    (Insert(), output_str, ("cdc",), (1,), []),
    (Insert(), output_str, ("m",), (1,), []),
    # len(output) < len(content)
    (Insert(), output_int, (output_int + [3],), (1,), []),
    (Insert(), output_str, (output_str + "m",), (1,), []),
    (Full(), np.ones((2, 4)) * np.nan, (), (), [((2, 4), np.nan)]),
    (Full(), np.ones(3) * np.inf, (), (), [((3,), np.inf)]),
    (Full(), np.array([3, 2, 1]), (), (), []),
    (BoolZeros(), np.zeros(5, dtype=bool), (), (), [(5,)]),
    (ToInt(), 7, (), (), [(7.0,), ("7",)]),
    (ToInt(), np.array([7, 3]), (), (), [(np.array([7.0, 3.0]),), (np.array(["7", "3"]),)]),
    (
        ToInt(),
        np.array([0, 1]),
        (),
        (),
        [(np.array([0.0, 1.0]),), (np.array(["0", "1"]),), (np.array([False, True]),)],
    ),
    (ToFloat(), 7.0, (), (), [(7,), ("7.0",)]),
    (ToFloat(), np.array([7.0, 3.0]), (), (), [(np.array([7, 3]),), (np.array(["7.0", "3.0"]),)]),
    (
        ToFloat(),
        np.array([0.0, 1.0]),
        (),
        (),
        [(np.array([0, 1]),), (np.array(["0.0", "1.0"]),), (np.array([False, True]),)],
    ),
    (Equal(), True, ([1, 3],), (0,), [([1, 3],)]),
    (Equal(), np.array([True, False]), (np.array([5.6, 6.7]),), (1,), []),
    (Equal(), np.array([True, True]), (np.array([5.6, 6.7]),), (1,), [(np.array([5.6, 6.7]),)]),
    # demonstration of how the dl of the error decreases as the estimate improves
    (Add(), 143.6, (10.3142,), (0,), [(133.3,)]),
    (Add(), 143.6, (100.79348,), (0,), [(42.8,)]),
    (Add(), 143.6, (143.3234,), (0,), [(0.3,)]),
    (Add(), 143.6, (143.578,), (0,), [(0,)]),
    (
        Add(),
        np.array([143.6, 140.7, 142.5]),
        (41.878234,),
        (1,),
        [(np.array([101.7, 98.8, 100.6]),)],
    ),
    (Add(), np.array([143.6, 140.7, 142.5]), (141.878234,), (1,), [(np.array([1.7, -1.2, 0.6]),)]),
    (Add(), 1200.0, (1158.0,), (0,), [(0,)]),  # adapts to output precision
    (Add(), 1200.0, (1128.0,), (0,), [(100,)]),  # adapts to output precision
    (Add(), np.array([1.0, 2.0]), (np.array([np.nan, 0.5]),), (0,), []),
    (
        Add(),
        np.array([-1, 1, 3, 1, -5, 3, 1, 1, -3]),
        (np.array([-1.5, 4.5, 4.5, -2.5, 3.5, -2.5, 4.5, 2.5, 4.5]),),
        (0,),
        [(np.array([0.0, -4.0, -2.0, 3.0, -9.0, 5.0, -4.0, -2.0, -8.0]),)],
    ),
    (Sub(), 10.0, (9.0,), (0,), [(0.0,)]),
    (Sub(), 10.5, (5.46,), (0,), [(-5.0,)]),
    (Sub(), 11.0, (9.7,), (0,), [(-1,)]),
    (
        Sub(),
        np.array([11.0, 12.32, 13.3256]),
        (np.array([9.7, 12.32983, 23.4]),),
        (0,),
        [(np.array([-1.3, 0.0098, 10.0744]),)],
    ),
    (Mult(), 1200.0, (125.0,), (0,), [(9.6,)]),
    (Mult(), 1200.0, (131.0,), (0,), [(9.2,)]),
    (Mult(), 981.55, (1e9,), (0,), []),  # exceeds MAX_PRECISION
    (Mult(), np.array([1200.0, 45.0]), (1e11,), (1,), []),  # exceeds MAX_PRECISION
    (
        Mult(),
        np.array([1200.0, 450.0, 987.0]),
        (np.array([131.0, 56.0, 0.1]),),
        (0,),
        [(np.array([9.16, 8.036, 9870.0]),)],
    ),
    (
        Mult(),
        np.array([1200.0, 450.0, 987.0]),
        (340.56,),
        (1,),
        [(np.array([3.524, 1.321, 2.898]),)],
    ),
    (Mult(), 130.0, (0.00053,), (0,), [(250000.0,)]),
    (Div(), 130.0, (100.5324,), (0,), [(0.77,)]),
    (Div(), 130000.0, (2010.5,), (0,), [(0.015,)]),
    (Div(), 0.234, (0.00009345,), (0,), [(0.000399,)]),
    (Div(), 130.0, (100.5324,), (1,), [(13000,)]),
    (Div(), 130000.0, (2010.5,), (1,), [(260000000,)]),
    (Div(), 0.234, (0.00009345,), (1,), [(2.187e-05,)]),
    (
        Div(),
        np.array([1200.0, 450.0, 987.0]),
        (np.array([131.0, 56.0, 0.1]),),
        (0,),
        [(np.array([0.1091667, 0.1244444, 0.0001013]),)],
    ),
    (
        Div(),
        np.array([1200.0, 450.0, 987.0]),
        (340.56,),
        (1,),
        [(np.array([408700.0, 153300.0, 336100.0]),)],
    ),
    (
        GetItem(),
        np.array([2.0, 3.0]),
        (np.array([True, False, False, True]),),
        (1,),
        [(np.array([2.0, np.nan, np.nan, 3.0]),)],
    ),
    (SetItem(), [342, 6, 8, 78], ([342, 6, 8, 252],), (0,), [(3, 78)]),
    (
        SetItem(),
        np.array([342, 6, 8, 78]),
        (np.array([17, 6, 8, 252]),),
        (0,),
        [(np.array([0, 3]), np.array([342, 78]))],
    ),
    (
        SetItem(),
        np.array([342.0, 78.0, 34.0, 252.0]),
        (np.array([False, True, True, False]),),
        (1,),
        [(np.array([342.0, np.nan, np.nan, 252.0]), np.array([78.0, 34.0]))],
    ),
    (
        SetItem(),
        np.array([342, 78, 34, 252]),
        (np.array([False, True, True, False]),),
        (1,),
        [(np.array([342, INTNAN64, INTNAN64, 252]), np.array([78, 34]))],
    ),
    (
        SetItem(),
        np.array([342.0, 78.0, 34.0, 252.0]),
        (np.array([1, 2]),),
        (1,),
        [(np.array([342.0, np.nan, np.nan, 252.0]), np.array([78.0, 34.0]))],
    ),
    (SetItem(), ["-", "-", "-", "-", "x"], (["-", "-", "-", "-", "-"],), (0,), [(4, "x")]),
    (
        SetItem(),
        ["-", "-", "-", "-", "x"],
        (4,),
        (1,),
        [(["-", "-", "-", "-", ""], "x")],
    ),  # '*' is the NaN of str
    (TRange(), np.array([10, 15, 20, 25, 30]), (), (), [(10, 35, 5)]),
    (Concat(), [6, 7, 8, 9, 10], ([6, 7],), (0,), [([8, 9, 10],)]),
    (Concat(), [6, 7, 8, 9, 10], ([9, 10],), (1,), [([6, 7, 8],)]),
    (Concat(), [6, 7, 8, 9, 10], ([6, 7, 8, 9, 10],), (0,), [([],)]),
    (Concat(), [6, 7, 8, 9, 10], ([6, 7, 8, 9, 10],), (1,), [([],)]),
    (Repeat(), [], (8,), (0,), [([],)]),
    (Repeat(), [], (0,), (0,), [([],)]),
    (Repeat(), [3, 4, 8], (1,), (0,), [([3, 4, 8],)]),
    (Repeat(), [3, 4, 8], ([3, 4, 8],), (1,), [(1,)]),
    (Repeat(), [], ([],), (1,), []),
    (Repeat(), [], ([3, 4],), (1,), [(0,)]),
    (Repeat(), [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1], (8,), (0,), [([0, 1],)]),
    (Repeat(), [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1], ([0, 1],), (1,), [(8,)]),
    (Repeat(), "11111111111111", (14,), (0,), [("1",)]),
    (Repeat(), [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1], (), (), [(8, [0, 1])]),
    (Repeat(), "11111111111111", (), (), [(14, "1")]),
    (
        Join(),
        "asddflklknaf",
        (),
        (),
        [(["a", "s", "d", "d", "f", "l", "k", "l", "k", "n", "a", "f"],)],
    ),
    (Zip2D(), [(1, 10), (2, 20), (3, 30)], (), (), [([1, 2, 3], [10, 20, 30])]),
    (
        Zip2D(),
        [(1, "a"), (2, "b"), (3, "c"), (4, "d"), (5, "e")],
        (),
        (),
        [([1, 2, 3, 4, 5], ["a", "b", "c", "d", "e"])],
    ),
    (Zip2D(), [(0.0, 10), (1.0, 20), (2.0, 30)], (), (), [([0.0, 1.0, 2.0], [10, 20, 30])]),
    (Zip2D(), [], (), (), []),
    (Zip2D(), [(), (), ()], (), (), []),
    (Zip2D(), [(1, 2, 3), (1, 2, 3), ()], (), (), []),
    (Zip2D(), [(1, 2, 3), (), (1, 2, 3)], (), (), []),
    (Zip2D(), [(1, 2, 3), (1, 2, 3), ()], (), (), []),
    (Zip2D(), [(1, 2), (1, 2, 3), (1, 2, 3)], (), (), []),
    (Zip2D(), [(1, 2, 3), (1, 2, 3, 4, 5), (1, 2, 3)], (), (), []),
    (
        Table(),
        [67, 189, 113, 113, 278, 278, 189],
        (),
        (),
        [([67, 113, 189, 278], [0, 2, 1, 1, 3, 3, 2])],
    ),
    (Table(), [113, 113, 113, 113], (), (), [([113], [0, 0, 0, 0])]),
    (
        Table(),
        [100, 101, 102, 103, 104, 105],
        (),
        (),
        [([100, 101, 102, 103, 104, 105], [0, 1, 2, 3, 4, 5])],
    ),
    (Table(), [], (), (), []),
]


@pytest.mark.parametrize("func, output, cond_inputs, cond, expected", params, ids=lambda x: type(x).__name__)
def test_explicit_inverse(func, output, cond_inputs, cond, expected):
    _test_explicit_inverse(func, output, cond_inputs, cond, expected)


def _test_explicit_inverse(func, output, cond_inputs, cond, expected):
    #  Have this separate, so it can get imported for other tests
    if not func._suitable(output):
        assert expected == []
        return
    actual = list(func._inverse(output, cond_inputs, cond))
    assert len(actual) == len(expected)
    for ex, ac in zip(expected, actual):
        assert len(ex) == len(ac)
        assert recursive_match(ex, ac)
        full_inputs = join_inputs(cond, cond_inputs, ac)
        try:
            result = func._call(*full_inputs)
        except ValueError as e:
            if str(e) == "This operator should not be called.":
                continue
            raise e
        assert recursive_match(output, result)
