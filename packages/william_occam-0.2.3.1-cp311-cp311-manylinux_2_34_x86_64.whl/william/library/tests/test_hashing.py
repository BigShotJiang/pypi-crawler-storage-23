import random
import string
from dataclasses import dataclass
from typing import Any

import numpy as np
import numpy.typing as npt
import pytest

from william.library.hashing import get_stable_key, sort_anything, unique_hash


def assert_equal_recursive(actual: Any, expected: Any) -> None:
    """Recursively checks equality, handling NumPy arrays and exact types."""
    assert type(actual) is type(expected), f"Type mismatch: {type(actual)} != {type(expected)}"

    if isinstance(actual, np.ndarray):
        assert np.array_equal(actual, expected), f"Array mismatch: {actual} != {expected}"
        assert actual.dtype.kind == expected.dtype.kind
    elif isinstance(actual, (list, tuple)):
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected):
            assert_equal_recursive(a, e)
    elif isinstance(actual, dict):
        assert len(actual) == len(expected)
        for k in actual:
            assert k in expected
            assert_equal_recursive(actual[k], expected[k])
    elif isinstance(actual, (set, frozenset)):
        # Sets are tricky if they contain unhashable-like keyed items,
        # but for these tests, simple equality or length + element check suffices.
        assert actual == expected
    else:
        assert actual == expected


@pytest.mark.parametrize(
    "test_input, expected_order",
    [
        # Content over Type: (1,1) < (1,2) < [1,2]
        ([(1, 2), (1, 1), [1, 2]], [(1, 1), (1, 2), [1, 2]]),
        # Mixed Scalars & Empty: None < 10 < 'z' < () < [] < {}
        ([{}, 10, [], "z", None, ()], [None, 10, "z", (), [], {}]),
        # NumPy stability: Array([1, 2]) content is smaller than List([1, 3])
        (
            [np.array([1, 2]), [1, 3], (1, 2)],
            [(1, 2), np.array([1, 2]), [1, 3]],
        ),
        # Deeply nested: 5 < [1, 2] < [{"a": 1}, 2]
        ([[{"a": 1}, 2], [1, 2], 5], [5, [1, 2], [{"a": 1}, 2]]),
        # Booleans vs Integers (False < True < 0 < 1)
        ([1, True, 0, False], [False, True, 0, 1]),
        # Deep recursion: [[[100]]] < [[[{'a': 1}]]]
        ([[[{"a": 1}]], [[100]]], [[[100]], [[{"a": 1}]]]),
        # Deep Nesting: Key comparison stops at 'a': 10 vs 20
        (
            [
                {"level1": [{"level2": {"a": 20}}]},
                {"level1": [{"level2": {"a": 10}}]},
            ],
            [
                {"level1": [{"level2": {"a": 10}}]},
                {"level1": [{"level2": {"a": 20}}]},
            ],
        ),
        # List vs Set: Content (1, 2) is identical.
        # Type Order: List (7) < Set (8).
        (
            [
                {"ids": {1, 2, 3}},
                {"ids": {1, 2}},
                {"ids": [1, 2]},
            ],
            [
                {"ids": [1, 2]},  # Content (1, 2), List (7)
                {"ids": {1, 2}},  # Content (1, 2), Set (8)
                {"ids": {1, 2, 3}},  # Content (1, 2, 3), Set (8)
            ],
        ),
        # Numeric Types: Int (2) < Float (3) < Str (4)
        (
            [[[100]], [["a"]], [[1.5]]],
            [[[100]], [[1.5]], [["a"]]],
        ),
        # Complex Dict Keys: Frozenset (9) keys are stable
        (
            [
                {frozenset({3, 4}): "second"},
                {frozenset({1, 2}): "first"},
            ],
            [
                {frozenset({1, 2}): "first"},
                {frozenset({3, 4}): "second"},
            ],
        ),
        # Length/Content: [1, 2] < [1, 2, 3]
        (
            [
                {"a": [1, 2, 3]},
                {"a": [1, 2]},
            ],
            [
                {"a": [1, 2]},
                {"a": [1, 2, 3]},
            ],
        ),
        # Direct Depth: [1] (Scalar inside) vs [[1]] (Collection inside)
        (
            [[[1]], [1]],
            [[1], [[1]]],
            # Reason: [1] contains (group 0, ...), [[1]] contains (group 1, ...)
        ),
        # Asymmetric Nesting in Dicts
        (
            [{"key": [[1]]}, {"key": [1]}, {"key": 1}],
            [
                {"key": 1},  # Scalar (group 0)
                {"key": [1]},  # List containing Scalar (group 1, content with group 0)
                {"key": [[1]]},  # List containing List (group 1, content with group 1)
            ],
        ),
        # Multiple paths with different branching
        (
            [[1, [2, 3]], [1, 2, 3], [1, 2]],
            [
                [1, 2],  # Shorter
                [1, 2, 3],  # Longer, but same level
                [1, [2, 3]],  # Deeper at index 1
            ],
        ),
    ],
)
def test_sort_anything(test_input, expected_order):
    """Unified test for order, type-safety and content adjacency."""
    result = sort_anything(test_input)
    assert len(result) == len(expected_order)

    for r, e in zip(result, expected_order):
        assert_equal_recursive(r, e)


@dataclass(slots=True)
class SlottedNode:
    name: str
    value: int


class RegularNode:
    def __init__(self, name: str, value: int) -> None:
        self.name = name
        self.value = value


def test_class_differentiation():
    """Verifies that slotted and regular classes are grouped separately."""
    s_node = SlottedNode("test", 1)
    r_node = RegularNode("test", 1)

    key_s = get_stable_key(s_node)
    key_r = get_stable_key(r_node)

    # Order 98 for slots, 99 for dict
    assert key_s[2] == 98
    assert key_r[2] == 99
    assert key_s != key_r


def test_slice_stability():
    """Verifies that slices can be sorted and hashed."""
    s1 = slice(0, 10, 1)
    s2 = slice(0, 10, 2)
    s3 = slice(1, 10, 1)

    items = [s3, s1, s2]
    sorted_items = sort_anything(items)

    assert sorted_items == [s1, s2, s3]
    assert unique_hash(s1) != unique_hash(s2)


# Setup for recursive cases
cyclic_list = [1, 2]
cyclic_list.append(cyclic_list)

cyclic_dict = {"a": 1}
cyclic_dict["self"] = cyclic_dict

cyclic_ndarray = np.array([None], dtype=object)
cyclic_ndarray[0] = cyclic_ndarray

# Diamond structure: same object twice but no cycle
shared_obj = [10, 20]
diamond_list = [shared_obj, shared_obj]


def test_stable_key_sorting_recursive() -> None:
    """Ensure sorting handles cycles and complex references consistently."""
    items = [
        cyclic_list,
        cyclic_dict,
        cyclic_ndarray,
        diamond_list,
        [1, 2, [1, 2]],
        42,
        {"z": 99},
        None,
    ]

    # Test stability and cross-type compatibility
    sorted_items = sort_anything(items)

    assert len(sorted_items) == len(items)
    # Double check that multiple passes yield same results (determinism)
    assert sort_anything(sorted_items) == sorted_items

    # Find the cyclic list in the sorted results to verify its internal structure
    # A cyclic list [shared_obj, shared_obj] (diamond) vs [[...]] (cycle)
    cyclic_list_key = get_stable_key(cyclic_list)

    # The top-level group is 1 (Container), but the content (index 1)
    # must contain a Group -1 entry because it references itself.
    content_keys = cyclic_list_key[1]
    has_cycle = any(k[0] == -1 for k in content_keys)
    assert has_cycle, "Cycle detection should trigger Group -1 inside the container's content"

    # Verify logical ordering (no TypeError)
    for i in range(len(sorted_items) - 1):
        key_current = get_stable_key(sorted_items[i])
        key_next = get_stable_key(sorted_items[i + 1])
        assert key_current <= key_next, f"Sorting failed at index {i}: {key_current} > {key_next}"

    # Verify that scalars (Group 0) like None and 42 are sorted correctly relative to containers
    # Group 0 comes before Group 1
    none_key = get_stable_key(None)
    assert none_key[0] == 0


@pytest.mark.parametrize(
    "val",
    [
        1,
        1.0,
        np.nan,
        "",
        "abc",
        np.array([1, 2], dtype=int),
        np.array([1.0, 2.0]),
        np.array([True, False]),
        [],
        [1, 2, 3],
        (1, 2, 3),
        {1, 2},
        {"a": 1},
        slice(0, 3),
        list[int],
        npt.NDArray[float],
        tuple[int, int],
        # Recursive and complex cases
        cyclic_list,
        cyclic_dict,
        cyclic_ndarray,
        diamond_list,
    ],
)
def test_unique_hash_determinism(val):
    """unique_hash returns an int and is deterministic for the same input."""
    h1 = unique_hash(val)
    h2 = unique_hash(val)
    assert isinstance(h1, int)
    assert h1 > 0
    assert h1 == h2


def test_unique_hash_equality_for_shared_objects() -> None:
    """
    Checks that even if objects are shared (diamond),
    the hash remains deterministic.
    """
    shared = [1, 2, 3]
    val1 = [shared, shared]
    val2 = [[1, 2, 3], [1, 2, 3]]

    # In our current "no-discard" version, these will actually be DIFFERENT
    # because val1 tracks the identity, whereas val2 has fresh identities.
    # This is an important distinction for identity-based hashing.
    assert unique_hash(val1) == unique_hash(val1)
    assert unique_hash(val2) == unique_hash(val2)


@pytest.mark.parametrize(
    ["item_a", "item_b"],
    [
        # Dict Order Invariance: Order of keys should not change the hash
        ({"a": 1, "b": 2}, {"b": 2, "a": 1}),
        # Set Order Invariance: Sets are unordered, hashes must match
        ({1, 2, 3}, {3, 2, 1}),
        # Nested Complexity: Identical nested structures
        (
            {"outer": [{"inner": {1, 2}}], "status": True},
            {"status": True, "outer": [{"inner": {2, 1}}]},
        ),
        # Deep Nesting: Identity with depth
        ([[[[[[[[[[1]]]]]]]]]], [[[[[[[[[[1]]]]]]]]]]),
        # Complex Mixed Nesting: Stability with different iteration orders
        (
            {"a": {frozenset({1, 2}): [1, 2, {"x": {3, 4}}]}, "b": 5},
            {"b": 5, "a": {frozenset({2, 1}): [1, 2, {"x": {4, 3}}]}},
        ),
        (np.array([1, 2, 3]), np.array([1, 2, 3], dtype=np.int64)),
        (432, np.int32(432)),
        (123, np.int64(123)),
        (float(np.float32(432.432)), np.float32(432.432)),
        (123.123, np.float64(123.123)),
    ],
)
def test_unique_hash_match(item_a, item_b):
    """Verifies that the hash is stable, unique, and type-aware across deep structures."""
    assert unique_hash(item_a) == unique_hash(item_b) != 0


@pytest.mark.parametrize(
    ["item_a", "item_b"],
    [
        # Type Distinction: "1" (str) vs 1 (int) must have different hashes
        ("1", 1),
        # NumPy vs List: Content is same, but type differs
        (np.array([1, 2]), [1, 2]),
        # different dtype
        (np.array([1, 2, 3]), np.array([1, 2, 3], dtype=np.int32)),
        # Boolean vs Integer: True and 1 are mathematically equal but distinct types
        (True, 1),
        # Empty Structures: Different types of empty collections
        ([], {}),
        ([], ()),
        # Deep Nesting: Difference at the very bottom
        ([[[[[[[[[[1]]]]]]]]]], [[[[[[[[[[2]]]]]]]]]]),
        # Depth Asymmetry: Same values but different nesting levels
        ([1, [2, [3]]], [1, 2, 3]),
        # Deeply nested Dict vs List with identical leaf values
        ({"level1": {"level2": {"level3": 100}}}, {"level1": {"level2": [100]}}),
        # Scalar vs. Collection at depth
        ([[[1]]], [[1]]),
        # Floating point precision in deep structures
        ({"data": [1, 2, {"val": 1.0000000000001}]}, {"data": [1, 2, {"val": 1.0}]}),
        # Consolidated from previous tests
        (list[int], npt.NDArray[float]),
        (list[int], tuple[int, int]),
    ],
)
def test_unique_hash_not_match(item_a, item_b):
    """Verifies that the hash is stable, unique, and type-aware across deep structures."""
    # Using xxh64 as default for these tests
    assert unique_hash(item_a) != unique_hash(item_b) != 0


def test_large_int_fallback():
    """Verifies that integers larger than 64-bit don't crash and remain stable."""
    large_val = 2**128 + 5
    h = unique_hash(large_val)
    assert isinstance(h, int)
    # Check that it's truncated to unsigned 64-bit if using our unique_hash
    assert 0 < h < 2**64


def generate_hash_benchmark_data(width: int = 5, depth: int = 10, array_size: int = 1000) -> list[Any]:
    """
    Generates a nested structure with heavy NumPy arrays for timing tests.

    The structure includes:
    - Deep nesting (controllable via depth)
    - Large NumPy arrays (length 1000)
    - Mixed Python types (dict, set, list, scalars)
    """
    if depth <= 0:
        # Leaf nodes
        return random.randint(0, 1000)

    rng = np.random.RandomState(42)
    container: list[Any] = []

    for _ in range(width):
        choice = random.random()

        if choice < 0.2:
            # Inject a large NumPy array
            container.append(rng.rand(array_size))
        elif choice < 0.4:
            # Nested List
            container.append(generate_hash_benchmark_data(width, depth - 1, array_size))
        elif choice < 0.6:
            # Nested Dict
            key = "".join(random.choices(string.ascii_letters, k=8))
            container.append({key: generate_hash_benchmark_data(width, depth - 1, array_size)})
        elif choice < 0.8:
            # Set of integers
            container.append({random.randint(0, 10000) for _ in range(10)})
        else:
            # Mixed scalars
            container.append(random.choice(["a" * 100, random.uniform(0, 1), True, None]))

    return container


def test_unique_hash_benchmark():
    data = generate_hash_benchmark_data(depth=3, array_size=1000)
    unique_hash(data)
