import numpy as np
import pytest

from william.library.functions import (
    _remove_multiple_entries,
    cumsum,
    diff,
    insert,
    list_given_slice,
    partition_given_content,
    partition_given_indices,
    slice_given_list,
    unique_list,
)

outputs_cut = [
    ((slice(9), np.arange(7, 16), np.arange(1, 6)), np.concatenate((np.arange(7, 16), np.arange(1, 6)))),
    ((slice(0, 9, 2), np.arange(0, 5), np.arange(0, 5)), [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]),
    (([1, 7, 8], "abc", "qwertyuiop"), "qawertybcuiop"),
    (([2, 4, 5], 13, [4, 2, 6]), [4, 2, 13, 6, 13, 13]),
    (([1, 4], "b", "acd"), "abcdb"),
]


@pytest.mark.parametrize("test_input,expected", outputs_cut)
def test_cut(test_input, expected):
    cut_result = insert(*test_input)
    assert np.all(cut_result == expected), "Insert doesn't work correctly"


targets_pgi = [
    ((np.concatenate((np.arange(7, 16), np.arange(1, 6))), slice(9)), [(np.arange(7, 16), np.arange(1, 6))]),
    (([0, 0, 1, 1, 2, 2, 3, 3, 4, 4], slice(0, 9, 2)), [(np.arange(0, 5), np.arange(0, 5))]),
    (("qawertybcuiop", [1, 7, 8]), [("abc", "qwertyuiop")]),
    (([4, 2, 3, 6, 3, 3], [2, 4, 5]), [([3, 3, 3], [4, 2, 6]), (3, [4, 2, 6])]),
]


@pytest.mark.parametrize("test_input, expected", targets_pgi)
def test_pgi(test_input, expected):
    for result, expect in zip(partition_given_indices(*test_input), expected):
        assert np.all(result[0] == expect[0]), "Insert doesn't work correctly"
        assert np.all(result[1] == expect[1]), "Insert doesn't work correctly"


targets_pgc = [
    ((np.arange(16), np.arange(7, 16)), (np.arange(7, 16), np.arange(7))),
    (("abcde", "cd"), ([2, 3], "abe")),
    (
        (
            [
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
            ],
            [1, 1, 1],
        ),
        ([3, 14, 25], [0] * 27),
    ),
    (([4, 2, 1, 6, 1, 1], 1), ([2, 4, 5], [4, 2, 6])),
    (("abcdb", "b"), ([1, 4], "acd")),
    (
        ([32, 14, 137, 45, 14, 17, 9, 0, -5, 14, 17, 14, 17, -33, 23], [14, 17, 9, 14, 17, -33]),
        ([4, 5, 6, 11, 12, 13], [32, 14, 137, 45, 0, -5, 14, 17, 23]),
    ),
    (
        ([1, 0, 12, 7, 19, 3, 76, 23, 12, 7, 19, 0, 17, 12], [12, 7, 19, 12, 7, 19]),
        ([2, 3, 4, 8, 9, 10], [1, 0, 3, 76, 23, 0, 17, 12]),
    ),
]


@pytest.mark.parametrize("test_input, expected", targets_pgc)
def test_pgc(test_input, expected):
    result = partition_given_content(*test_input).__next__()
    assert np.all(result[0] == expected[0]), "Insert doesn't work correctly"
    assert np.all(result[1] == expected[1]), "Insert doesn't work correctly"


remove_test = [([0, 5, 7, 0, 4, 5], [0, 5, 7, 4]), ([0, 0], [0])]


@pytest.mark.parametrize("inp, outp", remove_test)
def test_remove_multiple_entries(inp, outp):
    assert _remove_multiple_entries(inp) == outp


examples = [
    ([], slice(0)),
    ([6], slice(6, 7)),
    ([6, 2], slice(6, -2, -4)),
    ([6, 8, 10, 12], slice(6, 14, 2)),
]


@pytest.mark.parametrize("example", examples, ids=lambda ex: str(ex[0]) + ", " + str(ex[1]))
def test_slice_list_conversion(example):
    assert slice_given_list(example[0]) == example[1]
    assert list_given_slice(example[1]) == example[0]


def test_unique_list():
    assert unique_list([3, 4, 7, 3, 1, 4, 6, 2, 7]) == [3, 4, 7, 1, 6, 2]


def test_cumsum_diff():
    test_input, expected = (list(range(5)), [0, 1, 3, 6, 10])
    cs = cumsum(test_input)
    assert cs == expected, "Insert doesn't work correctly"
    assert diff(cs) == test_input, "Diff doesn't work correctly"


def test_unique_with_inverse_preallocated_matches_numpy():
    """unique_with_inverse_preallocated should reconstruct the input the same way as
    np.unique(arr, return_inverse=True). Include NaNs in the input to ensure they are
    handled correctly.
    """
    from william.library.functions import unique_with_inverse_preallocated

    arr = np.array([1.0, np.nan, 2.0, 1.0, np.nan, 2.0, 3.0, np.nan], dtype=float)

    # numpy reference
    src_np, inv_np = np.unique(arr, return_inverse=True)

    # preallocated buffers (unique_len at most arr.size)
    unique_buf = np.empty(arr.size, dtype=arr.dtype)
    inv_buf = np.empty(arr.size, dtype=np.int64)

    count = unique_with_inverse_preallocated(arr, unique_buf, inv_buf, arr.size)
    src_pre = unique_buf[:count]
    inv_pre = inv_buf[: arr.size]

    # reconstruct arrays
    recon_pre = src_pre[inv_pre]
    recon_np = src_np[inv_np]

    def equal_with_nan(a, b):
        if a.shape != b.shape:
            return False
        a_nan = np.isnan(a)
        b_nan = np.isnan(b)
        # positions where both are nan
        both_nan = a_nan & b_nan
        # positions where neither is nan and values equal
        both_eq = (~a_nan) & (~b_nan) & (a == b)
        return np.all(both_nan | both_eq)

    assert count == len(src_np), "unique count should match numpy.unique"
    assert equal_with_nan(recon_pre, arr), "reconstructed array from preallocated unique does not match original"
    assert equal_with_nan(recon_np, arr), "reconstructed array from numpy.unique does not match original"
    assert equal_with_nan(recon_pre, recon_np), "reconstructions differ between implementations"


def test_insert_numpy_indices_broadcast_and_negative():
    # scalar broadcasting into numpy-rest
    rest = np.array([1, 2, 3], dtype=int)
    inds = np.array([0, 2], dtype=int)
    res = insert(inds, 9, rest)
    assert isinstance(res, np.ndarray)
    assert res.dtype == rest.dtype
    assert np.array_equal(res, np.array([9, 1, 9, 2, 3], dtype=int))

    # negative indices normalize relative to final size and preserve content order
    inds2 = np.array([-1, 0], dtype=int)
    res2 = insert(inds2, [7, 8], rest)
    # content [7,8] will be assigned in order to normalized indices [-1->4, 0->0]
    assert np.array_equal(res2, np.array([8, 1, 2, 3, 7], dtype=int))
