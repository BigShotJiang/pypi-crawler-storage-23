import string
from math import factorial as fac
from math import log

import numpy as np
import pytest
from intnan import INTNAN64

from william.library.description import (
    _describe_by_permutation_index,
    _fraction,
    _jdesc_len_array_elias,
    _jdesc_len_float,
    _jdesc_len_int,
    desc_len,
    desc_len_1d_array_gaussian,
    desc_len_array_gaussian,
    elias_discrete,
    jelias,
    log_binomial,
    log_multinomial,
)
from william.library.description import jelias_posneg as epng
from william.library.precision import jprecision

try:
    from scipy.special import binom
except ImportError:
    binom = None


@pytest.mark.skipif(not binom, reason="scipy.special not available")
def test_log_binomial(rng):
    assert abs(log_binomial(100, 0) - np.log2(binom(100, 0))) < 1e-10
    assert abs(log_binomial(100, 100) - np.log2(binom(100, 100))) < 1e-10
    for _ in range(100):
        n = rng.integers(10, 20)
        k = rng.integers(0, n)
        assert abs(log_binomial(n, k) - np.log2(binom(n, k))) < 1e-10
        assert abs(log_binomial(n, k) - log_multinomial(n, (k, n - k))) < 1e-10
    assert abs(log_binomial(50, 23) - log_multinomial(50, (23, 0, 27, 0))) < 1e-10
    assert abs(log_multinomial(10, (2, 5, 3)) - np.log2(fac(10) / fac(2) / fac(5) / fac(3))) < 1e-10


def _elias_delta(x):
    """Elias delta coding implementation defined for x >= 1.
    See https://en.wikipedia.org/wiki/Elias_delta_coding"""

    def binary(x, min_len=1):
        return f"{x:0{min_len}b}"

    n = int(log(x, 2))
    l = int(log(n + 1, 2))
    return "0" * l + binary(n + 1, l + 1) + binary(x)[1:]


@pytest.mark.parametrize("x", [10**i for i in range(10)])
def test_elias_delta(x):
    assert len(_elias_delta(x)) == elias_discrete(x)


def test_fraction():
    assert _fraction(2 / 3) == (2, 3)
    assert _fraction(4 / 9) == (4, 9)
    assert _fraction(101 / 200, tol=0.01) == (1, 2)
    assert _fraction(101 / 200, tol=0.00001) == (101, 200)


params = [
    (0, 0, 0),
    (-2, -2, 0),
    (2, 2, 0),
    (10, 1, -1),
    (130000, 13, -4),
    (-3450000000, -345, -7),
    (INTNAN64, None, None),
]


@pytest.mark.parametrize("x, significand, decimals", params)
def test_int(x, significand, decimals):
    if x == INTNAN64:
        assert _jdesc_len_int(x) == 0
        return
    assert _jdesc_len_int(x) == epng(significand) + jelias(1 - decimals)


params = [
    ("A", 8 + jelias(1)),
    ("asdf", 4 * 8 + jelias(4)),
    (string.ascii_letters, 8 * len(string.ascii_letters) + jelias(len(string.ascii_letters))),
    (
        np.array([["asdf", "dfg"], ["fdasg", "jztrertg"]]),
        sum([jelias(i) + i * 8 for i in [4, 3, 5, 8]]) + jelias(2) * 2,
    ),
]


@pytest.mark.parametrize("x, dl", params)
def test_str(x, dl):
    assert desc_len(x) == dl


params = [
    (0.00542, 5, epng(542) + epng(-5)),
    (43.61873, 5, epng(4361873) + epng(-5)),
    (-43.61873, 5, epng(-4361873) + epng(-5)),
    (-0.005423452, 9, epng(-5423452) + epng(-9)),
    (347.0, 0, epng(347) + epng(0)),
    (1200.0, -2, epng(12) + epng(2)),
    (28300000, -5, epng(283) + epng(5)),
    (30, -1, epng(3) + epng(1)),
    (3e8, -8, epng(3) + epng(8)),
    (4e-8, 8, epng(4) + epng(-8)),
    (17.28, 2, epng(1728) + epng(-2)),
    (1.728, 2, epng(173) + epng(-2)),
    (0.1728, 2, epng(17) + epng(-2)),
    (0.01728, 2, epng(2) + epng(-2)),
    (0.001728, 2, epng(0) + epng(-2)),
    (0.0001728, 2, epng(0) + epng(-2)),
    (np.nan, 0, 0),
    # three significands, length code and decimals=0
    (np.array([-10.0, 2.0, 3.0]), None, epng(-10) + epng(2) + epng(3) + jelias(3) + jelias(1 - 0)),
    (np.array([np.nan, np.nan, np.nan]), None, jelias(3)),
    (np.array([np.nan, 1.0, np.nan]), None, _jdesc_len_float(1.0) + jelias(3)),
    (np.array([3.44589, np.nan, -0.0529]), 3, epng(3446) + epng(-53) + epng(-3) + jelias(3)),
]


@pytest.mark.parametrize("x, decimals, dl", params, ids=list(map(str, range(len(params)))))
def test_desc_len_float(x, decimals, dl):
    if isinstance(x, float):
        assert abs(_jdesc_len_float(x, decimals=decimals) - dl) < 1e-10
    if isinstance(x, np.ndarray):
        if decimals is None:
            assert abs(desc_len(x) - dl) < 1e-10
            return
        sig_dl, _ = _jdesc_len_array_elias(x, decimals)
        assert abs(jelias(len(x)) + sig_dl + epng(decimals) - dl) < 1e-10


def test_desc_len_gaussian_float_array(rng):
    # create RBG image as a 50x50x3 matrix
    red = np.array([255.0, 100.0, 100.0])
    img = np.ones((50, 50, 3)) * red
    img += rng.standard_normal(img.shape) * 20.0
    img = np.round(img, 2)

    decimals = jprecision(img)
    elias_dl, _ = _jdesc_len_array_elias(img.ravel(), decimals)
    gaussian_dl, _ = desc_len_array_gaussian(img, decimals)
    assert gaussian_dl < elias_dl


def test_desc_len_1d_array_gaussian(rng):
    x = np.round(rng.standard_normal(200) * 1000, 3)
    decimals = jprecision(x)
    scale = 10**decimals
    gaussian_dl, _ = desc_len_1d_array_gaussian(x, scale)
    elias_dl, _ = _jdesc_len_array_elias(x, decimals)
    assert gaussian_dl < elias_dl


params = [
    (np.array([12, 657, 831]), np.array([12, 657, 831]), 0),
    (np.array([12000, 657000, 831000]), np.array([12, 657, 831]), -3),
    (np.array([12.4, 0.231, 123.4123]), np.array([124000, 2310, 1234123]), 4),
]


@pytest.mark.parametrize("x, significand, decimals", params, ids=list(map(str, range(len(params)))))
def test_arrays(x, significand, decimals):
    if decimals is None:
        decimals = jprecision(x)
    if x.dtype.kind == "f":
        n = epng(decimals)
    if x.dtype.kind == "i":
        n = jelias(1 - decimals)
    sig_dl = sum([epng(s) for s in significand])
    assert _jdesc_len_array_elias(x, decimals)[0] == sig_dl
    assert desc_len(x) == jelias(len(significand)) + sig_dl + n


params = [
    (
        np.array([False, True, False, True, True, True, True, True, True, True, True, True, True]),
        27.11381997364,
    ),
    (
        np.array([np.nan, 1.0, np.nan, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]),
        27.11381997364 + 10.32524920461,
    ),
    (np.array(["", "", ""]), 7.325249204613159),
    (np.random.RandomState(42).random((5, 100)) < 0.97, 117.91063046983786),
]


@pytest.mark.parametrize("x, expected_dl", params, ids=list(map(str, range(len(params)))))
def test_describe_by_permutation_index(x, expected_dl):
    actual_dl = _describe_by_permutation_index(x)
    assert abs(actual_dl - expected_dl) < 1e-6
