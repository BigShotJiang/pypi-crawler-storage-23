from collections.abc import Callable

import numpy as np
import pytest

from william.library.types import (
    T1,
    T2,
    Array,
    concretize_specs,
    issubspec,
    isvarspec,
    sort_specs,
    spec_str,
    specify,
    str_to_spec,
    typecheck,
    typereplace,
    unify,
)

params = [
    (1, int),
    (1.0, float),
    ("1", str),
    ([1, 2, 3], list[int]),
    (tuple([1, 2, 3]), tuple[int, int, int]),
    (tuple([3, 4, tuple([[3, 4], [333, 222]])]), tuple[int, int, tuple[list[int], list[int]]]),
    (np.array([1, 2, 3]), Array[int]),
    (np.array([1.7, 2.2]), Array[float]),
    (tuple([3, 5.6, [np.ones(8), np.array([5.4, 6.2])]]), tuple[int, float, list[Array[float]]]),
    (
        tuple([3, "hello", tuple([{3, 4}, {333.7, 222.2}, {"asdf", "abc"}])]),
        tuple[int, str, tuple[set[int], set[float], set[str]]],
    ),
    ([], list),
    (set(), set),
    ({1, 2, 7.8}, set[int]),
    (np.array(["hello", "there"]), Array[str]),
    (np.array([[1, 2], [3, 4]]), Array[int]),
]


@pytest.mark.parametrize("obj, spec", params)
def test_specify(obj, spec):
    assert specify(obj) == spec


params = [
    (1, int, True),
    (1.0, float, True),
    ("1", str, True),
    ([1], list[int], True),
    ((8, 9), tuple[int], False),
    ((8, 9), tuple[int, int], True),
    ((1, [1, 2, 3]), tuple[int, list[int]], True),
    ((slice(4), [33, 35], [15, 14]), tuple[slice, list[int], list[int]], True),
    ({1}, set[int], True),
    ((1, {1, 2, 3}), tuple[int, set[int]], True),
    ((slice(4), {"33", "35"}, {1.5, 14.3}), tuple[slice, set[str], set[float]], True),
    (np.array([1]), Array[int], True),
    ((1, np.array([1, 2, 3])), tuple[int, Array[int]], True),
    ((slice(4), np.array(["33", "35"]), np.zeros(5)), tuple[slice, Array[str], Array[float]], True),
    (1.0, int, False),
    ([1], list[float], False),
    ({1}, list[int], False),
    ([1], tuple[int], False),
    ((1, [1, 2, "a"]), tuple[int, list[int]], False),
    ([1, 2, 3], list[T1], False),
    (np.ones(8), list[float], False),
    (4, list[int], False),
    (1.0, T1, False),
    (False, int, False),
    (True, int, False),
    (False, bool, True),
]


@pytest.mark.parametrize("obj, spec, success", params)
def test_typecheck(obj, spec, success):
    assert typecheck(obj, spec) == success


params = [
    (list[int], list, True),
    (list[int], list, True),
    (list[int], list[int], True),
    (tuple[tuple[int, int], str], tuple, True),
    (int, float, False),
    (list, list[int], False),
    (list[float], list[int], False),
    (set[int], set, True),
    (set, set, True),
    (set[float], set[float], True),
    (set, set[int], False),
    (set[float], set[int], False),
    (set, list, False),
    (list, set, False),
    (Array[str], Array, True),
    (Array, Array, True),
    (Array[float], Array[float], True),
    (Array, Array[int], False),
    (Array[float], Array[str], False),
    (Array, list, False),
    (list, Array, False),
    (Array, set, False),
    (set, Array, False),
    (Array[float], (list, Array, set), True),
    (set[int], set[T1], True),
    (set[tuple[int]], set, True),
]


@pytest.mark.parametrize("subspec, spec, success", params)
def test_issubspec(subspec, spec, success):
    assert issubspec(subspec, spec) == success


def test_isvarspec():
    assert isvarspec(T1)
    assert isvarspec(tuple[T1, int, T2])
    assert isvarspec(list[T1])
    assert isvarspec(set[T1])
    assert isvarspec(Array[T1])
    assert isvarspec(Callable[[T1], T1])
    assert not isvarspec(tuple[list[int], str])
    assert not isvarspec(tuple[set[str], str])
    assert not isvarspec(tuple[Array[float], int])
    assert not isvarspec(Callable[[int], int])

    # varspec                         spec                                 result


params_unify = [
    (tuple[T1, int], tuple[int, int], {T1: int}),
    (tuple[T1, int, list[T2]], tuple[float, int, list[str]], {T1: float, T2: str}),
    (T1, tuple[int, int, int], {T1: tuple[int, int, int]}),
    (tuple[int, int], tuple[int, int], {}),
    (list[T1], list[str], {T1: str}),
    (set[T1], set[int], {T1: int}),
    (Array[T1], Array[float], {T1: float}),
    (int, int, {}),
    (T1, int, {T1: int}),
    (list[T1], list[T2], {T1: T2}),
    (set[T1], set[T2], {T1: T2}),
    (Array[T1], Array[T2], {T1: T2}),
    (Callable[[T2], bool], Callable[[bool], bool], {T2: bool}),
    (Callable[[T2], T1], Callable, {}),
    (set[tuple[T1, T2]], set[T1], {tuple[T1, T2]: T1}),
    (tuple[Callable[[T2], bool], list[T2]], tuple[Callable[[bool], bool], list[bool]], {T2: bool}),
    (
        tuple[Callable[[tuple[T2]], T1]],
        tuple[Callable[[tuple[list[int]]], bool]],
        {T2: list[int], T1: bool},
    ),
    (
        tuple[Callable[[tuple[T2]], T1], list[T2]],
        tuple[Callable[[tuple[bool]], int], list[bool]],
        {T2: bool, T1: int},
    ),
    (
        tuple[Callable[[tuple[T1, T2]], T1], T1, list[T2]],
        tuple[Callable[[tuple[bool, list[int]]], bool], bool, list[list[int]]],
        {T1: bool, T2: list[int]},
    ),
    (
        tuple[Callable[[tuple[T1, T2]], T1], T1, set[T2]],
        tuple[Callable[[tuple[bool, Array[float]]], bool], bool, set[Array[float]]],
        {T1: bool, T2: Array[float]},
    ),
]


@pytest.mark.parametrize("varspec, spec, result", params_unify, ids=list(map(str, range(len(params_unify)))))
def test_unify(varspec, spec, result):
    assert unify(varspec, spec) == result


params_unify_exceptions = [
    (list[int], list[float]),
    (list[int], tuple[int]),
    (list[int], set[int]),
    (set[int], Array[int]),
    (list[int], tuple[int]),
    (tuple[T1], tuple[int, int]),
    (tuple[T1, T1], tuple[int, float]),
]


@pytest.mark.parametrize("varspec, spec", params_unify_exceptions)
def test_unify_exceptions(varspec, spec):
    with pytest.raises(TypeError):
        unify(varspec, spec)


def test_typereplace():
    assert typereplace(T1, {T1: list[str]}) == list[str]
    assert typereplace(tuple[int, T1, T2, list[T2]], {T1: float, T2: str}) == tuple[int, float, str, list[str]]
    assert typereplace(tuple[Callable[[T1], T2], list[T1]], {T2: int}) == tuple[Callable[[T1], int], list[T1]]
    assert typereplace(T1, {T1: set[str]}) == set[str]
    assert typereplace(tuple[int, T1, T2, Array[T2]], {T1: float, T2: str}) == tuple[int, float, str, Array[str]]
    assert typereplace(tuple[Callable[[T1], T2], set[T1]], {T2: int}) == tuple[Callable[[T1], int], set[T1]]
    assert typereplace(Callable[[T2, T2], T1], {T1: int, T2: float}) == Callable[[float, float], int]


# TODO: implementation missing
# params = [
#     (
#         [Array[T1]],
#         [bool, Array[bool], Array[int], int, Array[str], Array[float]],
#         [[Array[bool]], [Array[int]], [Array[str]], [Array[float]]],
#     ),
#     (
#         [T1, list[T1]],
#         [int, float, list[int], list[float]],
#         [[int, list[int]], [float, list[float]]],
#     ),
#     (
#         [tuple[T1, T2], tuple[str, T2], list[T1]],
#         [list[str], tuple[str, int], tuple[str, float], list[bool], tuple[bool, int]],
#         [
#             [tuple[str, int], tuple[str, int], list[str]],
#             [tuple[str, float], tuple[str, float], list[str]],
#             [tuple[bool, int], tuple[str, int], list[bool]],
#         ],
#     ),
# ]


def test_spec_to_string():
    specs = [
        list[int],
        list[float],
        Array[int],
        Array[float],
        set[int],
        tuple[int],
        Array[bool],
        tuple[list[int], set[float]],
        tuple[Array[int], list[str], set[float]],
    ]

    for spec in specs:
        s = spec_str(spec)
        back = str_to_spec(s)
        assert back == spec, f"Mismatch: {spec} vs {back}"


params = [
    ([list[T1], list[Array[int]], list[Array[T2]]], [1, 2, 0]),
    ([int, float, str], []),
    ([Array[T1], Array[T2]], [0, 1]),
    ([Array[bool], Array[int]], []),
    ([set[T1], set[int]], [1, 0]),
    ([list[int], list[Array[T2]]], []),
]


@pytest.mark.parametrize("specs, expected_order", params)
def test_sort_specs(specs, expected_order):
    sorted_indices = sort_specs(specs)
    assert sorted_indices == expected_order, f"Expected {expected_order}, got {sorted_indices}"


@pytest.mark.parametrize(
    "spec, concrete_types, expected",
    [
        (
            (Callable[[tuple[T2]], T1], Array[T2]),
            [int, float],
            [
                (Callable[[tuple[int]], int], Array[int]),
                (Callable[[tuple[int]], float], Array[int]),
                (Callable[[tuple[float]], int], Array[float]),
                (Callable[[tuple[float]], float], Array[float]),
            ],
        ),
    ],
)
def test_concretize_specs(spec, concrete_types, expected):
    results = list(concretize_specs(spec, concrete_types))
    assert results == expected
