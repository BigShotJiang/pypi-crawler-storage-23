import numpy as np
import pytest

from william.library.base import Value
from william.library.canvas import Canvas
from william.library.geometry_ops import Arc, Compose, Draw, Length, Line, Meanadd, PAdd, Rotate
from william.library.tests.test_library import _test_explicit_inverse

params = [
    (
        Compose(),
        np.array([[1.0, 2.0], [3.0, 4.0]]),
        ((np.array([0, 1]), np.array([1, 0])),),  # indices
        (1,),  # cond
        [
            (
                np.array([[1.0, np.nan], [np.nan, 4]]),  # input 0
                np.array([[np.nan, 2.0], [3.0, np.nan]]),
            )
        ],
    ),  # input 2
    (
        Compose(),
        np.array([[[1.0, 2.0, 5.0], [3.0, 4.0, 6.0]], [[9.0, 10.0, 7.0], [11.0, 12.0, 8.0]]]),  # output
        ((np.array([0, 1]), np.array([1, 0])),),  # indices
        (1,),  # cond
        [
            (
                np.array(
                    [
                        [[1.0, 2.0, 5.0], [np.nan, np.nan, np.nan]],  # input 0
                        [[np.nan, np.nan, np.nan], [11.0, 12.0, 8.0]],
                    ]
                ),
                np.array(
                    [
                        [[np.nan, np.nan, np.nan], [3.0, 4.0, 6.0]],  # input 2
                        [[9.0, 10.0, 7.0], [np.nan, np.nan, np.nan]],
                    ]
                ),
            )
        ],
    ),
    (
        Meanadd(),
        np.array([[[1.0, np.nan, 5.0], [3.0, np.nan, np.nan]], [[9.0, np.nan, 7.0], [11.0, np.nan, 8.0]]]),  # output
        (),
        (),
        [
            (
                np.array([6.0, np.nan, 7.0]),  # mean color
                np.array(
                    [
                        [[-5.0, np.nan, -2.0], [-3.0, np.nan, np.nan]],
                        [[3.0, np.nan, 0.0], [5.0, np.nan, 1.0]],
                    ]
                ),
            )
        ],
    ),  # rest
]


@pytest.mark.parametrize("func, output, cond_inputs, cond, expected", params, ids=lambda x: type(x).__name__)
def test_explicit_inverse(func, output, cond_inputs, cond, expected):
    _test_explicit_inverse(func, output, cond_inputs, cond, expected)


def test_lines_and_arcs():
    canvas = Canvas()
    line = Line()
    arc = Arc()

    p1 = Value((40, 50))
    p2 = Value((60, 90))
    vec = np.array(p2.value, dtype=float) - np.array(p1.value, dtype=float)
    min_radius = np.sqrt(np.sum(vec**2)) / 2

    curvature = Value(-0.5 / min_radius)
    arc_points = arc(p1, p2, curvature).value
    line_points = line(p1, p2).value

    rotate = Rotate()
    vec = Value(np.array(p2.value) - np.array(p1.value))
    rot_vec = rotate(vec, Value(0.125))
    point_add = PAdd()
    line_points2 = line(p1, point_add(p1, rot_vec)).value

    assert set(line_points) == {
        (47, 65),
        (42, 54),
        (41, 52),
        (50, 70),
        (56, 83),
        (55, 81),
        (46, 63),
        (59, 88),
        (40, 50),
        (58, 86),
        (49, 68),
        (48, 66),
        (57, 84),
        (45, 61),
        (53, 77),
        (47, 64),
        (54, 79),
        (56, 82),
        (55, 80),
        (44, 59),
        (43, 57),
        (52, 75),
        (51, 73),
        (46, 62),
        (45, 60),
        (54, 78),
        (53, 76),
        (42, 55),
        (41, 53),
        (43, 56),
        (50, 71),
        (44, 58),
        (51, 72),
        (59, 89),
        (40, 51),
        (58, 87),
        (52, 74),
        (60, 90),
        (49, 69),
        (48, 67),
        (57, 85),
    }

    assert set(arc_points) == {
        (57, 88),
        (53, 84),
        (45, 74),
        (41, 61),
        (47, 77),
        (42, 66),
        (41, 64),
        (50, 82),
        (43, 70),
        (58, 89),
        (40, 50),
        (40, 56),
        (44, 72),
        (40, 53),
        (40, 59),
        (46, 75),
        (51, 83),
        (49, 80),
        (48, 78),
        (57, 87),
        (45, 73),
        (54, 85),
        (41, 63),
        (55, 86),
        (41, 60),
        (47, 76),
        (42, 65),
        (44, 71),
        (40, 52),
        (40, 58),
        (43, 69),
        (50, 81),
        (40, 55),
        (51, 82),
        (52, 84),
        (58, 88),
        (59, 90),
        (49, 79),
        (41, 62),
        (47, 78),
        (56, 87),
        (42, 67),
        (44, 70),
        (40, 51),
        (43, 68),
        (59, 89),
        (40, 54),
        (40, 57),
        (52, 83),
        (60, 90),
        (46, 76),
        (48, 79),
    }

    vec = Value(np.array([4, 3]))
    assert Length()(vec).value == 5


def test_neg_line():
    line = Line()
    draw = Draw((50, 50, 3))

    p1 = Value((24.0, -48.0))
    p2 = Value((24.0, 24.0))
    line_points = line(p1, p2)
    col = np.array([255.0, 0.0, 0.0])
    col_points = Value([(col, p) for p in line_points.value])
    img = draw(col_points)
    img_ref = np.zeros((50, 50, 3))
    img_ref[24, :25, 0] = 255.0
    assert np.all(img.value == img_ref)
