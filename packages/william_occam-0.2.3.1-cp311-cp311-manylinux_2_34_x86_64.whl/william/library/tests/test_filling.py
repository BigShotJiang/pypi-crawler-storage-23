from itertools import chain, permutations

import pytest

from william.library.canvas import Canvas, GeometricFigure
from william.library.filling import (
    ExteriorFiller,
    JExteriorFiller,
    LineFiller,
    RecursiveFiller,
    arrange_domino_pieces,
    can_be_rearranged_into_a_path,
    is_a_path,
)

corner_params = [
    ([(0, 1), (0, 2), (1, 0)], False),
    ([(0, 6), (6, 0), (3, 10)], True),
    ([(-180, 12), (3, 3), (40, 40)], True),
    ([(-180, 12), (170, 3), (40, 140)], True),
    ([(12, 0), (6, 0), (0, 6)], True),
]


@pytest.mark.parametrize("corners, interior_exists", corner_params)
def test_fill(corners, interior_exists):
    canvas = Canvas()
    borders = GeometricFigure().polygon(corners)

    # canvas.make_image(borders, x_lim=(), y_lim=(), draw=True, offset=2, color=array([255, 200, 0]))
    filler = LineFiller()
    points = filler.fill(borders)
    # canvas.make_image(points, x_lim=(), y_lim=(), draw=True, offset=2, color=array([255, 200, 0]))

    points2 = RecursiveFiller(closed_paths_only=True).fill(borders)
    # canvas.make_image(points2, x_lim=(), y_lim=(), draw=True, offset=2, color=array([0, 200, 255]))

    if not interior_exists:
        with pytest.raises(ValueError):
            ExteriorFiller(closed_paths_only=True).fill(borders)
        return
    filler = ExteriorFiller(shape=(500, 500), closed_paths_only=True)
    points3 = filler.fill(borders)
    # canvas.make_image(points3, x_lim=(), y_lim=(), draw=True, offset=2, color=array([0, 0, 255]))

    jfiller = JExteriorFiller(shape=(500, 500), closed_paths_only=True)
    points3_fast = jfiller.fill(borders)
    assert set(points3) == set(points3_fast)


params = [
    [
        (10, 37),
        (46, 24),
        (46, 33),
        (37, 9),
        (26, 39),
        (46, 42),
        (16, 38),
        (24, 39),
        (8, 9),
        (19, 9),
        (4, 24),
        (40, 41),
        (20, 38),
        (12, 37),
        (5, 19),
        (30, 9),
        (3, 31),
        (41, 9),
        (46, 11),
        (46, 20),
        (46, 17),
        (6, 11),
        (21, 9),
        (41, 42),
        (46, 26),
        (46, 35),
        (14, 9),
        (36, 9),
        (35, 41),
        (46, 41),
        (4, 26),
        (31, 40),
        (4, 23),
        (5, 21),
        (3, 33),
        (46, 13),
        (16, 9),
        (38, 9),
        (27, 39),
        (37, 41),
        (5, 36),
        (17, 38),
        (46, 10),
        (6, 13),
        (30, 40),
        (46, 19),
        (6, 10),
        (20, 9),
        (31, 9),
        (46, 28),
        (33, 40),
        (13, 37),
        (11, 37),
        (46, 37),
        (46, 34),
        (7, 36),
        (4, 28),
        (11, 9),
        (33, 9),
        (22, 39),
        (4, 25),
        (5, 20),
        (3, 35),
        (44, 9),
        (3, 32),
        (26, 9),
        (15, 9),
        (46, 12),
        (36, 41),
        (46, 21),
        (9, 36),
        (6, 12),
        (46, 30),
        (44, 42),
        (32, 40),
        (46, 27),
        (46, 39),
        (46, 36),
        (17, 9),
        (28, 9),
        (18, 38),
        (6, 36),
        (38, 41),
        (5, 16),
        (10, 9),
        (4, 27),
        (32, 9),
        (43, 9),
        (14, 37),
        (34, 40),
        (4, 36),
        (3, 34),
        (46, 14),
        (46, 23),
        (28, 39),
        (8, 36),
        (6, 14),
        (46, 32),
        (23, 9),
        (43, 42),
        (12, 9),
        (34, 9),
        (45, 9),
        (46, 29),
        (46, 38),
        (27, 9),
        (39, 41),
        (29, 40),
        (5, 18),
        (5, 15),
        (3, 30),
        (25, 9),
        (45, 42),
        (23, 39),
        (3, 36),
        (46, 16),
        (7, 9),
        (18, 9),
        (29, 9),
        (40, 9),
        (19, 38),
        (46, 25),
        (46, 22),
        (46, 31),
        (22, 9),
        (15, 37),
        (25, 39),
        (46, 40),
        (9, 9),
        (42, 9),
        (4, 22),
        (21, 38),
        (5, 17),
        (3, 29),
        (13, 9),
        (24, 9),
        (35, 9),
        (46, 9),
        (46, 18),
        (46, 15),
        (6, 9),
        (39, 9),
        (42, 42),
    ],
    [
        (6, 18),
        (38, 20),
        (6, 15),
        (25, 32),
        (22, 11),
        (6, 24),
        (40, 26),
        (14, 7),
        (15, 36),
        (6, 33),
        (18, 35),
        (34, 28),
        (11, 5),
        (12, 37),
        (44, 23),
        (6, 11),
        (33, 29),
        (6, 8),
        (6, 20),
        (8, 39),
        (11, 38),
        (6, 17),
        (26, 32),
        (31, 16),
        (24, 32),
        (23, 12),
        (6, 26),
        (39, 26),
        (6, 35),
        (10, 5),
        (41, 26),
        (6, 4),
        (42, 25),
        (15, 7),
        (7, 3),
        (43, 23),
        (6, 13),
        (6, 10),
        (32, 29),
        (35, 28),
        (10, 38),
        (6, 19),
        (13, 37),
        (40, 21),
        (6, 28),
        (29, 30),
        (6, 37),
        (8, 4),
        (6, 34),
        (27, 14),
        (19, 10),
        (28, 31),
        (24, 12),
        (6, 6),
        (43, 25),
        (44, 24),
        (6, 3),
        (16, 8),
        (19, 34),
        (6, 12),
        (6, 21),
        (39, 21),
        (6, 30),
        (6, 27),
        (17, 9),
        (6, 39),
        (6, 36),
        (36, 19),
        (21, 34),
        (28, 15),
        (36, 28),
        (37, 27),
        (33, 17),
        (27, 31),
        (30, 30),
        (25, 13),
        (6, 5),
        (9, 38),
        (6, 14),
        (20, 10),
        (6, 23),
        (12, 6),
        (6, 32),
        (34, 18),
        (6, 29),
        (6, 38),
        (45, 24),
        (9, 4),
        (37, 20),
        (20, 34),
        (23, 33),
        (14, 36),
        (17, 35),
        (42, 22),
        (26, 13),
        (32, 17),
        (18, 9),
        (6, 7),
        (6, 16),
        (29, 15),
        (6, 25),
        (21, 11),
        (38, 27),
        (6, 22),
        (16, 36),
        (6, 31),
        (31, 30),
        (7, 39),
        (22, 33),
        (30, 16),
        (13, 6),
        (41, 22),
        (35, 18),
        (6, 9),
    ],
]


@pytest.mark.parametrize("borders", params)
def test_exterior_filler(borders):
    assert not is_a_path(borders)
    filler = ExteriorFiller(shape=(60, 60))
    p1 = filler.fill(borders)
    # canvas = Canvas()
    # from numpy import array
    # canvas.make_image(p1, x_lim=(), y_lim=(), draw=True, offset=2, color=array([0, 0, 255]))

    jfiller = JExteriorFiller(shape=(60, 60))
    p2 = jfiller.fill(borders)
    assert set(p1) == set(p2)


# def test_rgb_image():
#     canvas = Canvas()
#     img = canvas.image_from_file('william/graphs/umbrella_small.jpeg')
#     canvas.draw_image(img)


@pytest.mark.parametrize("corners", [c[0] for c in corner_params[1:]])
def test_can_be_rearranged_into_a_path(corners):
    # make a closed loop of lines (i.e. a polygon)
    lines = []
    for c0, c1 in zip(corners, corners[1:] + corners[:1]):
        line_points = GeometricFigure().line(c0, c1)
        lines.append(line_points)
    # lines a list of lists of points, each list of points corresponding to a line
    # check that no matter how the lines are permuted, they can still be arranged into a path
    for perm in permutations(lines):
        points = list(chain.from_iterable(perm))
        assert can_be_rearranged_into_a_path(points)


domino_params = [
    ([(4, 7), (9, 4), (9, 7)], [((4, 7), (7, 9), (9, 4))]),
    ([(4, 7), (9, 5), (9, 7)], []),  # is not closed
    ([(4, 7), (19, 5), (9, 7)], []),  # one piece, the (19, 5) is disconnected
    (
        [(7, 7), (7, 4), (9, 7), (4, 9)],
        [((7, 7), (7, 4), (4, 9), (9, 7)), ((7, 7), (7, 9), (9, 4), (4, 7))],
    ),
]


@pytest.mark.parametrize("pieces, expected_traces", domino_params)
def test_domino(pieces, expected_traces):
    actual_traces = list(arrange_domino_pieces(pieces))
    assert actual_traces == expected_traces
