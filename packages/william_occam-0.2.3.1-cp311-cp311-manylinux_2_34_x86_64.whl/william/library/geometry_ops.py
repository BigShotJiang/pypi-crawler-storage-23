from math import cos, sin

import numpy as np

from william.library.basic_ops import Add, BinOp, Operator, UnaryOp
from william.library.canvas import GeometricFigure
from william.library.complex_ops import Mean
from william.library.filling import ExteriorFiller, JExteriorFiller
from william.library.precision import execute
from william.library.types import Array, ColPoint, FloatPoint, Point


class Meanadd(BinOp):
    _raw_specs = [
        (tuple[float, Array[float]], Array[float]),
        (tuple[Array[float], Array[float]], Array[float]),
    ]
    conditions = ((),)
    commutative = False

    def _call(self, x, y):
        raise ValueError("This operator should not be called.")

    @staticmethod
    def _suitable(output):
        return isinstance(output, np.ndarray) and sum(output.shape) > 0

    def _inverse(self, output, cond_inputs, cond):
        result = np.zeros_like(output)
        if len(output.shape) == 3:
            m = np.zeros(3)
            for i in range(3):
                m[i], result[:, :, i] = self._single_inverse(output[:, :, i])
            yield m, result
        else:
            yield self._single_inverse(output)

    @staticmethod
    def _single_inverse(output):
        m = Mean()._call(output)
        if np.all(np.isnan(m)):
            return m, np.zeros_like(output) * np.nan
        return m, list(Add()._inverse(output, (m,), (0,)))[0][0]


# ========== Geometry stuff ========== #


class Line(BinOp):
    _raw_specs = [
        (tuple[Point, Point], set[Point]),
        (tuple[Point, Point], list[Point]),
        (tuple[FloatPoint, FloatPoint], list[Point]),
    ]
    conditions = ()
    commutative = True

    def __init__(self):
        self.geom = GeometricFigure()
        self._dl = 1.0

    def _call(self, p1, p2):
        if len(p1) != 2 or len(p2) != 2:
            raise ValueError("inputs have to be 2-dimensional")
        p1, p2 = sorted([p1, p2])
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        return self.geom.diff_line(p1[0], p1[1], dx, dy)


class Arc(Operator):
    """
    Draw an arc between points p1 and p2 with a certain curvature. Curvature is in [-1, 1]. 0 is a straight line,
    +1 is maximal (i.e. with center of arc being in the middle between p1 and p2), -1 maximal in the other direction.
    """

    _raw_specs = [
        (tuple[Point, Point, float], set[Point]),
        (tuple[Point, Point, float], list[Point]),
        (tuple[FloatPoint, FloatPoint, float], list[Point]),
    ]
    conditions = ()
    commutative = False

    def __init__(self):
        self.geom = GeometricFigure()
        self._dl = 1.0

    def _call(self, p1, p2, curvature):
        if len(p1) != 2 or len(p2) != 2:
            raise ValueError("inputs have to be 2-dimensional")
        if p1 is p2:
            raise ValueError("Points have to be different.")
        if curvature == 0:
            return Line()._call(p1, p2)
        return self.geom.arc(p1, p2, curvature)


class Triangle(Operator):
    _raw_specs = [(tuple[Point, Point, Point], list[Point])]
    conditions = ()
    commutative = True

    def __init__(self):
        self.geom = GeometricFigure()
        self._dl = 1.0

    def _call(self, p1, p2, p3):
        corners = [p1, p2, p3]
        if any(len(c) != 2 for c in corners):
            raise ValueError("inputs have to be 2-dimensional")
        return self.geom.polygon(corners, unique=True)


class Fill(UnaryOp):
    _raw_specs = [
        (tuple[set[Point]], set[Point]),
        (tuple[list[Point]], list[Point]),
    ]
    conditions = ()

    def __init__(self, shape=(), closed_paths_only=True):
        self.filler = JExteriorFiller(shape=shape, closed_paths_only=closed_paths_only)
        self._dl = 1.0

    def _call(self, points):
        return self.filler.fill(points)


class SlowFill(UnaryOp):
    _raw_specs = [
        (tuple[set[Point]], set[Point]),
        (tuple[list[Point]], list[Point]),
    ]
    conditions = ()

    def __init__(self, shape=None, closed_paths_only=True):
        self.filler = ExteriorFiller(shape=shape, closed_paths_only=closed_paths_only)
        self._dl = 1.0

    def _call(self, points):
        return self.filler.fill(points, cut_borders=True)


class Compose(Operator):
    _raw_specs = [
        (tuple[Array[float], set[Point], Array[float]], Array[float]),
        (tuple[Array[float], list[Point], Array[float]], Array[float]),
    ]
    conditions = ((1,),)
    commutative = False

    def _call(self, x1, points, x2):
        if x1.shape != x2.shape:
            raise ValueError("Wrong shape")
        int_idx = tuple(np.array(x) for x in zip(*points))
        if _bad_int_idx(int_idx, x1.shape):
            raise IndexError("Indices out of bounds.")
        bool_idx = np.zeros_like(x1, dtype=bool)
        bool_idx[int_idx] = True
        result = np.zeros_like(x1)
        result[bool_idx] = x2[bool_idx]
        result[~bool_idx] = x1[~bool_idx]
        return result

    def _inverse(self, output, cond_inputs, cond):
        bool_idx = np.zeros_like(output, dtype=bool)
        y = list(zip(*cond_inputs[0]))
        int_idx = (np.array(y[0]), np.array(y[1]))
        if _bad_int_idx(int_idx, output.shape):
            return
        bool_idx[int_idx] = True
        x1 = output.copy()
        x2 = output.copy()
        x1[bool_idx] = np.nan
        x2[~bool_idx] = np.nan
        yield x1, x2


def _bad_int_idx(int_idx, shape):
    return (
        np.any(int_idx[0] < 0)
        or np.any(int_idx[1] < 0)
        or np.any(int_idx[0] >= shape[0])
        or np.any(int_idx[1] >= shape[1])
    )


class PAdd(BinOp):
    _raw_specs = [
        (tuple[Point, Array[int]], Point),
        (tuple[FloatPoint, Array[float]], FloatPoint),
    ]
    conditions = (0,), (1,)
    commutative = False

    def _call(self, point, vector):
        if vector.shape != (len(point),):
            raise ValueError("Wrong shape")
        return point[0] + vector[0], point[1] + vector[1]

    def _inverse(self, output, cond_inputs, cond):
        result = [t - c for t, c in zip(output, cond_inputs[0])]
        if cond == (0,):
            yield (np.array(result),)
        else:
            yield (tuple(result),)


class Rotate(BinOp):
    _raw_specs = [
        (tuple[Array[int], float], Array[int]),
        (tuple[Array[float], float], Array[float]),
    ]
    conditions = ()
    commutative = False

    def _call(self, vec, angle):
        if not isinstance(vec, np.ndarray) and vec.kind != "i":
            raise ValueError("Wrong input")
        alpha = -angle * 2 * np.pi
        matrix = np.array([[np.cos(alpha), -np.sin(alpha)], [np.sin(alpha), np.cos(alpha)]])
        result = np.dot(matrix, vec)
        return result.astype(int)


class Cart(BinOp):
    """Convert from polar coordinates to cartesian in 2D."""

    _raw_specs = [(tuple[float, float], Array[float])]
    conditions = ()
    commutative = False

    def _call(self, r, alpha):
        return np.array([r * cos(alpha), r * sin(alpha)])


class Length(UnaryOp):
    """The Euclidean length of a vector."""

    _raw_specs = [(tuple[Array[int]], float), (tuple[Array[float]], float)]
    conditions = ()

    def _call(self, vec):
        if vec.shape != (2,):
            raise ValueError("Wrong shape.")
        return execute(lambda x: np.sqrt(np.sum(x.astype(float) ** 2)), (vec,))


class Distance(BinOp):
    """The Euclidean distance between points."""

    _raw_specs = [
        (tuple[Point, Point], float),
        (tuple[FloatPoint, FloatPoint], float),
    ]
    conditions = ()

    def _call(self, p1, p2):
        vec = np.array(p2, dtype=float) - np.array(p1, dtype=float)
        return execute(lambda x: np.sqrt(np.sum(x**2)), (vec,))


class AvgCol(BinOp):
    """
    Given an image and a list of points, compute the average color of those points in the image and return
    colored points.
    """

    _raw_specs = [(tuple[Array[float], list[Point]], list[ColPoint])]
    conditions = ()
    commutative = False

    def _call(self, img, points):
        int_idx = tuple(np.array(x) for x in zip(*points))
        if _bad_int_idx(int_idx, img.shape):
            raise IndexError("Indices out of bounds.")
        # i = 0
        # color = img[int_idx[0][i], int_idx[1][i], :]
        color = np.round(np.nanmean(img[int_idx], axis=0))
        return [(color, p) for p in points]


# class Dye(BinOp):
#     """
#     Given a color and a list of points, return colored points.
#     """
#
#     _raw_specs = [(Tuple[Array[float], List[Point]], List[ColPoint])]
#     conditions = ()
#     commutative = False
#
#     def _call(self, color, points):
#         return [(color, p) for p in points]


class Dye(UnaryOp):
    """
    Given a color and a list of points, return colored points.
    """

    _raw_specs = [(tuple[list[Point]], list[ColPoint])]
    conditions = ()
    commutative = False

    def __init__(self, image):
        self.image = image
        self._dl = 1.0

    def _call(self, points):
        color = np.zeros(3)
        for p in points:
            color += self.image[p]
        color = np.round(color / len(points))
        return [(color, p) for p in points]


class Draw(UnaryOp):
    _raw_specs = [(tuple[list[ColPoint]], Array[float])]
    conditions = ()

    def __init__(self, shape, background=np.zeros(3)):
        self.shape = shape
        self.background = background.reshape((1, -1))
        if shape[2] != len(background):
            raise ValueError("Shape does not fit to background color.")
        self._dl = 1.0

    def _call(self, colored_points):
        img = np.ones((self.shape[0], self.shape[1], 1))
        img = np.dot(img, self.background)
        for col, point in colored_points:
            if point[0] < 0 or point[1] < 0:
                continue
            # if np.any(col < 0):
            #     continue
            img[point[0], point[1], :] = col
        return img


img_shape = (60, 60)

meanadd = Meanadd()
line = Line()
arc = Arc()
triangle = Triangle()
fill = Fill(shape=img_shape, closed_paths_only=True)
slow_fill = SlowFill(shape=img_shape, closed_paths_only=False)
compose = Compose()
padd = PAdd()
rotate = Rotate()
cart = Cart()
length = Length()
distance = Distance()
avgcol = AvgCol()
dye = Dye(None)
draw = Draw((50, 50, 3))


geometry_ops = (
    compose,
    fill,
    slow_fill,
    rotate,
    padd,
    line,
    arc,
    distance,
    length,
    cart,
    meanadd,
    avgcol,
    dye,
    draw,
)
