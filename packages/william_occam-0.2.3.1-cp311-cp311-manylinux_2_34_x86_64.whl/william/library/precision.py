import warnings
from itertools import product

import intnan as inn
import numba as nb
import numpy as np
from numba.extending import overload, register_jitable

from william.library.types import int_type, number_type, py_type

MAX_PRECISION = 10
POW10 = 10.0 ** np.arange(-MAX_PRECISION, MAX_PRECISION + 1)


def custom_round(x, precision, round_halves_up=False):
    """
    Like numpy.round, but makes sure that 4.5 and 3.5 etc. are rounded up/down.
    The default behavior of numpy.round is to round the halves to the nearest even number.
    We don't want that, because we want to be able to reconstruct a number like this: round(round(a+b)-b) == a
    """
    rx = np.round(x, decimals=precision)
    eps = POW10[MAX_PRECISION - precision]
    sgn = 2 * int(round_halves_up) - 1
    if isinstance(x, np.ndarray):
        halves = np.zeros(x.shape, dtype=bool)
        valid = np.isfinite(x)
        halves[valid] = np.abs(x[valid] % eps - eps / 2) < 1e-13
        rx[halves] = x[halves] + sgn * eps / 2
        return rx
    if np.isnan(x):
        return np.nan
    halves = np.abs(x % eps - eps / 2) < 1e-13
    return x + sgn * eps / 2 if halves else rx


@register_jitable
def precision_array(x):
    max_prec = -1000
    cnt = 0
    ln = len(x)
    while cnt < min(ln, 10000):
        i = np.random.randint(ln) if ln > 10000 else cnt  # noqa
        prec = precision_scalar(x[i])
        if prec > max_prec:
            max_prec = prec
        cnt += 1
    return max_prec


@register_jitable
def precision_scalar(x):
    if np.isnan(x) or x == inn.INTNAN64:
        return -MAX_PRECISION
    if np.abs(x) < POW10[0]:
        return 0
    prec = 0
    positive = True
    for k in range(50):
        if prec <= 0 and np.abs(x - np.round(x, -k)) < POW10[0]:
            prec = -k
            positive = False
        elif not positive:
            return prec
        if positive and np.abs(x - np.round(x, k)) < POW10[0]:
            return k
    return prec


jprecision_array = nb.njit(precision_array)
jprecision_scalar = nb.njit(precision_scalar)


def jprecision(x):
    if isinstance(x, nb.types.Array | np.ndarray):
        if x.dtype == nb.types.bool_:
            return 0
        return jprecision_array(x.ravel())
    if x in (bool, nb.types.bool_):
        return 0
    return jprecision_scalar(x)


@overload(jprecision)
def _jprecision(x):
    if isinstance(x, nb.types.Array | np.ndarray):
        if x.dtype == nb.types.bool_:
            return lambda x: 0

        def impl(x):
            return precision_array(x.ravel())

        return impl

    if isinstance(x, bool):
        return lambda x: 0
    return precision_scalar


def first_decimal_precision(x):
    """Return the precision of the first non-zero decimal.
    E.g. 0.052 -> 2, 0.00063234 -> 4 and 543.74 --> -2, 5.6 -> 0"""
    if isinstance(x, np.ndarray):
        with warnings.catch_warnings(action="ignore", category=RuntimeWarning):
            x = np.nanmin(np.abs(x))
    if np.isnan(x) or x == inn.INTNAN64:
        return -MAX_PRECISION
    a = POW10 > x
    if np.any(a):
        return MAX_PRECISION - np.where(a)[0][0] + 1
    return -MAX_PRECISION + 1


def infer_precision(func, inputs, vary=True):
    prec = max(jprecision(inp) for inp in inputs)
    if not vary:
        return prec
    eps = POW10[MAX_PRECISION - prec] * 0.5001
    min_func, max_func = np.inf, -np.inf
    for signs in product(*[[-1, 1]] * len(inputs)):
        shifted_inputs = [inp + sgn * eps for inp, sgn in zip(inputs, signs)]
        with np.errstate(invalid="ignore"):
            output = func(*shifted_inputs)
        min_func = np.minimum(min_func, output)
        max_func = np.maximum(max_func, output)
    tol_precision = first_decimal_precision(max_func - min_func)
    return np.sign(tol_precision) * min(abs(tol_precision), MAX_PRECISION)


def execute(func, inputs, vary=True, ignore_precision=False):
    """A precision-sensitive execution of func(*inputs)"""
    result = func(*inputs)
    if ignore_precision or all(int_type(inp) for inp in inputs):
        return result
    # TODO: what if only some of the function's inputs are number-like? precision treatment will fail
    if not all(number_type(inp) for inp in inputs):
        return result
    prec = infer_precision(func, inputs, vary=vary)
    if prec is None:
        raise ValueError("Output can not be inferred with enough precision")
    # during inversion, we always round halves down; during execution, we round them up
    return custom_round(result, prec, round_halves_up=True)


def recursive_match(a, b):
    """
    Go through the structures a and b recursively and check if the floats contained match up to given precision.
    All other types much match exactly.
    The match is asymmetric: <a> is the target to be matched by the estimate <b>
    """
    a, b = py_type(a), py_type(b)
    if not isinstance(a, type(b)) and not isinstance(b, type(a)):
        # ints and floats should not lead to a type mismatch
        if not isinstance(a, int | float) or not isinstance(b, int | float):
            return False
    if isinstance(a, float) or isinstance(b, float):
        if np.isnan(a):  # anything fits a NaN
            return True
        if np.isnan(b):  # if target is a valid number, but the estimate is a NaN -> no match
            return False
        if not np.isfinite(a) and not np.isfinite(b):  # np.inf
            return a == b
        return np.abs(float(a) - np.round(float(b), jprecision_scalar(float(a)))) < POW10[0]
    if isinstance(a, tuple | list):
        if len(a) != len(b):
            return False
        for x, y in zip(a, b):
            if not recursive_match(x, y):
                return False
        return True
    if isinstance(a, np.ndarray):
        if a.shape != b.shape:
            return False
        if any(s == 0 for s in a.shape):
            return True
        if a.dtype.kind != b.dtype.kind:
            # ints and floats should not lead to a type mismatch
            if a.dtype.kind not in ["i", "f"] or b.dtype.kind not in ["i", "f"]:
                return False
        if a.dtype.kind in ["i", "f"]:
            a_not_nan = ~inn.isnan(a)
            decimals = jprecision_array(a.ravel()) if a.dtype.kind == "f" else 0.0
            if np.any(inn.isnan(b[a_not_nan])):
                return False
            both_infinite = ~np.isfinite(a) & ~np.isfinite(b)
            if np.any(a[a_not_nan & both_infinite] != b[a_not_nan & both_infinite]):
                return False
            finite = a_not_nan & ~both_infinite
            return np.all(np.abs(a[finite] - b[finite]) <= 0.5 * 10.0 ** (-decimals) + 1e-10)
        return np.all(a == b)  # bool- and str-arrays
    if hasattr(a, "root") and hasattr(b, "root"):
        return a.root.resembles(b.root)
    return a == b


def match(value1, value2, exact=False):
    if type(value1) != type(value2):
        return False
    if isinstance(value1, np.ndarray) and isinstance(value2, np.ndarray):
        if exact:
            if len(value1) != len(value2):
                return False
            if value1.dtype.kind != value2.dtype.kind:
                return False
            return np.all(value1 == value2)
        else:
            if len(value1) < len(value2):
                return False
            value1_trunc = value1[: len(value2)]
            if value1_trunc.shape != value2.shape:
                return False
            return np.all(value1_trunc == value2)
    return value1 == value2
