import numpy as np

from william.library.filling import LineFiller, get_boundary
from william.library.types import Point, specify
from william.paths import PROJECT_ROOT
from william.rendering import scale_array


class GeometricFigure:
    def __init__(self, y_lim=None, x_lim=None):
        self.y_lim = y_lim
        self.x_lim = x_lim

    def _outside(self, y, x):
        if self.y_lim is not None and (y < self.y_lim[0] or y >= self.y_lim[1]):
            return True
        if self.x_lim is not None and (x < self.x_lim[0] or x >= self.x_lim[1]):
            return True
        return False

    @staticmethod
    def round_range(a0, da, sa):
        if abs(da / sa) > 1e4:
            raise ValueError("Too large a number.")
        rnd = np.floor if da >= 0 else np.ceil
        return rnd(np.arange(a0, a0 + da, sa)).astype(int)

    def diff_line(self, y0, x0, dy, dx):
        if self._outside(y0, x0) or self._outside(y0 + dy, x0 + dx):
            raise ValueError("Line outside given limits.")
        y0, x0 = int(np.round(y0)), int(np.round(x0))
        dy += np.sign(dy) if dy != 0 else 1
        dx += np.sign(dx) if dx != 0 else 1
        sy, sx = dy / float(abs(dx)), np.sign(dx)
        if abs(dx) < abs(dy):
            sy, sx = np.sign(dy), dx / float(abs(dy))
        y = self.round_range(y0, dy, sy)
        x = self.round_range(x0, dx, sx)
        points = [(y0, x0)]
        for p in zip(y, x):
            if p != points[-1]:
                points.append(p)
        return points

    def line(self, c0, c1):
        dx = c1[0] - c0[0]
        dy = c1[1] - c0[1]
        return self.diff_line(c0[0], c0[1], dx, dy)

    def polygon(self, corners, unique=False):
        corners = [tuple(c) for c in corners]
        if unique and len(set(corners)) < len(corners):
            raise ValueError("All corners have to be different.")
        points = []
        for c0, c1 in zip(corners, corners[1:] + corners[:1]):
            points.extend(self.line(c0, c1))
        return points

    def filled_polygon(self, corners, filler, unique=False):
        borders = self.polygon(corners, unique=unique)
        return filler.fill(borders)

    @classmethod
    def arc(cls, p1, p2, curvature):
        # if curvature == -1:
        #     curvature = -0.999999999
        p1 = np.array(p1, dtype=float)
        p2 = np.array(p2, dtype=float)
        vec = p2 - p1
        min_radius = np.sqrt(np.sum(vec**2)) / 2
        # radius of the arc
        radius = 1 / np.abs(curvature)  # * min_radius
        if radius < min_radius:
            raise ValueError("Curvature has to be between -1/min_radius and +1/min_radius")

        # distance between arc (circle) center and the line p1-p2
        cathetus = np.sqrt(radius**2 - min_radius**2)
        # standard normal pointing from the line midpoint to the center of the arc
        normal = np.array([-vec[1], vec[0]]) * np.sign(curvature)
        length = np.sqrt(np.sum(normal**2))
        if length == 0:
            raise ValueError("Can't compute arc between one and the same point.")
        normal /= length
        # center point of the arc
        center = p1 + vec / 2 + normal * cathetus
        angle1, angle2, sgn = cls._angles(center, p1, p2)
        result = []
        # result.add((int(center[0]), int(center[1])))
        step = 1 / radius / 2 * np.sign(angle2 - angle1)
        for angle in np.arange(angle1, angle2, step):
            x = center[0] + radius * np.cos(angle) * sgn
            y = center[1] + radius * np.sin(angle) * sgn  # = np.sign(dy1/dx1) * np.sign(dy1)
            point = (int(round(x)), int(round(y)))
            if not result or point != result[-1]:
                result.append(point)
        return result

    @staticmethod
    def _angles(center, p1, p2):
        # two angles that the center-endpoint lines make with respect to the horizontal
        dx1, dy1 = (p1[0] - center[0]), (p1[1] - center[1])
        dx2, dy2 = (p2[0] - center[0]), (p2[1] - center[1])
        angle1 = np.pi / 2 * np.sign(dy1) if dx1 == 0 else np.arctan(dy1 / dx1)
        angle2 = np.pi / 2 * np.sign(dy2) if dx2 == 0 else np.arctan(dy2 / dx2)
        # take care of the sign business in the tangent and arc tangent (do the math on paper..)
        if np.sign(dx1) != np.sign(dx2):
            angle2 += np.pi
        # make sure that the arc does not span more than 180 degrees
        if angle2 > angle1 + np.pi:
            angle2 -= 2 * np.pi
        if angle2 < angle1 - np.pi:
            angle2 += 2 * np.pi
        return angle1, angle2, np.sign(dx1) if dx1 != 0 else 1


class Canvas:
    # TODO: Should probably be generic

    def __init__(self, y_lim=None, x_lim=None):
        self.geom = GeometricFigure(y_lim=y_lim, x_lim=x_lim)

    @staticmethod
    def image_from_file(filename):
        from PIL import Image

        return np.array(Image.open(PROJECT_ROOT / filename), dtype=float)

    @classmethod
    def make_image(cls, points, x_lim=(), y_lim=(), draw=True, offset=0, color=255):
        if not points:
            return
        if not x_lim or not y_lim:
            x_lim, y_lim, _, _ = get_boundary(points)
        dx = x_lim[1] - x_lim[0]
        dy = y_lim[1] - y_lim[0]
        dim = (dx + 2 * offset, dy + 2 * offset)
        rgb = isinstance(color, np.ndarray)
        if rgb:
            dim += (3,)
        image = np.zeros(dim)
        for x, y in points:
            if x < x_lim[0] or x >= x_lim[1]:
                continue
            if y < y_lim[0] or y >= y_lim[1]:
                continue
            xs = offset + x - x_lim[0]
            ys = offset + y - y_lim[0]
            if rgb:
                image[xs, ys, :] = color
            else:
                image[xs, ys] = color
        if not draw:
            return image
        cls.draw_image(image, x_lim=x_lim, y_lim=y_lim, offset=offset)
        return image

    @staticmethod
    def _scaled_ticks(a, b):
        max_tick_num = 10.0
        n0 = b - a
        step = max(int(n0 / max_tick_num), 1)
        nums = np.array(range(0, n0, step))
        return nums, nums + a

    @classmethod
    def draw_image(cls, image, x_lim=(), y_lim=(), offset=0):
        if not x_lim:
            x_lim = [0, image.shape[0]]
        if not y_lim:
            y_lim = [0, image.shape[1]]
        if image.dtype.kind == "f":
            image = image.astype(int)

        try:
            import matplotlib.pyplot as plt
        except ImportError:
            return
        plt.imshow(image, interpolation="nearest", cmap="gray", vmin=0, vmax=255)
        ax = plt.gca()
        pos, labels = cls._scaled_ticks(y_lim[0] - offset, y_lim[1] + offset)
        ax.set_xticks(pos)
        ax.set_xticklabels(labels)
        ax.xaxis.tick_top()
        pos, labels = cls._scaled_ticks(x_lim[0] - offset, x_lim[1] + offset)
        ax.set_yticks(pos)
        ax.set_yticklabels(labels)
        plt.show(block=False)

    @classmethod
    def draw_section(cls, section, repl_nan=0.0):
        img = section.nodes[0].output.copy()
        rgb = len(img.shape) == 3
        offset = np.array([70.0, 70.0, 70.0]) if rgb else 70.0
        for val_node in section.walk(op_nodes=False):
            if specify(val_node.output) != set[Point]:
                continue
            for y, x in val_node.output:
                if rgb:
                    img[y, x, :] = offset if np.any(np.isnan(img[y, x, :])) else img[y, x, :] + offset
                else:
                    img[y, x] = offset if np.isnan(img[y, x]) else img[y, x] + offset
        img = scale_array(img, repl_nan=repl_nan)
        cls.draw_image(img, x_lim=[0, img.shape[0]], y_lim=[0, img.shape[1]])

    def polygon_image(self, corners, size=(50, 50), colors=(np.nan, 255.0)):
        points = self.geom.filled_polygon(corners, LineFiller())
        img = np.ones(size) * colors[0]
        for p in points:
            img[p] = colors[1]
        return points, img
