import typing as tp
from collections.abc import Callable, MutableSequence
from functools import cmp_to_key
from itertools import product

import numpy as np
from typing_inspect import (
    is_callable_type,
    is_generic_type,
    is_tuple_type,
    is_typevar,
    is_union_type,
)

T1 = tp.TypeVar("T1", covariant=True)
T2 = tp.TypeVar("T2", covariant=True)
T3 = tp.TypeVar("T3", covariant=True)
T = tp.TypeVar("T")

# TODO: Changing the order here should not mess up things
DEFAULT_TYPES = int, float, str, bool, list, set, np.ndarray
TYPE_VARS = {t.__name__: t for t in (T1, T2, T3)}

array_type = {"i": (int,), "f": (float,), "b": (bool,), "U": (str, chr)}
int_like = int, np.int32, np.int64
float_like = float, np.float32, np.float64
number_like = int_like + float_like

_numpy_to_python = {
    np.int32: int,
    np.int64: int,
    np.float32: float,
    np.float64: float,
    np.bytes_: bytes,
    np.bool_: bool,
}


def py_type(x):
    if type(x) in _numpy_to_python:
        return _numpy_to_python[type(x)](x)
    return x


def iter_type(x):
    if isinstance(x, (list, tuple, set)):
        return type(x)
    if isinstance(x, np.ndarray):
        return np.array
    return None


def int_type(x):
    return isinstance(x, int_like) or isinstance(x, np.ndarray) and x.dtype.kind == "i"


def float_type(x):
    return isinstance(x, float_like) or isinstance(x, np.ndarray) and x.dtype.kind == "f"


def number_type(x):
    return int_type(x) or float_type(x)


def convert(x, py_type):
    if isinstance(x, np.ndarray):
        return x.astype(py_type)
    return py_type(x)


class _PrettyAlias(tp.GenericAlias):
    def __repr__(self):
        args = ", ".join(tp._type_repr(a) for a in self.__args__)
        return f"{self.__origin__.__name__}[{args}]"

    def __mro_entries__(self, bases):
        # issubclass(..., Array) will look like a normal class
        return (self.__origin__,)


class Array(MutableSequence[T], tp.Generic[T]):
    """Typing-only wrapper for numpy.ndarray."""

    __slots__ = ()
    _name = "Array"

    def __new__(cls, *args, **kwds):
        if getattr(cls, "_gorg", None) is Array:
            raise TypeError("Type Array cannot be instantiated; use array() instead")
        return tp._generic_new(np.array, cls, *args, **kwds)

    @classmethod
    def __class_getitem__(cls, params):
        # use custom alias for prettier repr
        return _PrettyAlias(cls, params)


list_like = tuple, list, set, Array
list_like_py = tuple, list, set, np.ndarray
Point = tuple[int, int]
FloatPoint = tuple[float, float]
ColPoint = tuple[Array[float], Point]


def _get_name(spec):
    if spec is None:
        return
    if hasattr(spec, "__origin__"):
        return spec.__origin__.__name__
    if spec in (tuple, list, set, dict) or isinstance(spec, tp.TypeVar):
        return spec.__name__
    return spec.__dict__.get("_name", None)


def issubspec(subspec, spec):
    """
    Determine if a type specification is compatible with a more general one.

    issubspec(List, List[int]) -> False
    issubspec(List[str], List) -> True
    issubspec(List[str], List[str]) -> True
    """
    # This might need more careful handling
    # See: https://github.com/python/mypy/blob/master/mypy/subtypes.py#L45
    if isinstance(spec, tuple):
        return any(issubspec(subspec, sp) for sp in spec)
    if subspec == spec:
        return True
    if is_typevar(spec):
        return True
    name1 = _get_name(subspec)
    name2 = _get_name(spec)
    if name1 is None or name2 is None:
        return False
    if name1 != name2:
        return False
    subspec_args = getattr(subspec, "__args__", None)
    spec_args = getattr(spec, "__args__", None)
    if not spec_args:  # e.g. List[int] is sub-spec of List
        return True
    if not subspec_args:  # since spec has arguments, if sub-spec hasn't, it can't be a sub-spec
        return False
    if len(subspec_args) != len(spec_args):
        return False
    return all(issubspec(s1, s2) for s1, s2 in zip(subspec_args, spec_args))


def isvarspec(spec):
    """Decide if a specification contains type variables."""
    if is_typevar(spec):
        return True
    if issubspec(spec, (list, set, Array)) or is_tuple_type(spec) or is_callable_type(spec):
        return any(isvarspec(subspec) for subspec in spec.__args__)
    return False


def get_typevars(spec, seen=None):
    """Yield all type variables in spec."""
    if seen is None:
        seen = set()
    if is_typevar(spec):
        if spec in seen:
            return
        yield spec
        seen.add(spec)
    elif isinstance(spec, tuple):
        for subspec in spec:
            yield from get_typevars(subspec, seen=seen)
    elif issubspec(spec, (list, set, Array)) or is_tuple_type(spec) or is_callable_type(spec):
        for subspec in spec.__args__:
            yield from get_typevars(subspec, seen=seen)


def specify(obj):
    """Create a fitting type definition for the given object."""
    if isinstance(
        obj,
        bool | int | np.integer | np.float64 | np.float32 | float | str | slice | np.bool_ | type(None),
    ):
        return type(py_type(obj))
    if isinstance(obj, list):
        if not obj:
            # empty list with unknown type
            return list
        else:
            # All list items must be of the same type
            # TODO: Do we need a check for this?
            return list[specify(obj[-1])]
    if isinstance(obj, set):
        if not obj:
            # empty set with unknown type
            return set
        else:
            # All set items must be of the same type
            # TODO: Do we need a check for this?
            return set[specify(next(iter(obj)))]
    if isinstance(obj, np.ndarray) and obj.dtype.kind in array_type:
        return Array[array_type[obj.dtype.kind][0]]
    if isinstance(obj, tuple):
        return tuple[tuple(specify(v) for v in obj)]
    if callable(obj):
        return tp.Callable
    raise TypeError(f"Cannot specify {type(obj).__name__}")


def typecheck(obj, spec):
    """Decide if an object fits a certain type specification."""
    if is_typevar(spec):
        return False
    if isinstance(obj, int | np.integer | float | np.float32 | np.float64 | str):
        # extra check due to bug in Python <= 3.5.3, e.g. isinstance(3, tp.List[int])
        # https://github.com/python/typing/issues/477
        if issubspec(spec, (list, tuple, set, Array)):
            return False
        if isinstance(obj, bool) and spec == int:  # we don't want typecheck(False, int) to be true
            return False
        return isinstance(py_type(obj), spec)
    if isinstance(obj, slice):
        return spec == slice
    if isinstance(obj, tuple) and is_tuple_type(spec) and len(obj) == len(spec.__args__):
        return all(typecheck(o, s) for o, s in zip(obj, spec.__args__))
    if isinstance(obj, list | set | np.ndarray) and is_generic_type(spec):
        spec_cls = {list: list, set: set, np.ndarray: Array}[type(obj)]
        if not issubspec(spec, spec_cls):
            return False
        if spec.__args__ == ():
            return len(obj) == 0
        if len(spec.__args__) != 1:
            return False
        return all(typecheck(o, spec.__args__[0]) for o in obj)
    return False


def unify(varspec, spec):
    """Create a dictionary of type replacements."""
    if varspec is spec:
        return {}
    if isinstance(varspec, tp.TypeVar):
        return {varspec: spec}
    if isinstance(spec, tp.TypeVar):
        repl = unify(spec, varspec)
        return dict((v, k) for k, v in repl.items())  # reverse the repl dictionary
    if varspec == spec:
        return {}
    if issubspec(varspec, list) and issubspec(spec, list):
        return unify(varspec.__args__[0], spec.__args__[0])
    if issubspec(varspec, set) and issubspec(spec, set):
        return unify(varspec.__args__[0], spec.__args__[0])
    if issubspec(varspec, Array) and issubspec(spec, Array):
        return unify(varspec.__args__[0], spec.__args__[0])
    if (is_tuple_type(varspec) and is_tuple_type(spec)) or (
        is_callable_type(varspec) and (is_callable_type(spec) or spec == Callable)
    ):
        if not hasattr(spec, "__args__") or spec.__args__ == ():
            return {}
        if len(varspec.__args__) != len(spec.__args__):
            raise TypeError("Type description does not match")
        ret = {}
        for vs, s in zip(varspec.__args__, spec.__args__):
            if (vs == ()) or (s == ()):
                raise TypeError("Not type object in tp.Tuple!")
            ret_tmp = unify(vs, s)
            if any(unify(ret_tmp[key], ret[key]) for key in ret_tmp if key in ret):
                raise TypeError("Type description does not match")
            ret.update(ret_tmp)
        return ret
    if is_union_type(varspec):
        ret = {}
        for vs in varspec.__args__:
            # TODO: This does not check for contradictions and simply overwrites them
            ret.update(unify(vs, spec))
        return ret
    raise TypeError("Type description does not match")


def typereplace(varspec, repl):
    if varspec in repl:
        return repl[varspec]
    if hasattr(varspec, "__args__") and varspec.__args__ == ():
        return varspec
    if issubspec(varspec, list):
        return list[typereplace(varspec.__args__[0], repl)]
    if issubspec(varspec, set):
        return set[typereplace(varspec.__args__[0], repl)]
    if issubspec(varspec, Array):
        return Array[typereplace(varspec.__args__[0], repl)]
    if is_tuple_type(varspec):
        return tuple[tuple(typereplace(vs, repl) for vs in tuple_args(varspec))]
    if is_union_type(varspec):
        return tp.Union[tuple(typereplace(vs, repl) for vs in varspec.__args__)]  # noqa
    if is_callable_type(varspec):
        return Callable[
            [typereplace(arg, repl) for arg in varspec.__args__[:-1]],
            typereplace(varspec.__args__[-1], repl),
        ]
    return varspec


def tuple_args(spec):
    if not is_tuple_type(spec):
        raise ValueError("Not Tuple type")
    if not spec.__args__:
        raise ValueError("Tuple without args")
    return () if spec.__args__ == ((),) else spec.__args__


# -----------------------------
# Serialisierung
# -----------------------------


def spec_str(spec):
    if spec in DEFAULT_TYPES:
        return spec.__name__
    if spec is None:
        return ""

    # TODO: get rid of explicit directory structure
    spec = str(spec).replace("tp.", "").replace("typing.", "")
    return spec.replace("william.library.types.", "").replace("collections.abc.", "")


# -----------------------------
# Parser for type strings
# -----------------------------

BASE_TYPES: dict[str, tp.Any] = {
    "int": int,
    "float": float,
    "str": str,
    "bool": bool,
    "list": list,
    "tuple": tuple,
    "set": set,
    "Array": Array,
}


def str_to_spec(s: str) -> tp.Any:
    """Parst einen Typ-String wie 'tuple[list[int], set[float]]' rekursiv."""

    s = s.strip()

    # Basisfall: keine eckigen Klammern
    if "[" not in s:
        if s not in BASE_TYPES:
            raise ValueError(f"Unknown type name: {s}")
        return BASE_TYPES[s]

    # Split: name[args...]
    name, rest = s.split("[", 1)
    if not rest.endswith("]"):
        raise ValueError(f"Malformed type string: {s}")
    inner = rest[:-1]  # strip letzter ']'

    # Argumente parsen (durch Kommata, aber klammerbalanciert!)
    args: list[str] = []
    depth = 0
    current = []
    for ch in inner:
        if ch == "," and depth == 0:
            args.append("".join(current).strip())
            current = []
        else:
            if ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
            current.append(ch)
    if current:
        args.append("".join(current).strip())

    # rekursiv auflösen
    parsed_args = [str_to_spec(arg) for arg in args]

    if name not in BASE_TYPES:
        raise ValueError(f"Unknown type name: {name}")
    base = BASE_TYPES[name]
    return base[tuple(parsed_args)] if len(parsed_args) > 1 else base[parsed_args[0]]


# -----------------------------
# Spec sorting
# -----------------------------


def sort_specs(spec_list: list[tp.Any]):
    """
    Sort a list of type specifications from the most specific to the most general.
    """

    def cmp(spec1, spec2):
        is1 = issubspec(spec1, spec2)
        is2 = issubspec(spec2, spec1)
        if is1 and not is2:
            return -1
        if is1 and is2:
            return 0
        if not is1 and not is2:
            raise ValueError("For sorting to work, each spec has to be a subtype of the other in the list.")
        return 1

    try:
        # sorted_list = sorted(spec_list, key=cmp_to_key(cmp))
        sorted_indices = sorted(range(len(spec_list)), key=cmp_to_key(lambda i, j: cmp(spec_list[i], spec_list[j])))
    except ValueError:
        return []
    return sorted_indices


def concretize_specs(specs, concrete_types):
    """
    spec: A tuple of types, e.g. (tuple[Callable[[tuple[T2]], T1], Array[T2]], Array[T1])
    concrete_types: List of concrete types, e.g. [int, float]
    Yields all concretized specs, where type variables are replaced by all combinations of the concrete types.
    """
    if not isinstance(specs, tuple):
        raise TypeError("Specs must be a tuple of types.")
    # Find all type variables in the spec
    typevars = list(get_typevars(specs))
    # Iterate over all combinations of concrete types for the type variables
    for types in product(concrete_types, repeat=len(typevars)):
        repl = dict(zip(typevars, types))
        # Replace the type variables in the spec
        concretized = tuple([typereplace(spec, repl) for spec in specs])
        yield concretized
