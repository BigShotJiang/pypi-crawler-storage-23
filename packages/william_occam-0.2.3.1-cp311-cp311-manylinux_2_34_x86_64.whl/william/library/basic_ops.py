import os
from collections import defaultdict
from collections.abc import Callable, Iterable
from copy import deepcopy
from functools import reduce
from itertools import chain, product

import intnan as inn
import numpy as np

from william.library.base import BinOp, Operator, UnaryOp
from william.library.functions import brange, mult, repeat, unique_with_inverse_preallocated
from william.library.precision import (
    MAX_PRECISION,
    POW10,
    custom_round,
    execute,
    first_decimal_precision,
    jprecision,
    recursive_match,
)
from william.library.types import T1, T2, Array, float_like, float_type, int_like, iter_type, number_like, specify
from william.utils.workspace import get_workspace

exec_errors = (TypeError, ValueError, ZeroDivisionError, IndexError, KeyError, OverflowError, AttributeError)
level = int(os.getenv("WILLIAM_DEBUG", "0"))

ws = get_workspace()


class Map(Operator):
    _raw_specs = [
        (tuple[Callable[[tuple[T2]], T1], list[T2]], list[T1]),
        (tuple[Callable[[tuple[T2]], T1], Array[T2]], Array[T1]),
    ]
    conditions = ((0,),)
    commutative = False
    has_callable = True

    def _call(self, x, y):
        func = getattr(x, "_call", x)
        short_cut_worked = False
        try:
            result = func(y)
            if isinstance(result, Iterable):
                short_cut_worked = True
        except exec_errors:
            pass
        if not short_cut_worked:
            result = list(map(func, y))
        if isinstance(y, np.ndarray):
            result = np.array(result)
        return result

    def _inverse(self, output, cond_inputs, cond):
        """
        :cond_inputs[0]: must be a function
        """
        func = cond_inputs[0]

        # shortcut implementation if function takes arrays/lists
        if func._suitable(output):
            # being cautious here, since the func is not in general expected to take arrays/lists
            try:
                for inv in func._inverse(output, (), ()):
                    yield inv
                return
            except exec_errors:
                pass

        inv_list = defaultdict(lambda: [[] for _ in range(len(output))])
        num_inverses = defaultdict(lambda: [0] * len(output))
        for i, t in enumerate(output):
            if not func._suitable(t):
                if level > 10:
                    raise ValueError(f"Value {t} not suitable for inversion of callable {func} inside Map.")
                return  # Unsuitable output for callable
            # collect inversions categorized by type and count their numbers
            for inv in func._inverse(t, (), ()):
                typ = type(inv[0])
                inv_list[typ][i].append(inv)
                num_inverses[typ][i] += 1

        for typ, nums in num_inverses.items():
            if np.prod(nums) > 100:
                del inv_list[typ]
        if len(inv_list) == 0:
            return  # Too many inversions

        for single_type_inv_list in inv_list.values():
            for inps in product(*single_type_inv_list):
                result = list(chain(*inps))
                if isinstance(output, np.ndarray):
                    try:
                        result = np.array(result)
                    except OverflowError:
                        continue
                yield (result,)


class Reduce(Operator):
    # the output of the function must be of the same type as the first input,
    # since it is reinserted into the first input of the function
    _raw_specs = [(tuple[Callable[[tuple[T1, T1]], T1], Array[T1]], T1)]
    conditions = ((0, 1),)
    commutative = False
    has_callable = True

    def _call(self, func, some_array):
        func = getattr(func, "_call", func)
        return reduce(func, some_array)


class Negate(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (int, float, Array[int], Array[float])]  # Don't include bool
    conditions = ((),)

    def _call(self, x):
        if isinstance(x, np.ndarray):
            invalid = inn.isnan(x)
            res = ws.tmp(like=x)
            res[:] = -x
            res[invalid] = x[invalid]
        else:
            res = -x if not inn.isnan(x) else x
        return res

    @staticmethod
    def _suitable(output):
        return isinstance(output, number_like) or specify(output) in [Array[int], Array[float], list[float], list[int]]

    def _inverse(self, output, cond_inputs, cond):
        if isinstance(output, list):
            res = self._call(np.array(output)).tolist()
        else:
            res = self._call(output)
        yield (res,)


class Invert(UnaryOp):
    _raw_specs = [(tuple[t], t) for t in (float, Array[float])]
    conditions = ((),)

    def _call(self, x):
        if isinstance(x, float_like) and x == 0:
            raise ZeroDivisionError
        if isinstance(x, np.ndarray) and np.any(x == 0):
            raise ZeroDivisionError
        return execute(lambda y: 1 / y, (x,), ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        return isinstance(output, number_like) and not np.any(output == 0)

    def _inverse(self, output, cond_inputs, cond):
        yield (1 / output,)


class Add(BinOp):
    common_specs = [
        # (tuple[int, float], float),
        (tuple[float, float], float),
        (tuple[Array[int], Array[int]], Array[int]),
        (tuple[Array[int], int], Array[int]),
        (tuple[Array[float], Array[float]], Array[float]),
        # (tuple[Array[int], Array[float]], Array[float]),
        # (tuple[Array[float], int], Array[float]),
        (tuple[Array[float], float], Array[float]),
    ]
    _raw_specs = common_specs[:1] + [(tuple[int, int], int)] + common_specs[1:]

    conditions = (0,), (1,)
    commutative = True

    def _call(self, *args):
        def my_sum(*my_args):
            z = 0
            shape = None
            for arg in my_args:
                if not isinstance(arg, np.ndarray):
                    if inn.isnan(arg):
                        return arg
                    z += arg
                    continue
                if shape is None:
                    shape = arg.shape
                if arg.shape != shape:
                    raise ValueError("Shape mismatch.")
                if not isinstance(z, np.ndarray):
                    z = np.full(shape, z, dtype=arg.dtype)
                z += arg
                z[inn.isnan(arg)] = inn.nanval(z)
            return z

        return execute(my_sum, args, ignore_precision=self.ignore_precision)

    @staticmethod
    def _suitable(output):
        if isinstance(output, np.ndarray):
            return sum(output.shape) > 0
        return isinstance(output, (np.ndarray,) + int_like + float_like)

    @staticmethod
    def check(inp, output):
        if isinstance(output, number_like):
            if not isinstance(inp, number_like):  # Has to be a number
                return False
            if not np.isfinite(output) or not np.isfinite(inp):
                return False  # Has to be finite
        else:
            if isinstance(inp, np.ndarray) and inp.shape != output.shape:
                return False  # Array shape mismatch
        return True

    @staticmethod
    def inv_func(cond):
        def my_sub(i, t):
            if isinstance(t, np.ndarray) or isinstance(i, np.ndarray):
                dtype = np.float64 if float_type(t) or float_type(i) else t.dtype
                result = ws.tmp(shape=t.shape, dtype=dtype)
                np.add(t, -i, out=result)
                return result
            return t - i

        return my_sub

    @staticmethod
    def _check_int(output):
        return isinstance(output, int_like)

    def _inverse(self, output, cond_inputs, cond):
        z = cond_inputs[0]
        if not self.check(z, output):
            return  # Wrong inputs

        out_array = isinstance(output, np.ndarray)
        z_array = isinstance(z, np.ndarray)
        inv_func = self.inv_func(cond)
        result = inv_func(z, output)

        if out_array:
            if z_array:
                result[inn.isnan(output) | inn.isnan(z)] = inn.nanval(result)
            else:
                result[inn.isnan(output)] = inn.nanval(result)
            # if result has no digits after the decimal point, convert to int array
            if output.dtype.kind == "i" and result.dtype.kind == "f" and np.all(result == np.floor(result)):
                result = result.astype(int)

        if not out_array and inn.isnan(output):
            yield (inn.nanval(type(output)),)
            return

        if np.any(inn.isnan(z) & ~inn.isnan(output)):
            return  # There is a NaN in the conditioned inputs

        if specify(output) in [float, Array[float]]:
            is_array = out_array & z_array
            if np.any(np.isinf(z) & ~np.isinf(output)):
                return  # There is an Inf in the conditioned inputs

            if not self.ignore_precision:
                prec = jprecision(output)
                if abs(prec) > MAX_PRECISION:
                    return  # Target too (im)precise
                eps = POW10[MAX_PRECISION - prec] * 0.5001
                interval = np.abs(inv_func(z, output - eps) - inv_func(z, output + eps))
                tol_precision = first_decimal_precision(interval)
                if abs(tol_precision) > MAX_PRECISION:
                    return  # Input can not be inferred with enough precision
                # during inversion, we always round halves down; during execution, we round them up
                result = custom_round(result, tol_precision, round_halves_up=False)

            # if all values are equal, yield scalar, instead of an array of equal values
            if is_array and np.all(result == result[0]):
                result = result.ravel()[0]
        if not isinstance(result, np.ndarray) and result == int(result) and self._check_int(output):
            yield (int(result),)
        else:
            yield (result,)

    # def _inverse(self, output, cond_inputs, cond):
    #     z = cond_inputs[0]
    #     if not self.check(z, output):
    #         return  # Wrong inputs
    #     inv_func = self.inv_func(cond)

    #     if isinstance(output, np.ndarray):
    #         if not isinstance(z, np.ndarray):
    #             z = np.full(output.shape, z)
    #         valid_output = ~inn.isnan(output)
    #         valid = ~inn.isnan(z) & valid_output

    #         # x + result = nan -> result = nan
    #         # don't use  here, since integer division leads to premature imprecise rounding
    #         result = np.full(output.shape, np.nan)
    #         result[valid_output] = inv_func(z[valid_output], output[valid_output])

    #         # since nan + x = 3 has no solution
    #         if np.any(inn.isnan(z) & valid_output):
    #             return  # There is a NaN in the conditioned inputs

    #         # since inf + x = 3 has no solution
    #         if np.any(np.isinf(z) & ~np.isinf(output)):
    #             return  # There is an Inf in the conditioned inputs

    #         vo = output[valid]
    #         vz = z[valid]
    #         prec = jprecision(vo)
    #         if abs(prec) > MAX_PRECISION:
    #             return  # Target too (im)precise
    #         eps = POW10[MAX_PRECISION - prec] * 0.5001
    #         interval = np.abs(inv_func(vz, vo - eps) - inv_func(vz, vo + eps))
    #         tol_precision = first_decimal_precision(interval)
    #         if abs(tol_precision) > MAX_PRECISION:
    #             return  # Input can not be inferred with enough precision
    #         # during inversion, we always round halves down; during execution, we round them up
    #         result[valid] = custom_round(result[valid], tol_precision, round_halves_up=False)
    #         # if all values are equal, yield scalar, instead of an array of equal values
    #         if np.all(result == result[0]):
    #             result = result.ravel()[0]
    #     else:
    #         if inn.isnan(output):
    #             yield inn.nanval(output),
    #             return
    #         if np.isinf(output):
    #             # TODO: check if input z is also infinite
    #             yield np.sign(output) * np.inf,
    #             return

    #         result = inv_func(z, output)

    #         # since nan + x = 3 and inf + x = 3 has no solution
    #         if inn.isnan(z) or np.isinf(z):
    #             return  # There is a NaN in the conditioned inputs

    #         prec = jprecision(output)
    #         if abs(prec) > MAX_PRECISION:
    #             return  # Target too (im)precise
    #         eps = POW10[MAX_PRECISION - prec] * 0.5001
    #         interval = np.abs(inv_func(z, output - eps) - inv_func(z, output + eps))
    #         tol_precision = first_decimal_precision(interval)
    #         if abs(tol_precision) > MAX_PRECISION:
    #             return  # Input can not be inferred with enough precision
    #         # during inversion, we always round halves down; during execution, we round them up
    #         result = custom_round(result, tol_precision, round_halves_up=False)
    #     if not isinstance(result, np.ndarray) and result == int(result) and self._check_int(output):
    #         yield (int(result),)
    #     else:
    #         yield (result,)


class Mult(Add):
    conditions = (0,), (1,)
    commutative = True
    arity = 2

    def _call(self, x, y):
        if isinstance(x, np.ndarray) and isinstance(y, np.ndarray) and x.shape != y.shape:
            raise ValueError("Shape mismatch.")
        # vary=True, otherwise 0.1 * 0.1 = 0
        return execute(lambda a, b: mult(a, b), (x, y), vary=True, ignore_precision=self.ignore_precision)

    @staticmethod
    def check(inp, output):
        if isinstance(output, number_like):
            if not isinstance(inp, number_like):
                return False  # Has to be a number
            if not np.isfinite(output) or not np.isfinite(inp):
                return False  # Has to be finite
        else:
            if isinstance(inp, np.ndarray) and inp.shape != output.shape:
                return False  # Lengths have to be equal
        if np.any((inp == 0) & (output != 0)):
            return False  # Not invertible if input is zero
        return True

    @staticmethod
    def inv_func(cond):
        def my_div(i, t):
            if isinstance(t, np.ndarray):
                result = ws.tmp(shape=t.shape, dtype=np.float64, zero=True)
                if isinstance(i, np.ndarray):
                    valid = i != 0
                    np.divide(t, i, out=result, where=valid)
                else:
                    if i != 0:
                        np.divide(t, i, out=result)
                result[(i == 0) & (t == 0)] = 0
                return result
            return t / i if i != 0 else 0

        return my_div

    @staticmethod
    def _check_int(output):
        return isinstance(output, int_like)


class Concat(BinOp):
    _raw_specs = [
        (tuple[str, str], str),
        (tuple[list[T1], list[T1]], list[T1]),
        (tuple[Array[T1], Array[T1]], Array[T1]),
    ]
    conditions = (0,), (1,)
    commutative = False
    arity = None  # variable arity

    def _call(self, *args):
        if all(isinstance(x, list) for x in args):
            return list(chain.from_iterable(args))
        if all(isinstance(x, str) for x in args):
            return "".join(args)
        if all(isinstance(x, np.ndarray) for x in args):
            return reduce(lambda x, y: np.concatenate((x, y)), args)
        raise TypeError("Arguments have wrong types for concatenation")

    @staticmethod
    def _suitable(output):
        return isinstance(output, list | str | np.ndarray) and len(output) > 0

    def _inverse(self, output, cond_inputs, cond):
        inp = cond_inputs[0]
        if not isinstance(inp, list | str | np.ndarray):
            return
        if (
            cond in [(0,), (1,)]
            and isinstance(inp, np.ndarray)
            and isinstance(output, np.ndarray)
            and len(inp.shape) != len(output.shape)
        ):
            return
        if cond == (0,):
            if recursive_match(output[: len(inp)], inp):
                yield (output[len(inp) :],)
            return
        if cond == (1,):
            if recursive_match(output[-len(inp) :], inp):
                yield (output[: -len(inp)],)


class Repeat(BinOp):
    """Deals with the case [1,5,1,5,1,5] = 3 * [1,5]"""

    # by convention, we fix the first input to be the number of repetitions and the second to at set repeated list
    _raw_specs = [
        (tuple[int, str], str),
        (tuple[int, list[T1]], list[T1]),
        (tuple[int, Array[T1]], Array[T1]),
    ]
    conditions = (), (0,), (1,)
    commutative = False

    def _call(self, x, y):
        if isinstance(y, np.ndarray):
            res = ws.tmp(shape=(x * len(y),), dtype=y.dtype)
            repeat(x, y, out=res)
        else:
            res = repeat(x, y)
        return res

    @staticmethod
    def _suitable(output):
        return isinstance(output, list | str | np.ndarray)

    def _inverse(self, output, cond_inputs, cond):
        def eq(a, b):
            a, b = np.array(a), np.array(b)
            if a.shape != b.shape:
                return False
            return np.all(a == b)

        lgh = len(output)
        if cond == ():
            if lgh <= 1:
                yield 1, output
                return
            for n in range(1, lgh):
                if lgh % n != 0:
                    continue
                reps = int(lgh / n)
                if eq(repeat(reps, output[:n]), output):
                    yield reps, output[:n]
                    return

        elif isinstance(cond_inputs[0], int_like) and cond == (0,):
            if lgh == 0:
                yield (iter_type(output)([]),)
                return
            rep_num = cond_inputs[0]
            if rep_num <= 0:
                return  # Can not invert 0 * list = output_list
            if lgh % rep_num != 0:
                return  # len(output) % arg != 0
            result = output[: int(lgh / rep_num)]
            if not eq(repeat(rep_num, result), output):
                return  # f'output does not consist of repeating sub-lists of length {rep_num}')
            yield (result,)

        elif isinstance(cond_inputs[0], Iterable) and cond == (1,):
            rep_lst = cond_inputs[0]
            if len(rep_lst) == 0:
                return  # n * [] = output_list not solvable for n
            if lgh % len(rep_lst) != 0:
                return  # len(output) % len(arg) != 0
            result = int(lgh / len(rep_lst))
            if not eq(repeat(result, rep_lst), output):
                return  # arg is not a prefix of output
            yield (result,)
        else:
            return  # input is of wrong type


class LessThan(BinOp):
    _raw_specs = [
        (tuple[T1, T1], bool),
        (tuple[Array[float], Array[float]], Array[bool]),
        (tuple[Array[float], float], Array[bool]),
        (tuple[Array[float], int], Array[bool]),
    ]
    conditions = ((0, 1),)
    commutative = False

    def _call(self, a, b):
        return a < b

    def _inverse(self, output, cond_inputs, cond):
        if isinstance(output, np.ndarray):
            if (
                output.shape != cond_inputs[0].shape
                or isinstance(cond_inputs[1], np.ndarray)
                and output.shape != cond_inputs[1].shape
            ):
                return  # Array shape mismatch
        try:
            res = self._call(*cond_inputs)
        except exec_errors:
            return
        if recursive_match(output, res):
            yield ()
        else:
            return  # function output does not match the output


class Equal(BinOp):
    _raw_specs = [(tuple[T1, T1], bool), (tuple[Array[T1], Array[T1]], Array[bool])]
    conditions = (0,), (1,)
    commutative = True

    def _call(self, a, b):
        return a == b

    @staticmethod
    def _suitable(output):
        return isinstance(output, bool) or isinstance(output, np.ndarray) and output.dtype.kind == "b"

    def _inverse(self, output, cond_inputs, cond):
        if (
            isinstance(output, np.ndarray)
            and isinstance(cond_inputs[0], np.ndarray)
            and output.shape != cond_inputs[0].shape
        ):
            return  # Array shape mismatch
        if np.all(output):
            yield (cond_inputs[0],)
        else:
            return  # a != b can not be solved for a or b


class Not(UnaryOp):
    _raw_specs = [(tuple[bool], bool), (tuple[Array[bool]], Array[bool])]
    conditions = ((),)

    def _call(self, x):
        if isinstance(x, np.ndarray) and x.dtype.kind == "b":
            return ~x
        if isinstance(x, list):
            x = np.array(x, dtype=bool)
            return (~x).tolist()
        return not x

    @staticmethod
    def _suitable(output):
        return isinstance(output, bool) or isinstance(output, np.ndarray) and output.dtype.kind == "b"

    def _inverse(self, output, cond_inputs, cond):
        if isinstance(output, np.ndarray) and output.dtype.kind == "b":
            yield (~output,)
            return
        yield (not output,)


class Len(UnaryOp):
    _raw_specs = [
        (tuple[Array[T1]], int),
        (tuple[list[T1]], int),
        (tuple[set[T1]], int),
        (tuple[str], int),
        (tuple[tuple[T1]], int),
    ]
    conditions = ((0,),)

    def _call(self, x):
        return len(x)


class GetItem(BinOp):
    _raw_specs = [
        (tuple[list[T1], int], T1),
        (tuple[list[T1], list[int]], list[T1]),
        (tuple[Array[T1], Array[bool]], Array[T1]),
        (tuple[Array[T1], Array[int]], Array[T1]),
        (tuple[str, int], str),
    ]
    conditions = ((), (1,))
    commutative = False

    # TODO: Add support for tuples, maybe also dictionaries

    def _call(self, x, y):
        if np.any(y < 0) or np.any(y >= len(x)):
            raise IndexError("index is out of bounds")
        if isinstance(y, list):
            return [x[i] for i in y]
        return x[y]

    @staticmethod
    def _suitable(output):
        if isinstance(output, np.ndarray):
            return len(output.shape) == 1 and output.shape != (0,)
        return False

    def _inverse(self, output, cond_inputs, cond):
        if cond == ():
            if output.dtype.kind in ["i", "f", "b"]:
                unique_len = len(np.unique(output))  # precompute unique length
                source = ws.tmp(shape=(unique_len,), dtype=output.dtype)
                indices = ws.tmp(shape=(output.size,), dtype=np.int64)
                unique_with_inverse_preallocated(output, source, indices, unique_len)
            else:
                source, indices = np.unique(output, return_inverse=True)
            yield source, indices

        if cond == (1,):
            indices = cond_inputs[0]
            if not isinstance(indices, Iterable):
                return  # index has to be iterable
            if isinstance(indices, np.ndarray) and indices.dtype.kind != "b":
                return  # index array has to be of boolean type in order to make that type of inversion
            if isinstance(indices, list) and specify(indices) != list[bool]:
                return  # index array has to be of boolean type in order to make that type of inversion
            if np.sum(indices) != len(output):
                return  # Shape mismatch
            nv = False if isinstance(output, np.ndarray) and output.dtype.kind == "b" else inn.nanval(output)
            # result = np.full(indices.shape, nv)
            result = ws.tmp(shape=indices.shape, dtype=type(nv))
            result[:] = nv
            result[indices] = output
            yield (result,)


class SetItem(Operator):
    _raw_specs = [
        (tuple[list[str], int, str], list[str]),
        (tuple[Array[T1], Array[bool], Array[T1]], Array[T1]),
        (tuple[Array[T1], Array[int], Array[T1]], Array[T1]),
        (tuple[Array[T1], tuple[Array[int], Array[int]], Array[T1]], Array[T1]),
        (tuple[Array[T1], list[int], Array[T1]], Array[T1]),
    ]
    conditions = (0,), (1,)
    commutative = False

    def _call(self, lst, index, item):
        x = deepcopy(lst)
        if isinstance(x, list):
            x = np.array(x)
            x[index] = item
            x = x.tolist()
        else:
            x[index] = item
        return x

    @staticmethod
    def _suitable(output):
        return isinstance(output, list | np.ndarray)

    def _inverse(self, output, cond_inputs, cond):
        if cond == (0,):
            lst = cond_inputs[0]
            if isinstance(lst, str):
                lst = list(lst)
                output = list(output)
            if not isinstance(lst, list | np.ndarray):
                return  # input has to be a list or an array

            if isinstance(lst, list):
                if len(lst) != len(output):
                    return  # first input and output have to be lists of equal length
                discrepancies = np.where(np.array(lst, dtype=object) != np.array(output, dtype=object))[0]
                if len(discrepancies) != 1:
                    return  # Input differs from output at more than one entry, or is entirely identical
                yield discrepancies[0], output[discrepancies[0]]

            if isinstance(lst, np.ndarray):
                if lst.shape != output.shape:
                    return  # first input and output have to be arrays of equal shape
                discrepancies = np.where(np.array(lst, dtype=object) != np.array(output, dtype=object))[0]
                assigned = ws.tmp(shape=(len(discrepancies),), dtype=output.dtype)
                assigned[:] = output[discrepancies]
                yield discrepancies, assigned

        if cond == (1,):
            indices = cond_inputs[0]
            if isinstance(indices, list):
                indices = np.array(indices)
            if isinstance(output, list):
                if isinstance(indices, int_like):
                    indices = [indices]
                if any(i >= len(output) for i in indices):
                    return  # Index larger than output length.
                content = ""
                x = output[: indices[0]]
                for i in range(len(indices) - 1):
                    x += [""] + output[indices[i] + 1 : indices[i + 1]]
                    if not isinstance(output[i], str):
                        return
                    content += output[i]
                x += [""] + output[indices[-1] + 1 :]
                if not isinstance(output[indices[-1]], str):
                    return
                content += output[indices[-1]]
                yield x, content
                return

            valid = False
            if isinstance(indices, np.ndarray) and indices.dtype.kind in ["i", "b"]:
                a, b = indices.shape, output.shape
                if indices.dtype.kind == "b" and (
                    len(a) == len(b) and a != b or len(a) < len(b) and a[0] != b[0] or len(a) > len(b)
                ):
                    return  # index array does not fit output array
                if indices.dtype.kind == "i" and np.any((indices < 0) | (indices >= len(output))):
                    return  # index array does not fit output array
                valid = True
            if isinstance(indices, tuple):
                valid = len(indices) == len(output.shape)
            elif isinstance(indices, int_like):
                valid = True
            elif indices.dtype.kind == "i":
                valid = True
            if not valid:
                return
            integer_indices = indices
            indices = ws.tmp(shape=output.shape, dtype=bool, zero=True)
            try:
                indices[integer_indices] = True
            except IndexError:
                return
            with np.errstate(invalid="ignore"):
                x = ws.tmp(shape=output.shape, dtype=output.dtype)
                x[:] = inn.nanval(output)
            if output.dtype.kind == "U":
                x[:] = ""
            x[~indices] = output[~indices]
            assigned = ws.tmp(shape=(np.sum(indices),), dtype=output.dtype)
            assigned[:] = output[indices]
            assigned = assigned[0] if assigned.shape == (1,) else assigned
            yield x, assigned


class BRange(Operator):
    _raw_specs = [
        (tuple[int, int], Array[int]),
        # (tuple[int, int], list[int]),
    ]
    conditions = ((),)
    commutative = False

    def _call(self, start, stop):
        result = ws.tmp(shape=(max(0, stop - start),), dtype=int)
        result[:] = brange(start, stop)
        return result

    @staticmethod
    def _suitable(output):
        if not isinstance(output, np.ndarray):
            return False
        if len(output) == 0:
            return False
        if output.dtype.kind != "i":
            return False  # output has to be an array of integers
        res = (output[0], output[-1] + 1)
        if inn.isnan(res[0]) or inn.isnan(res[1]):
            return False  # output contains NaN
        if len(range(*res)) != len(output) or np.any(np.arange(*res) != output):
            return False
        return True

    def _inverse(self, output, cond_inputs, cond):
        yield output[0], output[-1] + 1


class IfElse(Operator):
    _raw_specs = [(tuple[bool, T1, T1], T1)]
    conditions = ((0, 1, 2),)
    commutative = False

    def _call(self, x, y, z):
        return y if x else z
