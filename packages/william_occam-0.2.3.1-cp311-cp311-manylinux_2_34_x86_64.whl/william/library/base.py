import json
import os
from abc import ABC, abstractmethod
from collections.abc import Callable
from functools import cached_property, lru_cache
from itertools import islice, product
from typing import TypeVar

import numpy as np

from william.library.description import desc_len
from william.library.functions import unique_list
from william.library.hashing import unique_hash
from william.library.precision import recursive_match
from william.library.types import DEFAULT_TYPES, T1, Array, spec_str, specify, tuple_args, typereplace
from william.rendering import graphs_to_dot
from william.utils import FancyIndexingList, ignore_errors, pretty

exec_errors = (TypeError, ValueError, ZeroDivisionError, IndexError, KeyError, OverflowError)
level = int(os.getenv("WILLIAM_DEBUG", "0"))


class NodeContent(ABC):
    is_operator = False

    @property
    @abstractmethod
    def name(self):
        raise NotImplementedError("abstract method, override by a subclass")

    @property
    @abstractmethod
    def value(self):
        raise NotImplementedError("abstract method, override by a subclass")

    @property
    @abstractmethod
    def hash(self):
        raise NotImplementedError("abstract method, override by a subclass")

    @abstractmethod
    def desc_len(self):
        raise NotImplementedError("abstract method, override by a subclass")

    @abstractmethod
    def equals(self, other):
        raise NotImplementedError("abstract method, override by a subclass")

    @abstractmethod
    def copy(self):
        raise NotImplementedError("abstract method, override by a subclass")

    @abstractmethod
    def __str__(self):
        raise NotImplementedError("abstract method, override by a subclass")


class Value(NodeContent):
    """
    Values are contents of value nodes. Manage specs, units, description lengths and other potential properties of
    values.
    """

    def __init__(self, value, name=None, spec=None, permeable=True, dummy=False, sources=(), func=None):
        self._value = value
        self._name = name
        self.permeable = permeable
        self.dummy = dummy  # dummy value, hence don't use it for computations; only to be replaced
        self.realized = func is None
        self._dl = None
        self._spec = spec
        self._hash = None
        # sources are other values from which this value is to be computed using the function func
        self._sources = sources
        self._func = func

    @property
    def name(self):
        return self._name

    @property
    def value(self):
        # TODO: Caching decorator
        # FIXME: This does not reset ._dl and ._hash
        if self._value is not None or self._func is None:
            return self._value
        self._value = self._func(*self._sources)
        if self._value is not None:
            self._spec = specify(self._value)
            self.realized = True
        return self._value

    def __hash__(self):
        return self.hash

    @property
    def hash(self):
        # TODO: Caching decorator
        if not self.realized:
            raise ValueError("Cannot hash unrealized value.")
        if self._hash is None:
            self._hash = unique_hash((type(self), self.spec, self._value))
        return self._hash

    def desc_len(self, allow_none=False, mode="use_gaussian"):
        if self.dummy:
            return 0.0
        if self.is_none and not allow_none:
            raise ValueError("output is not defined")
        # TODO: Caching decorator
        if self._dl is None:
            self._dl = desc_len(self.value, mode=mode)  # computing/"realizing" the value here
        return self._dl

    def equals(self, other):
        # TODO: Use __eq__ instead
        # this is instead of __eq__ since graph_from_tuple function needs Value objects
        # to be different, even if they contain the same value
        other = other if isinstance(other, Value) else Value(other)
        return self.hash == other.hash  # recursive_match(self.value, other.value)

    def copy(self, clear_value=False):
        v = None if clear_value else (self._value.copy() if hasattr(self._value, "copy") else self._value)
        return type(self)(
            v,
            name=self.name,
            spec=self.spec,
            permeable=self.permeable,
            dummy=self.dummy,
            sources=self._sources,
            func=self._func,
        )

    def __str__(self):
        s = []
        if not self.is_image and self.value is not None:
            s.append(pretty(self.value, abbrev=True))
        if self._value is not None:
            s.append(f"dl={self.desc_len():.2f}")
        elif self._spec is not None:
            s.append(f"{spec_str(self._spec)}")
        if self.name:
            s.append(f"{self.name}")
        return "\n".join(s)

    def __repr__(self):
        return f"<Value {str(self)}>".replace("\n", " ")

    def set_spec(self, spec):
        if self.realized or self._spec is not None:
            return
        self._spec = spec

    @property
    def spec(self):
        # TODO: Caching decorator
        if self._spec is None and self._value is not None:
            self._hash = None  # reset hash
            self._spec = specify(self._value)
        return self._spec

    @property
    def is_none(self):
        return self._value is None and self.realized

    def flush(self):
        # TODO: should this also flush ._spec, ._dl
        self._value = None
        self.realized = self._func is None

    @property
    def is_image(self):
        return hasattr(self._value, "shape") and len(self._value.shape) == 3

    def serialize(self):
        """Make JSON object to store as string in a dot-file."""
        # TODO: how to store "computation traces" for factors? Some operations my include inversions after all
        d = {}
        if self.realized:
            d["value"] = pretty(self.value, abbrev=False)
            if not self.is_none:
                d["dl"] = self.desc_len()

        if self.name:
            d["name"] = self.name
        d["spec"] = spec_str(self.spec)
        d["permeable"] = self.permeable
        return json.dumps(d)


class Specified:
    @cached_property
    def arity(self):
        return len(tuple_args(self.specs[0][0]))

    @cached_property
    def _raw_specs(self):
        specs = self._typify(DEFAULT_TYPES)
        if not specs:
            return []
        arity = len(specs[0][0].__args__)
        if not all(len(spec[0].__args__) == arity for spec in specs):
            raise ValueError("arity of all specs must be equal")
        return specs

    @property
    def output_specs(self):
        return unique_list(spec[1] for spec in self.specs)

    @staticmethod
    def _type_sample(arg_type):
        """Return a proper instance for probing the type specifications."""
        if arg_type == np.ndarray:
            return np.array([0])
        return arg_type()

    @staticmethod
    def inv_specs(spec, cond):
        input_spec, output_spec = spec
        if cond:
            inv_spec = [output_spec]
            inv_spec.extend((spec for index, spec in enumerate(input_spec.__args__) if index in cond))
            specs = tuple[tuple(inv_spec)]
        else:
            specs = tuple[output_spec, type(None)]
        return specs

    def _typify(self, types):
        """
        Return all possible and deduplicated type specifications, trying all
        given types.
        """
        types = FancyIndexingList(types)
        # Create a lists of indices of types.
        # Avoid permuted duplicates like (t1, t2) <> (t2, t1)
        # TODO: There should be some more elegant permutation for that
        permutations = set(tuple(sorted(i)) for i in product(range(len(types)), repeat=self.arity))
        type_permutations = [types[k] for k in permutations]

        specs = []
        type_translation = {list: list[T1], tuple: tuple, set: set[T1], np.ndarray: Array[T1]}

        for arg_types in type_permutations:
            args = tuple(self._type_sample(arg_type) for arg_type in arg_types)
            try:
                res = self._call(*args)
            except exec_errors + (NotImplementedError,):
                continue
            else:
                input_types = tuple(type_translation.get(arg_type, arg_type) for arg_type in arg_types)
                input_spec = tuple[input_types]
                output_spec = type_translation.get(type(res), type(res))
                specs.append((input_spec, output_spec))
        return specs

    @abstractmethod
    def _call(self, *args):
        # Accepts actual values
        raise NotImplementedError("abstract method, override by a subclass")


class Operator(NodeContent, Specified):
    """
    Define an operator with all possible input and output specifications.
    """

    def __init__(self, dl: float = 1.0):
        # Make sure that type variables of different operator instances are different
        # objects, otherwise unification will mess up
        # However, the internal bindings of the type variables are kept
        # repl = {T1: TypeVar("T1"), T2: TypeVar("T2"), T3: TypeVar("T3")}
        repl = {T1: TypeVar("T1")}
        self.specs = [(typereplace(inp, repl), typereplace(out, repl)) for inp, out in self._raw_specs]
        self._dl = dl

    value_cls = Value
    is_operator = True
    primitive = True

    conditions = ((),)
    cond_inv_functions = {}
    has_callable = False
    commutative = False
    cumulative = False
    ignore_precision = False

    is_none = False
    realized = True
    is_image = False

    @property
    def name(self):
        return type(self).__name__.lower()

    @property
    def value(self):
        return self

    @property
    def hash(self):
        return unique_hash((type(self), self.name))  # TODO: Add self.specs?

    def desc_len(self, mode="use_gaussian"):
        return self._dl

    def equals(self, other):
        return self.__eq__(other)

    def copy(self):
        return self

    def __str__(self):
        return self.name

    def __eq__(self, other):
        """Return True, if we're of the same type."""
        return self.__class__ == other.__class__

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return f"<operator {self.name}>"

    def __hash__(self):
        return unique_hash((type(self), self.name))

    def __call__(self, *args):
        # Accepts value objects
        properties = self._properties(*args)
        result = self._call(*[a.value for a in args])
        return self.value_cls(result, **properties)

    @ignore_errors(exec_errors)
    def _call_delayed(self, *args):
        # Accepts value     objects, pack into value objects again later
        return self._call(*[a.value for a in args])

    def call_without_computation(self, *args):
        try:
            properties = self._properties(*args)
        except exec_errors:
            return
        return self.value_cls(None, sources=args, func=self._call_delayed, **properties)

    @staticmethod
    def _properties(*args):
        return {}

    @ignore_errors(exec_errors)
    def suitable(self, output):
        """Return if output is appropriate for inversion."""
        return self._suitable(output.value)

    @staticmethod
    def _suitable(output):
        return True

    def inverse(self, output, cond_inputs, cond, num_inferred=None):
        """
        Inversion of the operator.
        :output: output output of the operator
        :cond_inputs: input values, can be both variables and constants
        :cond: number of the input nodes to be used
        :return: returns the values of the other input nodes
        """
        if not self.suitable(output):
            if level > 10:
                raise ValueError(f"Output {output.value} not suitable for {self.name} operator inversion.")
            return

        ci = tuple(c.value for c in cond_inputs)
        found = False
        for inf in self._inverse(output.value, ci, cond):
            yield tuple(self.value_cls(i) for i in inf)
            found = True
        if not found and level > 10:
            raise ValueError(
                f"No inversion found for {self.name} operator with output {output.value}, cond_inputs {ci}, and cond {cond}."
            )

    @ignore_errors(exec_errors)
    def _inverse(self, output, cond_inputs, cond):
        """The default inverse. Do nothing."""
        if recursive_match(output, self._call(*cond_inputs)):
            yield ()
        else:
            return  # function output does not match the output

    def _inverse_delayed(self, output, cond_inputs, cond, num_inferred=None):
        # Accepts value objects, pack into value objects again later
        result = self._inverse(output.value, tuple(c.value for c in cond_inputs), cond)

        if num_inferred is not None:
            if not isinstance(result, tuple | list):
                # TODO: takes only the first yield of the inversion
                result = list(islice(result, 1))[0]
            return result[num_inferred]
        else:
            return result

    def inverse_without_computation(self, *args):
        return self.value_cls(None, sources=args, func=self._inverse_delayed)

    def generalized_conditions(self, arity=None, invert=True):
        arity = arity or self.arity
        if invert:
            for cond in self.conditions:
                if len(cond) < arity:
                    yield (-1,) + cond
        yield tuple(range(arity))

    @lru_cache
    def specs_and_conditions(self):
        # all inputs given, output is computed
        all_cond = tuple(range(self.arity))
        result = []
        for spec in self.specs:
            result.append((spec[0].__args__, all_cond))

        # the output and conditioned inputs are given, inferred inputs are computed.
        for cond in self.conditions:
            seen = set()
            for spec in self.specs:
                sub_specs = (spec[1],) + tuple(s for i, s in enumerate(spec[0].__args__) if i in cond)
                if sub_specs in seen:
                    continue
                seen.add(sub_specs)
                # -1 means the first "condition" is the output
                result.append((sub_specs, (-1,) + cond))
        return result

    @cached_property
    def spec(self):
        # TODO: takes only the first spec, what about others?
        n = 0
        return Callable[[self.specs[n][0]], self.specs[n][1]]

    def serialize(self):
        """Make JSON object to store as string in a dot-file."""
        d = {}
        if self.realized:
            if hasattr(self, "root"):
                # treatment of composite graphs
                # use special separator in order to avoid inserting new line, while being able to parse the string into new
                # lines while reading afterwards
                d["graph"] = graphs_to_dot([self.root], reading=False, with_brackets=False, separator="@$%")
            else:
                d["value"] = pretty(self, abbrev=False)
                if not self.is_none:
                    d["dl"] = self.desc_len()

        if self.name:
            d["name"] = self.name
        d["spec"] = spec_str(self.spec)
        d["permeable"] = True
        return json.dumps(d)


class UnaryOp(Operator):
    arity = 1
    commutative = True  # trivially


class BinOp(Operator):
    arity = 2

    @abstractmethod
    def _call(self, x, y):
        """Execute the defined function with exact two inputs."""
        raise NotImplementedError("abstract method, override by a subclass")

    # Todo: Should this be there for all BinOps?
    # @staticmethod
    # @abstractmethod
    # def check(inp, output):
    #     raise NotImplementedError("abstract method, override by a subclass")
    #
    # @staticmethod
    # @abstractmethod
    # def inv_func(cond):
    #     raise NotImplementedError("abstract method, override by a subclass")
