import hashlib
import struct
from collections.abc import Iterable
from types import GenericAlias
from typing import Any

import numpy as np

_TYPE_ORDER: dict[type, int] = {
    type(None): 0,
    bool: 1,
    int: 2,
    np.int32: 2,
    np.int64: 2,
    float: 3,
    np.float32: 3,
    np.float64: 3,
    str: 4,
    bytes: 5,
    tuple: 6,
    list: 7,
    set: 8,
    frozenset: 9,
    dict: 10,
    np.ndarray: 11,
    type: 12,
    np.dtype: 13,
    slice: 14,
}


def is_container_type(item: Any) -> bool:
    return (
        isinstance(item, (list, tuple, set, frozenset, dict, np.ndarray))
        or hasattr(item, "__dict__")
        or hasattr(item, "__slots__")
    )


def get_stable_key(item: Any, seen: set[int] | None = None) -> tuple[int, Any, Any, Any]:
    """
    Create a sort key from a recursive structure, creating a stable sort order
    even for unhashable and otherwise uncomparable objects.
    """
    order = _TYPE_ORDER.get(type(item), 99)
    obj_id = id(item)
    is_container = is_container_type(item)

    if not is_container:
        # Group 0: Scalars
        # Order is 2nd to prevent comparison of different types
        if isinstance(item, (type, np.dtype)):
            return 0, order, str(item), None
        if isinstance(item, slice):
            content = (
                get_stable_key(item.start, seen),
                get_stable_key(item.stop, seen),
                get_stable_key(item.step, seen),
            )
            return 0, order, content, None
        return 0, order, item, None

    # Group 1: Collections
    if seen is None:
        seen = set()
    if obj_id in seen:
        return -1, (obj_id,), order, None
    seen.add(obj_id)

    try:
        if isinstance(item, (list, tuple, set, frozenset)):
            transformed = [get_stable_key(element, seen) for element in item]
            if isinstance(item, (set, frozenset)):
                transformed.sort()
            # Structure: (Group, Content-Tuple, Type-Order, Extra)
            # Content is 2nd to sort containers with similar data close to each other
            return 1, tuple(transformed), order, None

        if isinstance(item, np.ndarray):
            dtype_order = 0 if np.issubdtype(item.dtype, np.integer) else 1
            transformed = tuple(get_stable_key(x, seen) for x in item.tolist())
            return 1, transformed, order, dtype_order

        if isinstance(item, dict):
            flat_list = []
            for k in sorted(item.keys(), key=lambda x: get_stable_key(x, seen)):
                flat_list.append(get_stable_key(k, seen))
                flat_list.append(get_stable_key(item[k], seen))
            return 1, tuple(flat_list), order, None

        if order == 99:
            # arbitrary classes
            class_key = get_stable_key(type(item).__name__, seen)
            if hasattr(item, "__slots__"):
                item_data = {s: getattr(item, s) for s in item.__slots__ if hasattr(item, s)}
                content = class_key, get_stable_key(item_data, seen)
                return 1, content, 98, None

            content = class_key, get_stable_key(item.__dict__, seen)
            return 1, content, 99, None

    finally:
        # Remove object from seen after processing all its children.
        # This allows the object to be processed again in "Diamond" structures
        # (different branches), but still detects cycles (same branch).
        if is_container:
            seen.remove(obj_id)

    raise TypeError(f"Unknown type {type(item)}")


def sort_anything(items: Iterable[Any]) -> list[Any]:
    """Sort objects in a stable order, even if python usually can't sensically compare them."""
    return sorted(items, key=get_stable_key)


def feed_hasher(item: Any, hasher: Any, seen: set[int] | None = None) -> None:
    """Recursively feeds an object's content into any compatible hasher."""

    obj_id = id(item)
    is_container = is_container_type(item)
    if is_container:
        if seen is None:
            seen = set()
        if obj_id in seen:
            hasher.update(b"\xff(")
            hasher.update(struct.pack("<Q", obj_id))
            hasher.update(b")")
            return
        seen.add(obj_id)

    match item:
        case bool():
            # needs to be before int
            hasher.update(b"\x01(T)" if item else b"\x01(F)")
        case int():
            hasher.update(b"\x02(")
            bit_length = item.bit_length()
            if bit_length < 64:
                # Fast path for standard 64-bit integers
                hasher.update(struct.pack("<q", item))
            else:
                # Fallback for arbitrarily large integers
                byte_length: int = max((bit_length // 8) + 1, 8)
                hasher.update(item.to_bytes(byte_length, "little", signed=True))
            hasher.update(b")")
        case float():
            hasher.update(b"\x03(")
            # Normalize to 8-byte double precision
            hasher.update(struct.pack("<d", item))
            hasher.update(b")")
        case str():
            hasher.update(b"\x04(")
            hasher.update(item.encode())
            hasher.update(b")")
        case None:
            hasher.update(b"\x00()")
        case list():
            hasher.update(b"\x07(")
            for element in item:
                feed_hasher(element, hasher, seen)
            hasher.update(b")")
        case dict():
            hasher.update(b"\x0a(")
            for k in sorted(item.keys(), key=get_stable_key):
                feed_hasher(k, hasher, seen)
                feed_hasher(item[k], hasher, seen)
            hasher.update(b")")
        case np.integer():
            hasher.update(b"\x02(")
            # Always use 8 bytes (int64)
            hasher.update(item.astype(np.int64).tobytes())
            hasher.update(b")")
        case np.floating():
            hasher.update(b"\x03(")
            # Always use 8 bytes (float64)
            hasher.update(item.astype(np.float64).tobytes())
            hasher.update(b")")
        case np.ndarray():
            hasher.update(b"\x0b(")
            hasher.update(str(item.shape).encode())
            hasher.update(str(item.dtype).encode())
            hasher.update(b"|")
            hasher.update(item.tobytes())
            hasher.update(b")")
        case bytes():
            hasher.update(b"\x05(")
            hasher.update(item)
            hasher.update(b")")
        case tuple():
            hasher.update(b"\x06(")
            for element in item:
                feed_hasher(element, hasher, seen)
            hasher.update(b")")
        case set():
            hasher.update(b"\x08(")
            for element in sorted(item, key=get_stable_key):
                feed_hasher(element, hasher, seen)
            hasher.update(b")")
        case frozenset():
            hasher.update(b"\x09(")
            for element in sorted(item, key=get_stable_key):
                feed_hasher(element, hasher, seen)
            hasher.update(b")")
        case type() | GenericAlias():
            hasher.update(b"\x0c(")
            hasher.update(str(item).encode())
            hasher.update(b")")
        case np.dtype():
            hasher.update(b"\x0d(")
            hasher.update(str(item).encode())
            hasher.update(b")")
        case slice():
            hasher.update(b"\x0e(")
            feed_hasher(item.start, hasher)
            feed_hasher(item.stop, hasher)
            feed_hasher(item.step, hasher)
            hasher.update(b")")
        case _:
            # arbitrary types
            if hasattr(item, "__slots__"):
                hasher.update(b"\x62(")
                item_data = [getattr(item, s) for s in item.__slots__]
            else:
                hasher.update(b"\x63(")
                item_data = item.__dict__
            feed_hasher(type(item), hasher, seen)
            feed_hasher(item_data, hasher, seen)
            hasher.update(b")")

    if is_container and seen is not None:
        seen.discard(obj_id)


try:
    import xxhash
except ImportError:

    def unique_hash(item: Any) -> int:
        """Generates a unique md5 hash for any Python object."""
        hasher = hashlib.md5()
        feed_hasher(item, hasher)
        # limit to int64 as used for __hash__
        return int.from_bytes(hasher.digest()[:8], byteorder="little")

else:

    def unique_hash(item: Any) -> int:
        """Generates a unique xxhash for any Python object."""
        hasher = xxhash.xxh64()
        feed_hasher(item, hasher)
        return hasher.intdigest()
