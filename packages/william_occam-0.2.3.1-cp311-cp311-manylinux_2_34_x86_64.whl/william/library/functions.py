import numpy as np
from numba import njit

from william.library.types import float_like, int_like
from william.utils import MAX_ARRAY_LEN, MAX_EXPONENT, MAX_INT, MAX_LIST_LEN, FancyIndexingList


def _repeat(x, n, output_type):
    if isinstance(x, str) and issubclass(output_type, str):
        return x[0] * n if len(x) == 1 else x
    if output_type == np.ndarray:
        return np.tile(x, n)
    return [x] * n


def cumop(func, start, some_list):
    if not isinstance(start, int_like + float_like):
        raise ValueError("start value has to be a number")
    result = np.concatenate(([start], some_list[:]))
    for i in range(len(some_list)):
        result[i + 1] = func(result[i], some_list[i])
    return result if isinstance(some_list, np.ndarray) else result.tolist()


def _remove_multiple_entries(indices0):
    indices = []
    seen = set()
    for i in indices0:
        if i < 0:
            raise IndexError("negative indices not allowed")
        if i not in seen:
            seen.add(i)
            indices.append(i)
    return indices


def listdiff(list1, list2):
    """Set difference preserving order.

    For common numeric cases (integer sequences) use a Numba-jitted helper for
    speed. Falls back to the Python implementation for other types.
    """
    try:
        a = np.asarray(list1)
        b = np.asarray(list2)
        # Only dispatch to the numba path for integer-like arrays
        if a.dtype.kind in ("i", "u") and b.dtype.kind in ("i", "u"):
            return _listdiff_numba(a.astype(np.int64), b.astype(np.int64)).tolist()
    except Exception:
        pass
    # Fallback Python implementation
    return [c for c in list1 if c not in list2]


@njit(cache=True)
def _listdiff_numba(a, b):
    """Numba-compiled set difference preserving order for integer arrays.

    Returns a 1-D int64 numpy array with elements in `a` that are not in `b`,
    preserving the original order.
    """
    n = a.shape[0]
    out = np.empty(n, dtype=np.int64)
    cnt = 0
    for i in range(n):
        ai = a[i]
        found = False
        # linear search over b (b is typically small in our use cases)
        for j in range(b.shape[0]):
            if ai == b[j]:
                found = True
                break
        if not found:
            out[cnt] = ai
            cnt += 1
    if cnt == 0:
        return out[:0]
    return out[:cnt]


@njit(cache=True)
def _unique_preserve_order_int64(a):
    """Return unique elements of int64 array 'a' preserving first-occurrence order."""
    n = a.size
    out = np.empty(n, dtype=np.int64)
    cnt = 0
    for i in range(n):
        ai = a[i]
        found = False
        for j in range(cnt):
            if out[j] == ai:
                found = True
                break
        if not found:
            out[cnt] = ai
            cnt += 1
    if cnt == 0:
        return out[:0]
    return out[:cnt]


def unique_list(iterable):
    seen = set()
    seen_add = seen.add
    return [x for x in iterable if x not in seen and not seen_add(x)]


def list_given_slice(Slice):
    # If only stop is given
    if Slice.step is None and Slice.start is None:
        indexes = [Slice.stop]
    # If step is None or 1
    elif Slice.step is None or Slice.step == 1:
        indexes = [Slice.start, Slice.stop]
    # If step is given
    else:
        indexes = [Slice.start, Slice.stop, Slice.step]
    return list(range(*indexes))


def slice_given_list(lst):
    # Convert a list of indices to a slice object
    if len(lst) == 0:
        return slice(0)
    if len(lst) == 1:
        return slice(lst[0], lst[0] + 1)
    diff_lst = diff(lst)
    step = diff_lst[1]
    if any(x != step for x in diff_lst[1:]):
        raise ValueError("List cannot be transformed to slice since the increment is not fixed")
    return slice(lst[0], lst[-1] + step, step)


def insert(indices0, content, rest):
    # If `rest` is a numpy array we use the fast NumPy-first implementation.
    # Otherwise fall back to the original list/string-friendly implementation
    # (uses FancyIndexingList) so existing tests for lists/strings continue to work.
    if isinstance(rest, np.ndarray):
        # NumPy-first path: expect indices0 to be a slice or numpy integer array (or list)
        if isinstance(indices0, slice):
            idx_list = list_given_slice(indices0)
            indices = np.asarray(idx_list, dtype=np.int64)
        elif isinstance(indices0, np.ndarray):
            if not np.issubdtype(indices0.dtype, np.integer):
                raise TypeError("indices0 numpy array must be of integer dtype")
            indices = indices0.astype(np.int64, copy=True)
        elif isinstance(indices0, list):
            indices = np.asarray(indices0, dtype=np.int64)
        else:
            raise TypeError("indices0 must be a slice, list or a numpy integer array")

        # If indices is empty but content is non-empty, that's an error
        if indices.size == 0 and (content != [] and content != ""):
            raise ValueError("indices length does not match content length")

        # Remove duplicate indices preserving first occurrence order using numba helper
        indices = _unique_preserve_order_int64(indices)

        # Prepare content array: support scalar content by broadcasting
        if np.isscalar(content):
            content_arr = np.full(indices.size, content, dtype=rest.dtype)
        else:
            content_arr = np.asarray(content, dtype=rest.dtype)
            if content_arr.size != indices.size:
                raise ValueError("indices length does not match content length")

        # Total length after insertion
        n = content_arr.size + rest.size

        # Normalize negative indices
        inds = indices.copy()
        for k in range(inds.size):
            if inds[k] < 0:
                inds[k] = inds[k] + n

        if np.any(inds < 0) or np.any(inds >= n):
            raise IndexError("Insert index out of output range")

        # Build boolean mask of used positions and remaining indices in order
        used = np.zeros(n, dtype=np.bool_)
        for ii in inds:
            used[ii] = True
        remaining_indices = np.nonzero(~used)[0]

        # Create result array and place content/rest
        result = np.empty(n, dtype=rest.dtype)
        result[inds] = content_arr
        result[remaining_indices] = rest
        return result

    # Fallback path for lists/strings/tuples: preserve original behavior
    # If indices0 is a slice, convert to list of indices
    if isinstance(indices0, slice):
        indices0 = list_given_slice(indices0)
    # If indices and content lengths do not match
    if len(indices0) == 0 and (content != [] and content != ""):
        raise ValueError("indices length does not match content length")

    indices = _remove_multiple_entries(indices0)

    # Repeat content if not a sequence
    if not isinstance(content, list | tuple | np.ndarray):
        content = _repeat(content, len(indices), type(rest))
    if not indices and not content:
        return rest
    if len(indices) != len(content):
        raise ValueError("indices length does not match content length")
    n = len(content) + len(rest)
    indices = [i if i >= 0 else i + n for i in indices]
    remaining_indices = listdiff(range(n), indices)

    # Insert content at indices, fill rest
    result = FancyIndexingList([None] * n)
    result[indices] = content
    result[remaining_indices] = rest
    if isinstance(rest, str):
        result = "".join(result)
    return result[:]


def partition_by_frequency(output):
    # Partition output by the most frequent value
    if isinstance(output, np.ndarray):
        values, counts = np.unique(output, return_counts=True)
        n = np.argmax(counts)
        content_idx = output != values[n]
        indices = np.where(content_idx)[0]  # .tolist()
        content = output[content_idx]
        if np.all(content == content[0]):
            content = content[0]
        yield indices, content, output[~content_idx]


def partition_given_indices(output, indices):
    # Partition output into content and rest by indices
    if isinstance(indices, slice):
        indices = list_given_slice(indices)
    if len(indices) == 0:
        content = ""
        if isinstance(output, str):
            content = []
        elif isinstance(output, np.ndarray):
            content = np.array([], dtype=output.dtype)
        yield content, output
        return
    # Remove negative indices (for uniqueness)
    n = len(output)
    indices = [i if i >= 0 else i + n for i in indices]
    if len(indices) > n:
        raise ValueError("indices length larger than output length")
    if len(set(indices)) < len(indices):
        raise ValueError("indices have to be unique")
    if any(i >= n or i < 0 for i in indices):
        raise IndexError("Insert index out of output range")
    # Handle strings specially (return strings for content/rest)
    if isinstance(output, str):
        content_chars = [output[i] for i in indices]
        content = "".join(content_chars)
        rest_chars = [output[i] for i in range(n) if i not in indices]
        rest = "".join(rest_chars)
        yield content, rest
        # If all characters equal, yield scalar char
        if len(content) > 0 and all(c == content[0] for c in content):
            yield content[0], rest
        return

    # Numpy arrays: use direct indexing and boolean mask for the rest
    if isinstance(output, np.ndarray):
        content = output[indices]
        used = np.zeros(n, dtype=np.uint8)
        used[indices] = 1
        rest = output[used == 0]
        yield content, rest
        # If all content values are equal, yield scalar
        if content.size > 0 and np.all(content == content[0]):
            yield content[0], rest
        return

    # Generic sequence (list/tuple): build content and rest via list comprehensions
    seq = list(output)
    content = [seq[i] for i in indices]
    rest = [seq[i] for i in range(n) if i not in indices]
    # Preserve tuple type if input was tuple
    if isinstance(output, tuple):
        content = tuple(content)
        rest = tuple(rest)
    yield content, rest
    if len(content) > 0 and all(c == content[0] for c in content):
        yield content[0], rest


def _common_len(list1, list2):
    """Return the largest index i such that list1[:i] == list2[:i] is true."""
    length = min(len(list1), len(list2))
    for i, (s1, s2) in enumerate(zip(list1[:length], list2[:length])):
        if s1 != s2:
            return i
    return length


def _max_common_len(output, content):
    """
    Return the index in output where the longest common substring with content starts.
    Also return the length of the substring.

    :param output: [32, 14, 137, 45, 14, 17, 9, 0, -5]
    :param content: [14, 17, 9]

    :return: 4, 3
    """
    max_common_len = 0
    idx = 0
    for i, s in enumerate(output):
        n = min(i + len(content), len(output))
        common_len = _common_len(output[i:n], content)
        if common_len > max_common_len:
            max_common_len = common_len
            idx = i
    return idx, max_common_len


def partition_given_content(output, content):
    """
    Return indices where content can be found in output, trying to group neighboring indices together.
    """
    # Empty or trivial cases ---------------------------------------------
    if isinstance(content, (list, tuple, np.ndarray)) and len(content) == 0:
        yield [], output
        return

    if isinstance(output, str) and isinstance(content, str):
        content = _repeat(content, output.count(content), type(output))
        if not content:
            raise ValueError("content doesn't match to the output")

    # Single value / scalar comparison -----------------------------------
    if not isinstance(content, (str, list, tuple, np.ndarray)) or (
        isinstance(content, str) and isinstance(output, (list, tuple, np.ndarray))
    ):
        arr = np.asarray(output)
        match = arr == content
        if not np.any(match):
            raise ValueError("content doesn't match to the output")
        indices = np.where(match)[0]
        rest = arr[~match]
        yield indices, rest.tolist() if not isinstance(output, np.ndarray) else rest
        return

    if len(output) < len(content):
        raise ValueError("output length smaller than content length")

    # Main case: sequences or arrays -------------------------------------
    # Strings are not supported by numba, so fallback
    if isinstance(output, str) or isinstance(content[0], str):
        source_list = list(output)
        indices = []
        while len(content):
            idx, mcl = _max_common_len(source_list, content)
            if mcl > 0:
                for i in range(idx, idx + mcl):
                    source_list[i] = None
                content = content[mcl:]
                indices.extend(range(idx, idx + mcl))
            else:
                break
        if len(content):
            raise ValueError("content doesn't match to the output")
        rest = [s for i, s in enumerate(output) if i not in indices]
        rest = "".join(rest) if isinstance(output, str) else np.array(rest)
        yield indices, rest
        return

    # Numeric path with numba --------------------------------------------
    arr_out = np.asarray(output)
    arr_cont = np.asarray(content)
    indices, used = _partition_indices_numba(arr_out, arr_cont)
    if indices.size != arr_cont.size:
        raise ValueError("content doesn't match to the output")
    rest = arr_out[used == 0]
    yield indices, (rest if isinstance(output, np.ndarray) else rest.tolist())


@njit(cache=True)
def _partition_indices_numba(output, content):
    n = output.size
    m = content.size
    used = np.zeros(n, dtype=np.uint8)
    indices = np.empty(m, dtype=np.int64)
    filled = 0

    # While there is still content left
    pos = 0
    while pos < m:
        best_i = -1
        best_len = 0

        # Find the longest unused block
        for i in range(n):
            if used[i] != 0:
                continue
            j = 0
            k = i
            while k < n and pos + j < m and used[k] == 0 and output[k] == content[pos + j]:
                j += 1
                k += 1
            if j > best_len:
                best_len = j
                best_i = i
                if best_len == m - pos:
                    break

        if best_len == 0:
            break

        for t in range(best_len):
            indices[filled + t] = best_i + t
            used[best_i + t] = 1
        filled += best_len
        pos += best_len

    return indices[:filled], used


def join_inputs(cond, cond_inputs, rest_inputs):
    return tuple(insert(cond, cond_inputs, rest_inputs)) if cond else rest_inputs


def power(x, y):
    if isinstance(y, int) and y < MAX_EXPONENT:
        res = pow(x, y)
        if res < MAX_INT:
            return pow(x, y)
        else:
            raise ValueError("Integer is too big.")
    if isinstance(y, list) and all(i < MAX_EXPONENT for i in y):
        return [pow(x, i) for i in y]
    else:
        raise ValueError("unknown type")


def mult(x, y):
    result = x * y
    if isinstance(result, int_like + float_like) and abs(result) > MAX_INT:
        raise ValueError("multiplication result too large")
    if isinstance(result, np.ndarray) and result.dtype.kind == "f":
        if all_numbers_whole(result):
            return result.astype(np.int64)
    return result


@njit(cache=True)
def all_numbers_whole(arr):
    """Check if all elements in a float array are whole numbers."""
    n = arr.size
    for i in range(n):
        val = arr[i]
        if np.isnan(val) or np.isinf(val):
            return False
        if val != np.floor(val):
            return False
    return True


def repeat(x, y, out=None):
    if isinstance(y, list | str) and (x * len(y) > MAX_LIST_LEN or x > MAX_INT):
        raise ValueError("list would be too long")
    if isinstance(y, np.ndarray) and (x * len(y) > MAX_ARRAY_LEN or x > MAX_INT):
        raise ValueError("array would be too long")
    if isinstance(y, list | str):
        return x * y
    if isinstance(y, np.ndarray):
        if out is not None:
            return tile_into(y, x, out)
        else:
            return np.tile(y, x)


@njit(cache=True)
def tile_into(arr, reps, out):
    """
    Numba-compiled in-place tile: write np.tile(arr, reps) into the preallocated
    output array `out`.

    This function supports 1-D numeric arrays and integer `reps`.

    Parameters
    ----------
    arr : ndarray
        Input 1-D array to be repeated.
    reps : int
        Number of repetitions.
    out : ndarray
        Preallocated output array of size arr.size * reps.

    Returns
    -------
    out : ndarray
        The filled output array (same object as the provided `out`).
    """
    # handle empty input
    n = arr.size
    if n == 0:
        return out
    total = n * reps
    if out.size != total:
        raise ValueError("output array has incorrect size")
    pos = 0
    for r in range(reps):
        for i in range(n):
            out[pos] = arr[i]
            pos += 1
    return out


def urange(stop):
    if stop < MAX_LIST_LEN:
        return np.array(list(range(stop)))
    raise ValueError("MAX_LIST_LEN condition violated.")


def brange(start, stop):
    if stop - start < MAX_LIST_LEN:
        return np.array(list(range(start, stop)))
    raise ValueError("MAX_LIST_LEN condition violated.")


def trange(start, stop, step):
    if (stop - start) / step < MAX_LIST_LEN:
        return np.array(list(range(start, stop, step)))
    raise ValueError("MAX_LIST_LEN condition violated.")


def table(values, positions):
    return [values[pos] for pos in positions]


def listslice(list_, i1, i2):
    result = [None] * (i2 - i1)
    c = 0
    for i in range(i1, i2):
        if i < 0 or i >= len(list_):
            return None
        result[c] = list_[i]
        c += 1
    return result


def cumsum(lst):
    if isinstance(lst, np.ndarray) and len(lst.shape) != 1:
        raise ValueError("cumsum only defined for 1D arrays")
    y = np.cumsum(lst)
    if isinstance(lst, list):
        return y.tolist()
    return y


def diff(lst):
    if isinstance(lst, np.ndarray) and len(lst.shape) != 1:
        raise ValueError("diff only defined for 1D arrays")
    y = np.diff(lst, prepend=0)
    if isinstance(lst, list):
        return y.tolist()
    return y


def sign(x):
    """What a shame. Python does not have a sign function."""
    if x > 0:
        return 1
    if x == 0:
        return 0
    return -1


@njit
def unique_with_inverse_preallocated(arr, unique_arr, inverse_arr, unique_len):
    """
    Compute unique values and inverse indices using preallocated arrays.
    `arr` is input array.
    `unique_arr` is preallocated array to hold unique values, size = unique_len.
    `inverse_arr` is preallocated array same size as arr to hold inverse indices.
    `unique_len` is number of unique values.

    Returns actual number of unique values found (should match unique_len if correct).
    """
    # Initialize unique count and fill first value
    if arr.size == 0:
        return 0
    unique_arr[0] = arr[0]
    count = 1
    inverse_arr[0] = 0

    for i in range(1, arr.size):
        val = arr[i]
        # cast to float for NaN checks; safe for ints too
        valf = float(val)
        found = -1
        for j in range(count):
            u = unique_arr[j]
            uf = float(u)
            # consider NaNs equal (numpy.unique groups NaNs together)
            if np.isnan(valf) and np.isnan(uf):
                found = j
                break
            if u == val:
                found = j
                break
        if found >= 0:
            inverse_arr[i] = found
        else:
            if count < unique_len:
                unique_arr[count] = val
                inverse_arr[i] = count
                count += 1
            else:
                # unique_arr overflow, handle error or break
                inverse_arr[i] = -1  # or raise exception
                break
    return count
