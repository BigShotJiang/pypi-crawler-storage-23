from itertools import islice

from william.library.base import Value
from william.library.types import float_like, int_like


def int_gen(free_values=()):
    for v in free_values:
        if isinstance(v.value, int_like):
            yield v
    yield Value(0)
    for n in range(5):
        yield Value(2**n)


def float_gen(free_values=()):
    for v in free_values:
        if isinstance(v.value, float_like):
            yield v
    yield Value(0.0)


class BufferedIterator:
    """Take an iterator and store returned items into a queue.
    Automatically pull items from the iterator as far as required.
    """

    def __init__(self, _iter):
        self._iter = _iter
        self._buffer = []
        self._max_index = None

    def _extend(self, index):
        num = index - len(self._buffer) + 1
        self._buffer.extend(islice(self._iter, num))
        if index != len(self._buffer) - 1:
            self._max_index = len(self._buffer) - 1

    def __getitem__(self, index):
        last_index = index
        if isinstance(index, slice):
            last_index = index.stop
        if last_index < 0:
            # As it's an implementation detail, how far the buffer already got
            # prefilled, it doesn't make sense to allow indexing from the right
            # end of the buffer.
            raise IndexError("index needs to be a positive value")
        if self._max_index is not None and last_index > self._max_index:
            raise IndexError("BufferedIterator index out of range")
        if len(self._buffer) < last_index + 1:
            self._extend(last_index)
        return self._buffer[index]
