from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from william.regressor import RegressionObjectiveFunction, WilliamRegressor

FILE_ENDINGS_CSV = ".csv", ".csv.gz", ".csv.gzip", ".csv.bz2", ".csv.zip", ".csv.zstd"
FILE_ENDINGS_PARQUET = (".parquet",)


FUNCTION_SET = (
    "add_ff",
    "self_add_f",
    "add_f_af",
    "add_af_af",
    "mult_ff",
    "self_mult_f",
    "mult_f_af",
    "mult_af_af",
    "soft_invert_f",
    "soft_invert_af",
    "negate_f",
    "negate_af",
    "exp_af",
    "log_af",  # "sqrt_af",
    "sin_af",
    # "cos_af",
    "tanh_af",
)


def read_data(fpath: Path) -> pd.DataFrame:
    """Read whatever we got (optionally compressed CSV or parquet) into a Pandas dataframe."""
    if fpath.name.endswith(FILE_ENDINGS_CSV):
        return pd.read_csv(fpath)
    if fpath.name.endswith(FILE_ENDINGS_PARQUET):
        return pd.read_parquet(fpath)
    raise ValueError("Unknown file type")


def prepare_data(df: pd.DataFrame, standardize: bool = True, precision: int = 6, max_size=100_000):
    """Use the "target" column as the label and the rest as features"""
    if len(df.columns) > 10:
        raise ValueError("The data has too many columns")
    if "target" not in df.columns:
        raise ValueError("No target column found")
    if len(df) > max_size:
        df = df.iloc[:max_size, :]
    if "target" not in df.columns:
        raise ValueError("Dataset has to have to column named 'target', denoting the regression target.")
    x_df = df.drop("target", axis=1)
    x_names = list(x_df.columns)
    x = np.array(x_df, dtype=np.float32)
    y = np.array(df["target"], dtype=np.float32)

    sc_x = StandardScaler()
    sc_y = StandardScaler()
    if standardize:
        # standardize the data to mean 0 and std 1
        x = np.round(sc_x.fit_transform(x), precision)
        x[np.isnan(x)] = 0

        y = np.round(sc_y.fit_transform(y.reshape(-1, 1)).flatten(), precision)
        y[np.isnan(y)] = 0

        # y = np.round((y - np.nanmean(y)) / np.nanstd(y), precision)
        # y[np.isnan(y)] = 0
        # x = np.round((x - np.nanmean(x, axis=0)) / np.nanstd(x, axis=0), precision)
        # x[np.isnan(x)] = 0
    return x, y, x_names, sc_x, sc_y


class R2Maximizer(RegressionObjectiveFunction):
    minimal_improvement = 0.001

    def _evaluate(self, tcs, mem=None):
        factor = mem[tcs.prediction_node].val
        y_predict = np.zeros_like(self.y_train) if factor.dummy else factor.value
        if np.any(~np.isfinite(y_predict)):
            return
        if np.any(np.abs(y_predict) > 1e15):
            return
        return -r2_score(self.y_train, y_predict)


def process_data(df: pd.DataFrame, standardize: bool = True, path: Path = None) -> str:
    est = WilliamRegressor(
        function_set=FUNCTION_SET,
        obj_fun_cls=R2Maximizer,
        store="",
        lin_reg=True,
    )
    x, y, x_names, sc_x, sc_y = prepare_data(df, standardize=standardize)
    fit_params = {
        "x_names": x_names,
        "level": 2,
        "max_time": 60,
        "render": False,
        "graph_num": None,
    }

    # Split the data into training and testing sets
    train_size = 0.75
    random_state = 42
    x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=train_size, random_state=random_state)
    train_idx, test_idx = train_test_split(np.arange(len(y)), train_size=train_size, random_state=random_state)

    try:
        est.fit(x_train, y_train, **fit_params)
    except KeyboardInterrupt:
        return "computation was interrupted"
    y_train_predict = est.predict(x_train, x_names=x_names)
    y_test_predict = est.predict(x_test, x_names=x_names)
    y_predict = np.zeros_like(y)
    y_predict[train_idx] = y_train_predict
    y_predict[test_idx] = y_test_predict

    pd = est._graph.prediction_node
    pd.render(filename="web_result", create_file="pdf", path=path)

    scaling = ""
    tree_name = pd.tree_name([], infix=True)[1:-1]
    for k, name in enumerate(x_names):
        tree_name = tree_name.replace(name, name + "_scaled")
        scaling += f"{name}_scaled = ({name} - {sc_x.mean_[k]}) / {sc_x.scale_[k]}\n    "
    result = f"""
    Dear user,
    The data has been scaled in the following way:
    
    {scaling}
    
    The function found by WILLIAM:
    target_scaled = {tree_name}
    
    Scaling target back:
    target = {sc_y.scale_[0]} * target_scaled + {sc_y.mean_[0]}
    
    Enjoy!
    """
    return result


# python3 -m uvicorn william.web.app:app
