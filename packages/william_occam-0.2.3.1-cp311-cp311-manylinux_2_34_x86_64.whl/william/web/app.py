"""
WILLIAM web interface. Run this web server from the project root with:

uvicorn william.web.app:app

By default, this opens a webserver on localhost:8000. A different port can be chosen by
using the --port argument. For development, add --reload for automatically reloading the
server on file changes.

Additional dependencies:
- uvicorn
- fastapi
- jinja2
- dotenv
- email_validator
- python-multipart
"""

import logging
import logging.handlers
import multiprocessing
import os
import random
import string
import time
from email.message import EmailMessage
from pathlib import Path
from smtplib import SMTP_SSL

from dotenv import load_dotenv
from email_validator import validate_email
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from starlette import status
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

from william.web.worker import FILE_ENDINGS_CSV, FILE_ENDINGS_PARQUET, process_data, read_data

MAX_FILE_SIZE = 5_000_000
FILE_ENDINGS = FILE_ENDINGS_CSV + FILE_ENDINGS_PARQUET
ALLOWED_MIMETYPES = [
    "text/csv",
    "application/gzip",
    "application/zip",
    "application/octet-stream",  # For Parquet files
]

CPU_COUNT = max(os.cpu_count() // 2, 1)
WEB_ROOT = Path(__file__).parent
PROJECT_ROOT = WEB_ROOT.parent.parent
TMP = PROJECT_ROOT / "tmp"
JOBS = TMP / "jobs"
PIDS = TMP / "pids"
LOGS = TMP / "logs"


load_dotenv()

logging.basicConfig(format="{levelname}: {message}", level=logging.INFO, style="{")
logger = logging.getLogger("root")


def write_pid_file(pid: int) -> None:
    with open(PIDS / f"{pid}.pid", "w") as f:
        f.write(str(pid))


def remove_pid_file(pid: int) -> None:
    os.remove(PIDS / f"{pid}.pid")


def process_count() -> int:
    # TODO: process count updates rather slow. Spamming jobs is possible to a small degree
    return sum(1 for _ in PIDS.glob("*.pid"))


class LimitUploadSize(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp, max_upload_size: int) -> None:
        super().__init__(app)
        self.max_upload_size = max_upload_size

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.method == "POST":
            if "content-length" not in request.headers:
                return JSONResponse(
                    status_code=status.HTTP_411_LENGTH_REQUIRED,
                    content={
                        "status": "error",
                        "message": "No content-length provided",
                    },
                )
            content_length = int(request.headers["content-length"])
            if content_length > self.max_upload_size:
                return JSONResponse(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    content={
                        "status": "error",
                        "message": "Upload file size too large",
                    },
                )
        return await call_next(request)


app = FastAPI()
app.add_middleware(LimitUploadSize, max_upload_size=MAX_FILE_SIZE)
templates = Jinja2Templates(directory=WEB_ROOT / "templates")


@app.on_event("startup")
def startup() -> None:
    for folder in (TMP, JOBS, PIDS, LOGS):
        if not folder.exists():
            folder.mkdir()

    for fpath in PIDS.glob("*.pid"):
        os.remove(fpath)

    # Needs initialized folders
    logger.addHandler(logging.handlers.TimedRotatingFileHandler(LOGS / "william_web.log"))


@app.get("/", response_class=HTMLResponse)
async def index():
    return templates.TemplateResponse("index.html", {"request": {}})


@app.post("/upload/")
async def upload(email: str = Form(...), file: UploadFile = File(...)):
    try:
        validate_email(email)
    except ValueError:
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={
                "status": "error",
                "message": "The email address seems invalid.",
            },
        )

    if process_count() >= CPU_COUNT:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={
                "status": "error",
                "message": "Server is too busy. Please try again later.",
            },
        )

    # Check the file type
    if file.content_type not in ALLOWED_MIMETYPES or not file.filename.endswith(FILE_ENDINGS):
        return JSONResponse(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            content={"status": "error", "message": "Invalid file type"},
        )

    fpath = JOBS / file.filename
    if fpath.exists():
        random_prefix = "".join(random.choice(string.ascii_letters) for _ in range(10))
        fpath = fpath.with_name(f"{random_prefix}-{fpath.name}")
    fpath.write_bytes(file.file.read())

    # TODO: Need more upfront verification of the received data

    # Create a new process for the task
    process = multiprocessing.Process(target=handle_uploaded_file, args=(fpath, email))
    process.start()

    resp = (
        "The file is being processed! You will receive an email after the process is completed. This may take a while."
    )
    return {"status": "success", "message": resp}


def send_email(email: str, result: str) -> None:
    msg = EmailMessage()
    msg.set_content(result)
    msg["Subject"] = "Your data analysis results"
    msg["From"] = "WILLIAM <william@occam.com.ua>"
    msg["To"] = email

    with SMTP_SSL(os.getenv("MAIL_HOST")) as server:
        server.login(os.getenv("MAIL_USERNAME"), os.getenv("MAIL_PASSWORD"))
        server.send_message(msg)


def handle_uploaded_file(fpath, email):
    """This is the long running job, which is spawned in a separate process."""
    pid = os.getpid()
    write_pid_file(pid)
    logger.info(f"Start working on {fpath.name} for {email}, PID: {pid}")
    try:
        result = process_data(read_data(fpath), path=TMP)
        time.sleep(3)
        logger.info(f"Work on {fpath.name} for {email} finished: {result}")
        try:
            send_email(email, result)
        except Exception as e:
            logger.info(f"Result mail delivery to {email} failed: {type(e).__name__}: {e}")
    finally:
        os.remove(fpath)
        remove_pid_file(pid)
