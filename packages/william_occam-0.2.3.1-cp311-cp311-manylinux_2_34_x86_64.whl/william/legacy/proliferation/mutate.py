from william.legacy.bush import Bush


def create_new_bush(bush, ref_section, maps, mems, new_dl, target_nodes, max_roots=1, only_fire=False):
    new_section, org_to_new, bush_to_new, hashes = bush.maps_and_hashes()

    trans_map = _map_from_ref_to_new_bush(maps[1], bush_to_new, mems[2])
    predicted_roots, direction, predicted_nodes, exists = _ref_section_clone(
        ref_section, mems[1], mems[2], hashes, trans_map=trans_map
    )
    if direction == -1 and only_fire:
        return
    # disallow more than one option
    if any([len(vn.options) > 1 for vn in new_section.walk(op_nodes=False)]):
        return
    impermeable = [org_to_new[n] for n in target_nodes if not n.output.permeable and n in org_to_new]
    # org_to_new[bush.entity.root]
    if bush.entity is not None and _bad_direction(new_section, impermeable, predicted_nodes):
        return
    # direction change is only possible, if the downward growth uses the previously upward created root
    if bush.direction == +1 and direction == -1:
        if len(bush.roots) >= 2:
            return
        if bush.replacing_node not in maps[1]:
            return
    # TODO: are impermeable nodes allowed to break the cycle?
    if any([root.cycle(impermeable=()) for root in predicted_roots]):
        return
    if _attaching_below_permeable_target_nodes(predicted_nodes, target_nodes, org_to_new):
        return
    if _black_listed(predicted_nodes):
        return
    if _concat_composition(predicted_roots):
        return

    new_bush = Bush(
        new_section,
        hash=hash(new_section),
        entity=bush.entity,
        node_to_entity=bush.node_to_entity,
        novel=set(bush_to_new[node] for node in bush.novel).union(predicted_nodes),
        roots=update_roots([bush_to_new[node] for node in bush.roots], predicted_roots, direction),
        corr=org_to_new,
        dl=new_dl,
        direction=direction,
        proliferate=not exists,
    )
    if len(new_bush.roots) > max_roots:
        return
    if direction == -1:
        assert all([n in new_bush.corr.inv for n in new_bush.roots])
    return new_bush


black_list = {
    "invert": "invert",
    "negate": "negate",
    "exp": "log",
    "log": "exp",
    "cos": "arccos",
    "sin": "arcsin",
    "arccos": "cos",
    "arcsin": "sin",
}


def _black_listed(predicted_nodes):
    for node in predicted_nodes:
        if node.is_val_node:
            continue
        forbidden = black_list.get(node.op.name, None)
        if forbidden is None:
            continue
        child = node.children[0]
        if not child.options:
            continue
        if child.options[0].op.name == forbidden:
            return True
    return False


def _concat_composition(predicted_roots):
    """Disallow constructions like concat(a, concat(a, b)), where <a> is a child of both concats in the composition."""
    for val_node in predicted_roots:
        if not val_node.options:
            continue
        node = val_node.options[0]
        if node.op.arity is not None:
            continue
        if node.op.name == "add":
            continue
        for child in node.children:
            if not child.options:
                continue
            sub_node = child.options[0]
            if sub_node.op != node.op:
                continue
            if set(node.children).intersection(sub_node.children):
                return True
    return False


def _attaching_below_permeable_target_nodes(predicted_nodes, target_nodes, org_to_new):
    """Don't attach below permeable target nodes."""
    for node in predicted_nodes:
        if node.is_val_node:
            continue
        vn = node.parent
        if not vn.output.permeable:
            continue
        if vn not in org_to_new.inv:
            continue
        org_vn = org_to_new.inv[vn]
        if org_vn in target_nodes:
            return True
    return False


def _map_from_ref_to_new_bush(map1, corr2, pred_mem):
    # map1: bush --> ref_section
    # corr2: bush --> new_bush
    # trans_map = map1 - corr2: ref_section --> new_bush
    trans_map = map1.difference(corr2)
    for node, entry in pred_mem.items():
        if entry.same and node in corr2:
            trans_map[node] = corr2[node]
    return trans_map  # pointing from ref_section to new bush


def _bad_direction(cond_rest, roots, pred_nodes):
    """
    All predicted nodes have to be either below the root or above cond nodes including permeable nodes.
    """
    for pred_node in pred_nodes:
        if not pred_node.is_below(roots) and not pred_node.is_above(cond_rest.nodes):
            return True
    return False


def _ref_section_clone(ref_section, mem, pred_mem, bush_hashes, trans_map=None):
    # clone only the part where propagation was successful (in pred_mem), but not
    # the one already existing (the cue graph given by trans_map)
    predicted_nodes, predicted_roots = _predicted_nodes(pred_mem, trans_map)

    # It is a new prediction, if it is not in mem (roots are in pred_mem by construction)
    # TODO: why pick only the first? Something is wrong here
    direction = +1 if predicted_roots[0] not in mem else -1

    # This is a complex operation. Here trans_map maps from matched part of the ref_section to new_bush and
    # predicted
    # nodes are nodes outside the trans_map, since predicted nodes are predicted and not part of the match. Hence,
    # repl=trans_map guarantees that the matched part of the ref_section is replaced by the respective nodes inside
    # new_bush and the predicted nodes are thereby attached to new_bush. By setting allowed=predicted_nodes it is
    # guaranteed that the predicted nodes are the only new nodes established by clone.
    clone_corr = {}
    ref_section.clone(
        corr=clone_corr,
        repl=trans_map,
        allowed=pred_mem.keys(),
        copy=True,
        replace=False,
    )
    exists = _set_values_for_clone(ref_section, clone_corr, pred_mem, predicted_nodes, bush_hashes)

    cloned_roots = [clone_corr[n] for n in predicted_roots if clone_corr[n]]
    cloned_pn = [clone_corr[n] for n in predicted_nodes if clone_corr[n]]
    return cloned_roots, direction, cloned_pn, exists


def _predicted_nodes(pred_mem, trans_map):
    roots = []  # roots are highest nodes in pred_mem, excluding the ones in trans_map
    nodes = []
    for node in pred_mem.keys():
        # there is a root, if a node inside the graph is in pred_mem and has no parent in pred_mem.
        if node.is_val_node and not any([n in pred_mem for n in node.walk(below=False, include_self=False)]):
            roots.append(node)
        if node not in trans_map:
            nodes.append(node)
    return nodes, roots


def _set_values_for_clone(ref_section, clone_corr, pred_mem, predicted_nodes, bush_hashes):
    # if any([root in predicted_nodes and clone_corr[root].output.hash in bush_hashes for root in roots]):
    #     return False
    exists = False
    for node in ref_section.walk():
        if node not in pred_mem:
            continue
        if not node.is_val_node:
            _remove_children_not_in_pred_mem(node, pred_mem, clone_corr)
            continue
        value = pred_mem[node].val
        value.set_spec(node.output.spec)
        # don't predict anything that already exists
        if node in predicted_nodes and value.realized and value.hash in bush_hashes:
            exists = True
        clone = clone_corr[node]
        clone.output = value

        # _remove_superfluous_options(clone, clone_corr.values(), removed)
    return exists


def _remove_children_not_in_pred_mem(node, pred_mem, clone_corr):
    for i in range(len(node.children) - 1, -1, -1):
        child = node.children[i]
        if child in pred_mem:
            continue
        # remove child
        cn = clone_corr[node]
        cc = clone_corr[child]
        del cn.children[i]
        j = cc.parents.index(cn)
        del cc.parents[j]


# def _remove_superfluous_options(node, new_nodes, removed):
#     """Forbid more than one option."""
#     # new, predicted nodes come from the ref_section, and clone_corr stores its copy-corr. Therefore, new options
#     # can be recognized by them being in clone_corr.values()
#     if node.is_cyclic() or not any([o in new_nodes for o in node.options]):
#         return
#     # delete all old options
#     for o in node.options[:]:
#         if o not in new_nodes:
#             o.remove_branch(removed=removed)


def update_roots(current_roots, predicted_roots, direction):
    # if a root is cyclic and dir=-1 and there is an impermeable in the cycle, make it the root
    if direction == -1:
        found = False
        for k, root in enumerate(current_roots):
            imps = [n for n in root.cycle() if n.is_val_node and not n.output.permeable]
            if imps:
                current_roots[k] = imps[0]
                found = True
        if found:
            return current_roots

    # Note: independently of direction, the roots should be the uppermost nodes
    # remove all current roots below predicted roots
    for root in current_roots[::-1]:
        cycle = root.cycle()
        if root in cycle and any([not node.output.permeable for node in cycle]):
            continue
        if root.is_below(predicted_roots):
            current_roots.remove(root)
    # add predicted roots that are not below some old root
    for pr in predicted_roots:
        if not pr.is_below(current_roots):
            current_roots.append(pr)
    return current_roots
