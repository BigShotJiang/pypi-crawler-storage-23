from itertools import chain

from dask.distributed import Client
from streamz import Stream, gen

from william.legacy.evaluation import attach_or_replace
from william.legacy.proliferation import associate
from william.legacy.proliferation.proliferate_sp import initial_bushes
from william.semantics.net import make_entity_net
from william.utils import UniquePrioHeapQueue

client = Client()


@Stream.register_api()
class hq_buffer(Stream):
    """Allow results to pile up at this point in the stream

    This allows results to buffer in place at various points in the stream.
    This can help to smooth flow through the system when backpressure is
    applied.
    """

    _graphviz_shape = "diamond"

    def __init__(self, upstream, n, **kwargs):
        # This indexing is necessary in order to handle the metadata
        self.queue = UniquePrioHeapQueue(
            maxsize=n,
            key=lambda b_t_m: b_t_m[0].dl,
            hash=lambda b_t_m: hash(b_t_m[0]),
            auto_truncate=True,
        )

        kwargs["ensure_io_loop"] = True
        Stream.__init__(self, upstream, **kwargs)

        self.loop.add_callback(self.cb)

    def update(self, b_t, who=None, metadata=None):
        self._retain_refs(metadata)
        return self.queue.put((b_t[0], b_t[1], metadata))

    @gen.coroutine
    def cb(self):
        while True:
            bush, target, metadata = yield self.queue.get()
            yield self._emit((bush, target), metadata=metadata)
            self._release_refs(metadata)


@Stream.register_api()
class iter_flatten(Stream):
    """Flatten streams of lists or iterables into a stream of elements"""

    def update(self, x, who=None, metadata=None):
        L = []
        items = chain(x)
        item = next(items)
        for item_next in items:
            y = self._emit(item)
            item = item_next
            if isinstance(y, list):
                L.extend(y)
            else:
                L.append(y)
        y = self._emit(item, metadata=metadata)
        if isinstance(y, list):
            L.extend(y)
        else:
            L.append(y)
        return L


def proliferate(
    target,
    obj_fun,
    graph_elements,
    entity=None,
    max_bushes=None,
    compute=True,
    max_roots=1,
    only_roots_as_cues=False,
    hq_size=1000,
    level=0,
):
    net = make_entity_net(target)
    if level >= 7:
        net.render()

    source = Stream()
    buffered = source.hq_buffer(hq_size)

    bush_stream = (
        buffered.filter(lambda b_t: b_t[0].proliferate)
        .map(
            bush_proliferate,
            graph_elements,
            compute=compute,
            max_roots=max_roots,
            only_roots_as_cues=only_roots_as_cues,
        )
        .iter_flatten()
        .connect(source)
    )
    obj_stream = buffered.filter(lambda b_t: b_t[0].yield_able).map(bush_eval, target, obj_fun, level=level)

    #    par_stream = hp_buffer(source, 1000).scatter()
    #    par_stream.filter(lambda bush: bush.proliferate).map(bush_proliferate, growth_manager, change_target=change_target, level=level).flatten().gather().connect(source)
    #    iit_stream = par_stream.filter(lambda bush: bush.yield_able).map(bush_iit_check, iit, modifiable, mem=mem, level=level).gather()

    new_objs = obj_stream.sink_to_list()
    # source.visualize("proliferate.pdf")

    for bush in initial_bushes(net, target, entity):
        source.emit((bush, target))

    del bush_stream
    return new_objs[0]


def bush_eval(bush, target, obj_fun, level=-1):
    p_instructions = attach_or_replace(bush, obj_fun, target, level=level)
    if p_instructions.success:
        return p_instructions


def bush_proliferate(bush, graph_elements, compute=True, max_roots=1, only_roots_as_cues=False):
    yield from associate(
        bush,
        graph_elements,
        compute=compute,
        max_roots=max_roots,
        only_roots_as_cues=only_roots_as_cues,
    )
