import os
from itertools import count
from multiprocessing import Queue, cpu_count, get_context
from queue import Empty, Full

from william.legacy.evaluation import attach_or_replace
from william.legacy.objective_function import ObjectiveFunction
from william.legacy.params import complete_params, default_params
from william.legacy.proliferation.association import associate
from william.legacy.proliferation.proliferate_sp import initial_bushes
from william.legacy.semantics.net import make_entity_net
from william.utils import UniquePrioHeapQueue, debugger, mppdb

__STOP_MARKER = "__STOP_MARKER__"


def proliferate(
    target,
    obj_fun,
    graph_elements,
    entity=None,
    params=default_params,
    hq_size=1000,
    level=0,
    debug=False,
):
    params = complete_params(params)
    ctx = get_context()
    if params["cpus"] == "all":
        worker_count = cpu_count()
    else:
        worker_count = int(params["cpus"])

    with ctx.Manager() as m:
        ready_queue = m.Queue(maxsize=worker_count)
        sort_queue = m.Queue()
        item_counter_queue = m.Queue()
        result_queue = m.Queue(maxsize=worker_count)

        net = make_entity_net(target, singleton=params["singleton"])
        if level >= 7:
            net.render()
        for bush in initial_bushes(net, target, entity):
            sort_queue.put((bush, target))

        processes = []
        hp = ctx.Process(
            target=hq_processor,
            args=(ready_queue, sort_queue, result_queue, item_counter_queue),
            kwargs={
                "max_processing_count": params["max_bushes"],
                "hq_size": hq_size,
                "level": level,
            },
        )
        hp.name = "heapqueue_manager"
        hp.start()
        processes.append(hp)
        for c in range(worker_count):
            p = ctx.Process(
                target=proliferate_worker_failsafe,
                args=(
                    obj_fun,
                    graph_elements,
                    ready_queue,
                    sort_queue,
                    result_queue,
                ),
                kwargs={
                    "compute": params["compute"],
                    "max_roots": params["max_roots"],
                    "only_roots_as_cues": params["only_roots_as_cues"],
                    "level": level,
                    "proc_num": c,
                    "debug": debug,
                },
            )
            p.name = f"proliferate_worker_{c}"
            processes.append(p)
            p.start()

        try:
            # Waiting for one of the workers to return a new object into the queue
            p_instructions = result_queue.get()
            if p_instructions is None:
                stop_processing(sort_queue, ready_queue, worker_count)
                raise RuntimeError(f"Maximum number of handled bushes ({params['max_bushes']}) reached.")
            if p_instructions == __STOP_MARKER:
                stop_processing(sort_queue, ready_queue, worker_count)
                if debug:
                    print("Child process crashed, waiting for debug")
                    for p in processes:
                        p.join()
                raise RuntimeError("Child process crashed")

            debugger(level, {5: "New object found"})
            stop_processing(sort_queue, ready_queue, worker_count)
            debugger(level, {5: "Queues closed"})
            for p in processes:
                p.join(timeout=10)
            debugger(level, {5: "Processes joined"})
            p_instructions.bush_count = item_counter_queue.get()
            return p_instructions
        finally:
            for p in processes:
                if p.is_alive():
                    debugger(level, {5: f"Terminating {p}"})
                    p.terminate()


def hq_processor(
    ready_queue: Queue,
    sort_queue: Queue,
    instruction_queue: Queue,
    item_counter_queue: Queue,
    max_processing_count=None,
    hq_size=1000,
    processing_display_count=100,
    level=0,
):
    __tracebackhide__ = True
    # Careful here:
    # The target may not be included in the hash, in order to avoid endless
    # reiteration of the same bushes
    hq = UniquePrioHeapQueue(
        maxsize=hq_size,
        key=lambda b_t: b_t[0].dl,
        hash=lambda b_t: hash(b_t[0]),
        auto_truncate=True,
    )
    item_counter = 0
    item_counter_last_output = 0

    while True:
        while True:
            try:
                item = sort_queue.get(block=False)
            except ValueError:
                # queue was closed
                return
            except Empty:
                break
            else:
                if item == __STOP_MARKER:
                    # items in the ready_queue, which were not fetched, don't count
                    item_counter_queue.put(item_counter - ready_queue.qsize())
                    return
                hq.put(item)

        while not ready_queue.full() and hq:
            item = hq.get()
            try:
                ready_queue.put(item, timeout=1)
            except ValueError:
                # queue was closed
                return
            except Full:
                hq.put(item)
                break
            else:
                item_counter += 1

        if item_counter - item_counter_last_output > processing_display_count:
            item_counter_last_output = item_counter
            debugger(
                level,
                {2: f"HeapQueue: {sort_queue.qsize()}->{len(hq)}->{ready_queue.qsize()}, processed: {item_counter}"},
            )

        if max_processing_count is not None and item_counter >= max_processing_count:
            # Processing limit has been reached
            hq.clear()
            instruction_queue.put(None)
            return


def proliferate_worker(
    obj_fun: ObjectiveFunction,
    graph_elements: dict,
    in_queue: Queue,
    out_queue: Queue,
    result_queue: Queue,
    compute=True,
    max_roots=1,
    only_roots_as_cues=False,
    level=0,
    proc_num=0,
):
    __tracebackhide__ = True
    # Reduce the process priority to leave more CPU time for the
    # Queue manager and other processes
    os.nice(1)
    params = {"only_roots_as_cues": only_roots_as_cues, "max_roots": max_roots, "compute": compute}

    for bush_num in count():
        try:
            b_t = in_queue.get()
        except ValueError:
            # queue was closed
            return
        else:
            if b_t == __STOP_MARKER:
                return
            bush, target = b_t

        debugger(level, {5: f"Bush #{proc_num}-{bush_num}, dl: {bush.dl:.2f}"})

        if bush.yield_able:
            p_instructions = attach_or_replace(
                bush,
                obj_fun,
                target,
                level=level,
            )
            if p_instructions.success:
                try:
                    result_queue.put(p_instructions, timeout=1)
                except ValueError:
                    # queue was closed
                    return
                debugger(
                    level,
                    {5: f"Bush #{proc_num}-{bush_num}, dl: {bush.dl:.2f}: returning new object"},
                )
                return

        if bush.proliferate:
            for associated_bush in associate(bush, graph_elements, target.nodes, params):
                try:
                    out_queue.put((associated_bush, target), timeout=1)
                except ValueError:
                    # queue was closed by hq_processor
                    return


def proliferate_worker_failsafe(
    obj_fun: ObjectiveFunction,
    graph_elements: dict,
    in_queue: Queue,
    out_queue: Queue,
    result_queue: Queue,
    compute=True,
    max_roots=1,
    only_roots_as_cues=False,
    level=0,
    proc_num=0,
    debug=False,
):
    try:
        return proliferate_worker(
            obj_fun,
            graph_elements,
            in_queue,
            out_queue,
            result_queue,
            compute=compute,
            max_roots=max_roots,
            only_roots_as_cues=only_roots_as_cues,
            level=level,
            proc_num=proc_num,
        )
    except Exception:
        result_queue.put(__STOP_MARKER)
        if debug:
            print(f"Starting debugger for worker #{proc_num}")
            pdb = mppdb.MultiprocessPdb()
            pdb.post_mortem()
        else:
            print(f"Proliferate worker #{proc_num} crashed")
            import traceback

            traceback.print_exc()
            raise


def stop_processing(sort_queue, ready_queue, worker_count):
    sort_queue.put(__STOP_MARKER)
    flush_queue(ready_queue)
    for _ in range(worker_count):
        try:
            ready_queue.put(__STOP_MARKER, timeout=5)
        except Full:
            pass


def flush_queue(queue):
    try:
        while True:
            queue.get_nowait()
    except Empty:
        return
