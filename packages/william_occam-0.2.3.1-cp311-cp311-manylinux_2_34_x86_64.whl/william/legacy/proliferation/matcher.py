from william.legacy.semantics.concepts import CueItem, breadth_first_walk
from william.library.hashing import unique_hash
from william.nvmap import MapEntry, NodeValueMap
from william.structures.graphs import Graph
from william.utils import pretty


def match_graphs(bush, ref_dict, only_roots_as_cues=False):
    seen_maps = set([])
    for name, ref in ref_dict.items():
        ref_graph = Graph(ref)
        for map1, nums in _match_bush_to_ref_section(bush, ref_graph, only_roots_as_cues=only_roots_as_cues):
            map_hash = hash(map1)
            if map_hash in seen_maps:
                continue
            seen_maps.add(map_hash)
            yield ref_graph, map1, nums


def _match_bush_to_ref_section(bush, ref_graph, only_roots_as_cues=False):
    # if there is a root, then only it can be a cue node
    gen = bush.node_combinations([None])
    if only_roots_as_cues and bush.roots:
        gen = [((root,), (i,)) for i, root in enumerate(bush.roots)]
    for val_nodes, num in gen:
        cue_node = val_nodes[0]
        for ref_node in ref_graph.walk(op_nodes=False):
            if cue_node.output.spec != ref_node.output.spec:
                continue
            yield Mapping({cue_node: ref_node}), num


def retrieve_from_memory(obj):
    for item in breadth_first_walk(CueItem(obj, 0), max_distance=1):
        # ref_graph = Graph(item.node.intension.root)
        # don't take item.obj.nodes themselves since they might be in a different order than the intension nodes
        # we need the correspondence between object nodes and their intension nodes
        retrieved_nodes = list(item.obj.root.walk(allowed=item.obj.nodes))
        intension_nodes = list(item.node.intension.root.walk())
        if len(retrieved_nodes) != len(intension_nodes):
            raise ValueError("The number of object nodes has to match the number of nodes in its intension.")
        if set(retrieved_nodes) != set(item.obj.nodes):
            raise ValueError("Wrong object nodes for some reason.")

        map0 = Mapping({})
        for ret_node, int_node in zip(retrieved_nodes, intension_nodes):
            if ret_node not in obj.nodes:
                continue
            map0[ret_node] = int_node
        yield map0


class Mapping(dict):
    def __str__(self):
        s = "================================\n"
        for node1, node2 in self.items():
            s += pretty(node1.val) + "\n"
            s += pretty(node2.val) + "\n\n"
        return s[:-1] + "================================\n"

    def __eq__(self, other):
        if len(self) != len(other):
            return False
        for cue, ref in self.items():
            if cue not in other:
                return False
            other_ref = other[cue]
            if ref is not other_ref:
                return False
        return True

    def __hash__(self):
        ids = [(id(node1), id(node2)) for node1, node2 in self.items()]
        return unique_hash(sorted(ids))

    @property
    def id(self):
        ids = [id(node) for node in self.keys()]
        return unique_hash(sorted(ids))

    def copy(self):
        return Mapping(super().copy())

    def pretty(self):
        s = ()
        for node1, node2 in self.items():
            if not node1.is_val_node:
                continue
            s += ((pretty(node1.output.value), pretty(node2.output.value)),)
        return s

    def to_mem(self):
        mem = NodeValueMap()
        for cue, ref in self.items():
            # same = (cue.val.hash == ref.val.hash) if check_sameness else False
            mem[ref] = MapEntry(same=cue is ref, val=cue.val)
        return mem

    def difference(self, corr):
        """
        If self is a map from A --> B and corr is a map from A --> C, then difference constructs a map from B --> C,
        like a vector difference.
        """
        trans_map = Mapping({})
        for cue, ref in self.items():
            trans_map[ref] = corr[cue]
        return trans_map

    def add(self, cues, refs, skip_existing=False):
        for cue, ref in zip(cues, refs):
            if skip_existing and cue in self:
                continue
            self[cue] = ref

    @property
    def contains_dummy_values(self):
        for node in self.keys():
            if not node.is_val_node:
                continue
            if node.output.dummy:
                return True
        return False
