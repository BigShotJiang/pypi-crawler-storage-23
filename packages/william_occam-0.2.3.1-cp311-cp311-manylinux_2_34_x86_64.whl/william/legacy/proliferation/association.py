from dataclasses import dataclass
from random import randint

from william.legacy.bush import Bush
from william.legacy.proliferation.matcher import Mapping, match_graphs
from william.legacy.proliferation.mutate import create_new_bush
from william.legacy.proliferation.predict import predict
from william.library.description import desc_len, int_tuple_dl
from william.propagation_py import RandomPropagation
from william.rendering import render_map
from william.structures import Graph, Node, ValueNode
from william.utils import set_trace_up


@dataclass(slots=True)
class DelayedBushBuilderSelf:
    """
    A wrapper for bush construction. It knows everything in order to construct a new bush from the previous bush,
    however it doesn't do so right after initialization. Only after this object is popped from the heap, the bush
    is actually constructed. This avoids the construction of many bushes in the heap that ultimately won't get popped
    at all since the proliferation is interrupted at some point, leaving the majority of bushes unused in the heap.
    """

    # TODO: generalize over the various bush builders and make them reuse code (derive classes)
    bush: Bush
    new_dl: float

    def build(self, *args):
        yield self.bush

    def __hash__(self):
        return self.bush.hash


@dataclass(slots=True)
class DelayedBushBuilderPreliminary:
    bush: Bush
    ref_graph: Graph
    map0: Mapping
    nums0: tuple
    new_dl: float
    target_nodes: list
    inf_nodes: list

    def build(self, *args):
        map_level = 0
        if map_level >= 1:
            render_map(self.bush.section, self.ref_graph, self.map0, [])
            set_trace_up()
        ref_root = self.ref_graph.nodes[0]
        # map- and mem-numbers: 0: initial after match. 1: after adding missing, 2: after propagation
        for maps, mems, nums, missing in predict(self.bush, ref_root, self.map0, self.inf_nodes):
            if map_level >= 2:
                render_map(self.bush.section, self.ref_graph, maps[1], missing)
                set_trace_up()
            updated_dl = self.bush.dl + int_tuple_dl(self.nums0 + tuple(nums))
            dbb = DelayedBushBuilderFinalize(self.bush, ref_root, maps, mems, updated_dl, self.target_nodes)
            yield dbb

    def __hash__(self):
        # Since this default builder is a preliminary builder, treat its objects as non-repeating
        return randint(10000000, 90000000)


@dataclass(slots=True)
class DelayedBushBuilderFinalize:
    bush: Bush
    ref_root: ValueNode
    maps: tuple
    mems: tuple
    new_dl: float
    target_nodes: list

    def build(self, max_roots, only_fire, compute):
        pr = RandomPropagation(
            partial=True,
            unique=True,
            compute=compute,
        )

        for mem2 in pr.propagate(self.ref_root, self.mems[1]):
            if len(mem2) <= len(self.mems[1]):
                continue
            new_bush = create_new_bush(
                self.bush,
                self.ref_root,
                self.maps,
                self.mems + (mem2,),
                self.new_dl,
                self.target_nodes,
                max_roots=max_roots,
                only_fire=only_fire,
            )
            if new_bush is not None:
                yield new_bush

    def __hash__(self):
        # no way to predict the hash of the new bush without actually creating it
        # hence for all practical purposes, treat such bushes as different bushes
        return randint(10000000, 90000000)


@dataclass(slots=True)
class DelayedBushBuilderRearrange:
    bush: Bush
    ref_root: ValueNode
    new_dl: float
    hash: int

    def build(self, *args):
        v = self.ref_root
        new_section, org_to_new, self_to_new, _ = self.bush.maps_and_hashes()
        new_bush = Bush(
            new_section,
            hash=self.hash,
            entity=self.bush.entity,
            node_to_entity=self.bush.node_to_entity,
            novel={self_to_new[v]},
            roots=[self_to_new[v]],
            corr=org_to_new,
            dl=self.new_dl,
            direction=+1,
            proliferate=False,
        )
        yield new_bush

    def __hash__(self):
        return self.hash


@dataclass(slots=True)
class DelayedBushBuilderVariableArity:
    bush: Bush
    common_children: list
    var_arity_node: Node
    new_dl: float
    hash: int

    def build(self, *args):
        new_section, org_to_new, bush_to_new, _ = self.bush.maps_and_hashes()
        new_children = [bush_to_new[n] for n in self.common_children]
        root = ValueNode(output=self.var_arity_node.parent.output)
        root.set_option(Node(op=self.var_arity_node.op, children=new_children), reverse=True)

        new_bush = Bush(
            new_section,
            hash=self.hash,
            entity=self.bush.entity,
            node_to_entity=self.bush.node_to_entity,
            novel={root, root.options[0]},
            roots=[root],
            corr=org_to_new,
            dl=self.new_dl,
            direction=+1,
            proliferate=False,
        )
        yield new_bush

    def __hash__(self):
        return self.hash


def associate(bush, graph_elements, target_nodes, params):
    if bush.first:
        for item in rearrange(bush):
            yield item
        # TODO: careful! Here some changes are applied to the current bush
        for item in replace_variable_arity_nodes(bush):
            yield item
    inf_nodes = bush.inferred_nodes()
    for ref_graph, map0, nums0 in match_graphs(bush, graph_elements, only_roots_as_cues=params["only_roots_as_cues"]):
        preliminary_dl = bush.dl + int_tuple_dl(nums0)
        dbb = DelayedBushBuilderPreliminary(bush, ref_graph, map0, nums0, preliminary_dl, target_nodes, inf_nodes)
        yield dbb


def rearrange(bush):
    """Use existing nodes in original graph as 'novel' values, in order to try to make replacements with them."""
    for val_nodes, num in bush.node_combinations([None]):
        dbb = DelayedBushBuilderRearrange(bush, val_nodes[0], bush.dl + desc_len(num), num[0])
        yield dbb


def replace_variable_arity_nodes(bush):
    """Dirty solution for replacing sub-graphs like union(a, union(b, c)) by union(a, b, c)."""
    for node in bush.section.walk(val_nodes=False):
        if node.op.arity is not None:
            continue
        # if len(node.children) == 2 and node.children[0] is node.children[1]:  # skip self-add
        #     continue
        if node.op.name == "add":  # TODO: deal with add at some point
            continue
        # TODO: careful! Here some changes are applied to the current bush
        _remove_doubled_children(node)
        common_children = _collect_common_children(node)
        if not common_children:
            continue
        dbb = DelayedBushBuilderVariableArity(bush, common_children, node, bush.dl + 1, 123)
        # new_section, org_to_new, bush_to_new, _ = bush.maps_and_hashes()
        # new_children = [bush_to_new[n] for n in common_children]
        # root = ValueNode(output=node.parent.output)
        # root.set_option(Node(op=node.op, children=new_children), reverse=True)
        #
        # new_bush = Bush(
        #     new_section,
        #     hash=123,
        #     entity=bush.entity,
        #     node_to_entity=bush.node_to_entity,
        #     novel={root, root.options[0]},
        #     roots=[root],
        #     corr=org_to_new,
        #     dl=bush.dl + 1,
        #     direction=+1,
        #     proliferate=False,
        # )
        yield dbb


def _collect_common_children(node):
    common_children = []
    found = False
    for child in node.children:
        if child.options and child.options[0].op == node.op:
            common_children.extend(child.options[0].children)
            found = True
        else:
            common_children.append(child)
    return list(common_children) if found else []


def _remove_doubled_children(node):
    for i in range(len(node.children) - 1, -1, -1):
        if node.children[i] in node.children[i + 1 :]:
            del node.children[i]
