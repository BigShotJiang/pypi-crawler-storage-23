"""
Used the matched portion of a graph, in order to predict other values.
If propagation/prediction fails, it means that some values are "missing" for propagation, try to find them.
"""

from william.composite import Composite
from william.conditions import inf_cond_nodes


def predict(bush, ref_root, map0, inf_nodes):
    mem0 = map0.to_mem()
    for missing in _missing_nodes_for_extension(ref_root, mem0):
        # TODO: missing sources is quite slow. Can it be moved to the delayed bush builder?
        #  The problem is that it creates <nums> which co-determines its position in the heap
        for cue_nodes, nums in _missing_sources(bush, missing, map0):
            mem1 = mem0.copy()
            mem1.add(missing, [n.output for n in cue_nodes], same=False, skip_existing=True)
            map1 = map0.copy()
            map1.add(cue_nodes, missing, skip_existing=True)  # map points from bush to ref_section
            if all([entry.same for entry in mem1.values()]):
                continue
            if any([n in cue_nodes for n, _ in inf_nodes]):
                continue
            # the map contains values which will be used for propagation. Don't use dummy values.
            if map1.contains_dummy_values:
                continue
            maps = (map0, map1)
            mems = (mem0, mem1)
            yield maps, mems, nums, missing


def _missing_nodes_for_extension(root, mem):
    occupied = set(mem.keys())
    # for leaf_cond_nodes in conditioned_nodes(obj.root, blocked=occupied):
    #     yield [cn for cn in leaf_cond_nodes if _trace_without_mem_exists(cn, occupied)]
    # TODO: Get rid of Composite
    comp = Composite(root)
    for gen_cond in comp.generalized_conditions():
        inf_nodes, cond_nodes = inf_cond_nodes(root, list(root.leaves()), gen_cond)
        if any([inf in occupied for inf in inf_nodes]):
            continue
        yield [cn for cn in cond_nodes if _trace_without_mem_exists(cn, occupied)]


def _trace_without_mem_exists(val_node, occupied):
    for trace in val_node.traces(me_too=True):
        if not occupied.intersection(trace):
            return True
    return False


def _missing_sources(bush, missing, map0):
    if not missing:
        yield [], []
        return
    skip = list(map0.keys())
    for val_nodes, nums in bush.node_combinations([n.output.spec for n in missing], skip=skip):
        yield val_nodes, list(nums)
