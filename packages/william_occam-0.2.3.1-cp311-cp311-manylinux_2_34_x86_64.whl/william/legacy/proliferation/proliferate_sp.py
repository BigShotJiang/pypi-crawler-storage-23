from queue import Full

from william.legacy.bush import Bush
from william.legacy.params import complete_params, default_params
from william.legacy.proliferation.association import DelayedBushBuilderSelf, associate
from william.utils import UniquePrioHeapQueue, debugger, dispdots, memory_usage, seen_already, set_trace_up


def proliferate(
    target,
    graph_elements,
    entity,
    node_to_entity,
    params=default_params,
    level=0,
):
    params, _ = complete_params(params)
    hq = UniquePrioHeapQueue(maxsize=params["hq_size"], key=lambda bb: bb.new_dl, auto_truncate=True)

    bush = Bush.from_entity(entity, node_to_entity, target, dl=0)
    dbb = DelayedBushBuilderSelf(bush, bush.dl)
    hq.put(dbb)

    seen_bushes = set()

    sk = 0
    bpd = 1  # bushes per dot
    bush_count = 0
    memory_at_start = memory_usage()
    while hq:
        try:
            dbb = hq.get()
        except RuntimeError as e:
            print(e)
            return

        for bush in dbb.build(params["max_roots"], params["only_fire"], params["compute"]):
            # This is required for acceleration purposes. We avoid generating (=associating) too many bushes, since
            # the majority won't ever pop out of the heap, when proliferation is stopped. Therefore, in order to avoid
            # running the time consuming <predict> at association, it is run by the default builder.
            # However, since the result of <predict> co-determines the position of the
            # bush in the heap, it is pushed back into the heap with its updated (increased) dl.
            # See new_dl computation inside DelayedBushBuilderDefault
            if not isinstance(bush, Bush):  # hence a DelayedBuilderSelf object
                try:
                    hq.put(bush)
                except Full:
                    return
                continue

            # The count is increased here, right after fetching from the queue, to be in line
            # with the multi-processed counting
            bush_count += 1

            if seen_already(bush, seen_bushes):
                continue

            if params["max_bushes"] is not None and bush_count >= params["max_bushes"]:
                print(f"Maximum number of handled bushes ({params['max_bushes']}) reached.")
                return

            if level in [2, 3]:
                dispdots(bush_count, bpd, dots_per_line=100)
            if level in [2, 3] and bush_count % (100 * bpd) == 0 or level not in [2, 3]:
                memory = memory_usage()
                bush_info = f"Bush #{bush_count}, dl: {bush.dl:.2f}, heap size: {len(hq)}, memory: {memory:.2f} MB, avg. MB/bush: {(memory - memory_at_start) / bush_count:.4f}"
                debugger(level, {2: bush_info})

            if level >= 10:  # step by step debugging
                bush.render()
                set_trace_up()
                if sk:
                    continue
                sk = 1
                hq.clear()

            if bush.yield_able:
                yield bush, bush_count

            if bush.proliferate:
                for new_dbb in associate(bush, graph_elements, target.nodes, params):
                    try:
                        hq.put(new_dbb)
                    except Full:
                        return
