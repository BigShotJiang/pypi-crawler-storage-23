from collections import defaultdict
from itertools import product

from william.structures import Node, ValueNode
from william.utils import FancyIndexingList


def ways_to_decouple(replaced, decoupled, lower=(), higher=(), new_replacing=True):
    """
    Iterates through mutations of nodes children. The mutations happen in-place. Though,
    after a full cycle of the iterator, the previous state is restored.
    """
    nodes = [replaced, decoupled]
    par_nums, group_idx, lower_idx = _parents_and_child_nums(replaced, lower=(), higher=higher)
    if not par_nums:
        yield ()
        return
    one_at_a_time = len(par_nums) > 4
    org_parents = replaced.parents[:]
    for comb in _loop_combs(len(par_nums), one_at_a_time=one_at_a_time, all_at_once=False):
        if not _commutation_comb_check(group_idx, comb):
            continue
        if not _lower_nodes_comb_check(comb, lower_idx):
            continue
        switch_children(nodes, comb, par_nums)
        concat_node, child_num = _dirty_add_line(replaced, decoupled, comb, par_nums, new_replacing=new_replacing)
        if sum(comb) == 0:  # all are zeros, the original state is restored
            replaced.parents = org_parents
        else:
            yield comb  # [str(p.op.name) for p, c in zip(org_parents, comb) if c == 1]
        _dirty_remove_line(concat_node, child_num)


def _dirty_add_line(replaced, decoupled, comb, par_nums, new_replacing=True):
    if not new_replacing:
        return None, None
    # comb = (0, 1) or (1, 0), one parent stays, the other decouples
    if len(comb) != 2 or sum(comb) != 1:
        return None, None
    # both parents have to be line-operators
    if any([p.op.name != "line" for p, _ in par_nums]):
        return None, None
    p1 = par_nums[0][0]
    p1_points = p1.parent
    if len(p1.parent.parents) != 1:  # only if the line is part of a single figure
        return None, None
    concat_node = p1.parent.parents[0]
    if concat_node.op.name != "concat":
        return None, None
    line = p1.op
    vn = ValueNode(output=line(replaced.output, decoupled.output))
    line_node = Node(op=line, children=[replaced, decoupled])
    vn.set_option(line_node, reverse=True)

    # add new child to concat
    child_num = concat_node.children.index(p1_points) + 1
    concat_node.children = concat_node.children[:child_num] + [vn] + concat_node.children[child_num:]
    vn.parents = [concat_node]
    return concat_node, child_num


def _dirty_remove_line(concat_node, child_num):
    if concat_node is None:
        return
    concat_node.children[child_num].options[0].remove()
    del concat_node.children[child_num]


def _loop_combs(n, one_at_a_time=False, all_at_once=False):
    if all_at_once:  # decouple all and return to original state (=all zeros)
        yield (1,) * n
        yield (0,) * n
        return
    if one_at_a_time:  # only combs of the form (0, 0, 0, 1, 0), or uniform ones
        yield (1,) * n
        for i in range(n):
            comb = [0] * n
            comb[i] = 1
            yield tuple(comb)
        yield (0,) * n
        return
    for comb in product([1, 0], repeat=n):
        yield comb


def _commutation_comb_check(group_idx, comb):
    """
    Do not allow ascending combs within the same group index, e.g. group_idx = [0, 1, 1, 0, 2, 2] and
    comb = (0, 0, 0, 1, 1, 1), then within group index 0, the comb is (0, 1) hence ascending from 0 to 1 which
    is not allowed. Commutative nodes are allowed with combs like (1, 0, 0), (1, 1, 0), (1, 1, 1) etc., i.e. only
    descending.
    """
    descended = defaultdict(bool)
    for g, c in zip(group_idx, comb):
        if c == 1 and descended[g]:
            return False
        descended[g] = c == 0
    return True


def _lower_nodes_comb_check(comb, lower_idx):
    """
    Further, decoupled lower nodes only together. Hence, if lower_idx = [2, 3] then
    the comb above is not allowed, but only (0, 0, 1, 1, 0, 0) and (_, _, 0, 0, _, _) where "_" can take on any values.
    """
    if not lower_idx:
        return True
    comb = FancyIndexingList(comb)
    num_decoupled = sum(comb)
    num_lower_decoupled = sum(comb[lower_idx])
    if num_lower_decoupled == len(lower_idx):  # if all lower nodes are to be decoupled,...
        return num_decoupled == num_lower_decoupled  # .. then they should be the only decoupled nodes
    # if only part of the lower nodes are to be decoupled, then none of them are allowed to be decoupled
    if num_lower_decoupled > 0:
        return False
    return True


def _parents_and_child_nums(node, lower=(), higher=()):
    """
    Assign a distinct index to every parent-child pair. This is necessary, since the PC-pair
    can repeat and we need that in order to treat parents with commutative operators.
    """
    par_nums = []
    group = {}
    idx = 0
    group_idx = []
    lower_idx = []
    for parent in node.parents:
        #  do not decouple higher nodes
        if parent in higher:
            continue
        for i, child in enumerate(parent.children):
            if child is not node:
                continue
            pc = (parent, child)
            if pc not in group or not parent.op.commutative:
                group[pc] = idx
                idx += 1
            par_nums.append((parent, i))
            group_idx.append(group[pc])
            if parent in lower:
                lower_idx.append(len(par_nums) - 1)
    return par_nums, group_idx, lower_idx


def switch_children(nodes, node_nums, par_nums):
    for node_num, (parent, child_num) in zip(node_nums, par_nums):
        _switch_child(parent, child_num, nodes[node_num])


def _switch_child(parent, num, new_child):
    """Switch child number <num> of <parent> node, to new_child."""
    child = parent.children[num]
    if new_child is child:
        return
    # remove parent as parent of current child,
    # unless there is another connection from parent to the same current child
    if not any([c is child for i, c in enumerate(parent.children) if i != num]):
        p_num = child.parents.index(parent)
        del child.parents[p_num]
    parent.set_child(new_child, num, reverse=True)
