from william.legacy.evaluation.attach_replace import attach, attach_or_replace, replace
