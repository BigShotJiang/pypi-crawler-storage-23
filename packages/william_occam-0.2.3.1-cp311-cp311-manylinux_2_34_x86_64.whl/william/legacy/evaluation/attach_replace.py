from collections import namedtuple

from william.legacy.finalization import apply_bush, reverse_apply_bush
from william.utils import everything, stop


def attach_or_replace(bush, target, replace_params, level=0):
    success, values = bush.section.realize()
    if not success:
        _flush(values)
        bush.proliferate = False
        return [], None
    bush.render(condition=level >= 6)
    stop(level, threshold=6)

    if bush.direction == -1:
        gen = attach(bush, target)
    else:
        gen = replace(bush, target, replace_params, level=level)
    return gen, values


def attach(bush, target):
    replaced = bush.corr.inv[bush.replacing_node]
    if _attachment_creates_cycle(bush.replacing_node, bush.corr.inv):
        return
    decoupled = None
    rev = apply_bush(bush, target, replaced, decoupled)
    yield everything, replaced, decoupled
    reverse_apply_bush(bush, target, decoupled, rev)


def _attachment_creates_cycle(replacing, inv):
    """
    Even though a node is below the replacing node in the bush, it might be above the (corresponding) replacing node in
    the original graph. Thus, even though the bush may not have a cycle, the application to the original graph will
    have one. Avoid this.
    """
    # replacing is always in corr.inv during attachment (direction == -1)
    org_replacing = inv[replacing]
    for node in replacing.walk(op_nodes=False, above=False, include_self=True):
        if node not in inv:
            continue
        if inv[node].is_above([org_replacing], include_self=False):
            return True
    return False


DecInfo = namedtuple("DecInfo", "decoupled_node decoupled_branch_pairs")


def replace(bush, target, replace_params, level=0):
    decoupled = bush.replacing_node.copy_wo_connections()
    imp_in_cycle, _ = _impermeable_in_cycle(target.nodes)
    bush_imp_in_cycle = set(bush.corr[n] for n in imp_in_cycle if n in bush.corr)
    for new_mem, replaced, comb in bush.prop(
        target, decoupled, replace_params, bush_imp_in_cycle=bush_imp_in_cycle, level=level
    ):
        stop(level, threshold=6)
        rev = apply_bush(
            bush,
            target,
            replaced,
            decoupled,
            mem=new_mem,
            imp_in_cycle=imp_in_cycle,
        )
        dec = DecInfo(decoupled_node=decoupled, decoupled_branch_pairs=rev.decoupled_branch_pairs)
        yield new_mem, replaced, dec
        reverse_apply_bush(bush, target, decoupled, rev)


def _flush(values):
    for v in values:
        v.flush()


def _impermeable_in_cycle(nodes):
    iic = []
    imps = []
    for node in nodes:
        if node.output.permeable:
            continue
        imps.append(node)
        if node.cycle():
            iic.append(node)
    return tuple(iic), tuple(imps)
