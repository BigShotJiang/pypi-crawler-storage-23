from william.conditions import ConditionCombinations, inf_cond_nodes
from william.propagation_py import FireDown, FireDownWithoutComputation, FireUp, FireUpWithoutComputation
from william.utils.containers import everything


class CondCombPropagation:
    """
    This type of propagation tries to find all the ways data can flow through a DAG. Every node has a set of
    generalized conditions, which determine which inputs are given in order to infer which outputs. The propagation
    algorithm tries to find all combinations of conditions for all nodes, such that the flow directions never conflict, i.e.
    data can never flow both into and out of a node.
    """

    def __init__(self, partial=False, use_existing=False, unique=True, compute=True, cache=False):
        self.partial = partial
        self.use_existing = use_existing
        self.unique = unique
        self.fire_up = FireUp(cache_enabled=cache) if compute else FireUpWithoutComputation()
        self.fire_down = FireDown(cache_enabled=cache) if compute else FireDownWithoutComputation()

    def propagate(self, root, mem, allowed=everything, invertible=everything, debug=False):
        mem_seen = []
        gen = ConditionCombinations.get(root, mem=mem, allowed=allowed, invertible=invertible)
        for k, cond_dict in enumerate(gen):
            # dispdots(k, 1)
            # print([(node.op.name, cond) for node, cond in cond_dict.items()])
            # print(pretty(source_node.output))
            # color = ConditionCombinations.color_from_cond_dict(cond_dict)
            # self.root.render(color=color)
            # self.root.render(color=color, filename='before')

            new_mem = mem.copy()
            eval_nodes = list(cond_dict.keys())
            # if not eval_nodes:
            #     continue
            while eval_nodes:
                node = eval_nodes.pop()
                success = self.evaluate(node, cond_dict, new_mem, seen=set(), allowed=allowed)
                if not success:
                    break
                eval_nodes = [n for n in cond_dict.keys() if n not in new_mem]
            else:
                if self.unique and new_mem in mem_seen:
                    continue
                mem_seen.append(new_mem)
                yield new_mem

    def evaluate(self, node, cond_dict, mem, seen=None, allowed=everything):
        if node in mem or node in seen:
            return True
        if node not in cond_dict:
            return True
        seen.add(node)

        gen_cond = cond_dict[node]
        inf_nodes, cond_nodes = inf_cond_nodes(node.parent, [c for c in node.children if c in allowed], gen_cond)
        success, cond_inputs, same = self._collect_firing_requirements(cond_nodes, gen_cond, cond_dict, mem, seen)
        if not success:
            return False
        success = self._try_to_fire(node, mem, inf_nodes, gen_cond, cond_inputs, same=same, allowed=allowed)
        return success

    def _collect_firing_requirements(self, cond_nodes, gen_cond, cond_dict, mem, seen):
        cond_inputs = ()
        same = True
        for cn, i in zip(cond_nodes, gen_cond):
            if cn in mem:
                same = same and mem[cn].same
                cond_inputs += (mem[cn].val,)
                continue
            if self.use_existing and not self._could_be_inferred(cn, cond_dict):
                mem.add([cn], [cn.output], same=True)
                cond_inputs += (mem[cn].val,)
                continue
            for neighbor in cn.neighbors():
                if neighbor not in cond_dict:
                    continue
                if cn not in list(_inf_nodes(neighbor, cond_dict[neighbor])):
                    continue
                success = self.evaluate(neighbor, cond_dict, mem, seen=seen)
                if not success:
                    return False, None, None
            if cn not in mem:
                return False, None, None
            cond_inputs += (mem[cn].val,)
            same = same and mem[cn].same
        return True, cond_inputs, same

    @staticmethod
    def _could_be_inferred(val_node, cond_dict):
        """
        Check whether the value of <val_node> could be inferred from its neighbors, given their conditions.
        It could be inferred only if it is among the inferred nodes of at least one neighbor.
        """
        present_neighbors = [n for n in val_node.neighbors() if n in cond_dict]
        for neighbor in present_neighbors:
            if val_node in list(_inf_nodes(neighbor, cond_dict[neighbor])):
                return True
        return False

    def _try_to_fire(self, node, mem, inf_nodes, gen_cond, cond_inputs, same=False, allowed=everything):
        if any(inf in mem for inf in inf_nodes):
            return False
        if same:
            mem.add(inf_nodes, [n.val for n in inf_nodes], same=True, op_node=node)
            return True

        fire_instance, cond = (self.fire_down, gen_cond[1:]) if gen_cond[0] == -1 else (self.fire_up, gen_cond)

        for inf_values in fire_instance._cached_loop(node, cond_inputs, cond, len(inf_nodes)):
            mem.add(inf_nodes, inf_values, same=False, op_node=node)
            return True  # TODO: only first inversion result used
        return False


def _inf_nodes(node, gen_cond, allowed=everything):
    if -1 not in gen_cond:
        yield node.parent
    for i, child in enumerate(c for c in node.children if c in allowed):
        if i not in gen_cond:
            yield child
