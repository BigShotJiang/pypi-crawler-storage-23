from dataclasses import dataclass

# This class needs to be in a separate module, in order to avoid
# circular imports, as the separation between evaluation and
# finalization is not that clear so far.


@dataclass
class ProliferationResults:
    improved_dl: float = None
    new_target: object = None
    bush_count: int = 0


default_proliferation_params = {
    "max_bushes": None,
    "compute": True,
    "max_roots": 1,
    "only_roots_as_cues": True,
    "only_fire": False,
    "singleton": True,
    "mode": "serial",
    "cpus": "all",
    "hq_size": None,
}


default_replace_params = {
    "replace_only_below_prediction_node": False,
}


def complete_params(params):
    a = dict((key, params.get(key, value)) for key, value in default_proliferation_params.items())
    b = dict((key, params.get(key, value)) for key, value in default_replace_params.items())
    return a, b


default_params = default_proliferation_params.copy()
default_params.update(default_replace_params)
