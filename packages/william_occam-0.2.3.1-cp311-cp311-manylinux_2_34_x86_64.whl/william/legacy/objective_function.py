from enum import IntEnum

from william.legacy.finalization.transfer import reassemble_branch
from william.library.basic_ops import Add
from william.library.description import desc_len
from william.utils import ansi, everything


class ThresholdState(IntEnum):
    NOT_REACHED = 0
    REACHED = 1
    MAX_GRAPH_SIZE_REACHED = 2


class ObjectiveFunction:
    """Allow the usage of arbitrary objective functions, not just the description length."""

    minimal_improvement = 0.1

    def __init__(self, threshold=None, max_op_nodes=None):
        self.threshold = threshold
        self.max_op_nodes = max_op_nodes
        self.seen = set()

    def improved(self, graph, parent_fitness, dec=None, mem=everything):
        if not self._check(graph, mem):
            return
        return self._improved(graph, parent_fitness, dec, mem=mem)

    @staticmethod
    def _check(graph, mem):
        return True

    def _improved(self, graph, parent_fitness, dec, mem=everything):
        """Return new description length, if the graph is an improvement."""
        # keep stuff below the decoupled node, only if there are impermeables down there
        # i.e. keep graph as small as possible, but don't miss the opportunity to express some impermeables with
        # other impermeables (impermeables are assumed to be data to be explained / compressed).
        if dec is not None and dec.decoupled_node.options and not dec.decoupled_node.is_above(graph.impermeable_nodes):
            # try removing stuff below decoupled node in order to keep graph small
            graph.remove_branch(dec.decoupled_node, me_too=False, removed_pairs=dec.decoupled_branch_pairs)
            dl = self.evaluate(graph, mem=mem)
            # if it is an improvement, keep it
            if self.better(dl, parent_fitness):
                return dl
            # otherwise, put it back together again and...
            reassemble_branch(dec.decoupled_branch_pairs)

        # ...go on computing the dl with the stuff below the decoupled node
        dl = self.evaluate(graph, mem=mem)
        if self.better(dl, parent_fitness):
            return dl

    def better(self, loss1, loss2):
        if loss1 is None:
            return False
        return loss1 < loss2 - self.minimal_improvement

    @staticmethod
    def size(graph):
        return len(list(graph.walk(val_nodes=False)))

    def evaluate(self, graph, mem=everything):
        dl0 = self._evaluate(graph, mem=mem)
        return dl0

    @staticmethod
    def _evaluate(graph, mem=everything):
        dl = 0
        for leaf in graph.leaves(mem=mem, op_nodes=True):
            dl += leaf.output_dl(mem=mem, mode="default")
            # permeable graph.nodes will be copied when they are propagated though, hence count their dl too
            if mem is everything or leaf not in mem or mem[leaf].same:
                continue
            if leaf in graph.nodes and leaf.output.permeable:
                dl += leaf.output_dl(mode="default")  # without mem, the original value
        return dl

    def accept_solution(self, tcs, mem):
        pass

    @staticmethod
    def check_dl(improved_dl, actual_dl, level):
        if improved_dl is None:
            return True
        if improved_dl < 0:
            return False
        if abs(improved_dl - actual_dl) > 1e-4 and level >= 1:
            print(f"\n{ansi.RED}actual_dl - improved_dl: {actual_dl - improved_dl:.2f}{ansi.RESET}")
        return True

    def threshold_state(self, search_node):
        if self.threshold is not None and search_node.progress >= self.threshold:
            return ThresholdState.REACHED
        if self.max_op_nodes is not None and search_node.num_op_nodes >= self.max_op_nodes:
            return ThresholdState.MAX_GRAPH_SIZE_REACHED
        return ThresholdState.NOT_REACHED

    def status_report(self, search_node):
        s = f"{ansi.CYAN}"
        s += f"Loss: {search_node.fitness:.4f}"
        s += f"   Progress: {search_node.progress:.4f}%"
        if self.threshold is not None:
            s += f" ({self.threshold}%)"
        s += f"   DOF: {search_node.degrees_of_freedom}"  # Op nodes: {search_node.num_op_nodes}
        pn = search_node.graph.prediction_node
        if pn is not None:
            s += pn.graph_name()
        s += f"{ansi.RESET}"
        return s

    def plot(self, search_node):
        try:
            from matplotlib import pylab as plt

            plt.ion()
        except ImportError:
            return

        fitness = search_node.fitness_trace
        plt.clf()
        plt.plot(fitness)
        if self.threshold is not None:
            v = (1 - self.threshold / 100) * fitness[0]
            plt.plot([v] * len(fitness), "--")
        plt.xlabel("iteration")
        plt.ylabel("description length (bits)")
        plt.show()
        plt.pause(0.00001)


class RegressionObjectiveFunction(ObjectiveFunction):
    def __init__(self, y_train, threshold=None, max_op_nodes=None):
        self.y_train = y_train
        super().__init__(threshold=threshold, max_op_nodes=max_op_nodes)

    @staticmethod
    def _check(graph, mem):
        return graph.prediction_node in mem

    def _evaluate(self, tcs, mem=everything):
        factor = mem[tcs.prediction_node].val
        if factor.dummy:
            residual = desc_len(self.y_train, mode="default")
        else:
            diff = list(Add()._inverse(self.y_train, (factor.value,), (0,)))
            if not diff:
                return
            residual = desc_len(diff[0][0], mode="default")
        leaves_dl = tcs.leaves_dl(mem=mem, op_nodes=True, mode="default")
        return residual + leaves_dl

    @staticmethod
    def check_dl(improved_dl, actual_dl, level):
        return True

    @staticmethod
    def _any_leaf_without_name(graph):
        for leaf in graph.leaves():
            if leaf is graph:
                continue
            if leaf.output.name is None:
                return True
        return False
