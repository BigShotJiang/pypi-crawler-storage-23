from itertools import product


def monster_nested_for(gen, cues, refs, x, combine=True, match_all=False):
    """Monster combinatorial, fucking marvelous, recursive, nested piece of code madness."""
    if not cues or not refs:
        yield x
        return
    combs = [(0, j) for j in range(len(refs))] if combine else [(0, 0)]
    found = False
    for i, j in combs:
        ys = list(gen(cues[i], refs[j], x))
        if not ys:
            continue
        cues_copy = cues[:]
        cues_copy.pop(i)
        refs_copy = refs[:]
        refs_copy.pop(j)
        for y in ys:
            for z in monster_nested_for(gen, cues_copy, refs_copy, y, combine=combine, match_all=match_all):
                found = True
                yield z
    if not found and not match_all:
        yield x


class Match:
    def __init__(self, corr):
        self.corr = corr

    def op_node_match(self, cue, ref, map0):
        """
        Try to match op node <cue> in graph 1 with op node <ref> in graph 2, with the previous
        mapping from graph 1 to graph 2 stored in <map0>. Yield all possible updated maps.
        """
        if cue in map0:
            # if cue already mapped to something which is not ref, then we get a contradiction. Break.
            if map0[cue] is not ref:
                return
            # otherwise simply yield the previous map back and continue search elsewhere
            yield map0
            return
        if cue.op != ref.op:
            return
        if len(cue.children) != len(ref.children):
            return
        # during self-association (graph 2 is a copy of graph 1), the match areas should not overlap (with op nodes)
        org = self.corr.get(ref, None)
        if org is cue or org in map0:
            return

        # Father forgive me, for I have sinned.
        # Nested loop using nested monster for loops which themselves contain a combinatorial
        # product, all contained in a double recursion.
        # Hopefully, the universe will not break down.
        # Serious comment:
        # Try to match children with each other.
        # Try all combinations in a nested way. monster_nested_for has to be used, since each cue child matched with
        # each ref child continues matching further with their respective parents and options and so forth.
        # Hence nesting is necessary and not merely all combinations of cue children with ref children.
        seen = set()
        for map1 in monster_nested_for(
            self.val_node_match,
            cue.children,
            ref.children,
            map0,
            combine=cue.op.commutative,
            match_all=True,
        ):
            for map2 in monster_nested_for(
                self.val_node_match, [cue.parent], [ref.parent], map1, combine=False, match_all=True
            ):
                map2[cue] = ref
                if map2 in seen:
                    # print("op skipping")
                    continue
                seen.add(map2)
                yield map2

    def val_node_match(self, cue, ref, map0):
        """
        Try to match value node <cue> in graph 1 with value node <ref> in graph 2, with the previous
        mapping from graph 1 to graph 2 stored in <map0>. Yield all possible updated maps.
        """
        if cue in map0:
            # if cue already mapped to something which is not ref, then we get a contradiction. Break.
            if map0[cue] is not ref:
                return
            # otherwise simply yield the previous map back and continue search elsewhere
            yield map0
            return
        if ref in map0.values():  # ref has to be unseen yet
            return
        if cue.output.spec != ref.output.spec:  # specs have to match
            return
        if len(cue.options) > 1 or len(ref.options) > 1:  # allow only single option nodes
            return
        map1 = map0.copy()
        map1[cue] = ref

        # Father forgive me, for I have sinned.
        # Nested loop using nested monster for loops which themselves contain a combinatorial
        # product, all contained in a double recursion.
        # Hopefully, the universe will not break down.
        # Serious comment:
        # Try to match options with each other. For each options match there can be various parent matches.
        # Try all combinations in a nested way. monster_nested_for has to be used, since each cue option matched with
        # each ref option continues matching further with their respective parent and children and so forth.
        # Hence nesting is necessary and not merely all combinations of cue options with ref options.
        seen = set()
        for map2 in monster_nested_for(self.op_node_match, cue.options, ref.options, map1, combine=True):
            for map3 in monster_nested_for(self.op_node_match, cue.parents, ref.parents, map2, combine=True):
                if map3 in seen:
                    # print("val skipping")
                    continue
                seen.add(map3)
                yield map3

    def find_nodes_by_specs(self, graph, specs, skip_root=False):
        for comb in product(*[self._find_node_by_spec(graph, spec, skip_root=skip_root) for spec in specs]):
            if len(set(comb)) == len(comb):
                yield list(comb)

    @staticmethod
    def _find_node_by_spec(graph, spec, skip_root=False):
        for node in graph.walk(op_nodes=False):
            if skip_root and node is graph:
                continue
            if node.output.spec == spec:
                yield node
