from william.legacy.semantics.concepts import ConceptNode, Extension


def taxonomy_from_extension(concept_node, remove_singletons=True):
    """
    Take extension and find all taxonomic subdivisions which are also extensions, recursively. The result is an
    extension tree.
    """
    # no point following a myriad of combinations when there is just a single object in the extension
    if remove_singletons and len(concept_node.extension.objects) == 1:
        concept_node.remove()
        return

    # all first leaves, all second leaves and so on..
    for leaf_tuple in zip(*[obj.leaves for obj in concept_node.extension.objects]):
        # each object and its n-th leaf
        for obj, leaf in zip(concept_node.extension.objects, leaf_tuple):
            if not leaf.options:
                continue
            for new_obj in obj.grow(leaf.options[0]):
                add_object_to_existing_child_or_make_new(concept_node, new_obj)
    for node in concept_node.children[::-1]:
        taxonomy_from_extension(node, remove_singletons=remove_singletons)


def add_object_to_existing_child_or_make_new(concept_node, obj):
    for child in concept_node.children:
        success = child.extension.add(obj)
        if success:
            return
    new_node = ConceptNode(extension=Extension(objects=[obj]))
    concept_node.set_child(new_node, reverse=True)


def remove_non_compressing_extensions(concept_graph, check_leaves=True):
    """Take concept graph and remove non-compressing extensions."""
    nodes = list(concept_graph.walk())
    roots = []
    for node in nodes:
        if not node.parents:
            roots.append(node)
        if not node.extension.compressing(check_leaves=check_leaves):
            node.remove()
            if node in roots:
                roots.remove(node)
    if not roots:
        ValueError("Hoppla, the whole graph has been removed. This should not happen.")
    return roots


def merge_compatible_concept_nodes(root, seen=None):
    # TODO: use structure hash built in a commutation invariant way??
    if seen is None:
        seen = set()
    nodes = list(root.walk())
    for node1 in nodes:
        for node2 in nodes:
            if (node1, node2) in seen:
                continue
            seen.add((node1, node2))
            if node1 is node2:
                continue
            if not node1.extension.compatible(node2.entity):
                continue
            _delete_overarching_taxonomic_links(node1, node2)
            _delete_overarching_taxonomic_links(node2, node1)
            node1.merge(node2)
            if node2 in root.nodes:
                root.nodes.remove(node2)
            root.remove_with_parents()

            # if node1.is_cyclic():
            #     raise ValueError("Cycle found.")
            # dn, dnc = root.asymmetric()
            # if dn is not None:
            #     st()
            # dbd = root.any_doubled()
            # if dbd is not None:
            #     raise ValueError("Doubled found.")
            merge_compatible_concept_nodes(root, seen=seen)
            return


def _delete_overarching_taxonomic_links(b, c):
    """If a --> b --> c and there is a direct link a --> c, delete the direct link."""
    # if not c.is_below([b], include_self=False, sense="taxonomic"):
    #     return
    for a in c.parents[:]:
        if b.is_below([a], include_self=False, sense="taxonomic"):
            c.parents.remove(a)
            a.children.remove(c)


def _delete_overarching_partonomic_links(b, c):
    """If a --> b --> c and there is a direct link a --> c, delete the direct link."""
    if not c.is_below([b], include_self=False, sense="partonomic"):
        return
    for a in c.wholes[:]:
        if b.is_below([a], include_self=False, sense="partonomic"):
            c.wholes.remove(a)
            a.parts.remove(c)
