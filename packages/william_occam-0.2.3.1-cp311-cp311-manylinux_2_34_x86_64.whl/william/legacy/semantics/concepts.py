import json
from dataclasses import dataclass
from itertools import permutations

from william.legacy.semantics.objects import Object
from william.rendering import ConceptNodeRenderingMixin, graphs_to_dot
from william.utils.helpers import replace_occurrences


class ConceptNode(ConceptNodeRenderingMixin):
    """The semantic net is made up of these nodes."""

    neighbor_names = ("children", "parents", "parts", "wholes")

    def __init__(self, extension=None, intension=None, name=""):
        self.name = name
        self._extension = extension
        if extension is not None:
            extension.belongs_to = self
        self._intension = intension
        # taxonomy
        self.children = []  # = is-gen-of, i.e. rectangle is a generalization of a square
        self.parents = []  # = is-a,      i.e. square is a rectangle
        # partonomy
        self.wholes = []  # roof is part of house, hence house is in the set of wholes of the root
        self.parts = []  # house has a roof

    @property
    def c(self):
        return self.children

    @property
    def is_gen_of(self):
        return self.children

    @property
    def is_a(self):
        return self.parents

    @property
    def neighbors(self):
        for name in self.neighbor_names:
            yield from getattr(self, name)

    @property
    def extension(self):
        return self._extension

    @property
    def intension(self):
        if self._intension is None:
            self._intension = self.entity.extract_intension()
        return self._intension

    @property
    def entity(self):
        return self.extension.objects[0]

    def set_child(self, child, num=None, reverse=False):
        if child in self.children:
            return
        if num is None:
            num = len(self.children)
        self.children.extend([None] * (num - len(self.children) + 1))
        self.children[num] = child
        if reverse and self not in child.parents:
            child.parents.append(self)

    def set_part(self, part, num=None, reverse=False):
        if part in self.parts:
            return
        if num is None:
            num = len(self.parts)
        self.parts.extend([None] * (num - len(self.parts) + 1))
        self.parts[num] = part
        if reverse and self not in part.wholes:
            part.wholes.append(self)

    def walk(self, seen=None, above=True, below=True, to_parts=True, to_wholes=True):
        """Depth-first walk through graph."""
        if seen is None:
            seen = set()
        if self in seen:
            return
        yield self
        seen.add(self)
        decision = {"children": below, "parents": above, "parts": to_parts, "wholes": to_wholes}
        for attribute, allowed in decision.items():
            if not allowed:
                continue
            for node in getattr(self, attribute):
                yield from node.walk(seen=seen, above=above, below=below, to_parts=to_parts, to_wholes=to_wholes)

    def remove(self):
        """Remove node by connecting its parents to its children."""
        for parent in self.parents:
            parent.children.remove(self)
        for child in self.children:
            child.parents.remove(self)
        for parent in self.parents:
            for child in self.children:
                parent.set_child(child, reverse=True)
        self.children = []
        self.parents = []

    def merge(self, other):
        """Merge a node with a compatible other."""
        if self is other:
            return
        for entity in other.extension.objects:
            entity.belongs_to = self.extension
            self.extension.objects.append(entity)

        for p in other.parents:
            if p in self.parents:
                p.children.remove(other)
                continue
            self.parents.append(p)
            replace_occurrences(p.children, other, self)
        other.parents = []

        for c in other.children:
            if c in self.children:
                c.parents.remove(other)
                continue
            self.children.append(c)
            replace_occurrences(c.parents, other, self)
        other.children = []

    def is_below(self, nodes, trace=(), include_self=True, sense="taxonomic"):
        if self in trace:
            return False
        if include_self and self in nodes:
            return True
        upper_neighbors = self.parents if sense == "taxonomic" else self.wholes
        for neighbor in upper_neighbors:
            if neighbor.is_below(nodes, trace=(self,) + trace, sense=sense):
                return True
        return False

    def is_cyclic(self, trace=()):
        if self in trace:
            return True
        for child in self.children:
            if child.is_cyclic(trace=(self,) + trace):
                return True
        return False

    def doubled(self):
        if len(set(self.children)) != len(self.children):
            return True
        if len(set(self.parents)) != len(self.parents):
            return True
        return False

    def any_doubled(self):
        for node in self.walk():
            if node.doubled():
                return node

    def asymmetric(self):
        for node in self.walk():
            for child in node.children:
                if node not in child.parents:
                    return node, child
        return None, None

    def serialize(self):
        d = {"name": self.name}
        # use special separator in order to avoid inserting new line, while being able to parse the string into new
        # lines while reading afterwards
        d["graph"] = graphs_to_dot([self.intension.root], reading=False, with_brackets=False, separator="@$%")
        return json.dumps(d)

    def resembles(self, other, seen=None):
        if seen is None:
            seen = set()
        if self in seen:
            return True
        seen.add(self)
        if not self.intension.root.resembles(other.intension.root):
            return False
        for attribute in ["children", "parents", "parts", "wholes"]:
            if not self.perm_check_resembles(getattr(self, attribute), getattr(other, attribute), seen):
                return False
        return True

    @staticmethod
    def perm_check_resembles(nodes1, nodes2, seen, commutative=True):
        if len(nodes1) != len(nodes2):
            return False
        # options or parents might occur in a different order in nodes2 than in nodes1, try to match all permutations
        perms = permutations(nodes2) if commutative else [nodes2]
        for nodes2_perm in perms:
            seen_backup = seen.copy()
            for p1, p2 in zip(nodes1, nodes2_perm):
                if not p1.resembles(p2, seen=seen):
                    break  # try different permutation
            else:
                return True
            # replace elements in seen by elements in seen_backup without changing the object
            seen.clear()
            seen.update(seen_backup)
        return False

    @property
    def size(self):
        return len(list(self.intension.root.walk()))

    def roots(self, seen=None):
        if seen is None:
            seen = set([])
        if not self.parents and not self.wholes and self not in seen:
            seen.add(self)
            yield self
        for up_node in self.parents + self.wholes:
            yield from up_node.roots(seen=seen)


class Extension:
    """An extension of a concept is the list of objects corresponding to that concept."""

    def __init__(self, objects=()):
        self.objects = list(objects)
        for entity in objects:
            entity.belongs_to = self
        self.belongs_to = None

    def add(self, entity):
        """Add new object."""
        if not self.compatible(entity):
            return False  # no success
        if self.exists_already(entity):
            return False  # no success
        self.objects.append(entity)
        entity.belongs_to = self
        return True  # success

    def compatible(self, entity):
        """
        Check if object is compatible with the other objects in the extension, i.e. if their graphs resemble.
        """
        if not self.objects:
            return True
        obj0 = self.objects[0]
        if len(entity.nodes) != len(obj0.nodes):
            return False
        return entity.root.resembles(obj0.root, check_values=False, allowed=(entity.nodes, obj0.nodes))

    def exists_already(self, entity):
        # TODO: use hash
        obj_nodes = set(entity.nodes)
        for obj0 in self.objects:
            if set(obj0.nodes) == obj_nodes:
                return True
        return False

    def compressing(self, check_leaves=True):
        """An extension is compressing if all of its objects are compressing."""
        for entity in self.objects:
            if not entity.compressing:
                return False
            if check_leaves and entity.has_uncompressed_leaves:
                return False
        return True


def breadth_first_walk(start_nodes, max_distance=None):
    """Breadth-first walk through graph."""
    seen = set()
    queue = []
    for node in start_nodes:
        seen.add(node.entity.id)
        queue.append(CueItem(node.entity, 0))

    while queue:
        item = queue.pop(0)
        yield item.entity

        if max_distance is not None and item.distance >= max_distance:
            continue
        for new_item in item.generate(seen):
            queue.append(new_item)


@dataclass(slots=True)
class CueItem:
    entity: Object
    distance: int

    def generate(self, seen):
        for neighbor in self.entity.node.neighbors:
            my_nodes = self.entity.op_nodes
            for entity in neighbor.extension.objects:
                if entity.id in seen:
                    continue
                seen.add(entity.id)
                your_nodes = entity.op_nodes
                if my_nodes.issubset(your_nodes) or your_nodes.issubset(my_nodes):
                    yield CueItem(entity, self.distance + 1)
