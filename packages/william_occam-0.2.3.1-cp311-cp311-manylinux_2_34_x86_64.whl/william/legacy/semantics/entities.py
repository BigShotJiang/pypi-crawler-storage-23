from collections import defaultdict, namedtuple
from functools import reduce
from itertools import chain

from william.library.hashing import unique_hash
from william.structures.graphs import Graph
from william.utils import UniqueList, ansi, everything


class Intension:
    """An intension of a concept is a graph with its value nodes void of values."""

    def __init__(self, root):
        self.root = root

    def __hash__(self):
        """A hash based solely on the connection matrix and the operators"""
        op_hashes = tuple(node.op.hash for node in self.root.walk(val_nodes=False))
        return unique_hash((type(self), op_hashes, self.root.connections()))

    def some_subgraph(self, other):
        """
        The subgraph-method of ValueNode works only if the graphs match STARTING FROM the given value nodes root1 and
        root2, which is rarely the case. Try to find locations where the graphs might match.
        """
        for op_node in other.root.walk(val_nodes=False):
            if not self.root.options or self.root.options[0].op != op_node.op:
                continue
            if self.root.subgraph(op_node.parent):
                return True
        return False

    def render(self, filename="intension", **kwargs):
        self.root.render(filename=filename, **kwargs)


class Entity:
    def __init__(self, root, nodes, modifiable):
        self.root = root
        self.nodes = UniqueList(nodes)
        self.belongs_to = None  # points to extension it belongs to
        self._modifiable = modifiable
        self._forbidden = None
        self._lower_parents = None
        self._higher_parents = None
        self.invertible = None
        # self._scaffold = None

    @property
    def id(self):
        return unique_hash(sorted(id(n) for n in self.nodes))

    @property
    def leaves(self):
        for node in self.nodes:
            if node.is_val_node and (not node.options or node.options[0] not in self.nodes):
                yield node

    @property
    def op_nodes(self):
        return set(n for n in self.nodes if not n.is_val_node)

    def extract_intension(self):
        """Copy the object, detaching it from the graph in which it is located and clear values of all value nodes."""
        new_root = self.root.clone(allowed=self.nodes, copy=True)
        for node in new_root.walk():
            if node.is_val_node:
                node.output = node.output.copy(clear_value=True)
        return Intension(new_root)

    @property
    def node(self):
        """Refers to concept it belongs to."""
        return self.belongs_to.belongs_to

    # @property
    # def scaffold(self):
    #     """
    #     The scaffold is a set of entity nodes excluding sub-entity nodes, but including the leaves. The meaning
    #     is that it describes the nodes that actually belong to the entity and to its parts or wholes.
    #     """
    #     if self._scaffold is not None:
    #         return self._scaffold
    #     # TODO: work on proper scaffold computation. This is not quite ripe yet.
    #     self._scaffold = UniqueList(self.nodes)
    #     if self.belongs_to is None:
    #         return self._scaffold
    #     # TODO: make sure that the entity graph is not set up after the scaffold is called, otherwise the caching will
    #     #  lead to the scaffold not being updated when parts are changed
    #     for part in self.node.parts:
    #         sub_entity = part.entity
    #         # scaffold -= set(sub_entity.nodes)
    #         self._scaffold.remove_elements(sub_entity.nodes)
    #         # scaffold.update(sub_entity.leaves)
    #     self._scaffold.extend(self.leaves)
    #     return self._scaffold

    @property
    def modifiable(self):
        return self._modifiable

    @property
    def forbidden(self):
        return self._forbidden

    @property
    def lower_parents(self):
        """Parents of this entity nodes that belong to sub-entities."""
        if self._lower_parents is not None or self.belongs_to is None:
            return self._lower_parents
        lower_nodes = list(chain.from_iterable([part.entity.nodes for part in self.node.parts]))
        self._lower_parents = set()
        for node in self.modifiable:
            if not node.is_val_node:
                continue
            for p in node.parents:
                if p in lower_nodes:
                    self._lower_parents.add(p)
        return self._lower_parents

    @property
    def higher_parents(self):
        """Parents that can not be decoupled, i.e. that do not belong to the entity nodes."""
        if self._higher_parents is not None:
            return self._higher_parents
        # consider all entity value nodes. If they have parents that do not belong to the entity and
        # are neither below nor above the root, forbid them
        self._higher_parents = set()
        for node in self.modifiable:
            if not node.is_val_node:
                continue
            for p in node.parents:
                if p not in self.nodes and not p.is_above([self.root]):
                    self._higher_parents.add(p)
        return self._higher_parents

    def render(self, global_root, filename="entity", **kwargs):
        color = {}
        for node in self.nodes:
            color[node] = '"#ff0000"'  # red
        # for node in self.scaffold:
        #     color[node] = '"#aa00ff"'  # magenta
        for node in self.modifiable:
            color[node] = '"#00aa00"'  # green
        for node in self.forbidden or []:
            color[node] = '"#707070"'  # grey
        print(
            "\nEntity colored in this order: "
            f"{ansi.RED}all nodes {ansi.GREEN}modifiable "
            f"{ansi.LIGHT_BLACK}forbidden{ansi.RESET}"
        )
        global_root.render(color=color, filename=filename, **kwargs)

    def serialize(self):
        d = {
            "root": self.root.nnf,
            "nodes": [n.nnf for n in self.nodes],
            "modifiable": [n.nnf for n in self.modifiable],
        }
        return d


PreEntity = namedtuple("PreEntity", "root nodes leaves_dls")


def collect_pre_entities(graph, elementary=False):
    if elementary:
        root = graph
        children = list(set(root.options[0].children))
        ent = PreEntity(root=root, nodes=[root.options[0]] + children, leaves_dls=[])
        return [ent]

    entities_dict = {}
    for node in graph.nodes:
        _collect_pre_entities(node, entities_dict)

    compressing_entities = [ent for ent in entities_dict.values() if sum(ent.leaves_dls) < ent.root.output_dl()]
    return compressing_entities


def _collect_pre_entities(val_node, entities, trace=()):
    nt = (val_node,) + trace
    if val_node.is_leaf:
        _add_to_trace(entities, val_node, nt)
        return
    _add_to_trace(entities, val_node, nt)
    _add_to_trace(entities, val_node.options[0], nt)
    for child in val_node.options[0].children:
        _collect_pre_entities(child, entities, trace=nt)


def _add_to_trace(entities, node, trace):
    for root in trace:
        if root not in entities:
            entities[root] = PreEntity(root=root, nodes=[], leaves_dls=[])
        ent = entities[root]
        if node in ent.nodes:
            continue
        if not node.is_val_node or node.is_leaf:
            ent.leaves_dls.append(node.output_dl())
        ent.nodes.append(node)


Head = namedtuple("Head", "root op_node children")


def get_modifiable(graph, roots):
    # TODO: should the impermeables be ignored? impermeable means that it should be still modifiable, right?
    impermeable = [n for n in graph.nodes if not n.output.permeable]
    modifiable = defaultdict(UniqueList)
    for node in graph.walk():
        if node in impermeable:
            continue

        if node.is_val_node and node in roots:
            continue
        if not node.is_val_node and node.parent in roots:
            continue
        head = lowest_common_trace_node(node, roots=roots)
        if head is not None:
            modifiable[head].append(node)

    # append root and op node that have been skipped above
    unused = set(roots)
    for head, nodes in modifiable.items():
        if head.root not in impermeable:
            nodes.append(head.root)
        nodes.append(head.op_node)
        unused.discard(head.root)

    # some roots never got to receive a head, fix this here
    for root in unused:
        head = Head(root=root, op_node=root.options[0], children=())
        if head.root not in impermeable:
            modifiable[head].append(head.root)
        modifiable[head].append(root.options[0])
    return modifiable


def lowest_common_trace_node(node, roots=None):
    def intersect(x, y):
        return UniqueList(x).intersection(y)

    list_of_traces = list(node.traces(me_too=False, op_nodes=False))
    common_trace = reduce(intersect, list_of_traces)
    if roots is not None:
        common_trace = UniqueList(common_trace).intersection(roots)
    if not common_trace:
        return None
    root = common_trace[0]
    all_trace_nodes = list(chain.from_iterable(list_of_traces))
    return _entity_head(root, allowed=all_trace_nodes)


def _entity_head(root, allowed=everything):
    """
    Because of variable arity nodes like union, an entity can not be keyed by a root (value node), since more than one
    entity can have the same root. Thus, as a key we take the children of its option, that belong to the traces.
    """
    op_node = root.options[0]
    if op_node.op.arity is not None:
        allowed = everything
    # if not node.is_val_node and node.parent is root:
    #     allowed = everything
    children = tuple(child for child in op_node.children if child in allowed)
    return Head(root=root, op_node=op_node, children=children)


def all_entity_nodes(graph, roots, modifiable):
    """
    Given the entity roots of a graph, compute all nodes belonging to an entity, including nodes of the sub-entities.

    Walk through graph with DFS, maintaining a trace of entity roots encountered along the way. Add the currently
    visited node to all roots above it. When an entity has been traversed, remove it from the trace.
    """
    inv_mod = _invert_dict_list(modifiable)
    heads = list(modifiable.keys())
    has_nodes = defaultdict(list)
    # TODO: walk with traces might be slow
    for node in graph.walk():
        for trace in node.traces(me_too=True):
            _update_entity_nodes(trace, roots, inv_mod, heads, has_nodes)
    return has_nodes


def _invert_dict_list(d):
    inv = defaultdict(list)
    for key, values in d.items():
        for v in values:
            inv[v].append(key)
    return inv


def _update_entity_nodes(trace, roots, inv_mod, heads, has_nodes):
    """
    Example:
    trace = (n0, n1, n2, n3, n4, n5, n6) where n6 is the uppermost node and n0 is the current node.
    inv_mod assigns which roots the node modifies. Hence, for each node in the trace we may have
    modifiables = (n6, n5, n3, n3, n5, n5, n6), where inv_mod[n0]=n6, inv_mod[n1]=n5 etc.,
    where all nodes in mod are entity roots, i.e. contained in <roots>.
    Hence, n3 are bracketed between the n5s and the n5s are bracketed between the n6s.
    Therefore, the current node is part of the roots n6 and n5, but not n3 since its bracket has closed. n5 still
    counts because it is the root right next to n0.
    We get:
    has_nodes[n3] == {n1,...,n3}
    has_nodes[n5] == {n0,...,n5}
    has_nodes[n6] == {n0,...,n6}
    """
    # active_heads maintains a list of heads encountered from top to down, but only those that are "active" hence,
    # have not been "closed" yet. Closing occurs, when a sub-entity has been fully traversed, so that its head is not
    # relevant any more.
    active_heads = []
    for node in trace[::-1]:  # top down walk through trace
        _add_node_to_active_heads(active_heads, node, roots, heads)
        if not active_heads:
            continue
        for head in active_heads:
            if node not in has_nodes[head] and _is_below(node, head):
                has_nodes[head].append(node)

        if node not in inv_mod:
            continue
        # the bracket for all nodes after (all) the mod_heads has closed,
        # update active heads whose bracket is still open
        mod_heads = inv_mod[node]
        indices = [active_heads.index(head) for head in mod_heads if head in active_heads]
        if not indices:
            continue
        active_heads = active_heads[: max(indices) + 1]


def _add_node_to_active_heads(active_heads, node, roots, heads):
    if node not in roots:
        return
    for head in heads:
        if head.root is node and head not in active_heads:
            active_heads.append(head)


def _is_below(node, head):
    if node is head.root:
        return True
    if node is head.op_node:
        return True
    ref_nodes = head.children if head.children else [head.op_node]
    if node.is_below(ref_nodes, include_self=True):
        return True
    return False


def entity_breadth_walk(initial_entity, node_to_entity, corr, additional_nodes=(), external_nodes=()):
    """Breadth-first walk through graph using the entity net.
    nodes are assumed to be from the bush, while entities are defined on the original graph. Hence corr is needed to
    map between them.
    """
    seen_nodes = set([])  # bush nodes
    for leaf in initial_entity.leaves:
        bush_node = corr[leaf]
        yield bush_node, 0
        seen_nodes.add(bush_node)

    for node in external_nodes:
        if not node.is_val_node or node in seen_nodes:
            continue
        yield node, 0
        seen_nodes.add(node)

    additional_entities = set()
    for node in additional_nodes:
        if node in external_nodes or node in seen_nodes:
            continue
        ent = node_to_entity[corr.inv[node]]
        if ent is initial_entity:
            continue
        additional_entities.add(ent)

    seen_entities = {initial_entity}.union(additional_entities)

    queue = [(entity, 0) for entity in additional_entities] + [(initial_entity, 1)]
    while queue:
        entity, distance = queue.pop(0)
        leaves_graph = Graph(list(entity.leaves))
        for org_node in leaves_graph.breadth_first_walk(allowed=entity.modifiable):
            bush_node = corr[org_node]
            if bush_node in seen_nodes or not bush_node.is_val_node:
                continue
            seen_nodes.add(bush_node)
            yield bush_node, distance

        for concept_node in entity.node.neighbors:
            neighbor = concept_node.entity
            if neighbor in seen_entities:
                continue
            seen_entities.add(neighbor)
            queue.append((neighbor, distance + 1))


class NodeCounter:
    def __init__(self):
        self.num = 0
        self._dict = {}

    def __getitem__(self, node):
        return self._dict[node]

    def add(self, node):
        if node in self._dict:
            return
        self._dict[node] = self.num
        self.num += 1


def multiples(
    entity,
    specs,
    max_distance=1e9,
    comb=(),
    dists=(),
    nums=(),
    skip=(),
    allowed=everything,
    node_count=None,
    node_to_entity=None,
    corr=None,
    external_nodes=(),
):
    """
    Yield all node tuples of given <size>, such that the sum of their distances (=path lengths) from given <nodes>
    matches the given <distance>.
    """
    if not specs:
        yield comb, dists, nums
        return
    if node_count is None:
        node_count = NodeCounter()
    num = 0
    d0 = sum(dists)
    for node, d in entity_breadth_walk(
        entity, node_to_entity, corr, additional_nodes=comb, external_nodes=external_nodes
    ):
        if d0 + d > max_distance:
            return
        if node in skip or node not in allowed:
            continue
        node_count.add(node)
        # don't exchange node order, exclude repetitions
        if any([node_count[node] <= node_count[nc] for nc in comb]):
            continue
        # if any([repr(node) <= repr(nc) for nc in comb]):
        #     continue
        if specs[0] is not None and node.output.spec != specs[0]:
            continue
        yield from multiples(
            entity,
            specs[1:],
            max_distance=max_distance,
            comb=comb + (node,),
            dists=dists + (d,),
            nums=nums + (num,),
            skip=skip,
            node_count=node_count,
            node_to_entity=node_to_entity,
            corr=corr,
            external_nodes=external_nodes,
        )
        num += 1
