import json
from itertools import combinations
from pathlib import Path
from typing import Any

from william.legacy.semantics.concepts import ConceptNode, Extension
from william.legacy.semantics.entities import Intension, all_entity_nodes, collect_pre_entities, get_modifiable
from william.legacy.semantics.objects import Entity, Object
from william.legacy.semantics.taxonomy import (
    _delete_overarching_partonomic_links,
    merge_compatible_concept_nodes,
    remove_non_compressing_extensions,
    taxonomy_from_extension,
)
from william.rendering import render, save_graphs
from william.structures.dot_to_graph import DotParser


class ConceptGraph:
    def __init__(self, concept_nodes):
        self.nodes = concept_nodes

    def walk(self, above=True, below=True, to_parts=True, to_wholes=True):
        """Depth-first walk through graph."""
        seen = set()
        for node in self.nodes:
            yield from node.walk(seen=seen, above=above, below=below, to_parts=to_parts, to_wholes=to_wholes)

    def resembles(self, other, **kwargs):
        seen = set()
        if len(self.nodes) != len(other.nodes):
            return False
        for node1, node2 in zip(self.nodes, other.nodes):
            if not node1.resembles(node2, seen=seen, **kwargs):
                return False
        return True

    def render(self, filename="semantic_net", **kwargs):
        render(self.nodes, filename=filename, **kwargs)

    @classmethod
    def load(cls, filename: Path | str, ops=()):
        return cls(SemanticNetParser(ops=ops).parse_file(filename))

    def save(self, filename: Path | str):
        save_graphs(self.nodes, filename)

    def remove_with_parents(self):
        for node in self.nodes[::-1]:
            if node.parents:
                self.nodes.remove(node)

    def update_roots(self):
        roots = []
        for node in self.nodes:
            for root in node.roots():
                if root not in roots:
                    roots.append(root)
        self.nodes = roots

    def find_by_entity(self, entity):
        if entity is None:
            return
        max_common = 0
        best = None
        for node in self.walk():
            ent = node.entity
            common = set(entity.nodes).intersection(ent.nodes)
            if (
                len(common) > max_common
                or best is not None
                and len(common) == max_common
                and len(entity.nodes) < len(best.nodes)
            ):
                max_common = len(common)
                best = ent
        return best

    def node_to_entity_map(self):
        """Map every node in graph to the smallest entity that contains it."""
        node_to_entity = {}
        for concept_node in self.walk():
            ent = concept_node.entity
            for node in ent.nodes:
                existing_entity = node_to_entity.get(node, None)
                if existing_entity is None or len(ent.nodes) < len(existing_entity.nodes):
                    node_to_entity[node] = ent
        return node_to_entity


def build_semantic_net(section, remove_singletons=True):
    ext = Extension(objects=[Object(root, [root]) for root in section.nodes])
    net = ConceptGraph([ConceptNode(extension=ext)])
    taxonomy_from_extension(net.nodes[0], remove_singletons=remove_singletons)
    net = ConceptGraph(remove_non_compressing_extensions(net, check_leaves=True))
    merge_compatible_concept_nodes(net)
    setup_partonomic_relations(net)
    return net


def add_partonomic_relations_to_taxonomies(net):
    nodes = sorted(list(net.walk()), key=lambda node: node.size)
    for i in range(len(nodes) - 1):
        node1 = nodes[i]
        # a node can be a part of several nodes of the equal size, but not of larger ones
        max_size = None
        for j in range(i + 1, len(nodes)):
            node2 = nodes[j]
            if max_size is not None and node2.size > max_size:
                break
            # nodes of the same taxonomy can not be part of each other
            if node2.is_below([node1]):
                continue
            if node1.intension.some_subgraph(node2.intension):
                node2.set_part(node1, reverse=True)
                max_size = node2.size
    net.update_roots()


def setup_partonomic_relations(net, is_part_of=lambda x, y: x.intension.some_subgraph(y.intension)):
    nodes = sorted(list(net.walk()), key=lambda node: node.size)
    _check_all_pairs_and_connect(nodes, is_part_of)
    _delete_overarching_links(nodes)
    net.update_roots()


def _check_all_pairs_and_connect(nodes, is_part_of):
    for node1, node2 in combinations(nodes, 2):
        # nodes of the same taxonomy can not be part of each other
        if node2.is_below([node1], sense="taxonomic"):
            continue
        if is_part_of(node1, node2):
            node2.set_part(node1, reverse=True)


def _delete_overarching_links(nodes):
    for node1, node2 in combinations(nodes, 2):
        _delete_overarching_partonomic_links(node2, node1)


def make_entity_net(graph, singleton=False):
    if singleton:
        net = _make_singleton_net(graph)
        return net
    pre_entities = collect_pre_entities(graph)
    roots = list(ent.root for ent in pre_entities)
    modifiable = get_modifiable(graph, roots)
    has_nodes = all_entity_nodes(graph, roots, modifiable)

    concept_nodes = []
    for head, nodes in has_nodes.items():
        ext = Extension(objects=[Entity(head.root, nodes, modifiable[head])])
        concept_nodes.append(ConceptNode(extension=ext))
    net = ConceptGraph(concept_nodes)

    def is_part_of(node1, node2):
        return set(node1.entity.nodes) < set(node2.entity.nodes)

    setup_partonomic_relations(net, is_part_of=is_part_of)

    # remove own root from modifiables and add the roots of the sub-entities instead
    # impermeable = [n for n in graph.nodes if not n.output.permeable]
    for concept_node in net.walk():
        entity = concept_node.entity
        entity.modifiable.discard(entity.root)
        for part in concept_node.parts:
            # remove nodes of the sub-entity...
            entity.modifiable.remove_elements(part.entity.nodes)
            # ...but keep the root
            entity.modifiable.add(part.entity.root)
            # if root not in impermeable:
            #     entity.modifiable.append(root)
        entity.modifiable.extend([n for n in entity.leaves])  # if n not in impermeable])
    return net


def _make_singleton_net(graph):
    nodes = list(graph.walk())
    # impermeable = [n for n in graph.nodes if not n.output.permeable]
    # modifiable = [n for n in nodes if n not in impermeable]
    modifiable = nodes[:]  # graph.nodes[:]
    ent = Entity(graph.nodes[0], nodes, modifiable)
    ent._lower_parents = set()
    ent._higher_parents = set()
    ent.invertible = []
    c = ConceptNode(extension=Extension(objects=[ent]))
    return ConceptGraph([c])


def smallest_entity_from_net(net):
    nodes = list(net.walk())
    if not nodes:
        return
    min_node = min(net.walk(), key=lambda node: node.size)
    return min_node.entity


class SemanticNetParser(DotParser):
    @staticmethod
    def _make_node(val, is_val_node: bool):
        return val

    def _recognize_value(self, val_str: str, is_json: bool, is_root: bool):
        val_dict = json.loads(val_str)
        lines = val_dict["graph"].split("@$%")[:-1]
        roots = DotParser(ops=self.ops).parse_lines(lines)
        node = ConceptNode(intension=Intension(roots[0]), name=val_dict.get("name", ""))
        return node

    @staticmethod
    def _connect(node_id1: str, node_id2: str, node_dict: dict[str, Any], edge_type: int) -> None:
        node1 = node_dict[node_id1]
        node2 = node_dict[node_id2]
        if edge_type == 1:
            node1.set_child(node2, reverse=True)
        if edge_type == 2:
            node1.set_part(node2, reverse=True)
