from pathlib import Path

import pytest

from william.library import geometry_ops
from william.paths import GRAPHS_PATH
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file


@pytest.fixture(scope="module")
def graphs_path():
    return Path(__file__).parent / "graphs"


@pytest.fixture(scope="session")
def final_house():
    return Graph(parse_dot_file("final_house.dot", ops=geometry_ops))


@pytest.fixture(scope="session")
def final_house2():
    return Graph(parse_dot_file("final_house2.dot", ops=geometry_ops))


@pytest.fixture(scope="session")
def house1():
    return Graph(parse_dot_file(GRAPHS_PATH / "matching/house1.dot", ops=geometry_ops))
