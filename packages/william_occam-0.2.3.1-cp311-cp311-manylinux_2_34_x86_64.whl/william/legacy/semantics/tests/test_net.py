import numpy as np
import pytest

from william.legacy.semantics.entities import entity_breadth_walk
from william.legacy.semantics.net import ConceptGraph, make_entity_net
from william.library import geometry_ops, padd
from william.structures import Node
from william.utils import TwoWayDict


@pytest.fixture(scope="module")
def data(final_house):
    return {"graph": final_house}


def test_make_entity_net(data, graphs_path):
    net = make_entity_net(data["graph"])
    ref = ConceptGraph.load(graphs_path / "entity_net.dot", ops=geometry_ops)
    assert ref.resembles(net)
    data["net"] = net


@pytest.mark.xfail(reason="Hu knows")
def test_entity_breadth_walk(final_house2):
    net = make_entity_net(final_house2)
    node_to_entity = net.node_to_entity_map()
    start_node = final_house2.find([(45.0, 39.0)])[0]
    corr = TwoWayDict(dict((n, n) for n in final_house2.walk()))  # id map
    actual = [
        n.v
        for n, _ in entity_breadth_walk(
            node_to_entity[start_node],
            node_to_entity,
            corr,
            external_nodes=final_house2.permeable_nodes,
        )
    ]
    assert actual == [
        "a[3.0,0.0]\ndl=13.66",
        "a[0.0,3.0]\ndl=13.66",
        "[(45,9),(45,10),..,(45,39)]\ndl=973.21",
        "(45.0,39.0)\ndl=32.37",
        "(45.0,9.0)\ndl=29.36",
        "[(21,9),(21,10),..,(45,39)]\ndl=3392.80",
        "(21.0,9.0)\ndl=27.83",
        "a[24.0,0.0]\ndl=18.07",
        "(21.0,39.0)\ndl=30.84",
        "[(21,39),(22,39),..,(45,39)]\ndl=799.40",
        "[(21,9),(21,10),..,(45,39)]\ndl=23438.41",
        "[(21,9),(21,10),..,(21,39)]\ndl=925.77",
        "[(21,9),(22,9),..,(45,9)]\ndl=724.16",
        "[(a[-50.6246,101.56820000000002,-52.2669],(21,9)),..]\ndl=107129.72",
        "a[-50.6246,101.56820000000002,-52.2669]\ndl=103.99",
        "[(6,24),(7,23),..,(21,39)]\ndl=7363.57",
        "(6.0,24.0)\ndl=27.23",
        "[(a[-47.04333333333334,-47.0925,102.5975],(6,24)),..]\ndl=159331.67",
        "a[-24.0,30.0]\ndl=29.58",
        "a[-47.04333333333334,-47.0925,102.5975]\ndl=171.21",
        "[(21,9),(21,10),..,(21,9)]\ndl=1830.36",
        "[(a[-47.04333333333334,-47.0925,102.5975],(6,24)),..]\ndl=52216.76",
        "dl=390150.35",
        "[(6,24),(7,25),..,(21,39)]\ndl=473.26",
        "[(6,24),(7,23),..,(21,9)]\ndl=449.14",
        "dl=167137.31",
        "dl=144609.64",
    ]
    all_nodes = set([n.v for n in final_house2.walk(op_nodes=False)])
    assert set(actual) == all_nodes

    corr = TwoWayDict()
    bush_graph = final_house2.clone(corr=corr)
    point = bush_graph.find([(45.0, 39.0)])[0]
    vec = bush_graph.find([np.array([3.0, 0.0])])[0]
    node = Node(op=padd, children=[point, vec], output=padd(point.output, vec.output))
    novel = node.parent
    actual2 = [
        n.v
        for n, _ in entity_breadth_walk(
            node_to_entity[corr.inv[point]],
            node_to_entity,
            corr,
            additional_nodes=(novel,),
            external_nodes=[novel] + final_house2.permeable_nodes,
        )
    ]
    assert actual2 == [novel.v] + actual
