import pytest

from william.legacy.semantics.concepts import ConceptNode, Extension
from william.legacy.semantics.net import ConceptGraph
from william.legacy.semantics.objects import Object
from william.legacy.semantics.taxonomy import (
    merge_compatible_concept_nodes,
    remove_non_compressing_extensions,
    taxonomy_from_extension,
)
from william.library import geometry_ops


@pytest.fixture(scope="module")
def data(final_house):
    return {"graph": final_house}


@pytest.mark.parametrize("op_name", ["line", "union", "fill"])
def test_taxonomy(data, op_name, graphs_path):
    graph = data["graph"]
    roots = [n for n in graph.walk(op_nodes=False) if n.options and n.options[0].op.name == op_name]
    ext = Extension(objects=[Object(root, [root]) for root in roots])
    net = ConceptGraph([ConceptNode(extension=ext)])
    taxonomy_from_extension(net.nodes[0], remove_singletons=True)
    # color = dict()
    # for node in net.walk():
    #     # node.render_node(graph)
    #     # st()
    #     if any([obj.has_uncompressed_leaves or not obj.compressing for obj in node.extension.objects]):
    #         color[node] = "\"#dd0000\""
    # net.render(color=color)
    net = ConceptGraph(remove_non_compressing_extensions(net, check_leaves=True))
    merge_compatible_concept_nodes(net)
    filename = f"taxonomy_{op_name}.dot"
    ref = ConceptGraph.load(graphs_path / filename, ops=geometry_ops)
    assert net.resembles(ref)


@pytest.mark.incremental
def test_set_of_taxonomies(data, graphs_path):
    graph = data["graph"]
    roots = [n for n in graph.walk(op_nodes=False) if n.options and n.options[0].op.name in ["line", "union", "fill"]]
    ext = Extension(objects=[Object(root, [root]) for root in roots])
    net = ConceptGraph([ConceptNode(extension=ext)])
    taxonomy_from_extension(net.nodes[0], remove_singletons=True)
    net = ConceptGraph(remove_non_compressing_extensions(net, check_leaves=True))
    merge_compatible_concept_nodes(net)
    ref = ConceptGraph.load(graphs_path / "set_of_taxonomies.dot", ops=geometry_ops)
    assert net.resembles(ref)
    data["net"] = net


# @pytest.mark.incremental
# def test_add_partonomic_relations(data):
#     net = data["net"]
#     # graph = data["graph"]
#     # singular_nodes = value_nodes_to_concept_nodes_by_type(graph)
#     # for node in singular_nodes:
#     #     spec = node.entity.root.output.spec
#     #     for obj in node.extension.objects[1:]:
#     #         assert obj.root.output.spec == spec
#     add_partonomic_relations_to_taxonomies(net)
#     ref = ConceptGraph.load("partonomy.dot", ops=geometry_ops)
#     assert net.resembles(ref)


# @pytest.mark.incremental
# def test_belongs_to(data):
#     net = data["net"]
#     for concept in net.walk():
#         assert concept is concept.extension.belongs_to
#         for obj in concept.extension.objects:
#             assert concept.extension is obj.belongs_to
#             assert concept is obj.node


# def bfs_old(start, max_distance=None):
#     """Breadth-first walk through graph."""
#     seen = {start.entity.id}
#     queue = [start]
#     while queue:
#         item = queue.pop(0)
#         yield item.entity

#         if max_distance is not None and item.distance >= max_distance:
#             continue
#         for new_item in item.generate(seen):
#             queue.append(new_item)


# @pytest.mark.incremental
# def test_entity_net_walk(data):
#     net = data["net"]
#     node = net.nodes[0].children[0].parts[0].parts[0]  # a general line concept
#     entity = node.extension.objects[1]  # a particular line entity
#     expected_ids = [
#         node.extension.objects[1].id,
#         node.children[0].extension.objects[1].id,
#         node.wholes[0].extension.objects[1].id,
#         node.wholes[0].extension.objects[2].id,
#     ]
#     # TODO: make this work with the real breadth first walk (?)
#     ids = [ent.id for ent in bfs_old(CueItem(entity, 0), max_distance=1)]
#     assert expected_ids == ids


# v = lambda x: Value(None, spec=x)
# corners = [v(Point) for _ in range(4)]

# Line
# t = (v(Set[Point]), line, (v(Point), v(Point)))

# Corner
# t = (v(Set[Point]), Union(), ((v(Set[Point]), line, (corners[0], corners[1])),
#                               (v(Set[Point]), line, (corners[1], corners[2]))))

# Triangle
# t = (v(Set[Point]), Union(), (
#     (v(Set[Point]), line, (corners[0], corners[1])),
#     (v(Set[Point]), line, (corners[1], corners[2])),
#     (v(Set[Point]), line, (corners[2], corners[0]))
#     ))

# v1 = v(Array[float])
# v2 = v(Array[float])

# Diff triangle
# t = (v(Set[Point]), Union(), (
#     (v(Set[Point]), line, (corners[0], (corners[1], padd, (corners[0], v1)))),
#     (v(Set[Point]), line, (corners[1], (corners[2], padd, (corners[0], v2)))),
#     (v(Set[Point]), line, (corners[2], corners[0]))
#     ))

# Tetragon
# t = (v(Set[Point]), Union(), (
#     (v(Set[Point]), line, (corners[0], corners[1])),
#     (v(Set[Point]), line, (corners[1], corners[2])),
#     (v(Set[Point]), line, (corners[2], corners[3])),
#     (v(Set[Point]), line, (corners[3], corners[0]))
#     ))
