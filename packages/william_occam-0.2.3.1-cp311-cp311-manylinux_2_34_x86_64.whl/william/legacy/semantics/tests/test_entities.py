from collections import defaultdict
from typing import Any

import numpy as np
import pytest

from william.legacy.semantics.entities import (
    Head,
    _invert_dict_list,
    _update_entity_nodes,
    all_entity_nodes,
    collect_pre_entities,
    get_modifiable,
    lowest_common_trace_node,
)
from william.library import Operator, Union


@pytest.fixture(scope="module")
def data(final_house):
    return {"graph": final_house}


def assert_value_match(value, expected_value, rtol=1e-5) -> None:
    """Assert that graph values are more or less equal to some reference value."""
    if isinstance(value, (np.ndarray, float)):
        np.testing.assert_allclose(value, expected_value, rtol=rtol)
    elif isinstance(expected_value, str) and isinstance(value, Operator):
        assert str(value) == expected_value
    else:
        assert value == expected_value


def assert_value_nodes_match(values: list[Any], expected: list[tuple[Any, float]]) -> None:
    for node, (expected_value, expected_dl) in zip(values, expected):
        value_obj = node.val
        if expected_dl is not None:
            assert_value_match(value_obj.desc_len(), expected_dl, rtol=1e-3)
        assert_value_match(value_obj.value, expected_value)


def test_collect_entities(house1):
    entities = collect_pre_entities(house1)
    expected = [1536.34, 10062.29, 2333.11, 233.58, 0.97, 0.5, 2110.35, 1261.85, 893.12]
    assert len(entities) == len(expected)
    for v1, v2 in zip(entities, expected):
        assert round(v1.root.output_dl() - sum(v1.leaves_dls), 2) == v2


# fmt: off
_long_test_set = {
    (42, 39), (21, 16), (45, 13), (21, 13), (45, 10), (26, 39), (37, 9), (21, 22), (24, 39), (45, 19), (35, 39),
    (21, 31), (30, 9), (45, 28), (41, 9), (45, 37), (21, 37), (45, 34), (37, 39), (21, 9), (32, 39), (30, 39),
    (43, 39), (21, 15), (45, 12), (36, 9), (21, 24), (45, 21), (21, 33), (45, 30), (45, 27), (21, 39), (45, 36),
    (38, 9), (27, 39), (31, 9), (21, 17), (45, 14), (21, 26), (45, 23), (38, 39), (21, 35), (45, 20), (45, 32),
    (21, 32), (45, 29), (33, 9), (22, 39), (44, 9), (45, 38), (26, 9), (21, 10), (33, 39), (44, 39), (21, 19),
    (45, 16), (21, 28), (28, 9), (45, 25), (39, 39), (21, 25), (45, 22), (21, 34), (45, 31), (32, 9), (43, 9),
    (41, 39), (28, 39), (21, 12), (23, 9), (34, 9), (45, 9), (21, 21), (45, 18), (21, 18), (21, 30), (45, 15),
    (27, 9), (21, 27), (45, 24), (21, 36), (45, 33), (25, 9), (36, 39), (23, 39), (34, 39), (45, 39), (29, 9),
    (40, 9), (21, 14), (22, 9), (21, 11), (45, 11), (21, 23), (25, 39), (21, 20), (45, 17), (21, 29), (42, 9),
    (31, 39), (45, 26), (21, 38), (29, 39), (40, 39), (45, 35), (24, 9), (35, 9), (39, 9)
}
# fmt: on


_big_test_arr = np.array(
    [
        [245.22, 131.68, 67.48],
        [284.58, 119.51, 109.37],
        [253.73, 80.4, 77.18],
        [233.69, 107.61, 94.62],
        [271.59, 73.51, 93.2],
        [218.88, 113.81, 78.8],
        [247.08, 107.6, 81.96],
        [281.28, 71.72, 130.97],
        [235.54, 115.4, 73.17],
        [252.71, 127.61, 90.67],
        [242.49, 101.83, 134.43],
        [266.69, 64.18, 108.66],
        [271.87, 110.06, 141.9],
        [252.9, 106.24, 108.36],
        [272.23, 104.55, 89.78],
        [242.82, 125.35, 110.07],
        [256.71, 118.11, 62.18],
        [279.8, 83.17, 131.58],
        [247.88, 130.83, 99.47],
        [255.16, 98.47, 113.23],
        [251.88, 107.77, 102.77],
        [212.2, 82.34, 138.9],
        [278.04, 105.38, 154.47],
        [242.6, 127.15, 123.82],
        [270.95, 110.0, 88.54],
        [256.19, 99.37, 92.91],
        [275.9, 119.25, 98.43],
        [261.71, 107.15, 56.07],
        [276.18, 83.85, 70.46],
        [280.41, 131.08, 97.11],
        [241.76, 105.61, 93.82],
        [249.96, 96.12, 121.46],
        [245.72, 88.78, 110.23],
        [236.94, 84.78, 74.34],
        [262.06, 102.31, 76.66],
        [262.24, 82.17, 112.54],
        [254.63, 99.66, 113.13],
        [249.68, 128.04, 98.87],
        [267.95, 103.48, 81.91],
        [202.09, 114.53, 57.81],
        [285.98, 129.07, 86.82],
        [282.86, 96.53, 79.82],
        [248.4, 122.3, 134.83],
        [297.89, 115.17, 132.28],
        [262.61, 120.75, 120.67],
        [272.55, 109.46, 109.16],
        [248.04, 113.57, 85.13],
        [250.52, 118.84, 77.47],
        [223.82, 108.26, 49.86],
        [272.68, 114.52, 118.75],
    ]
)

_test_params = [
    ((45, 9), _long_test_set, 3272.34),
    ((21, 9), _big_test_arr, 110777.09),
]


@pytest.mark.parametrize(["value", "expected_value", "expected_dl"], _test_params)
def test_lowest_common_trace_node(final_house, value, expected_value, expected_dl):
    vn = final_house.find([value])[0]
    value_obj = lowest_common_trace_node(vn).root.val
    assert_value_match(value_obj.desc_len(), expected_dl)
    value = value_obj.value
    if isinstance(value, np.ndarray) and len(value) and value[0].size > 50:
        # for big arrays, only compare the first element
        value = value[0]
    assert_value_match(value, expected_value)


@pytest.mark.incremental
def test_get_modifiable(data):
    graph = data["graph"]
    entities = collect_pre_entities(graph)
    roots = list(ent.root for ent in entities)
    modifiable = get_modifiable(graph, roots)
    root = graph.find([Union()])[0].parent
    head = Head(root=root, op_node=root.options[0], children=tuple(root.ch[:1] + root.ch[2:]))

    expected = [
        ((45, 9), 29.36),
        ("padd", None),
        (np.array([24, 0]), 18.07),
        ("add", None),
        (np.array([-6, 0]), 15.17),
        (np.array([30, 0]), 18.52),
        ("rotate", None),
        (0.25, 18.93),
        (_long_test_set, 3272.34),
        ("union", None),
    ]

    assert_value_nodes_match(modifiable[head], expected)
    # for incremental use
    data.update(entities=entities, roots=roots, modifiable=modifiable)


@pytest.mark.incremental
def test_update_entity_nodes(data):
    node = data["graph"].find([np.array([0, 30])])[0]
    trace = list(node.traces())[0]

    expected = [
        "a[0,30]\ndl=18.52",
        "padd",
        "(21,39)\ndl=30.84",
        "line",
        "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
        "union",
        "{(21,9),(21,10),..,(45,39)}\ndl=3272.34",
        "fill",
        "{(21,9),(21,10),..,(45,39)}\ndl=23438.41",
        "compose",
        "dl=96388.60",
        "compose",
        "dl=110777.09",
    ]

    assert [t.v for t in trace] == expected

    inv_mod = _invert_dict_list(data["modifiable"])
    heads = list(data["modifiable"].keys())
    has_nodes = defaultdict(list)
    _update_entity_nodes(trace, data["roots"], inv_mod, heads, has_nodes)

    expected = {
        "dl=110777.09": [
            "dl=110777.09",
            "compose",
            "dl=96388.60",
            "compose",
            "{(21,9),(21,10),..,(45,39)}\ndl=23438.41",
            "fill",
            "{(21,9),(21,10),..,(45,39)}\ndl=3272.34",
            "union",
            "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
            "line",
            "(21,39)\ndl=30.84",
            "padd",
            "a[0,30]\ndl=18.52",
        ],
        "dl=96388.60": [
            "dl=96388.60",
            "compose",
            "{(21,9),(21,10),..,(45,39)}\ndl=23438.41",
            "fill",
            "{(21,9),(21,10),..,(45,39)}\ndl=3272.34",
            "union",
            "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
            "line",
            "(21,39)\ndl=30.84",
        ],
        "{(21,9),(21,10),..,(45,39)}\ndl=23438.41": [
            "{(21,9),(21,10),..,(45,39)}\ndl=23438.41",
            "fill",
            "{(21,9),(21,10),..,(45,39)}\ndl=3272.34",
            "union",
            "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
            "line",
            "(21,39)\ndl=30.84",
        ],
        "{(21,9),(21,10),..,(45,39)}\ndl=3272.34": [
            "{(21,9),(21,10),..,(45,39)}\ndl=3272.34",
            "union",
            "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
            "line",
            "(21,39)\ndl=30.84",
        ],
        "{(21,39),(22,39),..,(45,39)}\ndl=799.40": [
            "{(21,39),(22,39),..,(45,39)}\ndl=799.40",
            "line",
            "(21,39)\ndl=30.84",
        ],
    }
    for head, nodes in has_nodes.items():
        actual = [n.v for n in nodes]
        assert actual == expected[head.root.v]


@pytest.mark.incremental
def test_all_entity_nodes(data):
    graph = data["graph"]
    modifiable = data["modifiable"]
    has_nodes = all_entity_nodes(graph, data["roots"], modifiable)
    root = graph.find_by_str("{(6,24),(7,23),..,(21,39)}\ndl=1744.37")[0]
    inv_mod = _invert_dict_list(modifiable)

    # fmt: off
    test_sets = [
        {
            (21, 10), (7, 23), (21, 16), (21, 13), (21, 19), (6, 24), (15, 33), (21, 22), (21, 28), (14, 16), (21, 25), (21, 31),
            (21, 34), (20, 38), (21, 37), (19, 37), (13, 17), (11, 29), (21, 9), (21, 12), (20, 10), (21, 15), (21, 21), (7, 25),
            (16, 34), (21, 18), (21, 24), (21, 30), (12, 18), (21, 27), (12, 30), (19, 11), (21, 33), (21, 36), (21, 39), (11, 19),
            (8, 26), (17, 35), (10, 20), (18, 12), (13, 31), (21, 14), (21, 11), (21, 17), (21, 23), (21, 20), (21, 26), (18, 36),
            (21, 29), (21, 35), (21, 32), (17, 13), (21, 38), (14, 32), (9, 21), (8, 22), (9, 27), (16, 14), (10, 28), (15, 15)
        },
        {
            (21, 39), (6, 24), (15, 33), (8, 26), (17, 35), (10, 28), (20, 38), (13, 31), (18, 36), (11, 29),
            (14, 32), (7, 25), (16, 34), (9, 27), (19, 37), (12, 30)
        },
        {
            (7, 23), (6, 24), (11, 19), (14, 16), (10, 20), (18, 12), (13, 17), (21, 9), (17, 13), (20, 10), (9, 21), (8, 22),
            (16, 14), (12, 18), (19, 11), (15, 15)
         }
    ]
    # fmt: on

    expected = [
        (test_sets[0], 1744.37),
        ("union", None),
        ((21, 39), 30.84),
        (test_sets[1], 473.26),
        ("line", None),
        ((21, 9), 27.83),
        (test_sets[2], 449.14),
        ("line", None),
        ((6, 24), 27.23),
    ]

    assert_value_nodes_match(has_nodes[inv_mod[root][0]], expected)

    # assert [n.v for n in modifiable[root]] == ['union', '{(21,10),(7,23),..,(15,15)}\ndl=1744.37', '(6,24)\ndl=27.23']
    # append_sub_entity_roots_to_modifiable(modifiable, has_nodes)
    # assert [n.v for n in modifiable[root]] == [
    #     'union', '{(21,10),(7,23),..,(15,15)}\ndl=1744.37', '(6,24)\ndl=27.23',
    #     '{(21,36),(21,10),..,(21,33)}\ndl=925.77', '{(21,39),(6,24),..,(12,30)}\ndl=473.26',
    #     '{(7,23),(6,24),..,(15,15)}\ndl=449.14'
    # ]
