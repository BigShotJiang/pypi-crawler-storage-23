import json
import logging
from dataclasses import dataclass
from functools import total_ordering
from pathlib import Path

from william.conditions import get_conditions_py
from william.legacy.condcomb_propagation import CondCombPropagation
from william.legacy.evaluation.decouple import ways_to_decouple
from william.legacy.semantics.entities import Entity, multiples
from william.nvmap import MapEntry, NodeValueMap
from william.paths import GRAPHS_PATH
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file
from william.utils import TwoWayDict, ansi, everything, get_path, stop

logger = logging.getLogger("bush")


@total_ordering
@dataclass(slots=True)
class Bush:
    """
    Bush is an item that gets passed around during induction. It handles the attachment and replacement processes.
    In <section> it carries around a copy of the original graph and <corr> and <inv_corr> save the mapping which node
    in the original graph correspond to its copy in the bush and vice versa.
    <novel> is a set of nodes created beyond the original graph.
    <roots> are the uppermost nodes of this creation (unless there is attachment from below).
    """

    section: Graph
    hash: int = 0
    entity: Entity = None
    node_to_entity: dict = None
    novel: set = ()  # new nodes in bush that do not exist in the original graph
    removed: set = ()  # nodes from original graph marked for removal
    roots: list = ()
    corr: TwoWayDict = None
    dl: float = 0
    direction: int = 0  # bush grows upward (+1) or downward (-1)?
    proliferate: bool = True
    first: bool = False

    def __lt__(self, other):
        return self.dl < other.dl

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return False
        return self.dl == other.dl

    @classmethod
    def from_entity(cls, entity, node_to_entity, target, dl=0):
        """The source node defines the starting point for the proliferation."""
        # cond_nodes = conditioned_nodes(entity.root)
        permeable = target.permeable_nodes
        section = Graph(list(entity.leaves), prediction=target._prediction).union(permeable, copy=False)
        corr = TwoWayDict()
        # allowed = entity.nodes + permeable
        new_section = section.clone(corr=corr)  # allowed=allowed)
        # corr.crop(allowed)
        return cls(
            new_section,
            hash=hash(new_section),
            entity=entity,
            node_to_entity=node_to_entity,
            novel=set(),
            removed=set(),
            roots=[],
            corr=corr,
            dl=dl,
            first=True,
        )

    def copy(self):
        # TODO: This should only return a copied bush and not other things.
        #       If this other stuff is necessary, it might be cached and fetched
        #       with a separate method. Otherwise, at least should be renamed to
        #       state, that it's not just returning a simple copy.
        new_section, org_to_new, self_to_new, hashes = self.maps_and_hashes()
        bush = Bush(
            new_section,
            hash=hash(new_section),
            entity=self.entity,
            node_to_entity=self.node_to_entity,
            novel=set(self_to_new[node] for node in self.novel),
            removed=self.removed.copy(),
            roots=[self_to_new[node] for node in self.roots],
            corr=org_to_new,
        )
        return bush, self_to_new, hashes

    def maps_and_hashes(self):
        self_to_new = {}
        hash_dict = {}
        new_section = self.section.clone(corr=self_to_new, hash_dict=hash_dict)
        org_to_new = self.corr.add(self_to_new)
        return new_section, org_to_new, self_to_new, set(hash_dict.keys())

    def __hash__(self):
        return self.hash

    @property
    def replacing_node(self):
        if len(self.roots) != 1:
            raise ValueError("There has to be exactly one root in order for the replacing node to be well-defined")
        return self.roots[0]

    def inferred_nodes(self):
        if self.entity is None:
            return
        num = 0
        for leaf in self.entity.root.leaves():
            if leaf in self.section.nodes:  # assuming section nodes are cond nodes or target nodes
                continue
            yield leaf, num
            num += 1

    def node_combinations(self, specs, skip=()):
        for val_nodes, _, nums in multiples(
            self.entity,
            specs,
            max_distance=10,
            skip=skip,
            node_to_entity=self.node_to_entity,
            corr=self.corr,
            external_nodes=self._nodes_outside_entity,
        ):
            yield val_nodes, nums

    @property
    def _nodes_outside_entity(self):
        """nodes that do not belong to the current entity (novel nodes or disconnected nodes from the section)"""
        outsiders = []
        for node in self.section.nodes + list(self.novel):
            if node not in self.corr.inv or self.corr.inv[node] not in self.entity.nodes and node not in outsiders:
                outsiders.append(node)
        return outsiders

    @property
    def yield_able(self):
        return len(self.roots) == 1

    def is_decompressing(self, skip=()):
        skip = [self.corr[n] for n in skip if n in self.corr]
        return self.replacing_node.leaves_dl(seen=set(skip), op_nodes=True) < self.replacing_node.output_dl()

    def render(self, filename="bush", condition=True):
        if not condition:
            return
        self.section.render(color=self.color, filename=filename)

    def r(self, filename="bush", condition=True):
        if not condition:
            return
        self.replacing_node.render(color=self.color, filename=filename)

    @property
    def color(self):
        color = {}
        for vn in self.novel:
            color[vn] = '"#ff9900"'
        for vn in self.roots:
            color[vn] = '"#00bb00"'
        return color

    def __str__(self):
        return f"dl={self.dl}\n{str(self.roots[0].output) if self.yield_able else 'None'}"

    def save(self, filename: Path | str, origin):
        # Note: origin has to be saved together with the bush, always. Only that guarantees that the node IDs in the
        # respective dot files will match
        fpath = get_path(filename, root=GRAPHS_PATH, suffix=".dot")
        name = fpath.stem
        origin.save(fpath)
        data = {
            "section": name + "_bush.dot",
            "hash": self.hash,
            "entity": self.entity.serialize() if self.entity else None,
            "novel": [n.nnf for n in self.novel],
            "removed": [n.nnf for n in self.removed],
            "roots": [n.nnf for n in self.roots],
            "corr": dict((n1.nnf, n2.nnf) for n1, n2 in self.corr.items()),
            "dl": self.dl,
            "direction": self.direction,
            "proliferate": self.proliferate,
            "first": self.first,
        }
        self.section.save(fpath.parent / data["section"])
        fpath.with_suffix(".json").write_text(json.dumps(data))

    @classmethod
    def load(cls, filename: Path | str, ops=(), prediction=False):
        fpath = get_path(filename, root=GRAPHS_PATH, suffix=".dot")
        org = {}
        origin = Graph(parse_dot_file(fpath, ops=ops, node_dict=org), prediction=prediction)
        des = {}
        destination = Graph(parse_dot_file(fpath.parent / f"{fpath.stem}_bush.dot", ops=ops, node_dict=des))
        data = json.loads(fpath.with_suffix(".json").read_text())
        ent = data["entity"]
        if ent is None:
            entity = None
        else:
            entity = Entity(
                org[ent["root"]],
                [org[n] for n in ent["nodes"]],
                [org[n] for n in ent["modifiable"]],
            )
        corr = TwoWayDict()
        for n1, n2 in data["corr"].items():
            corr[org[n1]] = des[n2]
        bush = cls(
            destination,
            hash=data["hash"],
            entity=entity,
            novel=set([des[n] for n in data["novel"]]),
            removed=set([des[n] for n in data["removed"]]),
            roots=[des[n] for n in data["roots"]],
            corr=corr,
            dl=data["dl"],
            direction=data["direction"],
            proliferate=data["proliferate"],
            first=data["first"],
        )
        return bush, origin

    def prop(self, target, decoupled, replace_params, bush_imp_in_cycle=(), level=0):
        mem1, below_replacing = _prepare_mem(self.replacing_node, decoupled, forbidden=())
        invertible = _update_invertible(self.entity, target)
        for replaced in self._loop_modifiable(self.replacing_node, mem1, below_replacing, replace_params, level=level):
            stop(level, threshold=7)
            for comb in ways_to_decouple(
                replaced,
                decoupled,
                lower=self.entity.lower_parents,
                higher=self.entity.higher_parents,
                new_replacing=self.replacing_node not in self.corr.inv,
            ):
                if level >= 4:
                    print(f"{ansi.YELLOW}{comb}{ansi.RESET}", end="")
                # has to be initiated here, since ways_to_decouple ultimately changes the target graph
                pr = CondCombPropagation(use_existing=True, partial=False, unique=True)
                mem2 = _init_mem(
                    target,
                    decoupled,
                    self.replacing_node,
                    self.corr.inv,
                    bush_imp_in_cycle=bush_imp_in_cycle,
                    mem=mem1,
                )
                for mem3 in pr.propagate(target, mem2, invertible=invertible):
                    yield mem3, replaced, comb
                if level >= 4:
                    print("")

    def _loop_modifiable(self, replacing, mem, below_replacing, replace_params, level=0):
        value = replacing.output
        # var_arity_root = len(replacing.options) > 0 and replacing.options[0].op.arity is None
        for replaced in self.entity.modifiable:
            if not replaced.is_val_node:
                continue
            if value.spec != replaced.output.spec:
                continue
            neighbors = list(replaced.neighbors())
            if neighbors and all([n in mem for n in neighbors]):
                continue
            # if there are no novel nodes right above the (corr of the) replaced node, it means that the downward
            # replacement goes far down, even below the novel nodes created by this bush. Hence there will be many new
            # nodes created after apply bush. Forbid this in order to keep the graph size low.
            # bush_replaced = self.corr[replaced]
            # if var_arity_root and bush_replaced in below_replacing:
            #    # and not self.novel.intersection(bush_replaced.parents):
            #    continue
            if (
                replace_params.get("replace_only_below_prediction_node", False)
                and self.section.prediction_node is not None
                and not self.corr[replaced].is_below([self.section.prediction_node], include_self=True)
            ):
                continue
            if level >= 4:
                print(ansi.YELLOW)
                print(f"Old value: {replaced.output}")
                print(f"New value: {value}{ansi.RESET}")
            yield replaced


def _prepare_mem(replacing, decoupled, forbidden=()):
    mem1 = NodeValueMap.from_nodes(forbidden)
    mem1[decoupled] = MapEntry(same=False, val=decoupled.output)

    # Do not propagate through the bush
    below_replacing = list(replacing.walk(include_self=False, above=False))
    for node in [replacing] + below_replacing:
        mem1[node] = MapEntry(same=True, val=node.val)
    return mem1, below_replacing


def _update_invertible(entity, target):
    if entity.invertible is everything:
        return entity.invertible
    invertible = entity.invertible[:] if entity.invertible is not None else entity.modifiable[:]
    op_nodes_below_impermeable = [n.options[0] for n in target.nodes if n.options and not n.output.permeable]
    invertible.extend(op_nodes_below_impermeable)
    return invertible


def _init_mem(target, decoupled, replacing, inv_corr, bush_imp_in_cycle=(), mem=None):
    mem1 = NodeValueMap() if mem is None else mem.copy()

    # don't propagate through impermeables
    for node in target.nodes:
        if node.output.permeable:
            continue
        mem1[node] = MapEntry(same=True, val=node.output)

    # Do not propagate into the original nodes which helped to compute the replacing node
    # replacing.walk(above=False, seen=set(bush_imp_in_cycle)):
    below_replacing = [replacing]
    if replacing.options:
        below_replacing.extend(list(replacing.options[0].walk(above=False, seen=set(bush_imp_in_cycle))))
    for node in below_replacing:
        if node not in inv_corr:
            continue
        org_node = inv_corr[node]
        # don't block propagation above the decoupled node, since it has to be able to propagate upward
        if org_node.is_above([decoupled]):
            continue
        mem1[org_node] = MapEntry(same=True, val=org_node.val)

    return mem1


def conditioned_nodes(root):
    if root.output.permeable:
        return list(root.leaves())
    cond = get_conditions_py(root)[0]
    if cond == ():
        return [root]
    return [leaf for i, leaf in enumerate(root.leaves()) if i in cond]
