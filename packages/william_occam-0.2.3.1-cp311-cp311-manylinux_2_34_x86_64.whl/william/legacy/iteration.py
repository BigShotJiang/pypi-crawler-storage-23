import time
from functools import cached_property
from itertools import count, islice
from math import inf

from william.legacy.evaluation import attach_or_replace
from william.legacy.evaluation.attach_replace import _flush
from william.legacy.objective_function import ObjectiveFunction, ThresholdState
from william.legacy.params import complete_params, default_params
from william.legacy.proliferation.proliferate_sp import proliferate
from william.legacy.semantics.concepts import breadth_first_walk
from william.legacy.semantics.net import make_entity_net
from william.library.functions import sign
from william.library.hashing import unique_hash
from william.paths import TMP_PATH
from william.utils import ansi, debugger, stop
from william.utils.helpers import heat_map, memory_usage, seen_already, set_trace_up

try:
    from graphviz import Digraph
except ModuleNotFoundError:
    Digraph = None

arrow_dict = {
    -1: ansi.YELLOW + "\u2193" + ansi.RESET,  # arrow down
    0: "",
    +1: ansi.RED + "\u2191" + ansi.RESET,  # arrow up
}


def iterate(
    target,
    graph_elements,
    obj_fun=None,
    entity_root=None,
    params=default_params,
    steps_per_entity=1000,
    stop_when_no_better=False,
    max_op_nodes=None,
    name="",
    rng=(0, None),
    level=0,
    save=False,
    render=True,
    max_time=None,
    max_memory=None,  # in megabytes
    logger=None,  # logger used for debug output
):
    """
    Debugging levels:
    0 = do not stop and do not print anything
    1 = do not stop and print only the compression rate after each successful iteration step
    2 = minimal output during iteration step (display dots during heap search)
    3 = stop after each successful iteration step and render resulting graph, including the graph before
    4 = print bush information, decoupling comb and old and new values during replacement
    5 = stop right after success before insert mem
    6 = debug evaluation and finalization: stop before attach/replace
    7 = display entity net, stop before ways_to_decouple
    8
    9
    10 = maximum debugging, halt at every bush, at every step of the dl-estimation
    """
    print_func = logger.info if logger else print
    obj_fun = obj_fun or ObjectiveFunction()
    end_time = None if max_time is None else time.time() + max_time

    prl_params, replace_params = complete_params(params)
    root = SearchNode(target, obj_fun, graph_elements, prl_params, entity_root=entity_root, level=level)
    root.r(condition=level >= 3 and render)
    root.r(filename="before", condition=level >= 3 and render)
    hash_dict = {hash(root): root}
    last_node = None

    print_func(obj_fun.status_report(root))
    stop(level, threshold=3)
    stop_num = 1000
    for num in count(start=rng[0]) if rng[1] is None else range(rng[0], rng[1]):
        # pick a search node randomly according to weight distribution
        search_node = root.pick(greedy=False)
        # in order to release the memory of all the bushes in the proliferators
        # do not do this when backtracking is enabled. There is no going back after flushing!
        root.flush(skip=(search_node,))

        arrow = ""
        if last_node is not None:
            arrow = arrow_dict[sign(search_node.degrees_of_freedom - last_node.degrees_of_freedom)]
        memory = memory_usage()
        tm = "" if max_time is None else f"  time left: {(end_time - time.time()) / 60: .2f}min"
        debugger(
            level,
            {1: ansi.GREEN + f"Iteration: {num}  memory: {memory:.2f} MB" + tm + f"  {arrow}"},
            logger=logger,
        )
        if max_memory is not None and memory > max_memory:
            debugger(level, {1: f"Max memory {max_memory} MB reached."}, logger=logger)
            break

        # various prints and renders
        search_node.r(condition=render)
        if search_node.parents:
            search_node.parents[0].r(filename="before", condition=level >= 3 and render)

        # break if nothing better found, unless no improvement has been found at all yet
        if stop_when_no_better and search_node is last_node and root.children:
            debugger(level, {1: "No improvement found."}, logger=logger)
            break
        if end_time is not None and time.time() >= end_time:
            debugger(level, {1: f"Max time {max_time} seconds reached."}, logger=logger)
            break

        if (num % stop_num == 0 or search_node is not last_node) and level >= 3:
            set_trace_up()
        last_node = search_node

        bush_count = search_node.bush_count
        for improved_dl, new_target, new_entity_root in search_node.proliferate(
            obj_fun,
            steps_per_entity,
            replace_params,
            max_op_nodes=max_op_nodes,
            level=level,
        ):
            child = hash_dict.get(hash(new_target), None)
            if child is None or child.is_above([search_node]):
                child = SearchNode(
                    new_target,
                    obj_fun,
                    graph_elements,
                    prl_params,
                    entity_root=new_entity_root,
                    dl=improved_dl,
                    level=level,
                )
                hash_dict[hash(new_target)] = child
            search_node.add_child(child, num=0)

            # more prints and renders
            print_func(obj_fun.status_report(child))
            new_target.render(condition=level >= 2 and render)
            # root.render(active_node=search_node, condition=render)
            stop(level, threshold=3)
            t_state = obj_fun.threshold_state(child)
            if t_state in (ThresholdState.REACHED, ThresholdState.MAX_GRAPH_SIZE_REACHED):
                msg = "Threshold reached" if t_state == ThresholdState.REACHED else "Maximum graph size reached."
                debugger(level, {1: msg}, logger=logger)
                return new_target
            if save:
                new_target.save(TMP_PATH / f"{name}/{name}{num + 1:03}.dot")
        if search_node.bush_count == bush_count:
            debugger(level, {1: "Proliferation exhausted."}, logger=logger)
            break
    if rng[1] is not None and num >= rng[1] - 1:
        debugger(level, {1: "Maximum number of iterations reached."}, logger=logger)
    return root.greedy_pick().graph  # return the best solution found


class SearchNode:
    def __init__(self, graph, obj_fun, graph_elements, params, parents=(), entity_root=None, dl=None, level=0):
        self.graph = graph
        self._org_graph = graph.clone()

        self.epm = EntitiesProliferationManager(graph, graph_elements, entity_root, params, level=level)

        self.parents = list(parents)
        self.children = []
        self.bush_count = 0
        # self.model_size = self.graph.model_size
        # self.degrees_of_freedom, self.belly = degrees_of_freedom(graph, return_belly=True)
        self.degrees_of_freedom = len(list(graph.walk(op_nodes=False)))

        self.fitness = obj_fun.evaluate(graph)
        assert obj_fun.check_dl(dl, self.fitness, level=level)
        self.num_op_nodes = obj_fun.size(graph)
        self.better = obj_fun.better

    def __hash__(self):
        return unique_hash(self._org_graph)

    def add_child(self, node, num=None):
        if self not in node.parents:
            node.parents.append(self)
        if num is not None and num < len(self.children):
            self.children[num] = node
        elif node not in self.children:
            self.children.append(node)

    def is_above(self, other_nodes):
        if self in other_nodes:
            return True
        for child in self.children:
            if child.is_above(other_nodes):
                return True
        return False

    @property
    def progress(self):
        f0 = self.initial_fitness
        return 100 * (f0 - self.fitness) / f0

    @property
    def initial_fitness(self):
        if not self.parents:
            return self.fitness
        return self.parents[0].initial_fitness

    @property
    def fitness_trace(self, trace=()):
        trace = (self.fitness,) + trace
        if not self.parents:
            return trace
        return self.parents[0].fitness_trace(trace=trace)

    def proliferate(self, obj_fun, steps_per_entity, replace_params, max_op_nodes=None, level=0):
        threshold = self.fitness
        for source_entity, bush, bush_count in self.epm.generate(steps_per_entity):
            found = False
            gen, values = attach_or_replace(bush, self.graph, replace_params, level=level)
            for mem, replaced, dec in gen:
                self.bush_count = bush_count
                # force him to improve on its best child
                # if self.children:
                #     threshold = min(threshold, *[c.fitness for c in self.children])
                new_dl = obj_fun.improved(self.graph, threshold, dec=dec, mem=mem)
                if new_dl is None:
                    _flush(values)
                    continue
                new_graph, copy_corr = self.graph.insert_mem(mem, copy=True)
                new_entity_root = get_new_entity_root(self.epm.initial_entity.root, dec, copy_corr)

                # maximum graph size allowed
                if max_op_nodes is not None and len(list(new_graph.walk(val_nodes=False))) > max_op_nodes:
                    debugger(level, {4: ansi.RED + "\nMax op nodes trespassed, skipping..." + ansi.RESET})
                    continue
                # every new child must not increase the degrees of freedom of the previous children
                new_dof = new_graph.degrees_of_freedom
                if new_dof == 0:
                    continue
                # Pass, if for all children the "<" sign holds:
                # 1. If the DOFs are equal, pass if new_dl is strictly smaller than that of previous children.
                # 2. If the DOF is smaller than any child's DOF, pass irrespectively of the fitness.
                # 3. If the DOF is larger than some child's DOF, do not pass.
                if self.not_improved(new_dof, new_dl, obj_fun.better):
                    debugger(level, {4: ansi.RED + "\nDOF criterion violated, skipping..." + ansi.RESET})
                    continue
                if seen_already(new_graph, obj_fun.seen):
                    debugger(level, {4: ansi.RED + "\nGraph seen already, skipping..." + ansi.RESET})
                    continue
                obj_fun.accept_solution(self.graph, mem)
                found = True

                # print(f"\nSelf: dof={self.degrees_of_freedom},  dl={self.fitness:.2f}")
                # print("Children:", [(c.degrees_of_freedom, f"{c.fitness:.2f}") for c in self.children])
                # print(f"New: dof={new_dof},  dl={new_dl:.2f}")
                # print(f"Bush count: {bush_count}")
                # print(f"New entity root: {new_entity_root.v}")

                # new_graph.truncate_superfluous_branches()
                # others = new_graph.nodes[1:]
                # shuffle(others)
                # new_graph = Graph(new_graph.nodes[:1] + others, prediction=new_graph._prediction)
                yield new_dl, new_graph, new_entity_root
            if found:
                self.epm.made_progress = True
        if level >= 2:
            print("\n")

    def not_improved(self, new_dof, new_dl, better_func):
        for c in self.children:
            if new_dof > c.degrees_of_freedom:
                return True
            if new_dof == c.degrees_of_freedom and not better_func(new_dl, c.fitness):
                return True
        return False

    def flush(self, skip=()):
        for search_node in self.walk():
            if search_node in skip:
                continue
            search_node.epm.flush()

    def greedy_pick(self):
        """Walk through the tree below and pick a node randomly from the weight distribution."""
        best = self
        best_fitness = self.fitness
        for child in self.children:
            if self.better(child.fitness, best_fitness):
                best = child
                best_fitness = child.fitness
        return self if best is self else best.greedy_pick()

    @cached_property
    def root(self):
        if not self.parents:
            return self
        return self.parents[0].root

    def walk(self, seen=None):
        if seen is None:
            seen = set()
        if self in seen:
            return
        yield self
        seen.add(self)
        for child in self.children:
            yield from child.walk(seen=seen)

    def pick(self, greedy=False):
        if greedy:
            return self.greedy_pick()
        best_node, _ = max([(c, c.weight) for c in self.walk()], key=lambda x: x[1])
        return best_node

    @property
    def weight(self):
        gain = self.degrees_of_freedom - self.root.degrees_of_freedom
        if self.epm.made_progress:
            return -inf
        # if self.bush_count >= self.MAX_BUSH_COUNT and self.children:
        #     return -inf
        return -gain

    def __str__(self):
        s = ""
        # dl = self._org_graph.leaves_dl(op_nodes=True)
        s += f"f: {self.fitness:.2f}\n"
        s += f"dof={self.degrees_of_freedom}   B: {self.bush_count}\n"
        s += f"W: {self.weight:.2f}\n"
        return s

    @property
    def ch(self):
        return self.children

    @property
    def p(self):
        return self.parents

    def r(self, condition=True, **kwargs):
        if not condition:
            return
        self._org_graph.render(**kwargs)

    def construct_dot(self, color, active_node=None, dot=None, seen=None):
        if seen is None:
            seen = set()
        if self in seen:
            return
        seen.add(self)
        dot = dot or Digraph("Search Graph", strict=False, filename=TMP_PATH / "search_graph")
        node_id = repr(self)[-10:]
        activity_color = "yellow" if self is active_node else "white"
        dot.node(
            node_id,
            label=str(self),
            shape="ellipse",
            color=color[self],
            fontcolor=color[self],
            style="filled",
            fillcolor=activity_color,
        )
        for parent in self.parents:
            parent_id = repr(parent)[-10:]
            dot.edge(parent_id, node_id)
        for child in self.children:
            child.construct_dot(color, active_node=active_node, dot=dot, seen=seen)
        return dot

    def render(self, active_node=None, condition=True):
        if not condition:
            return
        nodes = list(self.walk())
        weights = [n.weight for n in nodes]
        scaled_weights = scale_weights(weights, cutoff=30)
        color = dict([(node, heat_map(weight)) for node, weight in zip(nodes, scaled_weights)])
        dot = self.construct_dot(color, active_node=active_node)
        dot.render(view=True)


def scale_weights(weights, cutoff=100):
    """
    Take a list of weights and return a scaled list.
    Let b = max(weights). Compute the minimum weight a as the smallest weight above b - cutoff.
    Scale all weights above c and b between 0 and 1. Set all other weights to 0.
    """
    b = max(weights)
    a = min([weight for weight in weights if weight >= b - cutoff])
    if a == b:
        return [1 if w >= a else 0 for w in weights]
    return [max(0, (w - a) / (b - a)) for w in weights]


def get_new_entity_root(old_entity_root, dec, corr):
    # it should always be in corr, since the entity root should never be replaced during all the bush
    # acrobatics, (unless it is a permeable prediction node, see step 4 target.nodes[0] = decoupled_node,
    # in which case, the decoupled node should be taken.
    if old_entity_root in corr:
        return corr[old_entity_root]
    if dec.decoupled_node in corr:
        return corr[dec.decoupled_node]
    raise ValueError("Cannot find new entity root.")
    # org_replacing = bush.corr.inv.get(bush.replacing_node, None)
    # if org_replacing and org_replacing in copy_corr:
    #     new_entity_root = copy_corr[org_replacing]
    # if dec.decoupled_node in copy_corr:
    #     new_entity_root = copy_corr[dec.decoupled_node]
    # else:
    #     raise ValueError("Cannot find new entity root.")


class EntitiesProliferationManager:
    """
    Proliferation ensuring the balance between flexibility and rigidity. Inner entities are more flexible, outer
    entities -- more rigid.
    Take a graph, extracts entities from it and initializes an entity-centered-proliferator for each entity into a list.
    Create a generator the iterates each such proliferator a some <batch> number of steps and yields
    the results if one of them is successful. All proliferators corresponding to inner entities of the yielded entity
    are removed.
    """

    def __init__(self, graph, graph_elements, entity_root, params, level=0):
        self.graph = graph

        self.net = make_entity_net(graph, singleton=params["singleton"])
        node_to_entity = self.net.node_to_entity_map()
        self.initial_entity = node_to_entity.get(entity_root, self.net.nodes[0].entity)

        self.generators = []
        for entity in breadth_first_walk([self.initial_entity.node], max_distance=None):
            if not any([n.is_val_node for n in entity.modifiable]):
                continue
            prl = proliferate(graph, graph_elements, entity, node_to_entity, params, level=level)
            self.generators.append((entity, prl))
        self._bush_count = 0
        self.made_progress = False

    def flush(self):
        self.generators = []
        self.graph = None
        self.net = None

    def generate(self, steps_per_entity):
        # the source entity is the entity serving as a starting point for the bush proliferation
        for source_entity, gen in self.generators:
            # source_entity.render(self.graph)
            for bush, _ in islice(gen, steps_per_entity):
                yield source_entity, bush, self._bush_count
                self._bush_count += 1
            if self.made_progress:
                return
