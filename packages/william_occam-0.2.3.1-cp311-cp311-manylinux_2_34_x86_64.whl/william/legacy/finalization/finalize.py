from william.legacy.finalization.extract import extract_graph_below, reverse_extraction
from william.legacy.finalization.transfer import (
    reassemble_branch,
    reassemble_double_linked_pairs,
    reverse_option_transfer,
    reverse_parent_transfer,
    reverse_transfer_connections,
    transfer_connections,
)
from william.utils import replace_occurrences, unique
from william.utils.containers import AttrDict


def apply_bush(bush, target, replaced_node, decoupled_node, mem=(), imp_in_cycle=()):
    bush_imp_in_cycle = [bush.corr[n] for n in imp_in_cycle if n in bush.corr]

    rev = AttrDict(
        removed_extraction=set(),
        org_replacing=bush.corr.get_inv(bush.replacing_node, None),
        novel_copy=bush.novel.copy(),
        log_parents=set(),
        log_options=set(),
        removed_branches=[],
        log_parents_merge=set(),
        log_options_merge=set(),
        org_target_nodes=target.nodes[:],
        replaced_branch_pairs=set(),
        decoupled_branch_pairs=set(),
        org_replacing_branch_pairs=set(),
        double_linked_pairs=set(),
    )

    # step 0
    # remove all nodes not below replacing node
    extract_graph_below(bush.replacing_node, rev.removed_extraction)

    # step 1
    _update_novel(bush, decoupled_node, mem, imp_in_cycle, bush_imp_in_cycle)

    # step 2
    transfer_connections(
        target,
        decoupled_node,
        bush.replacing_node,
        rev.org_replacing,
        bush.corr,
        bush.novel,
        rev.log_parents,
        rev.log_options,
        rev.removed_branches,
    )
    if decoupled_node is None:
        return rev

    # step 3
    # if novel is empty, it means that no nodes are transferred from the bush. Hence, simply merge the
    # original replacing node with the decoupled node, which have the same value
    # Otherwise, nodes have been transferred from the bush, hence the replacing node (which is part of the bush)
    # should be merged with the decoupled node
    # merge_node = bush.replacing_node if bush.novel else rev.org_replacing
    if not bush.novel:
        decoupled_node.merge(rev.org_replacing, log_parents=rev.log_parents_merge, log_options=rev.log_options_merge)
        # org_replacing has just been stripped of all connections which moved to the decoupled node. Hence, if
        # org_replacing has been part of the target section, replace it with the decoupled node as well.
        replace_occurrences(target.nodes, rev.org_replacing, decoupled_node)

        # remove double-links to the same child for variable-arity operator nodes (like concat or union)
        rev.double_linked_pairs = remove_double_links(decoupled_node)
        target.remove_branch(rev.org_replacing, me_too=True, removed_pairs=rev.org_replacing_branch_pairs)

    # step 4
    if target.prediction_node is replaced_node:
        if decoupled_node in target.nodes:
            target.nodes.remove(decoupled_node)
        if target.prediction_node.output.permeable:
            target.nodes[0] = decoupled_node
        else:
            target.nodes = [decoupled_node] + target.nodes

        # when there are no novel nodes, org_replacing is the original of the replacing node. If, additionally,
        # org_replacing is part of the target nodes, it should be gone after the replacement.
        # otherwise the same value occurs twice in the target section (as the replacing and as the replaced node)
        if rev.org_replacing in target.nodes and rev.org_replacing is not replaced_node:
            target.nodes.remove(rev.org_replacing)

    # step 5
    # now that newly created graph is inserted, remove the old one
    target.remove_branch(replaced_node, me_too=True, removed_pairs=rev.replaced_branch_pairs, skip=(decoupled_node,))
    return rev


def remove_double_links(child):
    pairs = set()
    for parent in child.parents[:]:
        # only variable-arity nodes
        if parent.op.arity is not None:
            continue
        if len(parent.children) <= 2:
            continue
        unique_children = unique(parent.children)
        # there has to be at least a double link to this child
        multiplicity = len(parent.children) - len(unique_children)
        if multiplicity == 0:
            continue
        pairs.add((child, parent, tuple(parent.children)))  # store all children, since the order of children matters
        parent.children = unique_children
        # child.parents.remove(parent)
    return pairs


def reverse_apply_bush(bush, target, decoupled_node, rev):
    if decoupled_node is not None:
        # step 6
        reassemble_branch(rev.decoupled_branch_pairs)

        # step 5
        reassemble_branch(rev.replaced_branch_pairs)

        # step 4
        target.nodes = rev.org_target_nodes

        # step 3
        reassemble_branch(rev.org_replacing_branch_pairs)
        reassemble_double_linked_pairs(rev.double_linked_pairs)
        reverse_parent_transfer(rev.log_parents_merge)
        reverse_option_transfer(rev.log_options_merge)

    # step 2
    reverse_transfer_connections(rev.log_parents, rev.log_options, rev.removed_branches)

    # step 1
    bush.novel = rev.novel_copy
    # novel_wo_replacing = bush.novel.difference([bush.replacing_node])
    # if decoupled_node is not None and novel_wo_replacing:
    #     del bush.corr[decoupled_node]
    #     if rev.org_replacing is not None:
    #         bush.corr[rev.org_replacing] = bush.replacing_node

    # step 0
    reverse_extraction(rev.removed_extraction)


def _update_novel(bush, decoupled_node, mem, imp_in_cycle, bush_imp_in_cycle):
    # this way, <transfer connections to bush> will recognise the replacing node as border to novel and
    # move the connections
    if bush.replacing_node in bush.novel:
        bush.novel.remove(bush.replacing_node)

    if decoupled_node is None:
        return

    # Adding additional novel nodes to cover the case of "replace a node that helped computing the replacing node",
    # i.e. when the corr of the replaced node is below the replacing node.
    # In that case, add all nodes above corr[replaced] to the novel nodes which are below the replacing node and
    # that have been changed through propagation (in prop new value).
    # in bush
    # below_replacing = set(bush.replacing_node.walk(above=False, include_self=False))
    # if not bush.replacing_node.options:
    #     return
    # below_replacing = set(bush.replacing_node.options[0].walk(above=False, seen=set(bush_imp_in_cycle)))
    # in original graph
    above_decoupled = set(decoupled_node.walk(below=False, include_self=False, seen=set(imp_in_cycle)))
    # for bush_node in bush.corr[replaced_node].walk(
    #         below=False,
    #         include_self=False,
    #         val_nodes=False,
    #         seen=set(bush_imp_in_cycle),
    # ):
    #     org_node = bush.corr.get_inv(bush_node, None)
    #     if bush_node not in below_replacing:
    #         continue
    #     # skip if walk goes upward to parents that have not been propagated into
    #     if org_node in above_decoupled and org_node not in changed:
    #         continue
    #     bush.novel.add(bush_node)

    # walk down until there is an org node which is either not in mem or has stayed the same. Stop there.
    for bush_node in bush.replacing_node.walk(above=False, include_self=False, seen=set(bush_imp_in_cycle)):
        if bush_node in bush.corr.inv:
            org_node = bush.corr.inv[bush_node]
            changed = org_node in mem and not mem[org_node].same
            if not changed and org_node not in above_decoupled:
                continue
        bush.novel.add(bush_node)
