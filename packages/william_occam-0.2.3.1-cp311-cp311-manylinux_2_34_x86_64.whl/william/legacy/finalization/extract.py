def extract_graph_below(root, removed_pairs):
    below = list(root.walk(above=False))
    _extract(root, below, set(), removed_pairs)


def _extract(val_node, below, seen, removed):
    if val_node in seen:
        return
    seen.add(val_node)
    _remove_parents_not_below(val_node, below, removed)
    for option in val_node.options:
        for child in option.children:
            _extract(child, below, seen, removed)


def _remove_parents_not_below(val_node, below, removed):
    i = 0
    while i < len(val_node.parents):
        if val_node.parents[i] in below:
            i += 1
            continue
        removed.add((val_node, val_node.parents[i]))
        del val_node.parents[i]


def reverse_extraction(removed):
    for val_node, parent in removed:
        val_node.set_parent(parent, reverse=False)
