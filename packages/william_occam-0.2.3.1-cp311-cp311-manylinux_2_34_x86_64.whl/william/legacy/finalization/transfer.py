from william.utils import replace_occurrences, set_trace_up


def transfer_connections(
    target, decoupled, replacing, org_replacing, corr, novel, log_parents, log_options, removed_branches
):
    """
    Insert novel nodes from bush into the current target graph.

    Search for value nodes in original graph, such that they are not novel, but their neighbors are, other words
    value nodes on the boundary to novel nodes. Then transfer those novel nodes from the bush to the original graph.
    """
    deb = False
    org_nodes = set(target.walk())
    if decoupled is not None:
        org_nodes.add(decoupled)
        # corr[org_replacing] should lead nowhere, instead corr[decoupled] should equal replacing
        # this mimics this behavior without actually changing corr
        org_nodes.discard(org_replacing)

    for org_node in org_nodes:
        if not org_node.is_val_node or (org_node not in corr and org_node is not decoupled):
            continue
        # the corr of decoupled should be replacing
        if org_node is decoupled:
            bush_node = replacing
        else:
            bush_node = corr[org_node]  # corresponding node in bush
        # transfer connections only where novel nodes are attached to not novel ones,
        # i.e. at the junction between old and new
        if bush_node in novel:
            continue
        _transfer_parents(org_node, bush_node, novel, log_parents, deb=deb)
        _transfer_options(org_node, bush_node, novel, log_options, removed_branches, deb=deb)


def _transfer_parents(org_node, bush_node, novel, log_parents, deb=False):
    parents = bush_node.parents[:]
    for p in parents:
        if p not in novel:
            continue
        if deb:
            set_trace_up()

        org_node.set_parent(p, reverse=False)
        # replace all occurrences of bush_node among p's children with org_node
        # (a node can have more than one identical child)
        indices = replace_occurrences(p.children, bush_node, org_node)
        bush_node.delete_parent(p, reverse=False)
        log_parents.add((org_node, bush_node, p, indices))


def _transfer_options(org_node, bush_node, novel, log_options, removed_branches, deb=False):
    for option in bush_node.options:
        if option not in novel:
            continue
        if deb:
            set_trace_up()

        removed_branches.append(set())
        org_node.remove_branch(me_too=False, removed_pairs=removed_branches[-1])
        bush_node.delete_option(option, reverse=True)
        org_node.set_option(option, reverse=True)
        log_options.add((org_node, bush_node, option))


def reverse_transfer_connections(log_parents, log_options, removed_branches):
    for pairs in removed_branches[::-1]:
        reassemble_branch(pairs)
    reverse_parent_transfer(log_parents)
    reverse_option_transfer(log_options)


def reverse_parent_transfer(log_parents):
    for org_node, bush_node, parent, indices in log_parents:
        bush_node.set_parent(parent, reverse=False)
        replace_occurrences(parent.children, org_node, bush_node, nums=indices)
        if org_node not in parent.children:
            org_node.delete_parent(parent, reverse=False)


def reverse_option_transfer(log_options):
    for org_node, bush_node, option in log_options:
        org_node.delete_option(option, reverse=True)
        bush_node.set_option(option, reverse=True)


def reassemble_branch(removed_pairs):
    """Reverse the remove branch operation."""
    for node, parent in removed_pairs:
        if node.is_val_node:
            node.parents.append(parent)
        else:
            parent.options.append(node)
    removed_pairs.clear()


def reassemble_double_linked_pairs(removed_pairs):
    for node, parent, children in removed_pairs:
        if parent not in node.parents:
            node.parents.append(parent)
        parent.children = list(children)
