import numpy as np
from sklearn.linear_model import LinearRegression

from william.composite import Composite
from william.graph_elements import basic_elements, select
from william.legacy import RegressionObjectiveFunction, iterate
from william.library.base import Value
from william.library.basic_ops import Add, Mult
from william.library.types import specify
from william.paths import TMP_PATH
from william.structures import Graph, Node, ValueNode
from william.structures.dot_to_graph import parse_dot_file


class WilliamRegressor:
    def __init__(
        self,
        prediction_spec=None,
        function_set=None,
        obj_fun_cls=None,
        store="",
        lin_reg=False,
        steps_per_entity=1000,
        logger=None,
    ):
        self._graph = None
        self._prediction_spec = prediction_spec
        self.function_set = function_set or tuple(basic_elements.keys())
        self.obj_fun_cls = obj_fun_cls or RegressionObjectiveFunction
        self.store = store
        self.lin_reg = lin_reg
        self.steps_per_entity = steps_per_entity
        self.logger = logger

    def fit(
        self,
        x_train,
        y_train,
        x_names=None,
        threshold=None,
        level=0,
        graph_num=None,
        max_time=None,
        max_op_nodes=None,
        render=False,
    ):
        graph0 = self._init_graph(x_train, y_train, x_names, graph_num)
        params = {
            "max_bushes": None,
            "max_roots": 1,
            "only_roots_as_cues": True,
            "only_fire": True,
            "singleton": True,
            "compute": True,
            "hq_size": 10000000,
        }
        elements = select(basic_elements, self.function_set)
        self._graph = iterate(
            graph0,
            elements,
            obj_fun=self.obj_fun_cls(y_train, threshold=threshold),
            rng=(graph_num or 0, None),
            level=level,
            params=params,
            steps_per_entity=self.steps_per_entity,
            max_op_nodes=max_op_nodes,
            name=self.store,
            save=self.store != "",
            max_time=max_time,
            render=render,
            max_memory=30000,  # in MB
            logger=self.logger,
        )

    def _init_graph(self, x_train, y_train, x_names, graph_num):
        if graph_num is not None:
            graph0 = Graph(
                parse_dot_file(TMP_PATH / f"{self.store}/{self.store}{graph_num:03}.dot"),
                prediction=True,
            )
            return graph0
        if not self.lin_reg:
            spec = self._prediction_spec or specify(y_train)
            dummy = Value(None, spec=spec, permeable=True, dummy=True)
            values = values_from_data(x_train, y=y_train, x_names=x_names, vacuum=True)
            graph = Graph.from_values([dummy] + values, prediction=True)
            return graph

        values = values_from_data(x_train, y=y_train, x_names=x_names, vacuum=True)
        vacuum, features = values[0], values[1:]
        model = LinearRegression()
        model.fit(x_train, y_train)
        summands = []
        feature_nodes = []
        precision = 6
        for coefficient, feature in zip(model.coef_, features):
            vc = ValueNode(output=Value(np.round(coefficient, precision), permeable=True))
            vf = ValueNode(output=feature)
            feature_nodes.append(vf)
            out = Node(op=Mult(), children=[vc, vf], output=Mult()(vc.output, vf.output)).parent
            summands.append(out)
        summands.append(ValueNode(output=Value(np.round(model.intercept_, precision), permeable=True)))
        y_predict = np.dot(x_train, model.coef_) + model.intercept_
        prediction_node = Node(op=Add(), children=summands, output=Value(np.round(y_predict, precision))).parent
        graph = Graph([prediction_node] + [ValueNode(output=vacuum)] + feature_nodes, prediction=True)
        return graph

    def predict(self, x_test, x_names=None):
        inputs = values_from_data(x_test, x_names=x_names, vacuum=True)
        names_to_values = {inp.name: inp for j, inp in enumerate(inputs)}
        all_inputs = [
            names_to_values.get(leaf.output.name, leaf.output) for leaf in self._graph.prediction_node.leaves()
        ]
        y_pred = Composite(self._graph.prediction_node)(*all_inputs)
        return y_pred.value


def values_from_data(x, y=None, x_names=None, vacuum=False):
    values = []
    if vacuum:
        values.append(Value(0.1, permeable=True, name="vac"))
    if len(x) == 0:
        return values
    if y is not None and x.shape[:1] != y.shape:
        raise ValueError("Shape mismatch")
    if len(x.shape) == 1:
        x_names = x_names or ("name000",)
        values.append(Value(x, permeable=False, name=x_names[0]))
    elif len(x.shape) == 2:
        x_names = x_names or tuple(f"name{j:03}" for j in range(x.shape[1]))
        for j in range(x.shape[1]):  # factors given in rows
            values.append(Value(x[:, j], permeable=False, name=x_names[j]))
    else:
        raise ValueError("Training data has wrong shape")
    return values
