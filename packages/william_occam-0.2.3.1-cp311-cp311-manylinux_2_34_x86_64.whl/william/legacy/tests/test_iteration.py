from collections import OrderedDict
from pathlib import Path

import numpy as np
import pytest

from william.legacy.iteration import iterate
from william.legacy.objective_function import ObjectiveFunction
from william.legacy.tests.targets import ml_targets
from william.library import Add, Value
from william.library.types import Array
from william.structures import Graph, Node, ValueNode, graph_element

graphs_path = Path(__file__).parent / "graphs"


def test_graph_element():
    vn = graph_element(Add(), [Array[float]], Array[float], code=(0, 0))
    ch = ValueNode(output=Value(None, spec=Array[float]))
    nd = Node(op=Add(), children=[ch, ch])
    assert vn.resembles(nd.parent)


def select_targets(target_dicts, keys=None):
    keys = keys or list(target_dicts.keys())
    params = [
        (key,) + tuple(pair[1] for pair in param_pairs) for key, param_pairs in target_dicts.items() if key in keys
    ]
    return params, keys


alice_dicts = OrderedDict(ml_targets)
alice_params, alice_keys = select_targets(alice_dicts)


@pytest.fixture()
def level(pytestconfig):
    return int(pytestconfig.getoption("level"))


@pytest.fixture()
def graph_num(pytestconfig):
    return int(pytestconfig.getoption("graph_num"))


@pytest.mark.parametrize(
    "mode",
    [
        "serial",
        pytest.param("parallel", marks=pytest.mark.skip),
        pytest.param("dask", marks=pytest.mark.skip),
    ],
)
@pytest.mark.parametrize("key, targets, kwargs", alice_params, ids=alice_keys)
def test_induce(key, targets, kwargs, level, mode):
    np.set_printoptions(suppress=True)

    target = Graph.from_values(targets)
    obj_fun = ObjectiveFunction(threshold=kwargs.get("threshold", None))

    iterate(
        target,
        kwargs["graph_elements"],
        obj_fun=obj_fun,
        params={"mode": mode, "cpus": 1},
        steps_per_entity=1000,
        level=level,
        save=False,
        render=level > 0,
    )
