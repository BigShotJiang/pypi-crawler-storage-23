from william.legacy.match import Match, monster_nested_for
from william.legacy.proliferation import Mapping
from william.library import Union, geometry_ops, line  # TODO: This should only use standard ops
from william.structures import Node, ValueNode
from william.structures.dot_to_graph import parse_dot_file


def test_monster_fancy_nesting():
    def gen(cue, ref, corr):
        if type(cue) != type(ref):
            return
        corr_copy = corr.copy()
        corr_copy[cue] = ref
        yield corr_copy

    mem = {}
    cues = [3, "a", "b"]
    refs = ["c", 6.7, 5, "f", 8]
    correct = [
        {3: 5, "a": "c", "b": "f"},
        {3: 5, "a": "f", "b": "c"},
        {3: 8, "a": "c", "b": "f"},
        {3: 8, "a": "f", "b": "c"},
    ]
    assert list(monster_nested_for(gen, cues, refs, mem)) == correct


def test_line_matching1():
    # construct a cue
    start = (3, 5), (12, 2)
    corners = [ValueNode(output=s) for s in start]
    l1 = Node(op=line, children=[corners[0], corners[1]], output=line._call(start[0], start[1])).parent

    # construct a reference
    start = (8, 15), (43, 25), (89, 11)
    corners = [ValueNode(output=s) for s in start]
    r1 = Node(op=line, children=[corners[0], corners[1]], output=line._call(start[0], start[1])).parent
    u1 = Node(
        op=Union(),
        children=[r1, ValueNode(output={(0, 0), (1, 1)})],
        output=Union()._call(r1.output.value, {(0, 0), (1, 1)}),
    ).parent

    expected = [
        (
            ("(3,5)", "(8,15)"),
            ("(12,2)", "(43,25)"),
            ("[(3,5),(4,5),..,(12,2)]", "[(8,15),(9,15),..,(43,25)]"),
        ),
        (
            ("(3,5)", "(43,25)"),
            ("(12,2)", "(8,15)"),
            ("[(3,5),(4,5),..,(12,2)]", "[(8,15),(9,15),..,(43,25)]"),
        ),
    ]

    map0 = Mapping({})
    match = Match(dict())
    for exp, map1 in zip(expected, match.op_node_match(l1.options[0], r1.options[0], map0)):
        assert map1.pretty() == exp


def test_line_matching2():
    graph = parse_dot_file("matching/corner.dot", ops=(line,))[0]
    corners = [ValueNode(output=(0, 0)), ValueNode(output=(3, 0))]
    r1 = Node(op=line, children=corners, output={(0, 0), (1, 0)}).parent
    # corners[1].set_option(Node(op=PAdd(), children=[corners[0], ValueNode(output=np.array([3, 0]))]))
    val_nodes = [corners[0]] + [r1]
    ref_nodes = [graph.navigate((0, 0, 0, 0))] + [graph.options[0].children[1]]
    maps = list(
        monster_nested_for(
            Match({}).val_node_match,
            val_nodes,
            ref_nodes,
            Mapping({}),
            combine=False,
            match_all=True,
        )
    )
    assert maps == []

    ref_nodes = [graph.navigate((0, 0, 0, 0))] + [graph.options[0].children[0]]
    map0 = Mapping({})
    for map1 in monster_nested_for(
        Match(dict()).val_node_match, val_nodes, ref_nodes, map0, combine=False, match_all=True
    ):
        expected = [
            ((0, 0), (3, 5)),
            ((3, 0), (12, 2)),
            ({(1, 0), (0, 0)}, {(7, 4), (5, 5), (9, 3), (6, 4), (4, 5), (8, 3), (11, 2), (12, 2), (10, 3), (3, 5)}),
            # (<operator line>, <operator line>),
        ]
        actual = [(k.val.value, v.val.value) for k, v in map1.items()][:3]
        assert actual == expected


def test_different_vs_same_children_matching_failure():
    # construct a cue
    start = (3, 5), (12, 2)
    corners = [ValueNode(output=s) for s in start]
    l1 = Node(op=line, children=[corners[0], corners[0]], output=line._call(start[0], start[0])).parent

    # construct a reference
    start = (8, 15), (43, 25)
    corners = [ValueNode(output=s) for s in start]
    r1 = Node(op=line, children=[corners[0], corners[1]], output=line._call(start[0], start[1])).parent

    map0 = Mapping({})
    # no association because first line has two identical children and the associated line has two different ones
    assert list(Match(dict()).op_node_match(l1.options[0], r1.options[0], map0)) == []


def test_corner_with_triangle_matching():
    corner_graph = parse_dot_file("matching/corner_with_compose.dot", ops=geometry_ops)[0]
    ref_graph = parse_dot_file("matching/triangle.dot", ops=geometry_ops)[0]
    cue = corner_graph.find_by_value((18, 12)).__next__()
    ref = ref_graph.find_by_value((3, 5)).__next__()
    expected = [
        (
            ("(18,12)", "(3,5)"),
            ("(21,39)", "(12,2)"),
            ("{(18,12),(18,13),..,(21,39)}", "{(3,5),(4,5),..,(12,2)}"),
            ("{(21,9),(21,10),..,(21,39)}", "{(12,2),(12,3),..,(13,19)}"),
            ("(21,9)", "(13,19)"),
            ("{(18,12),(18,13),..,(21,39)}", "{(3,5),(4,5),..,(13,19)}"),
        ),
        (
            ("(18,12)", "(3,5)"),
            ("(21,39)", "(13,19)"),
            ("{(18,12),(18,13),..,(21,39)}", "{(3,5),(4,6),..,(13,19)}"),
            ("{(21,9),(21,10),..,(21,39)}", "{(3,5),(4,5),..,(13,19)}"),
            ("{(18,12),(18,13),..,(21,39)}", "{(3,5),(4,5),..,(13,19)}"),
        ),
    ]
    map0 = Mapping({})
    for map1, exp in zip(Match(dict()).val_node_match(cue, ref, map0), expected):
        assert map1.pretty() == exp
