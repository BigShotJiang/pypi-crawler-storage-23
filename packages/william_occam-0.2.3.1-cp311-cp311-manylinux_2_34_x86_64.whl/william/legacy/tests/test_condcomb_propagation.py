import numpy as np
import pytest

from william.legacy.condcomb_propagation import CondCombPropagation
from william.library import Value, compose, fill, line, meanadd, padd
from william.library.hashing import unique_hash
from william.library.precision import recursive_match
from william.nvmap import MapEntry, NodeValueMap
from william.paths import GRAPHS_PATH
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file

params = [
    ("simple_add", 6, 7, [[((7, 3), 10)]]),
    ("sqrt", 4, 5, [[((5, 20), 100), ((5, 15), 20)]]),
    ("simple_add_sub", 2.0, 5.0, [[((10.0, 15.0), -5.0), ((5.0, 10.0), 15.0)]]),
    (
        "sub_repeat",
        3,
        1,
        [[((2, [1, 1]), [1, 1, 1, 1]), ((3, 1), 2)], [((5, 1), 4), ((4, [1]), [1, 1, 1, 1])]],
    ),
    ("brange_diff", 6, 5, []),
    (
        "brange_diff",
        4,
        5,
        [
            [
                ((6, 5), 11),
                ((np.array([6, 7, 8, 9, 10]), np.array([], dtype=int)), np.array([6, 7, 8, 9, 10])),
                ((6, 11), np.array([6, 7, 8, 9, 10])),
            ]
        ],
    ),
    (
        "vertical_line",
        4,
        5,
        [
            [
                ((6, 11), np.array([6, 7, 8, 9, 10])),
                (
                    (np.array([6, 7, 8, 9, 10]), np.array([3, 3, 3, 3, 3])),
                    [
                        (np.int64(6), np.int64(3)),
                        (np.int64(7), np.int64(3)),
                        (np.int64(8), np.int64(3)),
                        (np.int64(9), np.int64(3)),
                        (np.int64(10), np.int64(3)),
                    ],
                ),
                ((5, np.array([3])), np.array([3, 3, 3, 3, 3])),
                (
                    (
                        [
                            (np.int64(6), np.int64(3)),
                            (np.int64(7), np.int64(3)),
                            (np.int64(8), np.int64(3)),
                            (np.int64(9), np.int64(3)),
                            (np.int64(10), np.int64(3)),
                        ],
                        [],
                    ),
                    [(6, 3), (7, 3), (8, 3), (9, 3), (10, 3)],
                ),
                ((6, 5), 11),
            ]
        ],
    ),
    # TODO: fix these test cases
    # ('multy_small', 3, 4, [[((5, -3), -15), ((1, 4), 5)],
    #                        [((2, 4), 6), ((6, -2.5), -15)],
    #                        [((3.75, -4), -15), ((-0.25, 4), 3.75), ((4,), -4)]]),
    # ('multy', 3, 4, [
    #     [((4, 8), -4), ((5, -4), -20), ((8,), 8), ((1, 4), 5), ((1,), 1)],
    #     [((4, 8), -4), ((5, -4), -20), ((8,), 8), ((1, 4), 5), ((-1,), 1)],
    #     [((4, 8), -4), ((-8,), 8), ((5, -4), -20), ((1, 4), 5), ((1,), 1)],
    #     [((4, 8), -4), ((-8,), 8), ((5, -4), -20), ((1, 4), 5), ((-1,), 1)],
    #     [((7.3333333333,), 7.3333333333), ((2, 4), 6), ((-2,), 2), ((4, 7.3333333333), -3.3333333333333335),
    #      ((6, -3.3333333333333335), -20)], [((-7.3333333333,), 7.3333333333), ((2, 4), 6), ((-2,), 2),
    #                                         ((4, 7.3333333333), -3.3333333333333335), ((6, -3.3333333333333335), -20)],
    #     [((-7,), 7), ((2.6666666667,), 2.6666666667), ((2.6666666667, 4), 6.666666666666667),
    #      ((6.666666666666667, -3), -20), ((4, 7), -3)], [((-7,), 7), ((2.6666666667, 4), 6.666666666666667),
    #                                                      ((-2.6666666667,), 2.6666666667),
    #                                                      ((6.666666666666667, -3), -20), ((4, 7), -3)]
    # ]),
    #
    # ('concat_repeat', 1, 2, [[(([71, 71], [71, 23]), [71, 71, 71, 23]), ((2, [71]), [71, 71])]]),
    # # TODO: There should be 1 solution (not specified here). The bug occurs because the
    # #  mem resulting from upward propagation should be used in downward propagation right away (and vice versa),
    # #  instead of generating independent mems for each propagation direction and each child and merging them
    # #  afterwards. Hence, if each direction depends on the other ones but each failing independently,
    # #  the propagation will fail altogether as happens here.
    # pytest.param('combinatorial_bug', 32, 30, [[]], marks=pytest.mark.xfail()),
    # pytest.param('triangle_bug', array([42, 33]), array([36, 18]), [[]], marks=pytest.mark.xfail()),
]


def special_hash(val_mem):
    return unique_hash(sorted([unique_hash(v) for v in val_mem]))


@pytest.mark.parametrize(
    "graph_name, source_key, output, expected_mems", params, ids=list(map(str, range(len(params))))
)
def test_propagate(graph_name, source_key, output, expected_mems):
    cs = Graph(parse_dot_file(GRAPHS_PATH / f"propagate/{graph_name}.dot"))
    source = cs.find([source_key])[0]

    mem0 = NodeValueMap()
    for node in cs.nodes:
        mem0[node] = MapEntry(same=True, val=node.output)
    mem0[source] = MapEntry(same=False, val=Value(output))
    pr = CondCombPropagation(use_existing=True, partial=False, unique=True)

    deb = False
    if deb:
        print(mem0)
        cs.render(mem0)

    mems = list(pr.propagate(cs, mem0))

    assert len(mems) == len(expected_mems)
    val_mems = np.array([special_hash(m.sorted_values) for m in mems])
    for k, (mem, exp) in enumerate(zip(mems, expected_mems)):
        # if k != kk:
        #     continue
        idx = np.where(special_hash(exp) == val_mems)[0]
        assert len(idx) > 0
        if deb:
            cs.render(mem=mem)

        filename = f"propagate/{graph_name}_result{idx[0]}.dot"
        if deb:
            cs.insert_mem(mem, copy=False)
            cs.save(GRAPHS_PATH / filename)
        else:
            cs_ref = Graph(parse_dot_file(GRAPHS_PATH / filename))
            assert cs.resembles(cs_ref, mem=mem)


def test_propagate_without_computation():
    graph_name = "brange_diff"
    source_key, output = 4, 5

    cs = Graph(parse_dot_file(GRAPHS_PATH / f"propagate/{graph_name}.dot"))
    source = cs.find([source_key])[0]

    mem0 = NodeValueMap()
    for node in cs.nodes:
        mem0[node] = MapEntry(same=True, val=node.output)
    mem0[source] = MapEntry(same=False, val=Value(output))
    pr = CondCombPropagation(use_existing=True, partial=False, unique=True, compute=True)
    pr2 = CondCombPropagation(use_existing=True, partial=False, unique=True, compute=False)

    mem1 = list(pr.propagate(cs, mem0))[0]
    mem2 = list(pr2.propagate(cs, mem0))[1]

    i = 0
    for node in cs.walk(op_nodes=False):
        if node in mem0 or mem1[node].same:
            continue
        assert mem1[node].val._value is not None
        assert mem2[node].val._value is None  # computation withheld
        i += 1
    assert i == 3

    some_node = cs.nodes[0].ch[1]
    assert len(mem1[some_node].val._value) == 0
    assert mem2[some_node].val._value is None
    _ = mem2[some_node].val.value  # computes everything here, including all the nodes needed for its computation

    for node in cs.walk(op_nodes=False):
        assert mem1[node].val._value is not None
        assert mem2[node].val._value is not None
        assert np.all(mem1[node].val._value == mem2[node].val._value)


def test_cond_comb_propagation():
    val_node = parse_dot_file("propagate/triangle_with_compose.dot", ops=(compose, meanadd, fill, line, padd))[0]
    source_key, output = (18, 12), (18, 15)

    source = val_node.find([source_key])[0]
    root = Graph(val_node)

    mem0 = NodeValueMap()
    mem0[source] = MapEntry(same=False, val=Value(output))
    for node in root.nodes:
        mem0[node] = MapEntry(same=True, val=node.output)
    pr = CondCombPropagation(use_existing=True, partial=False, unique=True)

    expected = [
        (np.array([3, 24]), np.array([3, -6])),
        (np.array([3, 27]), np.array([3, -6])),
        (np.array([3, 24]), np.array([3, -3])),
        (np.array([3, 27]), np.array([3, -3])),
    ]

    for mem, exp in zip(pr.propagate(root, mem0), expected):
        res = tuple(mem[p.children[1]].val.value for p in source.parents[1:3])
        assert recursive_match(res, exp)
