import numpy as np
import pytest

from william.legacy.regressor import WilliamRegressor

plt = None
try:
    from matplotlib import pylab as plt

    plt.ion()
except ImportError:
    pass


@pytest.fixture()
def level(pytestconfig):
    return int(pytestconfig.getoption("level"))


params = [
    (float, np.array([24]), 81),  # find average of array (=regression with 0 variables)
    (None, np.array([16.07, 3.78]), 27),  # linear regression with 1 variable
    (None, np.array([16.07, 0.38, 0.23]), 30),  # linear regression with 2 variables
    (None, np.array([0, -3.4, 5.9, 17.5]), 100),  # linear regression with 3 variables
]


@pytest.mark.timeout(100000)
@pytest.mark.parametrize("spec, coefficients, threshold", params, ids=list(map(str, range(len(params)))))
def test_regressor(spec, coefficients, threshold, level):
    function_set = (
        "add_ff",
        "self_add_f",
        "add_f_af",
        "negate_f",
        "div_ff",
        "add_af_af",
        "mult_ff",
        "self_mult_f",
        "mult_f_af",
        "invert_f",
    )
    est = WilliamRegressor(prediction_spec=spec, function_set=function_set, store="")

    rng = np.random.RandomState(42)
    length = 1001
    x_train = np.round(rng.standard_normal((length, len(coefficients) - 1)), 2)
    y_train = np.round(coefficients[0] + np.dot(x_train, coefficients[1:]) + rng.standard_normal(length) * 0.01, 2)
    est.fit(x_train, y_train, threshold=threshold, level=level, render=True)

    x_test = np.round(rng.standard_normal((10, len(coefficients) - 1)), 2)
    y_test = est.predict(x_test)
    assert np.all(coefficients[0] + np.dot(x_test, coefficients[1:]) - y_test < 1)

    # # compare with GP learn
    # from gplearn.genetic import SymbolicRegressor
    # from gplearn.functions import make_function
    # import graphviz
    # fun = make_function(function=lambda x: 0.23 * x, name="double", arity=1, wrap=False)
    # function_set = ("add", "mul", "neg", "inv", fun)
    # est_gp = SymbolicRegressor(population_size=5000,
    #                            generations=20, stopping_criteria=0.01,
    #                            p_crossover=0.7, p_subtree_mutation=0.1,
    #                            p_hoist_mutation=0.05, p_point_mutation=0.1,
    #                            max_samples=0.9, verbose=1, function_set=function_set,
    #                            parsimony_coefficient=0.01, random_state=0)
    # est_gp.fit(x_train.transpose(), y_train)
    # print(est_gp._program)
    # dot_data = est_gp._program.export_graphviz()
    # graph = graphviz.Source(dot_data)
    # graph.render()
    # # Result: of course GP learn finds the optimal solution for such simple linear regression...
