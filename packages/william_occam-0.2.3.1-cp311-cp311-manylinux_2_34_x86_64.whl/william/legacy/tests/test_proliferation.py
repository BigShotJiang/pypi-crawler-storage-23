from pathlib import Path

import pytest

from william.graph_elements import graph_element, select
from william.legacy.bush import Bush
from william.legacy.iteration import SearchNode
from william.legacy.objective_function import ObjectiveFunction
from william.legacy.params import complete_params
from william.legacy.proliferation import Mapping
from william.legacy.proliferation.mutate import update_roots
from william.legacy.proliferation.predict import predict
from william.legacy.regressor import basic_elements
from william.legacy.semantics.entities import Entity
from william.library import Add, geometry_ops
from william.propagation_py import RandomPropagation
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file

graphs_path = Path(__file__).parent / "graphs"


@pytest.mark.parametrize("mode", ["serial", pytest.param("parallel", marks=pytest.mark.skip)])
def test_proliferate(mode):
    target = Graph(parse_dot_file(graphs_path / "proliferate_before.dot"))
    obj_fun = ObjectiveFunction(target)
    elements = select(basic_elements, ["add_ff", "self_add_f", "add_f_af", "negate_f"])
    prl_params, replace_params = complete_params({"cpus": 1, "hq_size": 10000})
    search_node = SearchNode(target, obj_fun, elements, prl_params, level=0)
    results = list(search_node.proliferate(obj_fun, 10, replace_params))
    new_target = Graph(parse_dot_file(graphs_path / "proliferate_after.dot"))
    assert new_target.resembles(results[0][1])


def test_predict():
    graph = Graph(parse_dot_file(Path(__file__).parent / "proliferation_predict_bush.dot"))
    entity = Entity(graph.nodes[0], list(graph.walk()), [])
    bush = Bush(graph, entity=entity)
    ref_target = graph_element(Add(), [float], float, code=(0, 0))

    n0 = graph.nodes[0]
    n1 = ref_target.options[0].children[0]
    map0 = Mapping({n0: n1})
    # ref_graph = Graph(ref_target)
    items = list(predict(bush, ref_target, map0, bush.inferred_nodes()))
    assert len(items) == 1
    _, mems, nums, missing = items[0]

    pr = RandomPropagation(
        partial=True,
        unique=True,
        compute=True,
    )

    for mem in pr.propagate(ref_target, mems[1]):
        if len(mem) <= len(mems[1]):
            continue

        # assert item.entity.root is ref_target
        assert not missing
        assert mem[ref_target].val.value == 2.0
        assert mem[n1].val.value == 1.0
        assert not nums


params = [
    (
        "update_roots0.dot",
        ["[(a[-37,-16,59],(18,9)),..]\ndl=66516.03"],
        ["[(a[-37,-16,59],(18,9)),..]\ndl=2404.50"],
        1,
        ["[(a[-37,-16,59],(18,9)),..]\ndl=66516.03"],
    ),
    (
        "update_roots1.dot",
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67\ntarget"],
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67"],
        -1,
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67\ntarget"],
    ),
    (
        "update_roots1.dot",
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67"],
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67\ntarget"],
        -1,
        ["a[1.572925,1.57206,..,1.571855]\ndl=12096.67\ntarget"],
    ),
]


@pytest.mark.parametrize("graph_name, predicted_roots, current_roots, direction, expected", params)
def test_update_roots(graph_name, predicted_roots, current_roots, direction, expected):
    graph = Graph(parse_dot_file(graphs_path / graph_name, ops=geometry_ops))
    predicted_roots = [graph.find_by_str(s)[0] for s in predicted_roots]
    current_roots = [graph.find_by_str(s)[0] for s in current_roots]
    new_roots = update_roots(current_roots, predicted_roots, direction)
    assert [n.v for n in new_roots] == expected
