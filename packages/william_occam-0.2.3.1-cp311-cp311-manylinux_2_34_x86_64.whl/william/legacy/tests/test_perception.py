import numpy as np
import pytest

from william.graph_elements import graph_element, select
from william.legacy.iteration import iterate
from william.library import Add, Concat, Invert, Mult, Negate
from william.library.canvas import Canvas, GeometricFigure
from william.library.filling import LineFiller
from william.library.geometry_ops import (
    Draw,
    Dye,
    arc,
    avgcol,
    compose,
    distance,
    fill,
    geometry_ops,
    line,
    padd,
    rotate,
)
from william.library.types import Array, ColPoint, FloatPoint, Point
from william.paths import GRAPHS_PATH, TMP_PATH
from william.rendering import scale_array
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file
from william.utils import dispdots

c = 100.0
red, green, blue = np.array([255.0, c, c]), np.array([c, 255.0, c]), np.array([c, c, 255.0])
beige = np.array([245, 205, 150])
grey = np.array([c, c, c])


def single_triangle(canvas):
    start = ((45, 3), (45, 30), (20, 48))
    img = canvas.polygon_image(start, size=(50, 50, 3), colors=(red, blue))[1]
    img += np.random.default_rng().standard_normal(img.shape)
    return img


def two_triangles(canvas):
    p0, p1, p2 = np.array([6, 6]), np.array([24, 6]), np.array([24, 48])
    size = (50, 50)
    img = canvas.polygon_image([p0, p1, p2], size=size, colors=(0, 244.256))[1]
    c = np.array([1, 0])
    img2 = canvas.polygon_image([p1 + c, np.array([42, 6]), p2 + c], size=size, colors=(0, 104.492))[1]
    img[img2 != 0] = img2[img2 != 0]
    img = np.round(img - np.nanmean(img), 3)
    return img


def house():
    geom = GeometricFigure()
    img = np.ones((50, 50, 3)) * red
    for p in geom.filled_polygon(((21, 9), (21, 39), (6, 24)), LineFiller()):
        img[p] = blue
    for p in geom.filled_polygon(((21, 9), (21, 39), (45, 39), (45, 9)), LineFiller()):
        img[p] = green
    rng = np.random.RandomState(42)
    img += rng.standard_normal(img.shape) * 20.0
    # img -= np.mean(img)
    img = np.round(img, 2)
    return img


def rectangle():
    geom = GeometricFigure()
    img = np.ones((50, 50, 3)) * red
    for p in geom.filled_polygon(((21, 9), (21, 39), (45, 39), (45, 9)), LineFiller()):
        img[p] = green
    rng = np.random.RandomState(42)
    img += rng.standard_normal(img.shape) * 20.0
    img = np.round(img, 2)
    return img


def ice_cream(background=grey / 2):
    geom = GeometricFigure()
    img = np.ones((50, 50, 3)) * background
    p1, p2, p3 = (15, 15), (15, 33), (45, 24)
    for p in geom.filled_polygon((p1, p2, p3), LineFiller()):
        img[p] = beige
    closed_arc = geom.line(p1, p2) + geom.arc(p1, p2, -1 / 9.01)
    for p in LineFiller().fill(closed_arc):
        img[p] = beige
    rng = np.random.RandomState(42)
    img += rng.standard_normal(img.shape) * 10.0
    img = np.round(img, 2)
    return img


def umbrella(canvas):
    img = canvas.image_from_file(GRAPHS_PATH / "umbrella_small.jpeg")
    # img += np.random.randn(*img.shape)
    # img = np.round(img - np.nanmean(img), 2)
    return img


def test_drawings():
    """Simply check that these functions are executable."""
    canvas = Canvas()
    img = single_triangle(canvas)
    img = two_triangles(canvas)
    img = house()
    # TODO: assert something ??


def test_drawings_from_image():
    canvas = Canvas()
    try:
        img = umbrella(canvas)
    except ImportError:
        pytest.skip("pillow unavailable")
    # TODO: assert something ??


graph_elements = dict(
    (
        ("self_add_f", graph_element(Add(), [float], float, code=(0, 0))),
        ("add_ff", graph_element(Add(), [float, float], float)),
        ("negate_f", graph_element(Negate(), [float], float)),
        ("invert_f", graph_element(Invert(), [float], float)),
        ("self_add_i", graph_element(Add(), [int], int, code=(0, 0))),
        ("add_ii", graph_element(Add(), [int, int], int)),
        ("negate_i", graph_element(Negate(), [int], int)),
        ("line", graph_element(line, [FloatPoint, FloatPoint], list[Point])),
        ("self_line", graph_element(line, [FloatPoint], list[Point], code=(0, 0))),
        ("arc", graph_element(arc, [FloatPoint, FloatPoint, float], list[Point])),
        ("point_add", graph_element(padd, [FloatPoint, Array[float]], FloatPoint)),
        ("self_add_af", graph_element(Add(), [Array[float]], Array[float], code=(0, 0))),
        ("add_afaf", graph_element(Add(), [Array[float], Array[float]], Array[float])),
        ("negate_af", graph_element(Negate(), [Array[float]], Array[float])),
        ("mult_aff", graph_element(Mult(), [Array[float], float], Array[float])),
        ("distance", graph_element(distance, [FloatPoint, FloatPoint], float)),
        ("fill", graph_element(fill, [list[Point]], list[Point])),
        ("concat", graph_element(Concat(), [list[Point], list[Point]], list[Point])),
        ("concat_col", graph_element(Concat(), [list[ColPoint], list[ColPoint]], list[ColPoint])),
        ("rotate", graph_element(rotate, [Array[float], float], Array[float])),
        ("compose", graph_element(compose, [Array[float], list[Point], Array[float]], Array[float])),
        ("avgcol", graph_element(avgcol, [Array[float], list[Point]], list[ColPoint])),
        # ("dye", graph_element(dye, [List[Point]], List[ColPoint])),
        # ("draw", graph_element(draw, [List[ColPoint]], Array[float])),
    )
)


@pytest.fixture()
def level(pytestconfig):
    return int(pytestconfig.getoption("level"))


@pytest.fixture()
def graph_num(pytestconfig):
    return int(pytestconfig.getoption("graph_num"))


@pytest.mark.timeout(10000)
def test_rectangle(level, graph_num):
    name = "rectangle"
    img = rectangle()
    custom_ops = dict((op.name, op) for op in geometry_ops)
    custom_ops["draw"] = Draw((50, 50, 3), background=red)
    custom_ops["dye"] = Dye(img)
    graph = Graph(parse_dot_file(TMP_PATH / name / f"{name}{graph_num:03}.dot", ops=custom_ops))

    names = [
        "line",
        "point_add",
        "negate_af",
        "fill",
        "concat",
        "concat_col",
        "add_afaf",
        "self_add_af",
        # "draw",
        # "self_add_f",
        # "add_ff",
        # "negate_f",
        # "invert_f",
        # "distance",
        # "arc",
    ]

    elements = select(graph_elements, names)
    # elements["draw"] = graph_element(custom_ops["draw"], [List[ColPoint]], Array[float])
    elements["dye"] = graph_element(custom_ops["dye"], [list[Point]], list[ColPoint])

    params = {
        "max_roots": 1,
        "only_roots_as_cues": True,
        "only_fire": True,
        "singleton": False,
    }
    iterate(
        graph, elements, name=name, rng=(graph_num, None), steps_per_entity=1000, level=level, params=params, save=True
    )


@pytest.mark.timeout(10000)
def test_ice_cream(level, graph_num):
    name = "ice_cream"
    # img = ice_cream(background=grey / 2)
    # vacuum = [(9., 24.), np.array([0., 3.]), np.array([3., 0.])]
    # graph = Graph.from_values([Value(img, permeable=False)] + [Value(v) for v in vacuum])
    # graph.render()
    # graph.save(f"{name}000.dot", path=TMP_PATH / name)
    custom_ops = dict((op.name, op) for op in geometry_ops)
    custom_ops["draw"] = Draw((50, 50, 3), background=grey / 2)
    graph = Graph(parse_dot_file(TMP_PATH / name / f"{name}{graph_num:03}.dot", ops=custom_ops))

    # names = [
    #     "line", "point_add", "add_aiai", "negate_ai", "fill", "concat", "compose",
    #     "self_add_f", "add_ff", "negate_f", "invert_f", "distance", "arc",
    # ]
    names = [
        "line",
        "point_add",
        "negate_af",
        "fill",
        "concat",
        "concat_col",
        "draw",
        "add_afaf",
        "self_add_af",
        # "self_add_f",
        # "add_ff",
        # "negate_f",
        # "invert_f",
        # "distance",
        # "arc",
    ]

    elements = select(graph_elements, names)
    params = {
        "max_roots": 1,
        "only_roots_as_cues": True,
        "only_fire": True,
        "singleton": True,
    }
    iterate(graph, elements, name=name, rng=(graph_num, None), level=level, params=params, save=True)


@pytest.mark.timeout(10000)
def test_house(level, graph_num):
    name = "house"
    img = house()
    custom_ops = dict((op.name, op) for op in geometry_ops)
    custom_ops["draw"] = Draw((50, 50, 3), background=red)
    custom_ops["dye"] = Dye(img)
    graph = Graph(parse_dot_file(TMP_PATH / name / f"{name}{graph_num:03}.dot", ops=custom_ops))

    # values = [
    #     Value(img, permeable=False),
    #     Value((24., 12.)),
    #     Value(np.array([0., 3.])),
    #     Value(np.array([3., 0.]))
    # ]
    # graph = Graph.from_values(values)
    # graph.render()
    # graph.save(f"{name}000.dot", path=TMP_PATH / name)

    # names = [
    #     "self_line", "line", "point_add", "add_afaf", "self_add_af", "negate_af", "fill", "concat",
    #     "self_add_f", "add_ff", "negate_f", "mult_aff", "avgcol"
    # ]
    names = [
        "line",
        "point_add",
        "negate_af",
        "fill",
        "concat",
        "concat_col",
        "add_afaf",  # "self_line"
        "self_add_af",
    ]
    elements = select(graph_elements, names)
    # elements["draw"] = graph_element(custom_ops["draw"], [List[ColPoint]], Array[float])
    elements["dye"] = graph_element(custom_ops["dye"], [list[Point]], list[ColPoint])

    params = {
        "max_roots": 1,
        "only_roots_as_cues": True,
        "only_fire": True,
        "singleton": True,
    }

    entity_root = None  # graph.find_by_str("dye")[1].parent

    iterate(
        graph,
        elements,
        entity_root=entity_root,
        name=name,
        rng=(graph_num, None),
        steps_per_entity=10000,
        level=level,
        params=params,
        save=True,
    )


def make_video(name, path):
    try:
        from PIL import Image  # noqa
        from pylab import imsave  # noqa
    except ImportError:
        return
    # name = "house"
    # path = TMP_PATH / name / "success"
    for graph_num in range(1, 105):
        dispdots(graph_num, 1)
        graph = Graph(parse_dot_file(path / f"{name}{graph_num:03}.dot", ops=geometry_ops))
        if graph_num == 0:
            img2 = graph.nodes[0].output.value
            img1 = np.zeros_like(img2)
        else:
            img1 = graph.nodes[0].ch[1].output.value
            img2 = graph.nodes[0].ch[0].output.value
        img = np.concatenate((img1, img2), axis=1)
        img = scale_array(img, span=1)
        resized_img = resize_array(img, 20)
        filename = f"{path}/images/{name}{graph_num:03}.png"
        imsave(filename, resized_img)
    # make movie from images
    # ffmpeg -framerate 2 -pattern_type glob -i "*.png" output.mp4
    # Video converter so that Telegram can read it:
    # https://webservice.online-convert.com/convert-for-telegram


def resize_array(x, factor):
    y = np.zeros((x.shape[0] * factor, x.shape[1] * factor, x.shape[2]))
    for i in range(y.shape[0]):
        for j in range(y.shape[1]):
            y[i, j, :] = x[int(i / factor), int(j / factor), :]
    return y
