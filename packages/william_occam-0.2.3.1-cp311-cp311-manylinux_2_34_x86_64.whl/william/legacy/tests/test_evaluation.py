import numpy as np
import pytest

from william.legacy.bush import Bush
from william.legacy.evaluation import replace
from william.legacy.evaluation.decouple import _commutation_comb_check, _lower_nodes_comb_check, ways_to_decouple
from william.legacy.objective_function import ObjectiveFunction
from william.legacy.semantics.entities import Entity
from william.legacy.tests.conftest import GRAPHS_PATH, custom_ops
from william.library import Add, Concat, GetItem, Repeat, URange, Value, geometry_ops
from william.structures import Graph, ValueNode
from william.structures.dot_to_graph import parse_dot_file
from william.utils import TwoWayDict, everything

expected = [
    (Concat(), (-1,), ([71, 23],)),
    (Repeat(), (-1,), ([71, 23],)),
    (URange(), (-1,), ([71, 23],)),
    (Concat(), (0, 1), ([71, 23], [71, 23])),
    (GetItem(), (0, 1), ([71, 23], [71, 23])),
    (URange(), (0,), (1,)),
    (Add(), (0, 1), (1, 1)),
    (Repeat(), (-1, 0), ([71, 23], 1)),
    (GetItem(), (0, 1), ([71, 23], 1)),
    (GetItem(), (-1, 1), ([71, 23], 1)),
    (Repeat(), (0, 1), (1, [71, 23])),
]


def test_prop_new_value(d):
    bush = d["bush"]
    target = d["target"]
    decoupled_node = bush.replacing_node.copy_wo_connections()
    n = 0
    for mem, old_node, comb in bush.prop(target, decoupled_node, dict(), level=0):
        name = f"prop_new_value/prop{''.join(str(i) for i in comb)}.dot"
        ref_cs = Graph(parse_dot_file(GRAPHS_PATH / name, ops=custom_ops))
        assert target.resembles(ref_cs, mem=mem)
        n += 1
    if n != 7:
        raise ValueError("Prop did not yield anything, but should have in order to run the assert statement.")


params = [
    ("apply5", (9, 9), 0, (6, 9), 0, True),  # downward replacement
    ("apply6", 2.0, 1, 2.0, 0, True),
    ("apply7", 4.0, 0, 2.0, 0, True),
    ("apply8", np.array([16.48]), 0, np.array([-0.29]), 0, False),
]


@pytest.mark.parametrize(
    "graph_name, replacing_value, n0, replaced_value, n1, success_expected",
    params,
    ids=list(map(str, range(len(params)))),
)
def test_replace_and_apply(graph_name, replacing_value, n0, replaced_value, n1, success_expected):
    target = Graph(parse_dot_file(GRAPHS_PATH / f"{graph_name}.dot", ops=custom_ops))
    obj_fun = ObjectiveFunction(target)
    modifiable = [target.find([replaced_value])[n1]]
    entity = Entity(target.nodes[0], list(target.nodes[0].walk()), modifiable)
    entity._lower_parents = set()
    entity.invertible = everything
    bush = Bush.from_entity(entity, None, target)
    bush.roots = [bush.section.find([replacing_value])[n0]]

    # target.render()
    # bush.r()

    replace_apply_and_assert(graph_name, target, bush, obj_fun, success_expected)


def test_replace_and_apply_custom_bush(tmp_path):
    """
    Test that propagation into an original node of the nodes below the replacing node is forbidden, see _init_mem.
    """
    graph_name = "apply9"
    replacing_value = np.array([10, 0])
    n0 = 0
    replaced_value = np.array([0, 3])
    n1 = 0

    target = Graph(parse_dot_file(GRAPHS_PATH / f"{graph_name}.dot", ops=custom_ops))
    obj_fun = ObjectiveFunction(target)
    bush_section = Graph(parse_dot_file(GRAPHS_PATH / f"{graph_name}_bush.dot", ops=custom_ops))
    # bush_section.render(filename="bush")

    corr = corr_from_target_and_bush(target, bush_section)

    # from ...nvmap import NodeValueMap
    # mem = NodeValueMap.from_nodes(corr.keys())
    # target.render(mem=mem)
    some_node = target.find([np.array([-10, 0])])[0]
    old_value = some_node.output

    replacing_node = bush_section.find([replacing_value])[n0]
    novel = {replacing_node, replacing_node.options[0]}

    modifiable = [target.find([replaced_value])[n1]]
    ent_nodes = [n for n in target.walk() if n in corr]
    entity = Entity(ent_nodes[0], ent_nodes, modifiable)
    entity._lower_parents = set()
    entity.invertible = everything

    bush = Bush(
        bush_section,
        entity=entity,
        novel=novel,
        roots=[replacing_node],
        corr=corr,
        direction=+1,
    )

    name = "bush_saving_test"
    bush.save(tmp_path / name, target)
    new_bush, new_target = Bush.load(tmp_path / name, ops=custom_ops)
    assert new_target.resembles(target)
    assert new_bush.section.resembles(bush.section)
    assert set([n.v for n in new_bush.novel]) == set([n.v for n in bush.novel])
    assert set([n.v for n in new_bush.removed]) == set([n.v for n in bush.removed])
    assert [n.v for n in new_bush.roots] == [n.v for n in bush.roots]
    assert [n.v for n in new_bush.roots] == [n.v for n in bush.roots]
    assert new_bush.dl == bush.dl
    assert new_bush.direction == bush.direction
    assert new_bush.proliferate == bush.proliferate
    assert new_bush.first == bush.first

    replace_apply_and_assert(graph_name, target, bush, obj_fun, True)
    assert some_node.output is old_value  # was not affected by propagation


def replace_apply_and_assert(graph_name, target, bush, obj_fun, success_expected):
    res = []
    for mem, _, _ in replace(bush, target, dict(), level=0):
        improved_dl = obj_fun.improved(target, 1e15, mem=mem)
        if improved_dl is None:
            continue
        new_target, _ = target.insert_mem(mem, copy=True)
        res.append(new_target)

    success = len(res) > 0
    if success and not success_expected:
        raise ValueError("Propagation should fail but did not.")
    if not success:
        if success_expected:
            raise ValueError("Prop did not yield anything, but should have in order to run the assert statement.")
        return

    new_target = res[0]
    ref_cs = Graph(parse_dot_file(GRAPHS_PATH / f"{graph_name}_ref.dot", ops=custom_ops))
    assert new_target.resembles(ref_cs)


def corr_from_target_and_bush(target, bush_section):
    corr = TwoWayDict()
    for node in bush_section.walk(op_nodes=False):
        org_node = target.find([node.val.value])
        if org_node:
            corr[org_node[0]] = node
    for n1, n2 in list(corr.items()):
        if len(n1.options) != len(n2.options):
            continue
        if not n1.options:
            continue
        for o1, o2 in zip(n1.options, n2.options):
            corr[o1] = o2
    return corr


def test_ways_to_decouple_raw():
    p00 = parse_dot_file(GRAPHS_PATH / "ways_to_decouple.dot", ops=custom_ops)[0]
    new_node = p00.find([(7, 0)])[0]
    # p00 = ValueNode(output=(0, 0))
    # vec = ValueNode(output=np.array([12, 0]))
    # p05 = ValueNode(output=(0, 5))
    # Node(op=padd, children=[p00, vec], output=(0, 5))
    # Node(op=line, children=[p05, p00], output=line(p05.val, p00.val))
    # Node(op=Concat(), children=[p05, p00], output=(0, 5, 0, 0))
    # new_node = ValueNode(output=(7, 0))
    # nd = Node(op=padd, children=[new_node, ValueNode(output=np.array([-7, 0]))], output=(0, 0))
    # nd.set_parent(p00, reverse=True)
    p00_clone = p00.clone()
    # p00.render()
    for comb in ways_to_decouple(p00, new_node):
        # node.render()
        # print(comb)
        filename = "ways_to_decouple" + "".join([str(i) for i in comb]) + ".dot"
        ref_node = parse_dot_file(GRAPHS_PATH / filename, ops=custom_ops)[0]
        assert p00.resembles(ref_node)
    assert p00_clone.resembles(p00)


def test_ways_to_decouple_self():
    p00 = parse_dot_file(GRAPHS_PATH / "ways_to_decouple_self.dot", ops=custom_ops)[0]
    new_node = p00.find([(7, 0)])[0]
    # p00 = ValueNode(output=(0, 0))
    # p05 = ValueNode(output=(0, 5))
    # Node(op=line, children=[p05, p00], output=line(p05.val, p00.val))
    # Node(op=Concat(), children=[p00, p00], output=(0, 0, 0, 0))
    # new_node = ValueNode(output=(7, 0))
    # nd = Node(op=padd, children=[new_node, ValueNode(output=np.array([-7, 0]))], output=(0, 0))
    # nd.set_parent(p00, reverse=True)
    p00_clone = p00.clone()
    # p00.save('ways_to_decouple_self.dot')
    # p00.render()
    for comb in ways_to_decouple(p00, new_node):
        # p00.render()
        # print(comb)
        # p00.save('ways_to_decouple_self' + ''.join([str(i) for i in comb]) + '.dot')
        filename = "ways_to_decouple_self" + "".join([str(i) for i in comb]) + ".dot"
        ref_node = parse_dot_file(GRAPHS_PATH / filename, ops=custom_ops)[0]
        assert p00.resembles(ref_node)
    assert p00_clone.resembles(p00)


def test_ways_to_decouple_self_commutative():
    p00 = parse_dot_file(GRAPHS_PATH / "ways_to_decouple_self_commutative.dot", ops=custom_ops)[0]
    new_node = p00.find([(7, 0)])[0]
    # p00 = ValueNode(output=(3, 0))
    # p05 = ValueNode(output=(0, 5))
    # Node(op=line, children=[p05, p00], output=line(p05.val, p00.val))
    # Node(op=Add(), children=[p00, p00], output=(6, 0))
    # new_node = ValueNode(output=(7, 0))
    # nd = Node(op=padd, children=[new_node, ValueNode(output=np.array([-4, 0]))], output=(3, 0))
    # nd.set_parent(p00, reverse=True)
    # p00.render()
    # p00.save('ways_to_decouple_self_commutative.dot')
    p00_clone = p00.clone()
    for comb in ways_to_decouple(p00, new_node):
        # p00.render()
        # print(comb)
        # p00.save('ways_to_decouple_self_commutative' + ''.join([str(i) for i in comb]) + '.dot')
        filename = "ways_to_decouple_self_commutative" + "".join([str(i) for i in comb]) + ".dot"
        ref_node = parse_dot_file(GRAPHS_PATH / filename, ops=custom_ops)[0]
        assert p00.resembles(ref_node)
    assert p00_clone.resembles(p00)


def test_comb_check():
    assert not _commutation_comb_check([0, 1, 1, 0, 2, 2], (0, 0, 0, 1, 1, 1))
    assert _commutation_comb_check([0, 1, 1, 0, 2, 2], (1, 0, 0, 0, 1, 1))
    assert _lower_nodes_comb_check((0, 0, 1, 1, 0, 0), [2, 3])
    assert not _lower_nodes_comb_check((1, 0, 1, 1, 0, 0), [2, 3])
    assert not _lower_nodes_comb_check((0, 0, 1, 1, 0, 0), [2, 3, 5])
    assert _lower_nodes_comb_check((0, 0, 1, 1, 0, 1), [2, 3, 5])
    assert _lower_nodes_comb_check((0, 1, 0, 0, 0, 1), [2, 3])
    assert _lower_nodes_comb_check((1,), [])


def test_dirty_edge_adding():
    graph = Graph(parse_dot_file(GRAPHS_PATH / "insert_corner00.dot", ops=geometry_ops))
    org_graph = graph.clone()
    replaced = graph.find([(6.0, 18.0)])[0]
    decoupled = ValueNode(output=Value((15.0, 33.0)))
    for comb in ways_to_decouple(replaced, decoupled):
        filename = "insert_corner" + "".join([str(i) for i in comb]) + ".dot"
        graph_ref = Graph(parse_dot_file(GRAPHS_PATH / filename, ops=geometry_ops))
        assert graph.resembles(graph_ref)
        # graph.render()
        # graph.save(filename, path=GRAPHS_PATH)
    # original graph has to be restored after ways_to_decouple finishes
    assert graph.resembles(org_graph)
