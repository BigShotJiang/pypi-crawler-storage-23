import numpy as np

from william.legacy.regressor import basic_elements, select
from william.library.base import Value

rng = np.random.RandomState(42)
N = 1001
one = Value(1.0)

names2 = ["add_ff", "self_add_f", "add_f_af", "negate_f", "mult_ff", "mult_f_af", "invert_f", "invert_af"]


ml_targets = [
    (
        "simple_optimization_int",
        [
            ("targets", [Value(24 + np.round(rng.standard_normal(N), 3), permeable=False), one]),
            (
                "kwargs",
                {
                    "graph_elements": select(basic_elements, ["add_ff", "self_add_f", "add_f_af", "negate_f"]),
                    "threshold": 27.2,
                },
            ),
        ],
    ),
    (
        "simple_optimization_float",
        [
            (
                "targets",
                [
                    Value(
                        1.572 + np.round(rng.standard_normal(1001) * 0.001, 6),
                        name="target",
                        permeable=False,
                    ),
                    one,
                ],
            ),
            ("kwargs", {"graph_elements": select(basic_elements, names2), "threshold": 20}),
        ],
    ),
]


# half = Value(0.5)
# x_reg_a = Value(np.round(np.random.randn(N), 2), permeable=False, name="x1")
# x_reg_b = Value(np.round(np.random.randn(N), 2), permeable=False, name="x2")
# y_reg = np.round(16.07 + 0.38 * x_reg_a.value + 0.23 * x_reg_b.value + np.random.randn(N) * 0.01, 2)
# y_reg = Value(y_reg, permeable=False, name="y")
#
#
# ml_targets += [
#     ("regression",
#      [("targets", [y_reg, x_reg_a, x_reg_b, half]),
#       ("kwargs", {"graph_elements": basic_elements,
#                   "threshold": 100})]),
#
# ]
