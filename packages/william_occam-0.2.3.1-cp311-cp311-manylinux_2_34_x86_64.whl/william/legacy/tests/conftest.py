from pathlib import Path

import numpy as np
import pytest

from william.legacy.bush import Bush
from william.legacy.semantics.entities import Entity
from william.library import compose, line, meanadd, padd, rotate, slow_fill
from william.library.geometry_ops import Fill, avgcol, draw, dye
from william.structures import Graph, Node
from william.structures.dot_to_graph import parse_dot_file
from william.utils import TwoWayDict, everything

GRAPHS_PATH = Path(__file__).parent / "graphs"

custom_ops = dict(
    compose=compose,
    meanadd=meanadd,
    slow_fill=slow_fill,
    slowfill=slow_fill,
    line=line,
    padd=padd,
    rotate=rotate,
    fill=Fill(shape=(60, 60), closed_paths_only=False),
    avgcol=avgcol,
    draw=draw,
    dye=dye,
)


@pytest.fixture
def d():
    corr = TwoWayDict()
    target = Graph(parse_dot_file(GRAPHS_PATH / "house20.dot", ops=custom_ops))
    target_copy = target.clone(corr=corr)
    bush_target = target_copy.nodes[0]
    v00 = bush_target.find([(0, 0)])[0]
    replaced_node = corr.get_inv(v00)

    entity = Entity(bush_target, list(bush_target.walk()), [replaced_node])
    entity._lower_parents = set()
    entity._higher_parents = set()
    entity.invertible = everything
    bush = Bush(target_copy, entity=entity, corr=corr)
    v012 = bush_target.find([np.array([0, 12])])[0]
    v025 = bush.section.nodes[2]

    # simulate result of proliferation on bush
    v1 = Node(op=rotate, children=[v012, v025], output=np.array([-12, 0])).parent
    v2 = Node(op=rotate, children=[v1, v025], output=np.array([0, -12])).parent
    v3 = Node(op=rotate, children=[v2, v025], output=np.array([12, 0])).parent

    v4 = Node(op=padd, children=[v00, v3], output=(12, 0)).parent
    bush.novel = {
        v1,
        v2,
        v3,
        v4,
        v1.options[0],
        v2.options[0],
        v3.options[0],
        v4.options[0],
    }
    bush.roots = [v4]

    return dict([("target", target), ("bush", bush), ("replaced", replaced_node)])
