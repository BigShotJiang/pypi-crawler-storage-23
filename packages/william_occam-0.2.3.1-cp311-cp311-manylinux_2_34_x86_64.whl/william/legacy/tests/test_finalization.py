import pytest

from william.legacy.bush import Bush
from william.legacy.finalization.extract import extract_graph_below, reverse_extraction
from william.legacy.finalization.finalize import _update_novel, apply_bush, reverse_apply_bush
from william.legacy.finalization.transfer import reassemble_branch, reverse_transfer_connections, transfer_connections
from william.legacy.tests.conftest import GRAPHS_PATH
from william.legacy.tests.test_evaluation import custom_ops
from william.library import Operator
from william.nvmap import NodeValueMap
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file


@pytest.fixture(scope="module")
def gr():
    bush, target = Bush.load(GRAPHS_PATH / "apply2")
    decoupled = target.find([6])[0]
    d = {
        "bush": bush,
        "target": target,
        "imp_in_cycle": (),
        "decoupled_node": decoupled,
        "replaced_node": target.find([3])[1],
        "mem": NodeValueMap.from_nodes(decoupled.walk(below=False), same=False),
    }
    return d


@pytest.mark.incremental
def test_extract_graph_below(gr):
    """Step 0 and 1."""
    bush = gr["bush"]
    root = bush.replacing_node
    org_root = root.clone()
    gr["org_root"] = org_root
    assert root.resembles(org_root)
    removed_pairs = set()
    extract_graph_below(root, removed_pairs)
    gr["removed_pairs"] = removed_pairs
    assert set([(node.v, parent.v) for node, parent in removed_pairs]) == {
        ("1\ndl=6.33", "negate"),
        ("-6\ndl=10.17", "sub"),
        ("1\ndl=6.33", "div"),
        ("2\ndl=7.79", "div"),
        ("3\ndl=8.66", "mult"),
        ("-6\ndl=10.17", "add"),
    }
    assert not root.resembles(org_root)
    root_ref = Graph(parse_dot_file(GRAPHS_PATH / "apply2_after_extraction.dot"))
    assert root.resembles(root_ref.nodes[0])

    gr["bush_imp_in_cycle"] = [bush.corr[n] for n in gr["imp_in_cycle"] if n in bush.corr]

    # step 1
    gr["org_replacing"] = bush.corr.get_inv(bush.replacing_node, None)
    gr["novel_copy"] = bush.novel.copy()
    _update_novel(
        bush,
        gr["decoupled_node"],
        gr["mem"],
        gr["imp_in_cycle"],
        gr["bush_imp_in_cycle"],
    )


@pytest.mark.incremental
def test_transfer_connections(gr):
    # step 2
    bush = gr["bush"]
    gr["log_parents"], gr["log_options"], gr["removed_branches"] = set(), set(), []
    transfer_connections(
        gr["target"],
        gr["decoupled_node"],
        bush.replacing_node,
        gr["org_replacing"],
        bush.corr,
        bush.novel,
        gr["log_parents"],
        gr["log_options"],
        gr["removed_branches"],
    )
    # if decoupled_node is None:
    #     return
    ref = parse_dot_file(GRAPHS_PATH / "apply2_ref.dot")[0]
    assert gr["target"].nodes[0].resembles(ref)


@pytest.mark.incremental
def test_reverse_transfer_connections(gr):
    reverse_transfer_connections(gr["log_parents"], gr["log_options"], gr["removed_branches"])
    root = gr["bush"].replacing_node
    root_ref = Graph(parse_dot_file(GRAPHS_PATH / "apply2_after_extraction.dot"))
    assert root.resembles(root_ref.nodes[0])


@pytest.mark.incremental
def test_reverse_extraction(gr):
    reverse_extraction(gr["removed_pairs"])
    org_bush, org_target = Bush.load(GRAPHS_PATH / "apply2")
    assert gr["bush"].section.resembles(org_bush.section)
    assert gr["target"].resembles(org_target)


def test_remove_and_reassemble_branch():
    graph = Graph(parse_dot_file("nodes/remove_branch3.dot", ops=custom_ops))
    root = graph.find_by_str("[(15,15),(15,16),..,(21,39)]\ndl=741.11")[0]
    removed_pairs = set()
    root.remove_branch(me_too=True, removed_pairs=removed_pairs)
    ref_graph = Graph(parse_dot_file("nodes/remove_branch3_ref.dot", ops=custom_ops))
    assert graph.resembles(ref_graph)

    cs = Graph(parse_dot_file("nodes/regression.dot"))
    removed_pairs = set()
    cs.nodes[1].remove_branch(me_too=False, removed_pairs=removed_pairs)
    cs_ref = Graph(parse_dot_file("nodes/remove_branch1.dot"))
    assert cs.resembles(cs_ref)
    assert set((n.v, p.v) for n, p in removed_pairs) == {
        ("a[-0.11,0.94,..,0.27]\ndl=9284.68", "add"),
        ("add", "a[0.89,1.94,..,1.27]\ndl=9285.99"),
    }

    cs_org = cs.clone()
    removed_pairs = set()
    cs.nodes[0].options[0].children[1].remove_branch(me_too=False, removed_pairs=removed_pairs)
    cs_ref = Graph(parse_dot_file("nodes/remove_branch2.dot"))
    assert cs.resembles(cs_ref)
    reassemble_branch(removed_pairs)
    assert cs.resembles(cs_org)


def test_prop_and_apply(d):
    bush = d["bush"]
    target = d["target"]
    org_bush, org_target = bush.section.clone(), target.clone()

    decoupled_node = bush.replacing_node.copy_wo_connections()
    k = None
    for k, (mem, replaced_node, _) in enumerate(bush.prop(target, decoupled_node, dict())):
        if k > 0:
            continue
        rev = apply_bush(bush, target, replaced_node, decoupled_node)
        ref_target = Graph(parse_dot_file(GRAPHS_PATH / "apply_ref.dot", ops=custom_ops))
        assert target.resembles(ref_target, mem=mem)
    if k is None:
        raise ValueError("Prop did not yield anything, but should have in order to run the assert statement.")

    reverse_apply_bush(bush, target, decoupled_node, rev)
    assert bush.section.resembles(org_bush)
    assert target.resembles(org_target)


def _move_parents(source_node, target_node, skip=()):
    """Move all parents of source_node to target_node."""
    outer_parents = []
    for parent in source_node.parents:
        if parent in skip:
            outer_parents.append(parent)
            continue
        target_node.parents.append(parent)
        num = parent.children.index(source_node)
        parent.children[num] = target_node
    source_node.parents = outer_parents


params = [
    ("apply2", "apply2_ref", "6\ndl=10.17", 0, "3\ndl=8.66", 1, True),
    ("apply3", "apply3_ref", "0.5\ndl=14.10", 0, "1\ndl=6.33", 0, True),
    # attaching below this time
    ("apply4", "apply4_ref", None, None, "5\ndl=9.77", 0, True),
    # cyclic stuff
    (
        "apply10",
        "apply10_ref",
        "[(a[-52,104,-52],(21,9)),..]\ndl=66516.03",
        0,
        "[(a[-52,104,-52],(21,9)),..]\ndl=64122.56",
        0,
        True,
    ),
    # Tests whether, after replacing and removing replaced branch, the one of the target nodes (which is part of the
    # removed branch), is also cut away from the removed branch, staying with the target graph
    ("apply11", "apply11_ref", "(45,24)\ndl=31.39", 0, "(45,24)\ndl=31.39", 1, False),
    # bug fix of fitter test with dummy value
    ("apply12", "apply12_ref", "replacing_copy", None, "a[0]\ndl=0.00", 0, True),
    # when there are no novel nodes, org_replacing is the original of the replacing node. If, additionally,
    # org_replacing is part of the target nodes, it should be gone after the replacement.
    # The code part target.nodes.remove(rev.org_replacing) in finalize takes care of that. This is tested here.
    ("apply13", "apply13_ref", "replacing_copy", None, "0.1\ndl=0.00", 0, False),
    ("apply13", "apply13", "replacing_copy", None, "0.5\ndl=14.10", 0, False),  # no change
    # Test of the following part of finalize:
    # if target.prediction_node.output.dummy:
    #     target.nodes[0] = decoupled_node
    # the replacement of the dummy node should not make of copy of the dummy node, as opposed to the replacement
    # of any other target section node
    ("apply14", "apply14_ref", "replacing_copy", None, "a[0.5,-0.14,..,1.4]\ndl=8715.58\nname000", 0, True),
    # testing that this part...
    # if rev.org_replacing in target.nodes and rev.org_replacing is not replaced_node:
    #     target.nodes.remove(rev.org_replacing)
    # ...is under the condition target.prediction_node is replaced_node
    # In other words, remove org_replacing from the target nodes only, if a prediction node has been replaced. That is
    # since the prediction node does not have to be duplicated once replaced, as opposed to normal target nodes.
    (
        "apply15",
        "apply15_ref",
        "a[0.5,-0.14,..,1.4]\ndl=8715.58\nname000",
        1,
        "a[0.92,0.06,..,-0.14]\ndl=8742.49\nname001",
        0,
        True,
    ),
    # deletion of a doubled-linked child in a variable-arity node
    (
        "apply16",
        "apply16_ref",
        "[(9,18),(10,18),..,(48,24)]\ndl=1192.01",
        2,
        "[(9,18),(10,18),..,(48,24)]\ndl=1192.01",
        1,
        True,
    ),
    # upward replacement (no new novel nodes)
    ("apply17", "apply17_ref", "replacing_copy", None, "a[0.6130937146,..]\ndl=12641.72", 0, True),
]


@pytest.mark.parametrize(
    "graph_name, ref_graph_name, decoupled_str, dec_num, replaced_str, rep_num, keep_below",
    params,
    ids=list(map(str, range(len(params)))),
)
def test_apply_to_target(graph_name, ref_graph_name, decoupled_str, dec_num, replaced_str, rep_num, keep_below):
    class PastMean(Operator):
        arity = 2

    custom_ops.update({"pastmean": PastMean()})  # doesn't matter which op for this test case

    bush, target = Bush.load(GRAPHS_PATH / graph_name, ops=custom_ops, prediction=True)

    if decoupled_str == "replacing_copy":
        decoupled = bush.replacing_node.copy_wo_connections()
    elif decoupled_str is None:
        decoupled = None
    else:
        decoupled = target.find_by_str(decoupled_str)[dec_num]
    replaced = target.find_by_str(replaced_str)[rep_num]

    org_bush, org_target = bush.section.clone(), target.clone()

    rev = apply_bush(
        bush,
        target,
        replaced,
        decoupled,
        imp_in_cycle=(target.nodes[0],),
    )
    if not keep_below:
        target.remove_branch(decoupled, me_too=False, removed_pairs=rev.decoupled_branch_pairs)

    target_ref = Graph(parse_dot_file(GRAPHS_PATH / f"{ref_graph_name}.dot", ops=custom_ops))
    assert target.resembles(target_ref)

    # now reverse the application
    reverse_apply_bush(bush, target, decoupled, rev)

    assert bush.section.resembles(org_bush)
    assert target.resembles(org_target, debug=True)
