"""
DAG-based program enumeration with Dirichlet-process style updating.

This module provides data structures and logic for enumerating DAGs
(e.g. candidate programs) in order of "effective length" – a code-length
like score that incorporates both prior plausibility (shorter DAGs are
preferred) and posterior reinforcement (DAGs that proved useful are
reused more often).

Conceptual background:
----------------------
We model the space of candidate programs as a discrete (potentially
countably infinite) set. The natural prior for programs is Solomonoff's
2^{-l(q)} weighting, where l(q) is the code length. For DAGs, we
approximate l(q) using an Elias code length of the number of nodes.
This gives a base measure G0(q) ∝ 2^{-l(q)}.

To make reuse of already useful DAGs more likely, we update probabilities
according to a Dirichlet process posterior predictive distribution:

    P(q | data) = (n_q + α0 * G0(q)) / (α0 + n)

where:
- n_q is the usage count of DAG q
- n is the total number of uses across all DAGs
- α0 is a concentration parameter (roughly, how many pseudo-observations
  the prior corresponds to)
- G0(q) is the normalized base measure (here approximated by 2^{-l(q)})

In terms of effective lengths we work with:

    L(q) = -log2 (n_q + α0 G0(q)) + log2(α0)

which ensures that for n_q = 0 we recover the prior length. This length
is monotone with respect to the DP posterior predictive, and therefore
serves as a priority key for the heap.

Implementation details:
-----------------------
- DAGs are wrapped in DAGItem objects, which store the root, effective
  length, prior G0, usage count, and a flag indicating whether they
  have been grown already.
- DAGEnumerator manages the heap, expansion, and usage bookkeeping.
- Marking an item as "useful" increments its count and updates its
  effective length according to the posterior update formula.
- After a round of enumeration, used items can be pushed back into
  the heap with updated priorities.

This setup ensures that exploration is guided first by prior code length,
but over time increasingly biased toward reuse of successful DAGs,
exactly as in a Dirichlet-process posterior predictive scheme.
"""

import os
from collections import defaultdict
from heapq import heappop, heappush
from typing import Any

import numpy as np
from typing_inspect import is_callable_type

from william.composite import Composite
from william.delayed_builder import DAGBuildInfo, delayed_dag_build
from william.input_enumerator import BufferedIterator, float_gen, int_gen
from william.library.base import Value
from william.library.description import desc_len
from william.structures import ValueNode
from william.utils import ansi
from william.utils.helpers import debugger, seen_already, set_trace_up

# characteristic DAG code length after which usage counts become relevant
# (smaller values mean that counts become relevant earlier)
char_len_threshold = 5


def eff_len_from_count(
    op_dl: float, count: float, total_count: float, rng: np.random.Generator, alpha0: float = 2**char_len_threshold
) -> float:
    # Elias code of number of DAG nodes (approximates DAG code length)
    dl = op_dl + rng.random() * 1e-6  # break ties randomly, but reproducibly
    G0 = 2 ** (-dl)  # prior probability mass
    # posterior probability, constructed such that count=0 gives prior
    eff_len = np.log2(total_count + alpha0) - np.log2(count + alpha0 * G0)
    #  = log((total_count + alpha0)/(count + alpha0 * G0)) ~ -log(count/alpha0 + G0) ~ dl as long as total_count << alpha0
    return eff_len


class HeapItem:
    def __init__(self, dl: float, value: Value, indices: list[int]):
        self.dl = dl
        self.value = value
        self.indices = indices

    def __lt__(self, other):
        return self.dl < other.dl


class InputsEnumerator:
    def __init__(self, elements_by_spec, free_values=None):
        self.dag_enum = DAGEnumerator(elements_by_spec, trees_only=False, level=0)

        self.gens_by_spec = {}
        free_values = free_values or defaultdict(list)
        self.gens_by_spec[int] = BufferedIterator(int_gen(free_values=free_values[int]))
        self.gens_by_spec[float] = BufferedIterator(float_gen(free_values=free_values[float]))
        for spec, fv in free_values.items():
            if spec not in self.gens_by_spec and not is_callable_type(spec):
                self.gens_by_spec[spec] = BufferedIterator(iter(fv))

        self._dl_cache = {}

    def iterate(self, specs, max_heap_size=10000):
        gens = self.gens_from_specs(specs)
        if gens is None:
            return
        indices = [0] * len(gens)
        try:
            value = self._value(gens, indices)
        except IndexError:
            return
        dl = self._tuple_dl(value)
        heap = [HeapItem(dl, value, indices)]
        seen = set()
        while heap:
            if len(heap) >= max_heap_size:
                debugger(
                    1,
                    {
                        1: f"\nInputsEnumerator heap exceeded maximum size of {max_heap_size} for specs\n{specs}\nStopping iteration."
                    },
                    color="red",
                )
                return
            item = heappop(heap)

            if not seen_already(item.value, seen):
                yield item.dl, item.value

            for k in range(len(gens)):
                new_indices = item.indices[:]
                new_indices[k] += 1
                try:
                    new_value = self._value(gens, new_indices)
                except IndexError:
                    continue
                if hash(new_value) in seen:
                    continue

                new_dl = self._tuple_dl(new_value)
                new_item = HeapItem(new_dl, new_value, new_indices)
                heappush(heap, new_item)

    def gens_from_specs(self, specs):
        gens = []
        for spec in specs:
            if spec in self.gens_by_spec:
                gens.append(self.gens_by_spec[spec])
            elif is_callable_type(spec):
                input_specs, output_spec = spec.__args__[0].__args__, spec.__args__[1]
                gens.append(self.dag_enum.get_iterator(input_specs, output_spec))
            else:
                return None
        return gens

    @staticmethod
    def _value(gens, indexes):
        return tuple([gen[i] for gen, i in zip(gens, indexes)])

    @staticmethod
    def _tuple_dl(tpl):
        return sum(desc_len(v) for v in tpl)


class DAGItem:
    """
    A DAG candidate stored in the heap, with effective length used
    for prioritization.

    Attributes
    ----------
    root : Graph/ValueNode
        The DAG structure represented.
    dl : float
        Current effective length (priority key for the heap).
    G0 : float
        Prior probability mass for this DAG, ∝ 2^{-l(DAG)}.
    count : int
        Number of times this DAG has been marked as useful.
    grown : bool
        Whether this DAG has already been expanded to generate children.

    Notes
    -----
    The effective length is updated according to:

        L(q) = -log2(count + α0 * G0) + log2(α0)

    This corresponds to the negative log posterior predictive probability
    in a Dirichlet process model. For count=0, this reduces to the
    prior-based code length.
    """

    def __init__(self, root: ValueNode, dl: float):
        self.root = root
        self._dl = dl
        self._add_dl = 0

    def __lt__(self, other):
        return self.dl < other.dl

    def __eq__(self, other):
        return self.dl == other.dl

    @property
    def dl(self):
        return self._dl + self._add_dl

    @property
    def effective_length(self):
        """Return the current effective length (priority value)."""
        return f"DAG dl={self._dl:.2f}, iter dl={self._add_dl:.2f}"

    def render(self, *args, **kwargs):
        self.root.render(*args, **kwargs)
        print(self.effective_length)


class DAGEnumerator:
    """
    Enumerator that yields DAGs in order of effective length,
    while allowing posterior updates based on usefulness.

    Parameters
    ----------
    root : Graph/ValueNode
        Starting root DAG.
    elements : list of ValueNode
        Elements used to grow new DAGs.

    Attributes
    ----------
    elements : list
        Elements available for expansion.
    heap : list
        Priority queue of DAGItem objects, ordered by effective length.
    seen : set
        Hashes of DAGs already seen, to avoid duplicates.
    total_count : int
        Total number of times DAGs have been marked useful.
    used_items : list
        Items yielded in the last iteration round, to be optionally
        pushed back into the heap.

    Notes
    -----
    The enumerator is iterable. Each iteration yields the next DAGItem
    in order of effective length. When an item is marked as useful,
    its count and effective length are updated. Calling
    `push_back_used_items` reinserts yielded items into the heap with
    their updated priorities.
    """

    def __init__(
        self, elements_by_spec: dict[Any, list[ValueNode]], level: int | None = None, trees_only: bool = False
    ):
        self.elements_by_spec = elements_by_spec
        self.total_count = sum([count for val in self.elements_by_spec.values() for _, _, count in val])

        self.level = level if level is not None else int(os.environ.get("WILLIAM_DEBUG", 0))
        self.trees_only = trees_only

        self._iterator_cache = {}

    def get_iterator(self, input_specs: tuple[Any], output_spec: Any):
        """Returns a buffered iterator for a given (input_specs, output_spec) combination."""
        key = (tuple(input_specs), output_spec)
        if key not in self._iterator_cache:
            it = self.iterate_and_compose(input_specs, output_spec)
            self._iterator_cache[key] = BufferedIterator(it)
        return self._iterator_cache[key]

    def iterate_and_compose(self, input_specs: tuple[Any], output_spec: Any, max_attempts: int = 100):
        attempts = 0
        for item in self.iterate(output_spec, max_leaves=len(input_specs)):
            if attempts >= max_attempts:
                debugger(self.level, {1: "Maximum attempts reached, stopping enumeration."}, color="red")
                return
            if self._check_input_specs(item.root, input_specs):
                attempts = 0
                yield Composite(item.root, desc_len=item.dl)
            attempts += 1

    def iterate(self, spec: Any, max_leaves: int):
        heap = []
        seen = set()

        root = ValueNode(output=Value(None, spec=spec))
        leaf = root
        for elem_num, (_, eff_len, _) in enumerate(self.elements_by_spec[leaf.output.spec]):
            ddb = DAGBuildInfo(eff_len, root, 0, elem_num)
            heappush(heap, ddb)

        sk = 1
        while heap:
            ddb = heappop(heap)

            for new_root, new_root_leaves in delayed_dag_build(
                ddb, self.elements_by_spec, self.trees_only, max_leaves, seen
            ):
                item = DAGItem(new_root, ddb.dl)

                if self.level >= 10:
                    print(f"Total count: {self.total_count}, heap size: {len(heap)}")
                    item.render(view=False, filename="test2")
                    unpacked = item.root.clone_and_unpack()
                    unpacked.render(view=False)
                    print(ansi.LIGHT_MAGENTA + ("Keeping" if sk == 0 else "Skipping") + ansi.RESET)
                    set_trace_up()
                    if sk == 1:
                        continue
                    sk = 1
                    heap = []

                yield item

                for leaf_num, leaf in enumerate(new_root_leaves):
                    for elem_num, (_, elem_eff_dl, _) in enumerate(self.elements_by_spec[leaf.output.spec]):
                        new_ddb = DAGBuildInfo(ddb.dl + elem_eff_dl, new_root, leaf_num, elem_num)
                        heappush(heap, new_ddb)
        debugger(self.level, {1: "Heap is empty, stopping enumeration."}, color="red")

    @staticmethod
    def _check_input_specs(root: ValueNode, input_specs: tuple[Any]) -> bool:
        if not input_specs:
            return True
        leaves = list(root.leaves())
        if len(leaves) != len(input_specs):
            return False
        return all(leaf.output.spec == spec for leaf, spec in zip(leaves, input_specs))
