from itertools import islice, product

import numpy as np

from william.library.base import Value
from william.library.basic_ops import Add, BRange, Concat, GetItem, Map, Mult, Negate, Repeat, SetItem
from william.library.types import Array
from william.propagation import RandomPropagation
from william.propagation_py import RandomPropagation as RandomPropagationPy
from william.structures.rustgraph import build_root_from_rust_graph
from william.structures.sexpr_to_graph import build_graph
from william.utils.registry import RegistryBundle
from william.wunderbaum import SpeedyWunderbaum, Wunderbaum


def test_wunderbaum_iteration():
    ops = [Map, BRange, Add, Mult, Negate, Concat, Repeat, GetItem, SetItem]
    ops_with_counts = [(op_cls(dl=8), 0) for op_cls in ops]

    enum = Wunderbaum(Array[int], ops_with_counts, level=0)
    prop_class = RandomPropagationPy(partial=False, cache=False)
    target = Value(np.array(100 * [45] + 250 * [87], dtype=int), spec=Array[int])

    solution_sexpr = "(Array[int] (setitem (Array[int] (repeat int Array[int])) (Array[int] (negate Array[int])) (Array[int] (negate Array[int]))))"
    solution = build_graph(solution_sexpr)
    for item, _, _ in enum.iterate(prop_class, target, solution=solution, trees_only=True):
        pass


def test_speedy_wunderbaum_iteration():
    # TODO: ops with callables
    ops = [BRange, Add, Mult, Negate, Concat, Repeat, GetItem, SetItem]
    ops_with_counts = [(op_cls(dl=8), 0) for op_cls in ops]

    enum = Wunderbaum(Array[int], ops_with_counts, level=0)
    prop_class = RandomPropagationPy(partial=False, cache=False)

    regs = RegistryBundle()
    speedy_enum = SpeedyWunderbaum(regs, Array[int], ops_with_counts, level=0)
    rust_prop_class = RandomPropagation(regs.operators, partial=False, cache=False)
    target = Value(np.array(100 * [45] + 250 * [87], dtype=int), spec=Array[int])
    it1 = enum.iterate(prop_class, target, trees_only=False)
    it2 = speedy_enum.iterate(rust_prop_class, target, trees_only=False)

    for j, ((item1, _, _), (item2, _, _)) in enumerate(islice(zip(it1, it2), 200)):
        print(".", end="", flush=True)
        # if j % 500 == 0 and j > 0:
        #     print(f" {j} items compared")
        # assert set(enum.build_stats.keys()) == set(speedy_enum.build_stats.keys())
        # for key in enum.build_stats.keys():
        #     assert enum.build_stats[key] == speedy_enum.build_stats[key]
        root2, _ = build_root_from_rust_graph(item2.root, speedy_enum.regs)
        assert item1.root.resembles(root2)
        assert item1.cond == item2.cond
        assert abs(item1.dl - item2.dl) < 1e-6
        # root2, _ = build_root_from_rust_graph(item2.ddb.root, speedy_enum.regs)


# def test_wunderbaum_speed():
#     ops_with_counts = [(op_cls(dl=9), 0) for op_cls in basic_ops]

#     enum = Wunderbaum(Array[float], ops_with_counts, level=4)
#     prop_class = RandomPropagation(partial=False, cache=False)
#     target = Value(np.array([1.2]), spec=Array[float])

#     for item, _, _ in enum.iterate(prop_class, target, max_dl=30, trees_only=False):
#         pass

#     from matplotlib import pyplot as plt
#     dls, pops, times = zip(*enum.stats)
#     plt.figure(figsize=(12, 5))
#     plt.subplot(1, 2, 1)
#     plt.plot(np.array(pops) / 1000, times)
#     plt.xlabel("Number of popped items (1000s)")
#     plt.ylabel("Time (s)")
#     plt.title("Wunderbaum enumeration time")

#     plt.subplot(1, 2, 2)
#     plt.plot(np.array(dls), times)
#     plt.xlabel("Description length")
#     plt.ylabel("Time (s)")
#     plt.title("Wunderbaum enumeration time")
#     plt.savefig("prof/wunderbaum_speed.png")


def count_trees(
    out_types: tuple[int], depth: int, spec_dict: dict[int, list[tuple[int, ...]]], cache: dict[tuple, int]
) -> int:
    """
    Counts all possible trees that can produce the given output types
    by iterating through all operators and recursively expanding their input types.
    """
    if depth == 0:
        return 1

    total_count = 0
    for types in product(*[spec_dict[t] for t in out_types]):
        if (types, depth) in cache:
            total_count += cache[(types, depth)]
            continue
        flat_types = tuple(t for ts in types for t in ts)
        count = count_trees(flat_types, depth - 1, spec_dict, cache)
        cache[(types, depth)] = count
        total_count += count

    return total_count


def test_count_trees():
    spec_dict = {
        int: [(int, float), (int,), (Array[int],)],
        float: [(float, float), (float,)],
        Array[int]: [(Array[int], int), (Array[int],)],
    }
    # ops_with_counts = [(op_cls(dl=9), 0) for op_cls in basic_ops]
    # elems_by_spec = get_elements_by_spec(ops_with_counts)
    # spec_dict = defaultdict(list)
    # for spec, values in elems_by_spec.items():
    #     for elem, _, _ in values:
    #         ch_specs = tuple([child.output.spec for child in elem.option.children])
    #         spec_dict[spec].append(ch_specs)
    #         print(f"Spec: {str(spec).replace("collections.abc.", "")}, Operator: {elem.option.op}, Children: {str(ch_specs).replace("collections.abc.", "")}")

    count = count_trees((int,), 3, spec_dict, {})
    assert count == 85
