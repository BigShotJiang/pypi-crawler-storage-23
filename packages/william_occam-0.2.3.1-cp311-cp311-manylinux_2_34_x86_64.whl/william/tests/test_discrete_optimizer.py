import numpy as np
import pytest

from william.discrete_optimizer import AdaptiveOptimizer, NewtonOptimizer
from william.library.description import _jdesc_len_array_elias


def test_newton_optimizer():
    # Example: defined areas are rarely valid, otherwise convex around (20, -15)
    def f(x):
        a, b = x
        # artificially make some inputs invalid
        if not (-100 <= a <= 100 and -100 <= b <= 100):
            return None, None
        if (a + b) % 13 == 0:  # sporadically "broken"
            return None, None
        return (a - 20) ** 2 + (b + 15) ** 2 + 3, a + b

    opt = NewtonOptimizer(np.array([True, True]), max_iters=20)
    x0 = np.array([0, 1], dtype=np.int64)
    x_star, f_star, p_star = opt.optimize(f, x0, f(x0)[0], None)
    assert np.all(x_star == np.array([20, -15]))
    assert f_star == 3.0
    assert p_star == 5
    assert opt.num_evals == 14


def test_mixed_int_float_newton_optimizer():
    """Test optimizer with mixed integer and float dimensions.

    First dimension is integer, second is continuous. The objective has a clear
    minimum at (3, 1.5).
    """

    def f(x):
        # x may contain floats; treat first component as integer by rounding
        a_raw, b = x
        a = int(np.rint(a_raw))
        # domain guard
        if not (-100 <= a <= 100 and -100.0 <= b <= 100.0):
            return None, None
        # Objective is reported only to 3 decimal places to simulate limited precision
        val = float(round((a - 3) ** 2 + (b - 1.5) ** 2, 3))
        return val, (a, float(b))

    opt = NewtonOptimizer(np.array([True, False]), max_iters=200)
    x0 = np.array([0.0, 0.0], dtype=float)
    fx0, _ = f(x0)
    x_star, f_star, _ = opt.optimize(f, x0, fx0, None)

    # integer dimension should be exactly 3
    assert int(np.rint(x_star[0])) == 3
    # float dimension should be close to 1.5
    assert abs(float(x_star[1]) - 1.5) < 1e-2
    # objective close to zero
    assert abs(f_star - 0.0) < 1e-3


def test_adaptive_optimizer_example():
    rng = np.random.default_rng(42)
    x = np.round(rng.standard_normal(1000) * 100, 3)
    y = np.round(x * 6.5 - 306.2 + rng.standard_normal(1000) * 100, 3)

    def objective(params):
        d = params[0]
        val, _ = _jdesc_len_array_elias(y - x * d, 3)
        return val, None

    opt = AdaptiveOptimizer(is_int=np.array([False]), n_points=5)
    x0 = np.array([12.0])
    f0, p0 = objective(x0)
    x_best, _, _ = opt.optimize(objective, x0, f0, p0, verbose=False)

    params = np.arange(-3.0, 16.0, 0.01)
    fs = np.array([objective(np.array([p]))[0] for p in params])
    expected_best = params[np.argmin(fs)]

    assert abs(x_best[0] - expected_best) < 0.5


@pytest.mark.parametrize("seed", [42])
def test_adaptive_grid_mixed_float_int(seed):
    rng = np.random.default_rng(seed)

    # --- Data generation ---
    true_d = 6.5
    true_b = -306
    x = np.round(rng.standard_normal(1000) * 100, 3)
    y = np.round(x * true_d + true_b + rng.standard_normal(1000) * 100, 3)

    # --- Objective function ---
    def objective(params):
        d, b = params
        val, _ = _jdesc_len_array_elias(y - (x * d + b), 3)
        return val, None

    opt = AdaptiveOptimizer(is_int=np.array([False, True]), n_points=5)
    x0 = np.array([0.0, 0.0])
    f0, p0 = objective(x0)
    best_x, _, _ = opt.optimize(objective, x0, f0, p0, jointly_optimize=True)
    d_best, b_best = best_x

    # --- Expectations ---
    assert abs(d_best - true_d) < 1, f"Bad slope: {d_best}"
    assert abs(b_best - true_b) < 60, f"Bad bias: {b_best}"


def test_adaptive_optimizer_sampling_finds_joint_improvement():
    """If coordinate-wise moves individually worsen the objective but a joint
    move improves it, the optimizer should find the joint improvement via
    sampling when the coordinate sweep alone doesn't change anything.
    """

    def objective(x):
        # reward only when both coordinates are equal (joint move), otherwise big penalty
        a, b = float(x[0]), float(x[1])
        if a != b:
            return 100.0 + (a - 1.0) ** 2 + (b - 1.0) ** 2, None
        return (a - 1.0) ** 2 + (b - 1.0) ** 2, None

    opt = AdaptiveOptimizer(is_int=np.array([False, False]), n_points=3, max_iter=5)
    x0 = np.array([0.0, 0.0])
    f0, p0 = objective(x0)
    x_best, f_best, _ = opt.optimize(objective, x0, f0, p0, jointly_optimize=True)

    # The true best is at (1,1) with objective 0.0
    assert abs(x_best[0] - 1.0) < 1e-6 and abs(x_best[1] - 1.0) < 1e-6
    assert abs(f_best - 0.0) < 1e-6
