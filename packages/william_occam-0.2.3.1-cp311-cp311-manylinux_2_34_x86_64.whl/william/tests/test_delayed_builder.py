import pytest

from william.delayed_builder import DAGBuildInfo, delayed_dag_build, glue_leaves_py, speedy_delayed_dag_build
from william.hotloops import glue_leaves
from william.library.base import Value
from william.library.basic_ops import Add, BRange, Concat, GetItem, Mult, Negate, Repeat, SetItem
from william.library.types import Array
from william.paths import GRAPHS_PATH
from william.structures import Graph, Node, ValueNode
from william.structures.dot_to_graph import parse_dot_file
from william.structures.rustgraph import build_root_from_rust_graph, build_rust_graph_from_root
from william.structures.sexpr_to_graph import build_graph
from william.utils.registry import RegistryBundle
from william.wunderbaum import SpeedyWunderbaum, Wunderbaum


def test_glue_leaves():
    a = ValueNode(output=Value(1, spec=int))
    b = ValueNode(output=Value(2, spec=int))
    c = ValueNode(output=Value(3, spec=int))
    d = ValueNode(output=Value(4, spec=int))
    e = ValueNode(output=Value(5, spec=int))

    sub_root = Node(op=Add(), children=[a, b], output=Value(3, spec=int)).parent
    root = Node(op=Add(), children=[sub_root, c, d, e], output=Value(88, spec=int)).parent
    leaves = [a, b]
    candidates = [c, d, e]

    glued_roots_py = list(glue_leaves_py(root, leaves, candidates, trees_only=False, max_leaves=None))

    registry = RegistryBundle()
    rust_graph, id_map = build_rust_graph_from_root(root, registry)

    leaf_ids = [id_map[leaf] for leaf in leaves]
    cand_ids = [id_map[cand] for cand in candidates]
    glued_roots = glue_leaves(rust_graph, leaf_ids, cand_ids, trees_only=False, max_leaves=None)

    assert len(glued_roots) == len(glued_roots_py)
    for i, (gr_py, gr) in enumerate(zip(glued_roots_py, glued_roots)):
        glued_root, _ = build_root_from_rust_graph(gr, registry)
        assert glued_root.resembles(gr_py)
        expected = Graph(parse_dot_file(GRAPHS_PATH / "glue_leaves" / f"dag_{i}.dot"))
        assert gr_py.resembles(expected.nodes[0])


params = [
    ("Array[int]", 0, 11),
    ("((= $ Array[int]) (Array[int] (setitem _1 list[int] (Array[int] (setitem _1 list[int] Array[int])))))", 3, 13),
]


@pytest.mark.parametrize("sexpr, leaf_num, num_in_spec_list", params, ids=list(map(str, range(len(params)))))
def test_builder_compare(sexpr, leaf_num, num_in_spec_list):
    ops = [BRange, Add, Mult, Negate, Concat, Repeat, GetItem, SetItem]
    ops_with_counts = [(op_cls(dl=8), 0) for op_cls in ops]

    enum = Wunderbaum(Array[int], ops_with_counts, level=0)
    registry = RegistryBundle()
    speedy_enum = SpeedyWunderbaum(registry, Array[int], ops_with_counts, level=0)

    root = build_graph(sexpr)

    dag_info1 = DAGBuildInfo(dl=8.0, root=root, leaf_num=leaf_num, num_in_spec_list=num_in_spec_list)
    it1 = delayed_dag_build(dag_info1, enum.elements_by_spec, trees_only=False, max_leaves=None, seen=set())

    rust_root, _ = build_rust_graph_from_root(root, speedy_enum.regs)
    dag_info2 = DAGBuildInfo(dl=8.0, root=rust_root, leaf_num=leaf_num, num_in_spec_list=num_in_spec_list)
    it2 = speedy_delayed_dag_build(
        dag_info2, speedy_enum.elements_by_spec, trees_only=False, max_leaves=None, seen=set()
    )
    for (new_root1, _), (new_root2, _) in zip(it1, it2):
        new_root2_org, _ = build_root_from_rust_graph(new_root2, speedy_enum.regs)
        assert new_root1.resembles(new_root2_org)
