from copy import deepcopy

import numpy as np
import pytest

from william.composite import Composite, specs_intersection_at_valuenode, synchronize_specs
from william.library import BoolZeros, Concat, Operator, Repeat, ToChr, Value
from william.library.functions import join_inputs
from william.library.precision import recursive_match
from william.library.types import T1, T2, Array, unify
from william.propagation_py import RandomPropagation
from william.structures import Graph, ValueNode, graph_from_tuple
from william.structures.dot_to_graph import parse_dot_file
from william.structures.sexpr_to_graph import build_composite_with_constants


def test_resemble():
    composites = [parse_dot_file(f"composite/co{k}.dot")[0] for k in range(5)]
    samples = composites[:-2]

    node = deepcopy(composites[0])
    assert hash(node) == hash(composites[0])
    assert Composite(node).resembles(Composite(composites[0]))
    assert Composite(node) in set(Composite(c) for c in samples)


expected_inverse = [
    [(np.array([1, 2, 3, 4, 5, 6, 7, 8, 9]),)],
    [],
    [],
    [
        (
            ToChr(),
            np.array([97, 98, 99, 100, 101, 102, 103]),
        )
    ],
    [(1, np.array([2, 2, 2, 2, 2, 2, 2, 2]))],
    [(6,)],
    [(np.array([0, -1, 1, 0, 0, 1, 1, 0, 0, -1]),)],
]


inferred = [
    [([1], [2, 3, 4, 5])],
    [],
    [([0, 0, 0, 0, 0, 0], 4, [1]), (0, 4, [1])],
    [([1, 1, 1, 1], 6, [0]), (1, 6, [0])],
    [(np.array([2, 4, 6, 7, 8, 9]), 4, [1])],
    [(np.array([0, 1, 3, 5]), 6, [0])],
    [],
    [],
    [],
    [([-1, 5], 6, [1, 0, 0, 0, 0]), ([-1, 5], 6, [-1, 0, 0, 0, 0])],
    [(6, [3])],
]


def _get_pic():
    pic = [0] * 30
    pic[3] = pic[14] = pic[25] = 1
    return pic


params = [
    ("trees0", np.arange(10), (0,), (np.array([0]),), expected_inverse[0]),
    (
        "trees3",
        [(0, 1), (0, 2), (0, 3), (0, 4), (1, 4), (2, 4), (3, 4), (4, 4)],
        (),
        (),
        expected_inverse[2],
    ),
    ("trees6", np.array([2**i for i in range(9)]), (), (), expected_inverse[4]),
    ("trees6", list(np.arange(1, 9)), (), (), []),  # wrong type
    ("trees7", np.arange(6), (0,), ([0] * 6,), expected_inverse[5]),
    ("trees7", np.array([0, 0, 3, 3, 4, 6, 7, 7, 8, 8]), (1,), (10,), expected_inverse[6]),
    # map inversion test cases:
    ("trees12", np.array([0, 7]), (), (), [(np.array([0.0, 7.0]),), (np.array(["0", "7"]),)]),
    ("trees13", np.array([1, 0, 0]), (), (), [(np.array([1, 0, 0]),), (np.array([-1, 0, 0]),)]),
    ("trees13", np.array([1, -7, 0]), (), (), []),  # the result of abs cannot be negative
    ("trees13", np.array([1, 7, 9, 3, 4, 2, 8]), (), (), []),  # too many inversions (2^7) for map(abs, x)
    ("trees14", np.array([1.0, 2.0, 0.0, 4.5]), (), (), []),
    ("trees15", np.array([2.0, 8.0]), (0,), (np.array([6.0, 40.0]),), [(np.array([3.0, 5.0]),)]),
    (
        "trees17",
        np.array([float(i) for i in range(100)]),
        (),
        (),
        [(np.arange(100),), (np.array([str(float(i)) for i in range(100)]),)],
    ),
    ("trees18", np.array([13, -14, 0, 0, 0]), (), (), []),
    # DAG inversion
    ("dag2", 32, (0,), (5,), [(7,)]),
    # horizontal line, where y0=3, y0=9 and length=5
    (
        "dag5",
        {(3, 9), (4, 9), (9, 8), (5, 9), (6, 9), (7, 9)},
        (0, 1, 2),
        (3, 5, [9]),
        [({(9, 8)},)],
    ),
    (
        "cl_func",
        np.array([1.0, 1.0, 0.0, 0.0]),
        (1, 2),
        (np.array([1.0, 0.0, 0.0, 1.0]), np.array([1.0, 1.0, 0.0, 0.0])),
        [(np.array([np.nan, 1.0, np.nan, 0.0]), np.array([1.0, np.nan, 0.0, np.nan]))],
    ),
    (
        "insert",
        np.array(["a", "b", "c", "d", "e"]),
        (1,),
        (np.array([False, True, False, True, True]),),
        [(np.array([""] * 5), np.array(["b", "d", "e"]), np.array(["a", "c"]))],
    ),
    (
        "dec",
        np.array([[1.0, 2.0], [3.0, 4.0]]),
        (1,),
        (np.array([[False, True], [True, False]]),),  # indices
        [
            (
                np.array([[1.0, np.nan], [np.nan, 4]]),  # input 0
                np.array([[np.nan, 2.0], [3.0, np.nan]]),
            )
        ],
    ),  # input 2
    ("trees1", [1, 2, 3, 4, 5, 5, 5, 5], (), (), inferred[1]),
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (0,), (np.array([2, 4, 6, 7, 8, 9]),), inferred[2]),
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (0,), (np.array([0, 1, 3, 5]),), inferred[3]),
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (1,), (0,), inferred[4]),
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (1,), (1,), inferred[5]),
    (
        "trees3",
        [(0, 1), (0, 2), (0, 3), (0, 4), (1, 4), (2, 4), (3, 4), (4, 4)],
        (),
        (),
        inferred[6],
    ),
    ("trees4", [9, 9, 9, 9, 9, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100], (0,), (5,), inferred[7]),
    ("trees4", [9, 9, 9, 9, 9, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100], (1,), (9,), inferred[8]),
    ("trees9", 6 * [5, -1, -1, -1, -1], (1,), (0,), inferred[9]),
    ("trees10", 10 * [3], (0, 1), (4, [3]), inferred[10]),
    ("co2", np.array([15, 23, 17, 26, 19, 29, 21]), (0, 1, 2), (1, 7, 2), [(23, 32, 3, 15, 23, 2)]),
    ("co2", np.array([15, 23, 17, 26, 19, 29, 21]), (3, 4, 5), (23, 32, 3), [(1, 7, 2, 15, 23, 2)]),
    ("co2", np.array([15, 13, 14, 13, 12, 23, 11]), (0, 1, 2), (1, 9, 4), [(13, 33, 10, 15, 10, -1)]),
    ("co3", 9, (0, 1, 2), (3, 4, 5), [(2,)]),
    ("co4", 13, (1, 2), (12, 5), [(-6,)]),
    ("co4", 15, (0, 1), (3, 43), [(25,)]),
    ("co7", 12, (1,), (3,), [(9,), (-9,)]),
    (
        "co11",
        _get_pic(),
        (3, 4),
        (3, 1),
        [
            (
                3,
                36,
                11,
                [0] * 27,
            )
        ],
    ),
    ("co10", np.concatenate([np.arange(5), np.arange(9)]), (2,), (0,), []),
    ("co0", np.arange(9), (0,), (np.arange(7),), [(np.arange(7), np.array([7, 8]))]),
    ("co12", [132, 1542] * 8, (), (), [(8, [132, 1542])]),
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (), (), []),  # wrong cond = ()
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (2,), (4,), []),  # wrong cond = (2,)
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (3,), (0,), []),  # wrong cond = (3,)
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (1,), (5,), []),  # wrong input = 5
    ("trees2", [1, 1, 0, 1, 0, 1, 0, 0, 0, 0], (2, 3), (10, [0]), []),  # wrong input = 10
    ("trees4", [1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100], (), (), []),  # wrong cond = ()
    (
        "trees4",
        [1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100],
        (2,),
        (5,),
        [],
    ),  # wrong cond = (2,)
    (
        "trees4",
        [1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100],
        (0,),
        (25,),
        [],
    ),  # wrong input = 25
    (
        "trees4",
        [1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 0, 1, 2, 3, 4, 100],
        (1,),
        (5,),
        [],
    ),  # wrong input = 5
]


@pytest.mark.parametrize(
    "graph_name, output, cond, cond_inputs, expected",
    params,
    ids=list(map(str, range(len(params)))),
)
def test_inverse(graph_name, output, cond, cond_inputs, expected):
    prop_class = RandomPropagation(partial=True if graph_name == "dag5" else False)
    root = parse_dot_file("composite/" + graph_name + ".dot")[0]
    callable_nums = tuple(i for i, leaf in enumerate(root.leaves()) if isinstance(leaf.output, Operator))
    comp = Composite(root, constant_nums=callable_nums, prop_class=prop_class)

    cond_inputs = tuple([Value(c) for c in cond_inputs])
    output_v = Value(output)
    actual = []
    if not expected:
        with pytest.raises(StopIteration):
            next(comp.inverse(output_v, cond_inputs, cond))
        return
    for inferred_inputs in comp.inverse(output_v, cond_inputs, cond):
        inputs = join_inputs(cond, cond_inputs, inferred_inputs)
        assert recursive_match(output_v.value, comp(*inputs).value)
        actual.append(tuple(i.value for i in inferred_inputs))
    assert len(actual) == len(expected)
    assert recursive_match(expected, actual)


comm = [
    False,
    True,
    False,
    False,
    False,
    False,
    False,
    True,
    False,
    False,
    False,
    False,
    False,
    False,
    False,
    True,
    True,
    False,
    True,
    True,
    False,
    True,
]


@pytest.mark.parametrize("graph_name, commutative", zip(["co" + str(n) for n in range(22)], comm))
def test_commutative(graph_name, commutative):
    root = parse_dot_file(f"composite/{graph_name}.dot")[0]
    assert root.commutes == commutative


dag_params = [
    ("dag0", (15,), 225),  # x^2
    ("dag1", (5,), 30),  # x^2 + x
    ("dag2", (5, 7), 32),  # x^2 + y
    ("dag3", (5, 7), 70),  # 5*7 + 5*7
    ("dag4", (3, 4, [9]), [(3, 9), (4, 9), (5, 9), (6, 9)]),
    ("dag5", (3, 4, [9], {(9, 8)}), {(3, 9), (4, 9), (5, 9), (6, 9), (9, 8)}),
]


@pytest.mark.parametrize("graph_name, inputs, output", dag_params, ids=list(map(str, range(len(dag_params)))))
def test_dag_execution(graph_name, inputs, output):
    root = parse_dot_file(f"composite/{graph_name}.dot")[0]
    prop_class = RandomPropagation(partial=True)
    dag = Composite(root, prop_class=prop_class)
    vi = [Value(i) for i in inputs]
    assert recursive_match(output, dag(*vi).value)
    clone = Composite(root.clone(), prop_class=prop_class)
    assert recursive_match(output, clone(*vi).value)


def test_graph_from_tuple():
    graph = parse_dot_file("test_graph.dot")[0]
    v0 = Value([71, 71, 71, 23])
    v1 = Value([71])
    v2 = Value(1)
    v3 = Value([71])
    v4 = Value([71, 71, 23])
    v5 = Value([71, 23])
    rep = (v0, Concat(), ((v1, Repeat(), (v2, v3)), (v4, Concat(), (v1, v5))))
    graph2 = graph_from_tuple(rep)
    assert graph.resembles(graph2)


def test_hyper_graph():
    graph = Graph(parse_dot_file("hyper0.dot"))  # map and self-add
    comp = Composite(graph.nodes[0], constant_nums=(0,))
    result = comp(Value([3, 4, 5], spec=list[int]))
    assert result.value == [6, 8, 10]

    graph = Graph(parse_dot_file("hyper1.dot"))  # map and negate
    comp = Composite(graph.nodes[0], constant_nums=(0,))
    result = comp(Value([3, 4, 5], spec=list[int]))
    assert result.value == [-3, -4, -5]

    # test inverse
    assert list(comp.conditions) == [()]
    results = list(comp.inverse(Value([4, -7, 19]), (), ()))
    assert results[0][0].value == [-4, 7, -19]


params = [
    (
        "boolzeros",
        BoolZeros(),
        "(Array[bool] (map (Callable[[tuple[]], bool]) (Array[int] (trange int int int))))",
        (Composite(ValueNode(output=False), name="constant"), 0, 10, 1),
        (0, 1, 3),
        np.zeros(10, dtype=bool),
    ),
    (
        "intzeros",
        None,
        "(Array[int] (map (Callable[[tuple[]], int]) (Array[int] (trange int int int))))",
        (Composite(ValueNode(output=0), name="constant"), 0, 10, 1),
        (0, 1, 3),
        np.zeros(10, dtype=int),
    ),
    (
        "insert",
        None,  # Insert() has a different number of inputs, reconstruction requires inverse for computation of output array length
        "((= $ Array[int])"
        "(= $ Array[int])"
        "(= $ (int (add (int (len _1)) (int (len _2)))))"
        "(= $ (Array[int] (setitem (Array[bool] (boolzeros _3)) Array[int] bool)))"
        "(Array[T] (setitem (Array[T] (setitem (Array[int] (intzeros _3)) _4 _1)) (Array[bool] (not _4)) _2)))",
        [np.array([5, 6, 7]), np.array([15, 15, 15, 15]), np.array([1, 3, 5]), True],
        (),  # No constant leaves
        np.array([15, 5, 15, 6, 15, 7, 15]),
    ),
]


ops = {}
for p in params[:2]:
    ops[p[0]] = build_composite_with_constants(p[2], p[3], p[4], name=p[0])


@pytest.mark.parametrize(
    "name, org_op, sexpr, inputs, constant_nums, expected", params, ids=list(map(str, range(len(params))))
)
def test_reconstruction(name, org_op, sexpr, inputs, constant_nums, expected):
    """Constructing operators for a reduced set of operators."""
    op = build_composite_with_constants(sexpr, inputs, constant_nums, name=name, ops=ops)
    inputs = [Value(inp) for i, inp in enumerate(inputs) if i not in constant_nums]
    result = op(*inputs)
    assert recursive_match(expected, result.value)
    if org_op:
        org_result = org_op(*inputs)
        assert recursive_match(org_result.value, result.value)


params = [
    (
        "test_graph.dot",
        [
            (tuple[int, str, str], str),
            (tuple[int, list[T2], list[T2]], list[T2]),
            (tuple[int, Array[T2], Array[T2]], Array[T2]),
        ],
    ),
    (
        "composite/dag6.dot",
        [
            (tuple[list[str], int, list[str]], list[str]),
            (tuple[list[str], int, str], list[str]),
            (tuple[Array[T1], Array[bool], Array[T1]], Array[T1]),
            (tuple[Array[T1], Array[int], Array[T1]], Array[T1]),
            (tuple[Array[T1], list[int], Array[T1]], Array[T1]),
        ],
    ),
]


@pytest.mark.parametrize("graph_name, expected", params, ids=list(map(str, range(len(params)))))
def test_composite_specs(graph_name, expected):
    root = parse_dot_file(graph_name)[0]
    comp = Composite(root)
    actual = comp.specs
    assert len(actual) == len(expected)
    for act, exp in zip(actual, expected):
        assert len(act) == len(exp)
        for a, e in zip(act, exp):
            unify(a, e)


params = [
    (
        "composite/dag6.dot",
        Array[float],
        [
            [
                (Array[float], Array[float], Array[bool], Array[float]),
                (Array[float], Array[float], Array[int], Array[float]),
                (Array[float], Array[float], list[int], Array[float]),
            ],
            [
                (Array[float],),
            ],
            [
                (Array[float], Array[float], Array[bool]),
                (Array[float], Array[float], Array[int]),
            ],
        ],
    ),
]


@pytest.mark.parametrize("graph_name, fixed_spec, expected", params, ids=list(map(str, range(len(params)))))
def test_synchronize_specs(graph_name, fixed_spec, expected):
    root = parse_dot_file(graph_name)[0]
    trans_specs_dict = synchronize_specs(root, fixed_spec=fixed_spec)

    op_nodes = list(trans_specs_dict.keys())
    assert len(op_nodes) == len(expected)
    for op_node, exp_specs in zip(op_nodes, expected):
        n = len(trans_specs_dict[op_node][0])
        assert n == len(exp_specs)
        for var_num, exp in enumerate(exp_specs):
            for neighbor_num in range(len(exp)):
                act = trans_specs_dict[op_node][neighbor_num][var_num]
                unify(exp[neighbor_num], act)


params = [
    (
        "composite/co6.dot",
        (0, 0),
        [
            [(int, int, int)],
            [
                (str, int, str),
                (list[T1], int, list[T1]),
                (Array[T1], int, Array[T1]),
            ],
        ],
    ),
    (
        "composite/dag0.dot",
        (0, 0),
        [
            [
                (float, float),
                (int, int),
                (Array[int], Array[int]),
                (Array[float], Array[float]),
            ],
        ],
    ),
    (
        "composite/dag1.dot",
        (0, 1),
        [
            [(Array[int], Array[int], Array[int]), (Array[float], Array[float], Array[float])],
            [(Array[int], Array[int]), (Array[float], Array[float])],
            [(set[int], Array[int], Array[int]), (set[float], Array[float], Array[float])],
        ],
    ),
    (
        "composite/dag4.dot",
        (0, 0),
        [[(Array[int], int, int)], [(Array[tuple[int, T2]], Array[int], Array[T2])]],
    ),
    (
        "composite/dag4.dot",
        (0, 0, 0, 1),
        [
            [(int, int, int)],
            [(Array[int], int, int)],
        ],
    ),
    (
        "composite/dag4.dot",
        (0, 0, 0, 1, 0, 1),
        [
            [
                (int, int, int),
                (Array[int], Array[int], int),
            ],
            [
                (str, int, str),
                (list[T1], int, list[T1]),
                (Array[T1], int, Array[T1]),
            ],
        ],
    ),
]


@pytest.mark.parametrize("graph_name, code, expected", params, ids=list(map(str, range(len(params)))))
def test_specs_intersection(graph_name, code, expected):
    root = parse_dot_file(graph_name)[0]
    vn = root.navigate(code)
    trans_specs, _ = specs_intersection_at_valuenode(vn, {})
    op_nodes = list(vn.neighbors())

    assert len(op_nodes) == len(expected)
    for op_node, exp_specs in zip(op_nodes, expected):
        n = len(trans_specs[op_node][0])
        assert n == len(exp_specs)
        for var_num, exp in enumerate(exp_specs):
            for neighbor_num in range(len(exp)):
                act = trans_specs[op_node][neighbor_num][var_num]
                unify(exp[neighbor_num], act)
