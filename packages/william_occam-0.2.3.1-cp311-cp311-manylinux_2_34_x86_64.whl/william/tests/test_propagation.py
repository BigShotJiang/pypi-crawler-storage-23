import numpy as np
import pytest

from william.library import Canvas, Value, compose
from william.library.hashing import unique_hash
from william.nvmap import MapEntry, NodeValueMap
from william.propagation import RandomPropagation
from william.propagation_py import RandomPropagation as RandomPropagationPy
from william.structures import Graph
from william.structures.dot_to_graph import load_composite, parse_dot_file
from william.structures.rustgraph import build_rust_graph_from_root
from william.utils.registry import RegistryBundle

params = [
    # tree  target                     inputs                          child_idx_val
    (
        "co2",
        np.array([15, 3, 17, 6, 19, 9, 21]),
        np.array([1, 7, 2, 3, 12, 3, 15, 23, 2]),
        {0: [1, 3, 5], 2: [15, 17, 19, 21]},
    ),
    ("co3", None, [3, 4, 5, None], {0: 12, 1: None}),
    ("co4", None, [None, 12, 5], {0: None, 1: 12 - 5}),
    ("co4", None, [3, 43, None], {0: -3}),
    # test that propagate_up does not rewrite if output is None
    ("co4", None, [None, 12, 5], {}),
]


@pytest.mark.parametrize("graph_name, target, inputs, child_idx_val", params, ids=list(map(str, range(len(params)))))
def test_propagate_up(graph_name, target, inputs, child_idx_val):
    comp = load_composite(graph_name)
    mem = NodeValueMap()
    comp.set_leaves(mem, [Value(i) for i in inputs])
    pr = RandomPropagationPy(partial=True)
    mems = list(pr.propagate(comp.root, mem))
    if mems:
        mem = mems[0]

    if target is None:
        assert comp.root not in mem
    else:
        assert np.all(mem[comp.root].val.value == target)

    for idx, val in child_idx_val.items():
        ch = comp.root.options[0].children[idx]
        if val is None:
            assert ch not in mem
        else:
            assert np.all(mem[ch].val.value == val)


def mem_from_given(section, given):
    mem = NodeValueMap()
    for code, value in given:
        node = section.navigate(0, code)
        mem[node] = MapEntry(same=False, val=Value(value))
    return mem


canvas = Canvas()
p0, p1, p2 = np.array([2, 2]), np.array([4, 2]), np.array([2, 3])
points, img = canvas.polygon_image([p0, p1, p2], size=(5, 5))


params = [
    (
        "matching/set_mean_add.dot",
        [
            ((), np.array([33, 17, 18, 35, 37, 39, 19])),
            ((0, 1), np.array([True, False, False, True, True, True, False])),
        ],
        [
            [
                ((36.0, np.array([-3, -1, 1, 3])), np.array([33, 35, 37, 39])),
                (
                    (
                        np.array(
                            [
                                -9223372036854775808,
                                17,
                                18,
                                -9223372036854775808,
                                -9223372036854775808,
                                -9223372036854775808,
                                19,
                            ]
                        ),
                        np.array([True, False, False, True, True, True, False]),
                        np.array([33, 35, 37, 39]),
                    ),
                    np.array([33, 17, 18, 35, 37, 39, 19]),
                ),
                ((np.array([33, 35, 37, 39]),), 36.0),
            ]
        ],
    ),
    (
        "composite/trees2.dot",
        [((), [1, 1, 0, 1, 0, 1, 0, 0, 0, 0]), ((0, 0), [2, 4, 6, 7, 8, 9])],
        [
            [
                ((4, [1]), [1, 1, 1, 1]),
                (
                    ([2, 4, 6, 7, 8, 9], [0, 0, 0, 0, 0, 0], [1, 1, 1, 1]),
                    [1, 1, 0, 1, 0, 1, 0, 0, 0, 0],
                ),
            ],
            [
                ((4, [1]), [1, 1, 1, 1]),
                (([2, 4, 6, 7, 8, 9], 0, [1, 1, 1, 1]), [1, 1, 0, 1, 0, 1, 0, 0, 0, 0]),
            ],
        ],
    ),
]


@pytest.mark.parametrize("graph_name, given, expected", params, ids=list(map(str, range(len(params)))))
def test_random_propagation(graph_name, given, expected):
    root = Graph(parse_dot_file(graph_name, ops=(compose,)))

    mem = mem_from_given(root, given)

    pr = RandomPropagationPy()
    mems = list(pr.propagate(root, mem))

    assert len(mems) == len(expected)
    for new_mem, exp in zip(mems, expected):
        act = new_mem.sorted_values
        assert unique_hash(exp) == unique_hash(act)

    # Also test RustGraph propagation
    registry = RegistryBundle()
    rust_graph, id_map = build_rust_graph_from_root(root.nodes[0], registry)
    inv_id_map = {v: k for k, v in id_map.items()}
    rust_mem = {id_map[n]: entry for n, entry in mem.items()}

    pr = RandomPropagation(registry.operators)
    rust_mems = list(pr.propagate(rust_graph, rust_mem))
    assert len(rust_mems) == len(expected)
    for rust_mem, exp in zip(rust_mems, expected):
        rust_mem_py = NodeValueMap({inv_id_map[n]: entry for n, entry in rust_mem.items()})
        act = rust_mem_py.sorted_values
        assert unique_hash(exp) == unique_hash(act)
