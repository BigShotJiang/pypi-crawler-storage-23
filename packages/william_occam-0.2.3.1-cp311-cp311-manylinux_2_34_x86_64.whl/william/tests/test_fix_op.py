from william.fix_op import Fix
from william.library import Add, Mult, Value
from william.structures.sexpr_to_graph import build_graph


def test_fix_op():
    fix = Fix()
    add5 = fix(Value(5), Add())
    assert add5(Value(3)).value == 8


def test_fix_op_from_sexpr():
    sexpr = "(fix int (Callable[[tuple[int, int]], int] (int (mult int int))))"
    root = build_graph(sexpr)
    mult6 = root.options[0].op(Value(6), Mult())
    assert mult6(Value(7)).value == 42
