import numpy as np
import pytest

from william.alice import MORK, CompressionTask, GreedyAlice, TaskDomain
from william.fix_op import Fix
from william.library.basic_ops import Add, BRange, Concat, Equal, GetItem, LessThan, Map, Mult, Negate, Repeat
from william.library.complex_ops import CumSum, Insert

basic_ops = [Map, Fix, BRange, Add, Mult, Negate, Concat, Repeat, GetItem, Insert, CumSum, LessThan, Equal]
# basic_ops = [Add, GetItem]


########################### SEQUENCE DOMAIN ###########################

rng = np.random.default_rng(42)
sprinkled = np.zeros(10000, dtype=int)
sprinkled[rng.choice(10000, 100, replace=False)] = 1

increasing = []
for n in range(500):
    increasing += n * [123] + [64]
increasing = np.array(increasing, dtype=int)

alt_inc = np.zeros(998, dtype=int)
alt_inc[1::2] = np.arange(499)

seq_params = [
    (
        [np.tile([140, -50], 500)],
        "simple_repeat",
        95.0,
        {},
    ),
    (
        [np.array(100 * [45] + 250 * [87], dtype=int)],
        "insert_repeat",
        94.0,
        {},
    ),
    (
        [np.array(10 * [45] + 25 * [87] + 610 * [164], dtype=int)],
        "insert_repeat2",
        95.0,
        {},
    ),
    (
        [np.array(100 * [45] + 250 * [87, 62] + 610 * [164], dtype=int)],
        "insert_repeat3",
        95.0,
        {},
    ),
    (
        [np.array(100 * [45] + [-1] + 400 * [45], dtype=int)],
        "repeat_with_noise",
        94.0,
        {},
    ),
    (
        [(6 * np.arange(1000) - 18).astype(int)],
        "simply_linear",
        99.0,
        {},
    ),
    (
        [sprinkled],
        "sprinkled",
        75.0,
        {},
    ),
    (
        [increasing],
        "increasing_runs",
        99.95,
        {},
    ),
    (
        [np.array([-i for i in range(1000)])],
        "map_negate",
        99.0,
        {},
    ),
]

seq_tasks = [
    CompressionTask(targets, threshold_rate=thr, name=name, solutions=sols) for targets, name, thr, sols in seq_params
]
seq_domain = TaskDomain("sequence_tasks", seq_tasks, basic_ops)


############################ REGRESSION DOMAIN ###########################

reg_tasks = [
    CompressionTask([np.arange(1000) * 3 - 5], threshold_rate=98.0, name="reg_only_y", solutions={}),
]

x = np.round(rng.standard_normal(1000) * 100, 3)
y = np.round(x * 6.5 - 306.2 + rng.standard_normal(1000) * 10, 3)
reg_tasks += [
    CompressionTask([y, x], threshold_rate=14.0, name="reg_simple", solutions={}),
]

dy = np.round(np.concatenate((rng.standard_normal(500) * 0.1 + 0, rng.standard_normal(600) * 0.1 - 3)), 3)
y = 1052 + np.cumsum(dy)
reg_tasks += [
    CompressionTask([y], threshold_rate=55.5, name="reg_drift_change", solutions={}),
]

# # the Bitcoin power law
# x = np.round(1e-17 * np.arange(5000)**5.82 * (1 + 0.1 * np.random.randn(5000)), 3)
# reg_tasks += [
#     CompressionTask([x], threshold_rate=92.0, name="reg_power_law", solutions={}),
# ]

# Multiple linear regression with several variables
x1 = np.round(rng.standard_normal(1000), 3)
x2 = np.round(rng.standard_normal(1000), 3)
x3 = np.round(rng.standard_normal(1000), 3)
y = np.round(12.5 * x1 - 40.2 * x2 + 19.7 * x3 + 1607.3 + rng.standard_normal(1000) * 0.5, 3)
reg_tasks += [
    CompressionTask([y, x1, x2, x3], threshold_rate=2.5, name="reg_multiple_vars", solutions={}),
]

# eta = 12.5 * x1 - 40.2 * x2 + 3.2
# probabilities = 1 / (1 + np.exp(-eta))
# y = np.random.binomial(1, probabilities).astype(float)
# reg_tasks += [
#     CompressionTask([y, x1, x2], threshold_rate=100.0, name="logistic_regression", solutions={
#         0: "(Array[float] (add Array[float] (Array[float] (invert (Array[float] (add (Array[float] (exp Array[float])) float))))))"
#     }),
# ]

reg_domain = TaskDomain("regression_tasks", reg_tasks, basic_ops)

############################## POINTS DOMAIN #############################

# point_array = np.array([[i,i] for i in range(100)])
# points_tasks = [
#     CompressionTask([point_array], threshold_rate=100.0, name="diagonal", solutions={
#         #0: "(Array[int] (map (Callable[[tuple[Array[int]]], Array[int]] (fix int Callable[[tuple[int, Array[int]]], Array[int]])) (Array[int] (brange int int))))"
#     }),
# ]
points_domain = TaskDomain("points_tasks", [], basic_ops)


############################ STATISTICS DOMAIN ###########################

# x = np.random.randint(0, 2, size=(5000,))
# prob = np.array([0.1, 0.9])  # probability of classes 0 and 1
# y = (np.random.rand(5000) < prob[x]).astype(float)  # generate labels according to the probabilities
# stats_tasks = [
#     CompressionTask([y, prob[x]], threshold_rate=100.0, name="cond_prob", solutions={}),
# ]
stats_domain = TaskDomain("stats_tasks", [], basic_ops)

##########################################################################

# incompressible sequence, for runtime profiling
# profiling_task = CompressionTask([rng.choice([-1, 0, 1], 1000).astype(int)], name="incompressible")


domains = [seq_domain, reg_domain, points_domain, stats_domain]
all_tasks = [task for domain in domains for task in domain.tasks]
all_task_names = [task.name for domain in domains for task in domain.tasks]


@pytest.mark.timeout(30)
@pytest.mark.parametrize("task", all_tasks, ids=all_task_names)
def test_single_task(task):
    single = TaskDomain("single_task_domain", [task], [op.__class__ for op in seq_domain.operators])
    greedy_alice = GreedyAlice(single, min_rate=0.01, max_dag_dl=35, learn=False, trees_only=False, speedy=True)
    greedy_alice.run()


@pytest.mark.timeout(120)
@pytest.mark.skipif(not MORK, reason="MORK server not available")
@pytest.mark.parametrize("domain", domains, ids=[domain.name for domain in domains])
def test_domain_learning(domain):
    greedy_alice = GreedyAlice(domain, min_rate=0.01, max_dag_dl=100, erase_memory=True, learn=True, trees_only=True)
    greedy_alice.run()
