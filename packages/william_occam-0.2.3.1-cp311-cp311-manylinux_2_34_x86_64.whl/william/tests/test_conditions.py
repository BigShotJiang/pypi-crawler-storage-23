import pytest

from william.composite import Composite
from william.conditions import (
    ConditionCombinations,
    condition_combinations_py,
    filter_redundant,
    get_conditions_py,
    remove_redundant_conditions,
    tree_conditions_py,
    update_callable_conditions_py,
)
from william.hotloops import condition_combinations, get_conditions, tree_conditions, update_callable_conditions
from william.nvmap import MapEntry, NodeValueMap
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file
from william.structures.rustgraph import build_rust_graph_from_root
from william.utils.registry import RegistryBundle


def test_flux_combinations():
    cs = Graph(parse_dot_file("propagate/opt12.dot"))
    # cs.render()

    mem0 = NodeValueMap()
    mem0[cs.nodes[0]] = MapEntry(same=True, val=cs.nodes[0].val)
    mem0[cs.nodes[1]] = MapEntry(same=False, val=2.0)
    expected = [
        ("add", (-1, 0)),
        ("negate", (0,)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
        ("add", (0, 1)),
    ]
    for cond_dict in ConditionCombinations.get(cs, mem=mem0):
        assert [(str(key.op), value) for key, value in cond_dict.items()] == expected


params = [
    ("co0", [(), (0,), (1,)]),
    ("co1", [(0, 1), (0, 2), (1, 2)]),
    ("co2", [(), (0, 1, 2), (3, 4, 5)]),
    ("co3", [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]),
    ("co4", [(0, 1), (0, 2), (1, 2)]),
    ("co5", [(0, 1), (0, 2, 3, 4), (1, 2, 3, 4)]),
    ("co6", [(0, 1, 4), (0, 2, 4), (1, 2, 4)]),
    ("co7", [(0,), (1,)]),
    ("co8", [(0, 1), (0, 2, 3, 4)]),
    ("co9", [(4,), (0, 1, 2, 3)]),
    ("co10", [(), (0,), (1,)]),
    ("co11", [(), (3,), (4,), (0, 1, 2)]),
    ("co12", [(), (0,), (1,)]),
    ("co13", [(0, 1, 4), (0, 2, 4), (1, 2, 4)]),
    ("co14", [(1, 2, 3)]),
    ("co16", [(0,)]),
    (
        "co17",
        [
            (
                1,
                2,
                3,
                4,
                5,
            )
        ],
    ),
    ("co18", [(0, 1), (0, 2)]),
    ("co19", [(0,)]),
    ("co20", [(0,)]),
    ("co21", [(0,)]),
    ("dag0", [(0,)]),
    ("dag1", [(0,)]),
    ("dag2", [(0,)]),
    ("dag3", [(0, 1)]),
    ("dag4", [(1,)]),
    ("dag5", [(1,)]),
    ("dag6", [(0,), (1,)]),
]


@pytest.mark.parametrize(["graph_name", "ref"], params, ids=list(map(str, range(len(params)))))
def test_conditions(graph_name, ref):
    root = parse_dot_file("composite/" + graph_name + ".dot")[0]

    comp = Composite(root, name=graph_name)
    assert comp.conditions == ref


@pytest.mark.parametrize(["graph_name", "ref"], params, ids=list(map(str, range(len(params)))))
def test_tree_conditions(graph_name, ref):
    root = parse_dot_file(f"composite/{graph_name}.dot")[0]

    registry = RegistryBundle()
    rust_graph, _ = build_rust_graph_from_root(root, registry)
    op_snapshot = registry.operators.get_rust_snapshot()
    option_ids = rust_graph.get_options(rust_graph.get_root())

    # check update_callable_conditions
    py_conds = update_callable_conditions_py(root.options[0])

    rust_conds = update_callable_conditions(rust_graph, option_ids[0], op_snapshot)
    rust_conds = [tuple(c) for c in rust_conds]
    assert set(rust_conds) == set(py_conds)

    # check tree_conditions
    py_conds = tree_conditions_py(root.options[0])

    rust_conds = tree_conditions(rust_graph, option_ids[0], op_snapshot, True)
    rust_conds = [tuple(c) for c in rust_conds]
    assert set(rust_conds) == set(py_conds)

    # check get_conditions
    py_conds = get_conditions_py(root)
    rust_conds = get_conditions(rust_graph, rust_graph.get_root(), op_snapshot, True)
    rust_conds = [tuple(c) for c in rust_conds]
    assert set(rust_conds) == set(py_conds)


def test_condition_combinations():
    conditions_by_child = [[(0, 1), (2,)], [(0,), (1,)]]
    offset_list = [0, 4]
    actual_py = condition_combinations_py(conditions_by_child, offset_list)
    assert actual_py == [
        (0, 1, 4),
        (0, 1, 5),
        (2, 4),
        (2, 5),
    ]
    actual_rust = condition_combinations(conditions_by_child, offset_list)
    assert [tuple(c) for c in actual_rust] == actual_py


@pytest.mark.parametrize("num", list(range(22)))
def test_conditions_order_by_length(num):
    root = parse_dot_file(f"composite/co{num}.dot")[0]

    comp = Composite(root)
    len_expected = 0
    for cond in comp.conditions:
        len_actual = len(cond)
        assert len_actual >= len_expected
        len_expected = len_actual


params_filter_conditions = [
    ([()], [()]),
    ([(), (1,)], [(), (1,)]),
    ([(1,), ()], [(), (1,)]),
    ([(0, 2), (1,), ()], [(), (1,), (0, 2)]),
    ([(0, 2), (), (3,)], [(), (3,), (0, 2)]),
    ([(0,), (0, 2)], [(0,)]),
    ([(0, 1), (0,)], [(0,)]),
    ([(3,), (0, 2, 3), (1, 3)], [(3,)]),
    ([(0, 2), (2,), (0, 1, 2)], [(2,)]),
    ([(2,), (0, 2), (2,)], [(2,)]),
    ([(2,), (1, 2), (1,)], [(1,), (2,)]),
    ([(3,), (0, 1)], [(3,), (0, 1)]),
    ([(1, 2), (2, 3)], [(1, 2), (2, 3)]),
    ([(0,), (3,), (4,)], [(0,), (3,), (4,)]),
    ([(2,), (1, 2, 4, 5), (5,)], [(2,), (5,)]),
]


@pytest.mark.parametrize("conds, expected_filtered", params_filter_conditions)
def test_filter_conditions(conds, expected_filtered):
    dummy_root = parse_dot_file("composite/co0.dot")[0]
    arity = len(list(dummy_root.leaves()))
    actual_filtered = filter_redundant(conds, arity)
    assert actual_filtered == expected_filtered


params = [
    (((), (0,), (1,)), ((0,), (1,))),
    (((1, 2), (0,), (1, 3, 2), (), (1,)), ((0,), (1, 3, 2))),
]


@pytest.mark.parametrize("conditions, expected", params)
def test_remove_redundant_conditions(conditions, expected):
    assert remove_redundant_conditions(conditions) == expected
