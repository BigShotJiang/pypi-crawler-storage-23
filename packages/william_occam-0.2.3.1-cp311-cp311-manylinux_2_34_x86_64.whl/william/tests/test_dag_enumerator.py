from itertools import islice

from william.dag_enumerator import InputsEnumerator
from william.library.base import Value


def test_inputs_enumerator():
    enumerator = InputsEnumerator(
        {}, free_values={int: [Value(1000, dummy=True), Value(1001, dummy=True)], float: [Value(3.14, dummy=True)]}
    )
    expected_inputs = [
        (1000, 3.14),
        (1001, 3.14),
        (1000, 0.0),
        (0, 3.14),
        (1001, 0.0),
        (0, 0.0),
        (1, 3.14),
        (2, 3.14),
        (1, 0.0),
        (4, 3.14),
        (2, 0.0),
        (8, 3.14),
        (4, 0.0),
        (16, 3.14),
        (8, 0.0),
        (16, 0.0),
    ]
    inputs = []
    for dl, inp in islice(enumerator.iterate([int, float]), 100):
        inpv = tuple(v.value for v in inp)
        inputs.append(inpv)
    assert inputs == expected_inputs
