from itertools import chain

import numpy as np
import pytest

from william.bottleneck import ValueMDL
from william.jbottleneck import JMDL, JAncestors, JGraph, Mediator, Params, RustJMDL
from william.library import Add, Mult, Negate, Sub
from william.nvmap import MapEntry, NodeValueMap
from william.structures.dot_to_graph import parse_dot_file
from william.structures.graphs import Graph
from william.structures.nodes import Node
from william.structures.rustgraph import build_rust_graph_from_root
from william.structures.value_nodes import ValueNode
from william.utils.registry import RegistryBundle

params = [
    ("mult_negate", 8760.879357497288, 0, []),
    ("mult_negate_add", 573.8697633677614, 3, [Add(), Negate(), Mult()]),
    ("section1", 26.280150129207975, 2, [Add(), Sub()]),
    ("section2", 19.954900924594817, 2, [Add(), Sub()]),
    ("section3", 9.664933050786377, 1, [Negate()]),
    ("section4", 22.766942937463458, 2, [Add(), Negate()]),
    ("regression", 19582.338006270023, 4, [Add(), Add(), Add(), Add()]),
    # ('sqrt', 23.438815731952396, 1, [Mult()]),
    # ('vertical_line', 57.111114347676875, 5, [Concat(), BRange(), Zip2D(), Add(), Repeat()]),
    # ('graph_with_cycle', 32.82921659941171, 1, [Sub()]),
    # ('graph_with_cycle2', 1819.3295950683291, 0, []),
    # ('horizontal_line', 31.215255390391825, 2, [Mult(), Add()]),
    # ('big_graph3', 1689.8465886309464, None, []),
    # ('bush1', 464.34154358398956, 1, [Len()]),
]


@pytest.mark.timeout(20)
@pytest.mark.parametrize(
    "graph_name, expected_min_dl, num_ops, exp_sel", params, ids=list(map(str, range(len(params))))
)
def test_min_desc_len(graph_name, expected_min_dl, num_ops, exp_sel):
    roots = parse_dot_file(f"min_desc_len/{graph_name}.dot")
    graph = Graph(roots)
    mdl = ValueMDL(graph)
    min_dl, bn, sel = mdl.min_desc_len(return_bottleneck=True, return_selection=True)

    # set up jit-compiled version
    mem = NodeValueMap()
    for node in graph.walk():
        mem[node] = MapEntry(same=False, val=node.val)

    jmdl = JMDL(graph)
    jmin_dl, jbn_nodes, jsel = jmdl.min_desc_len(return_bottleneck=True, return_selection=True, mem=mem)

    assert abs(min_dl - expected_min_dl) < 1e-6
    assert abs(jmin_dl - expected_min_dl) < 1e-6

    # jit compiled version with rust graph
    if len(roots) == 1:
        registry = RegistryBundle()
        rust_graph, id_map = build_rust_graph_from_root(roots[0], registry)

        mem = NodeValueMap()
        for node in roots[0].walk():
            node_num = id_map[node]
            mem[node_num] = MapEntry(same=False, val=node.val)

        jrmdl = RustJMDL()
        jrmin_dl, jrbn, jrsel = jrmdl.min_desc_len(rust_graph, return_bottleneck=True, return_selection=True, mem=mem)

        assert abs(jrmin_dl - expected_min_dl) < 1e-6

    # bn.render()
    op_dl = 1.0
    assert abs(bn.desc_len() + num_ops * op_dl - min_dl) < 1e-6
    assert set(bn.nodes) == set(jbn_nodes)

    if exp_sel:
        assert all([node.op == exp_op for node, exp_op in zip(sel, exp_sel)])
        assert set(sel) == set(jsel)

    if not sel:
        return
    expected_min_clone = Graph(parse_dot_file(f"min_desc_len/{graph_name}_min_clone.dot"))
    allowed = sel[:]
    for node in sel:
        allowed.extend([node.parent] + node.children)

    allowed = sel + list(chain(*[list(node.neighbors()) for node in sel]))
    min_clone = graph.clone(allowed=allowed)
    assert min_clone.resembles(expected_min_clone)


test_params = Params(
    MAX_OP_NODES=10,
    MAX_VALUE_NODES=10,
    MAX_CHILDREN=4,
    MAX_OPTIONS=20,
    MAX_PARENTS=20,
    MAX_SECTION_LENGTH=10,
    MAX_DEPTH=6,
    MAX_TRACE_LENGTH=20,
)


def test_set_nodes():
    jg = JGraph(test_params)
    # mapping from Python nodes to JIT nodes
    ref = {}

    # new node
    node = Node(Sub())
    ref[node] = jg.n_op
    jg.new_op_node()
    assert jg.n_op == 1

    # new value nodes
    val_node1 = ValueNode(output=30)
    ref[val_node1] = jg.n_val
    jg.new_val_node(val_node1.output_dl())

    val_node2 = ValueNode(output=3.425)
    ref[val_node2] = jg.n_val
    jg.new_val_node(val_node2.output_dl())
    assert jg.n_val == 2

    # set children
    reverse = True
    node.set_child(val_node1, reverse=reverse)
    jg.set_child(ref[node], ref[val_node1], -1, reverse)

    node.set_child(val_node2, reverse=reverse)
    jg.set_child(ref[node], ref[val_node2], -1, reverse)

    assert len(node.children) == 2
    assert jg.n_c[ref[node]] == 2

    assert node.children[0] is val_node1
    assert jg.children[ref[node], 0] == ref[val_node1]

    assert val_node1.parents[0] is node
    assert jg.parents[ref[val_node1], 0] == ref[node]

    assert len(val_node1.parents) == 1
    assert jg.n_p[ref[val_node1]] == 1

    assert val_node2.parents[0] is node
    assert jg.parents[ref[val_node2], 0] == ref[node]

    assert len(val_node2.parents) == 1
    assert jg.n_p[ref[val_node2]] == 1

    # parent
    parent = ValueNode(output="terminator")
    ref[parent] = jg.n_val
    jg.new_val_node(parent.output_dl())
    assert jg.n_val == 3

    # set parent
    parent.set_option(node, reverse=False)
    jg.set_option(ref[parent], ref[node], -1, False)

    assert parent.options[0] is node
    assert jg.options[ref[parent], 0] == ref[node]

    assert node.parent.output.is_none
    assert jg.parent[ref[node]] == -1


params = ["mult_negate", "mult_negate_add", "add_with_cycle"]


@pytest.mark.parametrize("graph_name", params)
def test_graph_to_jgraph(graph_name):
    vn = parse_dot_file(f"min_desc_len/{graph_name}.dot")
    cs = Graph(vn)
    params = JMDL.get_params(cs)
    med = Mediator(params)
    jvn = med.val_node_to_jgraph(vn[0])
    assert med.val_nodes_match(jvn[0], vn[0], set())


def test_ancestors_update():
    """
    A complex test case for a complex algorithm.
    In order to imagine the graph encoded here, take a look at test_graph.jpg (see also graph 'horizontal line' below).
    The node numbers are encircled in the image.
    """
    # warnings.filterwarnings("ignore", message="numpy.ufunc size changed")
    graph = JGraph(test_params)
    graph.parents[1, :2] = [0, 2]
    graph.parents[2, :2] = [0, 1]
    graph.parents[3, 0] = 2
    graph.n_p[:5] = [0, 2, 2, 1, 1]
    graph.parent[:3] = [0, 1, 2]

    depth = 2
    ancs = JAncestors(test_params)
    # keep in mind, that only value nodes are tracked as ancestors
    # only operator 0 has ancestor 0 (number of ancestors=1)
    ancs.op[0, 0] = 0
    # the number of ancestors of operator 0 is seen here n_op[0, depth] == 1
    ancs.n_op[0, :] = [0, 1, 1, 1, 1, 1]
    ancs.val[1, 0] = 0
    ancs.val[2, 0] = 0
    ancs.n_val[1, :] = [0, 1, 1, 1, 1, 1]
    ancs.n_val[2, :] = [0, 1, 1, 1, 1, 1]

    op_sec = -np.ones(test_params.MAX_SECTION_LENGTH, dtype=np.int32)
    op_sec[:2] = [1, 2]
    n_op = 2
    ancs.update_op(graph, op_sec, n_op, depth)
    # now op nodes 1 and 2 (the ones in the op_sec), have ancestors [1,0] and [2,0] respectively
    np.testing.assert_array_equal(ancs.op[1, :2], np.array([1, 0]))  # before it was [0]
    np.testing.assert_array_equal(ancs.op[2, :2], np.array([2, 0]))  # before it was [0]
    # the number of ancestors of those op nodes has grown to 2 accordingly: n_op[1, depth] == 2, n_op[2, depth] == 2
    np.testing.assert_array_equal(ancs.n_op[1, :], np.array([0, 0, 2, 2, 2, 2]))
    np.testing.assert_array_equal(ancs.n_op[2, :], np.array([0, 0, 2, 2, 2, 2]))

    # ----------- node 1
    # when the child of a new op node is an already seen node, updated this seen node's ancestors by
    # the ancestors of the op node
    node = 1
    child = 2
    np.testing.assert_array_equal(ancs.val[child, : ancs.n_val[child, depth]], [0])
    # now update
    ancs.val_extend_trace(child, node, False, depth)
    # the val node 1 is now among node 2's ancestors
    np.testing.assert_array_equal(ancs.val[child, : ancs.n_val[child, depth]], [0, 1])

    # however this new ancestor (val node 1) is also the ancestor of all descendants of val node 2,
    # such as op node 2 (the children of op nodes 2 (val nodes 1 and 3) will be updated later)
    np.testing.assert_array_equal(ancs.op[2, : ancs.n_op[2, depth]], [2, 0])
    ancs.add_to_all_other_nodes(child, node, op_sec[:n_op], depth)
    np.testing.assert_array_equal(ancs.op[2, : ancs.n_op[2, depth]], [2, 0, 1])
    # now a cycle can be recognized, since node 2's child 1 is among the node's ancestors:
    assert 1 in ancs.op[2, : ancs.n_op[2, depth]]

    # ------------ node 2
    # when the child of a new op node is an already seen node, updated this seen node's ancestors by
    # the ancestors of the op node
    node = 2
    child = 1
    np.testing.assert_array_equal(ancs.val[child, : ancs.n_val[child, depth]], [0])
    # now update
    ancs.val_extend_trace(child, node, False, depth)
    # the val nodes 1 and 2 is now among val node 1's ancestors
    np.testing.assert_array_equal(ancs.val[child, : ancs.n_val[child, depth]], [0, 2, 1])

    # however this new ancestor (val node 1) is also the ancestor of all descendants of val node 2,
    # such as op node 2 (the children of op nodes 2 (val nodes 1 and 3) will be updated later)
    np.testing.assert_array_equal(ancs.op[1, : ancs.n_op[1, depth]], [1, 0])
    ancs.add_to_all_other_nodes(child, node, op_sec[:n_op], depth)
    # ancs.add_to_all_descendants(child, 5, 5, depth)
    np.testing.assert_array_equal(ancs.op[1, : ancs.n_op[1, depth]], [1, 0, 2])
