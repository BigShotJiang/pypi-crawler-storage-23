import os

import pytest

from william.library import geometry_ops
from william.structures import Graph
from william.structures.dot_to_graph import parse_dot_file

try:
    import graphviz
except ImportError:
    graphviz = None


@pytest.mark.skipif(not graphviz, reason="could not import graphviz")
@pytest.mark.skipif(os.getenv("CI") == "true", reason="Skipping visual test in CI")
def test_loading_rendering_saving(tmp_path):
    # old-version, value stored plainly in the label
    root = Graph(parse_dot_file("matching/add_ff.dot", ops=geometry_ops))
    root.render(filename=tmp_path / "test", view=False)

    # containing JSON values
    root = Graph(parse_dot_file("json_values.dot"))
    root.render(filename=tmp_path / "test", view=False)


def test_graph_name():
    root = Graph(parse_dot_file("composite/trees3.dot"))
    expected = "zip2d(concat(x0->repeat(None, None), x1->brange(None, None)), concat(x1, x0))"
    assert root.nodes[0].graph_name() == expected


def test_hyper_graph(tmp_path):
    graph = Graph(parse_dot_file("hyper0.dot"))
    graph.save(tmp_path / "hyper0_out.dot")
    graph_reloaded = Graph(parse_dot_file(tmp_path / "hyper0_out.dot"))
    assert graph_reloaded.resembles(graph)

    # load something else that has the same graph structure, but the composites are different inside
    different_graph = Graph(parse_dot_file("hyper1.dot"))
    assert not different_graph.resembles(graph)
