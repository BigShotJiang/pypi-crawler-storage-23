"""
Accelerated minimum description length computation with Numba
"""

from collections import namedtuple

import numba as nb
import numpy as np
from numba.experimental import jitclass

from william.library.description import desc_len
from william.nvmap import NodeValueMap
from william.structures.graphs import Graph
from william.structures.nodes import Node
from william.structures.rustgraph import RustGraph
from william.structures.value_nodes import ValueNode

my_jit, my_jitclass = nb.jit, jitclass  # the real jit
# dummy decorators for testing without numba
# def my_jit(*args, **kwargs):
#     def wrapper(func):
#         return func
#     return wrapper


# def my_jitclass(spec):
#     def wrapper(cls):
#         return cls
#     return wrapper

Params = namedtuple(
    "Params",
    "MAX_OP_NODES MAX_VALUE_NODES MAX_CHILDREN MAX_OPTIONS MAX_PARENTS MAX_SECTION_LENGTH MAX_DEPTH MAX_TRACE_LENGTH",
)
Tmp = namedtuple("Tmp", "idx val_sec op_sec bottleneck selection seen ancs")


class JMDL:
    def __init__(self, graph: Graph, params=None):
        self.root = graph
        p = params or self.get_params(graph)
        self.med = Mediator(p)
        nodes = graph.nodes
        self.med.val_node_to_jgraph(nodes)
        self.jsection = self.med.section_to_jsection(nodes, p)
        self.jsection_len = len(nodes)
        self.tmp = Tmp(
            idx=np.zeros((p.MAX_DEPTH, p.MAX_SECTION_LENGTH), dtype=np.int32),
            val_sec=-np.ones((p.MAX_DEPTH, p.MAX_SECTION_LENGTH), dtype=np.int32),
            op_sec=-np.ones((p.MAX_DEPTH, p.MAX_SECTION_LENGTH), dtype=np.int32),
            bottleneck=AWL((p.MAX_DEPTH + 1, p.MAX_SECTION_LENGTH), -1),
            selection=AWL((p.MAX_DEPTH + 1, p.MAX_OP_NODES), -1),
            seen=np.zeros((p.MAX_DEPTH, p.MAX_VALUE_NODES), dtype=np.bool_),
            ancs=JAncestors(p),
        )
        self.flush()

    @staticmethod
    def get_params(root: Graph):
        num_val_nodes = 0
        num_options = 0
        num_op_nodes = 0
        num_children = 0
        num_parents = 0
        nodes = list(root.walk())
        for node in nodes:
            if node.is_val_node:
                num_val_nodes += 1
                if len(node.options) > num_options:
                    num_options = len(node.options)
                if len(node.parents) > num_parents:
                    num_parents = len(node.parents)
            else:
                num_op_nodes += 1
                if len(node.children) > num_children:
                    num_children = len(node.children)
        max_section_length = len(nodes)
        params = Params(
            MAX_OP_NODES=num_op_nodes,
            MAX_VALUE_NODES=num_val_nodes,
            MAX_CHILDREN=num_children,
            MAX_OPTIONS=num_options,
            MAX_PARENTS=num_parents,
            MAX_SECTION_LENGTH=max_section_length,
            MAX_DEPTH=len(nodes),
            MAX_TRACE_LENGTH=len(nodes) * 10,
        )
        return params

    def flush(self):
        self.tmp.idx[:, :] = 0
        self.tmp.val_sec[:, :] = -1
        self.tmp.op_sec[:, :] = -1
        self.tmp.bottleneck.flush(-1, -1)
        self.tmp.selection.flush(-1, -1)
        self.tmp.seen[:, :] = False
        self.tmp.ancs.flush()
        for node in self.jsection[: self.jsection_len]:
            self.tmp.seen[0, node] = True
        self.tmp.val_sec[0, :] = self.jsection

    def min_desc_len(self, return_bottleneck=False, return_selection=False, mem=None):
        self.flush()
        self.med.mem_to_jmem(mem, self.root)
        min_dl = val_min_dl(self.med.graph, self.tmp, self.jsection_len, self.med.jmem, 0)

        result = min_dl
        if return_bottleneck:
            bottleneck = [self.med.jval_to_val[n] for n in self.tmp.bottleneck.con[0, : self.tmp.bottleneck.len[0]]]
            result = (min_dl, bottleneck)
        if return_selection:
            result = result if isinstance(result, tuple) else (result,)
            sel = [self.med.jop_to_op[n] for n in self.tmp.selection.con[0, : self.tmp.selection.len[0]]]
            result += (sel,)
        return result


class RustJMDL(JMDL):
    def __init__(self):
        num_nodes = 100
        self.params = Params(
            MAX_OP_NODES=num_nodes,
            MAX_VALUE_NODES=num_nodes,
            MAX_CHILDREN=10,
            MAX_OPTIONS=1,
            MAX_PARENTS=num_nodes,
            MAX_SECTION_LENGTH=num_nodes,
            MAX_DEPTH=num_nodes,
            MAX_TRACE_LENGTH=num_nodes * 10,
        )
        # self.med = RustMediator(self.params)
        self.tmp = Tmp(
            idx=np.zeros((self.params.MAX_DEPTH, self.params.MAX_SECTION_LENGTH), dtype=np.int32),
            val_sec=-np.ones((self.params.MAX_DEPTH, self.params.MAX_SECTION_LENGTH), dtype=np.int32),
            op_sec=-np.ones((self.params.MAX_DEPTH, self.params.MAX_SECTION_LENGTH), dtype=np.int32),
            bottleneck=AWL((self.params.MAX_DEPTH + 1, self.params.MAX_SECTION_LENGTH), -1),
            selection=AWL((self.params.MAX_DEPTH + 1, self.params.MAX_OP_NODES), -1),
            seen=np.zeros((self.params.MAX_DEPTH, self.params.MAX_VALUE_NODES), dtype=np.bool_),
            ancs=JAncestors(self.params),
        )
        self.jsection = -np.ones(self.params.MAX_SECTION_LENGTH, dtype=np.int32)
        self.jsection_len = 1
        self.flush()
        self.med = RustMediator(self.params)

    def min_desc_len(self, root: RustGraph, return_bottleneck=False, return_selection=False, mem=None):
        nodes = [root.get_root()]
        self.med.clear()
        self.med.val_node_to_jgraph(root, nodes)
        self.jsection_len = len(nodes)
        self.med.section_to_jsection(nodes, self.jsection)
        self.flush()
        self.med.mem_to_jmem(mem, root)
        min_dl = val_min_dl(self.med.graph, self.tmp, self.jsection_len, self.med.jmem, 0)

        result = min_dl
        if return_bottleneck:
            bottleneck = [self.med.jval_to_val[n] for n in self.tmp.bottleneck.con[0, : self.tmp.bottleneck.len[0]]]
            result = (min_dl, bottleneck)
        if return_selection:
            result = result if isinstance(result, tuple) else (result,)
            sel = [self.med.jop_to_op[n] for n in self.tmp.selection.con[0, : self.tmp.selection.len[0]]]
            result += (sel,)
        return result


spec = [
    ("con", nb.int32[:, :]),
    ("len", nb.int32[:]),
]


@my_jitclass(spec)
class AWL:
    """Array with length treatment"""

    def __init__(self, shape, default):
        self.con = np.ones(shape, dtype=np.int32)
        self.con[:, :] = default
        self.len = np.zeros(shape[0], dtype=np.int32)

    def flush(self, default, row):
        if row == -1:
            self.con[:, :] = default
            self.len[:] = 0
        else:
            self.con[row, :] = default
            self.len[row] = 0

    def add(self, value, row):
        self.con[row, self.len[row]] = value
        self.len[row] += 1

    def append(self, values, idx, row):
        for i in range(len(values)):
            self.con[row, idx] = values[i]
            idx += 1
        self.len[row] = idx


spec = [
    ("op", nb.int32[:, :]),
    ("n_op", nb.int32[:, :]),
    ("val", nb.int32[:, :]),
    ("n_val", nb.int32[:, :]),
]


@my_jitclass(spec)
class JAncestors:
    def __init__(self, p):
        # op[i, j] is j-th ancestor of op_node i
        self.op = -np.ones((p.MAX_OP_NODES, p.MAX_TRACE_LENGTH), dtype=np.int32)
        # n_op[i, d] is the number of ancestors of op_node i at depth d
        self.n_op = np.zeros((p.MAX_OP_NODES, p.MAX_DEPTH), dtype=np.int32)

        # val[i, j] is j-th ancestor of val_node i
        self.val = -np.ones((p.MAX_VALUE_NODES, p.MAX_TRACE_LENGTH), dtype=np.int32)
        # n_val[i, d] is the number of ancestors of val_node i at depth d
        self.n_val = np.zeros((p.MAX_VALUE_NODES, p.MAX_DEPTH), dtype=np.int32)

    def flush(self):
        self.op[:, :] = -1
        self.n_op[:, :] = 0
        self.val[:, :] = -1
        self.n_val[:, :] = 0

    def update_val(self, graph, val_section, n_val, d):
        for i in range(n_val):
            val_node = val_section[i]
            num_parents = graph.n_p[val_node]
            if num_parents == 0:
                continue
            self.n_val[val_node, d:] = self.n_val[val_node, d - 1]
            for j in range(num_parents):
                self.val_extend_trace(val_node, graph.parents[val_node, j], False, d)

    def update_op(self, graph, op_section, n_op, d):
        for i in range(n_op):
            node = op_section[i]
            self.op_extend_trace(node, graph.parent[node], d, d - 1)

    def val_extend_trace(self, target, source, is_value_node, depth):
        """Add all ancestors of the source to the ancestors of target."""
        if is_value_node:
            source_iter = self.val[source, : self.n_val[source, depth]]
        else:
            source_iter = self.op[source, : self.n_op[source, depth]]
        n_val = self.n_val[target, depth]
        for ancs in source_iter:
            n_val = self._append_val(ancs, target, n_val)
        self.n_val[target, depth:] = n_val

    def op_extend_trace(self, target, source, target_depth, source_depth):
        """Add all ancestors of the source including source itself to the ancestors of target."""
        n_op = self.n_op[target, target_depth]
        n_op = self._append_op(source, target, n_op)
        for ancs in self.val[source, : self.n_val[source, source_depth]]:
            n_op = self._append_op(ancs, target, n_op)
        self.n_op[target, target_depth:] = n_op

    def _append_val(self, val_node, target, n_val):
        if not isin(val_node, self.val[target, :n_val]):
            self.val[target, n_val] = val_node
            n_val += 1
        return n_val

    def _append_op(self, node, target, n_op):
        if not isin(node, self.op[target, :n_op]):
            self.op[target, n_op] = node
            n_op += 1
        return n_op

    def add_to_all_other_nodes(self, child, node, op_sec, d):
        # go through all other nodes in the section,...
        for other_node in op_sec:
            if other_node == node:
                continue
            # if the child is an ancestor of some of them...
            if isin(child, self.op[other_node, : self.n_op[other_node, d]]):
                # then append the node's ancestors to the other node's ancestors.
                self.op_extend_trace(other_node, child, d, d)

    def clean(self, d):
        """
        Assume that the numbers of ancestors remain the same as at depth d for all higher depths,
        which, however will change in the runtime of the algorithm.
        """
        for i in range(d + 1, self.n_val.shape[1]):
            self.n_val[:, i] = self.n_val[:, d]
            self.n_op[:, i] = self.n_op[:, d]


@my_jit(nopython=True)
def val_min_dl(graph, tmp, n_val, jmem, d):
    """
    :param graph: jitted node graph
    :param tmp: all sorts of temporary variables, ancestors, seen etc.
    :param n_val: length of the value section
    :param d: recursion depth
    """
    tmp.ancs.update_val(graph, tmp.val_sec[d, :], n_val, d)
    bn_len, sel_len = tmp.bottleneck.len[d], tmp.selection.len[d]
    min_dl = 1.0e16
    tmp.idx[d, :] = 0
    while tmp.idx[d, 0] != -1:
        tmp.ancs.clean(d)
        tmp.bottleneck.flush(-1, d + 1)
        tmp.selection.flush(-1, d + 1)
        leaves_dl, n_op = _option_comb(
            graph, tmp.val_sec[d, :], n_val, tmp.op_sec[d, :], tmp.idx[d, :], tmp.bottleneck, d, jmem
        )
        op_dl = 0.0
        if n_op > 0:
            op_dl = op_min_dl(graph, tmp, n_op, jmem, d + 1)
        dl = op_dl + leaves_dl

        if dl < min_dl:
            tmp.bottleneck.append(tmp.bottleneck.con[d + 1, : tmp.bottleneck.len[d + 1]], bn_len, d)
            tmp.selection.append(tmp.selection.con[d + 1, : tmp.selection.len[d + 1]], sel_len, d)
            min_dl = dl

        _index_step(tmp.idx[d, :], graph, tmp.val_sec[d, :], n_val)
    return min_dl


@my_jit(nopython=True)
def _option_comb(graph, val_section, n_val, op_section, idx, bottleneck, d, jmem):
    leaves_dl = 0.0
    n_op = 0
    for i in range(n_val):
        node = val_section[i]
        if idx[i] == 0:
            bottleneck.add(node, d + 1)
            leaves_dl += _get_dl(graph.dl, jmem.dl, node)
            continue
        option = graph.options[node, idx[i] - 1]
        op_section[n_op] = option
        n_op += 1
        if not jmem.op[option]:  # option not in mem -> skip to next combination
            return 1.0e16, 0
    return leaves_dl, n_op


@my_jit(nopython=True)
def _index_step(idx, graph, val_section, n_val):
    """
    A mechanism to step through the iterator itertools.product([0,1,..,n0], [0,1,..,n1],..),
    for example, let n0=1 and n1=2. Then [0,0] is incremented to [0,1], [0,2], [1,0], [1,1] and finally to [1,2].
    """
    for i in range(n_val - 1, -1, -1):
        # yes, idx is allowed to reach the number of options n_o, since idx refers to the option number idx-1,
        # and idx=0 refers to the value node itself (dummy node on the pure Python implementation)
        if idx[i] < graph.n_o[val_section[i]]:
            idx[i] += 1
            idx[i + 1 :] = 0
            return
    idx[:] = -1


@my_jit(nopython=True)
def op_min_dl(graph, tmp, n_op, jmem, d):
    tmp.op_sec[d, :] = tmp.op_sec[d - 1, :]
    tmp.seen[d, :] = tmp.seen[d - 1, :]
    tmp.ancs.update_op(graph, tmp.op_sec[d, :], n_op, d)

    n_val = 0
    dl = 0.0
    for i in range(n_op):
        node = tmp.op_sec[d, i]
        tmp.selection.add(node, d)

        _join_ancestors(graph, node, tmp.op_sec[d, :n_op], tmp.seen[d, :], tmp.ancs, d)

        n_val, ddl = _read_children(
            graph, node, tmp.val_sec[d, :], n_val, tmp.seen[d, :], tmp.ancs, tmp.bottleneck, d, jmem
        )
        dl += ddl

    if n_val > 0:
        dl += val_min_dl(graph, tmp, n_val, jmem, d)
    return dl


@my_jit(nopython=True)
def _read_children(graph, node, val_section, n_val, seen, ancs, bottleneck, d, jmem):
    if graph.n_c[node] == 0:
        bottleneck.add(graph.parent[node], d)
        return n_val, _get_dl(graph.dl, jmem.dl, graph.parent[node])

    ddl = 1.0  # the description length of an operator
    for j in range(graph.n_c[node]):
        child = graph.children[node, j]
        if isin(child, ancs.op[node, : ancs.n_op[node, d]]):  # cycle detected
            bottleneck.add(child, d)
            ddl += _get_dl(graph.dl, jmem.dl, child)
        if seen[child]:
            continue
        seen[child] = True
        val_section[n_val] = child
        n_val += 1
    return n_val, ddl


@my_jit(nopython=True)
def _join_ancestors(graph, node, op_sec, seen, ancs, d):
    for j in range(graph.n_c[node]):
        child = graph.children[node, j]
        if not seen[child]:
            continue
        # attach all of node's ancestors to the child's ancestors...
        ancs.val_extend_trace(child, node, False, d)
        # ...and to all of the other nodes in the op section, if the child is an ancestor (yeah, it's complicated)
        ancs.add_to_all_other_nodes(child, node, op_sec, d)


@my_jit(nopython=True)
def _get_dl(default_dl, mem_dl, node):
    x = mem_dl[node]
    return default_dl[node] if x == -1 else x


@nb.jit(fastmath=True, nopython=True)
def isin(element, array1d):
    for i in range(len(array1d)):
        if array1d[i] == element:
            return True
    return False


spec = [
    ("n_op", nb.int32),
    ("n_val", nb.int32),
    ("children", nb.int32[:, :]),
    ("n_c", nb.int32[:]),
    ("parent", nb.int32[:]),
    ("options", nb.int32[:, :]),
    ("n_o", nb.int32[:]),
    ("parents", nb.int32[:, :]),
    ("n_p", nb.int32[:]),
    ("dl", nb.float64[:]),
]


@my_jitclass(spec)
class JGraph:
    def __init__(self, p):
        self.n_op = 0
        self.n_val = 0

        # children[i, j] is the index of the j-th child of op_node i
        self.children = -np.ones((p.MAX_OP_NODES, p.MAX_CHILDREN), dtype=np.int32)
        # n_c[i] is the number of children of op_node i
        self.n_c = np.zeros(p.MAX_OP_NODES, dtype=np.int32)

        # op_nodes only have a single parent
        self.parent = -np.ones(p.MAX_OP_NODES, dtype=np.int32)

        self.options = -np.ones((p.MAX_VALUE_NODES, p.MAX_OPTIONS), dtype=np.int32)
        self.n_o = np.zeros(p.MAX_VALUE_NODES, dtype=np.int32)  # number of options

        self.parents = -np.ones((p.MAX_VALUE_NODES, p.MAX_PARENTS), dtype=np.int32)
        self.n_p = np.zeros(p.MAX_VALUE_NODES, dtype=np.int32)  # number of parents

        self.dl = -np.ones(p.MAX_VALUE_NODES, dtype=np.float64)

    def flush(self):
        self.n_op = 0
        self.n_val = 0
        self.children[:, :] = -1
        self.n_c[:] = 0
        self.parent[:] = -1
        self.options[:, :] = -1
        self.n_o[:] = 0
        self.parents[:, :] = -1
        self.n_p[:] = 0
        self.dl[:] = -1

    def new_val_node(self, dl):
        self.dl[self.n_val] = dl
        self.n_val += 1

    def new_op_node(self):
        self.n_op += 1

    def set_child(self, op_node, child_node, num, reverse):
        if num < 0:
            num = self.n_c[op_node]
            self.n_c[op_node] += 1
        self.children[op_node, num] = child_node
        if not reverse:
            return
        n_p = self.n_p[child_node]
        if np.any(self.parents[child_node, :n_p] == op_node):
            return
        self.parents[child_node, self.n_p[child_node]] = op_node
        self.n_p[child_node] += 1

    def set_parents(self, val_node, parent_node, num, reverse):
        if num < 0:
            num = self.n_p[val_node]
            self.n_p[val_node] += 1
        self.parents[val_node, num] = parent_node
        if not reverse:
            return
        n_c = self.n_c[parent_node]
        if np.any(self.children[parent_node, :n_c] == val_node):
            return
        self.children[parent_node, self.n_c[parent_node]] = val_node
        self.n_c[parent_node] += 1

    def set_option(self, val_node, option, num, reverse):
        if num < 0:
            num = self.n_o[val_node]
            self.n_o[val_node] += 1
        self.options[val_node, num] = option
        if not reverse:
            return
        self.parent[option] = val_node

    def set_parent(self, op_node, parent, reverse):
        self.parent[op_node] = parent
        if not reverse:
            return
        n_o = self.n_o[parent]
        if np.any(self.options[parent, :n_o] == op_node):
            return
        self.options[parent, self.n_o[parent]] = op_node
        self.n_o[parent] += 1


spec = [("op", nb.bool_[:]), ("val", nb.bool_[:]), ("dl", nb.float64[:])]


@my_jitclass(spec)
class JMem:
    """The mem storing the nodes affected by propagation and their respective description lengths."""

    def __init__(self, num_op, num_val):
        self.op = np.ones(num_op, dtype=np.bool_)
        self.val = np.ones(num_val, dtype=np.bool_)
        self.dl = -np.ones(num_val, dtype=np.float64)

    def flush(self, op_def, val_def, dl_def):
        self.op[:] = op_def
        self.val[:] = val_def
        self.dl[:] = dl_def


class Mediator:
    """Mediates between the jit and pure Python implementations."""

    def __init__(self, params, graph=None):
        self.graph = graph or JGraph(params)
        self.ref = {}
        self.jval_to_val = {}
        self.jop_to_op = {}
        self.jmem = JMem(params.MAX_OP_NODES, params.MAX_VALUE_NODES)

    def node_to_jgraph(self, node):
        if node in self.ref:
            return
        jnode = self.new_op_node(node)
        self.jop_to_op[jnode] = node

        for child in node.children:
            self._val_node_to_jgraph(child)
            self.graph.set_child(jnode, self.ref[child], -1, False)

        self._val_node_to_jgraph(node.parent)
        self.graph.set_parent(jnode, self.ref[node.parent], False)
        return jnode

    def val_node_to_jgraph(self, val_nodes):
        if not isinstance(val_nodes, list):
            val_nodes = [val_nodes]
        return [self._val_node_to_jgraph(val_node) for val_node in val_nodes]

    def _val_node_to_jgraph(self, val_node):
        if val_node in self.ref:
            return
        jval_node = self.new_val_node(val_node)
        self.jval_to_val[jval_node] = val_node

        for option in val_node.options:
            self.node_to_jgraph(option)
            self.graph.set_option(jval_node, self.ref[option], -1, False)

        for parent in val_node.parents:
            self.node_to_jgraph(parent)
            self.graph.set_parents(jval_node, self.ref[parent], -1, False)
        return jval_node

    def new_val_node(self, val_node):
        idx = self.graph.n_val
        self.ref[val_node] = idx
        self.graph.new_val_node(val_node.output_dl(allow_none=True))
        return idx

    def new_op_node(self, node):
        idx = self.graph.n_op
        self.ref[node] = idx
        self.graph.new_op_node()
        return idx

    def op_nodes_match(self, jnode, node, seen):
        if jnode in seen:
            return True
        seen.add(jnode)
        children = self.graph.children[jnode, : self.graph.n_c[jnode]]
        downward = self._match_check(children, node.children, seen, self.val_nodes_match)
        parent = self.graph.parent[jnode]
        upward = self._match_check([parent], [node.parent], seen, self.val_nodes_match)
        return upward and downward

    def val_nodes_match(self, jnode, node, seen):
        if jnode in seen:
            return True
        seen.add(jnode)
        options = self.graph.options[jnode, : self.graph.n_o[jnode]]
        downward = self._match_check(options, node.options, seen, self.op_nodes_match)
        parents = self.graph.parents[jnode, : self.graph.n_p[jnode]]
        upward = self._match_check(parents, node.parents, seen, self.op_nodes_match)
        return upward and downward

    @staticmethod
    def _match_check(nodes1, nodes2, seen, match):
        return len(nodes1) == len(nodes2) and all(match(n1, n2, seen) for n1, n2 in zip(nodes1, nodes2))

    def section_to_jsection(self, section_nodes, params):
        sec = -np.ones(params.MAX_SECTION_LENGTH, dtype=np.int32)
        for i, node in enumerate(section_nodes):
            sec[i] = self.ref[node]
        return sec

    def mem_to_jmem(self, mem, *args):
        if mem is None:
            self.jmem.flush(True, True, -1)
            return
        self.jmem.flush(False, False, -1)
        for node, entry in mem.items():
            idx = self.ref[node]
            if isinstance(node, ValueNode):
                self.jmem.val[idx] = True
                if not entry.same:
                    self.jmem.dl[idx] = entry.val.desc_len()
            if isinstance(node, Node):
                self.jmem.op[idx] = True


class RustMediator(Mediator):
    def __init__(self, params):
        self.graph = JGraph(params)
        self.ref = {}
        self.jval_to_val = {}
        self.jop_to_op = {}
        self.jmem = JMem(params.MAX_OP_NODES, params.MAX_VALUE_NODES)

    def clear(self):
        self.graph.flush()
        self.ref.clear()
        self.jval_to_val.clear()
        self.jop_to_op.clear()
        self.jmem.flush(True, True, -1)

    def node_to_jgraph(self, root: RustGraph, node: int):
        if node in self.ref:
            return
        jnode = self.new_op_node(node)
        self.jop_to_op[jnode] = node

        for child in root.get_children(node):
            self._val_node_to_jgraph(root, child)
            self.graph.set_child(jnode, self.ref[child], -1, False)

        self._val_node_to_jgraph(root, root.get_parent(node))
        self.graph.set_parent(jnode, self.ref[root.get_parent(node)], False)
        return jnode

    def val_node_to_jgraph(self, root: RustGraph, val_nodes: int | list[int]):
        if not isinstance(val_nodes, list):
            val_nodes = [val_nodes]
        return [self._val_node_to_jgraph(root, val_node) for val_node in val_nodes]

    def _val_node_to_jgraph(self, root: RustGraph, val_node: int):
        if val_node in self.ref:
            return
        jval_node = self.new_val_node(val_node)
        self.jval_to_val[jval_node] = val_node

        for option in root.get_options(val_node):
            self.node_to_jgraph(root, option)
            self.graph.set_option(jval_node, self.ref[option], -1, False)

        for parent in root.get_parents(val_node):
            self.node_to_jgraph(root, parent)
            self.graph.set_parents(jval_node, self.ref[parent], -1, False)
        return jval_node

    def new_val_node(self, val_node: int):
        idx = self.graph.n_val
        self.ref[val_node] = idx
        self.graph.new_val_node(1.0)
        return idx

    def new_op_node(self, node: int):
        idx = self.graph.n_op
        self.ref[node] = idx
        self.graph.new_op_node()
        return idx

    def op_nodes_match(self, root: RustGraph, jnode: int, node: int, seen: set):
        if jnode in seen:
            return True
        seen.add(jnode)
        children = self.graph.children[jnode, : self.graph.n_c[jnode]]
        downward = self._match_check(root, children, root.get_children(node), seen, self.val_nodes_match)
        parent = self.graph.parent[jnode]
        upward = self._match_check(root, [parent], [root.parent(node)], seen, self.val_nodes_match)
        return upward and downward

    def val_nodes_match(self, root: RustGraph, jnode: int, node: int, seen: set):
        if jnode in seen:
            return True
        seen.add(jnode)
        options = self.graph.options[jnode, : self.graph.n_o[jnode]]
        downward = self._match_check(root, options, root.get_options(node), seen, self.op_nodes_match)
        parents = self.graph.parents[jnode, : self.graph.n_p[jnode]]
        upward = self._match_check(root, parents, root.get_parents(node), seen, self.op_nodes_match)
        return upward and downward

    @staticmethod
    def _match_check(root: RustGraph, nodes1: list[int], nodes2: list[int], seen: set, match):
        return len(nodes1) == len(nodes2) and all(match(root, n1, n2, seen) for n1, n2 in zip(nodes1, nodes2))

    def section_to_jsection(self, section_nodes, jsection):
        for i, node in enumerate(section_nodes):
            jsection[i] = self.ref[node]

    def mem_to_jmem(self, mem: NodeValueMap | None, root: RustGraph):
        if mem is None:
            self.jmem.flush(True, True, -1)
            return
        self.jmem.flush(False, False, -1)
        for node, entry in mem.items():
            idx = self.ref[node]
            if root.is_value_node(node):
                self.jmem.val[idx] = True
                if not entry.same:
                    self.jmem.dl[idx] = desc_len(entry.val)
            else:
                self.jmem.op[idx] = True
