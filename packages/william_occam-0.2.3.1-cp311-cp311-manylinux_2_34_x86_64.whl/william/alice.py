import os
import sys
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from itertools import chain
from time import time
from typing import Any

import numpy as np

from william.library.base import Operator, Value
from william.library.description import jelias
from william.library.precision import recursive_match
from william.library.types import specify
from william.nvmap import MapEntry, NodeValueMap
from william.propagation import RandomPropagation
from william.propagation_py import RandomPropagation as RandomPropagationPy
from william.structures import Graph, ValueNode
from william.structures.rustgraph import build_root_from_rust_graph
from william.structures.sexpr_to_graph import build_graph, operator_from_string
from william.utils import debugger, dispdots, set_trace_up
from william.utils.helpers import memory_usage
from william.utils.registry import RegistryBundle
from william.wunderbaum import SpeedyWunderbaum, Wunderbaum

project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "hyperon", "MORK", "python"))
if project_root not in sys.path:
    sys.path.append(project_root)

try:
    from client import MORK  # type: ignore
except ImportError:
    MORK = None
    print("MORK client not available, skipping related tests.")


@dataclass
class CompressionTask:
    __slots__ = ("targets", "threshold_rate", "name", "solutions")

    def __init__(
        self,
        targets: list[Any],
        threshold_rate: float | None = None,
        name: str = "",
        solutions: dict[int, str] | None = None,
    ):
        self.targets = targets
        self.threshold_rate = threshold_rate or 100.0
        self.name = name
        self.solutions = solutions or {}

    def __str__(self):
        s = f"name={self.name}, "
        for target in self.targets:
            s += f"target_len={len(target) if hasattr(target, '__len__') else 'NA'} "
        s += f"and threshold_rate={self.threshold_rate}"
        return s


class TaskDomain:
    def __init__(self, name: str, tasks: list[CompressionTask], op_classes: list[Operator]):
        self.name = name
        self.tasks = tasks
        # set operators with suitable description length
        self.op_dl = np.ceil(jelias(len(op_classes)))
        self.operators = [op_class(dl=self.op_dl) for op_class in op_classes]

    def __str__(self):
        return f"Domain {self.name} with {len(self.operators)} operators"


class GreedyAlice:
    """Greedy ALgorithm for Incremental ComprEssion (ALICE)."""

    def __init__(
        self,
        task_domain: TaskDomain,
        min_rate: float = 0.01,
        max_dag_dl: float = float("inf"),
        max_prop_num: int = 100000,
        level: int | None = None,
        erase_memory: bool = True,
        learn: bool = False,
        trees_only: bool = True,
        speedy: bool = True,
    ):
        self.task_domain = task_domain
        self.min_rate = min_rate
        self.max_dag_dl = max_dag_dl
        self.max_prop_num = max_prop_num
        self.dag_cond_nums = []
        self.propagation_nums = []

        self.prop_class_py = RandomPropagationPy(partial=False, cache=False)

        self.learn = learn

        # initialize MORK client and upload elements
        self.mork = None
        if learn:
            # self.mork = MORK("http://127.0.0.1:8000")
            # if erase_memory:
            #     self.mork.clear()
            # sexprs = []
            # for op in self.task_domain.operators:
            #     for elem, _ in elements_from_operator(op):
            #         sexprs.append(elem.to_sexpr())
            # joined_sexprs = "\n".join(sexprs)
            # self.mork.upload_(joined_sexprs)
            raise NotImplementedError("MORK integration is not implemented in this version.")

        self.level = level if level is not None else int(os.environ.get("WILLIAM_DEBUG", 0))
        self.trees_only = trees_only
        self.speedy = speedy

    def run(self):
        t0 = time()
        for i, task in enumerate(self.task_domain.tasks):
            debugger(self.level, {1: f"\nStarting task {i} with {task}"}, color="green")
            self.run_task(task)

        debugger(
            self.level,
            {1: f"Total time for domain {self.task_domain.name}: ({time() - t0:.2f} seconds)"},
            color="green",
        )

    def run_task(
        self,
        task: CompressionTask,
        worthy_dl: float = 200.0,
    ):
        nodes = []
        for k, target in enumerate(task.targets):
            node = ValueNode(output=Value(target, permeable=False, spec=specify(target), name=f"target{k}"))
            nodes.append(node)
        graph = Graph(nodes, prediction=True)

        org_dl = graph.leaves_dl()
        leaves = graph.nodes[:]
        steps = 0
        t0 = time()
        while leaves:
            # sort leaves by their description length in reverse order
            if steps > 0:
                leaves.sort(key=lambda r: r.leaves_dl(), reverse=True)
            cur_leaf = leaves[0]

            # don't try to compress too short stuff
            if cur_leaf.output_dl() < worthy_dl:
                break
            debugger(
                self.level,
                {
                    1: f"{steps}",
                    2: f"\nStep {steps}\nTrying to compress sequence (dl={cur_leaf.output_dl():.2f}):\n{cur_leaf.output.value}\n",
                },
                color="cyan",
            )
            if self.level >= 2:
                cur_leaf.render(view=False)
                cur_leaf.clone_and_unpack().render(filename="unpacked", view=False)
            if self.level >= 3:
                # y = graph.prediction_node.output.value
                # pred = predict(graph, self.prop_class_py, show=True)
                # from matplotlib import pyplot as plt
                # plt.plot(y, '.')
                # plt.plot(pred, '.r')
                # plt.show()
                set_trace_up()

            free_values, free_hash_dict = initialize_free_values(graph, cur_leaf)
            new_root = self.compression_step(
                cur_leaf.output, free_values, solution_sexpr=task.solutions.get(steps, None)
            )

            if new_root is None:
                debugger(
                    self.level,
                    {2: f"\nCompression failed for leaf\n{cur_leaf.output}"},
                    color="red",
                    halt=self.level >= 3,
                )
                leaves = leaves[1:]
                continue
            debugger(
                self.level,
                {2: f"Leaf compressed by {(1 - new_root.leaves_dl() / new_root.output_dl()) * 100:.2f}%"},
            )

            cur_leaf.merge(new_root, upper=False, lower=True)

            # glue back free values
            new_leaves = []
            for leaf in cur_leaf.leaves():
                hsh = hash(leaf.output)
                if leaf.output_dl() > 0 or hsh not in free_hash_dict:
                    leaf.output.dummy = False
                    new_leaves.append(leaf)
                    continue

                # free values have dl = 0, we merge them back to the original leaves
                existing_leaf = free_hash_dict[hsh]
                if existing_leaf.is_above([leaf]):
                    continue  # avoid cycles
                existing_leaf.merge(leaf, upper=True, lower=False)

            leaves = new_leaves + leaves[1:]

            steps += 1
            check_target_reconstructable(graph, self.prop_class_py)

            rate = (1 - graph.leaves_dl() / org_dl) * 100
            msg = f"Total compression rate: {rate:.2f}% (threshold: {task.threshold_rate:.2f}%, "
            msg += f"{org_dl:.2f} bits -> {graph.leaves_dl():.2f} bits)"
            debugger(self.level, {2: msg}, color="cyan")
            if task.threshold_rate is not None and rate >= task.threshold_rate:
                break

        # show final result
        if self.level >= 2:
            graph.render(view=False)
            graph.clone_and_unpack().render(filename="unpacked", view=False)
        debugger(
            self.level,
            {1: f"\nFinished task {task.name} after {steps} steps ({time() - t0:.2f} seconds)\n"},
            color="green",
            halt=self.level >= 2,
        )

        # check if threshold rate was reached
        rate = (1 - graph.leaves_dl() / org_dl) * 100
        if task.threshold_rate is not None and rate < task.threshold_rate and task.threshold_rate < 100:
            raise RuntimeError(
                f"Failed to reach threshold rate of {task.threshold_rate}% in task {task.name}, got only {rate:.2f}%"
            )

    def compression_step(
        self, target: Value, free_values: list[Value], solution_sexpr: str | None = None
    ) -> Iterable[ValueNode]:
        org_dl = target.desc_len()
        threshold = org_dl * (1 - self.min_rate)
        debugger(self.level, {4: f"Original DL: {org_dl:.2f}, threshold for compression: {threshold:.2f}"})
        learning_threshold = threshold  # org_dl if self.learn else threshold

        solution = None
        if solution_sexpr is not None:
            solution = build_graph(solution_sexpr)
            if self.level >= 3:
                solution.render()
                set_trace_up()

        ops_with_counts = self._load_operators_with_counts()

        regs = RegistryBundle()
        if self.speedy:
            enum = SpeedyWunderbaum(regs, target.spec, ops_with_counts, level=self.level, free_values=free_values)
            prop_class = RandomPropagation(regs.operators, partial=False, cache=True)
        else:
            enum = Wunderbaum(target.spec, ops_with_counts, level=self.level, free_values=free_values)
            prop_class = RandomPropagationPy(partial=False, cache=True)

        wunder_iter = enum.iterate(
            prop_class, target, trees_only=self.trees_only, solution=solution, max_dl=self.max_dag_dl
        )

        self.dag_cond_nums.append(0)
        for dag_cond_num, (dag_item, dag_dl, dag_params) in enumerate(wunder_iter):
            mem, bottleneck = dag_params

            if isinstance(dag_item.root, ValueNode):
                root = dag_item.root
            else:
                root, id_map = build_root_from_rust_graph(dag_item.root, regs)
                mem = NodeValueMap({id_map[k]: v for k, v in mem.items()})
                bottleneck = [id_map[k] for k in bottleneck]

            self.dag_cond_nums[-1] += 1
            if 1 <= self.level < 5:
                dispdots(dag_cond_num, 20, dots_per_line=50)
            if self.level >= 5:
                dag_item.render(mem=mem, view=False)
                root.clone_and_unpack().render(mem=mem, filename="unpacked", view=False)
                print(f"DAG {dag_cond_num} with {dag_item.effective_length}, cond: {dag_item.cond}")
                debugger(
                    self.level,
                    {5: f"Minimized DL: {dag_dl:.2f} (threshold: {learning_threshold:.2f}) bits."},
                    color="yellow" if dag_dl >= learning_threshold else "cyan",
                    halt=self.level >= 5,
                )
            if dag_cond_num % 1000 == 0:
                memory = memory_usage()
                debugger(self.level, {1: f"{memory:.2f} MB used. {dag_item.effective_length}"})

            # be at least 1 bit better than before
            if dag_dl >= learning_threshold:
                continue
            # Keep searching for increasingly better compressions and learn on the way
            learning_threshold = dag_dl
            new_root = _copy_and_insert_mem(root, mem, bottleneck)
            check_target_reconstructable(new_root, self.prop_class_py)

            if self.level >= 4:
                new_root.render(view=False)
                new_root.clone_and_unpack().render(filename="unpacked", view=False)
                set_trace_up()

            if self.learn:
                unpacked = new_root.clone_and_unpack()
                # self.mork.upload_(unpacked.to_sexpr())
                for subgraph in unpacked.all_subgraphs():
                    sexpr = subgraph.to_sexpr()
                    self.mork.upload_(sexpr)

            # Stop as soon as we found a compression below the actual threshold.
            if dag_dl < threshold:
                debugger(self.level, {3: f"Found compression with dl={dag_dl:.2f} < {threshold:.2f}"}, color="green")
                return new_root

    def _load_operators_with_counts(self) -> list[tuple[Operator, int]]:
        """Loads operators from MORK database with their respective counts (number of times used)."""
        if not self.learn:
            ops = [(op, 0) for op in self.task_domain.operators]
            return ops

        expressions = self.mork.download_(format="json", show_weights=True).data["expressions"]
        ops = []
        seen = set()
        for i, item in enumerate(expressions):
            # added once to mork is the default, hence reuse number is 0
            count = item["weight"] - 1
            op = operator_from_string(item["expression"], name=f"op_{i}", op_dl=self.task_domain.op_dl)
            if op in seen:
                continue
            seen.add(op)
            ops.append((op, count))
        return ops


def initialize_free_values(graph: Graph, target_leaf: ValueNode) -> tuple[dict[Any, list[Value]], dict[int, ValueNode]]:
    free_values = defaultdict(list)

    # values in all graph leaves can be used as free values, to be glued together with the leaves later
    hash_dict = {}
    for other_leaf in graph.leaves():
        v0 = other_leaf.output
        hsh = hash(v0)
        if hsh in [hash(v) for v in free_values[v0.spec]]:
            continue
        v = v0
        if other_leaf is not target_leaf:
            v = v0.copy()
            v.dummy = True  # dl = 0 for free values
        free_values[v.spec].append(v)
        hash_dict[hsh] = other_leaf
    return free_values, hash_dict


def _copy_and_insert_mem(dag_root: ValueNode, mem: NodeValueMap, lowest_allowed_nodes: list[ValueNode]) -> ValueNode:
    """
    Create a copy of the DAG and insert the mappings, in order not to spoil
    the DAGs in the DAG iterator, since they are pushed back again.
    """
    graph = Graph([dag_root])
    # all below lowest allowed nodes are not to be copied, but cut off
    # this is where the autoencoder is cut in two pieces, for residual compression to continue
    blocked = list(chain(*[node.options for node in lowest_allowed_nodes]))
    new_graph, _ = graph.insert_mem(mem, copy=True, blocked=blocked)
    return new_graph.nodes[0]


def check_target_reconstructable(graph: Graph | ValueNode, prop_class: RandomPropagation):
    deb = False

    if isinstance(graph, ValueNode):
        graph = Graph([graph])

    mem = NodeValueMap()
    for leaf in graph.leaves():
        mem[leaf] = MapEntry(same=False, val=leaf.output)

    for prop_mem in prop_class.propagate(graph, mem, debug=deb):
        for root in graph.nodes:
            if not recursive_match(root.output.value, prop_mem[root].val.value):
                raise RuntimeError("Graph root value can't be reconstructed from its leaves.")


def predict(graph: Graph, prop_class: RandomPropagation, show: bool = False):
    deb = True
    mem = NodeValueMap()
    for leaf in graph.leaves():
        x = leaf.output.value

        if isinstance(x, np.ndarray) and x.dtype.kind == "f" and leaf not in graph.nodes[1:]:
            mem[leaf] = MapEntry(same=False, val=Value(np.ones_like(x) * np.nanmean(x)))
        else:
            mem[leaf] = MapEntry(same=False, val=leaf.output)

    for pred_mem in prop_class.propagate(graph, mem, debug=deb):
        if show:
            graph.render(pred_mem, filename="test2", view=False)
        return pred_mem[graph.prediction_node].val.value
