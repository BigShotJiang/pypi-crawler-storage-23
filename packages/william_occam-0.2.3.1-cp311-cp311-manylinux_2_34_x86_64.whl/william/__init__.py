from importlib.metadata import version as _get_version_str

from packaging.version import Version as _Version

try:
    __version__ = _get_version_str("william-occam")
except ImportError:
    __version__ = None
    __version_tuple = 0, 0, 0
else:
    __version_tuple = _Version(__version__).release
