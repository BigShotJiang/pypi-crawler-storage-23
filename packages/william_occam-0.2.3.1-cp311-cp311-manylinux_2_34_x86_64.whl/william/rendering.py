import os
import random
import subprocess
from pathlib import Path
from time import sleep

import numpy as np

from william.paths import GRAPHS_PATH, TMP_PATH
from william.utils import everything, get_path, pretty, seen_already

try:
    from graphviz import Source
except ModuleNotFoundError:
    Source = None

VALUE_COL = '"#000000"'
OP_COL = '"#000000"'
EDGE_COL = '"#000000"'
BLUE_COL = '"#0000ff"'
RED_COL = '"#dd0000"'

infix_rep = {"add": "+", "sub": "-", "div": "/", "mult": "*", "invert": "1/", "negate": "-"}


class NodeRenderingMixIn:
    """Printing and rendering of graphs"""

    op: None
    parent: None
    children: list

    def tree_name(self, branches, infix=False):
        if infix and self.op.name in infix_rep:
            name = infix_rep[self.op.name]
            if len(self.children) >= 2:
                s = f" {name} ".join(child.tree_name(branches, infix=infix) for child in self.children)
                if name in ["+", "-"]:
                    s = f"({s})"
            else:
                s = f"{name}" + self.children[0].tree_name(branches, infix=infix)
        else:
            s = ", ".join(child.tree_name(branches, infix=infix) for child in self.children)
            if s[0] != "(" or s[-1] != ")":
                s = f"({s})"
            s = f"{self.op.name}{s}"
        return s

    @property
    def nnf(self):
        return f"{self.op.name}{id(self)}"

    @staticmethod
    def naf(col, op, img_cnt, reading=True):
        return (
            f'label="{op.name}", shape=oval, color="#ffffff", height=0.02, '
            f"width=0.01; fontsize=10; fontcolor={col or OP_COL}"
        )

    def edges(self, color, separator):
        s = ""
        if not any(self is option for option in self.parent.options):
            col = color.get((self, self.parent), color.get((self.parent, self), EDGE_COL))
            s += f'"{self.nnf}" -> "{self.parent.nnf}" [arrowsize=0.5,style=dashed,color={col}];{separator}'
        for child in self.children:
            if child is None:
                continue
            style = ""
            if any(self is parent for parent in child.parents):
                style = ", arrowhead=none"
            col = color.get((self, child), color.get((child, self), EDGE_COL))
            s += f'"{self.nnf}" -> "{child.nnf}" [arrowsize=0.5{style},color={col}];{separator}'
        return s

    def graph_to_dot(self, **kwargs):
        return self.parent.graph_to_dot(**kwargs)


class ValueRenderingMixin:
    options: list
    parents: list
    output: None

    def __str__(self):
        options_str = "\n".join(str(o) for o in self.options)
        return f"<value node.. {pretty(self.output)}\n{options_str}..value node>\n"

    def image(self, col, filename):
        """If the value node has a composite as value, render its root as PNG."""

        val = self.output.value
        if type(val).__name__ != "Composite" or not hasattr(val, "root"):
            # TODO: This should be a proper type check, but avoid being a cyclic import.
            #       Maybe use a protocol.
            return False
        color = {}
        for node in val.root.walk():
            color[node] = col or VALUE_COL
        val.root.render(color=color, filename=filename, create_file="png")
        return True

    def graph_name(self, max_len=None):
        branches = []
        full_name = self.tree_name(branches)
        # sort by decreasing length. Guarantees that modifications in a branch name will not affect
        # subsequent branches
        branches = sorted(branches, key=len)[::-1]
        num = 0
        for k, branch_name in enumerate(branches):
            # skip branches that do not reoccur later or have occurred already
            if branch_name not in branches[k + 1 :] or k > 0 and branch_name in branches[: k - 1]:
                continue
            index = full_name.find(branch_name)
            var_name = f"x{num}"
            full_name = full_name[:index] + var_name + "->" + full_name[index:]
            j = index + len(var_name) + 2 + len(branch_name)
            full_name = full_name[:j] + full_name[j:].replace(branch_name, var_name)
            num += 1

        if max_len is not None and len(full_name) > max_len:
            full_name = full_name[:max_len]
        return full_name

    def tree_name(self, branches, infix=False):
        if not self.options:
            return str(self.output.value) if self.output.name is None else str(self.output.name)
        name = self.options[0].tree_name(branches, infix=infix)
        branches.append(name)
        return name

    @property
    def nnf(self):
        return str(id(self))

    @staticmethod
    def naf(col, output, img_cnt, reading=True):
        col = col or VALUE_COL
        desc = str(output) if reading else output.serialize()

        try:
            from pylab import imsave
        except ImportError:
            imsave = None

        # Bild für Composite-Graphen erzeugen
        if reading:
            filename = f"node{img_cnt}"
            if hasattr(output.value, "root"):
                # Render graph and save as PNG
                output_node = output.value.root
                color = {}
                for node in output_node.walk():
                    color[node] = col
                output_node.render(color=color, filename=filename, create_file="png")
                s = f'image="{filename}.png", xlabel="", label="", shape=box'
            elif output.is_image and imsave is not None:
                # treatment of saving arrays as images
                filename = f"node{img_cnt}"
                imsave(f"tmp/{filename}.png", scale_array(output._value, span=1))
                s = f'image="{filename}.png", xlabel="{desc}", label="", shape=box'
            else:
                s = f'label="{desc}", shape=box'
        else:
            s = f'label="{desc}", shape=box'
        return s + f", color={col}, height=0.02, width=0.01; fontsize=10; fontcolor={col}"

    def reverse_link(self, option):
        return self is option.parent

    def edges(self, color, separator):
        s = ""
        for option in self.options:
            style = ", arrowhead=none" if self is option.parent else ""
            col = color.get((self, option), color.get((option, self), EDGE_COL))
            s += f'"{self.nnf}" -> "{option.nnf}" [arrowsize=0.5{style}, color={col}];{separator}'
        for parent in self.parents:
            if parent is None:
                continue
            if any(self is child for child in parent.children):
                continue
            col = color.get((self, parent), color.get((parent, self), EDGE_COL))
            s += f'"{self.nnf}" -> "{parent.nnf}" [arrowsize=0.5,style=dashed,color={col}];{separator}'
        return s

    def graph_to_dot(self, seen=None, mem=(), color=None, reading=True, node_count=0, separator="\n"):
        if seen is None:
            seen = set()
        if color is None:
            color = {}
        if self not in color:
            color[self] = BLUE_COL
        s = ""
        edges = ""
        for k, node in enumerate(self.walk()):
            if seen_already(node, seen):
                continue
            col = color.get(node, None)
            value = mem[node].val if node in mem else node.val
            naf = node.naf(col, value, k, reading=reading)

            star = "*" if not reading and col == BLUE_COL else ""
            s += node.nnf + star + " [" + naf + "];" + separator
            edges += node.edges(color, separator)
        return s + edges, node_count

    def save(self, filename: Path | str):
        save_graphs([self], filename)

    def render(self, mem=(), filename: Path | str = "test", color=None, create_file="pdf", condition=True, view=True):
        if not condition:
            return
        return render([self], mem=mem, filename=filename, color=color, create_file=create_file, view=view)


class ConceptNodeRenderingMixin:
    intension: None
    extension: None
    children: list
    parts: list

    @property
    def nnf(self):
        return str(id(self))

    @staticmethod
    def naf(col, node, img_num, reading=True):
        col = col or VALUE_COL
        if reading:
            filename = f"node{img_num}"
            node.image(col, filename)
            s = f'image="{filename}.png", xlabel="{node.name}", label="", '
        else:
            s = f'label="{node.serialize()}", '
        s += f"shape=box, color={col}, height=0.02, width=0.01; fontsize=10; fontcolor={col}"
        return s

    def image(self, col, filename):
        color = {}
        for node in self.intension.root.walk():
            color[node] = col
        self.intension.root.render(color=color, filename=filename, create_file="png")

    def edges(self, color, separator):
        s = ""
        for child in self.children:
            s += '"' + self.nnf + '" -> "' + child.nnf
            style = "" if self in child.parents else "style=dashed, "
            col = color.get((self, child), RED_COL)
            s += f'"[arrowsize=1, {style}penwidth=2, color={col}, dir=back, label=" is a"];{separator}'
        for part in self.parts:
            s += '"' + self.nnf + '" -> "' + part.nnf
            style = "" if self in part.wholes else "style=dashed, "
            col = color.get((self, part), BLUE_COL)
            s += f'"[arrowsize=1, {style}penwidth=2, color={col}, label=" has a"];{separator}'
        return s

    def graph_to_dot(self, seen=None, mem=(), color=None, reading=True, node_count=0, separator="\n"):
        if seen is None:
            seen = set()
        if color is None:
            color = {}
        s = ""
        edges = ""
        for node in self.walk():
            if seen_already(node, seen):
                continue
            col = color.get(node, None)
            naf = node.naf(col, node, node_count, reading=reading)
            node_count += 1

            star = "*" if not reading and not node.parents and not node.wholes else ""
            s += node.nnf + star + " [" + naf + "];" + separator
            edges += node.edges(color, separator)
        return s + edges, node_count

    def save(self, fpath: Path | str):
        save_graphs([self], fpath)

    def render(self, filename="semantic_net", color=None, create_file="pdf"):
        return render([self], filename=filename, color=color, create_file=create_file)

    def render_node(self, global_root, obj_num=None, col='"#aa00aa"', **kwargs):
        color = {}
        objects = self.extension.objects if obj_num is None else [self.extension.objects[obj_num]]
        for obj in objects:
            for node in obj.nodes:
                color[node] = col
        global_root.render(color=color, **kwargs)
        self.intension.render()


def save_graphs(nodes, filename: Path | str, mkdir: bool = False) -> None:
    fpath = get_path(filename, root=GRAPHS_PATH, suffix=".dot", mkdir=mkdir)
    fpath.write_text(graphs_to_dot(nodes, reading=False, with_brackets=False))


def render(nodes, mem=(), filename: Path | str = "test", color=None, create_file="pdf", view: bool = True):
    """
    Render a graph using Graphviz. Keeps terminal focus when viewing PDFs (X11 only).

    Parameters
    ----------
    nodes : any
        Input graph nodes.
    mem : dict
        Replaces node values by mem[node].val when node in mem.
    filename : str | Path
        Base name of the rendered file.
    color : any
        Coloring specification passed to prepare_coloring().
    create_file : str | None
        'pdf', 'png', or None (returns Source object).
    view: bool
        Show file in pdf viewer if possible
    """

    if isinstance(mem, str):
        # TODO: wtf, just fix the argument order!
        filename = mem
        mem = ()

    fpath = get_path(filename, root=TMP_PATH, suffix=".dot")
    color = prepare_coloring(mem=mem, color=color)
    dot = graphs_to_dot(nodes, mem=mem, color=color, reading=True, with_brackets=True)

    sleep(0.001)

    try:
        src = Source(dot, filename=str(fpath))
    except TypeError:
        raise ModuleNotFoundError("Graphviz not installed. Cannot render graphs.")

    if create_file == "pdf":
        # remember current terminal window (X11)
        try:
            win_id = subprocess.check_output(["xdotool", "getactivewindow"]).strip()
        except Exception:
            win_id = None

        # render and open viewer only if not already open
        src.render(view=view or not viewer_open(fpath.stem))

        # restore focus to terminal
        if win_id:
            sleep(0.5)
            subprocess.run(["xdotool", "windowactivate", win_id], check=False)

    elif create_file == "png":
        src.render(format=create_file)

    elif create_file is None:
        return src


def graphs_to_dot(val_nodes, mem=(), color=None, reading=True, with_brackets=True, separator="\n") -> str:
    """Return an object generating a picture of the graph using .view()"""
    if not isinstance(val_nodes, list):
        val_nodes = [val_nodes]
    if color is None:
        color = {}
    for n in val_nodes:
        if n not in color:
            color[n] = BLUE_COL
    s = ""
    seen = set()
    node_count = 0
    for val_node in val_nodes:
        if val_node in seen:
            continue
        dot, node_count = val_node.graph_to_dot(
            seen=seen,
            mem=mem,
            color=color,
            reading=reading,
            node_count=node_count,
            separator=separator,
        )
        s += dot
    if with_brackets:
        s = f"digraph tree {{{separator}{s}}}"  # + "margin=0;\n" + "ratio=fill;\n" + "bgcolor=\"#FFFFFF\";\n"
    return s


def viewer_open(filename: str):
    for pid in os.listdir("/proc"):
        cmd_line = ()
        if pid.isdigit():
            try:
                with open(os.path.join("/proc", pid, "cmdline"), "rb") as cmdfile:
                    cmd_line = str(cmdfile.read()).replace("\x00", " ").strip()
            except OSError:
                pass
            if filename + ".pdf" in cmd_line:
                return True
    return False


def render_map(section, ref_section, map0, missing, filename="map", separator="\n"):
    ref_section, map0, missing = _disambiguate(section, ref_section, map0, missing)

    color = {}
    for n1, n2 in map0.items():
        if n2 in missing:
            color[n1] = '"#cc00cc"'
            color[n2] = '"#cc00cc"'
        else:
            color[n1] = '"#aa0000"'
            color[n2] = '"#aa0000"'

    s = graphs_to_dot(section.nodes, color=color, with_brackets=False)
    # TODO: bush=ref identity assumption
    if section is not ref_section:
        s += graphs_to_dot(ref_section.nodes, color=color, with_brackets=False)
    for n1, n2 in map0.items():
        s += f'"{n1.nnf}" -> "{n2.nnf}" [arrowsize=0.5, style=dashed, color={color[n1]}, constraint=false];{separator}'
    s = f"digraph tree {{{separator}{s}}}"

    src = Source(s, filename=TMP_PATH / filename)
    sleep(0.001)
    src.render(view=not viewer_open(filename))


def _disambiguate(section, ref_section, map0, missing):
    # TODO: bush=ref identity assumption
    if section is not ref_section:
        return ref_section, map0, missing
    corr = {}
    ref_copy = ref_section.clone(corr=corr)
    map_copy = map0.copy()
    for n1, n2 in map0.items():
        map_copy[n1] = corr[n2]
    miss_copy = [corr[n] for n in missing]
    return ref_copy, map_copy, miss_copy


def prepare_coloring(mem=(), color=None):
    if color is None:
        color = {}
    if mem is everything:
        return color
    for vn in mem:
        color[vn] = RED_COL
    return color


def scale_array(x, repl_nan=0.0, span=255.0):
    if np.all(np.isnan(x)):
        return np.zeros_like(x)
    xc = x.copy()
    xc[np.isnan(x)] = repl_nan
    min_x = np.nanmin(xc)
    max_x = np.nanmax(xc)
    if max_x == min_x:
        return x
    return (xc - min_x) / (max_x - min_x) * span


def random_rgb(a=0, b=255):
    """
    Generates a random RGB string.

    Returns:
        str: A string in the format '#rrggbb', where rr, gg, and bb are hexadecimal strings representing the red, green,
        and blue color channels, respectively.
    """
    r = random.randint(a, b)
    g = random.randint(a, b)
    b = random.randint(a, b)
    return f'"#{r:02x}{g:02x}{b:02x}"'
