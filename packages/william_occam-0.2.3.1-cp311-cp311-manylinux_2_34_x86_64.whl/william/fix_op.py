from william.composite import Composite
from william.library.base import Operator
from william.library.types import T1, T2, Callable, T
from william.structures.nodes import Node  # deep import to avoid circular dependency
from william.structures.value_nodes import ValueNode  # deep import to avoid circular dependency


class Fix(Operator):
    """Partial application of the first input to a callable, reducing the arity of the callable by one."""

    _raw_specs = [(tuple[T, Callable[[tuple[T, T1]], T2]], Callable[[tuple[T1]], T2])]
    conditions = ((0, 1),)
    commutative = False
    arity = 2

    def __call__(self, inp, op):
        if isinstance(op, Composite):
            root = op.root.clone()
            constant_nums = list(op.constant_nums)
        else:
            root = Node(op, children=[ValueNode() for _ in range(op.arity)]).parent
            constant_nums = []
        # fix first available input, not already fixed
        leaves = list(root.leaves())
        leaves[0].output = inp  # first leaf is being fixed
        for i in range(len(leaves)):
            if i in constant_nums:
                continue
            constant_nums.append(i)
            break
        else:
            raise ValueError("All inputs are fixed already.")
        comp = Composite(root, constant_nums=tuple(sorted(constant_nums)), name=f"Fix({inp}, {op})".replace("\n", ""))
        return comp
