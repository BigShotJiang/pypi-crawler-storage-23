import pytest

from william.structures.dot_to_graph import parse_dot_file
from william.structures.sexpr_to_graph import build_graph, operator_from_string, parse_sexpr

params = [
    ("sexpr_to_graph/test_graph0.dot", "(list[int] (arraytolist Array[int]))"),
    ("sexpr_to_graph/test_graph1.dot", "(Array[int] (cumsum Array[int]))"),
    (
        "sexpr_to_graph/test_graph2.dot",
        "(Array[int] (cumsum (Array[int] (getitem Array[int] (Array[int] (cumsum Array[int]))))))",
    ),
    ("sexpr_to_graph/test_graph3.dot", "(Array[int] (getitem Array[int] (Array[int] (cumsum Array[int]))))"),
    (
        "sexpr_to_graph/test_graph4.dot",
        "(Array[int] (insert list[int] Array[int] (Array[int] (repeat int Array[int]))))",
    ),
    (
        "sexpr_to_graph/test_graph5.dot",
        "(Array[int] (insert (Array[int] (arraytolist (Array[int] (cumsum Array[int])))) Array[int] (Array[int] (cumsum Array[int]))))",
    ),
    (
        "sexpr_to_graph/test_graph6.dot",
        "(Array[int] (insert (Array[int] (arraytolist (Array[int] (cumsum (Array[int] (cumsum Array[int])))))) int Array[int]))",
    ),
    ("sexpr_to_graph/test_graph7.dot", "(list[int] (map Callable[[tuple[int]], int] list[int]))"),
    (
        "sexpr_to_graph/test_graph8.dot",
        "((= $ int) (list[int] (map (Callable[[tuple[int]], int] (int (add _1 _1))) list[int])))",
    ),
    (
        "sexpr_to_graph/test_graph9.dot",
        "(Array[int] (map (Callable[[tuple[int, int]], int] (fix int (Callable[[tuple[int, int]], int] (int (mult int int))))) Array[int]))",
    ),
    ("glue_leaves/dag_0.dot", "(int (add (int (add int int)) int int int))"),
    ("glue_leaves/dag_1.dot", "((= $ int) (int (add (int (add _1 _1)) int int int)))"),
    ("glue_leaves/dag_2.dot", "((= $ int) (int (add (int (add _1 _1)) _1 int int)))"),
    ("glue_leaves/dag_3.dot", "((= $ int) (int (add (int (add _1 _1)) int _1 int)))"),
    ("glue_leaves/dag_4.dot", "((= $ int) (int (add (int (add _1 _1)) int int _1)))"),
    ("glue_leaves/dag_5.dot", "((= $ int) (int (add (int (add _1 int)) _1 int int)))"),
    ("glue_leaves/dag_6.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _1 _2 int)))"),
    ("glue_leaves/dag_7.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _1 int _2)))"),
    ("glue_leaves/dag_8.dot", "((= $ int) (int (add (int (add _1 int)) int _1 int)))"),
    ("glue_leaves/dag_9.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _2 _1 int)))"),
    ("glue_leaves/dag_10.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) int _1 _2)))"),
    ("glue_leaves/dag_11.dot", "((= $ int) (int (add (int (add _1 int)) int int _1)))"),
    ("glue_leaves/dag_12.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _2 int _1)))"),
    ("glue_leaves/dag_13.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) int _2 _1)))"),
    (
        "test_graph.dot",
        "((= $ (list[int] (repeat int list[int]))) (list[int] (concat _1 (list[int] (concat _1 list[int])))))",
    ),
    ("hyper0.dot", "((= $ int) (list[int] (map (Callable[[tuple[int]], int] (int (add _1 _1))) list[int])))"),
]


@pytest.mark.parametrize("name, sexpr", params)
def test_sexpr_to_graph(name, sexpr):
    root = build_graph(sexpr)
    new_sexpr = root.to_sexpr()
    assert new_sexpr == sexpr
    # Graph([root]).save(f"test_graph{i}.dot", path=GRAPHS_PATH / "sexpr_to_graph")
    expected = parse_dot_file(name)[0]
    assert root.resembles(expected, check_values=False)
    # works for DAGs too, but the dag_{i}.dot graphs have the add Operator with wrong arity
    # this conflicts with the specs stuff
    if "glue_leaves" not in name:
        operator_from_string(sexpr, name="test_op")


def test_parse_sexpr_brackets_and_commas():
    # Commas inside [] must not split
    s1 = "(list[int] (map collections.abc.Callable[[tuple[int]], int] list[int]))"
    parsed1 = parse_sexpr(s1)
    assert parsed1 == ["list[int]", ["map", "collections.abc.Callable[[tuple[int]], int]", "list[int]"]]

    s2 = "(foo (bar [a, b, c] baz))"
    parsed2 = parse_sexpr(s2)
    assert parsed2 == ["foo", ["bar", "[a, b, c]", "baz"]]

    s3 = "(outer (inner [x, y], z))"
    parsed3 = parse_sexpr(s3)
    assert parsed3 == ["outer", ["inner", "[x, y]", "z"]]

    s4 = "(Array[int] (getitem Array[int] (cumsum Array[int])))"
    parsed4 = parse_sexpr(s4)
    assert parsed4 == ["Array[int]", ["getitem", "Array[int]", ["cumsum", "Array[int]"]]]

    # Unbalanced parentheses
    try:
        parse_sexpr("(foo (bar [a, b, c]")
        assert False, "Unbalanced parentheses not detected"
    except ValueError:
        pass

    # Multiple nestings and complex types
    s5 = "(outer (middle (inner [x, [y, z], w] foo) bar) baz)"
    parsed5 = parse_sexpr(s5)
    assert parsed5 == ["outer", ["middle", ["inner", "[x, [y, z], w]", "foo"], "bar"], "baz"]

    s6 = "(wrap (f [A, [B, [C, D]], E] [X, Y]))"
    parsed6 = parse_sexpr(s6)
    assert parsed6 == ["wrap", ["f", "[A, [B, [C, D]], E]", "[X, Y]"]]

    s6a = "(wrap (f [C, D] [E, F]))"
    parsed6a = parse_sexpr(s6a)
    assert parsed6a == ["wrap", ["f", "[C, D]", "[E, F]"]]

    s7 = "(complex (op1 [T1, [T2, [T3, [T4]]]]) (op2 [U1, U2]))"
    parsed7 = parse_sexpr(s7)
    assert parsed7 == ["complex", ["op1", "[T1, [T2, [T3, [T4]]]]"], ["op2", "[U1, U2]"]]

    s8 = "(nest (a [b, [c, [d, [e, f]]], g] h) i)"
    parsed8 = parse_sexpr(s8)
    assert parsed8 == ["nest", ["a", "[b, [c, [d, [e, f]]], g]", "h"], "i"]

    s9 = "(multi (foo [bar, baz]) (qux [quux, [corge, grault]]))"
    parsed9 = parse_sexpr(s9)
    assert parsed9 == ["multi", ["foo", "[bar, baz]"], ["qux", "[quux, [corge, grault]]"]]

    s10 = "((= $ int) (list[int] (map (Callable[[tuple[int]], int] (int (add _1 _1))) list[int])))"
    parsed10 = parse_sexpr(s10)
    assert parsed10 == [
        ["=", "$", "int"],
        ["list[int]", ["map", ["Callable[[tuple[int]], int]", ["int", ["add", "_1", "_1"]]], "list[int]"]],
    ]
