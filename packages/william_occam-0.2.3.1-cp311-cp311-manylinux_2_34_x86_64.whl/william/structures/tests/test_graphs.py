from william.library.types import list_like_py
from william.paths import GRAPHS_PATH
from william.structures.dot_to_graph import parse_dot_file
from william.structures.graphs import Graph


def test_leaves():
    graph = Graph(parse_dot_file("growth/bush_grow.dot"))
    leaves = list(graph.leaves())
    assert [leaf.output.value for leaf in leaves] == [[71], [23], 1]


def test_leaves_dl():
    graph = Graph(parse_dot_file(GRAPHS_PATH / "nodes" / "graph_with_cycle2.dot"))
    expected = [
        "a['','',..,'v']\ndl=914.31",
        "a[True,True,..,False]\ndl=164.31",
        "a['s','s',..,'s']\ndl=462.11",
        "a[nan,nan,..,1.8]\ndl=451.94",
        "a[0.2,0.2,..,0.2]\ndl=136.19",
        "1\ndl=6.33",
    ]
    assert [n.v for n in graph.leaves()] == expected


def immutable(x):
    if isinstance(x, list_like_py):
        return tuple([y for y in x])
    return x
