import pytest

from william.library import Concat
from william.structures.dot_to_graph import DotParser

params = [
    (
        '139731379272704 [label="[71, 71, 71, 23]", shape=box, color="#aa00ff", height=0.02, width=0.01; fontsize=10;',
        "139731379272704",
        [71, 71, 71, 23],
        False,
    ),
    (
        'concat139731377915280 [label="concat", shape=none, height=0.02, width=0.01; fontsize=10;',
        "concat139731377915280",
        Concat(),
        False,
    ),
    (
        '139731377587576 [label="1", shape=box, color="#aa00ff", height=0.02, width=0.01; fontsize=10;',
        "139731377587576",
        1,
        False,
    ),
    (
        '"139731379272704" -> "concat139731377915280"[arrowsize=0.5, arrowhead=none, color="#aa00ff"];',
        "139731379272704",
        "concat139731377915280",
        True,
    ),
]


@pytest.mark.parametrize("line, exp_node_id, exp_val, exp_edge_def", params, ids=list(map(str, range(len(params)))))
def test_parse_dot_line(line, exp_node_id, exp_val, exp_edge_def):
    node_id, val, edge_def, is_val_node, is_root = DotParser().parse_dot_line(line)
    assert node_id == exp_node_id
    val = val if isinstance(val, str) else val.value
    assert val == exp_val
    assert edge_def == exp_edge_def
