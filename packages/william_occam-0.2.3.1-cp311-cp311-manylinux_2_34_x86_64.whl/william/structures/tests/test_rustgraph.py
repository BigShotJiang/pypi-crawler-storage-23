import pytest

from william.bottleneck import cross_sections
from william.delayed_builder import clone_and_attach
from william.library.basic_ops import Add, Mult
from william.library.types import Array
from william.structures.dot_to_graph import parse_dot_file
from william.structures.nodes import graph_element
from william.structures.rustgraph import build_root_from_rust_graph, build_rust_graph_from_root, rustgraph_element
from william.structures.tests.test_nodes import dags, trees
from william.utils.registry import RegistryBundle

registry = RegistryBundle()


def test_rustgraph_export_import():
    root = parse_dot_file("nodes/graph_with_cycle.dot")[0]

    rust_graph, id_map = build_rust_graph_from_root(root, registry)
    new_root, _ = build_root_from_rust_graph(rust_graph, registry)
    assert root.resembles(new_root), "Roots do not resemble after export/import"

    # --- Python-side walk ----------------------------------------------------
    py_nodes = list(root.walk())

    # --- Rust-side walk ------------------------------------------------------
    rust_start = id_map[root]
    rust_nodes = rust_graph.walk(rust_start)

    # --- Verify that all Python nodes appear in the Rust graph ---
    if len(py_nodes) != len(rust_nodes):
        raise AssertionError(f"Node count mismatch: Python={len(py_nodes)} vs Rust={len(rust_nodes)}")

    # Optional sanity check: IDs in the map should all be unique
    if len(id_map) != len(py_nodes):
        raise AssertionError(f"ID map incomplete: only {len(id_map)} of {len(py_nodes)} nodes mapped")

    # Optional: Check that all mapped IDs exist in Rust
    unmapped = [rid for rid in id_map.values() if rid not in rust_nodes]
    if unmapped:
        raise AssertionError(f"Some mapped nodes missing in Rust: {unmapped[:10]} ...")


def test_rustgraph_leaves():
    root = parse_dot_file("test_graph.dot")[0]

    rust_graph, id_map = build_rust_graph_from_root(root, registry)

    # --- Verify that all Python leaves appear in the Rust graph ---
    mapped_py_leaves_ids = [id_map[node] for node in root.leaves()]
    rust_leaves_ids = rust_graph.leaves()
    if set(mapped_py_leaves_ids) != set(rust_leaves_ids):
        raise AssertionError(f"Leaves mismatch: Python={mapped_py_leaves_ids} vs Rust={rust_leaves_ids}")


@pytest.mark.parametrize("node", trees + dags)
def test_clone(node):
    root = node.parent
    rust_graph, id_map = build_rust_graph_from_root(root, registry)

    new_graph, mapping = rust_graph.clone_subgraph()
    rust_clone, _ = build_root_from_rust_graph(new_graph, registry)
    clone = root.clone()

    assert clone.resembles(rust_clone), "Cloned roots do not resemble"


def test_graph_element_equivalence():
    """
    Compare a primitive Python graph_element() with the equivalent Rust graph
    built via rustgraph_element() to ensure structure and payload consistency.
    """

    # --- Setup ---------------------------------------------------------------
    registry = RegistryBundle()

    # Python side: build reference graph
    py_root = graph_element(Add(), [Array, Array], Array)

    # Rust side: build via direct Rust constructor
    rust_graph = rustgraph_element(Add(), [Array, Array], Array, registry)

    # --- Convert Rust graph back to Python graph -----------------------------
    rust_root, _ = build_root_from_rust_graph(rust_graph, registry)

    # --- Compare -------------------------------------------------------------
    # Both graphs should be structurally equivalent (same topology + specs/operators)
    assert py_root.resembles(rust_root), "Rust and Python graph_element results differ"


def test_clone_and_attach():
    g1 = rustgraph_element(Add(), [Array[int], Array[int]], Array[int], registry)
    g2 = rustgraph_element(Mult(), [Array[int], Array[int]], Array[int], registry)

    root_leaves = [n for n in g1.walk_from_root(True, True) if not g1.get_options(n) and not g1.get_children(n)]
    leaf_id = root_leaves[0]

    new_graph, new_elem_leaves, candidates = g1.clone_and_attach(g2, leaf_id)

    new_py_graph_ref = build_root_from_rust_graph(new_graph, registry)[0]

    g1py = build_root_from_rust_graph(g1, registry)[0]
    g2py = build_root_from_rust_graph(g2, registry)[0]
    leaves = list(g1py.leaves())
    new_py_graph, _, _ = clone_and_attach(g2py, g1py, leaves, leaves[0])
    assert new_py_graph.resembles(new_py_graph_ref), "clone_and_attach results differ"


def test_traces_and_is_below():
    root = parse_dot_file("test_graph.dot")[0]
    leaf = root.navigate((0, 0, 0, 0))

    # traces
    traces = list(leaf.traces())
    expected = [
        ["1\ndl=6.33", "repeat", "[71]\ndl=16.22", "concat", "[71,71,..,23]\ndl=64.80"],
        [
            "1\ndl=6.33",
            "repeat",
            "[71]\ndl=16.22",
            "concat",
            "[71,71,23]\ndl=48.74",
            "concat",
            "[71,71,..,23]\ndl=64.80",
        ],
    ]
    assert [[n.v for n in tr] for tr in traces] == expected
    rust_graph, id_map = build_rust_graph_from_root(root, registry)
    rust_leaf_id = id_map[leaf]
    rust_traces_ids = rust_graph.traces(rust_leaf_id, True, True, True, True, False)
    assert len(rust_traces_ids) == len(traces)
    for rust_trace_ids, py_trace in zip(rust_traces_ids, traces):
        assert len(rust_trace_ids) == len(py_trace)
        rust_trace_from_py = [id_map[node] for node in py_trace]
        assert rust_trace_ids == rust_trace_from_py

    # is_below
    vn0 = root.navigate((0, 1, 0, 1))
    vn1 = root.navigate((0, 1))
    assert vn0.is_below([vn0])
    assert vn0.is_below([vn1])
    assert leaf.is_below([root])
    assert not vn1.is_below([vn0])
    assert leaf.is_below([vn1])
    assert not leaf.is_below([vn0])

    assert rust_graph.is_below(id_map[vn0], [id_map[vn0]])
    assert rust_graph.is_below(id_map[vn0], [id_map[vn1]])
    assert rust_graph.is_below(id_map[leaf], [id_map[root]])
    assert not rust_graph.is_below(id_map[vn1], [id_map[vn0]])
    assert rust_graph.is_below(id_map[leaf], [id_map[vn1]])
    assert not rust_graph.is_below(id_map[leaf], [id_map[vn0]])


def test_cross_sections():
    root = parse_dot_file("min_desc_len/outlier.dot")[0]
    target_leaf = root.navigate((0, 1, 0, 0))
    leaves = list(root.leaves())

    rust_graph, id_map = build_rust_graph_from_root(root, registry)
    rust_leaf_id = id_map[target_leaf]
    rust_leaves_ids = rust_graph.leaves()

    cross_sects = list(cross_sections(target_leaf, leaves))
    rust_cross_sects = rust_graph.cross_sections(rust_leaf_id, rust_leaves_ids)

    assert len(cross_sects) == len(rust_cross_sects)
    cross_sects_from_py = [([id_map[node] for node in bn], num_ops) for bn, num_ops in cross_sects]

    for (py_bn, py_num_ops), (rust_bn_ids, rust_num_ops) in zip(cross_sects_from_py, rust_cross_sects):
        assert py_bn == rust_bn_ids
        assert py_num_ops == rust_num_ops
