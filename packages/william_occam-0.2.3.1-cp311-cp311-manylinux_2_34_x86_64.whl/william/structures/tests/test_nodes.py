from copy import deepcopy

import pytest

from william.library import Add, BRange, Mult, Negate, Repeat, Sub, Union, Zip2D
from william.library.geometry_ops import Fill, Line, PAdd
from william.structures import Graph, Node, ValueNode
from william.structures.dot_to_graph import parse_dot_file


def test_hashable():
    composites = [parse_dot_file(f"composite/co{k}.dot")[0] for k in range(5)]
    samples = composites[:-2]
    hashes = [hash(node) for node in samples]
    nodes = set(samples)
    assert len(nodes) == len(hashes) == len(samples)
    for node in samples:
        assert node in nodes
    nodes.update(composites)
    assert len(nodes) == len(composites)

    node = deepcopy(composites[0])
    assert hash(node) == hash(composites[0])
    assert node in nodes

    assert node != node.copy_wo_connections()
    assert hash(node) != hash(node.copy_wo_connections())


def test_initialization():
    x1 = ValueNode(output=5)
    x1.set_option(Node(op=Negate()), reverse=True)
    x2 = ValueNode(output=7)
    x2.set_option(Node(op=Sub()), reverse=True)
    node = Node(Add(), children=[x1, x2])
    assert len(node.children) == 2
    assert len(node.parents) == 0
    assert all([isinstance(c, ValueNode) for c in node.children])

    assert len(node.children[0].parents) == 1
    assert node.children[0].parents[0] is node
    assert len(node.children[1].parents) == 1
    assert node.children[1].parents[0] is node

    for child in node.children:
        assert child.options[0].parent is child

    assert node.children[0].options[0].parent is node.children[0]
    assert node.children[1].options[0].parent is node.children[1]


def test_resembles():
    vn = ValueNode(output=-6)
    vn.set_option(Node(Negate(), children=[ValueNode(output=6)]), reverse=True)
    vn1 = ValueNode(output=12)
    vn1.set_option(Node(Mult(), children=[ValueNode(output=3), ValueNode(output=4)]), reverse=True)
    vn2 = ValueNode(output=-1)
    vn2.set_option(Node(Add(), children=[ValueNode(output=5), vn]), reverse=True)
    node1 = Node(Sub(), children=[vn1, vn2])

    vn = ValueNode(output=-5)
    vn.set_option(Node(Negate(), children=[ValueNode(output=5)]), reverse=True)
    vn1 = ValueNode(output=12)
    vn1.set_option(Node(Mult(), children=[ValueNode(output=3), ValueNode(output=4)]), reverse=True)
    vn2 = ValueNode(output=-1)
    vn2.set_option(Node(Add(), children=[ValueNode(output=5), vn]), reverse=True)
    node2 = Node(Sub(), children=[vn1, vn2])

    vn1 = ValueNode(output=12)
    vn1.set_option(Node(Mult(), children=[ValueNode(output=3), ValueNode(output=4)]), reverse=True)
    vn2 = ValueNode(output=-1)
    vn2.set_option(Node(Add(), children=[ValueNode(output=5), ValueNode(output=7)]), reverse=True)
    node3 = Node(Sub(), children=[vn1, vn2])

    # node2 = Node(Sub(), children=[Node(Mult(), children=[Node.var('n', int), Node.var('x', int)]),
    #                               Node(Add(), children=[Node.var('fd', int),
    #                                                     Node(Negate(), children=[Node.var('x', int)])])])
    #
    # node3 = Node(Sub(), children=[Node(Mult(), children=[Node.var('x', int), Node.var('s', int)]),
    #                               Node(Add(), children=[Node.var('x', int),
    #                                                     Node(Negate(), children=[Node.var('as', int)])])])
    # node4 = Node(Sub(), children=[Node(Mult(), children=[Node.var('x', int),
    #                                                      Node.var('s', int)]),
    #                               Node(Add(), children=[Node.var('x', int), Node.var('x', int)])])
    assert node1.resembles(node2, check_values=False)
    assert not node1.resembles(node3, check_values=False)


trees = [
    Node(Sub(), children=[ValueNode(output=3), ValueNode(output=4)]),
    Node(
        Sub(),
        children=[
            ValueNode(output=5),
            Node(Add(), children=[ValueNode(output=10), ValueNode(output=30)]),
        ],
    ),
    Node(
        Mult(),
        children=[
            Node(
                Sub(),
                children=[
                    ValueNode(output=5),
                    Node(Add(), children=[ValueNode(output=10), ValueNode(output=30)]),
                ],
            ),
            Node(Sub(), children=[ValueNode(output=3), ValueNode(output=4)]),
        ],
    ),
]


@pytest.mark.parametrize("t", trees)
def test_repr(t):
    rep = repr(t)
    assert rep.startswith("<") and rep.endswith(">") and "Node" in rep


sexpr_params = [
    ("glue_leaves/dag_0.dot", "(int (add (int (add int int)) int int int))"),
    ("glue_leaves/dag_1.dot", "((= $ int) (int (add (int (add _1 _1)) int int int)))"),
    ("glue_leaves/dag_2.dot", "((= $ int) (int (add (int (add _1 _1)) _1 int int)))"),
    ("glue_leaves/dag_3.dot", "((= $ int) (int (add (int (add _1 _1)) int _1 int)))"),
    ("glue_leaves/dag_4.dot", "((= $ int) (int (add (int (add _1 _1)) int int _1)))"),
    ("glue_leaves/dag_5.dot", "((= $ int) (int (add (int (add _1 int)) _1 int int)))"),
    ("glue_leaves/dag_6.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _1 _2 int)))"),
    ("glue_leaves/dag_7.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _1 int _2)))"),
    ("glue_leaves/dag_8.dot", "((= $ int) (int (add (int (add _1 int)) int _1 int)))"),
    ("glue_leaves/dag_9.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _2 _1 int)))"),
    ("glue_leaves/dag_10.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) int _1 _2)))"),
    ("glue_leaves/dag_11.dot", "((= $ int) (int (add (int (add _1 int)) int int _1)))"),
    ("glue_leaves/dag_12.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) _2 int _1)))"),
    ("glue_leaves/dag_13.dot", "((= $ int) (= $ int) (int (add (int (add _1 _2)) int _2 _1)))"),
    (
        "test_graph.dot",
        "((= $ (list[int] (repeat int list[int]))) (list[int] (concat _1 (list[int] (concat _1 list[int])))))",
    ),
    ("hyper0.dot", "((= $ int) (list[int] (map (Callable[[tuple[int]], int] (int (add _1 _1))) list[int])))"),
]


@pytest.mark.parametrize("name, sexpr", sexpr_params)
def test_sexpr(name, sexpr):
    root = parse_dot_file(name)[0]
    x = root.to_sexpr()
    assert x == sexpr


def SNode(v, op):
    vn = ValueNode(output=v)
    vn.set_option(op, reverse=True)
    return vn


var = [ValueNode(output=i) for i in range(12)]
mult_tree = SNode(0, Node(Mult(), children=[var[0], var[1]]))
dag_params = [
    (Node(Mult(), children=[var[2], var[2]]), (15,), 225),  # x^2
    (
        Node(Add(), children=[SNode(6, Node(Mult(), children=[var[3], var[3]])), var[3]]),
        (5,),
        30,
    ),  # x^2 + x
    (
        Node(Add(), children=[SNode(8, Node(Mult(), children=[var[4], var[4]])), var[5]]),
        (5, 7),
        32,
    ),  # x^2 + y
    (Node(Add(), children=[mult_tree, mult_tree]), (5, 7), 70),  # 5*7 + 5*7
    (
        Node(
            Zip2D(),
            children=[
                SNode(
                    321,
                    Node(
                        BRange(),
                        children=[var[6], SNode(42, Node(Add(), children=[var[6], var[7]]))],
                    ),
                ),
                SNode([8, 9], Node(Repeat(), children=[var[7], var[8]])),
            ],
        ),
        (3, 4, [9]),
        [(3, 9), (4, 9), (5, 9), (6, 9)],
    ),
    (
        Node(
            Union(),
            children=[
                SNode(
                    9,
                    Node(
                        Zip2D(),
                        children=[
                            SNode(
                                5.6,
                                Node(
                                    BRange(),
                                    children=[
                                        var[9],
                                        SNode(19, Node(Add(), children=[var[9], var[10]])),
                                    ],
                                ),
                            ),
                            SNode(8.9, Node(Repeat(), children=[var[10], var[11]])),
                        ],
                    ),
                ),
                var[3],
            ],
        ),
        (3, 4, [9], {(9, 8)}),
        {(3, 9), (4, 9), (5, 9), (6, 9), (9, 8)},
    ),
]
dags = [d[0] for d in dag_params]


@pytest.mark.parametrize("t", trees + dags)
def test_copy(t):
    clone = t.clone()

    assert clone is not t
    assert t.resembles(clone)
    assert clone.resembles(t)

    # copying a node merely copies the connection structure of the graph and the respective nodes, but all nodes
    # keep their references to the same operators (operators are not copied)
    for n1, n2 in zip(t.walk(val_nodes=False), clone.walk(val_nodes=False)):
        assert n1 is not n2  # nodes are not the same objects
        assert n1.op is n2.op  # but they contain the same operator
        assert n1.resembles(n2)  # their content is equal
        assert n1.op == n2.op

    clone.children = []
    assert not t.resembles(clone)
    assert not clone.resembles(t)


@pytest.mark.parametrize(
    ["graph_name", "ref"],
    zip(
        ["co0", "co1", "co2", "co3", "co4", "dag0", "dag1", "dag2", "dag3", "dag4", "dag5"],
        [3, 3, 9, 4, 3, 1, 1, 2, 2, 3, 4, 3],
    ),
)
def test_num_leaves(graph_name, ref):
    root = parse_dot_file(f"composite/{graph_name}.dot")[0]
    assert len(list(root.leaves())) == ref


pn1 = parse_dot_file("nodes/repeat_add_sub_concat_insert.dot")[0]
pn2 = parse_dot_file("nodes/concat_self.dot")[0]


@pytest.mark.parametrize("val_node", [pn1, pn2])
def test_wonder_copy(val_node):
    clone = val_node.clone()

    assert clone is not val_node
    assert val_node.resembles(clone)
    assert clone.resembles(val_node)


def test_walk():
    nodes = list(pn1.walk())
    assert nodes[0] is pn1
    assert nodes[1] is pn1.options[0]
    assert nodes[2] is pn1.options[0].children[0]
    assert nodes[3] is pn1.options[0].children[0].options[0]
    assert nodes[4] is pn1.options[0].children[0].options[0].children[0]
    assert nodes[5] is pn1.options[0].children[0].options[0].children[1]
    assert nodes[6] is pn1.options[0].children[0].options[1]
    assert nodes[7] is pn1.options[0].children[0].options[1].children[0]
    assert nodes[8] is pn1.options[0].children[0].options[1].children[1]
    assert nodes[9] is pn1.options[0].children[1]
    assert nodes[10] is pn1.options[0].children[1].options[0]
    assert nodes[11] is pn1.options[0].children[1].options[0].children[0]
    assert nodes[12] is pn1.options[0].children[1].options[0].children[1]
    assert nodes[13] is pn1.options[0].children[1].options[1]
    assert nodes[14] is pn1.options[0].children[1].options[1].children[0]
    assert nodes[15] is pn1.options[0].children[1].options[1].children[1]
    assert nodes[16] is pn1.options[0].children[1].options[1].children[2]
    assert len(nodes) == 17


@pytest.mark.parametrize("dag", dags)
def test_clone1(dag):
    dag_clone = dag.clone()
    for n1, n2 in zip(dag.walk(), dag_clone.walk()):
        assert n1 is not n2
    assert dag.resembles(dag_clone)


def test_clone2():
    vn1 = ValueNode(output=3)
    n1 = Node(op=Add(), children=[vn1, ValueNode(output=4)], output=7)
    vn2 = ValueNode(output=3)
    n2 = Node(op=Sub(), children=[ValueNode(output=15), vn2], output=12)
    # Node(op=Mult(), children=[n1.parent, n2.parent], output=7*12)
    repl = {vn2: vn1}

    root = n2.parent
    root.clone(repl=repl, replace=True)
    assert len(vn1.parents) == 1
    root.clone(repl=repl, replace=False)
    assert len(vn1.parents) == 2


@pytest.mark.parametrize("node", [pn1.options[0]])
def test_initialization3(node):
    assert len(node.children) == 2
    assert len(node.parents) == 0
    assert all([isinstance(c, ValueNode) for c in node.children])

    assert len(node.children[0].parents) == 1
    assert node.children[0].parents[0] is node
    assert len(node.children[1].parents) == 1
    assert node.children[1].parents[0] is node

    for val_child in node.children:
        assert len(val_child.options) == 2
        for o in val_child.options:
            assert o.parents[0] is node

    nn = node.children[1].options[0]
    assert nn.children[0].parents[0] is nn

    assert node.parent.output.value == [1, 1, 1, 1]
    assert node.children[0].output.value == 2
    assert node.children[1].output.value == [1, 1]
    assert all([o.parent.output.value == 2 for o in node.children[0].options])
    assert all([o.parent.output.value == [1, 1] for o in node.children[1].options])


params = [
    ("decision_tree.dot", 2),
    ("test_graph.dot", 3),
    ("nodes/graph_with_cycle.dot", 2),
    ("nodes/graph_with_cycle2.dot", 3),
]


@pytest.mark.parametrize("graph_name, depth", params)
def test_depth(graph_name, depth):
    val_nodes = parse_dot_file(graph_name)
    actual_depth = val_nodes[0].depth(dict())
    assert actual_depth == depth
    cs = Graph(val_nodes)
    assert cs.depth() == depth


def del_vars(vn):
    for node in vn.walk(val_nodes=False):
        if not node.children:
            node.remove()


def test_subgraph1():
    cs = Graph(parse_dot_file("subgraph/graph1.dot"))
    sub_cs = Graph(parse_dot_file("subgraph/sub_graph1.dot"))
    assert sub_cs.subgraph(cs)

    rep_node = Node(op=Repeat(), children=[ValueNode(output=3), ValueNode(output="hello")])
    cs.nodes[0].set_option(rep_node, reverse=True)
    assert sub_cs.subgraph(cs)

    neg_node = Node(op=Negate(), children=[ValueNode(output=-1)])
    sub_cs.nodes[1].set_option(neg_node, reverse=True)
    assert not sub_cs.subgraph(cs)


params = [
    ("graph1.dot", "sub_graph1.dot", True),
    ("graph2.dot", "sub_graph2.dot", False),
    ("graph3.dot", "sub_graph3.dot", True),
    ("graph4.dot", "sub_graph4.dot", False),
]


@pytest.mark.parametrize("graph_name, subgraph_name, is_subgraph", params)
def test_subgraph(graph_name, subgraph_name, is_subgraph):
    ops = (Line(), PAdd(), Fill())
    cs = Graph(parse_dot_file(f"subgraph/{graph_name}", ops=ops))
    sub_cs = Graph(parse_dot_file(f"subgraph/{subgraph_name}", ops=ops))
    assert sub_cs.subgraph(cs) == is_subgraph


def test_subgraphs_with_same_root():
    vn = parse_dot_file("test_graph.dot")[0]
    subgraphs = list(vn.subgraphs_with_same_root())
    for k, (sg, _) in enumerate(subgraphs):
        sg_ref = parse_dot_file(f"subgraph/all_subgraphs_{k}.dot")[0]
        assert sg.resembles(sg_ref)
