from itertools import permutations
from pathlib import Path

from william.library.hashing import unique_hash
from william.rendering import render, save_graphs
from william.structures.dot_to_graph import parse_dot_file
from william.structures.value_nodes import ValueNode
from william.utils import everything, pretty
from william.utils.containers import EverythingButThis


class Graph:
    """
    Since incremental compression is performed with graphs here, the graph is a list of (value) nodes,
    cutting through the graph. The narrowest cross section of a graph is called bottleneck.
    """

    def __init__(self, nodes, prediction=False):
        if isinstance(nodes, list):
            self.nodes = nodes
        else:
            try:
                self.nodes = list(nodes)
            except TypeError:
                self.nodes = [nodes]
        self._prediction = prediction

    def __contains__(self, item):
        return hash(item) in self._ids

    def __str__(self):
        node_str = "\n".join(pretty(node.val) for node in self.nodes)
        return f"\n{node_str}"

    def __hash__(self):
        return unique_hash((type(self), [node.val.hash for node in self.walk()]))

    @property
    def _ids(self):
        return tuple(hash(node) for node in self.nodes)

    @property
    def id(self):
        return unique_hash(self._ids)

    @classmethod
    def from_values(cls, values, prediction=False):
        nodes = [ValueNode(output=v) for v in values]
        return cls(nodes, prediction=prediction)

    def desc_len(self, mem=None, mode="use_gaussian"):
        return sum([vn.output_dl(mem=mem, mode=mode) for vn in self.nodes])

    def walk(self, seen=None, **kwargs):
        if seen is None:
            seen = set()
        for root_node in self.nodes:
            yield from root_node.walk(seen=seen, **kwargs)

    def breadth_first_walk(self, above=True, below=True, op_nodes=True, val_nodes=True, allowed=everything):
        """Breadth-first walk through graph starting at this cross section."""
        seen = set(self.nodes)
        queue = self.nodes[:]
        while queue:
            node = queue.pop(0)
            if (node.is_val_node and val_nodes or not node.is_val_node and op_nodes) and node in allowed:
                yield node

            for neighbor in node.neighbors(above=above, below=below):
                if neighbor in seen:
                    continue
                seen.add(neighbor)
                queue.append(neighbor)

    def leaves(self, mem=everything, op_nodes=False):
        seen = set()
        for node in self.nodes:
            if node.output.permeable:
                continue
            if node.cycle():
                seen.update(node.parents)

        for node in self.nodes:
            for n in node.walk(seen=seen, above=False, below=True, op_nodes=False, val_nodes=True):
                if not n.options or n.options[0] not in mem or n.options[0] in seen:
                    yield n
                elif op_nodes:
                    yield n.options[0]

    def leaves_dl(self, mem=everything, op_nodes=True, mode="use_gaussian"):
        gen = self.leaves(mem=mem, op_nodes=op_nodes)
        return sum([leaf.output_dl(mem=mem, mode=mode) for leaf in gen])

    @property
    def prediction_node(self):
        if self._prediction:
            return self.nodes[0]

    @property
    def permeable_nodes(self):
        return [node for node in self.nodes if node.output.permeable]

    @property
    def impermeable_nodes(self):
        return [node for node in self.nodes if not node.output.permeable]

    @property
    def model_size(self):
        """
        The 'model' is the graph trying to explain the impermeable nodes. Try to find the residuum, defined as the
        leaf with the largest dl below each of the impermeable nodes.
        Not a beautiful solution, but so be it.
        """
        prediction_nodes = set()
        for val_node in self.nodes:
            if val_node.output.permeable:
                continue
            prediction_nodes.update(set(val_node.leaves(op_nodes=True)))
            leaves_and_dls = [(leaf, leaf.output_dl()) for leaf in self.leaves(op_nodes=False)]
            max_dl_leaf, _ = max(leaves_and_dls, key=lambda x: x[1])
            if max_dl_leaf in prediction_nodes:
                prediction_nodes.remove(max_dl_leaf)
        return sum([n.output_dl() for n in prediction_nodes])

    @property
    def degrees_of_freedom(self):
        # dof, belly = degrees_of_freedom(self, return_belly=True)
        return len(list(self.walk(op_nodes=False)))

    def depth(self):
        store = {}
        return max(node.depth(store) for node in self.nodes)

    def resembles(self, other, debug=False, **kwargs):
        if len(self.nodes) != len(other.nodes):
            if debug:
                raise ValueError
            return False
        for other_nodes_perm in permutations(other.nodes):
            seen = set()
            for node1, node2 in zip(self.nodes, other_nodes_perm):
                if not node1.resembles(node2, seen=seen, debug=debug, **kwargs):
                    break
            else:
                return True
        if debug:
            raise ValueError
        return False

    def subgraph(self, other):
        seen = set()
        if len(self.nodes) != len(other.nodes):
            return False
        for node1, node2 in zip(self.nodes, other.nodes):
            if not node1.subgraph(node2, seen=seen):
                return False
        return True

    def navigate(self, node_num, code):
        return self.nodes[node_num].navigate(code)

    def find(self, values, exact=False):
        found = []
        for node in self.nodes:
            for new_node in node.find(values, exact=exact):
                if new_node not in found:
                    found.append(new_node)
        return found

    def find_by_str(self, s):
        return [node for node in self.walk() if node.v == s]

    def render(self, mem=(), filename: Path | str = "test", color=None, create_file="pdf", condition=True, view=True):
        if not condition:
            return

        return render(self.nodes, mem=mem, filename=filename, color=color, create_file=create_file, view=view)

    def save(self, filename: Path | str):
        save_graphs(self.nodes, filename)

    @classmethod
    def load(cls, filename: Path | str, ops=(), prediction: bool = False):
        return cls(parse_dot_file(filename, ops=ops), prediction=prediction)

    def copy(self):
        return Graph([node.copy_wo_connections() for node in self.nodes], prediction=self._prediction)

    def union(self, nodes, copy=False):
        if isinstance(nodes, Graph):
            nodes = nodes.nodes
        new_nodes = [node.copy_wo_connections() if copy else node for node in self.nodes]
        for node in nodes:
            if node not in self.nodes:
                new_nodes.append(node.copy_wo_connections() if copy else node)
        return Graph(new_nodes, prediction=self._prediction)

    def clone(self, corr=None, hash_dict=None, repl=(), allowed=everything, copy=True, **kwargs):
        new_nodes = []
        if corr is None:
            corr = {}
        for node in self.nodes:
            new_node = node.clone(corr=corr, hash_dict=hash_dict, repl=repl, allowed=allowed, copy=copy, **kwargs)
            new_nodes.append(new_node)
        return Graph(new_nodes, prediction=self._prediction)

    def clone_and_unpack(self, **kwargs):
        clone = self.clone(**kwargs)
        for node in clone.nodes:
            node.unpack()
        return clone

    def insert_mem(self, mem, copy=False, blocked=()):
        corr = {}
        allowed = EverythingButThis(blocked)
        clone = self.clone(corr=corr, allowed=allowed) if copy else self
        if mem is everything:
            return clone, corr
        for old_node, new_node in list(zip(self.walk(op_nodes=False, allowed=allowed), clone.walk(op_nodes=False))):
            # sometimes old_node.val is mem[old_node].val can be true, even though same=False, this can happen
            # with the decoupled node. The decoupled node has to have same=False in order to trigger
            # propagation, but actually, it has the same value in it
            if old_node not in mem or mem[old_node].same or old_node.val is mem[old_node].val:
                continue
            # if value node in mem and has not remained the same, but is a permeable node of the section, make a copy
            # CAN'T REMEMBER WHY THIS WAS HERE
            # if old_node in self.nodes and old_node.output.permeable and old_node is not self.prediction_node:
            #     k = self.nodes.index(old_node)
            #     clone.nodes[k] = old_node.copy_wo_connections()
            new_node.output = mem[old_node].val.copy()
        return clone, corr

    def realize(self):
        """Compute the values of all value nodes in the section, return False if a value fails to compute."""
        values = []
        for val_node in self.walk(op_nodes=False):
            if not val_node.output.realized:
                v = val_node.output.value
                if v is None:
                    return False, values
                values.append(val_node.output)
        return True, values

    def truncate_superfluous_branches(self):
        impermeables = self.impermeable_nodes
        if not impermeables:
            return
        while True:
            val_nodes = list(self.walk(op_nodes=False))
            for val_node in val_nodes:
                if val_node.is_above(impermeables, include_self=True):
                    continue
                if not val_node.options:
                    continue
                self.remove_branch(val_node, me_too=False, removed_pairs=set())
                break
            else:
                break

    def remove_branch(self, node, me_too=True, removed_pairs=None, skip=()):
        removed_nodes = set()
        node.remove_branch(me_too=me_too, removed=removed_nodes, removed_pairs=removed_pairs, skip=skip)
        self.strip_target_nodes_from_removed_branch(removed_nodes, removed_pairs)

    def strip_target_nodes_from_removed_branch(self, removed_nodes, removed_pairs):
        """
        After replacing and removing replaced branch, the one of the target nodes (which may be part of the
        removed branch), should also be cut away from the removed branch, staying with the target graph.
        """
        for node in self.nodes:
            if node not in removed_nodes:
                continue
            while node.parents:
                removed_pairs.add((node, node.parents[0]))
                del node.parents[0]
            while node.options:
                removed_pairs.add((node.options[0], node))
                del node.options[0]
