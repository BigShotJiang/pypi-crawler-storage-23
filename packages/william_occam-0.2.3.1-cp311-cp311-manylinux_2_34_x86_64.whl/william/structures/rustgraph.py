from william.hotloops import RustGraph
from william.library.base import Value
from william.library.types import Array
from william.structures.nodes import Node
from william.structures.value_nodes import ValueNode
from william.utils.registry import RegistryBundle


def build_rust_graph_from_root(
    root_valnode,
    registry: RegistryBundle,
) -> tuple[RustGraph, dict[object, int]]:
    """
    Build a RustGraph from a Python ValueNode graph, starting from 'root_valnode'.

    Traverses the entire connected component (using .walk()) and:
      - registers each Value, Operator and Spec object in their registries,
      - creates corresponding nodes in the Rust graph,
      - stores payload information (value_id, type_id, op_id),
      - reproduces all connections (parents, children, options).

    Returns:
      (rust_graph, id_map) where id_map maps Python node objects (ValueNode/Node)
      to their Rust IDs.
    """
    rust_graph = RustGraph()
    id_map: dict[object, int] = {}

    # --- Pass 1: register and create nodes -----------------------------------
    for node in root_valnode.walk():
        if node.is_val_node:
            val_id = registry.op_id(node.output) if node.output.is_operator else registry.value_id(node.output)
            type_id = registry.spec_id(node.output.spec)
            rust_id = rust_graph.add_value_with_payload(val_id, type_id)
            id_map[node] = rust_id
        else:  # Operator Node
            op_id = registry.op_id(node.op)
            rust_id = rust_graph.add_op_with_payload(op_id)
            id_map[node] = rust_id

    # --- Pass 2: connect edges -----------------------------------------------
    for node in root_valnode.walk():
        rid = id_map[node]
        if node.is_val_node:  # ValueNode
            for op in node.options:
                rust_graph.connect_value_to_op(rid, id_map[op])
        else:  # Operator Node
            for ch in node.children:
                rust_graph.connect_op_to_value(rid, id_map[ch])

    rust_graph.set_root(id_map[root_valnode])
    return rust_graph, id_map


def build_root_from_rust_graph(rust_graph: RustGraph, registry: RegistryBundle):
    """Reconstruct a Python ValueNode graph from a `RustGraph`.

    Parameters
    ----------
    rust_graph:
        The RustGraph instance previously created by `build_rust_graph_from_root`.
    registry:
        RegistryBundle used to map numeric ids back to Python Value/Operator/Spec objects.
    rust_root_id:
        The Rust node id corresponding to the root ValueNode to return.

    Returns
    -------
    root_valnode, id_map
        The reconstructed Python `ValueNode` corresponding to `rust_root_id` and
        a dict mapping rust node ids -> Python node objects (ValueNode or Node).
    """

    n = rust_graph.num_nodes()
    rust_to_py: dict[int, object] = {}

    # --- Pass 1: create ValueNode objects for value nodes
    for rid in range(n):
        payload = rust_graph.get_value_payload(rid)
        if payload is not None:
            val_id, type_id = payload
            val_obj = registry.value(val_id)
            rust_to_py[rid] = ValueNode(output=val_obj)

    # --- Pass 2: create Operator Node objects and attach to their parent ValueNode
    for rid in range(n):
        op_id = rust_graph.get_op_id(rid)
        if op_id is not None:
            op_obj = registry.op(op_id)
            # find parent value node (should exist)
            parent_id = rust_graph.get_parent(rid)
            parent_py = rust_to_py.get(parent_id) if parent_id is not None else None
            # create Node with parent to avoid creating an automatic ValueNode
            node_py = Node(op_obj, parent=parent_py)
            # attach node to parent options if parent exists
            if parent_py is not None:
                parent_py.set_option(node_py, reverse=True)
            rust_to_py[rid] = node_py

    # --- Pass 3: wire children for operator nodes (this will set child.parents)
    for rid in range(n):
        if rid not in rust_to_py:
            continue
        py_node = rust_to_py[rid]
        # only operator Node objects have children
        if isinstance(py_node, Node):
            children = rust_graph.get_children(rid)
            for ch in children:
                child_py = rust_to_py[ch]
                py_node.set_child(child_py, reverse=True)

    # Return requested root and mapping
    root_py = rust_to_py[rust_graph.get_root()]
    return root_py, rust_to_py


def rustgraph_element(op_obj, input_specs, output_spec, registries: RegistryBundle):
    """
    Create a primitive graph in Rust corresponding to one operator node
    with its input and output ValueNodes.

    Args:
        op_obj: Operator object to register (e.g. Add(), Sub(), Mult()).
        input_specs: iterable of Spec objects (or strings to be evaluated).
        output_spec: Spec object (or string to be evaluated).
        registries: RegistryBundle holding .values, .operators, .specs.

    Returns:
        (rust_graph, output_id)
        rust_graph : a new RustGraph containing the primitive subgraph
        output_id  : the Rust ID of the output ValueNode
    """

    rust_graph = RustGraph()

    # Register the operator
    op_id = registries.op_id(op_obj)
    op_rid = rust_graph.add_op_with_payload(op_id)

    # Create input ValueNodes
    child_ids = []
    for s in input_specs:
        spec_obj = eval(s, {"Array": Array}) if isinstance(s, str) else s
        type_id = registries.spec_id(spec_obj)
        val_obj = Value(None, spec=spec_obj)
        val_id = registries.value_id(val_obj)
        val_rid = rust_graph.add_value_with_payload(val_id, type_id)
        child_ids.append(val_rid)
        # connect op -> child
        rust_graph.connect_op_to_value(op_rid, val_rid)

    # Create output ValueNode
    spec_obj = eval(output_spec, {"Array": Array}) if isinstance(output_spec, str) else output_spec
    type_id = registries.spec_id(spec_obj)
    val_obj = Value(None, spec=spec_obj)
    val_id = registries.value_id(val_obj)
    out_rid = rust_graph.add_value_with_payload(val_id, type_id)
    # connect output -> op
    rust_graph.connect_value_to_op(out_rid, op_rid)

    rust_graph.set_root(out_rid)
    return rust_graph
