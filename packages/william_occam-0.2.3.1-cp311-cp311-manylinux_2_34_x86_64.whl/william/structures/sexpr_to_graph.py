from __future__ import annotations

import inspect
import re
from collections.abc import Callable
from typing import Any

from typing_inspect import is_callable_type

from william import library
from william.composite import Composite
from william.fix_op import Fix
from william.library.types import Array
from william.structures.nodes import Node
from william.structures.value_nodes import ValueNode


# find all classes inheriting from Operator
def get_all_operators():
    ops = {}
    for name, cls in inspect.getmembers(library, inspect.isclass):
        if issubclass(cls, library.Operator) and cls is not library.Operator:
            ops[name.lower()] = cls
    return ops


OPERATORS = get_all_operators()
OPERATORS["fix"] = Fix


# -----------------------------
# Helper functions
# -----------------------------


def parse_sexpr(s: str) -> Any:
    """Converts an S-Expression into nested Python lists.
    Does not split at commas inside [] blocks."""
    # Split input into top-level expressions (by newlines or semicolons)
    exprs = [expr.strip() for expr in re.split(r"[\n;]+", s) if expr.strip()]
    results = []
    for expr in exprs:
        tokens = []
        token = ""
        i = 0
        n = len(expr)
        while i < n:
            c = expr[i]
            if c == "(" or c == ")":
                if token.strip():
                    tokens.append(token.strip())
                    token = ""
                tokens.append(c)
                i += 1
                continue
            elif c.isspace():
                if token.strip():
                    tokens.append(token.strip())
                    token = ""
                i += 1
                continue
            elif c == ",":
                i += 1
                continue
            elif c == "$":
                # Handle $variable as a single token
                start = i
                i += 1
                while i < n and (expr[i].isalnum() or expr[i] == "_"):
                    i += 1
                tokens.append(expr[start:i])
                continue
            elif c.isalnum() or c in "._":
                start = i
                while i < n and (expr[i].isalnum() or expr[i] in "._"):
                    i += 1
                if i < n and expr[i] == "[":
                    bracket_count = 0
                    while i < n:
                        if expr[i] == "[":
                            bracket_count += 1
                        elif expr[i] == "]":
                            bracket_count -= 1
                        i += 1
                        if bracket_count == 0:
                            break
                    tokens.append(expr[start:i])
                else:
                    tokens.append(expr[start:i])
                continue
            elif c == "[":
                start = i
                bracket_count = 0
                while i < n:
                    if expr[i] == "[":
                        bracket_count += 1
                    elif expr[i] == "]":
                        bracket_count -= 1
                    i += 1
                    if bracket_count == 0:
                        break
                tokens.append(expr[start:i])
                continue
            else:
                token += c
                i += 1
        if token.strip():
            tokens.append(token.strip())

        stack = []
        current = []
        for tok in tokens:
            if tok == "(":
                stack.append(current)
                current = []
            elif tok == ")":
                if not stack:
                    raise ValueError("Unbalanced parentheses")
                last = stack.pop()
                last.append(current)
                current = last
            else:
                current.append(tok)
        if stack:
            raise ValueError("Unbalanced parentheses")
        results.append(current[0] if current else [])
    if len(results) == 1:
        return results[0]
    return results


def build_graph(expr: str, additional_ops: dict[str, library.Operator] = (), op_dl: float = 1.0) -> ValueNode:
    parsed = parse_sexpr(expr)

    operators = {}
    for name, cls in OPERATORS.items():
        try:
            operators[name] = cls(dl=op_dl)
        except TypeError:
            # probably is abstract
            pass

    operators.update(additional_ops)
    result = _build_graph(parsed, operators=operators)
    root, out_type = result if isinstance(result, tuple) else (result, None)
    return root


def _build_graph(expr: list[Any], operators: dict[str, library.Operator]) -> Node | ValueNode | None:
    """Builds a graph from an S-Expression with variables (DAG support)."""

    # If the S-Expression is a list of definitions, extract them
    def build_expr(e, built_vars=None, output_type=None):
        if built_vars is not None and isinstance(e, str) and e in built_vars:
            return built_vars[e]
        if isinstance(e, str):
            return ValueNode(output=library.Value(None, spec=eval_type_string(e)))
        if not isinstance(e, list):
            return None
        if not e:
            raise ValueError("Empty expression")

        head, *tail = e
        if head in operators:

            def extract_valnode(x):
                res = build_expr(x, built_vars=built_vars, output_type=None)
                # composite inside
                if isinstance(res, tuple) and isinstance(res[0], tuple) and is_callable_type(eval_type_string(res[1])):
                    op = Composite(res[0][0], name="hyper", output_spec=res[1])
                    return ValueNode(output=op)
                return res[0] if isinstance(res, tuple) else res

            children = [extract_valnode(arg) for arg in tail]
            op = operators[head]
            val_node = Node(op, children=children).parent
            if output_type is not None:
                val_node.output = library.Value(None, spec=eval_type_string(output_type))
            return val_node

        # Output type/specification
        output_type = head
        if not tail:
            return ValueNode(output=library.Value(None, spec=eval_type_string(output_type)))
        child_expr = tail[0]
        child = build_expr(child_expr, built_vars=built_vars, output_type=output_type)
        return child, output_type

    if isinstance(expr, list) and expr and all(isinstance(e, list) and len(e) >= 3 and e[0] == "=" for e in expr[:-1]):
        # Collect definitions
        var_map = {}
        for i, def_expr in enumerate(expr[:-1]):
            if def_expr[1] != "$":
                raise ValueError("Variable expected after '='")
            var_name = f"_{i + 1}"
            var_value = def_expr[2]
            var_map[var_name] = var_value
        main_expr = expr[-1]
        # Build all variable subgraphs
        built_vars = {}
        for var_name, var_value in var_map.items():
            built_vars[var_name] = build_expr(var_value, built_vars=built_vars, output_type=None)
        return build_expr(main_expr, built_vars=built_vars, output_type=None)
    return build_expr(expr, output_type=None)


def eval_type_string(s: str) -> Any:
    """Evaluates a type from a string. Placeholders like _1, $, $x are not evaluated."""
    if isinstance(s, str):
        # Platzhalter: $x, $, _1, _2, ...
        if s.startswith("$") or re.match(r"^_\d+$", s):
            return s
        try:
            return eval(s, {"Callable": Callable, "Array": Array})
        except Exception:
            return s
    return s


def operator_from_string(s: str, name="no_name", op_dl: float = 1.0) -> library.Operator:
    """Builds a graph from an S-Expression in string form."""
    root = build_graph(s, op_dl=op_dl)
    num_op_nodes = len(list(root.walk(val_nodes=False)))
    op = root.options[0].op if num_op_nodes == 1 else Composite(root, name=name)
    return op


def build_composite_with_constants(
    sexpr: str, inputs: list[Any], constant_nums: tuple[int, ...], name="no_name", ops: dict[str, library.Operator] = ()
):
    root = build_graph(sexpr, additional_ops=ops)
    for i, leaf in enumerate(root.leaves()):
        if i in constant_nums:
            leaf.output = library.Value(inputs[i])
    op = Composite(root, name=name, constant_nums=constant_nums)
    return op
