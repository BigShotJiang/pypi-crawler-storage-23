from __future__ import annotations

from collections.abc import Iterator, Sequence
from itertools import product
from typing import TYPE_CHECKING, Any, Generic, Protocol, TypeVar

if TYPE_CHECKING:
    pass

from itertools import permutations

from william.library.base import Operator, Value
from william.library.precision import match, recursive_match
from william.library.types import spec_str
from william.rendering import ValueRenderingMixin
from william.utils import Everything, everything, pretty, remove_occurrences, replace_occurrences

# T = Nachbar-Typ
T = TypeVar("T", bound="BaseNode[Any]")


class BaseNode(Protocol, Generic[T]):
    """Gemeinsames Interface für Knoten im bipartiten Graphen."""

    is_val_node: bool
    options: list[T]
    parents: list[T]

    def neighbors(self, *, above: bool, below: bool, unique: bool = False) -> Iterator[T]: ...

    def walk(
        self: T,
        seen: set[BaseNode[Any]] | None = None,
        above: bool = True,
        below: bool = True,
        op_nodes: bool = True,
        val_nodes: bool = True,
        include_self: bool = True,
        allowed: Everything = everything,
    ) -> Iterator[T]: ...

    def is_below(
        self: T,
        nodes: Sequence[BaseNode[Any]],
        trace: tuple[BaseNode[Any], ...] = (),
        include_self: bool = True,
        skip: Sequence[BaseNode[Any]] = (),
    ) -> bool: ...

    def is_above(
        self: T,
        nodes: Sequence[BaseNode[Any]],
        trace: tuple[BaseNode[Any], ...] = (),
        include_self: bool = True,
        skip: Sequence[BaseNode[Any]] = (),
    ) -> bool: ...


class PropertiesMixin(Generic[T]):
    """Mixin mit Nachbarschafts- und Traversal-Logik."""

    is_val_node: bool
    options: list[T]
    parents: list[T]

    def neighbors(self, *, above: bool = True, below: bool = True, unique: bool = False) -> Iterator[T]:
        seen: set[T] = set()
        if below:
            for option in self.options:
                if unique and option in seen:
                    continue
                seen.add(option)
                yield option
        if above:
            for parent in self.parents:
                if unique and parent in seen:
                    continue
                seen.add(parent)
                yield parent

    def walk(
        self: T,
        seen: set[BaseNode[Any]] | None = None,
        above: bool = True,
        below: bool = True,
        op_nodes: bool = True,
        val_nodes: bool = True,
        include_self: bool = True,
        allowed: Everything = everything,
    ) -> Iterator[T]:
        if seen is None:
            seen = set()
        if self in seen or self not in allowed:
            return
        if val_nodes and include_self:
            yield self
        seen.add(self)
        for neighbor in self.neighbors(above=above, below=below):
            if neighbor is None:
                continue
            yield from neighbor.walk(
                seen=seen,
                above=above,
                below=below,
                op_nodes=op_nodes,
                val_nodes=val_nodes,
                allowed=allowed,
            )

    def breadth_first_walk(
        self: T, above: bool = True, below: bool = True, op_nodes: bool = True, val_nodes: bool = True
    ) -> Iterator[T]:
        """Breadth-first walk through graph."""
        seen = {self}
        queue = [(self, 0)]
        while queue:
            node, distance = queue.pop(0)
            if op_nodes and not node.is_val_node or val_nodes and node.is_val_node:
                yield node

            for neighbor in node.neighbors(above=above, below=below):
                if neighbor in seen:
                    continue
                seen.add(neighbor)
                queue.append((neighbor, distance + 1))

    def is_below(
        self: T,
        nodes: Sequence[BaseNode[Any]],
        trace: tuple[BaseNode[Any], ...] = (),
        include_self: bool = True,
        skip: Sequence[BaseNode[Any]] = (),
    ) -> bool:
        if self in trace or self in skip:
            return False
        if include_self and self in nodes:
            return True
        for parent in self.parents:
            if parent.is_below(nodes, trace=(self,) + trace, skip=skip):
                return True
        return False

    def is_above(
        self: T,
        nodes: Sequence[BaseNode[Any]],
        trace: tuple[BaseNode[Any], ...] = (),
        include_self: bool = True,
        skip: Sequence[BaseNode[Any]] = (),
    ) -> bool:
        if self in trace or self in skip:
            return False
        if include_self and self in nodes:
            return True
        for option in self.options:
            if option.is_above(nodes, trace=(self,) + trace, skip=skip):
                return True
        return False

    def cycle(
        self: T,
        trace: tuple[BaseNode[Any], ...] = (),
        impermeable: Sequence[BaseNode[Any]] = (),
    ) -> tuple[BaseNode[Any], ...]:
        """Check if graph is cyclic starting from self. Exclude cycles containing impermeable values."""
        if self in trace:
            cycle_from_self_to_self = (self,) + trace[: trace.index(self)]
            return cycle_from_self_to_self

        for option in self.options:
            # if not hasattr(option, "children"):
            #     continue
            for child in option.children:
                if child in impermeable:
                    continue
                new_trace = child.cycle(trace=(self,) + trace, impermeable=impermeable)
                if new_trace:
                    return new_trace
        return ()

    def roots(self: T, seen: set[BaseNode[Any]] | None = None) -> Iterator[T]:
        if seen is None:
            seen = set()
        if not self.parents and self not in seen:
            seen.add(self)
            yield self
        for parent in self.parents:
            yield from parent.roots(seen=seen)

    def depth(
        self: T,
        store: dict[BaseNode[Any], int],
        trace: tuple[BaseNode[Any], ...] = (),
    ) -> int:
        """The depth of the graph, i.e. the longest path from leaf to root."""
        if self in store:
            return store[self]
        if self in trace:
            return 0

        max_depth = 0
        for option in self.options:
            if not hasattr(option, "children"):
                continue
            depth_val = 1
            if option.children:  # type: ignore[attr-defined]
                depth_val += max(
                    child.depth(store, trace=(self,) + trace)
                    for child in option.children  # type: ignore[attr-defined]
                )
            if depth_val > max_depth:
                max_depth = depth_val
        store[self] = max_depth
        return max_depth

    def traces(self, me_too=True, trace=(), op_nodes=True, val_nodes=True, above=True, below=False):
        myself = (self,) if me_too and val_nodes else ()
        neighbors = list(self.neighbors(above=above, below=below, unique=True))
        if not neighbors:
            yield trace + myself
            return
        if self in trace:
            return
        for neighbor in neighbors:
            yield from neighbor.traces(
                trace=trace + myself,
                op_nodes=op_nodes,
                val_nodes=val_nodes,
                above=above,
                below=below,
            )

    def __getstate__(self):
        state = {key: getattr(self, key) for key in self.__slots__}
        return state

    def __setstate__(self, slots):
        for key, value in slots.items():
            setattr(self, key, value)

    def leaves(self, mem=everything, seen=None, op_nodes=False, blocked=()):
        if seen is None:
            seen = set([])
        if self in seen or self not in mem:
            return
        seen.add(self)
        v = self.output.value
        if not self.options or self.options[0] not in mem or self.options[0] in blocked:
            yield self
            return
        yield from self.options[0].leaves(mem=mem, seen=seen, op_nodes=op_nodes, blocked=blocked)

    def leaves_dl(self, mem=everything, seen=None, op_nodes=True, blocked=(), mode="use_gaussian"):
        gen = self.leaves(mem=mem, seen=seen, op_nodes=op_nodes, blocked=blocked)
        return sum([node.output_dl(mem=mem, mode=mode) for node in gen])

    def resembles(self, other, seen=None, check_values=True, mem=(), allowed=(everything, everything), debug=False):
        """
        Check for functional equality. __eq__ can not be used, as this is used for
        consistency checks within the tree internals.
        <allowed> consists of two sets which are permitted to be investigated for self and other, respectively.
        """
        if seen is None:
            seen = set()
        if (self, other) in seen:
            return True

        # either both have been seen or neither (e.g. when one is a DAG and the other a tree)
        if seen:
            seen1, seen2 = list(zip(*seen))
            s1, s2 = self in seen1, other in seen2
            if s1 != s2:
                return False

        seen.add((self, other))
        if type(self) != type(other):
            return False
        output = mem[self].val if self in mem else self.output
        if check_values and not recursive_match(output.value, other.output.value):
            return False
        options = [n for n in self.options if n in allowed[0]], [n for n in other.options if n in allowed[1]]
        if not perm_check_resembles(
            options[0],
            options[1],
            seen,
            check_values=check_values,
            mem=mem,
            allowed=allowed,
            debug=debug,
        ):
            return False
        parents = [n for n in self.parents if n in allowed[0]], [n for n in other.parents if n in allowed[1]]
        if not perm_check_resembles(
            parents[0],
            parents[1],
            seen,
            check_values=check_values,
            mem=mem,
            allowed=allowed,
            debug=debug,
        ):
            return False
        return True

    def subgraph(self, other, seen=None, check_values=True):
        if seen is None:
            seen = set()
        if (self, other) in seen:
            return True

        # either both have been seen or neither (e.g. when one is a DAG and the other a tree)
        if seen:
            seen1, seen2 = list(zip(*seen))
            s1, s2 = self in seen1, other in seen2
            if s1 != s2:
                return False

        seen.add((self, other))
        if check_values and self.output.hash != other.output.hash:
            return False
        if not perm_check_subgraph(self.parents, other.parents, seen, check_values=check_values):
            return False
        if not perm_check_subgraph(self.options, other.options, seen, check_values=check_values):
            return False
        return True

    def all_subgraphs(self):
        """Yield all subgraphs below this node."""
        for value_node in self.walk(op_nodes=False):
            for subgraph, _ in value_node.subgraphs_with_same_root():
                if subgraph.options:
                    yield subgraph

    def subgraphs_with_same_root(self, seen=None):
        if seen is None:
            seen = set()

        # --- Base case: just yield a copy of the current node ---
        # Each yielded item is (subgraph_root, correspondence_dict)
        # where corr maps original nodes → their copies.
        clone = self.copy_wo_connections()
        yield clone, {self: clone}

        # --- Prevent infinite recursion on cycles or repeated visits ---
        if self in seen:
            return
        seen.add(self)

        # --- If the node has no options (no outgoing edges), stop recursion ---
        if not self.options:
            return

        # --- Collect all possible subgraphs from each child ---
        sub_per_child = []
        for child in self.options[0].children:
            sub_per_child.append(list(child.subgraphs_with_same_root(seen=seen)))

        # --- For every combination of child subgraphs, build a new subgraph ---
        for combo in product(*sub_per_child):
            corr = {}  # mapping original → copy for this subgraph

            # Copy the current node and its option (without connections yet)
            root = self.copy_wo_connections()
            corr[self] = root

            option = self.options[0].copy_wo_connections()
            corr[self.options[0]] = option
            root.set_option(option, reverse=True)

            # --- Attach each child subgraph ---
            for child_dag, child_corr in combo:
                new_child_corr = {}

                # Clone the child DAG with its own correspondence dictionary
                cloned_child = child_dag.clone(corr=new_child_corr)
                root.options[0].set_child(cloned_child, reverse=True)

                # --- Merge child correspondence mappings into parent corr ---
                for k, v in child_corr.items():
                    new_v = new_child_corr[v]
                    if k in corr:
                        # If this original node already exists in corr,
                        # merge the newly cloned structure into the existing one.
                        corr[k].merge(new_v)
                        continue
                    corr[k] = new_v

            # Yield the new subgraph root and its correspondence map
            yield root, corr

    @property
    def commutes(self):
        for option in self.options:
            if not option.commutes:
                return False
        return True

    @property
    def is_leaf(self):
        return self.options == []

    @property
    def val(self):
        return self.output

    @property
    def v(self):
        return pretty(self.output)

    def remove(self):
        """Remove self and parents and options from the graph."""
        while self.parents:
            self.parents[0].remove()
        while self.options:
            self.options[0].remove()

    def remove_branch(self, me_too=True, removed=None, removed_pairs=None, skip=()):
        if removed_pairs is None:
            removed_pairs = set()
        if removed is None:
            removed = set()
        self._remove_branch(removed, removed_pairs, me_too=me_too, skip=skip)
        for pair in removed_pairs.copy():
            node, parent = pair
            if node in removed:
                # remove pair from removed_pairs, hence this pair should stay..
                removed_pairs.remove(pair)
            else:
                node.parents.remove(parent)
        if not me_too:
            for option in self.options:
                removed_pairs.add((option, self))
            self.options = []

    def _remove_branch(self, removed, removed_pairs, me_too=True, skip=()):
        removed_parents = [p for p in self.parents if p in removed]
        # if all parents have been marked as removed and self is to be removed too (me_too), then don't add it it
        # removed_pairs, since the latter only keeps track of connections between a non-removed value node and one of
        # its to-be-removed parents
        if me_too and len(removed_parents) < len(self.parents) or self in skip:
            for p in removed_parents:
                removed_pairs.add((self, p))
            return
        removed.add(self)
        for option in self.options:
            removed.add(option)
            for child in option.children:
                child._remove_branch(removed, removed_pairs, skip=skip)

    def find(self, values, exact=False):
        nodes = []
        for value in values:
            for node in self.find_by_value(value, exact=exact):
                nodes.append(node)
        return nodes

    def find_by_value(self, value, exact=False):
        for node in self.walk():
            if not node.is_val_node and node.op == value:
                yield node
            if node.is_val_node and match(node.output.value, value, exact=exact):
                yield node

    @property
    def connection_hash(self):
        hsh = 0
        for p in self.connections():
            hsh += sum(p)
        return hsh

    def connections(self, nodes=None):
        """
        List of connections in the form of [(4,5), (2,8), (4,8),...] where the numbers come from the node numbers during
        walk enumeration.
        """
        nodes = nodes or list(self.walk())
        num_dict = dict([(node, num) for node, num in zip(nodes, range(len(nodes)))])
        connections = []
        for node in nodes:
            for neighbor in node.neighbors():
                if neighbor in num_dict:
                    connections.append((num_dict[node], num_dict[neighbor]))
        return connections

    def equality_hash(self):
        """Hash based on the structure and values of the graph, not on object identity."""
        return hash(tuple(hash(node.val) for node in self.walk()) + tuple(self.connections()))

    def to_sexpr(self):
        seen = set()
        var_dict = {}
        var_num = [0]
        expr_defs = []
        main_expr = self._to_sexpr(seen, var_dict, var_num, expr_defs)
        return "(" + " ".join(expr_defs + [main_expr]) + ")" if expr_defs else main_expr

    def _to_sexpr(self, seen, var_dict, var_num, expr_defs):
        # if already seen, return variable
        if self in seen:
            return var_dict[self]
        seen.add(self)

        if (
            self in var_dict
            or len(self.parents) > 1
            or len(self.parents) == 1
            and sum([c is self for c in self.parents[0].children]) > 1
        ):
            if self not in var_dict:
                var_num[0] += 1
                var_dict[self] = f"_{var_num[0]}"
                def_str = self._to_expr_helper(seen, var_dict, var_num, expr_defs)
                # store definition
                expr_defs.append(f"(= $ {def_str})")
            return var_dict[self]

        return self._to_expr_helper(seen, var_dict, var_num, expr_defs)

    def _to_expr_helper(self, seen, var_dict, var_num, expr_defs):
        content = spec_str(self.output.spec)

        # take care of composites within value nodes, but only for leaves, since inner graph values are computable
        if hasattr(self.output.value, "root"):
            root = self.output.value.root
            input_specs_str = ", ".join(spec_str(v.output.spec) for v in root.leaves())
            content = f"Callable[[tuple[{input_specs_str}]], {spec_str(root.output.spec)}]"
            if not self.options:
                inner = root._to_sexpr(set(), var_dict, var_num, expr_defs)
                content = f"({content} {inner})"

        if not self.options:
            return content
        inner = " ".join(opt._to_sexpr(seen, var_dict, var_num, expr_defs) for opt in self.options)
        return f"({content} {inner})"

    def clone_and_unpack(self):
        """Clone the node and unpack any composite operators."""
        clone = self.clone()
        clone.unpack()
        return clone

    def unpack(self, seen=None):
        """Whenever there is a composite operator in a node, unpack it, and make a single graph out of it, without composites."""
        if seen is None:
            seen = set()
        if self in seen:
            return
        seen.add(self)
        for node in self.neighbors():
            node.unpack(seen=seen)


def perm_check_resembles(nodes1, nodes2, seen, commutative=True, debug=False, **kwargs):
    if len(nodes1) != len(nodes2):
        if debug:
            raise ValueError
        return False
    # options or parents might occur in a different order in nodes2 than in nodes1, try to match all permutations
    perms = permutations(nodes2) if commutative else [nodes2]
    for nodes2_perm in perms:
        seen_backup = seen.copy()
        for p1, p2 in zip(nodes1, nodes2_perm):
            if not p1.resembles(p2, seen=seen, debug=debug, **kwargs):
                break  # try different permutation
        else:
            return True
        # replace elements in seen by elements in seen_backup without changing the object
        seen.clear()
        seen.update(seen_backup)
    if debug:
        raise ValueError
    return False


# def perm_check_subgraph(nodes1, nodes2, seen, commutative=True, **kwargs):
#     seen_backup = seen.copy()
#     old = perm_check_subgraph_old(nodes1, nodes2, seen, commutative=commutative, **kwargs)
#     seen.clear()
#     seen.update(seen_backup)
#     new = perm_check_subgraph_new(nodes1, nodes2, seen, commutative=commutative, **kwargs)
#     if old != new:
#         seen.clear()
#         seen.update(seen_backup)
#         breakpoint()
#         new = perm_check_subgraph_new(nodes1, nodes2, seen, commutative=commutative, **kwargs)
#     return new


def perm_check_subgraph_old(nodes1, nodes2, seen, commutative=True, **kwargs):
    if len(nodes1) > len(nodes2):
        return False
    seen_backup = seen.copy()
    if commutative or len(nodes1) < len(nodes2):
        for n1 in nodes1:
            for n2 in nodes2:
                if n1.subgraph(n2, seen=seen, **kwargs):
                    break
            else:
                seen.clear()
                seen.update(seen_backup)
                return False
    else:
        for n1, n2 in zip(nodes1, nodes2):
            if not n1.subgraph(n2, seen=seen, **kwargs):
                seen.clear()
                seen.update(seen_backup)
                return False
    return True


def perm_check_subgraph(nodes1, nodes2, seen, commutative=True, **kwargs):
    if len(nodes1) > len(nodes2):
        return False

    if len(nodes1) < len(nodes2):
        seen_backup = seen.copy()
        for n1 in nodes1:
            for n2 in nodes2:
                if n1.subgraph(n2, seen=seen, **kwargs):
                    break
            else:
                seen.clear()
                seen.update(seen_backup)
                return False
        return True

    perms = permutations(nodes2) if commutative else [nodes2]
    for nodes2_perm in perms:
        seen_backup = seen.copy()
        for n1, n2 in zip(nodes1, nodes2_perm):
            if not n1.subgraph(n2, seen=seen, **kwargs):
                break  # try different permutation
        else:
            return True
        seen.clear()
        seen.update(seen_backup)
    return False


class CloningMixin:
    options: list
    parents: list
    output: Value

    def clone(self, corr=None, hash_dict=None, repl=(), allowed=everything, copy=True, replace=True):
        if corr is None:
            corr = {}
        if hash_dict is None:
            hash_dict = {}
        if self in corr:
            return corr[self]

        if self in repl:
            node = repl[self]
        elif copy:
            node = self.copy_wo_connections()
        else:
            node = self
        corr[self] = node
        hash_dict[node.output.hash] = node

        i = 0
        for parent in self.parents:
            new_parent = parent.clone(corr, hash_dict, repl, allowed, copy, replace)
            # this is behind the clone statement, since we want to walk through the whole graph, including the
            # disallowed part, since allowed parts might be found somewhere
            if parent not in allowed:
                continue
            num = i if replace else len(node.parents)
            node.set_parent(new_parent, num=num)
            i += 1

        i = 0
        for option in self.options:
            new_option = option.clone(corr, hash_dict, repl, allowed, copy, replace)
            # this is behind the clone statement, since we want to walk through the whole graph, including the
            # disallowed part, since allowed parts might be found somewhere
            if option not in allowed:
                continue
            num = i if replace else len(node.options)
            node.set_option(new_option, num=num)
            i += 1

        return node

    def copy_wo_connections(self):
        return ValueNode(output=self.output)

    def set_parent(self, parent, num: int | None = None, reverse: bool = False) -> None:
        raise NotImplementedError

    def set_option(self, option, num: int | None = None, reverse: bool = False) -> None:
        raise NotImplementedError


class ValueNode(ValueRenderingMixin, PropertiesMixin, CloningMixin):
    """Value nodes contain values (surprise), as opposed to operator nodes containing ___ (fill in the blank, see Node class)."""

    __slots__ = "parents", "options", "output", "_hash"
    is_val_node = True

    def __init__(self, options=None, parents=None, output: Value | None = None):
        self.parents = parents or []  # parents are wonder nodes
        for p in self.parents:
            p.children.append(self)

        self.options = options or []  # a list/heap of WonderNodes
        for opt in self.options:
            opt.parent = self

        self.output: Value = output if isinstance(output, (Value, Operator)) else Value(output)

        self._hash = hash(repr(self))

    #  Using a node as a dictionary key requires nodes to be hashable. This means,
    #  __hash__ and __eq__ must be defined

    def __hash__(self):
        return self._hash

    def __eq__(self, other):
        return hash(self) == hash(other)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        # Use type(self).__name__ to get the class name without module prefix
        return f"<{type(self).__name__} object at {hex(id(self))}>"

    @property
    def offspring(self):
        """Offspring is a general word for children or options"""
        return self.options

    @property
    def option(self):
        return self.options[0]

    @property
    def ch(self):
        return self.options[0].children

    def set_parent(self, parent, num=None, reverse=False):
        if num is None:
            num = len(self.parents)
        self.parents.extend([None] * (num - len(self.parents) + 1))
        self.parents[num] = parent
        if reverse and not any([self is c for c in parent.children]):
            parent.children.append(self)

    def delete_parent(self, parent, reverse=False):
        num = self.parents.index(parent)
        del self.parents[num]
        if reverse:
            remove_occurrences(parent.children, self)

    def set_option(self, option, num=None, reverse=False):
        if num is None:
            num = len(self.options)
        self.options.extend([None] * (num - len(self.options) + 1))
        self.options[num] = option
        if reverse:
            option.parent = self

    def delete_option(self, option, reverse=False):
        num = self.options.index(option)
        del self.options[num]
        if reverse:
            option.parent = None

    def navigate(self, code):
        if not len(code) or not self.options:
            return self
        return self.options[code[0]].navigate(code[1:])

    def merge(self, other, upper=True, lower=True, log_parents=None, log_options=None):
        """Merge nodes by transferring all connections from <other> node to self."""
        if self is other:
            return
        if upper:
            for p in other.parents:
                if p not in self.parents:
                    self.parents.append(p)
                indices = replace_occurrences(p.children, other, self)
                if log_parents is not None:
                    # <other> is p's child occurring <num> times. All of these <num> p-other links are now p-self links
                    log_parents.add((self, other, p, indices))
            other.parents = []
        if lower:
            for o in other.options:
                if o not in self.options:
                    self.options.append(o)
                o.parent = self
                if log_options is not None:
                    log_options.add((self, other, o))
            other.options = []

    def output_dl(self, mem=None, allow_none=False, mode="use_gaussian"):
        if mem and mem is not everything and self in mem and mem[self].val is not self.output:
            return mem[self].val.desc_len(mode=mode)
        return self.output.desc_len(allow_none=allow_none, mode=mode)
