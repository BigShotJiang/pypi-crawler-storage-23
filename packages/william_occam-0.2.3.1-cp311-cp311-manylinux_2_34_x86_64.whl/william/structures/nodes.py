from inspect import isclass

from william.library.base import Value
from william.library.types import Array
from william.rendering import NodeRenderingMixIn
from william.structures.value_nodes import ValueNode, perm_check_resembles, perm_check_subgraph
from william.utils import everything


class PropertiesMixin:
    """Various generators and properties of graphs"""

    parent: ValueNode | None = None
    op = None
    children: list[ValueNode]

    def neighbors(self, above=True, below=True, unique=False):
        seen = set()
        if above:
            yield self.parent
        if below:
            for child in self.children:
                if unique and child in seen:
                    continue
                seen.add(child)
                yield child

    def walk(
        self,
        seen=None,
        above=True,
        below=True,
        op_nodes=True,
        val_nodes=True,
        include_self=True,
        allowed=everything,
    ):
        """Recursive walk including value nodes."""
        if seen is None:
            seen = set()
        if self in seen or self not in allowed:
            return
        if op_nodes and include_self:
            yield self
        seen.add(self)
        for neighbor in self.neighbors(above=above, below=below):
            if neighbor is None:
                continue
            yield from neighbor.walk(
                seen=seen,
                above=above,
                below=below,
                op_nodes=op_nodes,
                val_nodes=val_nodes,
                allowed=allowed,
            )

    def is_below(self, nodes, trace=(), include_self=True, skip=()):
        if self in skip:
            return False
        if self in nodes:
            return True
        return self.parent.is_below(nodes, trace=trace, skip=skip)

    def is_above(self, nodes, trace=(), include_self=True, skip=()):
        if self in skip:
            return False
        if self in nodes:
            return True
        for child in self.children:
            if child.is_above(nodes, trace=trace, skip=skip):
                return True
        return False

    def roots(self, seen=None):
        yield from self.parent.roots(seen=seen)

    def traces(self, me_too=True, trace=(), op_nodes=True, val_nodes=True, above=True, below=False):
        myself = (self,) if me_too and op_nodes else ()
        if self in trace:
            return
        for neighbor in self.neighbors(above=above, below=below, unique=True):
            yield from neighbor.traces(
                trace=trace + myself, op_nodes=op_nodes, val_nodes=val_nodes, above=above, below=below
            )

    def __getstate__(self):
        state = {key: getattr(self, key) for key in self.__slots__}
        return state

    def __setstate__(self, slots):
        for key, value in slots.items():
            setattr(self, key, value)

    def leaves(self, mem=everything, seen=None, op_nodes=False, blocked=()):
        if seen is None:
            seen = set([])
        if self in seen or self not in mem:
            return
        seen.add(self)
        if op_nodes:
            yield self
        for child in self.children:
            yield from child.leaves(mem=mem, seen=seen, op_nodes=op_nodes, blocked=blocked)

    def leaves_dl(self, mem=everything, seen=None, op_nodes=True, blocked=(), mode="use_gaussian"):
        gen = self.leaves(mem=mem, seen=seen, op_nodes=op_nodes, blocked=blocked)
        return sum([node.output_dl(mem=mem, mode=mode) for node in gen])

    def resembles(self, other, seen=None, check_values=True, mem=(), allowed=(everything, everything), debug=False):
        """Check for functional equality. __eq__ can not be used, as this is used for
        consistency checks within the tree internals."""
        if seen is None:
            seen = set()
        if (self, other) in seen:
            return True
        seen.add((self, other))
        if type(self) != type(other):
            return False
        op = mem[self].val.value if self in mem else self.op
        if op != other.op:
            return False
        children = [n for n in self.children if n in allowed[0]], [n for n in other.children if n in allowed[1]]
        if len(children[0]) != len(children[1]):
            return False
        if not self.parent.resembles(
            other.parent,
            seen=seen,
            check_values=check_values,
            mem=mem,
            allowed=allowed,
            debug=debug,
        ):
            return False
        if not perm_check_resembles(
            children[0],
            children[1],
            seen,
            commutative=op.commutative,
            check_values=check_values,
            mem=mem,
            allowed=allowed,
            debug=debug,
        ):
            return False
        # for c1, c2 in zip(children[0], children[1]):
        #     if not c1.resembles(c2, seen=seen, check_values=check_values, mem=mem, allowed=allowed):
        #         return False
        return True

    def subgraph(self, other, seen=None, check_values=True):
        if seen is None:
            seen = set()
        if (self, other) in seen:
            return True
        seen.add((self, other))
        if self.op != other.op:
            return False
        if len(self.children) != len(other.children):
            return False
        if not self.parent.subgraph(other.parent, seen=seen, check_values=check_values):
            return False
        if not perm_check_subgraph(
            self.children,
            other.children,
            seen,
            commutative=self.op.commutative,
            check_values=check_values,
        ):
            return False
        # for c1, c2 in zip(self.children, other.children):
        #     if not c1.subgraph(c2, seen=seen, check_values=check_values):
        #         return False
        return True

    @property
    def commutes(self):
        if not self.children:
            return True
        callable_op_commutative = self.op.has_callable and self.children[0].output.value.commutative
        if not self.op.commutative and not callable_op_commutative:
            return False
        for child in self.children:
            if not child.commutes:
                return False
        return True

    @property
    def val(self):
        return self.op

    @property
    def v(self):
        return str(self.op)

    @property
    def prval(self):
        return self.op

    def output_dl(self, mem=None, mode="use_gaussian"):
        if mem is not None and self not in mem:
            return 0.0
        return self.op.desc_len(mode=mode)

    @property
    def offset(self):
        offset = [0]
        for c in self.children[:-1]:
            offset.append(offset[-1] + len(list(c.leaves())))
        return offset

    def remove(self):
        """Remove self from graph."""
        num = self.parent.options.index(self)
        del self.parent.options[num]
        for child in self.children:
            if self not in child.parents:
                continue
            num = child.parents.index(self)
            del child.parents[num]

    def _to_sexpr(self, seen, var_dict, var_num, expr_defs):
        return f"({self.op.name} {' '.join([c._to_sexpr(seen, var_dict, var_num, expr_defs) for c in self.children])})"

    def unpack(self, seen=None):
        """Whenever there is a composite operator in a node, unpack it, and make a single graph out of it, without composites."""
        if seen is None:
            seen = set()
        if self in seen:
            return
        seen.add(self)

        if not self.op.primitive:
            inner = self.op.root.clone()
            parent, children = self.parent, self.children[:]
            inner_leaves = list(inner.leaves())
            self.remove()
            parent.merge(inner, upper=False, lower=True)
            for org_child, inner_leaf in zip(children, inner_leaves):
                org_child.merge(inner_leaf, upper=True, lower=False)
            inner.unpack(seen=seen)  # keep unpacking hypergraph recursively

        for vn in self.neighbors():
            vn.unpack(seen=seen)


class CloningMixin:
    parent = None
    op = None
    children: list

    def clone(self, corr=None, hash_dict=None, repl=(), allowed=everything, copy=True, replace=True):
        if corr is None:
            corr = {}
        if hash_dict is None:
            hash_dict = {}
        if self in corr:
            return corr[self]
        if self in repl:
            node = repl[self]
        elif copy:
            node = Node(op=self.op)
        else:
            node = self
        corr[self] = node

        new_parent = self.parent.clone(corr, hash_dict, repl, allowed, copy, replace)
        # this is behind the clone statement, since we want to walk through the whole graph, including the
        # disallowed part, since allowed parts might be found somewhere
        if self.parent in allowed:
            node.parent = new_parent

        i = 0
        for ch in self.children:
            new_ch = ch.clone(corr, hash_dict, repl, allowed, copy, replace)
            # this is behind the clone statement, since we want to walk through the whole graph, including the
            # disallowed part, since allowed parts might be found somewhere
            if ch not in allowed:
                continue
            num = i if replace else len(node.children)
            node.set_child(new_ch, num=num)
            i += 1

        return node


class Node(NodeRenderingMixIn, PropertiesMixin, CloningMixin):
    """This node can branch horizontally into children and vertically into 'options'."""

    __slots__ = "op", "children", "parent", "_hash"
    is_val_node = False
    is_leaf = False  # operator nodes can not be leaves

    def __init__(self, op, children=None, parents=None, output=None, parent=None):
        if isclass(op):
            raise ValueError("Node has to be initialized with instance, not with class")
        self.op = op
        self._hash = hash(repr(self))

        # reference to the value node I belong to
        self.parent = ValueNode(options=[self], parents=parents, output=output) if parent is None else parent

        self.children = []
        if not children:
            return
        for c in children:
            # children are given as WonderNodes, but have to be ValueNodes, inside which they live
            val_child = c if isinstance(c, ValueNode) else c.parent
            self.children.append(val_child)
            if any([self is p for p in val_child.parents]):  # parents are not allowed to repeat themselves
                continue
            val_child.parents.append(self)

    #  Using a node as a dictionary key requires nodes to be hashable. This means,
    #  __hash__ and __eq__ must be defined

    def __hash__(self):
        return self._hash

    def __eq__(self, other):
        return hash(self) == hash(other)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        # Use type(self).__name__ to get the class name without module prefix
        return f"<{type(self).__name__} object at {hex(id(self))}>"

    @property
    def parents(self):
        """Fake parents"""
        return getattr(self.parent, "parents", [])

    @property
    def offspring(self):
        """Offspring is a general word for children or options"""
        return self.children

    def set_parent(self, parent, reverse=False):
        self.parent = parent
        if reverse and not any([self is o for o in parent.options]):
            parent.options.append(self)

    def set_child(self, child, num=None, reverse=False):
        if num is None:
            num = len(self.children)
        self.children.extend([None] * (num - len(self.children) + 1))
        self.children[num] = child
        if reverse and not any([self is p for p in child.parents]):
            child.parents.append(self)

    def navigate(self, code):
        if not len(code) or not self.children:
            return self
        return self.children[code[0]].navigate(code[1:])

    def copy_wo_connections(self):
        return Node(op=self.op.copy())


def graph_from_tuple(rep, mem=None):
    """
    Take tuple representation of a graph and translate it into WILLIAM's format.

    We use the language:
    element := (value, operator, (element1, element2,..)) | value
    For example, <rep> = (v0, op0, ((v1, op1, (v2, v3)),
                                    (v4, op2, (v5,)),
                                    v6
                                   )
                          )
    """
    if mem is None:
        mem = {}
    if not isinstance(rep, tuple):
        if rep not in mem:
            mem[rep] = ValueNode(output=rep)
        return mem[rep]
    val_node = ValueNode(output=rep[0])
    mem[rep[0]] = val_node
    children = [graph_from_tuple(child_rep, mem=mem) for child_rep in rep[2]]
    option = Node(op=rep[1], children=children)
    val_node.set_option(option, reverse=True)
    return val_node


def graph_element(op, input_specs, output_spec, code=None):
    """
    Take operator and define a primitive graph with a single operator node, parent and children of given specs.
    E.g. code=(0, 1, 0, 2) tells the 0th and 2nd input to the operator to be derived from the same child, since DAGs are allowed to have multiple parents.
    """
    if code is None:
        code = tuple(range(len(input_specs)))
    if len(input_specs) != max(code) + 1:
        raise ValueError("Ill-defined input specs.")
    child = {}
    children = []
    for n in code:
        if n not in child:
            s = input_specs[n]
            spec = eval(s, {"Array": Array}) if isinstance(s, str) else s
            child[n] = ValueNode(output=Value(None, spec=spec))
        children.append(child[n])
    s = output_spec
    spec = eval(s, {"Array": Array}) if isinstance(s, str) else s
    val_node = ValueNode(output=Value(None, spec=spec))
    val_node.set_option(Node(op=op, children=children), reverse=True)
    return val_node
