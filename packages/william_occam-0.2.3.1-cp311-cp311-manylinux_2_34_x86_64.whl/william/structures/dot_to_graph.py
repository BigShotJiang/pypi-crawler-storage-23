import json
import re
from collections.abc import Callable, Collection, Iterable
from pathlib import Path
from typing import Any, TypeVar

import numpy as np

from william.composite import Composite
from william.fix_op import Fix
from william.library import Operator, Value, library  # TODO: Fix this cyclic import
from william.library.types import Array
from william.paths import GRAPHS_PATH
from william.structures.nodes import Node
from william.structures.value_nodes import ValueNode
from william.utils import get_path

comp_path = GRAPHS_PATH / "composite"
composites = [fpath.stem for fpath in comp_path.iterdir() if fpath.is_file()]
library = library[:] + [Fix()]

EVAL_LOCALS = {
    "List": list,
    "Dict": dict,
    "Tuple": tuple,
    "Set": set,
    "Array": Array,
    "nan": np.nan,
    "inf": np.inf,
    "array": np.array,
    "Callable": Callable,
}


def load_composite(filename: str, **kwargs) -> Composite:
    root = parse_dot_file(f"composite/{filename}.dot")[0]
    return Composite(root, name=filename, **kwargs)


def parse_dot_file(
    filename: Path | str,
    ops: Collection[Operator] | dict[str, Operator] = (),
    value_cls: type = Value,
    node_dict: dict | None = None,
) -> list[Node | ValueNode]:
    return DotParser(ops=ops, value_cls=value_cls).parse_file(filename, node_dict=node_dict)


class DotParser:
    def __init__(self, ops: Collection[Operator] | dict[str, Operator] = (), value_cls: type = Value) -> None:
        self.value_cls = value_cls
        if isinstance(ops, dict):
            self.ops = ops
        elif isinstance(ops, list | tuple):
            self.ops = dict((op.name, op) for op in ops)
        else:
            raise TypeError(f"Invalid operators: {ops}")

    def parse_file(self, filename: Path | str, node_dict: dict[str, Any] | None = None) -> list[Node | ValueNode]:
        fpath = get_path(filename, root=GRAPHS_PATH, suffix=".dot")
        return self.parse_lines(fpath.read_text().splitlines(), node_dict=node_dict)

    def parse_lines(self, lines: Iterable[str], node_dict=None) -> list[Node | ValueNode]:
        prev_line = ""
        if node_dict is None:
            node_dict = {}
        roots = []
        for line in lines:
            lidx = line.find("label")
            if lidx > 0:
                quot_idx = [match.start() for match in re.finditer('"', line[lidx:])]
                if len(quot_idx) == 1:
                    prev_line = line
                    continue
            node_id, val, edge_type, is_val_node, is_root = self.parse_dot_line(prev_line + line)
            if edge_type == 0:  # not an edge
                node_dict[node_id] = self._make_node(val, is_val_node)
                if is_root:
                    roots.append(node_dict[node_id])
            else:
                self._connect(node_id, val, node_dict, edge_type)
            prev_line = ""
        return roots

    @staticmethod
    def _make_node(val: Any, is_val_node: bool) -> Node | ValueNode:
        return ValueNode(output=val) if is_val_node else Node(op=val)

    def parse_dot_line(self, line: str) -> tuple[str, Any, int, bool, bool]:
        is_val_node, is_root = False, False
        if line[0] != '"':  # not an edge
            node_id, val, is_val_node, is_root = self._parse_node_def(line)
            edge_type = 0
        else:
            node_id, val, edge_type = self._parse_edge_def(line)
        return node_id, val, edge_type, is_val_node, is_root

    def _parse_node_def(self, line: str) -> tuple[str, Any, bool, bool]:
        is_val_node = line[0] in map(str, range(10))
        i = line.find(" ")
        is_root, i = self._is_root(line, i)
        node_id = line[:i]
        val_str, is_json = self._read_value_string(line, i)
        if is_val_node:
            val = self._recognize_value(val_str, is_json, is_root)
        else:
            val = self._recognize_op(val_str)
        return node_id, val, is_val_node, is_root

    @staticmethod
    def _is_root(line: str, i: int) -> tuple[bool, int]:
        if line[:i].find("*") > 0:
            return True, i - 1
        return False, i

    @staticmethod
    def _read_value_string(line: str, i: int) -> tuple[str, bool]:
        j0, j1 = line[i:].find("{"), line[i:].rfind("}")
        if j0 > 0 and ":" in line[i + j0 : i + j1]:
            value_start, value_end = j0, j1 + 1
            is_json = True
        else:
            quot_idx = [match.start() for match in re.finditer('"', line[i:])]
            value_start, value_end = quot_idx[0] + 1, quot_idx[1]
            is_json = False
        result = line[i + value_start : i + value_end]
        if result == "{}":
            result = "None"
        return result, is_json

    def _recognize_value(self, val_str: str, is_json: bool, is_root: bool):
        if not is_json:
            val = self._recognize_value_content(val_str)
            # all roots impermeable by default
            return val if isinstance(val, Operator) else self.value_cls(val, permeable=not is_root)
        val_dict = json.loads(val_str)

        val = None
        if "graph" in val_dict:
            root = self.parse_lines(val_dict["graph"].split("@$%")[:-1])[0]
            val = Composite(root, name=val_dict.get("name", "composite"))
        elif "value" in val_dict:
            val = self._recognize_value_content(val_dict["value"])
        if isinstance(val, Operator):
            return val
        name = val_dict.get("name", None)
        spec = eval(val_dict["spec"], EVAL_LOCALS) if "spec" in val_dict and "None" not in val_dict["spec"] else None
        permeable = val_dict.get("permeable", not is_root)
        dummy = val_dict.get("dummy", False)
        return self.value_cls(val, name=name, spec=spec, permeable=permeable, dummy=dummy)

    def _recognize_value_content(self, val_str: str) -> Any:
        try:
            op = self._recognize_op(val_str)
        except ValueError:
            pass
        else:
            return op
        if val_str[0] == "a" and val_str[:5] != "array":
            return np.array(eval(val_str[1:], EVAL_LOCALS))
        return eval(val_str, EVAL_LOCALS)

    @staticmethod
    def _recognize_var(val: str, new_line_idx: int) -> tuple[str, type | TypeVar]:
        var_name = val[:new_line_idx]
        type_str = val[new_line_idx + 1 :]
        if type_str[:2] == "+T":
            type_var = TypeVar(type_str[1:], covariant=True)
            return var_name, type_var
        typing_type = eval(type_str)
        return var_name, typing_type

    def _recognize_op(self, op_string: str) -> Operator:
        if op_string in self.ops:
            return self.ops[op_string]
        for func in library:
            if str(func) == op_string:
                return func
        if op_string in composites:
            return self.load_composite(op_string)
        raise ValueError(f"Could not find operator '{op_string}' during parsing of dot string.")

    def load_composite(self, filename, **kwargs):
        root = self.parse_file("composite/" + filename + ".dot")[0]
        return Composite(root, name=filename, **kwargs)

    @staticmethod
    def _parse_edge_def(line: str) -> tuple[str, str, int]:
        edge_type = 2 if "has a" in line else 1
        quot_idx = [match.start() for match in re.finditer('"', line)]
        if line.find("->") < 0 or len(quot_idx) < 4:
            raise ValueError("This line does not encode an edge.")
        id1 = line[quot_idx[0] + 1 : quot_idx[1]]
        id2 = line[quot_idx[2] + 1 : quot_idx[3]]
        return id1, id2, edge_type

    @staticmethod
    def _connect(node_id1: str, node_id2: str, node_dict: dict[str, Any], edge_type: int) -> None:
        node1 = node_dict[node_id1]
        node2 = node_dict[node_id2]
        if isinstance(node1, ValueNode):
            node1.set_option(node2, reverse=True)
        else:
            node1.set_child(node2, reverse=True)
