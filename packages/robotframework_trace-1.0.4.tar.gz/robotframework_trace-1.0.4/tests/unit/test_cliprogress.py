import unittest
from io import StringIO
from unittest.mock import patch

from robot_trace.RobotTrace import (
    ANSI,
    InterceptStream,
    ProgressBox,
    RobotTrace,
    TestStatistics,
    TestTimings,
    TraceStack,
    Verbosity,
    _ANSICode,
    _past_tense,
)


class RobotTraceTestBase(unittest.TestCase):
    def setUp(self):
        super().setUp()
        import sys
        from io import StringIO

        self.orig_stdout = sys.__stdout__
        self.orig_stderr = sys.__stderr__
        sys.__stdout__ = StringIO()
        sys.__stderr__ = StringIO()

    def tearDown(self):
        super().tearDown()
        import sys

        sys.__stdout__ = self.orig_stdout
        sys.__stderr__ = self.orig_stderr


class TestVerbosity(unittest.TestCase):
    def test_equality(self):
        self.assertEqual(Verbosity.QUIET, Verbosity.QUIET)

    def test_inequality(self):
        self.assertNotEqual(Verbosity.QUIET, Verbosity.NORMAL)

    def test_ordering_less_than(self):
        self.assertLess(Verbosity.QUIET, Verbosity.NORMAL)

    def test_ordering_less_than_debug(self):
        self.assertLess(Verbosity.NORMAL, Verbosity.DEBUG)

    def test_from_string_lowercase(self):
        self.assertEqual(Verbosity.from_string("quiet"), Verbosity.QUIET)

    def test_from_string_uppercase(self):
        self.assertEqual(Verbosity.from_string("NORMAL"), Verbosity.NORMAL)

    def test_from_string_mixed_case(self):
        self.assertEqual(Verbosity.from_string("DeBuG"), Verbosity.DEBUG)

    def test_from_string_invalid(self):
        self.assertEqual(Verbosity.from_string("invalid"), Verbosity.NORMAL)


class TestANSI(unittest.TestCase):
    def test_ansicode_call(self):
        code = _ANSICode("\033[31m")
        result = code("Hello")
        self.assertEqual(result, "\033[31mHello\033[0m")

    def test_ansi_len(self):
        text = "Hello \033[31mWorld\033[0m!"
        self.assertEqual(ANSI.len(text), 12)  # "Hello World!"


class TestTraceStack(unittest.TestCase):
    def test_initial_state_trace(self):
        stack = TraceStack("test")
        self.assertEqual(stack.trace, "")

    def test_initial_state_errors(self):
        stack = TraceStack("test")
        self.assertFalse(stack.has_errors)

    def test_initial_state_warnings(self):
        stack = TraceStack("test")
        self.assertFalse(stack.has_warnings)

    def test_push_keyword(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        self.assertEqual(stack._depth, 1)

    def test_pop_keyword(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        stack.pop_keyword()
        self.assertEqual(stack._depth, 0)

    def test_flush_keyword_depth(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        stack.flush()
        self.assertEqual(stack._depth, 0)

    def test_flush_keyword_trace_content(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        stack.flush()
        self.assertIn("Keyword A", stack.trace)

    def test_append_trace(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        stack.append_trace("Hello world")
        self.assertEqual("  Hello world\n", stack.trace)

    def test_append_multiline_trace(self):
        stack = TraceStack("test")
        stack.push_keyword("Keyword A")
        stack.append_trace("Hello world\nLine 2")
        self.assertEqual("  Hello world\n  Line 2\n", stack.trace)


class TestTestStatistics(unittest.TestCase):
    def test_start_suite_counts(self):
        stats = TestStatistics()
        attributes = {"suites": [1, 2, 3], "totaltests": 10, "longname": "My Suite"}

        stats.start_suite("My Suite", attributes)
        self.assertEqual(stats.top_level_test_count, 10)

    def test_start_test_increment(self):
        stats = TestStatistics()
        stats.start_test("My Test", {"longname": "My_Suite.My Test"})
        self.assertEqual(len(stats.started_tests), 1)

    def test_end_test_pass(self):
        stats = TestStatistics()
        attributes = {"status": "PASS", "longname": "My_Suite.My Test"}

        stats.end_test("My Test", attributes)
        self.assertEqual(len(stats.completed_tests), 1)
        self.assertEqual(len(stats.passed_tests), 1)

    def test_end_test_fail(self):
        stats = TestStatistics()
        attributes = {"status": "FAIL", "longname": "My_Suite.My Test"}

        stats.end_test("My Test", attributes)
        self.assertEqual(len(stats.completed_tests), 1)
        self.assertEqual(len(stats.failed_tests), 1)


class TestTestTimings(unittest.TestCase):
    def test_format_time_none(self):
        self.assertEqual(TestTimings.format_time(None), "unknown")

    def test_format_time_seconds_only(self):
        self.assertEqual(TestTimings.format_time(45), "45s")

    def test_format_time_minutes_seconds(self):
        self.assertEqual(TestTimings.format_time(125), " 2m  5s")

    def test_format_time_hours_minutes_seconds(self):
        self.assertEqual(TestTimings.format_time(3665), " 1h  1m  5s")

    @patch("time.time", return_value=100.0)
    def test_elapsed_time(self, mock_time):
        timings = TestTimings()
        timings.start_suite()
        mock_time.return_value = 110.0
        self.assertEqual(timings.get_elapsed_time(), 10.0)


class TestRobotTraceHelper(RobotTraceTestBase):
    def setUp(self):
        super().setUp()
        self.listener = RobotTrace(verbosity="NORMAL", console_progress="NONE")

    def test_past_tense_upper_pass(self):
        self.assertEqual(_past_tense("PASS"), "PASSED")

    def test_past_tense_upper_fail(self):
        self.assertEqual(_past_tense("FAIL"), "FAILED")

    def test_past_tense_upper_skip(self):
        self.assertEqual(_past_tense("SKIP"), "SKIPPED")

    def test_past_tense_lower(self):
        self.assertEqual(_past_tense("pass"), "passed")

    def test_past_tense_title_try(self):
        self.assertEqual(_past_tense("Try"), "Tried")

    def test_past_tense_title_stop(self):
        self.assertEqual(_past_tense("Stop"), "Stopped")

    def test_verbosity_settings_debug(self):
        listener = RobotTrace(verbosity="DEBUG", console_progress="NONE")
        self.assertTrue(listener.print_passed)
        self.assertTrue(listener.print_skipped)
        self.assertTrue(listener.print_failed)

    def test_verbosity_settings_quiet(self):
        listener_quiet = RobotTrace(verbosity="QUIET", console_progress="NONE")
        self.assertFalse(listener_quiet.print_passed)
        self.assertTrue(listener_quiet.print_failed)


class TestStatisticsFormatReturns(unittest.TestCase):
    def test_format_run_results_all_zero(self):
        stats = TestStatistics()
        stats.top_level_test_count = 0
        stats.completed_tests = []
        stats.passed_tests = []
        stats.skipped_tests = []
        stats.failed_tests = []

        expected = "0 tests, 0 completed (0 passed, 0 skipped, 0 failed)."
        self.assertEqual(stats.format_run_summary(), expected)

    def test_format_run_results_one_test(self):
        stats = TestStatistics()
        stats.top_level_test_count = 1
        stats.completed_tests = ["t1"]
        stats.passed_tests = ["t1"]
        stats.skipped_tests = []
        stats.failed_tests = []

        expected = "1 test, 1 completed (1 passed, 0 skipped, 0 failed)."
        self.assertEqual(stats.format_run_summary(), expected)

    def test_format_run_results_with_errors_and_warnings(self):
        stats = TestStatistics()
        stats.top_level_test_count = 2
        stats.completed_tests = ["t1", "t2"]
        stats.passed_tests = ["t1"]
        stats.skipped_tests = []
        stats.failed_tests = ["t2"]
        stats.errors = {"t1": ["Error 1"]}
        stats.warnings = {"t1": ["Warn 1"]}

        expected = (
            "2 tests, 2 completed (1 passed, 0 skipped, 1 failed). "
            "1 test raised errors. 1 test raised warnings."
        )
        self.assertEqual(stats.format_run_summary(), expected)

    def test_format_run_results_extra(self):
        stats = TestStatistics()
        stats.failed_tests = ["t2"]
        stats.errors = {"t1": ["error 1"]}
        stats.warnings = {"t1": ["warn 1"]}
        res = stats.format_run_results()
        self.assertIn("Failing test:\n- t2", res)
        self.assertIn("Erroring test:\n- t1:\n  - error 1", res)
        self.assertIn("Warning test:\n- t1:\n  - warn 1", res)


class TestTimingsFormatETA(unittest.TestCase):
    @patch("time.time", return_value=120.0)
    def test_format_eta_calculates(self, mock_time):
        timings = TestTimings()
        timings.run_start_time = 100.0  # elapsed = 20s

        stats = TestStatistics()
        stats.completed_tests = [1, 2, 3, 4, 5]
        stats.top_level_test_count = 15

        # 5 tests took 20s -> 4s per test. 10 remaining -> 40s
        self.assertEqual(timings.format_eta(stats), "40s")

    def test_format_eta_unknown(self):
        timings = TestTimings()
        stats = TestStatistics()
        stats.completed_tests = []
        self.assertEqual(timings.format_eta(stats), "unknown")


class TestRobotTraceInitialization(RobotTraceTestBase):
    @patch("sys.stdout.isatty", return_value=True)
    def test_colors_auto_tty(self, mock_isatty):
        listener = RobotTrace(colors="AUTO", console_progress="NONE")
        self.assertTrue(listener.colors)

    @patch("sys.stdout.isatty", return_value=False)
    def test_colors_auto_no_tty(self, mock_isatty):
        listener = RobotTrace(colors="AUTO", console_progress="NONE")
        self.assertFalse(listener.colors)

    def test_colors_on(self):
        listener = RobotTrace(colors="ON", console_progress="NONE")
        self.assertTrue(listener.colors)

    def test_colors_off(self):
        listener = RobotTrace(colors="OFF", console_progress="NONE")
        self.assertFalse(listener.colors)

    @patch("sys.stdout", new_callable=StringIO)
    def test_console_progress_stdout(self, mock_stdout):
        listener = RobotTrace(console_progress="STDOUT")
        import sys

        self.assertEqual(listener.progress_box.stream, sys.stdout)

    @patch("sys.stderr", new_callable=StringIO)
    def test_console_progress_stderr(self, mock_stderr):
        listener = RobotTrace(console_progress="STDERR")
        import sys

        self.assertEqual(listener.progress_box.stream, sys.stderr)


class TestInterceptStream(unittest.TestCase):
    def test_write(self):
        stream = InterceptStream(None, lambda x: None)
        self.assertEqual(stream.write("hello"), 5)
        self.assertEqual(stream.written_lines, ["hello"])

    def test_writelines(self):
        stream = InterceptStream(None, lambda x: None)
        stream.writelines(["hello", "world"])
        self.assertEqual(stream.written_lines, ["hello", "world"])

    def test_flush(self):
        received = []
        stream = InterceptStream(None, lambda x: received.append(x))
        stream.write("hello")
        stream.write("world")
        stream.flush()
        self.assertEqual(received, ["hello", "world"])
        self.assertEqual(stream.written_lines, [])

    def test_getattr(self):
        class DummyStream:
            def dummy_method(self):
                return "dummy"

        stream = InterceptStream(DummyStream(), lambda x: None)
        self.assertEqual(stream.dummy_method(), "dummy")


class TestProgressBox(unittest.TestCase):
    def setUp(self):
        from io import StringIO

        self.stream = StringIO()
        self.box = ProgressBox(stream=self.stream, width=80)

    def test_draw(self):
        self.box.draw()
        output = self.stream.getvalue()
        self.assertIn("┌" + "─" * 78 + "┐", output)
        self.assertIn("└" + "─" * 78 + "┘", output)

    def test_draw_with_progress_bar(self):
        self.box.total_tasks = 10
        self.box.completed_tasks = 5
        self.stream.truncate(0)
        self.stream.seek(0)
        self.box.draw()
        output = self.stream.getvalue()
        expected_bar = "┌────────┤" + "█" * 30 + "░" * 30 + "├────────┐"
        self.assertIn(expected_bar, output)

    def test_progress_bar_narrow_terminal(self):
        box_narrow = ProgressBox(stream=self.stream, width=39)
        self.stream.truncate(0)
        self.stream.seek(0)
        box_narrow.total_tasks = 10
        output = self.stream.getvalue()
        self.assertIn("┌" + "─" * 37 + "┐", output)

    def test_setters_redraw(self):
        with (
            patch.object(self.box, "draw") as mock_draw,
            patch.object(self.box, "clear") as mock_clear,
        ):
            self.box.total_tasks = 5
            mock_clear.assert_called_once()
            mock_draw.assert_called_once()

            mock_clear.reset_mock()
            mock_draw.reset_mock()

            self.box.completed_tasks = 2
            mock_clear.assert_called_once()
            mock_draw.assert_called_once()

            # No redraw if value unchanged
            mock_clear.reset_mock()
            mock_draw.reset_mock()
            self.box.completed_tasks = 2
            mock_clear.assert_not_called()
            mock_draw.assert_not_called()

    def test_write_line_truncation(self):
        left = "A" * 100
        right = "B" * 10
        self.box.write_line(0, left, right)
        line = self.box._lines[0]
        self.assertTrue(line.endswith("BBBBBBBBBB"))
        expected_left_len = self.box.width - 4 - 10 - 1
        self.assertTrue(line.startswith("A" * (expected_left_len - 3) + "..."))

    def test_clear(self):
        self.box.clear()
        self.assertIn(ANSI.Cursor.CLEAR_LINE, self.stream.getvalue())

    def test_none_stream(self):
        box_none = ProgressBox(None, 80)
        box_none.draw()
        box_none.write_line(0, "left")
        box_none.clear()


class TestRobotTraceLifecycle(RobotTraceTestBase):
    def setUp(self):
        super().setUp()
        from io import StringIO

        patcher = patch("sys.stdout", new_callable=StringIO)
        self.mock_stdout = patcher.start()

        self.listener = RobotTrace(console_progress="NONE", verbosity="NORMAL")

    def tearDown(self):
        patch.stopall()
        super().tearDown()

    def test_suite_lifecycle(self):
        attributes = {"suites": [1], "totaltests": 1, "longname": "My_Suite"}

        self.listener.start_suite("My_Suite", attributes)
        self.assertEqual(len(self.listener.stats.started_suites), 1)

        end_attributes = {"status": "PASS", "longname": "My_Suite", "message": ""}
        self.listener.end_suite("My_Suite", end_attributes)
        self.assertEqual(self.listener.result_printer.suite_trace_stack._depth, 0)

    def test_test_lifecycle(self):
        suite_attributes = {"suites": [1], "totaltests": 1, "longname": "My_Suite"}
        self.listener.start_suite("My_Suite", suite_attributes)
        self.assertEqual(self.listener.progress_box.total_tasks, 1)

        test_attributes = {"longname": "My_Suite.My Test"}
        self.listener.start_test("My Test", test_attributes)
        self.assertTrue(self.listener.in_test)

        end_test_attributes = {
            "status": "PASS",
            "message": "All good",
            "longname": "My_Suite.My Test",
        }
        self.listener.end_test("My Test", end_test_attributes)
        self.assertFalse(self.listener.in_test)
        self.assertEqual(len(self.listener.stats.passed_tests), 1)
        self.assertEqual(self.listener.progress_box.completed_tasks, 1)

    def test_test_lifecycle_fail_with_errors(self):
        suite_attributes = {"suites": [1], "totaltests": 1, "longname": "My_Suite"}
        self.listener.start_suite("My_Suite", suite_attributes)

        self.listener.start_test("My Test", {"longname": "My_Suite.My Test"})

        msg_attributes = {"level": "ERROR", "message": "An error occurred"}
        self.listener.log_message(msg_attributes)

        end_test_attributes = {
            "status": "FAIL",
            "message": "Failure",
            "longname": "My_Suite.My Test",
        }
        self.listener.end_test("My Test", end_test_attributes)
        self.assertEqual(len(self.listener.stats.failed_tests), 1)


class TestRobotTraceKeywords(RobotTraceTestBase):
    def setUp(self):
        super().setUp()
        self.listener = RobotTrace(console_progress="NONE", verbosity="NORMAL")

        suite_attributes = {"suites": [1], "totaltests": 1, "longname": "My_Suite"}
        self.listener.start_suite("My_Suite", suite_attributes)

        self.listener.start_test("My Test", {"longname": "My_Suite.My Test"})

    def test_keyword_lifecycle(self):
        attributes = {
            "type": "KEYWORD",
            "args": ["arg1"],
            "status": "PASS",
            "elapsedtime": 1500,
            "kwname": "My Keyword",
        }

        self.listener.start_keyword("BuiltIn.My Keyword", attributes)
        self.assertEqual(self.listener.result_printer.test_trace_stack._depth, 1)

        self.listener.end_keyword("BuiltIn.My Keyword", attributes)
        self.assertEqual(self.listener.result_printer.test_trace_stack._depth, 0)
        self.assertIn("2s", self.listener.result_printer.test_trace_stack.trace)

    def test_keyword_lifecycle_not_run(self):
        attributes = {
            "type": "KEYWORD",
            "args": [],
            "status": "NOT RUN",
            "kwname": "My Keyword",
        }

        self.listener.start_keyword("MyLib.My Keyword", attributes)
        self.listener.end_keyword("MyLib.My Keyword", attributes)
        self.assertEqual(self.listener.result_printer.test_trace_stack._depth, 0)


class TestRobotTraceLogging(RobotTraceTestBase):
    def setUp(self):
        super().setUp()
        self.listener = RobotTrace(
            console_progress="NONE", verbosity="NORMAL", colors="OFF"
        )
        suite_attributes = {"suites": [1], "totaltests": 1, "longname": "My_Suite"}
        self.listener.start_suite("My_Suite", suite_attributes)
        self.listener.start_test("My Test", {"longname": "My_Suite.My Test"})

    def test_log_message_warn(self):
        attributes = {"level": "WARN", "message": "A warning\nLine 2"}
        self.listener.log_message(attributes)

        self.assertEqual(len(self.listener.stats.warnings), 1)
        self.assertTrue(self.listener.result_printer.test_trace_stack.has_warnings)
        self.assertIn(
            "W A warning", self.listener.result_printer.test_trace_stack.trace
        )
        self.assertIn("Line 2", self.listener.result_printer.test_trace_stack.trace)

    def test_log_message_error(self):
        attributes = {"level": "ERROR", "message": "An error"}
        self.listener.log_message(attributes)

        self.assertEqual(len(self.listener.stats.errors), 1)
        self.assertTrue(self.listener.result_printer.test_trace_stack.has_errors)
        self.assertIn("E An error", self.listener.result_printer.test_trace_stack.trace)

    def test_log_message_info(self):
        attributes = {"level": "INFO", "message": "Info msg"}
        self.listener.log_message(attributes)

        self.assertIn("I Info msg", self.listener.result_printer.test_trace_stack.trace)

    def test_log_message_to_console_stdout(self):
        import sys

        self.listener.log_message_to_console("Some stdout text", "stdout")
        self.assertIn(
            "Logged from test stdout: Some stdout text", sys.__stdout__.getvalue()
        )

    def test_log_message_to_console_stderr(self):
        import sys

        self.listener.log_message_to_console("Some stderr text\n", "stderr")
        self.assertIn(
            "Logged from test stderr: Some stderr text", sys.__stdout__.getvalue()
        )


class TestRobotTraceClose(RobotTraceTestBase):
    def test_close_prints_summary(self):
        import sys

        listener = RobotTrace(console_progress="NONE", verbosity="NORMAL")
        listener.stats.top_level_test_count = 1
        listener.stats.completed_tests = ["t1"]

        listener.close()
        output = sys.__stdout__.getvalue()
        self.assertIn("RUN COMPLETE", output)


class TestLiveTracePrinter(RobotTraceTestBase):
    def test_live_trace_printer_output(self):
        import sys

        listener = RobotTrace(console_progress="NONE", verbosity="DEBUG", colors="OFF")

        listener.start_suite(
            "My_Suite",
            {"suites": [1], "totaltests": 1, "longname": "My_Suite", "status": ""},
        )
        listener.start_test("My Test", {"longname": "My_Suite.My Test", "status": ""})

        listener.start_keyword(
            "BuiltIn.Log", {"type": "KEYWORD", "args": ["Hello"], "kwname": "Log"}
        )
        listener.log_message({"level": "INFO", "message": "Hello world\nLine 2"})
        listener.end_keyword("BuiltIn.Log", {"status": "PASS", "elapsedtime": 1000})

        listener.end_test(
            "My Test", {"status": "PASS", "longname": "My_Suite.My Test", "message": ""}
        )

        output = sys.__stdout__.getvalue()
        self.assertIn("SUITE: My_Suite", output)
        self.assertIn("TEST: My_Suite.My Test", output)
        self.assertIn("▶ BuiltIn.Log('Hello')", output)
        self.assertIn("  I Hello world", output)
        self.assertIn("    Line 2", output)
        self.assertIn("  ✓ PASS", output)
