"""Tests for z21aio package."""
