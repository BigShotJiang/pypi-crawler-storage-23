#!/usr/bin/env python3
"""
Standalone CLI for LinkedIn Recruiter bridge. Zero dependencies (stdlib only).

Install:
    pip install linkedin-bridge

Session mode (no login needed — paste session ID from extension):
    linkedin-bridge --session SESSION_ID ping
    linkedin-bridge --session SESSION_ID parseCandidateList
    linkedin-bridge --session SESSION_ID changeStage --stageName "Grade 5"

Legacy login mode (saves token to ~/.linkedin-bridge-token):
    linkedin-bridge login --email user@example.com --password secret
    linkedin-bridge parseCandidateList

Override API URL:
    LINKEDIN_BRIDGE_URL=http://localhost:8321 linkedin-bridge --session ID ping
"""

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

API_BASE = os.environ.get("LINKEDIN_BRIDGE_URL", "https://sourcer.8d1.ai")
TOKEN_FILE = Path.home() / ".linkedin-bridge-token"


def _load_token():
    """Load saved JWT access token."""
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    return None


def _save_token(token):
    """Save JWT access token to file."""
    TOKEN_FILE.write_text(token)
    TOKEN_FILE.chmod(0o600)


def _auth_headers():
    """Return Authorization header if token exists."""
    token = _load_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}


def http_get(url, headers=None):
    hdrs = headers or _auth_headers()
    req = urllib.request.Request(url, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 401:
            print("ERROR: Not authenticated. Run: linkedin-bridge login --email EMAIL --password PASS", file=sys.stderr)
            sys.exit(1)
        raise
    except urllib.error.URLError:
        print("ERROR: API not reachable at " + API_BASE, file=sys.stderr)
        sys.exit(1)


def http_post(url, body, headers=None):
    data = json.dumps(body).encode()
    hdrs = {"Content-Type": "application/json"}
    hdrs.update(headers or _auth_headers())
    req = urllib.request.Request(url, data=data, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=35) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 401:
            print("ERROR: Not authenticated. Run: linkedin-bridge login --email EMAIL --password PASS", file=sys.stderr)
            sys.exit(1)
        try:
            detail = json.loads(e.read()).get("detail", str(e))
        except Exception:
            detail = str(e)
        return e.code, {"detail": detail}
    except urllib.error.URLError:
        print("ERROR: Connection lost", file=sys.stderr)
        sys.exit(1)


def cmd_login(args):
    """Authenticate with email/password and save token."""
    params = _parse_params(args)
    email = params.get("email")
    password = params.get("password")

    if not email or not password:
        print("Usage: linkedin-bridge login --email EMAIL --password PASSWORD", file=sys.stderr)
        sys.exit(1)

    code, data = http_post(
        f"{API_BASE}/api/login",
        {"email": email, "password": password},
        headers={},
    )

    if code != 200:
        print(f"ERROR: Login failed — {data.get('detail', data)}", file=sys.stderr)
        sys.exit(1)

    token = data.get("access_token")
    if not token:
        print("ERROR: No access_token in response", file=sys.stderr)
        sys.exit(1)

    _save_token(token)
    print(f"Logged in. Token saved to {TOKEN_FILE}")


def _parse_params(args):
    """Parse --key value pairs from args list."""
    params = {}
    i = 0
    while i < len(args):
        if args[i].startswith("--"):
            key = args[i][2:]
            if i + 1 < len(args) and not args[i + 1].startswith("--"):
                val = args[i + 1]
                if val.isdigit():
                    val = int(val)
                elif val.lower() in ("true", "false"):
                    val = val.lower() == "true"
                params[key] = val
                i += 2
            else:
                params[key] = True
                i += 1
        else:
            i += 1
    return params


def _extract_session(argv):
    """Extract --session value from argv, return (session_id, remaining_argv)."""
    remaining = []
    session_id = None
    i = 0
    while i < len(argv):
        if argv[i] == "--session" and i + 1 < len(argv):
            session_id = argv[i + 1]
            i += 2
        else:
            remaining.append(argv[i])
            i += 1
    return session_id, remaining


def main():
    # Extract --session before other parsing
    session_id, argv = _extract_session(sys.argv[1:])

    if len(argv) < 1:
        print("Usage: linkedin-bridge [--session SESSION_ID] <action> [--param value ...]", file=sys.stderr)
        print("       linkedin-bridge login --email EMAIL --password PASSWORD", file=sys.stderr)
        sys.exit(1)

    action = argv[0]

    # Login is handled separately (no session mode)
    if action == "login":
        return cmd_login(argv[1:])

    params = _parse_params(argv[1:])

    if session_id:
        # Session-ID auth: no JWT needed, verify session is active
        status = http_get(f"{API_BASE}/api/bridge/{session_id}/status", headers={})
        if not status.get("connected"):
            print("ERROR: Bridge not connected", file=sys.stderr)
            sys.exit(1)
    else:
        # Legacy JWT mode: get session from /api/bridge/status
        status = http_get(f"{API_BASE}/api/bridge/status")
        if not status.get("connected") or not status.get("session_id"):
            print("ERROR: Bridge not connected", file=sys.stderr)
            sys.exit(1)
        session_id = status["session_id"]

    # Execute — session-ID auth works without Bearer token
    code, data = http_post(
        f"{API_BASE}/api/bridge/{session_id}/execute",
        {"action": action, "params": params, "timeout": 30},
        headers={"Content-Type": "application/json"},
    )

    if code != 200:
        print(f"ERROR: {data.get('detail', data)}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(data.get("result", data), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    sys.exit(main())
