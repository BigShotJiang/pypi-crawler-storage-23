"""
Empty setup.py for pytorch-triton-xpu
Target: HackerOne Bug Bounty - IntelSoftware
"""
from setuptools import setup

setup(
    name="pytorch-triton-xpu",
    version="0.0.0",
    description="Empty placeholder package - reserved for IntelSoftware",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
