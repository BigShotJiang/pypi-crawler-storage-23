# 绿色包注意清单

## runtime/python314._pth

```
python314.zip
.
..

# Uncomment to run site.main() automatically
#import site
```

## 异常处理提示.txt

```text
> 1.无法打开的优先参考 快速开始
 https://cgs.101114105.xyz/deploy/quick-start
 
其次考虑换源，开控制台逐条尝试，或自己找可用的 pypi 国内源
.\CGS.exe -i https://mirrors.aliyun.com/pypi/simple
.\CGS.exe -i https://repo.huaweicloud.com/repository/pypi/simple

> 2.能打开主界面后却使用异常的参考  FAQ
 https://cgs.101114105.xyz/faq/

---资源引用链接-------------------------------------------

> python 下载
https://www.python.org/downloads/release/python-3138/

> kemono 所需环境引用链接
https://cgs.101114105.xyz/feat/script.html#%E2%9A%A0%EF%B8%8F-%E9%80%9A%E7%94%A8%E5%89%8D%E7%BD%AE%E9%A1%BB%E7%9F%A5
```
