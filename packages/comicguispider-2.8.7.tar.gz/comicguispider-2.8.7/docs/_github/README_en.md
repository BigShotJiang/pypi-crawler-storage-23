<div align="center">
  <a href="https://github.com/jasoneri/ComicGUISpider" target="_blank">
    <img src="https://img-cgs.101114105.xyz/file/1765128492268_cgs_eat.png" alt="logo">
  </a>
  <h1 id="koishi"style="margin: 0.1em 0;">ComicGUISpider(CGS)</h1>
  <img src="https://img.shields.io/github/license/jasoneri/ComicGUISpider" alt="tag">
  <img src="https://img.shields.io/badge/Platform-All-blue?color=#4ec820" alt="tag">
  <img src="https://img.shields.io/badge/-%3E3.12-brightgreen.svg?logo=python" alt="tag">
  <a href="https://github.com/jasoneri/ComicGUISpider/releases" target="_blank">
    <img src="https://img.shields.io/github/downloads/jasoneri/ComicGUISpider/total?style=social&logo=github" alt="tag">
  </a>

  <p align="center">
  <a href="https://cgs.101114105.xyz/en/">🏠HomePage</a> | 
  <a href="https://cgs.101114105.xyz/en/deploy/quick-start">🚀Quick-Start</a> | 
  <a href="https://github.com/jasoneri/ComicGUISpider/releases/latest">📦portable-pkg</a>
  </p>

</div>

## 📑 Introduction

Comic-Downloader

▼ Demo ▼

|                             Preview / Multi-select / Paging                              |                         Clipboard Tasks                         |
|:-------------------------------------------------------------------------------:|:----------------------------------------------------------------------------:|
| ![turn-page-new](https://img-cgs.101114105.xyz/file/1764957470369_common-usage.gif) | ![load_clip](https://img-cgs.101114105.xyz/file/1764957479778_load_clip.gif) |

## ✨Features

- Easy to use with simple configuration
- Just click a few times after preview to download, and you can also browse the website on the preview window
- Convenient to specify selection with input rules like -3 (select the last three), 0 (select all), etc.
- Based on page retention, flipping pages is like putting items in a shopping cart
- Built-in restart is very convenient, and it is even more convenient with multiple launches
- Read clipboard stream
- De-duplication, add identifiers, etc.


## 🚨Availability Monitor

| Website                                 | locale |          Notes          |                                               status<br>(UTC+8)                                                |
|:----------------------------------------|:------:|:-----------------------:|:--------------------------------------------------------------------------------------------------------------:|
| [MangaCopy](https://www.2025copy.com/) |  :cn:  |  |  ![status_kaobei](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_kaobei.json)  |
| [Māngabz](https://mangabz.com)          |  :cn:  |                         | ![status_mangabz](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_mangabz.json) |
| [18comic](https://18comic.vip/)         |  :cn:  |           🔞            |      ![status_jm](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_jm.json)      |
| [wnacg](https://www.wnacg.com/)         |  :cn:  |           🔞            |   ![status_wnacg](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_wnacg.json)   |
| [ExHentai](https://exhentai.org/)       |   🌏   |           🔞            | ![status_ehentai](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_ehentai.json) |
| [Hitomi](https://hitomi.la/)     | 🌏 |     🔞     | ![status_hitomi](https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_hitomi.json) |
| [Kemono](https://kemono.cr)     | 🌏 |     🔞/[📒Usage](https://cgs.101114105.xyz/feat/script)    |  |

---

## 📜Contributing

- [✒️Dev Guide](https://cgs.101114105.xyz/en/dev)  
- [🌏i18n Guide](https://cgs.101114105.xyz/dev/i18n)  

---

## 📢 Changelog

Left-bottom of the config-dialog has `Check Update` button, please update according to the prompt

> [🕑Full History](https://cgs.101114105.xyz/changelog/history.html)

## 🔨 Configuration

[🔨Configuration](https://cgs.101114105.xyz/locate/en/config)

## 🍮Adaptable Reader

<table><tbody>  
  <tr>
    <td><div align="center"><a href="https://github.com/jasoneri/redViewer" target="_blank">
      <img src="https://img-cgs.101114105.xyz/file/1766904566021_rv.png" alt="logo" height="60">
      </a></div></td>
    <td><div align="center"><a href="https://github.com/gotson/komga" target="_blank">
      <img src="https://raw.githubusercontent.com/gotson/komga/master/.github/readme-images/app-icon.png" alt="komga" height="60">
      </a></div></td>
    <td><div align="center"><a href="https://github.com/Ruben2776/PicView" target="_blank">
      <img src="https://avatars.githubusercontent.com/u/4200419?s=48&v=4" alt="PicView" height="60">
      </a></div></td>
  </tr>
  <tr>
    <td>rV<br>Fully seamless integration with CGS<br><s>CGS serves it</s></td>
    <td>komga/ComicRack series<br>Requires post-processing set to <code>.cbz</code></td>
    <td>PicView<br>Image manager, good choice for managing subdirectory <br> images or <code>.cbz</code></td>
  </tr>
</tbody></table>

## 🔇 Disclaimer

See [License](https://github.com/jasoneri/ComicGUISpider/blob/GUI/LICENSE). By using this project you agree to:

- Non-commercial use only
- Developer's final interpretation

---
![CGS_en](https://count.getloli.com/get/@CGS_en?theme=rule34)
