# 📜 贡献指南 Contributing

## 版本发布

版本发布目前通过合并到主分支(`GUI`) 的「PR」后打 tag 自动触发打包与发布，  
主分支不接受非开发组发起的PR，开发需基于并PR到最新后缀带`dev`的分支。  
> [RoadMap/Todo](https://www.yuque.com/baimusheng/programer/vxlg9kdke2by2t7h?singleDoc)  

## 文档

如果要为文档做贡献，请注意以下几点：

- 文档皆存放在 docs 目录上，仅限 markdown
- 请确保你的 PR 标题和描述中包含了你的修改的目的和意图

撰写文档请使用规范的书面化用语，遵照 Markdown 语法，以及 [中文文案排版指北](https://github.com/sparanoid/chinese-copywriting-guidelines) 中的规范。
