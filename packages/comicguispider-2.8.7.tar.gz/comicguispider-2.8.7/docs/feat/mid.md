# CGSMid

自动化工作流编辑器。

## Timeline 数值

| Lane | 阶段 | 值 |
|------|------|-----|
| A | WAIT_SITE | 90 |
| B | WAIT_SEARCH | 100 |
| C | WAIT_BOOK_DECISION | 210 |
| D | WAIT_EP_DECISION | 310 |
| E | POSTPROCESSING | 600 |

## 用法

1. 从右侧规则库点 `+` 添加规则到 Lane
2. 点击规则按钮可查看详情/排序/移除
3. 开启「自动化」开关启用
