# 🎸 常规功能

::: tip 欢迎提供功能建议，提交issue / PR / 此页下方评论区留言 等  
:::

## 适用性

> [!Info] 没列出的功能全网适用，一眼独占的工具如 hitomiTool 也不会列出  

|  |  [拷贝](https://www.2025copy.com/) |    [Māngabz](https://mangabz.com)     | [禁漫](https://18comic.vip/) |    [wnacg](https://www.wnacg.com/)    | [ExHentai](https://exhentai.org/) | [hitomi](https://hitomi.la/) | [hcomic](https://h-comic.com) |
|:--------------------------------------|:-------------:|:---------:|:----:|:----------:|:----------:|:----------:|:----------:|
| 预览 | ❌ |     ❌ | ✔️ | ✔️ | ✔️ | ✔️ | ✔️ |
| 📋读剪贴板 | ❌ | ❌ | ✔️ | ✔️ | ✔️ | 🚧 | ❌ |
| 🔎聚合搜索 | ❌ | ❌ | ✔️ | ✔️ | ✔️ | 🚧 | ✔️ |
| 以图搜索 | ❌ | ❌ | ✔️ | ✔️ | ✔️ | 🚧 | ✔️ |

## 1. 主界面

| 功能项 | 说明 |
|:-------------:|:---------|
| 搜索框预设 | 搜索框区域按 `空格` 或右键点`展开预设`即可弹出预设项 （序号输入框同理）<br>主界面选中文本右键可快速加进预设 |
| 翻页按钮组 | 当列表结果出来后开启使用 |
| 读剪贴板 | ![clipBtn](../assets/img/feat/clipBtn.png)[📋跳转阅读 > 使用](/feat/clip) |
| 内置重启 | ![rebootBtn](../assets/img/feat/reboot.png)选择网站后开启使用   |

## 2. 预览/内置浏览器

| 功能项 | 说明 |
|:-------------:|:---------|
| 顶栏按钮组 | 左上窗口置顶，其他常规浏览器的按钮自行摸索<br>可鼠标 **按住顶栏空白处** 移动内置浏览器窗口 |
| 右上复制按钮 | 复制未完成任务链接，[📋跳转阅读 > 复制未完成任务链接](/feat/clip.md#复制未完成任务链接)   |
| 其他常规 | 多选/翻页等如动图所示。详情使用看 `🎥视频使用指南3` |
  

## 3. 工具视窗

![toolsWin](../assets/img/feat/toolsWin.png)

点击 rV 按钮触发显示，点击对应标签切换工具，常驻 rV工具

<table>
  <thead>
    <tr>
      <th style="text-align: center;">功能项</th>
      <th style="text-align: left;">说明</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align: center; vertical-align: middle;" rowspan="4">rV工具<br><small>rvTool</small></td>
      <td style="text-align: left;"><strong>显示记录</strong>: 显示已阅最新话、下载最新话<br><code>已阅最新话</code>需用 <a href="https://github.com/jasoneri/redViewer" target="_blank" rel="noopener noreferrer">rV</a> 操作过才有记录</td>
    </tr>
    <tr>
      <td style="text-align: left;"><strong>扫描本地</strong>: 重新刷本地数据存至<code>储存目录/rV.db</code>，<br>供<code>显示记录</code>使用，并且与 rV 共用</td>
    </tr>
    <tr>
      <td style="text-align: left;"><strong>rv相关</strong>: 下载&emsp;/&emsp;(右下)绑定<code>锚点</code>与运行&emsp;/&emsp;(左下)清除<code>锚点</code></td>
    </tr>
    <tr>
      <td style="text-align: left;"><strong>以图搜索</strong>: 借用 saucenao，按 CGS 内指示操作即可<br>（图一乐，你可以沿着链路继续找，或者来提供点靠谱的api/网站）</td>
    </tr>
    <tr>
      <td style="text-align: center;">聚合搜索<br><small>aggrSearch</small></td>
      <td style="text-align: left;"><a href="/feat/ags">🔎跳转阅读 > 使用</a></td>
    </tr>
    <tr>
      <td style="text-align: center;">hitomiTool</td>
      <td style="text-align: left;"><a href="https://img-cgs.101114105.xyz/file/1764957586207_hitomi-tools-usage.gif" target="_blank" rel="noopener noreferrer">📹参考用法</a></td>
    </tr>
  </tbody>
</table>
