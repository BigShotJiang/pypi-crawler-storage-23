from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from bauklotz.business.filter import FilterConfig, Filter
from bauklotz.reporting.item.generic.c4 import C4Item, Relation, External, ExplicitRelation, User
from bauklotz.reporting.item.generic.dependency import Dependency
from bauklotz.reporting.item.project import ProjectFile


@dataclass(frozen=True)
class C4MethodSummaryConfig(FilterConfig):
    pass


_NON_STRUCTURAL = (External, Relation, ExplicitRelation, User)


class C4MethodSummaryFilter(Filter[C4Item | ProjectFile | Dependency, C4Item, C4MethodSummaryConfig]):
    """Aggregates C4 items, project files, and file-level dependencies.

    On close, assigns each project file to the C4 items whose declaration
    directory contains it, then infers a single directed ``Uses`` relation
    for every pair of structural C4 items that share at least one
    file-level dependency.
    """

    def __init__(self, name: str, config: C4MethodSummaryConfig):
        super().__init__(name, config)
        self._c4_items: list[C4Item] = []
        self._project_files: list[ProjectFile] = []
        self._dependencies: dict[str, set[str]] = defaultdict(set)

    def process(self, item: C4Item | ProjectFile | Dependency) -> Iterable[C4Item]:
        match item:
            case C4Item():
                self._c4_items.append(item)
            case ProjectFile():
                self._project_files.append(item)
            case Dependency() as dep:
                self._dependencies[dep.source.canonical_id].add(dep.target)
        return ()

    def close(self) -> Iterable[C4Item]:
        self._assign_members()
        yield from self._c4_items
        yield from self._infer_relations()

    def _assign_members(self) -> None:
        """Add each project file to every C4 item whose declaration directory contains it."""
        for item in self._c4_items:
            item_dir: Path = item.declared_in.path.parent
            for project_file in self._project_files:
                if project_file.path.parent.is_relative_to(item_dir):
                    item.add_member(project_file)

    def _infer_relations(self) -> list[Relation]:
        """Return one ``Uses`` relation per ordered pair of structural items
        that have at least one file-level dependency between them."""
        structural: list[C4Item] = [
            item for item in self._c4_items
            if not isinstance(item, _NON_STRUCTURAL)
        ]
        relations: list[Relation] = []
        seen: set[tuple[str, str]] = set()

        for source in structural:
            source_file_ids: set[str] = {f.canonical_id for f in source.get_members()}
            for target in structural:
                if source is target:
                    continue
                pair = (source.canonical_id, target.canonical_id)
                if pair in seen:
                    continue
                for target_file in target.get_members():
                    if any(target_file.canonical_id in self._dependencies[sf_id]
                           for sf_id in source_file_ids):
                        seen.add(pair)
                        source.add_relation(target, "Uses", "Dependency")
                        relations.append(Relation("Uses", source, target, "Dependency"))
                        break

        return relations
