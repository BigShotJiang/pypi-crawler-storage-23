# remottxrea/simulator/caption_pool.py

import random


class CaptionPool:

    def __init__(self):

        self.captions = [

            "Sample media upload",
            "Automation media test",
            "Profile activity media",
            "Safe loop attachment",
            "Session media pulse"
        ]

    def get(self):

        return random.choice(self.captions)


caption_pool = CaptionPool()
