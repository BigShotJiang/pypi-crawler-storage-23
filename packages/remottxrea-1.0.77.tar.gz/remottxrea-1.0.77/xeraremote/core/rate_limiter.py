# core/rate_limiter.py

import asyncio
import time

from ..config.main_config import RATE_LIMIT_DELAY

class RateLimiter:

    def __init__(self):
        self.last_call = {}

    async def wait(self, key: str):

        delay = RATE_LIMIT_DELAY

        last = self.last_call.get(key, 0)
        now = time.time()

        diff = now - last

        if diff < delay:
            await asyncio.sleep(delay - diff)

        self.last_call[key] = time.time()


rate_limiter = RateLimiter()
