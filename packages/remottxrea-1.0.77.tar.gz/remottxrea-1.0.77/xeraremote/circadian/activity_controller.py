# remottxrea/circadian/activity_controller.py

import asyncio
from datetime import datetime, timedelta


class ActivityController:

    def __init__(self, duration_hours):

        self.duration = duration_hours

    # ---------- RUN SHIFT ----------
    async def run_shift(
        self,
        shift_accounts
    ):

        print(
            f"\n🟢 Shift start "
            f"({len(shift_accounts)} accounts)"
        )

        # Start all
        for phone, app in shift_accounts:
            await app.start()

        await asyncio.sleep(
            self.duration * 3600
        )

        # Stop all
        for phone, app in shift_accounts:
            await app.stop()

        print("🔴 Shift end")
