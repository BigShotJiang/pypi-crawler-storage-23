from .base_siglent_sdg_series_awg_instrument import BaseSiglentSDGSeriesAWGInstrument

class SiglentSDG1000AWGInstrument(BaseSiglentSDGSeriesAWGInstrument):
    """
    NOTE: This feature is experimental and subject to change. It was not fully validated yet.
          If you are a owner of this device and if you are interested in contribution, please open a issue with the
          validation results of the BalderHub package test results.
    """
