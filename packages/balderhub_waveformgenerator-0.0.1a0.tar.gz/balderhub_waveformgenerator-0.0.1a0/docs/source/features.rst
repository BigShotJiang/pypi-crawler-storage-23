Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================


.. autoclass:: balderhub.waveformgenerator.lib.scenario_features.WaveformGeneratorFeature
    :members:

Instruments
-----------

.. autoclass:: balderhub.waveformgenerator.lib.scenario_features.WaveformGeneratorInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.scenario_features.WaveformGeneratorInstrumentChannel
    :members:


Setup Features
==============

Siglent-Devices
---------------

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.BaseSiglentSDGSeriesAWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG800AWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG1000AWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG1000XAWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG2000XAWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG5000AWGInstrument
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.siglent.SiglentSDG6000XOrXEAWGInstrument
    :members:


Channel Selection Features
--------------------------

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.WaveformGeneratorInstrumentChannel2
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.WaveformGeneratorInstrumentChannel1
    :members:

.. autoclass:: balderhub.waveformgenerator.lib.setup_features.DirtyWaveformGeneratorChannel
    :members:
