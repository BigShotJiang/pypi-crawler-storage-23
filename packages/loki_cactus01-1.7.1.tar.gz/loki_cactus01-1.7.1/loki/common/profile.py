from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass
from http.cookiejar import Cookie
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse

import requests
from http.cookiejar import MozillaCookieJar


_SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$")


def _atomic_write_text(path: Path, text: str, *, encoding: str = "utf-8") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, encoding=encoding, dir=str(path.parent)) as tmp:
        tmp.write(text)
        tmp_path = Path(tmp.name)
    tmp_path.replace(path)


def default_loki_home() -> Path:
    env = os.environ.get("LOKI_HOME")
    if env:
        return Path(env).expanduser().resolve()

    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "loki"

    return Path.home() / ".loki"


def _validate_name(kind: str, value: str) -> str:
    if not _SAFE_NAME_RE.match(value):
        raise ValueError(f"Invalid {kind} name: {value!r}")
    return value


@dataclass(frozen=True, slots=True)
class ProfileRef:
    platform: str
    name: str = "default"

    def __post_init__(self) -> None:
        _validate_name("platform", self.platform)
        _validate_name("profile", self.name)


class Profile:
    def __init__(self, root: Path, ref: ProfileRef) -> None:
        self.root = root
        self.ref = ref

    @property
    def dir(self) -> Path:
        return self.root / "profiles" / self.ref.platform / self.ref.name

    @property
    def config_path(self) -> Path:
        return self.dir / "config.json"

    @property
    def cookies_path(self) -> Path:
        return self.dir / "cookies.txt"

    def _cookies_file_text(self) -> str | None:
        try:
            return self.cookies_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None

    @staticmethod
    def _looks_like_netscape_cookie_file(text: str) -> bool:
        stripped = text.lstrip()
        if stripped.startswith("# Netscape HTTP Cookie File"):
            return True
        for line in stripped.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            return len(parts) >= 7
        return False

    @staticmethod
    def _parse_cookie_header(text: str) -> dict[str, str]:
        cookies: dict[str, str] = {}
        for part in text.replace("\n", " ").split(";"):
            part = part.strip()
            if not part or "=" not in part:
                continue
            name, value = part.split("=", 1)
            name = name.strip()
            if not name:
                continue
            cookies[name] = value.strip()
        return cookies

    def _default_cookie_domain(self) -> str | None:
        config = self.read_config()
        domain = config.get("cookie_domain")
        if isinstance(domain, str) and domain.strip():
            return domain.strip()

        base_url = config.get("base_url")
        if isinstance(base_url, str) and base_url.strip():
            host = urlparse(base_url.strip()).hostname
            if host:
                return host

        return None

    @staticmethod
    def _normalize_cookie_url(value: str | None) -> str | None:
        if not isinstance(value, str):
            return None
        raw = value.strip()
        if not raw:
            return None
        if "://" not in raw:
            raw = f"https://{raw}"
        parsed = urlparse(raw)
        if not parsed.scheme or not parsed.netloc:
            return None
        return f"{parsed.scheme}://{parsed.netloc}/"

    def _default_cookie_url(self) -> str | None:
        config = self.read_config()
        cookie_url = config.get("cookie_url")
        normalized_cookie_url = self._normalize_cookie_url(cookie_url if isinstance(cookie_url, str) else None)
        if normalized_cookie_url:
            return normalized_cookie_url

        base_url = config.get("base_url")
        normalized_base_url = self._normalize_cookie_url(base_url if isinstance(base_url, str) else None)
        if normalized_base_url:
            return normalized_base_url
        return None

    @staticmethod
    def _normalize_same_site(value: Any) -> str | None:
        if not isinstance(value, str):
            return None
        lowered = value.strip().lower()
        if lowered == "strict":
            return "Strict"
        if lowered == "lax":
            return "Lax"
        if lowered == "none":
            return "None"
        return None

    @staticmethod
    def _cookie_scope_to_playwright(
        cookie: Cookie,
        *,
        default_domain: str | None,
        default_url: str | None,
    ) -> dict[str, Any] | None:
        result: dict[str, Any] = {
            "name": cookie.name,
            "value": cookie.value,
        }
        domain = (cookie.domain or default_domain or "").strip()
        if domain:
            result["domain"] = domain
            result["path"] = cookie.path or "/"
        elif default_url:
            result["url"] = default_url
        else:
            return None

        if cookie.expires is not None:
            result["expires"] = float(cookie.expires)
        result["secure"] = bool(cookie.secure)

        rest = getattr(cookie, "_rest", {}) or {}
        rest_lc = {str(k).lower(): v for k, v in rest.items()}
        if "httponly" in rest_lc:
            result["httpOnly"] = True
        same_site = Profile._normalize_same_site(rest_lc.get("samesite"))
        if same_site:
            result["sameSite"] = same_site
        return result

    def build_playwright_cookies(self, *, base_url: str | None = None) -> list[dict[str, Any]]:
        self.ensure()
        raw = self._cookies_file_text()
        if raw is None or not raw.strip():
            return []

        default_domain = self._default_cookie_domain()
        default_url = self._normalize_cookie_url(base_url) or self._default_cookie_url()

        if self._looks_like_netscape_cookie_file(raw):
            jar = MozillaCookieJar(str(self.cookies_path))
            jar.load(ignore_discard=True, ignore_expires=True)
            cookies: list[dict[str, Any]] = []
            for cookie in jar:
                cookie_item = self._cookie_scope_to_playwright(
                    cookie,
                    default_domain=default_domain,
                    default_url=default_url,
                )
                if cookie_item is not None:
                    cookies.append(cookie_item)
            return cookies

        cookies = []
        for name, value in self._parse_cookie_header(raw).items():
            cookie_item: dict[str, Any] = {"name": name, "value": value}
            if default_domain:
                cookie_item["domain"] = default_domain
                cookie_item["path"] = "/"
            elif default_url:
                cookie_item["url"] = default_url
            else:
                continue
            cookies.append(cookie_item)
        return cookies

    def read_config(self) -> dict[str, Any]:
        try:
            raw = self.config_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return {}
        data = json.loads(raw) if raw.strip() else {}
        if not isinstance(data, dict):
            raise ValueError(f"Invalid config type in {self.config_path}: expected object")
        return data

    def write_config(self, config: Mapping[str, Any]) -> None:
        _atomic_write_text(self.config_path, json.dumps(dict(config), ensure_ascii=False, indent=2) + "\n")

    def ensure(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)

    def load_cookies_into(self, session: requests.Session) -> None:
        self.ensure()
        raw = self._cookies_file_text()
        if raw is None or not raw.strip():
            return

        if self._looks_like_netscape_cookie_file(raw):
            jar = MozillaCookieJar(str(self.cookies_path))
            jar.load(ignore_discard=True, ignore_expires=True)
            session.cookies.update(jar)
            return

        cookie_domain = self._default_cookie_domain()
        for name, value in self._parse_cookie_header(raw).items():
            if cookie_domain:
                session.cookies.set(name, value, domain=cookie_domain, path="/")
            else:
                session.cookies.set(name, value)

    def save_cookies_from(self, session: requests.Session) -> None:
        self.ensure()
        raw = self._cookies_file_text()
        if raw is not None and raw.strip() and not self._looks_like_netscape_cookie_file(raw):
            pairs = [f"{c.name}={c.value}" for c in session.cookies]
            _atomic_write_text(self.cookies_path, "; ".join(pairs) + ("; " if pairs else ""))
            return

        jar = MozillaCookieJar(str(self.cookies_path))
        for cookie in session.cookies:
            jar.set_cookie(cookie)
        jar.save(ignore_discard=True, ignore_expires=True)


class ProfileManager:
    def __init__(self, root: Path | str | None = None) -> None:
        base = root or default_loki_home()
        self.root = Path(base).expanduser().resolve()

    def get(self, platform: str, name: str = "default") -> Profile:
        ref = ProfileRef(platform=platform, name=name)
        profile = Profile(self.root, ref)
        profile.ensure()
        return profile

    def list(self, platform: str | None = None) -> list[ProfileRef]:
        base = self.root / "profiles"
        if not base.exists():
            return []

        refs: list[ProfileRef] = []
        if platform:
            _validate_name("platform", platform)
            platforms = [platform]
        else:
            platforms = [p.name for p in base.iterdir() if p.is_dir()]

        for plat in platforms:
            plat_dir = base / plat
            if not plat_dir.is_dir():
                continue
            for prof_dir in plat_dir.iterdir():
                if prof_dir.is_dir():
                    try:
                        refs.append(ProfileRef(platform=plat, name=prof_dir.name))
                    except ValueError:
                        continue

        refs.sort(key=lambda r: (r.platform, r.name))
        return refs
