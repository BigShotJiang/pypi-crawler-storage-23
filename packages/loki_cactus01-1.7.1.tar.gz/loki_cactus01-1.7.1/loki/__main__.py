import logging.config

from loki import LOG_CONF

def main():
    logging.config.dictConfig(LOG_CONF)
    
if __name__ == '__main__':
    main()