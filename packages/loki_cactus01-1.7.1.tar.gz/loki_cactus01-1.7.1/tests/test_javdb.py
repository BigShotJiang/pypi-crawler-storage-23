import asyncio
import os

import pytest

from loki.scrapers.javdb import JavDB


@pytest.mark.skipif(
    os.environ.get("LOKI_JAVDB_INTEGRATION") != "1",
    reason="integration test (requires network/playwright browser)",
)
def test_search_integration():
    async def _run():
        jdb = await JavDB.create()
        try:
            res = await jdb.search("PRED-427")
            assert isinstance(res, dict)
        finally:
            await jdb.close()

    asyncio.run(_run())
