# loki

一个可被其它项目复用的工具库（同时包含部分 scraper）。

## 作为依赖安装

**本地源码引用（推荐开发阶段）**

```bash
pip install -e .
```

**启用 scraper 相关依赖**

```bash
pip install -e ".[scrapers]"
```

Playwright 还需要安装浏览器（首次一次性）：

```bash
python -m playwright install chromium
```

## 在其它项目里引用

```python
from loki.scrapers import RequestMixin, Method
from loki.scrapers.javdb import JavDB
```

## 构建 wheel（用于分发/离线安装）

```bash
python -m build
pip install dist/loki-*.whl
```

## 说明

- 依赖在 `pyproject.toml` 的 `[project.dependencies]` / `[project.optional-dependencies]` 中维护。
- 命令行入口 `loki` 指向 `loki.__main__:main`（目前仅做日志初始化）。
