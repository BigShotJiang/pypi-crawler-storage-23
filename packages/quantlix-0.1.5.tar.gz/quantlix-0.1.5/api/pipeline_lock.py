"""
Pipeline Lock v1 — Guarantee inference requests can't silently diverge from expected input + preprocessing contract.

Enforces:
- Request schema (JSON shape)
- Feature contract (names + count + ordering)
- Preprocessing artifact integrity (checksums) — verify at worker boot + periodically
- Coercion policy — HARD-DISABLED in v1; never silently coerce types
- Mismatch handling (block vs warn vs allow)

Input formats for tabular:
- Object {"age": 30, "income": 50}: unordered; canonicalized to feature_contract.features order
- Array [30, 50]: ordered; strict ordering enforced (must match features[] order)
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

# Violation codes per spec
SCHEMA_MISSING_FIELD = "SCHEMA_MISSING_FIELD"
SCHEMA_INVALID_TYPE = "SCHEMA_INVALID_TYPE"
SCHEMA_EXTRA_FIELD = "SCHEMA_EXTRA_FIELD"
SCHEMA_INVALID_VALUE = "SCHEMA_INVALID_VALUE"
FEATURE_MISSING_REQUIRED = "FEATURE_MISSING_REQUIRED"
FEATURE_UNKNOWN = "FEATURE_UNKNOWN"
FEATURE_TYPE_MISMATCH = "FEATURE_TYPE_MISMATCH"
FEATURE_ORDER_MISMATCH = "FEATURE_ORDER_MISMATCH"
FEATURE_COUNT_MISMATCH = "FEATURE_COUNT_MISMATCH"
ARTIFACT_CHECKSUM_MISMATCH = "ARTIFACT_CHECKSUM_MISMATCH"
ARTIFACT_MISSING = "ARTIFACT_MISSING"
ARTIFACT_LOAD_ERROR = "ARTIFACT_LOAD_ERROR"

TYPE_MAP = {
    "string": str,
    "number": (int, float),
    "integer": int,
    "float32": (int, float),
    "float64": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
}


@dataclass
class Violation:
    code: str
    path: str
    message: str
    expected: str | None = None
    got: str | None = None


@dataclass
class PipelineLockResult:
    valid: bool
    violations: list[Violation] = field(default_factory=list)
    feature_signature: str | None = None
    canonical_input: dict | None = None


def _is_valid_type(value: Any, dtype: str) -> bool:
    """Validate raw JSON type — no coercion. Value must already match dtype."""
    if dtype not in TYPE_MAP:
        return True
    expected = TYPE_MAP[dtype]
    if isinstance(expected, tuple):
        return isinstance(value, expected)
    return isinstance(value, expected)


def _compute_feature_signature(feature_contract: dict) -> str:
    """Stable signature for feature contract."""
    features = feature_contract.get("features", [])
    ordering = feature_contract.get("ordering", "strict")
    parts = [f"{f['name']}:{f.get('dtype', 'any')}" for f in features]
    sig = "|".join(parts) + f"|ordering={ordering}"
    return "sha256:" + hashlib.sha256(sig.encode()).hexdigest()[:16]


def _validate_schema(
    input_data: dict,
    schema_config: dict | None,
) -> list[Violation]:
    """Validate request schema. Returns list of violations."""
    violations: list[Violation] = []
    if not schema_config or not isinstance(schema_config, dict):
        return violations

    input_schema = schema_config.get("input_schema") or schema_config.get("schema")
    if not input_schema or not isinstance(input_schema, dict):
        return violations

    strict = schema_config.get("strict", True)
    properties = input_schema.get("properties", {})
    required = input_schema.get("required", [])
    additional_props = input_schema.get("additionalProperties", not strict)

    # Required fields
    for key in required:
        if key not in input_data:
            violations.append(
                Violation(
                    code=SCHEMA_MISSING_FIELD,
                    path=f"$.{key}",
                    message=f"Missing required field: {key}",
                    expected=properties.get(key, {}).get("type", "any"),
                )
            )
        elif key in properties:
            prop = properties[key]
            type_name = prop.get("type") if isinstance(prop, dict) else None
            if type_name and not _is_valid_type(input_data[key], type_name):
                violations.append(
                    Violation(
                        code=SCHEMA_INVALID_TYPE,
                        path=f"$.{key}",
                        message=f"Field '{key}' expected {type_name}",
                        expected=type_name,
                        got=type(input_data[key]).__name__,
                    )
                )
            # minLength, etc.
            if isinstance(prop, dict) and "minLength" in prop:
                val = input_data[key]
                if isinstance(val, str) and len(val) < prop["minLength"]:
                    violations.append(
                        Violation(
                            code=SCHEMA_INVALID_VALUE,
                            path=f"$.{key}",
                            message=f"Field '{key}' minLength {prop['minLength']}",
                        )
                    )

    # Extra fields
    if additional_props is False:
        for key in input_data:
            if key not in properties:
                violations.append(
                    Violation(
                        code=SCHEMA_EXTRA_FIELD,
                        path=f"$.{key}",
                        message=f"Unexpected field: {key}",
                    )
                )

    return violations


def _validate_feature_contract(
    input_data: dict | list,
    feature_contract: dict | None,
) -> tuple[list[Violation], dict | None, str | None]:
    """
    Validate feature contract. Returns (violations, canonical_input, feature_signature).

    Input formats for tabular:
    - Object {"age": 30, "income": 50}: unordered; canonicalized to features[] order
    - Array [30, 50]: ordered; strict ordering enforced (must match features[] order)
    """
    violations: list[Violation] = []
    if not feature_contract or not isinstance(feature_contract, dict):
        return violations, None, None

    contract_type = feature_contract.get("type", "text")
    if contract_type == "text":
        # Text: single prompt; signature for "what contract was applied"
        sig = "sha256:" + hashlib.sha256(b"text|prompt").hexdigest()[:16]
        return violations, None, sig

    features = feature_contract.get("features", [])
    if not features:
        return violations, None, None

    ordering = feature_contract.get("ordering", "strict")
    allow_missing_optional = feature_contract.get("allow_missing_optional", True)
    # reject | ignore | log — explicit handling for unknown/extra features
    additional_policy = feature_contract.get("additional_features_policy", "reject")
    feature_signature = _compute_feature_signature(feature_contract)

    # Tabular: object (unordered) or array (ordered)
    if isinstance(input_data, list):
        values = input_data
        keys = [f["name"] for f in features]
        if len(values) != len(features):
            violations.append(
                Violation(
                    code=FEATURE_ORDER_MISMATCH,
                    path="$.features",
                    message=f"Array order must match features[] order: expected {len(features)} values, got {len(values)}",
                    expected=str(len(features)),
                    got=str(len(values)),
                )
            )
        if ordering == "strict" and len(values) == len(features):
            for i, (f, v) in enumerate(zip(features, values)):
                dtype = f.get("dtype", "string")
                if not _is_valid_type(v, dtype):
                    violations.append(
                        Violation(
                            code=FEATURE_TYPE_MISMATCH,
                            path=f"$.features.{f['name']}",
                            message=f"Feature '{f['name']}' expected {dtype}",
                            expected=dtype,
                            got=type(v).__name__,
                        )
                    )
        canonical = dict(zip(keys, values)) if len(values) == len(features) else None
    else:
        # Object format: unordered; canonicalize to features[] order
        if not isinstance(input_data, dict):
            violations.append(
                Violation(
                    code=FEATURE_TYPE_MISMATCH,
                    path="$.features",
                    message="Tabular object input must be dict or array",
                    expected="object",
                    got=type(input_data).__name__,
                )
            )
            return violations, None, feature_signature

        canonical = {}
        feature_names = {f["name"] for f in features}
        unknown_keys = [k for k in input_data if k not in feature_names]

        # Unknown features: reject | ignore | log
        if unknown_keys and additional_policy == "reject":
            for key in unknown_keys:
                violations.append(
                    Violation(
                        code=FEATURE_UNKNOWN,
                        path=f"$.features.{key}",
                        message=f"Unknown feature: {key}",
                    )
                )
        # ignore: drop unknown; log: would emit event (handled at API layer)

        for f in features:
            name = f["name"]
            required = f.get("required", True)
            dtype = f.get("dtype", "string")

            if name not in input_data:
                if required:
                    violations.append(
                        Violation(
                            code=FEATURE_MISSING_REQUIRED,
                            path=f"$.features.{name}",
                            message=f"Missing required feature: {name}",
                        )
                    )
                elif allow_missing_optional:
                    canonical[name] = None  # default
            else:
                val = input_data[name]
                if not _is_valid_type(val, dtype):
                    violations.append(
                        Violation(
                            code=FEATURE_TYPE_MISMATCH,
                            path=f"$.features.{name}",
                            message=f"Feature '{name}' expected {dtype}",
                            expected=dtype,
                            got=type(val).__name__,
                        )
                    )
                canonical[name] = val

        # Canonicalize: always output in features[] order (object input is unordered)
        canonical = {f["name"]: canonical.get(f["name"]) for f in features}

    return violations, canonical if canonical else None, feature_signature


def validate_pipeline_lock(
    config: dict,
    input_data: dict,
) -> PipelineLockResult:
    """
    Run full pipeline lock validation.
    config: deployment.config["pipeline_lock"]
    Returns PipelineLockResult with violations and optional canonical_input.
    """
    pipeline_lock = config.get("pipeline_lock", {}) if config else {}
    mode = pipeline_lock.get("mode", "off")

    if mode == "off":
        return PipelineLockResult(valid=True)

    violations: list[Violation] = []
    feature_signature: str | None = None
    canonical_input: dict | None = None

    # 1) Request schema
    schema_config = pipeline_lock.get("schema", {})
    schema_violations: list[Violation] = []
    if isinstance(schema_config, dict):
        schema_violations = _validate_schema(input_data, schema_config)
        violations.extend(schema_violations)

    # 2) Feature contract
    feature_contract = pipeline_lock.get("feature_contract", {})
    if isinstance(feature_contract, dict):
        fc_input = input_data
        if isinstance(input_data, dict) and "input_path" in feature_contract:
            path = feature_contract["input_path"]
            fc_input = input_data.get(path, input_data)
        fc_violations, canonical_input, feature_signature = _validate_feature_contract(
            fc_input, feature_contract
        )
        violations.extend(fc_violations)

    # Feature/schema signature for "what contract was applied" (always when lock active)
    if not feature_signature and schema_config:
        # Schema-only: compute stable signature from schema
        schema_str = json.dumps(schema_config.get("input_schema") or schema_config.get("schema") or {}, sort_keys=True)
        feature_signature = "sha256:" + hashlib.sha256(schema_str.encode()).hexdigest()[:16]

    # 3) Preprocess integrity — config only; actual verification at worker
    # We store artifact config; worker verifies checksums on load
    preprocess_integrity = pipeline_lock.get("preprocess_integrity", {})
    if preprocess_integrity.get("enabled") and preprocess_integrity.get("artifacts"):
        # No runtime check here; worker does it
        pass

    # 4) Coercion — HARD-DISABLED in v1. We validate raw JSON types only; never coerce.
    # (Pydantic/parsing can silently coerce; we validate the dict before any typed parsing.)
    coercion = pipeline_lock.get("coercion", {})
    if coercion.get("enabled"):
        # v1: coercion is config-only; runtime never coerces
        pass

    valid = len(violations) == 0
    return PipelineLockResult(
        valid=valid,
        violations=violations,
        feature_signature=feature_signature,
        canonical_input=canonical_input,
    )


def violations_to_dicts(violations: list[Violation]) -> list[dict]:
    """Serialize violations for API response."""
    return [
        {
            "code": v.code,
            "path": v.path,
            "message": v.message,
            **({"expected": v.expected} if v.expected else {}),
            **({"got": v.got} if v.got else {}),
        }
        for v in violations
    ]


def diff_schemas(expected_schema: dict | None, observed_keys: set[str]) -> dict:
    """Compute diff between expected schema and observed live traffic keys."""
    if not expected_schema:
        return {"missing_in_traffic": [], "extra_in_traffic": []}

    if "properties" in expected_schema:
        expected_keys = set(expected_schema.get("properties", {}).keys())
    elif "input_schema" in expected_schema:
        expected_keys = set(expected_schema["input_schema"].get("properties", {}).keys())
    else:
        expected_keys = set(expected_schema.keys())

    missing = list(expected_keys - observed_keys)
    extra = list(observed_keys - expected_keys)
    return {"missing_in_traffic": missing, "extra_in_traffic": extra}


def get_default_pipeline_lock() -> dict:
    """Recommended default config for production."""
    return {
        "version": "1.0",
        "mode": "enforce",
        "schema": {
            "strict": True,
            "input_schema": {
                "type": "object",
                "required": ["prompt"],
                "properties": {"prompt": {"type": "string"}},
                "additionalProperties": False,
            },
        },
        "feature_contract": {"type": "text", "additional_features_policy": "reject"},
        "preprocess_integrity": {"enabled": True, "fail_on_mismatch": True, "artifacts": []},
        "coercion": {"enabled": False, "rules": {"trim_strings": True}},
        "actions": {
            "on_violation": "block",
            "http_status": 400,
            "response_body": "minimal",
            "include_violation_context": True,
            "emit_event": True,
        },
    }
