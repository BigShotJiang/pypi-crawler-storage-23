"""Prometheus metrics for users, usage, and tiers."""
from prometheus_client import Counter, Gauge

# Users
quantlix_users_total = Gauge(
    "quantlix_users_total",
    "Total number of registered users",
)
quantlix_users_by_plan = Gauge(
    "quantlix_users_by_plan",
    "Number of users per plan/tier",
    ["plan"],
)
quantlix_users_verified = Gauge(
    "quantlix_users_verified",
    "Number of users with verified email",
)

# Usage (current month)
quantlix_usage_tokens_total = Gauge(
    "quantlix_usage_tokens_total",
    "Total tokens used across all users this month",
)
quantlix_usage_compute_seconds_total = Gauge(
    "quantlix_usage_compute_seconds_total",
    "Total CPU compute seconds across all users this month",
)
quantlix_usage_gpu_seconds_total = Gauge(
    "quantlix_usage_gpu_seconds_total",
    "Total GPU seconds across all users this month",
)
quantlix_usage_jobs_total = Gauge(
    "quantlix_usage_jobs_total",
    "Total inference jobs this month",
)

# Pipeline Lock
# NOTE: deployment_id label can explode cardinality with many deployments.
# Consider: per-tenant aggregation, sampled metrics, or deployment_id only if count is small.
pipeline_lock_blocked_requests_total = Counter(
    "pipeline_lock_blocked_requests_total",
    "Total requests blocked by pipeline lock",
    ["deployment_id"],
)
pipeline_lock_warned_requests_total = Counter(
    "pipeline_lock_warned_requests_total",
    "Total requests warned by pipeline lock (allowed through)",
    ["deployment_id"],
)
pipeline_lock_violation_code_total = Counter(
    "pipeline_lock_violation_code_total",
    "Total violations by code",
    ["deployment_id", "code"],
)
