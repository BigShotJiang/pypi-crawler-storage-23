"""Deployments list, revisions, and rollback."""
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.auth import CurrentUser
from api.db import get_db
from api.models import Deployment, DeploymentRevision, Job
from api.pipeline_lock import diff_schemas
from api.schemas import (
    DeploymentListItem,
    DeploymentListResponse,
    DeploymentRevisionItem,
    DeploymentRevisionListResponse,
    RollbackResponse,
    SchemaStatsResponse,
)

router = APIRouter()


@router.get("", response_model=DeploymentListResponse)
async def list_deployments(
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """List user's deployments with revision counts. Supports pagination."""
    # Total count
    count_result = await db.scalar(
        select(func.count(func.distinct(Deployment.id))).where(
            Deployment.user_id == user.id
        )
    )
    total = count_result or 0

    result = await db.execute(
        select(
            Deployment.id,
            Deployment.model_id,
            Deployment.status,
            Deployment.created_at,
            Deployment.updated_at,
            func.count(DeploymentRevision.id).label("revision_count"),
        )
        .outerjoin(DeploymentRevision, Deployment.id == DeploymentRevision.deployment_id)
        .where(Deployment.user_id == user.id)
        .group_by(Deployment.id)
        .order_by(Deployment.updated_at.desc())
        .limit(limit)
        .offset(offset)
    )
    rows = result.all()
    return DeploymentListResponse(
        deployments=[
            DeploymentListItem(
                id=r.id,
                model_id=r.model_id,
                status=r.status,
                created_at=r.created_at,
                updated_at=r.updated_at,
                revision_count=r.revision_count or 0,
            )
            for r in rows
        ],
        total=total,
    )


@router.get("/{deployment_id}/revisions", response_model=DeploymentRevisionListResponse)
async def list_revisions(
    deployment_id: str,
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
):
    """List revisions for a deployment (newest first)."""
    result = await db.execute(
        select(Deployment).where(
            Deployment.id == deployment_id,
            Deployment.user_id == user.id,
        )
    )
    deployment = result.scalar_one_or_none()
    if not deployment:
        raise HTTPException(status_code=404, detail="Deployment not found")

    revs = await db.execute(
        select(DeploymentRevision)
        .where(DeploymentRevision.deployment_id == deployment_id)
        .order_by(DeploymentRevision.revision_number.desc())
    )
    revisions = revs.scalars().all()
    return DeploymentRevisionListResponse(
        deployment_id=deployment_id,
        revisions=[
            DeploymentRevisionItem(
                revision_number=r.revision_number,
                model_id=r.model_id,
                model_path=r.model_path,
                config=r.config or {},
                created_at=r.created_at,
            )
            for r in revisions
        ],
    )


@router.post("/{deployment_id}/rollback", response_model=RollbackResponse)
async def rollback(
    deployment_id: str,
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
    revision: int = Query(..., ge=1, description="Revision number to rollback to"),
):
    """Rollback deployment to a previous revision."""
    result = await db.execute(
        select(Deployment).where(
            Deployment.id == deployment_id,
            Deployment.user_id == user.id,
        )
    )
    deployment = result.scalar_one_or_none()
    if not deployment:
        raise HTTPException(status_code=404, detail="Deployment not found")

    rev_result = await db.execute(
        select(DeploymentRevision).where(
            DeploymentRevision.deployment_id == deployment_id,
            DeploymentRevision.revision_number == revision,
        )
    )
    rev = rev_result.scalar_one_or_none()
    if not rev:
        raise HTTPException(status_code=404, detail=f"Revision {revision} not found")

    deployment.model_id = rev.model_id
    deployment.model_path = rev.model_path
    deployment.config = rev.config
    return RollbackResponse(deployment_id=deployment_id, revision=revision)


@router.get("/{deployment_id}/schema-stats", response_model=SchemaStatsResponse)
async def get_schema_stats(
    deployment_id: str,
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
    limit: int = Query(100, ge=1, le=500, description="Jobs to analyze"),
):
    """Pipeline Lock v1: stats, violation codes, and schema diff."""
    result = await db.execute(
        select(Deployment).where(
            Deployment.id == deployment_id,
            Deployment.user_id == user.id,
        )
    )
    deployment = result.scalar_one_or_none()
    if not deployment:
        raise HTTPException(status_code=404, detail="Deployment not found")

    cfg = deployment.config or {}
    pipeline_lock = cfg.get("pipeline_lock", {})
    mode = pipeline_lock.get("mode", "off")
    schema_config = pipeline_lock.get("schema", {})
    input_schema = (
        schema_config.get("input_schema") or schema_config.get("schema")
        if isinstance(schema_config, dict)
        else None
    )
    preprocess_integrity = pipeline_lock.get("preprocess_integrity")

    jobs_result = await db.execute(
        select(Job)
        .where(Job.deployment_id == deployment_id)
        .order_by(desc(Job.created_at))
        .limit(limit)
    )
    jobs = jobs_result.scalars().all()

    # Only field paths/keys — never store raw values (PII, cardinality bombs)
    MAX_OBSERVED_PATHS = 500  # Cap per deployment
    observed_keys: set[str] = set()
    mismatch_count = 0
    code_counts: dict[str, int] = {}
    for j in jobs:
        if len(observed_keys) < MAX_OBSERVED_PATHS:
            if j.input_data and isinstance(j.input_data, dict):
                observed_keys.update(j.input_data.keys())
            elif j.input_data and isinstance(j.input_data, list):
                observed_keys.add("[array]")  # Presence only, no positional explosion
        if j.schema_mismatch and j.schema_mismatch.get("violations"):
            mismatch_count += 1
            for v in j.schema_mismatch["violations"]:
                code = v.get("code", "UNKNOWN")
                code_counts[code] = code_counts.get(code, 0) + 1

    top_violation_codes = [
        {"code": k, "count": v}
        for k, v in sorted(code_counts.items(), key=lambda x: -x[1])[:10]
    ]

    schema_diff = diff_schemas(input_schema, observed_keys)

    return SchemaStatsResponse(
        deployment_id=deployment_id,
        mode=mode,
        input_schema=input_schema,
        preprocess_integrity=preprocess_integrity,
        observed_keys=sorted(observed_keys),
        mismatch_count=mismatch_count,
        blocked_count=0,  # Blocked requests never create jobs; use metrics for this
        warned_count=mismatch_count,
        total_jobs=len(jobs),
        top_violation_codes=top_violation_codes,
        schema_diff=schema_diff,
    )
