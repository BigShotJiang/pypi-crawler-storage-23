"""Jobs endpoints - list recent inference jobs."""
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.auth import CurrentUser
from api.cost_estimation import compute_cost_amplification
from api.db import get_db
from api.models import Deployment, Job, JobStatus, UsageRecord
from api.schemas import JobListItem, JobListResponse, JobTraceResponse

router = APIRouter()


def _input_summary(input_data: dict | list | None) -> dict:
    """Derive input summary for trace view."""
    if not input_data:
        return {"type": "empty", "keys": [], "preview": None}
    if isinstance(input_data, list):
        return {"type": "array", "keys": ["[array]"], "length": len(input_data), "preview": None}
    keys = list(input_data.keys()) if isinstance(input_data, dict) else []
    preview = None
    for k in ("prompt", "text", "input"):
        if k in input_data and isinstance(input_data[k], str):
            s = input_data[k]
            preview = s[:80] + "…" if len(s) > 80 else s
            break
    return {"type": "object", "keys": keys, "preview": preview}


@router.get("", response_model=JobListResponse)
async def list_jobs(
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
    limit: int = Query(20, ge=1, le=100),
):
    """List recent inference jobs for the current user."""
    result = await db.execute(
        select(Job)
        .where(Job.user_id == user.id)
        .order_by(desc(Job.created_at))
        .limit(limit)
    )
    jobs = result.scalars().all()
    def _retry_after(j) -> int | None:
        if j.status != JobStatus.FAILED.value:
            return None
        if j.guardrail_blocked or j.policy_action == "block":
            return 60
        return None

    return JobListResponse(
        jobs=[
            JobListItem(
                id=j.id,
                deployment_id=j.deployment_id,
                status=j.status,
                tokens_used=j.tokens_used,
                compute_seconds=j.compute_seconds,
                created_at=j.created_at,
                completed_at=j.completed_at,
                error_message=j.error_message,
                guardrail_blocked=j.guardrail_blocked,
                policy_action=j.policy_action,
                retry_after_seconds=_retry_after(j),
                schema_mismatch=j.schema_mismatch,
            )
            for j in jobs
        ]
    )


@router.get("/{job_id}/trace", response_model=JobTraceResponse)
async def get_job_trace(
    job_id: str,
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
):
    """Decision Trace View: input summary, model, latency, guardrails, cost."""
    result = await db.execute(
        select(Job, Deployment)
        .join(Deployment, Job.deployment_id == Deployment.id)
        .where(Job.id == job_id, Job.user_id == user.id)
    )
    row = result.one_or_none()
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    job, deployment = row

    total_ms = None
    if job.created_at and job.completed_at:
        delta = job.completed_at - job.created_at
        total_ms = int(delta.total_seconds() * 1000)

    lb = job.latency_breakdown or {}

    usage = None
    ur = await db.execute(select(UsageRecord).where(UsageRecord.job_id == job_id))
    usage_row = ur.scalar_one_or_none()
    if usage_row:
        usage = {
            "tokens": usage_row.tokens_used,
            "compute_s": usage_row.compute_seconds,
            "gpu_s": usage_row.gpu_seconds,
        }
    else:
        usage = {
            "tokens": job.tokens_used or 0,
            "compute_s": job.compute_seconds or 0.0,
            "gpu_s": 0.0,
        }

    amplification = None
    if job.tokens_input and job.tokens_output and job.tokens_input > 0:
        amplification = round(job.tokens_output / job.tokens_input, 2)
    elif job.tokens_used and job.input_data:
        inp = job.input_data
        if isinstance(inp, dict) and "prompt" in inp and isinstance(inp["prompt"], str):
            input_tok_approx = max(1, len(inp["prompt"].split()) * 2)
            if input_tok_approx > 0:
                amplification = round(job.tokens_used / input_tok_approx, 2)

    cost_amplification = None
    if usage and (usage["tokens"] or usage["compute_s"] or usage["gpu_s"]):
        cost_amplification = compute_cost_amplification(
            tokens=usage["tokens"],
            compute_s=usage["compute_s"],
            gpu_s=usage["gpu_s"],
            retry_count=getattr(job, "retry_count", 0) or 0,
            fallback_triggered=bool(job.fallback_triggered),
        )

    return JobTraceResponse(
        job_id=job.id,
        input_summary=_input_summary(job.input_data),
        model_id=deployment.model_id or "unknown",
        fallback_triggered=bool(job.fallback_triggered),
        retry_count=getattr(job, "retry_count", 0) or 0,
        latency={
            "total_ms": total_ms,
            "compute_s": job.compute_seconds,
            "queue_ms": lb.get("queue_ms"),
            "inference_ms": lb.get("inference_ms"),
            "guardrail_ms": lb.get("guardrail_ms"),
        },
        tokens={
            "used": job.tokens_used,
            "input": job.tokens_input,
            "output": job.tokens_output,
            "amplification": amplification,
        },
        guardrail_outcome={
            "blocked": job.guardrail_blocked or False,
            "flags": (job.guardrail_flags or {}).get("flags", []),
            "policy_action": job.policy_action or "allow",
        },
        cost=usage,
        cost_amplification=cost_amplification,
    )
