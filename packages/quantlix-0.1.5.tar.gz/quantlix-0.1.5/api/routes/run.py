"""Run inference endpoints."""
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.auth import CurrentUser
from api.config import settings
from api.db import get_db
from api.guardrails.base import GuardrailAction
from api.guardrails.block_rate import check_block_rate_limit
from api.guardrails.config import get_guardrail_config
from api.guardrails.runner import run_guardrails
from api.metrics import (
    pipeline_lock_blocked_requests_total,
    pipeline_lock_violation_code_total,
    pipeline_lock_warned_requests_total,
)
from api.models import Deployment, DeploymentStatus, Job, JobStatus
from api.pipeline_lock import validate_pipeline_lock, violations_to_dicts
from api.queue import enqueue_job
from api.schemas import RunRequest, RunResponse
from api.usage_service import check_usage_limits

router = APIRouter()


@router.post("", response_model=RunResponse)
async def run_inference(
    body: RunRequest,
    user: CurrentUser,
    db: Annotated[AsyncSession, Depends(get_db)],
    response: Response,
):
    """Run inference on a deployed model."""
    result = await db.execute(
        select(Deployment).where(
            Deployment.id == body.deployment_id,
            Deployment.user_id == user.id,
        )
    )
    deployment = result.scalar_one_or_none()
    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Deployment not found",
        )

    is_gpu = bool(deployment.config and deployment.config.get("gpu"))
    ok, err = await check_usage_limits(db, user.id, is_gpu_job=is_gpu)
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=err,
        )

    if deployment.status not in (DeploymentStatus.READY.value, DeploymentStatus.PENDING.value):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Deployment not runnable (status: {deployment.status})",
        )

    input_payload = body.input if isinstance(body.input, dict) else {"data": body.input}
    request_id = f"req_{uuid.uuid4().hex[:12]}"

    # Pipeline Lock v1
    cfg = deployment.config or {}
    pl_result = validate_pipeline_lock(cfg, input_payload)
    pipeline_lock = cfg.get("pipeline_lock", {})
    mode = pipeline_lock.get("mode", "off")
    actions = pipeline_lock.get("actions", {})
    on_violation = actions.get("on_violation", "block")
    http_status = actions.get("http_status", 400)
    include_violation_context = actions.get("include_violation_context", True)

    if not pl_result.valid and mode != "off":
        violations_dict = violations_to_dicts(pl_result.violations)
        dep_id = str(deployment.id)

        for v in pl_result.violations:
            pipeline_lock_violation_code_total.labels(deployment_id=dep_id, code=v.code).inc()

        if mode == "enforce" or (mode == "warn" and on_violation == "block"):
            pipeline_lock_blocked_requests_total.labels(deployment_id=dep_id).inc()
            detail = {
                "error": "pipeline_lock_violation",
                "request_id": request_id,
                "violations": violations_dict if include_violation_context else [],
                "policy_action": "blocked",
            }
            raise HTTPException(status_code=http_status, detail=detail)

        if mode == "warn" and on_violation == "allow_with_warning":
            pipeline_lock_warned_requests_total.labels(deployment_id=dep_id).inc()
            # Continue; store violations on job, add to response

    # Use canonical input if feature contract produced one
    payload_for_inference = pl_result.canonical_input if pl_result.canonical_input else input_payload

    # Block rate limit — prevent repeated blocked outputs from multiplying cost
    max_blocks = cfg.get("guardrail_block_max", settings.guardrail_block_max_per_window)
    window_secs = cfg.get("guardrail_block_window", settings.guardrail_block_window_seconds)
    rate_result = await check_block_rate_limit(
        str(user.id), str(deployment.id), max_blocks, window_secs
    )
    if not rate_result.within_limit:
        response.headers["Retry-After"] = str(rate_result.retry_after_seconds)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "message": f"Too many blocked requests. Retry after {rate_result.retry_after_seconds}s",
                "blocks_in_window": rate_result.blocks_in_window,
                "max_blocks": rate_result.max_blocks,
                "retry_after_seconds": rate_result.retry_after_seconds,
            },
        )

    # Input guardrails — block before enqueue if any rule blocks
    enabled_rules, rule_config, fail_open, timeout = get_guardrail_config(deployment)
    passed, guardrail_results = run_guardrails(
        payload_for_inference, "input", enabled_rules, rule_config,
        timeout_seconds=timeout, fail_open=fail_open
    )
    if not passed:
        blocked = next((r for r in guardrail_results if r.action == GuardrailAction.BLOCK), None)
        retry_secs = 60
        response.headers["Retry-After"] = str(retry_secs)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": blocked.message if blocked else "Request blocked by guardrails",
                "retry_after_seconds": retry_secs,
            },
        )

    # Store violations on job if warn mode
    schema_mismatch = None
    if not pl_result.valid and pl_result.violations:
        schema_mismatch = {
            "violations": violations_to_dicts(pl_result.violations),
            "feature_signature": pl_result.feature_signature,
        }

    job = Job(
        user_id=user.id,
        deployment_id=deployment.id,
        input_data=payload_for_inference,
        status=JobStatus.QUEUED.value,
        schema_mismatch=schema_mismatch,
    )
    db.add(job)
    await db.flush()
    await db.refresh(job)
    await db.commit()  # Commit before enqueue so orchestrator can find the job

    await enqueue_job(
        job_id=job.id,
        payload={
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": payload_for_inference,
        },
    )

    block_rate = None
    if rate_result.blocks_in_window > 0:
        block_rate = {
            "blocks_in_window": rate_result.blocks_in_window,
            "max_blocks": rate_result.max_blocks,
        }

    # Build response; always include feature_signature when pipeline_lock active (even on success)
    pipeline_lock_response = None
    if mode != "off" and (pl_result.feature_signature or (not pl_result.valid and on_violation == "allow_with_warning")):
        pipeline_lock_response = {"feature_signature": pl_result.feature_signature or ""}
        if not pl_result.valid and on_violation == "allow_with_warning":
            pipeline_lock_response.update({
                "status": "warn",
                "request_id": request_id,
                "violations": violations_to_dicts(pl_result.violations),
            })

    return RunResponse(
        job_id=job.id,
        status=job.status,
        message="Inference job queued",
        block_rate=block_rate,
        schema_warnings=(schema_mismatch.get("violations") if schema_mismatch else None),
        pipeline_lock=pipeline_lock_response,
    )
