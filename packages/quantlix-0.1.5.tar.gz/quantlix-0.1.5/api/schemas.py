"""Pydantic schemas for API request/response."""
import re
from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator


# --- Auth helpers ---
PASSWORD_MIN_LENGTH = 12
PASSWORD_SPECIAL_CHARS = re.compile(r"[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>/?`~]")


def _check_password_strength(password: str) -> tuple[bool, int, list[str]]:
    """Check password strength. Returns (valid, score, feedback)."""
    feedback: list[str] = []
    score = 0
    if len(password) >= PASSWORD_MIN_LENGTH:
        score += 1
    else:
        feedback.append(f"At least {PASSWORD_MIN_LENGTH} characters")
    if any(c.isupper() for c in password):
        score += 1
    else:
        feedback.append("At least one uppercase letter")
    if any(c.islower() for c in password):
        score += 1
    else:
        feedback.append("At least one lowercase letter")
    if any(c.isdigit() for c in password):
        score += 1
    else:
        feedback.append("At least one digit")
    if PASSWORD_SPECIAL_CHARS.search(password):
        score += 1
    else:
        feedback.append("At least one special character (!@#$%^&* etc.)")
    return (len(feedback) == 0, score, feedback)


def _validate_password_strength(password: str) -> str:
    """Validate password meets strength requirements. Raises ValueError with specific message."""
    valid, _, feedback = _check_password_strength(password)
    if not valid:
        raise ValueError(feedback[0] if feedback else "Password does not meet requirements")
    return password


# --- Deploy ---
class DeployRequest(BaseModel):
    model_id: str = Field(..., description="Model identifier (e.g. my-llama-7b)")
    model_path: str | None = Field(None, description="MinIO path to model files (e.g. models/user123/llama)")
    config: dict = Field(
        default_factory=dict,
        description="Deployment config: replicas, resources, input_schema (Pipeline Lock), preprocessing_path, etc.",
    )
    deployment_id: str | None = Field(None, description="Update existing deployment (creates new revision)")


class DeployResponse(BaseModel):
    deployment_id: str
    status: str
    message: str = "Deployment queued"
    revision: int | None = Field(None, description="Revision number if updated")


# --- Deployments (list, revisions, rollback) ---
class DeploymentListItem(BaseModel):
    id: str
    model_id: str
    status: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    revision_count: int = 0


class DeploymentListResponse(BaseModel):
    deployments: list[DeploymentListItem]
    total: int = 0


class DeploymentRevisionItem(BaseModel):
    revision_number: int
    model_id: str
    model_path: str | None = None
    config: dict
    created_at: datetime | None = None


class DeploymentRevisionListResponse(BaseModel):
    deployment_id: str
    revisions: list[DeploymentRevisionItem]


class SchemaStatsResponse(BaseModel):
    """Pipeline Lock v1: stats for a deployment."""
    deployment_id: str
    mode: str = Field("off", description="enforce | warn | off")
    input_schema: dict | None = Field(None, description="Expected input schema from config")
    preprocess_integrity: dict | None = Field(None, description="Artifact checksums config")
    observed_keys: list[str] = Field(default_factory=list, description="Keys seen in live traffic")
    mismatch_count: int = Field(0, description="Jobs with violations in window")
    blocked_count: int = Field(0, description="Jobs blocked by pipeline lock (24h)")
    warned_count: int = Field(0, description="Jobs warned but allowed (24h)")
    total_jobs: int = Field(0, description="Total jobs in window")
    top_violation_codes: list[dict] = Field(
        default_factory=list,
        description="Most common violation codes: [{code, count}]",
    )
    schema_diff: dict = Field(
        default_factory=dict,
        description="Diff: missing_in_traffic, extra_in_traffic",
    )


class RollbackResponse(BaseModel):
    deployment_id: str
    revision: int
    message: str = "Rolled back"


# --- Run ---
class RunRequest(BaseModel):
    deployment_id: str = Field(..., description="ID of deployed model")
    input: Any = Field(..., description="Inference input (JSON)")


class RunResponse(BaseModel):
    job_id: str
    status: str
    message: str = "Inference job queued"
    block_rate: dict | None = Field(
        None,
        description="Proximity to block limit: blocks_in_window, max_blocks (only when > 0 blocks)",
    )
    schema_warnings: list[dict] | None = Field(
        None,
        description="Pipeline Lock: violations (warn mode; job still queued)",
    )
    pipeline_lock: dict | None = Field(
        None,
        description="Pipeline Lock: feature_signature (always when active), status/violations (when warn)",
    )


# --- Jobs (list) ---
class JobListItem(BaseModel):
    id: str
    deployment_id: str
    status: str
    tokens_used: int | None = None
    compute_seconds: float | None = None
    created_at: datetime | None = None
    completed_at: datetime | None = None
    error_message: str | None = Field(None, description="Error or block reason when failed")
    guardrail_blocked: bool | None = Field(None, description="True if blocked by guardrails")
    policy_action: str | None = Field(None, description="allow, block, or log")
    retry_after_seconds: int | None = Field(None, description="Suggested wait before retry when blocked")
    schema_mismatch: dict | None = Field(None, description="Pipeline Lock: input schema mismatches")


class JobListResponse(BaseModel):
    jobs: list[JobListItem]


# --- Job Trace (Decision Trace View) ---
class JobTraceResponse(BaseModel):
    """Per-request trace for debugging and observability."""
    job_id: str
    input_summary: dict = Field(..., description="Keys, type, truncated preview")
    model_id: str = Field(..., description="Selected model/tool")
    fallback_triggered: bool = Field(False, description="Whether fallback was used")
    retry_count: int = Field(0, description="Number of retries")
    latency: dict = Field(..., description="total_ms, compute_s, queue_ms, inference_ms, guardrail_ms")
    tokens: dict = Field(..., description="used, input, output, amplification (optional)")
    guardrail_outcome: dict = Field(..., description="blocked, flags, policy_action")
    cost: dict = Field(..., description="tokens, compute_s, gpu_s")
    cost_amplification: dict | None = Field(
        None,
        description="base_cost_eur, retry_cost_eur, fallback_cost_eur, total_cost_eur, amplification_factor",
    )


# --- Status ---
class StatusResponse(BaseModel):
    id: str
    type: str = Field(..., description="deployment or job")
    status: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    error_message: str | None = None
    config: dict | None = Field(None, description="Deployment config (when type=deployment)")
    # Job-specific
    output_data: dict | None = None
    tokens_used: int | None = None
    compute_seconds: float | None = None
    guardrail_blocked: bool | None = Field(None, description="True if blocked by guardrails")
    policy_action: str | None = Field(None, description="allow, block, or log")
    retry_after_seconds: int | None = Field(None, description="Suggested wait before retry when blocked")


# --- Auth ---
def _validate_email_not_disposable(email: str) -> str:
    """Reject disposable/temp-mail domains."""
    from api.disposable_domains import is_disposable_email

    if is_disposable_email(email):
        raise ValueError("Disposable email addresses are not allowed")
    return email


class SignupRequest(BaseModel):
    email: str = Field(..., description="User email")
    password: str = Field(
        ...,
        min_length=PASSWORD_MIN_LENGTH,
        description=f"Password (min {PASSWORD_MIN_LENGTH} chars, uppercase, lowercase, digit, special char)",
    )

    @field_validator("email")
    @classmethod
    def validate_email_not_disposable(cls, v: str) -> str:
        return _validate_email_not_disposable(v)

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)


class LoginRequest(BaseModel):
    email: str = Field(..., description="User email")
    password: str = Field(..., description="Password")


class AuthResponse(BaseModel):
    api_key: str = Field(..., description="API key for X-API-Key header")
    user_id: str = Field(..., description="User ID")


class SignupResponse(BaseModel):
    message: str = Field(..., description="Status message")
    email: str = Field(..., description="Email address verification was sent to")
    verification_link: str | None = Field(None, description="Verification URL (only in dev mode when email may not arrive)")
    api_key: str | None = Field(None, description="API key when email verification is disabled; use to log in immediately")
    user_id: str | None = Field(None, description="User ID when api_key is returned")


class ResendVerificationRequest(BaseModel):
    email: str = Field(..., description="Email to resend verification to")


class ForgotPasswordRequest(BaseModel):
    email: str = Field(..., description="Email to send reset link to")


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., description="Reset token from email link")
    new_password: str = Field(
        ...,
        min_length=PASSWORD_MIN_LENGTH,
        description=f"New password (min {PASSWORD_MIN_LENGTH} chars, uppercase, lowercase, digit, special char)",
    )

    @field_validator("new_password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)


class PasswordStrengthRequest(BaseModel):
    password: str = Field(..., description="Password to check")


class PasswordStrengthResponse(BaseModel):
    valid: bool = Field(..., description="Whether password meets all requirements")
    score: int = Field(..., ge=0, le=5, description="Strength score 0-5")
    feedback: list[str] = Field(default_factory=list, description="List of requirements not met")


class APIKeyInfo(BaseModel):
    id: str = Field(..., description="API key ID")
    name: str | None = Field(None, description="Key name/label")
    created_at: datetime = Field(..., description="When the key was created")


class APIKeyListResponse(BaseModel):
    api_keys: list[APIKeyInfo] = Field(..., description="List of API keys")


class CreateAPIKeyRequest(BaseModel):
    name: str | None = Field(None, max_length=100, description="Optional name for the key")


class CreateAPIKeyResponse(BaseModel):
    api_key: str = Field(..., description="New API key (shown only once)")
    id: str = Field(..., description="Key ID")
    name: str | None = Field(None, description="Key name")


class RotateAPIKeyResponse(BaseModel):
    api_key: str = Field(..., description="New API key (old key revoked)")
    id: str = Field(..., description="Key ID")
    name: str | None = Field(None, description="Key name")


class UpgradeRequest(BaseModel):
    plan: str = Field(..., description="Plan to upgrade to (e.g. 'pro')")


class UserMeResponse(BaseModel):
    id: str = Field(..., description="User ID")
    email: str = Field(..., description="User email")
    plan: str = Field(..., description="Current plan (free, pro)")


# --- Usage ---
class UsageDailyPoint(BaseModel):
    date: date
    tokens_used: int = 0
    compute_seconds: float = 0.0
    gpu_seconds: float = 0.0
    job_count: int = 0


class UsageHistoryResponse(BaseModel):
    daily: list[UsageDailyPoint]


class MetricsResponse(BaseModel):
    success_rate: float = Field(..., description="Fraction of completed jobs (0-1)")
    total_jobs: int = 0
    avg_latency_s: float | None = Field(None, description="Avg inference latency in seconds")
    p50_latency_s: float | None = Field(None, description="Median latency in seconds")
    p95_latency_s: float | None = Field(None, description="P95 latency in seconds")


class UsageResponse(BaseModel):
    user_id: str
    plan: str = Field(..., description="Current plan (free, pro)")
    tokens_used: int = 0
    compute_seconds: float = 0.0
    gpu_seconds: float = 0.0
    job_count: int = 0
    blocked_jobs_count: int = Field(0, description="Jobs blocked by guardrails or policy (no charge)")
    start_date: date | None = None
    end_date: date | None = None
    # Limits (0 = unlimited)
    tokens_limit: int | None = Field(None, description="Monthly token limit (0 = unlimited)")
    compute_limit: float | None = Field(None, description="Monthly CPU compute limit in seconds (0 = unlimited)")
    gpu_limit: float | None = Field(None, description="Monthly GPU limit in seconds (0 = none, Pro only)")
    gpu_seconds_overage: float | None = Field(None, description="GPU seconds over limit (billed at €0.50/hr)")
