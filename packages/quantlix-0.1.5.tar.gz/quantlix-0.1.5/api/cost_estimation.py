"""Cost estimation for inference jobs. Used for Cost Amplification Score in Decision Trace."""
from __future__ import annotations

# Rates in EUR (configurable via env in future). Pro GPU overage: €0.50/hr
TOKEN_COST_PER_1M = 10.0  # €10 per 1M tokens (typical LLM)
CPU_COST_PER_HOUR = 0.36  # ~€0.36/hr cloud CPU
GPU_COST_PER_HOUR = 0.50  # €0.50/hr Pro overage


def estimate_cost_eur(tokens: int, compute_s: float, gpu_s: float) -> float:
    """Estimate cost in EUR from usage. Returns 0 if all zero."""
    if tokens == 0 and compute_s == 0 and gpu_s == 0:
        return 0.0
    token_cost = (tokens / 1_000_000) * TOKEN_COST_PER_1M
    cpu_cost = (compute_s / 3600) * CPU_COST_PER_HOUR
    gpu_cost = (gpu_s / 3600) * GPU_COST_PER_HOUR
    return round(token_cost + cpu_cost + gpu_cost, 4)


def compute_cost_amplification(
    *,
    tokens: int,
    compute_s: float,
    gpu_s: float,
    retry_count: int,
    fallback_triggered: bool,
) -> dict:
    """
    Compute Cost Amplification Score breakdown.

    Total inference runs = 1 (base) + retry_count + (1 if fallback else 0).
    We charge for the final successful run only; failed attempts still consume compute.
    Cost per run = total_cost / total_runs. Base = 1 run, retry = retry_count runs, fallback = 1 run.
    """
    total_cost_eur = estimate_cost_eur(tokens, compute_s, gpu_s)
    total_runs = 1 + retry_count + (1 if fallback_triggered else 0)
    if total_runs <= 0:
        total_runs = 1
    cost_per_run = total_cost_eur / total_runs

    base_cost = round(cost_per_run, 4)
    retry_cost = round(retry_count * cost_per_run, 4)
    fallback_cost = round((1 if fallback_triggered else 0) * cost_per_run, 4)
    total_cost = round(base_cost + retry_cost + fallback_cost, 4)

    amplification = round(total_runs, 2) if total_runs > 1 else 1.0

    return {
        "base_cost_eur": base_cost,
        "retry_cost_eur": retry_cost,
        "fallback_cost_eur": fallback_cost,
        "total_cost_eur": total_cost,
        "amplification_factor": amplification,
    }
