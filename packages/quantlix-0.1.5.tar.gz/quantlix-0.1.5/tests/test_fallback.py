"""
Fallback logic tests — orchestrator fallback when primary inference fails.

Tests:
1. Fallback config parsing (config.fallback.model_id)
2. Primary fails, retries exhausted, fallback succeeds → fallback_triggered=True
3. Primary fails, retries exhausted, no fallback config → job FAILED
4. Primary fails, retries exhausted, fallback also fails → job FAILED
5. Primary succeeds → no fallback attempt, fallback_triggered=False
6. Primary fails, retries not exhausted → re-enqueue, no fallback
"""
from __future__ import annotations

import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Mock kubernetes before orchestrator imports it (orchestrator.k8s imports kubernetes)
_kubernetes = MagicMock()
_kubernetes.config = MagicMock()
_kubernetes.config.config_exception = MagicMock()
_kubernetes.config.config_exception.ConfigException = type("ConfigException", (Exception,), {})
sys.modules["kubernetes"] = _kubernetes
sys.modules["kubernetes.client"] = _kubernetes.client
sys.modules["kubernetes.config"] = _kubernetes.config
sys.modules["kubernetes.config.config_exception"] = _kubernetes.config.config_exception

from api.models import Deployment, DeploymentStatus, Job, JobStatus
from orchestrator.worker import MAX_INFERENCE_RETRIES, process_job


def _get_fallback_model_id(cfg: dict) -> str | None:
    """Extract fallback model_id from deployment config. Mirrors orchestrator logic."""
    fallback = cfg.get("fallback")
    if isinstance(fallback, dict):
        return fallback.get("model_id")
    return None


# --- Fallback config parsing ---
def test_fallback_config_model_id_extracted():
    """config.fallback.model_id is correctly extracted."""
    cfg = {"fallback": {"model_id": "qx-fallback-small"}}
    assert _get_fallback_model_id(cfg) == "qx-fallback-small"


def test_fallback_config_missing_returns_none():
    """No fallback config returns None."""
    assert _get_fallback_model_id({}) is None
    assert _get_fallback_model_id({"fallback": None}) is None


def test_fallback_config_invalid_type_returns_none():
    """config.fallback as non-dict (e.g. string) returns None."""
    assert _get_fallback_model_id({"fallback": "qx-fallback"}) is None
    assert _get_fallback_model_id({"fallback": []}) is None


def test_fallback_config_empty_dict_returns_none():
    """config.fallback = {} returns None (no model_id)."""
    assert _get_fallback_model_id({"fallback": {}}) is None


# --- Full process_job tests with mocks ---
@pytest.fixture
def job_deployment_user():
    """Create Job, Deployment, User for tests."""
    from api.models import User

    user_id = "user-11111111-1111-1111-1111-111111111111"
    deployment_id = "dep-22222222-2222-2222-2222-222222222222"
    job_id = "job-33333333-3333-3333-3333-333333333333"

    user = User(
        id=user_id,
        email="test@example.com",
        password_hash="x",
        email_verified=True,
        first_deploy_email_sent=True,
    )
    deployment = Deployment(
        id=deployment_id,
        user_id=user_id,
        model_id="qx-primary",
        status=DeploymentStatus.READY.value,
        config={},
    )
    job = Job(
        id=job_id,
        user_id=user_id,
        deployment_id=deployment_id,
        status=JobStatus.QUEUED.value,
        input_data={"prompt": "hello"},
        created_at=datetime.now(timezone.utc),
        fallback_triggered=False,
    )
    return job, deployment, user


@pytest.fixture
def mock_session(job_deployment_user):
    """Mock async session that returns our test entities."""
    job, deployment, user = job_deployment_user
    store = {"job": job, "deployment": deployment, "user": user}
    job_deployment_result = _MockResult((store["job"], store["deployment"]))
    user_result = _MockResult(store["user"])

    async def execute(statement):
        stmt_str = str(statement)
        if "users" in stmt_str.lower():
            return user_result
        return job_deployment_result

    session = MagicMock()
    session.execute = AsyncMock(side_effect=execute)
    session.flush = AsyncMock()
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    session.add = MagicMock()

    # async_session_maker() returns a context manager; both db and db2 use same session
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)
    return session, store, cm


class _MockResult:
    """Minimal Result mock for SQLAlchemy execute()."""

    def __init__(self, row):
        self._row = row
        self._rows = [row] if row is not None else []

    def one_or_none(self):
        return self._row

    def one(self):
        if self._row is None:
            raise ValueError("No row")
        return self._row

    def scalar_one_or_none(self):
        return self._row

    def scalars(self):
        return self

    def all(self):
        return self._rows

    def first(self):
        return self._rows[0] if self._rows else None


@pytest.mark.asyncio
async def test_primary_succeeds_no_fallback_attempted(job_deployment_user, mock_session):
    """When primary inference succeeds, no fallback is attempted."""
    job, deployment, user = job_deployment_user
    session, store, cm = mock_session

    with (
        patch("orchestrator.worker.async_session_maker", return_value=cm),
        patch("orchestrator.worker.create_inference_job", new_callable=AsyncMock) as mock_create,
        patch("orchestrator.worker.wait_for_job_completion", new_callable=AsyncMock) as mock_wait,
        patch("orchestrator.worker.read_inference_result_from_redis", new_callable=AsyncMock) as mock_read,
        patch("orchestrator.worker.settings", MagicMock(inference_url="")),
    ):
        mock_create.return_value = "inference-job-1"
        mock_wait.return_value = (True, None)
        mock_read.return_value = {
            "output_data": {"generated": "ok"},
            "tokens_used": 50,
            "compute_seconds": 1.0,
        }

        await process_job({
            "job_id": job.id,
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": {"prompt": "hello"},
            "retry_count": 0,
        })

        # create_inference_job called once (primary only), never with job_name_suffix
        assert mock_create.call_count == 1
        call_kw = mock_create.call_args.kwargs
        assert call_kw["model_id"] == "qx-primary"
        assert call_kw.get("job_name_suffix") is None
        assert mock_create.call_args.kwargs.get("job_name_suffix") is None


@pytest.mark.asyncio
async def test_primary_fails_retries_not_exhausted_reenqueue_no_fallback(job_deployment_user, mock_session):
    """When primary fails and retries not exhausted, re-enqueue; no fallback."""
    job, deployment, user = job_deployment_user
    session, store, cm = mock_session

    with (
        patch("orchestrator.worker.async_session_maker", return_value=cm),
        patch("orchestrator.worker.create_inference_job", new_callable=AsyncMock) as mock_create,
        patch("orchestrator.worker.wait_for_job_completion", new_callable=AsyncMock) as mock_wait,
        patch("orchestrator.worker.enqueue_job", new_callable=AsyncMock) as mock_enqueue,
        patch("orchestrator.worker.settings", MagicMock(inference_url="")),
    ):
        mock_create.return_value = "inference-job-1"
        mock_wait.return_value = (False, "Timeout")
        # retry_count=0 < MAX, so we re-enqueue
        await process_job({
            "job_id": job.id,
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": {"prompt": "hello"},
            "retry_count": 0,
        })

        mock_enqueue.assert_called_once()
        payload = mock_enqueue.call_args.kwargs.get("payload") or mock_enqueue.call_args[1].get("payload", {})
        assert payload.get("retry_count") == 1
        # No fallback attempt
        assert mock_create.call_count == 1


@pytest.mark.asyncio
async def test_primary_fails_retries_exhausted_no_fallback_config_job_failed(job_deployment_user, mock_session):
    """When primary fails, retries exhausted, no fallback config → job FAILED."""
    job, deployment, user = job_deployment_user
    deployment.config = {}  # No fallback
    session, store, cm = mock_session

    with (
        patch("orchestrator.worker.async_session_maker", return_value=cm),
        patch("orchestrator.worker.create_inference_job", new_callable=AsyncMock) as mock_create,
        patch("orchestrator.worker.wait_for_job_completion", new_callable=AsyncMock) as mock_wait,
        patch("orchestrator.worker.settings", MagicMock(inference_url="")),
    ):
        mock_create.return_value = "inference-job-1"
        mock_wait.return_value = (False, "Timeout")

        await process_job({
            "job_id": job.id,
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": {"prompt": "hello"},
            "retry_count": MAX_INFERENCE_RETRIES,  # Exhausted
        })

        # No fallback attempt (create called once for primary only)
        assert mock_create.call_count == 1
        # Job should be marked failed
        assert store["job"].status == JobStatus.FAILED.value
        assert store["job"].fallback_triggered is False


@pytest.mark.asyncio
async def test_primary_fails_fallback_succeeds_fallback_triggered_true(job_deployment_user, mock_session):
    """When primary fails, retries exhausted, fallback configured and succeeds → fallback_triggered=True."""
    job, deployment, user = job_deployment_user
    deployment.config = {"fallback": {"model_id": "qx-fallback-small"}}
    session, store, cm = mock_session

    with (
        patch("orchestrator.worker.async_session_maker", return_value=cm),
        patch("orchestrator.worker.create_inference_job", new_callable=AsyncMock) as mock_create,
        patch("orchestrator.worker.wait_for_job_completion", new_callable=AsyncMock) as mock_wait,
        patch("orchestrator.worker.read_inference_result_from_redis", new_callable=AsyncMock) as mock_read,
        patch("orchestrator.worker.settings", MagicMock(inference_url="")),
    ):
        # Primary fails
        def create_side_effect(*args, **kwargs):
            if kwargs.get("job_name_suffix") == "fb":
                return "inference-job-fb"
            return "inference-job-1"

        mock_create.side_effect = create_side_effect
        mock_wait.side_effect = [
            (False, "Timeout"),   # Primary
            (True, None),         # Fallback
        ]
        mock_read.return_value = {
            "output_data": {"generated": "fallback ok"},
            "tokens_used": 30,
            "compute_seconds": 0.5,
        }

        await process_job({
            "job_id": job.id,
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": {"prompt": "hello"},
            "retry_count": MAX_INFERENCE_RETRIES,
        })

        # create_inference_job called twice: primary + fallback
        assert mock_create.call_count == 2
        # Second call has fallback model and suffix
        fallback_call = mock_create.call_args_list[1]
        assert fallback_call.kwargs["model_id"] == "qx-fallback-small"
        assert fallback_call.kwargs["job_name_suffix"] == "fb"
        assert store["job"].fallback_triggered is True
        assert store["job"].status == JobStatus.COMPLETED.value


@pytest.mark.asyncio
async def test_primary_fails_fallback_also_fails_job_failed(job_deployment_user, mock_session):
    """When primary fails, fallback configured but fallback also fails → job FAILED."""
    job, deployment, user = job_deployment_user
    deployment.config = {"fallback": {"model_id": "qx-fallback-small"}}
    session, store, cm = mock_session

    with (
        patch("orchestrator.worker.async_session_maker", return_value=cm),
        patch("orchestrator.worker.create_inference_job", new_callable=AsyncMock) as mock_create,
        patch("orchestrator.worker.wait_for_job_completion", new_callable=AsyncMock) as mock_wait,
        patch("orchestrator.worker.settings", MagicMock(inference_url="")),
    ):
        def create_side_effect(*args, **kwargs):
            if kwargs.get("job_name_suffix") == "fb":
                return "inference-job-fb"
            return "inference-job-1"

        mock_create.side_effect = create_side_effect
        mock_wait.return_value = (False, "Timeout")  # Both primary and fallback fail

        await process_job({
            "job_id": job.id,
            "deployment_id": deployment.id,
            "user_id": user.id,
            "input": {"prompt": "hello"},
            "retry_count": MAX_INFERENCE_RETRIES,
        })

        assert mock_create.call_count == 2
        assert store["job"].status == JobStatus.FAILED.value
        assert store["job"].fallback_triggered is False
