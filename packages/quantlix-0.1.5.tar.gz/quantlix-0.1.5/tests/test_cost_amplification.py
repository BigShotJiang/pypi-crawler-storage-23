"""Cost Amplification Score tests."""
from api.cost_estimation import compute_cost_amplification, estimate_cost_eur


def test_estimate_cost_eur_zero():
    """Zero usage returns 0."""
    assert estimate_cost_eur(0, 0.0, 0.0) == 0.0


def test_estimate_cost_eur_tokens():
    """Token cost: €10/1M."""
    assert estimate_cost_eur(1_000_000, 0, 0) == 10.0
    assert estimate_cost_eur(100_000, 0, 0) == 1.0


def test_compute_cost_amplification_no_retry_no_fallback():
    """Single run: amplification 1.0, all cost in base."""
    r = compute_cost_amplification(
        tokens=50,
        compute_s=1.5,
        gpu_s=0,
        retry_count=0,
        fallback_triggered=False,
    )
    assert r["amplification_factor"] == 1.0
    assert r["retry_cost_eur"] == 0
    assert r["fallback_cost_eur"] == 0
    assert r["base_cost_eur"] == r["total_cost_eur"]


def test_compute_cost_amplification_with_retries():
    """2 retries: amplification 3.0, cost split across base + retry."""
    r = compute_cost_amplification(
        tokens=50,
        compute_s=1.5,
        gpu_s=0,
        retry_count=2,
        fallback_triggered=False,
    )
    assert r["amplification_factor"] == 3.0
    assert r["fallback_cost_eur"] == 0
    assert r["base_cost_eur"] > 0
    assert r["retry_cost_eur"] == 2 * r["base_cost_eur"]
    assert abs(r["total_cost_eur"] - (r["base_cost_eur"] + r["retry_cost_eur"])) < 0.0001


def test_compute_cost_amplification_with_fallback():
    """Fallback: amplification 2.0, base + fallback."""
    r = compute_cost_amplification(
        tokens=50,
        compute_s=1.5,
        gpu_s=0,
        retry_count=0,
        fallback_triggered=True,
    )
    assert r["amplification_factor"] == 2.0
    assert r["retry_cost_eur"] == 0
    assert r["base_cost_eur"] == r["fallback_cost_eur"]
    assert r["total_cost_eur"] == r["base_cost_eur"] + r["fallback_cost_eur"]


def test_compute_cost_amplification_retry_and_fallback():
    """Retry + fallback: amplification 4.0 (1 base + 2 retries + 1 fallback)."""
    r = compute_cost_amplification(
        tokens=100,
        compute_s=2.0,
        gpu_s=0,
        retry_count=2,
        fallback_triggered=True,
    )
    assert r["amplification_factor"] == 4.0
    assert r["base_cost_eur"] > 0
    assert r["retry_cost_eur"] == 2 * r["base_cost_eur"]
    assert r["fallback_cost_eur"] == r["base_cost_eur"]
    assert r["total_cost_eur"] == r["base_cost_eur"] + r["retry_cost_eur"] + r["fallback_cost_eur"]
