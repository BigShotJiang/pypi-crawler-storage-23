"""django_schema_browser package."""

__version__ = "0.1.4"
