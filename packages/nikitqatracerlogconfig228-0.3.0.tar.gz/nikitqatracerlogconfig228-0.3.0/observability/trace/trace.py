import grpc
from opentelemetry import metrics
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter as OTLPSpanGrpcExporter
from opentelemetry.sdk.extension.aws.trace import AwsXRayIdGenerator
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader, ConsoleMetricExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter, SimpleSpanProcessor


class TracerFactory:
    def __init__(
        self,
        service_name: str,
        service_version: str,
        deployment_environment: str,
    ):
        self.service_name = service_name
        self.service_version = service_version
        self.deployment_environment = deployment_environment

    def _create_resource(self) -> Resource:
        return Resource(
            attributes={
                "service.name": self.service_name,
                "service.version": self.service_version,
                "library.language": "python",
                "deployment.environment": self.deployment_environment,
            },
        )

    def configure_grpc(
        self,
        endpoint: str,
        headers: dict[str, str],
        insecure: bool = False,
    ) -> TracerProvider:
        resource = self._create_resource()

        provider = TracerProvider(
            resource=resource,
            id_generator=AwsXRayIdGenerator(),
        )
        span_processor = BatchSpanProcessor(
            OTLPSpanGrpcExporter(
                endpoint=endpoint,
                insecure=insecure,
                headers=headers,
                timeout=5,
                compression=grpc.Compression.Gzip,
            )
        )
        provider.add_span_processor(span_processor)

        metric_reader = PeriodicExportingMetricReader(
            OTLPMetricExporter(
                endpoint=endpoint,
                insecure=insecure,
                headers=headers,
                timeout=5,
                compression=grpc.Compression.Gzip,
            )
        )
        metric_provider = MeterProvider(
            resource=resource,
            metric_readers=[metric_reader]
        )
        metrics.set_meter_provider(metric_provider)

        trace.set_tracer_provider(provider)
        return provider

    def configure_console(self) -> TracerProvider:
        resource = self._create_resource()

        provider = TracerProvider(
            resource=resource,
            id_generator=AwsXRayIdGenerator(),
        )
        console_span_processor = SimpleSpanProcessor(ConsoleSpanExporter())
        provider.add_span_processor(console_span_processor)

        console_metric_reader = PeriodicExportingMetricReader(ConsoleMetricExporter())
        metric_provider = MeterProvider(
            resource=resource,
            metric_readers=[console_metric_reader]
        )
        metrics.set_meter_provider(metric_provider)

        trace.set_tracer_provider(provider)
        return provider

    def configure_dev(self) -> TracerProvider:
        resource = self._create_resource()

        provider = TracerProvider(
            resource=resource,
            id_generator=AwsXRayIdGenerator(),
        )

        metric_provider = MeterProvider(resource=resource)
        metrics.set_meter_provider(metric_provider)

        trace.set_tracer_provider(provider)
        return provider
