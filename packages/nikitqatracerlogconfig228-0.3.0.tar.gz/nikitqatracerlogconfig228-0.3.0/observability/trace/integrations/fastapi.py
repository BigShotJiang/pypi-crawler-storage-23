from opentelemetry import trace
from starlette.middleware.base import RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response


class TraceParentMiddleware:
    async def __call__(self, request: Request, call_next: RequestResponseEndpoint, *args, **kwargs) -> Response:
        span = trace.get_current_span()
        span_context = span.get_span_context()
        
        trace_parent_value = span_context.trace_id
        trace_parent_header = f"00-{trace_parent_value:032x}-{span_context.span_id:016x}-{span_context.trace_flags:02x}"
        
        response = await call_next(request)
        
        response.headers["traceparent"] = trace_parent_header
        
        return response
