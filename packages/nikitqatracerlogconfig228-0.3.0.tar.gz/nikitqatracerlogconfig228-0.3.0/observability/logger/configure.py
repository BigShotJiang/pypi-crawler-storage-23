import logging.config
import logging.handlers

from typing import Literal, Protocol

import structlog
from structlog.processors import CallsiteParameterAdder, CallsiteParameter
from structlog.typing import EventDict, WrappedLogger

from .config import LoggingConfig
from .processors.app.processor import ApplicationProcessor
from .processors.otel.processor import OTELRenamer
from .processors.sanitizer.processor import StructlogSanitizer


class Renderer(Protocol):
    def __call__(self, logger: WrappedLogger, name: str, event_dict: EventDict) -> str | bytes:
        raise NotImplementedError


def get_render_processor(fmt: Literal["json", "console", "console_colored"] = "json") -> Renderer:
    processors = {
        "json": structlog.processors.JSONRenderer(ensure_ascii=False, sort_keys=True),
        "console": structlog.processors.KeyValueRenderer(),
        "console_colored": structlog.dev.ConsoleRenderer(colors=True),
    }
    return processors[fmt]


def configure_logging(cfg: LoggingConfig) -> None:
    common_processors = [
        structlog.processors.EventRenamer(to="message"),
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.ExtraAdder(),
        structlog.dev.set_exc_info,
        structlog.processors.TimeStamper(fmt="%Y-%m-%d %H:%M:%S.%f", utc=True),
        structlog.contextvars.merge_contextvars,
        CallsiteParameterAdder(
            (
                CallsiteParameter.THREAD,
                CallsiteParameter.FILENAME,
                CallsiteParameter.FUNC_NAME,
                CallsiteParameter.LINENO,
            ),
        ),
    ]
    
    structlog_processors = [
        ApplicationProcessor(app_name=cfg.application.name, app_version=cfg.application.version),
        OTELRenamer(service_name="service_name", trace_id_name="trace_id", span_id_name="span_id"),
        structlog.processors.StackInfoRenderer(),
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.UnicodeDecoder(),
    ]
    
    if cfg.format == "json":
        common_processors.append(structlog.processors.dict_tracebacks)
        structlog_processors.append(structlog.processors.format_exc_info)

    processors = common_processors + structlog_processors
    
    if cfg.sensitivity:
        sanitizer = StructlogSanitizer(keys=cfg.sensitivity.keys, replacement=cfg.sensitivity.replacement)
        processors.append(sanitizer)
    
    renderer = get_render_processor(cfg.format)
    
    handler = logging.StreamHandler()
    handler.set_name("default")
    handler.setLevel(cfg.level)
    
    console_formatter = structlog.stdlib.ProcessorFormatter(
        processor=renderer,
        foreign_pre_chain=processors
    )
    handler.setFormatter(console_formatter)
    handlers: list[logging.Handler] = [handler]
    
    if cfg.file:
        file_handler = logging.handlers.WatchedFileHandler(filename=cfg.file.path, encoding="utf-8")
        file_handler.set_name("file")
        file_handler.setLevel(cfg.level)
        
        file_formatter = structlog.stdlib.ProcessorFormatter(
            processor=renderer,
            foreign_pre_chain=processors
        )
        file_handler.setFormatter(file_formatter)
        handlers.append(file_handler)
    
    root_logger = logging.getLogger()
    root_logger.setLevel(cfg.level)
    for h in handlers:
        root_logger.addHandler(h)
    
    specific_loggers = {
        "sqlalchemy.engine.Engine": cfg.level,
        "uvicorn": logging.INFO,
        "uvicorn.access": logging.ERROR,
        "uvicorn.error": logging.INFO,
    } | cfg.custom_loggers
    
    for logger_name, level in specific_loggers.items():
        logger = logging.getLogger(logger_name)
        logger.setLevel(level)
        for h in handlers:
            logger.addHandler(h)
        logger.propagate = False

    structlog.configure(
        processors=(*processors, renderer),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    
    logging.basicConfig(handlers=handlers, level=cfg.level)
