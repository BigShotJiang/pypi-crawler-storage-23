import http
import json
import math
import time
import logging

from fastapi import Request, Response
from starlette.types import Message
from starlette.middleware.base import RequestResponseEndpoint

from .schemas import RequestJsonLogSchema
from .cors import handle_custom_500_with_cors

logger = logging.getLogger(__name__)


EMPTY_VALUE = ""


class LoggingMiddleware:
    def __init__(
        self,
        logging_request: bool = True,
        logging_response: bool = True,
        logging_headers: bool = True,
    ):
        self.logging_request = logging_request
        self.logging_response = logging_response
        self.logging_headers = logging_headers
    
    @staticmethod
    async def get_protocol(request: Request) -> str:
        protocol = str(request.scope.get("type", ""))
        http_version = str(request.scope.get("http_version", ""))
        if protocol.lower() == "http" and http_version:
            return f"{protocol.upper()}/{http_version}"
        return EMPTY_VALUE
    
    @staticmethod
    async def set_body(request: Request, body: bytes) -> None:
        async def receive() -> Message:
            return {"type": "http.request", "body": body}
        
        request._receive = receive
    
    async def get_body(self, request: Request) -> bytes:
        body = await request.body()
        await self.set_body(request, body)
        return body
    
    async def __call__(
        self, request: Request, call_next: RequestResponseEndpoint, *args, **kwargs
    ):
        start_time = time.time()
        exception_object = None
        request_body = EMPTY_VALUE
        request_content_type = request.headers.get("Content-Type", EMPTY_VALUE)
        # Request Side
        try:
            if "application/json" == request_content_type:
                raw_request_body = await request.body()
                await self.set_body(request, raw_request_body)
                raw_request_body = await self.get_body(request)
                request_body = raw_request_body.decode()
        
        except AttributeError:
            request_body = EMPTY_VALUE
        try:
            if request_body != EMPTY_VALUE:
                request_body = json.loads(request_body)
        except json.decoder.JSONDecodeError:
            pass
        
        server: tuple = request.get("server", ("localhost", 80))
        request_headers: dict = dict(request.headers.items())
        # Response Side
        try:
            response = await call_next(request)
        
        except Exception as ex:
            response_body = bytes(http.HTTPStatus.INTERNAL_SERVER_ERROR.phrase.encode())
            response = handle_custom_500_with_cors(request=request)
            exception_object = ex
            response_headers = {}
        else:
            response_headers = dict(response.headers.items())
            response_body = b""
            async for chunk in response.body_iterator:
                response_body += chunk
            response = Response(
                content=response_body,
                status_code=response.status_code,
                headers=response.headers,
                media_type=response.media_type,
                background=response.background,
            )
        duration: int = math.ceil((time.time() - start_time) * 1000)
        
        response_content_type = response.headers.get("Content-Type", EMPTY_VALUE)
        
        try:
            if "application/json" == response_content_type:
                response_body = json.loads(response_body)
            else:
                response_body = EMPTY_VALUE
        except json.decoder.JSONDecodeError:
            response_body = response_body.decode()
        
        request_size = int(request_headers.get("content-length", 0))
        response_size = int(response_headers.get("content-length", 0))
        request_response_body_large = {"sys-info": "Request/Response size is very large"}
        
        request_json_fields = RequestJsonLogSchema(
            request_uri=str(request.url),
            request_referer=request_headers.get("referer", EMPTY_VALUE),
            request_protocol=await self.get_protocol(request),
            request_method=request.method,
            request_path=request.url.path,
            request_host=f"{server[0]}:{server[1]}",
            request_size=request_size,
            request_content_type=request_content_type,
            request_headers=request_headers if self.logging_headers else {},
            request_body=request_body
            if self.logging_request
            else request_response_body_large,
            request_direction="in",
            remote_ip=request.client[0],
            remote_port=request.client[1],
            response_status_code=response.status_code,
            response_size=response_size,
            response_headers=response_headers,
            response_body=response_body
            if self.logging_response
            else request_response_body_large,
            duration=duration,
        ).dict()
        
        message_template = "%s with code %s on request %s %s, for %s ms"
        message_formatted = message_template % (
            "Error" if exception_object else "Response",
            response.status_code,
            request.method,
            str(request.url),
            duration,
        )
        if exception_object:
            logger.exception(
                message_formatted,
                extra={
                    "meta": request_json_fields,
                },
                exc_info=exception_object,
            )
            return response
        else:
            logger.info(
                message_formatted,
                extra={
                    "meta": request_json_fields,
                },
            )
        return response

