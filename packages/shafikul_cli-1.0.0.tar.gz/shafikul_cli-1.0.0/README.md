# Shafikul CLI

**Shafikul CLI** is a command-line tool to scaffold **FastAPI projects** quickly.  
It helps you generate routers, models, database connections, and HTML templates with proper folder structure and auto updates for `main.py` and `.env` file.

---

## Features

- ✅ Create FastAPI routers, models, and database modules  
- ✅ Auto-generate `main.py` with imports and DB setup  
- ✅ Auto-generate or update `.env` file  
- ✅ Create HTML templates (`index.html` or custom names)  
- ✅ Interactive CLI (numeric and text options)  
- ✅ Colored console output  
- ✅ Version and About commands (`--version` / `--about`)  

---

## Installation

Install from PyPI:

```bash
pip install shafikul-cli
```

Or Locally (editable):
```sh
git clone https://github.com/build-with-shafikul/shafikul_cli.git
cd shafikul-cli
pip install -e .
```

## Show version
```sh
shafikul --version
```

## About CLI
```sh
shafikul --about
```

## Create resources
```sh
shafikul create app
```

### Interactive Option
<code>
1: router <br/>
2: models <br/>
3: database <br/>
4: html
</code>
<br/>
<br/>

You can select by number or by name
Example for HTML template: <br/>
<code>shafikul create app html <br/>
Enter file name default [index.html]: home.html</code>

Database creation also auto updates main.py and .env

# Project Structure
```sh
project_root/
├── app/
│   ├── models.py
│   └── database.py
├── router/
│   └── users.py
├── templates/
│   └── index.html
├── main.py
└── .env
```

# Development

If you want to contribute: <br/>
Fork the repo <br/>
Create a feature branch: git checkout -b feature-name<br/>
Commit your changes: git commit -m "Add feature"<br/>
Push to the branch: git push origin feature-name<br/>
Open a Pull Request

# License
`GPL-3.0 license`

# Author
Md Shafikul Islam
<a href="https://github.com/build-with-shafikul" target="_blank">GitHub ↗</a>