from setuptools import setup, find_packages

VERSION = "1.0.0"

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="shafikul-cli",
    version=VERSION,
    py_modules=["shafikul_cli"], 
    install_requires=[
        "typer",
        "rich",
        "keyboard",
        "pyautogui",
        "pyperclip",
    ],
    entry_points={
        "console_scripts": [
            "shafikul=shafikul_cli:app",
        ],
    },
    packages=find_packages(),
    include_package_data=True,
    long_description=long_description, 
    long_description_content_type="text/markdown",     
    description="CLI tool for FastAPI scaffolding with router, models, database, and templates.",
    author="Md Shafikul Islam",
    author_email="buildwithshafikul@gmail.com",
    url="https://github.com/build-with-shafikul/shafikul_cli",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",

)