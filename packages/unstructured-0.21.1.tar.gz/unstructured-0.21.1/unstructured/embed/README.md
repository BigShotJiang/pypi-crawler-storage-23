# Embed
![Project unmaintained](https://img.shields.io/badge/project-unmaintained-red.svg)

Project has been moved to: [Unstructured Ingest](https://github.com/Unstructured-IO/unstructured-ingest)

This python module will be removed from this repo in the near future.
