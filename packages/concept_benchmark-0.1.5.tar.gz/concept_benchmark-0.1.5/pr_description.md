# PR: Restructure package for pip install and CLI usage

**Base:** main ← **Head:** pretty_branch

## Summary

This PR restructures `concept-benchmark` from a collection of standalone scripts into a pip-installable package with a CLI, configurable benchmarks, and comprehensive documentation.

**92 files changed** — the diff is large because standalone scripts were absorbed into the package. The core ML logic (`models.py`, `data.py`, `kflip.py`, `intervention.py`, `train.py`) has minimal changes; the bulk of the work is new packaging infrastructure and pipeline orchestration.

### What changed

**Package structure**
- New `concept_benchmark/benchmarks/` module with `robot.py`, `sudoku.py`, `robot_text.py` — each exposes `run()` + individual stage functions (`setup_dataset`, `train_cbm`, `run_interventions`, etc.)
- New `concept_benchmark/config.py` with dataclass configs (`RobotBenchmarkConfig`, `SudokuBenchmarkConfig`) supporting YAML serialization
- New `concept_benchmark/cli.py` — CLI entry point (`cbm-benchmark robot/sudoku/robot-text`)
- New `concept_benchmark/alignment.py` — constrained retraining via CVXPY
- New `concept_benchmark/lfcbm.py` — Label-Free CBM using CLIP (for machine/llm/clip intervention regimes)
- New `concept_benchmark/llm_client.py` — LLM provider abstraction for Gemini API
- New `concept_benchmark/_logging.py` — logging configuration

**Intervention regimes**
- 6 regimes: `baseline`, `expert`, `subjective`, `machine`, `llm`, `clip`
- Configurable via `--regimes` CLI flag or `regimes` config parameter
- LFCBM concept description files bundled in `concept_benchmark/concept_descriptions/`

**Performance: vectorized intervention code**
- Vectorized `ScoreIntervention.propose()` — batches all N samples per combination into a single `predict_proba` call instead of looping per-sample. Reduces from N×C(n,k) to C(n,k) sklearn calls (~100x fewer calls for subconcept budget=3).
- Fast logistic regression path in KFlip — exploits linearity to compute `logit_new = base_logit - base_Z[:,S] @ w[S] + assign @ w[S]` instead of calling `predict_proba` per assignment. ~2.5x speedup on intervention stage.
- Vectorized confusion matrix computation with `np.bincount`.

**`--budgets` CLI flag**
- New `--budgets` flag for all benchmarks: `cbm-benchmark robot --budgets 1 3 max`
- `max` resolves to the number of concepts at runtime (7 for ideal, 12 for subconcept, 27 for sudoku)
- k=0 (no intervention baseline) is always included automatically in results

**Sudoku pipeline**
- Handwritten digit OCR pipeline (`synthetic/sudoku_ocr/`)
- Handwriting font (`Pecita.otf`) bundled in `concept_benchmark/data/fonts/`
- Selective classification with configurable `target_accuracy`
- `--data-type` (tabular/image) and `--handwriting`/`--no-handwriting` CLI flags
- Deterministic training on MPS (replaced `nn.Embedding` with `nn.Linear` on one-hot input)

**Robot text pipeline**
- Text modality for robot classification (`synthetic/robot_text/`)
- Template-based corpus generation with configurable difficulty

**CLI and config**
- `cbm-benchmark` entry point with `--stages`, `--seed`, `--config`, `--subconcept`, `--regimes`, `--strategy`, `--budgets`, `--dry-run`, etc.
- YAML config files for reproducibility (`cfg.to_yaml()` / `--config path.yaml`)
- `--force-setup` and `--force-retrain` flags
- Stage-level caching — repeated runs skip completed stages
- `[i/N]` stage progress indicators in pipeline output

**Config simplification**
- Removed `spurious_features` parameter — concept exclusion is now handled entirely by `drop_concepts` (added `has_elbows` and `hand_shape` to `IDEAL_DROP` / `SUBCONCEPT_DROP`)
- Deleted dead `add_irrelevant_feature()` function from `robot_catalog.py`

**Bug fixes**
- Fixed `expit` not imported in `synthetic/robot.py` (stochastic labeling was broken)
- Fixed MPS race condition from `non_blocking=True`
- Fixed `None > int` comparison in `intervention.py`
- Fixed mutable default argument in `cv.py`
- Fixed missing `import logging` in `alignment.py` (caused NameError on align stage)
- Removed deprecated sklearn parameters (`penalty=`, `n_jobs=`)
- Model fingerprinting to detect stale cached models after config changes

**Tests**
- New: `test_config.py` (config validation, YAML round-trip), `test_cli.py` (CLI parsing), `test_smoke_pipelines.py` (end-to-end pipeline smoke tests), `test_robot_pipeline_regression.py` (regression against known-good outputs)
- Removed stale tests that depended on deleted scripts
- 83 tests passing (+ 4 slow/skipped)

**Documentation**
- Complete README rewrite with Quick Start (CLI + Python API), parameter tables, expected outputs
- `install.sh` for one-command setup
- `CITATION.cff`
- Demo scripts: `scripts/demo_robot.py`, `scripts/demo_sudoku.py`, `scripts/demo_robot_text.py`
- Published to PyPI as `concept-benchmark` (v0.1.4)

### Deleted files

22 standalone scripts in `scripts/` were absorbed into the package modules. The functionality is preserved — `robot_image_training.py` → `benchmarks/robot.py`, `run_sudoku.py` → `benchmarks/sudoku.py`, etc. Three new demo scripts replace them.

### How to verify

```bash
# Install and run
./install.sh && source venv/bin/activate

# Quick smoke test
cbm-benchmark robot --seed 1014 --dry-run

# Full robot pipeline (~2 min for ideal, ~8 min for subconcept)
cbm-benchmark robot --seed 1014 --stages setup cbm dnn intervene collect
cbm-benchmark robot --seed 1014 --subconcept --budgets 1 3 max

# Full sudoku pipeline (~5 min)
cbm-benchmark sudoku --seed 171

# Tests
python -m pytest tests/ -v
```
