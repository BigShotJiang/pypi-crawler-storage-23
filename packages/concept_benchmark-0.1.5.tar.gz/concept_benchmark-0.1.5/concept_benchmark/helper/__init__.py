"""Helper utilities for concept_benchmark."""
