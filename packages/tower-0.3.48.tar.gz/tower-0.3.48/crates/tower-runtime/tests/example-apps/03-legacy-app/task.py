import dlt

print(dlt.version.__version__)
