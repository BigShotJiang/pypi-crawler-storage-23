# frame-counter
Frame counter CLI for speedrun verification

## Installation:
```
pip install frame-counter
```

## Usage:
```
frame-counter <FPS> <START_FRAME> <END_FRAME>
```

The result looks like this:
```
H:M:S.m
Mod Note: Start Frame: XX, End Frame: XX, Frame Rate: XX, Time: H:M:S.m
```
