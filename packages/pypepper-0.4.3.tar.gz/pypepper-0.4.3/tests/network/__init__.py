"""Network tests"""
