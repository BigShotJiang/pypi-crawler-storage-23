"""SSE tests"""
