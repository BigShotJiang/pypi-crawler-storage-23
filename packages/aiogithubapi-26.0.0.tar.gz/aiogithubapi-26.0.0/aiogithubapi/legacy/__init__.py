"""Initialise the legacy module, everything here is considered deprecated."""
