"""AIOGitHubAPI: objects.content"""

from .base import AIOGitHubAPIBase


class AIOGitHubAPIContentBase(AIOGitHubAPIBase):
    """Base Content class for AIOGitHubAPI."""
