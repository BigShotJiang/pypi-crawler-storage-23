"""Class objects for login."""
