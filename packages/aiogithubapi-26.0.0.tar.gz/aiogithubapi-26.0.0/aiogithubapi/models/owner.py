"""GitHub owner model."""

from .user import GitHubUserModel


class GitHubOwnerModel(GitHubUserModel):
    """GitHub owner model."""
