"""AIOGitHubAPI: Constants"""

from ..const import *

OAUTH_DEVICE_LOGIN = "https://github.com/login/device/code"
OAUTH_ACCESS_TOKEN = "https://github.com/login/oauth/access_token"
