"""Common elements."""
