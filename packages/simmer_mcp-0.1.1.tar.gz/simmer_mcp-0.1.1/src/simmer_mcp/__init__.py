"""Simmer MCP Server — gives AI agents Simmer's API docs as context."""

__version__ = "0.1.0"
