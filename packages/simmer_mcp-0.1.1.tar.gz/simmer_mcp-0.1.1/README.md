# simmer-mcp

MCP server that gives AI agents [Simmer's](https://simmer.markets) API documentation and error troubleshooting.

## Who is this for?

**Local AI setups** — Claude Desktop, Claude Code, Cursor, or any MCP-compatible client running on your machine. The server runs as a local stdio subprocess alongside your AI tool.

**Not for cloud-hosted Clawbots.** If your Clawbot runs on Railway/Render/etc., it already gets Simmer docs via the `/simmer` skill at runtime. You don't need this package — and adding `mcpServers` to `openclaw.json` will break your config (OpenClaw doesn't support that key).

## Install

```bash
pip install simmer-mcp
```

## Setup

Add to your MCP client config (Claude Desktop, Cursor, etc.):

```json
{
  "mcpServers": {
    "simmer": {
      "command": "python",
      "args": ["-m", "simmer_mcp"]
    }
  }
}
```

> **Warning:** Do NOT add `mcpServers` to `openclaw.json` — OpenClaw doesn't support this key and it will prevent the gateway from starting. This config goes in your MCP client's config file (e.g. Claude Desktop's `claude_desktop_config.json`).

Your agent now has full Simmer API docs in context and can call `troubleshoot_error("not enough balance")` when something fails.

## What it does

- **API docs as context** — serves `docs.md` and `skill.md` as MCP resources so your agent has the full Simmer API reference in working memory
- **Error lookup** — `troubleshoot_error()` tool matches common API errors to one-liner fixes

## Resources

| Resource | Description |
|----------|-------------|
| `simmer://docs/api-reference` | Full API reference (~2400 lines) |
| `simmer://docs/skill-reference` | Condensed agent reference (~600 lines) |

## Tools

| Tool | Description |
|------|-------------|
| `troubleshoot_error(error_text)` | Match an error against known patterns, get a fix |

## Docs

- Full API reference: https://simmer.markets/docs.md
- Python SDK: `pip install simmer-sdk`
- Website: https://simmer.markets
