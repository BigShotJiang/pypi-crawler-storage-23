#!/usr/bin/env python3
"""
Generic Workflow Example Runner

This module provides a generic runner for any YAML workflow definition.
It automatically detects MFA requirements and sets up the appropriate configuration.

Usage Examples:

    # Run with OpenAI (default)
    python example_runner.py concert_ticket_booking.yaml

    # Run with OpenAI and specific model
    python example_runner.py concert_ticket_booking.yaml --model gpt-4o

    # Run with Ollama
    python example_runner.py concert_ticket_booking.yaml --provider ollama --model llama3.2

    # Run with Ollama (shorter - uses default model)
    python example_runner.py concert_ticket_booking.yaml --provider ollama

    # Run with Bedrock
    python example_runner.py concert_ticket_booking.yaml --provider bedrock --model anthropic.claude-3-sonnet-20240229-v1:0

    # Run with Bedrock (shorter - uses default model)
    python example_runner.py concert_ticket_booking.yaml --provider bedrock

    # With initial context (pre-populate fields)
    python example_runner.py concert_ticket_booking.yaml --provider ollama --context '{"customer_name": "Alice"}'

    # With OpenAI and initial context
    python example_runner.py concert_ticket_booking.yaml --context '{"customer_name": "Bob", "concert_name": "Rock Fest"}'

    # Run any other workflow YAML file
    python example_runner.py /path/to/your_workflow.yaml --provider ollama --model llama3.2
"""

import argparse
import json
import logging
import os
import subprocess
import sys
import uuid
from typing import Optional, Literal, Dict, Any
import yaml

from langgraph.checkpoint.memory import MemorySaver
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import MFAConfig, InterruptType

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class WorkflowRunner:
    """
    Generic workflow runner that works with any YAML workflow definition

    Automatically detects and configures:
    - MFA-protected steps (creates MFAConfig if needed)
    - Workflow metadata (name, version, description)
    - Model provider settings (OpenAI or Ollama)
    - Initial context handling

    Command Line Usage:
        # OpenAI (requires OPENAI_API_KEY env var)
        python example_runner.py concert_ticket_booking.yaml
        python example_runner.py concert_ticket_booking.yaml --model gpt-4o

        # Ollama (requires Ollama running locally)
        python example_runner.py concert_ticket_booking.yaml --provider ollama --model llama3.2
        python example_runner.py concert_ticket_booking.yaml --provider ollama

    Programmatic Usage:
        from example_runner import WorkflowRunner

        # With OpenAI
        runner = WorkflowRunner(
            yaml_path="concert_ticket_booking.yaml",
            provider="openai",
            model_name="gpt-4o-mini"
        )
        runner.interactive_session(initial_context={"customer_name": "Alice"})

        # With Ollama
        runner = WorkflowRunner(
            yaml_path="concert_ticket_booking.yaml",
            provider="ollama",
            model_name="llama3.2"
        )
        runner.interactive_session()
    """

    def __init__(
        self,
        yaml_path: str,
        provider: Literal["openai", "ollama", "bedrock"] = "openai",
        model_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize the workflow runner

        Args:
            yaml_path: Path to the workflow YAML file
            provider: Model provider ("openai", "ollama", or "bedrock")
            model_name: Model name to use (defaults based on provider)
            config: Additional configuration options
        """
        logger.info("=" * 80)
        logger.info("Initializing Workflow Runner")
        logger.info("=" * 80)

        self.yaml_path = yaml_path
        self.provider = provider
        self.model_name = model_name or self._get_default_model(provider)
        self.config = config or {}

        logger.info(f"YAML Path: {yaml_path}")
        logger.info(f"Provider: {self.provider}")
        logger.info(f"Model: {self.model_name}")

        # Load and parse YAML to check for MFA
        self.workflow_config = self._load_yaml()
        self.mfa_enabled = self._check_mfa_enabled()

        # Create checkpointer for state persistence
        self.checkpointer = MemorySaver()
        logger.info("✓ Checkpointer initialized (MemorySaver)")

        # Configure MFA if needed
        self.mfa_config = None
        if self.mfa_enabled:
            self.mfa_config = self._create_mfa_config()
            logger.info("✓ MFA Config created (using mock endpoints)")
        else:
            logger.info("✓ No MFA required for this workflow")

        # Build workflow tool configuration
        tool_config = self._build_tool_config()

        # Initialize workflow tool
        try:
            workflow_name = self.workflow_config.get('name', 'Workflow')
            self.workflow_tool = WorkflowTool(
                yaml_path=yaml_path,
                name=workflow_name.replace(' ', ''),
                description=self.workflow_config.get('description', 'Workflow tool'),
                checkpointer=self.checkpointer,
                config=tool_config,
                mfa_config=self.mfa_config
            )
            logger.info("✓ Workflow loaded successfully")
            logger.info(f"  Workflow: {self.workflow_tool.engine.workflow_name}")
            logger.info(f"  Version: {self.workflow_tool.engine.workflow_version}")
            logger.info(f"  Steps: {len(self.workflow_tool.engine.steps)}")
            logger.info(f"  MFA-protected steps: {len([s for s in self.workflow_config.get('steps', []) if 'mfa' in s])}")
        except Exception as e:
            logger.error(f"✗ Failed to load workflow: {e}", exc_info=True)
            raise

        self.current_thread_id = None
        logger.info("=" * 80)

    def _load_yaml(self) -> Dict[str, Any]:
        """Load and parse the workflow YAML file"""
        try:
            with open(self.yaml_path, 'r') as f:
                config = yaml.safe_load(f)
            logger.info(f"✓ YAML loaded: {config.get('name', 'Unknown')} v{config.get('version', '?')}")
            return config
        except Exception as e:
            logger.error(f"✗ Failed to load YAML: {e}")
            raise

    def _check_mfa_enabled(self) -> bool:
        """Check if any steps in the workflow have MFA enabled"""
        steps = self.workflow_config.get('steps', [])
        mfa_steps = [step for step in steps if 'mfa' in step]

        if mfa_steps:
            logger.info(f"✓ Found {len(mfa_steps)} MFA-protected steps:")
            for step in mfa_steps:
                logger.info(f"  - {step['id']}: {step.get('description', 'No description')}")
            return True
        return False

    def _create_mfa_config(self) -> MFAConfig:
        """Create MFA configuration for workflows that require it"""
        # Get MFA endpoints from environment or use defaults
        base_url = os.getenv("MFA_BASE_URL", "http://localhost:8000")

        return MFAConfig(
            generate_token_base_url=base_url,
            generate_token_path=os.getenv("MFA_GENERATE_PATH", "/mfa/generate"),
            validate_token_base_url=base_url,
            validate_token_path=os.getenv("MFA_VALIDATE_PATH", "/mfa/validate"),
            authorize_token_base_url=base_url,
            authorize_token_path=os.getenv("MFA_AUTHORIZE_PATH", "/mfa/authorize")
        )

    @staticmethod
    def _get_default_model(provider: str) -> str:
        """Get default model for the provider"""
        defaults = {
            "openai": "gpt-4o-mini",
            "ollama": "llama3.2",
            "bedrock": "openai.gpt-oss-120b-1:0",
        }
        return defaults.get(provider, "gpt-4o-mini")

    def _get_model_config(self) -> dict:
        """Get model configuration based on provider"""
        if self.provider == "ollama":
            ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
            return {
                "model_name": self.model_name,
                "base_url": ollama_base_url,
                "provider": "ollama",
                "api_key": "dummy"
            }
        elif self.provider == "bedrock":
            return {
                "model_name": self.model_name,
                "provider": "bedrock",
            }
        else:
            config = {
                "model_name": self.model_name,
                "provider": "openai",
                "api_key": os.getenv("OPENAI_API_KEY", "")
            }
            if openai_base_url := os.getenv("OPENAI_BASE_URL"):
                config["base_url"] = openai_base_url
            return config

    def _build_tool_config(self) -> Dict[str, Any]:
        """Build the tool configuration"""
        tool_config = {
            "model_config": self._get_model_config()
        }

        # Merge with any additional config provided
        if self.config:
            tool_config.update(self.config)

        logger.info(f"Model config: {tool_config['model_config']}")
        return tool_config

    def start_workflow(self, thread_id: Optional[str] = None, initial_context: Optional[dict] = None):
        """
        Start a new workflow or resume an existing one

        Args:
            thread_id: Thread ID for resuming an existing workflow (optional)
            initial_context: Initial context to pre-populate fields (optional)
        """
        if thread_id:
            self.current_thread_id = thread_id
            logger.info(f"\n{'='*80}")
            logger.info(f"Resuming workflow with thread_id: {thread_id}")
            logger.info(f"{'='*80}")
        else:
            workflow_name = self.workflow_config.get('name', 'workflow').replace(' ', '_').lower()
            self.current_thread_id = f"{workflow_name}_{uuid.uuid4().hex[:8]}"
            logger.info(f"\n{'='*80}")
            logger.info(f"Starting new workflow with thread_id: {self.current_thread_id}")
            logger.info(f"{'='*80}")

        initial_context = initial_context or {}

        if initial_context:
            logger.info(f"Initial context provided: {list(initial_context.keys())}")
            for key, value in initial_context.items():
                logger.info(f"  {key}: {value}")
        else:
            logger.info("No initial context provided")

        try:
            result = self.workflow_tool.execute(
                thread_id=self.current_thread_id,
                initial_context=initial_context
            )

            logger.info(f"\nWorkflow result: {result[:100]}...")
            return self._handle_result(result)

        except Exception as e:
            logger.error(f"✗ Error executing workflow: {e}", exc_info=True)
            return None

    def resume_with_input(self, user_input: str, initial_context: dict):
        """
        Resume the workflow with user input

        Args:
            user_input: User's response to the current prompt
            initial_context: Context to pass to the workflow
        """
        if not self.current_thread_id:
            logger.error("✗ No active workflow session. Please start a new workflow first.")
            return None

        logger.info(f"\n{'='*80}")
        logger.info(f"Resuming thread: {self.current_thread_id}")
        logger.info(f"User input: {user_input}")
        logger.info(f"{'='*80}")

        try:
            result = self.workflow_tool.execute(
                thread_id=self.current_thread_id,
                user_message=user_input,
                initial_context=initial_context
            )

            logger.info(f"\nWorkflow result: {result[:100]}...")
            return self._handle_result(result)

        except Exception as e:
            logger.error(f"✗ Error resuming workflow: {e}", exc_info=True)
            return None

    def _handle_result(self, result: str) -> dict:
        """Parse and handle workflow result"""
        if InterruptType.USER_INPUT in result:
            parts = result.split("|")
            if len(parts) >= 4:
                thread_id = parts[1]
                workflow_name = parts[2]
                prompt = "|".join(parts[3:])

                logger.info(f"\n{'─'*80}")
                logger.info("WORKFLOW INTERRUPTED - Waiting for user input")
                logger.info(f"{'─'*80}")
                logger.info(f"Thread ID: {thread_id}")
                logger.debug(f"Prompt: {prompt}")

                return {
                    "type": "interrupt",
                    "thread_id": thread_id,
                    "workflow_name": workflow_name,
                    "prompt": prompt,
                    "needs_input": True
                }

        elif InterruptType.ASYNC in result:
            parts = result.split("|")
            if len(parts) >= 4:
                thread_id = parts[1]
                workflow_name = parts[2]
                metadata = parts[3]

                logger.info(f"\n{'─'*80}")
                logger.info("ASYNC OPERATION PENDING")
                logger.info(f"{'─'*80}")
                logger.info(f"Thread ID: {thread_id}")
                logger.info(f"Metadata: {metadata}")

                return {
                    "type": "async",
                    "thread_id": thread_id,
                    "workflow_name": workflow_name,
                    "metadata": metadata,
                    "needs_input": False
                }

        else:
            logger.info(f"\n{'='*80}")
            logger.info("WORKFLOW COMPLETED")
            logger.info(f"{'='*80}")
            logger.info(f"Final message: {result}")

            return {
                "type": "completed",
                "message": result,
                "needs_input": False
            }

    def interactive_session(self, initial_context: Optional[dict] = None):
        """
        Run an interactive CLI session

        Args:
            initial_context: Optional pre-populated context
        """
        initial_context = initial_context or {}

        workflow_name = self.workflow_config.get('name', 'Workflow')
        workflow_desc = self.workflow_config.get('description', '')

        print("\n" + "=" * 80)
        print(f"🔧 {workflow_name.upper()} - Interactive Session")
        if workflow_desc:
            print(f"   {workflow_desc}")
        print("=" * 80)
        print("Type 'quit' or 'exit' to end the session")
        if initial_context:
            print(f"Pre-populated fields: {', '.join(initial_context.keys())}")
        if self.mfa_enabled:
            print("⚠️  This workflow includes MFA-protected steps")
        print("=" * 80 + "\n")

        # Start workflow
        result = self.start_workflow(initial_context=initial_context)

        if not result:
            print("\n✗ Failed to start workflow")
            return

        # Interactive loop
        while result and result.get("needs_input"):
            prompt = result.get("prompt")
            if prompt:
                print(f"\n🤖 Bot: {prompt}")

            try:
                user_input = input("\n👤 You: ").strip()

                if user_input.lower() in ['quit', 'exit']:
                    print("\nExiting workflow session...")
                    logger.info("User exited session")
                    break

                if not user_input:
                    print("⚠️  Please provide valid input")
                    continue

                result = self.resume_with_input(user_input, initial_context)

            except KeyboardInterrupt:
                print("\n\nSession interrupted by user")
                logger.info("Session interrupted by user (Ctrl+C)")
                break
            except EOFError:
                print("\n\nEnd of input")
                logger.info("End of input (EOF)")
                break

        # Show final result
        if result and result.get("type") == "completed":
            print("\n" + "=" * 80)
            print("✓ WORKFLOW COMPLETE")
            print("=" * 80)
            print(f"\n{result['message']}")
            print("\n" + "=" * 80)


def check_ollama() -> bool:
    """Check if Ollama server is running"""
    try:
        result = subprocess.run(
            ["curl", "-s", "http://localhost:11434/api/tags"],
            capture_output=True,
            timeout=5
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def setup_provider(provider: str, model_name: Optional[str] = None):
    """Set up and validate the model provider"""
    if provider == "openai":
        if not os.getenv("OPENAI_API_KEY"):
            print("\n⚠️  OPENAI_API_KEY is not set")
            api_key = input("Enter your OpenAI API key (or press Enter to skip): ").strip()
            if api_key:
                os.environ["OPENAI_API_KEY"] = api_key
            else:
                print("✗ API key is required for OpenAI")
                return False
        print("✓ OPENAI_API_KEY is set")
        return True

    elif provider == "ollama":
        if not check_ollama():
            print("\n✗ Ollama is not running")
            print("Please start Ollama with: ollama serve")
            return False
        print("✓ Ollama is running")

        # Check if model exists
        if model_name:
            try:
                result = subprocess.run(
                    ["ollama", "list"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if model_name not in result.stdout:
                    print(f"\n⚠️  Model '{model_name}' not found")
                    pull = input(f"Pull model '{model_name}'? (y/n): ").strip().lower()
                    if pull == 'y':
                        print(f"Pulling {model_name}...")
                        subprocess.run(["ollama", "pull", model_name], check=True)
                    else:
                        return False
            except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.CalledProcessError):
                print("✗ Failed to check/pull Ollama model")
                return False
        return True

    elif provider == "bedrock":
        has_bearer = bool(os.getenv("AWS_BEARER_TOKEN_BEDROCK"))
        has_iam = bool(os.getenv("AWS_ACCESS_KEY_ID"))
        if not has_bearer and not has_iam:
            print("\n✗ No AWS credentials found for Bedrock")
            print("Set one of:")
            print("  export AWS_BEARER_TOKEN_BEDROCK=your-token")
            print("  export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=...")
            return False
        auth_method = "bearer token" if has_bearer else "IAM credentials"
        print(f"✓ AWS Bedrock auth configured ({auth_method})")
        if not os.getenv("AWS_REGION_NAME"):
            print("⚠️  AWS_REGION_NAME not set, defaulting to boto3 default region")
        return True

    return True


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Generic Workflow Runner - Run any YAML workflow definition"
    )
    parser.add_argument(
        "yaml_path",
        type=str,
        help="Path to the workflow YAML file"
    )
    parser.add_argument(
        "--provider",
        choices=["openai", "ollama", "bedrock"],
        default=os.getenv("MODEL_PROVIDER", "openai"),
        help="Model provider to use (default: openai, or set MODEL_PROVIDER env var)"
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model name to use (defaults: openai=gpt-4o-mini, ollama=llama3.2, bedrock=openai.gpt-oss-120b-1:0, or set MODEL_NAME env var)"
    )
    parser.add_argument(
        "--context",
        type=str,
        default=None,
        help='Initial context as JSON string, e.g. \'{"customer_name": "John"}\''
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help='Additional configuration as JSON string'
    )

    args = parser.parse_args()

    # Validate YAML path
    if not os.path.exists(args.yaml_path):
        print(f"✗ Error: YAML file not found: {args.yaml_path}")
        sys.exit(1)

    # Parse initial context
    initial_context = None
    if args.context:
        try:
            initial_context = json.loads(args.context)
            if not isinstance(initial_context, dict):
                print("Error: --context must be a JSON object")
                sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in --context: {e}")
            sys.exit(1)

    # Parse additional config
    config = None
    if args.config:
        try:
            config = json.loads(args.config)
            if not isinstance(config, dict):
                print("Error: --config must be a JSON object")
                sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in --config: {e}")
            sys.exit(1)

    # Get model name
    model_name = args.model or os.getenv("MODEL_NAME")

    # Setup provider
    if not setup_provider(args.provider, model_name):
        sys.exit(1)

    # Display configuration
    print(f"\n{'='*80}")
    print("Configuration:")
    print(f"  YAML: {args.yaml_path}")
    print(f"  Provider: {args.provider}")
    print(f"  Model: {model_name or f'default for {args.provider}'}")
    if args.provider == "ollama":
        ollama_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        print(f"  Ollama URL: {ollama_url}")
    if initial_context:
        print(f"  Initial Context: {list(initial_context.keys())}")
    print(f"{'='*80}\n")

    # Create and run workflow
    try:
        runner = WorkflowRunner(
            yaml_path=args.yaml_path,
            provider=args.provider,
            model_name=model_name,
            config=config
        )
        runner.interactive_session(initial_context=initial_context)
    except Exception as e:
        logger.error(f"✗ Error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
