## Tasks

### Mandatory
- Github Actions
- Tests
- Structure Outputs
- Tools
- Conversation History
- Field Validations
- Validate pre-populate fields in state
- State population audit

### Good to have
- Rollback
- call_function unexpected result
- Transitive dependencies
- Cancel a workflow
- Replaying state

### Priority
- Fork and Join
- Collect multiple items
- Re-usable workflows
- 