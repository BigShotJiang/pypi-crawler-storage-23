#!/usr/bin/env python3
"""
Automated MFA Test Scenarios

Runs the 5 test scenarios:
1. Positive case - capture valid OTP
2. Invalid OTP retry with valid OTP within max attempts
3. Invalid OTP, resend, then valid OTP
4. Invalid OTP, resend multiple times
5. MFA skip logic - multiple MFA steps in workflow

Prerequisites:
- Mock MFA server running at http://localhost:3000
- Valid OTP: 123456
- Invalid OTP: any other value

Environment Variables (optional):
- MFA_VALIDATION_ERROR_MESSAGE: Custom message for invalid OTP
- MAX_ATTEMPTS_MESSAGE: Custom message when max attempts reached
"""

import os
import sys
import uuid
from langgraph.checkpoint.memory import MemorySaver

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# Add examples directory to path for mfa_functions module
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'examples'))

from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import MFAConfig, InterruptType


def create_mfa_config() -> MFAConfig:
    """Create MFA configuration for testing"""
    base_url = os.getenv("MFA_BASE_URL", "http://localhost:3000")

    # Set environment variables for Pydantic BaseSettings
    os.environ["GENERATE_TOKEN_BASE_URL"] = base_url
    os.environ["GENERATE_TOKEN_PATH"] = "/mfa/generate"
    os.environ["RESEND_TOKEN_BASE_URL"] = base_url
    os.environ["RESEND_TOKEN_PATH"] = "/mfa/resend"
    os.environ["VALIDATE_TOKEN_BASE_URL"] = base_url
    os.environ["VALIDATE_TOKEN_PATH"] = "/mfa/validate"
    os.environ["AUTHORIZE_TOKEN_BASE_URL"] = base_url
    os.environ["AUTHORIZE_TOKEN_PATH"] = "/mfa/authorize"
    os.environ["API_TIMEOUT"] = "30"

    # Optional: Configure custom MFA error messages
    # These can be overridden via environment variables or passed directly
    if not os.getenv("MFA_VALIDATION_ERROR_MESSAGE"):
        os.environ["MFA_VALIDATION_ERROR_MESSAGE"] = "Invalid OTP entered"
    if not os.getenv("MAX_ATTEMPTS_MESSAGE"):
        os.environ["MAX_ATTEMPTS_MESSAGE"] = "Maximum authentication attempts reached. Please try again later."

    return MFAConfig()


def get_model_config():
    """Get model configuration"""
    provider = os.getenv("MODEL_PROVIDER", "openai")
    model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")

    if provider == "ollama":
        return {
            "model_name": model_name,
            "base_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1"),
            "provider": "ollama",
            "api_key": "dummy"
        }
    else:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print("⚠️  OPENAI_API_KEY not set. Set MODEL_PROVIDER=ollama to use local model.")
            sys.exit(1)
        config = {
            "model_name": model_name,
            "provider": "openai",
            "api_key": api_key
        }
        if base_url := os.getenv("OPENAI_BASE_URL"):
            config["base_url"] = base_url
        return config


def create_workflow_tool():
    """Create and initialize workflow tool"""
    from pathlib import Path

    checkpointer = MemorySaver()
    mfa_config = create_mfa_config()
    model_config = get_model_config()

    # Get absolute path to workflow file (in examples directory)
    yaml_path = Path(__file__).parent.parent / "examples" / "mfa_workflow.yaml"

    return WorkflowTool(
        yaml_path=str(yaml_path),
        name="PaymentMFAWorkflow",
        description="Payment workflow with MFA authentication",
        checkpointer=checkpointer,
        config={"model_config": model_config},
        mfa_config=mfa_config
    )


def execute_interaction(workflow_tool, thread_id, user_input, step_name=""):
    """Execute a single interaction with the workflow"""
    result = workflow_tool.execute(thread_id=thread_id, user_message=user_input, initial_context={})

    if InterruptType.USER_INPUT in result:
        parts = result.split("|")
        if len(parts) >= 4:
            prompt = "|".join(parts[3:])
            print(f"  [{step_name}] Bot: {prompt}")
            return result, prompt
    else:
        print(f"  [{step_name}] Final: {result}")
        return result, None

    return result, None


def run_scenario_1_positive_case():
    """
    Scenario 1: Positive case - valid OTP on first try

    Flow:
    1. Enter customer ID
    2. Enter payment amount
    3. Enter valid OTP (123456)
    4. Success!
    """
    print("\n" + "="*80)
    print("SCENARIO 1: Positive Case - Valid OTP")
    print("="*80)

    try:
        workflow_tool = create_workflow_tool()
        thread_id = f"test_scenario_1_{uuid.uuid4().hex[:8]}"

        print(f"\n🆔 Thread ID: {thread_id}")

        # Start workflow with empty initial context
        result = workflow_tool.execute(thread_id=thread_id, initial_context={})
        parts = result.split("|")
        prompt = "|".join(parts[3:])
        print(f"  [START] Bot: {prompt}")

        # Step 1: Customer ID
        result, _ = execute_interaction(workflow_tool, thread_id, "CUST123456", "Customer ID")

        # Step 2: Payment amount
        result, _ = execute_interaction(workflow_tool, thread_id, "5000", "Amount")

        # Step 3: Valid OTP (assuming mock server accepts 123456)
        result, prompt = execute_interaction(workflow_tool, thread_id, "123456", "Valid OTP")

        if not prompt:  # Workflow completed
            print("\n✅ Scenario 1 PASSED: Valid OTP accepted, payment processed")
            return True
        else:
            print("\n❌ Scenario 1 FAILED: Workflow did not complete after valid OTP")
            return False

    except Exception as e:
        print(f"\n❌ Scenario 1 ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_scenario_2_max_attempts():
    """
    Scenario 2: Invalid OTP retry with valid OTP within max_attempts

    Flow:
    1. Enter customer ID
    2. Enter payment amount
    3. Enter invalid OTP (attempt 1/3) - should show validation error
    4. Enter invalid OTP (attempt 2/3) - continues prompting
    5. Enter valid OTP (attempt 3/3) - should succeed

    Total: 3 attempts (2 invalid + 1 valid = 3, which is max_attempts)

    This verifies that validation errors are shown and valid OTP
    succeeds when provided within the max_attempts limit.
    """
    print("\n" + "="*80)
    print("SCENARIO 2: Invalid OTP Retry Flow (2 Invalid + 1 Valid)")
    print("="*80)

    try:
        workflow_tool = create_workflow_tool()
        thread_id = f"test_scenario_2_{uuid.uuid4().hex[:8]}"

        print(f"\n🆔 Thread ID: {thread_id}")

        # Start workflow with empty initial context
        result = workflow_tool.execute(thread_id=thread_id, initial_context={})
        parts = result.split("|")
        prompt = "|".join(parts[3:])
        print(f"  [START] Bot: {prompt}")

        # Step 1: Customer ID
        result, _ = execute_interaction(workflow_tool, thread_id, "CUST999888", "Customer ID")

        # Step 2: Payment amount
        result, _ = execute_interaction(workflow_tool, thread_id, "10000", "Amount")

        # Attempt 1/3: Invalid OTP - should show validation error
        result, prompt = execute_interaction(workflow_tool, thread_id, "111abc", "Invalid OTP")

        if not prompt:
            print("\n❌ Scenario 2 FAILED: Workflow ended after first invalid OTP")
            return False

        # Verify validation error is shown (without showing attempt count)
        if "not correct" in prompt.lower() or "incorrect" in prompt.lower():
            print("  ✓ Validation error displayed")

        # Attempt 2/3: Another invalid OTP - workflow should continue prompting
        result, prompt = execute_interaction(workflow_tool, thread_id, "222def", "Invalid OTP")

        if not prompt:
            print("\n❌ Scenario 2 FAILED: Workflow ended after second invalid OTP")
            return False

        print("  ✓ Workflow continues prompting after invalid OTPs")

        # Attempt 3/3: Valid OTP - should succeed (within max_attempts=3)
        result, prompt = execute_interaction(workflow_tool, thread_id, "123456", "Valid OTP")

        if not prompt:  # Workflow completed
            if "success" in result.lower() or "payment" in result.lower():
                print("\n✅ Scenario 2 PASSED: Invalid OTPs show errors, valid OTP succeeds")
                return True
            else:
                print(f"\n❌ Scenario 2 FAILED: Workflow ended without success: {result}")
                return False
        else:
            print("\n❌ Scenario 2 FAILED: Valid OTP not accepted")
            return False

    except Exception as e:
        print(f"\n❌ Scenario 2 ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_scenario_3_resend_then_valid():
    """
    Scenario 3: Invalid OTP, resend, then valid OTP

    Flow:
    1. Enter customer ID
    2. Enter payment amount
    3. Enter invalid OTP (attempt 1)
    4. Type "resend" (should NOT count as attempt)
    5. Enter valid OTP -> success

    Verifies: Resend doesn't count as validation attempt
    """
    print("\n" + "="*80)
    print("SCENARIO 3: Resend Flow - Invalid OTP, Resend, Valid OTP")
    print("="*80)

    try:
        workflow_tool = create_workflow_tool()
        thread_id = f"test_scenario_3_{uuid.uuid4().hex[:8]}"

        print(f"\n🆔 Thread ID: {thread_id}")

        # Start workflow with empty initial context
        result = workflow_tool.execute(thread_id=thread_id, initial_context={})
        parts = result.split("|")
        prompt = "|".join(parts[3:])
        print(f"  [START] Bot: {prompt}")

        # Step 1: Customer ID
        result, _ = execute_interaction(workflow_tool, thread_id, "CUST555777", "Customer ID")

        # Step 2: Payment amount
        result, _ = execute_interaction(workflow_tool, thread_id, "15000", "Amount")

        # Step 3: Invalid OTP (attempt 1)
        result, prompt = execute_interaction(workflow_tool, thread_id, "999xyz", "Invalid OTP")

        if not prompt:
            print("\n❌ Scenario 3 FAILED: Workflow ended after 1 invalid OTP")
            return False

        # Step 4: Resend (should NOT count as attempt)
        result, prompt = execute_interaction(workflow_tool, thread_id, "resend", "Resend Request")

        if not prompt:
            print("\n❌ Scenario 3 FAILED: Workflow ended after resend")
            return False

        if "sent" in prompt.lower() or "new" in prompt.lower():
            print("  ✓ Resend successful - new OTP message received")

        # Step 5: Valid OTP
        result, prompt = execute_interaction(workflow_tool, thread_id, "123456", "Valid OTP")

        if not prompt:  # Workflow completed
            print("\n✅ Scenario 3 PASSED: Resend + valid OTP = success (resend didn't count as attempt)")
            return True
        else:
            print("\n❌ Scenario 3 FAILED: Workflow did not complete after valid OTP")
            return False

    except Exception as e:
        print(f"\n❌ Scenario 3 ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_scenario_4_multiple_resends():
    """
    Scenario 4: Invalid OTP + resend repeatedly for 3 times

    Flow:
    1. Enter customer ID
    2. Enter payment amount
    3. Invalid OTP (attempt 1)
    4. Resend (not counted)
    5. Invalid OTP (attempt 2)
    6. Resend (not counted)
    7. Invalid OTP (attempt 3)
    8. Max attempts reached

    Verifies: Multiple resends don't count, but invalid OTPs do
    """
    print("\n" + "="*80)
    print("SCENARIO 4: Multiple Resends - Invalid OTP + Resend x3")
    print("="*80)

    try:
        workflow_tool = create_workflow_tool()
        thread_id = f"test_scenario_4_{uuid.uuid4().hex[:8]}"

        print(f"\n🆔 Thread ID: {thread_id}")

        # Start workflow with empty initial context
        result = workflow_tool.execute(thread_id=thread_id, initial_context={})
        parts = result.split("|")
        prompt = "|".join(parts[3:])
        print(f"  [START] Bot: {prompt}")

        # Step 1: Customer ID
        result, _ = execute_interaction(workflow_tool, thread_id, "CUST111222", "Customer ID")

        # Step 2: Payment amount
        result, _ = execute_interaction(workflow_tool, thread_id, "25000", "Amount")

        # Repeat: Invalid OTP -> Resend (3 times)
        for cycle in range(1, 4):
            print(f"\n  --- Cycle {cycle} ---")

            # Invalid OTP (format: numbers then letters for better LLM extraction)
            invalid_otps = ["111aaa", "222bbb", "333ccc"]
            result, prompt = execute_interaction(
                workflow_tool, thread_id, invalid_otps[cycle - 1], f"Invalid OTP #{cycle}"
            )

            if not prompt:
                if "max" in result.lower() or "attempt" in result.lower():
                    print(f"\n✅ Scenario 4 PASSED: Max attempts after {cycle} invalid OTPs (resends didn't count)")
                    return True
                else:
                    print(f"\n❌ Scenario 4 FAILED: Unexpected termination: {result}")
                    return False

            # Resend (if not last cycle)
            if cycle < 3:
                result, prompt = execute_interaction(
                    workflow_tool, thread_id, "resend", f"Resend #{cycle}"
                )

                if not prompt:
                    print(f"\n❌ Scenario 4 FAILED: Workflow ended after resend #{cycle}")
                    return False

        print("\n❌ Scenario 4 FAILED: Should have hit max attempts after 3 invalid OTPs")
        return False

    except Exception as e:
        print(f"\n❌ Scenario 4 ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_scenario_5_mfa_skip_logic():
    """
    Scenario 5: MFA Skip Logic - Multiple MFA steps in workflow

    Flow:
    1. Enter customer ID
    2. Enter payment amount
    3. Complete FIRST MFA (authenticate_payment) with valid OTP
    4. Payment processes successfully
    5. SECOND MFA (authenticate_confirmation) should AUTO-SKIP
    6. Confirmation generated and workflow completes

    Verifies: When first MFA completes, subsequent MFA steps skip automatically
    """
    print("\n" + "="*80)
    print("SCENARIO 5: MFA Skip Logic - Multiple MFA Steps")
    print("="*80)

    try:
        from pathlib import Path

        # Use workflow with multiple MFA steps
        yaml_path = Path(__file__).parent.parent / "examples" / "mfa_workflow_multi.yaml"

        checkpointer = MemorySaver()
        mfa_config = create_mfa_config()
        model_config = get_model_config()

        workflow_tool = WorkflowTool(
            yaml_path=str(yaml_path),
            name="MultiMFAWorkflow",
            description="Payment workflow with multiple MFA steps",
            checkpointer=checkpointer,
            config={"model_config": model_config},
            mfa_config=mfa_config
        )

        thread_id = f"test_scenario_5_{uuid.uuid4().hex[:8]}"

        print(f"\n🆔 Thread ID: {thread_id}")
        print("Expected: First MFA completes → Second MFA auto-skips")

        # Start workflow
        result = workflow_tool.execute(thread_id=thread_id, initial_context={})
        parts = result.split("|")
        prompt = "|".join(parts[3:])
        print(f"  [START] Bot: {prompt}")

        # Step 1: Customer ID
        result, _ = execute_interaction(workflow_tool, thread_id, "CUST777888", "Customer ID")

        # Step 2: Payment amount
        result, _ = execute_interaction(workflow_tool, thread_id, "20000", "Amount")

        # Step 3: First MFA - Enter valid OTP
        print("\n  → First MFA: authenticate_payment")
        result, prompt = execute_interaction(workflow_tool, thread_id, "123456", "Valid OTP (MFA #1)")

        # After first MFA with valid OTP, payment should process
        # and second MFA should auto-skip (no OTP prompt)
        if not prompt:  # Workflow completed
            if "success" in result.lower() or "payment" in result.lower():
                print("  ✓ First MFA completed successfully")
                print("  ✓ Second MFA auto-skipped (no prompt)")
                print("  ✓ Workflow completed")
                print("\n✅ Scenario 5 PASSED: Second MFA skipped after first MFA completion")
                return True
            else:
                print(f"\n❌ Scenario 5 FAILED: Unexpected completion: {result}")
                return False
        else:
            # If we get another prompt, check if it's asking for OTP again
            if "otp" in prompt.lower() or "enter" in prompt.lower():
                print("\n❌ Scenario 5 FAILED: Second MFA did NOT skip - prompted for OTP again")
                print(f"   Prompt: {prompt}")
                return False
            else:
                # Might be asking for something else, continue
                print(f"  [Unexpected] Bot: {prompt}")
                print("\n❌ Scenario 5 FAILED: Unexpected workflow state")
                return False

    except Exception as e:
        print(f"\n❌ Scenario 5 ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all test scenarios"""
    print("\n" + "="*80)
    print("🔐 MFA AUTOMATED TEST SCENARIOS")
    print("="*80)
    print("\nPrerequisites:")
    print("  ✓ Mock MFA server running at http://localhost:3000")
    print("  ✓ Valid OTP: 123456")
    print("  ✓ Invalid OTP: any other value")
    print("="*80)

    # Check MFA server
    base_url = os.getenv("MFA_BASE_URL", "http://localhost:3000")
    print(f"\n🔗 MFA Base URL: {base_url}")

    response = input("\nIs the mock MFA server running? (y/n): ").strip().lower()
    if response != 'y':
        print("\n❌ Please start the mock MFA server first!")
        print("Then run: python test_mfa_e_2_e.py")
        return

    results = {}

    # Run all scenarios
    results['scenario_1'] = run_scenario_1_positive_case()
    results['scenario_2'] = run_scenario_2_max_attempts()
    results['scenario_3'] = run_scenario_3_resend_then_valid()
    results['scenario_4'] = run_scenario_4_multiple_resends()
    results['scenario_5'] = run_scenario_5_mfa_skip_logic()

    # Summary
    print("\n" + "="*80)
    print("📊 TEST SUMMARY")
    print("="*80)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for scenario, result in results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"  {scenario}: {status}")

    print(f"\nTotal: {passed}/{total} scenarios passed")
    print("="*80 + "\n")

    return passed == total


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
