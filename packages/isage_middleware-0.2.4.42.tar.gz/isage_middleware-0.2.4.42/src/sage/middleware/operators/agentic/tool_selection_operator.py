"""
Tool Selection Operator

Middleware operator for tool selection using runtime components.

Supports engine_type switching:
- sagellm (default): SageLLMGenerator via single inference service port
- openai: OpenAIGenerator for OpenAI-compatible APIs
- hf: HFGenerator for HuggingFace models
"""

from typing import Any

from sage.common.core.functions import MapFunction

from .runtime import _build_generator


class ToolSelectionOperator(MapFunction):
    """
    Operator for tool selection.

    Wraps runtime tool selector in a middleware operator interface.

    Args:
        selector: Tool selector instance (optional)
        config: Configuration dictionary with optional keys:
            - selector: Selector-specific config (e.g., top_k)
            - generator: Generator config with engine_type
            - engine_type: Shorthand for generator.engine_type (sagellm/openai/hf)

    Example:
        ```python
        # Using sagellm service-port mode
        operator = ToolSelectionOperator(config={
            "generator": {
                "engine_type": "sagellm",
                "model_path": "Qwen/Qwen2.5-7B-Instruct",
            },
            "selector": {"top_k": 5},
        })

        # Using default sagellm mode
        operator = ToolSelectionOperator(config={
            "engine_type": "sagellm",
        })
        ```
    """

    def __init__(
        self,
        selector: Any | None = None,
        config: dict[str, Any] | None = None,
    ):
        """Initialize tool selection operator.

        Args:
            selector: Tool selector instance (optional)
            config: Configuration dictionary
        """
        super().__init__()

        # Parse configuration
        if config is None:
            config = {}

        self.config = config

        # Build generator if config provided
        generator_conf = config.get("generator", {})
        # Allow shorthand engine_type at top level
        if "engine_type" in config and "engine_type" not in generator_conf:
            generator_conf["engine_type"] = config["engine_type"]

        # Build generator (defaults to sagellm service-port mode)
        if generator_conf or not selector:
            engine_type = generator_conf.get("engine_type", "sagellm")
            # Ensure we have at least minimal config
            if not generator_conf:
                generator_conf = {"engine_type": "sagellm"}
            self.generator = _build_generator(generator_conf, engine_type=engine_type)
        else:
            self.generator = None

        try:
            from sage_libs.sage_agentic.agents.runtime import (
                BenchmarkAdapter,
                Orchestrator,
                RuntimeConfig,
            )
            from sage_libs.sage_agentic.agents.runtime.config import SelectorConfig
        except ImportError as exc:
            raise ImportError(
                "ToolSelectionOperator requires 'isage-agentic'. "
                "Install it with: pip install isage-agentic"
            ) from exc
        selector_config = SelectorConfig(**config.get("selector", {}))
        runtime_config = RuntimeConfig(selector=selector_config)

        # Create orchestrator
        self.orchestrator = Orchestrator(config=runtime_config, selector=selector)

        # Create adapter for easy use
        self.adapter = BenchmarkAdapter(self.orchestrator)

    def __call__(self, query: Any) -> list[Any]:
        """Execute tool selection.

        Args:
            query: Tool selection query

        Returns:
            List of selected tools
        """
        top_k = self.config.get("selector", {}).get("top_k", 5)
        return self.adapter.run_tool_selection(query, top_k=top_k)

    def execute(self, data: Any) -> list[Any]:
        """Execute map function interface."""
        return self.__call__(data)

    def get_metrics(self) -> dict[str, Any]:
        """Get performance metrics.

        Returns:
            Dictionary of metrics
        """
        return self.adapter.get_metrics()
