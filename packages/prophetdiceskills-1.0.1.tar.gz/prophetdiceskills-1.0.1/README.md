# 🔮 Prophet Dice Skills

<p align="center">
  <img src="https://img.shields.io/badge/python-3.6+-blue.svg" alt="Python Version">
  <img src="https://img.shields.io/badge/CUDA-Enabled-green.svg" alt="CUDA Enabled">
  <img src="https://img.shields.io/badge/PyTorch-Supported-ee4c2c.svg" alt="PyTorch Supported">
  <img src="https://img.shields.io/badge/License-MIT-purple.svg" alt="License">
</p>

**Prophet Dice Skills** is an advanced, cryptographically-aware, Machine Learning-enhanced framework designed for analyzing, simulating, and exploiting Provably Fair RNG systems (specifically modeled after the popular HMAC-SHA256 implementations used in online casinos like Stake).

It goes beyond standard statistics by treating RNG sequences as time-series datasets, deploying deep learning, real-time streaming AI, anomaly detection, and massively parallel GPU seed cracking algorithms.

---

## 🚀 Key Features

### 🧠 Groundbreaking AI Predictor Ensemble
*   **Time-Series Transformer (PyTorch)**: Deciphers micro-patterns using Multi-Head Attention to forecast non-linear deterministic RNG flaws.
*   **True Online Learning (`river`)**: Adaptive Random Forests and Hoeffding Trees stream process results roll-by-roll to adapt instantly without batch retraining.
*   **Meta-Learning Evolutionary Optimizer**: Self-evolves and genetically mutates your prediction ensemble weights based on live accuracy, storing the "fittest" models automatically.
*   **Signal Processing Pipelines**: Employs rigorous Kalman Filtering bounds and Hurst Exponent regime detection to filter noise and identify chaotic/trending moments.

### 🛡️ Real-Time Integrity & Anomaly Detection
*   **RNG Anomaly Detector**: Deploys an Isolation Forest across a rolling 100-roll window. It continuously monitors the cryptographic fingerprint of your session and fires an `ANOMALY` breaker if the casino's RNG server silently alters behavior, aggressively slashing betting confidence.

### 💰 "Anti-Human" Advanced Betting System
*   **Burst Strategy Engine**: Configurable, multi-tiered (Conservative, Balanced, Aggressive) capital allocator.
*   **Circuit Breakers**: Automatically detects variance clusters and cuts off trading until system conditions normalize.
*   **Config Manager**: Stores bankroll parameters effortlessly on disk (`auditor_config.json`).

### ⚡ CUDA-Accelerated Cryptanalysis 
*   **Massive Time-Crack Sweeps**: Given a target timestamp and observed nonces, uses NVIDIA GPUs via `numba.cuda` to brute-force solve the HMAC-SHA256 Server Seed space in milliseconds.
*   **Collision Farming Matrix**: Analyzes deterministic hashing structures to reverse-engineer sequential Nonce targets.

---

## 📦 Installation

```bash
pip install prophetdiceskills
```

*Note: For Deep Learning and GPU Cracking, ensure you have an NVIDIA GPU, CUDA Toolkit installed, and PyTorch dynamically linked (`pip install torch`).*

---

## 📖 Quickstart Guide

### 1. Basic Machine Learning Prediction

```python
from prophetdiceskills import GroundbreakingPredictor

# Initialize the Ensemble AI Predictor
predictor = GroundbreakingPredictor()

# Inject some actual history from your casino session...
history_rolls = [45.1, 99.2, 12.5, 66.8, 50.1]
for i, roll in enumerate(history_rolls):
    predictor.add(roll, identifier="my_seed", nonce=i+1)

# Request a prediction for the immediate next roll
pred = predictor.predict(current_identifier="my_seed", current_nonce=6)

if pred:
    print(f"Target: {pred['prediction']:.2f}")
    print(f"Confidence: {pred['confidence']:.2f}%")
    print(f"RNG Integrity: {pred['rng_integrity']}")
```

### 2. Auto-Updating Dashboard / Benchmarking

Test the library entirely offline without risking funds by importing the `benchmark.py` testing suite:

```bash
# This will spawn a dashboard via Matplotlib predicting 5,000 mathematically valid offline rolls.
python -m prophetdiceskills.benchmark --rolls 5000 --plot 
```

### 3. GPU Server Seed Brute Forcing

Requires an active NVIDIA CUDA grid. Attempt to find the casino's secret hash if you know roughly when a seed was issued and have some outcomes:

```python
from prophetdiceskills import aggressive_time_crack

# Searches 10 seconds of unix-time space per millisecond (40 million permutations max)
seed = aggressive_time_crack(
    client_seed="my_client_seed",
    target_timestamp_ms=1600000000000,
    target_outcomes=[45.10, 99.20, 12.05],
    start_nonce=1,
    variance_sec=10 
)
```

---

## 📚 Advanced Documentation

For detailed analysis of the individual components, architecture designs, and configuration tweaks, please view the `/docs/` repository files.  

*   [docs/ml.md] - In-depth guide on the Transformer, River Integration, and Isolation Forest.
*   [docs/bot.md] - Configuration flags for Risk Levels, Stop Loss, and Burst Modifiers.
*   [docs/core.md] - Detailed structure of the Provably Fair SHA256 Engine and Numba Kernels.

---

## ⚠️ Disclaimer

This library is primarily intended for **educational research**, penetration testing of cryptographic systems, and statistical AI analysis. Gambling mathematically guarantees a loss over infinite time due to server edges (e.g. 1% House Edge). The predictions provided by models inside this library attempt to isolate temporary anomalies in pseudo-random distributions, but **cannot guarantee profit**. 

Use strictly at your own financial risk.
