class ProphetBot:
    """A standard bot framework with typical dice bot functions."""
    def __init__(self, initial_balance=1000.0):
        self._balance = initial_balance
        self._wager = 0.0
        self._condition = "<"
        self._target = 50.0
        self._win = False
        self._current_streak = 0
        self._last_result = 0.0
        self._profit = 0.0
        
    def getbalance(self):
        """Returns the current balance."""
        return self._balance
        
    def setwager(self, amount):
        """Sets the current wager."""
        self._wager = amount
        
    def setcondition(self, condition):
        """Sets the win condition ('<' or '>')."""
        self._condition = condition
        
    def settarget(self, target):
        """Sets the target outcome (multiplier or chance)."""
        self._target = target
        
    def getresult(self):
        """Returns the result of the last roll."""
        return self._last_result
        
    def simulate_roll(self, result):
        """Simulates an incoming roll result from the casino."""
        self._last_result = result
        if self._condition == "<":
            self._win = result < self._target
        elif self._condition == ">":
            self._win = result > self._target
            
        if self._win:
            # Simple assumption: 99% RTP
            multiplier = 99.0 / self._target if self._target > 0 else 2.0
            payout = self._wager * multiplier
            self._profit += (payout - self._wager)
            self._balance += (payout - self._wager)
            self._current_streak = self._current_streak + 1 if self._current_streak > 0 else 1
        else:
            self._profit -= self._wager
            self._balance -= self._wager
            self._current_streak = self._current_streak - 1 if self._current_streak < 0 else -1
            
        return self._win
        
    def getprofit(self):
        return self._profit
        
    def is_win(self):
        return self._win
        
    def getstreak(self):
        return self._current_streak
