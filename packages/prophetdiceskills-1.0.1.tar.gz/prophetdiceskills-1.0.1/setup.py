from setuptools import setup, find_packages

setup(
    name="prophetdiceskills",
    version="1.0.1",
    author="Prophet Dice Skills",
    author_email="prophet@example.com",
    description="A library converting RNG cracking algorithms into callable functions with bot emulation.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numba",
        "numpy",
        "scipy",
        "scikit-learn",
        "PyWavelets",
        "matplotlib",
        "seaborn",
        "river",
        "torch"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
