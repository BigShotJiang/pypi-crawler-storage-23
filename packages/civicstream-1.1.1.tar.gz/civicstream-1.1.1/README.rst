CivicStream
===========

This package provides a command-line tool for capturing and visualizing streaming data
from a CivicAlert sensor device. It can be accessed from a command terminal by entering:

``civicstream``

Enter ``civicstream -h`` to see a listing of available command line parameters, including
activation of an IMU visualizer or configuration of the number of incoming audio channels.
