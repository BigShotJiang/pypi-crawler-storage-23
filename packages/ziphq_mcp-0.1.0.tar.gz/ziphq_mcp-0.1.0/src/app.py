"""Zip MCP application instance."""

from fastmcp import FastMCP

# Create the MCP server instance
mcp = FastMCP("ziphq-mcp")
