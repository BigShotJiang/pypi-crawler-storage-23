# UniShell

AI-powered code execution with natural language.

## Installation

```bash
pip install unishell-q
```

## How to Run

```bash
# Interactive mode
unishell

# With Azure OpenAI
unishell --model azure/gpt-4o --api_key YOUR_KEY --api_base YOUR_ENDPOINT --api_version 2024-08-01-preview

# With OpenAI
export OPENAI_API_KEY=your-key
unishell --model gpt-4o

# Auto-run (skip approval)
unishell -y
```

## How to Use

```bash
> create a file named test.txt in desktop
> lock my screen
> mute the volume
> open application for instance notepad
```

## Python API

```python
from unishell import unishell

unishell.llm.model = "gpt-4o"
unishell.llm.api_key = "your-key"
unishell.chat("Create a Python script")
```

**Version**: 0.4.1
