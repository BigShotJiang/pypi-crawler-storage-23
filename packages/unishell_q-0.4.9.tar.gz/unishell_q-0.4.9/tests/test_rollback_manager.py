"""Test rollback manager."""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from unishell.core.rollback import SimpleRollbackManager

print("=== Rollback Manager Tests ===\n")

# Initialize
rollback_mgr = SimpleRollbackManager()

with tempfile.TemporaryDirectory() as tmpdir:
    tmpdir = Path(tmpdir)
    
    print("=== Test 1: Create Snapshot ===")
    test_file = tmpdir / "test.txt"
    test_file.write_text("Original content")
    
    snapshot = rollback_mgr.create_snapshot(
        "file.move",
        {"source": str(test_file), "destination": str(tmpdir / "moved.txt")}
    )
    print(f"Snapshot ID: {snapshot.snapshot_id}")
    print(f"Action: {snapshot.action_id}")
    print(f"State: {snapshot.state}")
    print(f"Committed: {snapshot.committed}")
    print()
    
    print("=== Test 2: Rollback Without Execution ===")
    result = rollback_mgr.rollback(snapshot.snapshot_id)
    print(f"Success: {result['success']}")
    print(f"Message: {result['message']}")
    print()
    
    print("=== Test 3: Execute Move and Rollback ===")
    # Simulate file move
    import shutil
    shutil.move(str(test_file), str(tmpdir / "moved.txt"))
    print(f"File moved: {test_file.exists()} -> {(tmpdir / 'moved.txt').exists()}")
    
    # Rollback
    result = rollback_mgr.rollback(snapshot.snapshot_id)
    print(f"Rollback Success: {result['success']}")
    print(f"Message: {result['message']}")
    print(f"File restored: {test_file.exists()}")
    print()
    
    print("=== Test 4: Commit Snapshot ===")
    test_file2 = tmpdir / "test2.txt"
    test_file2.write_text("Content 2")
    
    snapshot2 = rollback_mgr.create_snapshot(
        "file.move",
        {"source": str(test_file2), "destination": str(tmpdir / "moved2.txt")}
    )
    
    # Commit
    result = rollback_mgr.commit(snapshot2.snapshot_id)
    print(f"Commit Success: {result['success']}")
    print(f"Message: {result['message']}")
    
    # Try to rollback committed snapshot
    result = rollback_mgr.rollback(snapshot2.snapshot_id)
    print(f"Rollback after commit: {result['success']}")
    print(f"Message: {result['message']}")
    print()
    
    print("=== Test 5: List Snapshots ===")
    snapshots = rollback_mgr.list_snapshots()
    print(f"Total snapshots: {len(snapshots)}")
    for snap in snapshots:
        print(f"  - {snap.snapshot_id}: {snap.action_id} (committed: {snap.committed})")
    print()
    
    print("=== Test 6: Cleanup Committed ===")
    removed = rollback_mgr.cleanup_committed()
    print(f"Removed {removed} committed snapshots")
    print(f"Remaining: {len(rollback_mgr.list_snapshots())}")
    print()
    
    print("=== Test 7: Unsupported Action ===")
    snapshot3 = rollback_mgr.create_snapshot(
        "system.restart",
        {}
    )
    result = rollback_mgr.rollback(snapshot3.snapshot_id)
    print(f"Success: {result['success']}")
    print(f"Message: {result['message']}")
    print()

print("[SUCCESS] Rollback manager tests complete!")
