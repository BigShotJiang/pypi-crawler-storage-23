"""Test intent classification and parameter extraction."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from unishell.core.intent import LLMIntentClassifier, LLMParameterExtractor

print("=== Intent Classification Tests ===\n")

# Initialize classifier (using sync mock for testing)
classifier = LLMIntentClassifier(llm_client=None, confidence_threshold=0.7)

# Test cases
test_inputs = [
    "Move file from /tmp/test.txt to /home/user/test.txt",
    "Delete the file at /var/log/old.log",
    "Restart the system now",
    "Ping google.com",
    "Do something unclear"
]

for user_input in test_inputs:
    result = classifier.classify_sync(user_input)
    print(f"Input: {user_input}")
    print(f"  Action ID: {result.action_id}")
    print(f"  Confidence: {result.confidence}")
    print(f"  Needs Clarification: {result.needs_clarification}")
    print(f"  Reasoning: {result.reasoning}")
    print()

print("\n=== Parameter Extraction Tests ===\n")

# Initialize extractor (using sync mock for testing)
extractor = LLMParameterExtractor(llm_client=None, confidence_threshold=0.7)

# Test cases with required params
test_cases = [
    {
        "input": "Move file from /tmp/test.txt to /home/user/test.txt",
        "action_id": "file.move",
        "required_params": ["source", "destination"]
    },
    {
        "input": "Delete the file at /var/log/old.log",
        "action_id": "file.delete",
        "required_params": ["path"]
    },
    {
        "input": "Ping google.com",
        "action_id": "network.ping",
        "required_params": ["host"]
    },
    {
        "input": "Move something somewhere",
        "action_id": "file.move",
        "required_params": ["source", "destination"]
    }
]

for test in test_cases:
    result = extractor.extract_sync(
        test["input"],
        test["action_id"],
        test["required_params"]
    )
    print(f"Input: {test['input']}")
    print(f"  Action: {test['action_id']}")
    print(f"  Parameters: {result.parameters}")
    print(f"  Missing: {result.missing_fields}")
    print(f"  Confidence: {result.confidence}")
    print()

print("\n=== Combined Workflow Test ===\n")

# Simulate full workflow
user_input = "Move file from /tmp/data.csv to /backup/data.csv"

# Step 1: Classify intent
intent_result = classifier.classify_sync(user_input)
print(f"1. Classification:")
print(f"   Input: {user_input}")
print(f"   Action ID: {intent_result.action_id}")
print(f"   Confidence: {intent_result.confidence}")

if intent_result.needs_clarification:
    print(f"   [STOP] Needs clarification: {intent_result.reasoning}")
else:
    print(f"   [OK] Proceeding to parameter extraction\n")
    
    # Step 2: Extract parameters
    param_result = extractor.extract_sync(
        user_input,
        intent_result.action_id,
        ["source", "destination"]
    )
    
    print(f"2. Parameter Extraction:")
    print(f"   Parameters: {param_result.parameters}")
    print(f"   Missing: {param_result.missing_fields}")
    print(f"   Confidence: {param_result.confidence}")
    
    if param_result.missing_fields:
        print(f"   [STOP] Missing required fields: {param_result.missing_fields}")
    else:
        print(f"   [OK] All parameters extracted")
        print(f"\n3. Ready for execution:")
        print(f"   Action: {intent_result.action_id}")
        print(f"   Params: {param_result.parameters}")

print("\n[SUCCESS] Intent classification layer tests complete!")
