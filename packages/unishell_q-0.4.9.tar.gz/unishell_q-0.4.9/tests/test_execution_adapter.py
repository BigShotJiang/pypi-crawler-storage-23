"""Test safe OS execution adapter."""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from unishell.core.execution import SafeOSExecutionAdapter
from unishell.core.models import ExecutionResult

print("=== Safe OS Execution Adapter Tests ===\n")

# Initialize adapter
adapter = SafeOSExecutionAdapter()

# Create temp directory for testing
with tempfile.TemporaryDirectory() as tmpdir:
    tmpdir = Path(tmpdir)
    
    # Create test files
    test_file1 = tmpdir / "test1.txt"
    test_file1.write_text("Test content 1")
    
    test_file2 = tmpdir / "test2.txt"
    test_file2.write_text("Test content 2")
    
    print("=== Test 1: Move File (Dry Run) ===")
    result = adapter.move_file(
        str(test_file1),
        str(tmpdir / "moved.txt"),
        dry_run=True
    )
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print(f"Dry Run: {result.dry_run}")
    print(f"Data: {result.data}")
    print(f"File still exists: {test_file1.exists()}")
    print()
    
    print("=== Test 2: Move File (Real) ===")
    result = adapter.move_file(
        str(test_file1),
        str(tmpdir / "moved.txt"),
        dry_run=False
    )
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print(f"Dry Run: {result.dry_run}")
    print(f"Original exists: {test_file1.exists()}")
    print(f"Moved exists: {(tmpdir / 'moved.txt').exists()}")
    print()
    
    print("=== Test 3: Delete File (Dry Run) ===")
    result = adapter.delete_file(str(test_file2), dry_run=True)
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print(f"Dry Run: {result.dry_run}")
    print(f"Data: {result.data}")
    print(f"File still exists: {test_file2.exists()}")
    print()
    
    print("=== Test 4: Delete File (Real) ===")
    result = adapter.delete_file(str(test_file2), dry_run=False)
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print(f"Dry Run: {result.dry_run}")
    print(f"File exists: {test_file2.exists()}")
    print()
    
    print("=== Test 5: Invalid Path (Path Traversal) ===")
    result = adapter.move_file("../../../etc/passwd", str(tmpdir / "bad.txt"))
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print()
    
    print("=== Test 6: Non-existent File ===")
    result = adapter.delete_file(str(tmpdir / "nonexistent.txt"))
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print()
    
    print("=== Test 7: Get File Info ===")
    info_file = tmpdir / "info.txt"
    info_file.write_text("Info test")
    result = adapter.get_file_info(str(info_file))
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print(f"Data: {result.data}")
    print()

print("=== Test 8: Restart System (Dry Run) ===")
result = adapter.restart_system(delay=10, dry_run=True)
print(f"Success: {result.success}")
print(f"Message: {result.message}")
print(f"Dry Run: {result.dry_run}")
print(f"Data: {result.data}")
print()

print("=== Test 9: Restart System (Real - Should Fail Safely) ===")
result = adapter.restart_system(delay=10, dry_run=False)
print(f"Success: {result.success}")
print(f"Message: {result.message}")
print(f"Metadata: {result.metadata}")
print()

print("=== Test 10: Restricted Paths ===")
# Create adapter with path restrictions
restricted_adapter = SafeOSExecutionAdapter(allowed_paths=[str(Path.home() / "Documents")])

with tempfile.TemporaryDirectory() as tmpdir2:
    tmpdir2 = Path(tmpdir2)
    test_file = tmpdir2 / "test.txt"
    test_file.write_text("Test")
    
    result = restricted_adapter.delete_file(str(test_file))
    print(f"Success: {result.success}")
    print(f"Message: {result.message}")
    print()

print("[SUCCESS] All execution adapter tests complete!")
