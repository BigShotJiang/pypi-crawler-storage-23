"""Task data model for gateway queue."""

from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime
from enum import Enum


class TaskStatus(str, Enum):
    """Task status states."""
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Task(BaseModel):
    """Task for distributed execution."""
    
    task_id: str = Field(..., description="Unique task identifier")
    user_input: str = Field(..., description="User's natural language input")
    device_id: Optional[str] = Field(None, description="Assigned device ID")
    status: TaskStatus = Field(default=TaskStatus.PENDING, description="Task status")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    assigned_at: Optional[datetime] = Field(None, description="Assignment timestamp")
    completed_at: Optional[datetime] = Field(None, description="Completion timestamp")
    result: Optional[Dict[str, Any]] = Field(None, description="Execution result")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
