"""Gateway orchestrator abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, AsyncIterator


class GatewayOrchestrator(ABC):
    """Abstract base class for orchestrating the complete execution pipeline."""

    @abstractmethod
    async def process(self, user_input: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process user input through complete pipeline.
        
        Args:
            user_input: Raw user input
            context: Request context
            
        Returns:
            Final execution result
        """
        pass

    @abstractmethod
    async def process_stream(self, user_input: str, context: Dict[str, Any]) -> AsyncIterator[Dict[str, Any]]:
        """Process user input with streaming results.
        
        Args:
            user_input: Raw user input
            context: Request context
            
        Yields:
            Execution result chunks
        """
        pass

    @abstractmethod
    async def health_check(self) -> Dict[str, bool]:
        """Check health of all pipeline components.
        
        Returns:
            Component health status dictionary
        """
        pass
