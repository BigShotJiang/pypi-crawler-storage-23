"""Action registry abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Callable, List


class ActionRegistry(ABC):
    """Abstract base class for action registration and retrieval."""

    @abstractmethod
    def register(self, intent: str, action: Callable, metadata: Dict[str, Any]) -> None:
        """Register an action for an intent.
        
        Args:
            intent: Intent identifier
            action: Callable action handler
            metadata: Action metadata
        """
        pass

    @abstractmethod
    def get_action(self, intent: str) -> Callable:
        """Get action handler for intent.
        
        Args:
            intent: Intent identifier
            
        Returns:
            Action handler callable
        """
        pass

    @abstractmethod
    def list_actions(self) -> List[str]:
        """List all registered intent identifiers.
        
        Returns:
            List of intent identifiers
        """
        pass

    @abstractmethod
    def get_metadata(self, intent: str) -> Dict[str, Any]:
        """Get metadata for registered action.
        
        Args:
            intent: Intent identifier
            
        Returns:
            Action metadata dictionary
        """
        pass
