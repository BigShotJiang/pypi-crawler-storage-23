"""Action schema definition using Pydantic."""

from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from enum import Enum


class PermissionLevel(str, Enum):
    """Permission levels for actions."""
    PUBLIC = "public"
    USER = "user"
    ADMIN = "admin"
    SYSTEM = "system"


class RiskLevel(str, Enum):
    """Risk levels for actions."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RollbackStrategy(str, Enum):
    """Rollback strategies."""
    NONE = "none"
    AUTOMATIC = "automatic"
    MANUAL = "manual"
    CHECKPOINT = "checkpoint"


class ExecutionConfig(BaseModel):
    """Execution configuration."""
    timeout: Optional[int] = None
    retry_count: int = 0
    requires_confirmation: bool = True


class ActionSchema(BaseModel):
    """Schema for action definition."""
    action_id: str = Field(..., description="Unique action identifier")
    category: str = Field(..., description="Action category")
    required_params: List[str] = Field(default_factory=list, description="Required parameters")
    optional_params: List[str] = Field(default_factory=list, description="Optional parameters")
    default_params: Dict[str, Any] = Field(default_factory=dict, description="Default parameter values")
    permission_level: PermissionLevel = Field(..., description="Required permission level")
    risk_level: RiskLevel = Field(..., description="Risk level")
    execution: ExecutionConfig = Field(..., description="Execution configuration")
    rollback_strategy: RollbackStrategy = Field(..., description="Rollback strategy")
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
