"""Example usage of ActionRegistry."""

from pathlib import Path
from unishell.core.action_registry import ActionRegistryImpl

# Initialize registry
registry = ActionRegistryImpl()

# Load individual JSON files
actions_dir = Path(__file__).parent / "core" / "action_registry" / "actions"

print("Loading actions from JSON files...")
registry.load_from_file(str(actions_dir / "file.move.json"))
registry.load_from_file(str(actions_dir / "file.delete.json"))
registry.load_from_file(str(actions_dir / "system.restart.json"))

# List all actions
print(f"\nRegistered actions: {registry.list_actions()}")

# Get specific action
file_move = registry.get_action("file.move")
print(f"\nAction: {file_move.action_id}")
print(f"  Category: {file_move.category}")
print(f"  Risk Level: {file_move.risk_level}")
print(f"  Required Params: {file_move.required_params}")
print(f"  Rollback Strategy: {file_move.rollback_strategy}")

# Validate parameters
print("\n--- Parameter Validation ---")
valid, missing = registry.validate_params("file.move", {
    "source": "/tmp/file.txt",
    "destination": "/home/user/file.txt"
})
print(f"Valid params: {valid}, Missing: {missing}")

valid, missing = registry.validate_params("file.move", {
    "source": "/tmp/file.txt"
})
print(f"Missing destination - Valid: {valid}, Missing: {missing}")

# Get actions by category
print("\n--- Actions by Category ---")
file_actions = registry.get_by_category("file")
print(f"File actions: {[a.action_id for a in file_actions]}")

system_actions = registry.get_by_category("system")
print(f"System actions: {[a.action_id for a in system_actions]}")

# Load from YAML (multiple actions at once)
print("\n--- Loading from YAML ---")
registry2 = ActionRegistryImpl()
registry2.load_from_file(str(actions_dir / "example_actions.yaml"))
print(f"Loaded from YAML: {registry2.list_actions()}")
