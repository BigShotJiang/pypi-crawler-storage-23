import platform
import subprocess
from .system_control import SystemControl
from .app_control import AppControl


class Os:
    def __init__(self, computer):
        self.computer = computer
        self.system_control = SystemControl()
        self.app_control = AppControl()

    def get_selected_text(self):
        """
        Returns the currently selected text.
        """
        # Store the current clipboard content
        current_clipboard = self.computer.clipboard.view()
        # Copy the selected text to clipboard
        self.computer.clipboard.copy()
        # Get the selected text from clipboard
        selected_text = self.computer.clipboard.view()
        # Reset the clipboard to its original content
        self.computer.clipboard.copy(current_clipboard)
        return selected_text

    def notify(self, text):
        """
        Displays a notification on the computer.
        """
        try:
            title = "Open UniShell"

            if len(text) > 200:
                text = text[:200] + "..."

            if "darwin" in platform.system().lower():  # Check if the OS is macOS
                text = text.replace('"', "'").replace("\n", " ")
                text = (
                    text.replace('"', "")
                    .replace("'", "")
                    .replace("“", "")
                    .replace("”", "")
                    .replace("<", "")
                    .replace(">", "")
                    .replace("&", "")
                )

                # Further sanitize the text to avoid errors
                text = text.encode("unicode_escape").decode("utf-8")

                ## Run directly
                script = f'display notification "{text}" with title "{title}"'
                subprocess.run(["osascript", "-e", script])

                # ## DISABLED OI-notifier.app
                # (This does not work. It makes `pip uninstall`` break for some reason!)

                # ## Use OI-notifier.app, which lets us use a custom icon

                # # Get the path of the current script
                # script_path = os.path.dirname(os.path.realpath(__file__))

                # # Write the notification text into notification_text.txt
                # with open(os.path.join(script_path, "notification_text.txt"), "w") as file:
                #     file.write(text)

                # # Construct the path to the OI-notifier.app
                # notifier_path = os.path.join(script_path, "OI-notifier.app")

                # # Call the OI-notifier
                # subprocess.run(["open", notifier_path])
            else:  # For other OS, use a general notification API
                try:
                    import plyer

                    plyer.notification.notify(title=title, message=text)
                except:
                    # Optional package
                    pass
        except Exception as e:
            # Notifications should be non-blocking
            if self.computer.verbose:
                print("Notification error:")
                print(str(e))

    # Maybe run code should be here...?

    def install_app(self, app_name, source=None, version=None):
        """Install an application."""
        return self.app_control.install(app_name, source, version)

    def uninstall_app(self, app_name, force=False):
        """Uninstall an application."""
        return self.app_control.uninstall(app_name, force)

    def update_app(self, app_name, version=None):
        """Update an application."""
        return self.app_control.update(app_name, version)

    def list_apps(self, filter=None):
        """List installed applications."""
        return self.app_control.list_installed(filter)

    def open_app(self, app_name, args=None):
        """Open an application."""
        return self.app_control.open_app(app_name, args)

    def close_app(self, app_name):
        """Force close an application."""
        return self.app_control.force_close(app_name)

    def set_default_app(self, app_name, file_type):
        """Set default application for file type."""
        return self.app_control.set_default(app_name, file_type)

    def schedule_app(self, app_name, schedule, args=None):
        """Schedule app auto-start."""
        return self.app_control.schedule_autostart(app_name, schedule, args)

    def toggle_startup(self, app_name, enabled):
        """Enable/disable app at startup."""
        return self.app_control.toggle_startup(app_name, enabled)

    def app_version(self, app_name):
        """Get app version."""
        return self.app_control.get_version(app_name)
