import platform
import subprocess
import psutil
import os


class SystemControl:
    """System control operations for Windows, Linux, and macOS"""
    
    def __init__(self):
        self.os_type = platform.system().lower()
    
    def restart(self, delay=0, force=False):
        """Restart the system"""
        if 'windows' in self.os_type:
            cmd = f'shutdown /r /t {delay}'
            if force:
                cmd += ' /f'
        elif 'darwin' in self.os_type:
            cmd = f'sudo shutdown -r +{delay//60}'
        else:
            cmd = f'sudo shutdown -r +{delay//60}'
        subprocess.run(cmd, shell=True)
    
    def shutdown(self, delay=0, force=False):
        """Shutdown the system"""
        if 'windows' in self.os_type:
            cmd = f'shutdown /s /t {delay}'
            if force:
                cmd += ' /f'
        elif 'darwin' in self.os_type:
            cmd = f'sudo shutdown -h +{delay//60}'
        else:
            cmd = f'sudo shutdown -h +{delay//60}'
        subprocess.run(cmd, shell=True)
    
    def sleep(self):
        """Put system to sleep"""
        if 'windows' in self.os_type:
            subprocess.run('rundll32.exe powrprof.dll,SetSuspendState 0,1,0', shell=True)
        elif 'darwin' in self.os_type:
            subprocess.run('pmset sleepnow', shell=True)
        else:
            subprocess.run('systemctl suspend', shell=True)
    
    def hibernate(self):
        """Hibernate the system"""
        if 'windows' in self.os_type:
            subprocess.run('shutdown /h', shell=True)
        elif 'darwin' in self.os_type:
            subprocess.run('pmset hibernatemode 25 && pmset sleepnow', shell=True)
        else:
            subprocess.run('systemctl hibernate', shell=True)
    
    def lock(self):
        """Lock the screen"""
        if 'windows' in self.os_type:
            subprocess.run('rundll32.exe user32.dll,LockWorkStation', shell=True)
        elif 'darwin' in self.os_type:
            subprocess.run('/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend', shell=True)
        else:
            subprocess.run('loginctl lock-session', shell=True)
    
    def get_resources(self):
        """Get CPU and RAM usage"""
        return {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'cpu_count': psutil.cpu_count(),
            'memory_percent': psutil.virtual_memory().percent,
            'memory_total': psutil.virtual_memory().total,
            'memory_available': psutil.virtual_memory().available,
            'memory_used': psutil.virtual_memory().used
        }
    
    def get_info(self):
        """Get system information"""
        return {
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'hostname': platform.node()
        }
    
    def kill_process(self, pid, force=False):
        """Kill a process by PID"""
        try:
            proc = psutil.Process(pid)
            if force:
                proc.kill()
            else:
                proc.terminate()
            return True
        except psutil.NoSuchProcess:
            return False
    
    def start_service(self, name):
        """Start a service"""
        if 'windows' in self.os_type:
            subprocess.run(f'net start {name}', shell=True)
        else:
            subprocess.run(f'sudo systemctl start {name}', shell=True)
    
    def stop_service(self, name):
        """Stop a service"""
        if 'windows' in self.os_type:
            subprocess.run(f'net stop {name}', shell=True)
        else:
            subprocess.run(f'sudo systemctl stop {name}', shell=True)
    
    def enable_service(self, name):
        """Enable a service"""
        if 'windows' in self.os_type:
            subprocess.run(f'sc config {name} start=auto', shell=True)
        else:
            subprocess.run(f'sudo systemctl enable {name}', shell=True)
    
    def disable_service(self, name):
        """Disable a service"""
        if 'windows' in self.os_type:
            subprocess.run(f'sc config {name} start=disabled', shell=True)
        else:
            subprocess.run(f'sudo systemctl disable {name}', shell=True)
    
    def change_setting(self, setting, value):
        """Change system settings"""
        if 'windows' in self.os_type:
            subprocess.run(f'reg add {setting} /v {value} /f', shell=True)
        else:
            pass  # Platform-specific implementation needed
    
    def update_os(self, auto_install=False):
        """Update the operating system"""
        if 'windows' in self.os_type:
            subprocess.run('powershell -Command "Install-Module PSWindowsUpdate -Force; Get-WindowsUpdate"', shell=True)
        elif 'darwin' in self.os_type:
            subprocess.run('softwareupdate -l', shell=True)
        else:
            subprocess.run('sudo apt update && sudo apt upgrade -y' if auto_install else 'sudo apt update', shell=True)
