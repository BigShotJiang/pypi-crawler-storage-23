"""Action poller for desktop agent."""
import aiohttp

class ActionPoller:
    def __init__(self, config):
        self.config = config
        
    async def pull_action(self):
        """Pull next available action from gateway."""
        url = f"{self.config.gateway_url}/agent/actions/pull"
        headers = {"Authorization": self.config.device_token}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status == 200:
                        return await resp.json()
                    elif resp.status == 204:
                        return None
        except:
            pass
        return None
