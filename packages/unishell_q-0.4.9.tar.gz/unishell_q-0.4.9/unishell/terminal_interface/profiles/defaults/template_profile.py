"""
This is the template Open UniShell profile.

A starting point for creating a new profile.

Learn about all the available settings - https://docs.unishell.com/settings/all-settings

"""

# Import the unishell
from unishell import unishell

# You can import other libraries too
from datetime import date

# You can set variables
today = date.today()

# LLM Settings
unishell.llm.model = "groq/llama-3.1-70b-versatile"
unishell.llm.context_window = 110000
unishell.llm.max_tokens = 4096
unishell.llm.api_base = "https://api.example.com"
unishell.llm.api_key = "your_api_key_here"
unishell.llm.supports_functions = False
unishell.llm.supports_vision = False


# UniShell Settings
unishell.offline = False
unishell.loop = True
unishell.auto_run = False

# Toggle OS Mode - https://docs.unishell.com/guides/os-mode
unishell.os = False

# Import Computer API - https://docs.unishell.com/code-execution/computer-api
unishell.computer.import_computer_api = True


# Set Custom Instructions to improve your UniShell's performance at a given task
unishell.custom_instructions = f"""
    Today's date is {today}.
    """
