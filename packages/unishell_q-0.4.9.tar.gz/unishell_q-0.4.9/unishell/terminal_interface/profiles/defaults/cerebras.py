"""
This is an Open UniShell profile to use Cerebras. 

Please set the CEREBRAS_API_KEY environment variable.

See https://inference-docs.cerebras.ai/introduction for more information.
"""

from unishell import unishell
import os

# LLM settings
unishell.llm.api_base = "https://api.cerebras.ai/v1"
unishell.llm.model = "openai/llama3.1-70b"  # or "openai/Llama-3.1-8B"
unishell.llm.api_key = os.environ.get("CEREBRAS_API_KEY")
unishell.llm.supports_functions = False
unishell.llm.supports_vision = False
unishell.llm.max_tokens = 4096
unishell.llm.context_window = 8192


# Computer settings
unishell.computer.import_computer_api = False

# Misc settings
unishell.offline = False
unishell.auto_run = False

# Custom Instructions
unishell.custom_instructions = f"""

    """
