__version__ = "0.1.15"
__app_name__ = "devmemory"
