"""Rate limiting algorithms."""
