from ...system.docs.openrpc import build_openrpc_spec

__all__ = ["build_openrpc_spec"]
