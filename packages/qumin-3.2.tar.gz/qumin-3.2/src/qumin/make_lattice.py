# !usr/bin/python3
# -*- coding: utf-8 -*-
"""Cluster lemmas according to their paradigms.

Author: Sacha Beniamine.
"""

import logging

from .clustering import find_microclasses
from .lattice.lattice import ICLattice
from .representations import segments

log = logging.getLogger()

try:
    import mpld3
except:
    mpld3 = None

def lattice_command(cfg, md, patterns_md):
    r"""Infer Inflection classes as a lattice from alternation patterns.

    Arguments:
        cfg (omegaconf.dictconfig.DictConfig): Configuration for this run.
        md (qumin.utils.Metadata): Metadata handler for this run.
        patterns_md (qumin.utils.Metadata): Metadata handler for the patterns run.
    """

    # Initializing segments
    sounds_file_name = md.get_table_path("sounds")
    segments.Inventory.initialize(sounds_file_name)

    # Inflectional paradigms: rows are forms, with lexeme and cell..
    paradigms = patterns_md.get_paradigms(md, segcheck=True)
    # Patterns: built on the paradigms
    patterns = patterns_md.get_patterns(paradigms)

    for pair in patterns:
        patterns[pair].loc[:, "pattern"] = patterns[pair].loc[:, "pattern"].map(str)

    microclasses = find_microclasses(paradigms, patterns)
    log.info("Building the lattice...")
    incidence_table = patterns.incidence_table(lexemes=microclasses)
    lattice = ICLattice(incidence_table, microclasses,
                        aoc=cfg.lattice.aoc,
                        keep_names=(not cfg.lattice.shorten))

    if cfg.lattice.stat:
        statname = md.get_path('lattice/stats.tex')
        stats = lattice.stats()
        with open(statname, "w", encoding="utf-8") as flow:
            flow.write(stats.to_frame().T.to_latex())
            log.info(stats.to_frame().T.to_markdown())
        md.register_file('lattice/stats.tex',  description="Lattice statistics",
                         custom={"statistics": stats.to_dict()})

    if cfg.lattice.png:
        lattpng = md.get_path('lattice/lattice.png')
        lattice.draw(lattpng, figsize=(20, 10), title=None, point=True)
        md.register_file('lattice/lattice.png', name="lattice_png", description="Lattice PNG figure")

    if cfg.lattice.pdf:
        lattpdf = md.get_path('lattice/lattice.pdf')
        lattice.draw(lattpdf, figsize=(20, 10), title=None, point=True)
        md.register_file('lattice/lattice.pdf', name="lattice_pdf",  description="Lattice PDF figure")

    if cfg.lattice.html and mpld3 is not None:
        latthtml = md.get_path('lattice/lattice.html')
        lattice.to_html(latthtml)
        md.register_file('lattice/lattice.html', name="lattice_html",  description="Lattice HTML figure")

    if cfg.lattice.ctxt:
        lattcxt = md.get_path('lattice/lattice.cxt')
        log.info(" ".join(["Exporting context to file:", str(lattcxt)]))
        lattice.context.tofile(lattcxt, frmat='cxt')
        md.register_file('lattice/lattice.cxt', name="lattice_cxt",  description="Lattice CXT figure")

    log.debug("Here is the first level of the hierarchy:")
    log.debug("Root:")
    obj, common = lattice.nodes.attributes["objects"], lattice.nodes.attributes["common"]
    if obj or common:
        log.debug("\tdefines: " + str(obj) + str(common))
    for child in lattice.nodes.children:
        extent, common = child.labels, child.attributes["common"]
        log.debug(" ".join(["\n\textent:", str(extent), "\n\tdefines:", str(common), ">"]))
