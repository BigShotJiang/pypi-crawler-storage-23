#!usr/bin/python3
# -*- coding: utf-8 -*-
"""author: Sacha Beniamine.

Compute conditional entropies in inflectional patterns.
"""

import logging

from hydra.core.hydra_config import HydraConfig

from .utils import adjust_cpus
from .predictability.distribution import PatternDistribution
from .representations import segments, create_features

log = logging.getLogger()


def H_command(cfg, md, patterns_md):
    r"""Compute entropies of flexional paradigms' distributions.

    Arguments:
        cfg (omegaconf.dictconfig.DictConfig): Configuration for this run.
        md (qumin.utils.Metadata): Metadata handler for this run.
        patterns_md (qumin.utils.Metadata): Metadata handler for the patterns run.
    """

    verbose = HydraConfig.get().verbose is not False
    sounds_file_name = md.get_table_path("sounds")
    preds = [cfg.entropy.n] if type(cfg.entropy.n) is int else sorted(cfg.entropy.n)
    onePred = preds[0] == 1

    legacy = len(set(preds) - {1}) > 0
    assert not (legacy and (cfg.pred.token_freq.patterns or
                            cfg.pred.token_freq.predictors or
                            cfg.pats.overabundant.keep)), \
        "Token frequencies and overabundant patterns can't be used " \
        "in N predictor computations, except for weighting cells."

    if onePred:
        preds.pop(0)

    # Initialize segment inventory for phonological computations
    segments.Inventory.initialize(sounds_file_name)

    # Inflectional paradigms: rows are forms, with lexeme and cell..
    paradigms = patterns_md.get_paradigms(md, segcheck=True)
    # Patterns: built on the paradigms
    patterns = patterns_md.get_patterns(paradigms)

    if verbose and len(patterns.cells) > 10:
        log.warning("Using verbose mode is strongly "
                    "discouraged on large (>10 cells) datasets."
                    "You should probably stop this process now.")

    if cfg.pred.features is not None:
        features = create_features(md, cfg.pred.features)
    else:
        features = None

    num_cpus = adjust_cpus(cfg.cpus)
    patterns.find_applicable(cpus=num_cpus)
    patterns.info()

    distrib = PatternDistribution(patterns,
                                  md.paralex,
                                  paradigms.frequencies,
                                  features=features)

    if onePred:
        if verbose:
            distrib.one_pred_metrics(debug=verbose,
                                     legacy=legacy,
                                     token_patterns=cfg.pred.token_freq.patterns,
                                     token_predictors=cfg.pred.token_freq.predictors,
                                     token_oa=cfg.pred.token_freq.overabundant,
                                     )
        distrib.one_pred_metrics(legacy=legacy,
                                 token_patterns=cfg.pred.token_freq.patterns,
                                 token_predictors=cfg.pred.token_freq.predictors,
                                 token_oa=cfg.pred.token_freq.overabundant,
                                 )
        mean = distrib.get_mean()
        log.info("Conditional entropy and probability of success:")
        log.info(mean.to_markdown())

    if preds:
        if cfg.pats.overabundant.keep:
            raise NotImplementedError
        if cfg.pred.importResults:
            distrib.import_file(cfg.pred.importResults)
        for n in preds:
            if verbose:
                distrib.n_preds_entropy(n, paradigms, debug=verbose)
            distrib.n_preds_entropy(n, paradigms)
            mean = distrib.get_mean(n=n)
            log.info("Conditional entropy and probability of success:")
            log.info(mean.to_markdown())

    ent_file = md.get_path('entropies.csv')
    log.info("Writing to: {}".format(ent_file))
    distrib.export_file(ent_file)
    md.register_file('entropies.csv', description="Entropy computation results",
                     custom={"mean_measures": mean.to_dict()})
