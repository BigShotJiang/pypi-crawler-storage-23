import logging
import hydra
import warnings

from .calc_paradigm_pred import H_command
from .find_patterns import pat_command
from .find_macroclasses import macroclasses_command
from .make_lattice import lattice_command
from .microclass_heatmap import heatmap_command
from .pred_heatmap import pred_heatmap_command
from .utils.metadata import Metadata
from .utils.config import register_config


# Set up the logger
log = logging.getLogger()

# The following is similar to logging.captureWarnings(True), adjusted for hydra.
def _showwarning(message, category, filename, lineno, file=None, line=None):
    """
    Special handler for warnings. Uses hydra logger instead of default 'py.warnings'.

    N.B.: this won't catch warnings redirected by hydra before the initialization of the logger.
    See: https://stackoverflow.com/a/28367973
    """
    s = warnings.formatwarning(message, category, filename, lineno, line)
    log.warning("%s", s)

warnings.showwarning = _showwarning

# Register the CLI configuration
register_config()

@hydra.main(version_base=None, config_path="config", config_name="qumin")
def qumin_command(cfg):

    log.info(cfg)

    # Deprecations
    # TODO remove in 4.0.0
    if cfg.action == 'H':
        warnings.warn(FutureWarning("'H' is deprecated as an action. Please use action=pred instead. H will be dropped in future versions."))
        cfg.action = 'pred'
    if cfg.action == 'ent_heatmap':
        warnings.warn(FutureWarning("'ent_heatmap' is deprecated as an action. Please use action=pred_heatmap instead. ent_heatmap will be dropped in future versions."))
        cfg.action = 'pred_heatmap'

    md = Metadata(cfg=cfg)
    action = cfg.action.value

    # Actions
    if (cfg.patterns is None or cfg.action == "patterns") and \
            cfg.action != 'pred_heatmap':
        check_pat_config(cfg.action, md)
        pat_command(cfg, md)

    if action in ['pred', 'macroclasses', 'lattice', 'heatmap']:
        patterns_md = Metadata(path=cfg.patterns) if cfg.patterns else md
        check_pat_config(action, patterns_md)

    if action == "pred":
        H_command(cfg, md, patterns_md)
    elif action == "macroclasses":
        macroclasses_command(cfg, md, patterns_md)
    elif action == "lattice":
        lattice_command(cfg, md, patterns_md)
    elif action == "heatmap":
        heatmap_command(cfg, md, patterns_md)

    if (action == "pred" and cfg.pred.vis) or action == 'pred_heatmap':
        pred_heatmap_command(cfg, md)

    # Once computations are done, save run metadata.
    md.save_metadata()


def check_pat_config(action, patterns_md):
    """
    Checks that the patterns are appropriate for this action.

    Arguments:
        action (bool): Action for this run.
        patterns_md: Metadata of the patterns computation.
    """
    not_overab = not patterns_md.cfg.pats.overabundant.keep
    not_defect = not patterns_md.cfg.pats.defective
    for_H = action == "pred"
    for_m = action == "macroclasses"
    assert not_overab or not for_m, "For this calculation, overabundant.keep must be False"
    assert not_defect or not for_m, "For this calculation, defective must be False"
