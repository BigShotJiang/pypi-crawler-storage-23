# -*- coding: utf-8 -*-
# !/usr/bin/python3
import logging
from os import cpu_count, name
from .config import register_config

log = logging.getLogger()


def adjust_cpus(n):
    if name != "posix":  # Forbid multiprocessing for now on windows
        if n != 1:
            log.warning(f"Warning, {n} cpus specified, but only 1 will be used, as you seem to run on windows.")
        return 1
    else:
        available = cpu_count()
        return n or min(max(1, available - 2), 10)


def memory_check(df, factor, max_gb=2, force=False):
    """
    Checks memory usage for a dataframe and warn if it exceeds a certain limit.

    Arguments:
        df (`pandas.DataFrame`): dataframe to test
        factor (int): multiplication factor for the test.
        max_gb (float): Threshold for memory warning.
        force (bool): whether to allow overpassing the limit. Defaults to False.
    """
    mem = df.memory_usage(deep=True, index=True).sum() / (1024 ** 3) * factor
    if mem > max_gb:
        if not force:
            raise Warning(f'The memory required might exceed {mem} GB of RAM. '
                          'If this is what you want, try again with force=true. '
                          'You could also sample some lexemes or select some cells.')
        else:
            log.warning(f'The required memory might exceed {mem} GB of RAM,'
                        'but you passed force=true.')
