
|PyPi|_ |pipeline|_ |zenodo|_ |DocStatus|_

.. |PyPi| image:: https://img.shields.io/pypi/v/qumin
.. _PyPi: https://pypi.org/project/qumin/

.. |pipeline| image:: https://gitlab.com/qumin/Qumin/badges/master/pipeline.svg
.. _pipeline: https://gitlab.com/qumin/Qumin

.. |zenodo| image:: https://zenodo.org/badge/DOI/10.5281/zenodo.15008373.svg
.. _zenodo: https://doi.org/10.5281/zenodo.15008373

.. |DocStatus| image:: https://readthedocs.org/projects/qumin/badge/?version=dev
.. _DocStatus: https://qumin.readthedocs.io/dev/?badge=latest

Qumin (QUantitative Modelling of INflection) is a package for the computational modelling of the inflectional morphology of languages. It was initially developed for `Sacha Beniamine's PhD dissertation <https://tel.archives-ouvertes.fr/tel-01840448>`_.

**Contributors**: Sacha Beniamine, Jules Bouton.

**Documentation**: https://qumin.readthedocs.io/

**Pypi**: https://pypi.org/project/qumin/

**Gitlab**: https://gitlab.com/qumin/Qumin

.. warning::
    The Github repo has now been migrated to gitlab. Update your bookmarks !


The current version was significantly updated since the publications cited below. These updates do not affect results, and focused on bugfixes, command line interface, paralex compatibility, workflow improvement and overall tidyness.

For more detail, you can refer to Sacha's dissertation (in French, `Beniamine 2018 <https://tel.archives-ouvertes.fr/tel-01840448>`_).

Quick Start
===========

To install Qumin, run:

.. code-block:: bash

    pip install qumin

To compute patterns and entropies:

.. code-block:: bash

    qumin action=pred data=<path/to/paralex.package.json>

To compute patterns and a lattice of microclasses:

.. code-block:: bash

    qumin action=lattice data=<path/to/paralex.package.json>


For a detailed introduction, you can head to the `tutorials <tutorials/index.html>`_. More advance use-cases are handled in the `how-to guides <howto/index.html>`_. A full `reference <reference/index.html>`_ of the command line options and of Qumín's internals is also provided.

Citing
======

If you use Qumin in your research, please cite the Qumin Zenodo deposit as well as the relevant paper for the specific actions used (see below). Substitute "<version used>" with the version of Qumin you used.

- Beniamine & Bouton. (2025). Qumin (v3.<version used>). [Python package]. doi: `10.5281/zenodo.15008373 <https://doi.org/10.5281/zenodo.15008373>`_ `https://pypi.org/project/qumin/ <https://pypi.org/project/qumin/>`_

- For alternation patterns, please cite `Beniamine (2018) <https://tel.archives-ouvertes.fr/tel-01840448>`_.
- For entropy calculations, please also cite `Bonami and Beniamine 2016 <http://www.llf.cnrs.fr/fr/node/4789>`_.
- For advanced predictibility calculations using probability of success or token frequencies, please also cite Bouton and Bonami 2026.
- For macroclass inference, please also cite `Beniamine, Bonami and Sagot (2018) <http://jlm.ipipan.waw.pl/index.php/JLM/article/view/184>`_
- For lattice inference, please also cite `Beniamine (2021) <https://langsci-press.org/catalog/book/262>`_.

For reproducibility, mentioning the exact current revision is important.

To appear in the publications list, send Sacha an email with the reference of your publication at s.<last name>@surrey.ac.uk
