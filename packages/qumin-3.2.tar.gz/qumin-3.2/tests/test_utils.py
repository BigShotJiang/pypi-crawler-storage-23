#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
from unittest.mock import patch

from frictionless import Package

from qumin.utils import adjust_cpus
from qumin.utils.metadata import Metadata, get_recursively
from omegaconf.dictconfig import DictConfig


def set_recursively(cfg, path, value):
    keys = path.split('.')
    for k in keys[:-1]:
        cfg = cfg[k]
    cfg[keys[-1]] = value


class MetadataTestCase(unittest.TestCase):
    """
    This test class controls the behavious of the Metadata class,
    and in particular of the method that reloads paradigms and patterns.
    """

    base_cfg = {"data": "test",
                "pats": {
                    "defective": False,
                    "overabundant": False,
                    },
                "cells": None,
                "lexemes": None,
                "force": False,
                "resegment": False,
                "pos": None,
                "sample_cells": 10,
                "sample_lexemes": None,
                "seed": 1,
                "force_random": True,
                }

    old = DictConfig(base_cfg)

    @patch('qumin.utils.metadata.Package')
    def test_get_paradigm_conf_no_error(self, mock_package):

        old = self.old
        mock_package.return_value = Package()

        with self.assertNoLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                old)

    @patch('qumin.utils.metadata.Package')
    def test_get_paradigm_conf_identical(self, mock_package):

        mock_package.return_value = Package()
        old = self.old

        for attr in ['pats.overabundant', 'pats.defective', 'resegment', 'lexemes']:
            new = self.old.copy()
            set_recursively(new, attr,
                            not get_recursively(new, attr))
            if attr == "lexemes":
                new[attr] = "empty/path"

            with self.assertLogs('root', level='WARNING') as cm:
                Metadata.get_paradigm_conf(
                    Metadata(cfg=old, rundir_path="test"),
                    new)

    @patch('qumin.utils.metadata.Package')
    def test_get_paradigm_conf_sets(self, mock_package):

        mock_package.return_value = Package()
        old = self.old.copy()
        new = self.old.copy()
        old['cells'] = ['A', 'B', 'C']
        new['cells'] = ['A', 'B', 'C', 'D']

        with self.assertLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)

        old = self.old.copy()
        new = self.old.copy()
        old['pos'] = ['noun']
        new['pos'] = ['verb']

        with self.assertLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)

        old = self.old.copy()
        new = self.old.copy()
        old['sample_cells'] = None
        new['cells'] = ['A', 'B', 'C', 'D']

        with self.assertNoLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)

    @patch('qumin.utils.metadata.Package')
    def test_get_paradigm_conf_sampling(self, mock_package):

        mock_package.return_value = Package()
        old = self.old
        new = self.old.copy()
        new['sample_cells'] = 5

        with self.assertLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)

        old = self.old.copy()
        new = self.old.copy()
        new['sample_lexemes'] = 3

        with self.assertLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)

        old = self.old.copy()
        new = self.old.copy()
        new['seed'] = 4

        with self.assertLogs('root', level='WARNING') as cm:
            Metadata.get_paradigm_conf(
                Metadata(cfg=old, rundir_path="test"),
                new)


class UtilsTestCase(unittest.TestCase):

    @patch('qumin.utils.cpu_count')
    def test_adjust_cpus(self, mock_cpus):
        # Windows
        with patch('qumin.utils.name', 'noposix'):
            self.assertEqual(adjust_cpus(10), 1)

        # Linux
        with patch('qumin.utils.name', 'posix'):
            # User input
            self.assertEqual(adjust_cpus(15), 15)

            # No user input
            mock_cpus.return_value = 2
            self.assertEqual(adjust_cpus(None), 1)
            mock_cpus.return_value = 5
            self.assertEqual(adjust_cpus(None), 3)
            mock_cpus.return_value = 15
            self.assertEqual(adjust_cpus(None), 10)
