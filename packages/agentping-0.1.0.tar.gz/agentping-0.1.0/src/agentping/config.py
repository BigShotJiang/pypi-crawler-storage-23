"""Configuration for the AgentPing MCP server."""

from __future__ import annotations

import json
import os
from pathlib import Path

_CONFIG_DIR = Path.home() / ".agentping"
_CONFIG_FILE = _CONFIG_DIR / "config.json"

DEFAULT_RELAY_URL = "wss://relay.agentping.dev/ws"


def get_api_key() -> str:
    """Get API key from env var or config file."""
    key = os.environ.get("AGENTPING_API_KEY", "")
    if key:
        return key
    config = load_config()
    return config.get("api_key", "")


def get_relay_url() -> str:
    """Get relay WebSocket URL from env var or config file."""
    url = os.environ.get("AGENTPING_RELAY_URL", "")
    if url:
        return url
    config = load_config()
    return config.get("relay_url", DEFAULT_RELAY_URL)


def get_agent_name() -> str:
    """Get agent name from env var or config file."""
    name = os.environ.get("AGENTPING_AGENT_NAME", "")
    if name:
        return name
    config = load_config()
    return config.get("agent_name", "unknown")


def load_config() -> dict:
    """Load config from ~/.agentping/config.json."""
    if not _CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(_CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(config: dict) -> None:
    """Save config to ~/.agentping/config.json."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(config, indent=2))
    # Restrict permissions — config contains API key
    _CONFIG_FILE.chmod(0o600)
