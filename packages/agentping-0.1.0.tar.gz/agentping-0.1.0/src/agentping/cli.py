"""CLI entry point — setup wizard and MCP server runner."""

from __future__ import annotations

import json
import sys

from agentping.config import DEFAULT_RELAY_URL, get_api_key, load_config, save_config


def setup() -> None:
    """Interactive setup wizard."""
    print("=" * 50)
    print("  AgentPing Setup")
    print("=" * 50)
    print()
    print("Get your API key at: https://app.agentping.dev/settings")
    print()

    existing = load_config()

    # API Key
    current_key = existing.get("api_key", "")
    masked = f"{current_key[:8]}...{current_key[-4:]}" if len(current_key) > 12 else "(not set)"
    api_key = input(f"API Key [{masked}]: ").strip()
    if not api_key:
        api_key = current_key

    if not api_key:
        print("\nError: API key is required.")
        sys.exit(1)

    if not api_key.startswith("sk-ap_"):
        print("\nWarning: Key doesn't start with 'sk-ap_'. Make sure you copied the full key.")

    # Agent name
    current_name = existing.get("agent_name", "")
    agent_name = input(f"Agent name [{current_name or 'auto-detect'}]: ").strip()
    if not agent_name:
        agent_name = current_name

    # Relay URL
    current_url = existing.get("relay_url", DEFAULT_RELAY_URL)
    relay_url = input(f"Relay URL [{current_url}]: ").strip()
    if not relay_url:
        relay_url = current_url

    # Save
    config = {
        "api_key": api_key,
        "agent_name": agent_name,
        "relay_url": relay_url,
    }
    save_config(config)

    print()
    print("Configuration saved to ~/.agentping/config.json")
    print()
    print("Next steps:")
    print("  1. Add AgentPing to your IDE's MCP config:")
    print()

    mcp_config = {
        "mcpServers": {
            "agentping": {
                "command": "agentping",
                "env": {
                    "AGENTPING_API_KEY": api_key,
                },
            }
        }
    }
    print(f"     {json.dumps(mcp_config, indent=2)}")
    print()
    print("  2. Restart your IDE / MCP host.")
    print("  3. The agent can now use bridge_* tools to reach you!")
    print()


def main() -> None:
    """CLI entry point."""
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        setup()
        return

    if len(sys.argv) > 1 and sys.argv[1] in ("-h", "--help", "help"):
        print("Usage:")
        print("  agentping          Run the MCP server (for IDE integration)")
        print("  agentping setup    Configure API key and settings")
        print("  agentping help     Show this help message")
        return

    # Default: run as MCP server
    api_key = get_api_key()
    if not api_key:
        print("Error: No API key configured.")
        print("Run `agentping setup` or set AGENTPING_API_KEY env var.")
        sys.exit(1)

    from agentping.server import main as server_main
    server_main()
