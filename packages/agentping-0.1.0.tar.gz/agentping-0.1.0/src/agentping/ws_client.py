"""WebSocket client with auto-reconnect, heartbeat, and message queuing."""
from __future__ import annotations

import asyncio
import json
import logging
import random
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

import websockets
from websockets.exceptions import ConnectionClosed

logger = logging.getLogger("agentping")
_BASE_BACKOFF, _MAX_BACKOFF, _MAX_QUEUE = 1.0, 30.0, 100


class RelayClient:
    """WebSocket client for the AgentPing relay service."""

    def __init__(self, relay_url: str, api_key: str, agent_name: str = "unknown") -> None:
        self._relay_url = relay_url
        self._api_key = api_key
        self._agent_name = agent_name
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._connection_id: Optional[str] = None
        self._user_id: Optional[str] = None
        self._connected = asyncio.Event()
        self._closing = False
        self._queue: List[Dict[str, Any]] = []
        self._response_waiters: Dict[str, asyncio.Future] = {}
        self._reconnect_attempt = 0

    async def connect(self) -> None:
        self._closing = False
        asyncio.ensure_future(self._connection_loop())

    async def close(self) -> None:
        self._closing = True
        self._connected.clear()
        if self._ws:
            try: await self._ws.close()
            except Exception: pass

    async def wait_connected(self, timeout: float = 30.0) -> bool:
        try:
            await asyncio.wait_for(self._connected.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    @property
    def is_connected(self) -> bool:
        return self._connected.is_set()

    async def send_message(self, message_type: str, title: str, **kwargs) -> Optional[str]:
        """Send a message to the relay. Returns message_id on ack, or None."""
        msg_id = str(uuid4())
        frame = self._envelope("send_message", msg_id, payload={
            "message_type": message_type, "title": title, **{k: v for k, v in kwargs.items()}
        })
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._response_waiters[msg_id] = fut
        await self._send_or_queue(frame)
        try:
            result = await asyncio.wait_for(fut, timeout=30.0)
            return result.get("message_id")
        except asyncio.TimeoutError:
            self._response_waiters.pop(msg_id, None)
            return None

    async def check_response(self, message_id: str) -> Optional[Dict]:
        """Non-blocking poll for a response."""
        return await self._request("check_response", message_id=message_id)

    async def wait_response(self, message_id: str, timeout: float = 300.0) -> Dict:
        """Block until response received, polling every 5s."""
        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            result = await self.check_response(message_id)
            if result and result.get("has_response"):
                return result
            await asyncio.sleep(min(5.0, deadline - asyncio.get_event_loop().time()))
        return {"has_response": False, "status": "timeout", "message_id": message_id}

    async def list_pending(self) -> List[Dict]:
        """List all pending messages."""
        result = await self._request("list_pending")
        return result.get("messages", []) if result else []

    # --- Internal helpers ---

    async def _request(self, msg_type: str, **extra) -> Optional[Dict]:
        msg_id = str(uuid4())
        frame = self._envelope(msg_type, msg_id, **extra)
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._response_waiters[msg_id] = fut
        await self._send_or_queue(frame)
        try:
            return await asyncio.wait_for(fut, timeout=15.0)
        except asyncio.TimeoutError:
            self._response_waiters.pop(msg_id, None)
            return None

    async def _connection_loop(self) -> None:
        while not self._closing:
            try:
                headers = {"Authorization": f"Bearer {self._api_key}",
                           "X-Agent-Name": self._agent_name}
                async with websockets.connect(
                    self._relay_url, extra_headers=headers,
                    ping_interval=None, close_timeout=5,
                ) as ws:
                    self._ws = ws
                    ack = json.loads(await asyncio.wait_for(ws.recv(), timeout=10.0))
                    if ack.get("type") == "connection_error":
                        logger.error("Rejected: %s (code %s)", ack.get("error"), ack.get("code"))
                        if ack.get("code") in (4001, 4002, 4004):
                            self._closing = True
                            return
                        break
                    if ack.get("type") == "connection_ack":
                        self._connection_id = ack.get("connection_id")
                        self._user_id = ack.get("user_id")
                        self._reconnect_attempt = 0
                        self._connected.set()
                        logger.info("Connected (id=%s, plan=%s, remaining=%s)",
                                    self._connection_id, ack.get("plan"),
                                    ack.get("messages_remaining"))
                        await self._flush_queue()
                        await self._receive_loop(ws)
            except (ConnectionClosed, OSError, asyncio.TimeoutError) as e:
                logger.warning("Connection lost: %s", e)
            except Exception:
                logger.exception("Connection loop error")
            self._connected.clear()
            self._ws = None
            if self._closing:
                break
            backoff = min(_BASE_BACKOFF * (2 ** self._reconnect_attempt), _MAX_BACKOFF)
            jitter = backoff * (0.5 + random.random() * 0.5)
            self._reconnect_attempt += 1
            logger.info("Reconnecting in %.1fs (attempt %d)", jitter, self._reconnect_attempt)
            await asyncio.sleep(jitter)

    async def _receive_loop(self, ws) -> None:
        async for raw in ws:
            try: data = json.loads(raw)
            except json.JSONDecodeError: continue
            t = data.get("type")
            if t == "ping":
                await ws.send(json.dumps(self._envelope("pong", str(uuid4()))))
            elif t == "message_ack":
                self._resolve(data.get("ref_id"), data)
            elif t in ("check_response_result", "pending_list"):
                self._resolve_any(data)
            elif t == "response_received":
                logger.info("Response for %s: %s", data.get("message_id"), data.get("status"))
            elif t == "error":
                self._resolve(data.get("ref_id"), {"error": data.get("error")})
                logger.warning("Relay error: %s", data.get("error"))

    def _resolve(self, key: Optional[str], data: Dict) -> None:
        if key:
            fut = self._response_waiters.pop(key, None)
            if fut and not fut.done():
                fut.set_result(data)

    def _resolve_any(self, data: Dict) -> None:
        """Resolve the oldest pending waiter."""
        self._resolve(data.get("id"), data)
        if not any(True for _ in []):  # id didn't match, try FIFO
            for key in list(self._response_waiters):
                fut = self._response_waiters.get(key)
                if fut and not fut.done():
                    self._response_waiters.pop(key)
                    fut.set_result(data)
                    return

    async def _send_or_queue(self, frame: Dict) -> None:
        if self._connected.is_set() and self._ws:
            try:
                await self._ws.send(json.dumps(frame))
                return
            except Exception:
                pass
        if len(self._queue) >= _MAX_QUEUE:
            self._queue.pop(0)
        self._queue.append(frame)

    async def _flush_queue(self) -> None:
        while self._queue and self._ws:
            frame = self._queue.pop(0)
            try: await self._ws.send(json.dumps(frame))
            except Exception:
                self._queue.insert(0, frame)
                break

    @staticmethod
    def _envelope(msg_type: str, msg_id: str, **kwargs) -> Dict:
        return {"type": msg_type, "id": msg_id,
                "timestamp": datetime.now(timezone.utc).isoformat(), **kwargs}
