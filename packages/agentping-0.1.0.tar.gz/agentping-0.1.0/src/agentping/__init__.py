"""AgentPing MCP server — bridges AI coding agents to developers."""

__version__ = "0.1.0"
