# AgentPing — MCP Server

Thin MCP server that bridges any MCP-compatible AI coding agent (Copilot, Cursor, Claude Code, Cline, Aider, Windsurf) to you via the AgentPing cloud relay.

## Install

```bash
pip install agentping
```

## Setup

```bash
agentping setup
```

Paste your API key when prompted. Get your key at [app.agentping.dev](https://app.agentping.dev).

## IDE Configuration

Add to your VS Code / Cursor MCP config (`.vscode/mcp.json` or `mcp.json`):

```json
{
  "mcpServers": {
    "agentping": {
      "command": "agentping",
      "env": {
        "AGENTPING_API_KEY": "sk-ap_live_..."
      }
    }
  }
}
```

## MCP Tools

| Tool | Purpose | Blocks? |
|------|---------|---------|
| `bridge_ping` | Test connectivity | No |
| `bridge_send_approval` | Ask dev to approve/reject | No |
| `bridge_ask_question` | Free-form question | No |
| `bridge_wait_response` | Block until reply | Yes |
| `bridge_check_response` | Non-blocking poll | No |
| `bridge_approve_and_wait` | Send + wait combo | Yes |
| `bridge_send_update` | Progress notification | No |
| `bridge_task_complete` | Task finished notification | No |
| `bridge_list_pending` | List unanswered requests | No |

## License

MIT
