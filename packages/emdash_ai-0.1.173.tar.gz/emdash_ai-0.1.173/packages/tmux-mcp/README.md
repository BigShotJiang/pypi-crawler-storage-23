# emdash-tmux-mcp

MCP server that gives agents safe terminal control over TUI applications using `tmux`.

## Why This Exists

TUI apps (like editors, debuggers, and interactive CLIs) require a real TTY. A normal
`stdin/stdout` subprocess is not enough and often breaks interaction.

This MCP server uses `tmux` as a stable PTY harness so the agent can:
- create isolated terminal sessions,
- send key presses,
- capture current screen text,
- resize sessions,
- clean up sessions.

## Tools

- `tmux_create_session`
- `tmux_send_keys`
- `tmux_capture_pane`
- `tmux_resize`
- `tmux_kill_session`
- `tmux_list_sessions`

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `TMUX_MCP_SESSION_PREFIX` | `emdash-open` | Prefix for all managed sessions |
| `TMUX_MCP_MAX_CAPTURE_LINES` | `400` | Maximum lines returned by capture |
| `TMUX_MCP_COMMAND_TIMEOUT` | `10` | Timeout (seconds) for each tmux command |

## Usage

Run over stdio (normally started by emdash MCP manager):

```bash
emdash-tmux-mcp
```
