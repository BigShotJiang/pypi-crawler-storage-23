"""emdash-ai: Graph-based coding intelligence system."""

__version__ = "0.1.46"
