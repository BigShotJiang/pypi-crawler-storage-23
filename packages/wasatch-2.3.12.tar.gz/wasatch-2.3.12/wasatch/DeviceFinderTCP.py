import logging

log = logging.getLogger(__name__)

class DeviceFinderTCP:
    """
    I started this class, but I'm not sure it's actually needed yet. Using 
    enlighten.Controller.other_device_ids for the moment.
    """

    def __init__(self):
        pass

    def find_tcp_devices(self):
        device_ids = []

        # for addr in self.addresses:
        #   ...

        return device_ids
