"""This package provides control of Wasatch Photonics spectrometers"""

__version__ = "2.3.12"   # used by flit and other pypi things
version = __version__   # legacy alias
