#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : __init__.py
# @Time         : 2023/11/21 18:44
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.ai_audio.tts.EdgeTTS import EdgeTTS
# from meutils.ai_audio.tts.openai_tts import EdgeTTS


# import pypinyin
#
# print(pypinyin.pinyin('陕西'))
