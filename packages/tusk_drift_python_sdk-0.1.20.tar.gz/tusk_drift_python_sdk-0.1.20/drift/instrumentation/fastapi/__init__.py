from .instrumentation import FastAPIInstrumentation

__all__ = ["FastAPIInstrumentation"]
