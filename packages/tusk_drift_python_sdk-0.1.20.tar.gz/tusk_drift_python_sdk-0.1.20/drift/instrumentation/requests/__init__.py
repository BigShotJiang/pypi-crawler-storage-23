"""requests HTTP client instrumentation."""

from .instrumentation import RequestsInstrumentation

__all__ = ["RequestsInstrumentation"]
