"""urllib.request instrumentation module."""

from .instrumentation import UrllibInstrumentation

__all__ = ["UrllibInstrumentation"]
