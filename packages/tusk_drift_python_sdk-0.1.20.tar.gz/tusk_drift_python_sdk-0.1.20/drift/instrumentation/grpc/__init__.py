"""gRPC client instrumentation."""

from .instrumentation import GrpcInstrumentation

__all__ = ["GrpcInstrumentation"]
