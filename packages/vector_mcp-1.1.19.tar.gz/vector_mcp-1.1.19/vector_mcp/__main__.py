#!/usr/bin/python
# coding: utf-8
from vector_mcp.vector_mcp import vector_mcp

if __name__ == "__main__":
    vector_mcp()
