"""Anonymous product analytics for tool usage tracking.

Emits lightweight events to PostHog via the HTTP Capture API on each tool
invocation. Uses httpx (already a project dependency) -- no posthog-python
library. Analytics never block tool execution (fire-and-forget via
asyncio.create_task) and failures are silently suppressed.

Privacy: Only an explicit allow-list of properties is sent. Tool arguments,
responses, API keys, and error messages are never transmitted.
"""

import asyncio
import contextvars
import os
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

import httpx

# ---------------------------------------------------------------------------
# Hard-coded PostHog constants (not configurable via environment)
# ---------------------------------------------------------------------------
POSTHOG_API_KEY = "phc_JOvJQa6PeY6ox8ugPwFcYyyEZ46xXFp3CerBS8cyz3n"
POSTHOG_HOST = "https://us.i.posthog.com"

# ---------------------------------------------------------------------------
# SSE session ID ContextVar (set by SSE middleware per-request)
# ---------------------------------------------------------------------------
sse_analytics_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "sse_analytics_id", default=""
)


def is_truthy(value: Optional[str]) -> bool:
    """Parse a string environment variable as a boolean.

    Returns True for "true", "True", "TRUE", "1", "yes".
    Returns False for everything else (including empty string and None).
    """
    if value is None:
        return False
    return value.strip().lower() in ("true", "1", "yes")


def _get_server_version() -> str:
    """Retrieve the package version from metadata, with fallback."""
    try:
        from importlib.metadata import version

        return version("okareo-mcp")
    except Exception:
        return "unknown"


@dataclass
class AnalyticsClient:
    """Encapsulates analytics state for the lifetime of the server process."""

    http_client: Optional[httpx.AsyncClient]
    distinct_id: str
    transport_type: str
    server_version: str
    enabled: bool


def init_analytics() -> AnalyticsClient:
    """Initialize the analytics subsystem. Called once during server lifespan startup.

    Reads DEV and AIRGAP from environment. PostHog key and host are hard-coded.
    Generates a per-process uuid4() as distinct_id (no file I/O).

    Never raises. Returns a disabled client on any initialization failure.
    """
    try:
        dev_mode = is_truthy(os.environ.get("DEV"))
        airgap = is_truthy(os.environ.get("AIRGAP"))
        enabled = not dev_mode and not airgap

        transport_type = os.environ.get("TRANSPORT", "stdio")
        server_version = _get_server_version()
        distinct_id = str(uuid.uuid4())

        http_client = None
        if enabled:
            http_client = httpx.AsyncClient(timeout=5.0)

        return AnalyticsClient(
            http_client=http_client,
            distinct_id=distinct_id,
            transport_type=transport_type,
            server_version=server_version,
            enabled=enabled,
        )
    except Exception:
        return AnalyticsClient(
            http_client=None,
            distinct_id=str(uuid.uuid4()),
            transport_type="stdio",
            server_version="unknown",
            enabled=False,
        )


async def shutdown_analytics(client: AnalyticsClient) -> None:
    """Close the HTTP client. Called during server lifespan teardown.

    Never raises. Logs to stderr on failure.
    """
    try:
        if client.http_client is not None:
            await client.http_client.aclose()
    except Exception as e:
        print(f"Analytics shutdown error: {e}", file=sys.stderr)


def emit_tool_event(
    client: AnalyticsClient, tool_name: str, success: bool
) -> None:
    """Emit a tool call event to PostHog. Fire-and-forget via asyncio.create_task.

    Uses the SSE session ID from ContextVar when available, falling back to the
    per-process uuid4() on the AnalyticsClient.

    Never raises. Silently drops events on any error.
    """
    if not client.enabled or client.http_client is None:
        return

    # Resolve distinct_id: prefer SSE session ID, fall back to per-process UUID
    sse_id = sse_analytics_id.get("")
    distinct_id = sse_id if sse_id else client.distinct_id

    payload = {
        "api_key": POSTHOG_API_KEY,
        "distinct_id": distinct_id,
        "event": "mcp_tool_call",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "properties": {
            "tool_name": tool_name,
            "transport_type": client.transport_type,
            "server_version": client.server_version,
            "tool_call_success": success,
            "$process_person_profile": False,
        },
    }

    try:
        asyncio.create_task(_send_event(client.http_client, payload))
    except Exception:
        pass


async def _send_event(
    http_client: httpx.AsyncClient, payload: dict
) -> None:
    """POST a single event to the PostHog Capture API. Errors are silently caught."""
    try:
        await http_client.post(
            f"{POSTHOG_HOST}/capture/",
            json=payload,
        )
    except Exception:
        pass
