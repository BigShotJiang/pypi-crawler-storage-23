from .edfdatainterface import EDFRecordingInterface
from .edfanaloginterface import EDFAnalogInterface

__all__ = ["EDFRecordingInterface", "EDFAnalogInterface"]
