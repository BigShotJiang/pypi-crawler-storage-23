"""Utility functions for Reldo."""

from .substitution import substitute_variables

__all__ = ["substitute_variables"]
