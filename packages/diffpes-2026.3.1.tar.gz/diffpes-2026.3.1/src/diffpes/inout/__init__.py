"""VASP file parsers for ARPES simulation input.

Extended Summary
----------------
Provides parsers for VASP output files (POSCAR, EIGENVAL, KPOINTS,
DOSCAR, PROCAR, CHGCAR) that return PyTree data structures suitable
for ARPES simulations.

Routine Listings
----------------
:func:`apply_kpath_ticks`
    Annotate a plot axis with KPathInfo symmetry labels.
:func:`load_from_h5`
    Load PyTrees from an HDF5 file.
:func:`plot_arpes_spectrum`
    Plot an ARPES map from an ArpesSpectrum PyTree.
:func:`plot_arpes_with_kpath`
    Plot an ARPES map and apply KPathInfo axis annotations.
:func:`plot_band_scatter_preset`
    Plot projected bands with size-weighted scatter markers.
:func:`plot_band_scatter_with_kpath`
    Plot projected-band scatter and annotate with KPathInfo.
:func:`list_band_scatter_presets`
    Return supported preset names for band-scatter plotting.
:func:`read_doscar`
    Parse VASP DOSCAR into DensityOfStates.
:func:`read_chgcar`
    Parse VASP CHGCAR into VolumetricData.
:func:`read_eigenval`
    Parse VASP EIGENVAL into BandStructure.
:func:`read_kpoints`
    Parse VASP KPOINTS into KPathInfo.
:func:`read_poscar`
    Parse VASP POSCAR into CrystalGeometry.
:func:`read_procar`
    Parse VASP PROCAR into OrbitalProjection.
:func:`save_to_h5`
    Save one or more named PyTrees to an HDF5 file.

Notes
-----
All parsers use standard Python I/O (not JAX) since file
parsing is inherently sequential. They convert parsed data
to JAX arrays via factory functions.
"""

from .chgcar import read_chgcar
from .doscar import read_doscar
from .eigenval import read_eigenval
from .hdf5 import load_from_h5, save_to_h5
from .helpers import (
    aggregate_atoms,
    check_consistency,
    reduce_orbitals,
    select_atoms,
)
from .kpoints import read_kpoints
from .plotting import (
    apply_kpath_ticks,
    list_band_scatter_presets,
    plot_arpes_spectrum,
    plot_arpes_with_kpath,
    plot_band_scatter_preset,
    plot_band_scatter_with_kpath,
)
from .poscar import read_poscar
from .procar import read_procar

__all__: list[str] = [
    "aggregate_atoms",
    "apply_kpath_ticks",
    "check_consistency",
    "list_band_scatter_presets",
    "load_from_h5",
    "plot_band_scatter_preset",
    "plot_band_scatter_with_kpath",
    "plot_arpes_spectrum",
    "plot_arpes_with_kpath",
    "read_chgcar",
    "read_doscar",
    "read_eigenval",
    "read_kpoints",
    "read_poscar",
    "read_procar",
    "reduce_orbitals",
    "save_to_h5",
    "select_atoms",
]
