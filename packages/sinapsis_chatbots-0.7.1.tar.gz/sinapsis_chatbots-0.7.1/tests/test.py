from sinapsis_core.cli.run_agent_from_config import generic_agent_builder

agent = generic_agent_builder("packages/sinapsis_vllm/src/sinapsis_vllm/configs/multimodal.yaml")

result = agent()

print(result)