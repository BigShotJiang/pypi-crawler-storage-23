import json
from typing import Any, cast

from llama_cpp import Llama
from llama_cpp.llama_types import CreateChatCompletionResponse
from sinapsis_chatbots_base.helpers.llm_keys import LLMChatKeys
from sinapsis_chatbots_base.helpers.postprocess_text import postprocess_text
from sinapsis_chatbots_base.templates.llm_text_completion_base import (
    LLMTextCompletionAttributes,
    LLMTextCompletionBase,
)
from sinapsis_core.data_containers.data_packet import DataContainer, TextPacket

from sinapsis_llama_cpp.helpers.llama_init_model import init_llama_model
from sinapsis_llama_cpp.helpers.llama_keys import (
    LLaMAModelKeys,
)
from sinapsis_llama_cpp.helpers.schemas import LLaMACompletionArgs, LLaMAInitArgs


class LLaMATextCompletion(LLMTextCompletionBase):
    """Template for configuring and initializing a LLaMA-based text completion model.

    This template is responsible for setting up and initializing a LLaMA-CPP model based
    on the provided configuration. It handles the model setup by downloading
    the model from the Hugging Face Hub and configuring the necessary parameters.
    The template takes a text input from the DataContainer, and generates a response
    using the llm model.

    Attributes:
        init_args (LLMInitArgs): Base model arguments, including the 'llm_model_name'.
        completion_args (LLMCompletionArgs): Base generation arguments, including
            'max_tokens', 'temperature', 'top_p', and 'top_k'.
        chat_history_key (str | None): Key in the packet's generic_data to find
            the conversation history.
        rag_context_key (str | None): Key in the packet's generic_data to find
            RAG context to inject.
        system_prompt (str | Path | None): The system prompt (or path to one)
            to instruct the model.
        pattern (str | None): A regex pattern used to post-process the model's response.
        keep_before (bool): If True, keeps text before the 'pattern' match; otherwise,
            keeps text after.

    Usage example:

    agent:
      name: my_test_agent
    templates:
    - template_name: InputTemplate
      class_name: InputTemplate
      attributes: {}
    - template_name: LLaMATextCompletion
      class_name: LLaMATextCompletion
      template_input: InputTemplate
      attributes:
        init_args:
          llm_model_name: 'TheBloke/Mistral-7B-Instruct-v0.2-GGUF'
          llm_model_file: 'mistral-7b-instruct-v0.2.Q2_K.gguf'
          n_gpu_layers: -1
          split_mode: 0
          main_gpu: 0
          use_mmap: true
          use_mlock: false
          seed: 42
          n_ctx: 8192
          n_batch: 512
          n_ubatch: 512
          flash_attn_type: -1
          offload_kqv: false
          verbose: true
        completion_args:
          temperature: 0.2
          top_p: 0.95
          top_k: 40
          max_tokens: 4096
          min_p: 0.05
          typical_p: 1.0
          stop: null
          seed: 42
          repeat_penalty: 1.0
          penalty_last_n: 64
          present_penalty: 0.0
          frequency_penalty: 0.0
          logit_bias: null
          response_format:
            type: text
        chat_history_key: null
        rag_context_key: null
        system_prompt: You are an expert in AI.
        pattern: null
        keep_before: true
    """

    class AttributesBaseModel(LLMTextCompletionAttributes):
        """Attributes for LLaMA-CPP text completion template.

        Attributes:
            init_args (LLaMAInitArgs): LLaMA model arguments, including the 'llm_model_name'.
            completion_args (LLaMACompletionArgs): LLaMA generation arguments, including
                'max_tokens', 'temperature', 'top_p', and 'top_k', among others.
            chat_history_key (str | None): Key in the packet's generic_data to find
                the conversation history.
            rag_context_key (str | None): Key in the packet's generic_data to find
                RAG context to inject.
            system_prompt (str | Path | None): The system prompt (or path to one)
                to instruct the model.
            pattern (str | None): A regex pattern used to post-process the model's response.
            keep_before (bool): If True, keeps text before the 'pattern' match; otherwise,
                keeps text after.
        """

        init_args: LLaMAInitArgs
        completion_args: LLaMACompletionArgs
        structure_output_key: str = "structured_output"

    def init_llm_model(self) -> Llama:
        """Initializes the LLaMA model using the downloaded model path and the configuration attributes.

        This method downloads the model from the Hugging Face Hub using the
        model name and file attributes, then configures the model with
        parameters such as context size, temperature, and other relevant
        settings. The initialized Llama model is returned.

        Returns:
            Llama: An initialized instance of the Llama model.
        """
        return init_llama_model(
            self.attributes.init_args.llm_model_name,
            self.attributes.init_args.llm_model_file,
            self.attributes.init_args.model_dump(exclude_none=True, exclude={"llm_model_file", "llm_model_name"}),
            model_type=LLaMAModelKeys.model_type,
        )

    def get_response(self, input_message: str | list) -> str | None:
        """Generates a response from the model based on the provided text input.

        This method sends the input text to the model and receives a response.

        Args:
            input_message (list): The input text or prompt to which the model
            will respond.

        Returns:
            str|None: The model's response as a string, or None if no response
                is generated.
        """
        self.logger.debug(f"Query is {input_message}")
        completion_args = self.attributes.completion_args.model_dump(exclude_none=True, exclude={"response_format"})
        response_format = self.attributes.completion_args.response_format.to_llama_format()
        completion_args["response_format"] = response_format
        chat_completion = None
        try:
            chat_completion = self.llm.create_chat_completion(messages=input_message, **completion_args)
        except (IndexError, AttributeError):
            self.reset_llm_state()
            if self.llm:
                chat_completion = self.llm.create_chat_completion(messages=input_message, **completion_args)

        if chat_completion:
            chat_completion = cast(CreateChatCompletionResponse, chat_completion)
            self.logger.info(chat_completion)
            llm_response_choice = chat_completion[LLMChatKeys.choices]
            response = llm_response_choice[0][LLMChatKeys.message][LLMChatKeys.content]
            self.logger.debug(response)

            if response:
                return postprocess_text(str(response), self.attributes.pattern, self.attributes.keep_before)
            return None
        return None

    def _parse_json_response(self, response: str) -> dict[str, Any] | None:
        """Attempts to parse a JSON response string into a dictionary.

        Args:
            response (str): The raw response string to parse.

        Returns:
            dict[str, Any] | None: The parsed dictionary if valid JSON, None otherwise.
        """
        try:
            parsed = json.loads(response)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            self.logger.warning(f"Failed to parse structured output as JSON: {response[:200]}")
        return None

    def generate_response(self, container: DataContainer) -> DataContainer:
        """Processes text packets and generates responses, parsing JSON for structured outputs.

        Extends the base class behavior by parsing JSON responses into the packet's
        generic_data when response_format type is 'json_object'. The raw string is
        always preserved as the content for compatibility with TextPacket.n_tokens.

        Args:
            container (DataContainer): Container with incoming messages.

        Returns:
            DataContainer: Updated DataContainer with the LLM responses.
        """
        self.logger.debug("Chatbot in progress")
        responses = []
        for packet in container.texts:
            full_context = []
            user_id, session_id, prompt = self.prepare_conversation_context(packet)
            if self.system_prompt:
                system_prompt_msg = self.generate_dict_msg(LLMChatKeys.system_value, self.system_prompt)
                full_context.append(system_prompt_msg)

            if self.attributes.chat_history_key:
                full_context.extend(packet.generic_data.get(self.attributes.chat_history_key, []))

            message = self.generate_dict_msg(LLMChatKeys.user_value, prompt)
            full_context.append(message)
            response = self.infer(full_context)
            self.logger.debug("End of interaction.")
            if response:
                generic_data: dict[str, Any] = {}
                if self.attributes.completion_args.response_format.type_ == "json_object":
                    parsed = self._parse_json_response(response)
                    if parsed is not None:
                        generic_data[self.attributes.structure_output_key] = parsed
                responses.append(TextPacket(source=session_id, content=response, id=user_id, generic_data=generic_data))

        container.texts.extend(responses)
        return container

    def _shut_down(self) -> None:
        """Manually closes the LLaMA model to prevent C++ garbage collection errors."""
        if hasattr(self, "llm") and self.llm is not None:
            self.llm.close()
