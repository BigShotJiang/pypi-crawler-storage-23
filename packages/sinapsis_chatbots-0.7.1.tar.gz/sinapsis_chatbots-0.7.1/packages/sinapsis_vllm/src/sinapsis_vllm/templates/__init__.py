import importlib
from collections.abc import Callable

_root_lib_path = "sinapsis_vllm.templates"

_template_lookup = {
    "vLLMBatchTextCompletion": f"{_root_lib_path}.vllm_batch_text_completion",
    "vLLMMultiModal": f"{_root_lib_path}.vllm_multimodal",
    "vLLMStreamingTextCompletion": f"{_root_lib_path}.vllm_streaming_text_completion",
    "vLLMTextCompletion": f"{_root_lib_path}.vllm_text_completion",
}


def __getattr__(name: str) -> Callable:
    """Dynamically retrieves a template by name from the internal lookup.

    Args:
        name: The name of the template to retrieve.

    Returns:
        Callable: The requested template object.

    Raises:
        AttributeError: If the template name is not found in the lookup table.
    """
    if name in _template_lookup:
        module = importlib.import_module(_template_lookup[name])
        return getattr(module, name)
    raise AttributeError(f"template `{name}` not found in {_root_lib_path}")


__all__ = list(_template_lookup.keys())
