class vLLMMultiModalKeys:
    """Keys for OpenAI-compatible multipart content used by vLLM.

    Keys:
        type (str): Key for the content part type.
        text (str): Value for text content parts.
        image_url (str): Value for image URL content parts.
        url (str): Key for the URL within an image_url part.
    """

    type: str = "type"
    text: str = "text"
    image_url: str = "image_url"
    url: str = "url"
