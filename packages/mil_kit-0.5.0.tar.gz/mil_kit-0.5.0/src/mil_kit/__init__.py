def main() -> None:
    print("Hello from psd-toolkit!")
