from enum import Enum

class PostPublicEnvelopeGetResponse200DocumentsItemBlocksAdditionalPropertyItemType3Color(str, Enum):
    AUXILIARY = "auxiliary"
    DANGER = "danger"
    GRAPE = "grape"
    INFO = "info"
    LIME = "lime"
    PINK = "pink"
    PRIMARY = "primary"
    SUCCESS = "success"
    TEAL = "teal"
    WARNING = "warning"

    def __str__(self) -> str:
        return str(self.value)
