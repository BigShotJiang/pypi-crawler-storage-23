# Copyright 2025 Subnoto
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import Any, Dict, Optional, Union

import httpx

from .session import SessionManager, SyncSessionManager
from .transport import TunnelTransport, SyncTunnelTransport
from .types import SubnotoConfig
from .generated.client import Client as GeneratedClient


class GeneratedClientWrapper:
    """Wrapper to make our httpx client compatible with generated client expectations.
    
    Supports both async and sync httpx clients — the generated API functions
    use get_async_httpx_client() for .asyncio() calls and get_httpx_client() for .sync() calls.
    """
    
    def __init__(self, httpx_client: Union[httpx.AsyncClient, httpx.Client]):
        self._httpx_client = httpx_client
        self.raise_on_unexpected_status = False
    
    def get_async_httpx_client(self) -> httpx.AsyncClient:
        if not isinstance(self._httpx_client, httpx.AsyncClient):
            raise NotImplementedError("Async client not available in sync mode")
        return self._httpx_client
    
    def get_httpx_client(self) -> httpx.Client:
        if not isinstance(self._httpx_client, httpx.Client):
            raise NotImplementedError("Sync client not available in async mode")
        return self._httpx_client


class SubnotoClient:
    """
    Async Subnoto API client with Oak tunnel encryption and HTTP signature authentication.
    
    Usage with generated API functions:
        from subnoto_api_client.generated.api.utils import post_public_utils_whoami
        response = await post_public_utils_whoami.asyncio(client=client.generated, body=...)
    
    Or with lower-level httpx methods:
        response = await client.get("/public/utils/whoami")
    """
    
    def __init__(self, config: SubnotoConfig):
        self.config = config
        self.session_manager = SessionManager(config)
        
        transport = TunnelTransport(self.session_manager, config.access_key, config.secret_key)
        self._client = httpx.AsyncClient(
            base_url=config.api_base_url, transport=transport, timeout=30.0
        )
        self.session_manager.http_client = self._client
        self.generated = GeneratedClientWrapper(self._client)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    async def close(self) -> None:
        await self._client.aclose()
        self.session_manager.destroy()
    
    async def get(
        self, path: str, *,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return await self._client.get(path, params=params, headers=headers)
    
    async def post(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return await self._client.post(path, json=json, content=data, headers=headers)
    
    async def put(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return await self._client.put(path, json=json, content=data, headers=headers)
    
    async def delete(
        self, path: str, *,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return await self._client.delete(path, headers=headers)
    
    async def patch(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return await self._client.patch(path, json=json, content=data, headers=headers)
    
    def get_attestation_results(self) -> Optional[str]:
        return self.session_manager.get_attestation_results()
    
    def get_attestation_status(self) -> Optional[str]:
        return self.session_manager.get_attestation_status()


class SubnotoSyncClient:
    """
    Sync Subnoto API client with Oak tunnel encryption and HTTP signature authentication.
    
    Usage with generated API functions:
        from subnoto_api_client.generated.api.utils import post_public_utils_whoami
        response = post_public_utils_whoami.sync(client=client.generated, body=...)
    
    Or with lower-level httpx methods:
        response = client.get("/public/utils/whoami")
    """
    
    def __init__(self, config: SubnotoConfig):
        self.config = config
        self.session_manager = SyncSessionManager(config)
        
        transport = SyncTunnelTransport(self.session_manager, config.access_key, config.secret_key)
        self._client = httpx.Client(
            base_url=config.api_base_url, transport=transport, timeout=30.0
        )
        self.session_manager.http_client = self._client
        self.generated = GeneratedClientWrapper(self._client)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def close(self) -> None:
        self._client.close()
        self.session_manager.destroy()
    
    def get(
        self, path: str, *,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return self._client.get(path, params=params, headers=headers)
    
    def post(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return self._client.post(path, json=json, content=data, headers=headers)
    
    def put(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return self._client.put(path, json=json, content=data, headers=headers)
    
    def delete(
        self, path: str, *,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return self._client.delete(path, headers=headers)
    
    def patch(
        self, path: str, *,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> httpx.Response:
        return self._client.patch(path, json=json, content=data, headers=headers)
    
    def get_attestation_results(self) -> Optional[str]:
        return self.session_manager.get_attestation_results()
    
    def get_attestation_status(self) -> Optional[str]:
        return self.session_manager.get_attestation_status()
