# Copyright 2025 Subnoto
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
Transport layer with tunnel encryption and HTTP signature authentication.
Provides both async (TunnelTransport) and sync (SyncTunnelTransport) implementations.
"""

from typing import TYPE_CHECKING

import httpx

from .middleware.signature_utils import sign_request_headers
from .types import SubnotoError

if TYPE_CHECKING:
    from .session import _BaseSessionManager


# --- Shared helpers ---

def _needs_encryption(host: str, path: str, method: str) -> bool:
    is_local = "localhost" in host or "127.0.0.1" in host
    return not is_local and (
        path.startswith("/tunnel/") or (path.startswith("/public/") and method != "GET")
    )


def _prepare_encrypted(
    session_manager: "_BaseSessionManager",
    access_key: str,
    secret_key: str,
    request: httpx.Request,
    body: bytes,
):
    """Encrypt body and build signed headers. Returns (encrypted_content, headers_dict)."""
    encrypted = session_manager.encrypt_request(body)
    
    session_id = session_manager.get_session_id()
    if not session_id:
        raise SubnotoError("Session ID not available")
    
    headers = dict(sign_request_headers(
        url=str(request.url), method=request.method, body_content=encrypted,
        access_key=access_key, secret_key=secret_key,
        existing_headers={"content-type": "application/octet-stream"}
    ))
    headers["X-Session-Id"] = session_id
    
    original_ct = request.headers.get("content-type", "")
    if "multipart/form-data" in original_ct:
        headers["X-Original-Content-Type"] = original_ct
    
    cookies = session_manager._get_cookies_for_request(str(request.url))
    if cookies:
        headers["Cookie"] = cookies
    
    return encrypted, headers


def _prepare_signed(
    session_manager: "_BaseSessionManager",
    access_key: str,
    secret_key: str,
    request: httpx.Request,
    body: bytes,
):
    """Sign request and build headers. Returns headers dict."""
    headers = dict(sign_request_headers(
        url=str(request.url), method=request.method, body_content=body,
        access_key=access_key, secret_key=secret_key,
        existing_headers=dict(request.headers)
    ))
    
    cookies = session_manager._get_cookies_for_request(str(request.url))
    if cookies:
        headers["Cookie"] = cookies
    
    return headers


def _make_request(original: httpx.Request, headers: dict, content: bytes) -> httpx.Request:
    return httpx.Request(
        method=original.method, url=original.url,
        headers=headers, content=content, extensions=original.extensions
    )


def _decrypt_response(
    session_manager: "_BaseSessionManager",
    response: httpx.Response,
    content: bytes,
    original_request: httpx.Request,
) -> httpx.Response:
    decrypted = session_manager.decrypt_response(content)
    return httpx.Response(
        status_code=response.status_code,
        headers=response.headers,
        content=decrypted,
        request=original_request,
    )


# --- Async transport ---

class TunnelTransport(httpx.AsyncHTTPTransport):
    """Async transport with tunnel encryption and signatures"""
    
    def __init__(self, session_manager, access_key: str, secret_key: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.session_manager = session_manager
        self.access_key = access_key
        self.secret_key = secret_key
    
    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path
        
        if path == "/tunnel/session":
            return await super().handle_async_request(request)
        
        if _needs_encryption(str(request.url.host), path, request.method):
            await self.session_manager.ensure_session()
            await request.aread()
            
            encrypted, headers = _prepare_encrypted(
                self.session_manager, self.access_key, self.secret_key, request, request.content
            )
            response = await super().handle_async_request(_make_request(request, headers, encrypted))
            
            if response.headers.get("x-subnoto-encrypted-response") == "true":
                content = await response.aread()
                response = _decrypt_response(self.session_manager, response, content, request)
        else:
            await request.aread()
            body = request.content if request.content else b""
            
            headers = _prepare_signed(
                self.session_manager, self.access_key, self.secret_key, request, body
            )
            response = await super().handle_async_request(_make_request(request, headers, body))
        
        self.session_manager._store_cookies(response, str(request.url))
        return response


# --- Sync transport ---

class SyncTunnelTransport(httpx.HTTPTransport):
    """Sync transport with tunnel encryption and signatures"""
    
    def __init__(self, session_manager, access_key: str, secret_key: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.session_manager = session_manager
        self.access_key = access_key
        self.secret_key = secret_key
    
    def handle_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path
        
        if path == "/tunnel/session":
            return super().handle_request(request)
        
        if _needs_encryption(str(request.url.host), path, request.method):
            self.session_manager.ensure_session()
            request.read()
            
            encrypted, headers = _prepare_encrypted(
                self.session_manager, self.access_key, self.secret_key, request, request.content
            )
            response = super().handle_request(_make_request(request, headers, encrypted))
            
            if response.headers.get("x-subnoto-encrypted-response") == "true":
                content = response.read()
                response = _decrypt_response(self.session_manager, response, content, request)
        else:
            request.read()
            body = request.content if request.content else b""
            
            headers = _prepare_signed(
                self.session_manager, self.access_key, self.secret_key, request, body
            )
            response = super().handle_request(_make_request(request, headers, body))
        
        self.session_manager._store_cookies(response, str(request.url))
        return response
