import subprocess
import sys
from pathlib import Path
from tkinter import Toplevel, Text, Scrollbar, VERTICAL, RIGHT, Y, LEFT, BOTH
from tkinter.messagebox import showerror
from thonny import get_workbench, get_runner
from tkinter.messagebox import showerror, showinfo


# binary selector for system
def get_blvflag_binary():
    bin_dir = Path(__file__).parent / "bin"

    if sys.platform.startswith("win"):
        return bin_dir / "blvflag.exe"
    else:
        return bin_dir / "blvflag"


# makes directories (for windows)
def make_dirs():
    home = Path.home()
    base = home / "blvflag" / "tool" / "history"
    (base / "std_history").mkdir(parents=True, exist_ok="True")
    (base / "err_history").mkdir(parents=True, exist_ok="True")


# runs tool with flags
def run_blvdiff(flags=None):
    flags = flags or []

    wb = get_workbench()

    editor = wb.get_editor_notebook().get_current_editor()
    if editor is None:
        showerror("BLVDIFF", "No open script.")
        return

    file_path = editor.get_filename()
    if file_path is None:
        showerror("BLVDIFF", "Please save.")
        return

    editor.save_file()
    editor.get_text_widget().update_idletasks()

    bin_path = get_blvflag_binary()
    if not bin_path.exists():
        showerror("BLVDIFF", f"blvflag binary not found:\n{bin_path}")
        return

    cmd = [str(bin_path)] + flags + [file_path]
    try:
        result = subprocess.run(cmd, text=True, capture_output=True, check=True)
        if "--revert" in flags:
            editor = wb.get_editor_notebook().get_current_editor()
            if editor:
                editor._load_file(editor.get_filename())

    except Exception as e:
        showerror("BLVDIFF", f"Failed to run blvflag:\n{e}")
        return


    show_output(result.stdout, result.stderr)


# sets up the api key
def setup():
    bin_path = get_blvflag_binary()
    if not bin_path.exists():
        showerror("BLVDIFF", f"blvflag binary not found:\n{bin_path}")
        return

    cmd = [str(bin_path), "setup"]

    try:
       auth_key="get_blv_key\n"
       subprocess.run(cmd, input=auth_key, text=True, check=True)

       make_dirs()
   
       showinfo(
            "BLVDIFF",
            "Setup complete.\n\nAPI key downloaded successfully."
        )
    except subprocess.CalledProcessError as e:
        showerror("BLVDIFF", f"Setup failed:\n{e}")
        return
    except Exception as e:
        showerror("BLVDIFF", f"Failed to run blvflag setup:\n{e}")
        return


# output - TODO: stderr?
def show_output(stdout, stderr):
    top = Toplevel()
    top.title("BLVDIFF")
    text = Text(top, wrap="none")
    text.pack(side=LEFT, fill=BOTH, expand=True)
    scrollbar = Scrollbar(top, orient=VERTICAL, command=text.yview)
    scrollbar.pack(side=RIGHT, fill=Y)
    text.configure(yscrollcommand=scrollbar.set)
    text.insert("end", stdout)
    text.configure(state="disabled")


# loads the plugin and places the menu options in tool
def load_plugin():
    wb = get_workbench()

    wb.add_command(
        "blvdiff.setup",
        "tools",
        "BLVDIFF: Setup",
        setup,
        group=90,
    )
    wb.add_command(
        "blvdiff.run",
        "tools",
        "BLVDIFF: Run Script",
        lambda: run_blvdiff([]),
        group=90,
    )
    wb.add_command(
        "blvdiff.explain",
        "tools",
        "BLVDIFF: --explain",
        lambda: run_blvdiff(["--explain"]),
        group=90,
    )
    wb.add_command(
        "blvdiff.diff",
        "tools",
        "BLVDIFF: --diff",
        lambda: run_blvdiff(["--diff"]),
        group=90,
    )
    wb.add_command(
        "blvdiff.revert",
        "tools",
        "BLVDIFF: --revert",
        lambda: run_blvdiff(["--revert"]),
        group=90,
    )

