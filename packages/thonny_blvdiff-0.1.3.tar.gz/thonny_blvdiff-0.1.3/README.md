# thonnycontrib-blvdiff

BLVDIFF integration plugin for Thonny.

Install from PyPI:

	pip install thonnycontrib-blvdiff

The plugin will be discovered automatically. Use the Tools menu to access BLVDIFF actions (Setup, Run Script, --explain, --diff, --revert).


License: MIT (see LICENSE)
