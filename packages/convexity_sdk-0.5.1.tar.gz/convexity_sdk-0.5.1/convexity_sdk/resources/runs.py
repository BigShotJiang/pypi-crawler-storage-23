"""Run resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    cancel_run_v1_run_cancel_run_id_post as _cancel_run,
)
from convexity_api_client.api.v1 import (
    create_and_start_run_v1_run_create_and_start_post as _create_and_start_run,
)
from convexity_api_client.api.v1 import (
    delete_run_v1_run_delete_run_id_delete as _delete_run,
)
from convexity_api_client.api.v1 import (
    get_run_status_v1_run_status_run_id_get as _get_run_status,
)
from convexity_api_client.models.cancel_run_response import CancelRunResponse
from convexity_api_client.models.create_run_request import CreateRunRequest
from convexity_api_client.models.create_run_response import CreateRunResponse
from convexity_api_client.models.delete_run_response import DeleteRunResponse
from convexity_api_client.models.run import Run


class Runs:
    """Synchronous sub-client for run operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def create_and_start(self, *, body: CreateRunRequest) -> CreateRunResponse:
        """Create a new run and start it immediately."""
        result = _create_and_start_run.sync(client=self._client, body=body)
        if not isinstance(result, CreateRunResponse):
            raise ValueError(f"Unexpected response when creating run: {result}")
        return result

    def get_status(self, run_id: str) -> Run:
        """Get the current status of a run."""
        result = _get_run_status.sync(run_id, client=self._client)
        if not isinstance(result, Run):
            raise ValueError(f"Unexpected response when fetching run status: {result}")
        return result

    def cancel(self, run_id: str) -> CancelRunResponse:
        """Cancel a running execution."""
        result = _cancel_run.sync(run_id, client=self._client)
        if not isinstance(result, CancelRunResponse):
            raise ValueError(f"Unexpected response when cancelling run: {result}")
        return result

    def delete(self, run_id: str) -> DeleteRunResponse:
        """Delete a run (only if not currently running)."""
        result = _delete_run.sync(run_id, client=self._client)
        if not isinstance(result, DeleteRunResponse):
            raise ValueError(f"Unexpected response when deleting run: {result}")
        return result
