# Convexity SDK

Python SDK for the Convexity platform.

## Installation

```bash
pip install convexity-sdk
```

## Usage

```python
import convexity_sdk
```
