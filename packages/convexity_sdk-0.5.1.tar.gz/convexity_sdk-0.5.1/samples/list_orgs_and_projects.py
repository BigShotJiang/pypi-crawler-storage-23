"""
Convexity SDK - List Organizations & Projects

This sample demonstrates how to:
- List all organizations the authenticated user belongs to
- List all projects within each organization

The SDK uses the generated ``convexity_api_client`` models, so return
types like ``OrganizationListResponse`` and ``ProjectListResponse``
come directly from the OpenAPI spec.

Prerequisites:
- A valid API key configured via environment variable, .convexity/config.yaml,
  or ~/.convexity/config.yaml
"""

from convexity_sdk import ConvexityClient

client = ConvexityClient()

# ── List all organizations ──────────────────────────────────────────────
org_list = client.organizations.list()
print(f"Found {org_list.total} organization(s):\n")

for org in org_list.organizations:
    role = org.current_user_role or "unknown"
    print(f"  • {org.name} (slug={org.slug}, role={role})")
    if org.description:
        print(f"    {org.description}")
    print(f"    members={org.member_count}  projects={org.project_count}")

    # ── List projects under this organization ───────────────────────────
    proj_list = client.projects.list_by_organization(org.id)
    if proj_list.total == 0:
        print("    (no projects)")
    for proj in proj_list.projects:
        print(f"      └─ {proj.name} (slug={proj.slug})")
        if proj.description:
            print(f"         {proj.description}")

    print()

client.close()
