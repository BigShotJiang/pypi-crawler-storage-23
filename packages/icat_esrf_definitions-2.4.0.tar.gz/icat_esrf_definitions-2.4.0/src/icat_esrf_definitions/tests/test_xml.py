import xml.etree.ElementTree as ET

from .. import DEFINITIONS_FILE
from ..models import IcatDataset
from . import xml_utils


def test_xml_dict():
    xml_dict_from_file = xml_utils.read_xml(DEFINITIONS_FILE)
    xml_dict_from_model = IcatDataset.to_xml_dict()
    assert xml_dict_from_model == xml_dict_from_file


def test_xml_file(tmp_path):
    with open(DEFINITIONS_FILE, "r", encoding="utf-8") as f:
        xml_str_from_file = f.read()

    filename = str(tmp_path / "test.xml")
    IcatDataset.to_xml_file(filename)

    with open(DEFINITIONS_FILE, "r", encoding="utf-8") as f:
        xml_str_from_model = f.read()

    assert xml_str_from_file == xml_str_from_model


def test_nexus_fied():
    model_dict = {
        "title": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "folder_path": "dummy folder_path",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"name": "dummy sample"},
    }
    model_dict["instrument"] = {"laser01": {"name": "laser1"}}
    model = IcatDataset(**model_dict)
    xml_str = model.to_xml_string(group_name="${entry}")

    root = ET.fromstring(xml_str)

    instrument_group = root.find(".//group[@groupName='instrument']")
    assert instrument_group is not None

    laser_group = instrument_group.find(".//group[@groupName='laser01']")
    assert laser_group is not None

    name_elem = laser_group.find("name")
    assert name_elem is not None

    assert name_elem.text == "${InstrumentLaser01_name}"

    description = name_elem.attrib.get("ESRF_description", "")
    assert (
        "See https://manual.nexusformat.org/classes/base_classes/NXsource.html#nxsource-name-field"
        in description
    )
