from silx.io.dictdump import dicttonx

from ..models import IcatDataset
from ..models.generate import generate_dataset
from . import compare


def test_nexus(tmp_path):
    dataset = generate_dataset()
    nxdict = dataset.to_nexus_dict()
    filename = str(tmp_path / "dataset.h5")
    dicttonx(nxdict, filename)


def test_icat():
    dataset = generate_dataset()
    icatdict = dataset.to_icat_dict()
    for key, value in icatdict.items():
        assert isinstance(key, str), key
        assert isinstance(value, str), f"{key} = {value}"


def test_roundtrip():
    dataset = generate_dataset()

    python_dict = dataset.model_dump(mode="python", exclude_unset=True, by_alias=True)
    new_dataset = IcatDataset(**python_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    json_dict = dataset.model_dump(mode="json", exclude_unset=True, by_alias=True)
    new_dataset = IcatDataset(**json_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    nexus_dict = dataset.to_nexus_dict()
    new_dataset = IcatDataset.from_nexus_dict(nexus_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    # TODO: Several ICAT fields are not recognized by IcatDataset.from_icat_dict
    # icat_dict = dataset.to_icat_dict()
    # new_dataset = IcatDataset.from_icat_dict(icat_dict)
    # compare.assert_equal_pydantic_model(new_dataset, dataset)
