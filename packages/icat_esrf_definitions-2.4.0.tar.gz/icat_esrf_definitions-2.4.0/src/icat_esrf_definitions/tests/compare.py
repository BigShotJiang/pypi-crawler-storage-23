from typing import Any
from typing import Dict

import numpy
import pint

from ..models.base.model import IcatBaseModel


def assert_equal_pydantic_model(actual: IcatBaseModel, expected: IcatBaseModel):
    assert_equal_serialize_models(actual.model_dump(), expected.model_dump())


def assert_equal_serialize_models(
    actual: Dict[str, Any], expected: Dict[str, Any]
) -> None:
    actual = _make_comparable(actual)
    expected = _make_comparable(expected)
    assert actual == expected


def _make_comparable(obj: Any) -> Any:
    if isinstance(obj, numpy.ndarray):
        return "__ndarray__", obj.tolist()
    elif isinstance(obj, pint.Quantity):
        return "__Quantity__", _make_comparable(obj.magnitude), obj.units
    elif isinstance(obj, dict):
        return {k: _make_comparable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_make_comparable(v) for v in obj]
    else:
        return obj
