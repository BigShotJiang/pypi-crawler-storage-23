from copy import deepcopy
from datetime import datetime

import pint
import pytest
from pydantic import ValidationError

from ..models import IcatDataset
from ..models.base.custom_types._metadata.quantity import REGISTRY
from . import compare


def test_entry():
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_value_with_units():
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["PTYCHO"] = {"beamSize": (0.001, "mm")}
    python_dict["PTYCHO"] = {"beamSize": REGISTRY.Quantity(1, "um")}
    json_dict["PTYCHO"] = {"beamSize": 1.0}
    nexus_dict["PTYCHO"] = {
        "@NX_class": "NXsubentry",
        "beamSize": 1.0,
        "beamSize@units": "µm",
    }
    icat_dict["PTYCHO_beamSize"] = "1.0"
    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_wrong_value():
    input_dict, *_ = _entry_data()
    input_dict["PTYCHO"] = {"non_existing": 42}
    with pytest.raises(ValidationError):
        _ = IcatDataset(**input_dict)


def test_icat_fields():
    fields = IcatDataset.icat_fields()
    field_names = IcatDataset.icat_field_names()
    assert list(fields) == list(field_names)


def test_json_schema():
    model_json_schema = IcatDataset.model_json_schema()
    json_schema = model_json_schema["$defs"]["IcatPtycho"]["properties"]["beamSize"]
    expected = {
        "anyOf": [
            {
                "description": "Physical quantity represented as a [magnitude, "
                "unit_string] pair. The value will be converted to "
                "'µm' during validation.",
                "items": [
                    {"description": "Magnitude of the quantity", "type": "number"},
                    {
                        "description": "Unit symbol (e.g., 'mm', 'µm', 'kg')",
                        "type": "string",
                    },
                ],
                "maxItems": 2,
                "minItems": 2,
                "type": "array",
            },
            {"type": "null"},
        ],
        "default": None,
        "description": "Beam size on the sample in microns",
        "record": "final",
        "include_nexus_url": False,
        "title": "Beamsize",
    }

    assert json_schema == expected


@pytest.mark.parametrize(
    "input_value, expected",
    [
        (["Alice", "Bob", "John"], ["Alice", "Bob", "John"]),
        (["Alice"], ["Alice"]),
        ([], []),
        ("", []),
        ("Alice", ["Alice"]),
        ("Alice, Bob, John", ["Alice", "Bob", "John"]),
        (" Alice , Bob , John ", ["Alice", "Bob", "John"]),
    ],
    ids=[
        "multi_items",
        "single_item",
        "empty_list",
        "empty_string",
        "single_string",
        "multi_string",
        "multi_string_spaces",
    ],
)
def test_comma_separated_list(input_value, expected):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["external_references"] = {"datacollector": {"endnote": input_value}}
    python_dict["external_references"] = {"datacollector": {"endnote": expected}}
    json_dict["external_references"] = {"datacollector": {"endnote": expected}}
    nexus_dict["external_references"] = {
        "@NX_class": "NXnote",
        "datacollector": {
            "@NX_class": "NXcite",
            "endnote": expected,
        },
    }
    icat_dict["ExternalReferencesDatacollector_endnote"] = ",".join(expected)

    model = IcatDataset(**input_dict)
    assert model.external_references.datacollector.endnote == expected

    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_comma_separated_list_invalid_type():
    input_dict, *_ = _entry_data()
    input_dict["external_references"] = {
        "datacollector": {"endnote": bytearray(b"invalid")}
    }
    with pytest.raises(TypeError):
        _ = IcatDataset(**input_dict)


def test_comma_separated_list_invalid_separator():
    input_dict, *_ = _entry_data()
    input_dict["external_references"] = {
        "datacollector": {"endnote": ["Alice", "Bob,John"]}
    }

    with pytest.raises(ValueError, match=r"List element contains separator"):
        _ = IcatDataset(**input_dict)


@pytest.mark.parametrize(
    "input_value, expected",
    [
        (["Technique1"], ["Technique1"]),
        ([], []),
        ("", []),
        ("Technique1", ["Technique1"]),
        (
            "Technique1 Technique2 Technique3",
            ["Technique1", "Technique2", "Technique3"],
        ),
        (
            " Technique1   Technique2     Technique3 ",
            ["Technique1", "Technique2", "Technique3"],
        ),
        (["1", "2.0"], ["1", "2.0"]),
    ],
    ids=[
        "single_item",
        "empty_list",
        "empty_string",
        "single_string",
        "multi_string",
        "multi_string_spaces",
        "multi_item",
    ],
)
def test_space_separated_list(input_value, expected):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["definition"] = input_value
    python_dict["definition"] = expected
    json_dict["definition"] = expected
    nexus_dict["definition"] = expected
    icat_dict["definition"] = " ".join(expected)

    model = IcatDataset(**input_dict)
    assert model.definition == expected
    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


@pytest.mark.parametrize(
    "input_value, expected",
    [
        ([1.0], [1.0]),
        ([1.1, 2.2, 3.3], [1.1, 2.2, 3.3]),
        (1, [1.0]),
        ([], []),
        (
            "1.0 2.0 3.0 ",
            [1.0, 2.0, 3.0],
        ),
    ],
    ids=["single_item", "multi_items", "number", "empty_list", "multi_string"],
)
def test_space_separated_list_float(input_value, expected):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["instrument"] = {"beam": {"incident_wavelength_weights": input_value}}
    python_dict["instrument"] = {"beam": {"incident_wavelength_weights": expected}}
    json_dict["instrument"] = {"beam": {"incident_wavelength_weights": expected}}
    nexus_dict["instrument"] = {
        "@NX_class": "NXinstrument",
        "beam": {
            "@NX_class": "NXbeam",
            "incident_wavelength_weights": expected,
        },
    }
    icat_dict["InstrumentBeam_incident_wavelength_weights"] = " ".join(
        map(str, expected)
    )

    model = IcatDataset(**input_dict)
    assert model.instrument.beam.incident_wavelength_weights == expected

    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_space_separated_list_invalid_type():
    input_dict, *_ = _entry_data()
    input_dict["definition"] = bytearray(b"invalid")
    with pytest.raises(TypeError):
        _ = IcatDataset(**input_dict)


def test_space_separated_list_invalid_separator():
    input_dict, *_ = _entry_data()
    input_dict["definition"] = ["Technique1 Technique2", "Technique3"]

    with pytest.raises(ValueError, match=r"List element contains separator"):
        _ = IcatDataset(**input_dict)


@pytest.mark.parametrize(
    "input_value, expected",
    [
        (
            [["Smith", "Alice", "0000-0000-0000-0000"], ["Doe", "John"]],
            [["Smith", "Alice", "0000-0000-0000-0000"], ["Doe", "John"]],
        ),
        ([], []),
        ("", []),
        (
            "Smith, Alice, 0000-0000-0000-0000",
            [["Smith", "Alice", "0000-0000-0000-0000"]],
        ),
        (
            "Smith, Alice, 0000-0000-0000-0000; Doe, John",
            [["Smith", "Alice", "0000-0000-0000-0000"], ["Doe", "John"]],
        ),
        (
            " Smith, Alice, 0000-0000-0000-0000 ;   Doe, John    ",
            [["Smith", "Alice", "0000-0000-0000-0000"], ["Doe", "John"]],
        ),
    ],
    ids=[
        "multi_items",
        "empty_list",
        "empty_string",
        "single_string",
        "multi_string",
        "multi_string_spaces",
    ],
)
def test_doi_users_list(input_value, expected):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["doi_users"] = input_value
    python_dict["doi_users"] = expected
    json_dict["doi_users"] = expected
    nexus_dict["doi_users"] = expected
    icat_dict["DOI_users"] = ";".join([",".join(u) for u in expected])

    model = IcatDataset(**input_dict)
    assert model.doi_users == expected

    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_doi_users_list_invalid_type():
    input_dict, *_ = _entry_data()
    input_dict["doi_users"] = bytearray(b"invalid")
    with pytest.raises(TypeError):
        _ = IcatDataset(**input_dict)


def test_doi_users_list_invalid_separator():
    input_dict, *_ = _entry_data()
    input_dict["doi_users"] = (
        [["Smith", "Alice", "0000-0000-0000-0000"], ["Doe;Smith", "John"]],
    )

    with pytest.raises(ValueError, match=r"List element contains separator"):
        _ = IcatDataset(**input_dict)


@pytest.mark.parametrize(
    "input_value, expected",
    [
        (
            [(1, 2), (3, 4)],
            [(1, 2), (3, 4)],
        ),
        ([], []),
        ("", []),
        (
            "1,2",
            [(1, 2)],
        ),
        (
            "1,2 3,4",
            [(1, 2), (3, 4)],
        ),
        (
            " 1,2    3,4    ",
            [(1, 2), (3, 4)],
        ),
    ],
    ids=[
        "multi_items",
        "empty_list",
        "empty_string",
        "single_string",
        "multi_string",
        "multi_string_spaces",
    ],
)
def test_roi_list(input_value, expected):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["instrument"] = {"detector01": {"rois": {"value": input_value}}}
    python_dict["instrument"] = {"detector01": {"rois": {"value": expected}}}
    json_dict["instrument"] = {
        "detector01": {"rois": {"value": list(map(list, expected))}}
    }
    nexus_dict["instrument"] = {
        "@NX_class": "NXinstrument",
        "detector01": {
            "@NX_class": "NXdetector",
            "rois": {"@NX_class": "NXcollection", "value": expected},
        },
    }
    icat_dict["InstrumentDetector01Rois_value"] = " ".join(
        [",".join(map(str, roi)) for roi in expected]
    )

    model = IcatDataset(**input_dict)
    assert model.instrument.detector01.rois.value == expected

    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def test_roi_list_invalid_type():
    input_dict, *_ = _entry_data()
    input_dict["instrument"] = {
        "detector01": {"rois": {"value": bytearray(b"invalid")}}
    }
    with pytest.raises(TypeError):
        _ = IcatDataset(**input_dict)


@pytest.mark.parametrize(
    "input_value, expected",
    [
        (([10, 20, 30], "keV"), REGISTRY.Quantity([10.0, 20.0, 30.0], "keV")),
        (([0.1, 0.2], "MeV"), REGISTRY.Quantity([100.0, 200.0], "keV")),
        (([], "MeV"), REGISTRY.Quantity([], "keV")),
    ],
    ids=["same_unit", "unit_conversion", "empty"],
)
def test_incident_energy_array(input_value, expected: pint.Quantity):
    input_dict, python_dict, json_dict, nexus_dict, icat_dict = _entry_data()
    input_dict["instrument"] = {"beam": {"incident_energy": input_value}}
    python_dict["instrument"] = {"beam": {"incident_energy": expected}}
    json_dict["instrument"] = {"beam": {"incident_energy": expected.magnitude.tolist()}}
    nexus_dict["instrument"] = {
        "@NX_class": "NXinstrument",
        "beam": {
            "@NX_class": "NXbeam",
            "incident_energy": expected.magnitude,
            "incident_energy@units": "keV",
        },
    }
    icat_dict["InstrumentBeam_incident_energy"] = " ".join(
        str(x) for x in expected.magnitude
    )

    model = IcatDataset(**input_dict)

    q = model.instrument.beam.incident_energy
    assert q is not None
    assert q.magnitude.tolist() == expected.magnitude.tolist()
    assert q.units == expected.units

    _assert_round_trip(input_dict, python_dict, json_dict, nexus_dict, icat_dict)


def _entry_data():
    input_dict = {
        "title": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "folder_path": "dummy folder_path",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"name": "dummy sample"},
    }
    python_dict = {
        "title": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "folder_path": "dummy folder_path",
        "start_time": datetime.fromisoformat("2032-04-23T10:20:30.400000+02:30"),
        "end_time": datetime.fromisoformat("2032-04-23T10:20:30.400000+02:30"),
        "sample": {"name": "dummy sample"},
    }
    json_dict = {
        "title": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "folder_path": "dummy folder_path",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"name": "dummy sample"},
    }
    nexus_dict = {
        "@NX_class": "NXentry",
        "title": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "folder_path": "dummy folder_path",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"@NX_class": "NXsample", "name": "dummy sample"},
    }
    icat_dict = {
        "datasetName": "dummy title",
        "scanNumber": "dummy scanNumber",
        "proposal": "dummy proposal",
        "location": "dummy folder_path",
        "startDate": "2032-04-23T10:20:30.400000+02:30",
        "endDate": "2032-04-23T10:20:30.400000+02:30",
        "Sample_name": "dummy sample",
    }
    return input_dict, python_dict, json_dict, nexus_dict, icat_dict


def _assert_round_trip(
    input_dict: dict,
    python_dict: dict,
    json_dict: dict,
    nexus_dict: dict,
    icat_dict: dict,
):
    original_input_dict = deepcopy(input_dict)
    original_python_dict = deepcopy(python_dict)
    original_json_dict = deepcopy(json_dict)
    original_nexus_dict = deepcopy(nexus_dict)
    original_icat_dict = deepcopy(icat_dict)

    model = IcatDataset(**input_dict)

    # Check serialization
    dumped_dict = model.model_dump(mode="python", exclude_unset=True, by_alias=True)
    compare.assert_equal_serialize_models(dumped_dict, python_dict)

    dumped_dict = model.model_dump(mode="json", exclude_unset=True, by_alias=True)
    compare.assert_equal_serialize_models(dumped_dict, json_dict)

    dumped_dict = model.to_nexus_dict()
    compare.assert_equal_serialize_models(dumped_dict, nexus_dict)

    dumped_dict = model.to_icat_dict()
    compare.assert_equal_serialize_models(dumped_dict, icat_dict)

    # Check validation
    new_model = IcatDataset(**python_dict)
    compare.assert_equal_pydantic_model(new_model, model)

    new_model = IcatDataset(**json_dict)
    compare.assert_equal_pydantic_model(new_model, model)

    new_model = IcatDataset.from_nexus_dict(nexus_dict)
    compare.assert_equal_pydantic_model(new_model, model)

    new_model = IcatDataset.from_icat_dict(icat_dict)
    compare.assert_equal_pydantic_model(new_model, model)

    # Check that inputs are not modified in-place
    compare.assert_equal_serialize_models(original_input_dict, input_dict)
    compare.assert_equal_serialize_models(original_python_dict, python_dict)
    compare.assert_equal_serialize_models(original_json_dict, json_dict)
    compare.assert_equal_serialize_models(original_nexus_dict, nexus_dict)
    compare.assert_equal_serialize_models(original_icat_dict, icat_dict)
