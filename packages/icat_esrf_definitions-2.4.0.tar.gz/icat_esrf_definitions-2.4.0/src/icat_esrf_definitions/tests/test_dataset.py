from ..models import IcatDataset
from ..models.applications.applications import APPLICATIONS_REGISTRY


def test_dataset_allows_none_for_optional_fields():
    data = {
        "title": "0001",
        "scanNumber": "1",
        "proposal": "hg123",
        "folder_path": "/tmp",
        "start_time": "2025-01-01T08:00:00",
        "end_time": "2025-01-01T05:01:00",
        "sample": {"name": "Sample"},
    }
    assert len(APPLICATIONS_REGISTRY) > 0
    for short_name in APPLICATIONS_REGISTRY:
        data[short_name] = None

    dataset = IcatDataset(**data)
    assert dataset.title == "0001"
    for short_name in APPLICATIONS_REGISTRY:
        assert getattr(dataset, short_name) is None
