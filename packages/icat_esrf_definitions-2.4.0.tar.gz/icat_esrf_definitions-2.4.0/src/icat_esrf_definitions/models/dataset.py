import importlib
import pkgutil
from datetime import datetime
from typing import Optional

from pydantic import create_model

# NeXus applications definitions
from . import applications
from .applications.applications import APPLICATIONS_REGISTRY
from .base.custom_types import CommaSeparatedList
from .base.custom_types import DOIUsersList
from .base.custom_types import SpaceSeparatedList
from .base.metadata_field import MetadataField
from .base.metadata_field import RecordType
from .base.nexus import NXentry
from .base_classes.aperture import IcatAperture
from .base_classes.external_references import IcatExternalReferences
from .base_classes.fresnel_zone_plate import IcatFresnelZonePlate
from .base_classes.instrument import IcatInstrument
from .base_classes.mirror import IcatMirror
from .base_classes.notes import IcatNotes
from .base_classes.process import IcatProcess

# NeXus base classes
from .base_classes.sample import IcatSample
from .base_classes.workflow import IcatWorkflow

for loader, module_name, is_pkg in pkgutil.iter_modules(applications.__path__):
    importlib.import_module(f".{module_name}", package=applications.__package__)


base_fields = {
    "title": (
        str,
        MetadataField(
            ...,
            description="Name of the dataset.",
            icat_name="datasetName",
        ),
    ),
    "scanNumber": (
        str,
        MetadataField(
            ...,
            description="Scan number.",
        ),
    ),
    "proposal": (
        str,
        MetadataField(
            ...,
            description="Proposal name associated with the beamtime or experiment.",
        ),
    ),
    "dataset_type": (
        Optional[str],
        MetadataField(
            None,
            description="Type of scan: either 'step_by_step' or 'continuous'.",
            icat_name="scanType",
            record=RecordType.final,
        ),
    ),
    "folder_path": (
        str,
        MetadataField(
            ...,
            description="Filesystem path where the dataset is stored.",
            icat_name="location",
        ),
    ),
    "start_time": (
        datetime,
        MetadataField(
            ...,
            description="Date and time when the scan or data collection started.",
            icat_name="startDate",
        ),
    ),
    "end_time": (
        datetime,
        MetadataField(
            ...,
            description="Date and time when the scan or data collection ended.",
            icat_name="endDate",
            record=RecordType.final,
        ),
    ),
    "definition": (
        Optional[SpaceSeparatedList[str]],
        MetadataField(
            None,
            description="Techniques used to collect the dataset, provided as a space-separated list.",
        ),
    ),
    "technique_pid": (
        Optional[SpaceSeparatedList[str]],
        MetadataField(
            None,
            description="Identifiers (ESRFET IDs) of the techniques used for this dataset, provided as a space-separated list.",
        ),
    ),
    "technique_pid_esrfet_version": (
        Optional[str],
        MetadataField(
            None,
            description="Version of the ESRFET ontology used for the technique PIDs metadata.",
        ),
    ),
    "doi_abstract": (
        Optional[str],
        MetadataField(
            None,
            description="Abstract or summary associated with the DOI.",
            icat_name="DOI_abstract",
        ),
    ),
    "doi_title": (
        Optional[str],
        MetadataField(
            None,
            description="Title of the publication associated with the DOI.",
            icat_name="DOI_title",
        ),
    ),
    "doi_users": (
        Optional[DOIUsersList],
        MetadataField(
            None,
            description="Users or authors associated with the DOI (first name, last name, and ORCID comma-separated), provided as a semicolon-separated list.",
            icat_name="DOI_users",
        ),
    ),
    "project_name": (
        Optional[str],
        MetadataField(
            None,
            description="Name of the project. A project represents a thematic or domain-focused collection of datasets (e.g. Human Organ Atlas).",
            icat_name="Project_name",
        ),
    ),
    "machine": (
        Optional[str],
        MetadataField(
            None,
            description="Name of the machine that collects the data.",
        ),
    ),
    "software": (
        Optional[str],
        MetadataField(
            None,
            description="Name of the software that collects the data.",
        ),
    ),
    "group_by": (
        Optional[CommaSeparatedList[str]],
        MetadataField(
            None,
            description=(
                "Parameters name that will be used to represent the data acquisition as a tree, provided as a comma-separated list. "
                "Mostly for visualization purposes."
            ),
        ),
    ),
    "complete": (
        Optional[str],
        MetadataField(
            None,
            description=(
                "May be set to true when all data files and parameters have been added to the data set. The precise meaning is facility-dependent."
            ),
        ),
    ),
    "investigationId": (
        Optional[int],
        MetadataField(
            None,
            description="Unique identifier of the investigation (experiment session) in ICAT. It is used during ingestion to associate the correct session to the dataset.",
        ),
    ),
    "sample": (
        IcatSample,
        MetadataField(
            ...,
            description=(
                "Description and metadata about the physical sample used in the experiment."
            ),
        ),
    ),
    "fresnel_zone_plate": (
        Optional[IcatFresnelZonePlate],
        MetadataField(
            None,
            description="Fresnel zone plate information.",
            icat_name="Fresnel__zone__plate",
        ),
    ),
    "aperture": (
        Optional[IcatAperture],
        MetadataField(
            None,
            description="Aperture settings or characteristics.",
        ),
    ),
    "mirror": (
        Optional[IcatMirror],
        MetadataField(
            None,
            description="Mirror configuration or parameters.",
        ),
    ),
    "instrument": (
        Optional[IcatInstrument],
        MetadataField(
            None,
            description="Instrument configuration and settings.",
        ),
    ),
    "notes": (
        Optional[IcatNotes],
        MetadataField(
            None,
            description="Free-form user notes or annotations.",
        ),
    ),
    "process": (
        Optional[IcatProcess],
        MetadataField(
            None,
            description="Post-processing metadata or logs.",
        ),
    ),
    "workflow": (
        Optional[IcatWorkflow],
        MetadataField(
            None,
            description="Workflow steps or automation pipeline.",
        ),
    ),
    "external_references": (
        Optional[IcatExternalReferences],
        MetadataField(
            None,
            description="Linked datasets, publications, or external identifiers associated with this dataset.",
        ),
    ),
}

for short_name, info in APPLICATIONS_REGISTRY.items():
    field_type = Optional[info["class"]]  # noqa: F722 dynamic type construction
    base_fields[short_name] = (
        field_type,
        MetadataField(None, description=info["description"]),
    )


IcatDataset = create_model(
    "IcatDataset",
    __base__=NXentry,
    **base_fields,
)
