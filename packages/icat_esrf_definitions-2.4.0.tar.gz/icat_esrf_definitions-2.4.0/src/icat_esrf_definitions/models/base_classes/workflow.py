from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXprocess


class IcatWorkflow(NXprocess):
    name: Optional[str] = MetadataField(None, description="Name of the workflow.")
    id: Optional[str] = MetadataField(
        None, description="Unique identifier of the workflow."
    )
    type: Optional[str] = MetadataField(
        None, description="Type or category of the workflow."
    )
    status: Optional[str] = MetadataField(
        None, description="Final status of the workflow."
    )
    note: Optional[str] = MetadataField(
        None,
        description="Note or comment from a workflow to provide feedback for users.",
    )
