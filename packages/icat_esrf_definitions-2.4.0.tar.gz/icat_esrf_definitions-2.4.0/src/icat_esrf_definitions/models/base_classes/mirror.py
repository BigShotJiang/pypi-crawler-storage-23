from enum import Enum
from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXgeometry
from ..base.nexus import NXmirror
from ..base.quantity import METERS


class MirrorType(str, Enum):
    single = "single"
    multi = "multi"


class MirrorInteriorAtmosphere(str, Enum):
    vacuum = "vacuum"
    helium = "helium"
    argon = "argon"


class IcatMirrorGeometry(NXgeometry):
    vertical: Optional[str] = MetadataField(
        None,
        description="Vertical coordinate or label. "
        "Present only if this is an additional reference point for components, rather than the location of a physical mirror.",
    )
    horizontal: Optional[str] = MetadataField(
        None,
        description="Horizontal coordinate or reference point of the mirror.",
    )
    transformation: Optional[str] = MetadataField(
        None,
        description="Transformation applied to the mirror's position or orientation.",
    )
    distance: Optional[METERS] = MetadataField(
        None,
        description="Distance of the mirror along the beam path relative to the sample position.",
    )
    component_index: Optional[int] = MetadataField(
        None,
        description="Index of the component along the beam path. "
        "The sample is at 0; upstream components have negative indices, downstream components have positive indices.",
    )


class IcatMirror(NXmirror):
    type: Optional[MirrorType] = MetadataField(
        None,
        description="Type of mirror. Possible values: "
        "'single' (mirror with a single material as a reflecting surface), 'multi' (mirror with stacked, multiple layers as a reflecting surface).",
        include_nexus_url=True,
    )
    description: Optional[str] = MetadataField(
        None, description="Text description of this mirror.", include_nexus_url=True
    )
    interior_atmosphere: Optional[MirrorInteriorAtmosphere] = MetadataField(
        None,
        description="Atmosphere inside the mirror housing. Possible values: 'vacuum', 'helium', 'argon'.",
        include_nexus_url=True,
    )
    substrate_material: Optional[str] = MetadataField(
        None, description="Material of the mirror substrate.", include_nexus_url=True
    )
    coating_material: Optional[str] = MetadataField(
        None,
        description="Material of the mirror coating used to enhance reflectivity.",
        include_nexus_url=True,
    )
    geometry: Optional[IcatMirrorGeometry] = MetadataField(
        None, description="Geometrical information of the mirror."
    )
