from abc import abstractmethod
from numbers import Number
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Sequence
from typing import Tuple
from typing import Type
from typing import Union
from typing import get_args
from typing import get_origin

import numpy
import pint
from pint import Quantity
from pint import Unit
from pint.util import UnitsContainer

from .base import CustomTypeMetadata

NumberInputType = Union[Number, str, None]
UnitsInputType = Union[Unit, UnitsContainer, str, None]
MagnitudeInputType = Union[NumberInputType, Sequence[NumberInputType]]

QuantityInputType = Union[
    Quantity, Sequence[Union[MagnitudeInputType, UnitsInputType]], MagnitudeInputType
]

MagnitudeType = Union[Number, Sequence[Number]]


REGISTRY = pint.UnitRegistry()

try:
    REGISTRY.formatter.default_format = "~P"
except AttributeError:
    REGISTRY.default_format = "~P"

REGISTRY.define("photon = count")
REGISTRY.define("photons = photon")
REGISTRY.define("pixel = []")
REGISTRY.define("pixels = pixel")


class QuantityMeta(CustomTypeMetadata):
    def __init__(self, value_type: Optional[type], json_schema: Dict[str, Any]):
        if value_type is not None:
            origin = get_origin(value_type)
            if origin is None and not isinstance(value_type, type):
                raise ValueError(
                    f"{value_type!r} is not a PydanticQuantity value type."
                )

        self.value_type: Optional[Type] = value_type
        super().__init__(json_schema)


class BaseQuantityMeta(QuantityMeta):
    """
    Base class for Quantity metas that handles common parsing and serialization logic.
    Subclasses must implement `_ensure_quantity(value)` to actually convert to a Quantity
    with the correct units or dimensions.
    """

    def _validate(self, value: QuantityInputType) -> Quantity:
        return self._ensure_quantity(value)

    def _icat_serialize(self, value: Optional[Quantity]) -> Union[Number, str, None]:
        if value is None:
            return None
        magnitude = self._get_magnitude(value)
        if numpy.isscalar(magnitude):
            return magnitude
        return " ".join(map(str, magnitude))

    def _json_serialize(
        self, value: Optional[Quantity]
    ) -> Union[List[Number], Number, None]:
        if value is None:
            return None
        magnitude = self._get_magnitude(value)
        if numpy.isscalar(magnitude):
            return magnitude
        return magnitude.tolist()

    def _nexus_serialize(
        self, value: Optional[Quantity]
    ) -> Union[numpy.ndarray, Number, None]:
        if value is None:
            return None
        return self._get_magnitude(value)

    @abstractmethod
    def _ensure_quantity(self, value: QuantityInputType) -> Quantity:
        pass

    @abstractmethod
    def _get_magnitude(self, value: Quantity) -> MagnitudeType:
        pass


class UnitQuantityMeta(BaseQuantityMeta):
    """
    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field: Annotated[Quantity, UnitQuantityMeta("mm", None)]
            field: Annotated[Quantity, UnitQuantityMeta("mm", float)]
    """

    def __init__(self, unit: Unit, value_type: Optional[type]):
        self.unit = unit

        json_schema = {
            "type": "array",
            "minItems": 2,
            "maxItems": 2,
            "items": [
                {
                    "type": "number",
                    "description": "Magnitude of the quantity",
                },
                {
                    "type": "string",
                    "description": "Unit symbol (e.g., 'mm', 'µm', 'kg')",
                },
            ],
            "description": (
                f"Physical quantity represented as a [magnitude, unit_string] pair. "
                f"The value will be converted to '{unit}' during validation."
            ),
        }

        super().__init__(value_type, json_schema)

    def _ensure_quantity(self, value: QuantityInputType) -> Quantity:
        return ensure_units(value, self.unit, self.value_type)

    def _get_magnitude(self, value: Quantity) -> MagnitudeType:
        return value.to(self.unit).magnitude


class DimensionQuantityMeta(BaseQuantityMeta):
    """
    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field1: Annotated[Quantity, DimensionQuantityMeta("[length]", None)]
            field2: Annotated[Quantity, DimensionQuantityMeta("[length]", float)]
    """

    def __init__(self, dimension: UnitsContainer, value_type: Optional[type]):
        self.dimension = dimension

        json_schema = {
            "type": "array",
            "minItems": 2,
            "maxItems": 2,
            "items": [
                {
                    "type": "number",
                    "description": "Magnitude of the quantity",
                },
                {
                    "type": "string",
                    "description": "Unit dimension (e.g., '[length]', '[mass]', '[energy]')",
                },
            ],
            "description": (
                f"Physical quantity represented as a [magnitude, dimension_string] pair. "
                f"The value will be converted to '{dimension}' during validation."
            ),
        }
        super().__init__(value_type, json_schema)

    def _ensure_quantity(self, value: QuantityInputType) -> Quantity:
        return ensure_dimension(value, self.dimension, self.value_type)

    def _get_magnitude(self, value: Quantity) -> MagnitudeType:
        return value.magnitude


def ensure_units(
    value: QuantityInputType,
    units: Unit,
    value_type: Optional[type],
) -> Quantity:
    """
    :raises ValueError: wrong value or units.
    """
    if isinstance(value, str):
        value = value.split()
        if len(value) == 1:
            value = value[0]

    if isinstance(value, Quantity):
        q = value.to(units)
        magnitude = q.magnitude

    elif isinstance(value, Sequence) and not isinstance(value, str):
        magnitude, input_units = _split_magnitude_and_units(value)
        magnitude = _as_numeric(magnitude)
        input_units = input_units or units

        q = REGISTRY.Quantity(magnitude, input_units).to(units)
    else:
        magnitude = _as_numeric(value)
        q = REGISTRY.Quantity(magnitude, units)

    if value_type is None and type(magnitude)(q.magnitude) == q.magnitude:
        value_type = type(magnitude)

    return _magnitude_type_coerce(q, value_type)


def ensure_dimension(
    value: QuantityInputType,
    dimension: UnitsContainer,
    value_type: Optional[type],
) -> Quantity:
    """
    :raises ValueError: wrong value or dimension.
    """
    if isinstance(value, str):
        value = value.split()
        if len(value) == 1:
            value = value[0]

    if isinstance(value, Quantity):
        q = value
        magnitude = q.magnitude

    elif isinstance(value, Sequence) and not isinstance(value, str):
        magnitude, units = _split_magnitude_and_units(value)

        magnitude = _as_numeric(magnitude)
        q = REGISTRY.Quantity(magnitude, units)
    else:
        magnitude = _as_numeric(value)
        q = REGISTRY.Quantity(magnitude)

    if not q.check(dimension):
        raise ValueError(f"{value} does not match dimensionality '{dimension}'")

    if value_type is None and type(magnitude)(q.magnitude) == q.magnitude:
        value_type = type(magnitude)

    return _magnitude_type_coerce(q, value_type)


def _split_magnitude_and_units(
    value: Sequence[Union[MagnitudeInputType, UnitsInputType]],
) -> Tuple[MagnitudeInputType, UnitsInputType]:
    """
    Extract value and optional unit from a sequence which is not a string.

    Examples:

    - [10] -> 10, None
    - [10, None] -> 10, None
    - [10, "mm"] -> 10, "mm"
    - [[10, 20]] -> [10, 20], None
    - [[10, 20], None] -> [10, 20], None
    - [[10, 20], "mm"] -> [10, 20], "mm"

    :raises ValueError:
    """
    if isinstance(value, str):
        raise ValueError(f"{value!r} is not expected to be a string")

    if len(value) == 0:
        return [], None

    if len(value) == 1 and isinstance(value[0], (Sequence, numpy.ndarray)):
        value = value[0]

    if len(value) == 2 and _is_unit(value[-1]):
        magnitude, units = value
    else:
        magnitude = value
        units = None

    return magnitude, units


def _is_unit(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, (Unit, UnitsContainer)):
        return True
    if not isinstance(value, str):
        return False
    try:
        _ = float(value)
    except ValueError:
        return True
    return False


def _as_numeric(value: Any) -> Union[Number, Sequence[Number], numpy.ndarray]:
    """
    :raises ValueError: value cannot be coerced to a number or list of numbers.
    """
    if isinstance(value, str):
        value = float(value)
        ivalue = int(value)
        return ivalue if value == ivalue else value

    if isinstance(value, Sequence):
        return type(value)(_as_numeric(v) for v in value if v is not None)

    if isinstance(value, (float, int, numpy.ndarray)):
        return value

    raise ValueError(f"{value!r} is expected to be a str, int or float")


def _magnitude_type_coerce(q: Quantity, value_type: Optional[type]) -> Quantity:
    if value_type is None:
        return q

    container_type, numeric_type = _split_container_and_item_type(value_type)

    # Scalar
    if container_type is None:
        if isinstance(q.magnitude, numeric_type):
            return q

        magnitude = q.magnitude
        if isinstance(magnitude, (Sequence, numpy.ndarray)):
            magnitude = numpy.squeeze(magnitude)
            if magnitude.ndim > 0:
                raise ValueError(
                    f"Magnitude {q.magnitude} cannot have more than one value"
                )

        magnitude = numeric_type(magnitude)

        if magnitude != q.magnitude:
            raise ValueError(
                f"Magnitude {q.magnitude} cannot be converted to type {numeric_type.__name__}"
            )
        return REGISTRY.Quantity(magnitude, q.units)

    # Sequence
    if not isinstance(q.magnitude, (Sequence, numpy.ndarray)) or isinstance(
        q.magnitude, str
    ):
        raise ValueError(f"Expected a sequence magnitude, got {type(q.magnitude)}")

    sequence = (
        q.magnitude.tolist() if isinstance(q.magnitude, numpy.ndarray) else q.magnitude
    )
    coerced = []
    for item in sequence:
        if item is None:
            coerced.append(None)
            continue

        coerced_item = numeric_type(item)
        if coerced_item != item:
            raise ValueError(
                f"Sequence item {item} cannot be converted to type {numeric_type.__name__}"
            )
        coerced.append(coerced_item)

    return REGISTRY.Quantity(list(coerced), q.units)


def _split_container_and_item_type(
    value_type: Optional[type],
) -> Tuple[Optional[type], Optional[type]]:
    """Extract the mumeric type from the value type.

    - int -> None, int
    - List[int] -> List, int
    """
    if value_type is None:
        return None, None

    origin = get_origin(value_type)
    if origin in (list, tuple, Sequence):
        (item_type,) = get_args(value_type)
        return origin, item_type

    return None, value_type
