"""Base model to represent ICAT schema's."""

import pathlib
from copy import deepcopy
from typing import Any
from typing import Dict
from typing import Generator
from typing import List
from typing import Tuple
from typing import Union

import pint
from pydantic import BaseModel
from pydantic import model_validator

try:
    import xmltodict
except ImportError:
    xmltodict = None

from . import field_utils
from . import icat
from .field_utils import has_custom_serialization
from .field_utils import resolve_field_description

_ALLOWED_EXTRA_KEYS = {
    "icat_name": {"include_in_xml": False, "description": "ICAT field name"},
    "record": {"include_in_xml": True, "description": "Record type"},
    "include_nexus_url": {
        "include_in_xml": False,
        "description": "Flag to automatically generate the NeXus URL",
    },
}

_ALLOWED_RECORD_VALUES = {"initial", "final"}


class IcatBaseModel(BaseModel, extra="forbid", validate_assignment=True):
    """Base model for ICAT dataset metadata.

    Model instances (i.e. includes values) can be converted to and from
    the following python dictionaries:

    - ICAT: flat dictionary with ICAT database key-value pairs.
    - NeXus: nested dictionary with Nexus groups, fields and attributes
             following the Silx dictdump schema.

    Numeric fields with units or unit dimensions are supported.

    Model classes (i.e. no values) can be converted to the following
    schema's

    - XML: original (non-defined) ICAT dataset metadata XDS schema.
    - Any schema supported by Pydantic like JSON schema.
    """

    @classmethod
    def __pydantic_init_subclass__(cls, *args, **kwargs) -> Any:
        """Validate the JSON extra keys of all fields."""
        result = super().__pydantic_init_subclass__(*args, **kwargs)
        for field_name, field_info in cls.model_fields.items():
            extras: Dict[str, Any] = field_info.json_schema_extra or {}

            allowed_keys = set(_ALLOWED_EXTRA_KEYS.keys())
            unknown_keys = set(extras) - allowed_keys
            if unknown_keys:
                raise ValueError(
                    f"Field '{field_name}' in '{cls.__name__}' contains invalid json_schema_extra keys: {unknown_keys}. "
                    f"Allowed keys are: {allowed_keys}"
                )

            if "record" in extras:
                record_value = extras["record"]
                if record_value not in _ALLOWED_RECORD_VALUES:
                    raise ValueError(
                        f"Field '{field_name}' in '{cls.__name__}' has invalid 'record' value: {record_value}. "
                        f"Allowed values are: {_ALLOWED_RECORD_VALUES}"
                    )

        return result

    @model_validator(mode="before")
    @classmethod
    def parse_nexus_style_units(cls, data: Any) -> Any:
        """
        Looks for NeXus-style quantity definitions (e.g., 'beamSize' and 'beamSize@units')
        in the input data and converts them into a format `BaseQuantityMeta` understands
        (e.g., {'beamSize': [magnitude, unit_str]}) before field validation.
        """
        if not isinstance(data, dict):
            return data

        modified_data = data.copy()
        keys_to_remove = set()

        for field_name, field_info in cls.model_fields.items():
            quantity_type = field_utils.get_field_type(
                field_info.annotation, pint.Quantity
            )
            if not quantity_type:
                continue

            # Field, attribute or group alias
            alias = field_info.alias or field_name
            units_key = f"{alias}@units"
            if alias in modified_data and units_key in modified_data:
                magnitude = modified_data[alias]
                unit_or_dimension = modified_data[units_key]
                modified_data[alias] = [magnitude, unit_or_dimension]
                keys_to_remove.add(units_key)

        for key in keys_to_remove:
            del modified_data[key]

        return modified_data

    @classmethod
    def icat_field_names(cls, parent_prefix: str = "") -> List[str]:
        return list(cls._iter_icat_names(parent_prefix))

    @classmethod
    def icat_fields(
        cls, parent_prefix: str = "", parent_nexus_nodes=()
    ) -> Dict[str, field_utils.IcatFieldInfo]:
        return {
            info.icat_name: info
            for info in cls._iter_icat_field_info(parent_prefix, parent_nexus_nodes)
        }

    def to_icat_dict(self, parent_prefix: str = "") -> Dict[str, str]:
        """Convert a Pydantic model instance to an ICAT-ingester-compliant dict."""
        return self._to_icat_dict(parent_prefix)

    @classmethod
    def from_icat_dict(
        cls, icat_data: Dict[str, Any], parent_prefix: str = ""
    ) -> "IcatBaseModel":
        """Create a Pydantic model instance from an ICAT-ingester-compliant dict."""
        model_data = cls._from_icat_dict(icat_data, parent_prefix)
        return cls(**model_data)

    @classmethod
    def to_xml_dict(
        cls, group_name: str = "${entry}", parent_prefix: str = ""
    ) -> Dict[str, Any]:
        """Convert the Pydantic model to an XML dict following the original XML structure (has not XDS schema)."""
        return cls._to_xml_dict(group_name, parent_prefix)

    @classmethod
    def to_xml_file(
        cls,
        xml_file: Union[str, bytes, pathlib.Path],
        group_name: str = "${entry}",
        parent_prefix: str = "",
    ) -> None:
        """Convert the Pydantic model to an XML file following the original XML structure (has not XDS schema)."""
        with open(xml_file, mode="w", encoding="utf-8") as fh:
            fh.write(
                cls.to_xml_string(group_name=group_name, parent_prefix=parent_prefix)
            )

    @classmethod
    def to_xml_string(
        cls, group_name: str = "${entry}", parent_prefix: str = ""
    ) -> str:
        """Convert the Pydantic model to an XML string following the original XML structure (has not XDS schema)."""
        xml_dict = cls.to_xml_dict(group_name=group_name, parent_prefix=parent_prefix)
        return cls._xml_dict_to_string(xml_dict)

    def to_nexus_dict(self) -> Dict[str, Any]:
        """Convert a Pydantic model instance to a NeXus-compliant dict."""
        return self._to_nexus_dict()

    @classmethod
    def from_nexus_dict(cls, nexus_data: Dict[str, Any]) -> "IcatBaseModel":
        """Create a Pydantic model instance from a NeXus-compliant dict."""
        return cls(**nexus_data)

    def _to_icat_dict(self, parent_prefix: str) -> Dict[str, str]:
        icat_data = dict()
        modes = {"icat": set(), "json": set()}
        alias_to_icat_short_name = dict()

        for field_name, field_info in type(self).model_fields.items():
            # Field or group alias, skip attributes
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias
            alias_to_icat_short_name[alias] = short_icat_name

            # Dump value
            value = getattr(self, field_name)
            if isinstance(value, IcatBaseModel):
                # Dump group
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                icat_data.update(value._to_icat_dict(field_prefix))
            elif has_custom_serialization(field_info.annotation):
                # Dump field later
                modes["icat"].add(field_name)
            else:
                # Dump field later
                modes["json"].add(field_name)

        # Dump fields
        for mode, include in modes.items():
            fields = self.model_dump(
                exclude_unset=True, by_alias=True, mode=mode, include=include
            )
            icat_data.update(
                {
                    icat.icat_field_name(parent_prefix, short_icat_name): value
                    for short_icat_name, value in fields.items()
                }
            )

        # Ensure keys are ICAT names and values are strings
        icat_data = {
            alias_to_icat_short_name.get(alias, alias): _to_icat_value(alias, value)
            for alias, value in icat_data.items()
            if value is not None
        }

        return icat_data

    @classmethod
    def _from_icat_dict(
        cls, icat_data: Dict[str, Any], parent_prefix: str, _top: bool = True
    ) -> dict:
        result = dict()
        if _top:
            icat_data = deepcopy(icat_data)
        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Load group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                subdata = group_model._from_icat_dict(
                    icat_data, field_prefix, _top=False
                )
                if subdata:
                    result[alias] = subdata
                continue

            # Pop field value
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            if icat_name in icat_data:
                result[alias] = icat_data.pop(icat_name)

        # Field values which are not popped are invalid.
        if _top and icat_data:
            raise ValueError(f"Unknown ICAT fields {list(icat_data)}")

        return result

    @classmethod
    def _iter_icat_names(cls, parent_prefix: str) -> Generator[str, None, None]:
        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Traverse group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                yield from group_model._iter_icat_names(field_prefix)
                continue

            # Full ICAT field name
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            yield icat_name

    @classmethod
    def _iter_icat_field_info(
        cls, parent_prefix: str, parent_nexus_nodes: Tuple[str, ...]
    ) -> Generator[field_utils.IcatFieldInfo, None, None]:
        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            nexus_nodes = parent_nexus_nodes + (field_name,)

            # Traverse group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                yield from group_model._iter_icat_field_info(field_prefix, nexus_nodes)
                continue

            # Field info
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)

            unit_info = field_utils.get_unit_info(field_info.annotation)
            nexus_type = field_utils.get_nexus_type(field_info.annotation)

            if field_info.json_schema_extra:
                record = field_info.json_schema_extra.get("record", None)
            else:
                record = None

            yield field_utils.IcatFieldInfo(
                icat_name=icat_name,
                nexus_nodes=nexus_nodes,
                description=resolve_field_description(
                    model_cls=cls,
                    field_name=field_name,
                    field_info=field_info,
                ),
                required=field_info.is_required(),
                unit_info=unit_info,
                nexus_type=nexus_type,
                annotation=field_info.annotation,
                record=record,
            )

    @classmethod
    def _to_xml_dict(cls, group_name: str, parent_prefix: str) -> Dict[str, Any]:
        xml_group_data = {"@groupName": group_name}
        groups = list()
        for field_name, field_info in cls.model_fields.items():
            # Field, attribute or group alias
            alias = field_info.alias or field_name

            # Store attribute
            if alias.startswith("@"):
                xml_group_data[alias] = field_info.default
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Store group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                group_attrs = group_model._to_xml_dict(alias, field_prefix)

                if field_info.description is not None:
                    group_attrs["@ESRF_description"] = resolve_field_description(
                        model_cls=cls,
                        field_name=field_name,
                        field_info=field_info,
                    )

                groups.append(group_attrs)
                continue

            # Store field
            field_attrs = dict()
            if field_info.is_required():
                field_attrs["@ESRF_mandatory"] = "Mandatory"

            if field_info.description is not None:
                field_attrs["@ESRF_description"] = resolve_field_description(
                    model_cls=cls,
                    field_name=field_name,
                    field_info=field_info,
                )

            field_attrs["@NAPItype"] = field_utils.get_nexus_type(field_info.annotation)

            unit_info = field_utils.get_unit_info(field_info.annotation)
            if unit_info is not None:
                field_attrs["@units"] = unit_info.as_str_xml()

            if field_info.json_schema_extra:
                for k, v in field_info.json_schema_extra.items():
                    if v is None:
                        continue
                    include_in_xml = _ALLOWED_EXTRA_KEYS.get(k, {}).get(
                        "include_in_xml", True
                    )
                    if not include_in_xml:
                        continue
                    field_attrs[f"@{k}"] = v

            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            field_attrs["#text"] = f"${{{icat_name}}}"
            xml_group_data[field_name] = field_attrs

        # Copy groups
        if groups:
            if len(groups) == 1:
                xml_group_data["group"] = groups[0]
            else:
                xml_group_data["group"] = groups

        return xml_group_data

    @classmethod
    def _xml_string_to_dict(cls, xml_string: str) -> dict:
        if xmltodict is None:
            raise RuntimeError("Requires 'xmltodict'")
        data = xmltodict.parse(xml_string)[cls.__name__]
        if data is None:
            return dict()
        return data

    @classmethod
    def _xml_dict_to_string(cls, xml_dict: dict) -> str:
        if xmltodict is None:
            raise RuntimeError("Requires 'xmltodict'")
        return xmltodict.unparse({"group": xml_dict}, pretty=True, indent=4)

    def _to_nexus_dict(self) -> Dict[str, Any]:
        nexus_data = dict()
        modes = {"nexus": set(), "json": set()}

        for field_name, field_info in type(self).model_fields.items():
            # Field, attribute or group alias
            alias = field_info.alias or field_name

            # Dump value
            value = getattr(self, field_name)
            if isinstance(value, IcatBaseModel):
                # Dump group
                nexus_data[alias] = value.to_nexus_dict()
            elif isinstance(value, pint.Quantity):
                # Dump field attributes now and field value later
                nexus_data[f"{alias}@units"] = str(value.units)
                modes["nexus"].add(field_name)
            elif has_custom_serialization(field_info.annotation):
                # Dump field later
                modes["nexus"].add(field_name)
            else:
                # Dump field later
                modes["json"].add(field_name)

        # Dump fields
        for mode, include in modes.items():
            fields = self.model_dump(
                exclude_none=True, by_alias=True, mode=mode, include=include
            )
            nexus_data.update(fields)

        return nexus_data


def _to_icat_value(name: str, value: Union[str, int, float, bool]) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    raise TypeError(
        f"Unsupported type for ICAT parameter: {name} = {type(value).__name__}"
    )
