from enum import Enum
from typing import Optional

from pydantic import Field


class RecordType(str, Enum):
    initial = "initial"
    final = "final"


class MetadataField:
    """
    Factory helper for defining Pydantic fields with additional schema metadata.
    """

    def __new__(
        cls,
        default=...,
        *,
        description: str,
        icat_name: Optional[str] = None,
        record: Optional[RecordType] = None,
        include_nexus_url: bool = False,
    ) -> Field:
        extra = {}
        if icat_name is not None:
            extra["icat_name"] = icat_name
        if record is not None:
            extra["record"] = record.value
        extra["include_nexus_url"] = include_nexus_url

        return Field(
            default,
            description=description,
            json_schema_extra=extra or None,
        )
