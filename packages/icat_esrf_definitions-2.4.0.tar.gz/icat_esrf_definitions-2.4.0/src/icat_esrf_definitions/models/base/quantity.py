from typing import List

from .custom_types import PydanticQuantity

# --- time & period ---
MILLISECONDS = PydanticQuantity[r"ms"]  # NX_TIME, NX_PERIOD
MICROSECONDS = PydanticQuantity[r"µs"]  # NX_TIME, NX_PERIOD
SECONDS = PydanticQuantity[r"s"]  # NX_TIME, NX_PERIOD
YEARS = PydanticQuantity[r"years"]  # NX_TIME, NX_PERIOD

# --- frequency ---
HERTZ = PydanticQuantity[r"Hz"]  # NX_FREQUENCY

# --- length & area & volume ---
ANGSTROMS = PydanticQuantity[r"angstroms"]  # NX_LENGTH
ANGSTROMS_ARRAY = PydanticQuantity[r"angstroms", List[float]]
NANOMETERS = PydanticQuantity[r"nm"]  # NX_LENGTH
MICROMETERS = PydanticQuantity[r"µm"]  # NX_LENGTH
MILLIMETERS = PydanticQuantity[r"mm"]  # NX_LENGTH
CENTIMETERS = PydanticQuantity[r"cm"]  # NX_LENGTH
METERS = PydanticQuantity[r"m"]  # NX_LENGTH

METERS_SQUARED = PydanticQuantity[r"m²"]  # NX_AREA
METERS_CUBED = PydanticQuantity[r"m³"]  # NX_VOLUME
NANOMETERS_CUBED = PydanticQuantity[r"nm³"]  # NX_VOLUME
BARN = PydanticQuantity[r"barn"]  # NX_CROSS_SECTION, NX_AREA
PER_SQUARE_METER = PydanticQuantity[r"1/m²"]  # NX_PER_AREA
PER_METER = PydanticQuantity[r"1/m"]  # NX_PER_LENGTH

# --- velocity ---
MILLIMETERS_PER_SECOND = PydanticQuantity[r"mm/s"]

# --- angle & solid angle & emittance ---
DEGREES_ANGLE = PydanticQuantity[r"deg"]  # NX_ANGLE
RADIANS = PydanticQuantity[r"rad"]  # NX_ANGLE
STERADIAN = PydanticQuantity[r"sr"]  # NX_SOLID_ANGLE
EMITTANCE = PydanticQuantity[r"nm*rad"]  # NX_EMITTANCE

# --- temperature ---
CELSIUS = PydanticQuantity[r"celsius"]  # NX_TEMPERATURE
DEGREES = PydanticQuantity[r"degrees"]  # NX_TEMPERATURE
KELVINS = PydanticQuantity[r"K"]  # NX_TEMPERATURE

# --- mass, density & molecular weight ---
GRAMS = PydanticQuantity[r"g"]  # NX_MASS
KILOGRAMS = PydanticQuantity[r"kg"]  # NX_MASS
KILODALTONS = PydanticQuantity[r"kDa"]  # NX_MASS
GRAMS_PER_CM3 = PydanticQuantity[r"g/cm³"]  # NX_MASS_DENSITY
SCATTERING_LENGTH_DENSITY = PydanticQuantity[r"m/m³"]  # NX_SCATTERING_LENGTH_DENSITY
GRAMS_PER_MOLE = PydanticQuantity[r"g/mol"]  # NX_MOLECULAR_WEIGHT

# --- electric & magnetic ---
MILLIAMPERES = PydanticQuantity[r"mA"]  # NX_CURRENT
AMPERES = PydanticQuantity[r"A"]  # NX_CURRENT
COULOMBS = PydanticQuantity[r"C"]  # NX_CHARGE
VOLTS = PydanticQuantity[r"V"]  # NX_VOLTAGE

# --- energy, power & pressure ---
JOULES = PydanticQuantity[r"J"]  # NX_ENERGY
KILOELECTRONVOLTS = PydanticQuantity[r"keV"]  # NX_ENERGY
KILOELECTRONVOLTS_ARRAY = PydanticQuantity[r"keV", List[float]]
WATTS = PydanticQuantity[r"W"]  # NX_POWER
PASCALS = PydanticQuantity[r"Pa"]  # NX_PRESSURE

# --- radiation dose ---
GRAY = PydanticQuantity[r"Gy"]
KILOGRAY = PydanticQuantity[r"kGy"]
GRAY_PER_SECOND = PydanticQuantity[r"Gy/s"]
GRAY_PER_SECOND_PER_MILLIAMPERE = PydanticQuantity[r"Gy/s/mA"]
ELECTRON_FLUENCE = PydanticQuantity[r"1 / angstrom**2"]

MILLIAMPERES = PydanticQuantity[r"mA"]
KILOVOLTS = PydanticQuantity[r"kV"]

PHOTON_FLUX = PydanticQuantity[r"photons/s"]
FLUX_DENSITY = PydanticQuantity[r"1/s/cm²"]  # NX_FLUX
COUNT = PydanticQuantity[r"", int]  # NX_COUNT
PIXELS = PydanticQuantity[r"", int]

# --- unitless & any ---
PERCENT = PydanticQuantity[r"%"]
NO_UNITS = PydanticQuantity[r""]  # NX_UNITLESS
NO_DIMENSION = PydanticQuantity[r""]  # NX_DIMENSIONLESS
ANY_UNITS = NO_UNITS  # NX_ANY
