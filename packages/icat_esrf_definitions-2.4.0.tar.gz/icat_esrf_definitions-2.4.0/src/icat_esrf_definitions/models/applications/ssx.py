from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXcollection
from ..base.nexus import NXsubentry
from .applications import register_application


class IcatSsxChip(NXcollection):
    horizontal_spacing: Optional[str] = MetadataField(None, description="")
    vertical_spacing: Optional[str] = MetadataField(None, description="")
    row_number: Optional[str] = MetadataField(None, description="")
    column_number: Optional[str] = MetadataField(None, description="")
    model: Optional[str] = MetadataField(None, description="")


class IcatSsxJet(NXcollection):
    speed: Optional[str] = MetadataField(None, description="Jet's speed")
    size: Optional[str] = MetadataField(None, description="Jet's size")


@register_application("SSX", description="Serial Synchrotron Crystallography")
class IcatSsx(NXsubentry):
    jet: Optional[IcatSsxJet] = MetadataField(None, description="")
    chip: Optional[IcatSsxChip] = MetadataField(None, description="")
