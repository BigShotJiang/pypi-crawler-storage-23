from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXsubentry
from ..base.quantity import MICROMETERS
from .applications import register_application


@register_application("HOLO", description="X-ray Holography")
class IcatHolo(NXsubentry):
    n: Optional[float] = MetadataField(
        None,
        description="Number of planes for holography measurement.",
        icat_name="N",
    )
    sampleDetectorDistances: Optional[str] = MetadataField(
        None,
        description="Sample/detector distances for all planes used.",
        icat_name="holoSampleDetectorDistances",
    )
    sourceSampleDistances: Optional[str] = MetadataField(
        None,
        description="Source/sample distances for all planes used.",
        icat_name="holoSourceSampleDistances",
    )
    im01NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 1.",
        icat_name="im01_num_end",
    )
    im01NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 1.",
        icat_name="im01_num_start",
    )
    im02NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 2.",
        icat_name="im02_num_end",
    )
    im02NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 2.",
        icat_name="im02_num_start",
    )
    im03NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 3.",
        icat_name="im03_num_end",
    )
    im03NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 3.",
        icat_name="im03_num_start",
    )
    im04NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last sample image in plane 4.",
        icat_name="im04_num_end",
    )
    im04NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first sample image in plane 4.",
        icat_name="im04_num_start",
    )
    ref01NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 1.",
        icat_name="ref01_num_end",
    )
    ref02NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 2.",
        icat_name="ref02_num_end",
    )
    ref02NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 2.",
        icat_name="ref02_num_start",
    )
    ref03NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 3.",
        icat_name="ref03_num_end",
    )
    ref03NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 3.",
        icat_name="ref03_num_start",
    )
    ref04NumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last reference image in plane 4.",
        icat_name="ref04_num_end",
    )
    ref04NumStart: Optional[float] = MetadataField(
        None,
        description="Index of first reference image in plane 4.",
        icat_name="ref04_num_start",
    )
    darkNumStart: Optional[float] = MetadataField(
        None,
        description="Index of first dark image.",
        icat_name="dark_num_start",
    )
    darkNumEnd: Optional[float] = MetadataField(
        None,
        description="Index of last dark image.",
        icat_name="dark_num_end",
    )
    pixelSize: Optional[MICROMETERS] = MetadataField(
        None, description="Pixel size of first distance in micron."
    )
