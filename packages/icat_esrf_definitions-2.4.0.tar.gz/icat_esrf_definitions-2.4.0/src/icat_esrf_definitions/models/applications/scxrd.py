from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXsubentry
from ..base.quantity import ANGSTROMS
from ..base.quantity import DEGREES
from ..base.quantity import METERS
from ..base.quantity import SECONDS
from .applications import register_application


@register_application("SCXRD", description="Single Crystal X-ray Diffraction")
class IcatScxrd(NXsubentry):
    sample_detector_distance: Optional[METERS] = MetadataField(
        None,
        description="Distance from sample to detector",
        record=RecordType.final,
    )
    beam_center_x: Optional[float] = MetadataField(
        None,
        description="X Coordinate of the beamcenter",
        record=RecordType.final,
    )
    beam_center_y: Optional[float] = MetadataField(
        None,
        description="Y Coordinate of the beamcenter",
        record=RecordType.final,
    )
    wavelength: Optional[ANGSTROMS] = MetadataField(
        None, description="X-ray wavelength", record=RecordType.final
    )
    detector_tilts: Optional[DEGREES] = MetadataField(
        None,
        description="Detector tilts around X, Y and Z axes",
        record=RecordType.final,
    )
    rotation_axis: Optional[str] = MetadataField(
        None,
        description="Name of the rotation axis (e.g., omega)",
        record=RecordType.final,
    )
    rotation_range: Optional[DEGREES] = MetadataField(
        None,
        description="Rotation range for the crystal scan (start,end)",
        record=RecordType.final,
    )
    rotation_step: Optional[DEGREES] = MetadataField(
        None,
        description="Rotation step between two frames",
        record=RecordType.final,
    )
    exposure_time: Optional[SECONDS] = MetadataField(
        None,
        description="Exposure time per image",
        record=RecordType.final,
    )
