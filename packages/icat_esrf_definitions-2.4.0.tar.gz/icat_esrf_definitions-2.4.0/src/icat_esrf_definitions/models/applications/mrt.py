from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.nexus import NXsubentry
from ..base.quantity import DEGREES_ANGLE
from ..base.quantity import GRAY
from ..base.quantity import GRAY_PER_SECOND_PER_MILLIAMPERE
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIMETERS
from ..base.quantity import MILLIMETERS_PER_SECOND
from .applications import register_application


@register_application("MRT", description="Microbeam Radiation Therapy")
class IcatMrt(NXsubentry):
    mscType: Optional[str] = MetadataField(None, description="Multislit Type")
    doseRate: Optional[GRAY_PER_SECOND_PER_MILLIAMPERE] = MetadataField(
        None, description="Dose Rate"
    )
    ctcMot: Optional[str] = MetadataField(None, description="C-to-C Motor")
    ctcSpacing: Optional[MICROMETERS] = MetadataField(
        None, description="C-to-C Spacing"
    )
    ctcN: Optional[int] = MetadataField(None, description="Number of Irradiations")
    crossMot: Optional[str] = MetadataField(None, description="Crossfiring Motor")
    crossAngle: Optional[DEGREES_ANGLE] = MetadataField(
        None, description="Crossfiring Angle"
    )
    crossN: Optional[int] = MetadataField(None, description="Number of Crossfiring")
    intlcdMot: Optional[str] = MetadataField(None, description="Interlaced Motor")
    intlcdOff: Optional[MICROMETERS] = MetadataField(
        None, description="Interlaced Offset"
    )
    expoStart: Optional[MILLIMETERS] = MetadataField(
        None, description="Z Start Position"
    )
    expoStop: Optional[MILLIMETERS] = MetadataField(None, description="Z Stop Position")
    expoSpeed: Optional[MILLIMETERS_PER_SECOND] = MetadataField(
        None, description="Z Last Speed"
    )
    IC01: Optional[str] = MetadataField(None, description="Counts on ION chamber 0-1")
    IC02: Optional[str] = MetadataField(None, description="Counts on ION chamber 0-2")
    IC0MU1: Optional[str] = MetadataField(
        None, description="Counts on ION MUSST chamber 0-1"
    )
    IC0MU2: Optional[str] = MetadataField(
        None, description="Counts on ION MUSST chamber 0-2"
    )
    IONCH1: Optional[str] = MetadataField(None, description="Counts on ION chamber 1")
    IONCH2: Optional[str] = MetadataField(None, description="Counts on ION chamber 2")
    dose: Optional[GRAY] = MetadataField(None, description="Dose Planned")
    beamHeight: Optional[MICROMETERS] = MetadataField(
        None, description="Beam Vertical Width"
    )
    beamSize: Optional[MICROMETERS] = MetadataField(None, description="Microbeam Width")
