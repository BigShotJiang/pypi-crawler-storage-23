from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXcollection
from ..base.nexus import NXsubentry
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIMETERS
from ..base.quantity import SECONDS
from .applications import register_application


class IcatPtychoHorizontalAxis(NXcollection):
    name: Optional[str] = MetadataField(
        None, description="Scan motor in the horizontal direction"
    )
    range: Optional[MICROMETERS] = MetadataField(
        None, description="Range of the moves in microns"
    )


class IcatPtychoVerticalAxis(NXcollection):
    name: Optional[str] = MetadataField(
        None, description="Scan motor in the vertical direction"
    )
    range: Optional[MICROMETERS] = MetadataField(
        None, description="Range of the moves in microns"
    )


@register_application("PTYCHO", description="Ptychographic Imaging")
class IcatPtycho(NXsubentry):
    propagation: Optional[str] = MetadataField(
        None,
        description="Propagation may be near or far",
        record=RecordType.final,
    )
    beamSize: Optional[MICROMETERS] = MetadataField(
        None,
        description="Beam size on the sample in microns",
        record=RecordType.final,
    )
    stepSize: Optional[MICROMETERS] = MetadataField(
        None, description="Step size during scan", record=RecordType.final
    )
    focusToDetectorDistance: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Focus to detector distance",
        record=RecordType.final,
    )
    countTime: Optional[SECONDS] = MetadataField(
        None, description="Step size during scan", record=RecordType.final
    )
    parameters: Optional[str] = MetadataField(
        None, description="Ptycho parameters", record=RecordType.final
    )
    tomoParameters: Optional[str] = MetadataField(
        None,
        description="Ptycho tomography parameters",
        record=RecordType.final,
    )
    refN: Optional[float] = MetadataField(
        None, description="Ptycho parameters", record=RecordType.final
    )
    darkN: Optional[float] = MetadataField(
        None, description="Ptycho parameters", record=RecordType.final
    )
    pixelSize: Optional[MICROMETERS] = MetadataField(
        None, description="Ptycho parameters", record=RecordType.final
    )
    Axis1: Optional[IcatPtychoHorizontalAxis] = MetadataField(
        None,
        description="",
        icat_name="_Axis1",
    )
    Axis2: Optional[IcatPtychoVerticalAxis] = MetadataField(
        None,
        description="",
        icat_name="_Axis2",
    )
