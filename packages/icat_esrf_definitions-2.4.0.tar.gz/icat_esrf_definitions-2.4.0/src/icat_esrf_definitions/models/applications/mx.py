from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXcollection
from ..base.nexus import NXsubentry
from ..base.quantity import ANGSTROMS
from ..base.quantity import DEGREES
from ..base.quantity import MILLIMETERS
from ..base.quantity import PHOTON_FLUX
from ..base.quantity import PIXELS
from ..base.quantity import SECONDS
from .applications import register_application


class IcatMxAutoprocintegrationScaling(NXcollection):
    overall_resolution_limit_low: Optional[str] = MetadataField(None, description="")
    overall_resolution_limit_high: Optional[str] = MetadataField(None, description="")
    overall_r_merge: Optional[str] = MetadataField(None, description="")
    overall_r_meas_within_IPlus_IMinus: Optional[str] = MetadataField(
        None, description=""
    )
    overall_r_meas_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    overall_r_pim_within_IPlus_IMinus: Optional[str] = MetadataField(
        None, description=""
    )
    overall_r_pim_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    overall_fractional_partial_bias: Optional[str] = MetadataField(None, description="")
    overall_n_total_observations: Optional[str] = MetadataField(None, description="")
    overall_n_total_unique_observations: Optional[str] = MetadataField(
        None, description=""
    )
    overall_mean_I_over_sigI: Optional[str] = MetadataField(None, description="")
    overall_completeness: Optional[str] = MetadataField(None, description="")
    overall_multiplicity: Optional[str] = MetadataField(None, description="")
    overall_anomalous_completeness: Optional[str] = MetadataField(None, description="")
    overall_anomalous_multiplicity: Optional[str] = MetadataField(None, description="")
    overall_anomalous: Optional[str] = MetadataField(None, description="")
    overall_cc_half: Optional[str] = MetadataField(None, description="")
    overall_ccAno: Optional[str] = MetadataField(None, description="")
    overall_sigAno: Optional[str] = MetadataField(None, description="")
    overall_isa: Optional[str] = MetadataField(None, description="")
    overall_completeness_spherical: Optional[str] = MetadataField(None, description="")
    overall_completeness_ellipsoidal: Optional[str] = MetadataField(
        None, description=""
    )
    overall_anomalous_completeness_spherical: Optional[str] = MetadataField(
        None, description=""
    )
    overall_anomalous_completeness_ellipsoidal: Optional[str] = MetadataField(
        None, description=""
    )
    inner_resolution_limit_low: Optional[str] = MetadataField(None, description="")
    inner_resolution_limit_high: Optional[str] = MetadataField(None, description="")
    inner_r_merge: Optional[str] = MetadataField(None, description="")
    inner_r_meas_within_IPlus_IMinus: Optional[str] = MetadataField(
        None, description=""
    )
    inner_r_meas_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    inner_r_pim_within_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    inner_r_pim_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    inner_fractional_partial_bias: Optional[str] = MetadataField(None, description="")
    inner_n_total_observations: Optional[str] = MetadataField(None, description="")
    inner_n_total_unique_observations: Optional[str] = MetadataField(
        None, description=""
    )
    inner_mean_I_over_sigI: Optional[str] = MetadataField(None, description="")
    inner_completeness: Optional[str] = MetadataField(None, description="")
    inner_multiplicity: Optional[str] = MetadataField(None, description="")
    inner_anomalous_completeness: Optional[str] = MetadataField(None, description="")
    inner_anomalous_multiplicity: Optional[str] = MetadataField(None, description="")
    inner_anomalous: Optional[str] = MetadataField(None, description="")
    inner_cc_half: Optional[str] = MetadataField(None, description="")
    inner_ccAno: Optional[str] = MetadataField(None, description="")
    inner_sigAno: Optional[str] = MetadataField(None, description="")
    inner_isa: Optional[str] = MetadataField(None, description="")
    inner_completeness_spherical: Optional[str] = MetadataField(None, description="")
    inner_completeness_ellipsoidal: Optional[str] = MetadataField(None, description="")
    inner_anomalous_completeness_spherical: Optional[str] = MetadataField(
        None, description=""
    )
    inner_anomalous_completeness_ellipsoidal: Optional[str] = MetadataField(
        None, description=""
    )
    outer_resolution_limit_low: Optional[str] = MetadataField(None, description="")
    outer_resolution_limit_high: Optional[str] = MetadataField(None, description="")
    outer_r_merge: Optional[str] = MetadataField(None, description="")
    outer_r_meas_within_IPlus_IMinus: Optional[str] = MetadataField(
        None, description=""
    )
    outer_r_meas_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    outer_r_pim_within_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    outer_r_pim_all_IPlus_IMinus: Optional[str] = MetadataField(None, description="")
    outer_fractional_partial_bias: Optional[str] = MetadataField(None, description="")
    outer_n_total_observations: Optional[str] = MetadataField(None, description="")
    outer_n_total_unique_observations: Optional[str] = MetadataField(
        None, description=""
    )
    outer_mean_I_over_sigI: Optional[str] = MetadataField(None, description="")
    outer_completeness: Optional[str] = MetadataField(None, description="")
    outer_multiplicity: Optional[str] = MetadataField(None, description="")
    outer_anomalous_completeness: Optional[str] = MetadataField(None, description="")
    outer_anomalous_multiplicity: Optional[str] = MetadataField(None, description="")
    outer_anomalous: Optional[str] = MetadataField(None, description="")
    outer_cc_half: Optional[str] = MetadataField(None, description="")
    outer_ccAno: Optional[str] = MetadataField(None, description="")
    outer_sigAno: Optional[str] = MetadataField(None, description="")
    outer_isa: Optional[str] = MetadataField(None, description="")
    outer_completeness_spherical: Optional[str] = MetadataField(None, description="")
    outer_completeness_ellipsoidal: Optional[str] = MetadataField(None, description="")
    outer_anomalous_completeness_spherical: Optional[str] = MetadataField(
        None, description=""
    )
    outer_anomalous_completeness_ellipsoidal: Optional[str] = MetadataField(
        None, description=""
    )


class IcatMxMrLigandfitting(NXcollection):
    ligand_FOFC_CC: Optional[str] = MetadataField(
        None, description="Ligand FOFC_CC", record=RecordType.final
    )
    R_free: Optional[str] = MetadataField(
        None, description="Free-r", record=RecordType.final
    )
    R_cryst: Optional[str] = MetadataField(
        None, description="R crystal", record=RecordType.final
    )
    B_factor: Optional[str] = MetadataField(
        None, description="B factor", record=RecordType.final
    )
    occupancy: Optional[str] = MetadataField(
        None, description="Occupancy", record=RecordType.final
    )
    PDB_file: Optional[str] = MetadataField(
        None, description="pdb file path", record=RecordType.final
    )
    MTZ_file: Optional[str] = MetadataField(
        None, description="mtz file", record=RecordType.final
    )
    PNG_2FOFC: Optional[str] = MetadataField(
        None,
        description="snapshot of the ligand in 2FO-FC electron density",
        record=RecordType.final,
    )
    PNG_FOFC: Optional[str] = MetadataField(
        None,
        description="snapshot of the ligand in FO-FC electron density",
        record=RecordType.final,
    )
    GIF_file: Optional[str] = MetadataField(
        None,
        description="animated GIF of the ligand in FO-FC electron density",
        record=RecordType.final,
    )
    ligand_XYZ: Optional[str] = MetadataField(
        None,
        description="x,y,z coordinates of the ligand",
        record=RecordType.final,
    )
    ligand_name: Optional[str] = MetadataField(
        None, description="name of the ligand", record=RecordType.final
    )
    MAP_FOFC: Optional[str] = MetadataField(
        None, description="MAP_FOFC file path", record=RecordType.final
    )
    MAP_2FOFC: Optional[str] = MetadataField(
        None, description="MAP_2FOFC file path", record=RecordType.final
    )


class IcatMxMrPhasing(NXcollection):
    source: Optional[str] = MetadataField(
        None,
        description="Describes the pdb suource: Alphafold, user, unit cell",
        record=RecordType.final,
    )
    search_model: Optional[str] = MetadataField(
        None,
        description="Identifier to the search model. It can be a link",
        record=RecordType.final,
    )
    space_group: Optional[str] = MetadataField(
        None, description="Phasing space group", record=RecordType.final
    )
    number_of_search_models_found: Optional[str] = MetadataField(
        None, description="Models found", record=RecordType.final
    )
    best_RFZ: Optional[str] = MetadataField(
        None, description="Best RFZ", record=RecordType.final
    )
    best_TFZ: Optional[str] = MetadataField(
        None, description="Best TTZ", record=RecordType.final
    )
    LLG: Optional[str] = MetadataField(
        None, description="Best LLG", record=RecordType.final
    )
    monomer_form_count: Optional[str] = MetadataField(
        None, description="Number of monomers", record=RecordType.final
    )
    RFZ_list: Optional[str] = MetadataField(
        None, description="List of RFZ", record=RecordType.final
    )
    TFZ_list: Optional[str] = MetadataField(
        None, description="List of TFZ", record=RecordType.final
    )
    PDB_file: Optional[str] = MetadataField(
        None, description="pdb file path", record=RecordType.final
    )
    MTZ_file: Optional[str] = MetadataField(
        None, description="MTZ file path", record=RecordType.final
    )
    MAP_2FOFC: Optional[str] = MetadataField(
        None, description="2FOFC map file path", record=RecordType.final
    )
    MAP_FOFC: Optional[str] = MetadataField(
        None, description="FOFC map file path", record=RecordType.final
    )


class IcatMxMrRefinement(NXcollection):
    R_free: Optional[str] = MetadataField(
        None, description="Free-r", record=RecordType.final
    )
    R_cryst: Optional[str] = MetadataField(
        None, description="R crystal", record=RecordType.final
    )
    PDB_file: Optional[str] = MetadataField(
        None, description="List of TFZ", record=RecordType.final
    )
    MTZ_file: Optional[str] = MetadataField(
        None, description="List of TFZ", record=RecordType.final
    )
    MAP_FOFC: Optional[str] = MetadataField(
        None, description="MAP_FOFC file path", record=RecordType.final
    )
    MAP_2FOFC: Optional[str] = MetadataField(
        None, description="MAP_2FOFC file path", record=RecordType.final
    )


class IcatMxSad(NXcollection):
    min_resolution: Optional[ANGSTROMS] = MetadataField(
        None,
        description="SAD minimal resolution",
        record=RecordType.final,
    )
    max_resolution: Optional[ANGSTROMS] = MetadataField(
        None,
        description="SAD maximal resolution",
        record=RecordType.final,
    )
    enantiomorph: Optional[str] = MetadataField(
        None, description="SAD enantiomorph", record=RecordType.final
    )
    space_group: Optional[str] = MetadataField(
        None, description="SAD space group", record=RecordType.final
    )
    step: Optional[str] = MetadataField(
        None, description="SAD step", record=RecordType.final
    )
    solvent: Optional[str] = MetadataField(
        None, description="SAD solvent", record=RecordType.final
    )
    pseudo_free_cc: Optional[str] = MetadataField(
        None, description="SAD pseudo_free_cc", record=RecordType.final
    )
    cc_partial_model: Optional[str] = MetadataField(
        None, description="SAD cc_partial_model", record=RecordType.final
    )
    chain_count: Optional[str] = MetadataField(
        None, description="SAD chain_count", record=RecordType.final
    )
    residues_count: Optional[str] = MetadataField(
        None, description="SAD residues_count", record=RecordType.final
    )
    average_fragment_length: Optional[str] = MetadataField(
        None,
        description="SAD average_fragment_length",
        record=RecordType.final,
    )
    PDB_file: Optional[str] = MetadataField(
        None, description="SAD PDB file path", record=RecordType.final
    )
    MTZ_file: Optional[str] = MetadataField(
        None, description="SAD MTZ file path", record=RecordType.final
    )


class IcatMxMr(NXcollection):
    step: Optional[str] = MetadataField(
        None, description="MR Step", record=RecordType.final
    )
    space_group: Optional[str] = MetadataField(
        None, description="MR space group", record=RecordType.final
    )
    min_resolution: Optional[str] = MetadataField(
        None, description="MR min resolution", record=RecordType.final
    )
    max_resolution: Optional[str] = MetadataField(
        None, description="MR max resolution", record=RecordType.final
    )
    Phasing: Optional[IcatMxMrPhasing] = MetadataField(None, description="")
    Refinement: Optional[IcatMxMrRefinement] = MetadataField(None, description="")
    LigandFitting: Optional[IcatMxMrLigandfitting] = MetadataField(None, description="")


class IcatMxAutoprocintegration(NXcollection):
    start_image_number: Optional[int] = MetadataField(
        None, description="First image number of the integration"
    )
    end_image_number: Optional[int] = MetadataField(
        None, description="Last image number of the integration"
    )
    detector_distance: Optional[str] = MetadataField(
        None, description="Refined detector distance"
    )
    beam_x: Optional[str] = MetadataField(None, description="Refined beam x")
    beam_y: Optional[str] = MetadataField(None, description="Refined beam y")
    rotation_axis_x: Optional[str] = MetadataField(
        None, description="X position of the rotation axis"
    )
    rotation_axis_y: Optional[str] = MetadataField(
        None, description="Y position of the rotation axis"
    )
    rotation_axis_z: Optional[str] = MetadataField(
        None, description="Z position of the rotation axis"
    )
    beam_vector_x: Optional[str] = MetadataField(None, description="Vector X")
    beam_vector_y: Optional[str] = MetadataField(None, description="Vector Y")
    beam_vector_z: Optional[str] = MetadataField(None, description="Vector Z")
    space_group: Optional[str] = MetadataField(None, description="Space group")
    cell_a: Optional[str] = MetadataField(None, description="cell a")
    cell_b: Optional[str] = MetadataField(None, description="cell b")
    cell_c: Optional[str] = MetadataField(None, description="cell c")
    cell_alpha: Optional[str] = MetadataField(None, description="cell alpha")
    cell_beta: Optional[str] = MetadataField(None, description="cell beta")
    cell_gamma: Optional[str] = MetadataField(None, description="cell gamma")
    anomalous: Optional[str] = MetadataField(None, description="anomalous")
    diffraction_limit_direction_1: Optional[str] = MetadataField(
        None,
        description="Diffraction limits (Ang.) of the ellipsoid fitted to the diffraction "
        "cut-off surface as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    diffraction_limit_direction_2: Optional[str] = MetadataField(
        None,
        description="Diffraction limits (Ang.) of the ellipsoid fitted to the diffraction "
        "cut-off surface as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    diffraction_limit_direction_3: Optional[str] = MetadataField(
        None,
        description="Diffraction limits (Ang.) of the ellipsoid fitted to the diffraction cut-off surface "
        "as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    principal_axis_1: Optional[str] = MetadataField(
        None,
        description="Corresponding principal axes of the ellipsoid fitted to the diffraction cut-off surface "
        "as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    principal_axis_2: Optional[str] = MetadataField(
        None,
        description="Corresponding principal axes of the ellipsoid fitted to the diffraction cut-off surface "
        "as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    principal_axis_3: Optional[str] = MetadataField(
        None,
        description="Corresponding principal axes of the ellipsoid fitted to the diffraction cut-off surface "
        "as direction cosines relative to the orthonormal basis (standard PDB convention), "
        "and also in terms of reciprocal unit-cell vectors",
    )
    fit_to_line_slope: Optional[str] = MetadataField(
        None,
        description="Slope of the linear regression fit of the estimated resolution per data frame",
    )
    fit_to_line_r2: Optional[str] = MetadataField(
        None,
        description="R squared of linear regression fit of estimated resolution per data frame",
    )
    fit_to_line_stdv: Optional[str] = MetadataField(
        None,
        description="Standard deviation of linear regression fit of estimated resolution per data frame",
    )
    Scaling: Optional[IcatMxAutoprocintegrationScaling] = MetadataField(
        None, description=""
    )


@register_application("MX", description="Macromolecular Crystallography")
class IcatMx(NXsubentry):
    aperture: Optional[str] = MetadataField(
        None,
        description="Aperture size in microns",
        record=RecordType.final,
    )
    kappa_settings_id: Optional[str] = MetadataField(
        None,
        description="Identifier used to distinguished between multiple kappa setting within the same data collection",
        record=RecordType.final,
    )
    beamShape: Optional[str] = MetadataField(
        None,
        description="Beam shape at sample position",
        record=RecordType.final,
    )
    beamSizeAtSampleX: Optional[PIXELS] = MetadataField(
        None,
        description="Horizontal beam size in pixels at sample position",
        record=RecordType.final,
    )
    beamSizeAtSampleY: Optional[PIXELS] = MetadataField(
        None,
        description="Vertical beam size in pixels at sample position",
        record=RecordType.final,
    )
    dataCollectionId: Optional[str] = MetadataField(
        None,
        description="ISPyB data collection id",
        record=RecordType.final,
    )
    detectorDistance: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Distance from detector to sample position",
        record=RecordType.final,
    )
    directory: Optional[str] = MetadataField(
        None,
        description="Data collection directory",
        record=RecordType.final,
    )
    exposureTime: Optional[SECONDS] = MetadataField(
        None,
        description="Exposure time per frame",
        record=RecordType.final,
    )
    flux: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Photon flux at the sample position",
        record=RecordType.final,
    )
    fluxEnd: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Flux in photon/s before data collection",
        record=RecordType.final,
    )
    motorsName: Optional[str] = MetadataField(
        None,
        description="Motor names",
        icat_name="motors_name",
        record=RecordType.final,
    )
    motorsValue: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Motor positions in mm",
        icat_name="motors_value",
        record=RecordType.final,
    )
    numberOfImages: Optional[int] = MetadataField(
        None, description="Number of images", record=RecordType.final
    )
    oscillationOverlap: Optional[DEGREES] = MetadataField(
        None,
        description="Overlap between frames",
        record=RecordType.final,
    )
    oscillationRange: Optional[DEGREES] = MetadataField(
        None,
        description="Degrees rotated per frame",
        record=RecordType.final,
    )
    oscillationStart: Optional[DEGREES] = MetadataField(
        None,
        description="Starting angle of data collection",
        record=RecordType.final,
    )
    resolution: Optional[ANGSTROMS] = MetadataField(
        None,
        description="Resolution at the edge of the detector",
        record=RecordType.final,
    )
    resolution_at_corner: Optional[ANGSTROMS] = MetadataField(
        None,
        description="Resolution at the corner of the detector",
        record=RecordType.final,
    )
    scanType: Optional[str] = MetadataField(
        None,
        description="mxCuBE experiment type",
        record=RecordType.final,
    )
    startImageNumber: Optional[int] = MetadataField(
        None,
        description="Data collection image start number",
        record=RecordType.final,
    )
    template: Optional[str] = MetadataField(
        None,
        description="Image file name template",
        record=RecordType.final,
    )
    transmission: Optional[str] = MetadataField(
        None, description="Transmission in %", record=RecordType.final
    )
    wavelength: Optional[ANGSTROMS] = MetadataField(
        None, description="Wavelength in A", record=RecordType.final
    )
    xBeam: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Horizontal beam centre in mm",
        record=RecordType.final,
    )
    yBeam: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Vertical beam centre in mm",
        record=RecordType.final,
    )
    rotation_axis: Optional[str] = MetadataField(
        None,
        description="Name of the rotation axis",
        record=RecordType.final,
    )
    axis_range: Optional[str] = MetadataField(
        None, description="Axis range", record=RecordType.final
    )
    axis_start: Optional[str] = MetadataField(
        None, description="Rotation start angle", record=RecordType.final
    )
    axis_end: Optional[str] = MetadataField(
        None, description="Rotation end angle", record=RecordType.final
    )
    SAD: Optional[IcatMxSad] = MetadataField(None, description="")
    MR: Optional[IcatMxMr] = MetadataField(None, description="")
    AutoprocIntegration: Optional[IcatMxAutoprocintegration] = MetadataField(
        None, description=""
    )
    position_id: Optional[str] = MetadataField(
        None,
        description="Identifier of the position within the crystal",
        record=RecordType.final,
    )
    characterisation_id: Optional[str] = MetadataField(
        None,
        description="Identifier of the characterisation",
        record=RecordType.final,
    )
    crystalPositionName: Optional[str] = MetadataField(
        None,
        description="Centered position, line and grid ID",
        record=RecordType.final,
    )
    phix: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Alignment table x translation",
        record=RecordType.final,
    )
    phiy: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Alignment table y translation",
        record=RecordType.final,
    )
    phiz: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Alignment table z translation",
        record=RecordType.final,
    )
    sampx: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Centring table x translation",
        record=RecordType.final,
    )
    sampy: Optional[MILLIMETERS] = MetadataField(
        None,
        description="Centring table y translation",
        record=RecordType.final,
    )
    kappa: Optional[DEGREES] = MetadataField(
        None,
        description="Mini-kappa reorientation angle",
        record=RecordType.final,
    )
    phi: Optional[DEGREES] = MetadataField(
        None,
        description="Kappa_phi rotation angle",
        record=RecordType.final,
    )
    omega: Optional[DEGREES] = MetadataField(
        None,
        description="Goniometer rotation axis",
        record=RecordType.final,
    )
