from typing import Optional

from ..base.metadata_field import MetadataField
from ..base.metadata_field import RecordType
from ..base.nexus import NXcollection
from ..base.nexus import NXsubentry
from ..base.quantity import MICROMETERS
from ..base.quantity import MILLIAMPERES
from ..base.quantity import PHOTON_FLUX
from ..base.quantity import SECONDS
from .applications import register_application


class IcatFluoMeasurement(NXcollection):
    current_start: Optional[MILLIAMPERES] = MetadataField(
        None,
        description="Storage ring current at the start of the measurement.",
        record=RecordType.initial,
    )
    current_end: Optional[MILLIAMPERES] = MetadataField(
        None,
        description="Storage ring current at the end of the measurement.",
        record=RecordType.final,
    )
    i0_start: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Incident flux at the start of the measurement.",
        record=RecordType.initial,
    )
    it_start: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Transmitted flux through the sample at the start of the measurement.",
        record=RecordType.initial,
    )
    i0_end: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Incident flux at the end of the measurement.",
        record=RecordType.final,
    )
    it_end: Optional[PHOTON_FLUX] = MetadataField(
        None,
        description="Transmitted flux through the sample at the end of the measurement.",
        record=RecordType.final,
    )


@register_application("FLUO", description="X-ray Fluorescence Imaging")
class IcatFluo(NXsubentry):
    pixelSize: Optional[MICROMETERS] = MetadataField(
        None,
        description="Size of one pixel or step in the first and second scan dimension.",
        record=RecordType.final,
    )
    dwellTime: Optional[SECONDS] = MetadataField(
        None,
        description="Time period during which the beam remains at one position.",
        record=RecordType.final,
    )
    scanDim_1: Optional[float] = MetadataField(
        None,
        description="Number of pixels in the first scan dimension.",
        icat_name="scanDim1",
        record=RecordType.final,
    )
    scanDim_2: Optional[float] = MetadataField(
        None,
        description="Number of pixels in the second scan dimension.",
        icat_name="scanDim2",
        record=RecordType.final,
    )
    scanRange_1: Optional[MICROMETERS] = MetadataField(
        None,
        description="Physical range of the first scan dimension.",
        icat_name="scanRange1",
        record=RecordType.final,
    )
    scanRange_2: Optional[MICROMETERS] = MetadataField(
        None,
        description="Physical range of the second scan dimension.",
        icat_name="scanRange2",
        record=RecordType.final,
    )
    scanAxis_1: Optional[str] = MetadataField(
        None,
        description="Motor name of the first scan axis.",
        icat_name="scanAxis1",
        record=RecordType.final,
    )
    scanAxis_2: Optional[str] = MetadataField(
        None,
        description="Motor name of the second scan axis.",
        icat_name="scanAxis2",
        record=RecordType.final,
    )
    i0: Optional[float] = MetadataField(
        None, description="Incident intensity before the sample."
    )
    it: Optional[float] = MetadataField(
        None, description="Transmitted intensity after the sample."
    )
    measurement: Optional[IcatFluoMeasurement] = MetadataField(
        None, description="X-ray fluorescence measurement parameters."
    )
