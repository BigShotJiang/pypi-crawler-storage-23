::: lean_interact.pool
    options:
      heading_level: 1
      heading: "Server Pool"
      show_symbol_type_heading: false
      members:
        - LeanServerPool
