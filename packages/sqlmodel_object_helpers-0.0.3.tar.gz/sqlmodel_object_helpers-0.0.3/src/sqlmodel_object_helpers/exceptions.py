from http import HTTPStatus


class QueryError(Exception):
    """Base exception for all library errors."""

    def __init__(self, message: str, status_code: int = HTTPStatus.BAD_REQUEST):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class ObjectNotFoundError(QueryError):
    """Raised when a requested object does not exist."""

    def __init__(self, model_name: str):
        super().__init__(f"Resource not found: {model_name}", status_code=HTTPStatus.NOT_FOUND)


class InvalidFilterError(QueryError):
    """Raised when filter parameters are invalid."""

    def __init__(self, detail: str):
        super().__init__(detail, status_code=HTTPStatus.BAD_REQUEST)


class InvalidLoadPathError(QueryError):
    """Raised when a load_path references a non-existent field or relationship."""

    def __init__(self, model_name: str, field_name: str):
        super().__init__(
            f"Model {model_name} has no field {field_name}",
            status_code=HTTPStatus.BAD_REQUEST,
        )


class DatabaseError(QueryError):
    """Raised for unexpected database errors (connection, timeout, etc.)."""

    def __init__(self, detail: str):
        super().__init__(detail, status_code=HTTPStatus.INTERNAL_SERVER_ERROR)


class MutationError(QueryError):
    """
    Raised when a create/update/delete operation fails.

    Covers constraint violations, invalid field names in update data,
    and other mutation-specific errors.
    """

    def __init__(self, detail: str):
        super().__init__(detail, status_code=HTTPStatus.BAD_REQUEST)
