import logging
import time
from typing import Any

from pydantic import BaseModel
from sqlalchemy import exists as sa_exists
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func
from sqlmodel import SQLModel, and_, or_, select

from .constants import settings
from .exceptions import DatabaseError, InvalidFilterError, ObjectNotFoundError, QueryError
from .filters import build_filter, build_flat_filter, flatten_filters
from .loaders import build_load_chain
from .operators import SUPPORTED_OPERATORS, Operator
from .types.filters import LogicalFilter, OrderAsc, OrderBy, OrderDesc, TimeFilter
from .types.pagination import GetAllPagination, Pagination, PaginationR
from .types.projections import ColumnSpec

logger = logging.getLogger("sqlmodel_object_helpers")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _apply_joins(stmt: Any, joins: list[Any]) -> Any:
    """
    Apply a list of join tuples to a statement.

    Supports 2-tuple (model, rel_prop) and 3-tuple (model, target, condition).
    """
    for join in joins:
        if len(join) == 2:
            _base_model, rel_prop = join
            target_model = rel_prop.mapper.class_
            stmt = stmt.join(target_model, rel_prop.primaryjoin)
        elif len(join) == 3:
            _base_model, target_model, condition = join
            stmt = stmt.join(target_model, condition)
        else:
            msg = f"Invalid join format: {join}"
            raise InvalidFilterError(msg)
    return stmt


def _apply_extra_joins(stmt: Any, extra_joins: list[tuple[Any, ...]]) -> Any:
    """Apply user-provided extra join tuples to a statement."""
    for join in extra_joins:
        if len(join) == 2:
            target, condition = join
            stmt = stmt.join(target, condition)
        elif len(join) == 3:
            target, condition, is_outer = join
            stmt = stmt.join(target, condition, isouter=is_outer)
        else:
            msg = f"Invalid join format: {join}"
            raise InvalidFilterError(msg)
    return stmt


def _build_load_options_list[T: SQLModel](
    model: type[T],
    load_paths: list[str | list[str] | tuple[str, ...]],
    *,
    suspend_error: bool,
) -> list[Any]:
    """Build load options list using unified build_load_chain."""
    load_options: list[Any] = []
    try:
        for path in load_paths:
            option = build_load_chain(model, path, suspend_error=suspend_error)
            if option is not None:
                load_options.append(option)
    except Exception as e:
        if not suspend_error:
            raise InvalidFilterError(str(e)) from e
    return load_options


def _build_time_filter_conditions[T: SQLModel](
    model: type[T],
    time_filter: TimeFilter,
) -> list[Any]:
    """Build WHERE conditions from a TimeFilter."""
    conditions: list[Any] = []
    field_map = {
        "created_after": ("created_at", Operator.GE),
        "created_before": ("created_at", Operator.LT),
        "updated_after": ("updated_at", Operator.GE),
        "updated_before": ("updated_at", Operator.LT),
    }
    for tf_field, (model_field, op) in field_map.items():
        value = getattr(time_filter, tf_field)
        if value is None:
            continue
        if not hasattr(model, model_field):
            continue
        attr = getattr(model, model_field)
        conditions.append(SUPPORTED_OPERATORS[op](attr, value))
    return conditions


def _build_order_by[T: SQLModel](
    model: type[T],
    order_by: OrderBy,
    *,
    suspend_error: bool,
) -> list[Any]:
    """Build ORDER BY expressions from an OrderBy model."""
    order_expressions: list[Any] = []
    for sort in order_by.sorts:
        if isinstance(sort, OrderAsc) and sort.asc:
            try:
                attr = getattr(model, sort.asc)
                order_expressions.append(attr.asc())
            except AttributeError:
                if not suspend_error:
                    msg = f"Model {model.__name__} has no field {sort.asc}"
                    raise InvalidFilterError(msg) from None
        elif isinstance(sort, OrderDesc) and sort.desc:
            try:
                attr = getattr(model, sort.desc)
                order_expressions.append(attr.desc())
            except AttributeError:
                if not suspend_error:
                    msg = f"Model {model.__name__} has no field {sort.desc}"
                    raise InvalidFilterError(msg) from None
    return order_expressions


async def _execute_with_pagination[T: SQLModel](
    session: AsyncSession,
    stmt: Any,
    pagination: Pagination,
) -> GetAllPagination[T]:
    """Execute a statement with pagination, returning paginated result."""
    if pagination.page is None or pagination.page < 1:
        msg = "Page must be greater than 0"
        raise InvalidFilterError(msg)
    if pagination.per_page is None or pagination.per_page < 1:
        msg = "Per-page count must be greater than 0"
        raise InvalidFilterError(msg)
    if pagination.per_page > settings.max_per_page:
        msg = f"per_page ({pagination.per_page}) exceeds maximum ({settings.max_per_page})"
        raise InvalidFilterError(msg)

    total_subq = stmt.subquery()
    total_stmt = select(func.count()).select_from(total_subq)
    total = await session.scalar(total_stmt)

    stmt = stmt.limit(pagination.per_page).offset(
        (pagination.page - 1) * pagination.per_page
    )
    result = await session.execute(stmt)
    data = list(result.scalars().unique().all())

    return GetAllPagination(
        data=data,
        pagination=PaginationR(
            page=pagination.page,
            per_page=pagination.per_page,
            total=total or 0,
        ),
    )


async def _execute_with_pagination_dicts(
    session: AsyncSession,
    stmt: Any,
    pagination: Pagination,
) -> GetAllPagination[dict[str, Any]]:
    """Execute a column-mode statement with pagination, returning paginated dicts."""
    if pagination.page is None or pagination.page < 1:
        msg = "Page must be greater than 0"
        raise InvalidFilterError(msg)
    if pagination.per_page is None or pagination.per_page < 1:
        msg = "Per-page count must be greater than 0"
        raise InvalidFilterError(msg)
    if pagination.per_page > settings.max_per_page:
        msg = f"per_page ({pagination.per_page}) exceeds maximum ({settings.max_per_page})"
        raise InvalidFilterError(msg)

    total_subq = stmt.subquery()
    total_stmt = select(func.count()).select_from(total_subq)
    total = await session.scalar(total_stmt)

    stmt = stmt.limit(pagination.per_page).offset(
        (pagination.page - 1) * pagination.per_page
    )
    result = await session.execute(stmt)
    data = [dict(m) for m in result.mappings().all()]

    return GetAllPagination(
        data=data,
        pagination=PaginationR(
            page=pagination.page,
            per_page=pagination.per_page,
            total=total or 0,
        ),
    )


# ---------------------------------------------------------------------------
# get_object
# ---------------------------------------------------------------------------


async def get_object[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    pk: dict[str, Any] | None = None,
    filters: BaseModel | dict[str, Any] | None = None,
    load_paths: list[str | tuple[str, ...]] | None = None,
    *,
    suspend_error: bool = False,
    order_by: Any | None = None,
    columns: list[Any] | None = None,
    extra_joins: list[tuple[Any, ...]] | None = None,
    limit_one: bool = True,
    for_update: bool = False,
) -> list[dict[str, Any]] | T | None:
    """
    Fetch a single object by primary key or filters.

    Supports two modes:
    - ORM mode: returns a model instance with eager-loaded relationships
    - SQL mode (columns + extra_joins): returns flat dicts
    """
    start = time.perf_counter()

    stmt = select(*columns) if columns else select(model)

    if extra_joins:
        stmt = _apply_extra_joins(stmt, extra_joins)

    if pk:
        pk_columns = [col.name for col in model.__table__.primary_key]  # type: ignore[attr-defined]  # SQLAlchemy metaclass
        if not all(k in pk_columns for k in pk):
            msg = f"Invalid pk keys: {pk.keys()}. Expected: {pk_columns}"
            raise InvalidFilterError(msg)
        pk_conditions = [getattr(model, key) == value for key, value in pk.items()]
        stmt = stmt.where(and_(*pk_conditions))
    elif filters:
        if isinstance(filters, LogicalFilter):
            filter_dict = filters.model_dump(exclude_unset=True)
        elif isinstance(filters, BaseModel):
            filter_dict = flatten_filters(filters.model_dump(exclude_unset=True))
        else:
            filter_dict = filters
        filter_expr, joins = build_filter(model, filter_dict)
        if filter_expr is not None:
            stmt = stmt.where(filter_expr)
        stmt = _apply_joins(stmt, joins)

    if load_paths and not columns:
        load_options = _build_load_options_list(model, load_paths, suspend_error=suspend_error)
        if load_options:
            stmt = stmt.options(*load_options)

    if order_by is not None:
        stmt = stmt.order_by(*order_by) if isinstance(order_by, (list, tuple)) else stmt.order_by(order_by)

    if for_update:
        stmt = stmt.with_for_update()

    if limit_one:
        stmt = stmt.limit(1)

    result = await session.execute(stmt)
    elapsed = time.perf_counter() - start

    if columns:
        data = [dict(m) for m in result.mappings().all()]
        logger.debug(
            "get_object(%s, pk=%s) → %d rows, %.3fs",
            model.__name__, pk, len(data), elapsed,
        )
        return data

    obj: T | None = result.scalars().unique().one_or_none()
    logger.debug(
        "get_object(%s, pk=%s) → %s, %.3fs",
        model.__name__, pk, "found" if obj else "None", elapsed,
    )
    if obj is None and not suspend_error:
        raise ObjectNotFoundError(model.__name__)
    return obj


# ---------------------------------------------------------------------------
# get_objects
# ---------------------------------------------------------------------------


async def get_objects[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    load_paths: list[str | list[str]] | None = None,
    logical_operator: str = "AND",
    *,
    suspend_error: bool = False,
    pagination: Pagination | None = None,
    order_by: Any | None = None,
    time_filter: TimeFilter | None = None,
    columns: list[Any] | None = None,
    extra_joins: list[tuple[Any, ...]] | None = None,
) -> list[T] | list[dict[str, Any]] | GetAllPagination[T] | GetAllPagination[dict[str, Any]]:
    """
    Fetch multiple objects with filtering, eager loading, pagination, and sorting.

    Two modes:
    - ORM mode (default): returns model instances, supports load_paths
    - SQL mode (columns=): returns flat dicts with only selected fields, supports extra_joins

    ``order_by`` accepts both ``OrderBy`` model (base model fields) and raw SQLAlchemy
    expressions (e.g. ``Attempt.id.desc()``, useful in columns mode for aliased fields).
    """
    start = time.perf_counter()

    # Validate mutually exclusive parameters
    if columns and load_paths:
        msg = "Parameters 'columns' and 'load_paths' cannot be used together"
        raise QueryError(msg)

    # Build load options (unified — selectinload/joinedload by uselist)
    load_options: list[Any] = []
    if load_paths:
        load_options = _build_load_options_list(model, load_paths, suspend_error=suspend_error)

    # Process filters via build_flat_filter
    if isinstance(filters, BaseModel):
        flat_filters = flatten_filters(filters.model_dump(exclude_unset=True))
    elif filters is None:
        flat_filters = {}
    else:
        flat_filters = filters

    conditions, join_entities = build_flat_filter(model, flat_filters, suspend_error=suspend_error)

    # Build statement
    stmt = select(*columns).select_from(model) if columns else select(model)

    if extra_joins:
        stmt = _apply_extra_joins(stmt, extra_joins)

    for alias, rel_attr in join_entities:
        stmt = stmt.join(alias, rel_attr, isouter=True)

    # Apply conditions (fix: skip .where() when no conditions)
    if conditions:
        logical_operator = logical_operator.upper()
        combined = and_(*conditions) if logical_operator == "AND" else or_(*conditions)
        stmt = stmt.where(combined)

    # Apply time filter
    if time_filter:
        time_conditions = _build_time_filter_conditions(model, time_filter)
        if time_conditions:
            stmt = stmt.where(and_(*time_conditions))

    if load_options and not columns:
        stmt = stmt.options(*load_options)

    # Sorting
    if order_by is not None:
        if isinstance(order_by, OrderBy):
            order_expressions = _build_order_by(model, order_by, suspend_error=suspend_error)
            if order_expressions:
                stmt = stmt.order_by(*order_expressions)
        elif isinstance(order_by, (list, tuple)):
            stmt = stmt.order_by(*order_by)
        else:
            stmt = stmt.order_by(order_by)

    try:
        # Pagination
        if pagination:
            if columns:
                paginated = await _execute_with_pagination_dicts(session, stmt, pagination)
            else:
                paginated = await _execute_with_pagination(session, stmt, pagination)
            elapsed = time.perf_counter() - start
            logger.debug(
                "get_objects(%s) → %d rows, total=%d, %.3fs",
                model.__name__, len(paginated.data),
                paginated.pagination.total if paginated.pagination else 0, elapsed,
            )
            return paginated

        result = await session.execute(stmt)
        data = [dict(m) for m in result.mappings().all()] if columns else list(result.scalars().unique().all())
    except QueryError:
        if not suspend_error:
            raise
        return []
    except Exception as e:
        if not suspend_error:
            raise DatabaseError(str(e)) from e
        return []
    else:
        elapsed = time.perf_counter() - start
        logger.debug(
            "get_objects(%s) → %d rows, %.3fs",
            model.__name__, len(data), elapsed,
        )
        return data


# ---------------------------------------------------------------------------
# count_objects
# ---------------------------------------------------------------------------


async def count_objects[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    logical_operator: str = "AND",
    *,
    suspend_error: bool = False,
    extra_joins: list[tuple[Any, ...]] | None = None,
    time_filter: TimeFilter | None = None,
) -> int:
    """
    Return the number of records matching the given filters.

    Issues a single ``SELECT count(*) FROM ... WHERE ...`` — no objects
    are loaded into memory.
    """
    start = time.perf_counter()

    if isinstance(filters, BaseModel):
        flat_filters = flatten_filters(filters.model_dump(exclude_unset=True))
    elif filters is None:
        flat_filters = {}
    else:
        flat_filters = filters

    conditions, join_entities = build_flat_filter(model, flat_filters, suspend_error=suspend_error)

    stmt = select(func.count()).select_from(model)

    if extra_joins:
        stmt = _apply_extra_joins(stmt, extra_joins)

    for alias, rel_attr in join_entities:
        stmt = stmt.join(alias, rel_attr, isouter=True)

    if conditions:
        logical_operator = logical_operator.upper()
        combined = and_(*conditions) if logical_operator == "AND" else or_(*conditions)
        stmt = stmt.where(combined)

    if time_filter:
        time_conditions = _build_time_filter_conditions(model, time_filter)
        if time_conditions:
            stmt = stmt.where(and_(*time_conditions))

    try:
        result = await session.scalar(stmt)
    except QueryError:
        if not suspend_error:
            raise
        return 0
    except Exception as e:
        if not suspend_error:
            raise DatabaseError(str(e)) from e
        return 0
    else:
        elapsed = time.perf_counter() - start
        logger.debug(
            "count_objects(%s) → %d, %.3fs",
            model.__name__, result or 0, elapsed,
        )
        return result or 0


# ---------------------------------------------------------------------------
# exists_object
# ---------------------------------------------------------------------------


async def exists_object[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    pk: dict[str, Any] | None = None,
    filters: dict[str, Any | list[Any]] | BaseModel | None = None,
    *,
    suspend_error: bool = False,
) -> bool:
    """
    Check whether at least one record matches the given criteria.

    Uses ``EXISTS (SELECT ... LIMIT 1)`` — the database stops at the
    first match without reading any row data.
    """
    start = time.perf_counter()

    inner = select(model)

    if pk:
        pk_columns = [col.name for col in model.__table__.primary_key]  # type: ignore[attr-defined]
        if not all(k in pk_columns for k in pk):
            msg = f"Invalid pk keys: {pk.keys()}. Expected: {pk_columns}"
            raise InvalidFilterError(msg)
        pk_conditions = [getattr(model, key) == value for key, value in pk.items()]
        inner = inner.where(and_(*pk_conditions))
    elif filters:
        if isinstance(filters, BaseModel):
            flat_filters = flatten_filters(filters.model_dump(exclude_unset=True))
        else:
            flat_filters = filters
        conditions, join_entities = build_flat_filter(model, flat_filters, suspend_error=suspend_error)
        for alias, rel_attr in join_entities:
            inner = inner.join(alias, rel_attr, isouter=True)
        if conditions:
            inner = inner.where(and_(*conditions))

    stmt = select(sa_exists(inner.limit(1)))

    try:
        result = await session.scalar(stmt)
    except QueryError:
        if not suspend_error:
            raise
        return False
    except Exception as e:
        if not suspend_error:
            raise DatabaseError(str(e)) from e
        return False
    else:
        elapsed = time.perf_counter() - start
        logger.debug(
            "exists_object(%s) → %s, %.3fs",
            model.__name__, result, elapsed,
        )
        return bool(result)


# ---------------------------------------------------------------------------
# get_projection
# ---------------------------------------------------------------------------


def _resolve_projection_columns[T: SQLModel](
    model: type[T],
    columns: list[ColumnSpec],
    outer_join_paths: set[str],
) -> tuple[list[Any], list[tuple[Any, Any, bool]]]:
    """
    Resolve column specs into SQLAlchemy select columns and join tuples.

    Walks ORM relationship chains from dot-notation paths,
    registers required JOINs, and builds labelled column expressions.

    Returns ``(select_columns, joins)`` where joins is a list of
    ``(target_model, primaryjoin_condition, is_outer)`` tuples.
    """
    select_columns: list[Any] = []
    joins: list[tuple[Any, Any, bool]] = []
    seen_joins: dict[str, type[SQLModel]] = {}

    for spec in columns:
        if isinstance(spec, tuple):
            path, alias = spec
        else:
            path = spec
            alias = None

        parts = path.split(".")

        if len(parts) == 1:
            try:
                attr = getattr(model, parts[0])
            except AttributeError:
                msg = f"Field '{parts[0]}' not found in model {model.__name__}"
                raise InvalidFilterError(msg) from None
            select_columns.append(attr.label(alias) if alias else attr)
            continue

        # Walk relationship chain (all parts except the last = field name)
        current_model: type[SQLModel] = model
        for i, part in enumerate(parts[:-1]):
            join_key = ".".join(parts[: i + 1])

            if join_key in seen_joins:
                current_model = seen_joins[join_key]
                continue

            try:
                relationships = current_model.__mapper__.relationships  # type: ignore[attr-defined]  # SQLAlchemy metaclass
            except AttributeError:
                msg = f"Model {current_model.__name__} has no mapper"
                raise InvalidFilterError(msg) from None

            if part not in relationships:
                msg = f"Relationship '{part}' not found in model {current_model.__name__}"
                raise InvalidFilterError(msg)

            rel_prop = relationships[part]
            target_model: type[SQLModel] = rel_prop.mapper.class_
            is_outer = join_key in outer_join_paths
            joins.append((target_model, rel_prop.primaryjoin, is_outer))
            seen_joins[join_key] = target_model
            current_model = target_model

        # Get the terminal column attribute
        field_name = parts[-1]
        try:
            attr = getattr(current_model, field_name)
        except AttributeError:
            msg = f"Field '{field_name}' not found in model {current_model.__name__}"
            raise InvalidFilterError(msg) from None

        select_columns.append(attr.label(alias) if alias else attr)

    return select_columns, joins


async def get_projection[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    columns: list[ColumnSpec],
    pk: dict[str, Any] | None = None,
    filters: BaseModel | dict[str, Any] | None = None,
    outer_joins: list[str] | None = None,
    *,
    suspend_error: bool = False,
    order_by: Any | None = None,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """
    Fetch specific columns from related tables using dot-notation paths.

    Unlike ``get_object`` (which returns full ORM instances), this function
    selects specific columns across multiple joined tables and returns flat
    dicts.  JOINs are resolved automatically from the model's ORM
    relationships.

    Args:
        session: Async SQLAlchemy session.
        model: Primary SQLModel class to query from.
        columns: Column specifications — strings for direct fields or
            ``(dot.path, alias)`` tuples for related fields.
        pk: Primary key filter dict.
        filters: Flat dict or Pydantic BaseModel for WHERE conditions.
        outer_joins: Dot-notation relationship paths that should use
            LEFT OUTER JOIN (e.g. ``["applications.attempt.schedule"]``).
        suspend_error: If True, return ``[]`` on errors instead of raising.
        order_by: SQLAlchemy ORDER BY expression(s).
        limit: Maximum number of rows to return.

    Returns:
        List of dicts with selected column values.

    """
    start = time.perf_counter()
    outer_join_set = set(outer_joins or [])

    try:
        select_cols, joins = _resolve_projection_columns(
            model, columns, outer_join_set
        )
    except InvalidFilterError:
        if suspend_error:
            return []
        raise

    stmt = select(*select_cols).select_from(model)

    # Apply column-resolved JOINs
    for target, condition, is_outer in joins:
        stmt = stmt.join(target, condition, isouter=is_outer)

    # Apply PK filter
    if pk:
        pk_conditions = [
            getattr(model, key) == value for key, value in pk.items()
        ]
        stmt = stmt.where(and_(*pk_conditions))
    elif filters:
        if isinstance(filters, LogicalFilter):
            filter_dict = filters.model_dump(exclude_unset=True)
            filter_expr, filter_joins = build_filter(model, filter_dict)
            if filter_expr is not None:
                stmt = stmt.where(filter_expr)
            stmt = _apply_joins(stmt, filter_joins)
        elif isinstance(filters, BaseModel):
            flat = flatten_filters(filters.model_dump(exclude_unset=True))
            conditions, join_entities = build_flat_filter(
                model, flat, suspend_error=suspend_error
            )
            for alias, rel_attr in join_entities:
                stmt = stmt.join(alias, rel_attr, isouter=True)
            if conditions:
                stmt = stmt.where(and_(*conditions))
        else:
            conditions, join_entities = build_flat_filter(
                model, filters, suspend_error=suspend_error
            )
            for alias, rel_attr in join_entities:
                stmt = stmt.join(alias, rel_attr, isouter=True)
            if conditions:
                stmt = stmt.where(and_(*conditions))

    if order_by is not None:
        stmt = stmt.order_by(*order_by) if isinstance(order_by, (list, tuple)) else stmt.order_by(order_by)

    if limit is not None:
        stmt = stmt.limit(limit)

    try:
        result = await session.execute(stmt)
        data = [dict(m) for m in result.mappings().all()]
    except QueryError:
        if suspend_error:
            return []
        raise
    except Exception as e:
        if suspend_error:
            return []
        raise DatabaseError(str(e)) from e
    else:
        elapsed = time.perf_counter() - start
        logger.debug(
            "get_projection(%s) → %d rows, %.3fs",
            model.__name__, len(data), elapsed,
        )
        return data
