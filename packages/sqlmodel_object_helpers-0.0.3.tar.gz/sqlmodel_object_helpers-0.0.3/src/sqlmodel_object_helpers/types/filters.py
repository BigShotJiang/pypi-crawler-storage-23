from datetime import date, datetime, timedelta
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from ..constants import settings


class FilterInt(BaseModel):
    eq: int | None = None
    ne: int | None = None
    gt: int | None = None
    lt: int | None = None
    ge: int | None = None
    le: int | None = None
    in_: list[int] | None = None

    @field_validator("eq", "ne", "gt", "lt", "ge", "le", mode="before")
    @classmethod
    def validate_int(cls, v: Any) -> Any:
        if isinstance(v, str):
            try:
                return int(v)
            except (ValueError, TypeError) as err:
                msg = "Value must be a number or a numeric string"
                raise ValueError(msg) from err
        return v

    @field_validator("in_", mode="before")
    @classmethod
    def validate_in_list(cls, v: Any) -> Any:
        if v is None:
            return v
        if not isinstance(v, list):
            msg = "in_ must be a list"
            raise ValueError(msg)
        if len(v) > settings.max_in_list_size:
            msg = f"in_ cannot contain more than {settings.max_in_list_size} elements"
            raise ValueError(msg)
        result: list[int] = []
        for item in v:
            if isinstance(item, int):
                result.append(item)
            elif isinstance(item, str):
                try:
                    result.append(int(item))
                except (ValueError, TypeError) as err:
                    msg = f"in_ list item must be a number, got: {item!r}"
                    raise ValueError(msg) from err
            else:
                msg = f"in_ list item must be a number, got: {item!r}"
                raise ValueError(msg)
        return result


class FilterStr(BaseModel):
    eq: str | None = None
    ne: str | None = None
    like: str | None = None
    ilike: str | None = None


class FilterDate(BaseModel):
    eq: date | None = None
    ne: date | None = None
    gt: date | None = None
    lt: date | None = None
    ge: date | None = None
    le: date | None = None


class FilterDatetime(BaseModel):
    eq: datetime | None = None
    ne: datetime | None = None
    gt: datetime | None = None
    lt: datetime | None = None
    ge: datetime | None = None
    le: datetime | None = None


class FilterTimedelta(BaseModel):
    eq: timedelta | None = None
    ne: timedelta | None = None
    gt: timedelta | None = None
    lt: timedelta | None = None
    ge: timedelta | None = None
    le: timedelta | None = None


class FilterBool(BaseModel):
    eq: bool | None = None
    ne: bool | None = None


class FilterExists(BaseModel):
    exists: bool


class OrderAsc(BaseModel):
    asc: str | None = None


class OrderDesc(BaseModel):
    desc: str | None = None


class OrderBy(BaseModel):
    sorts: list[OrderAsc | OrderDesc] = []


class LogicalFilter(BaseModel):
    model_config = ConfigDict(extra="forbid")

    AND: list[LogicalFilter] | None = None
    OR: list[LogicalFilter] | None = None
    condition: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_single_key(self) -> Self:
        set_fields = sum(
            1 for f in ("AND", "OR", "condition") if getattr(self, f) is not None
        )
        if set_fields != 1:
            msg = "Exactly one of AND, OR, or condition must be set"
            raise ValueError(msg)
        return self


class TimeFilter(BaseModel):
    """
    Filter by created_at / updated_at datetime ranges.

    All fields are optional — only set fields are applied.
    """

    model_config = ConfigDict(extra="forbid")

    created_after: datetime | None = None
    created_before: datetime | None = None
    updated_after: datetime | None = None
    updated_before: datetime | None = None

    @model_validator(mode="after")
    def validate_ranges(self) -> Self:
        if (
            self.created_after is not None
            and self.created_before is not None
            and self.created_after >= self.created_before
        ):
            msg = "created_after must be before created_before"
            raise ValueError(msg)
        if (
            self.updated_after is not None
            and self.updated_before is not None
            and self.updated_after >= self.updated_before
        ):
            msg = "updated_after must be before updated_before"
            raise ValueError(msg)
        if (
            self.created_after is not None
            and self.updated_before is not None
            and self.created_after >= self.updated_before
        ):
            msg = (
                "created_after cannot be >= updated_before "
                "(a record's update time cannot be earlier than its creation time)"
            )
            raise ValueError(msg)
        return self
