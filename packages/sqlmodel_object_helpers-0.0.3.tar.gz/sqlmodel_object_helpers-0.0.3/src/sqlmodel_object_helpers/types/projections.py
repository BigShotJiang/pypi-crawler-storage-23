"""Types for projection queries."""

type ColumnSpec = str | tuple[str, str]
"""Column specification for get_projection().

- ``"last_name"`` — direct field from the primary model
- ``("applications.attempt.unit.address", "unit_address")`` — dot-notation path + SQL alias
"""
