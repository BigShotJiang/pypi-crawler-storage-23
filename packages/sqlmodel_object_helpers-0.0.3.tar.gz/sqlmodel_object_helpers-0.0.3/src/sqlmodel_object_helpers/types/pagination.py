from pydantic import BaseModel, Field


class Pagination(BaseModel):
    page: int | None = Field(default=1, ge=1)
    per_page: int | None = Field(default=10, ge=1)


class PaginationR(Pagination):
    total: int


class GetAllPagination[T](BaseModel):
    data: list[T]
    pagination: PaginationR | None = None
