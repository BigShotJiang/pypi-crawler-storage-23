from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable


class Operator(StrEnum):
    EQ = "eq"
    NE = "ne"
    GT = "gt"
    LT = "lt"
    GE = "ge"
    LE = "le"
    IN = "in_"  # Python-safe alias for SQL IN (field name in FilterInt is `in_`)
    LIKE = "like"
    ILIKE = "ilike"
    BETWEEN = "between"
    IS = "is"
    IS_NOT = "isnot"
    MATCH = "match"
    NOT_IN = "not_in"


SUPPORTED_OPERATORS: dict[str, Callable[[Any, Any], Any]] = {
    Operator.EQ: lambda a, v: a == v,
    Operator.NE: lambda a, v: a != v,
    Operator.GT: lambda a, v: a > v,
    Operator.LT: lambda a, v: a < v,
    Operator.GE: lambda a, v: a >= v,
    Operator.LE: lambda a, v: a <= v,
    Operator.IN: lambda a, v: a.in_(v),
    "in": lambda a, v: a.in_(v),  # alias: raw dict filters use "in", model_dump() uses "in_"
    Operator.LIKE: lambda a, v: a.like(v),
    Operator.ILIKE: lambda a, v: a.ilike(v),
    Operator.BETWEEN: lambda a, v: a.between(v[0], v[1]),
    Operator.IS: lambda a, v: a.is_(v),
    Operator.IS_NOT: lambda a, v: a.is_not(v),
    Operator.MATCH: lambda a, v: a.match(v),
    Operator.NOT_IN: lambda a, v: ~a.in_(v),
    "exists": lambda a, v: a.is_not(None) if v else a.is_(None),
}

# Operators with extended handling in _apply_filter_value (RelationshipProperty check)
SPECIAL_OPERATORS: frozenset[str] = frozenset({"exists"})
