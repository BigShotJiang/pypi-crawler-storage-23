"""sqlmodel-object-helpers — reusable query helpers for SQLModel projects."""

__version__ = "0.0.3"

from .constants import QueryHelperSettings, settings
from .exceptions import (
    DatabaseError,
    InvalidFilterError,
    InvalidLoadPathError,
    MutationError,
    ObjectNotFoundError,
    QueryError,
)
from .filters import build_filter, build_flat_filter, flatten_filters
from .loaders import build_load_chain, build_load_options
from .operators import SPECIAL_OPERATORS, SUPPORTED_OPERATORS, Operator
from .mutations import (
    add_object,
    add_objects,
    check_for_related_records,
    delete_object,
    delete_objects,
    update_object,
    update_objects,
)
from .query import count_objects, exists_object, get_object, get_objects, get_projection
from .session import create_session_dependency
from .types.filters import (
    FilterBool,
    FilterDate,
    FilterDatetime,
    FilterExists,
    FilterInt,
    FilterStr,
    FilterTimedelta,
    LogicalFilter,
    OrderAsc,
    OrderBy,
    OrderDesc,
    TimeFilter,
)
from .types.pagination import (
    GetAllPagination,
    Pagination,
    PaginationR,
)
from .types.projections import ColumnSpec

__all__ = [
    "add_object",
    "add_objects",
    "build_filter",
    "build_flat_filter",
    "build_load_chain",
    "build_load_options",
    "check_for_related_records",
    "ColumnSpec",
    "count_objects",
    "create_session_dependency",
    "DatabaseError",
    "delete_object",
    "delete_objects",
    "exists_object",
    "FilterBool",
    "FilterDate",
    "FilterDatetime",
    "FilterExists",
    "FilterInt",
    "FilterStr",
    "FilterTimedelta",
    "flatten_filters",
    "get_object",
    "get_objects",
    "get_projection",
    "GetAllPagination",
    "InvalidFilterError",
    "InvalidLoadPathError",
    "LogicalFilter",
    "MutationError",
    "ObjectNotFoundError",
    "Operator",
    "OrderAsc",
    "OrderBy",
    "OrderDesc",
    "Pagination",
    "PaginationR",
    "QueryError",
    "QueryHelperSettings",
    "settings",
    "SPECIAL_OPERATORS",
    "SUPPORTED_OPERATORS",
    "TimeFilter",
    "update_object",
    "update_objects",
]
