"""
Security and performance limits for query building.

All values have sensible defaults. Override at application startup:

    from sqlmodel_object_helpers import settings
    settings.max_per_page = 300
    settings.max_filter_depth = 50
"""

from pydantic import BaseModel


class QueryHelperSettings(BaseModel):
    """
    Mutable settings for query-helper limits.

    Attributes:
        max_filter_depth: Maximum recursion depth for build_filter (AND/OR nesting).
            Each depth level ≈ 3 Python call frames, so 100 depth ≈ 300 frames
            (safe under Python's default recursion limit of 1000).
        max_and_or_items: Maximum number of sub-filters in a single AND/OR list.
        max_load_depth: Maximum depth of eager-loading chains
            (e.g. "application.applicant.educations" = 3).
        max_in_list_size: Maximum number of elements in an IN(...) list.
        max_per_page: Maximum value for per_page in pagination.

    """

    max_filter_depth: int = 100
    max_and_or_items: int = 100
    max_load_depth: int = 10
    max_in_list_size: int = 1000
    max_per_page: int = 500


settings = QueryHelperSettings()
