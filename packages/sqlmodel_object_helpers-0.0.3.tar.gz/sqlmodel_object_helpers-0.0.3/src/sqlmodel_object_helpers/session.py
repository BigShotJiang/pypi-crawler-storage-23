from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker


def create_session_dependency(factory: async_sessionmaker):
    """
    Create an async session generator for FastAPI Depends.

    Contract: the library calls flush() on mutations,
    this generator calls commit() on success, rollback() on error.

    Usage::

        get_session = create_session_dependency(async_session_factory)
        DbSession = Annotated[AsyncSession, Depends(get_session)]

        @router.get("/")
        async def endpoint(session: DbSession):
            ...
    """

    async def get_session() -> AsyncGenerator[AsyncSession]:
        async with factory() as session:
            try:
                yield session
            except Exception:
                await session.rollback()
                raise
            else:
                try:
                    await session.commit()
                except Exception:
                    await session.rollback()
                    raise

    return get_session
