from typing import Any

from sqlalchemy.orm import joinedload, selectinload
from sqlmodel import SQLModel

from .constants import settings
from .exceptions import InvalidFilterError, InvalidLoadPathError


def build_load_options(model: type[SQLModel], attrs: list[str]) -> Any | None:
    """
    Recursively build a single loader option chain.

    Uses selectinload for one-to-many (uselist=True) to avoid cartesian products,
    joinedload for many-to-one (uselist=False) for single-query efficiency.
    """
    if not attrs:
        return None
    if len(attrs) > settings.max_load_depth:
        return None
    attr_name = attrs[0]
    if attr_name.startswith("_") or not hasattr(model, attr_name):
        return None
    rel_attr = getattr(model, attr_name)
    prop = rel_attr.property
    loader = selectinload if getattr(prop, "uselist", False) else joinedload
    if len(attrs) > 1:
        nested_model = prop.mapper.class_
        nested_loader = build_load_options(nested_model, attrs[1:])
        if nested_loader:
            return loader(rel_attr).options(nested_loader)
        return loader(rel_attr)
    return loader(rel_attr)


def build_load_chain(
    model: type[SQLModel],
    path: str | list[str] | tuple[str, ...],
    *,
    suspend_error: bool = False,
) -> Any | None:
    """
    Build a load option chain from a path (string or list).

    Unified entry point for both get_object and get_objects.
    Uses selectinload for uselist=True, joinedload for uselist=False.

    Returns None if the path is invalid and suspend_error=True.
    Raises InvalidLoadPathError if the path is invalid and suspend_error=False.
    """
    attrs = path.split(".") if isinstance(path, str) else list(path)

    if not attrs:
        return None
    if len(attrs) > settings.max_load_depth:
        if not suspend_error:
            msg = f"Load path depth ({len(attrs)}) exceeds limit of {settings.max_load_depth}"
            raise InvalidFilterError(msg)
        return None

    current_model = model
    loader: Any = None

    for attr_name in attrs:
        if attr_name.startswith("_"):
            if not suspend_error:
                raise InvalidLoadPathError(current_model.__name__, attr_name)
            return None
        if not hasattr(current_model, attr_name):
            if not suspend_error:
                raise InvalidLoadPathError(current_model.__name__, attr_name)
            return None

        rel_attr = getattr(current_model, attr_name)
        prop = rel_attr.property

        if loader is None:
            strategy = selectinload if getattr(prop, "uselist", False) else joinedload
            loader = strategy(rel_attr)
        elif getattr(prop, "uselist", False):
            loader = loader.selectinload(rel_attr)
        else:
            loader = loader.joinedload(rel_attr)

        current_model = prop.mapper.class_

    return loader
