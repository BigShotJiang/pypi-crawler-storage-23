"""
Mutation helpers for SQLModel: add, update, delete.

All functions use ``session.flush()`` instead of ``session.commit()`` —
the caller manages transaction boundaries (commit / rollback).

``flush()`` sends SQL to the database and synchronises the session state
**without** ending the transaction, so changes can still be rolled back.
``commit()`` performs a flush and then finalises the transaction, making
changes permanent.  By only flushing here, multiple mutations can be
composed into a single atomic transaction at the call-site::

    async with session.begin():
        await add_object(session, billing)
        await add_object(session, payment)
        # commit happens automatically when the block exits
"""

import logging
import time
from typing import Any

from sqlalchemy import delete as sa_delete, inspect, update as sa_update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import ONETOMANY
from sqlmodel import SQLModel, and_, or_, select

from .exceptions import DatabaseError, MutationError, ObjectNotFoundError
from .filters import build_flat_filter, flatten_filters
from .query import get_object

logger = logging.getLogger("sqlmodel_object_helpers")


async def add_object[T: SQLModel](
    session: AsyncSession,
    instance: T,
) -> T:
    """
    Add a single model instance to the session, flush, and refresh.

    After ``flush()`` the instance will have all server-generated fields
    populated (auto-increment PK, ``server_default`` columns, etc.).

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        instance: SQLModel instance to persist.

    Returns:
        The same instance with server-generated fields populated.

    Raises:
        MutationError: On constraint violations (unique, FK, check).
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_name = type(instance).__name__

    session.add(instance)
    try:
        await session.flush()
        await session.refresh(instance)
    except IntegrityError as e:
        logger.warning("add_object(%s) — integrity error: %s", model_name, e.orig)
        msg = f"Integrity error creating {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("add_object(%s) — unexpected error", model_name)
        msg = f"Database error creating {model_name}: {e}"
        raise DatabaseError(msg) from e

    elapsed = time.perf_counter() - start
    logger.debug(
        "add_object(%s) → id=%s, %.3fs",
        model_name, getattr(instance, "id", "?"), elapsed,
    )
    return instance


async def add_objects[T: SQLModel](
    session: AsyncSession,
    instances: list[T],
) -> list[T]:
    """
    Add multiple model instances to the session, flush, and refresh each.

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        instances: List of SQLModel instances to persist.

    Returns:
        The same list with server-generated fields populated on every item.

    Raises:
        MutationError: On constraint violations.
        DatabaseError: On unexpected database errors.

    """
    if not instances:
        return []

    start = time.perf_counter()
    model_name = type(instances[0]).__name__

    session.add_all(instances)
    try:
        await session.flush()
        for inst in instances:
            await session.refresh(inst)
    except IntegrityError as e:
        logger.warning("add_objects(%s) — integrity error: %s", model_name, e.orig)
        msg = f"Integrity error creating {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("add_objects(%s) — unexpected error", model_name)
        msg = f"Database error creating {model_name}: {e}"
        raise DatabaseError(msg) from e

    elapsed = time.perf_counter() - start
    logger.debug(
        "add_objects(%s) → %d instances, %.3fs",
        model_name, len(instances), elapsed,
    )
    return instances


async def update_object[T: SQLModel](
    session: AsyncSession,
    instance: T,
    data: dict[str, Any],
) -> T:
    """
    Update an existing model instance with values from a dict.

    Validates that every key in *data* corresponds to an actual column or
    relationship on the model **before** touching the database.

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        instance: Existing SQLModel instance (persistent or detached).
        data: Mapping of ``field_name → new_value``.

    Returns:
        The updated instance with refreshed values.

    Raises:
        MutationError: If a key does not exist on the model, or on
            constraint violations during flush.
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_cls = type(instance)
    model_name = model_cls.__name__

    # Validate field names against the model class
    for key in data:
        if not hasattr(model_cls, key):
            msg = f"Model {model_name} has no field {key}"
            raise MutationError(msg)

    # Capture PK before flush — after IntegrityError the session is
    # invalidated and lazy-loading attributes would raise PendingRollbackError.
    instance_id = getattr(instance, "id", "?")

    for key, value in data.items():
        setattr(instance, key, value)

    # session.add() is idempotent for persistent instances and properly
    # merges detached ones.
    session.add(instance)
    try:
        await session.flush()
        await session.refresh(instance)
    except IntegrityError as e:
        logger.warning("update_object(%s, id=%s) — integrity error: %s", model_name, instance_id, e.orig)
        msg = f"Integrity error updating {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("update_object(%s, id=%s) — unexpected error", model_name, instance_id)
        msg = f"Database error updating {model_name}: {e}"
        raise DatabaseError(msg) from e

    elapsed = time.perf_counter() - start
    logger.debug(
        "update_object(%s, id=%s) → %d fields, %.3fs",
        model_name, getattr(instance, "id", "?"), len(data), elapsed,
    )
    return instance


async def update_objects[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    data: dict[str, Any],
    filters: dict[str, Any | list[Any]] | None = None,
    logical_operator: str = "AND",
) -> int:
    """
    Bulk-update records matching *filters* with values from *data*.

    Issues a single ``UPDATE ... SET ... WHERE ...`` — no objects are loaded.

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        model: The SQLModel class to update.
        data: Mapping of ``field_name → new_value``.
        filters: Flat dict filters (dot-notation **not** supported).
        logical_operator: ``"AND"`` or ``"OR"`` for combining conditions.

    Returns:
        Number of rows updated.

    Raises:
        MutationError: If *filters* is empty, references related tables,
            or a field in *data* does not exist on the model.
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_name = model.__name__

    if not data:
        msg = f"update_objects({model_name}): data cannot be empty"
        raise MutationError(msg)

    for key in data:
        if not hasattr(model, key):
            msg = f"Model {model_name} has no field {key}"
            raise MutationError(msg)

    if not filters:
        msg = f"update_objects({model_name}): filters are required for bulk updates"
        raise MutationError(msg)

    flat_filters = flatten_filters(filters)
    conditions, join_entities = build_flat_filter(model, flat_filters, suspend_error=False)

    if join_entities:
        msg = (
            f"update_objects({model_name}): filters referencing related tables "
            f"are not supported in bulk updates"
        )
        raise MutationError(msg)

    stmt = sa_update(model).values(**data)

    if conditions:
        logical_operator = logical_operator.upper()
        combined = and_(*conditions) if logical_operator == "AND" else or_(*conditions)
        stmt = stmt.where(combined)

    try:
        result = await session.execute(stmt)
        await session.flush()
    except IntegrityError as e:
        logger.warning("update_objects(%s) — integrity error: %s", model_name, e.orig)
        msg = f"Integrity error bulk-updating {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("update_objects(%s) — unexpected error", model_name)
        msg = f"Database error bulk-updating {model_name}: {e}"
        raise DatabaseError(msg) from e
    else:
        elapsed = time.perf_counter() - start
        row_count = result.rowcount
        logger.debug(
            "update_objects(%s) → %d rows, %.3fs",
            model_name, row_count, elapsed,
        )
        return row_count


async def delete_object[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    *,
    instance: T | None = None,
    pk: dict[str, Any] | None = None,
) -> None:
    """
    Delete a model instance by reference or primary key lookup.

    Exactly one of *instance* or *pk* must be provided.

    FK constraints in PostgreSQL will raise ``IntegrityError`` if the
    record has dependent children (``ON DELETE RESTRICT``), which is
    caught and re-raised as ``MutationError``.

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        model: The SQLModel class (used for PK lookup and logging).
        instance: The instance to delete (if already loaded).
        pk: Primary key dict, e.g. ``{"id": 5}``.

    Raises:
        MutationError: If neither or both of *instance* / *pk* are given,
            or on FK constraint violations.
        ObjectNotFoundError: If *pk* is given but no matching record exists.
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_name = model.__name__

    if (instance is None) == (pk is None):
        msg = f"delete_object({model_name}): provide exactly one of instance or pk"
        raise MutationError(msg)

    if pk is not None:
        # get_object raises ObjectNotFoundError when suspend_error=False (default)
        instance = await get_object(session, model, pk=pk)

    # Capture PK before delete — after IntegrityError the session is
    # invalidated and lazy-loading attributes would raise PendingRollbackError.
    instance_id = pk or getattr(instance, "id", "?")

    try:
        await session.delete(instance)
        await session.flush()
    except IntegrityError as e:
        logger.warning("delete_object(%s, pk=%s) — integrity error: %s", model_name, instance_id, e.orig)
        msg = f"Integrity error deleting {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("delete_object(%s, pk=%s) — unexpected error", model_name, instance_id)
        msg = f"Database error deleting {model_name}: {e}"
        raise DatabaseError(msg) from e

    elapsed = time.perf_counter() - start
    logger.debug(
        "delete_object(%s, pk=%s) → deleted, %.3fs",
        model_name, pk or getattr(instance, "id", "?"), elapsed,
    )


async def delete_objects[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    filters: dict[str, Any | list[Any]] | None = None,
    logical_operator: str = "AND",
) -> int:
    """
    Bulk-delete records matching *filters*.

    Issues a single ``DELETE FROM ... WHERE ...`` — no objects are loaded.

    Args:
        session: Async SQLAlchemy session (caller manages transaction).
        model: The SQLModel class to delete from.
        filters: Flat dict filters (dot-notation **not** supported).
        logical_operator: ``"AND"`` or ``"OR"`` for combining conditions.

    Returns:
        Number of rows deleted.

    Raises:
        MutationError: If *filters* is empty or references related tables.
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_name = model.__name__

    if not filters:
        msg = f"delete_objects({model_name}): filters are required for bulk deletes"
        raise MutationError(msg)

    flat_filters = flatten_filters(filters)
    conditions, join_entities = build_flat_filter(model, flat_filters, suspend_error=False)

    if join_entities:
        msg = (
            f"delete_objects({model_name}): filters referencing related tables "
            f"are not supported in bulk deletes"
        )
        raise MutationError(msg)

    stmt = sa_delete(model)

    if conditions:
        logical_operator = logical_operator.upper()
        combined = and_(*conditions) if logical_operator == "AND" else or_(*conditions)
        stmt = stmt.where(combined)

    try:
        result = await session.execute(stmt)
        await session.flush()
    except IntegrityError as e:
        logger.warning("delete_objects(%s) — integrity error: %s", model_name, e.orig)
        msg = f"Integrity error bulk-deleting {model_name}: {e.orig}"
        raise MutationError(msg) from e
    except Exception as e:
        logger.exception("delete_objects(%s) — unexpected error", model_name)
        msg = f"Database error bulk-deleting {model_name}: {e}"
        raise DatabaseError(msg) from e
    else:
        elapsed = time.perf_counter() - start
        row_count = result.rowcount
        logger.debug(
            "delete_objects(%s) → %d rows, %.3fs",
            model_name, row_count, elapsed,
        )
        return row_count


async def check_for_related_records[T: SQLModel](
    session: AsyncSession,
    model: type[T],
    pk: dict[str, Any],
) -> list[str] | None:
    """
    Check whether the record has dependent children via ONETOMANY relationships.

    Inspects all ONETOMANY relationships on the model and queries for the
    existence of at least one child record in each.  This is a read-only
    pre-deletion check — it does **not** modify any data.

    Args:
        session: Async SQLAlchemy session.
        model: The SQLModel class to inspect.
        pk: Primary key dict, e.g. ``{"id": 5}``.

    Returns:
        A list of human-readable strings describing each found dependency,
        or ``None`` if no related records exist.

    Raises:
        ObjectNotFoundError: If no record matches *pk*.
        DatabaseError: On unexpected database errors.

    """
    start = time.perf_counter()
    model_name = model.__name__

    pk_conditions = [getattr(model, key) == value for key, value in pk.items()]
    stmt = select(model).where(*pk_conditions)

    try:
        result = await session.execute(stmt)
        instance = result.unique().scalar_one_or_none()
    except Exception as e:
        logger.exception("check_for_related_records(%s, pk=%s) — error loading record", model_name, pk)
        msg = f"Database error checking relations for {model_name}: {e}"
        raise DatabaseError(msg) from e

    if instance is None:
        raise ObjectNotFoundError(model_name)

    mapper = inspect(model)
    related_records_info: list[str] = []

    for rel in mapper.relationships:
        if rel.direction != ONETOMANY:
            continue

        related_model = rel.mapper.class_
        conditions = []
        for local_col, remote_col in rel.local_remote_pairs:
            value = getattr(instance, local_col.name)
            conditions.append(remote_col == value)

        check_stmt = select(related_model).where(and_(*conditions)).limit(1)

        try:
            check_result = await session.execute(check_stmt)
            related_record = check_result.unique().scalar_one_or_none()
        except Exception as e:
            logger.exception("check_for_related_records(%s) — error checking %s", model_name, related_model.__name__)
            msg = f"Error checking relationship {model_name} -> {related_model.__name__}: {e}"
            raise DatabaseError(msg) from e

        if related_record is not None:
            related_pk = {
                col.name: getattr(related_record, col.name)
                for col in inspect(related_model).primary_key
            }
            related_pk_str = ", ".join(f"{k}={v}" for k, v in related_pk.items())
            table_comment = getattr(related_model.__table__, "comment", None) or related_model.__name__
            related_records_info.append(
                f"Related record found in '{related_model.__name__} ({table_comment})' ({related_pk_str})"
            )

    elapsed = time.perf_counter() - start
    logger.debug(
        "check_for_related_records(%s, pk=%s) → %d dependencies, %.3fs",
        model_name, pk, len(related_records_info), elapsed,
    )
    return related_records_info or None
