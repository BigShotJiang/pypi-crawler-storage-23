"""Tests for Pydantic models in sqlmodel_object_helpers.types module.

Tests cover:
- Pagination, PaginationR, GetAllPagination
- FilterInt, FilterStr, FilterDate, FilterDatetime, FilterTimedelta, FilterBool, FilterExists
- OrderAsc, OrderDesc, OrderBy
- LogicalFilter
"""

from datetime import date, datetime, timedelta

import pytest
from pydantic import BaseModel, ValidationError

import sqlmodel_object_helpers as soh


# =============================================================================
# Pagination Tests
# =============================================================================


def test_pagination_defaults():
    """Pagination should have default values: page=1, per_page=10."""
    pagination = soh.Pagination()
    assert pagination.page == 1
    assert pagination.per_page == 10


def test_pagination_page_ge_1():
    """Pagination page must be >= 1."""
    with pytest.raises(ValidationError) as exc_info:
        soh.Pagination(page=0)
    assert "greater than or equal to 1" in str(exc_info.value).lower()


def test_pagination_per_page_ge_1():
    """Pagination per_page must be >= 1."""
    with pytest.raises(ValidationError) as exc_info:
        soh.Pagination(per_page=0)
    assert "greater than or equal to 1" in str(exc_info.value).lower()


# =============================================================================
# FilterInt Tests
# =============================================================================


def test_filter_int_eq():
    """FilterInt should accept eq parameter."""
    filter_int = soh.FilterInt(eq=5)
    assert filter_int.eq == 5
    assert filter_int.ne is None
    assert filter_int.gt is None
    assert filter_int.lt is None
    assert filter_int.ge is None
    assert filter_int.le is None
    assert filter_int.in_ is None


def test_filter_int_string_coercion():
    """FilterInt should coerce string digits to int for comparison operators."""
    # Test single field
    filter_int = soh.FilterInt(eq="123")
    assert filter_int.eq == 123
    assert isinstance(filter_int.eq, int)

    # Test multiple fields
    filter_int = soh.FilterInt(eq="10", ne="20", gt="5", lt="100", ge="1", le="99")
    assert filter_int.eq == 10
    assert filter_int.ne == 20
    assert filter_int.gt == 5
    assert filter_int.lt == 100
    assert filter_int.ge == 1
    assert filter_int.le == 99


def test_filter_int_invalid_string():
    """FilterInt should raise ValidationError for non-numeric strings."""
    with pytest.raises(ValidationError) as exc_info:
        soh.FilterInt(eq="abc")
    assert "must be a number" in str(exc_info.value).lower()


def test_filter_int_in_list():
    """FilterInt should accept in_ parameter with list of integers."""
    filter_int = soh.FilterInt(in_=[1, 2, 3])
    assert filter_int.in_ == [1, 2, 3]


def test_filter_int_in_list_string_coercion():
    """FilterInt should coerce string digits in in_ list to integers."""
    filter_int = soh.FilterInt(in_=["1", "2", "3"])
    assert filter_int.in_ == [1, 2, 3]
    assert all(isinstance(x, int) for x in filter_int.in_)


def test_filter_int_in_list_mixed_types():
    """FilterInt should coerce mixed int/string digits in in_ list."""
    filter_int = soh.FilterInt(in_=[1, "2", 3, "4"])
    assert filter_int.in_ == [1, 2, 3, 4]


def test_filter_int_in_invalid_item():
    """FilterInt should raise ValidationError for non-numeric items in in_ list."""
    with pytest.raises(ValidationError) as exc_info:
        soh.FilterInt(in_=[1, "abc", 3])
    assert "must be a number" in str(exc_info.value).lower()


def test_filter_int_in_not_list():
    """FilterInt should raise ValidationError if in_ is not a list."""
    with pytest.raises(ValidationError) as exc_info:
        soh.FilterInt(in_="123")
    assert "must be a list" in str(exc_info.value).lower()


def test_filter_int_in_max_size():
    """FilterInt in_ cannot exceed max_in_list_size (default 1000)."""
    # Default max_in_list_size is 1000, so 1001 should fail
    with pytest.raises(ValidationError) as exc_info:
        soh.FilterInt(in_=list(range(1001)))
    assert "cannot contain more than" in str(exc_info.value).lower()

    # 1000 items should be OK
    filter_int = soh.FilterInt(in_=list(range(1000)))
    assert len(filter_int.in_) == 1000


def test_filter_int_in_custom_limit():
    """FilterInt in_ respects custom settings.max_in_list_size."""
    # Save original value
    original_max_in_list_size = soh.settings.max_in_list_size

    try:
        # Override settings
        soh.settings.max_in_list_size = 5

        # in_ with 6 items should fail
        with pytest.raises(ValidationError) as exc_info:
            soh.FilterInt(in_=[1, 2, 3, 4, 5, 6])
        assert "cannot contain more than" in str(exc_info.value).lower()

        # in_ with 5 items should be OK
        filter_int = soh.FilterInt(in_=[1, 2, 3, 4, 5])
        assert len(filter_int.in_) == 5

    finally:
        # Restore original value
        soh.settings.max_in_list_size = original_max_in_list_size


# =============================================================================
# LogicalFilter Tests
# =============================================================================


def test_logical_filter_condition():
    """LogicalFilter should accept condition parameter."""
    logical_filter = soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}})
    assert logical_filter.condition == {"id": {soh.Operator.EQ: 1}}
    assert logical_filter.AND is None
    assert logical_filter.OR is None


def test_logical_filter_and():
    """LogicalFilter should accept AND parameter."""
    sub_filters = [
        soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}}),
        soh.LogicalFilter(condition={"name": {soh.Operator.EQ: "test"}}),
    ]
    logical_filter = soh.LogicalFilter(AND=sub_filters)
    assert logical_filter.AND == sub_filters
    assert logical_filter.condition is None
    assert logical_filter.OR is None


def test_logical_filter_or():
    """LogicalFilter should accept OR parameter."""
    sub_filters = [
        soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}}),
        soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 2}}),
    ]
    logical_filter = soh.LogicalFilter(OR=sub_filters)
    assert logical_filter.OR == sub_filters
    assert logical_filter.condition is None
    assert logical_filter.AND is None


def test_logical_filter_multiple_keys():
    """LogicalFilter should reject multiple keys set simultaneously."""
    with pytest.raises(ValidationError) as exc_info:
        soh.LogicalFilter(AND=[soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}})], condition={"name": {soh.Operator.EQ: "test"}})
    assert "exactly one of" in str(exc_info.value).lower()


def test_logical_filter_no_keys():
    """LogicalFilter should reject when no keys are set."""
    with pytest.raises(ValidationError) as exc_info:
        soh.LogicalFilter()
    assert "exactly one of" in str(exc_info.value).lower()


def test_logical_filter_and_and_or():
    """LogicalFilter should reject both AND and OR set simultaneously."""
    with pytest.raises(ValidationError) as exc_info:
        soh.LogicalFilter(
            AND=[soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}})],
            OR=[soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 2}})],
        )
    assert "exactly one of" in str(exc_info.value).lower()


def test_logical_filter_nested():
    """LogicalFilter should support nested structures."""
    inner_filter = soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}})
    nested_filter = soh.LogicalFilter(AND=[inner_filter])
    outer_filter = soh.LogicalFilter(OR=[nested_filter])

    assert outer_filter.OR is not None
    assert outer_filter.OR[0].AND is not None
    assert outer_filter.OR[0].AND[0].condition == {"id": {soh.Operator.EQ: 1}}


def test_logical_filter_forbids_extra_fields():
    """LogicalFilter should forbid extra fields due to extra='forbid' config."""
    with pytest.raises(ValidationError) as exc_info:
        soh.LogicalFilter(condition={"id": {soh.Operator.EQ: 1}}, extra_field="not_allowed")
    # The error message should mention forbidden or extra
    error_str = str(exc_info.value).lower()
    assert "extra" in error_str or "forbidden" in error_str or "unexpected" in error_str


# =============================================================================
# FilterStr Tests
# =============================================================================


def test_filter_str_eq():
    """FilterStr accepts eq parameter."""
    f = soh.FilterStr(eq="hello")
    assert f.eq == "hello"
    assert f.ne is None
    assert f.like is None
    assert f.ilike is None


def test_filter_str_ne():
    """FilterStr accepts ne parameter."""
    f = soh.FilterStr(ne="world")
    assert f.ne == "world"


def test_filter_str_like():
    """FilterStr accepts like parameter with SQL pattern."""
    f = soh.FilterStr(like="%test%")
    assert f.like == "%test%"


def test_filter_str_ilike():
    """FilterStr accepts ilike parameter (case-insensitive like)."""
    f = soh.FilterStr(ilike="%Test%")
    assert f.ilike == "%Test%"


def test_filter_str_multiple_operators():
    """FilterStr accepts several operators at once."""
    f = soh.FilterStr(eq="exact", like="%partial%")
    assert f.eq == "exact"
    assert f.like == "%partial%"


def test_filter_str_empty_string():
    """FilterStr accepts empty string as a valid value."""
    f = soh.FilterStr(eq="")
    assert f.eq == ""


def test_filter_str_unicode():
    """FilterStr handles Unicode / Cyrillic strings."""
    f = soh.FilterStr(ilike="%Иванов%")
    assert f.ilike == "%Иванов%"


def test_filter_str_all_none():
    """FilterStr with no parameters has all fields None."""
    f = soh.FilterStr()
    assert f.eq is None
    assert f.ne is None
    assert f.like is None
    assert f.ilike is None


# =============================================================================
# FilterDate Tests
# =============================================================================


def test_filter_date_eq():
    """FilterDate accepts a date for eq."""
    d = date(2026, 1, 15)
    f = soh.FilterDate(eq=d)
    assert f.eq == d


def test_filter_date_range():
    """FilterDate supports ge + le for date range."""
    f = soh.FilterDate(ge=date(2026, 1, 1), le=date(2026, 12, 31))
    assert f.ge == date(2026, 1, 1)
    assert f.le == date(2026, 12, 31)


def test_filter_date_string_coercion():
    """Pydantic coerces ISO date strings to date objects."""
    f = soh.FilterDate(eq="2026-06-15")
    assert f.eq == date(2026, 6, 15)


def test_filter_date_invalid_string():
    """FilterDate rejects non-date strings."""
    with pytest.raises(ValidationError):
        soh.FilterDate(eq="not-a-date")


def test_filter_date_all_operators():
    """FilterDate supports all six comparison operators."""
    d = date(2026, 3, 1)
    f = soh.FilterDate(eq=d, ne=d, gt=d, lt=d, ge=d, le=d)
    assert f.eq == d
    assert f.ne == d
    assert f.gt == d
    assert f.lt == d
    assert f.ge == d
    assert f.le == d


# =============================================================================
# FilterDatetime Tests
# =============================================================================


def test_filter_datetime_eq():
    """FilterDatetime accepts a datetime for eq."""
    dt = datetime(2026, 1, 15, 10, 30, 0)
    f = soh.FilterDatetime(eq=dt)
    assert f.eq == dt


def test_filter_datetime_range():
    """FilterDatetime supports gt + lt for time range."""
    f = soh.FilterDatetime(
        gt=datetime(2026, 1, 1, 0, 0),
        lt=datetime(2026, 12, 31, 23, 59),
    )
    assert f.gt.year == 2026
    assert f.lt.month == 12


def test_filter_datetime_string_coercion():
    """Pydantic coerces ISO datetime strings."""
    f = soh.FilterDatetime(eq="2026-06-15T10:30:00")
    assert f.eq == datetime(2026, 6, 15, 10, 30, 0)


def test_filter_datetime_invalid_string():
    """FilterDatetime rejects non-datetime strings."""
    with pytest.raises(ValidationError):
        soh.FilterDatetime(eq="yesterday")


# =============================================================================
# FilterTimedelta Tests
# =============================================================================


def test_filter_timedelta_eq():
    """FilterTimedelta accepts a timedelta for eq."""
    td = timedelta(hours=2, minutes=30)
    f = soh.FilterTimedelta(eq=td)
    assert f.eq == td


def test_filter_timedelta_range():
    """FilterTimedelta supports ge + le for duration range."""
    f = soh.FilterTimedelta(
        ge=timedelta(minutes=0),
        le=timedelta(hours=8),
    )
    assert f.ge == timedelta(0)
    assert f.le == timedelta(hours=8)


def test_filter_timedelta_all_none():
    """FilterTimedelta with no parameters has all fields None."""
    f = soh.FilterTimedelta()
    assert f.eq is None
    assert f.gt is None


# =============================================================================
# FilterBool Tests
# =============================================================================


def test_filter_bool_eq_true():
    """FilterBool accepts eq=True."""
    f = soh.FilterBool(eq=True)
    assert f.eq is True
    assert f.ne is None


def test_filter_bool_eq_false():
    """FilterBool accepts eq=False."""
    f = soh.FilterBool(eq=False)
    assert f.eq is False


def test_filter_bool_ne():
    """FilterBool accepts ne parameter."""
    f = soh.FilterBool(ne=True)
    assert f.ne is True


def test_filter_bool_all_none():
    """FilterBool with no parameters has all fields None."""
    f = soh.FilterBool()
    assert f.eq is None
    assert f.ne is None


# =============================================================================
# FilterExists Tests
# =============================================================================


def test_filter_exists_true():
    """FilterExists accepts exists=True."""
    f = soh.FilterExists(exists=True)
    assert f.exists is True


def test_filter_exists_false():
    """FilterExists accepts exists=False."""
    f = soh.FilterExists(exists=False)
    assert f.exists is False


def test_filter_exists_required():
    """FilterExists requires the exists field (no default)."""
    with pytest.raises(ValidationError):
        soh.FilterExists()


# =============================================================================
# OrderAsc / OrderDesc / OrderBy Tests
# =============================================================================


def test_order_asc():
    """OrderAsc holds a field name for ascending sort."""
    o = soh.OrderAsc(asc="last_name")
    assert o.asc == "last_name"


def test_order_desc():
    """OrderDesc holds a field name for descending sort."""
    o = soh.OrderDesc(desc="created_at")
    assert o.desc == "created_at"


def test_order_by_empty():
    """OrderBy defaults to empty sorts list."""
    ob = soh.OrderBy()
    assert ob.sorts == []


def test_order_by_single_asc():
    """OrderBy accepts a single ascending sort."""
    ob = soh.OrderBy(sorts=[soh.OrderAsc(asc="id")])
    assert len(ob.sorts) == 1
    assert ob.sorts[0].asc == "id"


def test_order_by_single_desc():
    """OrderBy accepts a single descending sort."""
    ob = soh.OrderBy(sorts=[soh.OrderDesc(desc="created_at")])
    assert len(ob.sorts) == 1
    assert ob.sorts[0].desc == "created_at"


def test_order_by_mixed():
    """OrderBy accepts mixed asc/desc sorts in order."""
    ob = soh.OrderBy(sorts=[
        soh.OrderAsc(asc="last_name"),
        soh.OrderDesc(desc="id"),
    ])
    assert len(ob.sorts) == 2
    assert ob.sorts[0].asc == "last_name"
    assert ob.sorts[1].desc == "id"


# =============================================================================
# PaginationR Tests
# =============================================================================


def test_pagination_r_inherits_pagination():
    """PaginationR inherits page/per_page defaults from Pagination."""
    pr = soh.PaginationR(total=100)
    assert pr.page == 1
    assert pr.per_page == 10
    assert pr.total == 100


def test_pagination_r_custom_values():
    """PaginationR accepts custom page, per_page, and total."""
    pr = soh.PaginationR(page=3, per_page=25, total=250)
    assert pr.page == 3
    assert pr.per_page == 25
    assert pr.total == 250


def test_pagination_r_total_required():
    """PaginationR requires the total field."""
    with pytest.raises(ValidationError):
        soh.PaginationR()


# =============================================================================
# GetAllPagination Tests
# =============================================================================


def test_get_all_pagination_with_data():
    """GetAllPagination holds a list of items and pagination metadata."""
    gap = soh.GetAllPagination[str](
        data=["a", "b", "c"],
        pagination=soh.PaginationR(page=1, per_page=10, total=3),
    )
    assert len(gap.data) == 3
    assert gap.pagination.total == 3


def test_get_all_pagination_empty_data():
    """GetAllPagination accepts empty data list."""
    gap = soh.GetAllPagination[int](
        data=[],
        pagination=soh.PaginationR(page=1, per_page=10, total=0),
    )
    assert gap.data == []
    assert gap.pagination.total == 0


def test_get_all_pagination_without_pagination():
    """GetAllPagination works without pagination (None)."""
    gap = soh.GetAllPagination[str](data=["x"])
    assert gap.pagination is None


def test_get_all_pagination_model_dump():
    """GetAllPagination serializes correctly via model_dump."""
    gap = soh.GetAllPagination[str](
        data=["item"],
        pagination=soh.PaginationR(page=1, per_page=10, total=1),
    )
    d = gap.model_dump()
    assert d["data"] == ["item"]
    assert d["pagination"]["total"] == 1


# =============================================================================
# GetAllPagination — PEP 695 generic validation with BaseModel
# =============================================================================


class _ItemModel(BaseModel):
    """Concrete Pydantic model to test GetAllPagination[T] parametrization."""

    id: int
    name: str
    is_active: bool = True


class _StrictItemModel(BaseModel):
    """Model with extra='forbid' to test strict validation."""

    model_config = {"extra": "forbid"}

    id: int
    title: str


def test_pep695_generic_parametrization_creates_concrete_type():
    """GetAllPagination[_ItemModel] must resolve T — not stay as Any."""
    ConcreteModel = soh.GetAllPagination[_ItemModel]
    # __name__ or __pydantic_generic_metadata__ should reflect parametrization
    assert ConcreteModel is not soh.GetAllPagination
    # Must be subscriptable result, not the original generic
    assert hasattr(ConcreteModel, "model_fields")


def test_pep695_generic_validates_items_against_model():
    """Each item in data must be validated as _ItemModel, not passed as Any."""
    gap = soh.GetAllPagination[_ItemModel](
        data=[{"id": 1, "name": "test"}, {"id": 2, "name": "other", "is_active": False}],
        pagination=soh.PaginationR(page=1, per_page=10, total=2),
    )
    assert len(gap.data) == 2
    assert isinstance(gap.data[0], _ItemModel)
    assert isinstance(gap.data[1], _ItemModel)
    assert gap.data[0].name == "test"
    assert gap.data[1].is_active is False


def test_pep695_generic_rejects_invalid_item_type():
    """Data with wrong type for a required field must raise ValidationError."""
    with pytest.raises(ValidationError) as exc_info:
        soh.GetAllPagination[_ItemModel](
            data=[{"id": "not_an_int", "name": 123}],
        )
    errors = exc_info.value.errors()
    assert any(e["loc"] == ("data", 0, "id") for e in errors)


def test_pep695_generic_rejects_missing_required_fields():
    """Data items missing required fields must raise ValidationError."""
    with pytest.raises(ValidationError) as exc_info:
        soh.GetAllPagination[_ItemModel](
            data=[{"id": 1}],  # missing 'name'
        )
    errors = exc_info.value.errors()
    assert any("name" in str(e["loc"]) for e in errors)


def test_pep695_generic_rejects_garbage_data():
    """Completely wrong data must not silently pass as list[Any]."""
    with pytest.raises(ValidationError):
        soh.GetAllPagination[_ItemModel](
            data=[{"garbage": True}],
        )


def test_pep695_generic_model_validate_from_dict():
    """model_validate (JSON-like input) must enforce T validation."""
    raw = {
        "data": [{"id": 1, "name": "ok"}],
        "pagination": {"page": 1, "per_page": 10, "total": 1},
    }
    result = soh.GetAllPagination[_ItemModel].model_validate(raw)
    assert isinstance(result.data[0], _ItemModel)
    assert result.data[0].id == 1


def test_pep695_generic_model_validate_rejects_invalid():
    """model_validate must reject invalid items, not treat as Any."""
    raw = {
        "data": [{"wrong_field": "value"}],
        "pagination": None,
    }
    with pytest.raises(ValidationError):
        soh.GetAllPagination[_ItemModel].model_validate(raw)


def test_pep695_generic_json_schema_contains_item_ref():
    """model_json_schema must reference _ItemModel fields, not empty object."""
    schema = soh.GetAllPagination[_ItemModel].model_json_schema()
    data_schema = schema["properties"]["data"]
    # data must be {"type": "array", "items": {"$ref": ...}} — not {"type": "array"}
    assert "items" in data_schema
    # The items must reference the concrete model (via $ref or inline properties)
    items = data_schema["items"]
    if "$ref" in items:
        ref_name = items["$ref"].split("/")[-1]
        assert ref_name in schema.get("$defs", schema.get("definitions", {}))
    elif "properties" in items:
        assert "id" in items["properties"]
        assert "name" in items["properties"]
    else:
        pytest.fail(f"T was not resolved in JSON schema: items={items}")


def test_pep695_generic_json_schema_no_any_fallback():
    """Ensure data items schema is NOT empty object (which means Any)."""
    schema = soh.GetAllPagination[_ItemModel].model_json_schema()
    items = schema["properties"]["data"].get("items", {})
    # Empty items {} means T resolved to Any — this is the failure we're testing for
    assert items != {}, "T resolved to Any — PEP 695 generic not working with Pydantic"


def test_pep695_generic_model_dump_preserves_typed_data():
    """model_dump must serialize items with correct fields, not raw dicts."""
    gap = soh.GetAllPagination[_ItemModel](
        data=[{"id": 1, "name": "first"}, {"id": 2, "name": "second"}],
        pagination=soh.PaginationR(page=1, per_page=10, total=2),
    )
    dumped = gap.model_dump()
    assert dumped["data"][0] == {"id": 1, "name": "first", "is_active": True}
    assert dumped["data"][1] == {"id": 2, "name": "second", "is_active": True}


def test_pep695_generic_filters_extra_fields():
    """Extra fields not in _ItemModel must be stripped (default Pydantic behavior)."""
    gap = soh.GetAllPagination[_ItemModel](
        data=[{"id": 1, "name": "ok", "secret_field": "should_be_stripped"}],
    )
    dumped = gap.model_dump()
    assert "secret_field" not in dumped["data"][0]


def test_pep695_generic_strict_model_rejects_extra_fields():
    """With extra='forbid', extra fields in data items must raise ValidationError."""
    with pytest.raises(ValidationError):
        soh.GetAllPagination[_StrictItemModel](
            data=[{"id": 1, "title": "ok", "extra": "bad"}],
        )


def test_pep695_generic_empty_data_still_typed():
    """Empty data list should still produce a typed model, not list[Any]."""
    gap = soh.GetAllPagination[_ItemModel](data=[], pagination=None)
    schema = type(gap).model_json_schema()
    items = schema["properties"]["data"].get("items", {})
    assert items != {}, "Empty data caused T to resolve to Any"
