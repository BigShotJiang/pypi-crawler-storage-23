"""
Integration tests for the for_update parameter in get_object().

Tests verify that for_update=True does not break query execution.
SQLite does not support SELECT ... FOR UPDATE, so we only test that:
1) for_update=False (default) works as before
2) for_update=True executes without error on SQLite (silently ignored)
"""

import pytest

from conftest import Applicant
import sqlmodel_object_helpers as soh


pytestmark = pytest.mark.asyncio


async def test_get_object_default_no_for_update(session, seed_data):
    """Default for_update=False returns object normally."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(session, Applicant, pk={"id": applicant.id})

    assert result is not None
    assert result.last_name == "Иванов"


async def test_get_object_with_for_update(session, seed_data):
    """for_update=True adds WITH FOR UPDATE clause; SQLite ignores it gracefully."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(
        session, Applicant, pk={"id": applicant.id}, for_update=True,
    )

    assert result is not None
    assert result.id == applicant.id
    assert result.last_name == "Иванов"
