"""GENERATED ALWAYS AS STORED: full_name / passport computed columns.

Tests verify that SQLModel models with Computed columns:
1. DDL creates the table correctly (create_all)
2. INSERT populates generated values automatically
3. UPDATE recalculates generated values
4. Generated columns work with sqlmodel_object_helpers filters and sorting
5. NULL handling: all-NULL source fields → generated column IS NULL

Uses in-memory SQLite (same infrastructure as other tests).
SQLite supports GENERATED ALWAYS AS since version 3.31.0.
"""

import pytest

from conftest import ApplicantWithGenerated
import sqlmodel_object_helpers as soh


pytestmark = pytest.mark.asyncio


# ── full_name: конкатенация ФИО ──────────────────────────────────────


async def test_full_fio(session, seed_applicants_generated):
    """Полное ФИО → 'Иванов Иван Иванович'."""
    row = seed_applicants_generated[0]
    assert row.full_name == "Иванов Иван Иванович"


async def test_no_middle_name(session, seed_applicants_generated):
    """Без отчества → 'Петров Пётр' (без лишнего пробела)."""
    row = seed_applicants_generated[1]
    assert row.full_name == "Петров Пётр"
    assert not row.full_name.endswith(" "), "Лишний пробел в конце!"


async def test_only_last_name(session, seed_applicants_generated):
    """Только фамилия → 'Сидоров'."""
    row = seed_applicants_generated[2]
    assert row.full_name == "Сидоров"


async def test_all_null_full_name(session, seed_applicants_generated):
    """Все поля NULL → full_name IS NULL (не пустая строка)."""
    row = seed_applicants_generated[4]
    assert row.full_name is None


# ── passport: серия + номер ──────────────────────────────────────────


async def test_passport_full(session, seed_applicants_generated):
    """Серия + номер → '4510 123456'."""
    row = seed_applicants_generated[0]
    assert row.passport == "4510 123456"


async def test_passport_no_series(session, seed_applicants_generated):
    """Только номер → '123456' (без пробела в начале)."""
    row = seed_applicants_generated[3]
    assert row.passport == "123456"
    assert not row.passport.startswith(" "), "Лишний пробел в начале!"


async def test_passport_all_null(session, seed_applicants_generated):
    """Все поля NULL → passport IS NULL."""
    row = seed_applicants_generated[4]
    assert row.passport is None


# ── UPDATE → пересчёт ───────────────────────────────────────────────


async def test_update_recalculates(session, seed_applicants_generated):
    """UPDATE source-поля → GENERATED пересчитывается."""
    row = seed_applicants_generated[0]
    await soh.update_object(session, row, {"first_name": "Пётр"})
    await session.refresh(row)
    assert row.full_name == "Иванов Пётр Иванович"


async def test_update_add_middle_name(session, seed_applicants_generated):
    """Добавление отчества → full_name обновляется."""
    row = seed_applicants_generated[1]  # Петров Пётр (без отчества)
    await soh.update_object(session, row, {"middle_name": "Петрович"})
    await session.refresh(row)
    assert row.full_name == "Петров Пётр Петрович"


# ── Фильтрация через soh ────────────────────────────────────────────


async def test_filter_by_full_name(session, seed_applicants_generated):
    """Фильтрация по GENERATED колонке full_name через get_objects."""
    results = await soh.get_objects(
        session, ApplicantWithGenerated,
        filters={"full_name": {soh.Operator.LIKE: "%Иванов%"}},
    )
    assert len(results) == 1
    assert results[0].full_name == "Иванов Иван Иванович"


async def test_filter_by_passport(session, seed_applicants_generated):
    """Фильтрация по GENERATED колонке passport через get_objects."""
    results = await soh.get_objects(
        session, ApplicantWithGenerated,
        filters={"passport": {soh.Operator.EQ: "4510 123456"}},
    )
    assert len(results) == 1
    assert results[0].last_name == "Иванов"


async def test_order_by_full_name(session, seed_applicants_generated):
    """Сортировка по GENERATED колонке full_name."""
    results = await soh.get_objects(
        session, ApplicantWithGenerated,
        filters={"full_name": {"exists": True}},
        order_by=soh.OrderBy(sorts=[soh.OrderAsc(asc="full_name")]),
    )
    names = [r.full_name for r in results]
    assert names == sorted(names)


async def test_count_with_generated_filter(session, seed_applicants_generated):
    """count_objects с фильтром по GENERATED колонке."""
    count = await soh.count_objects(
        session, ApplicantWithGenerated,
        filters={"passport": {"exists": True}},
    )
    # rows 0,1,3 have passport (row 2 has only last_name, row 4 all NULL)
    assert count == 3


async def test_exists_with_generated_filter(session, seed_applicants_generated):
    """exists_object с фильтром по GENERATED колонке."""
    result = await soh.exists_object(
        session, ApplicantWithGenerated,
        filters={"full_name": {soh.Operator.EQ: "Сидоров"}},
    )
    assert result is True

    result = await soh.exists_object(
        session, ApplicantWithGenerated,
        filters={"full_name": {soh.Operator.EQ: "Несуществующий"}},
    )
    assert result is False
