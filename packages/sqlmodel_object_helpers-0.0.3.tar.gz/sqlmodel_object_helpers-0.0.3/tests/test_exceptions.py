"""
Direct tests for sqlmodel_object_helpers.exceptions module.

Tests validate status codes, messages, and inheritance hierarchy
for all five exception classes.
"""

from http import HTTPStatus

import pytest

import sqlmodel_object_helpers as soh


# ============================================================================
# QueryError (base class)
# ============================================================================


def test_query_error_default_status_code():
    """QueryError defaults to 400 Bad Request."""
    err = soh.QueryError("something went wrong")
    assert err.status_code == HTTPStatus.BAD_REQUEST
    assert err.message == "something went wrong"


def test_query_error_custom_status_code():
    """QueryError accepts a custom status code."""
    err = soh.QueryError("forbidden", status_code=HTTPStatus.FORBIDDEN)
    assert err.status_code == HTTPStatus.FORBIDDEN


def test_query_error_is_exception():
    """QueryError inherits from Exception."""
    err = soh.QueryError("test")
    assert isinstance(err, Exception)


def test_query_error_str_representation():
    """str(QueryError) returns the message."""
    err = soh.QueryError("query error")
    assert str(err) == "query error"


# ============================================================================
# ObjectNotFoundError
# ============================================================================


def test_object_not_found_status_code():
    """ObjectNotFoundError carries HTTP 404."""
    err = soh.ObjectNotFoundError("Applicant")
    assert err.status_code == HTTPStatus.NOT_FOUND


def test_object_not_found_message_format():
    """ObjectNotFoundError message contains the model name."""
    err = soh.ObjectNotFoundError("Applicant")
    assert "Applicant" in err.message
    assert "Resource not found" in err.message


def test_object_not_found_inherits_query_error():
    """ObjectNotFoundError is a subclass of QueryError."""
    err = soh.ObjectNotFoundError("Attempt")
    assert isinstance(err, soh.QueryError)
    assert isinstance(err, Exception)


def test_object_not_found_cyrillic_model():
    """ObjectNotFoundError works with Cyrillic model names."""
    err = soh.ObjectNotFoundError("Заявка")
    assert "Заявка" in err.message


# ============================================================================
# InvalidFilterError
# ============================================================================


def test_invalid_filter_error_status_code():
    """InvalidFilterError carries HTTP 400."""
    err = soh.InvalidFilterError("bad filter")
    assert err.status_code == HTTPStatus.BAD_REQUEST


def test_invalid_filter_error_message():
    """InvalidFilterError preserves the detail message."""
    err = soh.InvalidFilterError("Unsupported operator: foo")
    assert err.message == "Unsupported operator: foo"


def test_invalid_filter_error_inherits_query_error():
    """InvalidFilterError is a subclass of QueryError."""
    err = soh.InvalidFilterError("test")
    assert isinstance(err, soh.QueryError)


# ============================================================================
# InvalidLoadPathError
# ============================================================================


def test_invalid_load_path_error_status_code():
    """InvalidLoadPathError carries HTTP 400."""
    err = soh.InvalidLoadPathError("Applicant", "nonexistent")
    assert err.status_code == HTTPStatus.BAD_REQUEST


def test_invalid_load_path_error_message_format():
    """InvalidLoadPathError message contains model and field names."""
    err = soh.InvalidLoadPathError("Applicant", "foobar")
    assert "Applicant" in err.message
    assert "foobar" in err.message
    assert "has no field" in err.message


def test_invalid_load_path_error_inherits_query_error():
    """InvalidLoadPathError is a subclass of QueryError."""
    err = soh.InvalidLoadPathError("Model", "field")
    assert isinstance(err, soh.QueryError)


# ============================================================================
# DatabaseError
# ============================================================================


def test_database_error_status_code():
    """DatabaseError carries HTTP 500."""
    err = soh.DatabaseError("connection lost")
    assert err.status_code == HTTPStatus.INTERNAL_SERVER_ERROR


def test_database_error_message():
    """DatabaseError preserves the detail message."""
    err = soh.DatabaseError("timeout after 30s")
    assert err.message == "timeout after 30s"


def test_database_error_inherits_query_error():
    """DatabaseError is a subclass of QueryError."""
    err = soh.DatabaseError("test")
    assert isinstance(err, soh.QueryError)


# ============================================================================
# MutationError
# ============================================================================


def test_mutation_error_status_code():
    """MutationError carries HTTP 400."""
    err = soh.MutationError("constraint violation")
    assert err.status_code == HTTPStatus.BAD_REQUEST


def test_mutation_error_message():
    """MutationError preserves the detail message."""
    err = soh.MutationError("Integrity error creating Billing")
    assert "Integrity error" in err.message


def test_mutation_error_inherits_query_error():
    """MutationError is a subclass of QueryError."""
    err = soh.MutationError("test")
    assert isinstance(err, soh.QueryError)
    assert isinstance(err, Exception)


# ============================================================================
# Hierarchy tests
# ============================================================================


def test_all_errors_are_query_error_subclasses():
    """All custom exceptions inherit from QueryError."""
    assert issubclass(soh.ObjectNotFoundError, soh.QueryError)
    assert issubclass(soh.InvalidFilterError, soh.QueryError)
    assert issubclass(soh.InvalidLoadPathError, soh.QueryError)
    assert issubclass(soh.DatabaseError, soh.QueryError)
    assert issubclass(soh.MutationError, soh.QueryError)


def test_except_query_error_catches_all():
    """A single `except QueryError` block catches every library exception."""
    exceptions = [
        soh.ObjectNotFoundError("X"),
        soh.InvalidFilterError("X"),
        soh.InvalidLoadPathError("X", "y"),
        soh.DatabaseError("X"),
        soh.MutationError("X"),
    ]
    for exc in exceptions:
        with pytest.raises(soh.QueryError):
            raise exc
