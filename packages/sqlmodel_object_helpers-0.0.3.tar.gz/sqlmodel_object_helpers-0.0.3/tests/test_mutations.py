"""
Integration tests for sqlmodel_object_helpers.mutations module.

Tests use the same in-memory SQLite database and exam-crm production schema
as test_query.py.  FK enforcement is enabled via PRAGMA in conftest.py.
"""

from datetime import date

import pytest
from sqlmodel import select

from conftest import Applicant, Attempt, Billing, Organization
import sqlmodel_object_helpers as soh


pytestmark = pytest.mark.asyncio


# ============================================================================
# add_object tests
# ============================================================================


async def test_add_object_success(session, seed_data):
    """New Applicant is created with auto-generated PK."""
    applicant = Applicant(
        last_name="Тестов", first_name="Тест", passport_number="999888",
    )
    result = await soh.add_object(session, applicant)

    assert result.id is not None
    assert result.last_name == "Тестов"
    assert result.passport_number == "999888"


async def test_add_object_returns_same_instance(session, seed_data):
    """add_object returns the exact same object (identity check)."""
    applicant = Applicant(
        last_name="Идентичность", first_name="Тест", passport_number="000111",
    )
    result = await soh.add_object(session, applicant)

    assert result is applicant


async def test_add_object_persisted_in_db(session, seed_data):
    """After add_object + commit, a fresh SELECT finds the record."""
    applicant = Applicant(
        last_name="Персист", first_name="Тест", passport_number="777666",
    )
    await soh.add_object(session, applicant)
    await session.commit()

    stmt = select(Applicant).where(Applicant.passport_number == "777666")
    row = (await session.execute(stmt)).scalar_one_or_none()
    assert row is not None
    assert row.last_name == "Персист"


async def test_add_object_fk_violation(session, seed_data):
    """Billing referencing non-existent attempt_id raises MutationError."""
    billing = Billing(
        attempt_id=99999,
        billing_type_id=1,
        is_physical=True,
        is_paid=False,
        invoice_reason="test",
        invoice_date=date(2026, 1, 1),
        agreement_create_date=date(2026, 1, 1),
        agreement_expire_date=date(2026, 12, 31),
        address="test",
    )
    with pytest.raises(soh.MutationError, match="Integrity error"):
        await soh.add_object(session, billing)


async def test_add_object_flush_semantics(session, seed_data):
    """add_object uses flush(), not commit() — rollback discards the record."""
    applicant = Applicant(
        last_name="Откат", first_name="Тест", passport_number="111000",
    )
    await soh.add_object(session, applicant)
    assert applicant.id is not None

    await session.rollback()

    stmt = select(Applicant).where(Applicant.passport_number == "111000")
    row = (await session.execute(stmt)).scalar_one_or_none()
    assert row is None


# ============================================================================
# add_objects tests
# ============================================================================


async def test_add_objects_success(session, seed_data):
    """Multiple Applicants are created, all with PKs."""
    instances = [
        Applicant(last_name="Батч1", first_name="А", passport_number="B001"),
        Applicant(last_name="Батч2", first_name="Б", passport_number="B002"),
        Applicant(last_name="Батч3", first_name="В", passport_number="B003"),
    ]
    result = await soh.add_objects(session, instances)

    assert len(result) == 3
    assert all(a.id is not None for a in result)
    assert result[0].last_name == "Батч1"
    assert result[2].last_name == "Батч3"


async def test_add_objects_empty_list(session, seed_data):
    """Empty list returns [] without touching the database."""
    result = await soh.add_objects(session, [])
    assert result == []


async def test_add_objects_single_item(session, seed_data):
    """List of one item works correctly."""
    instances = [
        Applicant(last_name="Один", first_name="Тест", passport_number="S001"),
    ]
    result = await soh.add_objects(session, instances)

    assert len(result) == 1
    assert result[0].id is not None


async def test_add_objects_returns_list_type(session, seed_data):
    """Return type is list (not int, not tuple)."""
    instances = [
        Applicant(last_name="Тип1", first_name="А", passport_number="T001"),
        Applicant(last_name="Тип2", first_name="Б", passport_number="T002"),
    ]
    result = await soh.add_objects(session, instances)

    assert isinstance(result, list)


async def test_add_objects_fk_violation(session, seed_data):
    """One invalid FK in the batch raises MutationError for the whole batch."""
    instances = [
        Billing(
            attempt_id=99999,
            billing_type_id=1,
            is_physical=True,
            is_paid=False,
            invoice_reason="bad fk",
            invoice_date=date(2026, 1, 1),
            agreement_create_date=date(2026, 1, 1),
            agreement_expire_date=date(2026, 12, 31),
            address="test",
        ),
    ]
    with pytest.raises(soh.MutationError, match="Integrity error"):
        await soh.add_objects(session, instances)


# ============================================================================
# update_object tests
# ============================================================================


async def test_update_object_single_field(session, seed_data):
    """Update a single field on existing Applicant."""
    applicant = seed_data["applicants"][0]
    result = await soh.update_object(session, applicant, {"last_name": "Обновлённый"})

    assert result.last_name == "Обновлённый"


async def test_update_object_multiple_fields(session, seed_data):
    """Update several fields at once."""
    applicant = seed_data["applicants"][1]
    result = await soh.update_object(session, applicant, {
        "last_name": "Новая",
        "first_name": "Фамилия",
        "phone": "+70001112233",
    })

    assert result.last_name == "Новая"
    assert result.first_name == "Фамилия"
    assert result.phone == "+70001112233"


async def test_update_object_returns_refreshed(session, seed_data):
    """Returned instance has the updated values (refresh happened)."""
    applicant = seed_data["applicants"][0]
    original_name = applicant.first_name

    result = await soh.update_object(session, applicant, {"first_name": "Рефреш"})

    assert result.first_name == "Рефреш"
    assert result.first_name != original_name


async def test_update_object_invalid_field(session, seed_data):
    """Non-existent field name raises MutationError before touching DB."""
    applicant = seed_data["applicants"][0]

    with pytest.raises(soh.MutationError, match="has no field"):
        await soh.update_object(session, applicant, {"nonexistent_field": "value"})


async def test_update_object_empty_data(session, seed_data):
    """Empty dict is a valid no-op — no error, returns instance unchanged."""
    applicant = seed_data["applicants"][0]
    original_name = applicant.last_name

    result = await soh.update_object(session, applicant, {})

    assert result.last_name == original_name


async def test_update_object_fk_violation(session, seed_data):
    """Setting FK to non-existent record raises MutationError."""
    attempt = seed_data["attempts"][0]

    with pytest.raises(soh.MutationError, match="Integrity error"):
        await soh.update_object(session, attempt, {"application_id": 99999})


# ============================================================================
# delete_object tests
# ============================================================================


async def test_delete_object_by_instance(session, seed_data):
    """Delete by passing loaded instance — record disappears from DB."""
    # Create a standalone Applicant with no children
    applicant = Applicant(
        last_name="Удалить", first_name="Тест", passport_number="DEL001",
    )
    await soh.add_object(session, applicant)
    applicant_id = applicant.id
    await session.commit()

    await soh.delete_object(session, Applicant, instance=applicant)
    await session.commit()

    stmt = select(Applicant).where(Applicant.id == applicant_id)
    row = (await session.execute(stmt)).scalar_one_or_none()
    assert row is None


async def test_delete_object_by_pk(session, seed_data):
    """Delete by pk dict — record disappears from DB."""
    applicant = Applicant(
        last_name="УдалитьPK", first_name="Тест", passport_number="DEL002",
    )
    await soh.add_object(session, applicant)
    applicant_id = applicant.id
    await session.commit()

    await soh.delete_object(session, Applicant, pk={"id": applicant_id})
    await session.commit()

    stmt = select(Applicant).where(Applicant.id == applicant_id)
    row = (await session.execute(stmt)).scalar_one_or_none()
    assert row is None


async def test_delete_object_returns_none(session, seed_data):
    """delete_object returns None on success."""
    applicant = Applicant(
        last_name="Возврат", first_name="Тест", passport_number="DEL003",
    )
    await soh.add_object(session, applicant)
    await session.commit()

    result = await soh.delete_object(session, Applicant, instance=applicant)
    assert result is None


async def test_delete_object_not_found(session, seed_data):
    """Non-existent pk raises ObjectNotFoundError."""
    with pytest.raises(soh.ObjectNotFoundError):
        await soh.delete_object(session, Applicant, pk={"id": 99999})


async def test_delete_object_both_params(session, seed_data):
    """Passing both instance and pk raises MutationError."""
    applicant = seed_data["applicants"][0]

    with pytest.raises(soh.MutationError, match="exactly one"):
        await soh.delete_object(
            session, Applicant, instance=applicant, pk={"id": applicant.id},
        )


async def test_delete_object_neither_params(session, seed_data):
    """Passing neither instance nor pk raises MutationError."""
    with pytest.raises(soh.MutationError, match="exactly one"):
        await soh.delete_object(session, Applicant)


async def test_delete_object_fk_constraint(session, seed_data):
    """Deleting Attempt that has child Billings (non-nullable FK) raises MutationError."""
    attempt = seed_data["attempts"][0]  # att1 has bill1 (Billing.attempt_id is NOT NULL)

    with pytest.raises(soh.MutationError, match="Integrity error"):
        await soh.delete_object(session, Attempt, instance=attempt)


# ============================================================================
# check_for_related_records tests
# ============================================================================


async def test_check_related_has_children(session, seed_data):
    """Applicant with Applications returns non-empty list."""
    applicant = seed_data["applicants"][0]  # has appl1
    result = await soh.check_for_related_records(
        session, Applicant, pk={"id": applicant.id},
    )

    assert result is not None
    assert isinstance(result, list)
    assert len(result) >= 1


async def test_check_related_no_children(session, seed_data):
    """Applicant with no related records returns None."""
    applicant = Applicant(
        last_name="Одинокий", first_name="Тест", passport_number="LONE001",
    )
    await soh.add_object(session, applicant)
    await session.commit()

    result = await soh.check_for_related_records(
        session, Applicant, pk={"id": applicant.id},
    )

    assert result is None


async def test_check_related_not_found(session, seed_data):
    """Non-existent pk raises ObjectNotFoundError."""
    with pytest.raises(soh.ObjectNotFoundError):
        await soh.check_for_related_records(
            session, Applicant, pk={"id": 99999},
        )


async def test_check_related_message_format(session, seed_data):
    """Result strings contain related model name."""
    applicant = seed_data["applicants"][0]
    result = await soh.check_for_related_records(
        session, Applicant, pk={"id": applicant.id},
    )

    assert result is not None
    # At least one message should mention the related model
    joined = " ".join(result)
    assert "Application" in joined


async def test_check_related_multiple_rels(session, seed_data):
    """Organization has Units + BankAccounts + Billings — multiple deps found."""
    org = seed_data["organizations"][0]  # org1 has unit1, ba1, bill1
    result = await soh.check_for_related_records(
        session, Organization, pk={"id": org.id},
    )

    assert result is not None
    assert len(result) >= 2  # at least units + bank_accounts


# ============================================================================
# Exception tests (no DB needed)
# ============================================================================


async def test_mutation_error_status_code():
    """MutationError carries HTTP 400 status code."""
    err = soh.MutationError("test error")
    assert err.status_code == 400
    assert err.message == "test error"


async def test_mutation_error_inherits_query_error():
    """MutationError is a subclass of QueryError (caught by base handler)."""
    err = soh.MutationError("test")
    assert isinstance(err, soh.QueryError)
    assert isinstance(err, Exception)
