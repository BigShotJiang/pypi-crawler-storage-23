"""
Tests for loaders.py security limits and functionality.

Models match production exam-crm schema from SQL dump.
Tests cover build_load_options and build_load_chain.
"""

import pytest

from conftest import Applicant, Application, Attempt, Billing, Schedule, Unit
import sqlmodel_object_helpers as soh


# ==================== build_load_options tests ====================


def test_build_load_options_valid():
    """Test single-level: Applicant → applications."""
    result = soh.build_load_options(Applicant, ["applications"])
    assert result is not None


def test_build_load_options_nested():
    """Test two-level: Applicant → applications → attempts."""
    result = soh.build_load_options(Applicant, ["applications", "attempts"])
    assert result is not None


def test_build_load_options_invalid_attr():
    """Test non-existent attribute returns None."""
    result = soh.build_load_options(Applicant, ["nonexistent"])
    assert result is None


def test_build_load_options_underscore_rejected():
    """Test underscore attribute returns None."""
    result = soh.build_load_options(Applicant, ["_sa_instance_state"])
    assert result is None


def test_build_load_options_depth_limit():
    """Test max_load_depth=1 rejects 2-level path."""
    original_depth = soh.settings.max_load_depth
    try:
        soh.settings.max_load_depth = 1
        result = soh.build_load_options(Applicant, ["applications", "attempts"])
        assert result is None
    finally:
        soh.settings.max_load_depth = original_depth


# ==================== build_load_chain tests ====================


def test_build_load_chain_string_path():
    """Test string path: 'applications'."""
    result = soh.build_load_chain(Applicant, "applications")
    assert result is not None


def test_build_load_chain_dotted_path():
    """Test dotted string: 'applications.attempts'."""
    result = soh.build_load_chain(Applicant, "applications.attempts")
    assert result is not None


def test_build_load_chain_deep_path():
    """Test 3-level: 'applications.attempts.billings'."""
    result = soh.build_load_chain(Applicant, "applications.attempts.billings")
    assert result is not None


def test_build_load_chain_list_path():
    """Test list path: ['applications', 'attempts']."""
    result = soh.build_load_chain(Applicant, ["applications", "attempts"])
    assert result is not None


def test_build_load_chain_invalid_raises():
    """Test InvalidLoadPathError for invalid path."""
    with pytest.raises(soh.InvalidLoadPathError):
        soh.build_load_chain(Applicant, "nonexistent")


def test_build_load_chain_invalid_suspend():
    """Test suspend_error=True returns None for invalid path."""
    result = soh.build_load_chain(Applicant, "nonexistent", suspend_error=True)
    assert result is None


def test_build_load_chain_underscore_rejected():
    """Test InvalidLoadPathError for underscore attributes."""
    with pytest.raises(soh.InvalidLoadPathError):
        soh.build_load_chain(Applicant, "_private")


def test_build_load_chain_depth_limit():
    """Test max_load_depth raises InvalidFilterError."""
    original_depth = soh.settings.max_load_depth
    try:
        soh.settings.max_load_depth = 1

        with pytest.raises(soh.InvalidFilterError):
            soh.build_load_chain(Applicant, "applications.attempts")

        result = soh.build_load_chain(
            Applicant, "applications.attempts", suspend_error=True,
        )
        assert result is None
    finally:
        soh.settings.max_load_depth = original_depth


def test_build_load_chain_strategy_selectinload():
    """Test one-to-many → selectinload: Applicant.applications."""
    result = soh.build_load_chain(Applicant, "applications")
    assert result is not None


def test_build_load_chain_strategy_joinedload():
    """Test many-to-one → joinedload: Application.applicant."""
    result = soh.build_load_chain(Application, "applicant")
    assert result is not None


def test_build_load_chain_mixed_strategies():
    """Test mixed: Applicant → applications (selectin) → attempts (selectin)."""
    result = soh.build_load_chain(Applicant, "applications.attempts")
    assert result is not None


def test_build_load_chain_many_to_one_chain():
    """Test chain of many-to-one: Attempt → application → applicant."""
    result = soh.build_load_chain(Attempt, "application.applicant")
    assert result is not None


def test_build_load_chain_schedule_unit_org():
    """Test real hierarchy: Schedule → unit → organization."""
    result = soh.build_load_chain(Schedule, "unit.organization")
    assert result is not None


def test_build_load_chain_attempt_schedule_unit():
    """Test: Attempt → schedule → unit (nullable schedule)."""
    result = soh.build_load_chain(Attempt, "schedule.unit")
    assert result is not None


def test_build_load_chain_billing_attempt():
    """Test: Billing → attempt → application."""
    result = soh.build_load_chain(Billing, "attempt.application")
    assert result is not None


def test_build_load_chain_unit_children():
    """Test self-referencing: Unit → children."""
    result = soh.build_load_chain(Unit, "children")
    assert result is not None


def test_build_load_chain_unit_parent():
    """Test self-referencing: Unit → parent."""
    result = soh.build_load_chain(Unit, "parent")
    assert result is not None


def test_build_load_chain_empty_path():
    """Test that empty string path raises InvalidLoadPathError (splits to [''])."""
    with pytest.raises(soh.InvalidLoadPathError):
        soh.build_load_chain(Applicant, "")


def test_build_load_chain_empty_list_path():
    """Test that empty list path returns None."""
    result = soh.build_load_chain(Applicant, [])
    assert result is None
