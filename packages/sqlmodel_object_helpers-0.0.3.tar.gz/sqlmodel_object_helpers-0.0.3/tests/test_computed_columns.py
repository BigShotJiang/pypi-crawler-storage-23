"""Tests: DB-level computed columns work with sqlmodel-object-helpers filters and sorting.

Demonstrates two approaches:
1. Computed (GENERATED ALWAYS AS) — same-table expression, real DB column
2. column_property — cross-table SQL subquery mapped as ORM attribute
"""

import pytest

import sqlmodel_object_helpers as soh

from conftest import Product, Schedule


# ---------------------------------------------------------------------------
# Computed column (GENERATED ALWAYS AS)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_computed_column_in_where(session, seed_products):
    """Computed column (total_price) can be used in WHERE via get_objects."""
    results = await soh.get_objects(
        session, Product,
        filters={"total_price": {soh.Operator.GT: 100}},
    )
    assert len(results) == 2
    assert all(r.total_price > 100 for r in results)


@pytest.mark.asyncio
async def test_computed_column_in_order_by(session, seed_products):
    """Computed column (total_price) can be used in ORDER BY."""
    results = await soh.get_objects(
        session, Product,
        order_by=soh.OrderBy(sorts=[soh.OrderAsc(asc="total_price")]),
    )
    prices = [r.total_price for r in results]
    assert prices == sorted(prices)


@pytest.mark.asyncio
async def test_computed_column_value_matches(session, seed_products):
    """Computed column value equals quantity * unit_price."""
    results = await soh.get_objects(session, Product)
    for r in results:
        assert r.total_price == pytest.approx(r.quantity * r.unit_price)


# ---------------------------------------------------------------------------
# column_property (cross-table subquery)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_column_property_in_where(session, seed_data):
    """column_property (attempt_count) can be used in WHERE via get_objects."""
    results = await soh.get_objects(
        session, Schedule,
        filters={"attempt_count": {soh.Operator.GT: 1}},
    )
    assert len(results) > 0
    assert all(r.attempt_count > 1 for r in results)


@pytest.mark.asyncio
async def test_column_property_in_order_by(session, seed_data):
    """column_property (attempt_count) can be used in ORDER BY."""
    results = await soh.get_objects(
        session, Schedule,
        order_by=soh.OrderBy(sorts=[soh.OrderDesc(desc="attempt_count")]),
    )
    counts = [r.attempt_count for r in results]
    assert counts == sorted(counts, reverse=True)
