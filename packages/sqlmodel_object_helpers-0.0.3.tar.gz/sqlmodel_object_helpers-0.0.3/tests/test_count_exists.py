"""
Integration tests for count_objects() and exists_object() query functions.

Tests use the same in-memory SQLite database and exam-crm production schema
as other test modules.
"""

from datetime import datetime

import pytest

import sqlmodel_object_helpers as soh

from conftest import Applicant, Attempt


pytestmark = pytest.mark.asyncio


# ============================================================================
# count_objects tests
# ============================================================================


async def test_count_all_no_filters(session, seed_data):
    """count_objects without filters returns total row count."""
    total = await soh.count_objects(session, Applicant)
    assert total == 3


async def test_count_with_eq_filter(session, seed_data):
    """count_objects with eq filter returns matching count."""
    total = await soh.count_objects(
        session, Attempt, filters={"is_active": {soh.Operator.EQ: True}},
    )
    assert total == 3


async def test_count_with_multiple_filters_and(session, seed_data):
    """count_objects with AND: active AND not blocked."""
    total = await soh.count_objects(
        session, Attempt,
        filters={"is_active": {soh.Operator.EQ: True}, "is_blocked": {soh.Operator.EQ: False}},
        logical_operator="AND",
    )
    assert total == 2


async def test_count_with_in_operator(session, seed_data):
    """count_objects with IN operator: status_id IN (10, 20)."""
    total_10 = await soh.count_objects(
        session, Attempt,
        filters={"status_id": {soh.Operator.EQ: 10}},
    )

    total_20 = await soh.count_objects(
        session, Attempt,
        filters={"status_id": {soh.Operator.EQ: 20}},
    )

    total_in = await soh.count_objects(
        session, Attempt,
        filters={"status_id": {soh.Operator.IN: [10, 20]}},
    )
    assert total_in >= total_10
    assert total_in >= total_20
    assert total_in == total_10 + total_20


async def test_count_zero_when_no_match(session, seed_data):
    """count_objects returns 0 when no records match."""
    total = await soh.count_objects(
        session, Applicant,
        filters={"last_name": {soh.Operator.EQ: "НесуществующийЧеловек"}},
    )
    assert total == 0


async def test_count_suppress_error(session, seed_data):
    """count_objects with suspend_error=True skips invalid fields (returns all records)."""
    total = await soh.count_objects(
        session, Applicant,
        filters={"nonexistent_field": {soh.Operator.EQ: "x"}},
        suspend_error=True,
    )
    # Invalid field is silently skipped → no WHERE clause → all 3 applicants returned
    assert total == 3


async def test_count_with_time_filter(session, seed_data):
    """count_objects with time_filter counts by created_at range."""
    # applicant1: 2026-01-05, applicant2: 2026-01-08, applicant3: 2026-01-10
    total = await soh.count_objects(
        session, Applicant,
        time_filter=soh.TimeFilter(
            created_after=datetime(2026, 1, 6),
            created_before=datetime(2026, 1, 11),
        ),
    )
    assert total == 2  # applicant2 + applicant3


async def test_count_with_time_filter_and_filters(session, seed_data):
    """count_objects with time_filter combined with regular filters."""
    total = await soh.count_objects(
        session, Applicant,
        filters={"is_nrs": {soh.Operator.EQ: True}},
        time_filter=soh.TimeFilter(created_after=datetime(2026, 1, 6)),
    )
    assert total == 1  # only applicant3 (Сидоров, is_nrs=True, created 2026-01-10)


# ============================================================================
# exists_object tests
# ============================================================================


async def test_exists_by_pk_found(session, seed_data):
    """exists_object returns True when PK exists."""
    applicant = seed_data["applicants"][0]
    result = await soh.exists_object(session, Applicant, pk={"id": applicant.id})
    assert result is True


async def test_exists_by_pk_not_found(session, seed_data):
    """exists_object returns False when PK does not exist."""
    result = await soh.exists_object(session, Applicant, pk={"id": 99999})
    assert result is False


async def test_exists_by_filter_found(session, seed_data):
    """exists_object returns True when filter matches."""
    result = await soh.exists_object(
        session, Applicant,
        filters={"passport_number": {soh.Operator.EQ: "123456"}},
    )
    assert result is True


async def test_exists_by_filter_not_found(session, seed_data):
    """exists_object returns False when filter matches nothing."""
    result = await soh.exists_object(
        session, Applicant,
        filters={"passport_number": {soh.Operator.EQ: "000000"}},
    )
    assert result is False


async def test_exists_invalid_pk_raises(session, seed_data):
    """exists_object raises InvalidFilterError on bad PK key."""
    with pytest.raises(soh.InvalidFilterError):
        await soh.exists_object(session, Applicant, pk={"nonexistent": 1})
