"""
Integration tests for sqlmodel_object_helpers.query module.

Models match production exam-crm schema from SQL dump.
Tests use async SQLAlchemy with in-memory SQLite database.
"""

import pytest

from sqlalchemy.orm import aliased

from conftest import (
    Applicant, Application, Attempt, Billing,
    Organization, Schedule,
)
import sqlmodel_object_helpers as soh


pytestmark = pytest.mark.asyncio


# ============================================================================
# get_object tests
# ============================================================================


async def test_get_object_by_pk(session, seed_data):
    """Test getting Applicant by primary key."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(session, Applicant, pk={"id": applicant.id})

    assert result is not None
    assert isinstance(result, Applicant)
    assert result.last_name == "Иванов"
    assert result.passport_number == "123456"
    assert result.is_nrs is True


async def test_get_object_not_found_raises(session, seed_data):
    """Test that get_object raises ObjectNotFoundError when not found."""
    with pytest.raises(soh.ObjectNotFoundError):
        await soh.get_object(session, Applicant, pk={"id": 999})


async def test_get_object_not_found_suspend(session, seed_data):
    """Test that get_object returns None when suspend_error=True and not found."""
    result = await soh.get_object(
        session, Applicant, pk={"id": 999}, suspend_error=True,
    )
    assert result is None


async def test_get_object_with_filters_condition(session, seed_data):
    """Test LogicalFilter condition: last_name='Иванов'."""
    result = await soh.get_object(
        session,
        Applicant,
        filters=soh.LogicalFilter(condition={"last_name": {soh.Operator.EQ: "Иванов"}}),
    )

    assert result is not None
    assert result.last_name == "Иванов"
    assert result.first_name == "Пётр"
    assert result.middle_name == "Сергеевич"


async def test_get_object_with_filters_passport(session, seed_data):
    """Test filter by passport_number — real production query pattern."""
    result = await soh.get_object(
        session,
        Applicant,
        filters=soh.LogicalFilter(condition={"passport_number": {soh.Operator.EQ: "654321"}}),
    )

    assert result is not None
    assert result.last_name == "Петрова"


async def test_get_object_load_paths_one_level(session, seed_data):
    """Test eager loading: Applicant.applications."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(
        session, Applicant, pk={"id": applicant.id}, load_paths=["applications"],
    )

    assert result is not None
    applications = result.applications
    assert len(applications) == 1
    assert applications[0].email == "ivanov@example.com"


async def test_get_object_load_paths_two_levels(session, seed_data):
    """Test eager loading 2 levels: Applicant → applications → attempts."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(
        session,
        Applicant,
        pk={"id": applicant.id},
        load_paths=["applications", "applications.attempts"],
    )

    assert result is not None
    attempts = result.applications[0].attempts
    assert len(attempts) == 2  # Иванов has att1 + att2


async def test_get_object_deep_load_path(session, seed_data):
    """Test 3-level: applications.attempts.billings."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_object(
        session,
        Applicant,
        pk={"id": applicant.id},
        load_paths=[
            "applications",
            "applications.attempts",
            "applications.attempts.billings",
        ],
    )

    assert result is not None
    attempts = result.applications[0].attempts
    billed = [a for a in attempts if a.billings]
    assert len(billed) == 2
    assert any(b.invoice_number == "СЧ-0001" for a in billed for b in a.billings)


async def test_get_object_organization_by_inn(session, seed_data):
    """Test getting Organization by INN — common production lookup."""
    result = await soh.get_object(
        session,
        Organization,
        filters=soh.LogicalFilter(condition={"inn": {soh.Operator.EQ: "7701234567"}}),
    )

    assert result is not None
    assert "Энергетик" in result.short_name


# ============================================================================
# get_objects tests
# ============================================================================


async def test_get_objects_all_applicants(session, seed_data):
    """Test getting all 3 applicants."""
    result = await soh.get_objects(session, Applicant)
    assert isinstance(result, list)
    assert len(result) == 3


async def test_get_objects_filter_is_nrs(session, seed_data):
    """Test is_nrs=True returns Иванов + Сидоров."""
    result = await soh.get_objects(
        session, Applicant, filters={"is_nrs": {soh.Operator.EQ: True}},
    )
    assert len(result) == 2
    assert all(a.is_nrs is True for a in result)


async def test_get_objects_filter_status_id_eq(session, seed_data):
    """Test status_id=10 returns 2 active attempts."""
    result = await soh.get_objects(
        session, Attempt, filters={"status_id": {soh.Operator.EQ: 10}},
    )
    assert len(result) == 2
    assert all(a.status_id == 10 for a in result)


async def test_get_objects_filter_in(session, seed_data):
    """Test IN operator: status_id in [10, 20]."""
    result = await soh.get_objects(
        session, Attempt, filters={"status_id": {soh.Operator.IN: [10, 20]}},
    )
    assert len(result) == 3  # att1(10) + att3(10) + att4(20)
    assert all(a.status_id in (10, 20) for a in result)


async def test_get_objects_filter_ne(session, seed_data):
    """Test NE operator: status_id != 120."""
    result = await soh.get_objects(
        session, Attempt, filters={"status_id": {soh.Operator.NE: 120}},
    )
    assert len(result) == 3
    assert all(a.status_id != 120 for a in result)


async def test_get_objects_is_closed(session, seed_data):
    """Test filtering applications by is_closed=True."""
    result = await soh.get_objects(
        session, Application, filters={"is_closed": {soh.Operator.EQ: True}},
    )
    assert len(result) == 1
    assert result[0].applicant_id == seed_data["applicants"][2].id


async def test_get_objects_related_filter(session, seed_data):
    """Test filter through relationship: application.applicant.is_nrs=True."""
    result = await soh.get_objects(
        session,
        Attempt,
        filters={"application.applicant.is_nrs": {soh.Operator.EQ: True}},
    )
    # Иванов (NRS) has att1+att2, Сидоров (NRS) has att4 → 3 attempts
    assert len(result) == 3


async def test_get_objects_related_filter_org_inn(session, seed_data):
    """Test filter: unit.organization.inn — deep relationship through Unit→Organization."""
    result = await soh.get_objects(
        session,
        Schedule,
        filters={"unit.organization.inn": {soh.Operator.EQ: "7701234567"}},
    )
    assert len(result) == 1  # sched1 → unit1 → org1


async def test_get_objects_empty_result(session, seed_data):
    """Test that no matches returns empty list."""
    result = await soh.get_objects(
        session, Applicant, filters={"last_name": {soh.Operator.EQ: "Несуществующий"}},
    )
    assert isinstance(result, list)
    assert len(result) == 0


async def test_get_objects_with_pagination(session, seed_data):
    """Test pagination: page=1, per_page=2 from 3 applicants."""
    result = await soh.get_objects(
        session, Applicant, pagination=soh.Pagination(page=1, per_page=2),
    )
    assert hasattr(result, "data")
    assert len(result.data) == 2
    assert result.pagination.total == 3
    assert result.pagination.page == 1


async def test_get_objects_pagination_page_2(session, seed_data):
    """Test pagination page 2: remaining 1 applicant."""
    result = await soh.get_objects(
        session, Applicant, pagination=soh.Pagination(page=2, per_page=2),
    )
    assert len(result.data) == 1
    assert result.pagination.total == 3


async def test_get_objects_order_by_asc(session, seed_data):
    """Test ORDER BY last_name ASC."""
    result = await soh.get_objects(
        session, Applicant,
        order_by=soh.OrderBy(sorts=[soh.OrderAsc(asc="last_name")]),
    )
    names = [a.last_name for a in result]
    assert names == sorted(names)


async def test_get_objects_order_by_desc(session, seed_data):
    """Test ORDER BY last_name DESC."""
    result = await soh.get_objects(
        session, Applicant,
        order_by=soh.OrderBy(sorts=[soh.OrderDesc(desc="last_name")]),
    )
    names = [a.last_name for a in result]
    assert names == sorted(names, reverse=True)


async def test_get_objects_or_logical_operator(session, seed_data):
    """Test logical_operator='OR': status_id=10 OR is_blocked=True."""
    result = await soh.get_objects(
        session,
        Attempt,
        filters={"status_id": {soh.Operator.EQ: 10}, "is_blocked": {soh.Operator.EQ: True}},
        logical_operator="OR",
    )
    # status=10 (att1, att3) OR is_blocked=True (att4) → 3 unique
    assert len(result) == 3


async def test_get_objects_with_load_paths(session, seed_data):
    """Test load_paths selectinload for one-to-many."""
    result = await soh.get_objects(
        session, Applicant, load_paths=["applications"],
    )
    assert len(result) == 3
    for applicant in result:
        assert isinstance(applicant.applications, list)


async def test_get_objects_is_blocked_filter(session, seed_data):
    """Test filtering by is_blocked=True (real production flag)."""
    result = await soh.get_objects(
        session, Attempt, filters={"is_blocked": {soh.Operator.EQ: True}},
    )
    assert len(result) == 1
    assert result[0].is_blocked is True


async def test_get_objects_billing_is_paid(session, seed_data):
    """Test filtering billings by is_paid=True."""
    result = await soh.get_objects(
        session, Billing, filters={"is_paid": {soh.Operator.EQ: True}},
    )
    assert len(result) == 1
    assert result[0].invoice_number == "СЧ-0001"


async def test_get_objects_suspend_error(session, seed_data):
    """Test that suspend_error=True returns [] for unknown field."""
    result = await soh.get_objects(
        session, Applicant,
        filters={"nonexistent_field": {soh.Operator.EQ: "x"}},
        suspend_error=True,
    )
    assert isinstance(result, list)


# ============================================================================
# get_projection tests
# ============================================================================


async def test_get_projection_single_column(session, seed_data):
    """Test projection: Applicant.last_name."""
    result = await soh.get_projection(
        session, Applicant, columns=["last_name"],
    )
    assert len(result) == 3
    names = {row["last_name"] for row in result}
    assert names == {"Иванов", "Петрова", "Сидоров"}


async def test_get_projection_multiple_columns(session, seed_data):
    """Test projection: last_name + passport_number + is_nrs."""
    result = await soh.get_projection(
        session, Applicant, columns=["last_name", "passport_number", "is_nrs"],
    )
    assert len(result) == 3
    for row in result:
        assert "last_name" in row
        assert "passport_number" in row
        assert "is_nrs" in row


async def test_get_projection_dot_path(session, seed_data):
    """Test projection through relationship: Attempt → application → applicant.last_name."""
    result = await soh.get_projection(
        session, Attempt,
        columns=["status_id", "application.applicant.last_name"],
    )
    assert len(result) == 4
    for row in result:
        assert "status_id" in row
        assert "last_name" in row


async def test_get_projection_with_alias(session, seed_data):
    """Test projection alias: ('application.email', 'app_email')."""
    result = await soh.get_projection(
        session, Attempt,
        columns=["id", ("application.email", "app_email")],
    )
    assert len(result) == 4
    for row in result:
        assert "app_email" in row


async def test_get_projection_org_via_unit(session, seed_data):
    """Test projection: Schedule → unit → organization.inn (3-level)."""
    result = await soh.get_projection(
        session, Schedule,
        columns=["schedule_date", "unit.organization.inn"],
    )
    assert len(result) == 2
    for row in result:
        assert "schedule_date" in row
        assert "inn" in row


async def test_get_projection_with_pk_filter(session, seed_data):
    """Test projection filtered by primary key."""
    applicant = seed_data["applicants"][0]
    result = await soh.get_projection(
        session, Applicant,
        columns=["last_name", "first_name", "middle_name"],
        pk={"id": applicant.id},
    )
    assert len(result) == 1
    assert result[0]["last_name"] == "Иванов"
    assert result[0]["first_name"] == "Пётр"
    assert result[0]["middle_name"] == "Сергеевич"


async def test_get_projection_with_limit(session, seed_data):
    """Test projection with row limit."""
    result = await soh.get_projection(
        session, Applicant, columns=["last_name"], limit=2,
    )
    assert len(result) == 2


async def test_get_projection_outer_join(session, seed_data):
    """Test projection with LEFT OUTER JOIN for nullable schedule."""
    result = await soh.get_projection(
        session, Attempt,
        columns=["id", "schedule.schedule_date"],
        outer_joins=["schedule"],
    )
    assert len(result) == 4
    # att4 has no schedule → schedule_date should be None
    dates = [row["schedule_date"] for row in result]
    assert None in dates


async def test_get_projection_billing_fields(session, seed_data):
    """Test projection of billing-specific fields (real production query)."""
    result = await soh.get_projection(
        session, Billing,
        columns=["invoice_number", "invoice_date", "is_paid", "organization_inn"],
    )
    assert len(result) == 2
    invoice_numbers = {row["invoice_number"] for row in result}
    assert invoice_numbers == {"СЧ-0001", "СЧ-0002"}


async def test_get_projection_invalid_column_suspend(session, seed_data):
    """Test projection with invalid column and suspend_error=True returns []."""
    result = await soh.get_projection(
        session, Applicant, columns=["nonexistent"], suspend_error=True,
    )
    assert result == []


async def test_get_projection_invalid_column_raises(session, seed_data):
    """Test projection with invalid column raises InvalidFilterError."""
    with pytest.raises(soh.InvalidFilterError):
        await soh.get_projection(session, Applicant, columns=["nonexistent"])


# ============================================================================
# get_objects — columns + extra_joins (SQL mode)
# ============================================================================


async def test_get_objects_columns_returns_dicts(session, seed_data):
    """columns= switches get_objects to dict mode."""
    result = await soh.get_objects(
        session, Applicant,
        columns=[Applicant.id, Applicant.last_name],
    )
    assert isinstance(result, list)
    assert len(result) == 3
    assert all(isinstance(r, dict) for r in result)
    assert "id" in result[0]
    assert "last_name" in result[0]


async def test_get_objects_columns_with_label(session, seed_data):
    """Verify .label() — key use case for aliasing view columns."""
    result = await soh.get_objects(
        session, Applicant,
        columns=[Applicant.id, Applicant.last_name.label("surname")],
    )
    assert len(result) == 3
    assert "surname" in result[0]
    assert "last_name" not in result[0]


async def test_get_objects_columns_with_extra_joins(session, seed_data):
    """extra_joins: aliased LEFT JOIN to a related table."""
    sched_alias = aliased(Schedule)
    result = await soh.get_objects(
        session, Attempt,
        columns=[
            Attempt.id,
            Attempt.status_id,
            sched_alias.schedule_date.label("exam_date"),
        ],
        extra_joins=[
            (sched_alias, sched_alias.id == Attempt.schedule_id, True),
        ],
    )
    assert len(result) == 4
    assert "exam_date" in result[0]
    # att4 has no schedule → NULL
    no_sched = [r for r in result if r["exam_date"] is None]
    assert len(no_sched) == 1


async def test_get_objects_columns_with_pagination(session, seed_data):
    """Columns + pagination returns GetAllPagination[dict]."""
    result = await soh.get_objects(
        session, Applicant,
        columns=[Applicant.id, Applicant.last_name],
        pagination=soh.Pagination(page=1, per_page=2),
    )
    assert hasattr(result, "data")
    assert len(result.data) == 2
    assert result.pagination.total == 3
    assert isinstance(result.data[0], dict)


async def test_get_objects_columns_with_filters(session, seed_data):
    """Columns + filters work correctly together."""
    result = await soh.get_objects(
        session, Attempt,
        columns=[Attempt.id, Attempt.status_id],
        filters={"status_id": {soh.Operator.EQ: 10}},
    )
    assert len(result) == 2
    assert all(r["status_id"] == 10 for r in result)


async def test_get_objects_columns_with_raw_order_by(session, seed_data):
    """Columns + raw SA order_by (not OrderBy) for sorting by label."""
    result = await soh.get_objects(
        session, Applicant,
        columns=[Applicant.id, Applicant.last_name.label("surname")],
        order_by=Applicant.last_name.asc(),
    )
    assert len(result) == 3
    names = [r["surname"] for r in result]
    assert names == sorted(names)


async def test_get_objects_columns_and_load_paths_raises(session, seed_data):
    """Columns and load_paths are mutually exclusive."""
    with pytest.raises(soh.QueryError):
        await soh.get_objects(
            session, Applicant,
            columns=[Applicant.id],
            load_paths=["applications"],
        )
