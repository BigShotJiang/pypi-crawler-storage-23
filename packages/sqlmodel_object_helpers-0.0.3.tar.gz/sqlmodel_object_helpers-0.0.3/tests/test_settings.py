"""Tests for sqlmodel_object_helpers.constants module.

Tests the QueryHelperSettings class and the module-level settings instance.
"""

from pydantic import BaseModel

import sqlmodel_object_helpers as soh


# ---------------------------------------------------------------------------
# QueryHelperSettings Class Tests
# ---------------------------------------------------------------------------


def test_default_values():
    """Verify all default values in QueryHelperSettings are correct."""
    test_settings = soh.QueryHelperSettings()
    assert test_settings.max_filter_depth == 100
    assert test_settings.max_and_or_items == 100
    assert test_settings.max_load_depth == 10
    assert test_settings.max_in_list_size == 1000
    assert test_settings.max_per_page == 500


def test_override_settings():
    """Verify settings can be overridden and restored to defaults."""
    # Store original values
    original_max_filter_depth = soh.settings.max_filter_depth
    original_max_and_or_items = soh.settings.max_and_or_items
    original_max_load_depth = soh.settings.max_load_depth
    original_max_in_list_size = soh.settings.max_in_list_size
    original_max_per_page = soh.settings.max_per_page

    try:
        # Override settings
        soh.settings.max_filter_depth = 50
        soh.settings.max_and_or_items = 75
        soh.settings.max_load_depth = 5
        soh.settings.max_in_list_size = 500
        soh.settings.max_per_page = 300

        # Verify overrides
        assert soh.settings.max_filter_depth == 50
        assert soh.settings.max_and_or_items == 75
        assert soh.settings.max_load_depth == 5
        assert soh.settings.max_in_list_size == 500
        assert soh.settings.max_per_page == 300
    finally:
        # Restore defaults
        soh.settings.max_filter_depth = original_max_filter_depth
        soh.settings.max_and_or_items = original_max_and_or_items
        soh.settings.max_load_depth = original_max_load_depth
        soh.settings.max_in_list_size = original_max_in_list_size
        soh.settings.max_per_page = original_max_per_page

    # Verify restoration
    assert soh.settings.max_filter_depth == 100
    assert soh.settings.max_and_or_items == 100
    assert soh.settings.max_load_depth == 10
    assert soh.settings.max_in_list_size == 1000
    assert soh.settings.max_per_page == 500


def test_settings_is_basemodel():
    """Verify QueryHelperSettings is a Pydantic BaseModel instance."""
    assert isinstance(soh.settings, BaseModel)
    assert isinstance(soh.settings, soh.QueryHelperSettings)


def test_settings_is_pydantic_model_class():
    """Verify QueryHelperSettings is a Pydantic model class."""
    assert issubclass(soh.QueryHelperSettings, BaseModel)


def test_settings_instance_has_all_attributes():
    """Verify the module-level settings instance has all expected attributes."""
    assert hasattr(soh.settings, "max_filter_depth")
    assert hasattr(soh.settings, "max_and_or_items")
    assert hasattr(soh.settings, "max_load_depth")
    assert hasattr(soh.settings, "max_in_list_size")
    assert hasattr(soh.settings, "max_per_page")


def test_settings_attributes_are_integers():
    """Verify all settings attributes are integers."""
    assert isinstance(soh.settings.max_filter_depth, int)
    assert isinstance(soh.settings.max_and_or_items, int)
    assert isinstance(soh.settings.max_load_depth, int)
    assert isinstance(soh.settings.max_in_list_size, int)
    assert isinstance(soh.settings.max_per_page, int)


def test_settings_attributes_are_positive():
    """Verify all settings attributes have positive values."""
    assert soh.settings.max_filter_depth > 0
    assert soh.settings.max_and_or_items > 0
    assert soh.settings.max_load_depth > 0
    assert soh.settings.max_in_list_size > 0
    assert soh.settings.max_per_page > 0


def test_create_custom_settings_instance():
    """Verify custom QueryHelperSettings instances can be created with different values."""
    custom_settings = soh.QueryHelperSettings(
        max_filter_depth=50,
        max_and_or_items=75,
        max_load_depth=8,
        max_in_list_size=2000,
        max_per_page=250,
    )
    assert custom_settings.max_filter_depth == 50
    assert custom_settings.max_and_or_items == 75
    assert custom_settings.max_load_depth == 8
    assert custom_settings.max_in_list_size == 2000
    assert custom_settings.max_per_page == 250


def test_partial_override_settings():
    """Verify partial overrides work with remaining defaults."""
    partial_settings = soh.QueryHelperSettings(max_per_page=200)
    assert partial_settings.max_filter_depth == 100  # default
    assert partial_settings.max_and_or_items == 100  # default
    assert partial_settings.max_load_depth == 10  # default
    assert partial_settings.max_in_list_size == 1000  # default
    assert partial_settings.max_per_page == 200  # overridden


def test_settings_model_dump():
    """Verify QueryHelperSettings.model_dump() returns all attributes as dict."""
    settings_dict = soh.settings.model_dump()
    assert isinstance(settings_dict, dict)
    assert settings_dict["max_filter_depth"] == 100
    assert settings_dict["max_and_or_items"] == 100
    assert settings_dict["max_load_depth"] == 10
    assert settings_dict["max_in_list_size"] == 1000
    assert settings_dict["max_per_page"] == 500


def test_settings_model_validate():
    """Verify QueryHelperSettings can validate from dict."""
    data = {
        "max_filter_depth": 75,
        "max_and_or_items": 50,
        "max_load_depth": 7,
        "max_in_list_size": 1500,
        "max_per_page": 400,
    }
    validated_settings = soh.QueryHelperSettings.model_validate(data)
    assert validated_settings.max_filter_depth == 75
    assert validated_settings.max_and_or_items == 50
    assert validated_settings.max_load_depth == 7
    assert validated_settings.max_in_list_size == 1500
    assert validated_settings.max_per_page == 400


def test_settings_serialization():
    """Verify QueryHelperSettings can be serialized to JSON-compatible dict."""
    settings_json = soh.settings.model_dump_json()
    assert isinstance(settings_json, str)
    assert "max_filter_depth" in settings_json
    assert "max_and_or_items" in settings_json
    assert "max_load_depth" in settings_json
    assert "max_in_list_size" in settings_json
    assert "max_per_page" in settings_json
