"""
Integration tests for update_objects() and delete_objects() bulk mutations.

Tests use the same in-memory SQLite database and exam-crm production schema
as other test modules.
"""

import pytest
from sqlmodel import select

import sqlmodel_object_helpers as soh

from conftest import Attempt


pytestmark = pytest.mark.asyncio


# ============================================================================
# update_objects tests
# ============================================================================


async def test_update_objects_basic(session, seed_data):
    """Bulk update sets field on matching rows."""
    count = await soh.update_objects(
        session, Attempt,
        data={"is_blocked": True},
        filters={"is_active": {soh.Operator.EQ: True}},
    )
    assert count == 3  # att1, att3, att4 are active

    result = await session.execute(
        select(Attempt).where(Attempt.is_active, Attempt.is_blocked),
    )
    blocked_active = result.scalars().all()
    assert len(blocked_active) == 3


async def test_update_objects_no_match(session, seed_data):
    """Bulk update returns 0 when no rows match."""
    count = await soh.update_objects(
        session, Attempt,
        data={"is_blocked": True},
        filters={"status_id": {soh.Operator.EQ: 999}},
    )
    assert count == 0


async def test_update_objects_rejects_empty_filters(session, seed_data):
    """Bulk update without filters raises MutationError."""
    with pytest.raises(soh.MutationError, match="filters are required"):
        await soh.update_objects(
            session, Attempt,
            data={"is_blocked": True},
            filters=None,
        )


async def test_update_objects_rejects_empty_dict_filters(session, seed_data):
    """Bulk update with empty dict filters raises MutationError."""
    with pytest.raises(soh.MutationError, match="filters are required"):
        await soh.update_objects(
            session, Attempt,
            data={"is_blocked": True},
            filters={},
        )


async def test_update_objects_rejects_empty_data(session, seed_data):
    """Bulk update with empty data dict raises MutationError."""
    with pytest.raises(soh.MutationError, match="data cannot be empty"):
        await soh.update_objects(
            session, Attempt,
            data={},
            filters={"is_active": {soh.Operator.EQ: True}},
        )


async def test_update_objects_rejects_bad_field(session, seed_data):
    """Bulk update with non-existent field in data raises MutationError."""
    with pytest.raises(soh.MutationError, match="has no field"):
        await soh.update_objects(
            session, Attempt,
            data={"nonexistent_field": True},
            filters={"is_active": {soh.Operator.EQ: True}},
        )


async def test_update_objects_rejects_relation_filter(session, seed_data):
    """Bulk update with dot-notation (relation) filter raises MutationError."""
    with pytest.raises(soh.MutationError, match="related tables"):
        await soh.update_objects(
            session, Attempt,
            data={"is_blocked": True},
            filters={"application.email": {soh.Operator.EQ: "test@example.com"}},
        )


# ============================================================================
# delete_objects tests
# ============================================================================


async def test_delete_objects_basic(session, seed_data):
    """Bulk delete removes matching rows."""
    # Delete blocked attempts — att4 is blocked and has no billing FK references
    count = await soh.delete_objects(
        session, Attempt,
        filters={"is_blocked": {soh.Operator.EQ: True}},
    )
    assert count == 1

    result = await session.execute(select(Attempt))
    remaining = result.scalars().all()
    assert len(remaining) == 3


async def test_delete_objects_no_match(session, seed_data):
    """Bulk delete returns 0 when no rows match."""
    count = await soh.delete_objects(
        session, Attempt,
        filters={"status_id": {soh.Operator.EQ: 999}},
    )
    assert count == 0


async def test_delete_objects_rejects_empty_filters(session, seed_data):
    """Bulk delete without filters raises MutationError."""
    with pytest.raises(soh.MutationError, match="filters are required"):
        await soh.delete_objects(session, Attempt, filters=None)


async def test_delete_objects_rejects_relation_filter(session, seed_data):
    """Bulk delete with dot-notation (relation) filter raises MutationError."""
    with pytest.raises(soh.MutationError, match="related tables"):
        await soh.delete_objects(
            session, Attempt,
            filters={"application.email": {soh.Operator.EQ: "test@example.com"}},
        )


async def test_delete_objects_multiple_conditions(session, seed_data):
    """Bulk delete with multiple AND conditions."""
    count = await soh.delete_objects(
        session, Attempt,
        filters={"is_active": {soh.Operator.EQ: True}, "is_blocked": {soh.Operator.EQ: True}},
        logical_operator="AND",
    )
    assert count == 1  # only att4 is active AND blocked

    result = await session.execute(select(Attempt))
    remaining = result.scalars().all()
    assert len(remaining) == 3
