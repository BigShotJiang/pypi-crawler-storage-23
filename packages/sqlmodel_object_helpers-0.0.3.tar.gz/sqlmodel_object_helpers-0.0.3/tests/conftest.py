"""
Shared fixtures: in-memory SQLite + SQLModel models from exam-crm production schema.

Models match the SQL dump: last_exam-dump-exam_db-202601141043.sql
PostgreSQL-specific types (enums, timestamptz) adapted for SQLite compatibility.
"""

from datetime import date, datetime

import pytest_asyncio
from sqlalchemy import Column, Computed, Float, String, event, func, select as sa_select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import column_property
from sqlmodel import Field, Relationship, SQLModel


# ---------------------------------------------------------------------------
# Models — exact column names from production PostgreSQL schema
#
# Chain: Organization → Unit(units_lkp) → Schedule → Attempt → Application → Applicant
# Side:  Organization → BankAccount (via Bank)
#        Attempt → Billing ←→ Payment (M2M via billings_payments_ao)
# ---------------------------------------------------------------------------


class Organization(SQLModel, table=True):
    __tablename__ = "organizations"

    id: int | None = Field(default=None, primary_key=True)
    short_name: str | None = None
    full_name: str | None = None
    ogrn: str | None = None
    inn: str | None = None
    kpp: str | None = None
    empowered: str | None = None
    head_short_name: str | None = None
    head_full_name: str | None = None
    head_full_name_genetive: str | None = None
    head_position: str | None = None
    head_position_genetive: str | None = None
    legal_address: str | None = None
    billing_type_id: int | None = None
    phone: str | None = None
    city: str | None = None
    abbr: str | None = None
    description_override: str | None = None
    base1c: str | None = None
    ogrn_date: date | None = None
    edo_vendor: str | None = None
    edo_identificator: str | None = None
    is_1c_enabled: bool = False
    nds_id: int | None = None

    units: list[Unit] = Relationship(back_populates="organization")
    bank_accounts: list[BankAccount] = Relationship(back_populates="organization")
    billings: list[Billing] = Relationship(back_populates="organization")


class Bank(SQLModel, table=True):
    __tablename__ = "banks"

    id: int | None = Field(default=None, primary_key=True)
    name: str | None = None
    bik: str | None = None
    ks: str | None = None

    bank_accounts: list[BankAccount] = Relationship(back_populates="bank")


class BankAccount(SQLModel, table=True):
    __tablename__ = "bank_accounts"

    id: int | None = Field(default=None, primary_key=True)
    bank_rs: str
    organization_id: int | None = Field(default=None, foreign_key="organizations.id")
    bank_id: int | None = Field(default=None, foreign_key="banks.id")
    is_disabled: bool = False

    organization: Organization | None = Relationship(back_populates="bank_accounts")
    bank: Bank | None = Relationship(back_populates="bank_accounts")


class Unit(SQLModel, table=True):
    __tablename__ = "units_lkp"

    id: int | None = Field(default=None, primary_key=True)
    address: str
    full_name: str
    max_pc: int
    parent_id: int | None = Field(default=None, foreign_key="units_lkp.id")
    short_name: str
    organization_id: int | None = Field(default=None, foreign_key="organizations.id")
    city: str | None = None
    abbr_en: str | None = None
    phone: str | None = None
    is_hidden: bool | None = False
    tz: str | None = None
    is_self_exam: bool | None = True

    organization: Organization | None = Relationship(back_populates="units")
    parent: Unit = Relationship(
        back_populates="children",
        sa_relationship_kwargs={"remote_side": "Unit.id"},
    )
    children: list[Unit] = Relationship(back_populates="parent")
    schedules: list[Schedule] = Relationship(back_populates="unit")
    attempts: list[Attempt] = Relationship(back_populates="unit")


class Schedule(SQLModel, table=True):
    __tablename__ = "schedules"

    id: int | None = Field(default=None, primary_key=True)
    is_nostroy: bool
    is_nopriz: bool
    is_portfolio: bool
    is_singly: bool
    schedule_date: datetime
    unit_id: int | None = Field(default=None, foreign_key="units_lkp.id")
    hours: int | None = None
    max_pc: int | None = None
    is_hidden: bool = False
    workday_calendar_date: date | None = None

    unit: Unit | None = Relationship(back_populates="schedules")
    attempts: list[Attempt] = Relationship(back_populates="schedule")


class Applicant(SQLModel, table=True):
    __tablename__ = "applicants"

    id: int | None = Field(default=None, primary_key=True)
    passport_country_id: int | None = None
    passport_code: str | None = None
    passport_issue_date: date | None = None
    passport_issued_by: str | None = None
    passport_registration_address: str | None = None
    passport_series: str | None = None
    passport_number: str
    phone: str | None = None
    snils: str | None = None
    last_name: str | None = None
    first_name: str | None = None
    middle_name: str | None = None
    gender_id: int | None = None
    birthdate: date | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    is_nrs: bool = False
    parston_register: bool | None = None

    applications: list[Application] = Relationship(back_populates="applicant")
    payments: list[Payment] = Relationship(back_populates="applicant")


class Application(SQLModel, table=True):
    __tablename__ = "applications"

    id: int | None = Field(default=None, primary_key=True)
    email: str | None = None
    applicant_id: int | None = Field(default=None, foreign_key="applicants.id")
    assignee_id: int | None = None
    qualification_id: int | None = None
    is_closed: bool = False
    bonus_sum: int | None = None
    bonus_date: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    parston_register: bool | None = None
    is_email_test_mode: bool | None = None

    applicant: Applicant | None = Relationship(back_populates="applications")
    attempts: list[Attempt] = Relationship(back_populates="application")


class Attempt(SQLModel, table=True):
    __tablename__ = "attempts"

    id: int | None = Field(default=None, primary_key=True)
    email: str | None = None
    schedule_id: int | None = Field(default=None, foreign_key="schedules.id")
    application_id: int | None = Field(default=None, foreign_key="applications.id")
    attempt_type_id: int | None = None
    status_id: int | None = None
    unit_id: int | None = Field(default=None, foreign_key="units_lkp.id")
    is_buh_ready: bool | None = None
    is_io_ready: bool | None = None
    is_operator_ready: bool | None = None
    is_portfolio_ready: bool | None = None
    is_paid: bool | None = None
    token: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    status_updated_at: datetime | None = None
    billed_garant: int | None = None
    billed_gp: int | None = None
    paid_garant: int | None = None
    paid_gp: int | None = None
    is_active: bool
    is_blocked: bool
    schedule_type_id: int | None = None
    is_nrs: bool | None = None
    parston_uuid: str | None = None
    parston_register: bool | None = None
    is_etk_required: bool | None = False
    # tk_request: etkmark enum → str in SQLite
    tk_request: str | None = None

    application: Application | None = Relationship(back_populates="attempts")
    schedule: Schedule | None = Relationship(back_populates="attempts")
    unit: Unit | None = Relationship(back_populates="attempts")
    billings: list[Billing] = Relationship(back_populates="attempt")


class Billing(SQLModel, table=True):
    __tablename__ = "billings"

    id: int | None = Field(default=None, primary_key=True)
    attempt_id: int = Field(foreign_key="attempts.id")
    billing_type_id: int
    bank_acc_id: int | None = Field(default=None, foreign_key="bank_accounts.id")
    organization_id: int | None = Field(default=None, foreign_key="organizations.id")
    is_physical: bool
    invoice_reason: str
    invoice_date: date
    agreement_reason: str | None = None
    agreement_create_date: date
    agreement_expire_date: date
    address: str
    company_full_name: str | None = None
    company_short_name: str | None = None
    is_female: bool | None = None
    head_short_name: str | None = None
    head_full_name: str | None = None
    head_full_name_genitive: str | None = None
    head_position: str | None = None
    head_positiongenitive: str | None = None
    inn: str | None = None
    kpp: str | None = None
    ogrn: str | None = None
    bank_rs: str | None = None
    bank_ks: str | None = None
    bank_bik: str | None = None
    bank_name: str | None = None
    passport_issued: str | None = None
    passport_issued_date: date | None = None
    list_applicants_number: str | None = None
    list_applicants_date: date | None = None
    list_services_number: str | None = None
    list_services_date: date | None = None
    organization_short_name: str | None = None
    organization_inn: str | None = None
    organization_rs: str | None = None
    created_at: datetime | None = None
    is_paid: bool
    invoice_number: str | None = None
    agreement_number: str | None = None
    act_number: str | None = None
    act_date: date | None = None
    paid_in_debt: bool | None = False
    is_email_requested: bool | None = True
    is_1c: bool | None = True
    nds_id: int | None = None

    attempt: Attempt = Relationship(back_populates="billings")
    organization: Organization | None = Relationship(back_populates="billings")
    bank_account: BankAccount | None = Relationship()
    billing_payments: list[BillingPaymentAO] = Relationship(back_populates="billing")


class Payment(SQLModel, table=True):
    __tablename__ = "payments"

    id: int | None = Field(default=None, primary_key=True)
    operation_date: date | None = None
    corespond_inn: str | None = None
    corespond_name: str | None = None
    doc_number: str | None = None
    doc_date: date | None = None
    credit: int | None = None
    recipient_account: str | None = None
    recipient_inn: str | None = None
    recipient_name: str | None = None
    comment: str | None = None
    is_unknown: bool | None = None
    is_splitted: bool | None = None
    is_deleted: bool | None = None
    is_returned: bool | None = None
    parent_id: int | None = Field(default=None, foreign_key="payments.id")
    payment_type_id: int
    user_id: int
    created_at: datetime | None = None
    md5: str
    applicant_id: int | None = Field(default=None, foreign_key="applicants.id")
    buh_comment: str | None = None

    parent: Payment = Relationship(
        back_populates="children",
        sa_relationship_kwargs={"remote_side": "Payment.id"},
    )
    children: list[Payment] = Relationship(back_populates="parent")
    applicant: Applicant | None = Relationship(back_populates="payments")
    billing_payments: list[BillingPaymentAO] = Relationship(back_populates="payment")


class BillingPaymentAO(SQLModel, table=True):
    """Many-to-many association: billings ↔ payments."""

    __tablename__ = "billings_payments_ao"

    billing_id: int = Field(foreign_key="billings.id", primary_key=True)
    payment_id: int = Field(foreign_key="payments.id", primary_key=True)

    billing: Billing = Relationship(back_populates="billing_payments")
    payment: Payment = Relationship(back_populates="billing_payments")


class Product(SQLModel, table=True):
    """Demo model: DB-level computed column via GENERATED ALWAYS AS."""

    __tablename__ = "products"

    id: int | None = Field(default=None, primary_key=True)
    quantity: int
    unit_price: float
    total_price: float | None = Field(
        default=None,
        sa_column=Column(Float, Computed("quantity * unit_price")),
    )


FULL_NAME_EXPR = (
    "NULLIF(TRIM(COALESCE(last_name,'') || "
    "CASE WHEN first_name IS NOT NULL THEN ' '||first_name ELSE '' END || "
    "CASE WHEN middle_name IS NOT NULL THEN ' '||middle_name ELSE '' END), '')"
)

PASSPORT_EXPR = (
    "NULLIF(TRIM(COALESCE(passport_series,'') || "
    "CASE WHEN passport_number IS NOT NULL THEN ' '||passport_number ELSE '' END), '')"
)


class ApplicantWithGenerated(SQLModel, table=True):
    """Model with GENERATED ALWAYS AS STORED columns for full_name / passport."""

    __tablename__ = "applicants_generated"

    id: int | None = Field(default=None, primary_key=True)
    last_name: str | None = None
    first_name: str | None = None
    middle_name: str | None = None
    passport_series: str | None = None
    passport_number: str | None = None
    full_name: str | None = Field(
        default=None,
        sa_column=Column(String, Computed(FULL_NAME_EXPR)),
    )
    passport: str | None = Field(
        default=None,
        sa_column=Column(String, Computed(PASSPORT_EXPR)),
    )


# ---------------------------------------------------------------------------
# column_property — cross-table computation (workaround for SQLModel)
# Must be assigned AFTER both classes are defined.
# See: https://github.com/fastapi/sqlmodel/issues/240
# ---------------------------------------------------------------------------

Schedule.attempt_count = column_property(
    sa_select(func.count(Attempt.id))
    .where(Attempt.schedule_id == Schedule.id)
    .correlate_except(Attempt)
    .scalar_subquery()
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def engine():
    eng = create_async_engine("sqlite+aiosqlite:///:memory:")

    # Enable FK enforcement in SQLite (mirrors PostgreSQL behavior)
    @event.listens_for(eng.sync_engine, "connect")
    def _set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    async with eng.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture
async def session(engine):
    async with AsyncSession(engine, expire_on_commit=False) as sess:
        yield sess


@pytest_asyncio.fixture
async def seed_data(session: AsyncSession):
    """
    Seed realistic test data matching production exam-crm schema.

    Organizations:
        org1: АО "ЦОК Энергетик" (INN 7701234567)
        org2: ООО "ТестОрг" (INN 5012345678)

    Banks:
        bank1: ПАО Сбербанк (BIK 044525225)
        bank2: АО Тинькофф Банк (BIK 044525974)

    BankAccounts:
        ba1 → org1, bank1 (account 40702810938000012345)
        ba2 → org2, bank2 (account 40702810100000054321, disabled)

    Units (units_lkp):
        unit1 → org1: ЦОК Москва (address, full_name, short_name, max_pc=20)
        unit2 → org2: Филиал Казань (child of unit1 via parent_id)

    Schedules:
        sched1 → unit1: 2026-03-15 09:00, nostroy, 20 max_pc
        sched2 → unit2: 2026-04-10 10:00, nopriz, 10 max_pc

    Applicants:
        applicant1: Иванов Пётр Сергеевич, NRS, passport 4510 123456, born 1990-05-15
        applicant2: Петрова Анна Игоревна, not NRS, passport 4511 654321, born 1985-11-20
        applicant3: Сидоров Алексей (no middle_name, no birthdate), NRS

    Applications:
        appl1 → applicant1: ivanov@example.com, closed=False
        appl2 → applicant2: petrova@example.com, closed=False
        appl3 → applicant3: no email, closed=True

    Attempts:
        att1 → appl1, sched1, unit1: status=10, active, not blocked
        att2 → appl1, sched2, unit2: status=120, inactive, not blocked
        att3 → appl2, sched1, unit1: status=10, active, not blocked
        att4 → appl3, no schedule, unit1: status=20, active, blocked

    Billings:
        bill1 → att1, org1, ba1: individual, paid, 5000 (invoice 2026-02-01)
        bill2 → att2, org2, ba2: legal entity, not paid, 3000 (invoice 2026-02-15)

    Payments:
        pay1: credit=5000, linked to applicant1 (doc_number ПП-001)
        pay2: credit=3000, linked to applicant2 (doc_number ПП-002)

    BillingPaymentAO:
        bill1 ↔ pay1
    """
    # --- Organizations ---
    org1 = Organization(
        short_name='АО "ЦОК Энергетик"',
        full_name='Акционерное общество "Центр оценки квалификации Энергетик"',
        inn="7701234567", kpp="770101001", ogrn="1177746000001",
        ogrn_date=date(2017, 3, 10),
        head_short_name="Петров И.С.",
        head_full_name="Петров Игорь Сергеевич",
        head_position="Генеральный директор",
        legal_address="г. Москва, ул. Энергетическая, д. 10",
        city="Москва",
    )
    org2 = Organization(
        short_name='ООО "ТестОрг"',
        full_name='Общество с ограниченной ответственностью "ТестОрг"',
        inn="5012345678", kpp="501201001", ogrn="1195012000002",
        city="Казань",
    )
    session.add_all([org1, org2])
    await session.flush()

    # --- Banks ---
    bank1 = Bank(name="ПАО Сбербанк", bik="044525225", ks="30101810400000000225")
    bank2 = Bank(name="АО Тинькофф Банк", bik="044525974", ks="30101810145250000974")
    session.add_all([bank1, bank2])
    await session.flush()

    # --- BankAccounts ---
    ba1 = BankAccount(
        bank_rs="40702810938000012345", organization_id=org1.id, bank_id=bank1.id,
    )
    ba2 = BankAccount(
        bank_rs="40702810100000054321", organization_id=org2.id, bank_id=bank2.id,
        is_disabled=True,
    )
    session.add_all([ba1, ba2])
    await session.flush()

    # --- Units (units_lkp) ---
    unit1 = Unit(
        address="г. Москва, ул. Энергетическая, д. 10, оф. 301",
        full_name="Центр оценки квалификации г. Москва",
        short_name="ЦОК Москва",
        max_pc=20,
        organization_id=org1.id,
        city="Москва",
        abbr_en="COK-MSK",
        tz="Europe/Moscow",
    )
    session.add(unit1)
    await session.flush()

    unit2 = Unit(
        address="г. Казань, ул. Баумана, д. 5",
        full_name="Филиал Казань",
        short_name="Филиал Казань",
        max_pc=10,
        organization_id=org2.id,
        parent_id=unit1.id,
        city="Казань",
        tz="Europe/Moscow",
    )
    session.add(unit2)
    await session.flush()

    # --- Schedules ---
    sched1 = Schedule(
        is_nostroy=True, is_nopriz=False, is_portfolio=False, is_singly=False,
        schedule_date=datetime(2026, 3, 15, 9, 0),
        unit_id=unit1.id, hours=4, max_pc=20,
    )
    sched2 = Schedule(
        is_nostroy=False, is_nopriz=True, is_portfolio=True, is_singly=False,
        schedule_date=datetime(2026, 4, 10, 10, 0),
        unit_id=unit2.id, hours=3, max_pc=10,
    )
    session.add_all([sched1, sched2])
    await session.flush()

    # --- Applicants ---
    applicant1 = Applicant(
        last_name="Иванов", first_name="Пётр", middle_name="Сергеевич",
        passport_number="123456", passport_series="4510",
        passport_issued_by="ОВД г. Москвы",
        passport_issue_date=date(2010, 6, 20),
        snils="123-456-789 00",
        phone="+79161234567",
        birthdate=date(1990, 5, 15),
        gender_id=1,
        is_nrs=True,
        created_at=datetime(2026, 1, 5, 10, 0),
    )
    applicant2 = Applicant(
        last_name="Петрова", first_name="Анна", middle_name="Игоревна",
        passport_number="654321", passport_series="4511",
        passport_issued_by="ОВД г. Казани",
        passport_issue_date=date(2012, 3, 15),
        snils="987-654-321 00",
        phone="+79279876543",
        birthdate=date(1985, 11, 20),
        gender_id=2,
        is_nrs=False,
        created_at=datetime(2026, 1, 8, 14, 30),
    )
    applicant3 = Applicant(
        last_name="Сидоров", first_name="Алексей",
        passport_number="111222",
        is_nrs=True,
        created_at=datetime(2026, 1, 10, 9, 0),
    )
    session.add_all([applicant1, applicant2, applicant3])
    await session.flush()

    # --- Applications ---
    appl1 = Application(
        applicant_id=applicant1.id, email="ivanov@example.com",
        is_closed=False,
        created_at=datetime(2026, 1, 10, 9, 0),
    )
    appl2 = Application(
        applicant_id=applicant2.id, email="petrova@example.com",
        is_closed=False,
        created_at=datetime(2026, 1, 12, 14, 30),
    )
    appl3 = Application(
        applicant_id=applicant3.id,
        is_closed=True,
        created_at=datetime(2026, 1, 15, 11, 0),
    )
    session.add_all([appl1, appl2, appl3])
    await session.flush()

    # --- Attempts ---
    att1 = Attempt(
        application_id=appl1.id, schedule_id=sched1.id, unit_id=unit1.id,
        status_id=10, is_active=True, is_blocked=False,
        email="ivanov@example.com",
        created_at=datetime(2026, 1, 11, 10, 0),
    )
    att2 = Attempt(
        application_id=appl1.id, schedule_id=sched2.id, unit_id=unit2.id,
        status_id=120, is_active=False, is_blocked=False,
        email="ivanov@example.com",
        created_at=datetime(2026, 1, 20, 12, 0),
    )
    att3 = Attempt(
        application_id=appl2.id, schedule_id=sched1.id, unit_id=unit1.id,
        status_id=10, is_active=True, is_blocked=False,
        email="petrova@example.com",
        created_at=datetime(2026, 1, 13, 15, 0),
    )
    att4 = Attempt(
        application_id=appl3.id, schedule_id=None, unit_id=unit1.id,
        status_id=20, is_active=True, is_blocked=True,
        created_at=datetime(2026, 1, 16, 9, 30),
    )
    session.add_all([att1, att2, att3, att4])
    await session.flush()

    # --- Billings ---
    bill1 = Billing(
        attempt_id=att1.id, billing_type_id=1,
        bank_acc_id=ba1.id, organization_id=org1.id,
        is_physical=True, is_paid=True,
        invoice_reason="Оценка квалификации",
        invoice_date=date(2026, 2, 1),
        agreement_create_date=date(2026, 1, 15),
        agreement_expire_date=date(2026, 12, 31),
        address="г. Москва, ул. Энергетическая, д. 10",
        inn=applicant1.snils,
        bank_bik=bank1.bik, bank_name=bank1.name,
        bank_rs=ba1.bank_rs,
        organization_short_name=org1.short_name,
        organization_inn=org1.inn,
        invoice_number="СЧ-0001",
        agreement_number="ДОГ-0001",
        created_at=datetime(2026, 2, 1, 10, 0),
    )
    bill2 = Billing(
        attempt_id=att2.id, billing_type_id=2,
        bank_acc_id=ba2.id, organization_id=org2.id,
        is_physical=False, is_paid=False,
        invoice_reason="Оценка квалификации (юрлицо)",
        invoice_date=date(2026, 2, 15),
        agreement_create_date=date(2026, 2, 1),
        agreement_expire_date=date(2026, 12, 31),
        address="г. Казань, ул. Баумана, д. 5",
        company_full_name='ООО "СтройМонтаж"',
        company_short_name="СтройМонтаж",
        inn="1601234567", kpp="160101001",
        bank_bik=bank2.bik, bank_name=bank2.name,
        bank_rs=ba2.bank_rs,
        organization_short_name=org2.short_name,
        organization_inn=org2.inn,
        invoice_number="СЧ-0002",
        agreement_number="ДОГ-0002",
        created_at=datetime(2026, 2, 15, 11, 0),
    )
    session.add_all([bill1, bill2])
    await session.flush()

    # --- Payments ---
    pay1 = Payment(
        operation_date=date(2026, 2, 5),
        corespond_inn=org1.inn,
        corespond_name=org1.short_name,
        doc_number="ПП-001",
        doc_date=date(2026, 2, 5),
        credit=5000,
        payment_type_id=1,
        user_id=1,
        md5="a1b2c3d4e5f6",
        applicant_id=applicant1.id,
    )
    pay2 = Payment(
        operation_date=date(2026, 2, 20),
        corespond_inn="1601234567",
        corespond_name='ООО "СтройМонтаж"',
        doc_number="ПП-002",
        doc_date=date(2026, 2, 20),
        credit=3000,
        payment_type_id=1,
        user_id=1,
        md5="f6e5d4c3b2a1",
        applicant_id=applicant2.id,
    )
    session.add_all([pay1, pay2])
    await session.flush()

    # --- BillingPaymentAO ---
    bp1 = BillingPaymentAO(billing_id=bill1.id, payment_id=pay1.id)
    session.add(bp1)
    await session.commit()

    return {
        "organizations": [org1, org2],
        "banks": [bank1, bank2],
        "bank_accounts": [ba1, ba2],
        "units": [unit1, unit2],
        "schedules": [sched1, sched2],
        "applicants": [applicant1, applicant2, applicant3],
        "applications": [appl1, appl2, appl3],
        "attempts": [att1, att2, att3, att4],
        "billings": [bill1, bill2],
        "payments": [pay1, pay2],
    }


@pytest_asyncio.fixture
async def seed_products(session: AsyncSession):
    """Seed Product rows to test DB-level Computed columns."""
    products = [
        Product(quantity=10, unit_price=15.0),   # total = 150
        Product(quantity=3, unit_price=25.0),    # total = 75
        Product(quantity=20, unit_price=8.5),    # total = 170
    ]
    session.add_all(products)
    await session.flush()
    for p in products:
        await session.refresh(p)
    return products


@pytest_asyncio.fixture
async def seed_applicants_generated(session: AsyncSession):
    """Seed ApplicantWithGenerated rows to test GENERATED ALWAYS AS columns."""
    rows = [
        ApplicantWithGenerated(
            last_name="Иванов", first_name="Иван", middle_name="Иванович",
            passport_series="4510", passport_number="123456",
        ),
        ApplicantWithGenerated(
            last_name="Петров", first_name="Пётр",
            passport_series="4511", passport_number="654321",
        ),
        ApplicantWithGenerated(
            last_name="Сидоров",
        ),
        ApplicantWithGenerated(
            passport_number="123456",
        ),
        ApplicantWithGenerated(),  # all NULL
    ]
    session.add_all(rows)
    await session.flush()
    for r in rows:
        await session.refresh(r)
    return rows
