"""
Shop System Models - Shared model definitions for shop system services
"""

__version__ = "0.1.1"
