"""Command-related models for the shop system."""
