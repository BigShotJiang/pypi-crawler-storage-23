from shop_system_models.shop_api.commands.request import BotCommandModel


class BotCommandResponseModel(BotCommandModel):
    id: str
