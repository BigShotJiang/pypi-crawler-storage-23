import json
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from anthropic import Anthropic
from d4k_ms_base import ServiceEnvironment


class Claude:
    MODULE = "usdm4_legacy.claude.claude.Claude"
    CLAUDE_MODEL = "claude-haiku-4-5-20251001"
    MODEL_PRICING = {CLAUDE_MODEL: {"input": 15.0, "output": 75.0}}

    def __init__(self, errors: Errors):
        api_key = ServiceEnvironment().get("ANTHROPIC_API_KEY")
        self._errors = errors
        self._client = None
        if not api_key:
            errors.error(
                "Anthropic API key environment variable is not set",
                KlassMethodLocation(self.MODULE, "__init__"),
            )
        else:
            self._client = Anthropic(api_key=api_key)

    def prompt(self, text: str, system: str = "") -> str:
        try:
            if not self._client:
                self._errors.error(
                    "No client object found", KlassMethodLocation(self.MODULE, "prompt")
                )
                return None
            message = self._client.messages.create(
                max_tokens=1024,
                system=system,
                messages=[
                    {
                        "role": "user",
                        "content": text,
                    }
                ],
                model=self.CLAUDE_MODEL,
            )
            return message.content[0].text
        except Exception as e:
            self._errors.exception(
                "Error executing prompt '{text}'",
                e,
                KlassMethodLocation(self.MODULE, "prompt"),
            )
            return None

    def extract_json(self, text: str | None, dict=True) -> dict | None:
        if text:
            result = text.replace("\n", "")
            if dict:
                s_index = result.find("{")
                e_index = result.rfind("}")
            else:
                s_index = result.find("[")
                e_index = result.rfind("]")
            if s_index >= 0 and e_index >= 0 and e_index > s_index:
                result = result[s_index : e_index + 1]
                try:
                    return json.loads(result)
                except Exception as e:
                    self._errors.exception(
                        "Error decoding Claude JSON",
                        e,
                        KlassMethodLocation(self.MODULE, "extract_json"),
                    )
                    return None
        self._errors.error(
            "Error decoding Claude response",
            KlassMethodLocation(self.MODULE, "extract_json"),
        )
        return None

    def streaming_prompt(self, text: str, system_message: str = "") -> str:
        result_text = None
        with self._client.messages.stream(
            model=self.CLAUDE_MODEL,
            max_tokens=16384,  # Default for smaller extractions
            temperature=0,  # Zero temperature for deterministic output
            system=system_message,
            messages=[
                {
                    "role": "user",
                    "content": text,
                }
            ],
        ) as stream:
            # Process the streamed response
            result_text = self._streaming_response(stream)
        return result_text

    def _streaming_response(self, stream):
        full_response = ""
        try:
            for chunk in stream:
                if hasattr(chunk, "delta") and hasattr(chunk.delta, "text"):
                    content = chunk.delta.text
                    full_response += content
        except Exception as e:
            self._errors.exception(
                "Error decoding Claude stream",
                e,
                KlassMethodLocation(self.MODULE, "streaming_response"),
            )
            full_response = None
        return full_response
