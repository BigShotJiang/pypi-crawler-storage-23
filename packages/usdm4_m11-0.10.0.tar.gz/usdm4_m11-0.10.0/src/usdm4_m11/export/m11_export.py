from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4.api import (
    Wrapper,
    StudyDefinitionDocumentVersion,
    NarrativeContent,
    StudyVersion,
)
from usdm4_m11.utility.soup import get_soup, BeautifulSoup
from usdm4_m11.elements.elements import Elements
from usdm4_m11.specification import Specification


class M11Export:
    MODULE = "usdm4_m11.import_.m11_import.M11Export"

    def __init__(self, wrapper: Wrapper, errors: Errors):
        self._wrapper = wrapper
        self._errors = errors

    def process(self) -> str:
        try:
            elements = Elements(self._wrapper)
            specification = Specification()
            sl: dict = specification.section_list()
            text = '<div class="ich-m11-document-div">'
            if self._wrapper:
                version: StudyVersion = self._wrapper.first_version()
                nci_map = version.narrative_content_item_map()
                document: StudyDefinitionDocumentVersion = (
                    self._wrapper.study_document_version("M11")
                )
                if document:
                    ncs: list[NarrativeContent] = document.narrative_content_in_order()
                    for nc in ncs:
                        # print(f"NC: '{nc.sectionNumber}' '{nc.sectionTitle}'")
                        if section := self._in_specification(sl, nc):
                            # print(f"SECTION: Has specification: {section}")
                            template: str = specification.template(section["name"])
                            section_text = self._parse_elements(template, elements)
                        else:
                            # print(f"SECTION: Using content")
                            section_text = nc.content(nci_map)
                        text += (
                            '<div class="ich-m11-section-div">'
                            + section_text
                            + "</div>"
                        )
            else:
                text += "<i>No M11 document found</i>"
            text += "</div>"
            return text
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised processing M11 export of USDM",
                e,
                location,
            )
            return None

    @property
    def wrapper(self) -> Wrapper:
        return self._wrapper

    def _parse_elements(self, template: str, elements: Elements) -> str:
        soup = get_soup(template, self._errors)
        div: BeautifulSoup
        for div in soup.findAll("div", {"m11:hidden": True}):
            attributes = div.attrs
            hide = self._to_bool(elements.get(attributes["m11:hidden"]))
            del div["m11:hidden"]
            if hide:
                div["hidden"] = True
        ref: BeautifulSoup
        for ref in soup(["m11:element"]):
            attributes = ref.attrs
            value = elements.get(attributes["name"])
            # print(f"M11 EXPORT: {value}, {attributes["name"]}")
            if value is None:
                self._errors.error(
                    f"Detected null value for element '{attributes['name']}', ignored"
                )
            else:
                html_fragment = BeautifulSoup(value, "html.parser")
                ref.replace_with(html_fragment)
        return str(soup)

    def _in_specification(
        self, section_list, narrative_content: NarrativeContent
    ) -> dict | None:
        return next(
            (
                x
                for x in section_list
                if x["section_title"].upper() == narrative_content.sectionTitle.upper()
            ),
            None,
        )

    def _to_bool(self, value: str) -> bool:
        return True if value.upper() in ["T", "TRUE"] else False
