from usdm4.api.wrapper import Wrapper
from usdm4.api.geographic_scope import GeographicScope


class Elements:
    ELEMENT_METHODS = {
        # Title Page
        "Sponsor Confidentiality Statement": {
            "document": "_confidentiality_statement",
            "data": "",
        },
        "Full Title": {"document": "_full_title", "data": ""},
        "Trial Acronym": {"document": "_trial_acronym", "data": ""},
        "Sponsor Protocol Identifier": {"document": "_protocol_identifier", "data": ""},
        "Original Protocol": {"document": "_original_protocol", "data": ""},
        "Original Protocol Indicator": {
            "document": "_original_protocol_indicator",
            "data": "",
        },
        "Version Number": {"document": "_version_number", "data": ""},
        "Version Date": {"document": "_version_date", "data": ""},
        "Amendment Identifier": {"document": "_amendment_identifier", "data": ""},
        "Amendment Scope": {"document": "_amendment_scope", "data": ""},
        "Country Identifier": {"document": "_country_identifiers", "data": ""},
        "Region Identifier": {"document": "_region_identifiers", "data": ""},
        "Site Identifier": {"document": "_site_identifiers", "data": ""},
        "Sponsors Investigational Product Codes": {
            "document": "_not_defined",
            "data": "",
        },
        "Nonproprietary Names": {"document": "_not_defined", "data": ""},
        "Proprietary Names": {"document": "_not_defined", "data": ""},
        "Trial Phase": {"document": "_trial_phase", "data": ""},
        "Trial Short Title": {"document": "_trial_short_title", "data": ""},
        "Sponsor Name": {"document": "_sponsor_name", "data": ""},
        "Sponsor Legal Address": {"document": "_sponsor_legal_address", "data": ""},
        "Co-Sponsor Name": {"document": "_co_sponsor_name", "data": ""},
        "Co-Sponsor Legal Address": {
            "document": "_co_sponsor_legal_address",
            "data": "",
        },
        "Local Sponsor Name": {"document": "_local_sponsor_name", "data": ""},
        "Local Sponsor Legal Address": {
            "document": "_co_sponsor_legal_address",
            "data": "",
        },
        "Device Manufacturer Name": {
            "document": "_device_manufacturer_name",
            "data": "",
        },
        "Device Manufacturer Legal Address": {
            "document": "_device_manufacturer_legal_address",
            "data": "",
        },
        "EU CT Number": {"document": "_ema_identifier", "data": ""},
        "FDA IND Number": {"document": "_fda_ind_identifier", "data": ""},
        "IDE Number": {"document": "_fda_ide_identifier", "data": ""},
        "jRCT Number": {"document": "_jrct_identifier", "data": ""},
        "NCT Number": {"document": "_nct_identifier", "data": ""},
        "NMPA IND Number": {"document": "_nmpa_identifier", "data": ""},
        "WHO-UTN Number": {"document": "_who_identifier", "data": ""},
        "Other Regulatory or Clinical Trial Identifier": {
            "document": "_other_identifiers",
            "data": "",
        },
        "Sponsor Approval Date": {"document": "_sponsor_approval_date", "data": ""},
        "State location where sponsor approval information can be found": {
            "document": "_sponsor_approval_location",
            "data": "",
        },
        "Sponsor Signatory": {
            "document": "_not_supported",
            "data": "",
        },
        "Sponsor Signatory Location": {
            "document": "_not_supported",
            "data": "",
        },
        "Medical Expert Contact Info": {
            "document": "_medical_expert_contact_info",
            "data": "",
        },
        "Medical Expert Contact Info Location": {
            "document": "_medical_export_contact_info_location",
            "data": "",
        },
        # Amendments
        "Current Amendment Status": {
            "document": "_current_amendment_status",
            "data": "_current_amendment_status_data",
        },
        "Current Amendment Enrollment Unit": {"document": "_not_defined", "data": ""},
        "Current Amendment Enrollment": {"document": "_not_defined", "data": ""},
        "Amendment Scope Enrollment Description": {
            "document": "_not_defined",
            "data": "",
        },
        "Primary Reason for Amendment": {"document": "_primary_reason", "data": ""},
        "Primary Reason Other": {"document": "_primary_reason_other", "data": ""},
        "Secondary Reason for Amendment": {"document": "_secondary_reason", "data": ""},
        "Secondary Reason Other": {"document": "_secondary_reason_other", "data": ""},
        "Amendment Summary": {"document": "_amendment_summary", "data": ""},
        "Current Amendment Approximate Value Enrolled Heading": {
            "document": "_not_supported",
            "data": "",
        },
        "Current Amendment Approximate Value Enrolled": {
            "document": "_not_supported",
            "data": "",
        },
        "Current Amendment Scope Enrollment Definition": {
            "document": "_not_supported",
            "data": "",
        },
        "Substantial Impact Safety": {
            "document": "_substantial_impact_safety",
            "data": "",
        },
        "Substantial Impact Safety Explanation": {
            "document": "_explain_substantial_impact_safety",
            "data": "",
        },
        "Substantial Impact Data": {"document": "_substantial_impact_data", "data": ""},
        "Substantial Impact Data Explanation": {
            "document": "_explain_substantial_impact_data",
            "data": "",
        },
        "Overview of Changes in the Current Amendment": {
            "document": "_overview_of_changes_in_the_current_amendment",
            "data": "_overview_of_changes_in_the_current_amendment_data",
        },  # Check this one
        "Description of Change": {
            "document": "_description_of_change",
            "data": "_description_of_change_data",
        },
        "Brief Rationale for Change": {
            "document": "_brief_rationale_for_change",
            "data": "_brief_rationale_for_change_data",
        },
        "Amendment Details": {"document": "_not_defined", "data": ""},  # Check this one
        "Section Number and Name": {
            "document": "_section_and_name",
            "data": "_section_and_name_data",
        },
    }

    def __init__(self, wrapper: Wrapper):
        self._wrapper: Wrapper = wrapper
        self._study = self._wrapper.study
        self._study_version = self._study.first_version()
        self._document = self._study.document_by_template_name("M11")
        self._document_version = self._document.versions[0]

    def get(self, name: str, data: bool = False) -> str | None:
        if name in self.ELEMENT_METHODS:
            if data and self.ELEMENT_METHODS[name]["data"]:
                method = self.ELEMENT_METHODS[name]["data"]
            else:
                method = self.ELEMENT_METHODS[name]["document"]
            value = getattr(self, method)()
            return value
        else:
            return None

    # Methods must return a string

    # Title Page
    def _confidentiality_statement(self) -> str:
        return self._study_version.confidentiality_statement()

    def _full_title(self) -> str:
        return self._study_version.official_title_text()

    def _trial_acronym(self) -> str:
        return self._study_version.acronym_text()

    def _protocol_identifier(self) -> str:
        return self._study_version.sponsor_identifier_text()

    def _original_protocol_indicator(self) -> str:
        return "Yes" if self._study_version.original_version() else "No"

    def _original_protocol(self) -> str:
        return "True" if self._original_protocol_indicator() == "Yes" else "False"

    def _version_number(self) -> str:
        return self._study_version.versionIdentifier

    def _version_date(self) -> str:
        date_str = self._document_version.approval_date_text()
        return date_str if date_str else ""

    def _amendment_identifier(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.number if amendment else "Not Applicable"

    def _amendment_scope(self) -> str:
        amendment = self._study_version.first_amendment()
        if amendment:
            scope: GeographicScope
            if len(amendment.geographicScopes) == 1:
                scope = amendment.geographicScopes[0]
                return "Global" if scope.type.code == "C68846" else "Not Global"
            else:
                return f"Not Global: {self._country_identifiers()}{self._region_identifiers()}{self._site_identifiers()}"
        return "Not Applicable"

    def _country_identifiers(self) -> str:
        return self._country_region_identifiers("C25464")

    def _region_identifiers(self) -> str:
        return self._country_region_identifiers("C41129")

    def _site_identifiers(self) -> str:
        amendment = self._study_version.first_amendment()
        if amendment:
            return amendment.site_identifier_scopes_as_text()
        return ""

    def _country_region_identifiers(self, filter_code: str) -> str:
        scopes = []
        amendment = self._study_version.first_amendment()
        if amendment:
            scope: GeographicScope
            for scope in amendment.geographicScopes:
                if scope.type.code == filter_code:
                    scopes.append(scope.code.standardCode.decode)
            return (", ").join(scopes) if scopes else "Not Applicable"
        return ""

    def _trial_phase(self) -> str:
        return self._study_version.phases()

    def _trial_short_title(self) -> str:
        return self._study_version.short_title_text()

    def _sponsor_name(self) -> str:
        return self._study_version.sponsor_label_name()

    def _sponsor_legal_address(self) -> str:
        return self._study_version.sponsor_address()

    def _co_sponsor_name(self) -> str:
        return self._study_version.co_sponsor_label_name()

    def _co_sponsor_legal_address(self) -> str:
        return self._study_version.co_sponsor_address()

    def _local_sponsor_name(self) -> str:
        return self._study_version.local_sponsor_label_name()

    def _local_sponsor_legal_address(self) -> str:
        return self._study_version.local_sponsor_address()

    def _device_manufacturer_name(self) -> str:
        return self._study_version.device_manufacturer_label_name()

    def _device_manufacturer_legal_address(self) -> str:
        return self._study_version.device_manufacturer_address()

    def _ema_identifier(self) -> str:
        identifier = self._study_version.ema_identifier()
        return identifier.text if identifier else ""

    def _fda_ind_identifier(self) -> str:
        identifier = self._study_version.fda_ind_identifier()
        return identifier.text if identifier else ""

    def _fda_ide_identifier(self) -> str:
        identifier = self._study_version.fda_ide_identifier()
        return identifier.text if identifier else ""

    def _nct_identifier(self) -> str:
        identifier = self._study_version.nct_identifier()
        return identifier.text if identifier else ""

    def _jrct_identifier(self) -> str:
        identifier = self._study_version.jrct_identifier()
        return identifier.text if identifier else ""

    def _who_identifier(self) -> str:
        identifier = self._study_version.who_identifier()
        return identifier.text if identifier else ""

    def _nmpa_identifier(self) -> str:
        identifier = self._study_version.nmpa_identifier()
        return identifier.text if identifier else ""

    def _other_identifiers(self) -> str:
        return ""

    def _sponsor_approval(self) -> str:
        date_str = self._study_version.approval_date_text()
        return date_str if date_str else self._study_version.sponsor_approval_location()

    def _sponsor_approval_date(self) -> str:
        date_str = self._study_version.approval_date_text()
        return date_str if date_str else ""

    def _sponsor_approval_location(self) -> str:
        return self._study_version.sponsor_approval_location()

    # Amendment Details
    def _current_amendment_status(self) -> str:
        amendment_count = len(self._study_version.amendments)
        if amendment_count == 0:
            return "This protocol has not been amended."
        elif amendment_count == 1:
            return "This is the first protocol amendment."
        else:
            return (
                "<p>This protocol has been amended previously. Details of prior amendments are presented in Section 12.3 Prior Protocol Amendment(s).</p>"
                "<p><strong>Current Amendment</strong></p>"
                "<p>The table below describes the current amendment.</p>"
            )

    def _current_amendment_status_data(self) -> str:
        amendment_count = len(self._study_version.amendments)
        if amendment_count == 0:
            return "Original Protocol"
        elif amendment_count == 1:
            return "First Amendment"
        else:
            return "Multiple Amendments"

    def _primary_reason(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.primary_reason_as_text() if amendment else ""

    def _primary_reason_other(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.primary_other_reason_as_text() if amendment else ""

    def _secondary_reason(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.secondary_reason_as_text() if amendment else ""

    def _secondary_reason_other(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.secondary_other_reason_as_text() if amendment else ""

    def _amendment_summary(self) -> str:
        amendment = self._study_version.first_amendment()
        return amendment.summary if amendment else ""

    def _substantial_impact_safety(self) -> str:
        return self._substantial_impact(["C215665", "C215666"])

    def _explain_substantial_impact_safety(self) -> str:
        return self._substantial_impact_text(["C215665", "C215666"])

    def _substantial_impact_data(self) -> str:
        return self._substantial_impact(["C215667", "C215668"])

    def _explain_substantial_impact_data(self) -> str:
        return self._substantial_impact_text(["C215667", "C215668"])

    def _substantial_impact(self, codes: list[str]) -> str:
        amendment = self._study_version.first_amendment()
        if amendment:
            for impact in amendment.impacts:
                if impact.type.code in codes and impact.isSubstantial:
                    return "Yes"
        return "No"

    def _substantial_impact_text(self, codes: list[str]) -> str:
        result = ""
        amendment = self._study_version.first_amendment()
        if amendment:
            for impact in amendment.impacts:
                if impact.type.code in codes and impact.isSubstantial:
                    result += impact.text
        return result

    def _description_of_change(self) -> str:
        text = ""
        amendment = self._study_version.first_amendment()
        if amendment:
            for index, change in enumerate(amendment.changes):
                text += f"{index + 1}: {change.summary}<br/>"
        return text

    def _description_of_change_data(self) -> list[str]:
        amendment = self._study_version.first_amendment()
        return [x.summary for x in amendment.changes] if amendment else []

    def _brief_rationale_for_change(self) -> str:
        text = ""
        amendment = self._study_version.first_amendment()
        for index, change in enumerate(amendment.changes):
            text += f"{index + 1}: {change.rationale}<br/>"
        return text

    def _brief_rationale_for_change_data(self) -> list[str]:
        amendment = self._study_version.first_amendment()
        return [x.rationale for x in amendment.changes] if amendment else []

    def _section_and_name(self) -> str:
        text = ""
        amendment = self._study_version.first_amendment()
        for index, change in enumerate(amendment.changes):
            text += f"{index + 1}: "
            text += f"{('<br/>- ').join([f'{x.sectionNumber}, {x.sectionTitle}' for x in change.changedSections])}"
            text += "<br/>"
        return text

    def _section_and_name_data(self) -> list[list[dict]]:
        result = []
        amendment = self._study_version.first_amendment()
        if amendment:
            for change in amendment.changes:
                result.append(
                    [
                        {
                            "section_number": x.sectionNumber,
                            "section_title": x.sectionTitle,
                        }
                        for x in change.changedSections
                    ]
                )
        return result

    def _overview_of_changes_in_the_current_amendment(self) -> str:
        text = ""
        amendment = self._study_version.first_amendment()
        if amendment:
            text += '<table class="ich-m11-table">'
            text += "<tr>"
            text += "    <th>Description of Change</th>"
            text += "    <th>Brief Rationale for Change</th>"
            text += "    <th>Section # and Name</th>"
            text += "</tr>"

            for change in amendment.changes:
                sections = ("<br/>").join(
                    [
                        f"{x.sectionNumber}, {x.sectionTitle}"
                        for x in change.changedSections
                    ]
                )
                text += "<tr>"
                text += f"<td><p>{change.summary}</p></td>"
                text += f'<td><p">{change.rationale}</p></td>'
                text += f'<td><p">{sections}</p></td>'
                text += "</tr>"
            text += "</table>"
        return text

    def _overview_of_changes_in_the_current_amendment_data(self) -> list[dict]:
        result = []
        amendment = self._study_version.first_amendment()
        if amendment:
            for change in amendment.changes:
                result.append(
                    {
                        "summary": change.summary,
                        "rationale": change.rationale,
                        "sections": [
                            {
                                "section_number": x.sectionNumber,
                                "section_title": x.sectionTitle,
                            }
                            for x in change.changedSections
                        ],
                    }
                )
        return result

    def _medical_expert_contact_info(self) -> str:
        ap = self._study_version.medical_expert()
        return ap.name if ap else ""

    def _medical_export_contact_info_location(self) -> str:
        value = self._study_version.medical_expert_contact_details_location()
        return value if value else ""

    # Generic
    def _not_defined(self) -> str:
        return ""

    def _not_supported(self) -> str:
        return "Not supported"
