import re
from raw_docx.raw_docx import RawDocx, RawListItem, RawList, RawSection
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_m11.utility.claude import Claude


class InclusionExclusion:
    MODULE = "usdm4_m11.import_.inclusion_exclusion.InclusionExclusion"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False):
        self._errors = errors
        self._raw_docx = raw_docx
        self._use_ai = use_ai
        # self._use_ai = False
        self._ai = Claude(self._errors) if use_ai else None

    def process(self) -> dict:
        try:
            result = {"inclusion": [], "exclusion": []}
            result["inclusion"] = [x["text"] for x in self._process_section("5.2")]
            result["exclusion"] = [x["text"] for x in self._process_section("5.3")]
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Failed to decode the Inclusion/Exclusion criteria in the document",
                e,
                location,
            )
            return None

    def _process_section(self, section_number: str) -> list:
        section = self._raw_docx.target_document.section_by_number(section_number)
        if section:
            if self._use_ai:
                # print(f"AI extracting IE")
                ai_result = self._process_ai(section)
                if ai_result is None:
                    ai_result = self._process_simple(section)
                return ai_result if ai_result else []
            else:
                simple_result = self._process_simple(section)
                return simple_result if simple_result else []
        else:
            self._errors.error(
                f"Failed to find section {section_number} in M11 document"
            )
        return []

    def _process_ai(self, section: RawSection) -> list:
        try:
            text = section.to_html()
            title = (
                "inclusion criteria"
                if section.number == "5.2"
                else "exclusion critieria"
            )
            prompt = f"""
                You are an expert in reading clinical trial protocols. Your task is to extract all {title} from the provided HTML content.

                ## Instructions

                1. Identify and extract each individual {title} from the text
                2. Criteria may appear as:
                - Numbered or bulleted lists
                - Paragraphs
                - Items under category headings (e.g., "General {title}", "Indication specific {title}")
                3. Extract ALL criteria regardless of which category or section they appear in
                4. Do NOT include category headings as criteria - only extract the actual criterion text
                5. No text must be lost
                6. The case of all text must be preserved

                ## Handling Hierarchical Criteria

                Some criteria contain nested sub-lists that provide additional detail, qualifications, or breakdowns. When you encounter a criterion with sub-items:

                1. Treat the entire criterion (parent text AND all nested sub-items) as a SINGLE criterion
                2. Preserve the complete text including all sub-items in the "text" field
                3. Maintain the original formatting and structure (line breaks, indentation, sub-numbering)
                4. Do NOT split hierarchical criteria into separate entries

                ## Identifier Rules

                - If the criterion has an explicit identifier in the source text (e.g., "E1", "EC-01", "1.", "a)"), extract and use that identifier
                - If no identifier is present, assign sequential integer identifiers starting from 1 (i.e., "1", "2", "3", etc.)
                - Maintain consistent identifier format throughout the response

                ## Output Format

                Return a JSON array of objects. Each object must contain:
                - "identifier": The criterion identifier (string)
                - "text": The criterion text with original HTML formatting preserved (string)

                Example output structure:
                [
                    {{
                        "identifier": "1",
                        "text": "Subjects under 18 years of age"
                    }},
                    {{
                        "identifier": "2", 
                        "text": "Subjects with known hypersensitivity to <b>study drug</b> or excipients"
                    }}
                ]

                ## Edge Cases

                - If no exclusion criteria can be found, return an empty array: []
                - Preserve any HTML formatting (e.g., <b>, <i>, <sub>, <sup>) within the criterion text
                - Do not include introductory text such as "Subjects will be excluded if..." as a criterion

                ## Content to Process

                {text}
            """
            # print(f"PROMPT: {prompt}")
            null_result = []
            prompt_result = self._ai.streaming_prompt(prompt)
            # print(f"PROMPT RESULT: {prompt_result}")
            result = self._ai.extract_json(prompt_result, dict=False)
            # print(f"IE RESULT: {result}")
            result = result if result else null_result
            self._errors.info(
                f"Found {title}: {result}",
                KlassMethodLocation(self.MODULE, "_process_ai"),
            )
            return result
        except Exception as e:
            self._errors.exception(
                "Exception detected using IE AI processing",
                e,
                KlassMethodLocation(self.MODULE, "_process_ai"),
            )
            return None

    def _process_simple(self, section: RawSection) -> list:
        try:
            lists = section.lists()
            if lists:
                return self._process_list(lists[0])
            else:
                # Fallback: extract numbered paragraphs (e.g., Japanese style)
                result = self._process_numbered_paragraphs(section)
                if result:
                    return result
                self._errors.error(
                    f"Failed to find a list or numbered paragraphs in section {section.number} in M11 document"
                )
                return []
        except Exception as e:
            self._errors.exception(
                "Exception detected using IE simple processing",
                e,
                KlassMethodLocation(self.MODULE, "_process_simple"),
            )
            return None

    def _process_list(self, the_list: list) -> list:
        index = 1
        result = []
        for item in the_list.items:
            if isinstance(item, RawListItem):
                result.append({"identifier": index, "text": item.to_html()})
                index += 1
            elif isinstance(item, RawList):
                if result:
                    last = result[-1]
                    last["text"] += item.to_html()
                else:
                    self._errors.error(
                        f"RawList item detected with no previous RawListItem entries, type: '{type(item)}', text: '{item.to_text()}'"
                    )
            else:
                self._errors.error(
                    f"Neither a RawList or RawListItem detected, type: '{type(item)}', text: '{item.to_text()}'"
                )
        return result

    def _process_numbered_paragraphs(self, section: RawSection) -> list:
        """
        Extract criteria from numbered paragraphs (used when no Word lists are present).
        Handles patterns like "1　Text" or "1 Text" where numbers may be followed by
        full-width or regular spaces.
        """
        # Pattern matches number at start followed by space (regular or full-width)
        number_pattern = re.compile(r"^(\d+)[\s\u3000]+(.*)$")

        paragraphs = section.paragraphs()
        result = []

        for para in paragraphs:
            text = para.to_text().strip()
            if not text:
                continue

            match = number_pattern.match(text)
            if match:
                # New numbered criterion
                identifier = match.group(1)
                result.append({"identifier": int(identifier), "text": para.to_html()})
            elif result:
                # Non-numbered paragraph - append to previous criterion as continuation
                last = result[-1]
                last["text"] += para.to_html()
            # Skip non-numbered paragraphs before the first criterion (intro text)

        return result
