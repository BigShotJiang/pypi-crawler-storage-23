import re
from raw_docx.raw_docx import (
    RawDocx,
    RawTable,
    RawSection,
    RawParagraph,
    RawTableRow,
    RawTableCell,
)
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_m11.import_.extract.utility import (
    table_get_row,
    text_within,
)
from usdm4_m11.utility.claude import Claude


class Amendments:
    MODULE = "usdm4_m11.import_.amendments.Amendments"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False):
        self._errors = errors
        self._raw_docx = raw_docx
        self._use_ai = use_ai
        self._ai = Claude(self._errors) if use_ai else None

    def process(self, base_info: dict):
        try:
            result = None
            if base_info["identifier"].upper() == "NOT APPLICABLE":
                return result
            section: RawSection
            if section := self._find_amendment_section():
                amend_item, amend_index = section.find_first_at_start(
                    "Amendment Details"
                )
                table, table_index = self._amendment_table(section)
                if amend_item and table:
                    result = {}
                    result["amendment_details"] = section.to_html_between(
                        amend_index, table_index
                    )
                if table:
                    result = result if result else {}
                    result["identifier"] = base_info["identifier"]
                    result["scope"] = self._scopes(base_info["scope"])
                    result["enrollment"] = self._get_enrollment(table)
                    result["reasons"] = self._reasons(table)
                    result["summary"] = self._summary(table)
                    result["impact"] = self._safety_and_reliability_impact(table)
                    result["changes"] = self._changes(section)
                else:
                    self._errors.warning(
                        "Failed to find amendments table in section",
                        KlassMethodLocation(self.MODULE, "process"),
                    )
            else:
                pass
            self._errors.info(
                f"Amendment information {result}",
                KlassMethodLocation(self.MODULE, "process"),
            )
            return result
        except Exception as e:
            self._errors.exception(
                "Failed to extract amendment information",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return None

    def _find_amendment_section(
        self,
    ) -> RawSection | None:
        for index in range(10):
            section: RawSection = self._raw_docx.target_document.section_by_ordinal(
                index
            )
            if section:
                para, _ = section.find_first_at_start("Amendment Details")
                if para:
                    self._errors.info(
                        f"Found amendment section at index {index}",
                        KlassMethodLocation(self.MODULE, "_find_amendment_section"),
                    )
                    return section
        self._errors.warning(
            "Failed to find amendment section",
            KlassMethodLocation(self.MODULE, "_find_amendment_section"),
        )
        return None

    def _scopes(self, scope: str) -> dict:
        result = {
            "global": True,
            "countries": [],
            "regions": [],
            "sites": [],
            "unknown": [],
        }
        text: str = scope.strip()
        text_upper = text.upper()
        self._errors.info(f"Amendment scopes text: {text}")
        if text_upper.startswith("NOT APPLICABLE") or text_upper.startswith("GLOBAL"):
            # Global
            pass
        elif text_upper.startswith("NOT GLOBAL") or text_upper.startswith("LOCAL"):
            result["global"] = False
            identifiers = text[10:] if text_upper.startswith("NOT GLOBAL") else text[5:]
            result["unknown"] = re.split(r"[;,\s]+", identifiers)
        else:
            result["global"] = False
            identifiers = text
            result["unknown"] = re.split(r"[;,\s]+", identifiers)
        self._errors.info(f"Amendment scopes extracted: {result}")
        return result

    def _safety_and_reliability_impact(self, table: RawTable) -> dict:
        try:
            return {
                "safety_and_rights": self._safety_impact(table),
                "reliability_and_robustness": self._reliability_impact(table),
            }
        except Exception as e:
            location = KlassMethodLocation(
                self.MODULE, "_safety_and_reliability_impact"
            )
            self._errors.exception(
                "Failed to decode the safety and reliability impact", e, location
            )
            return None

    def _safety_impact(self, table: RawTable) -> dict:
        try:
            impact = self._impact(
                table,
                "Is this amendment likely to have a substantial impact on the safety",
            )
            result = {"safety": impact, "rights": impact}
            self._errors.info(f"Safety impact: {result}")
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_safety impact")
            self._errors.exception("Failed to decode the safety impact", e, location)
            return None

    def _reliability_impact(self, table: RawTable) -> dict:
        try:
            impact = self._impact(
                table,
                "Is this amendment likely to have a substantial impact on the reliability",
            )
            result = {"reliability": impact, "robustness": impact}
            self._errors.info(f"Reliability impact: {result}")
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_reliability_impact")
            self._errors.exception(
                "Failed to decode the reliability impact", e, location
            )
            return None

    def _summary(self, table: RawTable) -> dict:
        try:
            return table_get_row(table, "Amendment Summary")
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_summary")
            self._errors.exception(
                "Failed to decode the amendment summary", e, location
            )
            return None

    def _impact(self, table: RawTable, text: str) -> dict:
        try:
            impact = False
            reason = ""
            row: RawTableRow
            row, _ = table.find_row(text)
            if row:
                cell: RawTableCell = row.cells[1]
                impact = cell.text().upper().startswith("YES")
                if impact:
                    reason = cell.text()[3:].strip()  # Remove the "yes"
            return {"substantial": impact, "reason": reason}
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_impact")
            self._errors.exception("Failed to decode the impact", e, location)
            return None

    def _reasons(self, table: RawTable) -> dict | None:
        try:
            row: RawTableRow
            row, _ = table.find_row("Reason(s) for Amendment:")
            if row:
                result = {
                    "primary": row.find_cell("primary").text(),
                    "secondary": row.find_cell("secondary").text(),
                }
                self._errors.info(
                    f"Amendment reasons found {result}",
                    KlassMethodLocation(self.MODULE, "_reasons"),
                )
                return result
            else:
                return None
        except Exception:
            location = KlassMethodLocation(self.MODULE, "_reasons")
            self._errors.exception("Failed to decode the amendment reasons", location)
            return None

    def _changes(self, section: RawSection) -> list[dict] | None:
        try:
            results = []
            table = self._changes_table(section)
            if table:
                for index, row in enumerate(table.rows):
                    if index == 0:
                        continue
                    results.append(
                        {
                            "description": row.cells[0].text(),
                            "rationale": row.cells[1].text(),
                            "section": row.cells[2].text(),
                        }
                    )
            self._errors.info(f"Amendment changes: {results}")
            return results
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_changes")
            self._errors.exception(
                "Failed to decode the amendment changes", e, location
            )
            return None

    def _amendment_table(self, section: RawSection):
        try:
            for index, item in enumerate(section.items):
                if isinstance(item, RawParagraph):
                    if text_within(
                        "The table below describes the current amendment", item.text
                    ):
                        table = section.next_table(index + 1)
                        self._errors.info(
                            f"Amendment table {'' if table else 'not '} found"
                        )
                        self._errors.info(
                            "Amendment table found",
                            KlassMethodLocation(self.MODULE, "_amendment_table"),
                        )
                        return table, index
            self._errors.warning(
                "Failed to find amendment table",
                KlassMethodLocation(self.MODULE, "_amendment_table"),
            )
            return None, -1
        except Exception as e:
            self._errors.exception(
                "Failed to find the amendment table",
                e,
                KlassMethodLocation(self.MODULE, "_amendment_table"),
            )
            return None, -1

    def _changes_table(self, section: RawSection) -> RawTable | None:
        try:
            for index, item in enumerate(section.items):
                if isinstance(item, RawParagraph):
                    if text_within(
                        "Overview of Changes in the Current Amendment", item.text
                    ):
                        table = section.next_table(index + 1)
                        self._errors.info(
                            "Amendment changes table found",
                            KlassMethodLocation(self.MODULE, "_changes_table"),
                        )
                        return table
            self._errors.warning(
                "Failed to find amendment changes table",
                KlassMethodLocation(self.MODULE, "_changes_table"),
            )
            return None
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_changes_table")
            self._errors.exception("Failed to find the changes table", e, location)
            return None

    def _get_enrollment(self, table: RawTable) -> dict:
        text = table_get_row(table, "Enrolled at time ")
        return (
            self._get_enrollment_ai(text)
            if self._use_ai
            else self._get_enrollment_simple(text)
        )

    def _get_enrollment_ai(self, text: str) -> dict:
        try:
            prompt = f"""
    Extract enrollment/recruitment scope information from the provided text. Return a JSON object with the following fields.

    ## Fields to Extract

    ### keyword
    - Look for one of these keywords at or near the start of the string: "Globally", "Locally", or "Cohort"
    - Return the exact keyword found
    - If no keyword is found, return null

    ### value
    - Extract the numeric value stated in the text
    - Return as a number (integer or decimal as appropriate)
    - If no numeric value is found, return null

    ### unit
    - If the value is expressed as a percentage (e.g., "50%", "50 percent"), return "percent"
    - If the value is an absolute number (e.g., "100", "100 subjects"), return "absolute"
    - If no value is found, return null

    ### regions
    - Extract any geographic locations listed in the text
    - May include:
    - Countries (e.g., "United States", "Germany", "Japan")
    - Geographic regions (e.g., "Europe", "Asia", "North America", "Latin America")
    - Sub-regions (e.g., "Western Europe", "Southeast Asia", "Scandinavia")
    - Return as an array of strings, preserving the names as stated
    - Typically appears with "Locally" keyword
    - If no regions are specified, return an empty array

    ## Output Format

    Return valid JSON only, no additional text.

    {{
    "keyword": <string or null>,
    "value": <number or null>,
    "unit": <"percent" | "absolute" | null>,
    "regions": []
    }}

    ## Examples

    Input: "Globally 500 subjects"
    Output: {{"keyword": "Globally", "value": 500, "unit": "absolute", "regions": []}}

    Input: "Locally 30% in United States, Germany, Japan"
    Output: {{"keyword": "Locally", "value": 30, "unit": "percent", "regions": ["United States", "Germany", "Japan"]}}

    Input: "Locally 40% in Europe"
    Output: {{"keyword": "Locally", "value": 40, "unit": "percent", "regions": ["Europe"]}}

    Input: "Locally 250 subjects in North America, Western Europe"
    Output: {{"keyword": "Locally", "value": 250, "unit": "absolute", "regions": ["North America", "Western Europe"]}}

    Input: "Cohort 150"
    Output: {{"keyword": "Cohort", "value": 150, "unit": "absolute", "regions": []}}

    Input: "Locally 200 subjects in Asia, Australia"
    Output: {{"keyword": "Locally", "value": 200, "unit": "absolute", "regions": ["Asia", "Australia"]}}

                {text}
            """
            prompt_result = self._ai.prompt(prompt)
            result = self._ai.extract_json(prompt_result)
            result = result if result else self._enrollment_null()
            self._errors.info(
                f"Found enrollment: {result}",
                KlassMethodLocation(self.MODULE, "_get_enrollment_ai"),
            )
            return result
        except Exception as e:
            self._errors.exception(
                "Failed to find the enrollment, return default result",
                e,
                KlassMethodLocation(self.MODULE, "get_enrollment_ai"),
            )
            return self._enrollment_null()

    def _get_enrollment_simple(self, text: str) -> dict:
        try:
            number = re.findall("[0-9]+", text)
            value = int(number[0]) if number else 0
            unit = "%" if "%" in text else "absolute"
            result = {
                "keyword": "Globally",
                "value": value,
                "unit": unit,
                "regions": [],
            }
            self._errors.info(
                f"Found enrollment: {result}",
                KlassMethodLocation(self.MODULE, "_get_enrollment_simple"),
            )
            return result
        except Exception as e:
            self._errors.exception(
                "Failed to find the enrollment, return default result",
                e,
                KlassMethodLocation(self.MODULE, "get_enrollment_simple"),
            )
            return self._enrollment_null()

    def _enrollment_null(self) -> dict:
        return {
            "keyword": "Globally",
            "value": 0,
            "unit": "absolute",
            "regions": [],
        }
