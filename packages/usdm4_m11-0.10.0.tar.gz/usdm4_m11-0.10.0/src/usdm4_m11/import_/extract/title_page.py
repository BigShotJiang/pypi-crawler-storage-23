import re
from raw_docx.raw_docx import RawDocx, RawTable, RawSection
from usdm4_m11.import_.extract.utility import (
    table_get_row,
    section_get_para,
    section_get_text_between,
)
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_m11.utility.claude import Claude


class TitlePage:
    MODULE = "usdm4_m11.import_.title_page.TitlePage"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False):
        self._raw_docx = raw_docx
        self._sections = self._raw_docx.target_document.sections
        self._errors = errors
        self._use_ai = use_ai
        self._ai = Claude(self._errors) if use_ai else None

    def process(self):
        try:
            if table := self._title_table():
                table.replace_class("raw-docx-table", "ich-m11-title-page-table")
                return self._process_item(table)
            elif section := self._title_section():
                return self._process_item(section)
            else:
                self._errors.error(
                    "Failed to find the M11 title page content in the document",
                    KlassMethodLocation(self.MODULE, "process"),
                )
                return None
        except Exception as e:
            self._errors.exception(
                "Exception raised during title page processing",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return None

    def _process_item(self, item: RawTable | RawSection):
        names_and_addresses = self._extract_names_and_addresss(item)
        acronym = self._get_field_value(item, "Acronym")
        identifier = self._get_field_value(item, "Sponsor Protocol Identifier")
        compound_code = self._get_field_value(item, "Compound Code")
        reg_identifiers = self._extract_reg_identifiers(item)
        medical_expert_details = self._extract_medical_expert_details(item)
        result = {
            "identification": {
                "titles": {
                    "official": self._get_field_value(item, "Full Title"),
                    "acronym": acronym,
                    "brief": self._get_field_value(item, "Short Title"),
                },
                "identifiers": [
                    {
                        "identifier": identifier,
                        "scope": {
                            "non_standard": {
                                "type": "pharma",
                                "role": "sponsor",
                                "description": "The sponsor organization",
                                "label": names_and_addresses["sponsor"]["name"]
                                if names_and_addresses["sponsor"]
                                else "Not found",
                                "identifier": "Not known",
                                "identifierScheme": "Not known",
                                "legalAddress": names_and_addresses["sponsor"][
                                    "address"
                                ]
                                if names_and_addresses["sponsor"]
                                else None,
                            }
                        },
                    }
                ],
                "roles": {
                    "co_sponsor": names_and_addresses["co_sponsor"],
                    "local_sponsor": names_and_addresses["local_sponsor"],
                    "device_manufacturer": names_and_addresses["device"],
                },
                "other": {
                    "sponsor_signatory": self._get_field_value(
                        item, "Sponsor Signatory"
                    ),
                    "medical_expert": medical_expert_details,
                    "compound_codes": compound_code,
                    "compound_names": self._get_field_value(item, "Compound Name"),
                },
            },
            "amendments_summary": {
                "identifier": self._get_field_value(item, "Amendment Identifier"),
                "scope": self._get_field_value(item, "Amendment Scope"),
                # "amendment_details": self._get_field_value(item, "Amendment Details"),
            },
            "study_design": {
                "label": "Study Design 1",
                "rationale": "Not set",
                "trial_phase": self._get_field_value(item, "Trial Phase"),
            },
            "study": {
                "sponsor_approval_date": self._get_sponsor_approval_date(item),
                "version_date": self._get_protocol_date(item),
                "version": self._get_field_value(item, "Version Number"),
                "rationale": "Not set",
                "name": {
                    "acronym": acronym,
                    "identifier": identifier,
                    "compound_code": compound_code,
                },
                "confidentiality": self._get_field_value(
                    item, "Sponsor Confidentiality Statement"
                ),
                "original_protocol": self._get_field_value(item, "Original Protocol"),
            },
        }
        self._set_regulatory_identifiers(result, reg_identifiers)
        self._errors.info(f"Amendment info: {result['amendments_summary']}")
        return result

    def _set_regulatory_identifiers(self, result, reg_identifiers) -> None:
        extracted_reg_identifiers = self._get_regulatory_identifiers(reg_identifiers)
        for id_type, id_info in extracted_reg_identifiers.items():
            if len(id_info) > 0:
                identifier = {
                    "identifier": id_info[0],  # Only take one identifier of each type!
                    "scope": {
                        "standard": id_type,
                    },
                }
                result["identification"]["identifiers"].append(identifier)
        return result

    def _get_field_value(
        self,
        item: RawTable | RawSection,
        text: str,
        start_text: str = None,
        end_text: str = None,
    ) -> str:
        result = (
            table_get_row(item, text)
            if isinstance(item, RawTable)
            else section_get_text_between(item, start_text, end_text)
            if not text
            else section_get_para(item, text)
        )
        self._errors.info(f"Extracting title page field '{text}' -> '{result}'")
        return result

    def _get_sponsor_approval_date(self, item: RawTable | RawSection) -> str:
        return self._get_date(item, "Sponsor Approval")

    def _get_protocol_date(self, item: RawTable | RawSection) -> str:
        return self._get_date(item, "Version Date")

    def _get_date(self, item: RawSection | RawTable, text) -> str:
        try:
            date_text = (
                table_get_row(item, text)
                if isinstance(item, RawTable)
                else section_get_para(item, text)
            )
            if date_text:
                return date_text.strip()
            else:
                return None
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_get_date")
            self._errors.exception(
                f"Exception raised during date processing for '{text}'", e, location
            )
            return None

    def _get_regulatory_identifiers(self, text: str) -> dict:
        return (
            self._get_regulatory_identifiers_ai(text)
            if self._use_ai
            else self._get_regulatory_identifiers_simple(text)
        )

    def _get_regulatory_identifiers_ai(self, text: str) -> dict:
        prompt = f"""
            Extract clinical trial regulatory identifiers from the provided text. Return a JSON object with the following fields, each containing an array of strings.

## Identifier Types

### NCT (ClinicalTrials.gov)
- Pattern: "NCT" followed immediately by exactly 8 digits
- Example: "NCT12345678"
- Field: "nct"

### IND (FDA Investigational New Drug)
- Patterns accepted:
  - "IND" followed immediately by 5 or 6 digits (e.g., "IND12345" or "IND123456")
  - "IND" followed by whitespace then 5 or 6 digits (e.g., "IND 12345", "IND 123456")
  - Context containing "IND" followed by space, colon, or similar separator then 5 or 6 digits
- Normalise output to: "IND " + the 5 or 6 digits found (single space separator)
- Example output: "IND 123456", "IND 12345"
- Field: "fda-ind"

### EMA (European Medicines Agency)
- Patterns:
  - EudraCT format: "YYYY-NNNNNN-NN" (4-digit year, hyphen, 6 digits, hyphen, 2 digits)
  - Marketing authorisation format: "EU/1/YY/NNNNN/NNN" or similar EU/N/NN/NNNNN/NNN patterns
  - Some identifiers have been noted to have an additional hypen and two digits, i.e. "YYYY-NNNNNN-NN-NN" (4-digit year, hyphen, 6 digits, hyphen, 2 digits, hyphen, 2 digits)
- Field: "ema"

### jRCT (Japan Registry of Clinical Trials)
- Pattern: "jRCT" optionally followed by a single letter, then one or more digits
- Examples: "jRCT2031200012", "jRCTs031200012"
- Field: "jrct"

### WHO UTN (Universal Trial Number)
- Pattern: "U" followed by groups of 4 characters separated by hyphens (typically U1111-1111-1111)
- Field: "who"

### Other
- Any other apparent clinical trial registry identifiers not matching the above patterns
- Field: "other"

## Output Format

Return valid JSON only, no additional text. If no identifiers are found for a category, return an empty array for that field.

{{
  "nct": [],
  "fda-ind": [],
  "ema": [],
  "jrct": [],
  "who": [],
  "other": []
}}

            {text}
        """
        null_result = {
            "nct": [],
            "fda-ind": [],
            "ema": [],
            "jrct": [],
            "who": [],
            "other": [],
        }
        prompt_result = self._ai.prompt(prompt)
        result = self._ai.extract_json(prompt_result)
        result = result if result else null_result
        self._errors.info(
            f"Found regulatory identifiers: {result}",
            KlassMethodLocation(self.MODULE, "_get_regulatory_identifiers_ai"),
        )
        return result

    def _get_regulatory_identifiers_simple(self, text: str) -> dict:
        if not text:
            return {
                "nct": [],
                "fda-ind": [],
                "ema": [],
                "jrct": [],
                "who": [],
                "other": [],
            }

        # Pattern for NCT identifiers: NCT followed by exactly 8 digits
        nct_pattern = r"\bNCT\d{8}\b"

        # Multiple patterns for IND identifiers:
        # 1. IND followed directly by 6 digits (original format)
        # 2. IND followed by whitespace then 6 digits
        # 3. Title containing "IND" followed by space/colon then 6 digits
        ind_patterns = [
            r"\bIND\d{6}\b",  # IND123456
            r"\bIND\s+(\d{6})\b",  # IND 123456
            r"IND\s*\w*[\s:]+(\d{6})\b",  # Title with IND: 123456 or IND Number: 123456
        ]

        # Patterns for EMA identifiers:
        # 1. EudraCT format: YYYY-NNNNNN-NN with optional -NN suffix
        # 2. Marketing authorisation format: EU/N/NN/NNNNN/NNN
        ema_patterns = [
            r"\b\d{4}-\d{6}-\d{2}(?:-\d{2})?\b",  # 2024-123456-12 or 2024-123456-12-34
            r"\bEU/\d+/\d{2}/\d{5}/\d{3}\b",  # EU/1/24/12345/123
        ]

        # Pattern for WHO UTN identifiers: U followed by groups of 4 characters separated by hyphens
        who_pattern = r"\bU\d{4}(?:-\d{4})+\b"

        # Pattern for jRCT identifiers: jRCT optionally followed by a single letter, then one or more digits
        jrct_pattern = r"\bjRCT[a-zA-Z]?\d+\b"

        # Find NCT matches
        nct_matches = re.findall(nct_pattern, text, re.IGNORECASE)
        nct_identifiers = [match.upper() for match in nct_matches]

        # Find IND matches using multiple patterns
        ind_identifiers = []

        # Pattern 1: IND followed directly by 6 digits
        direct_matches = re.findall(ind_patterns[0], text, re.IGNORECASE)
        for match in direct_matches:
            ind_identifiers.append(match.upper())

        # Pattern 2: IND followed by whitespace then 6 digits
        spaced_matches = re.findall(ind_patterns[1], text, re.IGNORECASE)
        for match in spaced_matches:
            ind_identifiers.append(match)  # match is just the digits

        # Pattern 3: Title containing "IND" followed by space/colon then 6 digits
        title_matches = re.findall(ind_patterns[2], text, re.IGNORECASE)
        for match in title_matches:
            ind_identifiers.append(match)  # match is just the digits

        # Find EMA matches using multiple patterns
        ema_identifiers = []
        for ema_pattern in ema_patterns:
            ema_matches = re.findall(ema_pattern, text)
            ema_identifiers.extend(ema_matches)
        ema_identifiers = list(dict.fromkeys(ema_identifiers))

        # Find WHO UTN matches
        who_matches = re.findall(who_pattern, text)
        who_identifiers = list(dict.fromkeys(who_matches))

        # Find jRCT matches (case-sensitive to preserve canonical "jRCT" prefix)
        jrct_matches = re.findall(jrct_pattern, text)
        jrct_identifiers = list(dict.fromkeys(jrct_matches))

        # Remove duplicates while preserving order
        nct_identifiers = list(dict.fromkeys(nct_identifiers))
        ind_identifiers = list(dict.fromkeys(ind_identifiers))

        result = {
            "nct": nct_identifiers,
            "fda-ind": ind_identifiers,
            "ema": ema_identifiers,
            "jrct": jrct_identifiers,
            "who": who_identifiers,
            "other": [],
        }

        # Log the results
        location = KlassMethodLocation(
            self.MODULE, "_get_regulatory_identifiers_simple"
        )
        if (
            nct_identifiers
            or ind_identifiers
            or ema_identifiers
            or jrct_identifiers
            or who_identifiers
        ):
            self._errors.info(
                f"Found regulatory identifiers: NCT={nct_identifiers}, IND={ind_identifiers}, EMA={ema_identifiers}, jRCT={jrct_identifiers}, WHO={who_identifiers}",
                location,
            )
        else:
            self._errors.info("No regulatory identifiers found", location)
        return result

    def _get_organization_name(self, text: str) -> str:
        parts = re.split(r"[\n,]", text)
        name = parts[0].strip() if len(parts) > 0 else "Unknown"
        self._errors.info(
            f"Organization name set to '{name}'",
            location=KlassMethodLocation(self.MODULE, "_get_organization_name"),
        )
        return name

    def _get_organization_address(self, text: str) -> dict:
        address = (
            self._get_organization_address_ai(text)
            if self._use_ai
            else self._get_organization_address_simple(text)
        )
        self._errors.info(
            f"Organization address set to '{address}'",
            location=KlassMethodLocation(self.MODULE, "_get_organization_address"),
        )
        return address

    def _get_organization_address_simple(self, text: str) -> dict:
        """Simplified version of _get_organization_name_and_address without using the address service"""
        raw_parts = text.split("\n") if text else []
        params = {
            "lines": [],
            "city": "",
            "district": "",
            "state": "",
            "postalCode": "",
            "country": "",
        }
        parts = []
        for part in raw_parts:
            if not part.upper().startswith(("TEL", "FAX", "PHONE", "EMAIL")):
                parts.append(part)
        if len(parts) > 0:
            params["lines"] = [part.strip() for part in parts[1:]]
            if len(parts) > 2:
                params["country"] = parts[-1].strip()
        self._errors.info(
            f"Address result '{params}'",
            location=KlassMethodLocation(
                self.MODULE, "_get_organization_address_simple"
            ),
        )
        return params

    def _get_organization_address_ai(self, text: str) -> dict:
        prompt = f"""
<task>
Extract a postal/mailing address from the provided text and return it as structured JSON.
</task>

<instructions>
Parse the text to identify address components. The text may be in any language—extract and normalize the address accordingly.

Return a JSON object with these fields in this exact order:
- "lines": Array of street address components (street name, building number, apartment/suite, etc.) as separate strings. Use an empty array [] if none found.
- "city": City or town name. Use "" if not found.
- "district": District, county, or sub-regional division. Use "" if not found.
- "state": State, province, region, or top-level administrative division. Use "" if not found.
- "postalCode": ZIP code, postal code, or postcode. Use "" if not found.
- "country": ISO 3166-1 alpha-2 country code (e.g., "US", "DK", "JP"). Use "" if country cannot be determined.

Guidelines:
- Preserve the original language for city, district, and state names (do not translate)
- If multiple addresses are present, extract only the first complete address
- If no address is found, return the empty structure with all fields as "" or []
- Often the string may contain a company name. Remove the compnay name, eg "Bayer AG, 51368 Leverkusen, Germany", "Bayer AG" is the company (sponsor) name
</instructions>

<examples>
<example>
<input>Please ship to: 123 Main Street, Apt 4B, Springfield, IL 62701, USA</input>
<output>
{{
  "lines": ["123 Main Street", "Apt 4B"],
  "city": "Springfield",
  "district": "",
  "state": "IL",
  "postalCode": "62701",
  "country": "US"
}}
</output>
</example>

<example>
<input>〒100-0001 東京都千代田区千代田1-1</input>
<output>
{{
  "lines": ["千代田1-1"],
  "city": "千代田区",
  "district": "",
  "state": "東京都",
  "postalCode": "100-0001",
  "country": "JP"
}}
</output>
</example>

<example>
<input>The meeting is scheduled for Tuesday at 3pm.</input>
<output>
{{
  "lines": [],
  "city": "",
  "district": "",
  "state": "",
  "postalCode": "",
  "country": ""
}}
</output>
</example>

<example>
<input>Bayer AG, 51368 Leverkusen, Germany</input>
<output>
{{
  "lines": [],
  "city": "Leverkusen",
  "district": "",
  "state": "",
  "postalCode": "51368",
  "country": "Germany"
}}
</output>
</example>

</examples>

<input_text>
{text}
</input_text>

Return only the JSON object with no additional text or explanation.
        """
        null_result = {
            "lines": [],
            "city": "",
            "district": "",
            "state": "",
            "postalCode": "",
            "country": "",
        }
        prompt_result = self._ai.prompt(prompt)
        result = self._ai.extract_json(prompt_result)
        return result if result else null_result

    def _title_table(self):
        section: RawSection
        for section in self._sections:
            for table in section.tables():
                title = table_get_row(table, "Full Title")
                if title:
                    self._errors.info(
                        "Found M11 title page table",
                        location=KlassMethodLocation(self.MODULE, "_title_table"),
                    )
                    section.title = "Title Page"
                    return table
        return None

    def _title_section(self):
        section: RawSection
        for section in self._sections:
            for para in section.paragraphs():
                if para.find_at_start("Full Title"):
                    self._errors.info(
                        "Found M11 title page paragraph",
                        location=KlassMethodLocation(self.MODULE, "_title_para"),
                    )
                    section.title = "Title Page"
                    return section
        return None

    def _extract_reg_identifiers(self, item: RawTable | RawSection) -> str:
        if isinstance(item, RawTable):
            return self._get_field_value(
                item, "Regulatory or Clinical Trial Identifier(s):"
            )
        else:
            return self._get_field_value(
                item,
                None,
                "Regulatory or Clinical Trial Identifier(s):",
                "Sponsor Approval:",
            )

    def _extract_names_and_addresss(self, item: RawTable | RawSection) -> dict:
        """Extract sponsor, co-sponsor, and local sponsor names and addresses."""
        delim_text = [
            "Sponsor Name and Address:",
            "Co-Sponsor Name and Address:",
            "Local Sponsor Name and Address:",
            "Device Manufacturer Name and Address:",
            "Regulatory or Clinical Trial Identifier(s):",
        ]
        result = {
            "sponsor": None,
            "co_sponsor": None,
            "local_sponsor": None,
            "device": None,
        }
        if isinstance(item, RawTable):
            full_text = self._get_field_value(item, delim_text[0])
            full_text += self._get_field_value(item, delim_text[3])
        else:
            full_text = self._get_field_value(item, None, delim_text[0], delim_text[-1])
        self._errors.info(f"Names and addresses text: {full_text}")
        if not full_text:
            self._errors.warning(
                "Failed to find names and addresses text",
                KlassMethodLocation(self.MODULE, "_extract_names_and_addresss"),
            )
            return result
        full_text += f"\n{delim_text[-1]}"

        remaining_text = full_text
        for k, v in result.items():
            for delim in delim_text[1:]:
                if delim in remaining_text:
                    parts = remaining_text.split(delim, 1)
                    result[k] = parts[0]
                    remaining_text = parts[1].strip() if len(parts) > 1 else None
                    break
            self._errors.info(
                f"Parsing names and address, key {k}: interim raw result={result}, remaining={remaining_text}"
            )

        self._errors.info(f"Parsing names and address: raw result={result}")
        for k, v in result.items():
            if v:
                result[k] = {
                    "name": self._get_organization_name(v),
                    "address": self._get_organization_address(v),
                }
        self._errors.info(
            f"Extracted organisation names and adddress: result={result}",
            KlassMethodLocation(self.MODULE, "_extract_names_and_addresss"),
        )
        return result

    def _extract_medical_expert_details(self, item: RawTable | RawSection) -> dict:
        result = {"name": None, "address": None, "reference": None}
        if isinstance(item, RawTable):
            full_text = self._get_field_value(item, "Medical Expert Contact:")
        else:
            full_text = self._get_field_value(
                item, None, "Medical Expert Contact:", "Amendment Details"
            )
        if not full_text:
            self._errors.warning(
                "Failed to find medical expert name and addresse text",
                KlassMethodLocation(self.MODULE, "_extract_names_and_addresss"),
            )
            return result
        self._errors.info(f"Medical expert name and addresse text: {full_text}")
        result = (
            self._get_medical_expert_details_ai(full_text)
            if self._use_ai
            else self._get_medical_expert_details_simple(full_text)
        )
        self._errors.info(
            f"Extracted medical expert {result}",
            KlassMethodLocation(self.MODULE, "_extract_names_and_addresss"),
        )
        return result

    def _get_medical_expert_details_simple(self, text: str) -> dict:
        result = {"name": None, "reference": None}
        lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
        if len(lines) > 0:
            if lines[0].upper().startswith("NAME:"):
                result["name"] = lines[0][5:].strip()
                if len(lines) > 1:
                    result["reference"] = lines[1:]
            else:
                result["reference"] = lines
        return result

    def _get_medical_expert_details_ai(self, text: str) -> dict:
        system_prompt = """
            You are a clinical data extraction assistant. You extract medical expert 
            information from text and return ONLY valid JSON with no preamble or markdown.
            
            You will be given text that contains one of the following:
            1. The name of a medical expert, possibly accompanied by an address
            2. A reference or description of where the medical expert information can be 
            found (e.g. "See Section 3.2", "Refer to Appendix B", "Listed in the 
            protocol document")
            
            Your task is to determine which case applies and extract accordingly.
            
            Rules for identifying a name:
            - Look for person names, typically accompanied by medical titles or 
            qualifications (e.g. Dr., Prof., MD, PhD, MBBS, FRCP) but not always
            - A name is a person's name, not an organisation or document reference
            - If a name is found, extract it into the "name" field including any 
            titles and qualifications
            
            Rules for identifying a reference:
            - If the text does not contain a person's name, treat the entire text as a 
            reference to where the information can be found
            - Extract it into the "reference" field
            - split it into lines of text as an array of strings
            - If no text is found return null 
            
            Return format:
                {{ 
                    "name": string|null, 
                    "reference": [string]|null
                }}
            
            Examples:
            
            Input: Prof. Maria Jensen, MD, PhD
            Rigshospitalet
            Blegdamsvej 9
            2100 Copenhagen
            Denmark
            Output: {{ 
                "name": "Prof. Maria Jensen, MD, PhD", 
                "reference": [
                    "Rigshospitalet",
                    "Blegdamsvej 9",
                    "2100 Copenhagen", 
                    "Denmark"
                ]
            )}, 
            
            Input: Dr. Tanaka, 〒100-0001 東京都千代田区千代田1-1
            Output: {{
                "name": "Dr. Tanaka",
                "reference": [
                    "〒100-0001 東京都千代田区千代田1-1"
                ]
            }},

            Input: Prof. Mueller, Bayer AG, 51368 Leverkusen, Germany
            Output: {{
                "name": "Prof. Mueller",
                "reference": ["Bayer AG, 51368 Leverkusen, Germany"]
            }},

            Input: Dr. John Smith
            Output: {{
                "name": "Dr. John Smith",
                "reference": []
            }},

            Input: See Section 3.2 of the protocol
            Output: {{
                "name": null,
                "reference": ["See Section 3.2 of the protocol"]
            }},

            Input: Refer to the Investigator's Brochure, Appendix B
            Output: {{
                "name": null,
                "reference": ["Refer to the Investigator's Brochure, Appendix B"]
            }}
        """
        user_prompt = (
            f"Extract the medical expert information from this text:\n\n{text}"
        )
        null_result = {"name": None, "reference": None}
        prompt_result = self._ai.prompt(user_prompt, system_prompt)
        result = self._ai.extract_json(prompt_result)
        return result if result else null_result

    def _preserve_original(self, original_parts, value):
        for part in original_parts:
            for item in re.split(r"[,\s]+", part):
                if item.upper() == value.upper():
                    return item
        return value
