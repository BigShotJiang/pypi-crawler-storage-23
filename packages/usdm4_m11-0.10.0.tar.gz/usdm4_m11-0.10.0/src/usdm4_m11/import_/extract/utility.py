import re
from raw_docx.raw_table import RawTable
from raw_docx.raw_table_row import RawTableRow
from raw_docx.raw_table_cell import RawTableCell
from raw_docx.raw_paragraph import RawParagraph
from raw_docx.raw_section import RawSection


@staticmethod
def text_within(this_text: str, in_text: str) -> bool:
    clean_text = re.sub(
        r"\s+", " ", in_text
    )  # Remove any end of line chars and tabs etc
    return this_text.upper() in clean_text.upper()


@staticmethod
def table_get_row(table: RawTable, key: str) -> str:
    # print(f"\n\nTABLE FIND: {key}")
    for row in table.rows:
        if row.cells[0].is_text():
            # print(f"CELL 0: {row.cells[0].text()}")
            if text_within(key, row.cells[0].text()):
                # print(f"FOUND: {key}")
                cell = row.next_cell(0)
                result = cell.text() if cell else ""
                return result.strip()
    return ""


@staticmethod
def section_get_para(section: RawSection, search_text: str) -> str:
    para: RawParagraph
    for para in section.paragraphs():
        if text_within(search_text, para.text):
            parts = para.text.split(":")
            return (":").join(parts[1:]).strip() if len(parts) >= 2 else ""
    return ""


@staticmethod
def section_get_text_between(
    section: RawSection, start_text: str, end_text: str
) -> str:
    full_text = _get_section_text(section)
    # print(f"|----------|\n|\nFULL TEXT: {full_text}")
    clean_text = re.sub(r"[^\S\n]+", " ", full_text)
    clean_upper = clean_text.upper()
    start_pos = clean_upper.find(start_text.upper())
    if start_pos == -1:
        # print("START TEXT NOT FOUND")
        return ""
    after_start = start_pos + len(start_text)
    end_pos = clean_upper.find(end_text.upper(), after_start)
    if end_pos == -1:
        # print("END TEXT NOT FOUND")
        return ""
    result = clean_text[after_start:end_pos].strip()
    # print(f"TEXT: {result}\n|\n|----------|")
    return result


@staticmethod
def _get_section_text(section: RawSection) -> str:
    parts = []
    for item in section.items:
        if isinstance(item, RawTable):
            row: RawTableRow
            item: RawTable
            for row in item.rows:
                row_text = []
                cell: RawTableCell
                for cell in row.cells:
                    row_text.append(cell.text())
                parts.append(" ".join(row_text))
        elif isinstance(item, RawParagraph):
            parts.append(item.text)
    return "\n".join(parts)


@staticmethod
def section_find_para(section: RawSection, search_text: str) -> int:
    for index, para in enumerate(section.paragraphs()):
        if text_within(search_text, para.text):
            return index
    return None


@staticmethod
def table_get_row_html(table: RawTable, key: str) -> str:
    for row in table.rows:
        if row.cells[0].is_text():
            if text_within(key, row.cells[0].text()):
                cell = row.next_cell(0)
                return cell.to_html() if cell else ""
    return ""
