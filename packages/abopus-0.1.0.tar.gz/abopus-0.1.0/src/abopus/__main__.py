"""Entry point for `python -m abopus`."""

import sys

from abopus.converter import main

if __name__ == "__main__":
    sys.exit(main())
