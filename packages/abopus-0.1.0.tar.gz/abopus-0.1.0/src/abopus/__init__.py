"""abopus — Audiobook to Opus converter."""

__version__ = "0.1.0"
