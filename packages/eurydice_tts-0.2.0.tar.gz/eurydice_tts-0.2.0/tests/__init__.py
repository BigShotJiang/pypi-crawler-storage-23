"""Tests for eurydice."""
