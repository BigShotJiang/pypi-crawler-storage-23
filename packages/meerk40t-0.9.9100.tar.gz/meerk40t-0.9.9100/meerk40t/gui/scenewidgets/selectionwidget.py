"""
The selection widget deals with the manipulation of emphasized elements. It provides a series of related subwidgets:

BorderWidget: Draws the border of the selected object.
RotationWidget: Little arrow in the corner allowing the object to be rotated.
CornerWidget: Square in corner that typically governs uniform or x/y scaling.
SideWidget: Square at different sides that typically does x-scaling or y-scaling.
SkewWidget: Tiny squares along the side that deal with X-skew or y-skew.
MoveWidget: Center widget that moves the entire selected object.
MoveRotationOriginWidget: Function of rotating around an arbitrary center point.
ReferenceWidget: Yellow-R widget that that makes this object the reference object.
LockWidget: Widget to lock and unlock the given object.

"""

import math
import time

import numpy as np
import wx
import logging

logger = logging.getLogger(__name__)

from meerk40t.core.spatial import shortest_distance, shortest_distance_chunked, _cKDTree  # noqa: E402

from meerk40t.core.elements.element_types import elem_group_nodes, elem_nodes
from meerk40t.core.units import Length
from meerk40t.gui.laserrender import DRAW_MODE_SELECTION
from meerk40t.gui.scene.scene import (
    HITCHAIN_DELEGATE,
    HITCHAIN_HIT,
    RESPONSE_CHAIN,
    RESPONSE_CONSUME,
)
from meerk40t.gui.scene.sceneconst import HITCHAIN_HIT_AND_DELEGATE
from meerk40t.gui.scene.widget import Widget
from meerk40t.gui.wxutils import (
    StaticBoxSizer,
    create_menu_for_node,
    dip_size,
    get_gc_full_scale,
    get_matrix_scale,
    wxButton,
    wxCheckBox,
    wxStaticText,
)
from meerk40t.svgelements import Point
from meerk40t.core.geomstr import NON_GEOMETRY_TYPES, TYPE_END

# from time import perf_counter


NEARLY_ZERO = 1.0e-6
ROTATION_THRESHOLD = 0.001
POSITION_THRESHOLD = 0.0001
MAX_POINTS_FOR_SNAPPING = 100000

TOOL_RESULT_ABORT = -1
TOOL_RESULT_MOVE = 0
TOOL_RESULT_END = 1


def calculate_handle_offsets_and_deltas(
    half, handle_outside, inner_wd_half, inner_ht_half
):
    """
    Calculate handle offsets and deltas for widget positioning.

    Args:
        half: Half the widget size
        handle_outside: Whether handles should be placed outside the selection
        inner_wd_half: Half width of the inner selection area
        inner_ht_half: Half height of the inner selection area

    Returns:
        tuple: (offset_x, offset_y, dx, dy) for positioning calculations
    """
    offset_x = half if handle_outside else 0
    offset_y = half if handle_outside else 0
    dx = max(0, 2 * half - inner_wd_half)
    dy = max(0, 2 * half - inner_ht_half)
    return offset_x, offset_y, dx, dy


def process_event(
    widget,
    widget_identifier=None,
    window_pos=None,
    space_pos=None,
    event_type=None,
    nearest_snap=None,
    modifiers=None,
    helptext="",
    optimize_drawing=True,
):
    if widget_identifier is None:
        widget_identifier = "none"
    if space_pos is None:
        return RESPONSE_CHAIN
    try:
        inside = widget.contains(space_pos[0], space_pos[1])
    except TypeError:
        # Widget already destroyed ?!
        return RESPONSE_CHAIN
    # if event_type in ("move", "leftdown", "leftup"):
    #     print(f"Event for {widget_identifier}: {event_type}, {nearest_snap}")

    def _handle_hover_events():
        _ = widget.scene.context._
        if event_type == "hover" and widget.hovering and not inside:
            widget.hovering = False
            widget.scene.cursor("arrow")
            widget.scene.context.signal("statusmsg", "")
            return RESPONSE_CHAIN

        if event_type == "hover_start":
            if inside:
                widget.scene.cursor(widget.cursor)
                widget.hovering = True
                widget.scene.context.signal("statusmsg", _(helptext))
                return RESPONSE_CONSUME
        elif event_type in ("hover_end", "lost"):
            widget.scene.cursor("arrow")
            widget.hovering = False
            widget.scene.context.signal("statusmsg", "")
            return RESPONSE_CHAIN
        elif event_type == "hover":
            widget.hovering = True
            widget.scene.cursor(widget.cursor)
            widget.scene.context.signal("statusmsg", _(helptext))
            return RESPONSE_CONSUME
        return None  # Not a hover event

    def _handle_mouse_events():
        nonlocal nearest_snap
        nonlocal event_type
        if space_pos is None:
            return RESPONSE_CHAIN
        elements = widget.scene.context.elements
        dx = space_pos[4]
        dy = space_pos[5]
        # print (f"Event={event_type}, tool={widget.scene.tool_active}, modif={widget.scene.pane.modif_active}, snap={nearest_snap}")
        if widget.scene.pane.tool_active:
            # print ("ignore")
            return RESPONSE_CHAIN

        single_modifier = (
            modifiers
            and len(modifiers) == 1
            and ("shift" in modifiers or "ctrl" in modifiers)
        )

        if event_type == "leftdown":
            widget._last_win_x = window_pos[0]
            widget._last_win_y = window_pos[1]
        if event_type == "leftup":
            if (
                widget_identifier == "move"
                and hasattr(widget, "_last_win_x")
                and window_pos[0] == widget._last_win_x
                and window_pos[1] == widget._last_win_y
            ):
                # No movement occurred
                dx = 0
                dy = 0
                nearest_snap = None
                widget.was_lb_raised = False
                event_type = "leftclick"
                del widget._last_win_x
                del widget._last_win_y

        if event_type == "leftdown":
            # We want to establish that we don't have a singular Shift key or a singular ctrl-key
            # as these will extend / reduce the selection
            if widget_identifier == "move" or not single_modifier:
                cx = (widget.left + widget.right) / 2
                cy = (widget.top + widget.bottom) / 2
                # print(f"Start: x={space_pos[0]}, y={space_pos[1]}, dx={space_pos[4]}, dy={space_pos[5]}")
                # print(f"Widget: cx={cx}, cy={cy}")
                # Set them to the center of the widget
                widget.master.offset_x = cx - space_pos[0]
                widget.master.offset_y = cy - space_pos[1]
                widget.was_lb_raised = True
                widget.save_width = widget.master.width
                widget.save_height = widget.master.height
                widget.uniform = not widget.master.key_alt_pressed
                widget.master.total_delta_y = dy
                widget.master.total_delta_x = dx
                widget.master.total_delta_y = dy
                widget.master.tool_running = optimize_drawing
                widget.master.invalidate_rot_center()
                widget.master.check_rot_center()
                widget.tool(
                    space_pos, nearest_snap, dx, dy, TOOL_RESULT_ABORT, modifiers
                )
                return RESPONSE_CONSUME
        # elif event_type == "middledown":
        #     # Hmm, I think this is never called due to the consumption of this event by scene pane...
        #     widget.was_lb_raised = False
        #     widget.save_width = widget.master.width
        #     widget.save_height = widget.master.height
        #     widget.uniform = False
        #     widget.master.total_delta_x = dx
        #     widget.master.total_delta_y = dy
        #     widget.master.tool_running = optimize_drawing
        #     widget.tool(space_pos, nearest_snap, dx, dy, TOOL_RESULT_ABORT, modifiers)
        #     return RESPONSE_CONSUME
        elif event_type == "leftup":
            if widget.was_lb_raised:
                widget.tool(space_pos, nearest_snap, dx, dy, TOOL_RESULT_END, modifiers)
                widget.scene.context.elements.ensure_positive_bounds()
                widget.was_lb_raised = False
                widget.master.show_border = True
                widget.master.tool_running = False
                return RESPONSE_CONSUME
        elif event_type in ("middleup", "lost"):
            if widget.was_lb_raised:
                widget.tool(space_pos, nearest_snap, dx, dy, TOOL_RESULT_END, modifiers)
                widget.was_lb_raised = False
                widget.master.show_border = True
                widget.master.tool_running = False
                widget.scene.context.elements.ensure_positive_bounds()
                return RESPONSE_CONSUME
        elif event_type == "move":
            if widget.was_lb_raised:
                if not elements.has_emphasis():
                    return RESPONSE_CONSUME
                if widget.save_width is None or widget.save_height is None:
                    widget.save_width = widget.width
                    widget.save_height = widget.height
                widget.master.total_delta_x += dx
                widget.master.total_delta_y += dy
                widget.tool(
                    space_pos, nearest_snap, dx, dy, TOOL_RESULT_MOVE, modifiers
                )
                return RESPONSE_CONSUME
        elif event_type == "leftclick":
            if widget.was_lb_raised:
                widget.tool(space_pos, nearest_snap, dx, dy, TOOL_RESULT_END, modifiers)
                widget.scene.context.elements.ensure_positive_bounds()
                widget.was_lb_raised = False
                widget.master.tool_running = False
                widget.master.show_border = True
                return RESPONSE_CONSUME
            else:
                widget.tool(
                    space_pos, nearest_snap, dx, dy, TOOL_RESULT_ABORT, modifiers
                )
                widget.master.tool_running = False
                widget.master.show_border = True
                return RESPONSE_CONSUME
        return RESPONSE_CHAIN

    # Handle hover events first
    hover_result = _handle_hover_events()
    return hover_result if hover_result is not None else _handle_mouse_events()


def update_elements(scene):
    elements = scene.context.elements
    with elements.undofree():
        images = []
        for e in elements.elems(types=elem_group_nodes, emphasized=True):
            e.modified()
            if hasattr(e, "update"):
                images.append(e)
        for e in images:
            elements.do_image_update(e, scene.context, delayed=True)
    scene.pane.modif_active = False
    scene.context.signal("modified_by_tool")


class BorderWidget(Widget):
    """
    Border Widget it tasked with drawing the selection box
    """

    def __init__(self, master, scene, **kwargs):
        self.master = master
        self.scene = scene
        self.cursor = None
        Widget.__init__(
            self,
            scene,
            self.master.left,
            self.master.top,
            self.master.right,
            self.master.bottom,
            **kwargs,
        )
        self.msize = None
        self.update()
        context = self.scene.context
        # Make sure we have the correct display unit
        display_unit = context.setting(str, "_display_unit", context.units_name)
        if display_unit is None or display_unit == "":
            context._display_unit = context.units_name
        coord_display_mode = context.root.setting(int, "coord_display", 0)
        # 0 = all, 1 = to mk 0,0 only, 2=suppress
        self.show_lt = coord_display_mode in (0, 1)
        self.show_rb = coord_display_mode == 0
        self._angle_font = None
        self._label_font = None

    def set_size(self, *args):
        self.left = self.master.left
        self.top = self.master.top
        self.right = self.master.right
        self.bottom = self.master.bottom

    def _get_angle_font(self):
        if self._angle_font is None or self._angle_font.GetPointSize() != int(
            0.75 * self.master.font_size
        ):
            try:
                self._angle_font = wx.Font(
                    0.75 * self.master.font_size,
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            except TypeError:
                self._angle_font = wx.Font(
                    int(0.75 * self.master.font_size),
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
        return self._angle_font

    def _get_label_font(self):
        if self._label_font is None or self._label_font.GetPointSize() != int(
            self.master.font_size
        ):
            try:
                self._label_font = wx.Font(
                    self.master.font_size,
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            except TypeError:
                self._label_font = wx.Font(
                    int(self.master.font_size),
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
        return self._label_font

    def update(self):
        self.left = self.master.left
        self.top = self.master.top
        self.right = self.master.right
        self.bottom = self.master.bottom

    def hit(self):
        return HITCHAIN_DELEGATE

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        **kwargs,
    ):
        return RESPONSE_CHAIN

    def process_draw(self, gc):
        """
        Draw routine for drawing the selection box.
        """
        if not self.visible:  # We don't need that overhead
            return

        def get_length_text_and_extent(gc, value, units, secondary_units, rel_length):
            s_txt = str(
                Length(
                    amount=value,
                    digits=2,
                    preferred_units=units,
                    relative_length=rel_length,
                )
            )
            if units != secondary_units:
                s_txt += f"/{Length(amount=value, digits=2, preferred_units=secondary_units, relative_length=rel_length)}"
            try:
                (width, height, descent, externalLeading) = gc.GetFullTextExtent(s_txt)
                t_width = width + externalLeading
                t_height = height + descent
            except AttributeError:
                t_width, t_height = gc.GetTextExtent(s_txt)
            return s_txt, t_width, t_height

        context = self.scene.context
        self.update()
        center_x = (self.left + self.right) / 2.0
        center_y = (self.top + self.bottom) / 2.0

        if not self.master.show_border:
            # Only show angle if not showing border
            if abs(self.master.rotated_angle) > ROTATION_THRESHOLD:
                font = self._get_angle_font()
                gc.SetFont(font, self.scene.colors.color_manipulation)
                symbol = f"{360 * self.master.rotated_angle / math.tau:.0f}°"
                pen = wx.Pen()
                pen.SetColour(self.scene.colors.color_manipulation)
                pen.SetStyle(wx.PENSTYLE_SOLID)
                gc.SetPen(pen)
                brush = wx.Brush(wx.WHITE, wx.BRUSHSTYLE_SOLID)
                gc.SetBrush(brush)
                t_width, t_height = gc.GetTextExtent(symbol)
                gc.DrawEllipse(
                    center_x - 0.6 * t_width,
                    center_y - 0.6 * t_height,
                    1.2 * t_width,
                    1.2 * t_height,
                )
                gc.DrawText(
                    symbol,
                    center_x - 0.5 * t_width,
                    center_y - 0.5 * t_height,
                )
            return

        # Draw border and guides
        gc.PushState()
        sx, sy = get_gc_full_scale(gc)
        gc.Scale(1 / sx, 1 / sy)
        bed_w = self.scene.context.device.space.width
        bed_h = self.scene.context.device.space.height

        mypen = wx.Pen(self.master.selection_pen)
        mypen.SetWidth(1)
        mypen.SetStyle(wx.PENSTYLE_LONG_DASH)
        gc.SetPen(mypen)
        if self.show_lt:
            gc.StrokeLine(sx * center_x, sy * 0, sx * center_x, sy * self.top)
            gc.StrokeLine(sx * 0, sy * center_y, sx * self.left, sy * center_y)
        if self.show_rb:
            gc.StrokeLine(sx * center_x, sy * self.bottom, sx * center_x, sy * bed_h)
            gc.StrokeLine(sx * self.right, sy * center_y, sx * bed_w, sy * center_y)

        mypen.SetStyle(wx.PENSTYLE_DOT)
        gc.SetPen(mypen)
        gc.StrokeLine(sx * self.left, sy * self.top, sx * self.right, sy * self.top)
        gc.StrokeLine(sx * self.right, sy * self.top, sx * self.right, sy * self.bottom)
        gc.StrokeLine(
            sx * self.right, sy * self.bottom, sx * self.left, sy * self.bottom
        )
        gc.StrokeLine(sx * self.left, sy * self.bottom, sx * self.left, sy * self.top)
        gc.PopState()
        gc.SetPen(self.master.selection_pen)

        units = context._display_unit or context.units_name
        secondary_units = context.units_name
        gc.SetFont(self._get_label_font(), self.scene.colors.color_manipulation)

        # Draw coordinate labels
        if self.show_lt:
            # Y-Value (top)
            s_txt, t_width, t_height = get_length_text_and_extent(
                gc,
                self.top,
                units,
                secondary_units,
                self.scene.context.device.view.height,
            )
            distance = 0.25 * t_height
            pos = self.top / 2.0 - t_height / 2
            if pos + t_height + distance >= self.top:
                pos = self.top - t_height - distance
            gc.DrawText(s_txt, center_x - t_width / 2, pos)

            # X-Coordinate (left)
            s_txt, t_width, t_height = get_length_text_and_extent(
                gc,
                self.left,
                units,
                secondary_units,
                self.scene.context.device.view.width,
            )
            pos = self.left / 2.0 - t_width / 2
            if pos + t_width + distance >= self.left:
                pos = self.left - t_width - distance
            gc.DrawText(s_txt, pos, center_y)

        if self.show_rb:
            # Y-Value (bottom)
            rpos = bed_h - self.bottom
            s_txt, t_width, t_height = get_length_text_and_extent(
                gc, rpos, units, secondary_units, self.scene.context.device.view.height
            )
            distance = 1.5 * t_height
            pos = self.bottom + rpos / 2 - t_height / 2
            if pos - t_height - distance <= self.bottom:
                pos = self.bottom + distance
            gc.DrawText(s_txt, center_x - t_width / 2, pos)

            # X-Coordinate (right)
            rpos = bed_w - self.right
            s_txt, t_width, t_height = get_length_text_and_extent(
                gc, rpos, units, secondary_units, self.scene.context.device.view.width
            )
            pos = self.right + rpos / 2.0 - t_width / 2
            if pos - distance <= self.right:
                pos = self.right + distance
            gc.DrawText(s_txt, pos, center_y)

        # Height label (vertical, right)
        s_txt, t_width, t_height = get_length_text_and_extent(
            gc,
            self.bottom - self.top,
            units,
            secondary_units,
            self.scene.context.device.view.height,
        )
        gc.DrawText(
            s_txt,
            self.right + 0.5 * t_height,
            center_y + 0.5 * t_width,
            math.tau / 4,
        )

        # Width label (horizontal, bottom)
        s_txt, t_width, t_height = get_length_text_and_extent(
            gc,
            self.right - self.left,
            units,
            secondary_units,
            self.scene.context.device.view.width,
        )
        gc.DrawText(s_txt, center_x - 0.5 * t_width, self.bottom + 0.5 * t_height)
        if abs(self.master.rotated_angle) > ROTATION_THRESHOLD:
            font = self._get_angle_font()
            gc.SetFont(font, self.scene.colors.color_manipulation)
            symbol = f"{360 * self.master.rotated_angle / math.tau:.0f}°"
            pen = wx.Pen()
            pen.SetColour(self.scene.colors.color_manipulation)
            pen.SetStyle(wx.PENSTYLE_SOLID)
            gc.SetPen(pen)
            brush = wx.Brush(wx.WHITE, wx.BRUSHSTYLE_SOLID)
            gc.SetBrush(brush)
            t_width, t_height = gc.GetTextExtent(symbol)
            gc.DrawEllipse(
                center_x - 0.6 * t_width,
                center_y - 0.6 * t_height,
                1.2 * t_width,
                1.2 * t_height,
            )
            gc.DrawText(
                symbol,
                center_x - 0.5 * t_width,
                center_y - 0.5 * t_height,
            )


class RotationWidget(Widget):
    """
    Rotation Widget it tasked with drawing the rotation box and managing the events
    dealing with rotating the selected object.
    """

    def __init__(self, master, scene, index, size, inner=0, **kwargs):
        self.master = master
        self.scene = scene
        self.index = index
        self.half = size / 2
        self.inner = inner
        self.cursor = "rotate1"
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        self.rotate_cx = None
        self.rotate_cy = None
        self.reference_rect = None

        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.update()

    def set_size(self, msize, rotsize):
        self.inner = int(msize)
        self.half = rotsize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        # mid_x = (self.master.right + self.master.left) / 2
        # mid_y = (self.master.bottom + self.master.top) / 2
        # Selection very small ? Relocate Handle
        inner_wd_half = (self.master.right - self.master.left) / 2
        inner_ht_half = (self.master.bottom - self.master.top) / 2
        dx = max(0, self.inner - inner_wd_half)
        dy = max(0, self.inner - inner_ht_half)
        if self.master.handle_outside:
            offset_x = self.inner / 2
            offset_y = self.inner / 2
        else:
            offset_x = 0
            offset_y = 0

        if self.index == 0:
            pos_x = self.master.left - dx - offset_x
            pos_y = self.master.top - dy - offset_y
        elif self.index == 1:
            pos_x = self.master.right + dx + offset_x
            pos_y = self.master.top - dy - offset_y
        elif self.index == 2:
            pos_x = self.master.right + dx + offset_x
            pos_y = self.master.bottom + dy + offset_y
        else:
            pos_x = self.master.left - dx - offset_x
            pos_y = self.master.bottom + dy + offset_y
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:  # We don't need that overhead
            return
        self.update()  # make sure coords are valid

        cx = (self.left + self.right) / 2
        cy = (self.top + self.bottom) / 2
        if self.index == 0:  # tl
            signx = -1
            signy = -1
        elif self.index == 1:  # tr
            signx = +1
            signy = -1
        elif self.index == 2:  # br
            signx = +1
            signy = +1
        elif self.index == 3:  # bl
            signx = -1
            signy = +1
        else:
            raise ValueError("Selection location was not valid.")

        # Well, I would have liked to draw a proper arc via dc.DrawArc but the DeviceContext is not available here(?)
        segment = []
        # Start arrow at 0deg, cos = 1, sin = 0
        x = cx + signx * 1 * self.half
        y = cy + signy * 0 * self.half
        segment += [(x - signx * 1 / 2 * self.inner, y + signy * 1 / 2 * self.inner)]
        segment += [(x, y)]
        segment += [
            (x + 2 / 3 * signx * 1 / 2 * self.inner, y + signy * 1 / 2 * self.inner)
        ]
        segment += [(x, y)]

        # Arc-Segment
        numpts = 8
        for k in range(numpts + 1):
            radi = k * math.pi / (2 * numpts)
            sy = math.sin(radi)
            sx = math.cos(radi)
            x = cx + signx * sx * self.half
            y = cy + signy * sy * self.half
            # print ("Radian=%.1f (%.1f°), sx=%.1f, sy=%.1f, x=%.1f, y=%.1f" % (radi, (radi/math.pi*180), sy, sy, x, y))
            segment += [(x, y)]

        # End-arrow at 90deg, cos = 0, sin = 1
        # End-Arrow
        x = cx + signx * 0 * self.half
        y = cy + signy * 1 * self.half
        segment += [
            (x + signx * 1 / 2 * self.inner, y + 2 / 3 * signy * 1 / 2 * self.inner)
        ]
        segment += [(x, y)]
        segment += [(x + signx * 1 / 2 * self.inner, y - signy * 1 / 2 * self.inner)]
        gc.SetPen(self.master.handle_pen)
        gc.StrokeLines(segment)

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        """
        Change the rotation of the selected elements.
        """
        # Nearest snap makes not a lot of sense imho, so no dealing with it...
        nearest_snap = None
        if nearest_snap is not None:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]
            # dx = position[4]
            # dy = position[5]

        elements = self.scene.context.elements
        if event == TOOL_RESULT_END:
            update_elements(self.scene)
            self.master.last_angle = None
            self.master.start_angle = None
            self.master.rotated_angle = 0
        elif event == TOOL_RESULT_ABORT:
            self.scene.pane.modif_active = True
            # Normally this would happen automagically in the background, but as we are going
            # to suppress undo during the execution of this tool (to allow to go back to the
            # very starting point) we need to set the recovery point ourselves.
            # Hint for translate check: _("Element rotated")
            elements.undo.mark("Element rotated")
            return
        elif event == TOOL_RESULT_MOVE:
            if self.rotate_cx is None:
                self.rotate_cx = self.master.rotation_cx
            if self.rotate_cy is None:
                self.rotate_cy = self.master.rotation_cy
            # if self.rotate_cx == self.master.rotation_cx and self.rotate_cy == self.master.rotation_cy:
            #    print ("Rotating around center")
            # else:
            #    print ("Rotating around special point")
            # Improved code by tatarize to establish rotation angle

            current_angle = Point.angle(position[:2], (self.rotate_cx, self.rotate_cy))

            if self.master.last_angle is None:
                self.master.start_angle = current_angle
                self.master.last_angle = current_angle

            # Update Rotation angle...
            if self.master.key_shift_pressed:
                # Only steps of 5 deg
                desired_step = 5 * (math.tau / 360)
                old_angle = current_angle - self.master.start_angle
                new_angle = round(old_angle / desired_step) * desired_step
                current_angle += new_angle - old_angle
            elif self.master.key_control_pressed:
                # Only steps of 15 deg
                desired_step = 15 * (math.tau / 360)
                old_angle = current_angle - self.master.start_angle
                new_angle = round(old_angle / desired_step) * desired_step
                current_angle += new_angle - old_angle

            delta_angle = current_angle - self.master.last_angle
            self.master.last_angle = current_angle
            # Update Rotation angle...
            self.master.rotated_angle = current_angle - self.master.start_angle
            # print(
            #    "Angle to Point=%.1f, last_angle=%.1f, total_angle=%.1f, delta=%.1f"
            #    % (
            #        current_angle / math.pi * 180,
            #        self.master.last_angle / math.pi * 180,
            #        self.master.rotated_angle / math.pi * 180,
            #        delta_angle / math.pi * 180,
            #    )
            # )
            # Bring back to 'regular' radians
            while self.master.rotated_angle > 0.5 * math.tau:
                self.master.rotated_angle -= 1.0 * math.tau
            while self.master.rotated_angle < -0.5 * math.tau:
                self.master.rotated_angle += 1.0 * math.tau
            # Take representation rectangle and rotate it
            # if self.reference_rect is None:
            #    b = elements._emphasized_bounds
            #    self.reference_rect = Rect(
            #        x=b[0], y=b[1], width=b[2] - b[0], height=b[3] - b[1]
            #    )
            # self.reference_rect.transform.post_rotate(
            #    rot_angle, self.rotate_cx, self.rotate_cy
            # )
            # b = self.reference_rect.bbox()
            with elements.undofree():
                for e in elements.elems(emphasized=True):
                    try:
                        if e.lock:
                            continue
                    except AttributeError:
                        pass
                    e.matrix.post_rotate(delta_angle, self.rotate_cx, self.rotate_cy)
                    if e.type == "elem image":
                        e._cache = None
            # elements.update_bounds([b[0], b[1], b[2], b[3]])
            elements.signal("updating")

        self.scene.request_refresh()

    def hit(self):
        return HITCHAIN_HIT

    def _contains(self, x, y=None):
        # result: 0 = No Hit, 1 = outer, 2 = Inner
        value = 0
        if y is None:
            y = x.y
            x = x.x
        mid_x = (self.left + self.right) / 2
        mid_y = (self.top + self.bottom) / 2
        if self.index in (0, 3):  # left
            tx1 = self.left
            tx2 = mid_x + self.inner / 2
            bx1 = mid_x
            bx2 = self.right
        else:
            tx1 = mid_x - self.inner / 2
            tx2 = self.right
            bx1 = self.left
            bx2 = mid_x

        if self.index in (0, 1):  # top
            ty1 = self.top
            ty2 = mid_y + self.inner / 2
            by1 = mid_y
            by2 = self.bottom
        else:
            ty1 = mid_y - self.inner / 2
            ty2 = self.bottom
            by1 = self.top
            by2 = mid_y
        if tx1 <= x <= tx2 and ty1 <= y <= ty2:  # outer part
            value = 1
        elif bx1 <= x <= bx2 and by1 <= y <= by2:  # inner  part
            value = 2
        if (
            mid_x - self.inner / 2 <= x <= mid_x + self.inner / 2
            and mid_y - self.inner / 2 <= y <= mid_y + self.inner / 2
        ):
            # Corner-Handle
            value = 0

        return value

    def contains(self, x, y=None):
        # Slightly more complex than usual due to the inner exclusion...
        value = self._contains(x, y)
        return value != 0

    def inner_contains(self, x, y=None):
        # Slightly more complex than usual due to the inner exclusion...
        value = self._contains(x, y)
        return value == 2

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "rotation"
        # Translation hint: _("Rotate element")
        response = process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext="Rotate element",
        )
        if event_type == "leftdown":
            self.master.show_border = False
            # Hit in the inner area?
            if space_pos is not None and self.inner_contains(
                space_pos[0], space_pos[1]
            ):
                if self.index == 0:  # tl
                    self.rotate_cx = self.master.right
                    self.rotate_cy = self.master.bottom
                elif self.index == 1:  # tr
                    self.rotate_cx = self.master.left
                    self.rotate_cy = self.master.bottom
                elif self.index == 2:  # br
                    self.rotate_cx = self.master.left
                    self.rotate_cy = self.master.top
                elif self.index == 3:  # bl
                    self.rotate_cx = self.master.right
                    self.rotate_cy = self.master.top
            else:
                self.rotate_cx = None
                self.rotate_cy = None
        elif event_type in ("leftclick", "leftup"):
            self.master.show_border = True

        return response


class CornerWidget(Widget):
    """
    Corner Widget it tasked with drawing the corner box and managing the events
    dealing with sizing the selected object in both X- and Y-direction
    """

    def __init__(self, master, scene, index, size, **kwargs):
        self.master = master
        self.scene = scene
        self.index = index
        self.half = size / 2
        self.allow_x = True
        self.allow_y = True
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        if index == 0:
            self.method = "nw"
        elif index == 1:
            self.method = "ne"
        elif index == 2:
            self.method = "se"
        elif index == 3:
            self.method = "sw"
        self.cursor = f"size_{self.method}"

        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        # mid_x = (self.master.right + self.master.left) / 2
        # mid_y = (self.master.bottom + self.master.top) / 2
        # Selection very small ? Relocate Handle
        inner_wd_half = (self.master.right - self.master.left) / 2
        inner_ht_half = (self.master.bottom - self.master.top) / 2
        offset_x, offset_y, dx, dy = calculate_handle_offsets_and_deltas(
            self.half, self.master.handle_outside, inner_wd_half, inner_ht_half
        )

        if self.index == 0:
            pos_x = self.master.left - dx - offset_x
            pos_y = self.master.top - dy - offset_y
        elif self.index == 1:
            pos_x = self.master.right + dx + offset_x
            pos_y = self.master.top - dy - offset_y
        elif self.index == 2:
            pos_x = self.master.right + dx + offset_x
            pos_y = self.master.bottom + dy + offset_y
        else:
            pos_x = self.master.left - dx - offset_x
            pos_y = self.master.bottom + dy + offset_y
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:  # We don't need that overhead
            return

        self.update()  # make sure coords are valid
        brush = wx.Brush(
            self.scene.colors.color_manipulation_handle, wx.BRUSHSTYLE_SOLID
        )
        gc.SetPen(self.master.handle_pen)
        gc.SetBrush(brush)
        gc.DrawRectangle(self.left, self.top, self.width, self.height)

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        elements = self.scene.context.elements
        if nearest_snap is None:
            # print ("Took last snap instead...")
            nearest_snap = self.scene.pane.last_snap
        if nearest_snap is not None:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]
            # dx = position[4]
            # dy = position[5]

        if event == TOOL_RESULT_END:  # End
            update_elements(self.scene)
        elif event == TOOL_RESULT_ABORT:
            self.scene.pane.modif_active = True
            # Normally this would happen automagically in the background, but as we are going
            # to suppress undo during the execution of this tool (to allow to go back to the
            # very starting point) we need to set the recovery point ourselves.
            # Hint for translate check: _("Element scaled")
            elements.undo.mark("Element scaled")
            return
        elif event == TOOL_RESULT_MOVE:
            # Establish scales
            scalex = 1
            scaley = 1
            if "n" in self.method:
                try:
                    scaley = (self.master.bottom - position[1]) / self.save_height
                except ZeroDivisionError:
                    scaley = 1
            elif "s" in self.method:
                try:
                    scaley = (position[1] - self.master.top) / self.save_height
                except ZeroDivisionError:
                    scaley = 1

            if "w" in self.method:
                try:
                    scalex = (self.master.right - position[0]) / self.save_width
                except ZeroDivisionError:
                    scalex = 1
            elif "e" in self.method:
                try:
                    scalex = (position[0] - self.master.left) / self.save_width
                except ZeroDivisionError:
                    scalex = 1
            free = bool(modifiers and "alt" in modifiers)
            if len(self.method) > 1 and self.uniform and not free:  # from corner
                scale = (scaley + scalex) / 2.0
                scalex = scale
                scaley = scale
            if abs(scalex) < NEARLY_ZERO or abs(scaley) <= NEARLY_ZERO:
                return

            b = elements._emphasized_bounds
            if b is None:
                return

            # Establish origin
            orgy = self.master.bottom if "n" in self.method else self.master.top
            orgx = self.master.right if "w" in self.method else self.master.left

            grow = 1
            # If the crtl+shift-Keys are pressed then size equally on both opposing sides at the same time
            if self.master.key_shift_pressed and self.master.key_control_pressed:
                orgy = (self.master.bottom + self.master.top) / 2
                orgx = (self.master.left + self.master.right) / 2
                grow = 0.5

            oldvalue = self.save_width
            self.save_width *= scalex
            deltax = self.save_width - oldvalue
            oldvalue = self.save_height
            self.save_height *= scaley
            deltay = self.save_height - oldvalue

            if "n" in self.method:
                b[1] -= grow * deltay
                b[3] += (1 - grow) * deltay
            elif "s" in self.method:
                b[3] += grow * deltay
                b[1] -= (1 - grow) * deltay

            if "e" in self.method:
                b[2] += grow * deltax
                b[0] -= (1 - grow) * deltax
            elif "w" in self.method:
                b[0] -= grow * deltax
                b[2] += (1 - grow) * deltax

            # No undo of interim steps
            with elements.undofree():
                for node in elements.elems(emphasized=True):
                    try:
                        if node.lock:
                            continue
                    except AttributeError:
                        pass
                    node.matrix.post_scale(scalex, scaley, orgx, orgy)
                    node.scaled(sx=scalex, sy=scaley, ox=orgx, oy=orgy, interim=True)
                    if node.type == "elem image":
                        node._cache = None
            elements.signal("updating")
            elements.update_bounds([b[0], b[1], b[2], b[3]])

        self.scene.request_refresh()

    def hit(self):
        return HITCHAIN_HIT

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "corner"
        # Translation hint: _("Size element (with Alt-Key freely, with Ctrl+shift from center)")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext="Size element (with Alt-Key freely, with Ctrl+shift from center)",
        )


class SideWidget(Widget):
    """
    Side Widget it tasked with drawing the corner box and managing the events
    dealing with sizing the selected object either in X- or Y-direction
    """

    def __init__(self, master, scene, index, size, **kwargs):
        self.master = master
        self.scene = scene
        self.index = index
        self.half = size / 2
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        if index in (0, 2):
            self.allow_x = True
            self.allow_y = False
        else:
            self.allow_x = False
            self.allow_y = True
        if index == 0:
            self.method = "n"
        elif index == 1:
            self.method = "e"
        elif index == 2:
            self.method = "s"
        elif index == 3:
            self.method = "w"
        self.cursor = f"size_{self.method}"
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        mid_x = (self.master.right + self.master.left) / 2
        mid_y = (self.master.bottom + self.master.top) / 2
        # Selection very small ? Relocate Handle
        inner_wd_half = (self.master.right - self.master.left) / 2
        inner_ht_half = (self.master.bottom - self.master.top) / 2
        offset_x, offset_y, dx, dy = calculate_handle_offsets_and_deltas(
            self.half, self.master.handle_outside, inner_wd_half, inner_ht_half
        )

        if self.index == 0:
            pos_x = mid_x
            pos_y = self.master.top - dy - offset_y
        elif self.index == 1:
            pos_x = self.master.right + dx + offset_x
            pos_y = mid_y
        elif self.index == 2:
            pos_x = mid_x
            pos_y = self.master.bottom + dy + offset_y
        else:
            pos_x = self.master.left - dx - offset_x
            pos_y = mid_y
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:  # We don't need that overhead
            return

        self.update()  # make sure coords are valid
        brush = wx.Brush(
            self.scene.colors.color_manipulation_handle, wx.BRUSHSTYLE_SOLID
        )
        gc.SetPen(self.master.handle_pen)
        gc.SetBrush(brush)
        gc.DrawRectangle(self.left, self.top, self.width, self.height)

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        elements = self.scene.context.elements
        if nearest_snap is None:
            # print ("Took last snap instead...")
            nearest_snap = self.scene.pane.last_snap
        if nearest_snap is not None:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            # print(
            #     f"Side: pos={position[0]:.2f}, {position[1]:.2f}, "
            #     + f"old={position[2]:.2f}, {position[3]:.2f}, "
            #     + f"dx={position[4]:.2f}, dy={position[5]:.2f}"
            # )
            # print(
            #     f"snap: pos={nearest_snap[0]:.2f}, {nearest_snap[1]:.2f}, "
            #     + f"old={nearest_snap[2]:.2f}, {nearest_snap[3]:.2f}"
            # )
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]
            # dx = position[4]
            # dy = position[5]

        if event == TOOL_RESULT_END:
            update_elements(self.scene)
        elif event == TOOL_RESULT_ABORT:
            self.scene.pane.modif_active = True
            # Normally this would happen automagically in the background, but as we are going
            # to suppress undo during the execution of this tool (to allow to go back to the
            # very starting point) we need to set the recovery point ourselves.
            # Hint for translate check: _("Element scaled")
            elements.undo.mark("Element scaled")
            return
        elif event == TOOL_RESULT_MOVE:
            # Establish scales
            scalex = 1
            scaley = 1
            # deltax = 0
            # deltay = 0
            if "n" in self.method:
                try:
                    scaley = (self.master.bottom - position[1]) / self.save_height
                except ZeroDivisionError:
                    scaley = 1
            elif "s" in self.method:
                try:
                    scaley = (position[1] - self.master.top) / self.save_height
                except ZeroDivisionError:
                    scaley = 1
            if "w" in self.method:
                try:
                    scalex = (self.master.right - position[0]) / self.save_width
                except ZeroDivisionError:
                    scalex = 1
            elif "e" in self.method:
                try:
                    scalex = (position[0] - self.master.left) / self.save_width
                except ZeroDivisionError:
                    scalex = 1

            if len(self.method) > 1 and self.uniform:  # from corner
                scale = (scaley + scalex) / 2.0
                scalex = scale
                scaley = scale
            if abs(scalex) < NEARLY_ZERO or abs(scaley) <= NEARLY_ZERO:
                return
            # Correct, but slow...
            b = elements._emphasized_bounds
            if b is None:
                b = elements.selected_area()
            if b is None:
                return
            # Establish origin
            orgy = self.master.bottom if "n" in self.method else self.master.top
            orgx = self.master.right if "w" in self.method else self.master.left
            grow = 1
            # If the Ctr+Shift-Keys are pressed then size equally on both opposing sides at the same time
            if self.master.key_shift_pressed and self.master.key_control_pressed:
                orgy = (self.master.bottom + self.master.top) / 2
                orgx = (self.master.left + self.master.right) / 2
                grow = 0.5

            oldvalue = self.save_width
            self.save_width *= scalex
            deltax = self.save_width - oldvalue
            oldvalue = self.save_height
            self.save_height *= scaley
            deltay = self.save_height - oldvalue

            if "n" in self.method:
                b[1] -= grow * deltay
                b[3] += (1 - grow) * deltay
            elif "s" in self.method:
                b[3] += grow * deltay
                b[1] -= (1 - grow) * deltay

            if "e" in self.method:
                b[2] += grow * deltax
                b[0] -= (1 - grow) * deltax
            elif "w" in self.method:
                b[0] -= grow * deltax
                b[2] += (1 - grow) * deltax
            # print ("Side-Tool #%d called, method=%s - dx=%.1f, dy=%.1f" % (self.index, self.method, dx, dy))
            # print (f"New width: {b[2] - b[0]:.4f}, New height: {b[3] - b[1]:.4f}")
            # print (f"Applied: scalex={scalex:.4f}, scaley={scaley:.4f}, orgx={orgx:.4f}, orgy={orgx:.4f}")

            # No undo of interim steps
            with elements.undofree():
                for node in elements.elems(emphasized=True):
                    try:
                        if node.lock:
                            continue
                    except AttributeError:
                        pass
                    node.matrix.post_scale(scalex, scaley, orgx, orgy)
                    node.scaled(sx=scalex, sy=scaley, ox=orgx, oy=orgy, interim=True)
                    if node.type == "elem image":
                        node._cache = None
            elements.signal("updating")
            elements.update_bounds([b[0], b[1], b[2], b[3]])

        self.scene.request_refresh()

    def hit(self):
        return HITCHAIN_HIT

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "side"
        s_coord = "Y" if self.index in (0, 2) else "X"
        s_help = f"Size element in {s_coord}-direction (with Ctrl+shift from center)"
        # Translation hint: _("Size element in X-direction (with Ctrl+shift from center)")
        # Translation hint: _("Size element in Y-direction (with Ctrl+shift from center)")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext=s_help,
        )


class SkewWidget(Widget):
    """
    Skew Widget it tasked with drawing the skew box and managing the events
    dealing with skewing the selected object either in X- or Y-direction
    """

    def __init__(self, master, scene, is_x, size, **kwargs):
        self.master = master
        self.scene = scene
        self.is_x = is_x
        self.half = size / 2
        self.last_skew = 0
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.cursor = "skew_x" if is_x else "skew_y"
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        offset_x = self.half if self.master.handle_outside else 0
        offset_y = self.half if self.master.handle_outside else 0

        if self.is_x:
            pos_x = self.master.left + 3 / 4 * (self.master.right - self.master.left)
            pos_y = self.master.bottom + offset_y
        else:
            pos_x = self.master.right + offset_x
            pos_y = self.master.top + 1 / 4 * (self.master.bottom - self.master.top)
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:
            # print (f"SkewWidget_{'x' if self.is_x else 'y'}: Not drawing, tool_running={self.master.tool_running}, visible={self.visible}")
            return

        self.update()  # make sure coords are valid
        gc.SetPen(self.master.handle_pen)
        brush = wx.Brush(
            self.scene.colors.color_manipulation_handle, wx.BRUSHSTYLE_SOLID
        )
        gc.SetBrush(brush)
        gc.DrawRectangle(self.left, self.top, self.width, self.height)

    def hit(self):
        return HITCHAIN_HIT

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        """
        Change the skew of the selected elements.
        """
        elements = self.scene.context.elements
        # Skew makes not a lot of sense to listen to nearest_snap, so we ignore it...
        nearest_snap = None
        if nearest_snap is not None:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]
            # dx = position[4]
            # dy = position[5]

        if event == TOOL_RESULT_END:  # end
            self.last_skew = 0

            self.master.rotated_angle = self.last_skew
            update_elements(self.scene)
        elif event == TOOL_RESULT_ABORT:
            self.scene.pane.modif_active = True
            # Normally this would happen automagically in the background, but as we are going
            # to suppress undo during the execution of this tool (to allow to go back to the
            # very starting point) we need to set the recovery point ourselves.
            # Hint for translate check: _("Element skewed")
            elements.undo.mark("Element skewed")
            return
        elif event == TOOL_RESULT_MOVE:  # move
            if self.is_x:
                this_side = self.master.total_delta_x
                other_side = self.master.height
            else:
                this_side = self.master.total_delta_y
                other_side = self.master.width

            skew_tan = this_side / other_side
            current_angle = math.atan(skew_tan)
            delta_angle = current_angle - self.master.rotated_angle
            self.master.rotated_angle = current_angle

            # No undo of interim steps
            with elements.undofree():
                for e in elements.elems(emphasized=True):
                    try:
                        if e.lock:
                            continue
                    except AttributeError:
                        pass
                    if self.is_x:
                        e.matrix.post_skew_x(
                            delta_angle,
                            (self.master.right + self.master.left) / 2,
                            (self.master.top + self.master.bottom) / 2,
                        )
                    else:
                        e.matrix.post_skew_y(
                            delta_angle,
                            (self.master.right + self.master.left) / 2,
                            (self.master.top + self.master.bottom) / 2,
                        )
                    if e.type == "elem image":
                        e._cache = None
            elements.signal("updating")
            # elements.update_bounds([b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy])
        self.scene.request_refresh()

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "skew"
        s_help = f"Skew element in {'X' if self.is_x else 'Y'}-direction"
        # Translation hint: _("Skew element in X-direction")
        # Translation hint: _("Skew element in Y-direction")
        response = process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext=s_help,
        )
        if event_type == "leftdown":
            self.master.show_border = False
        elif event_type in ("leftclick", "leftup"):
            self.master.show_border = True

        return response


class MoveWidget(Widget):
    """
    Move Widget it tasked with drawing the skew box and managing the events
    dealing with moving the selected object
    """

    def __init__(self, master, scene, size, drawsize, **kwargs):
        self.master = master
        self.scene = scene
        self.action_size = size
        self.half_x = size / 2
        self.half_y = size / 2
        self.drawhalf = drawsize / 2
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        self.start_x = None
        self.start_y = None
        self.last_x = None
        self.last_y = None
        Widget.__init__(
            self, scene, -self.half_x, -self.half_y, self.half_x, self.half_y, **kwargs
        )
        self.cursor = "sizing"
        self.total_dx = 0
        self.total_dy = 0
        self.update()

        # User-configurable setting for showing snap preview
        # Registers the setting and uses default True
        self.scene.context.setting(bool, "snap_preview", True)

        # Snap preview runtime cache and state
        self._snap_cache = None
        self._snap_preview = None  # dict with preview info or None
        self._last_preview_pos = (0.0, 0.0)
        self._last_preview_time = 0.0
        self._preview_min_move = 1e-3  # threshold for recompute

    def set_size(self, msize, rotsize):
        self.action_size = rotsize
        self.half_x = rotsize / 2
        self.half_y = rotsize / 2
        self.drawhalf = msize / 2
        self.left = -self.half_x
        self.right = self.half_x
        self.top = -self.half_y
        self.bottom = self.half_y
        self.update()

    def update(self):
        # Let's take into account small selections
        pos_x = (self.master.right + self.master.left) / 2
        pos_y = (self.master.bottom + self.master.top) / 2
        inner_wd = (self.master.right - self.master.left) - (
            0.5 + 0.5
        ) * 2 * self.drawhalf
        self.half_x = max(self.drawhalf, min(self.action_size, inner_wd) / 2)
        inner_ht = (self.master.bottom - self.master.top) - (
            0.5 + 0.5
        ) * 2 * self.drawhalf
        self.half_y = max(self.drawhalf, min(self.action_size, inner_ht) / 2)
        self.right = self.left + 2 * self.half_x
        self.bottom = self.top + 2 * self.half_y
        self.set_position(pos_x - self.half_x, pos_y - self.half_y)

    def create_duplicate(self):
        from copy import copy

        self.duplicated_elements = True
        # Iterate through list of selected elements, duplicate them
        context = self.scene.context
        elements = context.elements
        copy_nodes = []
        changed_nodes = []
        delta_wordlist = 1
        # The alt-drag will leave a copy in the original location.
        # This copy will lose all hierarchy attributes,
        # so let's do something basic at least
        to_be_copied = []
        emph_list = list(elements.elems(emphasized=True))
        for e in emph_list:
            if hasattr(e, "hidden") and e.hidden:
                continue
            if e.type in ("file", "group"):
                for f in e.children:
                    if not f.emphasized:
                        f.emphasized = True
                        emph_list.append(f)
        if not emph_list:
            return
        with elements.undoscope("Create copy"):
            for e in emph_list:
                new_parent = None
                org_parent = e.parent
                # First make sure we have all child elements as well
                if e.type in ("file", "group"):
                    for f in e.children:
                        if not f.emphasized:
                            f.emphasized = True

                if org_parent is elements.elem_branch:
                    new_parent = elements.elem_branch
                else:
                    # Are all other elements of this group selected as well?
                    # If yes create another group...
                    # (that would actually need to travel down?!)
                    all_selected = True
                    if not org_parent.emphasized:
                        for sibling in org_parent.children:
                            if not sibling.emphasized:
                                all_selected = False
                                break
                    if not all_selected:
                        new_parent = org_parent
                to_be_copied.append([e, org_parent, new_parent])

            for entry in to_be_copied:
                e = entry[0]
                oldparent = entry[1]
                newparent = entry[2]
                if newparent is None:
                    # Add a new group...
                    newlabel = (
                        "Copy"
                        if oldparent.label is None
                        else f"Copy of {oldparent.display_label()}"
                    )
                    newid = (
                        "Copy" if oldparent.id is None else f"Copy of {oldparent.id}"
                    )
                    newparent = oldparent.parent.add(
                        type="group",
                        label=newlabel,
                        id=newid,
                    )
                    # and amend all other entries
                    for others in to_be_copied:
                        if others[1] is oldparent and others[2] is None:
                            others[2] = newparent

                copy_node = copy(e)
                copy_node.emphasized = False
                copy_node.selected = False
                had_optional = False
                # Need to add stroke and fill, as copy will take the
                # default values for these attributes
                options = ["fill", "stroke", "wxfont"]
                for optional in options:
                    if hasattr(e, optional):
                        setattr(copy_node, optional, getattr(e, optional))
                options = [prop for prop in dir(e) if prop.startswith("mk")]
                for optional in options:
                    if hasattr(e, optional):
                        setattr(copy_node, optional, getattr(e, optional))
                        had_optional = True

                newparent.add_node(copy_node)
                copy_nodes.append(copy_node)
                # The copy remains at the same place, we are moving the originals,
                # to provide the impression we are doing the right thing, we amend
                # consequently the original.
                if elements.copy_increases_wordlist_references and hasattr(e, "text"):
                    e.text = elements.wordlist_delta(copy_node.text, delta_wordlist)
                    e.altered()
                    changed_nodes.append(e)
                elif elements.copy_increases_wordlist_references and hasattr(
                    e, "mktext"
                ):
                    e.mktext = elements.wordlist_delta(e.mktext, delta_wordlist)
                    e.altered()
                    changed_nodes.append(e)
                delta_wordlist = 1
                if had_optional:
                    for property_op in self.scene.context.kernel.lookup_all(
                        "path_updater/.*"
                    ):
                        property_op(self.scene.context, e)

            if changed_nodes:
                self.scene.context.signal("element_property_update", changed_nodes)
            elements.classify(copy_nodes)

    def process_draw(self, gc):
        # Draw little handle and optionally snap preview while dragging
        if not self.visible:
            return

        # Draw the usual handle only when not actively running the tool to keep drawing cheap
        if not self.master.tool_running:
            self.update()  # make sure coords are valid
            gc.SetPen(self.master.handle_pen)
            brush = wx.Brush(
                self.scene.colors.color_manipulation_handle, wx.BRUSHSTYLE_SOLID
            )
            gc.SetBrush(brush)
            gc.DrawRectangle(
                self.left + self.half_x - self.drawhalf,
                self.top + self.half_y - self.drawhalf,
                2 * self.drawhalf,
                2 * self.drawhalf,
            )

        # Draw snap preview even when tool_running to give immediate feedback
        try:
            enabled = self.scene.context.setting(bool, "snap_preview", True)
        except Exception:
            enabled = True
        if enabled and self._snap_preview is not None:
            try:
                pen = wx.Pen()
                pen.SetColour(wx.Colour(255, 0, 0, 128))
                gc.SetPen(pen)
                gc.SetBrush(wx.TRANSPARENT_BRUSH)
                p1 = self._snap_preview.get("from")
                p2 = self._snap_preview.get("to")
                if p1 is not None and p2 is not None:
                    gc.StrokeLine(p1[0], p1[1], p2[0], p2[1])
            except Exception:
                pass

    def hit(self):
        return HITCHAIN_HIT

    def check_for_magnets(self):
        if (
            not self.master.key_shift_pressed
        ):  # if Shift-Key pressed then ignore Magnets...
            elements = self.scene.context.elements
            b = elements._emphasized_bounds
            if b is None:
                return
            allowlockmove = elements.lock_allows_move
            dx, dy = self.scene.pane.revised_magnet_bound(b)
            self.total_dx += dx
            self.total_dy += dy
            if dx != 0 or dy != 0:
                with elements.undofree():
                    for e in elements.elems(emphasized=True):
                        if not e.can_move(allowlockmove):
                            continue
                        e.matrix.post_translate(dx, dy)
                        # We would normally not adjust the node properties,
                        # but the pure adjustment of the bbox is hopefully not hurting
                        e.translated(dx, dy, interim=False)
                    self.translate(dx, dy)
                elements.signal("updating")
                elements.update_bounds([b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy])

    # --- Snap preview helpers ---
    def _gather_snap_cache(self, b):
        """Gather static point caches at the start of a drag operation.

        This collects non-moving data (non-selected element points, grid points)
        and the selected element points at the start position so preview updates
        can be cheap and incremental.
        """
        if b is None:
            return
        matrix = self.scene.widget_root.scene_widget.matrix
        gap = self.scene.context.action_attract_len / get_matrix_scale(matrix)
        other_points = []
        selected_points = []
        for e in self.scene.context.elements.elems():
            if hasattr(e, "hidden") and e.hidden:
                continue
            target = selected_points if e.emphasized else other_points
            if not hasattr(e, "as_geometry"):
                continue
            geom = e.as_geometry()
            lastpt = None
            for idx, seg in enumerate(geom.segments[: geom.index]):
                seg_type = geom._segtype(seg)
                if seg_type == TYPE_END:
                    lastpt = None
                if seg_type in NON_GEOMETRY_TYPES:
                    continue
                startpt = seg[0]
                endpt = seg[4]
                if (
                    np.isnan(startpt.real)
                    or np.isnan(startpt.imag)
                    or np.isnan(endpt.real)
                    or np.isnan(endpt.imag)
                ):
                    continue
                midpt = geom.position(idx, 0.5)

                def add_it(pt, last):
                    if last is not None and pt == last:
                        return last
                    # Do not filter points by bounds during cache gathering; include all points to avoid missing candidates.
                    last = pt
                    target.append(pt)
                    return last

                lastpt = add_it(startpt, lastpt)
                if not e.emphasized:
                    lastpt = add_it(midpt, lastpt)
                lastpt = add_it(endpt, lastpt)

        # Filter grid points to those in the vicinity of the bounds to reduce work for preview
        try:
            grid_points = self.scene.pane.grid.grid_points or []
        except Exception:
            grid_points = []

        # Include all valid grid points in the cache (no bounds-based filtering).
        gap_grid = self.scene.context.grid_attract_len / get_matrix_scale(matrix)
        filtered_grid = []
        for gp in grid_points:
            try:
                gx, gy = gp
            except Exception:
                continue
            filtered_grid.append((float(gx), float(gy)))

        other_arr = np.asarray(other_points)
        sel_arr = np.asarray(selected_points)
        grid_arr = np.asarray(filtered_grid)

        # Build KD-trees when available for faster repeated NN queries
        other_tree = None
        grid_tree = None
        try:
            if _cKDTree is not None and other_arr.size > 0:
                # other_arr is an array of complex numbers; convert to Nx2
                other_xy = np.column_stack((other_arr.real, other_arr.imag))
                other_tree = _cKDTree(other_xy)
        except Exception:
            other_tree = None
        try:
            if _cKDTree is not None and grid_arr.size > 0:
                grid_xy = np.asarray(grid_arr, dtype=float)
                grid_tree = _cKDTree(grid_xy)
        except Exception:
            grid_tree = None

        self._snap_cache = {
            "other_points": other_arr,
            "selected_points_start": sel_arr,
            "grid_points": grid_arr,
            "other_tree": other_tree,
            "grid_tree": grid_tree,
            "start_total_dx": self.total_dx,
            "start_total_dy": self.total_dy,
            "grid_tick_distance": self.scene.pane.grid.tick_distance,
        }

    def _clear_snap_cache(self):
        self._snap_cache = None
        self._snap_preview = None

    def _update_snap_preview(self, b):
        """Compute the snap preview (fast) based on cached data and current delta."""
        if (
            self._snap_cache is not None
            and "grid_tick_distance" in self._snap_cache
            and self._snap_cache.get("grid_tick_distance")
            != self.scene.pane.grid.tick_distance
        ):
            self._clear_snap_cache()
        if self._snap_cache is None:
            self._gather_snap_cache(b)
        if self._snap_cache is None:
            self._snap_preview = None
            return

        # matrix and gaps
        matrix = self.scene.widget_root.scene_widget.matrix
        gap_point = self.scene.context.action_attract_len / get_matrix_scale(matrix)
        gap_grid = self.scene.context.grid_attract_len / get_matrix_scale(matrix)

        # Compute shifted selected points
        dsx = self.total_dx - self._snap_cache.get("start_total_dx", 0)
        dsy = self.total_dy - self._snap_cache.get("start_total_dy", 0)
        sel_start = self._snap_cache.get("selected_points_start")
        if sel_start is None or sel_start.size == 0:
            sel_shifted = None
        else:
            # sel_start is an array of complex
            sel_shifted = sel_start + (dsx + 1j * dsy)

        # Compute shifted selection points + center for grid snapping
        center = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
        if sel_shifted is not None and sel_shifted.size > 0:
            sp_points = np.column_stack((sel_shifted.real, sel_shifted.imag))
            selected_corners_shifted = np.vstack([sp_points, center])
        else:
            selected_corners_shifted = np.array([center])

        # 0) Magnet preview precedence: if there's a magnet action, show magnet preview and skip other checks
        try:
            dx_m, dy_m = self.scene.pane.revised_magnet_bound(b)
        except Exception:
            dx_m, dy_m = 0, 0
        # Respect Shift modifier: if shift is pressed we should not show magnet preview
        if (dx_m != 0 or dy_m != 0) and (
            not getattr(self.master, "key_shift_pressed", False)
        ):
            pane = self.scene.pane
            # Compute anchor selection same as existing logic
            if pane.grid.tick_distance > 0:
                s = f"{pane.grid.tick_distance}{self.scene.context.units_name}"
                try:
                    len_tick = float(Length(s))
                except Exception:
                    len_tick = 1
            else:
                len_tick = 1
            if pane._magnet_attraction is None:
                pane._magnet_attraction = 1
            attraction_len = (
                1 / 3 * pane._magnet_attraction * pane._magnet_attraction * len_tick
            )

            # If Pane provides magnet_attracted_x/y use the same logic as revised_magnet_bound to pick anchors.
            if hasattr(pane, "magnet_attracted_x") and hasattr(
                pane, "magnet_attracted_y"
            ):
                delta_x1, x1 = pane.magnet_attracted_x(b[0], pane.magnet_attract_x)
                delta_x2, x2 = pane.magnet_attracted_x(b[2], pane.magnet_attract_x)
                delta_x3, x3 = pane.magnet_attracted_x(
                    (b[0] + b[2]) / 2, pane.magnet_attract_c
                )
                delta_y1, y1 = pane.magnet_attracted_y(b[1], pane.magnet_attract_y)
                delta_y2, y2 = pane.magnet_attracted_y(b[3], pane.magnet_attract_y)
                delta_y3, y3 = pane.magnet_attracted_y(
                    (b[1] + b[3]) / 2, pane.magnet_attract_c
                )

                # Choose x anchor
                if (
                    delta_x3 < delta_x1
                    and delta_x3 < delta_x2
                    and delta_x3 < attraction_len
                    and x3 is not None
                ):
                    anchor_x = (b[0] + b[2]) / 2
                elif (
                    delta_x1 < delta_x2
                    and delta_x1 < delta_x3
                    and delta_x1 < attraction_len
                    and x1 is not None
                ):
                    anchor_x = b[0]
                elif (
                    delta_x2 < delta_x1
                    and delta_x2 < delta_x3
                    and delta_x2 < attraction_len
                    and x2 is not None
                ):
                    anchor_x = b[2]
                else:
                    anchor_x = (b[0] + b[2]) / 2

                # Choose y anchor
                if (
                    delta_y3 < delta_y1
                    and delta_y3 < delta_y2
                    and delta_y3 < attraction_len
                    and y3 is not None
                ):
                    anchor_y = (b[1] + b[3]) / 2
                elif (
                    delta_y1 < delta_y2
                    and delta_y1 < delta_y3
                    and delta_y1 < attraction_len
                    and y1 is not None
                ):
                    anchor_y = b[1]
                elif (
                    delta_y2 < delta_y1
                    and delta_y2 < delta_y3
                    and delta_y2 < attraction_len
                    and y2 is not None
                ):
                    anchor_y = b[3]
                else:
                    anchor_y = (b[1] + b[3]) / 2
            else:
                # Pane doesn't expose helpers (tests/mocks); default to center anchor
                anchor_x = (b[0] + b[2]) / 2
                anchor_y = (b[1] + b[3]) / 2

            src = (anchor_x, anchor_y)
            dst = (anchor_x + dx_m, anchor_y + dy_m)
            self._snap_preview = {"type": "magnet", "from": src, "to": dst}
            return

        # 1 & 2) Compute both point and grid snapping and pick the closer candidate (if within thresholds)
        best = None
        best_dist = None
        # Point snapping
        try:
            if (
                self.scene.context.snap_points
                and sel_shifted is not None
                and self._snap_cache.get("other_points") is not None
            ):
                op = self._snap_cache.get("other_points")
                sp = sel_shifted
                if op.size > 0 and sp.size > 0:
                    # If cursor is provided, prefer matching the selected point nearest the cursor
                    tree = (
                        self._snap_cache.get("other_tree")
                        if self._snap_cache is not None
                        else None
                    )
                    try:
                        # Global nearest pair: compare all selected points to all other points and pick the minimum
                        if tree is not None:
                            pts = np.column_stack((sp.real, sp.imag))
                            dists, idxs = tree.query(pts, k=1)
                            min_i = int(np.argmin(dists))
                            min_dist = float(dists[min_i])
                            if min_dist < gap_point:
                                min_j = int(idxs[min_i])
                                pt1_p = op[min_j]
                                pt2_p = sp[min_i]
                                best = {
                                    "type": "point",
                                    "from": (pt2_p.real, pt2_p.imag),
                                    "to": (pt1_p.real, pt1_p.imag),
                                }
                                best_dist = min_dist
                        else:
                            dist_p, pt1_p, pt2_p = shortest_distance(op, sp, False)
                            if dist_p is not None and dist_p < gap_point:
                                best = {
                                    "type": "point",
                                    "from": (pt2_p.real, pt2_p.imag),
                                    "to": (pt1_p.real, pt1_p.imag),
                                }
                                best_dist = dist_p
                    except Exception:
                        dist_p = None
        except Exception:
            dist_p = None
        # Grid snapping: consider all selected vertices + center
        try:
            if self.scene.context.snap_grid and b is not None:
                gp = self._snap_cache.get("grid_points")
                if gp is not None and len(gp) > 0:
                    # Compare selected vertices + center against grid points
                    np_other = np.asarray(gp)
                    sp = selected_corners_shifted
                    tree = (
                        self._snap_cache.get("grid_tree")
                        if self._snap_cache is not None
                        else None
                    )
                    try:
                        if tree is not None:
                            pts = sp.astype(float)
                            dists, idxs = tree.query(pts, k=1)
                            min_i = int(np.argmin(dists))
                            min_dist = float(dists[min_i])
                            if min_dist < gap_grid:
                                min_j = int(idxs[min_i])
                                pt1_g = np_other[min_j]
                                pt2_g = sp[min_i]
                                if best is None or min_dist < best_dist:
                                    best = {
                                        "type": "grid",
                                        "from": (pt2_g[0], pt2_g[1]),
                                        "to": (pt1_g[0], pt1_g[1]),
                                    }
                                    best_dist = min_dist
                        else:
                            # Use vertices + center for distance computation
                            sel_xy = sp.astype(float)
                            dist_g, pt1_g, pt2_g = shortest_distance(
                                np_other, sel_xy, True
                            )
                            if dist_g is not None and dist_g < gap_grid:
                                if best is None or dist_g < best_dist:
                                    best = {
                                        "type": "grid",
                                        "from": (pt2_g[0], pt2_g[1]),
                                        "to": (pt1_g[0], pt1_g[1]),
                                    }
                                    best_dist = dist_g
                    except Exception:
                        dist_g = None
                else:
                    # Fallback to corners+center for compatibility
                    selected_corners = (
                        (b[0], b[1]),
                        (b[2], b[1]),
                        (b[0], b[3]),
                        (b[2], b[3]),
                        ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2),
                    )
                    np_other = np.asarray(gp) if gp is not None else np.asarray([])
                    np_selected = np.asarray(selected_corners)
                    if np_other.size > 0:
                        try:
                            dist_g, pt1_g, pt2_g = shortest_distance(
                                np_other, np_selected, True
                            )
                            tree = (
                                self._snap_cache.get("grid_tree")
                                if self._snap_cache is not None
                                else None
                            )
                            if tree is not None:
                                sel = np.column_stack(
                                    (np_selected.real, np_selected.imag)
                                )
                                dists, idxs = tree.query(sel, k=1)
                                min_i = int(np.argmin(dists))
                                min_dist = float(dists[min_i])
                                if min_dist < gap_grid:
                                    min_j = int(idxs[min_i])
                                    pt1_g = np_other[min_j]
                                    pt2_g = np_selected[min_i]
                                    if best is None or min_dist < best_dist:
                                        best = {
                                            "type": "grid",
                                            "from": (pt2_g[0], pt2_g[1]),
                                            "to": (pt1_g[0], pt1_g[1]),
                                        }
                                        best_dist = min_dist
                            else:
                                if dist_g is not None and dist_g < gap_grid:
                                    if best is None or dist_g < best_dist:
                                        best = {
                                            "type": "grid",
                                            "from": (pt2_g[0], pt2_g[1]),
                                            "to": (pt1_g[0], pt1_g[1]),
                                        }
                                        best_dist = dist_g
                        except Exception:
                            dist_g = None
        except Exception:
            dist_g = None

        if best is not None:
            self._snap_preview = best
            return

        # None
        self._snap_preview = None

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        """
        Change the position of the selected elements.
        """

        def move_to(dx, dy, interim=True):
            if dx == 0 and dy == 0:
                return
            self.total_dx += dx
            self.total_dy += dy
            b = elements._emphasized_bounds
            if b is None:
                b = elements.selected_area()
                if b is None:
                    # There is no emphasized bounds or selected area.
                    return
            allowlockmove = elements.lock_allows_move
            with elements.undofree():
                for e in elements.elems(emphasized=True):
                    if not e.can_move(allowlockmove):
                        continue
                    e.matrix.post_translate(dx, dy)
                    # We would normally not adjust the node properties,
                    # but the pure adjustment of the bbox is hopefully not hurting
                    e.translated(dx, dy, interim=interim)
            self.translate(dx, dy)
            elements.signal("updating")
            elements.update_bounds([b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy])

        elements = self.scene.context.elements
        elements.set_start_time("movewidget")
        lastdx = 0
        lastdy = 0
        if nearest_snap is None:
            # print ("Took last snap instead...")
            nearest_snap = self.scene.pane.last_snap
        # sweeping it under the rug for now until we have figured out a way
        # to move a defined reference and not an arbitrary point on the
        # Widget area.
        # nearest_snap = None
        if nearest_snap is not None and event != TOOL_RESULT_ABORT:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            # print(
            #     f"Move: pos={position[0]:.2f}, {position[1]:.2f}, "
            #     + f"old={position[2]:.2f}, {position[3]:.2f}, "
            #     + f"dx={position[4]:.2f}, dy={position[5]:.2f}"
            # )
            # print(
            #     f"snap: pos={nearest_snap[0]:.2f}, {nearest_snap[1]:.2f}, "
            #     + f"screen={nearest_snap[2]:.2f}, {nearest_snap[3]:.2f}"
            # )
            lastdx = nearest_snap[0] - position[0]
            lastdy = nearest_snap[1] - position[1]
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]
            # print(
            #     f"New: pos={position[0]:.2f}, {position[1]:.2f}, "
            #     + f"dx={position[4]:.2f}, dy={position[5]:.2f}"
            # )

        if event == TOOL_RESULT_END:  # end
            # Clear any transient preview state
            self._snap_preview = None
            self._snap_cache = None
            # Cleanup - we check for:
            # a) Would a point of the selection snap to a point of the non-selected elements? If yes we are done
            # b) Use the distance of the 4 corners and the center to a grid point -> take the smallest distance
            # c) Regular snap-check
            # d) Use magnet lines

            # Use chunked nearest neighbor search implemented in shortest_distance_chunked
            # to avoid memory blowup for large point sets.

            b = elements._emphasized_bounds
            if b is None:
                b = elements.selected_area()

            matrix = self.scene.widget_root.scene_widget.matrix

            # Collect candidate snaps (point, grid, magnet) and pick the closest
            candidates = []

            # Point snaps
            if (
                self.scene.context.snap_points
                and (not modifiers or "shift" not in modifiers)
                and b is not None
            ):
                gap = self.scene.context.action_attract_len / get_matrix_scale(matrix)
                other_points = []
                selected_points = []
                for e in self.scene.context.elements.elems():
                    if hasattr(e, "hidden") and e.hidden:
                        continue

                    target = selected_points if e.emphasized else other_points
                    if not hasattr(e, "as_geometry"):
                        continue
                    geom = e.as_geometry()
                    lastpt = None
                    for idx, seg in enumerate(geom.segments[: geom.index]):
                        seg_type = geom._segtype(seg)
                        if seg_type == TYPE_END:
                            lastpt = None
                        if seg_type in NON_GEOMETRY_TYPES:
                            continue
                        startpt = seg[0]
                        endpt = seg[4]
                        if (
                            np.isnan(startpt.real)
                            or np.isnan(startpt.imag)
                            or np.isnan(endpt.real)
                            or np.isnan(endpt.imag)
                        ):
                            print(
                                f"Strange, encountered within selectionwidget a segment with type: {seg_type} and start={startpt}, end={endpt} - coming from element type {e.type}\nPlease inform the developers"
                            )
                            continue

                        midpt = geom.position(idx, 0.5)

                        def add_it(pt, last):
                            if last is not None and pt == last:
                                return last
                            xx = pt.real
                            yy = pt.imag
                            ignore = (
                                xx < b[0] - gap
                                or xx > b[2] + gap
                                or yy < b[1] - gap
                                or yy > b[3] + gap
                            )
                            if not ignore:
                                last = pt
                                target.append(pt)
                            return last

                        lastpt = add_it(startpt, lastpt)
                        lastpt = add_it(midpt, lastpt)
                        lastpt = add_it(endpt, lastpt)
                total_points = len(other_points) + len(selected_points)
                if (
                    other_points is not None
                    and selected_points is not None
                    and len(other_points) > 0
                    and len(selected_points) > 0
                    and total_points <= MAX_POINTS_FOR_SNAPPING
                ):
                    try:
                        np_other = np.asarray(other_points)
                        np_selected = np.asarray(selected_points)
                        # Use KD-tree for the final snap nearest-neighbour if available
                        if (
                            _cKDTree is not None
                            and np_other.size > 0
                            and np_selected.size > 0
                        ):
                            try:
                                other_xy = np.column_stack(
                                    (np_other.real, np_other.imag)
                                )
                                tree = _cKDTree(other_xy)
                                # Global nearest pair: compare all selected points to all other points and pick the minimum
                                sel_xy = np.column_stack(
                                    (np_selected.real, np_selected.imag)
                                )
                                dists, idxs = tree.query(sel_xy, k=1)
                                min_i = int(np.argmin(dists))
                                min_dist = float(dists[min_i])
                                if min_dist < gap:
                                    min_j = int(idxs[min_i])
                                    pt1 = np_other[min_j]
                                    pt2 = np_selected[min_i]
                                    dx = float(pt1.real - pt2.real)
                                    dy = float(pt1.imag - pt2.imag)
                                    candidates.append(
                                        {
                                            "type": "point",
                                            "dist": min_dist,
                                            "dx": dx,
                                            "dy": dy,
                                        }
                                    )
                            except Exception:
                                # Fallback to chunked approach
                                dist, pt1, pt2 = shortest_distance(
                                    np_other, np_selected, False
                                )
                                if (
                                    dist is not None
                                    and dist < gap
                                    and pt1 is not None
                                    and pt2 is not None
                                ):
                                    dx = float(pt1.real - pt2.real)
                                    dy = float(pt1.imag - pt2.imag)
                                    candidates.append(
                                        {
                                            "type": "point",
                                            "dist": float(dist),
                                            "dx": dx,
                                            "dy": dy,
                                        }
                                    )
                        else:
                            dist, pt1, pt2 = shortest_distance(
                                np_other, np_selected, False
                            )
                            if (
                                dist is not None
                                and dist < gap
                                and pt1 is not None
                                and pt2 is not None
                            ):
                                dx = float(pt1.real - pt2.real)
                                dy = float(pt1.imag - pt2.imag)
                                candidates.append(
                                    {
                                        "type": "point",
                                        "dist": float(dist),
                                        "dx": dx,
                                        "dy": dy,
                                    }
                                )
                    except MemoryError:
                        pass

            # Grid snaps
            if (
                self.scene.context.snap_grid
                and (not modifiers or "shift" not in modifiers)
                and b is not None
            ):
                gap = self.scene.context.grid_attract_len / get_matrix_scale(matrix)
                selected_points = []
                for e in elements.elems(emphasized=True):
                    if hasattr(e, "hidden") and e.hidden:
                        continue
                    if not hasattr(e, "as_geometry"):
                        continue
                    geom = e.as_geometry()
                    lastpt = None
                    for idx, seg in enumerate(geom.segments[: geom.index]):
                        seg_type = geom._segtype(seg)
                        if seg_type == TYPE_END:
                            lastpt = None
                        if seg_type in NON_GEOMETRY_TYPES:
                            continue
                        startpt = seg[0]
                        endpt = seg[4]
                        if (
                            np.isnan(startpt.real)
                            or np.isnan(startpt.imag)
                            or np.isnan(endpt.real)
                            or np.isnan(endpt.imag)
                        ):
                            continue

                        def add_it(pt, last):
                            if last is not None and pt == last:
                                return last
                            last = pt
                            selected_points.append(pt)
                            return last

                        lastpt = add_it(startpt, lastpt)
                        lastpt = add_it(endpt, lastpt)
                # Add center
                center = ((b[0] + b[2]) / 2) + ((b[1] + b[3]) / 2) * 1j
                selected_points.append(center)
                other_points = self.scene.pane.grid.grid_points
                if (
                    other_points is not None
                    and selected_points is not None
                    and len(other_points) > 0
                    and len(selected_points) > 0
                    and len(other_points) + len(selected_points)
                    <= MAX_POINTS_FOR_SNAPPING
                ):
                    dist = None
                    if (
                        _cKDTree is not None
                        and len(other_points) > 0
                        and len(selected_points) > 0
                    ):
                        try:
                            p1_xy = np.column_stack(
                                (np_selected.real, np_selected.imag)
                            )
                            tree = _cKDTree(other_points)
                            dists, idxs = tree.query(p1_xy, k=1)
                            min_i = int(np.argmin(dists))
                            min_dist = float(dists[min_i])
                            if min_dist < gap:
                                pt1 = other_points[idxs[min_i]]
                                pt2 = selected_points[min_i]
                                dx = float(pt1[0] - pt2.real)
                                dy = float(pt1[1] - pt2.imag)
                                candidates.append(
                                    {
                                        "type": "grid",
                                        "dist": min_dist,
                                        "dx": dx,
                                        "dy": dy,
                                    }
                                )
                                dist = min_dist  # Indicate success
                        except Exception:
                            pass
                    if dist is None:
                        try:
                            np_other = np.asarray(other_points)
                            np_selected = np.asarray(selected_points)
                            dist, pt1, pt2 = shortest_distance(
                                np_other, np_selected, True
                            )
                        except MemoryError:
                            dist, pt1, pt2 = None, None, None

                    if dist is not None and dist < gap:
                        if pt1 is not None and pt2 is not None:
                            try:
                                dx = float(pt1[0] - pt2.real)
                                dy = float(pt1[1] - pt2.imag)
                                candidates.append(
                                    {
                                        "type": "grid",
                                        "dist": float(dist),
                                        "dx": dx,
                                        "dy": dy,
                                    }
                                )
                            except (IndexError, TypeError, AttributeError):
                                pass

            # Magnet snaps take precedence:
            # if a magnet action exists apply it
            # and skip other snap tests
            if not self.master.key_shift_pressed:
                dx_m, dy_m = self.scene.pane.revised_magnet_bound(b)
                if dx_m != 0 or dy_m != 0:
                    try:
                        self.total_dx = 0
                        self.total_dy = 0
                        move_to(float(dx_m), float(dy_m), interim=False)
                    except Exception:
                        pass
                    # We applied the magnet snap, skip other snap logic
                    update_elements(self.scene)
                    return

            # Choose best candidate
            if candidates:
                best = min(candidates, key=lambda c: c["dist"])
                try:
                    self.total_dx = 0
                    self.total_dy = 0
                    move_to(best["dx"], best["dy"], interim=False)
                except Exception:
                    pass
            else:
                if nearest_snap is None:
                    move_to(lastdx, lastdy, interim=False)
                else:
                    move_to(
                        lastdx - self.master.offset_x,
                        lastdy - self.master.offset_y,
                        interim=False,
                    )

            # if abs(self.total_dx) + abs(self.total_dy) > 1e-3:
            #     # Did we actually move?
            #     # Remember this, it is still okay
            #     bx0, by0, bx1, by1 = elements._emphasized_bounds
            #     for e in elements.flat(types=elem_group_nodes, emphasized=True):
            #         try:
            #             # e.modified()
            #             e.translated(self.total_dx, self.total_dy)
            #         except AttributeError:
            #             pass
            #     # .translated will set the scene emphasized bounds dirty, that's not needed, so...
            #     elements.update_bounds([bx0, by0, bx1, by1])
            update_elements(self.scene)
        elif event == TOOL_RESULT_ABORT:  # abort / start of drag
            if modifiers and "alt" in modifiers:
                self.create_duplicate()
            self.scene.pane.modif_active = True
            # Normally this would happen automagically in the background, but as we are going
            # to suppress undo during the execution of this tool (to allow to go back to the
            # very starting point) we need to set the recovery point ourselves.
            # Hint for translate check: _("Element shifted")
            elements.undo.mark("Element shifted")
            self.total_dx = 0
            self.total_dy = 0
            # Initialize snap preview cache at the start of drag.
            try:
                b = elements._emphasized_bounds
                if b is None:
                    b = elements.selected_area()
                self._gather_snap_cache(b)
            except Exception:
                self._snap_cache = None
            # Reset preview
            self._snap_preview = None
        elif event == TOOL_RESULT_MOVE:  # move
            move_to(dx, dy, interim=True)
            # Update preview intelligently (avoid recomputing too often)
            try:
                enabled = self.scene.context.setting(bool, "snap_preview", True)
            except Exception:
                enabled = True
            if enabled:
                b = elements._emphasized_bounds
                if b is None:
                    b = elements.selected_area()
                # Only update if bounds exist
                if b is not None:
                    # Throttle updates: recompute if movement passes threshold
                    dx_elapsed = abs(
                        self.total_dx
                        - (
                            self._snap_cache.get("start_total_dx")
                            if self._snap_cache
                            else 0
                        )
                    )
                    dy_elapsed = abs(
                        self.total_dy
                        - (
                            self._snap_cache.get("start_total_dy")
                            if self._snap_cache
                            else 0
                        )
                    )
                    if (
                        abs(self.total_dx - self._last_preview_pos[0])
                        + abs(self.total_dy - self._last_preview_pos[1])
                        > self._preview_min_move
                    ) or (time.time() - self._last_preview_time) > 0.05:
                        try:
                            self._update_snap_preview(b)
                            self._last_preview_pos = (self.total_dx, self.total_dy)
                            self._last_preview_time = time.time()
                            # Request refresh so preview is visible
                            self.scene.request_refresh()
                        except Exception:
                            pass
        self.scene.request_refresh()
        elements.set_end_time("movewidget")

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "move"
        # Translation hint: _("Move element")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext="Move element",
        )


class MoveRotationOriginWidget(Widget):
    """
    Move Rotation Origin Widget it tasked with drawing the rotation center indicator and managing the events
    dealing with moving the rotation center for the selected object
    """

    def __init__(self, master, scene, size, **kwargs):
        self.master = master
        self.scene = scene
        self.half = size / 2
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        self.at_center = True
        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.cursor = "rotmove"
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        try:
            # if 0 < abs(self.master.rotation_cx - (self.master.left + self.master.right)/2) <= 0.0001:
            #    print ("Difference for x too small")
            #    self.master.rotation_cx = (self.master.left + self.master.right)/2
            # if 0 < abs(self.master.rotation_cy - (self.master.top + self.master.bottom)/2) <= 0.0001:
            #    print ("Difference for y too small")
            #    self.master.rotation_cy = (self.master.top + self.master.bottom)/2
            pos_x = self.master.rotation_cx
            pos_y = self.master.rotation_cy
            self.set_position(pos_x - self.half, pos_y - self.half)
        except TypeError:
            # print ("There was nothing established as rotation center")
            pass

    def process_draw(self, gc):
        # This one gets painted always.
        if self.master.tool_running or not self.visible:  # We don't need that overhead
            return

        self.update()  # make sure coords are valid
        gc.SetPen(self.master.handle_pen)
        gc.SetBrush(wx.TRANSPARENT_BRUSH)
        gc.StrokeLine(
            self.left,
            self.top + self.height / 2.0,
            self.right,
            self.bottom - self.height / 2.0,
        )
        gc.StrokeLine(
            self.left + self.width / 2.0,
            self.top,
            self.right - self.width / 2.0,
            self.bottom,
        )
        gc.DrawEllipse(self.left, self.top, self.width, self.height)

    def tool(self, position, nearest_snap, dx, dy, event=0, modifiers=None):
        """
        Change the rotation-center of the selected elements.
        """
        lastdx = 0
        lastdy = 0
        if nearest_snap is None:
            # print ("Took last snap instead...")
            nearest_snap = self.scene.pane.last_snap
        if nearest_snap is not None:
            # Position is space_pos:
            # 0, 1: current x, y
            # 2, 3: last pos x, y
            # 4, 5: current - last
            position = list(position)
            lastdx = nearest_snap[0] - position[0]
            lastdy = nearest_snap[1] - position[1]
            position[0] = nearest_snap[0]
            position[1] = nearest_snap[1]
            position[4] = position[0] - position[2]
            position[5] = position[1] - position[3]

        if event == TOOL_RESULT_END:  # end
            self.master.rotation_cx += lastdx - self.master.offset_x
            self.master.rotation_cy += lastdy - self.master.offset_y
            self.master.invalidate_rot_center()
            self.scene.pane.modif_active = False
        elif event == TOOL_RESULT_ABORT:  # abort
            self.scene.pane.modif_active = True
            return
        elif event == TOOL_RESULT_MOVE:  # move
            self.master.rotation_cx += dx
            self.master.rotation_cy += dy
            self.master.invalidate_rot_center()
        self.scene.request_refresh()

    def hit(self):
        return HITCHAIN_HIT

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "rotcenter"
        if event_type == "doubleclick":
            self.master.rotation_cx = None
            self.master.rotation_cy = None
            self.master.invalidate_rot_center()
            self.scene.request_refresh()
            return RESPONSE_CONSUME
        # Translation hint: _("Move rotation center")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext="Move rotation center",
        )


class ReferenceWidget(Widget):
    """
    Reference Widget is tasked with drawing the reference box and managing the events
    dealing with assigning / revoking the reference status
    """

    def __init__(
        self, master, scene, size, is_reference_object, show_if_not_active, **kwargs
    ):
        self.master = master
        self.scene = scene
        self.half = size / 2
        if is_reference_object:
            self.half = self.half * 1.5
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.show_if_not_active = show_if_not_active
        if self.show_if_not_active is None:
            self.show_if_not_active = False
        self.is_reference_object = is_reference_object
        self.uniform = False
        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.cursor = "reference"
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        if self.is_reference_object:
            self.half = self.half * 1.5
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        offset_x = self.half if self.master.handle_outside else 0
        # offset_y = self.half if self.master.handle_outside else 0
        pos_x = self.master.left - offset_x
        pos_y = self.master.top + 1 / 4 * (self.master.bottom - self.master.top)
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:  # We don't need that overhead
            return
        if not (self.show_if_not_active or self.is_reference_object):
            return
        self.update()  # make sure coords are valid
        pen = wx.Pen()
        if self.is_reference_object:
            bgcol = wx.YELLOW
            fgcol = wx.RED
        else:
            bgcol = self.scene.colors.color_manipulation_handle
            fgcol = wx.BLACK
        pen.SetColour(bgcol)
        try:
            pen.SetWidth(self.master.line_width)
        except TypeError:
            pen.SetWidth(int(self.master.line_width))
        pen.SetStyle(wx.PENSTYLE_SOLID)
        gc.SetPen(pen)
        brush = wx.Brush(bgcol, wx.BRUSHSTYLE_SOLID)
        gc.SetBrush(brush)
        gc.DrawEllipse(self.left, self.top, self.width, self.height)
        # gc.DrawRectangle(self.left, self.top, self.width, self.height)
        try:
            font = wx.Font(
                0.75 * self.master.font_size,
                wx.FONTFAMILY_SWISS,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        except TypeError:
            font = wx.Font(
                int(0.75 * self.master.font_size),
                wx.FONTFAMILY_SWISS,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        gc.SetFont(font, fgcol)
        symbol = "r"
        (t_width, t_height) = gc.GetTextExtent(symbol)
        gc.DrawText(
            symbol,
            (self.left + self.right) / 2 - t_width / 2,
            (self.top + self.bottom) / 2 - t_height / 2,
        )

    def hit(self):
        return HITCHAIN_HIT

    def tool(
        self,
        position=None,
        nearest_snap=None,
        dx=None,
        dy=None,
        event=0,
        modifiers=None,
    ):  # Don't need all arguments, just for compatibility with pattern
        """
        Toggle the Reference Status of the selected elements
        """
        elements = self.scene.context.elements
        if event == TOOL_RESULT_ABORT:  # abort
            # Nothing to do...
            return
        elif event == TOOL_RESULT_END:  # leftup, leftclick
            if self.is_reference_object:
                self.scene.pane.reference_object = None
            else:
                for e in elements.elems(emphasized=True):
                    try:
                        # First object
                        self.scene.pane.reference_object = e
                        break
                    except AttributeError:
                        pass
            self.scene.context.signal("reference")
        self.scene.request_refresh()

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "reference"
        # Translation hint: _("Toggle reference status of element")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=nearest_snap,
            modifiers=modifiers,
            helptext="Toggle reference status of element",
            optimize_drawing=False,
        )


class LockWidget(Widget):
    """
    Lock Widget is tasked with drawing the lock box and managing the events
    dealing with revoking the lock status by clicking it
    """

    def __init__(self, master, scene, size, **kwargs):
        self.master = master
        self.scene = scene
        # Slightly bigger to be clearly seen
        self.half = size / 2
        self.was_lb_raised = False
        self.hovering = False
        self.save_width = 0
        self.save_height = 0
        self.uniform = False
        Widget.__init__(
            self, scene, -self.half, -self.half, self.half, self.half, **kwargs
        )
        self.cursor = "arrow"
        self.update()

    def set_size(self, msize, rotsize):
        self.half = msize / 2
        self.left = -self.half
        self.right = self.half
        self.top = -self.half
        self.bottom = self.half
        self.update()

    def update(self):
        offset_x = self.half if self.master.handle_outside else 0
        pos_x = self.master.right - offset_x
        pos_y = self.master.top + 1 / 4 * (self.master.bottom - self.master.top)
        self.set_position(pos_x - self.half, pos_y - self.half)

    def process_draw(self, gc):
        if self.master.tool_running or not self.visible:
            # We don't need that overhead
            return
        self.update()  # make sure coords are valid
        pen = wx.Pen()
        bgcol = wx.YELLOW
        fgcol = wx.RED
        pen.SetColour(bgcol)
        try:
            pen.SetWidth(self.master.line_width)
        except TypeError:
            pen.SetWidth(int(self.master.line_width))
        pen.SetStyle(wx.PENSTYLE_SOLID)
        gc.SetPen(pen)
        brush = wx.Brush(bgcol, wx.BRUSHSTYLE_SOLID)
        gc.SetBrush(brush)
        gc.DrawEllipse(self.left, self.top, self.width, self.height)
        # gc.DrawRectangle(self.left, self.top, self.width, self.height)
        try:
            font = wx.Font(
                0.75 * self.master.font_size,
                wx.FONTFAMILY_SWISS,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        except TypeError:
            font = wx.Font(
                int(0.75 * self.master.font_size),
                wx.FONTFAMILY_SWISS,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        gc.SetFont(font, fgcol)
        symbol = "L"
        (t_width, t_height) = gc.GetTextExtent(symbol)
        gc.DrawText(
            symbol,
            (self.left + self.right) / 2 - t_width / 2,
            (self.top + self.bottom) / 2 - t_height / 2,
        )

    def hit(self):
        return HITCHAIN_HIT

    def tool(
        self,
        position=None,
        nearest_snap=None,
        dx=None,
        dy=None,
        event=0,
        modifiers=None,
    ):  # Don't need all arguments, just for compatibility with pattern
        """
        Toggle the Reference Status of the selected elements
        """
        elements = self.scene.context.elements
        if event == TOOL_RESULT_ABORT:  # abort
            # Nothing to do...
            return
        elif event == TOOL_RESULT_END:  # leftup, leftclick
            data = list(elements.elems(emphasized=True))
            for e in data:
                e.lock = False
            self.scene.context.signal("element_property_update", data)
        self.scene.request_refresh()

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        s_me = "lock"
        # Translation hint: _("Remove the 'locked' status of the element")
        return process_event(
            widget=self,
            widget_identifier=s_me,
            window_pos=window_pos,
            space_pos=space_pos,
            event_type=event_type,
            nearest_snap=None,
            modifiers=modifiers,
            helptext="Remove the 'locked' status of the element",
            optimize_drawing=False,
        )


class RefAlign(wx.Dialog):
    """
    RefAlign provides a dialog how to align the selection in respect to the reference object
    """

    def __init__(self, context, *args, **kwds):
        self.cancelled = False
        self.option_pos = ""
        self.option_scale = ""
        self.option_rotate = False
        self.context = context
        _ = context._
        # begin wxGlade: RefAlign.__init__
        kwds["style"] = kwds.get("style", 0) | wx.DEFAULT_DIALOG_STYLE
        wx.Dialog.__init__(self, *args, **kwds)
        self.context.themes.set_window_colors(self)
        self.SetTitle(_("Align Selection"))

        sizer_ref_align = wx.BoxSizer(wx.VERTICAL)

        label_1 = wxStaticText(
            self,
            wx.ID_ANY,
            _("Move the selection into the reference object and scale the elements."),
        )
        sizer_ref_align.Add(label_1, 0, wx.EXPAND, 0)

        sizer_options = wx.BoxSizer(wx.HORIZONTAL)
        sizer_ref_align.Add(sizer_options, 0, wx.EXPAND, 0)

        sizer_pos = StaticBoxSizer(self, wx.ID_ANY, _("Position"), wx.HORIZONTAL)
        sizer_options.Add(sizer_pos, 1, wx.EXPAND, 0)

        sizer_6 = wx.BoxSizer(wx.VERTICAL)
        sizer_pos.Add(sizer_6, 1, wx.EXPAND, 0)

        self.radio_btn_1 = wx.RadioButton(self, wx.ID_ANY, "TL", style=wx.RB_GROUP)
        self.radio_btn_1.SetToolTip(
            _("Align the selection to the top left corner of the reference object")
        )
        sizer_6.Add(self.radio_btn_1, 0, 0, 0)

        self.radio_btn_4 = wx.RadioButton(self, wx.ID_ANY, "L")
        self.radio_btn_4.SetToolTip(
            _("Align the selection to the left side of the reference object")
        )
        sizer_6.Add(self.radio_btn_4, 0, 0, 0)

        self.radio_btn_7 = wx.RadioButton(self, wx.ID_ANY, "BL")
        self.radio_btn_7.SetToolTip(
            _("Align the selection to the bottom left corner of the reference object")
        )
        sizer_6.Add(self.radio_btn_7, 0, 0, 0)

        sizer_7 = wx.BoxSizer(wx.VERTICAL)
        sizer_pos.Add(sizer_7, 1, wx.EXPAND, 0)

        self.radio_btn_2 = wx.RadioButton(self, wx.ID_ANY, "T")
        self.radio_btn_2.SetToolTip(
            _("Align the selection to the upper side of the reference object")
        )
        sizer_7.Add(self.radio_btn_2, 0, 0, 0)

        self.radio_btn_5 = wx.RadioButton(self, wx.ID_ANY, "C")
        sizer_7.Add(self.radio_btn_5, 0, 0, 0)

        self.radio_btn_8 = wx.RadioButton(self, wx.ID_ANY, "B")
        self.radio_btn_8.SetToolTip(
            _("Align the selection to the lower side of the reference object")
        )
        sizer_7.Add(self.radio_btn_8, 0, 0, 0)

        sizer_8 = wx.BoxSizer(wx.VERTICAL)
        sizer_pos.Add(sizer_8, 1, wx.EXPAND, 0)

        self.radio_btn_3 = wx.RadioButton(self, wx.ID_ANY, "TR")
        self.radio_btn_3.SetToolTip(
            _("Align the selection to the top right corner of the reference object")
        )
        sizer_8.Add(self.radio_btn_3, 0, 0, 0)

        self.radio_btn_6 = wx.RadioButton(self, wx.ID_ANY, "R")
        sizer_8.Add(self.radio_btn_6, 0, 0, 0)

        self.radio_btn_9 = wx.RadioButton(self, wx.ID_ANY, "BR")
        self.radio_btn_9.SetToolTip(
            _("Align the selection to the bottom right corner of the reference object")
        )
        sizer_8.Add(self.radio_btn_9, 0, 0, 0)

        sizer_scale = StaticBoxSizer(self, wx.ID_ANY, _("Scaling"), wx.VERTICAL)
        sizer_options.Add(sizer_scale, 1, wx.EXPAND, 0)

        self.radio_btn_10 = wx.RadioButton(
            self, wx.ID_ANY, _("Unchanged"), style=wx.RB_GROUP
        )
        self.radio_btn_10.SetToolTip(_("Don't change the size of the object(s)"))
        sizer_scale.Add(self.radio_btn_10, 0, 0, 0)

        self.radio_btn_11 = wx.RadioButton(self, wx.ID_ANY, _("Fit"))
        self.radio_btn_11.SetToolTip(
            _("Scale the object(s) while maintaining the aspect ratio")
        )
        sizer_scale.Add(self.radio_btn_11, 0, 0, 0)

        self.radio_btn_12 = wx.RadioButton(self, wx.ID_ANY, _("Squeeze"))
        self.radio_btn_11.SetToolTip(
            _("Scale the object(s) to make them fit the target")
        )
        sizer_scale.Add(self.radio_btn_12, 0, 0, 0)

        self.chk_auto_rotate = wxCheckBox(self, wx.ID_ANY, _("Autorotate"))
        self.chk_auto_rotate.SetToolTip(
            _("Rotate the object(s) if they would fit better")
        )
        sizer_scale.Add(self.chk_auto_rotate, 0, 0, 0)

        sizer_buttons = wx.StdDialogButtonSizer()
        sizer_ref_align.Add(sizer_buttons, 0, wx.ALIGN_RIGHT | wx.ALL, 4)

        self.button_OK = wxButton(self, wx.ID_OK, "")
        self.button_OK.SetToolTip(_("Align and scale the elements"))
        self.button_OK.SetDefault()
        sizer_buttons.AddButton(self.button_OK)

        self.button_CANCEL = wxButton(self, wx.ID_CANCEL, "")
        self.button_CANCEL.SetToolTip(_("Close without applying any changes"))
        sizer_buttons.AddButton(self.button_CANCEL)

        sizer_buttons.Realize()

        self.SetSizer(sizer_ref_align)
        sizer_ref_align.Fit(self)

        self.SetAffirmativeId(self.button_OK.GetId())
        self.SetEscapeId(self.button_CANCEL.GetId())

        self.Layout()

        self.radio_btn_10.SetValue(True)  # Unchanged
        self.radio_btn_5.SetValue(True)  # center

    def results(self):
        self.cancelled = False
        self.option_rotate = self.chk_auto_rotate.GetValue()
        if self.radio_btn_10.GetValue():
            self.option_scale = "none"
        elif self.radio_btn_11.GetValue():
            self.option_scale = "fit"
        if self.radio_btn_12.GetValue():
            self.option_scale = "squeeze"
        for radio in (
            self.radio_btn_1,
            self.radio_btn_2,
            self.radio_btn_3,
            self.radio_btn_4,
            self.radio_btn_5,
            self.radio_btn_6,
            self.radio_btn_7,
            self.radio_btn_8,
            self.radio_btn_9,
        ):
            if radio.GetValue():
                s = radio.GetLabel()
                self.option_pos = s.lower()
                break
        return self.option_pos, self.option_scale, self.option_rotate


class SelectionWidget(Widget):
    """
    Selection Widget it tasked with drawing the selection box and managing the events
    dealing with moving, resizing and altering the selected object.
    """

    def __init__(self, scene, **kwargs):
        Widget.__init__(self, scene, all=False, **kwargs)
        self.selection_pen = wx.Pen()
        self.selection_pen.SetColour(self.scene.colors.color_manipulation)
        # self.selection_pen.SetStyle(wx.PENSTYLE_DOT)
        self.selection_pen.SetStyle(wx.PENSTYLE_LONG_DASH)
        # want to have sharp edges
        self.selection_pen.SetJoin(wx.JOIN_MITER)

        self.handle_pen = wx.Pen()
        self.handle_pen.SetColour(self.scene.colors.color_manipulation_handle)
        self.handle_pen.SetStyle(wx.PENSTYLE_SOLID)
        # want to have sharp edges
        self.handle_pen.SetJoin(wx.JOIN_MITER)
        fact = dip_size(self.scene.pane, 100, 100)
        self.font_size_factor = (fact[0] + fact[1]) / 100 * 0.5

        self.gc = None
        self.reset_variables()
        self.modifiers = []

        msize = 10
        rotsize = 10
        self.child_widgets = {}
        self.child_widgets["border"] = BorderWidget(
            master=self, scene=self.scene, layer=self.layer
        )
        self.add_widget(-1, self.child_widgets["border"])
        self.child_widgets["reference"] = ReferenceWidget(
            master=self,
            scene=self.scene,
            size=msize,
            is_reference_object=self.is_ref,
            show_if_not_active=False,
            layer=self.layer,
        )
        self.add_widget(-1, self.child_widgets["reference"])

        self.child_widgets["move"] = MoveWidget(
            master=self,
            scene=self.scene,
            size=rotsize,
            drawsize=msize,
            layer=self.layer,
        )
        self.add_widget(-1, self.child_widgets["move"])

        self.child_widgets["skew_x"] = SkewWidget(
            master=self,
            scene=self.scene,
            is_x=True,
            size=2 / 3 * msize,
            layer=self.layer,
        )
        self.child_widgets["skew_y"] = SkewWidget(
            master=self,
            scene=self.scene,
            is_x=False,
            size=2 / 3 * msize,
            layer=self.layer,
        )
        self.add_widget(-1, self.child_widgets["skew_x"])
        self.add_widget(-1, self.child_widgets["skew_y"])

        for i in range(4):
            self.child_widgets[f"rotation_{i}"] = RotationWidget(
                master=self,
                scene=self.scene,
                index=i,
                size=rotsize,
                inner=msize,
                layer=self.layer,
            )
            self.add_widget(-1, self.child_widgets[f"rotation_{i}"])
        self.child_widgets["rotation_org"] = MoveRotationOriginWidget(
            master=self,
            scene=self.scene,
            size=msize,
            layer=self.layer,
        )
        self.add_widget(-1, self.child_widgets["rotation_org"])
        for i in range(4):
            self.child_widgets[f"corner_{i}"] = CornerWidget(
                master=self,
                scene=self.scene,
                index=i,
                size=msize,
                layer=self.layer,
            )
            self.add_widget(-1, self.child_widgets[f"corner_{i}"])
            self.child_widgets[f"side_{i}"] = SideWidget(
                master=self,
                scene=self.scene,
                index=i,
                size=msize,
                layer=self.layer,
            )
            self.add_widget(-1, self.child_widgets[f"side_{i}"])
        self.child_widgets["lock"] = LockWidget(
            master=self,
            scene=self.scene,
            size=1.5 * msize,
            layer=self.layer,
        )
        self.add_widget(-1, self.child_widgets["lock"])

    def init(self, context):
        context.listen("ext-modified", self.external_modification)
        # Option to draw selection Handle outside of box to allow for better visibility

    def final(self, context):
        context.unlisten("ext-modified", self.external_modification)

    @property
    def key_shift_pressed(self):
        return self.modifiers and "shift" in self.modifiers

    @property
    def key_control_pressed(self):
        return self.modifiers and "ctrl" in self.modifiers

    @property
    def key_alt_pressed(self):
        return self.modifiers and "alt" in self.modifiers

    def reset_variables(self):
        self.modifiers = []
        self.save_width = None
        self.save_height = None
        self.cursor = "arrow"
        self.uniform = True
        self.rotation_cx = None
        self.rotation_cy = None
        self.rotated_angle = 0
        self.total_delta_x = 0
        self.total_delta_y = 0
        self.offset_x = 0
        self.offset_y = 0

        self.was_lb_raised = False
        self.hovering = False
        self.use_handle_rotate = True
        self.use_handle_skew = True
        self.use_handle_size = True
        self.use_handle_move = True
        self.keep_rotation = None
        self.line_width = 0
        self.font_size = 0
        self.tool_running = False
        self.active_tool = "none"
        self.single_element = True
        self.is_ref = False
        self.show_border = True
        self.last_angle = None
        self.start_angle = None

    @property
    def handle_outside(self):
        return self.scene.context.outer_handles

    def hit(self):
        elements = self.scene.context.elements
        try:
            bounds = elements.selected_area()
        except AttributeError:
            bounds = None
        if bounds is not None:
            self.left = bounds[0]
            self.top = bounds[1]
            self.right = bounds[2]
            self.bottom = bounds[3]
            if self.rotation_cx is None:
                # print ("Update rot-center")
                self.rotation_cx = (self.left + self.right) / 2
                self.rotation_cy = (self.top + self.bottom) / 2

            # print ("Hit and delegate")
            return HITCHAIN_HIT_AND_DELEGATE
        else:
            self.reset_variables()
            return HITCHAIN_DELEGATE

    def move_selection_to_ref(self, pos="c"):
        refob = self.scene.pane.reference_object

        elements = self.scene.context.elements
        if refob is None:
            return
        alignbounds = refob.bounds
        if "l" in pos:
            posx = "min"
        elif "r" in pos:
            posx = "max"
        else:
            posx = "center"
        if "t" in pos:
            posy = "min"
        elif "b" in pos:
            posy = "max"
        else:
            posy = "center"

        data = [e for e in elements.elems(emphasized=True) if e != refob]

        elements.align_elements(data, alignbounds, posx, posy, False)
        for q in data:
            q.invalidated_node()

    def rotate_elements_if_needed(self, doit):
        if not doit:
            return
        refob = self.scene.pane.reference_object
        if refob is None:
            return
        bb = refob.bounds
        elements = self.scene.context.elements
        cc = elements.selected_area()

        ratio_ref = (bb[3] - bb[1]) > (bb[2] - bb[0])
        ratio_sel = (cc[3] - cc[1]) > (cc[2] - cc[0])
        if ratio_ref != ratio_sel:
            angle = math.tau / 4
            cx = (cc[0] + cc[2]) / 2
            cy = (cc[1] + cc[3]) / 2
            dx = cc[2] - cc[0]
            dy = cc[3] - cc[1]
            for e in elements.elems(emphasized=True):
                if e.lock:
                    continue
                e.matrix.post_rotate(angle, cx, cy)
                if e.type == "elem image":
                    e._cache = None
            # Update bbox
            cc[0] = cx - dy / 2
            cc[2] = cc[0] + dy
            cc[1] = cy - dx / 2
            cc[3] = cc[1] + dx
            elements.update_bounds([cc[0], cc[1], cc[2], cc[3]])

    def scale_selection_to_ref(self, method="none"):
        refob = self.scene.pane.reference_object
        if refob is None:
            return
        bb = refob.bounds
        elements = self.scene.context.elements
        cc = elements.selected_area()

        if bb is None or cc is None:
            return
        try:
            pass  # b_ratio = (bb[2] - bb[0]) / (bb[3] - bb[1])
            # c_ratio = (cc[2] - cc[0]) / (cc[3] - cc[1])
        except ZeroDivisionError:
            return
        if method == "fit":
            scalex = (bb[2] - bb[0]) / (cc[2] - cc[0])
            scaley = (bb[3] - bb[1]) / (cc[3] - cc[1])
            scalex = min(scalex, scaley)
            scaley = scalex
        elif method == "squeeze":
            scalex = (bb[2] - bb[0]) / (cc[2] - cc[0])
            scaley = (bb[3] - bb[1]) / (cc[3] - cc[1])
        else:
            return
        dx = (scalex - 1) * (cc[2] - cc[0])
        dy = (scaley - 1) * (cc[3] - cc[1])

        if abs(scalex) < NEARLY_ZERO or abs(scaley) <= NEARLY_ZERO:
            return
        # No undo of interim steps
        with elements.undofree():
            for e in elements.elems(emphasized=True):
                if e.lock:
                    continue
                if e is not refob:
                    e.matrix.post_scale(scalex, scaley, cc[0], cc[1])
                    e.scaled(sx=scalex, sy=scaley, ox=cc[0], oy=cc[1])
        elements.signal("updating")
        elements.update_bounds([cc[0], cc[1], cc[2] + dx, cc[3] + dy])

    def show_reference_align_dialog(self, event):
        opt_pos = None
        opt_scale = None
        opt_rotate = False
        dlgRefAlign = RefAlign(self.scene.context, None, wx.ID_ANY, "")
        # SetTopWindow(self.dlgRefAlign)
        if dlgRefAlign.ShowModal() == wx.ID_OK:
            opt_pos, opt_scale, opt_rotate = dlgRefAlign.results()
            # print ("I would need to align to: %s and scale to: %s" % (opt_pos, opt_scale))
        dlgRefAlign.Destroy()
        if opt_pos is not None:
            self.rotate_elements_if_needed(opt_rotate)
            if opt_scale is not None:
                self.scale_selection_to_ref(opt_scale)
            self.move_selection_to_ref(opt_pos)
            self.scene.context.elements.validate_selected_area()
            self.scene.request_refresh()

    def become_reference(self, event):
        for e in self.scene.context.elements.elems(emphasized=True):
            try:
                # First object
                self.scene.pane.reference_object = e
                break
            except AttributeError:
                pass
        # print("set...")
        self.scene.context.signal("reference")
        self.scene.request_refresh()

    def delete_reference(self, event):
        self.scene.pane.reference_object = None
        self.scene.context.signal("reference")
        # Simplify, no complete scene refresh required
        # print("unset...")
        self.scene.request_refresh()

    def create_menu(self, gui, node, elements):
        if node is None:
            return
        if hasattr(node, "node"):
            node = node.node
        menu = create_menu_for_node(gui, node, elements)
        # Now check whether we have a reference object
        reference_object = self.scene.pane.reference_object
        if reference_object is not None:
            # Okay, just let's make sure we are not doing this on the refobject itself...
            for e in self.scene.context.elements.elems(emphasized=True):
                # Here we acknowledge the lock-status of an element
                if reference_object is e:
                    reference_object = None
                    break

        _ = self.scene.context._
        submenu = None
        # Add Manipulation menu
        if reference_object is not None:
            submenu = wx.Menu()
            item1 = submenu.Append(wx.ID_ANY, _("Align to reference object"))
            gui.Bind(wx.EVT_MENU, self.show_reference_align_dialog, id=item1.GetId())

        if self.single_element and not self.is_ref:
            if submenu is None:
                submenu = wx.Menu()
            item2 = submenu.Append(wx.ID_ANY, _("Become reference object"))
            gui.Bind(wx.EVT_MENU, self.become_reference, id=item2.GetId())
        if self.scene.pane.reference_object is not None:
            if submenu is None:
                submenu = wx.Menu()
            item3 = submenu.Append(wx.ID_ANY, _("Clear reference object"))
            gui.Bind(wx.EVT_MENU, self.delete_reference, id=item3.GetId())

        if submenu is not None:
            menu.AppendSubMenu(submenu, _("Reference Object"))

        if menu.MenuItemCount != 0:
            gui.PopupMenu(menu)
            menu.Destroy()

    def event(
        self,
        window_pos=None,
        space_pos=None,
        event_type=None,
        nearest_snap=None,
        modifiers=None,
        **kwargs,
    ):
        if self.scene.pane.suppress_selection:
            return RESPONSE_CHAIN
        self.modifiers = modifiers
        elements = self.scene.context.elements
        if event_type == "hover_start":
            if space_pos is not None and self.contains(space_pos[0], space_pos[1]):
                self.hovering = True
                self.scene.context.signal("statusmsg", "")
                self.tool_running = False

        elif event_type in ("hover_end", "lost"):
            self.scene.cursor(self.cursor)
            self.hovering = False
            if space_pos is not None:
                for subwidget in self:
                    if (
                        hasattr(subwidget, "hovering")
                        and subwidget.hovering
                        and not subwidget.contains(space_pos[0], space_pos[1])
                    ):
                        subwidget.hovering = False
            self.scene.cursor("arrow")
            self.scene.context.signal("statusmsg", "")
        elif event_type == "hover":
            if self.hovering:
                self.scene.cursor(self.cursor)
            # self.tool_running = False
            self.scene.context.signal("statusmsg", "")
            if space_pos is not None:
                for subwidget in self:
                    if (
                        hasattr(subwidget, "hovering")
                        and subwidget.hovering
                        and not subwidget.contains(space_pos[0], space_pos[1])
                    ):
                        subwidget.hovering = False
                        self.scene.cursor("arrow")
                        self.scene.context.signal("statusmsg", "")

        elif event_type in ("leftdown", "leftup", "leftclick", "move"):
            # self.scene.pane.tool_active = False
            pass
        elif event_type == "rightdown":
            self.scene.pane.tool_active = False
            self.scene.pane.modif_active = False
            smallest = bool(self.scene.context.select_smallest) != bool(
                modifiers and "ctrl" in modifiers
            )
            use_files = bool(self.scene.context.file_selection)
            elements.set_emphasized_by_position(
                space_pos,
                keep_old_selection=False,
                use_smallest=smallest,
                exit_over_selection=True,
                force_filenodes_too=use_files,
            )
            # Check if reference is still existing
            self.scene.pane.validate_reference()
            if not elements.has_emphasis():
                return RESPONSE_CONSUME
            self.create_menu(
                self.scene.context.gui, elements.top_element(emphasized=True), elements
            )
            return RESPONSE_CONSUME
        elif event_type == "doubleclick":
            self.scene.pane.tool_active = False
            self.scene.pane.modif_active = False
            smallest = bool(self.scene.context.select_smallest) != bool(
                modifiers and "ctrl" in modifiers
            )
            use_files = bool(self.scene.context.file_selection)
            elements.set_emphasized_by_position(
                space_pos,
                keep_old_selection=False,
                use_smallest=smallest,
                exit_over_selection=True,
                force_filenodes_too=use_files,
            )
            elements.signal("activate_selected_nodes", 0)
            return RESPONSE_CONSUME

        return RESPONSE_CHAIN

    def invalidate_rot_center(self):
        self.keep_rotation = None

    def check_rot_center(self):
        if self.keep_rotation is None:
            if self.rotation_cx is None:
                # print ("Update rot-center")
                self.rotation_cx = (self.left + self.right) / 2
                self.rotation_cy = (self.top + self.bottom) / 2
            cx = (self.left + self.right) / 2
            cy = (self.top + self.bottom) / 2
            value = (
                abs(self.rotation_cx - cx) < POSITION_THRESHOLD
                and abs(self.rotation_cy - cy) < POSITION_THRESHOLD
            )
            self.keep_rotation = value
            # if value:
            #    print ("RotHandle still in center")
            # else:
            #    print ("RotHandle (%.1f, %.1f) outside center (%.1f, %.1f)" % (self.rotation_cx, self.rotation_cy, cx, cy))

    def external_modification(self, origin, *args):
        # Reset rotation center...
        self.keep_rotation = True
        self.rotation_cx = None
        self.rotation_cy = None

    def process_draw(self, gc):
        """
        Draw routine for drawing the selection box.
        """
        self.hide_all_widgets()
        self.gc = gc
        if self.scene.context.draw_mode & DRAW_MODE_SELECTION != 0:
            return
        if self.scene.pane.suppress_selection:
            return
        context = self.scene.context
        try:
            self.use_handle_rotate = context.enable_sel_rotate
            self.use_handle_skew = context.enable_sel_skew
            self.use_handle_size = context.enable_sel_size
            self.use_handle_move = context.enable_sel_move
        except AttributeError:
            # Stuff has not yet been defined...
            self.use_handle_rotate = True
            self.use_handle_skew = True
            self.use_handle_size = True
            self.use_handle_move = True

        elements = self.scene.context.elements
        bounds = elements.selected_area()
        matrix = self.scene.widget_root.scene_widget.matrix
        if bounds is not None:
            try:
                factor = math.sqrt(abs(matrix.determinant))
                self.line_width = 2.0 / factor
                self.font_size = 12.0 / factor * self.font_size_factor
            except ZeroDivisionError:
                matrix.reset()
                return
            self.selection_pen.SetColour(self.scene.colors.color_manipulation)
            self.handle_pen.SetColour(self.scene.colors.color_manipulation_handle)
            try:
                self.selection_pen.SetWidth(int(self.line_width))
                self.handle_pen.SetWidth(int(0.75 * self.line_width))
            except TypeError:
                self.selection_pen.SetWidth(int(self.line_width))
                self.handle_pen.SetWidth(int(0.75 * self.line_width))
            self.font_size = max(
                self.font_size, 1.0
            )  # Mac does not allow values lower than 1.
            try:
                font = wx.Font(
                    int(self.font_size),
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            except (TypeError, AssertionError):
                font = wx.Font(
                    int(self.font_size),
                    wx.FONTFAMILY_SWISS,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            gc.SetFont(font, self.scene.colors.color_manipulation)
            gc.SetPen(self.selection_pen)
            self.left = bounds[0]
            self.top = bounds[1]
            self.right = bounds[2]
            self.bottom = bounds[3]
            self.check_rot_center()
            if self.keep_rotation:  # Reset it to center....
                cx = (self.left + self.right) / 2
                cy = (self.top + self.bottom) / 2
                # self.keep_rotation = False
                self.rotation_cx = cx
                self.rotation_cy = cy

            # Code for reference object - single object? And identical to reference?
            self.is_ref = False
            self.single_element = True
            is_locked = True
            no_scale = True
            no_skew = True
            no_move = True
            no_rotate = True
            for idx, e in enumerate(elements.elems(emphasized=True)):
                if e is self.scene.pane.reference_object:
                    self.is_ref = True
                # Is one of the elements locked?
                is_locked = is_locked and e.lock
                no_scale = no_scale and not e.can_scale
                no_skew = no_skew and not e.can_skew
                no_move = no_move and not e.can_move()
                no_rotate = no_rotate and not e.can_rotate
                if idx > 0:
                    self.single_element = False

            if not self.single_element:
                self.is_ref = False

            # Add all subwidgets in Inverse Order
            msize = 5 * self.line_width
            rotsize = 3 * msize
            show_skew_x = self.use_handle_skew
            show_skew_y = self.use_handle_skew
            # Let's check whether there is enough room...
            # Top and bottom handle are overlapping by 1/2, middle 1, skew 2/3
            if (self.bottom - self.top) < (0.5 + 1 + 0.5 + 1) * msize:
                show_skew_y = False
            if (self.right - self.left) < (0.5 + 1 + 0.5 + 1) * msize:
                show_skew_x = False

            self.child_widgets["reference"].is_reference_object = self.is_ref
            # Border Widget is fine as is
            for widget in self.child_widgets.values():
                widget.set_size(msize, rotsize)
            self.child_widgets["border"].visible = self.show_border
            self.child_widgets["reference"].visible = (
                self.single_element and self.use_handle_size
            )
            maymove = not is_locked or elements.lock_allows_move
            self.child_widgets["move"].visible = self.use_handle_move and maymove
            self.child_widgets["skew_x"].visible = show_skew_x and not no_skew
            self.child_widgets["skew_y"].visible = show_skew_y and not no_skew
            for i in range(4):
                self.child_widgets[f"rotation_{i}"].visible = (
                    self.use_handle_rotate and not no_rotate
                )
            self.child_widgets["rotation_org"].visible = (
                self.use_handle_rotate and not no_rotate
            )
            for i in range(4):
                self.child_widgets[f"corner_{i}"].visible = (
                    self.use_handle_size and not no_scale
                )
                self.child_widgets[f"side_{i}"].visible = (
                    self.use_handle_size and not no_scale
                )
            self.child_widgets["lock"].visible = is_locked
            # for key, widget in self.child_widgets.items():
            #     print(f"Widget {key} visible: {widget.visible}")

    def hide_all_widgets(self):
        for widget in self.child_widgets.values():
            widget.visible = False
