# Analysis — Feb 2026

AI coding session analysis for Pratilipi engineering (Jan–Feb 2026).

## Structure

```
analysis-feb2026/
├── README.md              ← you are here
├── docker-compose.yml     ← local Postgres for session data
│
├── utils/                 ← shared DB/message/pricing utilities
│
├── analyzers/             ← quantitative pipeline (a01–c02)
│   ├── runner.py          ← entry point: runs all analyzers per user
│   ├── base.py            ← session data loading, message streams
│   ├── config.py          ← DB connection config
│   ├── helpers.py         ← tool categorization, error detection
│   ├── llm_cache.py       ← gpt-4o response cache (SHA256 → JSON)
│   ├── a01–a10_*.py       ← metric analyzers (interruptions, errors, etc.)
│   ├── b01–b04_*.py       ← LLM-powered analyzers (task classification, etc.)
│   ├── c01–c02_*.py       ← aggregate analyzers (developer profile, team trends)
│   └── output/            ← (gitignored) per-user JSON results
│
├── qualitative/           ← qualitative deep-dive analysis
│   ├── qualitative_analysis.py  ← entry point: 7-cell script
│   └── dumps/             ← (gitignored) scored sessions, narratives, reports
│
├── research/              ← exploratory notebooks (data shape, patterns, etc.)
│   ├── 00_data_shape.py … 06_interrupt_output_taxonomy.py
│   └── summary.md
│
├── session_viewer/        ← interactive session viewer
│   ├── export_data.py     ← exports session data for the viewer
│   └── viewer/            ← HTML/JS viewer app
│
├── dashboard-v2/          ← React dashboard for quantitative metrics
│
└── output/                ← shared artifacts (pricing data, etc.)
```

## How to Run

### 1. Quantitative analyzers
```bash
cd analyzers/
python runner.py          # runs a01–c02 for all users, outputs to analyzers/output/
```

### 2. Qualitative analysis
```bash
cd qualitative/
python qualitative_analysis.py   # scores sessions, generates gpt-4o narratives + reports
# outputs to qualitative/dumps/
```

### 3. Session viewer
```bash
cd session_viewer/
python export_data.py     # exports data
cd viewer/ && npm run dev  # starts local viewer
```

### 4. Dashboard
```bash
cd dashboard-v2/
npm install && npm run dev
```

## Prerequisites

- `.prod.env` at repo root with `QC_TRACE_DSN` and `OPENAI_API_KEY`
- Python 3.11+ with `psycopg`, `pandas`, `openai`, `python-dotenv`
- Node.js for dashboard/viewer
