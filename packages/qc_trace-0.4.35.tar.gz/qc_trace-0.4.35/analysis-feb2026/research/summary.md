# Session‑view research overview

This folder hosts a set of short research scripts that interrogate the raw session data powering the viewer.

1. `00_data_shape.py`: enumerates the index metadata, counts sessions/messages/tools per source, and reports distributions such as message types, interruptions, and result statuses that establish the data shape before deeper dives.
2. `01_sample_user_prompts.py`: samples the very first user message per source, strips system noise (XML prefixes, file dumps, compaction banners), and summarizes prompt length/style differences between Claude Code, Codex CLI, Gemini CLI, and Cursor.
3. `02_interruption_patterns.py`: clusters every captured interruption by relative position, interrupted tool, and post‑interrupt user guidance while printing contextual excerpts.
4. `03_autonomy_and_streaks.py`: measures AI autonomy via tool streak lengths, detects Codex system prefixes in user prompts, and counts agent apologies/error tracebacks after tool runs.
5. `04_undo_revert_and_ai_behavior.py`: flags undo/revert requests, AI self‑corrections, clarification questions, and git commands so you can study how users or the assistant retract or rework actions.
6. `05_session_per_source_example.py`: prints one full session per source so you can see the exact sequence of user/assistant/tool events without opening raw JSONL files.
7. `06_interrupt_output_taxonomy.py`: classifies the textual content of interrupt tool results, highlighting when corrective guidance is kept inside `tool_result.output` versus pushed into a follow‑up user message.

Run these scripts with the repository virtualenv (`.venv/bin/python3`) so they can read `viewer/public/data`. The summary here helps future analysts pick the right script quickly.
