#!/bin/bash
# Multi-agent orchestration for developer analytics dashboard
# Usage: ./docs/run1-14022026/run_agents.sh [iterations]

set -euo pipefail

# Allow launching claude from within another claude session
unset CLAUDECODE 2>/dev/null || true

ITERATIONS="${1:-100}"
RUN_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$RUN_DIR/../.." && pwd)"
ANALYSIS_DIR="$PROJECT_DIR/analysis-14022026"

# Run dir = docs, logs, state, changelog (documentation)
LOG_DIR="$RUN_DIR/logs"
STATE_DIR="$RUN_DIR/state"

# Analysis dir = scripts, output JSON, dashboard app (project files)
OUTPUT_DIR="$ANALYSIS_DIR/output"
DASHBOARD_DIR="$ANALYSIS_DIR/dashboard"
SCRIPTS_DIR="$ANALYSIS_DIR/scripts"

mkdir -p "$LOG_DIR" "$STATE_DIR" "$OUTPUT_DIR" "$DASHBOARD_DIR" "$SCRIPTS_DIR"

# Initialize state file if not exists
if [ ! -f "$STATE_DIR/AGENT_STATE.md" ]; then
  cat > "$STATE_DIR/AGENT_STATE.md" << 'INITSTATE'
# Agent State

## Status: STARTING
## Iteration: 0
## Phase: VP-wow (targeting VP of Engineering reaction first)

## What exists:
- Local Postgres with all trace data (sessions, messages, tool_calls, tool_results, token_usage)
- Existing analysis notebooks in notebooks/003-focused-analytics/
- Connection utils in notebooks/utils/

## Next steps:
- Analysis agent: query local DB, compute metrics, produce JSON data files in analysis-14022026/output/ and analysis-14022026/dashboard/public/data/
- Frontend agent: scaffold Vite + React + Tailwind dashboard in analysis-14022026/dashboard/, keep dev server running on port 5173
- Reviewer: verify quality meets "oh fuck what" bar, check dev server is live

## Done so far:
(nothing yet)
INITSTATE
fi

# Initialize changelog if not exists
if [ ! -f "$STATE_DIR/CHANGELOG.md" ]; then
  cat > "$STATE_DIR/CHANGELOG.md" << 'INITLOG'
# Iteration Changelog

Each agent documents what they did per iteration. The reviewer verifies and scores.

---
INITLOG
fi

echo "=== Developer Analytics Dashboard — Multi-Agent Run ==="
echo "Iterations: $ITERATIONS"
echo "Run dir (docs/state/logs): $RUN_DIR"
echo "Analysis dir (scripts/output/dashboard): $ANALYSIS_DIR"
echo ""

for i in $(seq 1 "$ITERATIONS"); do
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  ITERATION $i / $ITERATIONS  ($(date '+%H:%M:%S'))"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # --- PAUSE CHECK ---
  if [ -f "$RUN_DIR/PAUSE" ]; then
    echo ""
    echo "  PAUSED (found $RUN_DIR/PAUSE file)"
    echo "  To resume: rm $RUN_DIR/PAUSE"
    echo "  Waiting..."
    while [ -f "$RUN_DIR/PAUSE" ]; do
      sleep 5
    done
    echo "  Resumed!"
  fi

  # --- ALL 3 AGENTS IN PARALLEL ---
  echo "[analysis] Starting..."
  claude -p \
    --dangerously-skip-permissions \
    "You are the ANALYSIS agent for a developer analytics project.

ENVIRONMENT:
- Working directory: $PROJECT_DIR
- Local Postgres: postgresql://localdev:localdev@localhost:15432/qc_trace
- CRITICAL: ONLY use LOCAL data. NEVER connect to prod. The local utils enforce this automatically.
- Python: $PROJECT_DIR/.venv/bin/python
- Utils: $ANALYSIS_DIR/utils/ (connection.py defaults to .local.env, sessions.py, messages.py, tokens.py, tools.py)
- Reference notebooks: notebooks/003-focused-analytics/002-dev-report.py and 003-qualitative-report.py
- Analysis scripts go in: $SCRIPTS_DIR/
- When writing scripts, use: sys.path.insert(0, '$ANALYSIS_DIR') then 'from utils.connection import init, query_df'

READ THESE FILES FIRST:
1. $STATE_DIR/AGENT_STATE.md — current state and what to do next
2. $STATE_DIR/REVIEW_FEEDBACK.md — reviewer feedback from last iteration (if exists)
3. $PROJECT_DIR/notebooks/003-focused-analytics/CONTEXT.md — full context on DB schema, metrics, conventions

DATA FILTER (CRITICAL):
- ONLY analyze data where org LIKE 'pratilipi%' (pratilipi-ai, pratilipi-platform, etc.)
- All SQL queries MUST include: WHERE s.org LIKE 'pratilipi%' (or equivalent join filter)
- Do NOT analyze data from other orgs — privacy constraint

YOUR JOB:
- Query the local Postgres DB and compute analytics
- Write any analysis scripts to $SCRIPTS_DIR/
- Produce JSON data files in $OUTPUT_DIR/ that the frontend agent can consume
- The JSON should contain pre-computed metrics, chart data, tables, insights
- Think about what would make a VP of Engineering say 'oh fuck what' — surface surprising patterns, wasteful behaviors, productivity killers, hidden insights
- Reference the metrics framework in CONTEXT.md but go BEYOND it — find the stories in the data
- NOTE: You are running IN PARALLEL with the frontend and reviewer agents. They are working on the PREVIOUS iteration's data. Focus on improving/adding data for the NEXT iteration.

OUTPUT:
- Write analysis scripts to $SCRIPTS_DIR/
- Write JSON files to $OUTPUT_DIR/ (e.g., overview.json, session_metrics.json, developer_profiles.json, insights.json, chart_data.json)
- ALSO copy all JSON files to $DASHBOARD_DIR/public/data/ (create the dir if needed) so the Vite dashboard can fetch them
- Update $STATE_DIR/AGENT_STATE.md with what you produced and what's next

DOCUMENTATION (MANDATORY):
Append to $STATE_DIR/CHANGELOG.md a section for this iteration:
## Iteration $i — Analysis Agent
- What you did (specific queries, metrics computed, files created/modified)
- What data you produced and why
- What you discovered that was surprising or noteworthy
- Decisions you made and why

ITERATION: $i / $ITERATIONS
Do NOT ask questions. Do as much as you can. Be thorough." \
    > "$LOG_DIR/iter-${i}-analysis.log" 2>&1 &
  PID_ANALYSIS=$!

  echo "[frontend] Starting..."
  claude -p \
    --dangerously-skip-permissions \
    "You are the FRONTEND agent for a developer analytics dashboard.

ENVIRONMENT:
- Working directory: $PROJECT_DIR
- Dashboard app directory: $DASHBOARD_DIR (Vite + React app)
- Analysis JSON data: $OUTPUT_DIR/ (produced by the analysis agent)
- Node/npm available on the system

READ THESE FILES FIRST:
1. $STATE_DIR/AGENT_STATE.md — current state and reviewer feedback
2. $STATE_DIR/REVIEW_FEEDBACK.md — reviewer feedback from last iteration (if exists)
3. $PROJECT_DIR/notebooks/003-focused-analytics/CONTEXT.md — domain context
4. All JSON files in $OUTPUT_DIR/ — this is your data source (may be updated mid-iteration by the analysis agent running in parallel)
5. The existing dashboard code in $DASHBOARD_DIR/ (if it exists already)

YOUR JOB:
- Build a Vite + React dashboard app in $DASHBOARD_DIR/
- On the FIRST iteration: scaffold with 'npm create vite@latest' inside $DASHBOARD_DIR/ (or init manually), install dependencies (recharts, framer-motion, lucide-react or similar), set up the project structure
- On SUBSEQUENT iterations: iterate on the existing app — add sections, improve visuals, fix reviewer feedback
- The dev server should always be running. After any changes, make sure 'npm run dev' works. Start it if not already running (port 5173)
- Copy JSON data files from $OUTPUT_DIR/ into $DASHBOARD_DIR/public/data/ so the app can fetch them
- NOTE: You are running IN PARALLEL with the analysis and reviewer agents. Use whatever JSON data currently exists in $OUTPUT_DIR/. If files are missing, build components that gracefully handle missing data.

DESIGN REQUIREMENTS:
- Dark, modern theme — think Linear, Vercel dashboard, or Raycast aesthetic
- Consistent design system: one font family, one color palette, consistent spacing/radius
- Use a charting library (recharts, nivo, or chart.js) for all visualizations
- Smooth transitions and animations between sections
- The dashboard must tell a STORY — it's not a bunch of charts, it's a narrative
- Structure: Hero section with headline insight → Overview metrics → Deep dives → Developer profiles → Surprising findings
- Each section should have a provocative headline that makes someone stop and read (e.g., 'Your AI spends 73% of its time lost' not 'Tool Usage Distribution')
- Responsive layout, but optimize for 1440px+ screens (this will be shown on a projector/large monitor)

TECH STACK:
- Vite + React + TypeScript
- Tailwind CSS (install via npm, configure in the project)
- Recharts or similar for charts
- Framer Motion for animations (optional but preferred)
- NO backend — pure static site loading JSON from public/data/

OUTPUT:
- All code in $DASHBOARD_DIR/
- Ensure 'npm run dev' works after your changes
- Update $STATE_DIR/AGENT_STATE.md with what you built

DOCUMENTATION (MANDATORY):
Append to $STATE_DIR/CHANGELOG.md a section for this iteration:
## Iteration $i — Frontend Agent
- What you built or changed (specific components, pages, charts added/modified)
- Design decisions and why
- What JSON data you consumed and how you visualized it
- Known limitations or things you'd improve with more data

ITERATION: $i / $ITERATIONS
Do NOT ask questions. Make it extraordinary." \
    > "$LOG_DIR/iter-${i}-frontend.log" 2>&1 &
  PID_FRONTEND=$!

  echo "[reviewer] Starting..."
  claude -p \
    --dangerously-skip-permissions \
    "You are the REVIEWER agent. You are ruthless and have extremely high standards.

ENVIRONMENT:
- Working directory: $PROJECT_DIR
- Analysis scripts: $SCRIPTS_DIR/
- Analysis output: $OUTPUT_DIR/
- Dashboard app: $DASHBOARD_DIR/
- State: $STATE_DIR/AGENT_STATE.md

READ:
1. $STATE_DIR/AGENT_STATE.md
2. $STATE_DIR/CHANGELOG.md — review what agents documented in previous iterations
3. The Vite dashboard app in $DASHBOARD_DIR/ — read the components, pages, styles
4. All JSON files in $OUTPUT_DIR/
5. $PROJECT_DIR/notebooks/003-focused-analytics/CONTEXT.md
6. Check if the dev server is running: curl -s http://localhost:5173 (if not, start it with 'cd $DASHBOARD_DIR && npm run dev &')

NOTE: You are running IN PARALLEL with the analysis and frontend agents. Review whatever currently exists — the other agents are simultaneously improving their work. Your feedback will be read by them at the START of the next iteration.

YOUR STANDARDS:
Phase 1 (current): VP of Engineering reaction — 'oh fuck what!'
- Does this dashboard surface something a VP has never seen before?
- Does it reveal hidden costs, surprising patterns, or actionable intelligence?
- Is the visual quality executive-grade? Would you be embarrassed showing this in a board meeting?
- Are the insights specific and data-backed, not generic fluff?

Phase 2 (after VP bar is met): Developer reaction — 'oh fuck what!'
- Does this show developers something about their own behavior they didn't know?
- Is it personal, specific, and slightly uncomfortable (in a good way)?
- Does it make them want to change how they work?

YOUR JOB:
1. Review the dashboard app code and the live dev server
2. Check if the analysis JSON data is rich enough
3. Write detailed feedback to $STATE_DIR/REVIEW_FEEDBACK.md with:
   - VERDICT: 'KEEP GOING' or 'VP SATISFIED — MOVE TO DEVS' or 'DONE'
   - What's working
   - What's missing or weak
   - Specific improvements for next iteration
4. Update $STATE_DIR/AGENT_STATE.md with the verdict and next steps
5. If DONE, write 'DONE' as the first line of $STATE_DIR/AGENT_STATE.md

Be specific. Don't say 'make it better' — say exactly what to add, change, or fix.

DOCUMENTATION (MANDATORY):
1. Append to $STATE_DIR/CHANGELOG.md a section for this iteration:
## Iteration $i — Reviewer
- Your verdict and why
- What met the bar and what didn't
- Specific action items for next iteration (numbered list)
- Quality score out of 10 for: Data Depth, Visual Impact, Insight Quality, Storytelling

2. ALSO review the changelog entries from the analysis and frontend agents this iteration.
   If they took shortcuts in documenting (vague descriptions, missing rationale), call it out
   in REVIEW_FEEDBACK.md and tell them to be more specific next iteration.

ITERATION: $i / $ITERATIONS
Do NOT ask questions." \
    > "$LOG_DIR/iter-${i}-reviewer.log" 2>&1 &
  PID_REVIEWER=$!

  echo "[all 3 agents running in parallel] Waiting..."
  wait $PID_ANALYSIS $PID_FRONTEND $PID_REVIEWER
  echo "[all 3 agents done]"

  # Check if reviewer said DONE
  if head -1 "$STATE_DIR/AGENT_STATE.md" 2>/dev/null | grep -qi "DONE"; then
    echo ""
    echo "=========================================="
    echo "  REVIEWER SAYS: DONE! (iteration $i)"
    echo "=========================================="
    break
  fi

  echo ""
done

echo ""
echo "Run complete."
echo "Dashboard: $DASHBOARD_DIR/ (npm run dev on :5173)"
echo "Logs: $LOG_DIR/"
echo "State: $STATE_DIR/AGENT_STATE.md"
