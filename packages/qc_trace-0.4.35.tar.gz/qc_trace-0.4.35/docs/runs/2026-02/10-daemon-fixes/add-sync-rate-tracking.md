# Add sync rate tracking and push throughput metrics

Add sync rate tracking to `quickcall status` so the user can see how fast messages are being pushed to the server. Also track push throughput in the daemon.

Reference: https://github.com/quickcall-dev/trace/issues/65

## Key files

- `qc_trace/daemon/push_status.py` — `record_push()` writes `push_status.json`
- `qc_trace/daemon/main.py` — `_poll_cycle()` calls `record_push` after successful push
- `qc_trace/cli/traced.py` — `cmd_status()` displays status

## Current state

- `push_status.json` tracks `by_source` with `last_push_at` and `messages_pushed`
- The status command already fetches server stats via `/api/stats`
- No rate calculation exists yet

## Changes needed

### 1. Track additional fields in `push_status.py`

- `first_push_at`: timestamp of the very first push (set once, never overwritten)
- `session_start_at`: timestamp when daemon started current run
- `messages_this_session`: count of messages pushed since daemon start
- `sessions_pushed`: count of unique session_ids pushed (track in a set, store count)

### 2. Calculate and display rates in `cmd_status` (`traced.py`)

- Messages/min rate (`messages_this_session / minutes since session_start_at`)
- Sessions synced vs total (server sessions / local files)
- ETA to sync remaining if there's a backlog

### 3. Example output

```
354 sessions · 77,283 messages
Sync:  749 files tracked · 85,537 lines processed
Rate:  120 messages/min · synced 6m ago
```

## Git workflow

You are on branch `bugs-and-perf`. Commit and push as you go:

```bash
git add -A && git commit -m "feat: <description>" && git push origin bugs-and-perf
```

After each meaningful change, update the tracking issue with a comment:

```bash
gh issue comment 65 --repo quickcall-dev/trace --body "**Sync rate tracking update**: <what was done>"
```

## Verification

Run `uv run pytest tests/` after changes. Bump version and publish to PyPI using `.prod.env` for the token.
