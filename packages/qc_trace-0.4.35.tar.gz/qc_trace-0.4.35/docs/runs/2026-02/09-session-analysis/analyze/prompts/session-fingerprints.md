# SESSION FINGERPRINTS Agent Instructions

Your job: create a compact fingerprint card for each of the 34 sessions. No fluff, no coach tips. Just the facts — what happened, how big, what type, was it trivial or substantive.

## Paths

- **Parsed sessions**: `docs/run1-09022026/analysis-outputs/parsed/` (34 JSON files)
- **Reclassification**: `docs/run1-09022026/analysis-outputs/reclassification.json` (if it exists — use new classifications; if not, classify yourself)
- **Raw JSONL**: `docs/internal/2026/01/{28,29,30,31}/`
- **Output**: `docs/run1-09022026/analysis-outputs/session-fingerprints.md`

## Output Format

Write `session-fingerprints.md`:

```markdown
# 34 Session Fingerprints — Jan 28-31, 2026

## Summary
- **Substantive sessions**: X (worth analyzing)
- **Trivial sessions**: Y (context-only, test pings, accidental opens)
- **Total time with AI**: Xh Ym across substantive sessions only

---

## Trivial Sessions (skip these)

| # | Filename | Events | Duration | Why trivial |
|---|----------|--------|----------|-------------|
| 1 | rollout-... | 9 | 2s | No real interaction |
...

---

## Substantive Sessions (ordered by date)

### [1] rollout-2026-01-28T15-51-17 — "Setting up cold-ranker project"
- **Type**: setup | **Outcome**: resolved | **Turns**: 7 | **Duration**: 4m 32s
- **What happened**: [1-2 sentences max]
- **First prompt**: > "{exact opening message}"
- **Key moment**: > "{the most interesting exchange — a struggle, breakthrough, or pivot}"

### [2] ...
```

### Rules:
- "What happened" is MAX 2 sentences. Not a story. Just what.
- "Key moment" is the single most interesting quote from the session. Could be a struggle, a clever prompt, a breakthrough, or a funny moment.
- For trivial sessions: just the table row. No analysis. No coach tips. No deep dive.
- For substantive sessions: the fingerprint card above. That's it.
- Order by date/time, not by importance.

## How to determine trivial vs substantive:
- **Trivial**: <3 user messages, OR duration <30s, OR just "hi"/"test"/single word, OR no meaningful code discussion
- **Substantive**: Everything else

## Constraints
- Do NOT give advice or recommendations
- Do NOT do git operations
- Do NOT modify files outside the output directory
- Keep it COMPACT — the whole file should be scannable in 3 minutes
