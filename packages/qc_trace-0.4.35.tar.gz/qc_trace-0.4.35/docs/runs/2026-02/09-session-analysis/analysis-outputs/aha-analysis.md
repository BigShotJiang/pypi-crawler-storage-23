# What Your 34 Sessions Actually Tell You

## The Number That Matters

You opened 34 sessions over 4 days. Five of them lasted under 1 second. Three more were abandoned mid-investigation. That's 8 sessions -- nearly 1 in 4 -- where you paid the full startup cost (AI reads your codebase, hits sandbox errors, escalates permissions) and got zero value back.

But here's the real number: **you asked "how to improve my model?" or "can recommend.py be made faster?" a combined 7 times across 7 separate sessions** before getting to a resolution. Each new session forced the AI to re-read your entire codebase from scratch. The AI read `model.py`, `training.py`, `dataset.py`, `config.py`, and `recommend.py` at least 15 times across those sessions. The same files. The same code. Over and over.

---

## Where Your Time Actually Went

Excluding the 5 throwaway sessions (<1s, "hi", etc.), you spent ~4.8 hours of wall-clock time across 29 substantive sessions. Here's where it went:

### Time Sink #1: The Recommend.py Optimization Saga (82 minutes across 6 sessions)

You spent Jan 31 morning trying to make `recommend.py` faster. Here's the timeline:

| Session | Duration | What happened | Outcome |
|---------|----------|---------------|---------|
| 06:14 (T12b0) | 512s | AI explored at `xhigh` effort, never delivered answer | abandoned |
| 06:23 (T12b8) | 22s | Same question at `medium` effort, got analysis | resolved |
| 06:25 (T12ba) | 193s | Implemented 3 specific optimizations | resolved |
| 06:30 (T12bf) | 1069s | Tried user batching, no throughput gain | partial |
| 06:49 (T12d0) | 247s | Re-asked same question in fresh session, got different optimization | partial |
| 06:55 (T12d5) | 2866s | Finally pivoted to filtering users by recency | resolved |

The punchline from `rollout-2026-01-31T06-55-05`:
> "Three sessions of GPU optimization work was rendered unnecessary by one product requirement clarification."

You asked "can recommend.py be made faster?" four times. The answer that mattered wasn't about GPU batching or tensor precomputation -- it was:

> "ok, actually i need to recommend only to users who have data_created 30 days ago from today, not all users."

That one sentence -- your own realization, not the AI's -- made everything before it irrelevant.

### Time Sink #2: The "How to Improve My Model?" Trilogy (Jan 28, 17:07-20:21)

Three sessions in 90 seconds, all abandoned:

| Session | Duration | Tool calls | What happened |
|---------|----------|------------|---------------|
| 17:07 (T0593-72) | 10s | 1 | AI started investigating, you interrupted |
| 17:08:14 (T0593-bd) | 0.1s | 0 | Set to `xhigh` effort, abandoned instantly |
| 17:08:38 (T0594) | 237s | 15 | AI read 4 files, prepared patch, you interrupted during apply |

Then at 20:00, you asked the same question a 4th time and stayed for 21 minutes. The AI did the **exact same investigation** it started 3 hours earlier.

From `rollout-2026-01-28T17-08-38`:
> "This plan was stated in session 3 but only executed in session 5 -- the same work, just delayed by impatience."

Cost: ~250 seconds of wasted sessions + the AI re-reading all the same files in the session that finally worked.

### Time Sink #3: "Fix error in X" Without a Traceback

Three sessions on Jan 29 evening where you said some variant of "fix my file" without showing the error:

| Session | Prompt | Duration | Tool calls | AI file reads |
|---------|--------|----------|------------|---------------|
| 20:30 (T0b73) | "can you fix error in model.py" | 447s | 17 | 6 files |
| 20:37 (T0b7a) | "can you fix error in training.py" | 288s | 11 | 5 files |
| 20:53 (T0b88) | "fix my recommend.py" | 350s | 1 | 8 files |

Compare to sessions where you pasted the traceback:

| Session | Prompt | Duration | Tool calls |
|---------|--------|----------|------------|
| 22:46 (T0bef) | RuntimeWarning traceback | 91s | 2 |
| 23:07 (T0c02) | IndexError traceback | 127s | 7 |
| 23:17 (T0c0c) | MODE=prod question | 49s | 7 |

**Sessions with tracebacks: avg 89s. Sessions without: avg 362s. That's 4x slower.**

From `rollout-2026-01-29T20-30-24`:
> "This request contains no error message, no traceback, no description of what went wrong. The agent had to do extensive code archaeology across 6 files and 20+ shell commands to infer the bug."

---

## When It's You vs When It's the AI

I went through every non-trivial session and categorized what caused friction. Here's the breakdown:

### Your Fault (and what to do about it)

**Problem 1: Session cycling (8 of 34 sessions = 24% wasted)**

You abandoned sessions before the AI could respond. Not once -- systematically. The pattern:

- Jan 28 17:07-17:08: sessions 3→4→5 on "how to improve my model?" (10s, 0.1s, then 237s before final abandon)
- Jan 29 10:18: sessions 8→9 on "test loss not decreasing" (0.2s, then kept at 1226s)
- Jan 29 13:21-13:23: sessions 12→13 on recommendation feature (7s, then kept at 1478s)
- Jan 30 16:43-16:47: sessions 24→25 on npz KeyError (177s, then 506s)

Every single time, the session you finally kept used the same prompt and got the same AI investigation you interrupted earlier.

**Problem 2: Not answering clarifying questions**

From `rollout-2026-01-28T15-57-48` -- the AI asked "hosted vs self-hosted?" three times. You responded with more terminal output each time:
> "i want my charts to see in browser in wandb"

This states the goal but doesn't answer the question. The session took 725 seconds. Answering "hosted" in one word would have cut it to ~200s.

**Problem 3: Never referencing previous sessions**

From `prompting-patterns.md`:
> "He never mentions previous sessions. Each session starts from scratch -- he never says 'continuing from where we left off' or references what the AI did in a prior session."

This cost you the most on Jan 31. Session 06:49 (`rollout-2026-01-31T06-49-43`) re-asked "how to make recommend.py faster?" 19 minutes after you'd already diagnosed the problem as compute-bound. The new AI didn't know that, so it proposed a different optimization that may have conflicted with your earlier changes.

**Problem 4: Specifying constraints after the AI has already implemented**

From `rollout-2026-01-29T13-23-37`:
> "all the env files you introduced have been set?"

The AI had already introduced `os.environ.get()` calls scattered across files. You then had to ask it to "wire them in config with default values" -- a retroactive cleanup. Same thing happened with sessions 32→33→34 (AVRO, filtering, then refactoring), where `rollout-2026-01-31T08-17-13` was entirely spent removing fallback defaults that sessions 32 and 33 had just added.

> "can you break recommend.py into proper functions? also the code assumes backup values if something is not avaialable, remove them and actually throw error if the value is not present."

If you'd said "no fallback defaults, raise errors" in session 32, session 34 wouldn't have existed.

### The AI's Fault (and when to bail)

**Infrastructure friction: sandbox failures on literally every session**

Every single session's first shell command failed with:
> "thread 'main' panicked at linux-sandbox/src/linux_run_main.rs:30:9: error running landlock: Sandbox(LandlockRestrict)"

This added 1-2 wasted tool calls per session. Across 29 substantive sessions, that's ~40 wasted tool calls just on sandbox handshakes. Not your fault. Not fixable from your side.

**apply_patch routing failures**

From `rollout-2026-01-29T10-18-14`:
> "Warning: apply_patch was requested via shell. Use the apply_patch tool instead of exec_command."

This appeared 7 times in that single session. The AI knew the fix but couldn't apply it because Codex CLI kept rejecting the tool routing. This directly caused session 5 (`rollout-2026-01-28T17-08-38`) to fail -- you waited 4 minutes, the AI had the patch ready, and the tool refused to apply it.

**False positive in code review**

In `rollout-2026-01-29T22-48-55`, the AI flagged a bug ("age_days read from ints.npy but written to floats.npy") and tried to patch it. The patch failed because the code was already correct. The AI then realized:
> "Checked `col/src/model/dataset.py` -- it already reads `age_days` and `total_interactions` from `batch_floats_data` with `self.shard_float_slices`. So the crash you described is already fixed in this file."

Not a huge time waste (one failed patch attempt), but it shows the AI's initial code review can have false positives when reading many files quickly.

**Auto-scaling that silently neutralized an optimization**

In `rollout-2026-01-31T06-30-50`, the AI implemented user batching but included auto-scaling logic that reduced `series_batch_size` proportionally, keeping total work constant:
> "That's expected with the current logic: I auto-scale series_batch_size down when you increase user_batch_size, so the total work per forward stays about the same."

You spent 3 turns adjusting batch sizes before the AI revealed it had built in a neutralizing mechanism. This is a design decision the AI should have flagged upfront.

**Bottom line: 6 of 8 abandoned sessions were your fault (impatience). The other 2 (sessions 5 and 24) were partially the AI's fault -- sandbox/tooling friction made the AI too slow, and you reasonably bailed.**

---

## Your Batting Average

The automated classifier tagged all 34 sessions as "bug-fix." That's wrong. Here's what you actually did, with real success rates (excluding 5 throwaway sessions):

| Actual Task Type | Sessions | Resolved | Rate | Avg Duration | Avg Tool Calls |
|-----------------|----------|----------|------|--------------|----------------|
| Bug fix WITH traceback | 6 | 5 | 83% | 279s | 7 |
| Bug fix WITHOUT traceback | 3 | 3 | 100% | 362s | 10 |
| ML diagnostics (vague) | 5 | 3 | 60% | 1201s | 19 |
| Feature building | 4 | 3 | 75% | 816s | 17 |
| Performance optimization | 6 | 3 | 50% | 818s | 10 |
| Code review / verification | 3 | 3 | 100% | 207s | 8 |
| Refactoring | 1 | 1 | 100% | 1228s | 12 |
| Disk/format question | 1 | 1 | 100% | 549s | 0 |

The story: **bug fixes and code reviews are your sweet spot** (89% combined resolution, fast). **Performance optimization is your weakest area** (50%, slow) -- not because the AI can't optimize, but because you kept restarting sessions and didn't define success criteria upfront.

The ML diagnostics number is misleading: 2 of the 5 "sessions" were instant abandons of the same question. If you'd stayed in the first session, that category would be 3/3 = 100%.

---

## The One Thing You Keep Doing

**You open a new session instead of continuing the current one. Every. Single. Time.**

This isn't just the throwaway sessions. Look at these clusters of related sessions that should have been single conversations:

| Cluster | Sessions | Total time | Could have been |
|---------|----------|------------|-----------------|
| "How to improve my model?" | 4 sessions (3 abandoned + 1 resolved) | ~26 min total wall clock | 1 session, ~10 min |
| "Test loss not decreasing" | 2 sessions (1 abandoned + 1 resolved) | ~21 min | 1 session, ~20 min |
| "Make recommend.py faster" | 6 sessions (1 abandoned + 5 kept) | ~82 min | 2-3 sessions, ~40 min |
| npz KeyError fix | 2 sessions (1 abandoned + 1 resolved) | ~11 min | 1 session, ~8 min |
| AVRO + filtering + refactoring | 3 sessions | ~37 min | 1-2 sessions, ~25 min |

From `rollout-2026-01-31T06-49-43`:
> "The developer opened a fresh AI session to re-ask the same optimization question, causing the AI to read all the same files again and propose a different (possibly conflicting) optimization."

The cost isn't just time. Each new session means the AI proposes potentially different solutions without knowing what was already tried. You end up with conflicting code changes layered on top of each other.

From `prompting-patterns.md`:
> "He never mentions previous sessions. Each session starts from scratch."

---

## Your Best Move

Your best session was `rollout-2026-01-29T22-48-55` -- the full code review.

**What you did:** Pointed the AI at `driver.py` and said:
> "this is my main file col/src/driver.py look at all the files and function it triggers, if there are any logical error or any errors in my prohram"

**What happened:** The AI read 15+ files, traced the entire call graph, and found 5 real bugs ranked by severity -- including **hardcoded API keys and database credentials** in source code:

> "Hardcoded secrets in source: API keys and DB credentials are committed and set at import-time, which is a severe security risk and overrides real env config in any environment."

**Why this was your best move:**
- Duration: 525s (under 9 minutes)
- Struggle: 2/10
- Tool calls: 17
- Value: 5 concrete bugs found across the entire codebase, one of which was a security vulnerability

Compare this to the "fix error in model.py" sessions that took 300-450s each to find ONE bug. The code review found 5 in the same time by giving the AI a broader mandate.

**Your second best move** was in `rollout-2026-01-31T06-55-05`, when you caught a bug the AI missed:
> "but isnt age_days. normalized as well?"

The AI had proposed filtering users by `age_days < 4.954` (the log2 value for 30 days). You realized age_days was also z-score normalized on top of log2, making that threshold meaningless. This is the one moment across 34 sessions where your domain knowledge directly prevented a shipped bug. The AI would have generated code that silently filtered the wrong users.

---

## How You Actually Use the AI

Across 29 substantive sessions, the AI made ~341 tool calls. Here's the breakdown:

**Nearly 100% of tool calls were shell commands** -- file reads (`sed`, `cat`), searches (`rg`, `ls`), and code execution (`python`, `apply_patch`). The AI has no other tools in Codex CLI; everything goes through shell.

**Tool call volume correlates inversely with prompt quality:**

| Prompt quality | Avg tool calls | Example |
|---------------|----------------|---------|
| Traceback pasted | 5-7 | `rollout-01-29T23-07`: 7 calls, resolved in 127s |
| Specific question | 4-8 | `rollout-01-29T23-17`: 7 calls, resolved in 49s |
| "Fix my X" (no traceback) | 11-17 | `rollout-01-29T20-30`: 17 calls, resolved in 447s |
| Vague ML question | 12-24 | `rollout-01-29T10-18-14`: 24 calls, resolved in 1226s |

The AI spent most of its tool calls **reading files it had already read in previous sessions.** In the recommend.py optimization cluster (6 sessions), it read `recommend.py` at least 12 times total. `model.py` was read in 18 of 29 sessions. `config.py` was read in at least 20 sessions.

**Sessions where the AI went straight to the fix** (under 5 tool calls): `rollout-01-29T22-46` (2 calls, log2 warning), `rollout-01-29T20-53` (1 call), `rollout-01-31T06-23` (4 calls, analysis-only). These all had one thing in common: the developer provided enough context that the AI didn't need to explore.

**Sessions where the AI floundered** (15+ tool calls): `rollout-01-29T10-18-14` (24 calls), `rollout-01-28T20-00` (22 calls), `rollout-01-29T13-23` (26 calls). These were either vague prompts or feature-building sessions where the AI had to understand the entire codebase architecture before it could act.

The pattern is simple: **every file read the AI does is a file read you could have prevented by telling it where to look.** Your best sessions provided the file, the error, and the line number. Your worst sessions said "fix my code" and made the AI find everything itself.
