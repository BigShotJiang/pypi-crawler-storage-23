# Cross-Session Synthesis: Nikhil's AI Coding Week (Jan 28-31)

## Executive Summary

Nikhil resolved 26 of 34 AI coding sessions across 4 days building a cold-ranker recommendation system, but **evening sessions had a 100% resolution rate (11/11) while afternoon sessions resolved only 45% (5/11)** -- the difference was patience, not problem difficulty. The 8 abandoned sessions, mostly rapid open-and-close cycles in the afternoon, collectively wasted more time than the problems would have taken to solve if Nikhil had simply waited 60 seconds.

---

## Top 3 Workflow Patterns

### Pattern 1: Rapid Session Cycling on the Same Question

Nikhil repeatedly opened and immediately closed sessions with identical prompts, then re-opened new sessions seconds later. This happened with "how to improve my model?" (3 consecutive abandoned sessions before resolution), "test loss not decreasing" (1 instant abandon before a 20-minute productive session), and "can recommend.py be made faster?" (1 abandoned 8-minute session before a 22-second successful one).

**Evidence from rollout-2026-01-28T17-08-38 (session 5):**
> "Across three consecutive sessions (sessions 3, 4, and 5), the developer asked the exact same question with the exact same training output. The total time spent cycling through these sessions was about 4.5 minutes, but the assistant only got to fully investigate in this last attempt."

**Evidence from rollout-2026-01-31T06-23-05 (session 27):**
> "This session completed in 22 seconds with `medium` effort and produced a more useful result than session 3's 512 seconds with `xhigh` effort. The key difference: session 3 tried to both analyze AND implement (writing patches), while session 4 focused purely on analysis and asked permission before implementing."

**Why this matters:** Each new session forces the AI to re-read the entire codebase from scratch. The developer pays the full exploration cost every time instead of letting the first session complete.

### Pattern 2: "Fix It" Without Error Messages

In at least 5 sessions, Nikhil asked the AI to fix errors without providing tracebacks, error messages, or descriptions of what went wrong. Prompts like "fix error in model.py," "fix my recommend.py," and "fix error in training.py" forced the AI into exhaustive multi-file archaeology that turned 60-second fixes into 5-7 minute investigations.

**Evidence from rollout-2026-01-29T20-30-24 (session 15):**
> "This request contains no error message, no traceback, no description of what went wrong. The agent had to do extensive code archaeology across 6 files and 20+ shell commands to infer the bug."

**Evidence from rollout-2026-01-29T20-53-38 (session 18):**
> "Three words is not much to go on. The developer did not describe what was broken, what error they saw, or what behavior they expected. The agent had to spend the majority of its ~350 seconds reading 8+ files to figure out the problems on its own."

**Why this matters:** A 10-second copy-paste of the traceback consistently cuts resolution time by 3-5x across these sessions.

### Pattern 3: Optimizing Code Before Questioning Scope

Nikhil spent approximately 48 minutes across 3 consecutive sessions (Jan 31, 06:14-06:55) trying to make `recommend.py` faster through GPU-level optimizations (batching, tensor reshaping, mixed precision). None produced measurable throughput improvement. Then, in one sentence, he realized he only needed to score users from the last 30 days -- a domain-level filter that delivered 5-10x speedup instantly.

**Evidence from rollout-2026-01-31T06-55-05 (session 31):**
> "Three sessions of GPU optimization work was rendered unnecessary by one product requirement clarification."

**Evidence from rollout-2026-01-31T06-30-50 (session 29):**
> "The developer ran three optimization rounds that produced zero throughput gain because two distinct bottlenecks were being conflated."

**Why this matters:** Asking "do I need to do all this work?" before asking "how do I make this work faster?" saves hours.

---

## The Aha Insight

**Nikhil's evenings were flawless. His afternoons were chaotic. The problems weren't harder -- he was less patient.**

**The data:**
Of 34 sessions, the 11 evening sessions (18:00-24:00) had a **100% resolution rate** with 0 abandonments. The 11 afternoon sessions (12:00-18:00) had only a **45% resolution rate** with 6 abandonments. Morning sessions (06:00-12:00) fell in between at 83% (10/12). Average struggle score tells the same story: evenings averaged 3.3/10 while afternoons averaged 4.4/10 -- not because problems were harder, but because premature session abandonment turned solvable problems into repeated failures.

**Evidence:**
> "The developer interrupted the session almost instantly -- the entire session lasted only 10 seconds. This suggests impatience or a realization that the question needed to be asked differently." (rollout-2026-01-28T17-07-55, afternoon session)

> "This session was efficient with no significant struggle points. The sandbox still required escalation for every file read, but the assistant handled it smoothly. The struggle_score of 0 is accurate -- this was a clean diagnostic session." (rollout-2026-01-29T11-47-50, morning session after the developer committed to staying)

The evening sessions were where Nikhil's deepest technical work happened: the 21-minute feature-cross discussion (Jan 28, 20:00), the full code review catching hardcoded secrets (Jan 29, 22:48), and the rapid-fire bug fixes from 20:07-23:17 on Jan 29 that resolved 8 sessions in a row.

---

## Prompting Evolution (Day 1 vs Day 4)

**Day 1 (Jan 28) -- average specificity: 4.4/5**
> "how to improve my model?" (rollout-2026-01-28T17-07-55)

Despite the high aggregate specificity score (boosted by excellent error-pasting in sessions 1 and 2), Day 1's core ML question was extremely broad. The developer asked the same vague question 4 times across 4 sessions before getting a resolution.

**Day 4 (Jan 31) -- average specificity: 4.3/5**
> "Precompute series tensors once, Replace batch topk merge, Use torch.inference_mode() in score_user - do these" (rollout-2026-01-31T06-25-34)

By Day 4, Nikhil had learned to use a two-step pattern: first ask for analysis at `medium` effort (22 seconds), then cherry-pick specific items for implementation. The numerical specificity scores are nearly identical (4.4 vs 4.3), but the qualitative prompting strategy evolved significantly.

**Trend:** Prompting specificity scores stayed flat, but prompting *strategy* improved markedly. Day 1 was "ask vaguely, abandon, repeat." Day 4 was "analyze first, then implement specific items." The developer also learned to provide reference code (the 150-line AVRO example in session 32) and to challenge AI suggestions ("but isn't age_days normalized as well?" in session 31 -- catching a real bug the AI missed).

---

## Time-of-Day Analysis

| Time Block | Sessions | Resolution Rate | Avg Turns | Avg Struggle |
|-----------|----------|----------------|-----------|-------------|
| Morning (6-12) | 12 | 83% | 7.2 | 2.2 |
| Afternoon (12-18) | 11 | 45% | 7.5 | 4.4 |
| Evening (18-24) | 11 | 100% | 6.4 | 3.3 |
| Night (0-6) | 0 | N/A | N/A | N/A |

**Best productivity window:** Evening (18:00-24:00). Every single evening session resolved successfully, with the lowest average turns (6.4) and zero abandonments. This is when Nikhil did his deepest work: feature engineering discussions, comprehensive code reviews, and sustained bug-fixing sprints. The evening of Jan 29 (20:07-23:17) was particularly remarkable -- 8 consecutive resolved sessions in 3 hours, each building on the previous one.

---

## Session Type Effectiveness

| Type | Count | Avg Turns to Resolve | Resolution Rate | Avg Specificity |
|------|-------|---------------------|----------------|----------------|
| Bug Fix | 34 | 7 | 76% | 4.3 |

*Note: All 34 sessions were classified as "bug-fix" in the automated metrics pipeline. The deep-dive analyses reveal the actual work included feature-building (recommendation pipeline, AVRO output), performance optimization (GPU batching, tensor precomputation), refactoring (recommend.py restructuring), and codebase inquiry (MODE=prod behavior). A richer session-type classifier would surface more granular effectiveness patterns.*

**Most efficient type:** Codebase inquiry sessions (e.g., rollout-2026-01-29T23-17-23: 4 turns, 49 seconds, 0 struggle) resolved fastest because they required no code changes -- just reading and explaining.

**Least efficient type:** Performance optimization sessions averaged the most total time per resolution. The recommend.py optimization saga consumed 727 seconds across 3 sessions before the developer pivoted to a domain-level solution that made all the GPU work irrelevant.

---

## One Recommendation for Next Week

**What to do:**
Before opening a new AI session, spend 15 seconds writing a "context header" with three things: (1) the exact error message or traceback, (2) what you already tried, and (3) what specific outcome you want. If you don't have a traceback, state the symptom precisely ("test loss plateaus at 0.25 after epoch 3" instead of "how to improve my model?").

**Why it works (evidence):**
> "The developer provided an exemplary bug report -- the entire terminal output including the full traceback with exact line numbers and the runtime context. No guesswork was needed." (rollout-2026-01-29T23-07-18 -- resolved in 127 seconds, 4 turns, specificity 5/5)

> "The developer provided the complete stack trace with line numbers and file paths, giving Codex everything needed to locate the bug instantly. The follow-up message was also effective -- concise and decisive, approving the fix while proactively asking about a related file." (rollout-2026-01-30T16-47-16 -- resolved in 506 seconds with a helper function covering both file types)

**vs. what happened without it:**
> "This request contains no error message, no traceback, no description of what went wrong. The agent had to do extensive code archaeology across 6 files and 20+ shell commands to infer the bug." (rollout-2026-01-29T20-30-24 -- 447 seconds, specificity 2/5, the agent had to read 6 files to find a dimension mismatch that a traceback would have pointed to instantly)

> "Three words is not much to go on. The developer did not describe what was broken, what error they saw, or what behavior they expected. The agent had to spend the majority of its ~350 seconds reading 8+ files to figure out the problems on its own." (rollout-2026-01-29T20-53-38 -- 350 seconds for bugs a traceback would have revealed in 30 seconds)

Sessions with tracebacks resolved in 2-4 turns. Sessions without them took 6-9 turns. The difference is not skill -- it's a 15-second copy-paste.
