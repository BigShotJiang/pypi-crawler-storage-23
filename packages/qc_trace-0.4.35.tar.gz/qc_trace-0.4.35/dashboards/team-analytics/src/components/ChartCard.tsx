import type { ReactNode } from "react";

interface Props {
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
}

export function ChartCard({ title, description, children, className = "" }: Props) {
  return (
    <div className={`bg-white rounded-lg border border-slate-200 ${className}`}>
      <div className="px-5 pt-4 pb-1">
        <h3 className="text-[12px] font-semibold text-slate-700 tracking-tight">
          {title}
        </h3>
        {description && (
          <p className="text-[11px] text-slate-400 mt-0.5">{description}</p>
        )}
      </div>
      <div className="px-4 pb-4">
        {children}
      </div>
    </div>
  );
}
