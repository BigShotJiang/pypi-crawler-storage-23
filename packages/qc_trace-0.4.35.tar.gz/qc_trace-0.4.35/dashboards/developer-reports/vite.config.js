import { defineConfig } from 'vite'

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        main: './index.html',
        jay: './jay.html',
        ajay: './ajay.html',
        vaibhav: './vaibhav.html',
      },
    },
  },
})
