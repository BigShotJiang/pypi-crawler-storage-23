import { useCallback } from 'react';
import { useOutletContext } from 'react-router-dom';
import { api, type Stats } from '../api';
import { usePolling } from '../hooks/usePolling';
import { StatsCards } from '../components/StatsCards';
import { DeviceStatus } from '../components/DeviceStatus';
import { LiveFeed } from '../components/LiveFeed';

export function Overview() {
  const { org } = useOutletContext<{ org?: string }>();
  const fetcher = useCallback(() => api.stats({ org }), [org]);
  const { data: stats, loading, error } = usePolling<Stats>(fetcher, 5000);

  return (
    <div className="space-y-6">
      <StatsCards stats={stats} loading={loading} error={error} />
      <DeviceStatus org={org} />
      <LiveFeed org={org} />
    </div>
  );
}
