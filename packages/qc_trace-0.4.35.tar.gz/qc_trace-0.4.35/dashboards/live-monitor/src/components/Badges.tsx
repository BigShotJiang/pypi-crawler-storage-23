import type { KnownSource } from '../sources';

const SOURCE_COLORS: Record<KnownSource, string> = {
  claude_code: 'bg-orange-500/15 text-orange-600 border-orange-300/30 dark:text-orange-300 dark:border-orange-500/30',
  codex_cli: 'bg-green-500/15 text-green-600 border-green-300/30 dark:text-green-300 dark:border-green-500/30',
  gemini_cli: 'bg-blue-500/15 text-blue-600 border-blue-300/30 dark:text-blue-300 dark:border-blue-500/30',
  cursor: 'bg-purple-500/15 text-purple-600 border-purple-300/30 dark:text-purple-300 dark:border-purple-500/30',
};

const TYPE_COLORS: Record<string, string> = {
  user: 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-300',
  assistant: 'bg-indigo-500/15 text-indigo-700 dark:text-indigo-300',
  tool_call: 'bg-yellow-500/15 text-yellow-700 dark:text-yellow-300',
  tool_result: 'bg-amber-500/15 text-amber-700 dark:text-amber-300',
  system: 'bg-gray-500/15 text-gray-600 dark:text-gray-400',
};

export function SourceBadge({ source }: { source: string }) {
  const cls = SOURCE_COLORS[source as KnownSource] ?? 'bg-gray-500/15 text-gray-600 border-gray-300/30 dark:text-gray-400 dark:border-gray-500/30';
  return (
    <span className={`text-[10px] px-1.5 py-0.5 rounded border font-medium ${cls}`}>
      {source.replaceAll('_', ' ')}
    </span>
  );
}

export function TypeBadge({ type }: { type: string }) {
  const cls = TYPE_COLORS[type] ?? 'bg-gray-500/15 text-gray-600 dark:text-gray-400';
  return (
    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${cls}`}>
      {type}
    </span>
  );
}
