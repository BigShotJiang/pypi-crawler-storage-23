export const KNOWN_SOURCES = ['claude_code', 'codex_cli', 'gemini_cli', 'cursor'] as const;

export type KnownSource = (typeof KNOWN_SOURCES)[number];
