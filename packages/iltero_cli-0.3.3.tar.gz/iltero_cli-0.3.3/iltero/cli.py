"""Iltero CLI - Main entry point.

This is a ground-up rebuild of the Iltero CLI focused on compliance scanning
and result processing. See implementation_docs/20260204/iltero-cli-rebuild/
for complete design documentation.
"""

import sys
import traceback

import typer
from rich.console import Console

# Import command groups
from iltero.commands.auth import app as auth_app
from iltero.commands.compliance import app as compliance_app
from iltero.commands.config import app as config_app
from iltero.commands.environment import app as environment_app
from iltero.commands.init import app as init_app
from iltero.commands.scan import app as scan_app
from iltero.commands.scanner import app as scanner_app
from iltero.commands.stack import app as stack_app
from iltero.commands.token import app as token_app
from iltero.commands.workspace import app as workspace_app
from iltero.core.config import ConfigManager
from iltero.core.context import ContextManager
from iltero.core.exceptions import IlteroError, sanitize_error_message
from iltero.utils.output import print_error
from iltero.version import __version__

# Global Typer app
app = typer.Typer(
    name="iltero",
    help="Iltero CLI - Infrastructure compliance scanning and management",
    no_args_is_help=True,
    add_completion=False,
)

# Console for output
console = Console()

# Register command groups
app.add_typer(scan_app, name="scan")
app.add_typer(scanner_app, name="scanner")
app.add_typer(token_app, name="token")
app.add_typer(compliance_app, name="compliance")
app.add_typer(config_app, name="config")
app.add_typer(init_app, name="init")
app.add_typer(auth_app, name="auth")
app.add_typer(workspace_app, name="workspace")
app.add_typer(environment_app, name="environment")
app.add_typer(stack_app, name="stack")

# Global instances
_config: ConfigManager | None = None
_context: ContextManager | None = None


def get_config() -> ConfigManager:
    """Get the global config manager instance.

    Returns:
        ConfigManager instance
    """
    global _config
    if _config is None:
        _config = ConfigManager()
    return _config


def get_context() -> ContextManager:
    """Get the global context manager instance.

    Returns:
        ContextManager instance
    """
    global _context
    if _context is None:
        _context = ContextManager(get_config().config_dir)
    return _context


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"iltero version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        envvar="ILTERO_DEBUG",
        help="Enable debug logging",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        envvar="ILTERO_NO_COLOR",
        help="Disable colored output",
    ),
) -> None:
    """Iltero CLI - Infrastructure compliance scanning.

    The new Iltero CLI is focused on compliance scanning and result processing.
    It provides commands for:

    - Scanning: Static analysis and plan evaluation
    - Compliance: View scans, violations, and posture
    - Tokens: Manage API tokens for CI/CD
    - Config: Manage CLI configuration

    Set your workspace context:
      export ILTERO_WORKSPACE=my-workspace

    Or use the --workspace flag on commands.
    """
    # Store in context for commands to access
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug
    ctx.obj["no_color"] = no_color

    # Configure console
    if no_color:
        console.no_color = True


def cli_main() -> None:
    """Main CLI entry point with error handling."""
    try:
        app()
    except IlteroError as e:
        # Handle known CLI errors
        print_error(f"Error: {e.message}")
        sys.exit(e.exit_code)
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        console.print("\nOperation cancelled by user")
        sys.exit(130)
    except Exception as e:
        # Handle unexpected errors
        print_error(f"Unexpected error: {e}")
        if "--debug" in sys.argv:
            # Show sanitized traceback in debug mode (redact paths, tokens)
            tb = traceback.format_exc()
            sanitized_tb = sanitize_error_message(tb, max_length=5000)
            console.print(f"[dim]{sanitized_tb}[/dim]")
        sys.exit(1)


if __name__ == "__main__":
    cli_main()
