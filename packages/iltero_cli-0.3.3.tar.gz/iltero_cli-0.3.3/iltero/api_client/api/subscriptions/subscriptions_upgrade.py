from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_subscription_operation_response_schema import (
    APIResponseModelSubscriptionOperationResponseSchema,
)
from ...models.subscription_upgrade_request_schema import SubscriptionUpgradeRequestSchema
from ...types import Response


def _get_kwargs(
    *,
    body: SubscriptionUpgradeRequestSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/subscriptions/upgrade",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelSubscriptionOperationResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelSubscriptionOperationResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelSubscriptionOperationResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: SubscriptionUpgradeRequestSchema,
) -> Response[APIResponseModelSubscriptionOperationResponseSchema]:
    """Upgrade Subscription


            Upgrade organization subscription to a higher tier.

            SECURITY: This endpoint is called AFTER successful payment gateway
            subscription creation. Requires org:subscription:upgrade permission (owners/admins only).


    Args:
        body (SubscriptionUpgradeRequestSchema): Request schema for subscription upgrade.

            This endpoint is called AFTER payment gateway subscription
            creation. The payment gateway (Stripe/Paddle) handles the actual payment
            processing - this just updates our database records.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelSubscriptionOperationResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: SubscriptionUpgradeRequestSchema,
) -> APIResponseModelSubscriptionOperationResponseSchema | None:
    """Upgrade Subscription


            Upgrade organization subscription to a higher tier.

            SECURITY: This endpoint is called AFTER successful payment gateway
            subscription creation. Requires org:subscription:upgrade permission (owners/admins only).


    Args:
        body (SubscriptionUpgradeRequestSchema): Request schema for subscription upgrade.

            This endpoint is called AFTER payment gateway subscription
            creation. The payment gateway (Stripe/Paddle) handles the actual payment
            processing - this just updates our database records.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelSubscriptionOperationResponseSchema
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: SubscriptionUpgradeRequestSchema,
) -> Response[APIResponseModelSubscriptionOperationResponseSchema]:
    """Upgrade Subscription


            Upgrade organization subscription to a higher tier.

            SECURITY: This endpoint is called AFTER successful payment gateway
            subscription creation. Requires org:subscription:upgrade permission (owners/admins only).


    Args:
        body (SubscriptionUpgradeRequestSchema): Request schema for subscription upgrade.

            This endpoint is called AFTER payment gateway subscription
            creation. The payment gateway (Stripe/Paddle) handles the actual payment
            processing - this just updates our database records.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelSubscriptionOperationResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: SubscriptionUpgradeRequestSchema,
) -> APIResponseModelSubscriptionOperationResponseSchema | None:
    """Upgrade Subscription


            Upgrade organization subscription to a higher tier.

            SECURITY: This endpoint is called AFTER successful payment gateway
            subscription creation. Requires org:subscription:upgrade permission (owners/admins only).


    Args:
        body (SubscriptionUpgradeRequestSchema): Request schema for subscription upgrade.

            This endpoint is called AFTER payment gateway subscription
            creation. The payment gateway (Stripe/Paddle) handles the actual payment
            processing - this just updates our database records.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelSubscriptionOperationResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
