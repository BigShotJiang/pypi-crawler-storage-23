from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_password_reset_response import APIResponseModelPasswordResetResponse
from ...models.password_reset_schema import PasswordResetSchema
from ...types import Response


def _get_kwargs(
    *,
    body: PasswordResetSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/password/reset",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelPasswordResetResponse | None:
    if response.status_code == 200:
        response_200 = APIResponseModelPasswordResetResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelPasswordResetResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PasswordResetSchema,
) -> Response[APIResponseModelPasswordResetResponse]:
    """Reset password


            Resets the user's password using a valid reset token.

            Validates the reset token and updates the user's password. After a
            successful reset, the user must log in with the new password. All
            existing sessions will be invalidated.


    Args:
        body (PasswordResetSchema): Password reset schema with validation.

            SECURITY: Password minimum length is 12 characters (aligned with PasswordValidator).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPasswordResetResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PasswordResetSchema,
) -> APIResponseModelPasswordResetResponse | None:
    """Reset password


            Resets the user's password using a valid reset token.

            Validates the reset token and updates the user's password. After a
            successful reset, the user must log in with the new password. All
            existing sessions will be invalidated.


    Args:
        body (PasswordResetSchema): Password reset schema with validation.

            SECURITY: Password minimum length is 12 characters (aligned with PasswordValidator).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPasswordResetResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PasswordResetSchema,
) -> Response[APIResponseModelPasswordResetResponse]:
    """Reset password


            Resets the user's password using a valid reset token.

            Validates the reset token and updates the user's password. After a
            successful reset, the user must log in with the new password. All
            existing sessions will be invalidated.


    Args:
        body (PasswordResetSchema): Password reset schema with validation.

            SECURITY: Password minimum length is 12 characters (aligned with PasswordValidator).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPasswordResetResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PasswordResetSchema,
) -> APIResponseModelPasswordResetResponse | None:
    """Reset password


            Resets the user's password using a valid reset token.

            Validates the reset token and updates the user's password. After a
            successful reset, the user must log in with the new password. All
            existing sessions will be invalidated.


    Args:
        body (PasswordResetSchema): Password reset schema with validation.

            SECURITY: Password minimum length is 12 characters (aligned with PasswordValidator).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPasswordResetResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
