from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_framework_details_response_schema import (
    APIResponseModelFrameworkDetailsResponseSchema,
)
from ...types import Response


def _get_kwargs(
    framework: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/dashboard/frameworks/{framework}/details".format(
            framework=quote(str(framework), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelFrameworkDetailsResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelFrameworkDetailsResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelFrameworkDetailsResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    framework: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelFrameworkDetailsResponseSchema]:
    """Get framework details


            Returns detailed framework compliance data for dashboard drilldown.

            This endpoint is designed for web UI detailed views.
            Use policy and violation endpoints for CLI framework analysis.


    Args:
        framework (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelFrameworkDetailsResponseSchema]
    """

    kwargs = _get_kwargs(
        framework=framework,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    framework: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelFrameworkDetailsResponseSchema | None:
    """Get framework details


            Returns detailed framework compliance data for dashboard drilldown.

            This endpoint is designed for web UI detailed views.
            Use policy and violation endpoints for CLI framework analysis.


    Args:
        framework (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelFrameworkDetailsResponseSchema
    """

    return sync_detailed(
        framework=framework,
        client=client,
    ).parsed


async def asyncio_detailed(
    framework: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelFrameworkDetailsResponseSchema]:
    """Get framework details


            Returns detailed framework compliance data for dashboard drilldown.

            This endpoint is designed for web UI detailed views.
            Use policy and violation endpoints for CLI framework analysis.


    Args:
        framework (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelFrameworkDetailsResponseSchema]
    """

    kwargs = _get_kwargs(
        framework=framework,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    framework: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelFrameworkDetailsResponseSchema | None:
    """Get framework details


            Returns detailed framework compliance data for dashboard drilldown.

            This endpoint is designed for web UI detailed views.
            Use policy and violation endpoints for CLI framework analysis.


    Args:
        framework (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelFrameworkDetailsResponseSchema
    """

    return (
        await asyncio_detailed(
            framework=framework,
            client=client,
        )
    ).parsed
