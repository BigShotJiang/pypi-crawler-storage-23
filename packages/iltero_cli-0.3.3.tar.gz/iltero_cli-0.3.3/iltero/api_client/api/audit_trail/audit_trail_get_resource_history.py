import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_audit_log_resource_history_response import (
    APIResponseModelAuditLogResourceHistoryResponse,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    resource_type: str,
    resource_id: str,
    *,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.datetime):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.datetime):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/audit/logs/resource/{resource_type}/{resource_id}".format(
            resource_type=quote(str(resource_type), safe=""),
            resource_id=quote(str(resource_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelAuditLogResourceHistoryResponse | None:
    if response.status_code == 200:
        response_200 = APIResponseModelAuditLogResourceHistoryResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelAuditLogResourceHistoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    resource_type: str,
    resource_id: str,
    *,
    client: AuthenticatedClient,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[APIResponseModelAuditLogResourceHistoryResponse]:
    """Get resource audit history


            Retrieves complete audit trail history for a specific resource.

            Returns chronological audit logs showing all changes, access events,
            and operations performed on the resource. Useful for compliance audits
            and change tracking.


    Args:
        resource_type (str):
        resource_id (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelAuditLogResourceHistoryResponse]
    """

    kwargs = _get_kwargs(
        resource_type=resource_type,
        resource_id=resource_id,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    resource_type: str,
    resource_id: str,
    *,
    client: AuthenticatedClient,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> APIResponseModelAuditLogResourceHistoryResponse | None:
    """Get resource audit history


            Retrieves complete audit trail history for a specific resource.

            Returns chronological audit logs showing all changes, access events,
            and operations performed on the resource. Useful for compliance audits
            and change tracking.


    Args:
        resource_type (str):
        resource_id (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelAuditLogResourceHistoryResponse
    """

    return sync_detailed(
        resource_type=resource_type,
        resource_id=resource_id,
        client=client,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    resource_type: str,
    resource_id: str,
    *,
    client: AuthenticatedClient,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[APIResponseModelAuditLogResourceHistoryResponse]:
    """Get resource audit history


            Retrieves complete audit trail history for a specific resource.

            Returns chronological audit logs showing all changes, access events,
            and operations performed on the resource. Useful for compliance audits
            and change tracking.


    Args:
        resource_type (str):
        resource_id (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelAuditLogResourceHistoryResponse]
    """

    kwargs = _get_kwargs(
        resource_type=resource_type,
        resource_id=resource_id,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    resource_type: str,
    resource_id: str,
    *,
    client: AuthenticatedClient,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> APIResponseModelAuditLogResourceHistoryResponse | None:
    """Get resource audit history


            Retrieves complete audit trail history for a specific resource.

            Returns chronological audit logs showing all changes, access events,
            and operations performed on the resource. Useful for compliance audits
            and change tracking.


    Args:
        resource_type (str):
        resource_id (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelAuditLogResourceHistoryResponse
    """

    return (
        await asyncio_detailed(
            resource_type=resource_type,
            resource_id=resource_id,
            client=client,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
        )
    ).parsed
