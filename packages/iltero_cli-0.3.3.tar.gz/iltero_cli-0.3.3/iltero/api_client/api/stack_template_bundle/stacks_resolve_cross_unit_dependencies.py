from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_cross_unit_dependencies_response_schema import (
    APIResponseModelCrossUnitDependenciesResponseSchema,
)
from ...types import Response


def _get_kwargs(
    stack_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/stacks/{stack_id}/template-bundle/dependencies".format(
            stack_id=quote(str(stack_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelCrossUnitDependenciesResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelCrossUnitDependenciesResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelCrossUnitDependenciesResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelCrossUnitDependenciesResponseSchema]:
    """Resolve cross-unit dependencies


            Resolves cross-unit data flows via UIC contracts.

            Returns dependency graph showing how infrastructure units are connected.


    Args:
        stack_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCrossUnitDependenciesResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelCrossUnitDependenciesResponseSchema | None:
    """Resolve cross-unit dependencies


            Resolves cross-unit data flows via UIC contracts.

            Returns dependency graph showing how infrastructure units are connected.


    Args:
        stack_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCrossUnitDependenciesResponseSchema
    """

    return sync_detailed(
        stack_id=stack_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelCrossUnitDependenciesResponseSchema]:
    """Resolve cross-unit dependencies


            Resolves cross-unit data flows via UIC contracts.

            Returns dependency graph showing how infrastructure units are connected.


    Args:
        stack_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCrossUnitDependenciesResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelCrossUnitDependenciesResponseSchema | None:
    """Resolve cross-unit dependencies


            Resolves cross-unit data flows via UIC contracts.

            Returns dependency graph showing how infrastructure units are connected.


    Args:
        stack_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCrossUnitDependenciesResponseSchema
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            client=client,
        )
    ).parsed
