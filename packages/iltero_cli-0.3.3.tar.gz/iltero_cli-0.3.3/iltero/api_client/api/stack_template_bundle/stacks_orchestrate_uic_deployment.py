from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_uic_deployment_response_schema import APIResponseModelUICDeploymentResponseSchema
from ...models.stacks_orchestrate_uic_deployment_deployment_config_type_0 import (
    StacksOrchestrateUicDeploymentDeploymentConfigType0,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    stack_id: str,
    *,
    deployment_config: None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_deployment_config: dict[str, Any] | None | Unset
    if isinstance(deployment_config, Unset):
        json_deployment_config = UNSET
    elif isinstance(deployment_config, StacksOrchestrateUicDeploymentDeploymentConfigType0):
        json_deployment_config = deployment_config.to_dict()
    else:
        json_deployment_config = deployment_config
    params["deployment_config"] = json_deployment_config

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/stacks/{stack_id}/template-bundle/deploy".format(
            stack_id=quote(str(stack_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelUICDeploymentResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelUICDeploymentResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelUICDeploymentResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    deployment_config: None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset = UNSET,
) -> Response[APIResponseModelUICDeploymentResponseSchema]:
    """Orchestrate UIC deployment


            Orchestrates UIC-coordinated deployment for a stack.

            Handles deployment ordering, dependency resolution, and cross-unit data flows.


    Args:
        stack_id (str):
        deployment_config (None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelUICDeploymentResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        deployment_config=deployment_config,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    deployment_config: None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset = UNSET,
) -> APIResponseModelUICDeploymentResponseSchema | None:
    """Orchestrate UIC deployment


            Orchestrates UIC-coordinated deployment for a stack.

            Handles deployment ordering, dependency resolution, and cross-unit data flows.


    Args:
        stack_id (str):
        deployment_config (None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelUICDeploymentResponseSchema
    """

    return sync_detailed(
        stack_id=stack_id,
        client=client,
        deployment_config=deployment_config,
    ).parsed


async def asyncio_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    deployment_config: None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset = UNSET,
) -> Response[APIResponseModelUICDeploymentResponseSchema]:
    """Orchestrate UIC deployment


            Orchestrates UIC-coordinated deployment for a stack.

            Handles deployment ordering, dependency resolution, and cross-unit data flows.


    Args:
        stack_id (str):
        deployment_config (None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelUICDeploymentResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        deployment_config=deployment_config,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    deployment_config: None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset = UNSET,
) -> APIResponseModelUICDeploymentResponseSchema | None:
    """Orchestrate UIC deployment


            Orchestrates UIC-coordinated deployment for a stack.

            Handles deployment ordering, dependency resolution, and cross-unit data flows.


    Args:
        stack_id (str):
        deployment_config (None | StacksOrchestrateUicDeploymentDeploymentConfigType0 | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelUICDeploymentResponseSchema
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            client=client,
            deployment_config=deployment_config,
        )
    ).parsed
