from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_template_bundle_response_schema import APIResponseModelTemplateBundleResponseSchema
from ...types import UNSET, Response, Unset


def _get_kwargs(
    bundle_id: str,
    *,
    version: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_version: None | str | Unset
    if isinstance(version, Unset):
        json_version = UNSET
    else:
        json_version = version
    params["version"] = json_version

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/iac/bundles/{bundle_id}".format(
            bundle_id=quote(str(bundle_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelTemplateBundleResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelTemplateBundleResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelTemplateBundleResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    version: None | str | Unset = UNSET,
) -> Response[APIResponseModelTemplateBundleResponseSchema]:
    """Get Template Bundle


            Retrieve a specific template bundle.

            Optional version parameter returns specific version, otherwise returns latest.


    Args:
        bundle_id (str):
        version (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_id=bundle_id,
        version=version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    version: None | str | Unset = UNSET,
) -> APIResponseModelTemplateBundleResponseSchema | None:
    """Get Template Bundle


            Retrieve a specific template bundle.

            Optional version parameter returns specific version, otherwise returns latest.


    Args:
        bundle_id (str):
        version (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleResponseSchema
    """

    return sync_detailed(
        bundle_id=bundle_id,
        client=client,
        version=version,
    ).parsed


async def asyncio_detailed(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    version: None | str | Unset = UNSET,
) -> Response[APIResponseModelTemplateBundleResponseSchema]:
    """Get Template Bundle


            Retrieve a specific template bundle.

            Optional version parameter returns specific version, otherwise returns latest.


    Args:
        bundle_id (str):
        version (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_id=bundle_id,
        version=version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    version: None | str | Unset = UNSET,
) -> APIResponseModelTemplateBundleResponseSchema | None:
    """Get Template Bundle


            Retrieve a specific template bundle.

            Optional version parameter returns specific version, otherwise returns latest.


    Args:
        bundle_id (str):
        version (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleResponseSchema
    """

    return (
        await asyncio_detailed(
            bundle_id=bundle_id,
            client=client,
            version=version,
        )
    ).parsed
