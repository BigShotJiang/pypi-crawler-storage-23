from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_template_bundle_list_response_schema import (
    APIResponseModelTemplateBundleListResponseSchema,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    bundle_id: str,
    *,
    active_only: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["active_only"] = active_only

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/iac/bundles/{bundle_id}/versions".format(
            bundle_id=quote(str(bundle_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelTemplateBundleListResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    active_only: bool | Unset = True,
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    """Get Template Versions


            Retrieve all versions of a template.

            Set active_only=false to include inactive versions.


    Args:
        bundle_id (str):
        active_only (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleListResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_id=bundle_id,
        active_only=active_only,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    active_only: bool | Unset = True,
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    """Get Template Versions


            Retrieve all versions of a template.

            Set active_only=false to include inactive versions.


    Args:
        bundle_id (str):
        active_only (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleListResponseSchema
    """

    return sync_detailed(
        bundle_id=bundle_id,
        client=client,
        active_only=active_only,
    ).parsed


async def asyncio_detailed(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    active_only: bool | Unset = True,
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    """Get Template Versions


            Retrieve all versions of a template.

            Set active_only=false to include inactive versions.


    Args:
        bundle_id (str):
        active_only (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleListResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_id=bundle_id,
        active_only=active_only,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bundle_id: str,
    *,
    client: AuthenticatedClient,
    active_only: bool | Unset = True,
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    """Get Template Versions


            Retrieve all versions of a template.

            Set active_only=false to include inactive versions.


    Args:
        bundle_id (str):
        active_only (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleListResponseSchema
    """

    return (
        await asyncio_detailed(
            bundle_id=bundle_id,
            client=client,
            active_only=active_only,
        )
    ).parsed
