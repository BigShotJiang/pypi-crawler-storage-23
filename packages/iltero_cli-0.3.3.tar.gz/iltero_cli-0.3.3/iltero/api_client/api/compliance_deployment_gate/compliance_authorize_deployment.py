from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_deployment_gate_response_schema import APIResponseModelDeploymentGateResponseSchema
from ...models.deployment_gate_request_schema import DeploymentGateRequestSchema
from ...types import Response


def _get_kwargs(
    stack_id: str,
    run_id: str,
    *,
    body: DeploymentGateRequestSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/compliance/stacks/{stack_id}/runs/{run_id}/authorize-deployment".format(
            stack_id=quote(str(stack_id), safe=""),
            run_id=quote(str(run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelDeploymentGateResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelDeploymentGateResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelDeploymentGateResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: str,
    run_id: str,
    *,
    client: AuthenticatedClient,
    body: DeploymentGateRequestSchema,
) -> Response[APIResponseModelDeploymentGateResponseSchema]:
    """Authorize deployment based on compliance


            Verifies that a run has passed all compliance checks before
            allowing deployment. This endpoint provides defense-in-depth
            security by ensuring compliance gates cannot be bypassed by
            modifying workflow YAML files.

            The following checks are performed:
            1. Run exists and belongs to this organization
            2. Run belongs to the specified stack
            3. Static compliance scan passed (no critical/high violations)
            4. Plan evaluation passed (no policy violations)
            5. Run has not been superseded by newer commits

            Returns authorization status with detailed compliance information.


    Args:
        stack_id (str):
        run_id (str):
        body (DeploymentGateRequestSchema): Request schema for deployment gate authorization.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelDeploymentGateResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        run_id=run_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: str,
    run_id: str,
    *,
    client: AuthenticatedClient,
    body: DeploymentGateRequestSchema,
) -> APIResponseModelDeploymentGateResponseSchema | None:
    """Authorize deployment based on compliance


            Verifies that a run has passed all compliance checks before
            allowing deployment. This endpoint provides defense-in-depth
            security by ensuring compliance gates cannot be bypassed by
            modifying workflow YAML files.

            The following checks are performed:
            1. Run exists and belongs to this organization
            2. Run belongs to the specified stack
            3. Static compliance scan passed (no critical/high violations)
            4. Plan evaluation passed (no policy violations)
            5. Run has not been superseded by newer commits

            Returns authorization status with detailed compliance information.


    Args:
        stack_id (str):
        run_id (str):
        body (DeploymentGateRequestSchema): Request schema for deployment gate authorization.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelDeploymentGateResponseSchema
    """

    return sync_detailed(
        stack_id=stack_id,
        run_id=run_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    stack_id: str,
    run_id: str,
    *,
    client: AuthenticatedClient,
    body: DeploymentGateRequestSchema,
) -> Response[APIResponseModelDeploymentGateResponseSchema]:
    """Authorize deployment based on compliance


            Verifies that a run has passed all compliance checks before
            allowing deployment. This endpoint provides defense-in-depth
            security by ensuring compliance gates cannot be bypassed by
            modifying workflow YAML files.

            The following checks are performed:
            1. Run exists and belongs to this organization
            2. Run belongs to the specified stack
            3. Static compliance scan passed (no critical/high violations)
            4. Plan evaluation passed (no policy violations)
            5. Run has not been superseded by newer commits

            Returns authorization status with detailed compliance information.


    Args:
        stack_id (str):
        run_id (str):
        body (DeploymentGateRequestSchema): Request schema for deployment gate authorization.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelDeploymentGateResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        run_id=run_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: str,
    run_id: str,
    *,
    client: AuthenticatedClient,
    body: DeploymentGateRequestSchema,
) -> APIResponseModelDeploymentGateResponseSchema | None:
    """Authorize deployment based on compliance


            Verifies that a run has passed all compliance checks before
            allowing deployment. This endpoint provides defense-in-depth
            security by ensuring compliance gates cannot be bypassed by
            modifying workflow YAML files.

            The following checks are performed:
            1. Run exists and belongs to this organization
            2. Run belongs to the specified stack
            3. Static compliance scan passed (no critical/high violations)
            4. Plan evaluation passed (no policy violations)
            5. Run has not been superseded by newer commits

            Returns authorization status with detailed compliance information.


    Args:
        stack_id (str):
        run_id (str):
        body (DeploymentGateRequestSchema): Request schema for deployment gate authorization.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelDeploymentGateResponseSchema
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            run_id=run_id,
            client=client,
            body=body,
        )
    ).parsed
