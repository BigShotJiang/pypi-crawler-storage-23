from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_drift_detection_response_schema import APIResponseModelDriftDetectionResponseSchema
from ...types import UNSET, Response, Unset


def _get_kwargs(
    stack_id: str,
    *,
    drift_status: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_drift_status: None | str | Unset
    if isinstance(drift_status, Unset):
        json_drift_status = UNSET
    else:
        json_drift_status = drift_status
    params["drift_status"] = json_drift_status

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/stacks/drift/stack/{stack_id}/latest".format(
            stack_id=quote(str(stack_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelDriftDetectionResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelDriftDetectionResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelDriftDetectionResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    drift_status: None | str | Unset = UNSET,
) -> Response[APIResponseModelDriftDetectionResponseSchema]:
    """Get latest drift detection for stack


            Get the latest drift detection for a specific stack.

            Returns the most recent drift detection result for the stack.


    Args:
        stack_id (str):
        drift_status (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelDriftDetectionResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        drift_status=drift_status,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    drift_status: None | str | Unset = UNSET,
) -> APIResponseModelDriftDetectionResponseSchema | None:
    """Get latest drift detection for stack


            Get the latest drift detection for a specific stack.

            Returns the most recent drift detection result for the stack.


    Args:
        stack_id (str):
        drift_status (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelDriftDetectionResponseSchema
    """

    return sync_detailed(
        stack_id=stack_id,
        client=client,
        drift_status=drift_status,
    ).parsed


async def asyncio_detailed(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    drift_status: None | str | Unset = UNSET,
) -> Response[APIResponseModelDriftDetectionResponseSchema]:
    """Get latest drift detection for stack


            Get the latest drift detection for a specific stack.

            Returns the most recent drift detection result for the stack.


    Args:
        stack_id (str):
        drift_status (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelDriftDetectionResponseSchema]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        drift_status=drift_status,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: str,
    *,
    client: AuthenticatedClient,
    drift_status: None | str | Unset = UNSET,
) -> APIResponseModelDriftDetectionResponseSchema | None:
    """Get latest drift detection for stack


            Get the latest drift detection for a specific stack.

            Returns the most recent drift detection result for the stack.


    Args:
        stack_id (str):
        drift_status (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelDriftDetectionResponseSchema
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            client=client,
            drift_status=drift_status,
        )
    ).parsed
