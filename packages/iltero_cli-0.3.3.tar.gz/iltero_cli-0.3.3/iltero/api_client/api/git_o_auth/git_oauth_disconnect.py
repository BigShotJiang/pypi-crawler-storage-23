from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_git_o_auth_disconnect_response_schema import (
    APIResponseModelGitOAuthDisconnectResponseSchema,
)
from ...types import Response


def _get_kwargs(
    provider: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/repositories/oauth/{provider}/disconnect".format(
            provider=quote(str(provider), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelGitOAuthDisconnectResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelGitOAuthDisconnectResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelGitOAuthDisconnectResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelGitOAuthDisconnectResponseSchema]:
    """Disconnect Git OAuth


            Disconnects Git OAuth credentials.

            Soft deletes credentials (is_active=False) for audit trail.
            User can reconnect at any time.


    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthDisconnectResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelGitOAuthDisconnectResponseSchema | None:
    """Disconnect Git OAuth


            Disconnects Git OAuth credentials.

            Soft deletes credentials (is_active=False) for audit trail.
            User can reconnect at any time.


    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthDisconnectResponseSchema
    """

    return sync_detailed(
        provider=provider,
        client=client,
    ).parsed


async def asyncio_detailed(
    provider: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelGitOAuthDisconnectResponseSchema]:
    """Disconnect Git OAuth


            Disconnects Git OAuth credentials.

            Soft deletes credentials (is_active=False) for audit trail.
            User can reconnect at any time.


    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthDisconnectResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelGitOAuthDisconnectResponseSchema | None:
    """Disconnect Git OAuth


            Disconnects Git OAuth credentials.

            Soft deletes credentials (is_active=False) for audit trail.
            User can reconnect at any time.


    Args:
        provider (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthDisconnectResponseSchema
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
        )
    ).parsed
