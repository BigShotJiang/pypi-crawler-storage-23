from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_policy_set_response_schema import APIResponseModelPolicySetResponseSchema
from ...types import Response


def _get_kwargs(
    policy_set_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/policies/sets/{policy_set_id}".format(
            policy_set_id=quote(str(policy_set_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelPolicySetResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelPolicySetResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelPolicySetResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    policy_set_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelPolicySetResponseSchema]:
    """Get policy set details


            Retrieves detailed information about a specific policy set.

            Use this endpoint to view all policies within a set and their
            configuration. Includes metadata about compliance frameworks.


    Args:
        policy_set_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPolicySetResponseSchema]
    """

    kwargs = _get_kwargs(
        policy_set_id=policy_set_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    policy_set_id: UUID,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelPolicySetResponseSchema | None:
    """Get policy set details


            Retrieves detailed information about a specific policy set.

            Use this endpoint to view all policies within a set and their
            configuration. Includes metadata about compliance frameworks.


    Args:
        policy_set_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPolicySetResponseSchema
    """

    return sync_detailed(
        policy_set_id=policy_set_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    policy_set_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelPolicySetResponseSchema]:
    """Get policy set details


            Retrieves detailed information about a specific policy set.

            Use this endpoint to view all policies within a set and their
            configuration. Includes metadata about compliance frameworks.


    Args:
        policy_set_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPolicySetResponseSchema]
    """

    kwargs = _get_kwargs(
        policy_set_id=policy_set_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    policy_set_id: UUID,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelPolicySetResponseSchema | None:
    """Get policy set details


            Retrieves detailed information about a specific policy set.

            Use this endpoint to view all policies within a set and their
            configuration. Includes metadata about compliance frameworks.


    Args:
        policy_set_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPolicySetResponseSchema
    """

    return (
        await asyncio_detailed(
            policy_set_id=policy_set_id,
            client=client,
        )
    ).parsed
