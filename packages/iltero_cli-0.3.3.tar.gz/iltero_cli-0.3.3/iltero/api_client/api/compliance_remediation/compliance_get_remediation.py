from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_remediation_response_schema import APIResponseModelRemediationResponseSchema
from ...types import Response


def _get_kwargs(
    remediation_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/remediations/{remediation_id}".format(
            remediation_id=quote(str(remediation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelRemediationResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelRemediationResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelRemediationResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    remediation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelRemediationResponseSchema]:
    """Get remediation details


            Retrieves detailed information about a specific remediation action.

            Use this endpoint to check remediation status, view affected resources,
            and track progress of violation fixes.


    Args:
        remediation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelRemediationResponseSchema]
    """

    kwargs = _get_kwargs(
        remediation_id=remediation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    remediation_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelRemediationResponseSchema | None:
    """Get remediation details


            Retrieves detailed information about a specific remediation action.

            Use this endpoint to check remediation status, view affected resources,
            and track progress of violation fixes.


    Args:
        remediation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelRemediationResponseSchema
    """

    return sync_detailed(
        remediation_id=remediation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    remediation_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelRemediationResponseSchema]:
    """Get remediation details


            Retrieves detailed information about a specific remediation action.

            Use this endpoint to check remediation status, view affected resources,
            and track progress of violation fixes.


    Args:
        remediation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelRemediationResponseSchema]
    """

    kwargs = _get_kwargs(
        remediation_id=remediation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    remediation_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelRemediationResponseSchema | None:
    """Get remediation details


            Retrieves detailed information about a specific remediation action.

            Use this endpoint to check remediation status, view affected resources,
            and track progress of violation fixes.


    Args:
        remediation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelRemediationResponseSchema
    """

    return (
        await asyncio_detailed(
            remediation_id=remediation_id,
            client=client,
        )
    ).parsed
