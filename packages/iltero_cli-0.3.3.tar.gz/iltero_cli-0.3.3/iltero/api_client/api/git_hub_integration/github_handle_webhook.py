from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_git_hub_webhook_process_response_schema import (
    APIResponseModelGitHubWebhookProcessResponseSchema,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/integrations/github/webhook",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelGitHubWebhookProcessResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelGitHubWebhookProcessResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelGitHubWebhookProcessResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[APIResponseModelGitHubWebhookProcessResponseSchema]:
    """Handle GitHub App webhook events


            Processes webhook events from GitHub App including installations, repositories, and CI/CD
    events.

            Validates webhook signatures and routes events to appropriate handlers:
            - Installation events (created, deleted, suspend, unsuspend)
            - Repository events (added, removed)
            - CI/CD events (workflow_run, check_run, push, pull_request, deployment_status)


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitHubWebhookProcessResponseSchema]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> APIResponseModelGitHubWebhookProcessResponseSchema | None:
    """Handle GitHub App webhook events


            Processes webhook events from GitHub App including installations, repositories, and CI/CD
    events.

            Validates webhook signatures and routes events to appropriate handlers:
            - Installation events (created, deleted, suspend, unsuspend)
            - Repository events (added, removed)
            - CI/CD events (workflow_run, check_run, push, pull_request, deployment_status)


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitHubWebhookProcessResponseSchema
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[APIResponseModelGitHubWebhookProcessResponseSchema]:
    """Handle GitHub App webhook events


            Processes webhook events from GitHub App including installations, repositories, and CI/CD
    events.

            Validates webhook signatures and routes events to appropriate handlers:
            - Installation events (created, deleted, suspend, unsuspend)
            - Repository events (added, removed)
            - CI/CD events (workflow_run, check_run, push, pull_request, deployment_status)


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitHubWebhookProcessResponseSchema]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> APIResponseModelGitHubWebhookProcessResponseSchema | None:
    """Handle GitHub App webhook events


            Processes webhook events from GitHub App including installations, repositories, and CI/CD
    events.

            Validates webhook signatures and routes events to appropriate handlers:
            - Installation events (created, deleted, suspend, unsuspend)
            - Repository events (added, removed)
            - CI/CD events (workflow_run, check_run, push, pull_request, deployment_status)


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitHubWebhookProcessResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
