#. Lot compatibility (similar to what happens in pickings).
#. Release stock reserves if the task is deleted.