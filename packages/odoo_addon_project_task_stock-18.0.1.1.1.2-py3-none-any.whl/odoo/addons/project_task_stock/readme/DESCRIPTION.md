This module allows to consume products directly from a project task.
