"""Optimization and constraint programming solver interfaces.

This package provides solver model interfaces for defining and solving
mathematical optimization and constraint programming problems using
RelationalAI's solver infrastructure.
"""

from __future__ import annotations

from relationalai.experimental.solvers import Provider, Solver

from .common import all_different, implies, make_name, special_ordered_set_type_2
from .solver_model import SolverModel

__version__ = "0.0.0"

__all__ = [
    "Solver",
    "Provider",
    "SolverModel",
    "make_name",
    "all_different",
    "implies",
    "special_ordered_set_type_2",
]
