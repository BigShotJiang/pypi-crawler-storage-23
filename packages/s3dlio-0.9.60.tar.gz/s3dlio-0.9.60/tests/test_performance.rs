// tests/test_performance.rs
//
// SPDX-License-Identifier: Apache-2.0 OR MIT
// SPDX-FileCopyrightText: 2025 Russ Fellows <russ.fellows@gmail.com>

use std::time::Instant;
use s3dlio::data_gen_alt;

/// Measure generate_random_data() over 100 runs of 1 GiB each.
/// Run with: `cargo test -- --ignored --nocapture perf_random`
/*
#[test]
#[ignore]
fn perf_random() {
    let size = 1024 * 1024 * 1024; // 1 GiB
    let runs = 100;

    let t0 = Instant::now();
    for _ in 0..runs {
        let _buf = generate_random_data(size);
    }
    let elapsed = t0.elapsed();
    println!(
        "generate_random_data: {} × {:.1} MB → {:?}",
        runs,
        size as f64 / (1024.0*1024.0),
        elapsed
    );
}
*/

/// Measure data_gen_alt::generate_controlled_data_alt() over 100 runs of 1 GiB each.
/// Run with: `cargo test -- --ignored --nocapture perf_controlled`
#[test]
#[ignore]
fn perf_controll1() {
    let size = 1024 * 1024 * 1024; // 1 GiB
    let runs = 50;
    let dedup = 3;
    let compress = 2;

    let t0 = Instant::now();
    for _ in 0..runs {
        let _buf = data_gen_alt::generate_controlled_data_alt(size, dedup, compress, None).to_vec();
    }
    let elapsed = t0.elapsed();
    println!(
        "data_gen_alt::generate_controlled_data_alt: {} × {:.1} MB (dedup={}, compress={}) → {:?}",
        runs,
        size as f64 / (1024.0*1024.0),
        dedup,
        compress,
        elapsed
    );
}

/// Measure data_gen_alt::generate_controlled_data_alt() over 100 runs of 1 GiB each.
/// Run with: `cargo test -- --ignored --nocapture perf_controlled`
#[test]
#[ignore]
fn perf_controll2() {
    let size = 1024 * 1024 * 1024; // 1 GiB
    let runs = 50;
    let dedup = 1;
    let compress = 1;

    let t0 = Instant::now();
    for _ in 0..runs {
        let _buf = data_gen_alt::generate_controlled_data_alt(size, dedup, compress, None).to_vec();
    }
    let elapsed = t0.elapsed();
    println!(
        "data_gen_alt::generate_controlled_data_alt: {} × {:.1} MB (dedup={}, compress={}) → {:?}",
        runs,
        size as f64 / (1024.0*1024.0),
        dedup,
        compress,
        elapsed
    );
}
