# O1TwoSum
An experimental Python library achieving algorithmic O(1) Time and Space complexity for the Two Sum problem over data streams. 

*Note: Limited to integers 0-50. Leverages parallel bitwise intersection. While algorithmic O(1), it relies on Python's arbitrary-precision integers under the hood.*

### Usage
```python
from o1twosum import O1TwoSum

system = O1TwoSum()
system.ingest(2)
system.ingest(11)

print(system.query(13)) # Output: (2, 11)