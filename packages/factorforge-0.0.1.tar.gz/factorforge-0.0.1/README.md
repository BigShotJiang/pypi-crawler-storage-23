# FactorForge

ML Alpha Discovery System for stock trading.

**This package is under active development.** Full release coming soon.

## Links

- Website: https://factorforge.io
- GitHub: https://github.com/factorforge/factorforge
