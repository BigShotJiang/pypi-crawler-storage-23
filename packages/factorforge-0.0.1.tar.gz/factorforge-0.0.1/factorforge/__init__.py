"""FactorForge - ML Alpha Discovery System for stock trading."""

__version__ = "0.0.1"
