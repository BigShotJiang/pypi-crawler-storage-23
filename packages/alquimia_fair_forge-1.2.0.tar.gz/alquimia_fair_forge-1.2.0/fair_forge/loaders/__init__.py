"""Data loaders for Fair Forge."""

from .hurtlex import HurtlexLoader

__all__ = ["HurtlexLoader"]
