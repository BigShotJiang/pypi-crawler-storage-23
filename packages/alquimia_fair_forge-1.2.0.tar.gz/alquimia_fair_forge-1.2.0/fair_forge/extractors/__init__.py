"""Feature and group extractors for Fair Forge."""

from .embedding import EmbeddingGroupExtractor

__all__ = ["EmbeddingGroupExtractor"]
