"""Dot notation and access for dictionaries in python"""
from .diot import (
    Diot,
    CamelDiot,
    SnakeDiot,
    FrozenDiot,
    OrderedDiot,
    DiotFrozenError
)

__all__ = [
    "Diot",
    "CamelDiot",
    "SnakeDiot",
    "FrozenDiot",
    "OrderedDiot",
    "DiotFrozenError",
]

__version__ = "0.3.3"
