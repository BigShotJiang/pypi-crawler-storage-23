# ansel-sh

AI-powered demand forecasting.

## Installation

```bash
pip install ansel-sh
```

## Quick start

```python
import asyncio
from ansel_sh import File, create_forecast

file = File(uri="file:///path/to/sales.csv", name="sales.csv", created_by="user")
forecast = asyncio.run(create_forecast(files=file))
```
