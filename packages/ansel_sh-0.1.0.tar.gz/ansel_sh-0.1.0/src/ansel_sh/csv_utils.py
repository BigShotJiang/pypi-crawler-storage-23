from __future__ import annotations

import csv
import io
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import cast

from pydantic import BaseModel, TypeAdapter, ValidationError


@dataclass(frozen=True)
class ValidationIssue:
    """Validation issue detail for a row or manifest-level error."""

    code: str
    detail: str
    row_index: int | None = None
    row_key: str | None = None


@dataclass(frozen=True)
class ValidationResult:
    """Results from validating a CSV file.

    Validation is best-effort: every row produces a ``parsed_rows`` entry
    (with invalid fields omitted), but only rows that fully validate appear
    in ``parsed_models``.

    Attributes:
        issues: Structural or row-level validation issues.
        parsed_rows: Best-effort parsed values for every row; invalid fields omitted.
        parsed_models: Only rows that pass full Pydantic model validation.
        raw_rows: DictReader output (keys/values may be None for extra/missing columns).
    """

    issues: tuple[ValidationIssue, ...]
    parsed_rows: tuple[dict[str, object], ...]
    parsed_models: tuple[BaseModel, ...] = ()
    raw_rows: tuple[dict[str | None, str | None], ...] = ()


def index_rows_by_key(
    parsed_rows: Sequence[dict[str, object]],
    row_key: str,
    /,
) -> dict[str, dict[str, object]]:
    """Index parsed row dicts by a string key.

    Normalizes keys with ``str(value or "").strip()``:
    - falsy values (None, "", 0, False) are treated as blank and skipped
    - whitespace-only keys are skipped
    - duplicate keys overwrite earlier rows
    """
    result: dict[str, dict[str, object]] = {}
    for row in parsed_rows:
        key = str(row.get(row_key) or "").strip()
        if key:
            result[key] = row
    return result


def write_csv(
    path: Path,
    headers: Sequence[str],
    rows: Iterable[Sequence[str]],
    /,
) -> None:
    """Write a CSV with known headers and rows."""
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def read_csv_rows(path: Path, /) -> tuple[list[str], list[dict[str | None, str | None]]]:
    """Read CSV rows into raw dictionaries using DictReader.

    CSVs without headers are not supported: the first row is always treated as the header.
    Extra columns are stored under the None key, and missing columns yield None values.
    Empty files return an empty header list and no rows.
    """
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        header = list(reader.fieldnames or [])
        rows = list(reader)
    return header, rows


def parse_csv_list(value: object, /) -> object:
    """Parse a comma-separated CSV cell into a list of stripped tokens.

    None or blank/whitespace strings return an empty list.
    Lists are returned unchanged. Other non-str inputs are returned unchanged.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return cast(list[object], value)
    if not isinstance(value, str):
        return value
    if not value.strip():
        return []
    parsed = next(csv.reader([value]))
    return cast(list[object], [token.strip() for token in parsed if token.strip()])


def serialize_csv_list(values: Sequence[str], /) -> str:
    """Serialize a list of strings into a single CSV cell value.

    Empty inputs return an empty string.
    """
    if not values:
        return ""
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(values)
    return buffer.getvalue().strip("\r\n")


def _serialize_scalar(value: object, /) -> str:
    if isinstance(value, Enum):
        return str(cast(object, value.value))
    return str(value)


def serialize_csv_value(value: object, /) -> str:
    """Serialize a Python value into a CSV cell string.

    Handles None (→ ``""``), lists (→ comma-separated via
    ``serialize_csv_list``), datetime/date (→ ISO date), enums
    (→ ``str(value)``), and plain scalars (→ ``str``).
    """
    if value is None:
        return ""
    if isinstance(value, list):
        items = cast(Iterable[object], value)
        return serialize_csv_list([_serialize_scalar(item) for item in items])
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return _serialize_scalar(value)


def normalize_row_for_model(
    row: Mapping[str | None, str | None],
    model: type[BaseModel],
    /,
) -> dict[str, object]:
    """Normalize blank cells and parse list-typed fields from CSV strings."""
    normalized: dict[str, object] = {}
    for field_name, field_info in model.model_fields.items():
        if field_name not in row:
            continue
        value = row.get(field_name)
        if value == "":
            # Treat empty cells as missing to honor optional/required semantics.
            continue
        if field_info.default_factory is list and isinstance(value, str):
            normalized[field_name] = parse_csv_list(value)
        else:
            normalized[field_name] = value
    return normalized


def _validate_row_with_model(
    row: Mapping[str | None, str | None],
    model: type[BaseModel],
    /,
) -> tuple[dict[str, object], BaseModel | None, list[ValidationIssue]]:
    """Validate a row with Pydantic, falling back to per-field validation.

    This only enforces row-level typing/shape; cross-field completeness rules
    belong to domain-specific validation.
    """
    issues: list[ValidationIssue] = []
    normalized = normalize_row_for_model(row, model)
    try:
        parsed_model = model.model_validate(normalized)
        parsed_row = cast(dict[str, object], parsed_model.model_dump())
        return parsed_row, parsed_model, issues
    except ValidationError as exc:
        for error in exc.errors():
            field = ".".join(str(part) for part in error.get("loc", ()))
            issues.append(
                ValidationIssue(
                    code="row_validation_error",
                    detail=f"{field}: {error.get('msg', 'invalid value')}",
                )
            )

    # Best-effort: validate fields independently via TypeAdapter so we can
    # keep valid values even when full-row validation fails.
    parsed: dict[str, object] = {}
    for field_name, field_info in model.model_fields.items():
        if field_name not in normalized:
            continue
        try:
            adapter: TypeAdapter[object] = TypeAdapter(cast(object, field_info.annotation))
            parsed[field_name] = adapter.validate_python(normalized[field_name])
        except ValidationError as exc:
            message = exc.errors()[0].get("msg", "invalid value")
            issues.append(
                ValidationIssue(
                    code="row_validation_error",
                    detail=f"{field_name}: {message}",
                )
            )
    return parsed, None, issues


def validate_csv_structure(
    *,
    path: Path,
    row_model: type[BaseModel],
    row_key: str | None,
    mutable_fields: Sequence[str] = (),
    immutable_values: Mapping[str, Mapping[str, str]] | None = None,
) -> ValidationResult:
    """Validate a CSV using a Pydantic row model and header/mutation rules.

    Validations performed:
    - Header order mismatch: expected row_model field order vs CSV header.
    - Missing headers: required model fields not present.
    - Extra headers: CSV includes unexpected columns.
    - Extra row columns: DictReader yields None key.
    - Missing row key: row_key empty/blank after trimming.
    - Unexpected row key: row_key not present in immutable_values when provided.
    - Immutable mutation: any key in immutable_values[row_key] changed.
    - Missing expected row: immutable_values keys not present in the CSV.
    - Row validation: Pydantic model validation with best-effort fallback.
    - Field incomplete: mutable fields that are empty/falsy after agent output.

    mutable_fields declares which columns the agent is allowed to modify.
    All other columns are read-only by default.

    immutable_values maps row_key values to expected column values for the
    read-only columns: ``{"row-id": {"column": "expected"}}``. When provided,
    read-only columns are checked for mutation, mutable fields are checked
    for completeness, and unexpected/missing rows are flagged.
    """
    header, rows = read_csv_rows(path)
    issues: list[ValidationIssue] = []
    parsed_rows: list[dict[str, object]] = []
    parsed_models: list[BaseModel] = []

    required_list = list(row_model.model_fields.keys())
    if header != required_list:
        issues.append(
            ValidationIssue(
                code="header_mismatch",
                detail=f"expected {required_list}, got {header}",
            )
        )
    header_set = set(header)
    required_set = set(required_list)
    missing_headers = [name for name in required_list if name not in header_set]
    extra_headers = [name for name in header if name not in required_set]
    if missing_headers:
        issues.append(
            ValidationIssue(
                code="header_missing",
                detail=f"missing {missing_headers}",
            )
        )
    if extra_headers:
        issues.append(
            ValidationIssue(
                code="header_extra",
                detail=f"extra {extra_headers}",
            )
        )

    seen_keys: set[str] = set()
    for row_index, row in enumerate(rows, start=2):
        if None in row:
            issues.append(
                ValidationIssue(
                    code="row_extra_columns",
                    detail="row has extra columns",
                    row_index=row_index,
                )
            )

        row_id = ""
        if row_key is not None:
            row_id = (row.get(row_key) or "").strip()
            if not row_id:
                issues.append(
                    ValidationIssue(
                        code="row_missing_key",
                        detail=f"missing {row_key}",
                        row_index=row_index,
                    )
                )

            if row_id and immutable_values:
                seen_keys.add(row_id)
                expected = immutable_values.get(row_id)
                if expected is None:
                    issues.append(
                        ValidationIssue(
                            code="row_unexpected_key",
                            detail=f"{row_key} {row_id} not in expected rows",
                            row_index=row_index,
                            row_key=row_id,
                        )
                    )
                else:
                    for column, expected_value in expected.items():
                        if row.get(column) != expected_value:
                            issues.append(
                                ValidationIssue(
                                    code="immutable_mutation",
                                    detail=f"{column} changed",
                                    row_index=row_index,
                                    row_key=row_id,
                                )
                            )

        parsed, parsed_model, row_issues = _validate_row_with_model(row, row_model)
        for issue in row_issues:
            issues.append(
                ValidationIssue(
                    code=issue.code,
                    detail=issue.detail,
                    row_index=row_index,
                    row_key=row_id or None,
                )
            )
        parsed_rows.append(parsed)
        if parsed_model is not None:
            parsed_models.append(parsed_model)

        # Completeness check: flag mutable fields that are empty/falsy.
        # Only runs when immutable_values is provided, signaling the agent was
        # expected to fill in the mutable fields (e.g. files classification).
        if row_key is not None and immutable_values and mutable_fields and row_id:
            missing = [f for f in mutable_fields if not parsed.get(f)]
            if missing:
                issues.append(
                    ValidationIssue(
                        code="field_incomplete",
                        detail=f"missing {', '.join(missing)}",
                        row_index=row_index,
                        row_key=row_id,
                    )
                )

    if row_key is not None and immutable_values:
        missing_keys = [key for key in immutable_values.keys() if key not in seen_keys]
        if missing_keys:
            issues.append(
                ValidationIssue(
                    code="row_missing_expected",
                    detail=f"missing {row_key} values: {missing_keys}",
                )
            )

    return ValidationResult(
        issues=tuple(issues),
        parsed_rows=tuple(parsed_rows),
        parsed_models=tuple(parsed_models),
        raw_rows=tuple(rows),
    )
