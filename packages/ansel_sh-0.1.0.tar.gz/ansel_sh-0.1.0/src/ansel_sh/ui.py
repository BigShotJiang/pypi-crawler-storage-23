"""
User-facing interaction utilities.

Contents:
1. Events
2. Confirm
"""

from __future__ import annotations

import sys
from typing import override

from .events import Event, event, publish


# ============================================
# 1. EVENTS
# ============================================


@event
class ConfirmationRequested(Event, frozen=True):
    """Emitted when the user is prompted for confirmation."""

    prompt: str

    @override
    def message(self) -> str:
        return f"Awaiting confirmation: {self.prompt}"


@event
class ConfirmationCompleted(Event, frozen=True):
    """Emitted when the user responds to a confirmation prompt."""

    confirmed: bool

    @override
    def message(self) -> str:
        return f"User {'confirmed' if self.confirmed else 'declined'}"


# ============================================
# 2. CONFIRM
# ============================================


def confirm(message: str) -> bool:
    """
    Print a message and prompt the user to continue or quit.

    Auto-confirms when stdout is not a TTY (e.g. piped, CI).
    Only an empty response (Enter) confirms; any other input declines.
    Events are published in both TTY and non-TTY modes.
    """
    publish(ConfirmationRequested(prompt=message))

    if not sys.stdout.isatty():
        publish(ConfirmationCompleted(confirmed=True))
        return True

    print(message)

    response = input("Press Enter to continue (or type anything to quit): ")
    confirmed = response.strip() == ""
    publish(ConfirmationCompleted(confirmed=confirmed))

    return confirmed
