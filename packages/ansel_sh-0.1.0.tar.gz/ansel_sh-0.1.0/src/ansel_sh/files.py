"""
File domain module.

Sections:
1. Domain Events
2. Factory Functions
3. Agent Runners
4. Resolution
"""

import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from typing import Protocol, override

from claude_agent_sdk import ResultMessage

from .agents import run_agent
from .agents.files import FilesClassifier, FilesClassifierInput
from .agents.observability import observe
from .csv_utils import ValidationIssue
from .events import Event, event, log_events, publish
from .file_schemas import (
    FILES_MANIFEST,
    FilesManifestEntry,
)
from .models import DateRange, File, FileAggregation, FileFrequency, FileRecord
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import (
    discover_files,
    materialize,
    stage_files_to_sandbox,
)

# ============================================
# 1. DOMAIN EVENTS
# ============================================


@event
class FilesClassificationStarted(Event, frozen=True):
    """Emitted when the Files Classifier agent begins analyzing files."""

    files: list[File]

    @override
    def message(self) -> str:
        return f"Start classifying {len(self.files)} files"


@event
class FilesClassificationCompleted(Event, frozen=True):
    """Emitted when the Files Classifier agent finishes classifying files."""

    files: list[File]

    @override
    def message(self) -> str:
        return f"Finished classifying {len(self.files)} files"


@event
class FilesClassificationFailed(Event, frozen=True):
    """Emitted when file classification fails."""

    files: list[File]
    error: str

    @override
    def message(self) -> str:
        return f"File classification failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 2. FACTORY FUNCTIONS
# ============================================


def classify_file(
    file: File,
    records: list[FileRecord] | None = None,
    aggregations: list[FileAggregation] | None = None,
    frequencies: list[FileFrequency] | None = None,
    date_range: DateRange | None = None,
    /,
) -> File:
    """
    Classify a file with metadata discovered by the Files Classifier agent.

    Args:
            file: The file to classify.
            records: What's been recorded (orders, sales, inventory).
            aggregations: At what level data is aggregated (variant, product, family, store).
            frequencies: How often data is recorded (day, week, month, quarter).
            date_range: Time range covered by file data.

    Returns:
            A new File with classification metadata.
    """
    return File(
        id=file.id,
        uri=file.uri,
        name=file.name,
        created_by=file.created_by,
        description=file.description,
        sources=file.sources,
        created_at=file.created_at,
        records=records or [],
        aggregations=aggregations or [],
        frequencies=frequencies or [],
        date_range=date_range,
    )


@log_events
async def create_files(files: File | list[File] | None = None) -> list[File]:
    """
    Created classified Files from input files.
    """
    with with_run_context():
        if files is None:
            return await resolve_files()

        input_files = [files] if isinstance(files, File) else files
        return await resolve_files(input_files)


# ============================================
# 3. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class FileResult:
    """Materialized file and its validation issues."""

    file: File
    issues: tuple[ValidationIssue, ...]


@dataclass(frozen=True)
class FilesClassifierResult:
    """Output from a files classifier run."""

    classified: list[File]
    manifest: FileResult
    result: ResultMessage


class FilesClassifierRunner(Protocol):
    def __call__(
        self,
        files: list["File"],
        /,
    ) -> Awaitable[FilesClassifierResult]: ...


@observe(name="files_classifier")
async def _run_files_classifier(
    files: list[File],
    /,
) -> FilesClassifierResult:
    """
    Classify files by running the FilesClassifier agent in a sandbox.

    Returns classified files matching the input IDs.
    """
    publish(FilesClassificationStarted(files=files))

    try:
        # Create temp sandbox dir
        with create_agent_sandbox_dir() as sandbox_dir:
            # Stage files for classification
            staged_files = stage_files_to_sandbox(files, sandbox_dir)

            # Write a manifest so the agent can enumerate files.
            staged_entries = [FilesManifestEntry.from_file(f, sandbox_dir) for f in staged_files]
            files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, staged_entries)

            # Agent input schema — path is relative to sandbox root
            agent_input = FilesClassifierInput(files_manifest_path=files_manifest_path)

            # Run the agent (writes classification.csv to .ansel via output model).
            result_message = await run_agent(
                FilesClassifier(), agent_input, sandbox_dir, trace=True
            )

            # Validate agent output in sandbox before materialization
            files_manifest_validation_result = FILES_MANIFEST.validate_file(
                sandbox_dir,
                immutable_values=FILES_MANIFEST.immutable_row_values(staged_entries),
            )

            # Persist agent output to durable storage (audit artifact)
            files_manifest = materialize(FILES_MANIFEST, sandbox_dir, agent_name="files_classifier")

            files_manifest_entries = FILES_MANIFEST.load(sandbox_dir)

        classified_files = _build_classified_files(files_manifest_entries, files)

        publish(FilesClassificationCompleted(files=classified_files))
        return FilesClassifierResult(
            classified=classified_files,
            manifest=FileResult(
                file=files_manifest, issues=files_manifest_validation_result.issues
            ),
            result=result_message,
        )
    except Exception as exc:
        publish(FilesClassificationFailed(files=files, error=str(exc)))
        raise


def _build_classified_files(
    entries: list[FilesManifestEntry],
    original_files: list[File],
    /,
) -> list[File]:
    """Map loaded manifest entries to classified File instances."""
    entries_by_id = {e.id: e for e in entries}

    classified_files: list[File] = []
    for original_file in original_files:
        entry = entries_by_id.get(original_file.id)
        if entry is not None:
            records = entry.records or None
            aggregations = entry.aggregations or None
            frequencies = entry.frequencies or None
            date_range = (
                DateRange(min=entry.date_min, max=entry.date_max)
                if entry.date_min and entry.date_max
                else None
            )
        else:
            records, aggregations, frequencies, date_range = None, None, None, None

        classified_files.append(
            classify_file(
                original_file,
                records,
                aggregations,
                frequencies,
                date_range,
            )
        )

    return classified_files


# ============================================
# 4. RESOLUTION
# ============================================


async def resolve_files(
    files: list[File] | None = None,
    runner: FilesClassifierRunner = _run_files_classifier,
    /,
) -> list[File]:
    """
    Ensure files exist and are classified.

    - If `files` is None, discover files from the default data source.
    - Raises ValueError if no files are available after discovery.
    - Only unclassified files are sent to the classifier; pre-classified inputs are preserved.
    - The returned list preserves input order.

    Args:
            files: Input files. When omitted, collect from the default data directory.
            runner: Callable used to classify files when needed.

    Returns:
            Classified files.

    Raises:
            ValueError: If no files are available.
    """
    if files is None:
        files = discover_files()
    if not files:
        raise ValueError("files required")

    files_need_classification = [file for file in files if not file.is_classified]
    if not files_need_classification:
        return files

    # Run the classifier agent
    classifier_result = await runner(files_need_classification)
    files_classified_by_id = {file.id: file for file in classifier_result.classified}

    missing_file_ids = [
        file.id for file in files_need_classification if file.id not in files_classified_by_id
    ]
    if missing_file_ids:
        raise ValueError(f"Missing classifications for: {', '.join(missing_file_ids)}")

    # Return the full input set in order, merging newly classified files with any pre-classified ones.
    return [files_classified_by_id.get(file.id, file) for file in files]
