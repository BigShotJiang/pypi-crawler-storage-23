"""
Entity domain module.

Sections:
1. Entity
2. Domain Events
3. Agent Runners
4. Resolution
"""

from __future__ import annotations

import sys
from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Protocol, override

from claude_agent_sdk import ResultMessage
from pydantic import BaseModel, Field

from .agents import run_agent
from .agents.entities import (
    ENTITIES_ANALYST,
    ENTITIES_EXTRACTOR,
    EntitiesAnalystInput,
    EntitiesAnalystOutput,
    EntitiesExtractorInput,
)
from .agents.observability import observe
from .events import Event, event, log_events, publish
from .files import FileResult, resolve_files
from .file_schemas import (
    ENTITIES_MANIFEST,
    FILES_MANIFEST,
    EntitiesManifestEntry,
    FilesManifestEntry,
)
from .models import File, FileAggregation
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import materialize, stage_files_to_sandbox
from .ui import confirm
from .utils import generate_id, utc_now

# ============================================
# 1. ENTITY
# ============================================

IdentifierType = Literal["sku", "upc", "id"]


# TODO: Revisit if identifiers are needed for MVP-level entity workflows.
class EntityIdentifier(BaseModel, frozen=True):
    """
    Machine-readable identifier for an entity.

    Attributes:
            type: Kind of identifier (sku, upc, internal, external).
            value: The actual identifier string.
    """

    type: IdentifierType
    value: str


class Entity(BaseModel):
    """
    The thing you forecast — a product, variant, family, or store.

    Entities are discovered by agents from file metadata, or created manually.
    Each entity belongs to one aggregation level and can have multiple
    machine-readable identifiers for cross-system references.

    Attributes:
            id: Unique identifier (ent_xxx).
            name: Human-readable name (e.g., "iPhone 16 Pro Max").
            aggregation: Granularity level (variant, product, family, store).
            identifiers: Machine-readable IDs (SKU, UPC, etc.).
            created_at: When this entity was created.
            updated_at: When this entity was last modified.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("ent"))
    name: str
    aggregation: FileAggregation

    # References
    identifiers: list[EntityIdentifier] = Field(default_factory=list)

    # Lineage
    # TODO: Revisit lineage design — not sure if IDs are the right approach
    # source_file_ids: list[str] = Field(default_factory=list)

    # Time
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class Entities(BaseModel):
    """Collection of extracted entities and their source files."""

    items: list[Entity]
    files: list[File]


# ============================================
# 2. DOMAIN EVENTS
# ============================================


@event
class EntityAnalysisStarted(Event, frozen=True):
    """Emitted when the Entities Analyst agent begins analyzing files."""

    file_ids: list[str]

    @override
    def message(self) -> str:
        return f"Start analyzing entities from {len(self.file_ids)} files"


@event
class EntityAnalysisCompleted(Event, frozen=True):
    """Emitted when the Entities Analyst agent finishes analysis."""

    aggregation: FileAggregation
    entity_count: int

    @override
    def message(self) -> str:
        return f"Finished entity analysis: {self.entity_count} {self.aggregation}"


@event
class EntityExtractionStarted(Event, frozen=True):
    """Emitted when the Entities Extractor agent begins extracting entities."""

    aggregation: FileAggregation
    entity_count: int

    @override
    def message(self) -> str:
        return f"Start extracting {self.entity_count} {self.aggregation} entities"


@event
class EntityExtractionCompleted(Event, frozen=True):
    """Emitted when the Entities Extractor agent finishes extraction."""

    entities: list[Entity]

    @override
    def message(self) -> str:
        return f"Finished extracting {len(self.entities)} entities"


# ============================================
# 3. AGENT RUNNERS
# ============================================


class EntitiesAnalystRunner(Protocol):
    def __call__(self, files: list[File], /) -> Awaitable[EntitiesAnalystOutput]: ...


@dataclass(frozen=True)
class EntitiesExtractorResult:
    """Output from an entities extractor run."""

    entities: list[Entity]
    manifest: FileResult
    result: ResultMessage


class EntitiesExtractorRunner(Protocol):
    def __call__(
        self,
        files: list[File],
        aggregation: FileAggregation,
        limit: int | None,
        /,
    ) -> Awaitable[EntitiesExtractorResult]: ...


@observe(name="entities_analyst")
async def _run_entities_analyst(files: list[File], /) -> EntitiesAnalystOutput:
    """Run the Entities Analyst agent and return the inferred aggregation."""
    if not files:
        raise ValueError("files required")

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        entries = [FilesManifestEntry.from_file(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, entries)

        agent_input = EntitiesAnalystInput(
            files_manifest_path=files_manifest_path,
        )

        return await run_agent(ENTITIES_ANALYST, agent_input, sandbox_dir)


@observe(name="entities_extractor")
async def _run_entities_extractor(
    files: list[File],
    aggregation: FileAggregation,
    limit: int | None,
    /,
) -> EntitiesExtractorResult:
    """Run the Entities Extractor agent and parse the resulting entities manifest."""
    if not files:
        raise ValueError("files required")

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        entries = [FilesManifestEntry.from_file(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, entries)

        # Write an empty entities manifest (headers only) for the agent to fill in.
        entities_manifest_path = ENTITIES_MANIFEST.dump(sandbox_dir, [])

        agent_input = EntitiesExtractorInput(
            files_manifest_path=files_manifest_path,
            entities_manifest_path=entities_manifest_path,
            aggregation=aggregation,
            limit=limit,
        )

        result_message = await run_agent(ENTITIES_EXTRACTOR, agent_input, sandbox_dir)

        # Validate agent output in sandbox
        entities_manifest_validation_result = ENTITIES_MANIFEST.validate_file(sandbox_dir)

        # Persist agent output to durable storage (audit artifact)
        entities_manifest = materialize(
            ENTITIES_MANIFEST, sandbox_dir, agent_name="entities_extractor"
        )

        entities_manifest_entries = ENTITIES_MANIFEST.load(sandbox_dir)

    return EntitiesExtractorResult(
        entities=_build_entities(entities_manifest_entries),
        manifest=FileResult(
            file=entities_manifest, issues=entities_manifest_validation_result.issues
        ),
        result=result_message,
    )


def _build_entities(entries: list[EntitiesManifestEntry], /) -> list[Entity]:
    """Map loaded manifest entries to domain Entity instances.

    Identifier columns (sku, upc, id) are mapped directly to
    EntityIdentifier instances.
    """
    entities: list[Entity] = []
    for entry in entries:
        identifiers = (
            [EntityIdentifier(type="sku", value=v) for v in entry.sku]
            + [EntityIdentifier(type="upc", value=v) for v in entry.upc]
            + [EntityIdentifier(type="id", value=v) for v in entry.id]
        )
        entities.append(
            Entity(
                name=entry.name,
                aggregation=entry.aggregation,
                identifiers=identifiers,
            )
        )

    return entities


def _format_entity_preview(entities: list[Entity]) -> str:
    """Format extracted entities for CLI preview."""
    lines: list[str] = ["Extracted entities:"]
    for entity in entities:
        lines.append(f"  {entity.name} ({entity.aggregation.value})")
        for ident in entity.identifiers:
            lines.append(f"    {ident.type}: {ident.value}")
    return "\n".join(lines)


# ============================================
# 4. RESOLUTION
# ============================================


@log_events
async def create_entities(files: File | list[File] | None = None) -> Entities:
    """
    Public entrypoint: classify files then extract entities.

    Handles run context, file resolution, and entity extraction end-to-end.
    When no files are provided, files are discovered and classified first.
    """
    with with_run_context():
        if files is None:
            resolved_files = await resolve_files()
        else:
            input_files = [files] if isinstance(files, File) else files
            resolved_files = await resolve_files(input_files)

        entities = await resolve_entities(resolved_files)
        return Entities(items=entities, files=resolved_files)


async def resolve_entities(
    files: list[File],
    analyst_runner: EntitiesAnalystRunner = _run_entities_analyst,
    extractor_runner: EntitiesExtractorRunner = _run_entities_extractor,
    /,
) -> list[Entity]:
    """
    Internal resolver: run analyst then extractor agents sequentially.

    Called by create_entities after files are resolved. Accepts optional
    runner overrides for testing without live agent calls.

    Args:
            files: Classified files to extract entities from.
            analyst_runner: Infers the aggregation level.
            extractor_runner: Extracts entities at that level.

    Returns:
            Extracted entities.

    Raises:
            ValueError: If files is empty.
    """
    if not files:
        raise ValueError("files required")

    publish(EntityAnalysisStarted(file_ids=[file_obj.id for file_obj in files]))

    limit = 1
    # TODO: entities limit is hardcoded to 1, remove hardcode
    analyst_result = await analyst_runner(files)
    aggregation = analyst_result.aggregation
    publish(EntityAnalysisCompleted(aggregation=aggregation, entity_count=limit))

    publish(EntityExtractionStarted(aggregation=aggregation, entity_count=limit))
    extractor_result = await extractor_runner(files, aggregation, limit)
    entities = extractor_result.entities
    publish(EntityExtractionCompleted(entities=entities))

    if entities:
        preview = _format_entity_preview(entities)
        if not confirm(preview):
            sys.exit(0)

    return entities
