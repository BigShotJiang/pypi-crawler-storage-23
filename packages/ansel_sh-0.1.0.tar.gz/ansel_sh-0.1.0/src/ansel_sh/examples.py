import asyncio

from ansel_sh.agents.observability import init_laminar
from ansel_sh.entities import create_entities
from ansel_sh.files import create_files

init_laminar()


async def main() -> None:
    # _ = await create_entities()
    _ = await create_files()


if __name__ == "__main__":
    asyncio.run(main())
