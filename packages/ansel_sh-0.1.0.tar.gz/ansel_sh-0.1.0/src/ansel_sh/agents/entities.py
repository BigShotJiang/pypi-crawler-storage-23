"""
Agent: Entities Analyst
    Responsible for determining most likely aggregation level from provided files.
    Input: FilesManifest
    Output: FileAggregation

Agent: Entities Extractor
    Responsible for populating an entities manifest from provided files.
    Input: FilesManifest + empty EntitiesManifest (headers only)
    Output: EntitiesManifest (filled in)
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..file_schemas import ENTITIES_MANIFEST, FILES_MANIFEST
from ..models import FileAggregation
from .base import Agent, StructuredAgent


class EntitiesAnalystInput(BaseModel):
    """Input for EntitiesAnalyst."""

    files_manifest_path: str = FILES_MANIFEST.filename
    target: str = "demand"
    target_description: str = """
        "Consumer demand in ecommerce. "
        "Lagging indicators of realized demand: revenue, units sold. "
        "Demand drivers: price, offers, campaigns, spend, traffic. "
        "Context for understanding unmet demand: inventory levels."
    """


class EntitiesAnalystOutput(BaseModel):
    """Output of EntitiesAnalyst."""

    aggregation: FileAggregation
    evidence: str


def _format_definitions(definitions: dict[str, str]) -> str:
    return "\n".join(f"- {key}: {value}" for key, value in definitions.items())


_ANALYST_SYSTEM_PROMPT = f"""
You are a csv file analyst, tasked with determining the most likely aggregation level for forecasting a target variable based on available data files. An updated files manifest {FILES_MANIFEST.filename} is provided. Read it to know what files to analyze.

Carefully inspect the contents of each file, then consider holistically the aggregation level for forecasting the target variable that has the highest likelihood of being comprehensive and successful. Valid aggregation levels and their definitions provided below:

{_format_definitions({a.value: a.description for a in FileAggregation})}

Remember in addition to the most likely aggregation level, you must also provide evidence to support your conclusion that is grounded in your analysis of the file contents.
"""

_ANALYST_QUERY_TEMPLATE = """
Determine the most likely aggregation level for forecasting {target} - {target_description}. Use the files manifest at: {files_manifest_path}.
"""


class EntitiesAnalyst(StructuredAgent[EntitiesAnalystInput, EntitiesAnalystOutput]):
    """Agent that infers the likely entity aggregation level from files."""

    system_prompt: str = _ANALYST_SYSTEM_PROMPT
    query_template: str = _ANALYST_QUERY_TEMPLATE
    output_model: type[BaseModel] | None = EntitiesAnalystOutput


ENTITIES_ANALYST = EntitiesAnalyst()


class EntitiesExtractorInput(BaseModel):
    """Input schema for the EntitiesExtractor agent."""

    files_manifest_path: str = FILES_MANIFEST.filename
    entities_manifest_path: str = ENTITIES_MANIFEST.filename
    aggregation: FileAggregation
    limit: int | None = Field(default=1, ge=1)


_EXTRACTOR_SYSTEM_PROMPT = f"""
You are a csv file analyst, tasked with extracting entity names and identifiers from provided data files. An updated files manifest {FILES_MANIFEST.filename} is provided. Read it to know what files to analyze.

Carefully inspect the contents of each file, then identify the distinct entities present at the requested aggregation level. An empty entities manifest {ENTITIES_MANIFEST.filename} has been prepared with headers: {", ".join(ENTITIES_MANIFEST.headers)}. Fill in rows for each entity you discover. Do not modify column headers. The columns are defined as follows:

{_format_definitions(ENTITIES_MANIFEST.column_descriptions)}
"""

_EXTRACTOR_QUERY_TEMPLATE = """
Extract entity names and identifiers at aggregation level: {aggregation}. Limit: {limit}. Use the files manifest at: {files_manifest_path}. Fill in the entities manifest at: {entities_manifest_path}.
"""


class EntitiesExtractor(Agent[EntitiesExtractorInput]):
    """Agent that populates an entities manifest from files."""

    system_prompt: str = _EXTRACTOR_SYSTEM_PROMPT
    query_template: str = _EXTRACTOR_QUERY_TEMPLATE


ENTITIES_EXTRACTOR = EntitiesExtractor()
