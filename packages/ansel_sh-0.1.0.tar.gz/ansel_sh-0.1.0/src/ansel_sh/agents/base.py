"""Base agent with Claude SDK infrastructure."""

from __future__ import annotations

import asyncio
import contextlib
import sys
from abc import ABC
from pathlib import Path
from typing import Generic, TypeVar, overload

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ResultMessage,
)
from pydantic import BaseModel

from ..events import publish
from .errors import raise_for_result
from .events import AgentRunCompleted, AgentRunFailed, AgentRunStarted
from .observability import get_trace_url, observe

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


class Agent(ABC, Generic[InputT]):
    """
    Base agent without structured output — returns ResultMessage.
    """

    model: str = "claude-haiku-4-5"
    system_prompt: str = ""
    query_template: str = ""
    output_model: type[BaseModel] | None = None


class StructuredAgent(Agent[InputT], Generic[InputT, OutputT]):
    """
    Agent with structured output — returns OutputT.
    """

    output_model: type[BaseModel] | None


@overload
async def run_agent(
    agent: StructuredAgent[InputT, OutputT],
    input_data: InputT,
    workdir: Path,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> OutputT: ...


@overload
async def run_agent(
    agent: Agent[InputT],
    input_data: InputT,
    workdir: Path,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> ResultMessage: ...


async def run_agent(
    agent: Agent[InputT],
    input_data: InputT,
    workdir: Path,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> BaseModel | ResultMessage:
    """
    Run an agent and return validated output.

    Args:
            agent: The agent to run.
            input_data: Input for the agent.
            workdir: Existing directory to use as the agent workdir.
            model: Override the agent's default model.
            trace: Enable Laminar observability tracing.

    Raises:
            ValueError: If workdir does not exist or is not a directory.
            ValueError: If the agent returns no ResultMessage.
            ValueError: If output_model is set but the agent returns no structured output.
            StructuredOutputRetriesError: If the agent exhausted structured output retries.
            AuthenticationError: If the API key is invalid or missing.
            AgentError: For other agent errors.
    """
    agent_name = agent.__class__.__name__

    if trace:
        observed = observe(name=f"{agent_name}Agent")(_run_agent_core)
        return await observed(agent, input_data, workdir, model=model)
    return await _run_agent_core(agent, input_data, workdir, model=model)


async def _run_agent_core(
    agent: Agent[InputT],
    input_data: InputT,
    workdir: Path,
    /,
    *,
    model: str | None = None,
) -> BaseModel | ResultMessage:
    if not workdir.exists() or not workdir.is_dir():
        raise ValueError(f"workdir must be an existing directory: {workdir}")

    agent_name = agent.__class__.__name__
    trace_url = get_trace_url()
    publish(AgentRunStarted(agent_name=agent_name, trace_url=trace_url))

    # Build the query from the input schema.
    format_data = input_data.model_dump()
    query = agent.query_template.format(**format_data) if agent.query_template else ""

    # Build output_format if output_model exists
    output_model = agent.output_model
    output_format = (
        {"type": "json_schema", "schema": output_model.model_json_schema()}
        if output_model
        else None
    )

    # Ensure the agent resolves file paths relative to its current directory.
    system_prompt = agent.system_prompt or ""
    system_prompt += "\nAll file paths are relative to your current directory (./). Use relative paths when reading or writing files."

    # Build agent options
    options = ClaudeAgentOptions(
        model=model or agent.model,
        system_prompt=system_prompt,
        cwd=workdir,
        permission_mode="bypassPermissions",
        output_format=output_format,
    )

    # Run the agent and capture the final result.
    result_message: ResultMessage | None = None
    tool_counts: dict[str, int] = {}
    message_count = 0
    turn_count: int | None = None

    def _record_tool_use(message: AssistantMessage) -> None:
        for block in message.content:
            name = getattr(block, "name", None)
            if isinstance(name, str):
                tool_counts[name] = tool_counts.get(name, 0) + 1

    def _format_summary() -> str:
        tools = ", ".join(f"{name}({count})" for name, count in sorted(tool_counts.items()))
        tools_part = tools or "none"
        turns_part = str(turn_count) if turn_count is not None else "unknown"
        return f"turns: {turns_part}, messages: {message_count}, tools: {tools_part}"

    spinner_task: asyncio.Task[None] | None = None

    async def _spinner() -> None:
        frames = "|/-\\"
        idx = 0
        while True:
            frame = frames[idx % len(frames)]
            print(f"\rAgent working... {frame}", end="", flush=True)
            idx += 1
            await asyncio.sleep(0.1)

    if sys.stdout.isatty():
        spinner_task = asyncio.create_task(_spinner())

    try:
        async with ClaudeSDKClient(options=options) as client:
            await client.query(query)
            async for message in client.receive_response():
                message_count += 1
                if isinstance(message, AssistantMessage):
                    _record_tool_use(message)
                if isinstance(message, ResultMessage):
                    raise_for_result(message)
                    result_message = message
                    turn_count = message.num_turns
                    break
    except Exception:
        publish(
            AgentRunFailed(
                agent_name=agent_name,
                trace_url=trace_url,
                summary=_format_summary(),
            )
        )
        raise
    finally:
        if spinner_task is not None:
            spinner_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await spinner_task
            print("\r", end="", flush=True)

    if result_message is None:
        raise ValueError("Agent did not return a ResultMessage")
        # TODO: do sth more useful when this happens

    publish(
        AgentRunCompleted(
            agent_name=agent_name,
            trace_url=trace_url,
            summary=_format_summary(),
        )
    )

    if output_model is None:
        return result_message
    else:
        if result_message.structured_output is None:
            raise ValueError("Agent did not return required structured output")
        return output_model.model_validate(result_message.structured_output)
