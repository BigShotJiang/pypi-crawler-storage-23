"""Output schemas for agent results."""
