"""
Forecast domain module.

Sections:
1. Forecast Entity
2. Domain Events
3. Agent Runners
4. Public Entrypoint
5. Resolution
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, override

from claude_agent_sdk import ResultMessage
from pydantic import BaseModel, Field

from .agents import run_agent
from .agents.forecasts import (
    FORECAST_TARGET_ANALYST,
    FORECASTER,
    ForecasterInput,
    ForecastTargetAnalystInput,
)
from .agents.observability import observe
from .entities import Entity, resolve_entities
from .events import Event, event, log_events, publish
from .file_schemas import (
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TARGET_SNAPSHOT,
    FilesManifestEntry,
    create_forecast_result,
    create_snapshot,
    generate_forecast_dates,
)
from .files import FileResult, resolve_files
from .forecast_models import ForecastModel, resolve_forecast_model
from .models import File, ForecastSettings
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import materialize, stage_files_to_sandbox
from .utils import generate_id, utc_now

# ============================================
# 1. FORECAST ENTITY
# ============================================


class ForecastItem(BaseModel, frozen=True):
    """Individual forecast data point."""

    date: str
    value: int


class Forecast(BaseModel):
    """
    Generated forecast.

    Created by running a two-agent pipeline:
    1. Target analyst — extracts recent target data from user files.
    2. Forecaster — fills in predicted values using model instructions.

    Attributes:
        id: Unique identifier (fct_xxx).
        entity_id: ID of the entity being forecasted.
        model_id: ID of the model used for forecasting.
        settings: Forecast settings used for generation.
        target_data: Target data snapshot file produced by step 1.
        result: Forecast result file produced by step 2.
        items: Individual forecast data points.
        created_at: When this forecast was created.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("fct"))

    # References
    entity_id: str
    model_id: str

    settings: ForecastSettings

    # Outputs
    target_data: File
    result: File
    items: list[ForecastItem] = Field(default_factory=list)

    # Time
    created_at: datetime = Field(default_factory=utc_now)


# ============================================
# 2. DOMAIN EVENTS
# ============================================


@event
class ForecastStarted(Event, frozen=True):
    entity_id: str
    model_id: str

    @override
    def message(self) -> str:
        return f"Start forecasting for entity {self.entity_id} with model {self.model_id}"


@event
class ForecastCompleted(Event, frozen=True):
    forecast_id: str
    entity_id: str

    @override
    def message(self) -> str:
        return f"Forecast {self.forecast_id} completed for entity {self.entity_id}"


@event
class ForecastFailed(Event, frozen=True):
    entity_id: str
    error: str

    @override
    def message(self) -> str:
        return f"Forecast failed for entity {self.entity_id}: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 3. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class ForecastTargetAnalystResult:
    """Output from a forecast target analyst run."""

    target_data: FileResult
    result: ResultMessage


@dataclass(frozen=True)
class ForecasterResult:
    """Output from a forecaster run."""

    forecast: FileResult
    items: list[ForecastItem]
    result: ResultMessage


class ForecastTargetAnalystRunner(Protocol):
    def __call__(
        self,
        entity: Entity,
        files: list[File],
        settings: ForecastSettings,
        /,
    ) -> Awaitable[ForecastTargetAnalystResult]: ...


class ForecasterRunner(Protocol):
    def __call__(
        self,
        entity: Entity,
        model: ForecastModel,
        target_data_file: File,
        settings: ForecastSettings,
        /,
    ) -> Awaitable[ForecasterResult]: ...


@observe(name="forecast_target_analyst")
async def _run_forecast_target_analyst(
    entity: Entity,
    files: list[File],
    settings: ForecastSettings,
    /,
) -> ForecastTargetAnalystResult:
    """Run step 1: extract target data from user files.

    The agent receives the files manifest, user files, and an empty target
    snapshot CSV in the sandbox. It reads the files and populates the target
    snapshot with all available data (no holdout).
    """
    if not files:
        raise ValueError("files required")

    # Create interval-aware snapshot definition for date format validation.
    target_snapshot = create_snapshot(
        settings.interval, TARGET_SNAPSHOT.stem, TARGET_SNAPSHOT.description
    )

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        manifest_entries = [FilesManifestEntry.from_file(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, manifest_entries)

        # Write empty target snapshot (headers only) for the agent to populate.
        target_snapshot_path = target_snapshot.dump(sandbox_dir, [])

        agent_input = ForecastTargetAnalystInput(
            entity_name=entity.name,
            entity_aggregation=entity.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            files_manifest_path=files_manifest_path,
            target_snapshot_path=target_snapshot_path,
        )

        result_message = await run_agent(FORECAST_TARGET_ANALYST, agent_input, sandbox_dir)

        # Validate agent output in sandbox before materialization
        target_validation_result = target_snapshot.validate_file(sandbox_dir)

        # Materialize agent output
        target_data_file = materialize(
            target_snapshot, sandbox_dir, agent_name="forecast_target_analyst"
        )

        return ForecastTargetAnalystResult(
            target_data=FileResult(file=target_data_file, issues=target_validation_result.issues),
            result=result_message,
        )


@observe(name="forecaster")
async def _run_forecaster(
    entity: Entity,
    model: ForecastModel,
    target_data_file: File,
    settings: ForecastSettings,
    /,
) -> ForecasterResult:
    """Run step 2: fill in forecast values from model instructions + target data.

    The agent receives the target snapshot (read-only context), model
    instructions (read-only context), and a pre-staged forecast template with
    dates pre-filled and target column set to None. It fills in the target
    column values.
    """
    # Load target entries from the materialized analyst output.
    target_entries = TARGET_SNAPSHOT.load(target_data_file.local_path.parent)
    if not target_entries:
        raise ValueError("target snapshot is empty")

    # Find last date and generate forecast dates.
    last_date = target_entries[-1].date
    forecast_dates = generate_forecast_dates(last_date, settings.interval, settings.horizon)

    # Create the parameterized forecast result definition.
    forecast_result_def = create_forecast_result(settings.target, settings.interval)
    forecast_entry_model = forecast_result_def.row_model

    # Load model instructions from materialized trainer output.
    model_instructions_entries = MODEL_INSTRUCTIONS.load(model.instructions.local_path.parent)

    with create_agent_sandbox_dir() as sandbox_dir:
        # Dump target snapshot into sandbox (read-only context).
        target_snapshot_path = TARGET_SNAPSHOT.dump(sandbox_dir, target_entries)

        # Dump model instructions into sandbox (read-only context).
        _ = MODEL_INSTRUCTIONS.dump(sandbox_dir, model_instructions_entries)

        # Dump pre-filled forecast template (dates filled, target=None).
        template_rows = [
            forecast_entry_model.model_validate({"date": d, settings.target: None})
            for d in forecast_dates
        ]
        forecast_result_path = forecast_result_def.dump(sandbox_dir, template_rows)

        # Capture immutable date values for validation.
        immutable_values = forecast_result_def.immutable_row_values(template_rows)

        agent_input = ForecasterInput(
            entity_name=entity.name,
            entity_aggregation=entity.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            target_snapshot_path=target_snapshot_path,
            model_instructions_path=MODEL_INSTRUCTIONS.filename,
            forecast_result_path=forecast_result_path,
        )

        result_message = await run_agent(FORECASTER, agent_input, sandbox_dir)

        # Validate the forecast result file.
        forecast_validation_result = forecast_result_def.validate_file(
            sandbox_dir, immutable_values=immutable_values
        )

        # Materialize the forecast result file.
        forecast_file = materialize(forecast_result_def, sandbox_dir, agent_name="forecaster")

        # Parse entries and convert to ForecastItems.
        result_entries = forecast_result_def.load(sandbox_dir)
        items: list[ForecastItem] = []
        for entry in result_entries:
            data: dict[str, object] = dict(entry.model_dump())
            target_value = data.get(settings.target)
            if isinstance(target_value, (int, float)):
                items.append(ForecastItem(date=str(data["date"]), value=int(target_value)))

        return ForecasterResult(
            forecast=FileResult(file=forecast_file, issues=forecast_validation_result.issues),
            items=items,
            result=result_message,
        )


# ============================================
# 4. PUBLIC ENTRYPOINT
# ============================================


@log_events
async def create_forecast(
    entity: Entity | None = None,
    files: File | list[File] | None = None,
    model: ForecastModel | None = None,
    settings: ForecastSettings | None = None,
) -> Forecast:
    """
    Public entrypoint: resolve files, entity, model, then generate a forecast.

    Handles run context, file resolution, entity resolution, model training
    (if needed), and forecast generation end-to-end.

    Args:
        entity: Entity to forecast for. When None, files are analyzed
            and the first discovered entity is used.
        files: Input data files. Accepts a single File, a list, or None to
            discover from the default data directory.
        model: Pre-trained forecast model. When None, one is trained
            automatically via resolve_forecast_model.
        settings: Forecast settings. Defaults to standard settings when None.

    Returns:
        Generated Forecast.
    """
    with with_run_context():
        # Resolve files — ensures classification.
        if files is None:
            resolved_files = await resolve_files()
        else:
            input_files = [files] if isinstance(files, File) else files
            resolved_files = await resolve_files(input_files)

        # Resolve entity — discover from files when not provided.
        if entity is None:
            entities = await resolve_entities(resolved_files)
            if not entities:
                raise ValueError("no entities found")
            entity = entities[0]

        resolved_settings = settings if settings is not None else ForecastSettings()

        # Resolve model — train one if not provided.
        if model is None:
            model = await resolve_forecast_model(entity, resolved_files, resolved_settings)

        return await resolve_forecast(entity, resolved_files, model, resolved_settings)


# ============================================
# 5. RESOLUTION
# ============================================


async def resolve_forecast(
    entity: Entity,
    files: list[File],
    model: ForecastModel,
    settings: ForecastSettings,
    target_analyst_runner: ForecastTargetAnalystRunner = _run_forecast_target_analyst,
    forecaster_runner: ForecasterRunner = _run_forecaster,
    /,
) -> Forecast:
    """
    Internal resolver: run target analyst then forecaster agents sequentially.

    Called after entities, files, and model are resolved. Accepts optional
    runner overrides for testing without live agent calls.

    Args:
        entity: The entity to forecast for.
        files: Classified files to use for target data extraction.
        model: Trained forecast model with instructions.
        settings: Forecast settings (target, interval, horizon).
        target_analyst_runner: Extracts target data from files.
        forecaster_runner: Generates forecast values.

    Returns:
        Generated Forecast.

    Raises:
        ValueError: If files is empty.
    """
    if not files:
        raise ValueError("files required")

    publish(ForecastStarted(entity_id=entity.id, model_id=model.id))

    try:
        # Target analyst: extract recent target data from user files
        target_analyst_result = await target_analyst_runner(entity, files, settings)
        target_data_file = target_analyst_result.target_data.file

        # Forecaster: fill in predicted values
        forecaster_result = await forecaster_runner(entity, model, target_data_file, settings)

        forecast = Forecast(
            entity_id=entity.id,
            model_id=model.id,
            settings=settings,
            target_data=target_data_file,
            result=forecaster_result.forecast.file,
            items=forecaster_result.items,
        )

        publish(ForecastCompleted(forecast_id=forecast.id, entity_id=entity.id))
        return forecast
    except Exception as exc:
        publish(ForecastFailed(entity_id=entity.id, error=str(exc)))
        raise
