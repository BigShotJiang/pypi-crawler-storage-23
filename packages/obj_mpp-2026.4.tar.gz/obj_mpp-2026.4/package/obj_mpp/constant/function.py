"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

from obj_mpp.hint.function import parameter_t

UNSUPPORTED_PARAMETER_KINDS = (
    parameter_t.POSITIONAL_OR_KEYWORD,
    parameter_t.VAR_POSITIONAL,
    parameter_t.VAR_KEYWORD,
)
