"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

from enum import Enum as enum_t


class reduction_e(enum_t):
    MEAN = 1
    STDDEV = 2
    VARIANCE = 3
    MEDIAN = 4
    MIN = 5
    MAX = 6
