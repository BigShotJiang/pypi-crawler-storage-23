"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import typing as h

from matplotlib.backend_bases import Event as event_t, MouseEvent as event_mouse_t

button_press_event_h = h.TypeVar("button_press_event_h", bound=event_t | event_mouse_t)
button_release_event_h = h.TypeVar(
    "button_release_event_h", bound=event_t | event_mouse_t
)
