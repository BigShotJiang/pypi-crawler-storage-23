from polar_cli.app import main

main()
