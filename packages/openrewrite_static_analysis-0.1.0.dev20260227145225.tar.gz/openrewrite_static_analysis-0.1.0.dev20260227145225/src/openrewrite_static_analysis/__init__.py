"""OpenRewrite static analysis and code cleanup recipes for Python."""

import importlib
import inspect
import pkgutil

from rewrite import Recipe, RecipeMarketplace

__all__ = ["activate"]


def activate(marketplace: RecipeMarketplace) -> None:
    """
    Install all static analysis recipes into the marketplace.

    This function is called by the OpenRewrite discovery mechanism when the
    openrewrite-static-analysis package is found via entry points.

    Args:
        marketplace: The RecipeMarketplace to install recipes into
    """
    from rewrite.decorators import get_recipe_category

    from . import cleanup as cleanup_pkg

    # Auto-discover all Recipe subclasses from the cleanup package
    for module_info in pkgutil.walk_packages(
        cleanup_pkg.__path__, prefix=cleanup_pkg.__name__ + "."
    ):
        module = importlib.import_module(module_info.name)
        for _name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, Recipe) and obj is not Recipe and obj.__module__ == module.__name__:
                category = get_recipe_category(obj)
                if category is not None:
                    marketplace.install(obj, category)
