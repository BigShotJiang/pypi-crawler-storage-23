"""
Recipes that modernize and improve pandas API usage.

- DataframeAppendToConcat: Migrate deprecated ``.append()`` to ``pd.concat()``
- PandasAvoidInplace: Convert ``inplace=True`` mutations to explicit reassignment
- ReplaceApplyWithMethodCall: Turn ``apply("method_name")`` into a direct call
- UseIsna: Fix broken ``== np.nan`` checks by switching to ``.isna()``

Caveat: These recipes rely on syntactic matching without type resolution.
Results should be reviewed, especially in mixed codebases.

See: https://pandas.pydata.org/docs/whatsnew/v1.4.0.html#deprecations
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python.tree import NamedArgument
from rewrite.java.tree import Binary as JBinary, Empty, Expression, Identifier, Literal, MethodInvocation
from rewrite.java.support_types import JContainer, JRightPadded, Space
from rewrite.utils import random_id

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template pairs for df.append(x) -> pd.concat([df, x])
_df = capture('df')
_x = capture('x')
_append_pattern = pattern("{df}.append({x})", df=_df, x=_x)
_concat_template = template("pd.concat([{df}, {x}])", df=_df, x=_x)


@categorize(_Cleanup)
class DataframeAppendToConcat(Recipe):
    """
    Migrate from the removed ``DataFrame.append()`` to ``pd.concat()``.

    ``DataFrame.append()`` was deprecated starting with pandas 1.4.0 and
    no longer exists in pandas 2.0+. This recipe rewrites ``.append()``
    calls into the equivalent ``pd.concat()`` form.

    **Warning**: Because no type information is available, this recipe
    transforms *every* ``.append(arg)`` call it encounters -- including
    calls on lists, deques, and other types that have their own ``.append()``
    method. Apply this recipe only when DataFrame usage dominates, or
    inspect each change individually. It is deliberately excluded from
    ``PythonBestPractices``; enable it on a per-project basis.

    Example:
        Before:
            merged = orders.append(new_orders)

        After:
            merged = pd.concat([orders, new_orders])
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.DataframeAppendToConcat"

    @property
    def display_name(self) -> str:
        return "Migrate deprecated `.append()` to `pd.concat()`"

    @property
    def description(self) -> str:
        return (
            "`DataFrame.append()` no longer exists in pandas 2.0+. "
            "This recipe rewrites `.append(x)` calls to `pd.concat([df, x])`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _append_pattern.match(method, self.cursor)
                if match:
                    return _concat_template.apply(self.cursor, values=match)
                return method

        return Visitor()


def _find_inplace_true(method: MethodInvocation) -> Optional[int]:
    """Find the index of an ``inplace=True`` keyword argument.

    Returns the index in the arguments list, or None if not found.
    Only matches when the value is the literal ``True``, not ``False``.
    """
    for i, arg in enumerate(method.arguments):
        if isinstance(arg, NamedArgument):
            if arg.name.simple_name == "inplace":
                val = arg.value
                if isinstance(val, Literal) and val.value is True:
                    return i
    return None


def _remove_arg_at(method: MethodInvocation, index: int) -> MethodInvocation:
    """Remove the argument at the given index from a MethodInvocation.

    Adjusts whitespace so trailing commas and spaces are cleaned up.
    """
    container = method.padding.arguments
    padded_args = list(container._elements)  # List[JRightPadded[Expression]]
    padded_args.pop(index)
    # If we removed the last arg, clean up trailing comma space on the new last arg
    if padded_args and index == len(padded_args):
        last = padded_args[-1]
        padded_args[-1] = last.replace(_after=Space.EMPTY)
    # If no args remain, add an Empty element (standard for empty arg lists)
    if not padded_args:
        empty = Empty(
            _id=random_id(),
            _prefix=Space.EMPTY,
            _markers=Markers.EMPTY,
        )
        padded_args = [JRightPadded(
            _element=empty,
            _after=Space.EMPTY,
            _markers=Markers.EMPTY,
        )]
    new_container = container.replace(_elements=padded_args)
    return method.replace(_arguments=new_container)


@categorize(_Cleanup)
class PandasAvoidInplace(Recipe):
    """
    Convert ``inplace=True`` pandas operations to explicit reassignment.

    The ``inplace`` parameter hinders method chaining, complicates type
    checking, and rarely provides any performance benefit because most
    pandas methods still create an internal copy. This recipe drops
    ``inplace=True`` and wraps the call in a plain assignment instead.

    Example:
        Before:
            sales.drop_duplicates(subset="id", inplace=True)

        After:
            sales = sales.drop_duplicates(subset="id")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.PandasAvoidInplace"

    @property
    def display_name(self) -> str:
        return "Eliminate `inplace=True` in favor of reassignment"

    @property
    def description(self) -> str:
        return (
            "Convert pandas operations that use `inplace=True` into "
            "reassignment form, e.g. `df.drop_duplicates(inplace=True)` "
            "becomes `df = df.drop_duplicates()`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[Expression]:
                method = super().visit_method_invocation(method, p)
                if not isinstance(method, MethodInvocation):
                    return method
                # Must have a select (receiver): df.method(...)
                select = method.select
                if select is None:
                    return method
                inplace_idx = _find_inplace_true(method)
                if inplace_idx is None:
                    return method
                # Remove the inplace=True argument
                cleaned = _remove_arg_at(method, inplace_idx)
                # Build: df = df.method(...)
                from rewrite.java.tree import Assignment as JAssignment
                from rewrite.java.support_types import JLeftPadded
                target = select.replace(_prefix=method.prefix)
                call = cleaned.replace(_prefix=Space.SINGLE_SPACE)
                assignment = JAssignment(
                    _id=random_id(),
                    _prefix=method.prefix,
                    _markers=Markers.EMPTY,
                    _variable=target,
                    _assignment=JLeftPadded(
                        _before=Space.SINGLE_SPACE,
                        _element=call,
                        _markers=Markers.EMPTY,
                    ),
                    _type=None,
                )
                return assignment

        return Visitor()


@categorize(_Cleanup)
class ReplaceApplyWithMethodCall(Recipe):
    """
    Simplify ``apply("name")`` into a direct method invocation.

    Passing a string to ``apply()`` to invoke a named aggregation is
    less readable and slower than calling the corresponding method
    directly on the DataFrame or Series.

    Example:
        Before:
            totals = sales.apply("mean")

        After:
            totals = sales.mean()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ReplaceApplyWithMethodCall"

    @property
    def display_name(self) -> str:
        return "Convert `apply('name')` to a direct method invocation"

    @property
    def description(self) -> str:
        return (
            "When `apply()` receives a string literal like `'sum'` or `'mean'`, "
            "rewrite the call as a direct method invocation on the object."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                if not isinstance(method, MethodInvocation):
                    return method
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "apply":
                    return method
                # Must have exactly one argument, which is a string literal
                args = list(method.arguments)
                if len(args) != 1:
                    return method
                arg = args[0]
                if not isinstance(arg, Literal):
                    return method
                method_name = arg.value
                if not isinstance(method_name, str):
                    return method
                # Replace method name with the string value
                new_name = method.name.replace(_simple_name=method_name)
                # Create empty arguments container (no args)
                empty = Empty(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                )
                new_args = JContainer(
                    _before=Space.EMPTY,
                    _elements=[JRightPadded(
                        _element=empty,
                        _after=Space.EMPTY,
                        _markers=Markers.EMPTY,
                    )],
                    _markers=Markers.EMPTY,
                )
                return method.replace(_name=new_name, _arguments=new_args)

        return Visitor()


# Pattern/template pairs for UseIsna
_isna_expr = capture('expr')
_np_nan_pattern = pattern("{expr} == np.nan", expr=_isna_expr)
_numpy_nan_pattern = pattern("{expr} == numpy.nan", expr=_isna_expr)
_isna_template = template("{expr}.isna()", expr=_isna_expr)


@categorize(_Cleanup)
class UseIsna(Recipe):
    """
    Fix incorrect ``== np.nan`` comparisons by using ``.isna()`` instead.

    Equality checks against ``np.nan`` are always ``False`` due to IEEE 754
    floating-point semantics -- NaN is never equal to anything, including
    itself. The ``.isna()`` method is the proper pandas API for detecting
    missing values.

    Example:
        Before:
            prices["discount"] == np.nan

        After:
            prices["discount"].isna()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseIsna"

    @property
    def display_name(self) -> str:
        return "Use `.isna()` instead of `== np.nan` comparisons"

    @property
    def description(self) -> str:
        return (
            "Rewrite `== np.nan` and `== numpy.nan` equality tests as `.isna()` "
            "calls, since direct NaN comparison always evaluates to False."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_binary(binary, p)
                match = _np_nan_pattern.match(binary, self.cursor)
                if match:
                    return _isna_template.apply(self.cursor, values=match)
                match = _numpy_nan_pattern.match(binary, self.cursor)
                if match:
                    return _isna_template.apply(self.cursor, values=match)
                return binary

        return Visitor()
