"""
Recipes that strip out code constructs which have no observable effect.

- RemoveRedundantPass: Delete ``pass`` from blocks that already contain other statements.
- RemoveRedundantContinue: Delete a trailing ``continue`` at the end of a loop iteration where the loop would restart anyway.
- RemoveRedundantPathExists: Eliminate a ``path.exists()`` guard when the next check is ``is_dir()`` or ``is_file()``, which already handle non-existent paths.
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python import tree as py_tree
from rewrite.python.template import pattern, template, capture
from rewrite.java import tree as j
from rewrite.java.tree import Binary as JBinary, Empty, Identifier, MethodInvocation
from openrewrite_static_analysis.cleanup import trees_equal

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


@categorize(_Cleanup)
class RemoveRedundantPass(Recipe):
    """
    Delete ``pass`` statements that appear alongside real statements.

    ``pass`` serves as a no-op placeholder so that syntactically required
    blocks (class bodies, function bodies, conditionals, etc.) are not
    empty. Once a block contains any other statement, the ``pass`` adds
    no value and should be removed.

    Example:
        Before:
            class Config:
                debug = True
                pass

        After:
            class Config:
                debug = True
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantPass"

    @property
    def display_name(self) -> str:
        return "Delete unnecessary ``pass`` in non-empty blocks"

    @property
    def description(self) -> str:
        return (
            "Delete ``pass`` when the enclosing block already contains other "
            "statements; ``pass`` is only useful as a placeholder in empty blocks."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_pass(
                self, pass_: py_tree.Pass, p: ExecutionContext
            ) -> Optional[py_tree.Pass]:
                pass_ = super().visit_pass(pass_, p)
                if pass_ is None:
                    return None
                block = self.cursor.first_enclosing(j.Block)
                if block and len(block.statements) > 1:
                    return None
                return pass_

        return Visitor()


@categorize(_Cleanup)
class RemoveRedundantContinue(Recipe):
    """
    Strip a trailing ``continue`` that adds no effect at the end of a loop body.

    When ``continue`` is the last statement inside a ``for`` or ``while``
    block, it is superfluous because the loop would advance to the next
    iteration on its own.

    Example:
        Before:
            for line in lines:
                process(line)
                continue

        After:
            for line in lines:
                process(line)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantContinue"

    @property
    def display_name(self) -> str:
        return "Strip trailing ``continue`` from loop body"

    @property
    def description(self) -> str:
        return (
            "Strip ``continue`` when it is the final statement in a loop body, "
            "since the loop naturally advances to the next iteration."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_continue(
                self, continue_: j.Continue, p: ExecutionContext
            ) -> Optional[j.Continue]:
                continue_ = super().visit_continue(continue_, p)
                if continue_ is None:
                    return None
                block = self.cursor.first_enclosing(j.Block)
                if not block:
                    return continue_
                stmts = block.statements
                # Only remove if continue is the last statement and
                # the block has more than one statement
                if len(stmts) < 2:
                    return continue_
                if not (isinstance(stmts[-1], j.Continue) and stmts[-1].id == continue_.id):
                    return continue_
                # Ensure the block is the direct body of a loop
                loop = self.cursor.first_enclosing(j.ForEachLoop)
                if not loop:
                    loop = self.cursor.first_enclosing(j.WhileLoop)
                if loop and isinstance(loop.body, j.Block) and loop.body.id == block.id:
                    return None
                return continue_

        return Visitor()


def _has_no_args(method: MethodInvocation) -> bool:
    """Check if a method invocation has no actual arguments (just an Empty marker)."""
    args = method.arguments
    return len(args) == 0 or (len(args) == 1 and isinstance(args[0], Empty))


def _is_method_call(node, method_name: str) -> bool:
    """Check if a node is a method invocation with the given name and no arguments."""
    return (
        isinstance(node, MethodInvocation)
        and isinstance(node.name, Identifier)
        and node.name.simple_name == method_name
        and _has_no_args(node)
    )


@categorize(_Cleanup)
class RemoveRedundantPathExists(Recipe):
    """
    Eliminate a superfluous ``exists()`` guard paired with ``is_dir()`` or ``is_file()``.

    Both ``pathlib.Path.is_dir()`` and ``pathlib.Path.is_file()`` already
    yield ``False`` when the path does not exist, so a preceding
    ``path.exists()`` check joined with ``and`` adds no information.

    Example:
        Before:
            if target.exists() and target.is_file():
                upload(target)

        After:
            if target.is_file():
                upload(target)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantPathExists"

    @property
    def display_name(self) -> str:
        return "Drop ``exists()`` check before ``is_dir()``/``is_file()``"

    @property
    def description(self) -> str:
        return (
            "Drop ``path.exists()`` when it is ``and``-ed with ``is_dir()`` "
            "or ``is_file()``, which inherently return ``False`` for missing paths."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # Must be an 'and' binary expression
                if binary.operator != JBinary.Type.And:
                    return binary

                left = binary.left
                right = binary.right

                # Case 1: exists() on left, is_dir()/is_file() on right
                if _is_method_call(left, "exists") and _is_method_call(right, "is_dir") or \
                   _is_method_call(left, "exists") and _is_method_call(right, "is_file"):
                    if left.select and right.select and trees_equal(left.select, right.select, self.cursor):
                        return right.replace(_prefix=binary.prefix)

                # Case 2: is_dir()/is_file() on left, exists() on right
                if _is_method_call(right, "exists") and _is_method_call(left, "is_dir") or \
                   _is_method_call(right, "exists") and _is_method_call(left, "is_file"):
                    if left.select and right.select and trees_equal(left.select, right.select, self.cursor):
                        return left.replace(_prefix=binary.prefix)

                return binary

        return Visitor()
