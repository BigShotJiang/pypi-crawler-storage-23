"""Umbrella recipe that bundles every individual Python cleanup transformation."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


@categorize(_Cleanup)
class PythonBestPractices(Recipe):
    """
    Run the full suite of Python cleanup transformations.

    This umbrella recipe aggregates every individual cleanup rule --
    covering style, correctness, and readability improvements -- into
    a single invocation.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.PythonBestPractices"

    @property
    def display_name(self) -> str:
        return "Python cleanup suite"

    @property
    def description(self) -> str:
        return (
            "Run every Python cleanup recipe in one pass -- literal "
            "simplification, boolean and comparison tidying, dead code "
            "removal, naming fixes, pandas modernization, and more."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "cleanup", "best-practices"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of all cleanup recipes to apply."""
        # Import here to avoid circular imports
        from .boolean_simplification import (
            BooleanIfExpIdentity,
            CollectionToBool,
            DeMorgan,
            RemoveRedundantBoolean,
            SimplifyBooleanComparison,
            SimplifyLenComparison,
            SimplifyStrLenComparison,
        )
        from .collection_literals import (
            CollectionIntoSet,
            DictLiteral,
            ListLiteral,
            TupleLiteral,
            UnwrapIterableConstruction,
        )
        from .comparison_simplification import (
            FlipComparison,
            MergeComparisons,
            SimplifySubstringSearch,
        )
        from .complex_transforms import (
            DefaultMutableArg,
            SwapVariable,
            TernaryToIfExpression,
        )
        from .comprehension_cleanup import (
            CollectionBuiltinToComprehension,
            ComprehensionToGenerator,
            ConvertAnyToIn,
            IdentityComprehension,
            InvertAnyAll,
            InvertAnyAllBody,
            SimplifyConstantSum,
            SimplifyGenerator,
        )
        from .conditionals import (
            AssignIfExp,
            MergeElseIfIntoElif,
            MergeIsinstance,
            MergeNestedIfs,
            RemovePassElif,
            RemoveRedundantCondition,
            RemoveRedundantIf,
            RemoveUnnecessaryElse,
            SwapIfElseBranches,
        )
        from .datetime_cleanup import UseDatetimeNowNotToday
        from .dict_cleanup import (
            RemoveDictKeys,
            RemoveDuplicateDictKey,
            RemoveDuplicateSetKey,
            RemoveRedundantConstructorInDictUnion,
            SimplifyDictionaryUpdate,
            UseDictionaryUnion,
        )
        from .exception_cleanup import (
            DoNotUseBareExcept,
            RaiseFromPreviousError,
            SimplifySingleExceptionTuple,
            UseContextlibSuppress,
        )
        from .expression_simplification import (
            AugAssign,
            OrIfExpIdentity,
            SwapIfExpression,
        )
        from .loop_cleanup import (
            UseFileIterator,
            UselessElseOnLoop,
            YieldFrom,
        )
        from .naming_conventions import ClassMethodFirstArgName
        from .none_and_identity import (
            BinOpIdentity,
            EqualityIdentity,
            NoneCompare,
            SquareIdentity,
        )
        from .pandas_cleanup import (
            PandasAvoidInplace,
            ReplaceApplyWithMethodCall,
            UseIsna,
        )
        from .range_cleanup import RemoveUnitStepFromRange, RemoveZeroFromRange
        from rewrite.python.recipes import RemovePass
        from .redundant_code import (
            RemoveRedundantContinue,
            RemoveRedundantPathExists,
        )
        from .string_cleanup import (
            RemoveNoneFromDefaultGet,
            RemoveRedundantFstring,
            RemoveStrFromFstring,
            RemoveStrFromPrint,
            SimplifyFstringFormatting,
            StrPrefixSuffix,
            UseGetitemForReMatchGroups,
            UseStringRemoveAffix,
        )
        from .syntax_cleanup import (
            BreakOrContinueOutsideLoop,
            ReturnOrYieldOutsideFunction,
        )
        from .unreachable_code import (
            RemoveAssertTrue,
            RemoveEmptyNestedBlock,
            RemoveUnreachableCode,
        )

        return [
            # Collection literals
            DictLiteral(),
            ListLiteral(),
            TupleLiteral(),
            CollectionIntoSet(),
            UnwrapIterableConstruction(),
            # Range cleanup
            RemoveZeroFromRange(),
            RemoveUnitStepFromRange(),
            # None and identity
            NoneCompare(),
            EqualityIdentity(),
            BinOpIdentity(),
            SquareIdentity(),
            # Boolean simplification
            SimplifyBooleanComparison(),
            BooleanIfExpIdentity(),
            RemoveRedundantBoolean(),
            # SimplifyEmptyCollectionComparison intentionally excluded:
            # `x == ""` → `not x` changes semantics (not x is also true for None, 0, False, etc.)
            SimplifyLenComparison(),
            SimplifyStrLenComparison(),
            CollectionToBool(),
            DeMorgan(),
            # Comparison simplification
            FlipComparison(),
            SimplifySubstringSearch(),
            MergeComparisons(),
            MergeIsinstance(),
            # Expression simplification
            OrIfExpIdentity(),
            SwapIfExpression(),
            AugAssign(),
            # Conditionals
            RemoveRedundantCondition(),
            MergeNestedIfs(),
            MergeElseIfIntoElif(),
            SwapIfElseBranches(),
            RemovePassElif(),
            RemoveRedundantIf(),
            RemoveUnnecessaryElse(),
            AssignIfExp(),
            # Redundant code
            RemovePass(),
            RemoveRedundantContinue(),
            RemoveRedundantPathExists(),
            # Unreachable code
            RemoveAssertTrue(),
            RemoveUnreachableCode(),
            RemoveEmptyNestedBlock(),
            # String cleanup
            RemoveStrFromPrint(),
            RemoveNoneFromDefaultGet(),
            RemoveRedundantFstring(),
            RemoveStrFromFstring(),
            StrPrefixSuffix(),
            UseGetitemForReMatchGroups(),
            SimplifyFstringFormatting(),
            UseStringRemoveAffix(),
            # Dict cleanup
            RemoveDictKeys(),
            SimplifyDictionaryUpdate(),
            UseDictionaryUnion(),
            RemoveRedundantConstructorInDictUnion(),
            RemoveDuplicateDictKey(),
            RemoveDuplicateSetKey(),
            # Loop cleanup
            UseFileIterator(),
            UselessElseOnLoop(),
            YieldFrom(),
            # Comprehension cleanup
            CollectionBuiltinToComprehension(),
            SimplifyGenerator(),
            ComprehensionToGenerator(),
            IdentityComprehension(),
            InvertAnyAll(),
            InvertAnyAllBody(),
            ConvertAnyToIn(),
            SimplifyConstantSum(),
            # Exception cleanup
            DoNotUseBareExcept(),
            SimplifySingleExceptionTuple(),
            RaiseFromPreviousError(),
            UseContextlibSuppress(),
            # Naming conventions
            ClassMethodFirstArgName(),
            # Pandas cleanup
            PandasAvoidInplace(),
            ReplaceApplyWithMethodCall(),
            UseIsna(),
            # Complex transforms
            TernaryToIfExpression(),
            DefaultMutableArg(),
            SwapVariable(),
            # Syntax cleanup
            BreakOrContinueOutsideLoop(),
            ReturnOrYieldOutsideFunction(),
            # Datetime cleanup
            UseDatetimeNowNotToday(),
        ]
