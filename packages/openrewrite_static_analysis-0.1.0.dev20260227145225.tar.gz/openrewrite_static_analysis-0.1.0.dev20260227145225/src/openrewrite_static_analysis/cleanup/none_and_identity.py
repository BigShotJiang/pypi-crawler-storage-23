"""
Recipes that fix ``None`` comparison style and simplify algebraic identity expressions.

- ``val == None`` becomes ``val is None``; ``val != None`` becomes ``val is not None`` (NoneCompare)
- Identical-literal comparisons like ``5 == 5`` are folded to ``True`` / ``False`` (EqualityIdentity)
- Self-referencing bitwise/arithmetic ops such as ``n | n``, ``n ^ n`` are collapsed (BinOpIdentity)
- Self-multiplication like ``n * n`` is rewritten as ``n ** 2`` (SquareIdentity)

See: https://peps.python.org/pep-0008/#programming-recommendations
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from openrewrite_static_analysis.cleanup import trees_equal
from rewrite.java.tree import Binary as JBinary, Literal

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template pairs for == None -> is None
_x = capture('x')
_eq_none_pattern = pattern("{x} == None", x=_x)
_is_none_template = template("{x} is None", x=_x)

# Pattern/template pairs for != None -> is not None
_neq_none_pattern = pattern("{x} != None", x=_x)
_is_not_none_template = template("{x} is not None", x=_x)

# Templates for EqualityIdentity
_true_template = template("True")
_false_template = template("False")

# Templates for BinOpIdentity
_zero_template = template("0")

# Templates for SquareIdentity
_base = capture('base')
_power_template = template("{base} ** 2", base=_base)

# BinOpIdentity: operators that collapse to zero (self-cancelling)
_ZERO_OPS = frozenset({JBinary.Type.BitXor, JBinary.Type.Subtraction})



@categorize(_Cleanup)
class NoneCompare(Recipe):
    """
    Switch ``== None`` / ``!= None`` to ``is None`` / ``is not None``.

    ``None`` is a singleton, so the correct way to test for it is with
    the identity operators ``is`` and ``is not`` rather than the equality
    operators ``==`` and ``!=``. This follows the PEP 8 programming
    recommendations.

    Example:
        Before:
            if response == None:
                handle_missing()

        After:
            if response is None:
                handle_missing()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.NoneCompare"

    @property
    def display_name(self) -> str:
        return "Compare to `None` with identity operators (`is` / `is not`)"

    @property
    def description(self) -> str:
        return "Switch `== None` to `is None` and `!= None` to `is not None`, following PEP 8 singleton comparison guidance."

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                match = _eq_none_pattern.match(binary, self.cursor)
                if match:
                    return _is_none_template.apply(self.cursor, values=match)
                match = _neq_none_pattern.match(binary, self.cursor)
                if match:
                    return _is_not_none_template.apply(self.cursor, values=match)
                return binary

        return Visitor()


@categorize(_Cleanup)
class EqualityIdentity(Recipe):
    """
    Fold comparisons of a literal to itself into ``True`` or ``False``.

    When both operands of ``==`` or ``!=`` are the same literal, the
    outcome is statically determined: equality yields ``True`` and
    inequality yields ``False``. Replacing the comparison with the
    boolean constant makes the intent obvious.

    Example:
        Before:
            if 42 == 42:
                run_guaranteed()
            if 42 != 42:
                run_impossible()

        After:
            if True:
                run_guaranteed()
            if False:
                run_impossible()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.EqualityIdentity"

    @property
    def display_name(self) -> str:
        return "Fold same-literal `==`/`!=` comparisons to boolean constants"

    @property
    def description(self) -> str:
        return (
            "When both sides of `==` or `!=` are the same literal, replace the "
            "expression with `True` or `False` respectively."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                op = binary.operator
                if op not in (JBinary.Type.Equal, JBinary.Type.NotEqual):
                    return binary
                left = binary.left
                right = binary.right
                # Both sides must be literals
                if not isinstance(left, Literal) or not isinstance(right, Literal):
                    return binary
                if not trees_equal(left, right, self.cursor):
                    return binary
                if op == JBinary.Type.Equal:
                    return _true_template.apply(self.cursor, values={})
                else:
                    return _false_template.apply(self.cursor, values={})

        return Visitor()


@categorize(_Cleanup)
class BinOpIdentity(Recipe):
    """
    Collapse self-cancelling binary operations on duplicate operands to zero.

    When the left and right operands of ``^`` or ``-`` are the same
    expression, the result is always ``0``.

    Note: ``n | n`` and ``n & n`` are mathematically idempotent but are
    intentionally excluded — real code uses these patterns deliberately
    (e.g., boolean filter masks).

    Example:
        Before:
            delta = x ^ x

        After:
            delta = 0
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.BinOpIdentity"

    @property
    def display_name(self) -> str:
        return "Collapse self-cancelling `^` / `-` with duplicate operands to `0`"

    @property
    def description(self) -> str:
        return (
            "When both operands of `^` or `-` are the same expression, "
            "reduce to `0` (the self-cancelling identity)."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                op = binary.operator
                if op not in _ZERO_OPS:
                    return binary
                if not trees_equal(binary.left, binary.right, self.cursor):
                    return binary
                return _zero_template.apply(self.cursor, values={})

        return Visitor()


@categorize(_Cleanup)
class SquareIdentity(Recipe):
    """
    Rewrite self-multiplication as exponentiation with ``** 2``.

    Multiplying an expression by itself is equivalent to squaring it.
    Using the power operator makes the mathematical intent explicit
    and is easier to read at a glance.

    Example:
        Before:
            area = side * side

        After:
            area = side ** 2
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SquareIdentity"

    @property
    def display_name(self) -> str:
        return "Rewrite self-multiplication as `** 2`"

    @property
    def description(self) -> str:
        return (
            "When an expression is multiplied by itself, rewrite it using the "
            "exponentiation operator (`** 2`) for clarity."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                if binary.operator != JBinary.Type.Multiplication:
                    return binary
                # Skip literal * literal (e.g. 60 * 60) — the repeated
                # constant often carries semantic meaning like
                # "seconds per minute × minutes per hour".
                if isinstance(binary.left, Literal):
                    return binary
                if not trees_equal(binary.left, binary.right, self.cursor):
                    return binary
                return _power_template.apply(
                    self.cursor, values={"base": binary.left}
                )

        return Visitor()
