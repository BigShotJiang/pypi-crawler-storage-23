"""
Recipes for cleaning up datetime-related patterns.

- UseDatetimeNowNotToday: Replace `datetime.today()` with `datetime.now()`.
  `datetime.today()` is equivalent to `datetime.now()` but less commonly used
  and less explicit about intent. `datetime.now()` is the preferred form.

See: https://docs.python.org/3/library/datetime.html#datetime.datetime.today
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template
from rewrite.java.tree import MethodInvocation

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template for datetime.today() -> datetime.now()
_today_pattern = pattern("datetime.today()")
_now_template = template("datetime.now()")


@categorize(_Cleanup)
class UseDatetimeNowNotToday(Recipe):
    """
    Replace `datetime.today()` with `datetime.now()`.

    `datetime.today()` is equivalent to `datetime.now()` without a timezone
    argument, but `datetime.now()` is more commonly used, more explicit, and
    supports an optional timezone parameter for future refactoring.

    Example:
        Before:
            from datetime import datetime
            print(datetime.today())

        After:
            from datetime import datetime
            print(datetime.now())
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseDatetimeNowNotToday"

    @property
    def display_name(self) -> str:
        return "Use `datetime.now()` instead of `datetime.today()`"

    @property
    def description(self) -> str:
        return (
            "Replace `datetime.today()` with `datetime.now()`. "
            "Both are equivalent, but `now()` is more explicit and supports timezone arguments."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _today_pattern.match(method, self.cursor)
                if match:
                    return _now_template.apply(self.cursor, values=match)
                return method

        return Visitor()
