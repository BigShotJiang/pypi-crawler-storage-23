"""
Recipes that simplify and improve dictionary and set usage.

- ``RemoveDictKeys``: Strip superfluous ``.keys()`` when iterating or testing membership on dicts.
- ``SimplifyDictionaryUpdate``: Convert single-entry ``dict.update()`` calls into direct bracket assignment.
- ``UseDictionaryUnion``: Rewrite double-star dict merges as pipe-operator unions (Python 3.9+).
- ``RemoveRedundantConstructorInDictUnion``: Eliminate unnecessary ``dict()`` wrapping in union expressions.
- ``RemoveDuplicateDictKey``: Clean up repeated keys in dictionary display literals.
- ``RemoveDuplicateSetKey``: Clean up repeated values in set display literals.
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python import tree as py_tree
from rewrite.java.tree import (
    Binary as JBinary,
    Empty,
    ForEachLoop,
    Identifier,
    JContainer,
    Lambda,
    Literal,
    MethodInvocation,
    Try,
)
from rewrite.python.tree import Binary as PyBinary

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template pairs for d.keys() -> d
_d = capture('d')
_keys_pattern = pattern("{d}.keys()", d=_d)
_keys_template = template("{d}", d=_d)

# Template for SimplifyDictionaryUpdate: d["k"] = v
_upd_d = capture('d')
_upd_k = capture('k')
_upd_v = capture('v')
_update_template = template("{d}[{k}] = {v}", d=_upd_d, k=_upd_k, v=_upd_v)

def _deduplicate_elements(elements, original_container):
    """Remove earlier duplicate elements, keeping the last occurrence.

    Returns a new JContainer with duplicates removed and the first element's
    prefix adjusted, or None if no duplicates were found.
    """
    if len(elements) < 2:
        return None

    # Build a mapping of key -> last index
    key_last_index = {}
    for i, elem in enumerate(elements):
        key = _expr_key(elem)
        key_last_index[key] = i

    # Keep only elements whose index matches the last occurrence
    new_elements = []
    first_removed = False
    for i, elem in enumerate(elements):
        key = _expr_key(elem)
        if key_last_index[key] == i:
            new_elements.append(elem)
        elif i == 0:
            first_removed = True

    if len(new_elements) == len(elements):
        return None

    # If the first element was removed, fix the new first element's prefix
    # to avoid leftover spacing from the comma separator
    if first_removed and new_elements:
        original_first_prefix = elements[0].prefix
        new_elements[0] = new_elements[0].replace(_prefix=original_first_prefix)

    # Build new container preserving padding
    new_container = JContainer.build_nullable(
        original_container, new_elements
    )
    return new_container


def _expr_key(expr) -> str:
    """Return a canonical string key for an expression, used for deduplication."""
    if isinstance(expr, Identifier):
        return f"id:{expr.simple_name}"
    elif isinstance(expr, Literal):
        return f"lit:{expr.value_source}"
    elif isinstance(expr, py_tree.Star):
        return f"star:{_expr_key(expr.expression)}"
    elif isinstance(expr, py_tree.KeyValue):
        return _expr_key(expr.key)
    else:
        # Fallback: use the id, so it never matches (no dedup for complex exprs)
        return f"unknown:{id(expr)}"


@categorize(_Cleanup)
class RemoveDictKeys(Recipe):
    """
    Strip redundant ``.keys()`` from dictionary iteration and membership checks.

    Python dictionaries already yield their keys when iterated or used with
    the ``in`` operator, so explicitly calling ``.keys()`` adds no value.

    Example:
        Before:
            for name in registry.keys():
                process(name)

        After:
            for name in registry:
                process(name)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveDictKeys"

    @property
    def display_name(self) -> str:
        return "Drop redundant `.keys()` on dict iteration"

    @property
    def description(self) -> str:
        return (
            "Dictionaries iterate over their keys by default, making explicit "
            "`.keys()` calls unnecessary in for-loops and `in` expressions."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _keys_pattern.match(method, self.cursor)
                if not match:
                    return method

                # Only apply in safe contexts where .keys() is redundant:
                # 1. for-loop iterable: `for k in d.keys():`
                if self.cursor.first_enclosing(ForEachLoop) is not None:
                    return _keys_template.apply(self.cursor, values=match)

                # 2. membership check: `k in d.keys()` / `k not in d.keys()`
                parent_value = self.cursor.parent_tree_cursor().value
                if isinstance(parent_value, PyBinary) and parent_value.operator in (
                    PyBinary.Type.In, PyBinary.Type.NotIn,
                ):
                    return _keys_template.apply(self.cursor, values=match)

                return method

        return Visitor()


@categorize(_Cleanup)
class SimplifyDictionaryUpdate(Recipe):
    """
    Convert single-entry ``dict.update()`` calls to direct bracket assignment.

    Calling ``.update()`` with a one-item dictionary literal is verbose compared
    to assigning the key directly, which is both clearer and faster.

    Example:
        Before:
            config.update({"timeout": 30})

        After:
            config["timeout"] = 30
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyDictionaryUpdate"

    @property
    def display_name(self) -> str:
        return "Convert one-item `dict.update()` to bracket assignment"

    @property
    def description(self) -> str:
        return (
            "When `.update()` receives a dictionary literal containing exactly one key, "
            "rewrite it as a direct key assignment for clarity and efficiency."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Check method name is "update"
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "update":
                    return method

                # Must have a receiver (d.update, not bare update)
                if method.select is None:
                    return method

                # Must have exactly one argument
                args = method.arguments
                if len(args) != 1:
                    return method

                # The argument must be a DictLiteral with exactly one KeyValue
                arg = args[0]
                if not isinstance(arg, py_tree.DictLiteral):
                    return method
                elements = arg.elements
                if len(elements) != 1:
                    return method
                kv = elements[0]
                if not isinstance(kv, py_tree.KeyValue):
                    return method

                # Skip inside exception-testing contexts (pytest.raises,
                # assertRaises, etc.) — .update() and []= can raise
                # different exception types on non-dict mappings.
                if self._inside_raises_context():
                    return method

                # Skip inside lambda — assignment is not valid in lambda body.
                if self.cursor.first_enclosing(Lambda) is not None:
                    return method

                # Build the replacement: d["k"] = v
                values = {
                    'd': method.select,
                    'k': kv.key,
                    'v': kv.value,
                }
                return _update_template.apply(self.cursor, values=values)

            def _inside_raises_context(self) -> bool:
                """Check if the cursor is inside a `with ...raises(...)` block."""
                cursor = self.cursor
                while cursor is not None:
                    val = cursor.value
                    if isinstance(val, Try) and val.resources:
                        for resource in val.resources:
                            vd = resource.variable_declarations
                            if self._is_raises_call(vd):
                                return True
                    cursor = cursor.parent
                return False

            @staticmethod
            def _is_raises_call(node) -> bool:
                """Check if an AST node is a method call with 'raises' in the name."""
                if isinstance(node, MethodInvocation):
                    if isinstance(node.name, Identifier):
                        name = node.name.simple_name.lower()
                        if 'raises' in name:
                            return True
                return False

        return Visitor()


@categorize(_Cleanup)
class UseDictionaryUnion(Recipe):
    """
    Rewrite double-star dict merges using the ``|`` union operator (Python 3.9+).

    A dictionary literal that only contains ``**`` unpacking expressions can be
    expressed more concisely with the pipe-based union syntax introduced in
    Python 3.9.

    Example:
        Before:
            merged = {**defaults, **overrides}

        After:
            merged = defaults | overrides
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseDictionaryUnion"

    @property
    def display_name(self) -> str:
        return "Use dict union operator instead of double-star unpacking"

    @property
    def description(self) -> str:
        return (
            "Dict literals made up entirely of `**` unpacking can be rewritten "
            "with the `|` union operator available since Python 3.9."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_dict_literal(
                self, dict_lit: py_tree.DictLiteral, p: ExecutionContext
            ):
                dict_lit = super().visit_dict_literal(dict_lit, p)
                if not isinstance(dict_lit, py_tree.DictLiteral):
                    return dict_lit

                elements = dict_lit.elements
                # Need at least 2 elements, all must be Star with DICT kind
                if len(elements) < 2:
                    return dict_lit

                for elem in elements:
                    if not isinstance(elem, py_tree.Star):
                        return dict_lit
                    if elem.kind != py_tree.Star.Kind.DICT:
                        return dict_lit

                # Build a | b | c chain using template
                # Start with the first element's inner expression
                expressions = [elem.expression for elem in elements]

                # Build the template code and captures dynamically
                captures_dict = {}
                parts = []
                for i, expr in enumerate(expressions):
                    cap_name = f"e{i}"
                    cap = capture(cap_name)
                    captures_dict[cap_name] = cap
                    parts.append(f"{{{cap_name}}}")

                tmpl_code = " | ".join(parts)
                tmpl = template(tmpl_code, **captures_dict)

                values = {}
                for i, expr in enumerate(expressions):
                    values[f"e{i}"] = expr

                result = tmpl.apply(self.cursor, values=values)
                if result is not None:
                    result = result.replace(_prefix=dict_lit.prefix)
                return result

        return Visitor()


@categorize(_Cleanup)
class RemoveRedundantConstructorInDictUnion(Recipe):
    """
    Eliminate unnecessary ``dict()`` wrapping in dictionary union expressions.

    The ``|`` operator on dictionaries already returns a new dict, so calling
    ``dict()`` on an operand before the union adds no value.

    Example:
        Before:
            result = dict(mapping) | extras

        After:
            result = mapping | extras
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantConstructorInDictUnion"

    @property
    def display_name(self) -> str:
        return "Unwrap unnecessary `dict()` from union operands"

    @property
    def description(self) -> str:
        return (
            "The `|` operator already produces a fresh dict, so wrapping an "
            "operand in `dict()` is redundant and can be removed."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            @staticmethod
            def _unwrap_dict(node):
                """If node is dict(x) with exactly one arg, return x. Else None."""
                if not isinstance(node, MethodInvocation):
                    return None
                if node.select is not None:
                    return None
                if not isinstance(node.name, Identifier):
                    return None
                if node.name.simple_name != "dict":
                    return None
                args = node.arguments
                if len(args) != 1:
                    return None
                arg = args[0]
                # dict() with no real args has an Empty placeholder
                if isinstance(arg, Empty):
                    return None
                return arg

            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                if binary.operator != JBinary.Type.BitOr:
                    return binary

                changed = False
                left = binary.left
                right = binary.right

                # Check if left is dict(arg) with exactly one arg
                unwrapped = self._unwrap_dict(left)
                if unwrapped is not None:
                    left = unwrapped.replace(_prefix=left.prefix)
                    changed = True

                # Check if right is dict(arg) with exactly one arg
                unwrapped = self._unwrap_dict(right)
                if unwrapped is not None:
                    right = unwrapped.replace(_prefix=right.prefix)
                    changed = True

                if changed:
                    return binary.replace(_left=left, _right=right)
                return binary

        return Visitor()


@categorize(_Cleanup)
class RemoveDuplicateDictKey(Recipe):
    """
    Clean up repeated keys in dictionary display literals.

    Python silently uses only the last value when a key appears more than once
    in a dict literal. Removing the earlier occurrences makes the source code
    reflect the actual runtime result.

    Example:
        Before:
            scores = {x: 10, y: 20, x: 30}

        After:
            scores = {y: 20, x: 30}
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveDuplicateDictKey"

    @property
    def display_name(self) -> str:
        return "Deduplicate repeated keys in dict literals"

    @property
    def description(self) -> str:
        return (
            "When a dict literal contains the same key more than once, only the "
            "final value survives at runtime. This removes the shadowed entries."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_dict_literal(
                self, dict_lit: py_tree.DictLiteral, p: ExecutionContext
            ):
                dict_lit = super().visit_dict_literal(dict_lit, p)
                if not isinstance(dict_lit, py_tree.DictLiteral):
                    return dict_lit

                new_container = _deduplicate_elements(
                    dict_lit.elements, dict_lit.padding.elements
                )
                if new_container is None:
                    return dict_lit
                return dict_lit.replace(_elements=new_container)

        return Visitor()


@categorize(_Cleanup)
class RemoveDuplicateSetKey(Recipe):
    """
    Clean up repeated values in set display literals.

    Duplicate entries in a set literal are ignored at runtime since sets only
    store unique elements. Removing the redundant entries makes the intent
    of the code more obvious.

    Example:
        Before:
            colors = {"red", "blue", "red"}

        After:
            colors = {"blue", "red"}
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveDuplicateSetKey"

    @property
    def display_name(self) -> str:
        return "Deduplicate repeated elements in set literals"

    @property
    def description(self) -> str:
        return (
            "Set literals with repeated values have redundant entries that are "
            "discarded at runtime. This removes the duplicates, keeping the last one."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_collection_literal(
                self, collection: py_tree.CollectionLiteral, p: ExecutionContext
            ):
                collection = super().visit_collection_literal(collection, p)
                if not isinstance(collection, py_tree.CollectionLiteral):
                    return collection

                if collection.kind != py_tree.CollectionLiteral.Kind.SET:
                    return collection

                new_container = _deduplicate_elements(
                    collection.elements, collection.padding.elements
                )
                if new_container is None:
                    return collection
                return collection.replace(_elements=new_container)

        return Visitor()
