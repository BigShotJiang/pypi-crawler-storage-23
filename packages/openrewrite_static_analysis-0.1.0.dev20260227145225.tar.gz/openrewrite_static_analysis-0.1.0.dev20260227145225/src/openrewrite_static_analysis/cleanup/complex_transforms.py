"""
Recipes that simplify or correct multi-statement and compound-expression idioms.

- TernaryToIfExpression: Rewrite the ``and``/``or`` ternary trick as a real
  conditional expression
- DefaultMutableArg: Guard against the shared-mutable-default pitfall
- SwapVariable: Collapse a three-line temp-variable swap into tuple unpacking

The ``cond and val or fallback`` trick pre-dates Python 2.5's conditional
expression syntax. It silently gives the wrong answer when ``val`` is falsy,
because ``cond and val`` short-circuits to a falsy result and ``or fallback``
then kicks in. Using ``val if cond else fallback`` avoids this edge case.
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.java.markers import OmitParentheses
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python.tree import CollectionLiteral, CompilationUnit, DictLiteral, ExpressionStatement
from rewrite.java.tree import (
    Assignment,
    Binary as JBinary,
    Block,
    Empty,
    Expression,
    Identifier,
    Literal,
    MethodDeclaration,
    MethodInvocation,
    Statement,
    VariableDeclarations,
)
from rewrite.java.support_types import JContainer, JLeftPadded, JRightPadded, Space
from rewrite.utils import random_id

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template for cond and x or y -> x if cond else y
_cond = capture('cond')
_x = capture('x')
_y = capture('y')
_ternary_pattern = pattern("{cond} and {x} or {y}", cond=_cond, x=_x, y=_y)
_ternary_template = template("{x} if {cond} else {y}", cond=_cond, x=_x, y=_y)


@categorize(_Cleanup)
class TernaryToIfExpression(Recipe):
    """
    Rewrite the ``and``/``or`` ternary trick as a proper conditional expression.

    Before Python 2.5 introduced ``val if cond else fallback``, developers
    used ``cond and val or fallback`` as a makeshift ternary. This pattern
    is buggy: whenever ``val`` evaluates to a falsy value (``0``, ``""``,
    ``None``, ``False``), the result silently falls through to ``fallback``.

    A true conditional expression always returns ``val`` when ``cond`` holds,
    regardless of ``val``'s truthiness.

    Example:
        Before:
            mode = is_verbose and "debug" or "info"

        After:
            mode = "debug" if is_verbose else "info"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.TernaryToIfExpression"

    @property
    def display_name(self) -> str:
        return "Convert `and`/`or` ternary trick to conditional expression"

    @property
    def description(self) -> str:
        return (
            "Rewrite the legacy `cond and val or fallback` idiom as "
            "`val if cond else fallback` to avoid silent bugs when `val` is falsy."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                match = _ternary_pattern.match(binary, self.cursor)
                if match:
                    # Skip when the fallback is itself an `and` expression —
                    # `A and B or C and D` is boolean logic, not a ternary trick
                    y_val = match['y']
                    if isinstance(y_val, JBinary) and y_val.operator == JBinary.Type.And:
                        return binary
                    return _ternary_template.apply(self.cursor, values=match)
                return binary

        return Visitor()


def _is_mutable_default(expr: Any) -> bool:
    """Check if an expression is a mutable default value ([], {}, set()).

    Matches empty list literals, empty dict literals, and set() calls.
    """
    if isinstance(expr, CollectionLiteral):
        if expr.kind == CollectionLiteral.Kind.LIST:
            # Empty list: has one Empty element
            elems = list(expr.elements)
            return len(elems) == 1 and isinstance(elems[0], Empty)
        return False
    if isinstance(expr, DictLiteral):
        # Empty dict: has one Empty element
        elems = list(expr.elements)
        return len(elems) == 1 and isinstance(elems[0], Empty)
    if isinstance(expr, MethodInvocation):
        # set() call with no args
        if isinstance(expr.name, Identifier) and expr.name.simple_name == "set":
            args = list(expr.arguments)
            return len(args) == 1 and isinstance(args[0], Empty)
    return False


def _build_none_literal() -> Literal:
    """Create a ``None`` literal AST node."""
    return Literal(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _value=None,
        _value_source="None",
        _unicode_escapes=None,
        _type=None,
    )


def _build_guard_statement(
    param_name: str, original_default: Expression, body_indent: str
) -> Statement:
    """Build an ``if param is None: param = original_default`` guard statement.

    Uses template.get_tree() to generate a properly formed If node, then adjusts
    the prefix to match the body indentation and replaces placeholder names/values
    with the actual parameter name and original default value.

    Args:
        param_name: The parameter name to guard.
        original_default: The original mutable default expression (e.g., []).
        body_indent: The whitespace prefix for body statements (e.g., '\\n    ').
    """
    # Use a template to generate the If statement AST.
    # The template parser adds its own indentation, so we use a minimal form
    # and then fix up indentation afterward.
    guard_template = template(f"if {param_name} is None:\n    {param_name} = []")
    guard_if = guard_template.get_tree()

    # Replace the [] placeholder in the then-body with the actual original default.
    then_block = guard_if.then_part  # Block (property unwraps JRightPadded)
    guard_stmt = then_block.statements[0]  # Assignment (unwrapped)

    # Replace the assignment's right side with the original default.
    new_assignment_padded = guard_stmt._assignment.replace(
        _element=original_default.replace(_prefix=Space.SINGLE_SPACE)
    )
    new_guard_stmt = guard_stmt.replace(_assignment=new_assignment_padded)

    # Fix indentation of the statement inside the if-body:
    # It should be body_indent + 4 more spaces
    inner_indent = body_indent + "    "
    new_guard_stmt = new_guard_stmt.replace(_prefix=Space([], inner_indent))

    # Rebuild the block with the updated statement
    raw_stmts = list(then_block._statements)
    raw_stmts[0] = raw_stmts[0].replace(_element=new_guard_stmt)
    new_block = then_block.replace(_statements=raw_stmts)

    # Rebuild the If with the new block via the raw padded then_part
    new_then_padded = guard_if._then_part.replace(_element=new_block)
    guard_if = guard_if.replace(_then_part=new_then_padded)

    # Set the if-statement prefix to match the body indentation
    guard_if = guard_if.replace(_prefix=Space([], body_indent))

    return guard_if


@categorize(_Cleanup)
class DefaultMutableArg(Recipe):
    """
    Guard against the shared-mutable-default pitfall.

    Python evaluates default argument values once at function definition
    time. When that default is a mutable object (``[]``, ``{}``, ``set()``),
    every call that relies on the default shares the *same* instance --
    mutations in one call leak into subsequent calls. This recipe changes
    the default to ``None`` and inserts a guard clause at the top of the
    function body that creates a fresh instance when needed.

    Example:
        Before:
            def enqueue(items: list = []):
                process(items)

        After:
            def enqueue(items: list = None):
                if items is None:
                    items = []
                process(items)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.DefaultMutableArg"

    @property
    def display_name(self) -> str:
        return "Guard mutable default arguments with `None` sentinel"

    @property
    def description(self) -> str:
        return (
            "Change mutable default values (`[]`, `{}`, `set()`) to `None` "
            "and prepend an `if arg is None: arg = <original>` guard so each "
            "call gets its own fresh instance."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_declaration(
                self, method: MethodDeclaration, p: ExecutionContext
            ) -> Optional[MethodDeclaration]:
                method = super().visit_method_declaration(method, p)
                if not isinstance(method, MethodDeclaration):
                    return method
                if method.body is None:
                    return method

                # Find parameters with mutable defaults
                guards: List[tuple] = []  # (param_name, original_default)
                new_params_padded = []
                changed = False
                params_container = method.padding.parameters
                for padded_param in params_container._elements:
                    param = padded_param.element
                    if isinstance(param, VariableDeclarations):
                        raw_vars = param._variables  # List[JRightPadded[NamedVariable]]
                        if raw_vars:
                            var_padded = raw_vars[0]
                            var = var_padded.element
                            init_padded = var.padding.initializer
                            if init_padded is not None:
                                init = init_padded.element
                                if _is_mutable_default(init):
                                    # Replace default with None, preserving spacing
                                    none_lit = _build_none_literal()
                                    none_lit = none_lit.replace(_prefix=init.prefix)
                                    new_init_padded = init_padded.replace(_element=none_lit)
                                    new_var = var.replace(
                                        _initializer=new_init_padded,
                                    )
                                    new_var_padded = var_padded.replace(_element=new_var)
                                    new_param = param.replace(_variables=[new_var_padded])
                                    new_padded = padded_param.replace(_element=new_param)
                                    new_params_padded.append(new_padded)
                                    guards.append((var.name.simple_name, init))
                                    changed = True
                                    continue
                    new_params_padded.append(padded_param)

                if not changed:
                    return method

                # Update parameters
                new_params_container = params_container.replace(_elements=new_params_padded)
                method = method.padding.replace(_parameters=new_params_container)

                # Determine body indentation from the first statement
                body = method.body
                body_stmts = list(body._statements)
                if body_stmts:
                    first_stmt_prefix = body_stmts[0].element.prefix.whitespace
                    # Extract the indentation (last line of whitespace)
                    body_indent = first_stmt_prefix
                else:
                    body_indent = "\n    "

                # Build guard statements, inserting after any leading docstring
                guard_stmts = []
                for param_name, original_default in guards:
                    guard = _build_guard_statement(param_name, original_default, body_indent)
                    padded_guard = JRightPadded(
                        _element=guard,
                        _after=Space.EMPTY,
                        _markers=Markers.EMPTY,
                    )
                    guard_stmts.append(padded_guard)

                # Detect leading docstring (ExpressionStatement wrapping a string Literal)
                docstring_count = 0
                if body_stmts:
                    first_elem = body_stmts[0].element
                    if isinstance(first_elem, ExpressionStatement) and isinstance(first_elem.expression, Literal) and isinstance(first_elem.expression.value, str):
                        docstring_count = 1

                new_stmts = list(body_stmts[:docstring_count])
                new_stmts.extend(guard_stmts)
                new_stmts.extend(body_stmts[docstring_count:])
                new_body = body.replace(_statements=new_stmts)
                method = method.replace(_body=new_body)

                return method

        return Visitor()


def _is_simple_identifier(expr: Any) -> Optional[str]:
    """Return the simple name if the expression is a plain Identifier, else None."""
    if isinstance(expr, Identifier):
        return expr.simple_name
    return None


def _find_swap_pattern(
    stmts: List[JRightPadded],
) -> Optional[tuple]:
    """Find a 3-statement swap pattern in a list of padded statements.

    Looks for: temp = a; a = b; b = temp
    Returns (index, a_name, b_name) or None.
    """
    for i in range(len(stmts) - 2):
        s1 = stmts[i].element
        s2 = stmts[i + 1].element
        s3 = stmts[i + 2].element

        # All three must be simple assignments (Identifier = Identifier)
        if not isinstance(s1, Assignment) or not isinstance(s2, Assignment) or not isinstance(s3, Assignment):
            continue

        temp = _is_simple_identifier(s1.variable)
        a1 = _is_simple_identifier(s1.assignment)
        a2_left = _is_simple_identifier(s2.variable)
        b1 = _is_simple_identifier(s2.assignment)
        b2_left = _is_simple_identifier(s3.variable)
        temp2 = _is_simple_identifier(s3.assignment)

        if temp is None or a1 is None or a2_left is None or b1 is None or b2_left is None or temp2 is None:
            continue

        # Check pattern: temp = a; a = b; b = temp
        if temp == temp2 and a1 == a2_left and b1 == b2_left:
            return (i, a1, b1)

    return None


@categorize(_Cleanup)
class SwapVariable(Recipe):
    """
    Collapse a temp-variable swap into Python's tuple-unpacking idiom.

    Python supports simultaneous assignment via tuple unpacking, making
    a dedicated temporary variable unnecessary for swapping two values.
    This recipe recognizes the three-line pattern ``tmp = x; x = y;
    y = tmp`` and condenses it into ``x, y = y, x``.

    Example:
        Before:
            backup = left
            left = right
            right = backup

        After:
            left, right = right, left
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SwapVariable"

    @property
    def display_name(self) -> str:
        return "Simplify temp-variable swap to tuple unpacking"

    @property
    def description(self) -> str:
        return (
            "Detect the three-line swap idiom (`tmp = x; x = y; y = tmp`) "
            "and condense it into `x, y = y, x` using tuple unpacking."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_compilation_unit(
                self, cu: CompilationUnit, p: ExecutionContext
            ) -> Optional[CompilationUnit]:
                cu = super().visit_compilation_unit(cu, p)
                if not isinstance(cu, CompilationUnit):
                    return cu
                new_stmts = self._transform_stmts(cu._statements)
                if new_stmts is not None:
                    return cu.replace(_statements=new_stmts)
                return cu

            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Optional[Block]:
                block = super().visit_block(block, p)
                if not isinstance(block, Block):
                    return block
                new_stmts = self._transform_stmts(block._statements)
                if new_stmts is not None:
                    return block.replace(_statements=new_stmts)
                return block

            def _transform_stmts(
                self, stmts: List[JRightPadded]
            ) -> Optional[List[JRightPadded]]:
                result = _find_swap_pattern(stmts)
                if result is None:
                    return None

                idx, a_name, b_name = result

                # Get the prefix from the first statement (temp = a) for the result
                first_stmt = stmts[idx].element
                prefix = first_stmt.prefix

                # Build: a, b = b, a
                a_id = Identifier(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name=a_name,
                    _type=None,
                    _field_type=None,
                )
                b_id = Identifier(
                    _id=random_id(),
                    _prefix=Space.SINGLE_SPACE,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name=b_name,
                    _type=None,
                    _field_type=None,
                )
                b_id2 = Identifier(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name=b_name,
                    _type=None,
                    _field_type=None,
                )
                a_id2 = Identifier(
                    _id=random_id(),
                    _prefix=Space.SINGLE_SPACE,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name=a_name,
                    _type=None,
                    _field_type=None,
                )

                # Markers to omit parentheses on tuple literals
                omit_parens = Markers(
                    _id=random_id(),
                    _markers=[OmitParentheses(_id=random_id())],
                )

                # Left side: a, b (tuple without parentheses)
                left_tuple = CollectionLiteral(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _kind=CollectionLiteral.Kind.TUPLE,
                    _elements=JContainer(
                        _before=Space.EMPTY,
                        _elements=[
                            JRightPadded(
                                _element=a_id,
                                _after=Space.EMPTY,
                                _markers=Markers.EMPTY,
                            ),
                            JRightPadded(
                                _element=b_id,
                                _after=Space.EMPTY,
                                _markers=Markers.EMPTY,
                            ),
                        ],
                        _markers=omit_parens,
                    ),
                    _type=None,
                )

                # Right side: b, a (tuple without parentheses)
                right_tuple = CollectionLiteral(
                    _id=random_id(),
                    _prefix=Space.SINGLE_SPACE,
                    _markers=Markers.EMPTY,
                    _kind=CollectionLiteral.Kind.TUPLE,
                    _elements=JContainer(
                        _before=Space.EMPTY,
                        _elements=[
                            JRightPadded(
                                _element=b_id2,
                                _after=Space.EMPTY,
                                _markers=Markers.EMPTY,
                            ),
                            JRightPadded(
                                _element=a_id2,
                                _after=Space.EMPTY,
                                _markers=Markers.EMPTY,
                            ),
                        ],
                        _markers=omit_parens,
                    ),
                    _type=None,
                )

                # Build the assignment: a, b = b, a
                swap_assign = Assignment(
                    _id=random_id(),
                    _prefix=prefix,
                    _markers=Markers.EMPTY,
                    _variable=left_tuple,
                    _assignment=JLeftPadded(
                        _before=Space.SINGLE_SPACE,
                        _element=right_tuple,
                        _markers=Markers.EMPTY,
                    ),
                    _type=None,
                )

                padded_swap = JRightPadded(
                    _element=swap_assign,
                    _after=Space.EMPTY,
                    _markers=Markers.EMPTY,
                )

                # Replace the 3 statements with 1
                new_stmts = list(stmts)
                new_stmts[idx:idx + 3] = [padded_swap]
                return new_stmts

        return Visitor()
