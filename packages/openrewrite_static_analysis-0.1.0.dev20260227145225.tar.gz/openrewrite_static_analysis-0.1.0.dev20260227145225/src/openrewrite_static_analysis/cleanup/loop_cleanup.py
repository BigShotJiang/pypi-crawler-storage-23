"""
Recipes that simplify and modernize loop constructs.

- Replace ``f.readlines()`` with direct file iteration -- avoids loading the entire file
  into a list and follows standard Python conventions.
- Flatten ``for/else`` when the loop has no ``break`` -- the else block always runs anyway,
  so it can be placed after the loop without the else keyword.
- Collapse ``for x in seq: yield x`` into ``yield from seq`` -- shorter and potentially
  faster delegation to a sub-iterator.
"""

from typing import Any, List, Optional
from uuid import uuid4

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python.format import auto_format
from rewrite.python.tree import (
    ExpressionStatement,
    StatementExpression,
    TrailingElseWrapper,
    YieldFrom as PyYieldFrom,
)
from rewrite.java.tree import (
    Block,
    Break,
    ForEachLoop,
    Identifier,
    JRightPadded,
    Lambda,
    Markers,
    MethodDeclaration,
    MethodInvocation,
    Space,
    Statement,
    Yield,
)

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template for f.readlines() -> f
_f = capture('f')
_readlines_pattern = pattern("{f}.readlines()", f=_f)
_readlines_template = template("{f}", f=_f)


@categorize(_Cleanup)
class UseFileIterator(Recipe):
    """
    Iterate over file objects directly instead of calling ``.readlines()``.

    The ``.readlines()`` method loads every line into a list before iteration
    begins. File objects are already iterable and yield lines one at a time,
    which uses less memory and is considered standard practice.

    Example:
        Before:
            for row in handle.readlines():
                parse(row)

        After:
            for row in handle:
                parse(row)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseFileIterator"

    @property
    def display_name(self) -> str:
        return "Iterate over file objects directly, not via `readlines()`"

    @property
    def description(self) -> str:
        return (
            "File objects are iterable and yield lines on demand, so calling "
            "`.readlines()` to build an intermediate list is unnecessary."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                # Only strip .readlines() when it is the iterable of a for-loop.
                # In that context the cursor parent chain is:
                #   MethodInvocation → ForEachLoop.Control → ForEachLoop
                parent = self.cursor.parent
                if parent is None or not isinstance(parent.value, ForEachLoop.Control):
                    return method
                match = _readlines_pattern.match(method, self.cursor)
                if match:
                    return _readlines_template.apply(self.cursor, values=match)
                return method

        return Visitor()


class _BreakChecker(PythonVisitor[None]):
    """Helper visitor that checks if a tree contains any break statements."""

    def __init__(self):
        super().__init__()
        self.found = False

    def visit_break(self, brk: Break, p: None) -> Break:
        self.found = True
        return brk

    def visit_method_declaration(self, method, p):
        # Don't traverse into nested functions - their breaks don't affect outer loop
        return method

    def visit_lambda(self, lambda_expr, p):
        # Don't traverse into lambdas
        return lambda_expr


def _has_break(tree) -> bool:
    """Return True if the tree contains a break statement."""
    checker = _BreakChecker()
    checker.visit(tree, None)
    return checker.found


def _flatten_useless_else(
    stmts_padded: List[JRightPadded[Statement]],
) -> Optional[List[JRightPadded[Statement]]]:
    """Process a statement list, flattening useless else on for loops.

    Returns a new list if any changes were made, or None if unchanged.
    """
    new_stmts: List[JRightPadded[Statement]] = []
    changed = False
    for stmt_padded in stmts_padded:
        stmt = stmt_padded.element
        if (
            isinstance(stmt, TrailingElseWrapper)
            and isinstance(stmt.statement, ForEachLoop)
            and not _has_break(stmt.statement.body)
        ):
            changed = True
            loop = stmt.statement
            # Keep the loop, preserving the wrapper's prefix
            new_stmts.append(
                JRightPadded(
                    loop.replace(_prefix=stmt.prefix),
                    Space([], ''),
                    Markers.EMPTY,
                )
            )
            # Splice else body statements after the loop (auto_format fixes indentation)
            new_stmts.extend(stmt.else_block._statements)
            continue
        new_stmts.append(stmt_padded)
    return new_stmts if changed else None


@categorize(_Cleanup)
class UselessElseOnLoop(Recipe):
    """
    Flatten ``for/else`` when the loop contains no ``break`` statement.

    Python's ``else`` on a ``for`` loop only has meaning when the loop might
    exit early via ``break``. When no ``break`` exists, the else block executes
    unconditionally, so it can be moved to follow the loop directly.

    Example:
        Before:
            for val in measurements:
                if val > threshold:
                    outliers.append(val)
            else:
                log("scan complete")

        After:
            for val in measurements:
                if val > threshold:
                    outliers.append(val)
            log("scan complete")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UselessElseOnLoop"

    @property
    def display_name(self) -> str:
        return "Flatten `for/else` when the loop has no `break`"

    @property
    def description(self) -> str:
        return (
            "A `for/else` where the loop body never breaks is misleading -- the "
            "`else` runs every time. This moves the else body after the loop."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                result = _flatten_useless_else(cu._statements)
                if result is not None:
                    cu = cu.replace(_statements=result)
                    cu = auto_format(cu, p, cursor=self.cursor.parent)
                return cu

            def visit_block(self, block: Block, p: ExecutionContext) -> Block:
                block = super().visit_block(block, p)
                result = _flatten_useless_else(block._statements)
                if result is not None:
                    block = block.replace(_statements=result)
                    block = auto_format(block, p, cursor=self.cursor.parent)
                return block

        return Visitor()


@categorize(_Cleanup)
class YieldFrom(Recipe):
    """
    Collapse ``for`` loop that only yields the loop variable into ``yield from``.

    A loop whose sole purpose is to yield each element of an iterable one by
    one can be replaced with ``yield from``, which delegates iteration to the
    sub-iterator and is both shorter and potentially faster.

    Example:
        Before:
            def iter_pages(doc):
                for page in doc.get_pages():
                    yield page

        After:
            def iter_pages(doc):
                yield from doc.get_pages()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.YieldFrom"

    @property
    def display_name(self) -> str:
        return "Collapse for-yield loop into `yield from`"

    @property
    def description(self) -> str:
        return (
            "A for-loop that does nothing but yield the loop variable can be "
            "expressed as `yield from`, which is shorter and delegates directly."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            @staticmethod
            def _is_async_method(method: MethodDeclaration) -> bool:
                """Check if a MethodDeclaration has the 'async' modifier."""
                return any(
                    getattr(m, 'keyword', None) == 'async'
                    for m in method.modifiers
                )

            def _is_inside_async(self) -> bool:
                """Check if current cursor is inside an async function."""
                cursor = self.cursor
                while cursor is not None:
                    if isinstance(cursor.value, MethodDeclaration):
                        return self._is_async_method(cursor.value)
                    cursor = cursor.parent
                return False

            def _try_yield_from(self, stmt: Statement) -> Optional[StatementExpression]:
                """If stmt is a for loop with a single yield of the loop var, return yield from."""
                if not isinstance(stmt, ForEachLoop):
                    return None

                # yield from is a SyntaxError inside async def
                if self._is_inside_async():
                    return None

                body = stmt.body
                if not isinstance(body, Block):
                    return None
                if len(body.statements) != 1:
                    return None

                # Get the single statement, unwrapping StatementExpression
                body_stmt = body.statements[0]
                inner = None
                if isinstance(body_stmt, StatementExpression):
                    inner = body_stmt.statement
                elif isinstance(body_stmt, Yield):
                    inner = body_stmt

                if not isinstance(inner, Yield):
                    return None

                # Check that the yielded value is the loop variable
                yield_value = inner.value
                if not isinstance(yield_value, Identifier):
                    return None

                # Get the loop variable name
                ctrl_var = stmt.control.variable
                var_name = None
                if isinstance(ctrl_var, ExpressionStatement):
                    if isinstance(ctrl_var.expression, Identifier):
                        var_name = ctrl_var.expression.simple_name

                if var_name is None or yield_value.simple_name != var_name:
                    return None

                # Get the iterable expression
                iterable = stmt.control.iterable

                # Create: yield from iterable
                yield_from_expr = PyYieldFrom(
                    _id=uuid4(),
                    _prefix=Space([], ' '),
                    _markers=Markers.EMPTY,
                    _expression=iterable.replace(_prefix=Space([], ' ')),
                    _type=None,
                )

                yield_stmt = Yield(
                    _id=uuid4(),
                    _prefix=stmt.prefix,
                    _markers=Markers.EMPTY,
                    _implicit=False,
                    _value=yield_from_expr,
                )

                return StatementExpression(
                    _id=uuid4(),
                    _statement=yield_stmt,
                )

            @staticmethod
            def _get_loop_var_name(stmt: Statement) -> Optional[str]:
                """Extract the loop variable name from a ForEachLoop, if simple."""
                if not isinstance(stmt, ForEachLoop):
                    return None
                ctrl_var = stmt.control.variable
                if isinstance(ctrl_var, ExpressionStatement):
                    if isinstance(ctrl_var.expression, Identifier):
                        return ctrl_var.expression.simple_name
                return None

            @staticmethod
            def _contains_name(tree, name: str) -> bool:
                """Check if any Identifier with the given name exists in the tree."""
                if isinstance(tree, Identifier):
                    return tree.simple_name == name
                # Walk all attributes that are AST nodes or lists of AST nodes
                for attr in vars(tree).values():
                    if isinstance(attr, list):
                        for item in attr:
                            if hasattr(item, 'prefix'):
                                if Visitor._contains_name(item, name):
                                    return True
                            # JRightPadded wraps elements
                            if hasattr(item, 'element') and hasattr(item.element, 'prefix'):
                                if Visitor._contains_name(item.element, name):
                                    return True
                    elif hasattr(attr, 'prefix'):
                        if Visitor._contains_name(attr, name):
                            return True
                    elif hasattr(attr, 'element') and hasattr(attr, '_before'):
                        # JLeftPadded / JRightPadded
                        if hasattr(attr.element, 'prefix') and Visitor._contains_name(attr.element, name):
                            return True
                return False

            def _replace_in_stmts(
                self, stmts: List[JRightPadded[Statement]]
            ) -> Optional[List[JRightPadded[Statement]]]:
                """Replace for-yield loops with yield from in a statement list."""
                new_stmts = []
                changed = False
                for i, rp in enumerate(stmts):
                    replacement = self._try_yield_from(rp.element)
                    if replacement is not None:
                        # Check if the loop variable is used in any subsequent statement
                        var_name = self._get_loop_var_name(rp.element)
                        if var_name is not None:
                            used_after = any(
                                self._contains_name(stmts[j].element, var_name)
                                for j in range(i + 1, len(stmts))
                            )
                            if used_after:
                                new_stmts.append(rp)
                                continue
                        new_stmts.append(rp.replace(_element=replacement))
                        changed = True
                    else:
                        new_stmts.append(rp)
                return new_stmts if changed else None

            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                result = self._replace_in_stmts(cu._statements)
                if result is not None:
                    cu = cu.replace(_statements=result)
                return cu

            def visit_block(self, block: Block, p: ExecutionContext) -> Block:
                block = super().visit_block(block, p)
                result = self._replace_in_stmts(block._statements)
                if result is not None:
                    block = block.replace(_statements=result)
                return block

        return Visitor()
