"""
Recipes that convert empty collection constructor calls to their shorter literal forms,
and optimize collection usage patterns.

Prefer literal syntax over constructor calls for empty collections -- it is the
conventional Python style, avoids a function-call overhead, and reads more concisely:

- dict() becomes {}
- list() becomes []
- tuple() becomes ()

Other collection-related recipes in this module:
- CollectionIntoSet: Convert list/tuple to set in membership tests for O(1) lookups
- UnwrapIterableConstruction: Flatten redundant iterable wrapping into a direct literal

See: https://docs.quantifiedcode.com/python-anti-patterns/performance/using_key_in_list_to_check_if_key_is_contained_in_a_list.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template
from rewrite.python.tree import Binary as PyBinary, CollectionLiteral
from rewrite.java import Space, TrailingComma
from rewrite.java.tree import Identifier, Literal, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template pairs for dict() -> {}
_dict_pattern = pattern("dict()")
_dict_template = template("{}")

# Pattern/template pairs for list() -> []
_list_pattern = pattern("list()")
_list_template = template("[]")

# Pattern/template pairs for tuple() -> ()
_tuple_pattern = pattern("tuple()")
_tuple_template = template("()")


@categorize(_Cleanup)
class DictLiteral(Recipe):
    """
    Convert no-argument ``dict()`` constructor calls to the ``{}`` literal form.

    The curly-brace literal is the standard Python idiom for creating an empty
    dictionary. It is both faster at runtime and more concise than calling
    the ``dict`` built-in with no arguments.

    Example:
        Before:
            settings = dict()

        After:
            settings = {}
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.DictLiteral"

    @property
    def display_name(self) -> str:
        return "Use `{}` literal instead of `dict()` constructor"

    @property
    def description(self) -> str:
        return "Convert no-argument `dict()` calls to the `{}` literal, which is more concise and avoids a function call."

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _dict_pattern.match(method, self.cursor)
                if match:
                    return _dict_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class ListLiteral(Recipe):
    """
    Convert no-argument ``list()`` constructor calls to the ``[]`` literal form.

    Square-bracket notation is the conventional way to create an empty list in
    Python. It eliminates the overhead of a built-in function call and is
    immediately recognizable to readers.

    Example:
        Before:
            items = list()

        After:
            items = []
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ListLiteral"

    @property
    def display_name(self) -> str:
        return "Use `[]` literal instead of `list()` constructor"

    @property
    def description(self) -> str:
        return "Convert no-argument `list()` calls to the `[]` literal, which is more concise and avoids a function call."

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _list_pattern.match(method, self.cursor)
                if match:
                    return _list_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class TupleLiteral(Recipe):
    """
    Convert no-argument ``tuple()`` constructor calls to the ``()`` literal form.

    Parenthesis notation is the preferred way to express an empty tuple in
    Python. It avoids a built-in function call and is the style recommended
    by most linters and style guides.

    Example:
        Before:
            coords = tuple()

        After:
            coords = ()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.TupleLiteral"

    @property
    def display_name(self) -> str:
        return "Use `()` literal instead of `tuple()` constructor"

    @property
    def description(self) -> str:
        return "Convert no-argument `tuple()` calls to the `()` literal, which is more concise and avoids a function call."

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _tuple_pattern.match(method, self.cursor)
                if match:
                    return _tuple_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class CollectionIntoSet(Recipe):
    """
    Convert list or tuple literals to set literals when used in ``in`` checks.

    Membership tests against a set are hash-based and run in constant time,
    whereas scanning a list or tuple is linear. When every element is a
    literal, switching to a set literal ``{...}`` is a safe, no-cost
    performance improvement.

    Example:
        Before:
            if status in ["active", "pending"]:
                process_request()

        After:
            if status in {"active", "pending"}:
                process_request()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.CollectionIntoSet"

    @property
    def display_name(self) -> str:
        return "Prefer set literals in `in` membership tests"

    @property
    def description(self) -> str:
        return (
            "When a list or tuple of literals appears on the right side of an `in` test, "
            "convert it to a set literal for constant-time lookup."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_python_binary(
                self, binary: PyBinary, p: ExecutionContext
            ) -> Optional[PyBinary]:
                binary = super().visit_python_binary(binary, p)
                if not isinstance(binary, PyBinary):
                    return binary
                if binary.operator != PyBinary.Type.In:
                    return binary
                right = binary.right
                if not isinstance(right, CollectionLiteral):
                    return binary
                if right.kind not in (CollectionLiteral.Kind.LIST, CollectionLiteral.Kind.TUPLE):
                    return binary
                # Only convert if all elements are literals
                for elem in right.elements:
                    if not isinstance(elem, Literal):
                        return binary
                # Replace with set literal
                new_right = right.replace(_kind=CollectionLiteral.Kind.SET)
                return binary.replace(_right=new_right)

        return Visitor()


# Mapping from constructor function name to target collection literal kind
_UNWRAP_TARGET_KIND = {
    "tuple": CollectionLiteral.Kind.TUPLE,
    "list": CollectionLiteral.Kind.LIST,
    "set": CollectionLiteral.Kind.SET,
}


@categorize(_Cleanup)
class UnwrapIterableConstruction(Recipe):
    """
    Simplify a ``tuple()``, ``list()``, or ``set()`` call that wraps a literal into just the literal.

    When one of these constructors receives a single list or tuple literal as
    its only argument, the wrapping call is unnecessary. The inner literal can
    be converted directly to the target collection type.

    Example:
        Before:
            data = tuple([base_cfg, *overrides, final_cfg])

        After:
            data = (base_cfg, *overrides, final_cfg)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UnwrapIterableConstruction"

    @property
    def display_name(self) -> str:
        return "Flatten redundant collection constructor wrapping a literal"

    @property
    def description(self) -> str:
        return (
            "When `tuple()`, `list()`, or `set()` wraps a single list or tuple literal, "
            "remove the constructor and use the target literal form directly."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                if not isinstance(method, MethodInvocation):
                    return method
                if not isinstance(method.name, Identifier):
                    return method
                func_name = method.name.simple_name
                if func_name not in _UNWRAP_TARGET_KIND:
                    return method
                # Must have no receiver (standalone function call)
                if method.select is not None:
                    return method
                # Must have exactly one argument
                args = list(method.arguments)
                if len(args) != 1:
                    return method
                arg = args[0]
                # The argument must be a list or tuple literal
                if not isinstance(arg, CollectionLiteral):
                    return method
                if arg.kind not in (CollectionLiteral.Kind.LIST, CollectionLiteral.Kind.TUPLE):
                    return method
                # Unwrap: replace with a collection literal of the target kind
                target_kind = _UNWRAP_TARGET_KIND[func_name]
                result = arg.replace(_prefix=method.prefix, _kind=target_kind)
                # Single-element tuple needs trailing comma: (x,)
                if target_kind == CollectionLiteral.Kind.TUPLE and len(list(arg.elements)) == 1:
                    padded = list(result._elements._elements)
                    last = padded[-1]
                    tc = TrailingComma(random_id(), last.after)
                    new_markers = last.markers.replace(markers=last.markers.markers + [tc])
                    last = last.replace(_markers=new_markers, _after=Space.EMPTY)
                    padded[-1] = last
                    elements = result._elements.replace(_elements=padded)
                    result = result.replace(_elements=elements)
                return result

        return Visitor()
