"""Tests for conditional cleanup recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.conditionals import (
    RemoveRedundantCondition,
    MergeIsinstance,
    MergeNestedIfs,
    MergeElseIfIntoElif,
    SwapIfElseBranches,
    RemovePassBody,
    RemovePassElif,
    RemoveRedundantIf,
    RemoveUnnecessaryElse,
    AssignIfExp,
)


class TestRemoveRedundantCondition:
    """Tests for RemoveRedundantCondition: y if z else y -> y."""

    def test_same_branches(self):
        """Test that y if z else y is simplified to y."""
        spec = RecipeSpec(recipe=RemoveRedundantCondition())
        spec.rewrite_run(
            python(
                "result = y if z else y",
                "result = y",
            )
        )

    def test_no_change_different_branches(self):
        """Test that a if z else b is not modified when branches differ."""
        spec = RecipeSpec(recipe=RemoveRedundantCondition())
        spec.rewrite_run(python("result = a if z else b"))

    def test_same_branches_complex_expression(self):
        """Test with more complex identical branches."""
        spec = RecipeSpec(recipe=RemoveRedundantCondition())
        spec.rewrite_run(
            python(
                "result = foo if condition else foo",
                "result = foo",
            )
        )


class TestMergeIsinstance:
    """Tests for MergeIsinstance: isinstance(x, A) or isinstance(x, B) -> isinstance(x, (A, B))."""

    def test_merges_isinstance(self):
        """Test that two isinstance calls with or are merged."""
        spec = RecipeSpec(recipe=MergeIsinstance())
        spec.rewrite_run(
            python(
                "if isinstance(x, int) or isinstance(x, str):\n    pass",
                "if isinstance(x, (int, str)):\n    pass",
            )
        )

    def test_no_change_different_vars(self):
        """Test that isinstance calls on different variables are not merged."""
        spec = RecipeSpec(recipe=MergeIsinstance())
        spec.rewrite_run(
            python(
                "if isinstance(x, int) or isinstance(y, str):\n    pass"
            )
        )

    def test_no_change_single_isinstance(self):
        """Test that a single isinstance call is not modified."""
        spec = RecipeSpec(recipe=MergeIsinstance())
        spec.rewrite_run(
            python("if isinstance(x, int):\n    pass")
        )

    def test_no_change_isinstance_already_tuple(self):
        """Don't merge when isinstance already has tuple arg."""
        spec = RecipeSpec(recipe=MergeIsinstance())
        spec.rewrite_run(
            python(
                '''
            if isinstance(x, (int, float)) or isinstance(x, str):
                pass
            '''
            )
        )


class TestMergeNestedIfs:
    """Tests for MergeNestedIfs: nested if without else -> combined and condition."""

    def test_merge_simple_nested_ifs(self):
        """Test that nested ifs are merged into a single if with and."""
        spec = RecipeSpec(recipe=MergeNestedIfs())
        spec.rewrite_run(
            python(
                "if a:\n    if b:\n        return c\n",
                "if a and b:\n    return c\n",
            )
        )

    def test_no_merge_when_inner_has_else(self):
        """Test that nested if with else is not merged."""
        spec = RecipeSpec(recipe=MergeNestedIfs())
        spec.rewrite_run(
            python("if a:\n    if b:\n        return c\n    else:\n        return d\n")
        )

    def test_no_merge_when_outer_has_else(self):
        """Test that outer if with else is not merged."""
        spec = RecipeSpec(recipe=MergeNestedIfs())
        spec.rewrite_run(
            python("if a:\n    if b:\n        return c\nelse:\n    return d\n")
        )

    def test_no_merge_when_multiple_statements_in_body(self):
        """Test that outer if with multiple statements is not merged."""
        spec = RecipeSpec(recipe=MergeNestedIfs())
        spec.rewrite_run(
            python("if a:\n    x()\n    if b:\n        return c\n")
        )

    def test_merge_preserves_or_precedence(self):
        """Test that inner `or` condition gets parenthesized to preserve precedence."""
        spec = RecipeSpec(recipe=MergeNestedIfs())
        spec.rewrite_run(
            python(
                "if a:\n    if b or c:\n        return d\n",
                "if a and (b or c):\n    return d\n",
            )
        )


class TestMergeElseIfIntoElif:
    """Tests for MergeElseIfIntoElif: else: if -> elif."""

    def test_merge_else_if_into_elif(self):
        """Test that else containing only an if is promoted to elif."""
        spec = RecipeSpec(recipe=MergeElseIfIntoElif())
        spec.rewrite_run(
            python(
                "if x:\n    do_a()\nelse:\n    if y:\n        do_b()\n    else:\n        do_c()\n",
                "if x:\n    do_a()\nelif y:\n    do_b()\nelse:\n    do_c()\n",
            )
        )

    def test_no_change_when_else_has_multiple_statements(self):
        """Test that else with multiple statements is not changed."""
        spec = RecipeSpec(recipe=MergeElseIfIntoElif())
        spec.rewrite_run(
            python(
                "if x:\n    do_a()\nelse:\n    setup()\n    if y:\n        do_b()\n"
            )
        )

    def test_no_change_when_already_elif(self):
        """Test that existing elif is not modified."""
        spec = RecipeSpec(recipe=MergeElseIfIntoElif())
        spec.rewrite_run(
            python("if x:\n    do_a()\nelif y:\n    do_b()\n")
        )


class TestSwapIfElseBranches:
    """Tests for SwapIfElseBranches: if x: pass else: body -> if not x: body."""

    def test_swap_pass_if_with_else(self):
        """Test that if with pass body and else is swapped."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python(
                "if x:\n    pass\nelse:\n    take_off_hat()\n",
                "if not x:\n    take_off_hat()\n",
            )
        )

    def test_no_change_when_if_body_not_pass(self):
        """Test that if with non-pass body is not swapped."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python("if x:\n    do_something()\nelse:\n    take_off_hat()\n")
        )

    def test_no_change_when_no_else(self):
        """Test that if with pass body but no else is not modified."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python("if x:\n    pass\n")
        )

    def test_swap_removes_double_negation(self):
        """Test that if not x: pass else: body -> if x: body."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python(
                "if not x:\n    pass\nelse:\n    take_off_hat()\n",
                "if x:\n    take_off_hat()\n",
            )
        )

    def test_swap_when_else_is_elif(self):
        """Swap when else body is an elif — fix prefix on promoted body."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python(
                "if x:\n    pass\nelif y:\n    process()\n",
                "if not x:\n    if y:\n        process()\n",
            )
        )

    def test_swap_when_else_is_elif_chain(self):
        """Swap when else body is an elif chain with else."""
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python(
                "if x:\n    pass\nelif y:\n    a()\nelse:\n    b()\n",
                "if not x:\n    if y:\n        a()\n    else:\n        b()\n",
            )
        )

    def test_swap_is_not_none_with_elif_in_method(self):
        """Negating `is not None` in a method context must produce `is None`, not `not x is not None`.

        `not x is not None` is parsed as `not (x is not None)` which IS
        semantically correct, but the code should simplify to `x is None`
        for clarity.  More importantly, the elif chain body must be
        correctly indented after being nested inside the new if.
        """
        spec = RecipeSpec(recipe=SwapIfElseBranches())
        spec.rewrite_run(
            python(
                "def resolve(self, dep):\n"
                "    package = cache.get(dep)\n"
                "    if package is not None:\n"
                "        pass\n"
                "    elif dep.is_vcs():\n"
                "        handle_vcs()\n"
                "    elif dep.is_file():\n"
                "        handle_file()\n",
                "def resolve(self, dep):\n"
                "    package = cache.get(dep)\n"
                "    if package is None:\n"
                "        if dep.is_vcs():\n"
                "            handle_vcs()\n"
                "        elif dep.is_file():\n"
                "            handle_file()\n",
            )
        )


class TestRemovePassBody:
    """Tests for RemovePassBody: if not a: pass else: body -> if a: body."""

    def test_remove_pass_body_with_negation(self):
        """Test that if not a: pass else: body is simplified."""
        spec = RecipeSpec(recipe=RemovePassBody())
        spec.rewrite_run(
            python(
                "if not a:\n    pass\nelse:\n    return c\n",
                "if a:\n    return c\n",
            )
        )

    def test_remove_pass_body_positive_condition(self):
        """Test that if a: pass else: body negates the condition."""
        spec = RecipeSpec(recipe=RemovePassBody())
        spec.rewrite_run(
            python(
                "if a:\n    pass\nelse:\n    return c\n",
                "if not a:\n    return c\n",
            )
        )

    def test_no_change_when_if_body_not_pass(self):
        """Test that if with non-pass body is not changed."""
        spec = RecipeSpec(recipe=RemovePassBody())
        spec.rewrite_run(
            python("if a:\n    x()\nelse:\n    return c\n")
        )

    def test_no_change_when_no_else(self):
        """Test that if with pass body but no else is not changed."""
        spec = RecipeSpec(recipe=RemovePassBody())
        spec.rewrite_run(
            python("if a:\n    pass\n")
        )


class TestRemovePassElif:
    """Tests for RemovePassElif: elif with pass body followed by else."""

    def test_remove_pass_elif(self):
        """Test that elif with pass body is simplified."""
        spec = RecipeSpec(recipe=RemovePassElif())
        spec.rewrite_run(
            python(
                "if a:\n    x()\nelif b:\n    pass\nelse:\n    return c\n",
                "if a:\n    x()\nelif not b:\n    return c\n",
            )
        )

    def test_no_change_when_elif_not_pass(self):
        """Test that elif with non-pass body is not changed."""
        spec = RecipeSpec(recipe=RemovePassElif())
        spec.rewrite_run(
            python("if a:\n    x()\nelif b:\n    y()\nelse:\n    return c\n")
        )

    def test_no_change_when_no_else_after_elif(self):
        """Test that elif with pass but no else is not changed."""
        spec = RecipeSpec(recipe=RemovePassElif())
        spec.rewrite_run(
            python("if a:\n    x()\nelif b:\n    pass\n")
        )

    def test_double_pass_elif_only_transforms_innermost(self):
        """With two pass-only elifs, only the innermost is transformed.

        The outer elif b's else body is another elif (If node).
        Transforming it would nest the elif chain, producing worse code.
        Only the inner elif c is transformed because its else body is a Block.
        """
        spec = RecipeSpec(recipe=RemovePassElif())
        spec.rewrite_run(
            python(
                "if a:\n    x()\nelif b:\n    pass\nelif c:\n    pass\nelse:\n    return d\n",
                "if a:\n    x()\nelif b:\n    pass\nelif not c:\n    return d\n",
            )
        )


class TestRemoveRedundantIf:
    """Tests for RemoveRedundantIf: elif with negated if condition -> else."""

    def test_remove_negated_elif(self):
        """Test that elif with negation of if condition becomes else."""
        spec = RecipeSpec(recipe=RemoveRedundantIf())
        spec.rewrite_run(
            python(
                'if name.startswith("L"):\n    sing("Hip Hip!")\nelif not name.startswith("L"):\n    sing("Hello")\n',
                'if name.startswith("L"):\n    sing("Hip Hip!")\nelse:\n    sing("Hello")\n',
            )
        )

    def test_no_change_when_elif_different_condition(self):
        """Test that elif with different condition is not changed."""
        spec = RecipeSpec(recipe=RemoveRedundantIf())
        spec.rewrite_run(
            python(
                'if name.startswith("L"):\n    sing("Hip Hip!")\nelif name.endswith("L"):\n    sing("Hello")\n'
            )
        )

    def test_remove_simple_negated_elif(self):
        """Test with simple variable negation."""
        spec = RecipeSpec(recipe=RemoveRedundantIf())
        spec.rewrite_run(
            python(
                "if a:\n    x()\nelif not a:\n    y()\n",
                "if a:\n    x()\nelse:\n    y()\n",
            )
        )


class TestRemoveUnnecessaryElse:
    """Tests for RemoveUnnecessaryElse: remove else after guard clause."""

    def test_remove_else_after_return(self):
        """Test that else is removed when if body ends with return."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python(
                "if a is None:\n    return 42\nelse:\n    var = 1\n    return var\n",
                "if a is None:\n    return 42\nvar = 1\nreturn var\n",
            )
        )

    def test_remove_else_after_raise(self):
        """Test that else is removed when if body ends with raise."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python(
                "if a is None:\n    raise ValueError()\nelse:\n    return a\n",
                "if a is None:\n    raise ValueError()\nreturn a\n",
            )
        )

    def test_no_change_when_if_does_not_exit(self):
        """Test that else is kept when if body does not exit."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python("if a:\n    x = 1\nelse:\n    x = 2\n")
        )

    def test_no_change_when_no_else(self):
        """Test that if without else is not modified."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python("if a:\n    return 42\n")
        )

    def test_remove_else_after_return_in_method(self):
        """Else body in method context must be properly dedented, not concatenated onto return line."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python(
                "def __len__(self):\n"
                "    if distance <= self._zero:\n"
                "        return 0\n"
                "    else:\n"
                "        q, r = divmod(distance, step)\n"
                "        return int(q) + int(r != self._zero)\n",
                "def __len__(self):\n"
                "    if distance <= self._zero:\n"
                "        return 0\n"
                "    q, r = divmod(distance, step)\n"
                "    return int(q) + int(r != self._zero)\n",
            )
        )

    def test_remove_else_after_return_with_comment(self):
        """Else with inline comment must still be properly dedented."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python(
                "def __len__(self):\n"
                "    if distance <= zero:\n"
                "        return 0\n"
                "    else:  # regular division\n"
                "        q, r = divmod(distance, step)\n"
                "        return int(q)\n",
                "def __len__(self):\n"
                "    if distance <= zero:\n"
                "        return 0\n"
                "    q, r = divmod(distance, step)\n"
                "    return int(q)\n",
            )
        )

    def test_remove_else_dedents_for_loop_body(self):
        """When else has a for-loop, the loop body must also be dedented."""
        spec = RecipeSpec(recipe=RemoveUnnecessaryElse())
        spec.rewrite_run(
            python(
                "def search(self):\n"
                "    if done:\n"
                "        return\n"
                "    else:\n"
                "        for i in range(start, end):\n"
                "            i %= length\n"
                "            if match(i):\n"
                "                return i\n",
                "def search(self):\n"
                "    if done:\n"
                "        return\n"
                "    for i in range(start, end):\n"
                "        i %= length\n"
                "        if match(i):\n"
                "            return i\n",
            )
        )


class TestAssignIfExp:
    """Tests for AssignIfExp: if/else assignment to ternary."""

    def test_convert_assignment_to_ternary(self):
        """Test that if/else with same-variable assignment becomes ternary."""
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(
            python(
                "if condition:\n    x = 1\nelse:\n    x = 2\n",
                "x = 1 if condition else 2\n",
            )
        )

    def test_no_change_when_different_variables(self):
        """Test that if/else assigning different variables is not changed."""
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(
            python("if condition:\n    x = 1\nelse:\n    y = 2\n")
        )

    def test_no_change_when_multiple_statements(self):
        """Test that if/else with multiple statements is not changed."""
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(
            python("if condition:\n    x = 1\n    y = 2\nelse:\n    x = 3\n")
        )

    def test_no_change_tuple_unpacking(self):
        """Test that tuple unpacking assignment is NOT converted to ternary.

        `left, right = X if cond else Y, Z` has ambiguous comma parsing.
        """
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(
            python(
                """
                if cond:
                    left, right = a, b
                else:
                    left, right = c, d
                """
            )
        )

    def test_no_change_nested_if_else(self):
        """Test that nested if/else is NOT converted to chained ternary."""
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(
            python(
                """
                if a:
                    x = val1 if b else val2
                else:
                    x = val3
                """
            )
        )

    def test_no_change_elif_chain(self):
        """elif/else that assigns to same var should not produce `else:x = ...`."""
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(python(
            "if a:\n    x = 1\nelif b:\n    x = 2\nelse:\n    x = 3",
        ))

    def test_no_change_lambda_values(self):
        """Lambda values must not be converted to ternary — lambda body absorbs the `if`.

        `key = lambda x: expr1 if cond else lambda x: expr2` parses as
        `lambda x: (expr1 if cond else (lambda x: expr2))`, returning a lambda
        object instead of a value when cond is False.
        """
        spec = RecipeSpec(recipe=AssignIfExp())
        spec.rewrite_run(python(
            "if ordering is None:\n"
            "    key = lambda x: x[0] - x[1]\n"
            "else:\n"
            "    key = lambda x: x[0] - ordering(x[1])\n",
        ))

