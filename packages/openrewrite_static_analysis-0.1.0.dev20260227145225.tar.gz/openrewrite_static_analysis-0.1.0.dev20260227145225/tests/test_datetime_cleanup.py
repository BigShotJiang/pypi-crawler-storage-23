"""Tests for datetime cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.datetime_cleanup import (
    UseDatetimeNowNotToday,
)


class TestUseDatetimeNowNotToday:
    """Tests for the UseDatetimeNowNotToday recipe."""

    def test_replaces_datetime_today(self):
        """Test that datetime.today() is replaced with datetime.now()."""
        spec = RecipeSpec(recipe=UseDatetimeNowNotToday())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                print(datetime.today())
                """,
                """
                from datetime import datetime
                print(datetime.now())
                """,
            )
        )

    def test_replaces_in_assignment(self):
        """Test that datetime.today() is replaced in an assignment."""
        spec = RecipeSpec(recipe=UseDatetimeNowNotToday())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                dt = datetime.today()
                """,
                """
                from datetime import datetime
                dt = datetime.now()
                """,
            )
        )

    def test_no_change_datetime_now(self):
        """Test that datetime.now() is not modified."""
        spec = RecipeSpec(recipe=UseDatetimeNowNotToday())
        spec.rewrite_run(
            python(
                """
                from datetime import datetime
                dt = datetime.now()
                """
            )
        )

    def test_no_change_date_today(self):
        """Test that date.today() is not modified (only datetime.today())."""
        spec = RecipeSpec(recipe=UseDatetimeNowNotToday())
        spec.rewrite_run(
            python(
                """
                from datetime import date
                dt = date.today()
                """
            )
        )

    def test_no_change_other_today_method(self):
        """Test that other objects' today() method is not modified."""
        spec = RecipeSpec(recipe=UseDatetimeNowNotToday())
        spec.rewrite_run(
            python(
                """
                result = my_obj.today()
                """
            )
        )
