"""Tests for syntax cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.syntax_cleanup import (
    BreakOrContinueOutsideLoop,
    ReturnOrYieldOutsideFunction,
)


class TestBreakOrContinueOutsideLoop:
    """Tests for the BreakOrContinueOutsideLoop recipe."""

    def test_removes_break_outside_loop(self):
        """Test that break outside any loop is removed."""
        spec = RecipeSpec(recipe=BreakOrContinueOutsideLoop())
        spec.rewrite_run(
            python(
                """
                def handle(numbers):
                    for number in numbers:
                        if is_valid(number):
                            continue
                    break
                    handle(number)
                """,
                """
                def handle(numbers):
                    for number in numbers:
                        if is_valid(number):
                            continue
                    handle(number)
                """,
            )
        )

    def test_removes_continue_outside_loop(self):
        """Test that continue outside any loop is removed."""
        spec = RecipeSpec(recipe=BreakOrContinueOutsideLoop())
        spec.rewrite_run(
            python(
                """
                x = 1
                continue
                y = 2
                """,
                """
                x = 1
                y = 2
                """,
            )
        )

    def test_no_change_break_inside_for(self):
        """Test that break inside a for loop is not removed."""
        spec = RecipeSpec(recipe=BreakOrContinueOutsideLoop())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    if i > 5:
                        break
                """
            )
        )

    def test_no_change_continue_inside_while(self):
        """Test that continue inside a while loop is not removed."""
        spec = RecipeSpec(recipe=BreakOrContinueOutsideLoop())
        spec.rewrite_run(
            python(
                """
                while True:
                    if done:
                        continue
                """
            )
        )

    def test_no_change_break_inside_nested_if_in_loop(self):
        """Test that break inside an if inside a loop is not removed."""
        spec = RecipeSpec(recipe=BreakOrContinueOutsideLoop())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    if i > 5:
                        break
                    print(i)
                """
            )
        )


class TestReturnOrYieldOutsideFunction:
    """Tests for the ReturnOrYieldOutsideFunction recipe."""

    def test_removes_return_outside_function(self):
        """Test that return outside any function is removed."""
        spec = RecipeSpec(recipe=ReturnOrYieldOutsideFunction())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    print(i)
                    return i
                """,
                """
                for i in range(10):
                    print(i)
                """,
            )
        )

    def test_removes_bare_return_outside_function(self):
        """Test that bare return outside any function is removed."""
        spec = RecipeSpec(recipe=ReturnOrYieldOutsideFunction())
        spec.rewrite_run(
            python(
                """
                x = 1
                return
                y = 2
                """,
                """
                x = 1
                y = 2
                """,
            )
        )

    def test_no_change_return_inside_function(self):
        """Test that return inside a function is not removed."""
        spec = RecipeSpec(recipe=ReturnOrYieldOutsideFunction())
        spec.rewrite_run(
            python(
                """
                def foo():
                    return 42
                """
            )
        )

    def test_no_change_return_in_nested_function(self):
        """Test that return inside a nested function is not removed."""
        spec = RecipeSpec(recipe=ReturnOrYieldOutsideFunction())
        spec.rewrite_run(
            python(
                """
                def outer():
                    def inner():
                        return 1
                    return inner()
                """
            )
        )

    def test_no_change_return_inside_method(self):
        """Test that return inside a class method is not removed."""
        spec = RecipeSpec(recipe=ReturnOrYieldOutsideFunction())
        spec.rewrite_run(
            python(
                """
                class Foo:
                    def bar(self):
                        return 42
                """
            )
        )
