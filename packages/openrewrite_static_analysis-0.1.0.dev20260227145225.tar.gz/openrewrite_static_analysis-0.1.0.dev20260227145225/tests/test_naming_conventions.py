"""Tests for naming conventions cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.naming_conventions import (
    ClassMethodFirstArgName,
    InstanceMethodFirstArgName,
)


class TestClassMethodFirstArgName:
    """Tests for the ClassMethodFirstArgName recipe."""

    def test_renames_first_arg(self):
        """Test that first param of @classmethod is renamed to `cls`."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @classmethod
    def bar(klass, x):
        return x
''',
                '''class Foo:
    @classmethod
    def bar(cls, x):
        return x
''',
            )
        )

    def test_no_change_already_cls(self):
        """Test that @classmethod with `cls` is not modified."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @classmethod
    def bar(cls, x):
        return x
'''
            )
        )

    def test_renames_body_references(self):
        """Test that references to the renamed param in the body are also renamed."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @classmethod
    def create(klass, value):
        return klass(value)
''',
                '''class Foo:
    @classmethod
    def create(cls, value):
        return cls(value)
''',
            )
        )

    def test_no_change_instance_method(self):
        """Test that instance methods are not affected."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def bar(klass, x):
        return x
'''
            )
        )

    def test_no_change_staticmethod(self):
        """Test that @staticmethod methods are not affected."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @staticmethod
    def bar(klass, x):
        return x
'''
            )
        )

    def test_no_params(self):
        """Test that @classmethod with no params is not modified."""
        spec = RecipeSpec(recipe=ClassMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @classmethod
    def bar():
        pass
'''
            )
        )


class TestInstanceMethodFirstArgName:
    """Tests for the InstanceMethodFirstArgName recipe."""

    def test_renames_first_arg(self):
        """Test that first param of instance method is renamed to `self`."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def bar(this, x):
        return x
''',
                '''class Foo:
    def bar(self, x):
        return x
''',
            )
        )

    def test_no_change_already_self(self):
        """Test that instance method with `self` is not modified."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def bar(self, x):
        return x
'''
            )
        )

    def test_renames_body_references(self):
        """Test that references to the renamed param in the body are also renamed."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def get_name(this):
        return this.name
''',
                '''class Foo:
    def get_name(self):
        return self.name
''',
            )
        )

    def test_no_change_staticmethod(self):
        """Test that @staticmethod methods are not affected."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @staticmethod
    def bar(x):
        return x
'''
            )
        )

    def test_no_change_classmethod(self):
        """Test that @classmethod methods are not affected."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    @classmethod
    def bar(klass, x):
        return x
'''
            )
        )

    def test_no_change_top_level_function(self):
        """Test that top-level functions are not affected."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''def foo(this, x):
    return this
'''
            )
        )

    def test_no_params(self):
        """Test that instance method with no params is not modified."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def bar():
        pass
'''
            )
        )

    def test_no_rename_in_nested_function(self):
        """Test that variables in nested functions are not renamed."""
        spec = RecipeSpec(recipe=InstanceMethodFirstArgName())
        spec.rewrite_run(
            python(
                '''class Foo:
    def method(this):
        def inner():
            this = 10
            return this
        return this.name
''',
                '''class Foo:
    def method(self):
        def inner():
            this = 10
            return this
        return self.name
''',
            )
        )
