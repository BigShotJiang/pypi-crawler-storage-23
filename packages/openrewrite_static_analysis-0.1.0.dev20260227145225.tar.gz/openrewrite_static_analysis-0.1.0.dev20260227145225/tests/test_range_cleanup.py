"""Tests for range() cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.range_cleanup import (
    RemoveZeroFromRange,
    RemoveUnitStepFromRange,
)


class TestRemoveZeroFromRange:
    """Tests for the RemoveZeroFromRange recipe."""

    def test_removes_zero_start_from_range(self):
        """Test that range(0, x) is simplified to range(x)."""
        spec = RecipeSpec(recipe=RemoveZeroFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(0, 10)
                """,
                """
                result = range(10)
                """,
            )
        )

    def test_removes_zero_start_with_variable(self):
        """Test that range(0, n) is simplified to range(n) when n is a variable."""
        spec = RecipeSpec(recipe=RemoveZeroFromRange())
        spec.rewrite_run(
            python(
                """
                n = 10
                result = range(0, n)
                """,
                """
                n = 10
                result = range(n)
                """,
            )
        )

    def test_no_change_when_single_arg_range(self):
        """Test that range(x) with a single argument is not modified."""
        spec = RecipeSpec(recipe=RemoveZeroFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(10)
                """
            )
        )

    def test_no_change_when_nonzero_start(self):
        """Test that range(1, 10) is not modified."""
        spec = RecipeSpec(recipe=RemoveZeroFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(1, 10)
                """
            )
        )


class TestRemoveUnitStepFromRange:
    """Tests for the RemoveUnitStepFromRange recipe."""

    def test_removes_unit_step_from_range(self):
        """Test that range(x, y, 1) is simplified to range(x, y)."""
        spec = RecipeSpec(recipe=RemoveUnitStepFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(0, 10, 1)
                """,
                """
                result = range(0, 10)
                """,
            )
        )

    def test_removes_unit_step_with_variables(self):
        """Test that range(a, b, 1) is simplified to range(a, b) with variables."""
        spec = RecipeSpec(recipe=RemoveUnitStepFromRange())
        spec.rewrite_run(
            python(
                """
                a = 2
                b = 20
                result = range(a, b, 1)
                """,
                """
                a = 2
                b = 20
                result = range(a, b)
                """,
            )
        )

    def test_no_change_when_two_arg_range(self):
        """Test that range(x, y) without a step is not modified."""
        spec = RecipeSpec(recipe=RemoveUnitStepFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(0, 10)
                """
            )
        )

    def test_no_change_when_step_is_not_one(self):
        """Test that range(x, y, 2) is not modified."""
        spec = RecipeSpec(recipe=RemoveUnitStepFromRange())
        spec.rewrite_run(
            python(
                """
                result = range(0, 10, 2)
                """
            )
        )
