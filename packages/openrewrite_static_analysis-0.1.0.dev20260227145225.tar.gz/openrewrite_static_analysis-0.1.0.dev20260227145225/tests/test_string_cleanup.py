"""Tests for string cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.string_cleanup import (
    RemoveStrFromPrint,
    RemoveNoneFromDefaultGet,
    RemoveRedundantFstring,
    RemoveStrFromFstring,
    SimplifyFstringFormatting,
    StrPrefixSuffix,
    UseGetitemForReMatchGroups,
    UseStringRemoveAffix,
)


class TestRemoveStrFromPrint:
    """Tests for the RemoveStrFromPrint recipe."""

    def test_removes_str_from_print(self):
        """Test that print(str(x)) is simplified to print(x)."""
        spec = RecipeSpec(recipe=RemoveStrFromPrint())
        spec.rewrite_run(
            python(
                "print(str(x))",
                "print(x)",
            )
        )

    def test_no_change_no_str(self):
        """Test that print(x) without str() is not modified."""
        spec = RecipeSpec(recipe=RemoveStrFromPrint())
        spec.rewrite_run(python("print(x)"))


class TestRemoveNoneFromDefaultGet:
    """Tests for the RemoveNoneFromDefaultGet recipe."""

    def test_removes_none_default(self):
        """Test that d.get('key', None) is simplified to d.get('key')."""
        spec = RecipeSpec(recipe=RemoveNoneFromDefaultGet())
        spec.rewrite_run(
            python(
                "x = d.get('key', None)",
                "x = d.get('key')",
            )
        )

    def test_no_change_non_none_default(self):
        """Test that d.get('key', 0) with a non-None default is not modified."""
        spec = RecipeSpec(recipe=RemoveNoneFromDefaultGet())
        spec.rewrite_run(python("x = d.get('key', 0)"))

    def test_no_change_bytes_default(self):
        """Test that d.get('body', b'') is NOT modified — b'' is not None."""
        spec = RecipeSpec(recipe=RemoveNoneFromDefaultGet())
        spec.rewrite_run(python('x = d.get("body", b"")'))

    def test_no_change_empty_string_default(self):
        """Test that d.get('key', '') is NOT modified — '' is not None."""
        spec = RecipeSpec(recipe=RemoveNoneFromDefaultGet())
        spec.rewrite_run(python("x = d.get('key', '')"))

    def test_no_change_dict_default(self):
        """Test that d.get('key', {}) is NOT modified — {} is not None."""
        spec = RecipeSpec(recipe=RemoveNoneFromDefaultGet())
        spec.rewrite_run(python("x = d.get('key', {})"))


class TestRemoveRedundantFstring:
    """Tests for the RemoveRedundantFstring recipe."""

    def test_removes_fstring_no_interpolation(self):
        """f-string with no interpolations becomes a regular string."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(
            python(
                'print(f"Why am I an f-string")',
                'print("Why am I an f-string")',
            )
        )

    def test_removes_fstring_single_quotes(self):
        """f-string with single quotes and no interpolations becomes a regular string."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(
            python(
                "x = f'no interpolation here'",
                "x = 'no interpolation here'",
            )
        )

    def test_no_change_fstring_with_interpolation(self):
        """f-string with interpolations is not modified."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(python('x = f"hello {name}"'))

    def test_no_change_regular_string(self):
        """Regular string is not modified."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(python('x = "hello world"'))

    def test_removes_empty_fstring(self):
        """Empty f-string becomes a regular empty string."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(
            python(
                'x = f""',
                'x = ""',
            )
        )

    def test_rf_string_no_interpolation(self):
        """rf-string without interpolation should become r-string, not lose r prefix."""
        spec = RecipeSpec(recipe=RemoveRedundantFstring())
        spec.rewrite_run(
            python(
                r'pattern = rf"test\.txt"',
                r'pattern = r"test\.txt"',
            )
        )


class TestRemoveStrFromFstring:
    """Tests for the RemoveStrFromFstring recipe."""

    def test_removes_str_from_fstring_single(self):
        """str() call inside f-string is removed."""
        spec = RecipeSpec(recipe=RemoveStrFromFstring())
        spec.rewrite_run(
            python(
                'x = f"Name: {str(name)}"',
                'x = f"Name: {name}"',
            )
        )

    def test_removes_str_from_fstring_multiple(self):
        """Multiple str() calls inside f-string are removed."""
        spec = RecipeSpec(recipe=RemoveStrFromFstring())
        spec.rewrite_run(
            python(
                'x = f"Name: {str(name)}, Age: {str(age)}"',
                'x = f"Name: {name}, Age: {age}"',
            )
        )

    def test_no_change_no_str_in_fstring(self):
        """f-string without str() is not modified."""
        spec = RecipeSpec(recipe=RemoveStrFromFstring())
        spec.rewrite_run(python('x = f"Name: {name}"'))

    def test_no_change_str_with_no_args(self):
        """str() with no arguments inside f-string is not modified."""
        spec = RecipeSpec(recipe=RemoveStrFromFstring())
        spec.rewrite_run(python('x = f"empty: {str()}"'))

    def test_no_change_method_on_object(self):
        """obj.str() inside f-string is not modified (not a bare str() call)."""
        spec = RecipeSpec(recipe=RemoveStrFromFstring())
        spec.rewrite_run(python('x = f"value: {obj.str(name)}"'))


class TestStrPrefixSuffix:
    """Tests for the StrPrefixSuffix recipe."""

    def test_prefix_check_becomes_startswith(self):
        """name[:8] == 'forecast' becomes name.startswith('forecast')."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(
            python(
                'x = name[:8] == "forecast"',
                'x = name.startswith("forecast")',
            )
        )

    def test_suffix_check_becomes_endswith(self):
        """name[-8:] == 'forecast' becomes name.endswith('forecast')."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(
            python(
                'x = name[-8:] == "forecast"',
                'x = name.endswith("forecast")',
            )
        )

    def test_reversed_order_prefix(self):
        """'forecast' == name[:8] also becomes name.startswith('forecast')."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(
            python(
                'x = "forecast" == name[:8]',
                'x = name.startswith("forecast")',
            )
        )

    def test_no_change_length_mismatch(self):
        """name[:5] == 'forecast' is not modified (5 != 8)."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(python('x = name[:5] == "forecast"'))

    def test_no_change_not_equality(self):
        """name[:8] != 'forecast' is not modified (not ==)."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(python('x = name[:8] != "forecast"'))

    def test_no_change_no_slice(self):
        """name == 'forecast' is not modified (no slice)."""
        spec = RecipeSpec(recipe=StrPrefixSuffix())
        spec.rewrite_run(python('x = name == "forecast"'))


class TestSimplifyFstringFormatting:
    """Tests for the SimplifyFstringFormatting recipe."""

    def test_inline_integer_constant(self):
        """f"{5} years old" becomes f"5 years old"."""
        spec = RecipeSpec(recipe=SimplifyFstringFormatting())
        spec.rewrite_run(
            python(
                'x = f"{5} years old"',
                'x = f"5 years old"',
            )
        )

    def test_inline_string_constant(self):
        """f"{'hello'} world" becomes f"hello world"."""
        spec = RecipeSpec(recipe=SimplifyFstringFormatting())
        spec.rewrite_run(
            python(
                "x = f\"{'hello'} world\"",
                'x = f"hello world"',
            )
        )

    def test_remove_nested_fstring(self):
        """f"{f'{name.upper()}'}" becomes f"{name.upper()}"."""
        spec = RecipeSpec(recipe=SimplifyFstringFormatting())
        spec.rewrite_run(
            python(
                "x = f\"{f'{name.upper()}'}\"",
                'x = f"{name.upper()}"',
            )
        )

    def test_no_change_variable_interpolation(self):
        """f"{name}" is not modified."""
        spec = RecipeSpec(recipe=SimplifyFstringFormatting())
        spec.rewrite_run(python('x = f"{name}"'))

    def test_no_change_formatted_value(self):
        """f"{x:.2f}" is not modified (has format spec)."""
        spec = RecipeSpec(recipe=SimplifyFstringFormatting())
        spec.rewrite_run(python('x = f"{value:.2f}"'))


class TestUseGetitemForReMatchGroups:
    """Tests for the UseGetitemForReMatchGroups recipe."""

    def test_group_zero(self):
        """m.group(0) becomes m[0]."""
        spec = RecipeSpec(recipe=UseGetitemForReMatchGroups())
        spec.rewrite_run(
            python(
                "x = m.group(0)",
                "x = m[0]",
            )
        )

    def test_group_one(self):
        """m.group(1) becomes m[1]."""
        spec = RecipeSpec(recipe=UseGetitemForReMatchGroups())
        spec.rewrite_run(
            python(
                "x = m.group(1)",
                "x = m[1]",
            )
        )

    def test_no_change_group_no_args(self):
        """m.group() with no arguments is not modified."""
        spec = RecipeSpec(recipe=UseGetitemForReMatchGroups())
        spec.rewrite_run(python("x = m.group()"))

    def test_no_change_group_multiple_args(self):
        """m.group(1, 2) with multiple arguments is not modified."""
        spec = RecipeSpec(recipe=UseGetitemForReMatchGroups())
        spec.rewrite_run(python("x = m.group(1, 2)"))

    def test_no_change_not_group(self):
        """m.start(0) is not modified (not group method)."""
        spec = RecipeSpec(recipe=UseGetitemForReMatchGroups())
        spec.rewrite_run(python("x = m.start(0)"))


class TestUseStringRemoveAffix:
    """Tests for the UseStringRemoveAffix recipe."""

    def test_removeprefix(self):
        """if text.startswith('prefix'): text = text[N:] becomes text = text.removeprefix('prefix')."""
        spec = RecipeSpec(recipe=UseStringRemoveAffix())
        spec.rewrite_run(
            python(
                """
                if text.startswith("Hello, "):
                    text = text[7:]
                """,
                """
                text = text.removeprefix("Hello, ")
                """,
            )
        )

    def test_removesuffix_with_len(self):
        """if text.endswith('suffix'): text = text[:-N] becomes text = text.removesuffix('suffix')."""
        spec = RecipeSpec(recipe=UseStringRemoveAffix())
        spec.rewrite_run(
            python(
                """
                if text.endswith(" World!"):
                    text = text[:-7]
                """,
                """
                text = text.removesuffix(" World!")
                """,
            )
        )

    def test_no_change_different_variable(self):
        """Variables must match between condition and assignment."""
        spec = RecipeSpec(recipe=UseStringRemoveAffix())
        spec.rewrite_run(
            python(
                """
                if text.startswith("Hello, "):
                    other = text[7:]
                """
            )
        )

    def test_no_change_wrong_slice_length(self):
        """Slice length must match the prefix string length."""
        spec = RecipeSpec(recipe=UseStringRemoveAffix())
        spec.rewrite_run(
            python(
                """
                if text.startswith("Hello, "):
                    text = text[5:]
                """
            )
        )

    def test_no_change_multiple_statements(self):
        """If body has more than one statement, do not modify."""
        spec = RecipeSpec(recipe=UseStringRemoveAffix())
        spec.rewrite_run(
            python(
                """
                if text.startswith("Hello, "):
                    text = text[7:]
                    print(text)
                """
            )
        )
