"""Tests for complex transform cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.complex_transforms import (
    TernaryToIfExpression,
    DefaultMutableArg,
    SwapVariable,
)


class TestTernaryToIfExpression:
    """Tests for TernaryToIfExpression: cond and x or y -> x if cond else y."""

    def test_transforms_and_or_pattern(self):
        """Test that cond and x or y is transformed to x if cond else y."""
        spec = RecipeSpec(recipe=TernaryToIfExpression())
        spec.rewrite_run(
            python(
                "result = cond and x or y",
                "result = x if cond else y",
            )
        )

    def test_no_change_simple_or(self):
        """Test that a simple or expression is not modified."""
        spec = RecipeSpec(recipe=TernaryToIfExpression())
        spec.rewrite_run(python("result = x or y"))

    def test_no_change_simple_and(self):
        """Test that a simple and expression is not modified."""
        spec = RecipeSpec(recipe=TernaryToIfExpression())
        spec.rewrite_run(python("result = x and y"))

    def test_no_change_compound_boolean_expression(self):
        """(A and B) or (C and D) is boolean logic, NOT a ternary trick.

        The pattern `cond and val or fallback` only applies when the intent
        is a conditional expression.  When `and`/`or` combine multiple
        boolean conditions (e.g. `has_space and spaces != 1 or has_tab and
        spaces > 0`), converting to a ternary changes the semantics: the
        original evaluates both branches via short-circuit, while the
        ternary returns `B` (possibly False) instead of falling through to
        `C and D`.
        """
        spec = RecipeSpec(recipe=TernaryToIfExpression())
        spec.rewrite_run(python(
            "if has_space and num_spaces != 1 or has_tab and num_spaces > 0:\n    adjust()"
        ))

    def test_no_change_or_of_and_clauses(self):
        """Simpler case: `a and b or c and d` should not become ternary."""
        spec = RecipeSpec(recipe=TernaryToIfExpression())
        spec.rewrite_run(python(
            "result = a and b or c and d"
        ))


class TestDefaultMutableArg:
    """Tests for DefaultMutableArg: replace mutable default with None + guard."""

    def test_empty_list_default(self):
        """Test def func(hats: list = []) -> def func(hats: list = None) with guard."""
        spec = RecipeSpec(recipe=DefaultMutableArg())
        spec.rewrite_run(
            python(
                """
                def func(hats: list = []):
                    change(hats)
                """,
                """
                def func(hats: list = None):
                    if hats is None:
                        hats = []
                    change(hats)
                """,
            )
        )

    def test_empty_dict_default(self):
        """Test def func(opts = {}) -> def func(opts = None) with guard."""
        spec = RecipeSpec(recipe=DefaultMutableArg())
        spec.rewrite_run(
            python(
                """
                def func(opts = {}):
                    use(opts)
                """,
                """
                def func(opts = None):
                    if opts is None:
                        opts = {}
                    use(opts)
                """,
            )
        )

    def test_no_change_immutable_default(self):
        """Test that immutable defaults (None, int, str) are not changed."""
        spec = RecipeSpec(recipe=DefaultMutableArg())
        spec.rewrite_run(
            python(
                """
                def func(x=None, y=0, z="hello"):
                    pass
                """
            )
        )

    def test_no_change_no_default(self):
        """Test that parameters without defaults are not changed."""
        spec = RecipeSpec(recipe=DefaultMutableArg())
        spec.rewrite_run(
            python(
                """
                def func(x, y):
                    pass
                """
            )
        )

    def test_guard_after_docstring(self):
        """Guard should be inserted after the docstring, not before it."""
        spec = RecipeSpec(recipe=DefaultMutableArg())
        spec.rewrite_run(
            python(
                '''
                def func(items=[]):
                    """Process items."""
                    process(items)
                ''',
                '''
                def func(items=None):
                    """Process items."""
                    if items is None:
                        items = []
                    process(items)
                ''',
            )
        )


class TestSwapVariable:
    """Tests for SwapVariable: 3-statement swap -> tuple assignment."""

    def test_basic_swap(self):
        """Test temp=a; a=b; b=temp -> a, b = b, a."""
        spec = RecipeSpec(recipe=SwapVariable())
        spec.rewrite_run(
            python(
                """
                temp = a
                a = b
                b = temp
                """,
                """
                a, b = b, a
                """,
            )
        )

    def test_swap_with_different_temp_name(self):
        """Test tmp=x; x=y; y=tmp -> x, y = y, x."""
        spec = RecipeSpec(recipe=SwapVariable())
        spec.rewrite_run(
            python(
                """
                tmp = x
                x = y
                y = tmp
                """,
                """
                x, y = y, x
                """,
            )
        )

    def test_no_change_not_swap_pattern(self):
        """Test that non-swap assignment sequences are not changed."""
        spec = RecipeSpec(recipe=SwapVariable())
        spec.rewrite_run(
            python(
                """
                a = 1
                b = 2
                c = 3
                """
            )
        )
