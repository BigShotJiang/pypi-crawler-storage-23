"""Tests for None comparison and identity cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.none_and_identity import (
    NoneCompare,
    EqualityIdentity,
    BinOpIdentity,
    SquareIdentity,
)


class TestNoneCompare:
    """Tests for the NoneCompare recipe."""

    def test_eq_none(self):
        """Test that `x == None` is replaced with `x is None`."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x == None:\n    pass",
                "if x is None:\n    pass",
            )
        )

    def test_neq_none(self):
        """Test that `x != None` is replaced with `x is not None`."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x != None:\n    pass",
                "if x is not None:\n    pass",
            )
        )

    def test_no_change_already_is_none(self):
        """Test that `x is None` is not modified."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x is None:\n    pass"
            )
        )

    def test_no_change_already_is_not_none(self):
        """Test that `x is not None` is not modified."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x is not None:\n    pass"
            )
        )

    def test_no_change_eq_other_value(self):
        """Test that `x == 0` is not modified (only None comparisons)."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x == 0:\n    pass"
            )
        )

    def test_no_change_neq_other_value(self):
        """Test that `x != 0` is not modified (only None comparisons)."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x != 0:\n    pass"
            )
        )

    def test_no_change_bytes_literal(self):
        """Test that `x == b'hello'` is NOT turned into `x is None`."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                'x = name == b"hello"'
            )
        )

    def test_no_change_string_literal(self):
        """Test that `x == 'hello'` is NOT turned into `x is None`."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                'if x == "hello":\n    pass'
            )
        )

    def test_no_change_int_literal(self):
        """Test that `x == 42` is NOT turned into `x is None`."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x == 42:\n    pass"
            )
        )

    def test_no_change_ternary_with_none(self):
        """Ternary containing None should not be transformed."""
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(python('x = cookies == (b"a=b" if cond else None)'))

    def test_no_change_ellipsis_comparison(self):
        """Comparison to Ellipsis literal must NOT become `is None`.

        Real-world example from jedi: `if pos_tup[1] == ...:` was
        incorrectly turned into `if pos_tup[1] is None:`.
        """
        spec = RecipeSpec(recipe=NoneCompare())
        spec.rewrite_run(
            python(
                "if x == ...:\n    pass"
            )
        )


class TestEqualityIdentity:
    """Tests for the EqualityIdentity recipe."""

    def test_literal_eq_same_literal_becomes_true(self):
        """Test that `1 == 1` is replaced with `True`."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "if 1 == 1:\n    always_do_this()",
                "if True:\n    always_do_this()",
            )
        )

    def test_literal_neq_same_literal_becomes_false(self):
        """Test that `1 != 1` is replaced with `False`."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "if 1 != 1:\n    never_do_this()",
                "if False:\n    never_do_this()",
            )
        )

    def test_string_literal_eq_same(self):
        """Test that `'a' == 'a'` is replaced with `True`."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "x = 'a' == 'a'",
                "x = True",
            )
        )

    def test_no_change_different_literals(self):
        """Test that `1 == 2` is not modified (different values)."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "if 1 == 2:\n    pass"
            )
        )

    def test_no_change_variable_comparison(self):
        """Test that `x == x` is not modified (not literals)."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "if x == x:\n    pass"
            )
        )

    def test_no_change_already_true(self):
        """Test that `True` is not modified."""
        spec = RecipeSpec(recipe=EqualityIdentity())
        spec.rewrite_run(
            python(
                "if True:\n    pass"
            )
        )


class TestBinOpIdentity:
    """Tests for the BinOpIdentity recipe."""

    def test_no_change_or_same_variable(self):
        """x | x should not be simplified (intentional in real code)."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(python("y = x | x"))

    def test_no_change_and_same_variable(self):
        """x & x should not be simplified (intentional in real code)."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(python("y = x & x"))

    def test_xor_same_variable(self):
        """Test that `x ^ x` is replaced with `0`."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(
            python(
                "y = x ^ x",
                "y = 0",
            )
        )

    def test_sub_same_variable(self):
        """Test that `x - x` is replaced with `0`."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(
            python(
                "y = x - x",
                "y = 0",
            )
        )

    def test_no_change_different_operands(self):
        """Test that `x | y` is not modified (different operands)."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(
            python(
                "y = x | z"
            )
        )

    def test_no_change_addition(self):
        """Test that `x + x` is not modified (not a recognized identity)."""
        spec = RecipeSpec(recipe=BinOpIdentity())
        spec.rewrite_run(
            python(
                "y = x + x"
            )
        )


class TestSquareIdentity:
    """Tests for the SquareIdentity recipe."""

    def test_variable_times_self(self):
        """Test that `x * x` is replaced with `x ** 2`."""
        spec = RecipeSpec(recipe=SquareIdentity())
        spec.rewrite_run(
            python(
                "y = x * x",
                "y = x ** 2",
            )
        )

    def test_no_change_different_operands(self):
        """Test that `x * y` is not modified (different operands)."""
        spec = RecipeSpec(recipe=SquareIdentity())
        spec.rewrite_run(
            python(
                "y = x * z"
            )
        )

    def test_no_change_already_power(self):
        """Test that `x ** 2` is not modified."""
        spec = RecipeSpec(recipe=SquareIdentity())
        spec.rewrite_run(
            python(
                "y = x ** 2"
            )
        )

    def test_no_change_literal_times_literal(self):
        """60 * 60 should not become 60 ** 2 (loses semantic meaning)."""
        spec = RecipeSpec(recipe=SquareIdentity())
        spec.rewrite_run(python("SECONDS = 60 * 60"))
