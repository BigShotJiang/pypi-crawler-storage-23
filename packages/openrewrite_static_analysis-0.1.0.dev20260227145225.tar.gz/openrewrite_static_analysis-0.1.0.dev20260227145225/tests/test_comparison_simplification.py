"""Tests for comparison simplification cleanup recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.comparison_simplification import (
    FlipComparison,
    SimplifySubstringSearch,
    MergeComparisons,
    ChainCompares,
)


class TestFlipComparison:
    """Tests for the FlipComparison recipe: literal == x -> x == literal."""

    def test_flips_literal_eq(self):
        """Test that 1 == x is flipped to x == 1."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(
            python(
                "if 1 == x:\n    pass",
                "if x == 1:\n    pass",
            )
        )

    def test_flips_string_literal_eq(self):
        """Test that 'hello' == x is flipped to x == 'hello'."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(
            python(
                'if "hello" == x:\n    pass',
                'if x == "hello":\n    pass',
            )
        )

    def test_flips_literal_neq(self):
        """Test that 1 != x is flipped to x != 1."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(
            python(
                "if 1 != x:\n    pass",
                "if x != 1:\n    pass",
            )
        )

    def test_no_change_already_correct(self):
        """Test that x == 1 is not modified."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(python("if x == 1:\n    pass"))

    def test_no_change_both_literals(self):
        """Test that 1 == 2 is not modified (both sides are literals)."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(python("if 1 == 2:\n    pass"))

    def test_no_change_no_literals(self):
        """Test that x == y is not modified (neither side is a literal)."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(python("if x == y:\n    pass"))

    def test_no_change_chained_comparison(self):
        """Test that chained comparison 400 <= x < 600 is NOT broken by flipping."""
        spec = RecipeSpec(recipe=FlipComparison())
        spec.rewrite_run(python("if 400 <= status_code < 600:\n    pass"))


class TestSimplifySubstringSearch:
    """Tests for the SimplifySubstringSearch recipe."""

    def test_find_eq_neg1(self):
        """Test that s.find('x') == -1 is simplified to 'x' not in s."""
        spec = RecipeSpec(recipe=SimplifySubstringSearch())
        spec.rewrite_run(
            python(
                'if s.find("x") == -1:\n    pass',
                'if "x" not in s:\n    pass',
            )
        )

    def test_find_neq_neg1(self):
        """Test that s.find('x') != -1 is simplified to 'x' in s."""
        spec = RecipeSpec(recipe=SimplifySubstringSearch())
        spec.rewrite_run(
            python(
                'if s.find("x") != -1:\n    pass',
                'if "x" in s:\n    pass',
            )
        )

    def test_no_change_regular_eq(self):
        """Test that x == -1 without find is not modified."""
        spec = RecipeSpec(recipe=SimplifySubstringSearch())
        spec.rewrite_run(python("if x == -1:\n    pass"))

    def test_no_change_find_eq_zero(self):
        """Test that s.find('x') == 0 is not modified (not -1)."""
        spec = RecipeSpec(recipe=SimplifySubstringSearch())
        spec.rewrite_run(python('if s.find("x") == 0:\n    pass'))


class TestMergeComparisons:
    """Tests for the MergeComparisons recipe: x == 'A' or x == 'B' -> x in ['A', 'B']."""

    def test_merge_string_comparisons(self):
        """Test that x == 'A' or x == 'B' is merged to x in ['A', 'B']."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(
            python(
                'if x == "A" or x == "B":\n    do_something()',
                'if x in ["A", "B"]:\n    do_something()',
            )
        )

    def test_merge_int_comparisons(self):
        """Test that x == 1 or x == 2 is merged to x in [1, 2]."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(
            python(
                "if x == 1 or x == 2:\n    pass",
                "if x in [1, 2]:\n    pass",
            )
        )

    def test_no_change_different_left_operands(self):
        """Test that x == 1 or y == 2 is not modified (different left operands)."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(python("if x == 1 or y == 2:\n    pass"))

    def test_no_change_not_equality(self):
        """Test that x < 1 or x < 2 is not modified (not equality comparisons)."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(python("if x < 1 or x < 2:\n    pass"))

    def test_no_change_and_instead_of_or(self):
        """Test that x == 1 and x == 2 is not modified (uses 'and' not 'or')."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(python("if x == 1 and x == 2:\n    pass"))

    def test_merge_three_comparisons(self):
        """Test that x == 'a' or x == 'b' or x == 'c' merges into x in ['a', 'b', 'c']."""
        spec = RecipeSpec(recipe=MergeComparisons())
        spec.rewrite_run(
            python(
                'if os == "windows" or os == "cygwin" or os == "wsl":\n    pass',
                'if os in ["windows", "cygwin", "wsl"]:\n    pass',
            )
        )


class TestChainCompares:
    """Tests for the ChainCompares recipe: 1 < b and b < 3 -> 1 < b < 3."""

    def test_chain_less_than(self):
        """Test that 1 < b and b < 3 is chained to 1 < b < 3."""
        spec = RecipeSpec(recipe=ChainCompares())
        spec.rewrite_run(
            python(
                'if 1 < b and b < 3:\n    print("b is between 1 and 3")',
                'if 1 < b < 3:\n    print("b is between 1 and 3")',
            )
        )

    def test_no_change_different_middle(self):
        """Test that 1 < a and b < 3 is not modified (different middle operand)."""
        spec = RecipeSpec(recipe=ChainCompares())
        spec.rewrite_run(python("if 1 < a and b < 3:\n    pass"))
