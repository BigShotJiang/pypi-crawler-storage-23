"""Tests for redundant code cleanup recipes."""

from rewrite.test import RecipeSpec, python
from rewrite.python.recipes import RemovePass
from openrewrite_static_analysis.cleanup.redundant_code import (
    RemoveRedundantContinue,
    RemoveRedundantPathExists,
)


class TestRemovePass:
    """Tests for the RemovePass recipe (framework-level)."""

    def test_removes_pass_with_other_statements_in_class(self):
        """Test that pass is removed when class body has other statements."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                class Foo:
                    x = 1
                    pass
                """,
                """
                class Foo:
                    x = 1
                """,
            )
        )

    def test_removes_pass_with_other_statements_in_function(self):
        """Test that pass is removed when function body has other statements."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                def foo():
                    x = 1
                    pass
                """,
                """
                def foo():
                    x = 1
                """,
            )
        )

    def test_removes_pass_with_other_statements_in_if(self):
        """Test that pass is removed when if body has other statements."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                if True:
                    x = 1
                    pass
                """,
                """
                if True:
                    x = 1
                """,
            )
        )

    def test_no_change_when_pass_only_statement_in_class(self):
        """Test that pass is not removed when it's the only statement in a class."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                class Foo:
                    pass
                """
            )
        )

    def test_no_change_when_pass_only_statement_in_function(self):
        """Test that pass is not removed when it's the only statement in a function."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                def foo():
                    pass
                """
            )
        )

    def test_no_change_when_pass_only_statement_in_if(self):
        """Test that pass is not removed when it's the only statement in an if body."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                if True:
                    pass
                """
            )
        )

    def test_removes_pass_at_beginning_of_block(self):
        """Test that pass is removed even if it appears before other statements."""
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                """
                class Foo:
                    pass
                    x = 1
                """,
                """
                class Foo:
                    x = 1
                """,
            )
        )

    def test_no_change_when_only_docstring_and_pass(self):
        """Test that pass is NOT removed when the only other 'statement' is a docstring.

        A docstring alone is technically a valid function body, but
        docstring + pass is a common pattern for intentionally empty functions.
        """
        spec = RecipeSpec(recipe=RemovePass())
        spec.rewrite_run(
            python(
                '''
                def foo():
                    """This function intentionally does nothing."""
                    pass
                '''
            )
        )


class TestRemoveRedundantContinue:
    """Tests for the RemoveRedundantContinue recipe."""

    def test_removes_trailing_continue_in_for(self):
        """Test that trailing continue is removed from for loop."""
        spec = RecipeSpec(recipe=RemoveRedundantContinue())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    print(i)
                    continue
                """,
                """
                for i in range(10):
                    print(i)
                """,
            )
        )

    def test_removes_trailing_continue_in_while(self):
        """Test that trailing continue is removed from while loop."""
        spec = RecipeSpec(recipe=RemoveRedundantContinue())
        spec.rewrite_run(
            python(
                """
                while True:
                    print(1)
                    continue
                """,
                """
                while True:
                    print(1)
                """,
            )
        )

    def test_no_change_when_continue_in_if(self):
        """Test that continue inside an if inside a loop is not removed."""
        spec = RecipeSpec(recipe=RemoveRedundantContinue())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    if i > 5:
                        continue
                    print(i)
                """
            )
        )

    def test_no_change_when_continue_not_last(self):
        """Test that continue followed by another statement at loop level is not removed."""
        spec = RecipeSpec(recipe=RemoveRedundantContinue())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    continue
                    print(i)
                """
            )
        )

    def test_no_change_when_continue_only_statement(self):
        """Test that continue is not removed when it's the only statement in a loop."""
        spec = RecipeSpec(recipe=RemoveRedundantContinue())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    continue
                """
            )
        )


class TestRemoveRedundantPathExists:
    """Tests for the RemoveRedundantPathExists recipe."""

    def test_removes_exists_before_is_dir(self):
        """Test that p.exists() and p.is_dir() simplifies to p.is_dir()."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.exists() and p.is_dir():
                    do_sth()
                """,
                """
                if p.is_dir():
                    do_sth()
                """,
            )
        )

    def test_removes_exists_before_is_file(self):
        """Test that p.exists() and p.is_file() simplifies to p.is_file()."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.exists() and p.is_file():
                    do_sth()
                """,
                """
                if p.is_file():
                    do_sth()
                """,
            )
        )

    def test_removes_exists_after_is_dir(self):
        """Test that p.is_dir() and p.exists() simplifies to p.is_dir()."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.is_dir() and p.exists():
                    do_sth()
                """,
                """
                if p.is_dir():
                    do_sth()
                """,
            )
        )

    def test_no_change_different_targets(self):
        """Test that exists() and is_dir() on different targets are not simplified."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.exists() and q.is_dir():
                    do_sth()
                """
            )
        )

    def test_no_change_or_operator(self):
        """Test that 'or' expressions are not modified."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.exists() or p.is_dir():
                    do_sth()
                """
            )
        )

    def test_no_change_exists_alone(self):
        """Test that exists() alone is not modified."""
        spec = RecipeSpec(recipe=RemoveRedundantPathExists())
        spec.rewrite_run(
            python(
                """
                if p.exists():
                    do_sth()
                """
            )
        )
