"""Tests for pandas cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.pandas_cleanup import (
    DataframeAppendToConcat,
    PandasAvoidInplace,
    ReplaceApplyWithMethodCall,
    UseIsna,
)


class TestDataframeAppendToConcat:
    """Tests for the DataframeAppendToConcat recipe."""

    def test_replaces_append(self):
        """Test that df.append(other) is replaced with pd.concat([df, other])."""
        spec = RecipeSpec(recipe=DataframeAppendToConcat())
        spec.rewrite_run(
            python(
                """
                result = df.append(other)
                """,
                """
                result = pd.concat([df, other])
                """,
            )
        )

    def test_replaces_append_with_variable_names(self):
        """Test with different variable names."""
        spec = RecipeSpec(recipe=DataframeAppendToConcat())
        spec.rewrite_run(
            python(
                """
                combined = my_dataframe.append(new_rows)
                """,
                """
                combined = pd.concat([my_dataframe, new_rows])
                """,
            )
        )

    def test_no_change_no_append(self):
        """Test that non-append method calls are not changed."""
        spec = RecipeSpec(recipe=DataframeAppendToConcat())
        spec.rewrite_run(
            python(
                """
                result = df.merge(other)
                """
            )
        )

    def test_no_change_concat_already(self):
        """Test that pd.concat is not changed."""
        spec = RecipeSpec(recipe=DataframeAppendToConcat())
        spec.rewrite_run(
            python(
                """
                result = pd.concat([df, other])
                """
            )
        )


class TestPandasAvoidInplace:
    """Tests for PandasAvoidInplace: remove inplace=True and reassign."""

    def test_sort_values_inplace_with_arg(self):
        """Test df.sort_values('Language', inplace=True) -> df = df.sort_values('Language')."""
        spec = RecipeSpec(recipe=PandasAvoidInplace())
        spec.rewrite_run(
            python(
                'df.sort_values("Language", inplace=True)',
                'df = df.sort_values("Language")',
            )
        )

    def test_drop_inplace_with_arg(self):
        """Test df.drop(columns, inplace=True) -> df = df.drop(columns)."""
        spec = RecipeSpec(recipe=PandasAvoidInplace())
        spec.rewrite_run(
            python(
                'df.drop(columns, inplace=True)',
                'df = df.drop(columns)',
            )
        )

    def test_reset_index_inplace_only(self):
        """Test df.reset_index(inplace=True) -> df = df.reset_index()."""
        spec = RecipeSpec(recipe=PandasAvoidInplace())
        spec.rewrite_run(
            python(
                'df.reset_index(inplace=True)',
                'df = df.reset_index()',
            )
        )

    def test_no_change_without_inplace(self):
        """Test that calls without inplace=True are not changed."""
        spec = RecipeSpec(recipe=PandasAvoidInplace())
        spec.rewrite_run(
            python(
                'df.sort_values("Language")',
            )
        )

    def test_no_change_inplace_false(self):
        """Test that inplace=False is not changed."""
        spec = RecipeSpec(recipe=PandasAvoidInplace())
        spec.rewrite_run(
            python(
                'df.sort_values("Language", inplace=False)',
            )
        )


class TestReplaceApplyWithMethodCall:
    """Tests for ReplaceApplyWithMethodCall: df.apply('sum') -> df.sum()."""

    def test_apply_sum(self):
        """Test df.apply('sum') -> df.sum()."""
        spec = RecipeSpec(recipe=ReplaceApplyWithMethodCall())
        spec.rewrite_run(
            python(
                'result = df.apply("sum")',
                'result = df.sum()',
            )
        )

    def test_apply_mean(self):
        """Test df.apply('mean') -> df.mean()."""
        spec = RecipeSpec(recipe=ReplaceApplyWithMethodCall())
        spec.rewrite_run(
            python(
                "result = df.apply('mean')",
                "result = df.mean()",
            )
        )

    def test_no_change_apply_with_lambda(self):
        """Test that apply with a lambda is not changed."""
        spec = RecipeSpec(recipe=ReplaceApplyWithMethodCall())
        spec.rewrite_run(
            python(
                'result = df.apply(lambda x: x + 1)',
            )
        )

    def test_no_change_apply_with_function(self):
        """Test that apply with a function reference is not changed."""
        spec = RecipeSpec(recipe=ReplaceApplyWithMethodCall())
        spec.rewrite_run(
            python(
                'result = df.apply(my_func)',
            )
        )

    def test_no_change_non_apply(self):
        """Test that non-apply method calls are not changed."""
        spec = RecipeSpec(recipe=ReplaceApplyWithMethodCall())
        spec.rewrite_run(
            python(
                'result = df.map("sum")',
            )
        )


class TestUseIsna:
    """Tests for UseIsna: df['col'] == np.nan -> df['col'].isna()."""

    def test_np_nan_comparison(self):
        """Test x == np.nan -> x.isna()."""
        spec = RecipeSpec(recipe=UseIsna())
        spec.rewrite_run(
            python(
                "x == np.nan",
                "x.isna()",
            )
        )

    def test_numpy_nan_comparison(self):
        """Test x == numpy.nan -> x.isna()."""
        spec = RecipeSpec(recipe=UseIsna())
        spec.rewrite_run(
            python(
                "x == numpy.nan",
                "x.isna()",
            )
        )

    def test_no_change_regular_comparison(self):
        """Test that regular comparisons are not changed."""
        spec = RecipeSpec(recipe=UseIsna())
        spec.rewrite_run(
            python(
                "x == 0",
            )
        )

    def test_no_change_is_none(self):
        """Test that is None comparisons are not changed."""
        spec = RecipeSpec(recipe=UseIsna())
        spec.rewrite_run(
            python(
                "x is None",
            )
        )
