"""Tests for boolean simplification cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.boolean_simplification import (
    SimplifyBooleanComparison,
    BooleanIfExpIdentity,
    RemoveRedundantBoolean,
    DeMorgan,
    SimplifyEmptyCollectionComparison,
    SimplifyLenComparison,
    SimplifyStrLenComparison,
    CollectionToBool,
)


class TestSimplifyBooleanComparison:
    """Tests for the SimplifyBooleanComparison recipe."""

    def test_eq_true(self):
        """Test that `x == True` is simplified to `x`."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(
            python(
                "result = x == True",
                "result = x",
            )
        )

    def test_eq_false(self):
        """Test that `x == False` is simplified to `not x`."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(
            python(
                "result = x == False",
                "result = not x",
            )
        )

    def test_neq_true(self):
        """Test that `x != True` is simplified to `not x`."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(
            python(
                "result = x != True",
                "result = not x",
            )
        )

    def test_neq_false(self):
        """Test that `x != False` is simplified to `x`."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(
            python(
                "result = x != False",
                "result = x",
            )
        )

    def test_no_change_is_true(self):
        """``x is True`` is NOT simplified because ``is`` tests identity,
        not equality.  ``1 is True`` is False while ``1 == True`` is True."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x is True"))

    def test_no_change_is_false(self):
        """``x is False`` is NOT simplified because ``is`` tests identity."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x is False"))

    def test_no_change_is_not_true(self):
        """``x is not True`` is NOT simplified because ``is not`` tests identity."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x is not True"))

    def test_no_change_is_not_false(self):
        """``x is not False`` is NOT simplified because ``is not`` tests identity."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x is not False"))

    def test_no_change_non_boolean(self):
        """Test that comparisons with non-boolean values are not modified."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x == 1"))

    def test_no_change_is_none(self):
        """Test that `x is None` is not modified."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x is None"))

    def test_no_change_plain_comparison(self):
        """Test that `x == y` with non-boolean is not modified."""
        spec = RecipeSpec(recipe=SimplifyBooleanComparison())
        spec.rewrite_run(python("result = x == y"))


class TestBooleanIfExpIdentity:
    """Tests for the BooleanIfExpIdentity recipe."""

    def test_true_if_cond_else_false(self):
        """Test that `True if cond else False` is simplified to `bool(cond)`."""
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(
            python(
                "result = True if cond else False",
                "result = bool(cond)",
            )
        )

    def test_false_if_cond_else_true(self):
        """Test that `False if cond else True` is simplified to `not cond`."""
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(
            python(
                "result = False if cond else True",
                "result = not cond",
            )
        )

    def test_no_change_non_boolean_ternary(self):
        """Test that ternaries with non-boolean values are not modified."""
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(python("result = 1 if cond else 0"))

    def test_no_change_true_if_cond_else_true(self):
        """Test that `True if cond else True` is not modified (not identity pattern)."""
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(python("result = True if cond else True"))

    def test_no_change_false_if_cond_else_false(self):
        """Test that `False if cond else False` is not modified (not identity pattern)."""
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(python("result = False if cond else False"))

    def test_true_if_cond_else_false_preserves_bool_type(self):
        """True if cond else False should become bool(cond), not just cond.

        Replacing with bare `cond` changes the return type — cond may not
        be a bool.  Wrapping in bool() preserves the guaranteed bool type.
        """
        spec = RecipeSpec(recipe=BooleanIfExpIdentity())
        spec.rewrite_run(
            python(
                "result = True if check() else False",
                "result = bool(check())",
            )
        )


class TestRemoveRedundantBoolean:
    """Tests for the RemoveRedundantBoolean recipe."""

    def test_true_and_x(self):
        """Test that `True and x` is simplified to `x`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = True and x",
                "result = x",
            )
        )

    def test_x_and_true(self):
        """Test that `x and True` is simplified to `x`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = x and True",
                "result = x",
            )
        )

    def test_false_and_x(self):
        """Test that `False and x` is simplified to `False`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = False and x",
                "result = False",
            )
        )

    def test_x_and_false(self):
        """Test that `x and False` is simplified to `False`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = x and False",
                "result = False",
            )
        )

    def test_x_or_false(self):
        """Test that `x or False` is simplified to `x`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = x or False",
                "result = x",
            )
        )

    def test_false_or_x(self):
        """Test that `False or x` is simplified to `x`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = False or x",
                "result = x",
            )
        )

    def test_true_or_x(self):
        """Test that `True or x` is simplified to `True`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = True or x",
                "result = True",
            )
        )

    def test_x_or_true(self):
        """Test that `x or True` is simplified to `True`."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(
            python(
                "result = x or True",
                "result = True",
            )
        )

    def test_no_change_integer_and(self):
        """Test that `1 and x` is not modified (1 is not True literal)."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(python("result = 1 and x"))

    def test_no_change_integer_or(self):
        """Test that `0 or x` is not modified (0 is not False literal)."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(python("result = 0 or x"))

    def test_no_change_no_boolean(self):
        """Test that `x and y` is not modified when no boolean literal."""
        spec = RecipeSpec(recipe=RemoveRedundantBoolean())
        spec.rewrite_run(python("result = x and y"))


class TestDeMorgan:
    """Tests for the DeMorgan recipe."""

    def test_not_not(self):
        """Test that `not not p` is simplified to `p`."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not not p",
                "result = p",
            )
        )

    def test_not_eq_to_neq(self):
        """Test that `not (p == 1 and q == 2)` becomes `p != 1 or q != 2`."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (p == 1 and q == 2)",
                "result = p != 1 or q != 2",
            )
        )

    def test_not_or_to_and(self):
        """Test that `not (a or b)` becomes `not a and not b`."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (a or b)",
                "result = not a and not b",
            )
        )

    def test_no_change_simple_not(self):
        """Test that `not x` is not modified (not a double negation or DeMorgan pattern)."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(python("result = not x"))

    def test_not_and_with_or_operands(self):
        """Test that `not (a or b and c or d)` parenthesizes `or` operands under `not`."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (a and b)",
                "result = not a or not b",
            )
        )

    def test_not_or_with_and_operands(self):
        """Test that `not (a and b or c and d)` parenthesizes `or` result under `and`."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (a and b or c and d)",
                "result = not (a and b) and not (c and d)",
            )
        )

    def test_fused_not_not_and(self):
        """not (not x and not y) simplifies to x or y in one step."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (not x and not y)",
                "result = x or y",
            )
        )

    def test_fused_not_not_or(self):
        """not (not x or not y) simplifies to x and y in one step."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (not x or not y)",
                "result = x and y",
            )
        )

    def test_not_and_in_and_context(self):
        """not (x and y) inside `... and z` must parenthesize the or result.

        not (x and y) and z  →  (not x or not y) and z
        Without parens:         not x or not y and z  (WRONG precedence)
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (x and y) and z",
                "result = (not x or not y) and z",
            )
        )

    def test_not_and_in_rhs_and_context(self):
        """not (a and b) on the RHS of `and` must parenthesize the or result.

        x and not (a and b)  →  x and (not a or not b)
        Without parens:         x and not a or not b  (WRONG precedence)

        Real-world example from isort: `comment and not (config.use_parentheses
        and "noqa" in comment)` was incorrectly turned into
        `comment and not config.use_parentheses or not "noqa" in comment`.
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = x and not (a and b)",
                "result = x and (not a or not b)",
            )
        )

    def test_not_or_in_rhs_and_context(self):
        """not (a or b) on the RHS of `and` need not be parenthesized.

        x and not (a or b)  →  x and not a and not b
        The `and` result has the same precedence, so no parens needed.
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = x and not (a or b)",
                "result = x and not a and not b",
            )
        )

    def test_not_and_with_in_operator(self):
        """DeMorgan on `not (A and X in Y)` must negate `in` idiomatically.

        not (use_parens and "noqa" in comment)
            → not use_parens or "noqa" not in comment

        Real-world example from isort wrap.py.
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                'result = not (use_parens and "noqa" in comment)',
                'result = not use_parens or "noqa" not in comment',
            )
        )

    def test_not_or_with_in_operator(self):
        """DeMorgan on `not (A or X in Y)` flips `in` to `not in`.

        not (a or "x" in items)  →  not a and "x" not in items
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                'result = not (a or "x" in items)',
                'result = not a and "x" not in items',
            )
        )

    def test_not_and_with_not_in_operator(self):
        """DeMorgan on `not (A and X not in Y)` flips `not in` to `in`.

        not (flag and key not in d)  →  not flag or key in d
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (flag and key not in d)",
                "result = not flag or key in d",
            )
        )

    def test_not_and_with_is_operator(self):
        """DeMorgan on `not (A and X is Y)` flips `is` to `is not`.

        not (ready and val is None)  →  not ready or val is not None
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (ready and val is None)",
                "result = not ready or val is not None",
            )
        )

    def test_not_and_with_is_not_operator(self):
        """DeMorgan on `not (A and X is not Y)` flips `is not` to `is`.

        not (ok and val is not None)  →  not ok or val is None
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                "result = not (ok and val is not None)",
                "result = not ok or val is None",
            )
        )

    def test_not_and_both_in_operators(self):
        """DeMorgan with both operands as `in` expressions flips both.

        not ("a" in x and "b" in y)  →  "a" not in x or "b" not in y
        """
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(
            python(
                'result = not ("a" in x and "b" in y)',
                'result = "a" not in x or "b" not in y',
            )
        )

    def test_no_change_multiway_and(self):
        """not (a and b and c) should not be partially expanded."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(python("x = not (a and b and c)"))

    def test_no_change_multiway_or(self):
        """not (a or b or c) should not be partially expanded."""
        spec = RecipeSpec(recipe=DeMorgan())
        spec.rewrite_run(python("x = not (a or b or c)"))


class TestSimplifyEmptyCollectionComparison:
    """Tests for the SimplifyEmptyCollectionComparison recipe."""

    def test_eq_empty_string(self):
        """Test that `a == ""` is simplified to `not a`."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(
            python(
                'if a == "":\n    pass',
                'if not a:\n    pass',
            )
        )

    def test_neq_empty_string(self):
        """Test that `a != ""` is simplified to `a`."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(
            python(
                'if a != "":\n    pass',
                'if a:\n    pass',
            )
        )

    def test_eq_empty_list(self):
        """Test that `l == []` is simplified to `not l`."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(
            python(
                "if l == []:\n    pass",
                "if not l:\n    pass",
            )
        )

    def test_neq_empty_dict(self):
        """Test that `d != {}` is simplified to `d`."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(
            python(
                "if d != {}:\n    pass",
                "if d:\n    pass",
            )
        )

    def test_eq_empty_tuple(self):
        """Test that `t == ()` is simplified to `not t`."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(
            python(
                "if t == ():\n    pass",
                "if not t:\n    pass",
            )
        )

    def test_no_change_non_empty(self):
        """Test that `a == "hello"` is not modified."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(python('if a == "hello":\n    pass'))

    def test_no_change_non_collection(self):
        """Test that `a == 0` is not modified."""
        spec = RecipeSpec(recipe=SimplifyEmptyCollectionComparison())
        spec.rewrite_run(python("if a == 0:\n    pass"))


class TestSimplifyLenComparison:
    """Tests for the SimplifyLenComparison recipe."""

    def test_len_gt_0(self):
        """Test that `len(x) > 0` is simplified to `x`."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(
            python(
                "if len(x) > 0:\n    pass",
                "if x:\n    pass",
            )
        )

    def test_len_neq_0(self):
        """Test that `len(x) != 0` is simplified to `x`."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(
            python(
                "if len(x) != 0:\n    pass",
                "if x:\n    pass",
            )
        )

    def test_len_eq_0(self):
        """Test that `len(x) == 0` is simplified to `not x`."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(
            python(
                "if len(x) == 0:\n    pass",
                "if not x:\n    pass",
            )
        )

    def test_len_gte_1(self):
        """Test that `len(x) >= 1` is simplified to `x`."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(
            python(
                "if len(x) >= 1:\n    pass",
                "if x:\n    pass",
            )
        )

    def test_no_change_len_gt_1(self):
        """Test that `len(x) > 1` is not modified."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(python("if len(x) > 1:\n    pass"))

    def test_no_change_non_len(self):
        """Test that `foo(x) > 0` is not modified."""
        spec = RecipeSpec(recipe=SimplifyLenComparison())
        spec.rewrite_run(python("if foo(x) > 0:\n    pass"))


class TestSimplifyStrLenComparison:
    """Tests for the SimplifyStrLenComparison recipe."""

    def test_len_eq_0_to_eq_empty(self):
        """Test that `len(s) == 0` is simplified to `s == ""`."""
        spec = RecipeSpec(recipe=SimplifyStrLenComparison())
        spec.rewrite_run(
            python(
                'if len(s) == 0:\n    pass',
                'if s == "":\n    pass',
            )
        )

    def test_len_gt_0_to_neq_empty(self):
        """Test that `len(s) > 0` is simplified to `s != ""`."""
        spec = RecipeSpec(recipe=SimplifyStrLenComparison())
        spec.rewrite_run(
            python(
                'if len(s) > 0:\n    pass',
                'if s != "":\n    pass',
            )
        )

    def test_len_neq_0_to_neq_empty(self):
        """Test that `len(s) != 0` is simplified to `s != ""`."""
        spec = RecipeSpec(recipe=SimplifyStrLenComparison())
        spec.rewrite_run(
            python(
                'if len(s) != 0:\n    pass',
                'if s != "":\n    pass',
            )
        )

    def test_no_change_len_gt_1(self):
        """Test that `len(s) > 1` is not modified."""
        spec = RecipeSpec(recipe=SimplifyStrLenComparison())
        spec.rewrite_run(python("if len(s) > 1:\n    pass"))


class TestCollectionToBool:
    """Tests for the CollectionToBool recipe."""

    def test_non_empty_tuple_to_true(self):
        """Test that `if ("foo", "bar"):` becomes `if True:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                'if ("foo", "bar"):\n    pass',
                'if True:\n    pass',
            )
        )

    def test_empty_list_to_false(self):
        """Test that `if []:` becomes `if False:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                "if []:\n    pass",
                "if False:\n    pass",
            )
        )

    def test_empty_dict_to_false(self):
        """Test that `if {}:` becomes `if False:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                "if {}:\n    pass",
                "if False:\n    pass",
            )
        )

    def test_empty_tuple_to_false(self):
        """Test that `if ():` becomes `if False:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                "if ():\n    pass",
                "if False:\n    pass",
            )
        )

    def test_non_empty_list_to_true(self):
        """Test that `if [1, 2]:` becomes `if True:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                "if [1, 2]:\n    pass",
                "if True:\n    pass",
            )
        )

    def test_no_change_variable_condition(self):
        """Test that `if x:` is not modified."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(python("if x:\n    pass"))

    def test_while_empty_list(self):
        """Test that `while []:` becomes `while False:`."""
        spec = RecipeSpec(recipe=CollectionToBool())
        spec.rewrite_run(
            python(
                "while []:\n    pass",
                "while False:\n    pass",
            )
        )
