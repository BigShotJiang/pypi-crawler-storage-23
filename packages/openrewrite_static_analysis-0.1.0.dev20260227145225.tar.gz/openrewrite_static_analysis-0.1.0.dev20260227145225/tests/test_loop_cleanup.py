"""Tests for loop cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.loop_cleanup import (
    UseFileIterator,
    UselessElseOnLoop,
    YieldFrom,
)


class TestUseFileIterator:
    """Tests for the UseFileIterator recipe."""

    def test_removes_readlines_in_for(self):
        """Test that f.readlines() is replaced with f in a for loop."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                for line in f.readlines():
                    print(line)
                """,
                """
                for line in f:
                    print(line)
                """,
            )
        )

    def test_removes_readlines_with_open(self):
        """Test that open(...).readlines() is replaced with open(...)."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                for line in open("file.txt").readlines():
                    print(line)
                """,
                """
                for line in open("file.txt"):
                    print(line)
                """,
            )
        )

    def test_no_change_for_readline(self):
        """Test that readline() (singular) is not changed."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                line = f.readline()
                """
            )
        )

    def test_no_change_for_read(self):
        """Test that read() is not changed."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                content = f.read()
                """
            )
        )

    def test_applies_to_any_readlines(self):
        """Test that readlines is simplified on any object (pattern is generic)."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                for line in my_buffer.readlines():
                    process(line)
                """,
                """
                for line in my_buffer:
                    process(line)
                """,
            )
        )

    def test_no_change_readlines_in_assignment(self):
        """Test that f.readlines() is NOT removed when assigned to a variable."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                lines = f.readlines()
                """
            )
        )

    def test_no_change_readlines_with_slicing(self):
        """Test that f.readlines()[-5:] is NOT simplified."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                last_five = handle.readlines()[-5:]
                """
            )
        )

    def test_no_change_readlines_in_list_comp(self):
        """Test that readlines() inside a list comprehension is NOT simplified."""
        spec = RecipeSpec(recipe=UseFileIterator())
        spec.rewrite_run(
            python(
                """
                stripped = [line.strip() for line in f.readlines()]
                """
            )
        )


class TestUselessElseOnLoop:
    """Tests for the UselessElseOnLoop recipe."""

    def test_removes_else_from_for_without_break(self):
        """Test that else is moved after loop when there is no break."""
        spec = RecipeSpec(recipe=UselessElseOnLoop())
        spec.rewrite_run(
            python(
                """
                for n in numbers:
                    if n % 2:
                        evens.append(n)
                else:
                    print("Done!")
                """,
                """
                for n in numbers:
                    if n % 2:
                        evens.append(n)
                print("Done!")
                """,
            )
        )

    def test_no_change_when_break_present(self):
        """Test that else is kept when loop body contains break."""
        spec = RecipeSpec(recipe=UselessElseOnLoop())
        spec.rewrite_run(
            python(
                """
                for n in numbers:
                    if n == target:
                        break
                else:
                    print("Not found")
                """,
            )
        )

    def test_removes_else_simple_loop(self):
        """Test else removal from simple for loop with no break."""
        spec = RecipeSpec(recipe=UselessElseOnLoop())
        spec.rewrite_run(
            python(
                "for x in items:\n    process(x)\nelse:\n    done()",
                "for x in items:\n    process(x)\ndone()",
            )
        )

    def test_removes_else_when_break_in_nested_function(self):
        """Test that break inside nested function doesn't prevent else removal."""
        spec = RecipeSpec(recipe=UselessElseOnLoop())
        spec.rewrite_run(
            python(
                """
                for n in numbers:
                    def inner():
                        break
                    evens.append(n)
                else:
                    print("Done!")
                """,
                """
                for n in numbers:
                    def inner():
                        break
                    evens.append(n)
                print("Done!")
                """,
            )
        )


class TestYieldFrom:
    """Tests for the YieldFrom recipe."""

    def test_replaces_yield_in_for_with_yield_from(self):
        """Test that yield in for loop is replaced with yield from."""
        spec = RecipeSpec(recipe=YieldFrom())
        spec.rewrite_run(
            python(
                """
                def get_content(entry):
                    for block in entry.get_blocks():
                        yield block
                """,
                """
                def get_content(entry):
                    yield from entry.get_blocks()
                """,
            )
        )

    def test_no_change_when_yield_value_differs(self):
        """Test that yield of non-loop-variable is not changed."""
        spec = RecipeSpec(recipe=YieldFrom())
        spec.rewrite_run(
            python(
                """
                def get_content(entry):
                    for block in entry.get_blocks():
                        yield block.text
                """,
            )
        )

    def test_no_change_when_body_has_multiple_statements(self):
        """Test that for loop with multiple statements is not changed."""
        spec = RecipeSpec(recipe=YieldFrom())
        spec.rewrite_run(
            python(
                """
                def get_content(entry):
                    for block in entry.get_blocks():
                        process(block)
                        yield block
                """,
            )
        )

    def test_no_change_in_async_function(self):
        """Test that yield from is not used inside async def (SyntaxError)."""
        spec = RecipeSpec(recipe=YieldFrom())
        spec.rewrite_run(
            python(
                """
                async def get_content(entry):
                    for block in entry.get_blocks():
                        yield block
                """,
            )
        )

    def test_no_change_when_loop_var_used_after_loop(self):
        """Don't convert to yield from when loop variable is referenced after the loop.

        In `for item in it: yield item` followed by code using `item`,
        the loop variable retains the last yielded value. Converting to
        `yield from` loses that binding — `item` keeps its pre-loop value.
        """
        spec = RecipeSpec(recipe=YieldFrom())
        spec.rewrite_run(
            python(
                """
                def padded(iterable, default):
                    item = _marker
                    for item in iterable:
                        yield item
                    final = default if item is _marker else item
                    yield from repeat(final)
                """,
            )
        )
