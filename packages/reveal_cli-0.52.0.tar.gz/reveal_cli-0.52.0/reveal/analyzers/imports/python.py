"""Python import extraction using tree-sitter.

Previous implementation: Tree-sitter + 2 regex patterns for parsing
Current implementation: Pure tree-sitter AST extraction

Benefits:
- Eliminates regex patterns (from-import parsing, __all__ string extraction)
- Uses tree-sitter node types (relative_import, import_prefix, string nodes)
- More robust handling of edge cases

Extracts import statements and symbol usage from Python source files.
Uses tree-sitter for consistent parsing across all language analyzers.
"""

import os
from pathlib import Path
from typing import List, Set, Optional, Dict, Tuple

from .types import ImportStatement
from .base import LanguageExtractor, register_extractor
from .resolver import resolve_python_import
from ...registry import get_analyzer

# Module-level cache for extract_imports results keyed by (file_path_str, mtime_ns).
# I002 builds an import graph by calling extract_imports on every file in a directory,
# often visiting the same files multiple times across different graph builds.
# I001 also calls extract_imports for each checked file independently.
# Caching avoids redundant parses + file reads across both rules and repeated builds.
_extract_imports_cache: Dict[Tuple[str, int], List[ImportStatement]] = {}


@register_extractor
class PythonExtractor(LanguageExtractor):
    """Python import extractor using tree-sitter parsing.

    Supports:
    - import os, sys
    - from x import y, z
    - from . import relative
    - from x import *
    - import numpy as np
    """

    extensions = {'.py', '.pyi'}
    language_name = 'Python'

    def extract_imports(self, file_path: Path) -> List[ImportStatement]:
        """Extract all import statements from Python file using tree-sitter.

        Results are cached by (file_path, mtime_ns) so I002's graph builder and
        I001's per-file check share results without re-parsing.

        Args:
            file_path: Path to Python source file

        Returns:
            List of ImportStatement objects
        """
        path_str = os.path.abspath(str(file_path))
        try:
            mtime_ns = os.stat(path_str).st_mtime_ns
        except OSError:
            mtime_ns = 0
        cache_key = (path_str, mtime_ns)
        if cache_key in _extract_imports_cache:
            return _extract_imports_cache[cache_key]

        analyzer = self._get_tree_analyzer(path_str)
        if not analyzer:
            _extract_imports_cache[cache_key] = []
            return []

        # Read source lines for noqa comment detection
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                source_lines = f.readlines()
        except Exception:  # noqa: BLE001
            source_lines = []

        imports = []
        for node in analyzer._find_nodes_by_type('import_statement'):
            imports.extend(self._parse_import_statement(node, file_path, analyzer, source_lines))
        for node in analyzer._find_nodes_by_type('import_from_statement'):
            imports.extend(self._parse_from_import(node, file_path, analyzer, source_lines))

        _extract_imports_cache[cache_key] = imports
        return imports

    def _get_tree_analyzer(self, path_str: str):
        """Get a tree-sitter analyzer instance for *path_str*, or None if parse fails."""
        try:
            analyzer_class = get_analyzer(path_str)
            if not analyzer_class:
                return None
            analyzer = analyzer_class(path_str)
            return analyzer if analyzer.tree else None
        except Exception:  # noqa: BLE001
            return None

    def _is_inside_type_checking(self, node) -> bool:
        """Check if import node is inside a TYPE_CHECKING conditional block.

        Walks up the AST to detect patterns like:
            if TYPE_CHECKING:
                from typing import SomeType

        Returns:
            True if import is inside TYPE_CHECKING block
        """
        current = node.parent
        while current:
            # Check if this is an 'if' statement
            if current.type == 'if_statement':
                # Get the condition node (first child after 'if')
                if current.children and len(current.children) > 1:
                    condition = current.children[1]  # Skip 'if' keyword
                    # Check if condition contains 'TYPE_CHECKING'
                    # This handles: TYPE_CHECKING, typing.TYPE_CHECKING, etc.
                    condition_text = self._get_node_text_from_tree(condition, current)
                    if 'TYPE_CHECKING' in condition_text:
                        return True
            current = current.parent
        return False

    def _get_node_text_from_tree(self, node, analyzer_or_tree) -> str:
        """Helper to get node text when we have a tree reference."""
        if hasattr(analyzer_or_tree, '_get_node_text'):
            return str(analyzer_or_tree._get_node_text(node))
        # Fallback: decode bytes
        if hasattr(node, 'text'):
            return str(node.text.decode('utf-8'))
        return ""

    def _parse_import_statement(self, node, file_path: Path, analyzer, source_lines: List[str]) -> List[ImportStatement]:
        """Parse 'import x, y as z' statements."""
        imports = []

        # Detect TYPE_CHECKING context
        is_type_checking = self._is_inside_type_checking(node)

        # Get source line (0-indexed -> 1-indexed)
        line_number = node.start_point[0] + 1
        source_line = source_lines[node.start_point[0]].rstrip() if node.start_point[0] < len(source_lines) else ""

        # Get full import text for parsing
        import_text = analyzer._get_node_text(node)

        # Extract module names and aliases
        # Pattern: import os, sys as s, pathlib
        # Remove 'import ' prefix
        modules_text = import_text[7:].strip() if import_text.startswith('import ') else import_text

        # Split by comma, handle aliases
        for module_part in modules_text.split(','):
            module_part = module_part.strip()
            if not module_part:
                continue

            # Check for alias (import numpy as np)
            if ' as ' in module_part:
                module_name, alias = module_part.split(' as ', 1)
                module_name = module_name.strip()
                alias = alias.strip()
            else:
                module_name = module_part
                alias = None

            imports.append(ImportStatement(
                file_path=file_path,
                line_number=line_number,
                module_name=module_name,
                imported_names=[],
                is_relative=False,
                import_type='import',
                alias=alias,
                is_type_checking=is_type_checking,
                source_line=source_line
            ))

        return imports

    def _extract_from_module_name(self, node, analyzer) -> tuple:
        """Extract module name and relative flag from 'from' import node.

        Returns:
            Tuple of (module_name, is_relative)
        """
        is_relative = False
        module_name = ''

        for child in node.children:
            if child.type == 'relative_import':
                # Relative import: from . import x, from ..parent import y
                is_relative = True
                for subchild in child.children:
                    if subchild.type == 'dotted_name':
                        module_name = analyzer._get_node_text(subchild)
            elif (child.type == 'dotted_name' and child.prev_sibling and
                  analyzer._get_node_text(child.prev_sibling) == 'from'):
                # Absolute import: from pathlib import Path
                module_name = analyzer._get_node_text(child)
                break

        return module_name, is_relative

    def _parse_imported_names(self, node, analyzer) -> tuple:
        """Parse imported names and determine import type.

        Returns:
            Tuple of (imported_names, import_type)
        """
        imported_names = []
        import_type = 'from_import'
        seen_import_keyword = False

        for child in node.children:
            # Wait until we see the 'import' keyword
            if child.type == 'import':
                seen_import_keyword = True
                continue

            if not seen_import_keyword:
                continue

            # Skip commas and parentheses
            if child.type in [',', '(', ')']:
                continue

            # Wildcard import: from x import *
            if child.type == 'wildcard_import' or analyzer._get_node_text(child) == '*':
                return ['*'], 'star_import'

            # Regular imports: from x import Name or from x import Name as Alias
            if child.type == 'dotted_name':
                imported_names.append(analyzer._get_node_text(child))
            elif child.type == 'aliased_import':
                imported_names.append(analyzer._get_node_text(child))

        return imported_names, import_type

    def _parse_from_import(self, node, file_path: Path, analyzer, source_lines: List[str]) -> List[ImportStatement]:
        """Parse 'from x import y' statements."""
        # Detect TYPE_CHECKING context
        is_type_checking = self._is_inside_type_checking(node)

        # Get source line (0-indexed -> 1-indexed)
        line_number = node.start_point[0] + 1
        source_line = source_lines[node.start_point[0]].rstrip() if node.start_point[0] < len(source_lines) else ""

        # Extract module name and imported names
        module_name, is_relative = self._extract_from_module_name(node, analyzer)
        imported_names, import_type = self._parse_imported_names(node, analyzer)

        return [ImportStatement(
            file_path=file_path,
            line_number=line_number,
            module_name=module_name,
            imported_names=imported_names,
            is_relative=is_relative,
            import_type=import_type,
            alias=None,  # from imports don't have module-level aliases
            is_type_checking=is_type_checking,
            source_line=source_line
        )]

    def extract_symbols(self, file_path: Path) -> Set[str]:
        """Extract all symbol references (names used in code).

        Args:
            file_path: Path to Python source file

        Returns:
            Set of symbol names referenced in the file

        Used for detecting unused imports by comparing imported names
        with actually-used symbols.
        """
        try:
            analyzer_class = get_analyzer(str(file_path))
            if not analyzer_class:
                return set()

            analyzer = analyzer_class(str(file_path))
            if not analyzer.tree:
                return set()

        except Exception:
            return set()

        symbols = set()

        # Find identifier nodes (tree-sitter node type for names)
        identifier_nodes = analyzer._find_nodes_by_type('identifier')

        for node in identifier_nodes:
            # Extract the identifier text
            name = analyzer._get_node_text(node)

            # Filter out identifiers in assignment/definition contexts
            # We want to track usage, not definitions
            if self._is_usage_context(node):
                symbols.add(name)

            # Also handle attribute access (os.path -> track 'os')
            if node.parent and node.parent.type == 'attribute':
                # Get root of attribute chain
                root = self._get_root_identifier(node.parent, analyzer)
                if root:
                    symbols.add(root)

        return symbols

    def _is_usage_context(self, node) -> bool:
        """Check if identifier node is in a usage context (not definition).

        Filters out:
        - Function/class definitions
        - Parameter names
        - Assignment targets
        - Import names
        """
        if not node.parent:
            return True

        parent_type = node.parent.type

        # Fast path: common definition/import contexts at immediate parent level.
        # import_from_name covers `from x import NAME` identifiers;
        # dotted_name covers module path identifiers; aliased_import covers aliases.
        if parent_type in ('function_definition', 'class_definition', 'parameters',
                           'dotted_name', 'aliased_import', 'import_from_name'):
            return False

        # Check for import statement ancestor. Import identifiers are at most
        # 2-3 levels below their containing import_statement, so bound the walk.
        current = node.parent
        for _ in range(3):
            if current.type in ('import_statement', 'import_from_statement'):
                return False
            current = current.parent
            if current is None:
                break

        # For assignments and keyword args, only filter the target/key (left side),
        # not the value (right side) which is a genuine usage context.
        if parent_type in ('assignment', 'keyword_argument'):
            if node.parent.children and node.parent.children[0] == node:
                return False

        return True

    def _get_root_identifier(self, attribute_node, analyzer) -> Optional[str]:
        """Extract root identifier from attribute chain.

        Examples:
            os.path.join -> 'os'
            sys.argv -> 'sys'
        """
        # Walk up the attribute chain to find the root
        current = attribute_node
        while current and current.type == 'attribute':
            # Attribute nodes have structure: object.attribute
            if current.children:
                current = current.children[0]
            else:
                break

        # Current should now be an identifier
        if current and current.type == 'identifier':
            result = analyzer._get_node_text(current)
            return str(result) if result is not None else None

        return None

    def extract_exports(self, file_path: Path) -> Set[str]:
        """Extract names from __all__ declaration.

        Args:
            file_path: Path to Python source file

        Returns:
            Set of names declared in __all__ (empty if no __all__ found)

        Used to detect re-exports - imports that appear in __all__
        are intentionally exposed and should not be flagged as unused.
        """
        analyzer = self._get_tree_analyzer(str(file_path))
        if not analyzer:
            return set()

        exports: Set[str] = set()

        # Find __all__ = [...] and __all__ += [...] assignments
        for node in analyzer._find_nodes_by_type('assignment'):
            if analyzer._get_node_text(node).strip().startswith('__all__'):
                exports.update(self._extract_string_literals(node, analyzer))

        # Also find __all__.append('X') and __all__.extend([...]) call patterns
        for node in analyzer._find_nodes_by_type('call'):
            call_text = analyzer._get_node_text(node)
            if call_text.startswith('__all__.append(') or call_text.startswith('__all__.extend('):
                exports.update(self._extract_string_literals(node, analyzer))

        return exports

    def _extract_string_literals(self, node, analyzer) -> List[str]:
        """Recursively extract string content from AST nodes."""
        strings = []
        if node.type == 'string':
            text = analyzer._get_node_text(node).strip('"\'')
            strings.append(text)
        for child in node.children:
            strings.extend(self._extract_string_literals(child, analyzer))
        return strings

    def resolve_import(
        self,
        stmt: ImportStatement,
        base_path: Path
    ) -> Optional[Path]:
        """Resolve Python import statement to file path.

        Args:
            stmt: Import statement to resolve
            base_path: Directory of the file containing the import

        Returns:
            Absolute path to the imported file, or None if not resolvable
        """
        return resolve_python_import(stmt, base_path)


# Backward compatibility: Keep old function-based API
def extract_python_imports(file_path: Path) -> List[ImportStatement]:
    """Extract all import statements from Python file.

    DEPRECATED: Use PythonExtractor().extract_imports() instead.
    Kept for backward compatibility with existing code.
    """
    extractor = PythonExtractor()
    return extractor.extract_imports(file_path)


def extract_python_symbols(file_path: Path) -> Set[str]:
    """Extract all symbol references from Python file.

    DEPRECATED: Use PythonExtractor().extract_symbols() instead.
    Kept for backward compatibility with existing code.
    """
    extractor = PythonExtractor()
    return extractor.extract_symbols(file_path)


__all__ = [
    'PythonExtractor',
    'extract_python_imports',  # deprecated
    'extract_python_symbols',  # deprecated
]
