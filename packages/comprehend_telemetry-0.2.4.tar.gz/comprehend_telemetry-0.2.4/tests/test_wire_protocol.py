"""Tests for wire protocol V2 type definitions."""

import json
from comprehend_telemetry.wire_protocol import (
    # Time utilities
    hrtime_to_tuple, tuple_to_hrtime, hrtime_now,

    # Message types
    InitMessage,
    StartProcessContextMessage,
    EndContextMessage,
    NewObservedServiceMessage,
    NewObservedHttpRouteMessage,
    NewObservedDatabaseMessage,
    NewObservedHttpServiceMessage,
    NewObservedHttpRequestMessage,
    NewObservedDatabaseConnectionMessage,
    HttpClientObservation,
    HttpServerObservation,
    CustomObservation,
    ObservationMessage,
    TimeSeriesMetricsMessage,
    TimeSeriesDataPoint,
    CumulativeMetricsMessage,
    CumulativeDataPoint,
    TraceSpansMessage,
    TraceSpan,
    DatabaseQueryMessage,
    InitAck,
    ObservedAck,
    ObservationsAck,
    ContextAck,
    TimeSeriesMetricsAck,
    CumulativeMetricsAck,
    TraceSpansAck,
    DatabaseQueryAck,
    CustomMetricChange,
    CustomCumulativeMetricSpecification,
    CustomTimeSeriesMetricSpecification,
    CustomSpanObservationSpecification,
    SpanMatcherRule,

    # Serialization
    serialize_message,
    deserialize_message,
    parse_custom_metric_spec,
    parse_span_matcher_rule,
)


class TestTimeUtilities:
    def test_hrtime_conversion_roundtrip(self):
        ns_time = 1754411344309532945
        time_tuple = hrtime_to_tuple(ns_time)
        assert time_tuple == [1754411344, 309532945]
        converted_back = tuple_to_hrtime(time_tuple)
        assert converted_back == ns_time

    def test_hrtime_zero(self):
        assert hrtime_to_tuple(0) == [0, 0]
        assert tuple_to_hrtime([0, 0]) == 0

    def test_hrtime_now(self):
        result = hrtime_now()
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] > 0


class TestMessageTypes:
    def test_init_message_v2(self):
        msg = InitMessage(token="test-token")
        assert msg.event == "init"
        assert msg.protocolVersion == 2
        assert msg.token == "test-token"

    def test_init_ack_with_custom_metrics(self):
        ack = InitAck(customMetrics=[{"type": "cumulative", "id": "test"}])
        assert ack.type == "ack-authorized"
        assert len(ack.customMetrics) == 1

    def test_start_process_context(self):
        msg = StartProcessContextMessage(
            seq=1,
            timestamp=1000000000,
            ingestionId="test-uuid",
            serviceEntityHash="hash123",
            resources={"service.name": "test"}
        )
        assert msg.event == "context-start"
        assert msg.type == "process"
        assert msg.seq == 1
        assert msg.ingestionId == "test-uuid"
        assert msg.serviceEntityHash == "hash123"

    def test_end_context(self):
        msg = EndContextMessage(seq=2, timestamp=2000000000, ingestionId="test-uuid")
        assert msg.event == "context-end"
        assert msg.seq == 2

    def test_context_ack(self):
        ack = ContextAck(seq=1)
        assert ack.type == "ack-context"
        assert ack.seq == 1

    def test_service_message(self):
        msg = NewObservedServiceMessage(
            hash="service-hash", name="my-service",
            namespace="prod", environment="production"
        )
        assert msg.event == "new-entity"
        assert msg.type == "service"

    def test_http_route_message(self):
        msg = NewObservedHttpRouteMessage(
            hash="route-hash", parent="service-hash",
            method="GET", route="/api/users/{id}"
        )
        assert msg.event == "new-entity"
        assert msg.type == "http-route"

    def test_database_message(self):
        msg = NewObservedDatabaseMessage(
            hash="db-hash", system="postgresql",
            name="mydb", host="localhost", port=5432
        )
        assert msg.event == "new-entity"
        assert msg.type == "database"

    def test_http_service_message(self):
        msg = NewObservedHttpServiceMessage(
            hash="http-service-hash", protocol="https",
            host="api.example.com", port=443
        )
        assert msg.event == "new-entity"
        assert msg.type == "http-service"

    def test_http_request_interaction(self):
        msg = NewObservedHttpRequestMessage(
            hash="request-hash", from_="client-hash", to="server-hash"
        )
        assert msg.event == "new-interaction"
        assert msg.type == "http-request"
        assert msg.from_ == "client-hash"

    def test_database_connection_interaction(self):
        msg = NewObservedDatabaseConnectionMessage(
            hash="conn-hash", from_="service-hash", to="db-hash",
            connection="connection-1", user="dbuser"
        )
        assert msg.event == "new-interaction"
        assert msg.type == "db-connection"


class TestObservations:
    def test_http_client_observation_with_span_context(self):
        obs = HttpClientObservation(
            subject="request-hash",
            spanId="abc123",
            traceId="def456",
            timestamp=1754411344309532945,
            path="/api/users",
            method="GET",
            duration=150000000,
            status=200,
        )
        assert obs.type == "http-client"
        assert obs.spanId == "abc123"
        assert obs.traceId == "def456"

    def test_http_server_observation_with_span_context(self):
        obs = HttpServerObservation(
            subject="route-hash",
            spanId="abc123",
            traceId="def456",
            timestamp=1754411344309532945,
            path="/api/users",
            status=200,
            duration=50000000,
        )
        assert obs.type == "http-server"
        assert obs.spanId == "abc123"
        assert obs.traceId == "def456"

    def test_custom_observation(self):
        obs = CustomObservation(
            subject="custom-subject",
            id="custom-id",
            spanId="span1",
            traceId="trace1",
            timestamp=1000000000,
            attributes={"key": "value", "count": 42},
        )
        assert obs.type == "custom"
        assert obs.id == "custom-id"
        assert obs.attributes["key"] == "value"

    def test_observation_message(self):
        obs = HttpClientObservation(
            subject="hash1", timestamp=123, path="/test", method="GET", duration=100
        )
        msg = ObservationMessage(seq=1, observations=[obs])
        assert msg.event == "observations"
        assert msg.seq == 1
        assert len(msg.observations) == 1

    def test_observation_message_default_list(self):
        msg = ObservationMessage(seq=1)
        assert msg.observations == []


class TestMetricsMessages:
    def test_timeseries_message(self):
        msg = TimeSeriesMetricsMessage(
            seq=1,
            data=[TimeSeriesDataPoint(
                subject="hash1", type="process.cpu.utilization",
                timestamp=1000000000, value=0.5, unit="1",
                attributes={"pid": "1234"}
            )]
        )
        assert msg.event == "timeseries"
        assert len(msg.data) == 1
        assert msg.data[0].value == 0.5

    def test_cumulative_message(self):
        msg = CumulativeMetricsMessage(
            seq=2,
            data=[CumulativeDataPoint(
                subject="hash1", type="process.cpu.time",
                timestamp=1000000000, value=100.5, unit="s",
                attributes={}
            )]
        )
        assert msg.event == "cumulative"
        assert len(msg.data) == 1

    def test_timeseries_ack(self):
        ack = TimeSeriesMetricsAck(seq=1)
        assert ack.type == "ack-timeseries"

    def test_cumulative_ack(self):
        ack = CumulativeMetricsAck(seq=2)
        assert ack.type == "ack-cumulative"


class TestTraceSpansMessages:
    def test_trace_spans_message(self):
        msg = TraceSpansMessage(
            seq=1,
            data=[TraceSpan(
                trace="trace-id", span="span-id",
                parent="parent-id", name="test-span",
                timestamp=1000000000
            )]
        )
        assert msg.event == "tracespans"
        assert len(msg.data) == 1
        assert msg.data[0].trace == "trace-id"
        assert msg.data[0].parent == "parent-id"

    def test_trace_spans_ack(self):
        ack = TraceSpansAck(seq=1)
        assert ack.type == "ack-tracespans"


class TestDatabaseQueryMessage:
    def test_database_query_message(self):
        msg = DatabaseQueryMessage(
            seq=1, query="SELECT * FROM users",
            from_="service-hash", to="db-hash",
            timestamp=1000000000, duration=50000000,
            traceId="trace1", spanId="span1",
            returnedRows=10
        )
        assert msg.event == "db-query"
        assert msg.query == "SELECT * FROM users"
        assert msg.traceId == "trace1"
        assert msg.spanId == "span1"

    def test_database_query_ack(self):
        ack = DatabaseQueryAck(seq=1)
        assert ack.type == "ack-db-query"


class TestCustomMetrics:
    def test_custom_metric_change(self):
        msg = CustomMetricChange(customMetrics=[])
        assert msg.type == "custom-metric-change"

    def test_custom_cumulative_spec(self):
        spec = CustomCumulativeMetricSpecification(
            id="my.metric", attributes=["host"], subject="hash1"
        )
        assert spec.type == "cumulative"
        assert spec.id == "my.metric"

    def test_custom_timeseries_spec(self):
        spec = CustomTimeSeriesMetricSpecification(
            id="my.gauge", attributes=["env"], subject="hash2"
        )
        assert spec.type == "timeseries"

    def test_custom_span_observation_spec(self):
        rule = SpanMatcherRule(kind="type", value="server")
        spec = CustomSpanObservationSpecification(
            rule=rule, subject="hash3"
        )
        assert spec.type == "span"
        assert spec.rule.kind == "type"

    def test_parse_custom_metric_spec_cumulative(self):
        raw = {"type": "cumulative", "id": "test.metric", "attributes": ["a"], "subject": "h1"}
        spec = parse_custom_metric_spec(raw)
        assert isinstance(spec, CustomCumulativeMetricSpecification)
        assert spec.id == "test.metric"

    def test_parse_custom_metric_spec_timeseries(self):
        raw = {"type": "timeseries", "id": "test.gauge", "attributes": [], "subject": "h2"}
        spec = parse_custom_metric_spec(raw)
        assert isinstance(spec, CustomTimeSeriesMetricSpecification)

    def test_parse_custom_metric_spec_span(self):
        raw = {
            "type": "span",
            "subject": "h3",
            "rule": {"kind": "attribute-equals", "key": "http.method", "value": "GET"}
        }
        spec = parse_custom_metric_spec(raw)
        assert isinstance(spec, CustomSpanObservationSpecification)
        assert spec.rule.kind == "attribute-equals"
        assert spec.rule.key == "http.method"

    def test_parse_span_matcher_rule_nested(self):
        raw = {
            "kind": "all",
            "rules": [
                {"kind": "type", "value": "server"},
                {"kind": "attribute-present", "key": "http.route"}
            ]
        }
        rule = parse_span_matcher_rule(raw)
        assert rule.kind == "all"
        assert len(rule.rules) == 2
        assert rule.rules[0].kind == "type"
        assert rule.rules[1].kind == "attribute-present"


class TestSerialization:
    def test_serialize_init_message_v2(self):
        msg = InitMessage(token="secret-token")
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["event"] == "init"
        assert data["protocolVersion"] == 2
        assert data["token"] == "secret-token"

    def test_serialize_interaction_from_field(self):
        msg = NewObservedHttpRequestMessage(
            hash="req-hash", from_="client-hash", to="server-hash"
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["from"] == "client-hash"
        assert "from_" not in data

    def test_serialize_observation_with_time_conversion(self):
        obs = HttpClientObservation(
            subject="req-hash",
            spanId="span1",
            traceId="trace1",
            timestamp=1754411344309532945,
            path="/api/test",
            method="POST",
            duration=150000000
        )
        msg = ObservationMessage(seq=1, observations=[obs])
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        obs_data = data["observations"][0]
        assert obs_data["timestamp"] == [1754411344, 309532945]
        assert obs_data["duration"] == [0, 150000000]
        assert obs_data["spanId"] == "span1"
        assert obs_data["traceId"] == "trace1"

    def test_serialize_timeseries_message(self):
        msg = TimeSeriesMetricsMessage(
            seq=1,
            data=[TimeSeriesDataPoint(
                subject="hash1", type="process.cpu.utilization",
                timestamp=1000000000000000000, value=0.5, unit="1",
                attributes={"pid": "1234"}
            )]
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["event"] == "timeseries"
        assert data["data"][0]["type"] == "process.cpu.utilization"
        assert data["data"][0]["attributes"] == {"pid": "1234"}

    def test_serialize_trace_spans_message(self):
        msg = TraceSpansMessage(
            seq=1,
            data=[TraceSpan(
                trace="t1", span="s1", parent="p1",
                name="test", timestamp=1000000000000000000
            )]
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["event"] == "tracespans"
        assert data["data"][0]["trace"] == "t1"
        assert data["data"][0]["parent"] == "p1"

    def test_serialize_db_query_message(self):
        msg = DatabaseQueryMessage(
            seq=1, query="SELECT 1", from_="svc", to="db",
            timestamp=1000000000, duration=50000000,
            traceId="t1", spanId="s1"
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["event"] == "db-query"
        assert data["from"] == "svc"
        assert data["traceId"] == "t1"

    def test_serialize_context_message(self):
        msg = StartProcessContextMessage(
            seq=1, timestamp=1000000000000000000,
            ingestionId="uuid", serviceEntityHash="hash",
            resources={"service.name": "test"}
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert data["event"] == "context-start"
        assert data["type"] == "process"
        assert data["resources"] == {"service.name": "test"}

    def test_deserialize_message(self):
        json_data = '{"event":"new-interaction","type":"http-request","hash":"req-hash","from":"client","to":"server"}'
        data = deserialize_message(json_data)
        assert data["from_"] == "client"
        assert "from" not in data

    def test_none_fields_omitted(self):
        msg = NewObservedServiceMessage(
            hash="srv-hash", name="my-service",
            namespace=None, environment="prod"
        )
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        assert "namespace" not in data
        assert data["environment"] == "prod"

    def test_none_optional_fields_on_observations(self):
        obs = HttpClientObservation(
            subject="req-hash", spanId="s1", traceId="t1",
            timestamp=1000, path="/test", method="GET",
            duration=100, status=200,
            httpVersion=None, requestBytes=None, responseBytes=1024,
            errorMessage=None, errorType=None, stack=None
        )
        msg = ObservationMessage(seq=1, observations=[obs])
        json_str = serialize_message(msg)
        data = json.loads(json_str)
        http_data = data["observations"][0]
        assert "httpVersion" not in http_data
        assert "requestBytes" not in http_data
        assert "errorMessage" not in http_data
        assert http_data["responseBytes"] == 1024
