"""Integration tests for the complete Python telemetry SDK V2."""

from unittest.mock import Mock, patch
import time

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.resources import Resource

from comprehend_telemetry.span_processor import ComprehendDevSpanProcessor
from comprehend_telemetry.wire_protocol import (
    TraceSpansMessage,
    DatabaseQueryMessage,
    ObservationMessage,
    HttpServerObservation,
    HttpClientObservation,
)


def test_complete_sdk_integration():
    """Test the complete SDK integration with OpenTelemetry."""
    sent_messages = []
    mock_connection = Mock()
    mock_connection.send_message = Mock(side_effect=lambda msg: sent_messages.append(msg))
    mock_connection.close = Mock()
    mock_connection.next_seq = Mock(side_effect=iter(range(1, 1000)))
    mock_connection.set_process_context = Mock()

    resource = Resource.create({
        'service.name': 'my-python-service',
        'service.namespace': 'production',
        'deployment.environment': 'prod'
    })

    tracer_provider = TracerProvider(resource=resource)
    processor = ComprehendDevSpanProcessor(mock_connection)
    tracer_provider.add_span_processor(processor)

    tracer = tracer_provider.get_tracer(__name__)

    # HTTP Server span
    with tracer.start_as_current_span(
        "handle_user_request",
        kind=trace.SpanKind.SERVER
    ) as span:
        span.set_attributes({
            'http.method': 'GET',
            'http.route': '/api/users/{id}',
            'http.target': '/api/users/123',
            'http.status_code': 200,
            'http.user_agent': 'Python-Test/1.0'
        })

        # Database span (nested)
        with tracer.start_as_current_span("query_user_database") as db_span:
            db_span.set_attributes({
                'db.system': 'postgresql',
                'db.name': 'users_db',
                'db.statement': 'SELECT * FROM users WHERE id = $1',
                'net.peer.name': 'db.example.com',
                'net.peer.port': 5432,
                'db.response.returned_rows': 1
            })
            time.sleep(0.001)

        # HTTP Client span (nested)
        with tracer.start_as_current_span(
            "call_external_api",
            kind=trace.SpanKind.CLIENT
        ) as client_span:
            client_span.set_attributes({
                'http.method': 'POST',
                'http.url': 'https://api.external.com/v1/validate',
                'http.status_code': 200
            })
            time.sleep(0.001)

    processor.shutdown()

    assert len(sent_messages) > 0

    # Should have set process context
    mock_connection.set_process_context.assert_called_once()

    # Check for trace spans (V2: every span reports a trace span)
    trace_span_msgs = [m for m in sent_messages if isinstance(m, TraceSpansMessage)]
    assert len(trace_span_msgs) >= 3  # at least 3 spans

    # Check for db-query message (V2: top-level, not interaction)
    db_query_msgs = [m for m in sent_messages if isinstance(m, DatabaseQueryMessage)]
    assert len(db_query_msgs) == 1
    assert db_query_msgs[0].query == 'SELECT * FROM users WHERE id = $1'
    assert db_query_msgs[0].traceId is not None
    assert db_query_msgs[0].spanId is not None

    # Check observations have span context
    obs_msgs = [m for m in sent_messages if isinstance(m, ObservationMessage)]
    for obs_msg in obs_msgs:
        for obs in obs_msg.observations:
            assert obs.spanId != '', f"Missing spanId on {obs.type} observation"
            assert obs.traceId != '', f"Missing traceId on {obs.type} observation"

    # Verify service message
    service_messages = [m for m in sent_messages
                       if getattr(m, 'event', None) == 'new-entity' and getattr(m, 'type', None) == 'service']
    assert len(service_messages) >= 1
    assert service_messages[0].name == 'my-python-service'
    assert service_messages[0].namespace == 'production'


def test_error_handling_integration():
    """Test error handling in V2 integration."""
    sent_messages = []
    mock_connection = Mock()
    mock_connection.send_message = Mock(side_effect=lambda msg: sent_messages.append(msg))
    mock_connection.close = Mock()
    mock_connection.next_seq = Mock(side_effect=iter(range(1, 1000)))
    mock_connection.set_process_context = Mock()

    resource = Resource.create({'service.name': 'error-test-service'})
    tracer_provider = TracerProvider(resource=resource)
    processor = ComprehendDevSpanProcessor(mock_connection)
    tracer_provider.add_span_processor(processor)

    tracer = tracer_provider.get_tracer(__name__)

    with tracer.start_as_current_span("failing_operation", kind=trace.SpanKind.SERVER) as span:
        span.set_attributes({
            'http.method': 'POST',
            'http.route': '/api/error',
            'http.status_code': 500
        })
        span.add_event("exception", {
            'exception.type': 'ValueError',
            'exception.message': 'Invalid input data',
            'exception.stacktrace': 'Traceback...\n  File "test.py", line 42'
        })
        from opentelemetry.trace import Status, StatusCode
        span.set_status(Status(StatusCode.ERROR, "Operation failed"))

    processor.shutdown()

    obs_msgs = [m for m in sent_messages if isinstance(m, ObservationMessage)]
    found_error = False
    for obs_msg in obs_msgs:
        for obs in obs_msg.observations:
            if hasattr(obs, 'errorMessage') and obs.errorMessage == 'Invalid input data':
                found_error = True
                assert obs.errorType == 'ValueError'
                assert 'Traceback' in obs.stack

    assert found_error, "Error information not found in observations"
