"""Tests for ComprehendSDK."""

from unittest.mock import Mock, patch, MagicMock

from comprehend_telemetry.sdk import ComprehendSDK
from comprehend_telemetry.span_processor import ComprehendDevSpanProcessor
from comprehend_telemetry.metrics_exporter import ComprehendMetricsExporter
from comprehend_telemetry.wire_protocol import InitAck


class TestComprehendSDK:
    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_creates_connection(self, mock_ws_class):
        sdk = ComprehendSDK(organization='test-org', token='test-token')
        mock_ws_class.assert_called_once()
        call_kwargs = mock_ws_class.call_args[1]
        assert call_kwargs['organization'] == 'test-org'
        assert call_kwargs['token'] == 'test-token'
        assert call_kwargs['on_authorized'] is not None
        assert call_kwargs['on_custom_metric_change'] is not None
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_debug_true_uses_print(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t', debug=True)
        call_kwargs = mock_ws_class.call_args[1]
        assert call_kwargs['logger'] is print
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_debug_callable(self, mock_ws_class):
        custom_logger = Mock()
        sdk = ComprehendSDK(organization='o', token='t', debug=custom_logger)
        call_kwargs = mock_ws_class.call_args[1]
        assert call_kwargs['logger'] is custom_logger
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_debug_false(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t', debug=False)
        call_kwargs = mock_ws_class.call_args[1]
        assert call_kwargs['logger'] is None
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_get_span_processor(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t')
        processor = sdk.get_span_processor()
        assert isinstance(processor, ComprehendDevSpanProcessor)
        # Same instance on second call
        assert sdk.get_span_processor() is processor
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_get_metrics_exporter(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t')
        exporter = sdk.get_metrics_exporter()
        assert isinstance(exporter, ComprehendMetricsExporter)
        # Same instance on second call
        assert sdk.get_metrics_exporter() is exporter
        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_custom_metrics_distributed_on_auth(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t')

        # Create processor and exporter to register listeners
        processor = sdk.get_span_processor()
        exporter = sdk.get_metrics_exporter()

        # Simulate on_authorized callback
        call_kwargs = mock_ws_class.call_args[1]
        on_authorized = call_kwargs['on_authorized']

        ack = InitAck(
            customMetrics=[
                {'type': 'span', 'subject': 'h1', 'rule': {'kind': 'type', 'value': 'server'}},
                {'type': 'cumulative', 'id': 'test.metric', 'attributes': [], 'subject': 'h2'},
            ]
        )
        on_authorized(ack)

        # Processor should have the span spec
        assert len(processor._span_observation_specs) == 1

        # Exporter should have the cumulative spec
        assert len(exporter._custom_cumulative_specs) == 1

        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_custom_metric_change_distributed(self, mock_ws_class):
        sdk = ComprehendSDK(organization='o', token='t')
        processor = sdk.get_span_processor()
        exporter = sdk.get_metrics_exporter()

        call_kwargs = mock_ws_class.call_args[1]
        on_change = call_kwargs['on_custom_metric_change']

        from comprehend_telemetry.wire_protocol import (
            CustomTimeSeriesMetricSpecification,
            CustomSpanObservationSpecification,
            SpanMatcherRule,
        )
        specs = [
            CustomTimeSeriesMetricSpecification(id='new.gauge', attributes=[], subject='h3'),
            CustomSpanObservationSpecification(
                rule=SpanMatcherRule(kind='type', value='client'), subject='h4'
            ),
        ]
        on_change(specs)

        assert len(exporter._custom_timeseries_specs) == 1
        assert len(processor._span_observation_specs) == 1

        sdk.shutdown()

    @patch('comprehend_telemetry.sdk.WebSocketConnection')
    def test_shutdown_closes_all(self, mock_ws_class):
        mock_conn = Mock()
        mock_ws_class.return_value = mock_conn

        sdk = ComprehendSDK(organization='o', token='t')
        sdk.get_span_processor()
        sdk.get_metrics_exporter()
        sdk.shutdown()

        mock_conn.close.assert_called()
