"""Tests for ComprehendDevSpanProcessor V2."""

from unittest.mock import Mock, patch
from typing import Dict, Any, Optional

from opentelemetry.trace import SpanKind, StatusCode
from opentelemetry.sdk.trace import ReadableSpan

from comprehend_telemetry.span_processor import (
    ComprehendDevSpanProcessor,
    match_span_rule,
)
from comprehend_telemetry.wire_protocol import (
    NewObservedServiceMessage,
    NewObservedHttpRouteMessage,
    ObservationMessage,
    HttpServerObservation,
    HttpClientObservation,
    TraceSpansMessage,
    DatabaseQueryMessage,
    CustomObservation,
    CustomSpanObservationSpecification,
    SpanMatcherRule,
)


def create_mock_span(
    name="test-span",
    kind=SpanKind.INTERNAL,
    attributes=None,
    resource_attributes=None,
    status_code=StatusCode.OK,
    status_description="",
    events=None,
    start_time=1700000000000000000,
    end_time=None,
    trace_id=0x0123456789abcdef0123456789abcdef,
    span_id=0x0123456789abcdef,
    parent_span_id=None,
):
    if attributes is None:
        attributes = {}
    if resource_attributes is None:
        resource_attributes = {'service.name': 'test-service'}
    if events is None:
        events = []
    if end_time is None:
        end_time = start_time + 100000000

    mock_span = Mock(spec=ReadableSpan)
    mock_span.name = name
    mock_span.kind = kind
    mock_span.attributes = attributes
    mock_span.resource = Mock()
    mock_span.resource.attributes = resource_attributes
    mock_span.status = Mock()
    mock_span.status.status_code = status_code
    mock_span.status.description = status_description
    mock_span.events = events
    mock_span.start_time = start_time
    mock_span.end_time = end_time

    # Span context
    mock_span.context = Mock()
    mock_span.context.trace_id = trace_id
    mock_span.context.span_id = span_id

    # Parent span context
    if parent_span_id:
        mock_span.parent = Mock()
        mock_span.parent.span_id = parent_span_id
    else:
        mock_span.parent = None

    return mock_span


class TestComprehendDevSpanProcessor:
    def setup_method(self):
        self.sent_messages = []
        self.mock_connection = Mock()
        self.mock_connection.send_message = Mock(side_effect=lambda msg: self.sent_messages.append(msg))
        self.mock_connection.close = Mock()
        self.mock_connection.next_seq = Mock(side_effect=iter(range(1, 1000)))
        self.mock_connection.set_process_context = Mock()

    def _create_processor(self):
        return ComprehendDevSpanProcessor(self.mock_connection)

    def _msgs_of_type(self, event=None, msg_type=None):
        results = []
        for msg in self.sent_messages:
            if event and getattr(msg, 'event', None) != event:
                continue
            if msg_type and getattr(msg, 'type', None) != msg_type:
                continue
            results.append(msg)
        return results

    def test_service_discovery(self):
        processor = self._create_processor()
        span = create_mock_span(
            resource_attributes={
                'service.name': 'my-api',
                'service.namespace': 'production',
                'deployment.environment': 'prod'
            }
        )
        processor.on_end(span)

        service_msgs = self._msgs_of_type('new-entity', 'service')
        assert len(service_msgs) == 1
        assert service_msgs[0].name == 'my-api'
        assert service_msgs[0].namespace == 'production'
        assert service_msgs[0].environment == 'prod'

    def test_service_discovery_sets_process_context(self):
        processor = self._create_processor()
        span = create_mock_span(
            resource_attributes={'service.name': 'my-api', 'deployment.environment': 'prod'}
        )
        processor.on_end(span)

        self.mock_connection.set_process_context.assert_called_once()
        call_args = self.mock_connection.set_process_context.call_args
        assert 'service.name' in call_args[1].get('resources', call_args[0][1])

    def test_service_discovery_no_duplicates(self):
        processor = self._create_processor()
        span1 = create_mock_span(resource_attributes={'service.name': 'my-api'})
        span2 = create_mock_span(resource_attributes={'service.name': 'my-api'})
        processor.on_end(span1)
        processor.on_end(span2)

        service_msgs = self._msgs_of_type('new-entity', 'service')
        assert len(service_msgs) == 1

    def test_process_context_set_only_once(self):
        processor = self._create_processor()
        span1 = create_mock_span(resource_attributes={'service.name': 'svc1'})
        span2 = create_mock_span(resource_attributes={'service.name': 'svc2'})
        processor.on_end(span1)
        processor.on_end(span2)

        assert self.mock_connection.set_process_context.call_count == 1

    def test_ignore_spans_without_service_name(self):
        processor = self._create_processor()
        span = create_mock_span(resource_attributes={})
        processor.on_end(span)
        assert len(self.sent_messages) == 0

    def test_http_server_span(self):
        processor = self._create_processor()
        span = create_mock_span(
            kind=SpanKind.SERVER,
            attributes={
                'http.route': '/api/users/{id}',
                'http.method': 'GET',
                'http.target': '/api/users/123',
                'http.status_code': 200
            }
        )
        processor.on_end(span)

        # service + route + observation + trace span
        route_msgs = self._msgs_of_type('new-entity', 'http-route')
        assert len(route_msgs) == 1
        assert route_msgs[0].method == 'GET'
        assert route_msgs[0].route == '/api/users/{id}'

        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        assert len(obs_msgs) == 1
        obs = obs_msgs[0].observations[0]
        assert isinstance(obs, HttpServerObservation)
        assert obs.path == '/api/users/123'
        assert obs.status == 200
        assert obs.spanId != ''
        assert obs.traceId != ''

    def test_http_server_span_trace_ids(self):
        processor = self._create_processor()
        span = create_mock_span(
            kind=SpanKind.SERVER,
            attributes={
                'http.route': '/test',
                'http.method': 'GET',
                'http.status_code': 200,
            },
            trace_id=0xaabbccdd00112233aabbccdd00112233,
            span_id=0xaabbccdd00112233,
        )
        processor.on_end(span)

        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        obs = obs_msgs[0].observations[0]
        assert obs.traceId == 'aabbccdd00112233aabbccdd00112233'
        assert obs.spanId == 'aabbccdd00112233'

    def test_trace_span_reported_for_every_span(self):
        processor = self._create_processor()
        span = create_mock_span(
            parent_span_id=0xdeadbeef12345678,
        )
        processor.on_end(span)

        trace_msgs = self._msgs_of_type('tracespans')
        assert len(trace_msgs) == 1
        ts = trace_msgs[0].data[0]
        assert ts.trace == format(0x0123456789abcdef0123456789abcdef, '032x')
        assert ts.span == format(0x0123456789abcdef, '016x')
        assert ts.parent == format(0xdeadbeef12345678, '016x')
        assert ts.name == 'test-span'

    def test_trace_span_no_parent(self):
        processor = self._create_processor()
        span = create_mock_span(parent_span_id=None)
        processor.on_end(span)

        trace_msgs = self._msgs_of_type('tracespans')
        ts = trace_msgs[0].data[0]
        assert ts.parent == ''

    def test_http_client_span(self):
        processor = self._create_processor()
        span = create_mock_span(
            kind=SpanKind.CLIENT,
            attributes={
                'http.url': 'https://api.external.com/v1/data',
                'http.method': 'GET',
                'http.status_code': 200
            }
        )
        processor.on_end(span)

        http_service_msgs = self._msgs_of_type('new-entity', 'http-service')
        assert len(http_service_msgs) == 1
        assert http_service_msgs[0].protocol == 'https'
        assert http_service_msgs[0].host == 'api.external.com'
        assert http_service_msgs[0].port == 443

        http_request_msgs = self._msgs_of_type('new-interaction', 'http-request')
        assert len(http_request_msgs) == 1

        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        assert len(obs_msgs) == 1
        obs = obs_msgs[0].observations[0]
        assert isinstance(obs, HttpClientObservation)
        assert obs.path == '/v1/data'
        assert obs.method == 'GET'
        assert obs.spanId != ''
        assert obs.traceId != ''

    def test_database_operation_sends_db_query_message(self):
        processor = self._create_processor()
        span = create_mock_span(
            attributes={
                'db.system': 'postgresql',
                'db.statement': 'SELECT * FROM users WHERE id = $1',
                'db.name': 'myapp',
                'net.peer.name': 'db.example.com',
                'net.peer.port': 5432,
                'db.response.returned_rows': 1,
            }
        )
        processor.on_end(span)

        # Should have database entity, db-connection interaction, and db-query message
        db_msgs = self._msgs_of_type('new-entity', 'database')
        assert len(db_msgs) == 1
        assert db_msgs[0].system == 'postgresql'

        conn_msgs = self._msgs_of_type('new-interaction', 'db-connection')
        assert len(conn_msgs) == 1

        # V2: db-query is a top-level message, not an interaction
        dbq_msgs = self._msgs_of_type('db-query')
        assert len(dbq_msgs) == 1
        assert dbq_msgs[0].query == 'SELECT * FROM users WHERE id = $1'
        assert dbq_msgs[0].traceId is not None
        assert dbq_msgs[0].spanId is not None
        assert dbq_msgs[0].returnedRows == 1

    def test_database_no_query_for_non_sql(self):
        processor = self._create_processor()
        span = create_mock_span(
            attributes={
                'db.system': 'mongodb',
                'db.statement': 'db.users.find({})',
                'db.name': 'myapp',
            }
        )
        processor.on_end(span)

        dbq_msgs = self._msgs_of_type('db-query')
        assert len(dbq_msgs) == 0

    def test_error_info_from_exception_events(self):
        processor = self._create_processor()

        exception_event = Mock()
        exception_event.name = 'exception'
        exception_event.attributes = {
            'exception.message': 'Database connection failed',
            'exception.type': 'ConnectionError',
            'exception.stacktrace': 'Error at line 42'
        }

        span = create_mock_span(
            kind=SpanKind.SERVER,
            attributes={
                'http.route': '/api/error',
                'http.method': 'GET',
                'http.status_code': 500,
            },
            status_code=StatusCode.ERROR,
            events=[exception_event]
        )
        processor.on_end(span)

        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        obs = obs_msgs[0].observations[0]
        assert obs.errorMessage == 'Database connection failed'
        assert obs.errorType == 'ConnectionError'
        assert obs.stack == 'Error at line 42'

    def test_custom_span_matching(self):
        processor = self._create_processor()

        # Set up custom span spec
        rule = SpanMatcherRule(kind='type', value='server')
        spec = CustomSpanObservationSpecification(
            rule=rule, subject='custom-subject'
        )
        processor.update_custom_metrics([spec])

        span = create_mock_span(
            kind=SpanKind.SERVER,
            attributes={'http.method': 'GET'}
        )
        processor.on_end(span)

        # Should have a custom observation
        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        custom_obs = [
            o for msg in obs_msgs for o in msg.observations
            if isinstance(o, CustomObservation)
        ]
        assert len(custom_obs) == 1
        assert custom_obs[0].subject == 'custom-subject'
        assert custom_obs[0].duration is not None
        assert custom_obs[0].attributes.get('http.method') == 'GET'

    def test_custom_span_no_match(self):
        processor = self._create_processor()

        rule = SpanMatcherRule(kind='type', value='client')
        spec = CustomSpanObservationSpecification(rule=rule, subject='s')
        processor.update_custom_metrics([spec])

        span = create_mock_span(kind=SpanKind.SERVER)
        processor.on_end(span)

        obs_msgs = [m for m in self.sent_messages if hasattr(m, 'observations')]
        custom_obs = [
            o for msg in obs_msgs for o in msg.observations
            if isinstance(o, CustomObservation)
        ]
        assert len(custom_obs) == 0

    def test_shutdown_closes_connection(self):
        processor = self._create_processor()
        result = processor.shutdown()
        assert result is True
        self.mock_connection.close.assert_called_once()

    def test_force_flush(self):
        processor = self._create_processor()
        assert processor.force_flush() is True

    def test_on_start_is_noop(self):
        processor = self._create_processor()
        processor.on_start(Mock(), Mock())


class TestMatchSpanRule:
    def _make_span(self, kind=SpanKind.SERVER, attributes=None):
        span = Mock(spec=ReadableSpan)
        span.kind = kind
        span.attributes = attributes or {}
        return span

    def test_type_match(self):
        span = self._make_span(kind=SpanKind.SERVER)
        rule = SpanMatcherRule(kind='type', value='server')
        assert match_span_rule(span, rule) is True

    def test_type_no_match(self):
        span = self._make_span(kind=SpanKind.CLIENT)
        rule = SpanMatcherRule(kind='type', value='server')
        assert match_span_rule(span, rule) is False

    def test_attribute_present(self):
        span = self._make_span(attributes={'http.method': 'GET'})
        rule = SpanMatcherRule(kind='attribute-present', key='http.method')
        assert match_span_rule(span, rule) is True

    def test_attribute_absent(self):
        span = self._make_span(attributes={})
        rule = SpanMatcherRule(kind='attribute-absent', key='http.method')
        assert match_span_rule(span, rule) is True

    def test_attribute_equals(self):
        span = self._make_span(attributes={'http.method': 'GET'})
        rule = SpanMatcherRule(kind='attribute-equals', key='http.method', value='GET')
        assert match_span_rule(span, rule) is True

    def test_attribute_not_equals(self):
        span = self._make_span(attributes={'http.method': 'POST'})
        rule = SpanMatcherRule(kind='attribute-not-equals', key='http.method', value='GET')
        assert match_span_rule(span, rule) is True

    def test_all_rule(self):
        span = self._make_span(kind=SpanKind.SERVER, attributes={'http.method': 'GET'})
        rule = SpanMatcherRule(kind='all', rules=[
            SpanMatcherRule(kind='type', value='server'),
            SpanMatcherRule(kind='attribute-present', key='http.method'),
        ])
        assert match_span_rule(span, rule) is True

    def test_any_rule(self):
        span = self._make_span(kind=SpanKind.CLIENT)
        rule = SpanMatcherRule(kind='any', rules=[
            SpanMatcherRule(kind='type', value='server'),
            SpanMatcherRule(kind='type', value='client'),
        ])
        assert match_span_rule(span, rule) is True
