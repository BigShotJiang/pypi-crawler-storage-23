"""WebSocket connection for comprehend.dev telemetry ingestion V2."""

import json
import os
import threading
import uuid
from typing import Dict, Optional, Callable, Union, List, Any

import websocket

from .wire_protocol import (
    InitMessage,
    StartProcessContextMessage,
    NewObservedEntityMessage,
    NewObservedInteractionMessage,
    ObservationInputMessage,
    AttributeType,
    CustomMetricSpecification,
    InitAck,
    serialize_message,
    hrtime_now,
    parse_custom_metric_spec,
)

INGESTION_ENDPOINT = os.environ.get(
    'COMPREHEND_INGESTION_ENDPOINT', 'wss://ingestion.comprehend.dev'
)


class SeqQueue:
    """A queue of unacknowledged messages keyed by sequence number."""

    def __init__(self, ack_type: str):
        self.ack_type = ack_type
        self._pending: Dict[int, Any] = {}

    def add(self, message: Any) -> None:
        self._pending[message.seq] = message

    def ack(self, seq: int) -> None:
        self._pending.pop(seq, None)

    def values(self):
        return self._pending.values()


class WebSocketConnection:
    """WebSocket connection with automatic reconnection and message acknowledgment."""

    def __init__(
        self,
        organization: str,
        token: str,
        logger: Optional[Callable[[str], None]] = None,
        on_authorized: Optional[Callable[[InitAck], None]] = None,
        on_custom_metric_change: Optional[Callable[[List[CustomMetricSpecification]], None]] = None,
    ):
        self.organization = organization
        self.token = token
        self.logger = logger
        self._on_authorized = on_authorized
        self._on_custom_metric_change = on_custom_metric_change

        self.unacknowledged_observed: Dict[str, Union[NewObservedEntityMessage, NewObservedInteractionMessage]] = {}

        self.observations_queue = SeqQueue('ack-observations')
        self.timeseries_queue = SeqQueue('ack-timeseries')
        self.cumulative_queue = SeqQueue('ack-cumulative')
        self.trace_spans_queue = SeqQueue('ack-tracespans')
        self.db_query_queue = SeqQueue('ack-db-query')
        self.context_queue = SeqQueue('ack-context')

        self.seq_queues: Dict[str, SeqQueue] = {}
        for q in [self.observations_queue, self.timeseries_queue, self.cumulative_queue,
                   self.trace_spans_queue, self.db_query_queue, self.context_queue]:
            self.seq_queues[q.ack_type] = q

        self.socket: Optional[websocket.WebSocketApp] = None
        self.reconnect_delay = 1.0
        self.should_reconnect = True
        self.authorized = False
        self._connection_thread: Optional[threading.Thread] = None
        self._reconnect_timer: Optional[threading.Timer] = None

        self._process_context: Optional[Dict[str, Any]] = None
        self.ingestion_id: str = str(uuid.uuid4())

        self._seq = 1
        self._seq_lock = threading.Lock()

        self._connect()

    def next_seq(self) -> int:
        with self._seq_lock:
            seq = self._seq
            self._seq += 1
            return seq

    def _log(self, message: str) -> None:
        if self.logger:
            self.logger(message)

    def _connect(self) -> None:
        websocket_url = f"{INGESTION_ENDPOINT}/{self.organization}/observations"
        self._log(f"Attempting to connect to {websocket_url}...")

        self.socket = websocket.WebSocketApp(
            websocket_url,
            on_open=self._on_open,
            on_message=self._on_message,
            on_close=self._on_close,
            on_error=self._on_error
        )

        self._connection_thread = threading.Thread(
            target=self._run_connection,
            daemon=True
        )
        self._connection_thread.start()

    def _run_connection(self) -> None:
        try:
            self.socket.run_forever()
        except Exception as e:
            self._log(f"WebSocket connection error: {e}")

    def _on_open(self, ws: websocket.WebSocketApp) -> None:
        self._log("WebSocket connected. Sending init/auth message.")
        self.ingestion_id = str(uuid.uuid4())
        init_message = InitMessage(
            event="init",
            protocolVersion=2,
            token=self.token
        )
        self._send_raw(init_message)

    def _on_message(self, ws: websocket.WebSocketApp, message: str) -> None:
        try:
            msg_data = json.loads(message)
            msg_type = msg_data.get("type")

            if msg_type == "ack-authorized":
                self.authorized = True
                self._log("Authorization acknowledged by server.")

                if self._on_authorized:
                    ack = InitAck(
                        type="ack-authorized",
                        customMetrics=msg_data.get("customMetrics", [])
                    )
                    self._on_authorized(ack)

                # Send context first if we have one
                if self._process_context:
                    self._send_context_start()

                # Replay entities and interactions
                for message_obj in self.unacknowledged_observed.values():
                    self._send_raw(message_obj)

                # Replay all seq-based queues (except context, already sent)
                for q in self.seq_queues.values():
                    if q is self.context_queue:
                        continue
                    for message_obj in q.values():
                        self._send_raw(message_obj)

            elif msg_type == "ack-observed":
                hash_val = msg_data.get("hash")
                if hash_val and hash_val in self.unacknowledged_observed:
                    del self.unacknowledged_observed[hash_val]

            elif msg_type == "custom-metric-change":
                if self._on_custom_metric_change:
                    raw_specs = msg_data.get("customMetrics", [])
                    specs = [parse_custom_metric_spec(s) for s in raw_specs]
                    self._on_custom_metric_change(specs)

            elif 'seq' in msg_data:
                queue = self.seq_queues.get(msg_type)
                if queue:
                    queue.ack(msg_data['seq'])

        except Exception as e:
            self._log(f"Error parsing message from server: {e}")

    def _on_close(self, ws: websocket.WebSocketApp, close_status_code: Optional[int], close_msg: Optional[str]) -> None:
        code = close_status_code or 0
        reason = close_msg or ""
        self._log(f"WebSocket disconnected. Code: {code}, Reason: {reason}")
        self.authorized = False

        if self.should_reconnect:
            self._reconnect_timer = threading.Timer(self.reconnect_delay, self._connect)
            self._reconnect_timer.start()

    def _on_error(self, ws: websocket.WebSocketApp, error: Exception) -> None:
        self._log(f"WebSocket encountered an error: {error}")

    def _send_raw(self, message: Any) -> None:
        if self.socket:
            try:
                serialized = serialize_message(message)
                self.socket.send(serialized)
            except Exception:
                pass

    def _send_context_start(self) -> None:
        if not self._process_context:
            return
        seq = self.next_seq()
        context_msg = StartProcessContextMessage(
            event='context-start',
            seq=seq,
            timestamp=self._process_context['timestamp'],
            ingestionId=self.ingestion_id,
            type='process',
            serviceEntityHash=self._process_context['serviceEntityHash'],
            resources=self._process_context['resources'],
        )
        self.context_queue.add(context_msg)
        self._send_raw(context_msg)

    def set_process_context(self, service_entity_hash: str, resources: Dict[str, AttributeType]) -> None:
        import time
        self._process_context = {
            'serviceEntityHash': service_entity_hash,
            'resources': resources,
            'timestamp': int(time.time() * 1_000_000_000),
        }
        if self.authorized:
            self._send_context_start()

    def send_message(self, message: Any) -> None:
        event = getattr(message, 'event', None)
        if event == 'new-entity' or event == 'new-interaction':
            self.unacknowledged_observed[message.hash] = message
        elif event == 'observations':
            self.observations_queue.add(message)
        elif event == 'timeseries':
            self.timeseries_queue.add(message)
        elif event == 'cumulative':
            self.cumulative_queue.add(message)
        elif event == 'tracespans':
            self.trace_spans_queue.add(message)
        elif event == 'db-query':
            self.db_query_queue.add(message)

        if self.authorized:
            self._send_raw(message)

    def close(self) -> None:
        self.should_reconnect = False
        if self._reconnect_timer:
            self._reconnect_timer.cancel()
            self._reconnect_timer = None
        if self.socket:
            self.socket.close()
