"""ComprehendDev metrics exporter for OpenTelemetry Python SDK."""

import hashlib
from typing import Dict, List, Optional, Sequence

from opentelemetry.sdk.metrics.export import (
    MetricExporter,
    MetricExportResult,
    MetricsData,
)
from opentelemetry.sdk.metrics.export import (
    AggregationTemporality,
    Histogram,
    ExponentialHistogram,
)
from opentelemetry.sdk.metrics import (
    Counter,
    Histogram as HistogramInstrument,
    ObservableCounter,
    ObservableGauge,
    ObservableUpDownCounter,
    UpDownCounter,
)

from .websocket_connection import WebSocketConnection
from .wire_protocol import (
    AttributeType,
    CustomCumulativeMetricSpecification,
    CustomMetricSpecification,
    CustomTimeSeriesMetricSpecification,
    TimeSeriesMetricsMessage,
    TimeSeriesDataPoint,
    CumulativeMetricsMessage,
    CumulativeDataPoint,
)


KNOWN_GAUGE_METRICS = {
    'process.cpu.utilization',
    'process.uptime',
    'process.memory.usage',
}

KNOWN_CUMULATIVE_METRICS = {
    'process.cpu.time',
    'process.memory.virtual',
}


class ComprehendMetricsExporter(MetricExporter):
    """Exports metrics to comprehend.dev via WebSocket."""

    def __init__(self, connection: WebSocketConnection):
        self._connection = connection
        self._custom_cumulative_specs: List[CustomCumulativeMetricSpecification] = []
        self._custom_timeseries_specs: List[CustomTimeSeriesMetricSpecification] = []

        super().__init__(
            preferred_temporality={
                Counter: AggregationTemporality.CUMULATIVE,
                UpDownCounter: AggregationTemporality.CUMULATIVE,
                HistogramInstrument: AggregationTemporality.CUMULATIVE,
                ObservableCounter: AggregationTemporality.CUMULATIVE,
                ObservableUpDownCounter: AggregationTemporality.CUMULATIVE,
                ObservableGauge: AggregationTemporality.CUMULATIVE,
            },
        )

    def update_custom_metrics(self, specs: List[CustomMetricSpecification]) -> None:
        self._custom_cumulative_specs = [
            s for s in specs
            if isinstance(s, CustomCumulativeMetricSpecification) or
            (hasattr(s, 'type') and s.type == 'cumulative')
        ]
        self._custom_timeseries_specs = [
            s for s in specs
            if isinstance(s, CustomTimeSeriesMetricSpecification) or
            (hasattr(s, 'type') and s.type == 'timeseries')
        ]

    def export(
        self,
        metrics_data: MetricsData,
        timeout_millis: float = 10_000,
        **kwargs,
    ) -> MetricExportResult:
        try:
            for resource_metrics in metrics_data.resource_metrics:
                service_subject = self._get_service_subject(resource_metrics)
                for scope_metrics in resource_metrics.scope_metrics:
                    for metric in scope_metrics.metrics:
                        name = metric.name
                        unit = metric.unit or ''

                        # Skip histogram types
                        if isinstance(metric.data, (Histogram, ExponentialHistogram)):
                            continue

                        # Check standard well-known metrics
                        if name in KNOWN_GAUGE_METRICS and service_subject:
                            self._send_timeseries_data(service_subject, name, unit, metric.data)
                            continue
                        if name in KNOWN_CUMULATIVE_METRICS and service_subject:
                            self._send_cumulative_data(service_subject, name, unit, metric.data)
                            continue

                        # Check custom metric specs
                        cumulative_spec = next(
                            (s for s in self._custom_cumulative_specs if s.id == name), None
                        )
                        if cumulative_spec:
                            self._send_cumulative_data(
                                cumulative_spec.subject, name, unit, metric.data,
                                cumulative_spec.attributes,
                            )
                            continue

                        timeseries_spec = next(
                            (s for s in self._custom_timeseries_specs if s.id == name), None
                        )
                        if timeseries_spec:
                            self._send_timeseries_data(
                                timeseries_spec.subject, name, unit, metric.data,
                                timeseries_spec.attributes,
                            )

            return MetricExportResult.SUCCESS
        except Exception:
            return MetricExportResult.FAILURE

    def _send_timeseries_data(
        self,
        subject: str,
        name: str,
        unit: str,
        data,
        filter_attributes: Optional[List[str]] = None,
    ) -> None:
        points: List[TimeSeriesDataPoint] = []
        for dp in data.data_points:
            points.append(TimeSeriesDataPoint(
                subject=subject,
                type=name,
                timestamp=dp.time_unix_nano,
                value=dp.value,
                unit=unit,
                attributes=_extract_attributes(dict(dp.attributes) if dp.attributes else {}, filter_attributes),
            ))
        if points:
            self._connection.send_message(TimeSeriesMetricsMessage(
                event='timeseries',
                seq=self._connection.next_seq(),
                data=points,
            ))

    def _send_cumulative_data(
        self,
        subject: str,
        name: str,
        unit: str,
        data,
        filter_attributes: Optional[List[str]] = None,
    ) -> None:
        points: List[CumulativeDataPoint] = []
        for dp in data.data_points:
            points.append(CumulativeDataPoint(
                subject=subject,
                type=name,
                timestamp=dp.time_unix_nano,
                value=dp.value,
                unit=unit,
                attributes=_extract_attributes(dict(dp.attributes) if dp.attributes else {}, filter_attributes),
            ))
        if points:
            self._connection.send_message(CumulativeMetricsMessage(
                event='cumulative',
                seq=self._connection.next_seq(),
                data=points,
            ))

    def _get_service_subject(self, resource_metrics) -> Optional[str]:
        attrs = resource_metrics.resource.attributes
        name = attrs.get('service.name')
        if not name:
            return None
        namespace = attrs.get('service.namespace', '')
        environment = attrs.get('deployment.environment', '')
        id_string = f"service:{name}:{namespace}:{environment}"
        return hashlib.sha256(id_string.encode('utf-8')).hexdigest()

    def force_flush(self, timeout_millis: float = 10_000) -> bool:
        return True

    def shutdown(self, timeout_millis: float = 30_000, **kwargs) -> None:
        pass


def _extract_attributes(
    attrs: Dict,
    filter_keys: Optional[List[str]] = None,
) -> Dict[str, AttributeType]:
    result: Dict[str, AttributeType] = {}
    for key, value in attrs.items():
        if value is None:
            continue
        if filter_keys and key not in filter_keys:
            continue
        result[key] = value
    return result
