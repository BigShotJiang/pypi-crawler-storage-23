"""Wire protocol type definitions for comprehend.dev telemetry V2."""

from typing import Literal, Union, List, Optional, Any, Dict
from dataclasses import dataclass, field
import json

# Time representation: Python OpenTelemetry uses nanosecond integers
# TypeScript uses HrTime which is [seconds, nanoseconds]
HrTime = int  # nanoseconds since epoch

AttributeType = Union[str, int, float, bool]


# Utility functions for time conversion
def hrtime_to_tuple(ns_time: int) -> List[int]:
    """Convert nanosecond timestamp to [seconds, nanoseconds] tuple for wire protocol."""
    return [ns_time // 1_000_000_000, ns_time % 1_000_000_000]


def tuple_to_hrtime(time_tuple: List[int]) -> int:
    """Convert [seconds, nanoseconds] tuple to nanosecond timestamp."""
    return time_tuple[0] * 1_000_000_000 + time_tuple[1]


def hrtime_now() -> List[int]:
    """Get current time as [seconds, nanoseconds] tuple."""
    import time
    now_ms = int(time.time() * 1000)
    return [now_ms // 1000, (now_ms % 1000) * 1_000_000]


# Initialization

@dataclass
class InitMessage:
    event: Literal["init"] = "init"
    protocolVersion: Literal[2] = 2
    token: str = ""


@dataclass
class InitAck:
    type: Literal["ack-authorized"] = "ack-authorized"
    customMetrics: List[Any] = field(default_factory=list)


# Contexts

@dataclass
class StartProcessContextMessage:
    event: Literal["context-start"] = "context-start"
    seq: int = 0
    timestamp: HrTime = 0
    ingestionId: str = ""
    type: Literal["process"] = "process"
    serviceEntityHash: str = ""
    resources: Dict[str, AttributeType] = field(default_factory=dict)


@dataclass
class EndContextMessage:
    event: Literal["context-end"] = "context-end"
    seq: int = 0
    timestamp: HrTime = 0
    ingestionId: str = ""


@dataclass
class ContextAck:
    type: Literal["ack-context"] = "ack-context"
    seq: int = 0


# Entity messages

@dataclass
class NewObservedServiceMessage:
    event: Literal["new-entity"] = "new-entity"
    type: Literal["service"] = "service"
    hash: str = ""
    name: str = ""
    namespace: Optional[str] = None
    environment: Optional[str] = None


@dataclass
class NewObservedHttpRouteMessage:
    event: Literal["new-entity"] = "new-entity"
    type: Literal["http-route"] = "http-route"
    hash: str = ""
    parent: str = ""
    method: str = ""
    route: str = ""


@dataclass
class NewObservedDatabaseMessage:
    event: Literal["new-entity"] = "new-entity"
    type: Literal["database"] = "database"
    hash: str = ""
    system: str = ""
    name: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None


@dataclass
class NewObservedHttpServiceMessage:
    event: Literal["new-entity"] = "new-entity"
    type: Literal["http-service"] = "http-service"
    hash: str = ""
    protocol: str = ""
    host: str = ""
    port: int = 0


NewObservedEntityMessage = Union[
    NewObservedServiceMessage,
    NewObservedHttpRouteMessage,
    NewObservedDatabaseMessage,
    NewObservedHttpServiceMessage
]


# Interaction messages

@dataclass
class NewObservedHttpRequestMessage:
    event: Literal["new-interaction"] = "new-interaction"
    type: Literal["http-request"] = "http-request"
    hash: str = ""
    from_: str = ""  # 'from' is a Python keyword
    to: str = ""


@dataclass
class NewObservedDatabaseConnectionMessage:
    event: Literal["new-interaction"] = "new-interaction"
    type: Literal["db-connection"] = "db-connection"
    hash: str = ""
    from_: str = ""
    to: str = ""
    connection: Optional[str] = None
    user: Optional[str] = None


NewObservedInteractionMessage = Union[
    NewObservedHttpRequestMessage,
    NewObservedDatabaseConnectionMessage
]


# Observations

@dataclass
class HttpClientObservation:
    type: Literal["http-client"] = "http-client"
    subject: str = ""
    spanId: str = ""
    traceId: str = ""
    timestamp: HrTime = 0
    path: str = ""
    method: str = ""
    duration: HrTime = 0
    status: Optional[int] = None
    httpVersion: Optional[str] = None
    requestBytes: Optional[int] = None
    responseBytes: Optional[int] = None
    errorMessage: Optional[str] = None
    errorType: Optional[str] = None
    stack: Optional[str] = None


@dataclass
class HttpServerObservation:
    type: Literal["http-server"] = "http-server"
    subject: str = ""
    spanId: str = ""
    traceId: str = ""
    timestamp: HrTime = 0
    path: str = ""
    status: int = 0
    duration: HrTime = 0
    httpVersion: Optional[str] = None
    requestBytes: Optional[int] = None
    responseBytes: Optional[int] = None
    userAgent: Optional[str] = None
    errorMessage: Optional[str] = None
    errorType: Optional[str] = None
    stack: Optional[str] = None


@dataclass
class CustomObservation:
    type: Literal["custom"] = "custom"
    subject: str = ""
    id: str = ""
    spanId: str = ""
    traceId: str = ""
    timestamp: HrTime = 0
    duration: Optional[HrTime] = None
    attributes: Dict[str, AttributeType] = field(default_factory=dict)
    errorMessage: Optional[str] = None
    errorType: Optional[str] = None
    stack: Optional[str] = None


Observation = Union[
    HttpClientObservation,
    HttpServerObservation,
    CustomObservation
]


@dataclass
class ObservationMessage:
    event: Literal["observations"] = "observations"
    seq: int = 0
    observations: List[Observation] = field(default_factory=list)


@dataclass
class ObservedAck:
    type: Literal["ack-observed"] = "ack-observed"
    hash: str = ""


@dataclass
class ObservationsAck:
    type: Literal["ack-observations"] = "ack-observations"
    seq: int = 0


# Time series metrics

@dataclass
class TimeSeriesDataPoint:
    subject: str = ""
    type: str = ""
    timestamp: HrTime = 0
    value: float = 0.0
    unit: str = ""
    attributes: Dict[str, AttributeType] = field(default_factory=dict)


@dataclass
class TimeSeriesMetricsMessage:
    event: Literal["timeseries"] = "timeseries"
    seq: int = 0
    data: List[TimeSeriesDataPoint] = field(default_factory=list)


@dataclass
class TimeSeriesMetricsAck:
    type: Literal["ack-timeseries"] = "ack-timeseries"
    seq: int = 0


# Cumulative metrics

@dataclass
class CumulativeDataPoint:
    subject: str = ""
    type: str = ""
    timestamp: HrTime = 0
    value: float = 0.0
    unit: str = ""
    attributes: Dict[str, AttributeType] = field(default_factory=dict)


@dataclass
class CumulativeMetricsMessage:
    event: Literal["cumulative"] = "cumulative"
    seq: int = 0
    data: List[CumulativeDataPoint] = field(default_factory=list)


@dataclass
class CumulativeMetricsAck:
    type: Literal["ack-cumulative"] = "ack-cumulative"
    seq: int = 0


# Trace spans

@dataclass
class TraceSpan:
    trace: str = ""
    span: str = ""
    parent: str = ""
    name: str = ""
    timestamp: HrTime = 0


@dataclass
class TraceSpansMessage:
    event: Literal["tracespans"] = "tracespans"
    seq: int = 0
    data: List[TraceSpan] = field(default_factory=list)


@dataclass
class TraceSpansAck:
    type: Literal["ack-tracespans"] = "ack-tracespans"
    seq: int = 0


# Database query

@dataclass
class DatabaseQueryMessage:
    event: Literal["db-query"] = "db-query"
    seq: int = 0
    query: str = ""
    from_: str = ""
    to: str = ""
    timestamp: HrTime = 0
    duration: HrTime = 0
    traceId: Optional[str] = None
    spanId: Optional[str] = None
    errorMessage: Optional[str] = None
    errorType: Optional[str] = None
    stack: Optional[str] = None
    returnedRows: Optional[int] = None


@dataclass
class DatabaseQueryAck:
    type: Literal["ack-db-query"] = "ack-db-query"
    seq: int = 0


# Custom metrics

@dataclass
class CustomMetricChange:
    type: Literal["custom-metric-change"] = "custom-metric-change"
    customMetrics: List[Any] = field(default_factory=list)


@dataclass
class SpanMatcherRule:
    kind: str = ""
    value: Optional[str] = None
    key: Optional[str] = None
    rules: Optional[List['SpanMatcherRule']] = None


@dataclass
class CustomCumulativeMetricSpecification:
    type: Literal["cumulative"] = "cumulative"
    id: str = ""
    attributes: List[str] = field(default_factory=list)
    subject: str = ""


@dataclass
class CustomTimeSeriesMetricSpecification:
    type: Literal["timeseries"] = "timeseries"
    id: str = ""
    attributes: List[str] = field(default_factory=list)
    subject: str = ""


@dataclass
class CustomSpanObservationSpecification:
    type: Literal["span"] = "span"
    rule: Optional[SpanMatcherRule] = None
    subject: str = ""


CustomMetricSpecification = Union[
    CustomCumulativeMetricSpecification,
    CustomTimeSeriesMetricSpecification,
    CustomSpanObservationSpecification
]


# Union types for message categories
ObservationInputMessage = Union[
    InitMessage,
    StartProcessContextMessage,
    EndContextMessage,
    NewObservedEntityMessage,
    NewObservedInteractionMessage,
    ObservationMessage,
    TimeSeriesMetricsMessage,
    CumulativeMetricsMessage,
    TraceSpansMessage,
    DatabaseQueryMessage
]

ObservationOutputMessage = Union[
    InitAck,
    ContextAck,
    CustomMetricChange,
    ObservedAck,
    ObservationsAck,
    TimeSeriesMetricsAck,
    CumulativeMetricsAck,
    TraceSpansAck,
    DatabaseQueryAck
]


# JSON serialization support
def _convert_for_wire_protocol(obj: Any) -> Any:
    """Recursively convert objects for wire protocol serialization."""
    if hasattr(obj, '__dataclass_fields__'):
        data = {}
        for field_name in obj.__dataclass_fields__.keys():
            field_value = getattr(obj, field_name)

            # Skip None values
            if field_value is None:
                continue

            # Handle 'from_' field name conversion
            if field_name == 'from_':
                data['from'] = field_value
            # Convert HrTime fields to [seconds, nanoseconds] tuples
            elif field_name in ['timestamp', 'duration'] and isinstance(field_value, int):
                data[field_name] = hrtime_to_tuple(field_value)
            # Recursively handle lists
            elif isinstance(field_value, list):
                data[field_name] = [_convert_for_wire_protocol(item) for item in field_value]
            # Recursively handle dicts
            elif isinstance(field_value, dict):
                data[field_name] = field_value
            # Recursively handle nested dataclasses
            elif hasattr(field_value, '__dataclass_fields__'):
                data[field_name] = _convert_for_wire_protocol(field_value)
            else:
                data[field_name] = field_value

        return data
    elif isinstance(obj, list):
        return [_convert_for_wire_protocol(item) for item in obj]
    else:
        return obj


class WireProtocolEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if hasattr(obj, '__dataclass_fields__'):
            return _convert_for_wire_protocol(obj)
        return super().default(obj)


def serialize_message(message: Any) -> str:
    """Serialize a wire protocol message to JSON."""
    return json.dumps(_convert_for_wire_protocol(message), separators=(',', ':'))


def deserialize_message(json_data: str) -> Dict[str, Any]:
    """Deserialize JSON to dictionary."""
    data = json.loads(json_data)

    if 'from' in data:
        data['from_'] = data.pop('from')

    for field_name in ['timestamp', 'duration']:
        if field_name in data and isinstance(data[field_name], list):
            data[field_name] = tuple_to_hrtime(data[field_name])

    return data


def parse_custom_metric_spec(raw: Dict[str, Any]) -> CustomMetricSpecification:
    """Parse a raw dict into a typed CustomMetricSpecification."""
    spec_type = raw.get('type')
    if spec_type == 'cumulative':
        return CustomCumulativeMetricSpecification(
            type='cumulative',
            id=raw.get('id', ''),
            attributes=raw.get('attributes', []),
            subject=raw.get('subject', ''),
        )
    elif spec_type == 'timeseries':
        return CustomTimeSeriesMetricSpecification(
            type='timeseries',
            id=raw.get('id', ''),
            attributes=raw.get('attributes', []),
            subject=raw.get('subject', ''),
        )
    elif spec_type == 'span':
        return CustomSpanObservationSpecification(
            type='span',
            rule=parse_span_matcher_rule(raw.get('rule', {})),
            subject=raw.get('subject', ''),
        )
    raise ValueError(f"Unknown custom metric spec type: {spec_type}")


def parse_span_matcher_rule(raw: Dict[str, Any]) -> SpanMatcherRule:
    """Parse a raw dict into a SpanMatcherRule."""
    kind = raw.get('kind', '')
    rule = SpanMatcherRule(kind=kind)
    if kind in ('type', 'attribute-equals', 'attribute-not-equals'):
        rule.value = raw.get('value')
    if kind in ('attribute-present', 'attribute-absent', 'attribute-equals', 'attribute-not-equals'):
        rule.key = raw.get('key')
    if kind in ('all', 'any'):
        rule.rules = [parse_span_matcher_rule(r) for r in raw.get('rules', [])]
    return rule
