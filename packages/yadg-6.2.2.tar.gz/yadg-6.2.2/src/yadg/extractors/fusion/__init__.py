"""
Extractors for data files created and exported from Inficon Fusion Micro GCs.

"""
