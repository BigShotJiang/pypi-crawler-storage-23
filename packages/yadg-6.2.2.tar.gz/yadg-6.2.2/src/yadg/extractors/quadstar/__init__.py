"""
An extractors for data files produced by Quadstar mass spectrometers.

"""
