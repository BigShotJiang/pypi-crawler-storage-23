#pragma once

#include r2graded_matrix
#include r3graded_matrix

namespace graded_linalg {


class Interval_module {
    R2GradedMatrix<int> presentation;
    vec<r2degree> lower_b;
    vec<r2degree> upper_b;

    Interval_module(R2GradedMatrix& )
    
}

}