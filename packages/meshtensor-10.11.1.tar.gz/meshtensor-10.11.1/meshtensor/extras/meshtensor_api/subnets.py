from typing import Union

from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor


class Subnets:
    """Class for managing subnet operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.all_subnets = meshtensor.all_subnets
        self.blocks_since_last_step = meshtensor.blocks_since_last_step
        self.blocks_since_last_update = meshtensor.blocks_since_last_update
        self.blocks_until_next_epoch = meshtensor.blocks_until_next_epoch
        self.bonds = meshtensor.bonds
        self.burned_register = meshtensor.burned_register
        self.commit_reveal_enabled = meshtensor.commit_reveal_enabled
        self.difficulty = meshtensor.difficulty
        self.get_all_ema_mesh_inflow = meshtensor.get_all_ema_mesh_inflow
        self.get_all_subnets_info = meshtensor.get_all_subnets_info
        self.get_all_subnets_netuid = meshtensor.get_all_subnets_netuid
        self.get_ema_mesh_inflow = meshtensor.get_ema_mesh_inflow
        self.get_parents = meshtensor.get_parents
        self.get_children = meshtensor.get_children
        self.get_children_pending = meshtensor.get_children_pending
        self.get_hyperparameter = meshtensor.get_hyperparameter
        self.get_liquidity_list = meshtensor.get_liquidity_list
        self.get_neuron_for_pubkey_and_subnet = (
            meshtensor.get_neuron_for_pubkey_and_subnet
        )
        self.get_next_epoch_start_block = meshtensor.get_next_epoch_start_block
        self.get_mechanism_emission_split = meshtensor.get_mechanism_emission_split
        self.get_mechanism_count = meshtensor.get_mechanism_count
        self.get_subnet_burn_cost = meshtensor.get_subnet_burn_cost
        self.get_subnet_hyperparameters = meshtensor.get_subnet_hyperparameters
        self.get_subnet_info = meshtensor.get_subnet_info
        self.get_subnet_price = meshtensor.get_subnet_price
        self.get_subnet_prices = meshtensor.get_subnet_prices
        self.get_subnet_owner_hotkey = meshtensor.get_subnet_owner_hotkey
        self.get_subnet_reveal_period_epochs = meshtensor.get_subnet_reveal_period_epochs
        self.get_subnet_validator_permits = meshtensor.get_subnet_validator_permits
        self.get_total_subnets = meshtensor.get_total_subnets
        self.get_uid_for_hotkey_on_subnet = meshtensor.get_uid_for_hotkey_on_subnet
        self.immunity_period = meshtensor.immunity_period
        self.is_hotkey_registered_on_subnet = meshtensor.is_hotkey_registered_on_subnet
        self.is_subnet_active = meshtensor.is_subnet_active
        self.max_weight_limit = meshtensor.max_weight_limit
        self.min_allowed_weights = meshtensor.min_allowed_weights
        self.recycle = meshtensor.recycle
        self.register = meshtensor.register
        self.register_subnet = meshtensor.register_subnet
        self.root_register = meshtensor.root_register
        self.set_subnet_identity = meshtensor.set_subnet_identity
        self.start_call = meshtensor.start_call
        self.subnet = meshtensor.subnet
        self.subnet_exists = meshtensor.subnet_exists
        self.subnetwork_n = meshtensor.subnetwork_n
        self.tempo = meshtensor.tempo
        self.weights_rate_limit = meshtensor.weights_rate_limit
        self.weights = meshtensor.weights
