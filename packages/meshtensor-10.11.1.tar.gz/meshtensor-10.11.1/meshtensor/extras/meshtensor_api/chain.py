from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Chain:
    """Class for managing chain state operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.get_admin_freeze_window = meshtensor.get_admin_freeze_window
        self.get_block_hash = meshtensor.get_block_hash
        self.get_block_info = meshtensor.get_block_info
        self.get_current_block = meshtensor.get_current_block
        self.get_delegate_identities = meshtensor.get_delegate_identities
        self.get_existential_deposit = meshtensor.get_existential_deposit
        self.get_minimum_required_stake = meshtensor.get_minimum_required_stake
        self.get_start_call_delay = meshtensor.get_start_call_delay
        self.get_timestamp = meshtensor.get_timestamp
        self.get_vote_data = meshtensor.get_vote_data
        self.is_fast_blocks = meshtensor.is_fast_blocks
        self.is_in_admin_freeze_window = meshtensor.is_in_admin_freeze_window
        self.last_drand_round = meshtensor.last_drand_round
        self.state_call = meshtensor.state_call
        self.tx_rate_limit = meshtensor.tx_rate_limit
