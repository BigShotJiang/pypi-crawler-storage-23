from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Staking:
    """Class for managing staking operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.add_stake = meshtensor.add_stake
        self.add_stake_multiple = meshtensor.add_stake_multiple
        self.claim_root = meshtensor.claim_root
        self.get_auto_stakes = meshtensor.get_auto_stakes
        self.get_hotkey_stake = meshtensor.get_hotkey_stake
        self.get_minimum_required_stake = meshtensor.get_minimum_required_stake
        self.get_root_alpha_dividends_per_subnet = (
            meshtensor.get_root_alpha_dividends_per_subnet
        )
        self.get_root_claim_type = meshtensor.get_root_claim_type
        self.get_root_claimable_all_rates = meshtensor.get_root_claimable_all_rates
        self.get_root_claimable_rate = meshtensor.get_root_claimable_rate
        self.get_root_claimable_stake = meshtensor.get_root_claimable_stake
        self.get_root_claimed = meshtensor.get_root_claimed
        self.get_stake = meshtensor.get_stake
        self.get_stake_add_fee = meshtensor.get_stake_add_fee
        self.get_stake_for_coldkey_and_hotkey = (
            meshtensor.get_stake_for_coldkey_and_hotkey
        )
        self.get_stake_info_for_coldkey = meshtensor.get_stake_info_for_coldkey
        self.get_stake_info_for_coldkeys = meshtensor.get_stake_info_for_coldkeys
        self.get_stake_movement_fee = meshtensor.get_stake_movement_fee
        self.get_stake_weight = meshtensor.get_stake_weight
        self.get_unstake_fee = meshtensor.get_unstake_fee
        self.move_stake = meshtensor.move_stake
        self.set_auto_stake = meshtensor.set_auto_stake
        self.set_root_claim_type = meshtensor.set_root_claim_type
        self.sim_swap = meshtensor.sim_swap
        self.swap_stake = meshtensor.swap_stake
        self.transfer_stake = meshtensor.transfer_stake
        self.unstake = meshtensor.unstake
        self.unstake_all = meshtensor.unstake_all
        self.unstake_multiple = meshtensor.unstake_multiple
