from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Governance:
    """Class for managing governance operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        # Extrinsics
        self.delegate_voting_power = meshtensor.delegate_voting_power
        self.undelegate_voting_power = meshtensor.undelegate_voting_power
        self.submit_referendum = meshtensor.submit_referendum
        self.vote_referendum = meshtensor.vote_referendum
        self.endorse_referendum = meshtensor.endorse_referendum
        self.cancel_referendum = meshtensor.cancel_referendum
        self.submit_treasury_proposal = meshtensor.submit_treasury_proposal
        self.approve_treasury_proposal = meshtensor.approve_treasury_proposal
        self.signal_golr = meshtensor.signal_golr
        self.update_contribution_scores = meshtensor.update_contribution_scores
        self.distribute_governance_rewards = meshtensor.distribute_governance_rewards
        self.claim_governance_rewards = meshtensor.claim_governance_rewards
        self.submit_preimage = meshtensor.submit_preimage
        self.set_track_coefficients = meshtensor.set_track_coefficients
        self.set_governance_config = meshtensor.set_governance_config
        self.set_golr_config = meshtensor.set_golr_config
        self.prune_stale_accounts = meshtensor.prune_stale_accounts
        # Queries
        self.get_voting_power = meshtensor.get_voting_power
        self.get_track_info = meshtensor.get_track_info
        self.get_referendum_info = meshtensor.get_referendum_info
        self.get_referendum_status = meshtensor.get_referendum_status
        self.get_treasury_balance = meshtensor.get_treasury_balance
        self.get_tc_members = meshtensor.get_tc_members
        self.get_governance_participation_rate = meshtensor.get_governance_participation_rate
        self.get_contribution_score = meshtensor.get_contribution_score
        self.get_governance_vote_count = meshtensor.get_governance_vote_count
        self.get_pending_governance_rewards = meshtensor.get_pending_governance_rewards
        self.get_delegation = meshtensor.get_delegation
        self.get_delegated_vp_total = meshtensor.get_delegated_vp_total
        self.is_golr_active = meshtensor.is_golr_active
        self.get_threshold_multiplier = meshtensor.get_threshold_multiplier
        self.get_golr_signatories = meshtensor.get_golr_signatories
        self.get_total_eligible_voting_power = meshtensor.get_total_eligible_voting_power
        self.get_governance_reward_rate = meshtensor.get_governance_reward_rate
