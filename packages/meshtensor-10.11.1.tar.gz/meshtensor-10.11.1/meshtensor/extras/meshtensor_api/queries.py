from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Queries:
    """Class for managing meshtensor query operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.query_constant = meshtensor.query_constant
        self.query_map = meshtensor.query_map
        self.query_map_meshtensor = meshtensor.query_map_meshtensor
        self.query_module = meshtensor.query_module
        self.query_runtime_api = meshtensor.query_runtime_api
        self.query_meshtensor = meshtensor.query_meshtensor
