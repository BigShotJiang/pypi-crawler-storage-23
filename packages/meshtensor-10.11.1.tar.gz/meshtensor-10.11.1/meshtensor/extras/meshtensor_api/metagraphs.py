from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Metagraphs:
    """Class for managing metagraph operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.get_metagraph_info = meshtensor.get_metagraph_info
        self.get_all_metagraphs_info = meshtensor.get_all_metagraphs_info
        self.get_subnet_state = meshtensor.get_subnet_state
        self.get_subnet_to_prune = meshtensor.get_subnet_to_prune
        self.get_coldkey_auto_stake_hotkey = meshtensor.get_coldkey_auto_stake_hotkey
        self.metagraph = meshtensor.metagraph
