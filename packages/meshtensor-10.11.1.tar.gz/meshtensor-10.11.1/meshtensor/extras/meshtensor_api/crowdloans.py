from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Crowdloans:
    """Class for managing any Crowdloans operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.contribute_crowdloan = meshtensor.contribute_crowdloan
        self.create_crowdloan = meshtensor.create_crowdloan
        self.dissolve_crowdloan = meshtensor.dissolve_crowdloan
        self.finalize_crowdloan = meshtensor.finalize_crowdloan
        self.freeze_crowdloan = meshtensor.freeze_crowdloan
        self.get_crowdloan_auto_refunding = meshtensor.get_crowdloan_auto_refunding
        self.get_crowdloan_by_id = meshtensor.get_crowdloan_by_id
        self.get_crowdloan_constants = meshtensor.get_crowdloan_constants
        self.get_crowdloan_contributions = meshtensor.get_crowdloan_contributions
        self.get_crowdloan_creation_block = meshtensor.get_crowdloan_creation_block
        self.get_crowdloan_frozen = meshtensor.get_crowdloan_frozen
        self.get_crowdloan_frozen_duration = meshtensor.get_crowdloan_frozen_duration
        self.get_crowdloan_grace_period = meshtensor.get_crowdloan_grace_period
        self.get_crowdloan_grace_period_snapshot = (
            meshtensor.get_crowdloan_grace_period_snapshot
        )
        self.get_crowdloan_last_cap_update = meshtensor.get_crowdloan_last_cap_update
        self.get_crowdloan_next_id = meshtensor.get_crowdloan_next_id
        self.get_crowdloan_original_cap = meshtensor.get_crowdloan_original_cap
        self.get_crowdloans = meshtensor.get_crowdloans
        self.refund_crowdloan = meshtensor.refund_crowdloan
        self.unfreeze_crowdloan = meshtensor.unfreeze_crowdloan
        self.update_call_crowdloan = meshtensor.update_call_crowdloan
        self.update_cap_crowdloan = meshtensor.update_cap_crowdloan
        self.update_end_crowdloan = meshtensor.update_end_crowdloan
        self.update_min_contribution_crowdloan = (
            meshtensor.update_min_contribution_crowdloan
        )
        self.withdraw_crowdloan = meshtensor.withdraw_crowdloan
        self.get_accumulated_lease_dividends = (
            meshtensor.get_accumulated_lease_dividends
        )
        self.get_subnet_lease = meshtensor.get_subnet_lease
        self.get_subnet_lease_id = meshtensor.get_subnet_lease_id
        self.get_subnet_lease_shares = meshtensor.get_subnet_lease_shares
        self.get_force_termination_requested_at = (
            meshtensor.get_force_termination_requested_at
        )
        self.get_force_termination_veto_weight = (
            meshtensor.get_force_termination_veto_weight
        )
        self.get_pending_lease_dividends = meshtensor.get_pending_lease_dividends
        self.get_next_subnet_lease_id = meshtensor.get_next_subnet_lease_id
