from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Delegates:
    """Class for managing delegate operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.is_hotkey_delegate = meshtensor.is_hotkey_delegate
        self.get_delegate_by_hotkey = meshtensor.get_delegate_by_hotkey
        self.set_delegate_take = meshtensor.set_delegate_take
        self.get_delegate_identities = meshtensor.get_delegate_identities
        self.get_delegate_take = meshtensor.get_delegate_take
        self.get_delegated = meshtensor.get_delegated
        self.get_delegates = meshtensor.get_delegates
