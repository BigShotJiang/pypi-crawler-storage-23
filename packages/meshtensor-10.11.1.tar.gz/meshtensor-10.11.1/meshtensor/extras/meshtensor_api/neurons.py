from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Neurons:
    """Class for managing neuron operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.get_all_neuron_certificates = meshtensor.get_all_neuron_certificates
        self.get_neuron_certificate = meshtensor.get_neuron_certificate
        self.neuron_for_uid = meshtensor.neuron_for_uid
        self.neuron_lite_for_uid = meshtensor.neuron_lite_for_uid
        self.neurons = meshtensor.neurons
        self.neurons_lite = meshtensor.neurons_lite
        self.query_identity = meshtensor.query_identity
