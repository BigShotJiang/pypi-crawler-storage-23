from typing import Optional, TYPE_CHECKING

from async_substrate_interface.errors import (
    SubstrateRequestException,
    StorageFunctionNotFound,
    BlockNotFound,
    ExtrinsicNotFound,
)

if TYPE_CHECKING:
    from meshtensor.core.synapse import Synapse

__all__ = [
    "BalanceTypeError",
    "BalanceUnitMismatchError",
    "BlacklistedException",
    "BlockNotFound",
    "ChainConnectionError",
    "ChainError",
    "ChainQueryError",
    "ChainTransactionError",
    "DelegateTakeTooHigh",
    "DelegateTakeTooLow",
    "DelegateTxRateLimitExceeded",
    "DuplicateChild",
    "ExtrinsicNotFound",
    "HotKeyAccountNotExists",
    "IdentityError",
    "InternalServerError",
    "InvalidChild",
    "InvalidRequestNameError",
    "MaxAttemptsException",
    "MaxSuccessException",
    "MetadataError",
    "NominationError",
    "NonAssociatedColdKey",
    "NotDelegateError",
    "NotEnoughStakeToSetChildkeys",
    "NotRegisteredError",
    "NotVerifiedException",
    "PostProcessException",
    "PriorityException",
    "ProportionOverflow",
    "RegistrationError",
    "RegistrationNotPermittedOnRootSubnet",
    "RunException",
    "StakeError",
    "StorageFunctionNotFound",
    "SubnetNotExists",
    "SubstrateRequestException",
    "SynapseDendriteNoneException",
    "SynapseException",
    "SynapseParsingError",
    "TakeError",
    "TooManyChildren",
    "TransferError",
    "TxRateLimitExceeded",
    "UnknownSynapseError",
    "UnstakeError",
    # Meshtensor pallet errors
    "RootNetworkDoesNotExist",
    "InvalidIpType",
    "InvalidIpAddress",
    "InvalidPort",
    "HotKeyNotRegisteredInSubNet",
    "HotKeyNotRegisteredInNetwork",
    "NotEnoughStake",
    "NotEnoughStakeToWithdraw",
    "NotEnoughStakeToSetWeights",
    "NotEnoughBalanceToStake",
    "BalanceWithdrawalError",
    "ZeroBalanceAfterWithdrawn",
    "NeuronNoValidatorPermit",
    "WeightVecNotEqualSize",
    "DuplicateUids",
    "UidVecContainInvalidOne",
    "WeightVecLengthIsLow",
    "TooManyRegistrationsThisBlock",
    "HotKeyAlreadyRegisteredInSubNet",
    "NewHotKeyIsSameWithOld",
    "InvalidWorkBlock",
    "InvalidDifficulty",
    "InvalidSeal",
    "MaxWeightExceeded",
    "HotKeyAlreadyDelegate",
    "SettingWeightsTooFast",
    "IncorrectWeightVersionKey",
    "ServingRateLimitExceeded",
    "UidsLengthExceedUidsInSubNet",
    "NetworkTxRateLimitExceeded",
    "HotKeySetTxRateLimitExceeded",
    "StakingRateLimitExceeded",
    "SubNetRegistrationDisabled",
    "TooManyRegistrationsThisInterval",
    "TransactorAccountShouldBeHotKey",
    "FaucetDisabled",
    "NotSubnetOwner",
    "StakeTooLowForRoot",
    "AllNetworksInImmunity",
    "NotEnoughBalanceToPaySwapHotKey",
    "NotRootSubnet",
    "CanNotSetRootNetworkWeights",
    "NoNeuronIdAvailable",
    "NoWeightsCommitFound",
    "InvalidRevealCommitHashNotMatch",
    "CommitRevealEnabled",
    "CommitRevealDisabled",
    "LiquidAlphaDisabled",
    "AlphaHighTooLow",
    "AlphaLowOutOfRange",
    "ColdKeyAlreadyAssociated",
    "NotEnoughBalanceToPaySwapColdKey",
    "ColdkeyIsInArbitration",
    "SwapAlreadyScheduled",
    "FailedToSchedule",
    "NewColdKeyIsHotkey",
    "InvalidChildkeyTake",
    "TxChildkeyTakeRateLimitExceeded",
    "InvalidIdentity",
    "MechanismDoesNotExist",
    "CannotUnstakeLock",
    "TooManyUnrevealedCommits",
    "ExpiredWeightCommit",
    "RevealTooEarly",
    "InputLengthsUnequal",
    "CommittingWeightsTooFast",
    "AmountTooLow",
    "InsufficientLiquidity",
    "SlippageTooHigh",
    "TransferDisallowed",
    "ActivityCutoffTooLow",
    "CallDisabled",
    "FirstEmissionBlockNumberAlreadySet",
    "NeedWaitingMoreBlocksToStarCall",
    "NotEnoughAlphaOutToRecycle",
    "CannotBurnOrRecycleOnRootSubnet",
    "UnableToRecoverPublicKey",
    "InvalidRecoveredPublicKey",
    "SubtokenDisabled",
    "HotKeySwapOnSubnetIntervalNotPassed",
    "ZeroMaxStakeAmount",
    "SameNetuid",
    "InsufficientBalance",
    "StakingOperationRateLimitExceeded",
    "InvalidLeaseBeneficiary",
    "InvalidBeneficiaryShare",
    "InsufficientBeneficiaryContribution",
    "CrowdloanCapBelowLockCost",
    "LeaseCannotEndInThePast",
    "LeaseNetuidNotFound",
    "LeaseDoesNotExist",
    "LeaseHasNoEndBlock",
    "LeaseHasNotEnded",
    "Overflow",
    "BeneficiaryDoesNotOwnHotkey",
    "ExpectedBeneficiaryOrigin",
    "AdminActionProhibitedDuringWeightsWindow",
    "SymbolDoesNotExist",
    "SymbolAlreadyInUse",
    "IncorrectCommitRevealVersion",
    "RevealPeriodTooLarge",
    "RevealPeriodTooSmall",
    "InvalidValue",
    "SubnetLimitReached",
    "CannotAffordLockCost",
    "EvmKeyAssociateRateLimitExceeded",
    "SameAutoStakeHotkeyAlreadySet",
    "UidMapCouldNotBeCleared",
    "TrimmingWouldExceedMaxImmunePercentage",
    "ChildParentInconsistency",
    "InvalidNumRootClaim",
    "InvalidRootClaimThreshold",
    "InvalidSubnetNumber",
    "PrecisionLoss",
    "SubnetPaused",
    "ForceTerminationNotRequested",
    "ForceTerminationNoticePeriodNotElapsed",
    "ForceTerminationAlreadyRequested",
    "NoForceTerminationToVeto",
    "NotALeaseShareholder",
    "AlreadyVetoed",
    "InsufficientLeaseShares",
    "CannotTransferSharesToSelf",
    "ZeroShareTransfer",
    "ForceTerminationPending",
    "LockCostExceedsTolerance",
    "MaxLeaseShareholdersReached",
    # Crowdloan pallet errors
    "DepositTooLow",
    "CapTooLow",
    "MinimumContributionTooLow",
    "CannotEndInPast",
    "BlockDurationTooShort",
    "BlockDurationTooLong",
    "InvalidCrowdloanId",
    "CapRaised",
    "ContributionPeriodEnded",
    "ContributionTooLow",
    "InvalidOrigin",
    "AlreadyFinalized",
    "ContributionPeriodNotEnded",
    "NoContribution",
    "CapNotRaised",
    "Underflow",
    "CallUnavailable",
    "NotReadyToDissolve",
    "DepositCannotBeWithdrawn",
    "MaxContributorsReached",
    "GracePeriodExpired",
    "TooManyActiveCrowdloans",
    "AutoRefundInProgress",
    "CapRecentlyUpdated",
    "CapReductionExcessive",
    "ParametersLocked",
    "EndBlockCannotBeShortened",
    "TargetAddressAndCallConflict",
    "CrowdloanFrozen",
]


class _ChainErrorMeta(type):
    _exceptions: dict[str, Exception] = {}

    def __new__(mcs, name, bases, attrs):
        cls = super().__new__(mcs, name, bases, attrs)

        mcs._exceptions.setdefault(cls.__name__, cls)

        return cls

    @classmethod
    def get_exception_class(mcs, exception_name):
        return mcs._exceptions[exception_name]


class MaxSuccessException(Exception):
    """Raised when the POW Solver has reached the max number of successful solutions."""


class MaxAttemptsException(Exception):
    """Raised when the POW Solver has reached the max number of attempts."""


class BalanceTypeError(Exception):
    """Raised when a Balance object receives an invalid type."""


class BalanceUnitMismatchError(Exception):
    """Raised when Balance objects with different units are used in operations."""


class ChainError(SubstrateRequestException, metaclass=_ChainErrorMeta):
    """Base error for any chain related errors."""

    @classmethod
    def from_error(cls, error):
        try:
            error_cls = _ChainErrorMeta.get_exception_class(
                error["name"],
            )
        except KeyError:
            return cls(error)
        else:
            return error_cls(" ".join(error["docs"]))


class ChainConnectionError(ChainError):
    """Error for any chain connection related errors."""


class ChainTransactionError(ChainError):
    """Error for any chain transaction related errors."""


class DelegateTakeTooHigh(ChainTransactionError):
    """Delegate take is too high."""


class DelegateTakeTooLow(ChainTransactionError):
    """Delegate take is too low."""


class DuplicateChild(ChainTransactionError):
    """Duplicate child when setting children."""


class HotKeyAccountNotExists(ChainTransactionError):
    """The hotkey does not exist."""


class IdentityError(ChainTransactionError):
    """Error raised when an identity transaction fails."""


class InvalidChild(ChainTransactionError):
    """Attempting to set an invalid child for a hotkey on a network."""


class MetadataError(ChainTransactionError):
    """Error raised when metadata commitment transaction fails."""


class NominationError(ChainTransactionError):
    """Error raised when a nomination transaction fails."""


class NonAssociatedColdKey(ChainTransactionError):
    """Request to stake, unstake or subscribe is made by a coldkey that is not associated with the hotkey account."""


class NotEnoughStakeToSetChildkeys(ChainTransactionError):
    """The parent hotkey doesn't have enough own stake to set childkeys."""


class NotRegisteredError(ChainTransactionError):
    """Error raised when a neuron is not registered, and the transaction requires it to be."""


class ProportionOverflow(ChainTransactionError):
    """Proportion overflow when setting children."""


class RegistrationError(ChainTransactionError):
    """Error raised when a neuron registration transaction fails."""


class RegistrationNotPermittedOnRootSubnet(ChainTransactionError):
    """Operation is not permitted on the root subnet."""


class StakeError(ChainTransactionError):
    """Error raised when a stake transaction fails."""


class NotDelegateError(StakeError):
    """Error raised when a hotkey you are trying to stake to is not a delegate."""


class SubnetNotExists(ChainTransactionError):
    """The subnet does not exist."""


class TakeError(ChainTransactionError):
    """Error raised when an increase / decrease take transaction fails."""


class TransferError(ChainTransactionError):
    """Error raised when a transfer transaction fails."""


class TooManyChildren(ChainTransactionError):
    """Too many children MAX 5."""


class TxRateLimitExceeded(ChainTransactionError):
    """Default transaction rate limit exceeded."""


class DelegateTxRateLimitExceeded(TxRateLimitExceeded):
    """A transactor exceeded the rate limit for delegate transaction."""


class UnstakeError(ChainTransactionError):
    """Error raised when an unstake transaction fails."""


# --- Meshtensor pallet errors (matching on-chain error variant names exactly) ---


class RootNetworkDoesNotExist(ChainTransactionError):
    """The root network does not exist."""


class InvalidIpType(ChainTransactionError):
    """The IP type is invalid."""


class InvalidIpAddress(ChainTransactionError):
    """The IP address is invalid."""


class InvalidPort(ChainTransactionError):
    """The port is invalid."""


class HotKeyNotRegisteredInSubNet(ChainTransactionError):
    """The hotkey is not registered in the subnet."""


class HotKeyNotRegisteredInNetwork(ChainTransactionError):
    """The hotkey is not registered in the network."""


class NotEnoughStake(ChainTransactionError):
    """Not enough stake for the operation."""


class NotEnoughStakeToWithdraw(ChainTransactionError):
    """Not enough stake to withdraw."""


class NotEnoughStakeToSetWeights(ChainTransactionError):
    """Not enough stake to set weights."""


class NotEnoughBalanceToStake(ChainTransactionError):
    """Not enough balance to stake."""


class BalanceWithdrawalError(ChainTransactionError):
    """Error withdrawing balance."""


class ZeroBalanceAfterWithdrawn(ChainTransactionError):
    """Balance would be zero after withdrawal."""


class NeuronNoValidatorPermit(ChainTransactionError):
    """Neuron does not have a validator permit."""


class WeightVecNotEqualSize(ChainTransactionError):
    """Weight vector is not equal size."""


class DuplicateUids(ChainTransactionError):
    """Duplicate UIDs in weight vector."""


class UidVecContainInvalidOne(ChainTransactionError):
    """UID vector contains an invalid UID."""


class WeightVecLengthIsLow(ChainTransactionError):
    """Weight vector length is too low."""


class TooManyRegistrationsThisBlock(ChainTransactionError):
    """Too many registrations this block."""


class HotKeyAlreadyRegisteredInSubNet(ChainTransactionError):
    """Hotkey is already registered in the subnet."""


class NewHotKeyIsSameWithOld(ChainTransactionError):
    """New hotkey is the same as the old one."""


class InvalidWorkBlock(ChainTransactionError):
    """Invalid work block for PoW registration."""


class InvalidDifficulty(ChainTransactionError):
    """Invalid difficulty for PoW registration."""


class InvalidSeal(ChainTransactionError):
    """Invalid seal for PoW registration."""


class MaxWeightExceeded(ChainTransactionError):
    """Maximum weight exceeded."""


class HotKeyAlreadyDelegate(ChainTransactionError):
    """Hotkey is already a delegate."""


class SettingWeightsTooFast(ChainTransactionError):
    """Setting weights too fast (rate limited)."""


class IncorrectWeightVersionKey(ChainTransactionError):
    """Incorrect weight version key."""


class ServingRateLimitExceeded(ChainTransactionError):
    """Serving rate limit exceeded."""


class UidsLengthExceedUidsInSubNet(ChainTransactionError):
    """UIDs length exceeds UIDs in subnet."""


class NetworkTxRateLimitExceeded(ChainTransactionError):
    """Network transaction rate limit exceeded."""


class HotKeySetTxRateLimitExceeded(ChainTransactionError):
    """Hotkey set transaction rate limit exceeded."""


class StakingRateLimitExceeded(ChainTransactionError):
    """Staking rate limit exceeded."""


class SubNetRegistrationDisabled(ChainTransactionError):
    """Subnet registration is disabled."""


class TooManyRegistrationsThisInterval(ChainTransactionError):
    """Too many registrations this interval."""


class TransactorAccountShouldBeHotKey(ChainTransactionError):
    """Transactor account should be a hotkey."""


class FaucetDisabled(ChainTransactionError):
    """Faucet is disabled."""


class NotSubnetOwner(ChainTransactionError):
    """Caller is not the subnet owner."""


class StakeTooLowForRoot(ChainTransactionError):
    """Stake is too low for root network."""


class AllNetworksInImmunity(ChainTransactionError):
    """All networks are in immunity period."""


class NotEnoughBalanceToPaySwapHotKey(ChainTransactionError):
    """Not enough balance to pay for hotkey swap."""


class NotRootSubnet(ChainTransactionError):
    """Operation requires root subnet."""


class CanNotSetRootNetworkWeights(ChainTransactionError):
    """Cannot set root network weights."""


class NoNeuronIdAvailable(ChainTransactionError):
    """No neuron ID available for registration."""


class NoWeightsCommitFound(ChainTransactionError):
    """No weights commit found."""


class InvalidRevealCommitHashNotMatch(ChainTransactionError):
    """Revealed weights hash does not match committed hash."""


class CommitRevealEnabled(ChainTransactionError):
    """Commit-reveal is enabled, direct weight setting not allowed."""


class CommitRevealDisabled(ChainTransactionError):
    """Commit-reveal is disabled."""


class LiquidAlphaDisabled(ChainTransactionError):
    """Liquid alpha is disabled."""


class AlphaHighTooLow(ChainTransactionError):
    """Alpha high parameter is too low."""


class AlphaLowOutOfRange(ChainTransactionError):
    """Alpha low parameter is out of range."""


class ColdKeyAlreadyAssociated(ChainTransactionError):
    """Cold key is already associated."""


class NotEnoughBalanceToPaySwapColdKey(ChainTransactionError):
    """Not enough balance to pay for coldkey swap."""


class ColdkeyIsInArbitration(ChainTransactionError):
    """Coldkey is in arbitration."""


class SwapAlreadyScheduled(ChainTransactionError):
    """Swap is already scheduled."""


class FailedToSchedule(ChainTransactionError):
    """Failed to schedule the operation."""


class NewColdKeyIsHotkey(ChainTransactionError):
    """New coldkey is already used as a hotkey."""


class InvalidChildkeyTake(ChainTransactionError):
    """Invalid childkey take value."""


class TxChildkeyTakeRateLimitExceeded(ChainTransactionError):
    """Childkey take transaction rate limit exceeded."""


class InvalidIdentity(ChainTransactionError):
    """Invalid identity data."""


class MechanismDoesNotExist(ChainTransactionError):
    """The mechanism does not exist."""


class CannotUnstakeLock(ChainTransactionError):
    """Cannot unstake a locked stake."""


class TooManyUnrevealedCommits(ChainTransactionError):
    """Too many unrevealed weight commits."""


class ExpiredWeightCommit(ChainTransactionError):
    """Weight commit has expired."""


class RevealTooEarly(ChainTransactionError):
    """Weight reveal is too early."""


class InputLengthsUnequal(ChainTransactionError):
    """Input lengths are unequal."""


class CommittingWeightsTooFast(ChainTransactionError):
    """Committing weights too fast (rate limited)."""


class AmountTooLow(ChainTransactionError):
    """Amount is too low."""


class InsufficientLiquidity(ChainTransactionError):
    """Insufficient liquidity for the operation."""


class SlippageTooHigh(ChainTransactionError):
    """Slippage is too high."""


class TransferDisallowed(ChainTransactionError):
    """Transfer is disallowed."""


class ActivityCutoffTooLow(ChainTransactionError):
    """Activity cutoff is too low."""


class CallDisabled(ChainTransactionError):
    """Call is disabled."""


class FirstEmissionBlockNumberAlreadySet(ChainTransactionError):
    """First emission block number is already set."""


class NeedWaitingMoreBlocksToStarCall(ChainTransactionError):
    """Need to wait more blocks to start call."""


class NotEnoughAlphaOutToRecycle(ChainTransactionError):
    """Not enough alpha out to recycle."""


class CannotBurnOrRecycleOnRootSubnet(ChainTransactionError):
    """Cannot burn or recycle on root subnet."""


class UnableToRecoverPublicKey(ChainTransactionError):
    """Unable to recover public key."""


class InvalidRecoveredPublicKey(ChainTransactionError):
    """Invalid recovered public key."""


class SubtokenDisabled(ChainTransactionError):
    """Subtoken is disabled."""


class HotKeySwapOnSubnetIntervalNotPassed(ChainTransactionError):
    """Hotkey swap on subnet interval has not passed."""


class ZeroMaxStakeAmount(ChainTransactionError):
    """Max stake amount cannot be zero."""


class SameNetuid(ChainTransactionError):
    """Source and destination netuid are the same."""


class InsufficientBalance(ChainTransactionError):
    """Insufficient balance for the operation."""


class StakingOperationRateLimitExceeded(ChainTransactionError):
    """Staking operation rate limit exceeded."""


class InvalidLeaseBeneficiary(ChainTransactionError):
    """Invalid lease beneficiary."""


class InvalidBeneficiaryShare(ChainTransactionError):
    """Invalid beneficiary share percentage."""


class InsufficientBeneficiaryContribution(ChainTransactionError):
    """Insufficient beneficiary contribution."""


class CrowdloanCapBelowLockCost(ChainTransactionError):
    """Crowdloan cap is below lock cost."""


class LeaseCannotEndInThePast(ChainTransactionError):
    """Lease cannot end in the past."""


class LeaseNetuidNotFound(ChainTransactionError):
    """Lease netuid not found."""


class LeaseDoesNotExist(ChainTransactionError):
    """Lease does not exist."""


class LeaseHasNoEndBlock(ChainTransactionError):
    """Lease has no end block."""


class LeaseHasNotEnded(ChainTransactionError):
    """Lease has not ended yet."""


class Overflow(ChainTransactionError):
    """Arithmetic overflow."""


class BeneficiaryDoesNotOwnHotkey(ChainTransactionError):
    """Beneficiary does not own the hotkey."""


class ExpectedBeneficiaryOrigin(ChainTransactionError):
    """Expected beneficiary origin."""


class AdminActionProhibitedDuringWeightsWindow(ChainTransactionError):
    """Admin action prohibited during weights window."""


class SymbolDoesNotExist(ChainTransactionError):
    """Symbol does not exist."""


class SymbolAlreadyInUse(ChainTransactionError):
    """Symbol is already in use."""


class IncorrectCommitRevealVersion(ChainTransactionError):
    """Incorrect commit-reveal version."""


class RevealPeriodTooLarge(ChainTransactionError):
    """Reveal period is too large."""


class RevealPeriodTooSmall(ChainTransactionError):
    """Reveal period is too small."""


class InvalidValue(ChainTransactionError):
    """Invalid value."""


class SubnetLimitReached(ChainTransactionError):
    """Subnet limit reached."""


class CannotAffordLockCost(ChainTransactionError):
    """Cannot afford the lock cost."""


class EvmKeyAssociateRateLimitExceeded(ChainTransactionError):
    """EVM key association rate limit exceeded."""


class SameAutoStakeHotkeyAlreadySet(ChainTransactionError):
    """Same auto-stake hotkey is already set."""


class UidMapCouldNotBeCleared(ChainTransactionError):
    """UID map could not be cleared."""


class TrimmingWouldExceedMaxImmunePercentage(ChainTransactionError):
    """Trimming would exceed maximum immune percentage."""


class ChildParentInconsistency(ChainTransactionError):
    """Child-parent relationship inconsistency."""


class InvalidNumRootClaim(ChainTransactionError):
    """Invalid number of root claims."""


class InvalidRootClaimThreshold(ChainTransactionError):
    """Invalid root claim threshold."""


class InvalidSubnetNumber(ChainTransactionError):
    """Invalid subnet number."""


class PrecisionLoss(ChainTransactionError):
    """Precision loss in calculation."""


class SubnetPaused(ChainTransactionError):
    """Subnet is paused."""


class ForceTerminationNotRequested(ChainTransactionError):
    """Force termination has not been requested."""


class ForceTerminationNoticePeriodNotElapsed(ChainTransactionError):
    """Force termination notice period has not elapsed."""


class ForceTerminationAlreadyRequested(ChainTransactionError):
    """Force termination has already been requested."""


class NoForceTerminationToVeto(ChainTransactionError):
    """No force termination to veto."""


class NotALeaseShareholder(ChainTransactionError):
    """Caller is not a lease shareholder."""


class AlreadyVetoed(ChainTransactionError):
    """Already vetoed the force termination."""


class InsufficientLeaseShares(ChainTransactionError):
    """Insufficient lease shares for transfer."""


class CannotTransferSharesToSelf(ChainTransactionError):
    """Cannot transfer lease shares to self."""


class ZeroShareTransfer(ChainTransactionError):
    """Cannot transfer zero shares."""


class ForceTerminationPending(ChainTransactionError):
    """Force termination is pending."""


class LockCostExceedsTolerance(ChainTransactionError):
    """Lock cost exceeds tolerance."""


class MaxLeaseShareholdersReached(ChainTransactionError):
    """Maximum number of lease shareholders reached."""


# --- Crowdloan pallet errors ---


class DepositTooLow(ChainTransactionError):
    """Crowdloan deposit is too low."""


class CapTooLow(ChainTransactionError):
    """Crowdloan cap is too low."""


class MinimumContributionTooLow(ChainTransactionError):
    """Minimum contribution is too low."""


class CannotEndInPast(ChainTransactionError):
    """Crowdloan cannot end in the past."""


class BlockDurationTooShort(ChainTransactionError):
    """Block duration is too short."""


class BlockDurationTooLong(ChainTransactionError):
    """Block duration is too long."""


class InvalidCrowdloanId(ChainTransactionError):
    """Invalid crowdloan ID."""


class CapRaised(ChainTransactionError):
    """Crowdloan cap has been raised."""


class ContributionPeriodEnded(ChainTransactionError):
    """Contribution period has ended."""


class ContributionTooLow(ChainTransactionError):
    """Contribution is too low."""


class InvalidOrigin(ChainTransactionError):
    """Invalid origin for the operation."""


class AlreadyFinalized(ChainTransactionError):
    """Crowdloan is already finalized."""


class ContributionPeriodNotEnded(ChainTransactionError):
    """Contribution period has not ended."""


class NoContribution(ChainTransactionError):
    """No contribution found."""


class CapNotRaised(ChainTransactionError):
    """Crowdloan cap was not raised."""


class Underflow(ChainTransactionError):
    """Arithmetic underflow."""


class CallUnavailable(ChainTransactionError):
    """Call is unavailable."""


class NotReadyToDissolve(ChainTransactionError):
    """Crowdloan is not ready to dissolve."""


class DepositCannotBeWithdrawn(ChainTransactionError):
    """Deposit cannot be withdrawn."""


class MaxContributorsReached(ChainTransactionError):
    """Maximum contributors reached."""


class GracePeriodExpired(ChainTransactionError):
    """Grace period has expired."""


class TooManyActiveCrowdloans(ChainTransactionError):
    """Too many active crowdloans."""


class AutoRefundInProgress(ChainTransactionError):
    """Auto-refund is in progress."""


class CapRecentlyUpdated(ChainTransactionError):
    """Cap was recently updated."""


class CapReductionExcessive(ChainTransactionError):
    """Cap reduction is excessive."""


class ParametersLocked(ChainTransactionError):
    """Parameters are locked."""


class EndBlockCannotBeShortened(ChainTransactionError):
    """End block cannot be shortened."""


class TargetAddressAndCallConflict(ChainTransactionError):
    """Target address and call conflict."""


class CrowdloanFrozen(ChainTransactionError):
    """Crowdloan is frozen."""


class ChainQueryError(ChainError):
    """Error for any chain query related errors."""


class InvalidRequestNameError(Exception):
    """This exception is raised when the request name is invalid. Usually indicates a broken URL."""


class SynapseException(Exception):
    def __init__(
        self, message="Synapse Exception", synapse: Optional["Synapse"] = None
    ):
        self.message = message
        self.synapse = synapse
        super().__init__(self.message)


class UnknownSynapseError(SynapseException):
    """This exception is raised when the request name is not found in the Axon's forward_fns dictionary."""


class SynapseParsingError(Exception):
    """This exception is raised when the request headers are unable to be parsed into the synapse type."""


class NotVerifiedException(SynapseException):
    """This exception is raised when the request is not verified."""


class BlacklistedException(SynapseException):
    """This exception is raised when the request is blacklisted."""


class PriorityException(SynapseException):
    """This exception is raised when the request priority is not met."""


class PostProcessException(SynapseException):
    """This exception is raised when the response headers cannot be updated."""


class RunException(SynapseException):
    """This exception is raised when the requested function cannot be executed. Indicates a server error."""


class InternalServerError(SynapseException):
    """This exception is raised when the requested function fails on the server. Indicates a server error."""


class SynapseDendriteNoneException(SynapseException):
    def __init__(
        self,
        message="Synapse Dendrite is None",
        synapse: Optional["Synapse"] = None,
    ):
        self.message = message
        super().__init__(self.message, synapse)
