"""
The AdminUtils module contains administrative functions that can modify core network parameters. These functions now
operate through governance origins rather than direct sudo access, meaning parameter changes must be approved through
the appropriate governance track before taking effect.

Note:
    Functions that previously required sudo now require the appropriate governance origin (e.g., Root, ParameterCritical,
    ParameterStandard). The `sudo_` prefix has been removed from function names to reflect this change.
"""

from dataclasses import dataclass
from typing import Optional

from .base import CallBuilder as _BasePallet, Call


@dataclass
class AdminUtils(_BasePallet):
    """Factory class for creating GenericCall objects for AdminUtils pallet functions.

    This class provides methods to create GenericCall instances for all AdminUtils pallet extrinsics. These functions
    now go through governance origins instead of requiring direct sudo access.

    Works with both sync (Meshtensor) and async (AsyncMeshtensor) instances. For async operations, pass an AsyncMeshtensor
    instance and await the result.

    Example:
        # Sync usage
        call = AdminUtils(meshtensor).set_default_take(default_take=100)
        response = meshtensor.sign_and_send_extrinsic(call=call, ...)

        # Async usage
        call = await AdminUtils(async_meshtensor).set_default_take(default_take=100)
        response = await async_meshtensor.sign_and_send_extrinsic(call=call, ...)
    """

    def swap_authorities(
        self,
        new_authorities: list[str],
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function swap_authorities.

        Sets the new authorities for Aura consensus.
        Requires Root governance origin.

        Parameters:
            new_authorities: List of new authority identifiers.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(new_authorities=new_authorities)

    def set_default_take(
        self,
        default_take: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_default_take.

        Sets the default take for the network.
        Requires Root governance origin.

        Parameters:
            default_take: The default take value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(default_take=default_take)

    def set_tx_rate_limit(
        self,
        tx_rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_tx_rate_limit.

        Sets the transaction rate limit for the network.
        Requires Root governance origin.

        Parameters:
            tx_rate_limit: The transaction rate limit (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(tx_rate_limit=tx_rate_limit)

    def set_serving_rate_limit(
        self,
        netuid: int,
        serving_rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_serving_rate_limit.

        Sets the serving rate limit for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            serving_rate_limit: The serving rate limit (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            serving_rate_limit=serving_rate_limit,
        )

    def set_min_difficulty(
        self,
        netuid: int,
        min_difficulty: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_difficulty.

        Sets the minimum difficulty for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            min_difficulty: The minimum difficulty value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            min_difficulty=min_difficulty,
        )

    def set_max_difficulty(
        self,
        netuid: int,
        max_difficulty: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_difficulty.

        Sets the maximum difficulty for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            max_difficulty: The maximum difficulty value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            max_difficulty=max_difficulty,
        )

    def set_weights_version_key(
        self,
        netuid: int,
        weights_version_key: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_weights_version_key.

        Sets the weights version key for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            weights_version_key: The weights version key (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            weights_version_key=weights_version_key,
        )

    def set_weights_set_rate_limit(
        self,
        netuid: int,
        weights_set_rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_weights_set_rate_limit.

        Sets the weights set rate limit for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            weights_set_rate_limit: The weights set rate limit (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            weights_set_rate_limit=weights_set_rate_limit,
        )

    def set_adjustment_interval(
        self,
        netuid: int,
        adjustment_interval: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_adjustment_interval.

        Sets the adjustment interval for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            adjustment_interval: The adjustment interval (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            adjustment_interval=adjustment_interval,
        )

    def set_adjustment_alpha(
        self,
        netuid: int,
        adjustment_alpha: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_adjustment_alpha.

        Sets the adjustment alpha for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            adjustment_alpha: The adjustment alpha value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            adjustment_alpha=adjustment_alpha,
        )

    def set_immunity_period(
        self,
        netuid: int,
        immunity_period: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_immunity_period.

        Sets the immunity period for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            immunity_period: The immunity period (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            immunity_period=immunity_period,
        )

    def set_min_allowed_weights(
        self,
        netuid: int,
        min_allowed_weights: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_allowed_weights.

        Sets the minimum allowed weights for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            min_allowed_weights: The minimum allowed weights (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            min_allowed_weights=min_allowed_weights,
        )

    def set_max_allowed_uids(
        self,
        netuid: int,
        max_allowed_uids: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_allowed_uids.

        Sets the maximum allowed UIDs for a subnet.
        Requires ParameterCritical governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            max_allowed_uids: The maximum allowed UIDs (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            max_allowed_uids=max_allowed_uids,
        )

    def set_kappa(
        self,
        netuid: int,
        kappa: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_kappa.

        Sets the kappa for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            kappa: The kappa value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, kappa=kappa)

    def set_rho(
        self,
        netuid: int,
        rho: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_rho.

        Sets the rho for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            rho: The rho value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, rho=rho)

    def set_activity_cutoff(
        self,
        netuid: int,
        activity_cutoff: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_activity_cutoff.

        Sets the activity cutoff for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            activity_cutoff: The activity cutoff value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            activity_cutoff=activity_cutoff,
        )

    def set_network_registration_allowed(
        self,
        netuid: int,
        registration_allowed: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_network_registration_allowed.

        Sets the network registration allowed for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            registration_allowed: Whether registration is allowed (bool).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            registration_allowed=registration_allowed,
        )

    def set_network_pow_registration_allowed(
        self,
        netuid: int,
        registration_allowed: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_network_pow_registration_allowed.

        Sets the network PoW registration allowed for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            registration_allowed: Whether PoW registration is allowed (bool).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            registration_allowed=registration_allowed,
        )

    def set_target_registrations_per_interval(
        self,
        netuid: int,
        target_registrations_per_interval: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_target_registrations_per_interval.

        Sets the target registrations per interval for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            target_registrations_per_interval: The target registrations per interval (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            target_registrations_per_interval=target_registrations_per_interval,
        )

    def set_min_burn(
        self,
        netuid: int,
        min_burn: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_burn.

        Sets the minimum burn for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            min_burn: The minimum burn value in MESHLET (MeshCurrency).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, min_burn=min_burn)

    def set_max_burn(
        self,
        netuid: int,
        max_burn: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_burn.

        Sets the maximum burn for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            max_burn: The maximum burn value in MESHLET (MeshCurrency).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, max_burn=max_burn)

    def set_difficulty(
        self,
        netuid: int,
        difficulty: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_difficulty.

        Sets the difficulty for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            difficulty: The difficulty value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, difficulty=difficulty)

    def set_max_allowed_validators(
        self,
        netuid: int,
        max_allowed_validators: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_allowed_validators.

        Sets the maximum allowed validators for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            max_allowed_validators: The maximum allowed validators (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            max_allowed_validators=max_allowed_validators,
        )

    def set_bonds_moving_average(
        self,
        netuid: int,
        bonds_moving_average: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_bonds_moving_average.

        Sets the bonds moving average for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            bonds_moving_average: The bonds moving average value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            bonds_moving_average=bonds_moving_average,
        )

    def set_bonds_penalty(
        self,
        netuid: int,
        bonds_penalty: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_bonds_penalty.

        Sets the bonds penalty for a subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            bonds_penalty: The bonds penalty value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            bonds_penalty=bonds_penalty,
        )

    def set_max_registrations_per_block(
        self,
        netuid: int,
        max_registrations_per_block: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_registrations_per_block.

        Sets the maximum registrations per block for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            max_registrations_per_block: The maximum registrations per block (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            max_registrations_per_block=max_registrations_per_block,
        )

    def set_subnet_owner_cut(
        self,
        subnet_owner_cut: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_subnet_owner_cut.

        Sets the subnet owner cut for a subnet.
        Requires Root governance origin.

        Parameters:
            subnet_owner_cut: The subnet owner cut value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(subnet_owner_cut=subnet_owner_cut)

    def set_network_rate_limit(
        self,
        rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_network_rate_limit.

        Sets the network rate limit for the network.
        Requires Root governance origin.

        Parameters:
            rate_limit: The network rate limit (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(rate_limit=rate_limit)

    def set_tempo(
        self,
        netuid: int,
        tempo: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_tempo.

        Sets the tempo for a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            tempo: The tempo value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, tempo=tempo)

    def set_total_issuance(
        self,
        total_issuance: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_total_issuance.

        Sets the total issuance for the network.
        Requires Root governance origin.

        Parameters:
            total_issuance: The total issuance value in MESHLET (MeshCurrency).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(total_issuance=total_issuance)

    def set_network_immunity_period(
        self,
        immunity_period: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_network_immunity_period.

        Sets the immunity period for the network.
        Requires Root governance origin.

        Parameters:
            immunity_period: The immunity period (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(immunity_period=immunity_period)

    def set_network_min_lock_cost(
        self,
        lock_cost: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_network_min_lock_cost.

        Sets the min lock cost for the network.
        Requires Root governance origin.

        Parameters:
            lock_cost: The lock cost value in MESHLET (MeshCurrency).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(lock_cost=lock_cost)

    def set_subnet_limit(
        self,
        max_subnets: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_subnet_limit.

        Sets the subnet limit for the network.
        Requires Root governance origin.

        Parameters:
            max_subnets: The maximum number of subnets (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(max_subnets=max_subnets)

    def set_lock_reduction_interval(
        self,
        interval: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_lock_reduction_interval.

        Sets the lock reduction interval for the network.
        Requires Root governance origin.

        Parameters:
            interval: The lock reduction interval (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(interval=interval)

    def set_meshlet_recycled(
        self,
        netuid: int,
        meshlet_recycled: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_meshlet_recycled.

        Sets the recycled MESHLET for a subnet.
        Requires ParameterStandard governance origin.

        Parameters:
            netuid: The network identifier.
            meshlet_recycled: The recycled MESHLET value (MeshCurrency).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, meshlet_recycled=meshlet_recycled)

    def set_stake_threshold(
        self,
        min_stake: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_stake_threshold.

        Sets the weights min stake.
        Requires Root governance origin.

        Parameters:
            min_stake: The minimum stake value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(min_stake=min_stake)

    def set_nominator_min_required_stake(
        self,
        min_stake: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_nominator_min_required_stake.

        Sets the minimum stake required for nominators.
        Requires Root governance origin.

        Parameters:
            min_stake: The minimum stake required for nominators (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(min_stake=min_stake)

    def set_tx_delegate_take_rate_limit(
        self,
        tx_rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_tx_delegate_take_rate_limit.

        Sets the rate limit for delegate take transactions.
        Requires Root governance origin.

        Parameters:
            tx_rate_limit: The transaction rate limit (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(tx_rate_limit=tx_rate_limit)

    def set_min_delegate_take(
        self,
        take: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_delegate_take.

        Sets the minimum delegate take.
        Requires Root governance origin.

        Parameters:
            take: The minimum delegate take value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(take=take)

    def set_commit_reveal_weights_enabled(
        self,
        netuid: int,
        enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_commit_reveal_weights_enabled.

        Enables/disables commit/reveal for a given subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            enabled: Whether commit/reveal weights is enabled (bool).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, enabled=enabled)

    def set_liquid_alpha_enabled(
        self,
        netuid: int,
        enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_liquid_alpha_enabled.

        Enables or disables Liquid Alpha for a given subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier for the subnet.
            enabled: A boolean flag to enable or disable Liquid Alpha.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, enabled=enabled)

    def set_alpha_values(
        self,
        netuid: int,
        alpha_low: int,
        alpha_high: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_alpha_values.

        Sets values for liquid alpha.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The network identifier.
            alpha_low: The low alpha value (u16).
            alpha_high: The high alpha value (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            alpha_low=alpha_low,
            alpha_high=alpha_high,
        )

    def set_coldkey_swap_schedule_duration(
        self,
        duration: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_coldkey_swap_schedule_duration.

        Sets the duration of the coldkey swap schedule.
        Requires Root governance origin.

        Parameters:
            duration: The new duration for the coldkey swap schedule, in number of blocks.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(duration=duration)

    def set_dissolve_network_schedule_duration(
        self,
        duration: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_dissolve_network_schedule_duration.

        Sets the duration of the dissolve network schedule.
        Requires Root governance origin.

        Parameters:
            duration: The new duration for the dissolve network schedule, in number of blocks.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(duration=duration)

    def set_commit_reveal_weights_interval(
        self,
        netuid: int,
        interval: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_commit_reveal_weights_interval.

        Sets the commit-reveal weights periods for a specific subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier of the subnet for which the periods are being set.
            interval: The number of epochs that define the commit-reveal period.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, interval=interval)

    def set_evm_chain_id(
        self,
        chain_id: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_evm_chain_id.

        Sets the EVM ChainID.
        Requires Root governance origin.

        Parameters:
            chain_id: The u64 chain ID.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(chain_id=chain_id)

    def schedule_grandpa_change(
        self,
        next_authorities: list[tuple],
        in_blocks: int,
        forced: Optional[int] = None,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function schedule_grandpa_change.

        Schedule a change in the authorities.
        Requires Root governance origin.

        The change will be applied at the end of execution of the block `in_blocks` after the
        current block. This value may be 0, in which case the change is applied at the end of
        the current block.

        If the `forced` parameter is defined, this indicates that the current set has been
        synchronously determined to be offline and that after `in_blocks` the given change
        should be applied.

        Parameters:
            next_authorities: The list of next authorities (AuthorityList).
            in_blocks: The number of blocks after which the change is applied.
            forced: Optional block number for forced change.

        Returns:
            GenericCall instance.
        """
        params = {
            "next_authorities": next_authorities,
            "in_blocks": in_blocks,
        }
        if forced is not None:
            params["forced"] = forced
        return self.create_composed_call(**params)

    def set_toggle_transfer(
        self,
        netuid: int,
        toggle: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_toggle_transfer.

        Enable or disable atomic alpha transfers for a given subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier for the subnet.
            toggle: A boolean flag to enable or disable transfers.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, toggle=toggle)

    def set_recycle_or_burn(
        self,
        netuid: int,
        recycle_or_burn: str,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_recycle_or_burn.

        Set the behaviour of the "burn" UID(s) for a given subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier for the subnet.
            recycle_or_burn: The desired behaviour of the "burn" UID(s) for the subnet.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            recycle_or_burn=recycle_or_burn,
        )

    def toggle_evm_precompile(
        self,
        precompile_id: str,
        enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function toggle_evm_precompile.

        Toggles the enablement of an EVM precompile.
        Requires Root governance origin.

        Parameters:
            precompile_id: The identifier of the EVM precompile to toggle.
            enabled: The new enablement state of the precompile.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            precompile_id=precompile_id,
            enabled=enabled,
        )

    def set_subnet_moving_alpha(
        self,
        alpha: dict,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_subnet_moving_alpha.

        Sets the new moving alpha value for the SubnetMovingAlpha.
        Requires ParameterCritical governance origin.

        Parameters:
            alpha: The new moving alpha value (I96F32).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(alpha=alpha)

    def set_subnet_owner_hotkey(
        self,
        netuid: int,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_subnet_owner_hotkey.

        Change the SubnetOwnerHotkey for a given subnet.
        Requires Root governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier for the subnet.
            hotkey: The new hotkey for the subnet owner.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, hotkey=hotkey)

    def set_ema_price_halving_period(
        self,
        netuid: int,
        ema_halving: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_ema_price_halving_period.

        Sets the number of blocks for EMA price to halve.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The unique identifier for the subnet.
            ema_halving: Number of blocks for EMA price to halve.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, ema_halving=ema_halving)

    def set_alpha_sigmoid_steepness(
        self,
        netuid: int,
        steepness: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_alpha_sigmoid_steepness.

        Sets the Steepness for the alpha sigmoid function.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The unique identifier for the subnet.
            steepness: The Steepness for the alpha sigmoid function. (range is 0-int16::MAX,
                negative values are reserved for future use).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, steepness=steepness)

    def set_yuma3_enabled(
        self,
        netuid: int,
        enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_yuma3_enabled.

        Enables or disables Yuma3 for a given subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The unique identifier for the subnet.
            enabled: A boolean flag to enable or disable Yuma3.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, enabled=enabled)

    def set_bonds_reset_enabled(
        self,
        netuid: int,
        enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_bonds_reset_enabled.

        Enables or disables Bonds Reset for a given subnet.
        Requires ParameterStandard governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier for the subnet.
            enabled: A boolean flag to enable or disable Bonds Reset.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, enabled=enabled)

    def set_sn_owner_hotkey(
        self,
        netuid: int,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_sn_owner_hotkey.

        Sets or updates the hotkey account associated with the owner of a specific subnet.
        Requires Root governance origin or subnet owner.

        Parameters:
            netuid: The unique identifier of the subnet whose owner hotkey is being set.
            hotkey: The new hotkey account to associate with the subnet owner.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, hotkey=hotkey)

    def set_subtoken_enabled(
        self,
        netuid: int,
        subtoken_enabled: bool,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_subtoken_enabled.

        Enables or disables subtoken trading for a given subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The unique identifier of the subnet.
            subtoken_enabled: A boolean indicating whether subtoken trading should be enabled or disabled.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            subtoken_enabled=subtoken_enabled,
        )

    def set_commit_reveal_version(
        self,
        version: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_commit_reveal_version.

        Sets the commit-reveal weights version for all subnets.
        Requires Root governance origin.

        Parameters:
            version: The commit-reveal weights version (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(version=version)

    def set_owner_immune_neuron_limit(
        self,
        netuid: int,
        immune_neurons: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_owner_immune_neuron_limit.

        Sets the number of immune owner neurons.
        Requires ParameterStandard governance origin.

        Parameters:
            netuid: The network identifier.
            immune_neurons: The number of immune owner neurons (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            immune_neurons=immune_neurons,
        )

    def set_ck_burn(
        self,
        burn: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_ck_burn.

        Sets the childkey burn for a subnet.
        Requires Root governance origin.

        Parameters:
            burn: The childkey burn value (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(burn=burn)

    def set_admin_freeze_window(
        self,
        window: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_admin_freeze_window.

        Sets the admin freeze window length (in blocks) at the end of a tempo.
        Requires Root governance origin.

        Parameters:
            window: The admin freeze window length in blocks (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(window=window)

    def set_owner_hparam_rate_limit(
        self,
        epochs: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_owner_hparam_rate_limit.

        Sets the owner hyperparameter rate limit in epochs (global multiplier).
        Requires Root governance origin.

        Parameters:
            epochs: The owner hyperparameter rate limit in epochs (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(epochs=epochs)

    def set_mechanism_count(
        self,
        netuid: int,
        mechanism_count: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_mechanism_count.

        Sets the desired number of mechanisms in a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            mechanism_count: The desired number of mechanisms (MechId).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            mechanism_count=mechanism_count,
        )

    def set_mechanism_emission_split(
        self,
        netuid: int,
        maybe_split: Optional[list[int]] = None,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_mechanism_emission_split.

        Sets the emission split between mechanisms in a subnet.
        Requires ParameterCritical governance origin.

        Parameters:
            netuid: The network identifier.
            maybe_split: Optional list of emission split values (Option<Vec<u16>>).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, maybe_split=maybe_split)

    def trim_to_max_allowed_uids(
        self,
        netuid: int,
        max_n: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function trim_to_max_allowed_uids.

        Trims the maximum number of UIDs for a subnet.
        Requires Root governance origin.

        The trimming is done by sorting the UIDs by emission descending and then trimming
        the lowest emitters while preserving temporally and owner immune UIDs.

        Parameters:
            netuid: The network identifier.
            max_n: The maximum number of UIDs (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, max_n=max_n)

    def set_min_allowed_uids(
        self,
        netuid: int,
        min_allowed_uids: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_allowed_uids.

        Sets the minimum allowed UIDs for a subnet.
        Requires Root governance origin.

        Parameters:
            netuid: The network identifier.
            min_allowed_uids: The minimum allowed UIDs (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            min_allowed_uids=min_allowed_uids,
        )

    def set_mesh_flow_cutoff(
        self,
        flow_cutoff: dict,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_mesh_flow_cutoff.

        Sets MESH flow cutoff value (A).
        Requires ParameterCritical governance origin.

        Parameters:
            flow_cutoff: The MESH flow cutoff value (I64F64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(flow_cutoff=flow_cutoff)

    def set_mesh_flow_normalization_exponent(
        self,
        exponent: dict,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_mesh_flow_normalization_exponent.

        Sets MESH flow normalization exponent (p).
        Requires ParameterCritical governance origin.

        Parameters:
            exponent: The MESH flow normalization exponent (U64F64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(exponent=exponent)

    def set_mesh_flow_smoothing_factor(
        self,
        smoothing_factor: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_mesh_flow_smoothing_factor.

        Sets MESH flow smoothing factor (alpha).
        Requires ParameterCritical governance origin.

        Parameters:
            smoothing_factor: The MESH flow smoothing factor (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(smoothing_factor=smoothing_factor)

    def set_min_non_immune_uids(
        self,
        netuid: int,
        min: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_non_immune_uids.

        Sets the minimum number of non-immune UIDs for a subnet.
        Requires ParameterStandard governance origin.

        Parameters:
            netuid: The network identifier.
            min: The minimum non-immune UIDs (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, min=min)

    def set_start_call_delay(
        self,
        delay: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_start_call_delay.

        Sets the delay before a subnet can call start.
        Requires ParameterStandard governance origin.

        Parameters:
            delay: The delay in blocks (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(delay=delay)

    def pause_subnet(
        self,
        netuid: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function pause_subnet.

        Pauses a specific subnet (circuit breaker). While paused, the subnet rejects
        registration, set_weights, serve_axon, and new staking. Unstaking remains allowed.
        Requires Emergency governance origin (Technical Committee).

        Parameters:
            netuid: The subnet identifier (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid)

    def resume_subnet(
        self,
        netuid: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function resume_subnet.

        Resumes a paused subnet.
        Requires Root governance origin.

        Parameters:
            netuid: The subnet identifier (u16).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid)

    def slash_validator(
        self,
        validator: str,
        amount: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function slash_validator.

        Slashes a validator's balance via governance vote. The slashed amount is burned.
        Requires Root governance origin.

        Parameters:
            validator: The validator AccountId (SS58 address).
            amount: The amount to slash (u64).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(validator=validator, amount=amount)

    def set_max_registrations_per_interval(
        self,
        max_registrations: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_registrations_per_interval.

        Sets the maximum registrations per interval (global).
        Requires ParameterCritical governance origin.

        Parameters:
            max_registrations: The maximum registrations per interval (u16, >= 1).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(max_registrations=max_registrations)

    def set_max_beneficiary_share(
        self,
        max_share: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_max_beneficiary_share.

        Sets the maximum beneficiary share percentage for leased subnets.
        Requires ParameterCritical governance origin.

        Parameters:
            max_share: The maximum share percentage (u8, 1-50).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(max_share=max_share)

    def set_min_beneficiary_contribution(
        self,
        min_contribution: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_min_beneficiary_contribution.

        Sets the minimum beneficiary contribution percentage for leased subnets.
        Requires ParameterCritical governance origin.

        Parameters:
            min_contribution: The minimum contribution percentage (u8, 10-100).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(min_contribution=min_contribution)

    def set_crowdloan_lock_cost_multiplier(
        self,
        multiplier: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_crowdloan_lock_cost_multiplier.

        Sets the crowdloan lock cost multiplier.
        Requires ParameterCritical governance origin.

        Parameters:
            multiplier: The lock cost multiplier (u8, 1-10).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(multiplier=multiplier)

    def set_crowdloan_grace_period(
        self,
        grace_period: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_crowdloan_grace_period.

        Sets the crowdloan grace period in blocks.
        Requires ParameterCritical governance origin.

        Parameters:
            grace_period: The grace period in blocks (BlockNumber, 50400-648000).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(grace_period=grace_period)

    def set_force_termination_veto_threshold(
        self,
        threshold: int,
    ) -> Call:
        """Returns GenericCall instance for AdminUtils function set_force_termination_veto_threshold.

        Sets the force termination veto threshold percentage.
        Requires ParameterCritical governance origin.

        Parameters:
            threshold: The veto threshold percentage (u8, 51-80).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(threshold=threshold)
