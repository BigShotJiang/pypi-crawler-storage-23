from dataclasses import dataclass
from typing import Literal, Optional, Union

from meshtensor.core.types import UIDs, Weights, Salt
from meshtensor.utils import Certificate
from .base import CallBuilder as _BasePallet, Call


@dataclass
class MeshtensorModule(_BasePallet):
    """Factory class for creating GenericCall objects for MeshtensorModule pallet functions.

    This class provides methods to create GenericCall instances for all MeshtensorModule pallet extrinsics.

    Works with both sync (Meshtensor) and async (AsyncMeshtensor) instances. For async operations, pass an AsyncMeshtensor
    instance and await the result.

    Example:
        # Sync usage
        call = MeshtensorModule(meshtensor).start_call(netuid=14)
        response = meshtensor.sign_and_send_extrinsic(call=call, ...)

        # Async usage
        call = await MeshtensorModule(async_meshtensor).start_call(netuid=14)
        response = await async_meshtensor.sign_and_send_extrinsic(call=call, ...)
    """

    def add_stake(
        self,
        netuid: int,
        hotkey: str,
        amount_staked: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.add_stake.

        Parameters:
            netuid: The netuid of the subnet to add stake to.
            hotkey: The hotkey SS58 address associated with validator.
            amount_staked: Amount of stake in MESHLET to add.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            hotkey=hotkey,
            amount_staked=amount_staked,
        )

    def add_stake_limit(
        self,
        netuid: int,
        hotkey: str,
        amount_staked: int,
        limit_price: float,
        allow_partial: bool,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.add_stake_limit.

        Parameters:
            netuid: The netuid of the subnet to add stake to.
            hotkey: The hotkey SS58 address associated with validator.
            amount_staked: Amount of stake in MESHLET to add.
            limit_price: The limit price expressed in units of MESHLET per one Alpha.
            allow_partial: If True, allows partial unstaking if price tolerance exceeded.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            hotkey=hotkey,
            amount_staked=amount_staked,
            limit_price=limit_price,
            allow_partial=allow_partial,
        )

    def burned_register(
        self,
        netuid: int,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.burned_register.

        Parameters:
            netuid: The netuid of the subnet to register on.
            hotkey: The hotkey SS58 address associated with the neuron.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, hotkey=hotkey)

    def claim_root(self, subnets: list[int]) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.claim_root.

        Parameters:
            subnets: The netuids of the subnets to claim root for. Think about it as netuids.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(subnets=subnets)

    def commit_mechanism_weights(
        self,
        netuid: int,
        mecid: int,
        commit_hash: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.commit_mechanism_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            mecid: The subnet mechanism unique identifier.
            commit_hash: The hash of the commitment.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid, mecid=mecid, commit_hash=commit_hash
        )

    def commit_timelocked_mechanism_weights(
        self,
        netuid: int,
        mecid: int,
        commit: bytes,
        reveal_round: int,
        commit_reveal_version: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.commit_timelocked_mechanism_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            mecid: The subnet mechanism unique identifier.
            commit: Raw bytes of the encrypted and compressed uids & weights values for setting weights.
            reveal_round: Drand round number when weights have to be revealed. Based on Drand Quicknet network.
            commit_reveal_version: The version of the commit-reveal in the chain.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            mecid=mecid,
            commit=commit,
            reveal_round=reveal_round,
            commit_reveal_version=commit_reveal_version,
        )

    def commit_timelocked_weights(
        self,
        netuid: int,
        commit: bytes,
        reveal_round: int,
        commit_reveal_version: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.commit_timelocked_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            commit: Raw bytes of the encrypted and compressed uids & weights values for setting weights.
            reveal_round: Drand round number when weights have to be revealed. Based on Drand Quicknet network.
            commit_reveal_version: The version of the commit-reveal in the chain.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            commit=commit,
            reveal_round=reveal_round,
            commit_reveal_version=commit_reveal_version,
        )

    def commit_weights(
        self,
        netuid: int,
        commit_hash: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.commit_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            commit_hash: The hash of the commitment.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            commit_hash=commit_hash,
        )

    def reveal_weights(
        self,
        netuid: int,
        uids: UIDs,
        values: Weights,
        salt: Salt,
        version_key: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.reveal_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            uids: List of neuron UIDs for which weights are being revealed.
            values: List of weight values corresponding to each UID.
            salt: The salt used to generate the hash.
            version_key: Version key for compatibility with the network.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            uids=uids,
            values=values,
            salt=salt,
            version_key=version_key,
        )

    def batch_set_weights(
        self,
        netuids: list[int],
        weights: list[list[tuple[int, int]]],
        version_keys: list[int],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.batch_set_weights.

        Parameters:
            netuids: List of subnet unique identifiers.
            weights: List of lists of (uid, weight) tuples for each subnet.
            version_keys: List of version keys for compatibility with the network.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuids=netuids,
            weights=weights,
            version_keys=version_keys,
        )

    def batch_commit_weights(
        self,
        netuids: list[int],
        commit_hashes: list[str],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.batch_commit_weights.

        Parameters:
            netuids: List of subnet unique identifiers.
            commit_hashes: List of weight commitment hashes.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuids=netuids,
            commit_hashes=commit_hashes,
        )

    def batch_reveal_weights(
        self,
        netuid: int,
        uids_list: list[list[int]],
        values_list: list[list[int]],
        salts_list: list[list[int]],
        version_keys: list[int],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.batch_reveal_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            uids_list: List of lists of neuron UIDs for each reveal.
            values_list: List of lists of weight values for each reveal.
            salts_list: List of lists of salt values for each reveal.
            version_keys: List of version keys for each reveal.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            uids_list=uids_list,
            values_list=values_list,
            salts_list=salts_list,
            version_keys=version_keys,
        )

    def decrease_take(self, hotkey: str, take: int) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.decrease_take.

        Parameters:
            hotkey: SS58 address of the hotkey to set take for.
            take: The percentage of rewards that the delegate claims from nominators.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey, take=take)

    def increase_take(self, hotkey: str, take: int) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.increase_take.

        Parameters:
            hotkey: SS58 address of the hotkey to set take for.
            take: The percentage of rewards that the delegate claims from nominators.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey, take=take)

    def move_stake(
        self,
        origin_netuid: int,
        origin_hotkey_ss58: str,
        destination_netuid: int,
        destination_hotkey_ss58: str,
        alpha_amount: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.move_stake.

        Parameters:
            origin_netuid: The netuid of the source subnet.
            origin_hotkey_ss58: The SS58 address of the source hotkey.
            destination_netuid: The netuid of the destination subnet.
            destination_hotkey_ss58: The SS58 address of the destination hotkey.
            alpha_amount: Amount of origin Balance to move.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            origin_netuid=origin_netuid,
            origin_hotkey=origin_hotkey_ss58,
            destination_netuid=destination_netuid,
            destination_hotkey=destination_hotkey_ss58,
            alpha_amount=alpha_amount,
        )

    def register(
        self,
        netuid: int,
        coldkey: str,
        hotkey: str,
        block_number: int,
        nonce: int,
        work: list[int],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.register.

        Parameters:
            netuid: The netuid of the subnet to register on.
            coldkey: The coldkey SS58 address associated with the neuron.
            hotkey: The hotkey SS58 address associated with the neuron.
            block_number: POW block number.
            nonce: POW nonce.
            work: List representation of POW seal.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            coldkey=coldkey,
            hotkey=hotkey,
            block_number=block_number,
            nonce=nonce,
            work=work,
        )

    def register_leased_network(
        self, beneficiary_share: int, end_block: Optional[int]
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.register_leased_network.

        Parameters:
            beneficiary_share: The percentage of emissions allocated to lease beneficiaries (0-100).
            end_block: The block number when the lease ends, or None for perpetual lease.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            beneficiary_share=beneficiary_share, end_block=end_block
        )

    def register_network(self, hotkey: str) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.register_network.

        Parameters:
            hotkey: The hotkey SS58 address associated with the subnet owner.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey)

    def register_network_with_identity(
        self, hotkey: str, identity: Optional[dict] = None
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.register_network_with_identity.

        Parameters:
            hotkey: The hotkey SS58 address associated with the subnet owner.
            identity: Optional subnet identity dict with keys: subnet_name, github_repo,
                subnet_contact, subnet_url, discord, description, logo_url, additional.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey, identity=identity)

    def remove_stake(
        self,
        netuid: int,
        hotkey: str,
        amount_unstaked: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.remove_stake.

        Parameters:
            netuid: The netuid of the subnet to remove stake from.
            hotkey: The hotkey SS58 address associated with validator.
            amount_unstaked: Amount of stake in MESHLET to remove/unstake from the validator.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            hotkey=hotkey,
            amount_unstaked=amount_unstaked,
        )

    def remove_stake_limit(
        self,
        netuid: int,
        hotkey: str,
        amount_unstaked: int,
        limit_price: float,
        allow_partial: bool,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.remove_stake_limit.

        Parameters:
            netuid: The netuid of the subnet to remove stake from.
            hotkey: The hotkey SS58 address associated with validator.
            amount_unstaked: Amount of stake in MESHLET to remove/unstake from the validator.
            limit_price: The limit price expressed in units of MESHLET per one Alpha.
            allow_partial: Allows partial stake execution of the amount.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            hotkey=hotkey,
            amount_unstaked=amount_unstaked,
            limit_price=limit_price,
            allow_partial=allow_partial,
        )

    def remove_stake_full_limit(
        self,
        netuid: int,
        hotkey: str,
        limit_price: Optional[float] = None,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.remove_stake_full_limit.

        Parameters:
            netuid: The netuid of the subnet to remove stake from.
            hotkey: The hotkey SS58 address associated with validator.
            limit_price: The limit price expressed in units of MESHLET per one Alpha.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid, hotkey=hotkey, limit_price=limit_price
        )

    def reveal_mechanism_weights(
        self,
        netuid: int,
        mecid: int,
        uids: UIDs,
        values: Weights,
        salt: Salt,
        version_key: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.reveal_mechanism_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            mecid: The subnet mechanism unique identifier.
            uids: List of neuron UIDs for which weights are being revealed. Think like UIDs.
            values: List of weight values corresponding to each UID. Think like Weights.
            salt: The salt used to generate the hash.
            version_key: Version key for compatibility with the network.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            mecid=mecid,
            uids=uids,
            values=values,
            salt=salt,
            version_key=version_key,
        )

    def root_register(self, hotkey: str) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.root_register.

        Parameters:
            hotkey: The hotkey SS58 address associated with the neuron.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey)

    def serve_axon(
        self,
        netuid: int,
        version: int,
        ip: int,
        port: int,
        ip_type: int,
        protocol: int,
        placeholder1: int = 0,
        placeholder2: int = 0,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.serve_axon.

        Parameters:
            netuid: The network uid to serve on.
            version: The meshtensor version identifier.
            ip: Integer representation of endpoint ip.
            port: Endpoint port number i.e., ``9221``.
            ip_type: The endpoint ip version.
            protocol: An ``int`` representation of the protocol.
            placeholder1: Placeholder for further extra params.
            placeholder2: Placeholder for further extra params.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            version=version,
            ip=ip,
            port=port,
            ip_type=ip_type,
            protocol=protocol,
            placeholder1=placeholder1,
            placeholder2=placeholder2,
        )

    def serve_axon_tls(
        self,
        netuid: int,
        version: int,
        ip: int,
        port: int,
        ip_type: int,
        protocol: int,
        placeholder1: int = 0,
        placeholder2: int = 0,
        certificate: Optional[Certificate] = None,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.serve_axon_tls.

        Parameters:
            netuid: The network uid to serve on.
            version: The meshtensor version identifier.
            ip: Integer representation of endpoint ip.
            port: Endpoint port number i.e., ``9221``.
            ip_type: The endpoint ip version.
            protocol: An ``int`` representation of the protocol.
            placeholder1: Placeholder for further extra params.
            placeholder2: Placeholder for further extra params.
            certificate: Certificate to use for TLS. If ``None``, no TLS will be used.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            version=version,
            ip=ip,
            port=port,
            ip_type=ip_type,
            protocol=protocol,
            placeholder1=placeholder1,
            placeholder2=placeholder2,
            certificate=certificate,
        )

    def set_coldkey_auto_stake_hotkey(self, netuid: int, hotkey: str) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_coldkey_auto_stake_hotkey.

        Parameters:
            netuid: The netuid of the subnet to set auto stake hotkey for.
            hotkey: The hotkey SS58 address associated with the validator neuron.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, hotkey=hotkey)

    def set_children(
        self,
        hotkey: str,
        netuid: int,
        children: list[tuple[float, str]],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_children.

        Parameters:
            hotkey: The hotkey SS58 address associated with the neuron.
            netuid: The netuid of the subnet to set children for.
            children: List of tuples containing the proportion of stake to assign to each child hotkey.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            netuid=netuid,
            children=children,
        )

    def set_mechanism_weights(
        self,
        netuid: int,
        mecid: int,
        dests: UIDs,
        weights: Weights,
        version_key: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_mechanism_weights.

        Parameters:
            netuid: The unique identifier of the subnet.
            mecid: The subnet mechanism unique identifier.
            dests: List of neuron UIDs for which weights are being revealed. Think like UIDs.
            weights: List of weight values corresponding to each UID.
            version_key: Version key for compatibility with the network.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            mecid=mecid,
            dests=dests,
            weights=weights,
            version_key=version_key,
        )

    def set_pending_childkey_cooldown(
        self,
        cooldown: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_pending_childkey_cooldown.

        Parameters:
            cooldown: The pending childkey cooldown period in seconds.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(cooldown=cooldown)

    def set_root_claim_type(
        self,
        new_root_claim_type: Literal["Swap", "Keep"] | dict,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_root_claim_type.

        Parameters:
            new_root_claim_type: The new root claim type. Can be:
                - String: "Swap" or "Keep"
                - Dict: {"KeepSubnets": {"subnets": [1, 2, 3]}}

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(new_root_claim_type=new_root_claim_type)

    def set_subnet_identity(
        self,
        netuid: int,
        subnet_name: str,
        github_repo: str,
        subnet_contact: str,
        subnet_url: str,
        discord: str,
        description: str,
        logo_url: str,
        additional: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_subnet_identity.

        Parameters:
            netuid: The netuid of the subnet to set identity for.
            subnet_name: The name of the subnet.
            github_repo: The GitHub repository URL of the subnet.
            subnet_contact: The contact information of the subnet owner.
            subnet_url: The URL of the subnet.
            logo_url: The URL of the subnet logo.
            discord: The Discord server URL of the subnet.
            description: The description of the subnet.
            additional: Additional information about the subnet.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            subnet_name=subnet_name,
            github_repo=github_repo,
            subnet_contact=subnet_contact,
            subnet_url=subnet_url,
            discord=discord,
            description=description,
            logo_url=logo_url,
            additional=additional,
        )

    def start_call(self, netuid: int) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.start_call.

        Parameters:
            netuid: The netuid of the subnet to to be activated.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid)

    def try_associate_hotkey(self, hotkey: str) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.try_associate_hotkey.

        Parameters:
            hotkey: The hotkey SS58 address to associate with the coldkey.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey)

    def associate_evm_key(
        self,
        netuid: int,
        evm_key: str,
        block_number: int,
        signature: list[int],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.associate_evm_key.

        Parameters:
            netuid: The netuid of the subnet.
            evm_key: The EVM H160 address to associate.
            block_number: The block number for the signature.
            signature: The signature proving ownership of the EVM key.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            evm_key=evm_key,
            block_number=block_number,
            signature=signature,
        )

    def schedule_swap_coldkey(
        self,
        new_coldkey: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.schedule_swap_coldkey.

        Parameters:
            new_coldkey: The SS58 address of the new coldkey.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(new_coldkey=new_coldkey)

    def set_identity(
        self,
        name: str,
        url: str,
        github_repo: str,
        image: str,
        discord: str,
        description: str,
        additional: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_identity.

        Parameters:
            name: The display name for the identity.
            url: The URL associated with the identity.
            github_repo: The GitHub repository URL.
            image: The image URL for the identity.
            discord: The Discord contact information.
            description: A description of the identity.
            additional: Any additional metadata.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            name=name,
            url=url,
            github_repo=github_repo,
            image=image,
            discord=discord,
            description=description,
            additional=additional,
        )

    def swap_hotkey(
        self,
        hotkey: str,
        new_hotkey: str,
        netuid: Optional[int] = None,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.swap_hotkey.

        Parameters:
            hotkey: The SS58 address of the current hotkey.
            new_hotkey: The SS58 address of the new hotkey.
            netuid: Optional netuid to restrict the swap to a specific subnet.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            new_hotkey=new_hotkey,
            netuid=netuid,
        )

    def swap_stake(
        self,
        hotkey: str,
        origin_netuid: int,
        destination_netuid: int,
        alpha_amount: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.swap_stake.

        Parameters:
            hotkey: The hotkey SS58 address associated with the stake.
            origin_netuid: The source subnet UID.
            destination_netuid: The destination subnet UID.
            alpha_amount: Amount of stake in MESHLET to swap.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            origin_netuid=origin_netuid,
            destination_netuid=destination_netuid,
            alpha_amount=alpha_amount,
        )

    def swap_stake_limit(
        self,
        hotkey: str,
        origin_netuid: int,
        destination_netuid: int,
        alpha_amount: int,
        limit_price: float,
        allow_partial: bool,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.swap_stake_limit.

        Parameters:
            hotkey: The hotkey SS58 address associated with the stake.
            origin_netuid: The source subnet UID.
            destination_netuid: The destination subnet UID.
            alpha_amount: The amount of stake in MESHLET to swap.
            allow_partial: If true, allows partial stake swaps when the full amount would exceed the price
                tolerance.
            limit_price: Maximum allowed increase in a price ratio (0.005 = 0.5%).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            origin_netuid=origin_netuid,
            destination_netuid=destination_netuid,
            alpha_amount=alpha_amount,
            limit_price=limit_price,
            allow_partial=allow_partial,
        )

    def unstake_all(
        self,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.unstake_all.

        Unstakes all MESH/Alpha across ALL subnets for the given hotkey at once.

        Parameters:
            hotkey: The hotkey SS58 address to unstake from across all subnets.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey)

    def unstake_all_alpha(
        self,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.unstake_all_alpha.

        Unstakes all Alpha across ALL subnets for the given hotkey at once, keeping MESH on root.

        Parameters:
            hotkey: The hotkey SS58 address to unstake alpha from across all subnets.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey)

    def set_childkey_take(
        self,
        hotkey: str,
        netuid: int,
        take: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.set_childkey_take.

        Parameters:
            hotkey: SS58 address of the hotkey to set childkey take for.
            netuid: The netuid of the subnet.
            take: The childkey take value as u16.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(hotkey=hotkey, netuid=netuid, take=take)

    def set_tx_childkey_take_rate_limit(
        self,
        tx_rate_limit: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorModule.set_tx_childkey_take_rate_limit.

        Root-only. Sets the transaction rate limit for changing childkey take.

        Parameters:
            tx_rate_limit: The new rate limit in blocks (1 to 5_256_000).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(tx_rate_limit=tx_rate_limit)

    def set_min_childkey_take(
        self,
        take: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorModule.set_min_childkey_take.

        Root-only. Sets the minimum allowed childkey take.

        Parameters:
            take: The new minimum childkey take value as u16.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(take=take)

    def set_max_childkey_take(
        self,
        take: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorModule.set_max_childkey_take.

        Root-only. Sets the maximum allowed childkey take.

        Parameters:
            take: The new maximum childkey take value as u16.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(take=take)

    def transfer_stake(
        self,
        destination_coldkey: str,
        hotkey: str,
        origin_netuid: int,
        destination_netuid: int,
        alpha_amount: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.transfer_stake.

        Parameters:
            destination_coldkey: SS58 address of the destination coldkey.
            hotkey: SS58 address of the hotkey associated with the stake.
            origin_netuid: Network UID of the origin subnet.
            destination_netuid: Network UID of the destination subnet.
            alpha_amount: The amount of stake in MESHLET to transfer as a `Balance` object.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            destination_coldkey=destination_coldkey,
            hotkey=hotkey,
            origin_netuid=origin_netuid,
            destination_netuid=destination_netuid,
            alpha_amount=alpha_amount,
        )

    def recycle_alpha(
        self,
        hotkey: str,
        amount: int,
        netuid: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.recycle_alpha.

        Recycles alpha from a cold/hot key pair, reducing AlphaOut on the subnet.

        Parameters:
            hotkey: The hotkey SS58 address associated with the stake.
            amount: The amount of alpha to recycle.
            netuid: The subnet ID.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            amount=amount,
            netuid=netuid,
        )

    def burn_alpha(
        self,
        hotkey: str,
        amount: int,
        netuid: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.burn_alpha.

        Burns alpha from a cold/hot key pair without reducing AlphaOut.

        Parameters:
            hotkey: The hotkey SS58 address associated with the stake.
            amount: The amount of alpha to burn.
            netuid: The subnet ID.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            hotkey=hotkey,
            amount=amount,
            netuid=netuid,
        )

    def terminate_lease(
        self,
        lease_id: int,
        hotkey: str,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.terminate_lease.

        Terminates a lease after the end block has passed. The subnet is transferred to the
        beneficiary and the lease is removed from storage.

        Parameters:
            lease_id: The ID of the lease to terminate.
            hotkey: The hotkey SS58 address of the beneficiary to mark as subnet owner.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            lease_id=lease_id,
            hotkey=hotkey,
        )

    def request_force_terminate_lease(
        self,
        lease_id: int,
        action: Union[str, dict],
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.request_force_terminate_lease.

        Requests force-termination of a lease. Requires root origin. Contributors have a notice
        period (50400 blocks, ~7 days) to react before execution.

        Parameters:
            lease_id: The ID of the lease to force-terminate.
            action: The action to take on force-termination. Can be:
                - "TransferToBeneficiary": Transfer subnet to the lease beneficiary.
                - "Dissolve": Dissolve the subnet entirely.
                - {"TransferToDesignated": {"0": "<SS58 address>"}}: Transfer to a designated account.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            lease_id=lease_id,
            action=action,
        )

    def force_terminate_lease(
        self,
        lease_id: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.force_terminate_lease.

        Executes a previously requested force-termination of a lease. Requires root origin and
        the notice period (50400 blocks, ~7 days) to have elapsed since the request.

        Parameters:
            lease_id: The ID of the lease to force-terminate.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(lease_id=lease_id)

    def veto_force_termination(
        self,
        lease_id: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.veto_force_termination.

        Vetoes a pending force-termination. Any lease shareholder can veto. If cumulative veto
        weight exceeds the threshold (default 51%) of total shares, the force-termination is cancelled.

        Parameters:
            lease_id: The ID of the lease to veto force-termination for.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(lease_id=lease_id)

    def transfer_lease_shares(
        self,
        lease_id: int,
        to: str,
        shares_bits: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.transfer_lease_shares.

        Transfers lease shares from the caller to another account. Pending dividends remain
        with the sender.

        Parameters:
            lease_id: The ID of the lease.
            to: The SS58 address of the recipient.
            shares_bits: The amount of shares to transfer as U64F64 fixed-point bits (u128).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            lease_id=lease_id,
            to=to,
            shares_bits=shares_bits,
        )

    def update_symbol(
        self,
        netuid: int,
        symbol: bytes,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.update_symbol.

        Updates the symbol for a subnet.

        Parameters:
            netuid: The unique identifier of the subnet.
            symbol: The symbol to set for the subnet, as bytes.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            netuid=netuid,
            symbol=symbol,
        )

    def root_dissolve_network(
        self,
        netuid: int,
    ) -> Call:
        """Returns GenericCall instance for Meshtensor function MeshtensorModule.root_dissolve_network.

        Dissolves a subnet via root/governance origin.

        Parameters:
            netuid: The unique identifier of the subnet to dissolve.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid)
