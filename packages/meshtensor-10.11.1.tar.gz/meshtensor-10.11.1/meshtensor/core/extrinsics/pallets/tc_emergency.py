from dataclasses import dataclass
from typing import TYPE_CHECKING

from .base import CallBuilder as _BasePallet, Call

if TYPE_CHECKING:
    from scalecodec import GenericCall


@dataclass
class TcEmergency(_BasePallet):
    """Factory class for creating GenericCall objects for TcEmergency pallet functions.

    The TC Emergency pallet allows the Technical Committee to execute Root-level
    emergency calls after a mandatory on-chain delay. Requires a 7/9 supermajority
    of TC members for approval, with a 4-hour execution delay.

    Works with both sync (Meshtensor) and async (AsyncMeshtensor) instances.
    """

    def propose(
        self,
        call: "GenericCall",
    ) -> Call:
        """Returns GenericCall instance for TcEmergency.propose.

        Submits a new emergency proposal. The caller must be a TC member.
        The proposer's vote is automatically counted as the first approval.

        Parameters:
            call: The runtime call to be dispatched with Root origin if approved.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(call=call)

    def approve(
        self,
        proposal_id: int,
    ) -> Call:
        """Returns GenericCall instance for TcEmergency.approve.

        Approves an existing emergency proposal. The caller must be a TC member
        who has not already approved this proposal.

        Parameters:
            proposal_id: The unique identifier of the proposal to approve.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(proposal_id=proposal_id)

    def execute(
        self,
        proposal_id: int,
    ) -> Call:
        """Returns GenericCall instance for TcEmergency.execute.

        Executes a proposal that has reached threshold and whose delay has elapsed.
        Permissionless: any signed account can trigger execution.
        The call is dispatched with Root origin.

        Parameters:
            proposal_id: The unique identifier of the proposal to execute.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(proposal_id=proposal_id)

    def cancel(
        self,
        proposal_id: int,
    ) -> Call:
        """Returns GenericCall instance for TcEmergency.cancel.

        Cancels a pending proposal. Only callable by Root origin (governance referendum).

        Parameters:
            proposal_id: The unique identifier of the proposal to cancel.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(proposal_id=proposal_id)
