from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

from .base import CallBuilder as _BasePallet, Call

if TYPE_CHECKING:
    from scalecodec import GenericCall


@dataclass
class MeshtensorGovernance(_BasePallet):
    """Factory class for creating GenericCall objects for MeshtensorGovernance pallet functions.

    This class provides methods to create GenericCall instances for all MeshtensorGovernance pallet extrinsics,
    including delegation, contribution scoring, governance rewards, and GoLR signaling.

    Works with both sync (Meshtensor) and async (AsyncMeshtensor) instances. For async operations, pass an AsyncMeshtensor
    instance and await the result.

    Example:
        # Sync usage
        call = MeshtensorGovernance(meshtensor).delegate(track=0, delegatee="5F...", conviction=1)
        response = meshtensor.sign_and_send_extrinsic(call=call, ...)

        # Async usage
        call = await MeshtensorGovernance(async_meshtensor).delegate(track=0, delegatee="5F...", conviction=1)
        response = await async_meshtensor.sign_and_send_extrinsic(call=call, ...)
    """

    # =========================================================================
    # MeshtensorGovernance pallet extrinsics (call_index 0-5)
    # =========================================================================

    def update_contribution_scores(self) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.update_contribution_scores.

        Permissionless call that computes contribution scores and participation rate
        from on-chain governance activity data. Scores are derived from GovernanceVoteCount
        (formula: min(vote_count * 100, 1000)). Also finalizes the current participation
        epoch and resets counters. Anyone can call this.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call()

    def distribute_governance_rewards(self) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.distribute_governance_rewards.

        Permissionless call that distributes governance rewards from the reward pool
        to participants based on their voting power and conviction.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call()

    def delegate(
        self,
        track: int,
        delegatee: str,
        conviction: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.delegate.

        Delegates voting power on a specific governance track to another account.

        Parameters:
            track: The governance track ID (0=Root, 1=Treasury, 2=ParameterCritical,
                   3=ParameterStandard, 4=Subnet, 5=Emergency, 6=CriticalUpgrade).
            delegatee: The SS58 address of the account to delegate voting power to.
            conviction: The conviction multiplier (0-6). Higher conviction locks tokens
                       longer for more voting power.

        Returns:
            GenericCall instance.

        Raises:
            ValueError: If conviction is not in the valid range 0-6.
        """
        if not 0 <= conviction <= 6:
            raise ValueError(
                f"Invalid conviction: {conviction}. Must be between 0 and 6."
            )
        return self.create_composed_call(
            track=track,
            delegatee=delegatee,
            conviction=conviction,
        )

    def undelegate(
        self,
        track: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.undelegate.

        Removes voting power delegation on a specific governance track.

        Parameters:
            track: The governance track ID to undelegate on.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(track=track)

    def signal_golr(self) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.signal_golr.

        Signals support for Governance of Last Resort (GoLR) activation. Only callable
        by validators when governance has been paralyzed for 180+ days. When enough
        validators (80% supermajority by default) signal, reduced threshold mode activates.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call()

    def set_contribution_scores(
        self,
        scores: list[tuple[str, int]],
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_contribution_scores.

        Root-only call that directly sets contribution scores for accounts.
        Typically called via a governance referendum.

        Parameters:
            scores: A list of (AccountId, score) tuples where AccountId is an SS58 address
                    and score is a u32 contribution score value.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(scores=scores)

    def fund_governance_pool(
        self,
        amount: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.fund_governance_pool.

        Root-only call that transfers the specified amount into the governance reward pool.
        Typically called via a governance referendum.

        Parameters:
            amount: The amount in MESHLET (Balance) to deposit into the governance reward pool.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(amount=amount)

    def set_subnet_council(
        self,
        netuid: int,
        members: list[str],
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_subnet_council.

        Root-only call that sets the governance council members for a specific subnet.
        Typically called via a governance referendum. Maximum 64 members per subnet.

        Parameters:
            netuid: The subnet UID to set the council for.
            members: A list of SS58 addresses of council member accounts.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(netuid=netuid, members=members)

    def set_participation_rate(
        self,
        rate: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_participation_rate.

        Root-only governance override for the participation rate. Normally the rate
        is auto-computed on-chain via ``update_contribution_scores``. This override
        allows governance referenda to manually set the rate. Drives the dynamic
        reward scaler (3-8%).

        Parameters:
            rate: Participation rate in parts per thousand (0=0%, 500=50%, 1000=100%).
                  Values above 1000 are clamped to 1000.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(rate=rate)

    def set_stake_deposit_blocks(
        self,
        deposits: list[tuple[str, int]],
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_stake_deposit_blocks.

        Root-only governance override for stake deposit blocks. Normally deposit blocks
        are auto-set on first governance participation (lazy init). This override allows
        governance referenda to manually set deposit blocks for VP duration bonus calculation.

        Parameters:
            deposits: A list of (AccountId, BlockNumber) tuples where AccountId is an
                      SS58 address and BlockNumber is when the account first staked.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(deposits=deposits)

    def claim_governance_rewards(self) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.claim_governance_rewards.

        Claims pending governance rewards accumulated from the governance reward pool.
        Transfers real tokens from the governance pot account to the caller's free balance.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call()

    def set_track_coefficients(
        self,
        track_id: int,
        alpha: int,
        beta: int,
        gamma: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_track_coefficients.

        Root-only call that updates VP formula coefficients for a governance track.
        Coefficients should sum to 1000 (parts per thousand).

        Parameters:
            track_id: The governance track ID (0-6).
            alpha: Quadratic stake weight (0-1000).
            beta: Contribution weight (0-1000).
            gamma: Reserved/future weight (0-1000).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            track_id=track_id, alpha=alpha, beta=beta, gamma=gamma
        )

    def set_governance_reward_rates(
        self,
        base: int,
        min: int,
        max: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_governance_reward_rates.

        Root-only call that updates the dynamic governance reward rate parameters.
        Currently a placeholder that emits an event for off-chain tracking.

        Parameters:
            base: Base reward rate (parts per thousand).
            min: Minimum reward rate (parts per thousand).
            max: Maximum reward rate (parts per thousand).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(base=base, min=min, max=max)

    def set_governance_config(
        self,
        min_contribution_floor: int,
        max_delegation_pct: int,
        delegation_factor: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_governance_config.

        Root-only call that updates core governance configuration parameters.
        All values are in parts per thousand (0-1000) and clamped on-chain.

        Parameters:
            min_contribution_floor: Minimum CW floor (default 150 = 0.15).
            max_delegation_pct: Max delegated VP per delegatee (default 50 = 5%).
            delegation_factor: Delegation decay (default 900 = 90%).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            min_contribution_floor=min_contribution_floor,
            max_delegation_pct=max_delegation_pct,
            delegation_factor=delegation_factor,
        )

    def set_golr_config(
        self,
        paralysis_days: int,
        threshold_pct: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_golr_config.

        Root-only call that updates GoLR (Governance of Last Resort) parameters.

        Parameters:
            paralysis_days: Days of inactivity before GoLR can be invoked (min 90).
            threshold_pct: Validator supermajority percentage needed (0-100).

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            paralysis_days=paralysis_days, threshold_pct=threshold_pct
        )

    def record_governance_activity(self) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.record_governance_activity.

        Root-only call that resets the GoLR (Governance of Last Resort) paralysis
        timer. Should be included in every governance referendum via
        ``submit_referendum_with_activity_reset`` to automatically keep the timer
        fresh.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call()

    def prune_stale_accounts(
        self,
        accounts: list[str],
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.prune_stale_accounts.

        Root-only call that removes governance storage entries for accounts with
        zero balance. Cleans up ContributionScore, GovernanceVoteCount,
        StakeDepositBlock, HasVotedThisEpoch, and PendingRewards maps.

        Parameters:
            accounts: List of SS58-encoded account addresses to prune.
                Maximum 500 per call.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(accounts=accounts)

    def endorse_referendum(
        self,
        ref_index: int,
        track: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.endorse_referendum.

        Endorses a referendum as a technical committee or subnet council member.
        On the Emergency track (5), TC membership is verified on-chain.

        Parameters:
            ref_index: The index of the referendum to endorse.
            track: The governance track ID (0-6) for the endorsement bucket.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            referendum_index=ref_index,
            track=track,
        )

    def set_endorsement_thresholds(
        self,
        thresholds: list[tuple[int, int]],
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_endorsement_thresholds.

        Root-only call that updates endorsement thresholds per track.

        Parameters:
            thresholds: List of (track_id, threshold) tuples.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(thresholds=thresholds)

    def set_active_account_count(
        self,
        count: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorGovernance.set_active_account_count.

        Root-only call that sets the active governance account count.

        Parameters:
            count: The new active account count value.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(count=count)

    # =========================================================================
    # Convenience wrappers for related pallets
    # =========================================================================

    def cancel_referendum(
        self,
        ref_index: int,
    ) -> Call:
        """Returns GenericCall instance for Referenda.cancel.

        Cancels an active referendum. Routes to the Referenda pallet.

        Parameters:
            ref_index: The index of the referendum to cancel.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            call_module="Referenda",
            call_function="cancel",
            idx=ref_index,
        )

    def approve_treasury_proposal(
        self,
        proposal_id: int,
    ) -> Call:
        """Returns GenericCall instance for Treasury.approve_proposal.

        Approves a pending treasury proposal. Routes to the Treasury pallet.

        Parameters:
            proposal_id: The unique identifier of the treasury proposal.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            call_module="Treasury",
            call_function="approve_proposal",
            proposal_id=proposal_id,
        )

    def submit_referendum(
        self,
        track: int,
        call: "GenericCall",
        deposit: int,
        enactment_block: int,
    ) -> Call:
        """Returns GenericCall instance for Referenda.submit.

        Submits a new referendum proposal on the specified governance track.
        This routes to the Referenda pallet, not MeshtensorGovernance.

        Parameters:
            track: The governance track ID (0=Root, 1=Treasury, etc.).
            call: The proposed runtime call to be executed if the referendum passes.
            deposit: The deposit amount in MESHLET to lock for the referendum.
            enactment_block: The block number at which the proposal should be enacted if approved.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            call_module="Referenda",
            call_function="submit",
            track=track,
            call=call,
            deposit=deposit,
            enactment_block=enactment_block,
        )

    def vote_referendum(
        self,
        ref_index: int,
        vote,
        conviction: int,
    ) -> Call:
        """Returns GenericCall instance for MeshtensorVoting.vote.

        Casts a vote on an active referendum with the specified conviction level.
        VP-weighted: the voting power formula is applied automatically on-chain.
        This routes to the MeshtensorVoting pallet, not MeshtensorGovernance.

        Parameters:
            ref_index: The index of the referendum to vote on.
            vote: True/"aye" for aye, False/"nay" for nay, "abstain" for abstain.
            conviction: The conviction multiplier (0-6).

        Returns:
            GenericCall instance.

        Raises:
            ValueError: If conviction is not in the valid range 0-6 or vote value is invalid.
        """
        if not 0 <= conviction <= 6:
            raise ValueError(
                f"Invalid conviction: {conviction}. Must be between 0 and 6."
            )

        # Normalize vote to string
        if isinstance(vote, bool):
            vote_str = "aye" if vote else "nay"
        elif isinstance(vote, str):
            vote_str = vote.lower()
        else:
            raise ValueError(f"Invalid vote type: {type(vote)}. Must be bool or str.")

        if vote_str not in ("aye", "nay", "abstain"):
            raise ValueError(
                f"Invalid vote: {vote_str}. Must be 'aye', 'nay', or 'abstain'."
            )

        if vote_str == "abstain":
            # SplitAbstain vote type — put full weight into abstain bucket
            account_vote = {
                "SplitAbstain": {
                    "aye": 0,
                    "nay": 0,
                    "abstain": 1,
                }
            }
        else:
            conviction_value = f"Locked{conviction}x" if conviction > 0 else "None"
            account_vote = {
                "Standard": {
                    "vote": {"aye": vote_str == "aye", "conviction": conviction_value},
                    "balance": 0,
                }
            }

        return self.meshtensor.compose_call(
            call_module="MeshtensorVoting",
            call_function="vote",
            call_params={
                "poll_index": ref_index,
                "vote": account_vote,
            },
        )

    def submit_preimage(
        self,
        encoded_call: bytes,
    ) -> Call:
        """Returns GenericCall instance for Preimage.note_preimage.

        Stores a preimage of a runtime call on-chain. The preimage hash can then
        be referenced in referendum proposals. Required for runtime upgrade proposals
        (system.set_code) and other large calls.

        Parameters:
            encoded_call: The SCALE-encoded bytes of the runtime call to store.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            call_module="Preimage",
            call_function="note_preimage",
            bytes=list(encoded_call),
        )

    def submit_treasury_proposal(
        self,
        value: int,
        beneficiary: str,
        description_hash: str,
    ) -> Call:
        """Returns GenericCall instance for Treasury.propose_spend.

        Submits a treasury spending proposal. Routes to the Treasury pallet.

        Parameters:
            value: The amount in MESHLET to be spent from the treasury.
            beneficiary: The SS58 address of the account to receive the funds.
            description_hash: The blake2_256 hash of the proposal description.

        Returns:
            GenericCall instance.
        """
        return self.create_composed_call(
            call_module="Treasury",
            call_function="propose_spend",
            value=value,
            beneficiary=beneficiary,
            description_hash=description_hash,
        )
