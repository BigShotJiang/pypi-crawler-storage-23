from typing import Optional, TYPE_CHECKING

from meshtensor.core.extrinsics.mev_shield import submit_encrypted_extrinsic
from meshtensor.core.extrinsics.pallets import MeshtensorGovernance
from meshtensor.core.settings import DEFAULT_MEV_PROTECTION
from meshtensor.core.types import ExtrinsicResponse
from meshtensor.utils.balance import check_balance_amount

if TYPE_CHECKING:
    from meshtensor_wallet import Wallet
    from meshtensor.core.meshtensor import Meshtensor
    from meshtensor.utils.balance import Balance
    from scalecodec.types import GenericCall


def submit_referendum_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    track: int,
    call: "GenericCall",
    deposit: "Balance",
    enactment_block: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Submits a new referendum proposal on the specified governance track.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID (0=Root, 1=Treasury, 2=ParameterCritical, etc.).
        call: The proposed runtime call to be executed if the referendum passes.
        deposit: The deposit amount in MESH to lock for the referendum.
        enactment_block: The block number at which the proposal should be enacted if approved.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        check_balance_amount(deposit)

        composed_call = MeshtensorGovernance(meshtensor).submit_referendum(
            track=track,
            call=call,
            deposit=deposit.meshlet,
            enactment_block=enactment_block,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def vote_referendum_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    ref_index: int,
    vote,
    conviction: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Casts a vote on an active referendum with the specified conviction level.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to vote on.
        vote: True/"aye" for aye, False/"nay" for nay, or "abstain" for abstain.
        conviction: The conviction multiplier (0-6). Higher conviction locks tokens longer for more voting power.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).vote_referendum(
            ref_index=ref_index,
            vote=vote,
            conviction=conviction,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def delegate_voting_power_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    track: int,
    delegatee: str,
    conviction: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Delegates voting power on a specific track to another account.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID to delegate on.
        delegatee: The SS58 address of the account to delegate voting power to.
        conviction: The conviction multiplier (0-6) for the delegated votes.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).delegate(
            track=track,
            delegatee=delegatee,
            conviction=conviction,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def undelegate_voting_power_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    track: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Removes voting power delegation on a specific track.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID to undelegate on.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).undelegate(
            track=track,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def endorse_referendum_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    ref_index: int,
    track: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Endorses a referendum as a technical committee member.

    Endorsements can accelerate the decision process for referenda.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to endorse.
        track: The governance track ID (0-6) for the endorsement bucket.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).endorse_referendum(
            ref_index=ref_index,
            track=track,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def cancel_referendum_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    ref_index: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Cancels an active referendum.

    Only callable by the referendum proposer or through emergency governance.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to cancel.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).cancel_referendum(
            ref_index=ref_index,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def submit_treasury_proposal_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    value: "Balance",
    beneficiary: str,
    description_hash: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Submits a treasury spending proposal.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        value: The amount in MESH to be spent from the treasury.
        beneficiary: The SS58 address of the account to receive the funds.
        description_hash: The blake2_256 hash of the proposal description.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        check_balance_amount(value)

        composed_call = MeshtensorGovernance(meshtensor).submit_treasury_proposal(
            value=value.meshlet,
            beneficiary=beneficiary,
            description_hash=description_hash,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def approve_treasury_proposal_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    proposal_id: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Approves a pending treasury proposal. Requires appropriate governance origin.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        proposal_id: The unique identifier of the treasury proposal to approve.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).approve_treasury_proposal(
            proposal_id=proposal_id,
        )

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def signal_golr_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Signals support for Governance of Last Resort (GoLR) activation.

    Only callable by validators when governance has been paralyzed for 180+ days.
    When 80% of validators signal, reduced threshold mode activates.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for revealed execution if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).signal_golr()

        if mev_protection:
            return submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def update_contribution_scores_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Triggers contribution score recalculation for the current epoch.

    This is a permissionless call — anyone can trigger the computation.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).update_contribution_scores()

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def claim_governance_rewards_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Claims pending governance rewards accumulated from the governance reward pool.

    Transfers real tokens from the governance pot account to the caller's free balance.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).claim_governance_rewards()

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def submit_preimage_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    encoded_call: bytes,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Stores a preimage of a runtime call on-chain.

    The preimage hash can then be referenced in referendum proposals. Required
    for runtime upgrade proposals (system.set_code) and other large calls.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        encoded_call: The SCALE-encoded bytes of the runtime call to store.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).submit_preimage(
            encoded_call=encoded_call,
        )

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def distribute_governance_rewards_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Distributes governance rewards from the reward pool to participants.

    This is a permissionless call — anyone can trigger the distribution.

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).distribute_governance_rewards()

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def set_track_coefficients_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    track_id: int,
    alpha: int,
    beta: int,
    gamma: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Updates VP formula coefficients for a governance track. Root-only (governance referendum).

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track_id: The governance track ID (0-6).
        alpha: Quadratic stake weight (0-1000).
        beta: Contribution weight (0-1000).
        gamma: Reserved/future weight (0-1000).
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).set_track_coefficients(
            track_id=track_id, alpha=alpha, beta=beta, gamma=gamma,
        )

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def set_governance_config_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    min_contribution_floor: int,
    max_delegation_pct: int,
    delegation_factor: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Updates core governance configuration parameters. Root-only (governance referendum).

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        min_contribution_floor: Minimum CW floor (0-1000, default 150 = 0.15).
        max_delegation_pct: Max delegated VP per delegatee (0-1000, default 50 = 5%).
        delegation_factor: Delegation decay factor (0-1000, default 900 = 90%).
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).set_governance_config(
            min_contribution_floor=min_contribution_floor,
            max_delegation_pct=max_delegation_pct,
            delegation_factor=delegation_factor,
        )

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def set_golr_config_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    paralysis_days: int,
    threshold_pct: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Updates GoLR (Governance of Last Resort) parameters. Root-only (governance referendum).

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        paralysis_days: Days of inactivity before GoLR can be invoked (min 90).
        threshold_pct: Validator supermajority percentage needed (0-100).
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).set_golr_config(
            paralysis_days=paralysis_days, threshold_pct=threshold_pct,
        )

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


def prune_stale_accounts_extrinsic(
    meshtensor: "Meshtensor",
    wallet: "Wallet",
    accounts: list[str],
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """
    Prunes governance storage for zero-balance accounts. Root-only (governance referendum).

    Parameters:
        meshtensor: Active Meshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        accounts: List of SS58-encoded account addresses to prune (max 500).
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = MeshtensorGovernance(meshtensor).prune_stale_accounts(
            accounts=accounts,
        )

        return meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)
