"""
This module provides async functionalities for registering a wallet with the meshtensor network using Proof-of-Work (PoW).
"""

import asyncio
from typing import Optional, Union, TYPE_CHECKING

from meshtensor.core.errors import RegistrationError
from meshtensor.core.extrinsics.asyncex.mev_shield import submit_encrypted_extrinsic
from meshtensor.core.extrinsics.pallets import MeshtensorModule
from meshtensor.core.settings import DEFAULT_MEV_PROTECTION
from meshtensor.core.types import ExtrinsicResponse
from meshtensor.utils.mtlogging import logging
from meshtensor.utils.registration import create_pow_async, log_no_torch_error, torch

if TYPE_CHECKING:
    from meshtensor_wallet import Wallet
    from meshtensor.core.async_meshtensor import AsyncMeshtensor


async def burned_register_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    netuid: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Registers the wallet to chain by recycling MESH.

    Parameters:
        meshtensor: Meshtensor instance.
        wallet: Meshtensor wallet object.
        netuid: The ``netuid`` of the subnet to register on.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        block_hash = await meshtensor.substrate.get_chain_head()
        if not await meshtensor.subnet_exists(netuid=netuid, block_hash=block_hash):
            return ExtrinsicResponse(
                False, f"Subnet {netuid} does not exist."
            ).with_log()

        neuron, old_balance, recycle_amount = await asyncio.gather(
            meshtensor.get_neuron_for_pubkey_and_subnet(
                netuid=netuid,
                hotkey_ss58=wallet.hotkey.ss58_address,
                block_hash=block_hash,
            ),
            meshtensor.get_balance(
                address=wallet.coldkeypub.ss58_address, block_hash=block_hash
            ),
            meshtensor.recycle(netuid=netuid, block_hash=block_hash),
        )

        if not neuron.is_null:
            message = "Already registered."
            logging.debug(f"[green]{message}[/green]")
            logging.debug(f"\t\tuid: [blue]{neuron.uid}[/blue]")
            logging.debug(f"\t\tnetuid: [blue]{neuron.netuid}[/blue]")
            logging.debug(f"\t\thotkey: [blue]{neuron.hotkey}[/blue]")
            logging.debug(f"\t\tcoldkey: [blue]{neuron.coldkey}[/blue]")
            return ExtrinsicResponse(
                message=message, data={"neuron": neuron, "old_balance": old_balance}
            )

        logging.debug(f"Recycling {recycle_amount} to register on subnet:{netuid}")

        call = await MeshtensorModule(meshtensor).burned_register(
            netuid=netuid, hotkey=wallet.hotkey.ss58_address
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )
        extrinsic_fee = response.extrinsic_fee
        logging.debug(
            f"The registration fee for SN #[blue]{netuid}[/blue] is [blue]{extrinsic_fee}[/blue]."
        )
        if not response.success:
            logging.error(f"[red]{response.message}[/red]")
            await asyncio.sleep(0.5)
            return response

        # Successful registration, final check for neuron and pubkey
        new_balance = await meshtensor.get_balance(
            address=wallet.coldkeypub.ss58_address
        )

        logging.debug(
            f"Balance: [blue]{old_balance}[/blue] :arrow_right: [green]{new_balance}[/green]"
        )
        is_registered = await meshtensor.is_hotkey_registered(
            netuid=netuid, hotkey_ss58=wallet.hotkey.ss58_address
        )

        response.data = {
            "neuron": neuron,
            "balance_before": old_balance,
            "balance_after": new_balance,
            "recycle_amount": recycle_amount,
        }

        if is_registered:
            logging.debug("[green]Registered.[/green]")
            return response

        # neuron not found
        message = f"Neuron with hotkey {wallet.hotkey.ss58_address} not found in subnet {netuid} after registration."
        return ExtrinsicResponse(
            success=False,
            message=message,
            extrinsic=response.extrinsic,
            error=RegistrationError(message),
        ).with_log()

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def register_subnet_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    *,
    identity: Optional[dict] = None,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Registers a new subnetwork on the Meshtensor blockchain asynchronously.

    Parameters:
        meshtensor: The meshtensor interface to send the extrinsic.
        wallet: The wallet to be used for subnet registration.
        identity: Optional subnet identity dict with keys: subnet_name, github_repo,
            subnet_contact, subnet_url, discord, description, logo_url, additional.
            If provided, uses register_network_with_identity for atomic registration.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        balance = await meshtensor.get_balance(wallet.coldkeypub.ss58_address)
        burn_cost = await meshtensor.get_subnet_burn_cost()

        if burn_cost > balance:
            return ExtrinsicResponse(
                False,
                f"Insufficient balance {balance} to register subnet. Current burn cost is {burn_cost} MESH.",
            ).with_log()

        if identity:
            call = await MeshtensorModule(meshtensor).register_network_with_identity(
                hotkey=wallet.hotkey.ss58_address, identity=identity
            )
        else:
            call = await MeshtensorModule(meshtensor).register_network(
                hotkey=wallet.hotkey.ss58_address
            )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]Successfully registered subnet.[/green]")
            return response

        logging.error(f"Failed to register subnet: {response.message}")
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def register_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    netuid: int,
    max_allowed_attempts: int = 3,
    output_in_place: bool = True,
    cuda: bool = False,
    dev_id: Union[list[int], int] = 0,
    tpb: int = 256,
    num_processes: Optional[int] = None,
    update_interval: Optional[int] = None,
    log_verbose: bool = False,
    *,
    unsigned: bool = False,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Registers a neuron on the Meshtensor subnet with provided netuid using the provided wallet.

    Registration is a critical step for a neuron to become an active participant in the network, enabling it to stake,
    set weights, and receive incentives.

    Parameters:
        meshtensor: Meshtensor object to use for chain interactions
        wallet: Meshtensor wallet object.
        netuid: The ``netuid`` of the subnet to register on.
        max_allowed_attempts: Maximum number of attempts to register the wallet.
        output_in_place: Whether the POW solving should be outputted to the console as it goes along.
        cuda: If `True`, the wallet should be registered using CUDA device(s).
        dev_id: The CUDA device id to use, or a list of device ids.
        tpb: The number of threads per block (CUDA).
        num_processes: The number of processes to use to register.
        update_interval: The number of nonces to solve between updates.
        log_verbose: If `True`, the registration process will log more information.
        unsigned: If `True`, submits the registration as an unsigned extrinsic (for zero-balance PoW registration).
            This uses the blockchain's ValidateUnsigned path and requires no transaction fees.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if unsigned:
            # For unsigned PoW registration, only hotkey is needed (no coldkey signing)
            if not (
                unlocked := ExtrinsicResponse.unlock_wallet(
                    wallet, raise_error, unlock_type="hotkey"
                )
            ).success:
                return unlocked
        else:
            if not (
                unlocked := ExtrinsicResponse.unlock_wallet(
                    wallet, raise_error, unlock_type="both"
                )
            ).success:
                return unlocked

        block_hash = await meshtensor.substrate.get_chain_head()
        if not await meshtensor.subnet_exists(netuid, block_hash=block_hash):
            return ExtrinsicResponse(
                False, f"Subnet {netuid} does not exist."
            ).with_log()

        neuron = await meshtensor.get_neuron_for_pubkey_and_subnet(
            hotkey_ss58=wallet.hotkey.ss58_address, netuid=netuid, block_hash=block_hash
        )

        if not neuron.is_null:
            message = "Already registered."
            logging.debug(f"[green]{message}[/green]")
            logging.debug(f"\t\tuid: [blue]{neuron.uid}[/blue]")
            logging.debug(f"\t\tnetuid: [blue]{neuron.netuid}[/blue]")
            logging.debug(f"\t\thotkey: [blue]{neuron.hotkey}[/blue]")
            logging.debug(f"\t\tcoldkey: [blue]{neuron.coldkey}[/blue]")
            return ExtrinsicResponse(message=message, data={"neuron": neuron})

        logging.debug(
            f"Registration hotkey: [blue]{wallet.hotkey.ss58_address}[/blue], Public coldkey: "
            f"[blue]{wallet.coldkeypub.ss58_address}[/blue] in the network: [blue]{meshtensor.network}[/blue]."
        )

        if not torch:
            log_no_torch_error()
            return ExtrinsicResponse(False, "Torch is not installed.").with_log()

        # Attempt rolling registration.
        attempts = 1

        while True:
            # Solve latest POW.
            if cuda:
                if not torch.cuda.is_available():
                    return ExtrinsicResponse(False, "CUDA not available.").with_log()

                logging.debug(f"Creating a POW with CUDA.")
                pow_result = await create_pow_async(
                    meshtensor=meshtensor,
                    wallet=wallet,
                    netuid=netuid,
                    output_in_place=output_in_place,
                    cuda=cuda,
                    dev_id=dev_id,
                    tpb=tpb,
                    num_processes=num_processes,
                    update_interval=update_interval,
                    log_verbose=log_verbose,
                )
            else:
                logging.debug(f"Creating a POW.")
                pow_result = await create_pow_async(
                    meshtensor=meshtensor,
                    wallet=wallet,
                    netuid=netuid,
                    output_in_place=output_in_place,
                    cuda=cuda,
                    num_processes=num_processes,
                    update_interval=update_interval,
                    log_verbose=log_verbose,
                )

            # pow failed
            if not pow_result:
                # might be registered already on this subnet
                is_registered = await meshtensor.is_hotkey_registered(
                    netuid=netuid, hotkey_ss58=wallet.hotkey.ss58_address
                )
                if is_registered:
                    message = f"Already registered in subnet {netuid}."
                    logging.debug(f"[green]{message}[/green]")
                    return ExtrinsicResponse(message=message)

            # pow successful, proceed to submit pow to chain for registration
            else:
                # check if a pow result is still valid
                while not await pow_result.is_stale_async(meshtensor=meshtensor):
                    call = await MeshtensorModule(meshtensor).register(
                        netuid=netuid,
                        coldkey=wallet.coldkeypub.ss58_address,
                        hotkey=wallet.hotkey.ss58_address,
                        block_number=pow_result.block_number,
                        nonce=pow_result.nonce,
                        work=[int(byte_) for byte_ in pow_result.seal],
                    )
                    if unsigned:
                        # Submit as unsigned extrinsic (Fair Launch: zero-balance PoW registration)
                        ext = await meshtensor.substrate.create_unsigned_extrinsic(call=call)
                        result = await meshtensor.substrate.submit_extrinsic(
                            ext,
                            wait_for_inclusion=wait_for_inclusion,
                            wait_for_finalization=wait_for_finalization,
                        )
                        if wait_for_inclusion or wait_for_finalization:
                            if await result.is_success:
                                response = ExtrinsicResponse(
                                    success=True,
                                    message="Registered via unsigned PoW.",
                                    extrinsic=result,
                                )
                            else:
                                response = ExtrinsicResponse(
                                    success=False,
                                    message=str(await result.error_message or "Unsigned registration failed."),
                                    extrinsic=result,
                                )
                        else:
                            response = ExtrinsicResponse(
                                success=True,
                                message="Unsigned extrinsic submitted.",
                                extrinsic=result,
                            )
                    elif mev_protection:
                        response = await submit_encrypted_extrinsic(
                            meshtensor=meshtensor,
                            wallet=wallet,
                            call=call,
                            period=period,
                            raise_error=raise_error,
                            wait_for_inclusion=wait_for_inclusion,
                            wait_for_finalization=wait_for_finalization,
                            wait_for_revealed_execution=wait_for_revealed_execution,
                        )
                    else:
                        response = await meshtensor.sign_and_send_extrinsic(
                            call=call,
                            wallet=wallet,
                            period=period,
                            raise_error=raise_error,
                            wait_for_inclusion=wait_for_inclusion,
                            wait_for_finalization=wait_for_finalization,
                        )

                    if not response.success:
                        # Look error here
                        # https://github.com/meshtensor/meshtensor/blob/development/pallets/meshtensor/src/errors.rs
                        if "HotKeyAlreadyRegisteredInSubNet" in response.message:
                            logging.debug(
                                f"[green]Already registered on subnet:[/green] [blue]{netuid}[/blue]."
                            )
                            return response
                        await asyncio.sleep(0.5)

                    if response.success:
                        is_registered = await meshtensor.is_hotkey_registered(
                            netuid=netuid, hotkey_ss58=wallet.hotkey.ss58_address
                        )
                        if is_registered:
                            logging.debug("[green]Registered.[/green]")
                            return response

                        # neuron not found, try again
                        logging.warning("[red]Unknown error. Neuron not found.[/red]")
                        continue
                else:
                    # Exited loop because pow is no longer valid.
                    logging.warning("[red]POW is stale.[/red]")
                    # Try again.

            if attempts < max_allowed_attempts:
                # Failed registration, retry pow
                attempts += 1
                logging.warning(
                    f"Failed registration, retrying pow ... [blue]({attempts}/{max_allowed_attempts})[/blue]"
                )
            else:
                # Failed to register after max attempts.
                return ExtrinsicResponse(False, "No more attempts.").with_log()

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_subnet_identity_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    netuid: int,
    subnet_name: str,
    github_repo: str,
    subnet_contact: str,
    subnet_url: str,
    logo_url: str,
    discord: str,
    description: str,
    additional: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Set the identity information for a given subnet.

    Parameters:
        meshtensor: An instance of the Meshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        netuid: The unique ID for the subnet.
        subnet_name: The name of the subnet to assign the identity information.
        github_repo: URL of the GitHub repository related to the subnet.
        subnet_contact: Subnet's contact information, e.g., email or contact link.
        subnet_url: The URL of the subnet's primary web portal.
        logo_url: The URL of the logo's primary web portal.
        discord: Discord server or contact for the subnet.
        description: A textual description of the subnet.
        additional: Any additional metadata or information related to the subnet.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).set_subnet_identity(
            netuid=netuid,
            subnet_name=subnet_name,
            github_repo=github_repo,
            subnet_contact=subnet_contact,
            subnet_url=subnet_url,
            logo_url=logo_url,
            discord=discord,
            description=description,
            additional=additional,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug(
                f"[green]Identities for subnet[/green] [blue]{netuid}[/blue] [green]are set.[/green]"
            )
            return response

        logging.error(
            f"[red]Failed to set identity for subnet {netuid}: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_identity_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    name: str,
    url: str,
    github_repo: str,
    image: str,
    discord: str,
    description: str,
    additional: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Set the on-chain identity (ChainIdentityV2) for the signing coldkey.

    Parameters:
        meshtensor: An instance of the AsyncMeshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        name: The display name for the identity.
        url: The URL associated with the identity.
        github_repo: The GitHub repository URL.
        image: The image URL for the identity.
        discord: The Discord contact information.
        description: A description of the identity.
        additional: Any additional metadata.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).set_identity(
            name=name,
            url=url,
            github_repo=github_repo,
            image=image,
            discord=discord,
            description=description,
            additional=additional,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]Identity set successfully.[/green]")
            return response

        logging.error(
            f"[red]Failed to set identity: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def swap_hotkey_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    hotkey: str,
    new_hotkey: str,
    netuid: Optional[int] = None,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Swap a hotkey for a new one on the chain.

    Parameters:
        meshtensor: An instance of the AsyncMeshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        hotkey: The SS58 address of the current hotkey.
        new_hotkey: The SS58 address of the new hotkey.
        netuid: Optional netuid to restrict the swap to a specific subnet.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).swap_hotkey(
            hotkey=hotkey,
            new_hotkey=new_hotkey,
            netuid=netuid,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]Hotkey swapped successfully.[/green]")
            return response

        logging.error(
            f"[red]Failed to swap hotkey: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def schedule_swap_coldkey_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    new_coldkey: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Schedule a coldkey swap on the chain.

    Parameters:
        meshtensor: An instance of the AsyncMeshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        new_coldkey: The SS58 address of the new coldkey.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).schedule_swap_coldkey(
            new_coldkey=new_coldkey,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]Coldkey swap scheduled successfully.[/green]")
            return response

        logging.error(
            f"[red]Failed to schedule coldkey swap: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def try_associate_hotkey_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    hotkey: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Try to associate a hotkey with the signing coldkey.

    Parameters:
        meshtensor: An instance of the AsyncMeshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        hotkey: The SS58 address of the hotkey to associate.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).try_associate_hotkey(
            hotkey=hotkey,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]Hotkey association successful.[/green]")
            return response

        logging.error(
            f"[red]Failed to associate hotkey: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def associate_evm_key_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    netuid: int,
    evm_key: str,
    block_number: int,
    signature: list[int],
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Associate an EVM key with the hotkey on a specific subnet.

    Parameters:
        meshtensor: An instance of the AsyncMeshtensor class to interact with the blockchain.
        wallet: A wallet instance used to sign and submit the extrinsic.
        netuid: The netuid of the subnet.
        evm_key: The EVM H160 address to associate.
        block_number: The block number for the signature.
        signature: The signature proving ownership of the EVM key.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the inclusion of the transaction.
        wait_for_finalization: Whether to wait for the finalization of the transaction.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(
                wallet, raise_error, unlock_type="both"
            )
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).associate_evm_key(
            netuid=netuid,
            evm_key=evm_key,
            block_number=block_number,
            signature=signature,
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

        if not wait_for_finalization and not wait_for_inclusion:
            return response

        if response.success:
            logging.debug("[green]EVM key associated successfully.[/green]")
            return response

        logging.error(
            f"[red]Failed to associate EVM key: {response.message}[/red]"
        )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)
