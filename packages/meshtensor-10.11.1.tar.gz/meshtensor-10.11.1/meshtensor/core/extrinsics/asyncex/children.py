from typing import TYPE_CHECKING, Optional

from meshtensor.core.extrinsics.asyncex.mev_shield import submit_encrypted_extrinsic
from meshtensor.core.extrinsics.pallets import MeshtensorModule, Sudo
from meshtensor.core.settings import DEFAULT_MEV_PROTECTION
from meshtensor.core.types import ExtrinsicResponse
from meshtensor.utils import float_to_u64

if TYPE_CHECKING:
    from meshtensor_wallet import Wallet
    from meshtensor.core.async_meshtensor import AsyncMeshtensor


async def set_children_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    hotkey_ss58: str,
    netuid: int,
    children: list[tuple[float, str]],
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Allows a coldkey to set children-keys.

    Parameters:
        meshtensor: The Meshtensor client instance used for blockchain interaction.
        wallet: meshtensor wallet instance.
        hotkey_ss58: The ``SS58`` address of the neuron's hotkey.
        netuid: The netuid value.
        children: A list of children with their proportions.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Waits for the transaction to be included in a block.
        wait_for_finalization: Waits for the transaction to be finalized on the blockchain.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.

    Raises:
        DuplicateChild: There are duplicates in the list of children.
        InvalidChild: Child is the hotkey.
        NonAssociatedColdKey: The coldkey does not own the hotkey or the child is the same as the hotkey.
        NotEnoughStakeToSetChildkeys: Parent key doesn't have minimum own stake.
        ProportionOverflow: The sum of the proportions does exceed uint64.
        RegistrationNotPermittedOnRootSubnet: Attempting to register a child on the root network.
        SubnetNotExists: Attempting to register to a non-existent network.
        TooManyChildren: Too many children in request.
        TxRateLimitExceeded: Hotkey hit the rate limit.
        meshtensor_wallet.errors.KeyFileError: Failed to decode keyfile data.
        meshtensor_wallet.errors.PasswordError: Decryption failed or wrong password for decryption provided.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).set_children(
            netuid=netuid,
            hotkey=hotkey_ss58,
            children=[
                (float_to_u64(proportion), child_hotkey)
                for proportion, child_hotkey in children
            ],
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def root_set_pending_childkey_cooldown_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    cooldown: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Sets the pending childkey cooldown period in blocks.

    Parameters:
        meshtensor: The Meshtensor client instance used for blockchain interaction.
        wallet: The wallet used to sign the extrinsic (must be unlocked).
        cooldown: The cooldown period in blocks.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks. The transaction remains encrypted in the mempool until validators
            decrypt and execute it. If False, submits the transaction directly without encryption.
        period: The number of blocks during which the transaction will remain valid after it's submitted. If the
            transaction is not included in a block within that number of blocks, it will expire and be rejected. You can
            think of it as an expiration date for the transaction.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Waits for the transaction to be included in a block.
        wait_for_finalization: Waits for the transaction to be finalized on the blockchain.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).set_pending_childkey_cooldown(
            cooldown=cooldown
        )

        sudo_call = await Sudo(meshtensor).sudo(call=call)

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=sudo_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=sudo_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_childkey_take_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    hotkey_ss58: str,
    netuid: int,
    take: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Sets the childkey take for a hotkey on a specific subnet.

    Parameters:
        meshtensor: The AsyncMeshtensor client instance.
        wallet: meshtensor wallet instance.
        hotkey_ss58: The SS58 address of the hotkey to set childkey take for.
        netuid: The netuid of the subnet.
        take: The childkey take value as u16.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet.
        period: The number of blocks during which the transaction will remain valid.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Waits for the transaction to be included in a block.
        wait_for_finalization: Waits for the transaction to be finalized on the blockchain.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        call = await MeshtensorModule(meshtensor).set_childkey_take(
            hotkey=hotkey_ss58, netuid=netuid, take=take
        )

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def _async_root_sudo_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    call,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Helper to wrap a call in Sudo and submit it (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        sudo_call = await Sudo(meshtensor).sudo(call=call)

        if mev_protection:
            response = await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=sudo_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            response = await meshtensor.sign_and_send_extrinsic(
                call=sudo_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )
        return response

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def root_set_tx_childkey_take_rate_limit_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    tx_rate_limit: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Sets the transaction rate limit for changing childkey take. Root-only.

    Parameters:
        meshtensor: The AsyncMeshtensor client instance.
        wallet: The sudo wallet (must be unlocked).
        tx_rate_limit: The new rate limit in blocks (1 to 5_256_000).

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    call = await MeshtensorModule(meshtensor).set_tx_childkey_take_rate_limit(
        tx_rate_limit=tx_rate_limit
    )
    return await _async_root_sudo_extrinsic(
        meshtensor=meshtensor,
        wallet=wallet,
        call=call,
        mev_protection=mev_protection,
        period=period,
        raise_error=raise_error,
        wait_for_inclusion=wait_for_inclusion,
        wait_for_finalization=wait_for_finalization,
        wait_for_revealed_execution=wait_for_revealed_execution,
    )


async def root_set_min_childkey_take_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    take: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Sets the minimum allowed childkey take. Root-only.

    Parameters:
        meshtensor: The AsyncMeshtensor client instance.
        wallet: The sudo wallet (must be unlocked).
        take: The new minimum childkey take value as u16.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    call = await MeshtensorModule(meshtensor).set_min_childkey_take(take=take)
    return await _async_root_sudo_extrinsic(
        meshtensor=meshtensor,
        wallet=wallet,
        call=call,
        mev_protection=mev_protection,
        period=period,
        raise_error=raise_error,
        wait_for_inclusion=wait_for_inclusion,
        wait_for_finalization=wait_for_finalization,
        wait_for_revealed_execution=wait_for_revealed_execution,
    )


async def root_set_max_childkey_take_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    take: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Sets the maximum allowed childkey take. Root-only.

    Parameters:
        meshtensor: The AsyncMeshtensor client instance.
        wallet: The sudo wallet (must be unlocked).
        take: The new maximum childkey take value as u16.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    call = await MeshtensorModule(meshtensor).set_max_childkey_take(take=take)
    return await _async_root_sudo_extrinsic(
        meshtensor=meshtensor,
        wallet=wallet,
        call=call,
        mev_protection=mev_protection,
        period=period,
        raise_error=raise_error,
        wait_for_inclusion=wait_for_inclusion,
        wait_for_finalization=wait_for_finalization,
        wait_for_revealed_execution=wait_for_revealed_execution,
    )
