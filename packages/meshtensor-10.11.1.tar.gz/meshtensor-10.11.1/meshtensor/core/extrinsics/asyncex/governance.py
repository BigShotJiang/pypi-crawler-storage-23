from typing import Optional, TYPE_CHECKING

from meshtensor.core.extrinsics.asyncex.mev_shield import submit_encrypted_extrinsic
from meshtensor.core.extrinsics.pallets import MeshtensorGovernance
from meshtensor.core.settings import DEFAULT_MEV_PROTECTION
from meshtensor.core.types import ExtrinsicResponse
from meshtensor.utils.balance import check_balance_amount

if TYPE_CHECKING:
    from meshtensor_wallet import Wallet
    from meshtensor.core.async_meshtensor import AsyncMeshtensor
    from meshtensor.utils.balance import Balance
    from scalecodec.types import GenericCall


async def submit_referendum_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    track: int,
    call: "GenericCall",
    deposit: "Balance",
    enactment_block: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Submits a new referendum proposal on the specified governance track.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID (0=Root, 1=Treasury, 2=ParameterCritical, etc.).
        call: The proposed runtime call to be executed if the referendum passes.
        deposit: The deposit amount in MESH to lock for the referendum.
        enactment_block: The block number at which the proposal should be enacted if approved.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        check_balance_amount(deposit)

        composed_call = await MeshtensorGovernance(meshtensor).submit_referendum(
            track=track,
            call=call,
            deposit=deposit.meshlet,
            enactment_block=enactment_block,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def vote_referendum_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    ref_index: int,
    vote,
    conviction: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Casts a vote on an active referendum with the specified conviction level.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to vote on.
        vote: True/"aye" for aye, False/"nay" for nay, or "abstain" for abstain.
        conviction: The conviction multiplier (0-6). Higher conviction locks tokens longer for more voting power.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).vote_referendum(
            ref_index=ref_index,
            vote=vote,
            conviction=conviction,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def delegate_voting_power_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    track: int,
    delegatee: str,
    conviction: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Delegates voting power on a specific track to another account.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID to delegate on.
        delegatee: The SS58 address of the account to delegate voting power to.
        conviction: The conviction multiplier (0-6) for the delegated votes.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).delegate(
            track=track,
            delegatee=delegatee,
            conviction=conviction,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def undelegate_voting_power_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    track: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Removes voting power delegation on a specific track.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        track: The governance track ID to undelegate on.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(
            meshtensor
        ).undelegate(
            track=track,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def endorse_referendum_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    ref_index: int,
    track: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Endorses a referendum as a technical committee member.

    Endorsements can accelerate the decision process for referenda.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to endorse.
        track: The governance track ID (0-6) for the endorsement bucket.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).endorse_referendum(
            ref_index=ref_index,
            track=track,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def cancel_referendum_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    ref_index: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Cancels an active referendum.

    Only callable by the referendum proposer or through emergency governance.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        ref_index: The index of the referendum to cancel.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).cancel_referendum(
            ref_index=ref_index,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def submit_treasury_proposal_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    value: "Balance",
    beneficiary: str,
    description_hash: str,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Submits a treasury spending proposal.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        value: The amount in MESH to be spent from the treasury.
        beneficiary: The SS58 address of the account to receive the funds.
        description_hash: The blake2_256 hash of the proposal description.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        check_balance_amount(value)

        composed_call = await MeshtensorGovernance(
            meshtensor
        ).submit_treasury_proposal(
            value=value.meshlet,
            beneficiary=beneficiary,
            description_hash=description_hash,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def approve_treasury_proposal_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    proposal_id: int,
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """
    Approves a pending treasury proposal. Requires appropriate governance origin.

    Parameters:
        meshtensor: Active AsyncMeshtensor connection.
        wallet: Meshtensor Wallet instance used to sign the transaction.
        proposal_id: The unique identifier of the treasury proposal to approve.
        mev_protection: If True, encrypts and submits the transaction through the MEV Shield pallet to protect
            against front-running and MEV attacks.
        period: The number of blocks during which the transaction will remain valid after it's submitted.
        raise_error: Raises a relevant exception rather than returning `False` if unsuccessful.
        wait_for_inclusion: Whether to wait for the extrinsic to be included in a block.
        wait_for_finalization: Whether to wait for finalization of the extrinsic.
        wait_for_revealed_execution: Whether to wait for the revealed execution of transaction if mev_protection used.

    Returns:
        ExtrinsicResponse: The result object of the extrinsic execution.
    """
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(
            meshtensor
        ).approve_treasury_proposal(
            proposal_id=proposal_id,
        )

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def signal_golr_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    *,
    mev_protection: bool = DEFAULT_MEV_PROTECTION,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
    wait_for_revealed_execution: bool = True,
) -> ExtrinsicResponse:
    """Signals support for GoLR activation (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).signal_golr()

        if mev_protection:
            return await submit_encrypted_extrinsic(
                meshtensor=meshtensor,
                wallet=wallet,
                call=composed_call,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
                wait_for_revealed_execution=wait_for_revealed_execution,
            )
        else:
            return await meshtensor.sign_and_send_extrinsic(
                call=composed_call,
                wallet=wallet,
                period=period,
                raise_error=raise_error,
                wait_for_inclusion=wait_for_inclusion,
                wait_for_finalization=wait_for_finalization,
            )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def update_contribution_scores_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Triggers contribution score recalculation (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).update_contribution_scores()

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def claim_governance_rewards_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Claims pending governance rewards (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).claim_governance_rewards()

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def submit_preimage_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    encoded_call: bytes,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Stores a preimage of a runtime call on-chain (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).submit_preimage(
            encoded_call=encoded_call,
        )

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def distribute_governance_rewards_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Distributes governance rewards from the reward pool (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).distribute_governance_rewards()

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_track_coefficients_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    track_id: int,
    alpha: int,
    beta: int,
    gamma: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Updates VP formula coefficients for a governance track (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).set_track_coefficients(
            track_id=track_id, alpha=alpha, beta=beta, gamma=gamma,
        )

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_governance_config_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    min_contribution_floor: int,
    max_delegation_pct: int,
    delegation_factor: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Updates core governance configuration parameters (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).set_governance_config(
            min_contribution_floor=min_contribution_floor,
            max_delegation_pct=max_delegation_pct,
            delegation_factor=delegation_factor,
        )

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def set_golr_config_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    paralysis_days: int,
    threshold_pct: int,
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Updates GoLR parameters (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).set_golr_config(
            paralysis_days=paralysis_days, threshold_pct=threshold_pct,
        )

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)


async def prune_stale_accounts_extrinsic(
    meshtensor: "AsyncMeshtensor",
    wallet: "Wallet",
    accounts: list[str],
    *,
    period: Optional[int] = None,
    raise_error: bool = False,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = True,
) -> ExtrinsicResponse:
    """Prunes governance storage for zero-balance accounts (async version)."""
    try:
        if not (
            unlocked := ExtrinsicResponse.unlock_wallet(wallet, raise_error)
        ).success:
            return unlocked

        composed_call = await MeshtensorGovernance(meshtensor).prune_stale_accounts(
            accounts=accounts,
        )

        return await meshtensor.sign_and_send_extrinsic(
            call=composed_call,
            wallet=wallet,
            period=period,
            raise_error=raise_error,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    except Exception as error:
        return ExtrinsicResponse.from_exception(raise_error=raise_error, error=error)
