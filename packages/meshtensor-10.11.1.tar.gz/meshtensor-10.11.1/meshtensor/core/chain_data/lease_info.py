from dataclasses import dataclass
from enum import Enum
from typing import Optional

from meshtensor.core.chain_data.info_base import InfoBase
from meshtensor.core.chain_data.utils import decode_account_id
from meshtensor.utils.balance import Balance


class ForceTerminationAction(str, Enum):
    """
    Represents the action to take when force-terminating a subnet lease.

    Variants:
        TransferToBeneficiary: Transfer subnet ownership to the beneficiary.
        TransferToDesignated: Transfer subnet ownership to a designated account.
        Dissolve: Dissolve the subnet entirely.
    """

    TransferToBeneficiary = "TransferToBeneficiary"
    TransferToDesignated = "TransferToDesignated"
    Dissolve = "Dissolve"

    @classmethod
    def normalize(cls, value) -> "str | dict":
        """
        Normalizes a ForceTerminationAction to a format suitable for Substrate calls.

        Handles:
        - String values ("TransferToBeneficiary", "Dissolve") -> returns string
        - Enum values -> returns string
        - Dict values ({"TransferToDesignated": account_id}) -> returns dict as-is
        """
        if isinstance(value, cls):
            if value == cls.TransferToDesignated:
                raise ValueError(
                    "TransferToDesignated must be provided as dict: "
                    "{'TransferToDesignated': '<account_id>'}"
                )
            return value.value

        if isinstance(value, str):
            if value in ("TransferToBeneficiary", "Dissolve"):
                return value
            if value == "TransferToDesignated":
                raise ValueError(
                    "TransferToDesignated must be provided as dict: "
                    "{'TransferToDesignated': '<account_id>'}"
                )
            raise ValueError(
                f"Invalid ForceTerminationAction: {value}. "
                f"Valid: 'TransferToBeneficiary', 'Dissolve', or "
                f"{{'TransferToDesignated': '<account_id>'}}"
            )

        if isinstance(value, dict):
            if "TransferToDesignated" in value:
                return value
            raise ValueError(
                f"Invalid dict format for ForceTerminationAction: {value}"
            )

        raise TypeError(
            f"ForceTerminationAction must be str, enum, or dict, "
            f"got {type(value).__name__}"
        )


@dataclass
class SubnetLeaseInfo(InfoBase):
    """
    Represents a subnet lease from on-chain storage.

    Each instance reflects the state of a specific subnet lease as stored in
    ``SubnetLeases`` chain storage, keyed by ``LeaseId``.

    Attributes:
        lease_id: The unique lease identifier (u32).
        beneficiary: The SS58 address of the lease beneficiary.
        coldkey: The SS58 address of the lease coldkey (crowdloan creator).
        hotkey: The SS58 address of the lease hotkey.
        beneficiary_share: The beneficiary's share percentage (0-100).
        end_block: Optional block number when the lease ends.
        netuid: The subnet ID associated with this lease.
        cost: The lock cost paid for the lease.
    """

    lease_id: int
    beneficiary: str
    coldkey: str
    hotkey: str
    beneficiary_share: int
    end_block: Optional[int]
    netuid: int
    cost: Balance

    @classmethod
    def from_dict(cls, lease_id: int, data: dict) -> "SubnetLeaseInfo":
        """Returns a SubnetLeaseInfo object from decoded chain data."""
        return cls(
            lease_id=lease_id,
            beneficiary=decode_account_id(data["beneficiary"]),
            coldkey=decode_account_id(data["coldkey"]),
            hotkey=decode_account_id(data["hotkey"]),
            beneficiary_share=data["beneficiary_share"],
            end_block=data.get("end_block"),
            netuid=data["netuid"],
            cost=Balance.from_meshlet(data["cost"]),
        )

    @classmethod
    def _from_dict(cls, decoded: dict) -> "SubnetLeaseInfo":
        """Returns a SubnetLeaseInfo object from decoded chain data (InfoBase pattern)."""
        return cls.from_dict(decoded.get("lease_id", 0), decoded)
