"""
This module defines the `DynamicInfo` data class and associated methods for handling and decoding dynamic information in
the Meshtensor network.
"""

from dataclasses import dataclass
from typing import Optional, Union

from meshtensor.core.chain_data.info_base import InfoBase
from meshtensor.core.chain_data.utils import decode_account_id

from meshtensor.core.chain_data.subnet_identity import SubnetIdentity
from meshtensor.utils.balance import Balance, fixed_to_float


@dataclass
class DynamicInfo(InfoBase):
    netuid: int
    owner_hotkey: str
    owner_coldkey: str
    subnet_name: str
    symbol: str
    tempo: int
    last_step: int
    blocks_since_last_step: int
    emission: Balance
    alpha_in: Balance
    alpha_out: Balance
    mesh_in: Balance
    price: Optional[Balance]
    k: float
    is_dynamic: bool
    alpha_out_emission: Balance
    alpha_in_emission: Balance
    mesh_in_emission: Balance
    pending_alpha_emission: Balance
    pending_root_emission: Balance
    network_registered_at: int
    subnet_volume: Balance
    subnet_identity: Optional[SubnetIdentity]
    moving_price: float

    @classmethod
    def _from_dict(cls, decoded: dict) -> "DynamicInfo":
        """Returns a DynamicInfo object from decoded chain data."""

        netuid = int(decoded["netuid"])
        symbol = bytes([int(b) for b in decoded["token_symbol"]]).decode()
        subnet_name = bytes([int(b) for b in decoded["subnet_name"]]).decode()

        is_dynamic = (
            True if int(decoded["netuid"]) > 0 else False
        )  # Root is not dynamic

        owner_hotkey = decode_account_id(decoded["owner_hotkey"])
        owner_coldkey = decode_account_id(decoded["owner_coldkey"])

        emission = Balance.from_meshlet(decoded["emission"]).set_unit(0)
        alpha_in = Balance.from_meshlet(decoded["alpha_in"]).set_unit(netuid)
        alpha_out = Balance.from_meshlet(decoded["alpha_out"]).set_unit(netuid)
        # Runtime may return mesh_in
        mesh_in_raw = decoded.get("mesh_in", decoded.get("mesh_in", 0))
        mesh_in = Balance.from_meshlet(mesh_in_raw).set_unit(0)
        alpha_out_emission = Balance.from_meshlet(decoded["alpha_out_emission"]).set_unit(
            netuid
        )
        alpha_in_emission = Balance.from_meshlet(decoded["alpha_in_emission"]).set_unit(
            netuid
        )
        mesh_in_emission_raw = decoded.get("mesh_in_emission", decoded.get("mesh_in_emission", 0))
        mesh_in_emission = Balance.from_meshlet(mesh_in_emission_raw).set_unit(0)
        pending_alpha_emission = Balance.from_meshlet(
            decoded["pending_alpha_emission"]
        ).set_unit(netuid)
        pending_root_emission = Balance.from_meshlet(
            decoded["pending_root_emission"]
        ).set_unit(0)

        subnet_volume = Balance.from_meshlet(decoded["subnet_volume"]).set_unit(netuid)

        if subnet_identity := decoded.get("subnet_identity"):
            # we need to check it for keep backwards compatibility
            logo_bytes = subnet_identity.get("logo_url")
            si_logo_url = bytes(logo_bytes).decode() if logo_bytes else None

            subnet_identity = SubnetIdentity(
                subnet_name=bytes(subnet_identity["subnet_name"]).decode(),
                github_repo=bytes(subnet_identity["github_repo"]).decode(),
                subnet_contact=bytes(subnet_identity["subnet_contact"]).decode(),
                subnet_url=bytes(subnet_identity["subnet_url"]).decode(),
                logo_url=si_logo_url,
                discord=bytes(subnet_identity["discord"]).decode(),
                description=bytes(subnet_identity["description"]).decode(),
                additional=bytes(subnet_identity["additional"]).decode(),
            )
        else:
            subnet_identity = None

        price = decoded.get("price", None)

        if price and not isinstance(price, Balance):
            raise ValueError(f"price must be a Balance object, got {type(price)}.")

        return cls(
            netuid=netuid,
            owner_hotkey=owner_hotkey,
            owner_coldkey=owner_coldkey,
            subnet_name=subnet_name,
            symbol=symbol,
            tempo=int(decoded["tempo"]),
            last_step=int(decoded["last_step"]),
            blocks_since_last_step=int(decoded["blocks_since_last_step"]),
            emission=emission,
            alpha_in=alpha_in,
            alpha_out=alpha_out,
            mesh_in=mesh_in,
            k=mesh_in.meshlet * alpha_in.meshlet,
            is_dynamic=is_dynamic,
            price=(
                price
                if price is not None
                else Balance.from_mesh(mesh_in.mesh / alpha_in.mesh).set_unit(netuid)
            ),
            alpha_out_emission=alpha_out_emission,
            alpha_in_emission=alpha_in_emission,
            mesh_in_emission=mesh_in_emission,
            pending_alpha_emission=pending_alpha_emission,
            pending_root_emission=pending_root_emission,
            network_registered_at=int(decoded["network_registered_at"]),
            subnet_identity=subnet_identity,
            subnet_volume=subnet_volume,
            moving_price=fixed_to_float(decoded["moving_price"], 32),
        )

    def mesh_to_alpha(self, mesh: Union[Balance, float, int]) -> Balance:
        if isinstance(mesh, (float, int)):
            mesh = Balance.from_mesh(mesh)
        if self.price.mesh != 0:
            return Balance.from_mesh(mesh.mesh / self.price.mesh).set_unit(self.netuid)
        else:
            return Balance.from_mesh(0)

    def alpha_to_mesh(self, alpha: Union[Balance, float, int]) -> Balance:
        if isinstance(alpha, (float, int)):
            alpha = Balance.from_mesh(alpha)
        return Balance.from_mesh(alpha.mesh * self.price.mesh)

    def mesh_to_alpha_with_slippage(
        self, mesh: Union[Balance, float, int], percentage: bool = False
    ) -> Union[tuple[Balance, Balance], float]:
        """
        Returns an estimate of how much Alpha would a staker receive if they stake their mesh using the current pool state.

        Parameters:
            mesh: Amount of MESH to stake.
            percentage: percentage

        Returns:
            If percentage is False, a tuple of balances where the first part is the amount of Alpha received, and the
            second part (slippage) is the difference between the estimated amount and ideal
            amount as if there was no slippage. If percentage is True, a float representing the slippage percentage.
        """
        if isinstance(mesh, (float, int)):
            mesh = Balance.from_mesh(mesh)

        if self.is_dynamic:
            new_mesh_in = self.mesh_in + mesh
            if new_mesh_in == 0:
                return mesh, Balance.from_meshlet(0)
            new_alpha_in = self.k / new_mesh_in

            # Amount of alpha given to the staker
            alpha_returned = Balance.from_meshlet(
                self.alpha_in.meshlet - new_alpha_in.meshlet
            ).set_unit(self.netuid)

            # Ideal conversion as if there is no slippage, just price
            alpha_ideal = self.mesh_to_alpha(mesh)

            if alpha_ideal.mesh > alpha_returned.mesh:
                slippage = Balance.from_mesh(
                    alpha_ideal.mesh - alpha_returned.mesh
                ).set_unit(self.netuid)
            else:
                slippage = Balance.from_mesh(0)
        else:
            alpha_returned = mesh.set_unit(self.netuid)
            slippage = Balance.from_mesh(0)

        if percentage:
            slippage_pct_float = (
                100 * float(slippage) / float(slippage + alpha_returned)
                if slippage + alpha_returned != 0
                else 0
            )
            return slippage_pct_float
        else:
            return alpha_returned, slippage

    slippage = mesh_to_alpha_with_slippage
    mesh_slippage = mesh_to_alpha_with_slippage

    def alpha_to_mesh_with_slippage(
        self, alpha: Union[Balance, float, int], percentage: bool = False
    ) -> Union[tuple[Balance, Balance], float]:
        """
        Returns an estimate of how much MESH would a staker receive if they unstake their alpha using the current pool state.

        Parameters:
            alpha: Amount of Alpha to stake.
            percentage: percentage

        Returns:
            If percentage is False, a tuple of balances where the first part is the amount of MESH received, and the
            second part (slippage) is the difference between the estimated amount and ideal
            amount as if there was no slippage. If percentage is True, a float representing the slippage percentage.
        """
        if isinstance(alpha, (float, int)):
            alpha = Balance.from_mesh(alpha)

        if self.is_dynamic:
            new_alpha_in = self.alpha_in + alpha
            new_mesh_reserve = self.k / new_alpha_in
            # Amount of MESH given to the unstaker
            mesh_returned = Balance.from_meshlet(self.mesh_in.meshlet - new_mesh_reserve.meshlet)

            # Ideal conversion as if there is no slippage, just price
            mesh_ideal = self.alpha_to_mesh(alpha)

            if mesh_ideal > mesh_returned:
                slippage = Balance.from_mesh(mesh_ideal.mesh - mesh_returned.mesh)
            else:
                slippage = Balance.from_mesh(0)
        else:
            mesh_returned = alpha.set_unit(0)
            slippage = Balance.from_mesh(0)

        if percentage:
            slippage_pct_float = (
                100 * float(slippage) / float(slippage + mesh_returned)
                if slippage + mesh_returned != 0
                else 0
            )
            return slippage_pct_float
        else:
            return mesh_returned, slippage

    alpha_slippage = alpha_to_mesh_with_slippage
