from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from meshtensor.core.chain_data.info_base import InfoBase
from meshtensor.core.chain_data.utils import decode_account_id
from meshtensor.utils.balance import Balance


class ReferendumStatus(Enum):
    """Status of a referendum in the governance system."""

    Preparing = "Preparing"
    Deciding = "Deciding"
    Confirming = "Confirming"
    Approved = "Approved"
    Rejected = "Rejected"
    Cancelled = "Cancelled"
    TimedOut = "TimedOut"


class GovernanceTrack(Enum):
    """Governance tracks available in the Meshtensor network.

    Each track has different thresholds, periods, and privileges:
        Root: Full root-level access for critical operations.
        Treasury: Treasury spending proposals.
        ParameterCritical: Critical network parameter changes.
        ParameterStandard: Standard network parameter changes.
        Subnet: Subnet-level governance decisions.
        Emergency: Emergency actions requiring fast execution.
        CriticalUpgrade: Critical runtime upgrades.
    """

    Root = 0
    Treasury = 1
    ParameterCritical = 2
    ParameterStandard = 3
    Subnet = 4
    Emergency = 5
    CriticalUpgrade = 6


@dataclass
class ReferendumInfo(InfoBase):
    """Full referendum data from the governance pallet.

    Attributes:
        ref_index: The unique index of the referendum.
        track: The governance track this referendum belongs to.
        proposer: The SS58 address of the account that submitted the referendum.
        call_hash: The blake2_256 hash of the proposed call.
        status: The current status of the referendum.
        tally_ayes: Total voting power in favor.
        tally_nays: Total voting power against.
        tally_support: Total support (participation).
        submission_block: The block number when the referendum was submitted.
        decision_block: The block number when the decision period started, if applicable.
        confirmation_block: The block number when confirmation started, if applicable.
        enactment_block: The block number when the proposal would be enacted, if approved.
        endorsements: Number of technical committee endorsements.
    """

    ref_index: int
    track: int
    proposer: str
    call_hash: str
    status: ReferendumStatus
    tally_ayes: Balance
    tally_nays: Balance
    tally_support: Balance
    submission_block: int
    decision_block: Optional[int]
    confirmation_block: Optional[int]
    enactment_block: Optional[int]
    endorsements: int

    @classmethod
    def _from_dict(cls, decoded: dict) -> "ReferendumInfo":
        """Returns a ReferendumInfo object from decoded chain data."""
        status_str = decoded.get("status", "Preparing")
        if isinstance(status_str, dict):
            status_str = next(iter(status_str.keys()))

        return cls(
            ref_index=decoded["ref_index"],
            track=decoded["track"],
            proposer=decode_account_id(decoded["proposer"]),
            call_hash=decoded["call_hash"],
            status=ReferendumStatus(status_str),
            tally_ayes=Balance.from_meshlet(decoded.get("tally_ayes", 0)),
            tally_nays=Balance.from_meshlet(decoded.get("tally_nays", 0)),
            tally_support=Balance.from_meshlet(decoded.get("tally_support", 0)),
            submission_block=decoded["submission_block"],
            decision_block=decoded.get("decision_block"),
            confirmation_block=decoded.get("confirmation_block"),
            enactment_block=decoded.get("enactment_block"),
            endorsements=decoded.get("endorsements", 0),
        )


@dataclass
class VotingPower(InfoBase):
    """Breakdown of voting power components for an account.

    Attributes:
        raw_stake: The raw staked balance.
        q_norm: Quadratic normalization factor.
        contribution_weight: Weight based on network contributions.
        base_vp: Base voting power before conviction.
        conviction_boost: Multiplier from conviction lock.
        final_vp: Final computed voting power.
    """

    raw_stake: Balance
    q_norm: float
    contribution_weight: float
    base_vp: Balance
    conviction_boost: float
    final_vp: Balance

    @classmethod
    def _from_dict(cls, decoded: dict) -> "VotingPower":
        """Returns a VotingPower object from decoded chain data."""
        return cls(
            raw_stake=Balance.from_meshlet(decoded["raw_stake"]),
            q_norm=decoded["q_norm"],
            contribution_weight=decoded["contribution_weight"],
            base_vp=Balance.from_meshlet(decoded["base_vp"]),
            conviction_boost=decoded["conviction_boost"],
            final_vp=Balance.from_meshlet(decoded["final_vp"]),
        )


@dataclass
class TrackInfo(InfoBase):
    """Configuration for a governance track.

    Attributes:
        track_id: The unique identifier of the track.
        name: Human-readable name of the track.
        approval_threshold: Minimum approval percentage required to pass (0.0-1.0).
        support_threshold: Minimum support (participation) required (0.0-1.0).
        decision_period: Number of blocks for the decision period.
        confirmation_period: Number of blocks for the confirmation period.
        enactment_period: Number of blocks before an approved proposal is enacted.
        min_deposit: Minimum deposit required to submit a referendum on this track.
    """

    track_id: int
    name: str
    approval_threshold: float
    support_threshold: float
    decision_period: int
    confirmation_period: int
    enactment_period: int
    min_deposit: Balance

    @classmethod
    def _from_dict(cls, decoded: dict) -> "TrackInfo":
        """Returns a TrackInfo object from decoded chain data."""
        return cls(
            track_id=decoded["track_id"],
            name=decoded["name"],
            approval_threshold=decoded["approval_threshold"],
            support_threshold=decoded["support_threshold"],
            decision_period=decoded["decision_period"],
            confirmation_period=decoded["confirmation_period"],
            enactment_period=decoded["enactment_period"],
            min_deposit=Balance.from_meshlet(decoded["min_deposit"]),
        )
