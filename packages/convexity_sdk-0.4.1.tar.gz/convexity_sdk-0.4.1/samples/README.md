git pull# Convexity SDK Samples

This directory contains sample scripts demonstrating how to use the Convexity SDK.

## Samples

| Sample                                                               | Description                                 |
| -------------------------------------------------------------------- | ------------------------------------------- |
| [getting_started.py](getting_started.py)                             | Basic SDK setup and usage                   |
| [create_org_and_project.py](create_org_and_project.py)               | Create an organization and project          |
| [create_databricks_connections.py](create_databricks_connections.py) | Create Databricks connections               |
| [create_datasets.py](create_datasets.py)                             | Create datasets from Databricks connections |
| [create_dashboards.py](create_dashboards.py)                         | Create analytic dashboards with widgets     |
| [share_dashboard.py](share_dashboard.py)                             | Share a dashboard with other users          |
| [list_orgs_and_projects.py](list_orgs_and_projects.py)               | List organizations and projects             |
| [query_datalake.py](query_datalake.py)                               | Query the DuckLake warehouse with DuckDB    |
| [create_forecast_task.py](create_forecast_task.py)                   | Create a demand-forecasting task and run it |

## Running Samples

```bash
# From the repo root
uv run python packages/convexity-sdk/samples/getting_started.py
```
