"""
Convexity SDK - Create Organization & Project

This sample demonstrates how to:
- Create a new organization
- Add members to the organization as admins
- Create a project within the organization

Prerequisites:
- A valid API key with WRITE or ADMIN permission
"""

from convexity_api_client.models.organization_role import OrganizationRole

from convexity_sdk import ConvexityClient

client = ConvexityClient()

# ── Step 1: Create a new organization ───────────────────────────────────
org = client.organizations.create(
    name="Convexity SDK samples",
    slug="convexity-sdk-samples",
    description="Organization created by the Convexity SDK sample scripts",
)
print(f"Created organization: {org.name} (id={org.id})")

# ── Step 2: Add admin members ──────────────────────────────────────────
admin_user_ids = [
    "6eadd2f4-08aa-4017-9131-6ba87d066b12",
    "c572deb6-8c2e-4515-a23e-fb468a721048",
]

for user_id in admin_user_ids:
    member = client.organizations.add_member(
        org.id,
        user_id=user_id,
        role=OrganizationRole.ADMIN,
    )
    print(f"  Added admin: {member.user_id} (role={member.role})")

# ── Step 3: Create a project in the organization ───────────────────────
project = client.projects.create(
    name="griffin it",
    slug="griffin-it",
    organization_id=org.id,
    description="Test project created by the Convexity SDK sample scripts",
)
print(f"Created project: {project.name} (id={project.id})")

print("\nDone!")
client.close()
