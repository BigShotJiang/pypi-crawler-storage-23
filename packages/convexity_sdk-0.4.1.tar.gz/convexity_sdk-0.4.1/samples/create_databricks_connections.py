"""
Convexity SDK - Create Databricks Connections

This sample demonstrates how to:
- Look up an existing organization and project by slug
- Create Databricks connections using the generated API client
- Verify each connection after creation

Prerequisites:
- A valid API key with WRITE or ADMIN permission
- The "Convexity SDK samples" organization and "griffin it" project must
  already exist. Run `create_org_and_project.py` first if they don't.
- Set DATABRICKS_* environment variables in .env (see .env.example)
"""

import os
import sys

from convexity_api_client.api.v1 import (
    create_databricks_connection_v1_connections_databricks_post as create_databricks_api,
)
from convexity_api_client.api.v1 import (
    get_organization_by_slug_v1_organizations_slug_slug_get as get_org_by_slug_api,
)
from convexity_api_client.api.v1 import (
    get_project_by_slug_v1_organizations_organization_id_projects_slug_slug_get as get_project_by_slug_api,
)
from convexity_api_client.api.v1 import (
    verify_databricks_connection_v1_connections_databricks_connection_id_verify_post as verify_databricks_api,
)
from convexity_api_client.models.create_databricks_connection_request import CreateDatabricksConnectionRequest
from convexity_api_client.models.verify_result import VerifyResult

from convexity_sdk import ConvexityClient

ORG_SLUG = "convexity-sdk-samples"
PROJECT_SLUG = "griffin-it"

# ── Initialise SDK client ───────────────────────────────────────────────
client = ConvexityClient()
api = client._api_client  # low-level generated client for connection APIs

# ── Step 1: Resolve organization ────────────────────────────────────────
org = get_org_by_slug_api.sync(ORG_SLUG, client=api)
if org is None or not hasattr(org, "id"):
    print(
        f'ERROR: Organization "{ORG_SLUG}" not found.\nPlease run create_org_and_project.py first.',
        file=sys.stderr,
    )
    raise SystemExit(1)
print(f"Found organization: {org.name} (id={org.id})")

# ── Step 2: Resolve project ────────────────────────────────────────────
project = get_project_by_slug_api.sync(org.id, PROJECT_SLUG, client=api)
if project is None or not hasattr(project, "id"):
    print(
        f'ERROR: Project "{PROJECT_SLUG}" not found in organization "{ORG_SLUG}".\nPlease run create_org_and_project.py first.',
        file=sys.stderr,
    )
    raise SystemExit(1)
print(f"Found project: {project.name} (id={project.id})")

# ── Step 3: Read Databricks credentials from environment ────────────────
server_hostname = os.environ["DATABRICKS_SERVER_HOSTNAME"]
http_path = os.environ["DATABRICKS_HTTP_PATH"]
access_token = os.environ["DATABRICKS_ACCESS_TOKEN"]

# ── Step 4: Create "canonical" Databricks connection ────────────────────
canonical_body = CreateDatabricksConnectionRequest(
    name="canonical",
    project_id=project.id,
    server_hostname=server_hostname,
    http_path=http_path,
    access_token=access_token,
    db_schema="analytics",
    description="Databricks canonical connection (analytics schema)",
)
canonical = create_databricks_api.sync(client=api, body=canonical_body, project_id=project.id)
print(f"Created connection: {canonical.name} (id={canonical.id})")

# ── Step 5: Create "analytic" Databricks connection ─────────────────────
analytic_body = CreateDatabricksConnectionRequest(
    name="analytic",
    project_id=project.id,
    server_hostname=server_hostname,
    http_path=http_path,
    access_token=access_token,
    db_schema="canonical",
    description="Databricks analytic connection (canonical schema)",
)
analytic = create_databricks_api.sync(client=api, body=analytic_body, project_id=project.id)
print(f"Created connection: {analytic.name} (id={analytic.id})")

# ── Step 6: Verify both connections ─────────────────────────────────────
for conn in [canonical, analytic]:
    result = verify_databricks_api.sync(conn.id, client=api)
    if isinstance(result, VerifyResult):
        status = "OK" if result.success else "FAILED"
        print(f"  Verify [{conn.name}]: {status} — {result.message}")
    else:
        print(f"  Verify [{conn.name}]: unexpected response — {result}")

print("\nDone!")

# -- Step 7: Print the schemas of both connections to verify they are different --
print(f"\nCanonical connection schema: {canonical.db_schema}")
print(f"Analytic connection schema: {analytic.db_schema}")
client.close()
