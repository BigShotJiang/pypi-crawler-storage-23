"""Project resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    create_project_v1_projects_post as _create_project,
)
from convexity_api_client.api.v1 import (
    get_project_v1_projects_project_id_get as _get_project,
)
from convexity_api_client.api.v1 import (
    list_organization_projects_v1_organizations_organization_id_projects_get as _list_org_projects,
)
from convexity_api_client.api.v1 import (
    list_user_projects_v1_projects_get as _list_projects,
)
from convexity_api_client.models.create_project_request import CreateProjectRequest
from convexity_api_client.models.project_list_response import ProjectListResponse
from convexity_api_client.models.project_response import ProjectResponse


class Projects:
    """Synchronous sub-client for project operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def list(self) -> ProjectListResponse:
        """List all projects the authenticated user has access to."""
        result = _list_projects.sync(client=self._client)
        if result is None:
            return ProjectListResponse(projects=[], total=0)
        return result

    def list_by_organization(self, organization_id: str) -> ProjectListResponse:
        """List projects within a specific organization."""
        result = _list_org_projects.sync(organization_id, client=self._client)
        if result is None:
            return ProjectListResponse(projects=[], total=0)
        # The generated func may return HTTPValidationError on 422;
        # with raise_on_unexpected_status=True that won't reach here.
        if not isinstance(result, ProjectListResponse):
            return ProjectListResponse(projects=[], total=0)
        return result

    def get(self, project_id: str) -> ProjectResponse | None:
        """Get a single project by ID."""
        result = _get_project.sync(project_id, client=self._client)
        if isinstance(result, ProjectResponse):
            return result
        return None

    def create(
        self,
        *,
        name: str,
        slug: str,
        organization_id: str,
        description: str | None = None,
    ) -> ProjectResponse:
        """Create a new project in an organization."""
        body = CreateProjectRequest(
            name=name,
            slug=slug,
            organization_id=organization_id,
            description=description,
        )
        result = _create_project.sync(client=self._client, body=body)
        if not isinstance(result, ProjectResponse):
            raise ValueError(f"Unexpected response when creating project: {result}")
        return result
