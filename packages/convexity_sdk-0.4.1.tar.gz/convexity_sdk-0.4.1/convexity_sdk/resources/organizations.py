"""Organization resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    add_member_v1_organizations_organization_id_members_post as _add_member,
)
from convexity_api_client.api.v1 import (
    create_organization_v1_organizations_post as _create_org,
)
from convexity_api_client.api.v1 import (
    get_organization_v1_organizations_organization_id_get as _get_org,
)
from convexity_api_client.api.v1 import (
    list_organizations_v1_organizations_get as _list_orgs,
)
from convexity_api_client.models.add_organization_member_request import AddOrganizationMemberRequest
from convexity_api_client.models.create_organization_request import CreateOrganizationRequest
from convexity_api_client.models.organization_list_response import OrganizationListResponse
from convexity_api_client.models.organization_member_response import OrganizationMemberResponse
from convexity_api_client.models.organization_response import OrganizationResponse
from convexity_api_client.models.organization_role import OrganizationRole


class Organizations:
    """Synchronous sub-client for organization operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def list(self) -> OrganizationListResponse:
        """List all organizations the authenticated user belongs to."""
        result = _list_orgs.sync(client=self._client)
        if result is None:
            return OrganizationListResponse(organizations=[], total=0)
        return result

    def get(self, organization_id: str) -> OrganizationResponse | None:
        """Get a single organization by ID."""
        return _get_org.sync(organization_id, client=self._client)

    def create(
        self,
        *,
        name: str,
        slug: str,
        description: str | None = None,
    ) -> OrganizationResponse:
        """Create a new organization."""
        body = CreateOrganizationRequest(
            name=name,
            slug=slug,
            description=description,
        )
        result = _create_org.sync(client=self._client, body=body)
        if not isinstance(result, OrganizationResponse):
            raise ValueError(f"Unexpected response when creating organization: {result}")
        return result

    def add_member(
        self,
        organization_id: str,
        *,
        user_id: str,
        role: OrganizationRole = OrganizationRole.MEMBER,
    ) -> OrganizationMemberResponse:
        """Add a member to an organization."""
        body = AddOrganizationMemberRequest(
            user_id=user_id,
            role=role,
        )
        result = _add_member.sync(organization_id, client=self._client, body=body)
        if not isinstance(result, OrganizationMemberResponse):
            raise ValueError(f"Unexpected response when adding member: {result}")
        return result
