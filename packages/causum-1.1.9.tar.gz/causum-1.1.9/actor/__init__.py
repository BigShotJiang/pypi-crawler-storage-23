"""
Actor namespace package.
"""
try:
    from importlib.metadata import version as _version

    __version__ = _version("causum")
except Exception:
    __version__ = "1.0.0"
