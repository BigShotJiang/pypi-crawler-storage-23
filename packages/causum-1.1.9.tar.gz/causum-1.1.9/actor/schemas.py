from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

_SCHEMA_CACHE: Dict[str, Dict[str, Any]] = {}


def load_schema(name: str) -> Dict[str, Any]:
    """Load and cache a JSON schema from the schemas/ directory."""
    if name in _SCHEMA_CACHE:
        return _SCHEMA_CACHE[name]
    schema_path = Path(__file__).resolve().parent / "schemas" / name
    data = json.loads(schema_path.read_text())
    _SCHEMA_CACHE[name] = data
    return data
