"""
Logging service providing controlled file/stdout logging with optional in-memory buffer.
"""

from .service import LoggingService

__all__ = ["LoggingService"]
