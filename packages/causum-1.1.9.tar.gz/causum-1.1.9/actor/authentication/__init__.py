"""
Universal Connection Manager package.
"""

from .manager import ConnectionManager
from .exceptions import (
    SecretProviderError,
    ConfigurationError,
    AuthMaterializationError,
    ValidationError,
)

__all__ = [
    "ConnectionManager",
    "SecretProviderError",
    "ConfigurationError",
    "AuthMaterializationError",
    "ValidationError",
]
