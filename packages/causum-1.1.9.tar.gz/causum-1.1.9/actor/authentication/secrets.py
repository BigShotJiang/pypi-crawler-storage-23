from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional

from .exceptions import ConfigurationError, SecretProviderError
from .config import SecretStoreConfig


class SecretProvider:
    """Base secret provider interface."""

    def get(self, key: str) -> str:
        raise NotImplementedError


class CompositeSecretProvider(SecretProvider):
    """Resolve literals first, then delegate to a base provider."""

    def __init__(self, base: Optional[SecretProvider], literals: Dict[str, object]):
        self.base = base
        self.literals = literals

    def get(self, key: str) -> str:
        if key in self.literals:
            val = self.literals[key]
            return str(val)
        if not self.base:
            raise SecretProviderError(f"Secret '{key}' not found in literals and no base provider configured")
        return self.base.get(key)


class EnvSecretProvider(SecretProvider):
    def get(self, key: str) -> str:
        if key not in os.environ:
            raise SecretProviderError(f"Environment variable '{key}' not found")
        return os.environ[key]


class FileSecretProvider(SecretProvider):
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        if not self.base_path.exists():
            raise SecretProviderError(f"Secret directory not found: {base_path}")

    def get(self, key: str) -> str:
        secret_path = self.base_path / key
        if not secret_path.exists():
            raise SecretProviderError(f"Secret file not found: {secret_path}")
        try:
            return secret_path.read_text().strip()
        except OSError as exc:
            raise SecretProviderError(f"Failed reading secret file {secret_path}: {exc}") from exc


class VaultSecretProvider(SecretProvider):
    def __init__(self, url: str, token_path: str, mount_point: str, namespace: Optional[str] = None):
        try:
            import hvac  # type: ignore
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise SecretProviderError("hvac library required for vault provider") from exc

        token_file = Path(token_path)
        if not token_file.exists():
            raise SecretProviderError(f"Vault token file not found: {token_path}")
        token = token_file.read_text().strip()

        client = hvac.Client(url=url, token=token, namespace=namespace)
        if not client.is_authenticated():  # pragma: no cover - requires live Vault
            raise SecretProviderError("Failed to authenticate to Vault with provided token")

        self.client = client
        self.mount_point = mount_point

    def get(self, key: str) -> str:
        try:
            response = self.client.secrets.kv.v2.read_secret_version(  # type: ignore[attr-defined]
                path=key,
                mount_point=self.mount_point,
            )
        except Exception as exc:  # pragma: no cover - live Vault only
            raise SecretProviderError(f"Vault secret read failed for key '{key}': {exc}") from exc

        data = response.get("data", {}).get("data") if isinstance(response, dict) else None
        if not data:
            raise SecretProviderError(f"Vault secret '{key}' missing data payload")
        # Prefer "value", otherwise allow single-field secrets to remain usable.
        if "value" in data:
            return data["value"]
        if len(data) == 1:
            return next(iter(data.values()))
        raise SecretProviderError(
            f"Vault secret '{key}' contains multiple fields; specify a singular path or flatten the secret."
        )


class KubernetesSecretProvider(SecretProvider):
    def __init__(
        self,
        namespace: str,
        default_secret: Optional[str] = None,
        context: Optional[str] = None,
        kubeconfig_path: Optional[str] = None,
    ):
        try:
            from kubernetes import client, config  # type: ignore
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise SecretProviderError("kubernetes library required for k8s provider") from exc

        loaded = False
        try:
            config.load_incluster_config()
            loaded = True
        except Exception:
            pass
        if not loaded:
            try:
                config.load_kube_config(config_file=kubeconfig_path, context=context)
                loaded = True
            except Exception as exc:
                raise SecretProviderError(f"Failed to load kubeconfig: {exc}")
        self.core = client.CoreV1Api()
        self.namespace = namespace
        self.default_secret = default_secret

    def get(self, key: str) -> str:
        # mapping value may be "secret_name:key" or just "key" using default secret
        secret_name = self.default_secret
        data_key = key
        if ":" in key:
            secret_name, data_key = key.split(":", 1)
        if not secret_name:
            raise SecretProviderError("K8s secret name is required (set default_secret or use 'name:key' mapping).")
        try:
            secret = self.core.read_namespaced_secret(secret_name, self.namespace)
        except Exception as exc:  # pragma: no cover - live cluster only
            raise SecretProviderError(f"K8s secret fetch failed for '{secret_name}' in ns '{self.namespace}': {exc}") from exc
        if not secret.data or data_key not in secret.data:
            raise SecretProviderError(f"K8s secret '{secret_name}' missing key '{data_key}'")
        try:
            import base64

            return base64.b64decode(secret.data[data_key]).decode()
        except Exception as exc:  # pragma: no cover - depends on secret content
            raise SecretProviderError(f"K8s secret '{secret_name}' key '{data_key}' could not be decoded: {exc}") from exc


def fetch_secret(
    provider: SecretProvider,
    mapping: Dict[str, str],
    key: str,
    required: bool = True,
) -> Optional[str]:
    """Fetch a secret value from *provider* using *mapping*.

    This is the single canonical helper used by database, LLM, and embedding
    authentication builders.
    """
    if key not in mapping:
        if required:
            raise ConfigurationError(f"Secret mapping missing required key '{key}'")
        return None
    try:
        return provider.get(mapping[key])
    except SecretProviderError:
        raise
    except Exception as exc:
        raise SecretProviderError(f"Failed retrieving secret '{mapping[key]}': {exc}") from exc


def build_secret_provider(config: SecretStoreConfig) -> SecretProvider:
    provider = config.provider
    if provider == "env":
        return EnvSecretProvider()
    if provider == "file":
        assert config.file  # validated in pydantic
        return FileSecretProvider(config.file.path)
    if provider == "vault":
        assert config.vault  # validated in pydantic
        return VaultSecretProvider(
            url=config.vault.url,
            token_path=config.vault.token_path,
            mount_point=config.vault.mount_point,
            namespace=config.vault.namespace,
        )
    if provider == "k8s":
        assert config.k8s  # validated in pydantic
        return KubernetesSecretProvider(
            namespace=config.k8s.namespace,
            default_secret=config.k8s.default_secret,
            context=config.k8s.context,
            kubeconfig_path=config.k8s.kubeconfig_path,
        )
    raise SecretProviderError(f"Unsupported secret provider '{provider}'")
