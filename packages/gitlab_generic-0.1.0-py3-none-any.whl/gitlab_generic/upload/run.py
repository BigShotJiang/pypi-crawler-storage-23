# ────────────────────────────────────────────────────────────────────────────────────────
#   upload/run.py
#   ─────────────
#
#   CLI runner for the upload command — uploads files to the Generic Package Registry.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
#   Feb 2026 - Auto-detect name/version from filenames; group multi-file uploads
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import sys
from argparse import Namespace
from pathlib import Path
from ..common import APIError
from ..common import GitLabAPI
from ..common import parse_filename
from ..common import resolve_config
from ..common.output import bold
from ..common.output import format_size
from ..common.output import green
from ..common.output import red
from ..common.output import yellow

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: Namespace) -> int:
    """Upload file(s) to the Generic Package Registry."""
    config = resolve_config(args)
    if config is None:
        return 1

    api = GitLabAPI(config["url"], config["token"], verbose=args.verbose)
    file_paths = [Path(f) for f in args.files]
    cli_name: str | None = getattr(args, "name", None)
    cli_version: str | None = getattr(args, "version", None)

    # Validate all files exist before uploading any
    for file_path in file_paths:
        if not file_path.exists():
            print(red("Error:") + f" File not found: {file_path}", file=sys.stderr)
            return 1

    # Build groups of (name, version) -> [file_paths]
    groups: dict[tuple[str, str], list[Path]] = {}

    for file_path in file_paths:
        name = cli_name
        version = cli_version

        if not name or not version:
            detected = parse_filename(file_path.name)
            if detected is None:
                print(
                    red("Error:")
                    + f" Cannot detect name/version from filename: {file_path.name}",
                    file=sys.stderr,
                )
                print(
                    yellow("Tip:") + " Use --name and --version to specify explicitly.",
                    file=sys.stderr,
                )
                return 1
            if not name:
                name = detected[0]
            if not version:
                version = detected[1]

        groups.setdefault((name, version), []).append(file_path)

    # Upload each group
    total_files = 0
    failed = 0
    multi_group = len(groups) > 1

    for (package_name, version), paths in sorted(groups.items()):
        if multi_group:
            print(bold(f"{package_name}=={version}"))

        for file_path in paths:
            file_size = file_path.stat().st_size
            print(f"  Uploading {file_path.name} ({format_size(file_size)})...")
            total_files += 1

            try:
                api.upload_file(config["project"], package_name, version, file_path)
            except APIError as e:
                print(red("  Error:") + f" {e}", file=sys.stderr)
                failed += 1
                continue

            print(green("  OK"))

    if failed:
        print(red(f"\n{failed} of {total_files} uploads failed."))
        return 1

    print(green(f"\n{total_files} file(s) uploaded successfully."))
    return 0
