# ────────────────────────────────────────────────────────────────────────────────────────
#   list_cmd/run.py
#   ───────────────
#
#   CLI runner for the list command — lists packages in a GitLab Generic Package Registry.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import json
import sys
from argparse import Namespace
from ..common import APIError
from ..common import GitLabAPI
from ..common import resolve_config
from ..common.output import cyan
from ..common.output import dim
from ..common.output import green
from ..common.output import is_prerelease
from ..common.output import print_table
from ..common.output import red
from ..common.output import version_key
from ..common.output import yellow

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: Namespace) -> int:
    """List packages in the Generic Package Registry."""
    config = resolve_config(args)
    if config is None:
        return 1

    api = GitLabAPI(config["url"], config["token"], verbose=args.verbose)
    name_filter: str | None = getattr(args, "name", None)

    try:
        packages = api.list_packages(config["project"], name=name_filter)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    if not packages:
        if args.json:
            print("[]")
        else:
            print(yellow("No packages found."))
        return 0

    # Group by package name: collect all versions per package
    by_name: dict[str, list[dict[str, object]]] = {}
    for pkg in packages:
        name = str(pkg.get("name", ""))
        by_name.setdefault(name, []).append(pkg)

    if args.json:
        result: list[dict[str, object]] = []
        for name, versions in sorted(by_name.items()):
            versions.sort(
                key=lambda p: version_key(str(p.get("version", ""))), reverse=True
            )
            stable = [
                v for v in versions if not is_prerelease(str(v.get("version", "")))
            ]
            latest = str((stable[0] if stable else versions[0]).get("version", ""))
            all_versions = [str(v.get("version", "")) for v in versions]
            result.append(
                {
                    "name": name,
                    "version_count": len(versions),
                    "latest": latest,
                    "versions": all_versions,
                }
            )
        print(json.dumps(result, indent=2))
        return 0

    rows: list[list[str]] = []
    for name, versions in sorted(by_name.items()):
        # Sort by version using PEP 440 ordering (pre-release < release)
        versions.sort(
            key=lambda p: version_key(str(p.get("version", ""))), reverse=True
        )
        count = str(len(versions))

        # Find latest stable (non-prerelease) version; fall back to latest overall
        stable = [v for v in versions if not is_prerelease(str(v.get("version", "")))]
        latest = str((stable[0] if stable else versions[0]).get("version", ""))

        rows.append([cyan(name), dim(count), green(latest)])

    print_table(["Name", "Versions", "Latest"], rows)
    return 0
