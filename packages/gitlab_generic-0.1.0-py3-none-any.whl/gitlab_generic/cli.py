# ────────────────────────────────────────────────────────────────────────────────────────
#   cli.py
#   ──────
#
#   Main CLI for gitlab-generic with subcommand dispatch.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import sys
import traceback
from pathlib import Path
from .argbuilder import ArgsParser
from .argbuilder import Namespace
from .version import VERSION_STR

# ────────────────────────────────────────────────────────────────────────────────────────
#   Descriptions
# ────────────────────────────────────────────────────────────────────────────────────────

LIST_DESCRIPTION = """\
List packages in a GitLab project's Generic Package Registry.

Shows one line per package with the version count and latest stable
version. Use --name to filter by package name, or --json for
machine-readable output.

Example:
  gitlab-generic list
  gitlab-generic list --name my-package
  gitlab-generic list --json
"""

SHOW_DESCRIPTION = """\
Show versions for one or more packages.

Lists all stable versions of each named package, newest first, with
creation dates and file details. Pre-release versions are hidden by
default.

Use --all to include pre-release versions, --plain for bare
package==version lines, or --json for machine-readable output.

Example:
  gitlab-generic show my-package
  gitlab-generic show package-a package-b
  gitlab-generic show my-package --all
  gitlab-generic show my-package --plain
"""

DOWNLOAD_DESCRIPTION = """\
Download file(s) from the Generic Package Registry.

Downloads all files for a package version. Use package==version to
select a specific version; without it the latest stable release is
used. Use --all to download every version of a package.

Example:
  gitlab-generic download my-package
  gitlab-generic download my-package==1.2.3
  gitlab-generic download package-a package-b -o ./files/
  gitlab-generic download my-package --all
"""

UPLOAD_DESCRIPTION = """\
Upload file(s) to the Generic Package Registry.

If --name and --version are given, all files are uploaded to that
package version. Otherwise the package name and version are detected
from each filename (e.g. "calrep-0.29.0-linux-x64.tar.gz" is
detected as package "calrep" version "0.29.0"). Files with the same
detected name and version are grouped and uploaded together.

Example:
  gitlab-generic upload dist/app.tar.gz --name my-package --version 1.0.0
  gitlab-generic upload *.tar.gz
  gitlab-generic upload calrep-0.29.0-*.tar.gz caltech-0.24.0-*.tar.gz
"""

DELETE_DESCRIPTION = """\
Delete one or more package versions from the registry.

Specify each package and version using package==version format.

Example:
  gitlab-generic delete my-package==1.2.3
  gitlab-generic delete package-a==1.0.0 package-b==2.0.0
"""

# ────────────────────────────────────────────────────────────────────────────────────────
#   Argument Parsing
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def create_parser() -> ArgsParser:
    """Create the main argument parser with subcommands."""
    parser = ArgsParser(
        prog="gitlab-generic",
        description="Manage files in a GitLab Generic Package Registry.",
        version=f"gitlab-generic {VERSION_STR}",
    )

    # =========== Common Options ===========

    common = parser.create_common_collection()
    common.add_argument(
        "-c",
        "--config",
        type=Path,
        help="Path to JSON config file (default: ~/.config/gitlab-generic/config.json)",
    )
    common.add_argument(
        "--url",
        help="GitLab instance URL (default: https://gitlab.com)",
    )
    common.add_argument(
        "-p",
        "--project",
        help="GitLab project ID or path (e.g., 12345 or group/project)",
    )
    common.add_argument(
        "-t",
        "--token",
        help="GitLab private access token",
    )
    common.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Show verbose output",
    )

    # =========== List Command ===========

    list_cmd = parser.add_command(
        "list",
        help="List packages in the registry",
        description=LIST_DESCRIPTION,
    )
    list_cmd.add_argument(
        "--name",
        help="Filter by package name",
    )
    list_cmd.add_argument(
        "-j",
        "--json",
        action="store_true",
        help="Output as JSON",
    )

    # =========== Show Command ===========

    show_cmd = parser.add_command(
        "show",
        help="Show versions for one or more packages",
        description=SHOW_DESCRIPTION,
    )
    show_cmd.add_argument(
        "package_names",
        nargs="+",
        help="Package name(s) to show",
    )
    show_cmd.add_argument(
        "-a",
        "--all",
        action="store_true",
        help="Include pre-release versions (hidden by default)",
    )
    show_cmd.add_argument(
        "--plain",
        action="store_true",
        help="Plain output: one package==version per line, no colour or headers",
    )
    show_cmd.add_argument(
        "-j",
        "--json",
        action="store_true",
        help="Output as JSON",
    )

    # =========== Download Command ===========

    download_cmd = parser.add_command(
        "download",
        help="Download file(s) from the registry",
        description=DOWNLOAD_DESCRIPTION,
    )
    download_cmd.add_argument(
        "packages",
        nargs="+",
        help="Package(s) to download (my-package or my-package==1.2.3)",
    )
    download_cmd.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        help="Output directory (default: current directory)",
    )
    download_cmd.add_argument(
        "-a",
        "--all",
        action="store_true",
        help="Download all versions of the named package(s)",
    )

    # =========== Upload Command ===========

    upload_cmd = parser.add_command(
        "upload",
        help="Upload file(s) to the registry",
        description=UPLOAD_DESCRIPTION,
    )
    upload_cmd.add_argument(
        "files",
        nargs="+",
        help="Path(s) to file(s) to upload",
    )
    upload_cmd.add_argument(
        "-n",
        "--name",
        help="Package name (auto-detected from filename if omitted)",
    )
    upload_cmd.add_argument(
        "--version",
        help="Package version (auto-detected from filename if omitted)",
    )

    # =========== Delete Command ===========

    delete_cmd = parser.add_command(
        "delete",
        help="Delete package version(s) from the registry",
        description=DELETE_DESCRIPTION,
    )
    delete_cmd.add_argument(
        "packages",
        nargs="+",
        help="Package version(s) to delete (my-package==1.2.3)",
    )

    return parser


# ────────────────────────────────────────────────────────────────────────────────────────
#   Main Entry Point
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    """
    Main entry point for gitlab-generic CLI.

    Parameters:
        argv: Command line arguments (without program name). If None, uses sys.argv[1:].

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    if argv is None:
        argv = sys.argv[1:]

    try:
        return _main_inner(argv)
    except KeyboardInterrupt:
        print()
        print("---- Manually Terminated ----")
        print()
        return 1
    except SystemExit:
        raise
    except BaseException as e:
        t = "-----------------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-----------------------------------------------------------------------------\n"
        t += "\n"
        print(t, file=sys.stderr)
        return 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _main_inner(argv: list[str]) -> int:
    """Inner main function that does the actual work."""
    from . import delete
    from . import download
    from . import list_cmd
    from . import show
    from . import upload

    parser = create_parser()
    args: Namespace = parser.parse(argv)

    if not args.command:
        return 0  # Help was shown by ArgsParser

    commands = {
        "list": list_cmd.run,
        "show": show.run,
        "download": download.run,
        "upload": upload.run,
        "delete": delete.run,
    }

    return commands[args.command](args)
