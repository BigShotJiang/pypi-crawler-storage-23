# ────────────────────────────────────────────────────────────────────────────────────────
#   show
#   ────
#
#   Show versions and files for a specific package.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

from .run import run

__all__ = ["run"]
