# ────────────────────────────────────────────────────────────────────────────────────────
#   show/run.py
#   ───────────
#
#   CLI runner for the show command — shows versions and files for a package.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import json
import sys
from argparse import Namespace
from ..common import APIError
from ..common import GitLabAPI
from ..common import resolve_config
from ..common.output import bold
from ..common.output import cyan
from ..common.output import dim
from ..common.output import format_size
from ..common.output import green
from ..common.output import is_prerelease
from ..common.output import print_table
from ..common.output import red
from ..common.output import version_key
from ..common.output import yellow

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: Namespace) -> int:
    """Show versions for one or more packages."""
    config = resolve_config(args)
    if config is None:
        return 1

    api = GitLabAPI(config["url"], config["token"], verbose=args.verbose)
    package_names: list[str] = args.package_names
    exit_code = 0

    show_all: bool = getattr(args, "all", False)
    plain: bool = args.plain
    as_json: bool = args.json

    if as_json:
        return _show_json(api, config["project"], package_names, show_all=show_all)

    for i, package_name in enumerate(package_names):
        if i > 0 and not plain:
            print()

        code = _show_package(
            api, config["project"], package_name, show_all=show_all, plain=plain
        )
        if code != 0:
            exit_code = code

    return exit_code


# ────────────────────────────────────────────────────────────────────────────────────────
def _show_json(
    api: GitLabAPI,
    project: str,
    package_names: list[str],
    *,
    show_all: bool,
) -> int:
    """Output version info as JSON for one or more packages."""
    result: list[dict[str, object]] = []
    exit_code = 0

    for package_name in package_names:
        try:
            all_packages = api.list_packages(project, name=package_name)
        except APIError as e:
            print(red("Error:") + f" {e}", file=sys.stderr)
            exit_code = 1
            continue

        all_packages = [p for p in all_packages if p.get("name") == package_name]
        if not all_packages:
            exit_code = 1
            continue

        all_packages.sort(
            key=lambda p: version_key(str(p.get("version", ""))), reverse=True
        )

        if show_all:
            packages = all_packages
        else:
            packages = [
                p for p in all_packages if not is_prerelease(str(p.get("version", "")))
            ]

        versions: list[dict[str, object]] = []
        for pkg in packages:
            pkg_id = int(pkg.get("id", 0))  # type: ignore[arg-type]
            try:
                files = api.get_package_files(project, pkg_id)
            except APIError:
                files = []

            file_list: list[dict[str, str | int]] = [
                {
                    "name": str(f.get("file_name", "")),
                    "size": int(f.get("size", 0)),
                }
                for f in files
            ]

            versions.append(
                {
                    "version": str(pkg.get("version", "")),
                    "created": str(pkg.get("created_at", ""))[:10],
                    "files": file_list,
                }
            )

        result.append({"name": package_name, "versions": versions})

    print(json.dumps(result, indent=2))
    return exit_code


# ────────────────────────────────────────────────────────────────────────────────────────
def _show_package(
    api: GitLabAPI,
    project: str,
    package_name: str,
    *,
    show_all: bool,
    plain: bool,
) -> int:
    """Show versions for a single package."""
    try:
        all_packages = api.list_packages(project, name=package_name)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    # Filter to exact name match (API does substring matching)
    all_packages = [p for p in all_packages if p.get("name") == package_name]

    if not all_packages:
        if not plain:
            print(yellow(f"No package found: {package_name}"))
        return 1

    # Sort by version (newest first)
    all_packages.sort(
        key=lambda p: version_key(str(p.get("version", ""))), reverse=True
    )

    # Filter to stable only unless --all
    if show_all:
        packages = all_packages
    else:
        packages = [
            p for p in all_packages if not is_prerelease(str(p.get("version", "")))
        ]

    # Plain mode: just print package==version lines
    if plain:
        for pkg in packages:
            version = str(pkg.get("version", ""))
            print(f"{package_name}=={version}")
        return 0

    total = len(all_packages)
    shown = len(packages)
    if shown == total:
        count_label = f"({total} versions)"
    else:
        count_label = f"({shown} of {total} versions)"

    print(bold(package_name) + dim(f"  {count_label}"))
    print()

    if not packages:
        print(dim("  No stable versions found. Use --all to include pre-releases."))
        return 0

    # Latest stable for tagging
    stable = [p for p in packages if not is_prerelease(str(p.get("version", "")))]
    latest_stable = str(stable[0].get("version", "")) if stable else None

    rows: list[list[str]] = []
    for pkg in packages:
        version = str(pkg.get("version", ""))
        created = str(pkg.get("created_at", ""))[:10]

        spec = f"{package_name}=={version}"
        if version == latest_stable:
            v_display = green(spec) + cyan(" (latest)")
        elif is_prerelease(version):
            v_display = yellow(spec)
        else:
            v_display = green(spec)

        # Fetch files for this version
        pkg_id = int(pkg.get("id", 0))  # type: ignore[arg-type]
        try:
            files = api.get_package_files(project, pkg_id)
        except APIError:
            files = []

        file_count = str(len(files))
        total_size = sum(int(f.get("size", 0)) for f in files)

        rows.append(
            [v_display, dim(created), dim(file_count), dim(format_size(total_size))]
        )

    print_table(["Version", "Created", "Files", "Size"], rows)
    return 0
