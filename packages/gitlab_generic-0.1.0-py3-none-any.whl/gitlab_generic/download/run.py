# ────────────────────────────────────────────────────────────────────────────────────────
#   download/run.py
#   ───────────────
#
#   CLI runner for the download command — downloads files from the Generic Package
#   Registry.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import sys
from argparse import Namespace
from pathlib import Path
from ..common import APIError
from ..common import GitLabAPI
from ..common import parse_package_spec
from ..common import resolve_config
from ..common.output import format_size
from ..common.output import green
from ..common.output import is_prerelease
from ..common.output import red
from ..common.output import version_key
from ..common.output import yellow

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: Namespace) -> int:
    """Download package files from the registry."""
    config = resolve_config(args)
    if config is None:
        return 1

    api = GitLabAPI(config["url"], config["token"], verbose=args.verbose)
    specs: list[str] = args.packages
    output_dir = Path(getattr(args, "output_dir", None) or ".")
    download_all: bool = getattr(args, "all", False)
    exit_code = 0

    for spec in specs:
        package_name, version_filter = parse_package_spec(spec)

        if download_all:
            if version_filter is not None:
                print(
                    red("Error:") + f" Do not use ==version with --all: {spec}",
                    file=sys.stderr,
                )
                exit_code = 1
                continue
            code = _download_all(api, config["project"], package_name, output_dir)
        else:
            code = _download_one(
                api,
                config["project"],
                package_name,
                version_filter,
                output_dir,
            )

        if code != 0:
            exit_code = code

    return exit_code


# ────────────────────────────────────────────────────────────────────────────────────────
def _download_all(
    api: GitLabAPI,
    project: str,
    package_name: str,
    output_dir: Path,
) -> int:
    """Download all versions of a package."""
    try:
        packages = api.list_packages(project, name=package_name)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    packages = [p for p in packages if p.get("name") == package_name]

    if not packages:
        print(yellow(f"No package found: {package_name}"))
        return 1

    # Sort newest first
    packages.sort(key=lambda p: version_key(str(p.get("version", ""))), reverse=True)

    exit_code = 0
    for pkg in packages:
        code = _download_version(api, project, package_name, pkg, output_dir)
        if code != 0:
            exit_code = code

    return exit_code


# ────────────────────────────────────────────────────────────────────────────────────────
def _download_one(
    api: GitLabAPI,
    project: str,
    package_name: str,
    version_filter: str | None,
    output_dir: Path,
) -> int:
    """Download a single package (latest stable, or a specific version)."""
    try:
        packages = api.list_packages(project, name=package_name)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    # Filter to exact name match
    packages = [p for p in packages if p.get("name") == package_name]

    if version_filter:
        packages = [p for p in packages if p.get("version") == version_filter]
    else:
        # Sort by version and pick latest stable release
        packages.sort(
            key=lambda p: version_key(str(p.get("version", ""))), reverse=True
        )
        stable = [p for p in packages if not is_prerelease(str(p.get("version", "")))]
        packages = stable if stable else packages

    if not packages:
        msg = f"No package found: {package_name}"
        if version_filter:
            msg += f"=={version_filter}"
        print(yellow(msg))
        return 1

    return _download_version(api, project, package_name, packages[0], output_dir)


# ────────────────────────────────────────────────────────────────────────────────────────
def _download_version(
    api: GitLabAPI,
    project: str,
    package_name: str,
    pkg: dict[str, object],
    output_dir: Path,
) -> int:
    """Download all files for a single package version entry."""
    pkg_id = int(pkg.get("id", 0))  # type: ignore[arg-type]
    pkg_version = str(pkg.get("version", ""))

    try:
        files = api.get_package_files(project, pkg_id)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    if not files:
        print(yellow(f"No files found for {package_name}=={pkg_version}"))
        return 1

    # Download each file using the generic registry URL
    for file_info in files:
        filename = str(file_info.get("file_name", ""))
        file_size = int(file_info.get("size", 0))

        dest = output_dir / filename

        print(f"Downloading {filename} ({format_size(file_size)})...")

        try:
            api.download_generic_file(
                project, package_name, pkg_version, filename, dest
            )
        except APIError as e:
            print(red("Error:") + f" {e}", file=sys.stderr)
            return 1

        print(green("Saved:") + f" {dest}")

    return 0
