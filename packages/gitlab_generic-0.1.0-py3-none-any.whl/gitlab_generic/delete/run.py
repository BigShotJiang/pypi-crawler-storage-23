# ────────────────────────────────────────────────────────────────────────────────────────
#   delete/run.py
#   ─────────────
#
#   CLI runner for the delete command — deletes a package from the registry.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import sys
from argparse import Namespace
from ..common import APIError
from ..common import GitLabAPI
from ..common import parse_package_spec
from ..common import resolve_config
from ..common.output import green
from ..common.output import red
from ..common.output import yellow

# ────────────────────────────────────────────────────────────────────────────────────────
#   Runner
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def run(args: Namespace) -> int:
    """Delete one or more package versions from the registry."""
    config = resolve_config(args)
    if config is None:
        return 1

    api = GitLabAPI(config["url"], config["token"], verbose=args.verbose)
    specs: list[str] = args.packages
    exit_code = 0

    for spec in specs:
        package_name, version_filter = parse_package_spec(spec)

        if version_filter is None:
            print(
                red("Error:") + f" Must specify version: {package_name}==<version>",
                file=sys.stderr,
            )
            exit_code = 1
            continue

        code = _delete_one(api, config["project"], package_name, version_filter)
        if code != 0:
            exit_code = code

    return exit_code


# ────────────────────────────────────────────────────────────────────────────────────────
def _delete_one(api: GitLabAPI, project: str, package_name: str, version: str) -> int:
    """Delete a single package version."""
    try:
        packages = api.list_packages(project, name=package_name)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    packages = [p for p in packages if p.get("name") == package_name]
    packages = [p for p in packages if p.get("version") == version]

    if not packages:
        print(yellow(f"No package found: {package_name}=={version}"))
        return 1

    pkg = packages[0]
    pkg_id = int(pkg.get("id", 0))

    print(f"Deleting {package_name}=={version}...")

    try:
        api.delete_package(project, pkg_id)
    except APIError as e:
        print(red("Error:") + f" {e}", file=sys.stderr)
        return 1

    print(green("Deleted successfully."))
    return 0
