# ────────────────────────────────────────────────────────────────────────────────────────
#   api.py
#   ──────
#
#   GitLab REST API client using stdlib urllib. Handles authentication, pagination,
#   JSON responses, file downloads, and file uploads for the Generic Package Registry.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import json
import sys
from pathlib import Path
from typing import Any
from typing import cast
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.parse import urlencode
from urllib.request import Request
from urllib.request import urlopen

# ────────────────────────────────────────────────────────────────────────────────────────
#   Exceptions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
class APIError(Exception):
    """Error from the GitLab API."""

    def __init__(self, status: int, message: str, url: str = ""):
        self.status = status
        self.url = url
        super().__init__(f"HTTP {status}: {message}" + (f" ({url})" if url else ""))


# ────────────────────────────────────────────────────────────────────────────────────────
#   API Client
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
class GitLabAPI:
    """GitLab REST API client using stdlib urllib.

    Parameters:
        url: GitLab instance base URL (e.g., "https://gitlab.com").
        token: Private access token for authentication.
        verbose: If True, print request details to stderr.
    """

    # ────────────────────────────────────────────────────────────────────────────────────
    def __init__(self, url: str, token: str, *, verbose: bool = False):
        self._base_url = url.rstrip("/")
        self._token = token
        self._verbose = verbose

    # ────────────────────────────────────────────────────────────────────────────────────
    @staticmethod
    def encode_project(project: str) -> str:
        """Encode a project ID or path for use in API URLs.

        Numeric IDs are returned as-is. Paths like "group/project" are URL-encoded.
        """
        if project.isdigit():
            return project
        return quote(project, safe="")

    # ────────────────────────────────────────────────────────────────────────────────────
    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        body: bytes | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> tuple[Any, dict[str, str]]:
        """Make an HTTP request to the GitLab API.

        Parameters:
            method: HTTP method (GET, POST, PUT, DELETE, etc.).
            path: API path (e.g., "/projects/123/packages").
            params: Query parameters to append to the URL.
            body: Request body bytes.
            extra_headers: Additional headers to include.

        Returns:
            Tuple of (parsed JSON response, response headers dict).
        """
        url = f"{self._base_url}/api/v4{path}"
        if params:
            url += "?" + urlencode(params)

        headers: dict[str, str] = {"PRIVATE-TOKEN": self._token}
        if extra_headers:
            headers.update(extra_headers)

        if self._verbose:
            print(f"  {method} {url}", file=sys.stderr)

        req = Request(url, method=method, headers=headers, data=body)

        try:
            with urlopen(req) as resp:
                resp_headers = {k.lower(): v for k, v in resp.getheaders()}
                content = resp.read()
                if content:
                    return json.loads(content), resp_headers
                return None, resp_headers
        except HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            try:
                error_data = json.loads(error_body)
                message = error_data.get("message", error_data.get("error", error_body))
            except (json.JSONDecodeError, AttributeError):
                message = error_body

            hint = ""
            if e.code == 401:
                hint = " (check that your token is valid)"
            elif e.code == 403:
                hint = " (your token lacks permission for this action)"
            elif e.code == 404:
                hint = (
                    " (project not found — this can also mean your token"
                    " lacks access to the project)"
                )

            raise APIError(e.code, str(message) + hint, url) from None

    # ────────────────────────────────────────────────────────────────────────────────────
    def _paginated_request(
        self,
        path: str,
        *,
        params: dict[str, str] | None = None,
    ) -> list[dict[str, Any]]:
        """Make a paginated GET request, fetching all pages.

        Uses GitLab's X-Next-Page header for pagination.

        Parameters:
            path: API path.
            params: Base query parameters.

        Returns:
            Combined list of all results across all pages.
        """
        all_results: list[dict[str, Any]] = []
        page_params = dict(params or {})
        page_params.setdefault("per_page", "100")
        page_params["page"] = "1"

        while True:
            data, headers = self._request("GET", path, params=page_params)
            if isinstance(data, list):
                all_results.extend(cast("list[dict[str, Any]]", data))
            else:
                break

            next_page = headers.get("x-next-page", "")
            if not next_page:
                break
            page_params["page"] = next_page

        return all_results

    # ────────────────────────────────────────────────────────────────────────────────────
    def list_packages(
        self,
        project: str,
        *,
        name: str | None = None,
    ) -> list[dict[str, Any]]:
        """List generic packages in a project.

        Parameters:
            project: Project ID or URL-encoded path.
            name: Optional package name filter.

        Returns:
            List of package dicts from the GitLab API.
        """
        encoded = self.encode_project(project)
        params: dict[str, str] = {"package_type": "generic"}
        if name:
            params["package_name"] = name
        return self._paginated_request(f"/projects/{encoded}/packages", params=params)

    # ────────────────────────────────────────────────────────────────────────────────────
    def get_package_files(
        self,
        project: str,
        package_id: int,
    ) -> list[dict[str, Any]]:
        """List files for a specific package.

        Parameters:
            project: Project ID or URL-encoded path.
            package_id: The package ID from list_packages.

        Returns:
            List of package file dicts.
        """
        encoded = self.encode_project(project)
        return self._paginated_request(
            f"/projects/{encoded}/packages/{package_id}/package_files"
        )

    # ────────────────────────────────────────────────────────────────────────────────────
    def delete_package(
        self,
        project: str,
        package_id: int,
    ) -> None:
        """Delete a package from the registry.

        Parameters:
            project: Project ID or URL-encoded path.
            package_id: The package ID to delete.
        """
        encoded = self.encode_project(project)
        self._request("DELETE", f"/projects/{encoded}/packages/{package_id}")

    # ────────────────────────────────────────────────────────────────────────────────────
    def delete_package_file(
        self,
        project: str,
        package_id: int,
        file_id: int,
    ) -> None:
        """Delete a single file from a package.

        Parameters:
            project: Project ID or URL-encoded path.
            package_id: The package ID.
            file_id: The file ID to delete.
        """
        encoded = self.encode_project(project)
        self._request(
            "DELETE",
            f"/projects/{encoded}/packages/{package_id}/package_files/{file_id}",
        )

    # ────────────────────────────────────────────────────────────────────────────────────
    def download_file(self, url: str, dest: Path) -> Path:
        """Download a file from a URL to a local path.

        Parameters:
            url: Full URL to download from.
            dest: Destination file path.

        Returns:
            The destination path.
        """
        headers: dict[str, str] = {"PRIVATE-TOKEN": self._token}
        req = Request(url, headers=headers)

        if self._verbose:
            print(f"  GET {url}", file=sys.stderr)

        try:
            with urlopen(req) as resp:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
        except HTTPError as e:
            raise APIError(e.code, e.reason, url) from None

        return dest

    # ────────────────────────────────────────────────────────────────────────────────────
    def download_generic_file(
        self,
        project: str,
        package_name: str,
        version: str,
        filename: str,
        dest: Path,
    ) -> Path:
        """Download a file from the generic package registry.

        Uses the direct generic registry URL:
        GET /projects/:id/packages/generic/:name/:version/:filename

        Parameters:
            project: Project ID or URL-encoded path.
            package_name: Package name.
            version: Package version.
            filename: Name of the file to download.
            dest: Destination file path.

        Returns:
            The destination path.
        """
        encoded = self.encode_project(project)
        url = (
            f"{self._base_url}/api/v4/projects/{encoded}"
            f"/packages/generic/{quote(package_name, safe='')}"
            f"/{quote(version, safe='')}/{quote(filename, safe='')}"
        )
        return self.download_file(url, dest)

    # ────────────────────────────────────────────────────────────────────────────────────
    def upload_file(
        self,
        project: str,
        package_name: str,
        version: str,
        file_path: Path,
    ) -> Any:
        """Upload a file to the generic package registry.

        Uses PUT /projects/:id/packages/generic/:name/:version/:filename
        with the raw file content as the request body.

        Parameters:
            project: Project ID or URL-encoded path.
            package_name: Package name.
            version: Package version string.
            file_path: Path to the file to upload.

        Returns:
            API response (parsed JSON).
        """
        encoded = self.encode_project(project)
        filename = file_path.name
        file_data = file_path.read_bytes()

        path = (
            f"/projects/{encoded}"
            f"/packages/generic/{quote(package_name, safe='')}"
            f"/{quote(version, safe='')}/{quote(filename, safe='')}"
        )

        if self._verbose:
            print(
                f"  PUT {self._base_url}/api/v4{path}",
                file=sys.stderr,
            )
            print(
                f"  Uploading {filename} ({len(file_data)} bytes)",
                file=sys.stderr,
            )

        data, _headers = self._request(
            "PUT",
            path,
            body=file_data,
            extra_headers={"Content-Type": "application/octet-stream"},
        )
        return data
