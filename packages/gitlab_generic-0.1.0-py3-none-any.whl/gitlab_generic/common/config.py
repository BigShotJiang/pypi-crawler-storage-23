# ────────────────────────────────────────────────────────────────────────────────────────
#   config.py
#   ─────────
#
#   Configuration loading and resolution. Supports a JSON config file at
#   ~/.config/gitlab-generic/config.json with CLI flag overrides.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import json
import sys
from argparse import Namespace
from pathlib import Path
from typing import TypedDict

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

DEFAULT_CONFIG_PATH = "~/.config/gitlab-generic/config.json"

# ────────────────────────────────────────────────────────────────────────────────────────
#   Types
# ────────────────────────────────────────────────────────────────────────────────────────


class Config(TypedDict):
    """Resolved configuration for GitLab API access."""

    url: str
    project: str
    token: str


class _FileConfig(TypedDict, total=False):
    """Shape of the JSON config file (all fields optional)."""

    url: str
    project: str
    token: str


# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def find_default_config() -> Path | None:
    """Look for a default config file at ~/.config/gitlab-generic/config.json."""
    default_path = Path(DEFAULT_CONFIG_PATH).expanduser()
    if default_path.exists():
        return default_path
    return None


# ────────────────────────────────────────────────────────────────────────────────────────
def load_config(filepath: Path) -> _FileConfig:
    """Load configuration from a JSON file.

    Parameters:
        filepath: Path to the JSON config file.

    Returns:
        Parsed config with url, project, and token fields (all optional).
    """
    with open(filepath, encoding="utf-8") as f:
        data = json.load(f)

    config: _FileConfig = {}

    if "url" in data and isinstance(data["url"], str):
        config["url"] = data["url"].rstrip("/")

    if "project" in data and isinstance(data["project"], (str, int)):
        config["project"] = str(data["project"])

    if "token" in data and isinstance(data["token"], str):
        config["token"] = data["token"]

    return config


# ────────────────────────────────────────────────────────────────────────────────────────
def resolve_config(args: Namespace) -> Config | None:
    """Resolve configuration from CLI flags and config file.

    CLI flags take precedence over config file values. If no config file is
    specified via --config, looks for the default at ~/.config/gitlab-generic/config.json.

    Parameters:
        args: Parsed CLI arguments with optional url, project, token, config fields.

    Returns:
        Resolved Config, or None if required fields are missing (errors printed to stderr).
    """
    from .output import cyan
    from .output import red
    from .output import yellow

    # Load config file
    file_config: _FileConfig = {}
    config_path: Path | None = getattr(args, "config", None)

    if config_path:
        if not config_path.exists():
            print(
                red("Error:") + f" Config file not found: {config_path}",
                file=sys.stderr,
            )
            return None
        file_config = load_config(config_path)
    else:
        default = find_default_config()
        if default:
            if getattr(args, "verbose", False):
                print(cyan(f"Using default config: {default}"))
            file_config = load_config(default)

    # Resolve: CLI flags override config file
    url: str | None = getattr(args, "url", None) or file_config.get("url")
    project: str | None = getattr(args, "project", None) or file_config.get("project")
    token: str | None = getattr(args, "token", None) or file_config.get("token")

    # Default URL
    if not url:
        url = "https://gitlab.com"

    # Validate required fields
    missing: list[str] = []
    if not project:
        missing.append("-p/--project")
    if not token:
        missing.append("-t/--token")

    if missing:
        print(red("Error:") + " Missing required configuration:", file=sys.stderr)
        for arg in missing:
            print(f"  {arg}", file=sys.stderr)
        print(
            yellow("Tip:")
            + " Provide via CLI flags, or create a config file at "
            + f"{DEFAULT_CONFIG_PATH}",
            file=sys.stderr,
        )
        return None

    assert project is not None
    assert token is not None

    return Config(url=url, project=project, token=token)
