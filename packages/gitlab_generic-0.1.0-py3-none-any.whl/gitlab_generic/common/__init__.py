# ────────────────────────────────────────────────────────────────────────────────────────
#   common
#   ──────
#
#   Shared utilities for gitlab-generic.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

from .api import APIError
from .api import GitLabAPI
from .config import Config
from .config import resolve_config
from .output import set_colours_enabled

__all__ = [
    "APIError",
    "Config",
    "GitLabAPI",
    "parse_filename",
    "parse_package_spec",
    "resolve_config",
    "set_colours_enabled",
]


# Compound extensions to strip before splitting the stem.
_COMPOUND_EXTENSIONS = (".tar.gz", ".tar.bz2", ".tar.xz", ".tar.zst")


def parse_package_spec(spec: str) -> tuple[str, str | None]:
    """Parse 'name==version' or 'name' into (name, version_or_none)."""
    if "==" in spec:
        name, version = spec.split("==", 1)
        return name.strip(), version.strip()
    return spec.strip(), None


def parse_filename(filename: str) -> tuple[str, str] | None:
    """Extract (package_name, version) from a filename.

    Splits the filename stem on ``-`` and looks for the first segment that
    starts with a digit.  Everything before that segment is the package name;
    that segment is the version.  Remaining segments (platform, arch, etc.)
    are ignored.

    Returns ``None`` if the name or version cannot be determined.

    Examples::

        parse_filename("calrep-0.29.0-darwin-arm64.tar.gz")
        # -> ("calrep", "0.29.0")

        parse_filename("my-tool-1.2.3.zip")
        # -> ("my-tool", "1.2.3")
    """
    # Strip compound extensions first, then any remaining single extension.
    stem = filename
    for ext in _COMPOUND_EXTENSIONS:
        if stem.endswith(ext):
            stem = stem[: -len(ext)]
            break
    else:
        # No compound extension matched — strip a single extension.
        dot = stem.rfind(".")
        if dot > 0:
            stem = stem[:dot]

    parts = stem.split("-")
    if len(parts) < 2:
        return None

    # Find the first part that starts with a digit (the version).
    for i, part in enumerate(parts):
        if part and part[0].isdigit():
            if i == 0:
                # No name segments before the version.
                return None
            name = "-".join(parts[:i])
            version = parts[i]
            return name, version

    return None
