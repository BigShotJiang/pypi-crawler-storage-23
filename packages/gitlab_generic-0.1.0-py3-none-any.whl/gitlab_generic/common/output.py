# ────────────────────────────────────────────────────────────────────────────────────────
#   output.py
#   ─────────
#
#   Terminal output helpers — ANSI colours (auto-detected), table formatting,
#   and human-readable file sizes.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import re
import sys

# ────────────────────────────────────────────────────────────────────────────────────────
#   Colour Support
# ────────────────────────────────────────────────────────────────────────────────────────

_colours_enabled: bool = sys.stdout.isatty()

_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_CYAN = "\033[36m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"


# ────────────────────────────────────────────────────────────────────────────────────────
def set_colours_enabled(enabled: bool) -> None:
    """Enable or disable coloured output globally."""
    global _colours_enabled
    _colours_enabled = enabled


# ────────────────────────────────────────────────────────────────────────────────────────
def red(text: str) -> str:
    """Wrap text in red ANSI colour."""
    return f"{_RED}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
def green(text: str) -> str:
    """Wrap text in green ANSI colour."""
    return f"{_GREEN}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
def yellow(text: str) -> str:
    """Wrap text in yellow ANSI colour."""
    return f"{_YELLOW}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
def cyan(text: str) -> str:
    """Wrap text in cyan ANSI colour."""
    return f"{_CYAN}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
def bold(text: str) -> str:
    """Wrap text in bold ANSI style."""
    return f"{_BOLD}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
def dim(text: str) -> str:
    """Wrap text in dim ANSI style."""
    return f"{_DIM}{text}{_RESET}" if _colours_enabled else text


# ────────────────────────────────────────────────────────────────────────────────────────
#   Formatting
# ────────────────────────────────────────────────────────────────────────────────────────


# Pre-release tag ordering: alpha < beta < rc < (release)
_PRE_RELEASE_ORDER = {"a": 0, "alpha": 0, "b": 1, "beta": 1, "rc": 2, "c": 2}

# Matches: major.minor.patch followed by optional pre-release (e.g., a1, b2, rc1)
_VERSION_RE = re.compile(
    r"^(\d+(?:\.\d+)*)(?:[.\-]?(?:(a|alpha|b|beta|rc|c)\.?(\d*)))?(.*)$", re.IGNORECASE
)


# ────────────────────────────────────────────────────────────────────────────────────────
def version_key(version: str) -> tuple[tuple[int, ...], int, int, str]:
    """Return a sort key for PEP 440-ish version strings.

    Pre-release versions (a/alpha/b/beta/rc) sort before the corresponding
    release. For example: 1.0.0a1 < 1.0.0b1 < 1.0.0rc1 < 1.0.0.

    Returns a tuple of (numeric_parts, pre_release_phase, pre_release_num, remainder)
    so that sorted(..., key=version_key) gives ascending order.
    """
    m = _VERSION_RE.match(version.strip())
    if not m:
        return ((), 99, 0, version)

    nums = tuple(int(x) for x in m.group(1).split("."))
    pre_tag = m.group(2)
    pre_num = int(m.group(3)) if m.group(3) else 0

    if pre_tag:
        phase = _PRE_RELEASE_ORDER.get(pre_tag.lower(), 3)
    else:
        # No pre-release tag = final release, sorts after all pre-releases
        phase = 99
        pre_num = 0

    return (nums, phase, pre_num, m.group(4) or "")


# ────────────────────────────────────────────────────────────────────────────────────────
def is_prerelease(version: str) -> bool:
    """Return True if the version string looks like a pre-release."""
    m = _VERSION_RE.match(version.strip())
    if not m:
        return False
    return m.group(2) is not None


# ────────────────────────────────────────────────────────────────────────────────────────
def format_size(size_bytes: int) -> str:
    """Format a byte count as a human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


# ────────────────────────────────────────────────────────────────────────────────────────
def _visible_len(text: str) -> int:
    """Return the visible length of a string, ignoring ANSI escape codes."""
    import re

    return len(re.sub(r"\033\[[0-9;]*m", "", text))


# ────────────────────────────────────────────────────────────────────────────────────────
def _pad(text: str, width: int) -> str:
    """Pad a string to a visible width, accounting for ANSI escape codes."""
    visible = _visible_len(text)
    if visible >= width:
        return text
    return text + " " * (width - visible)


# ────────────────────────────────────────────────────────────────────────────────────────
def print_table(headers: list[str], rows: list[list[str]]) -> None:
    """Print a simple aligned table to stdout.

    Handles ANSI colour codes in cell values — alignment is based on
    visible character width, not raw string length.

    Parameters:
        headers: Column header strings.
        rows: List of rows, each a list of column values.
    """
    if not rows:
        return

    # Calculate column widths based on visible length
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], _visible_len(cell))

    # Print header
    header_line = "  ".join(bold(h.ljust(widths[i])) for i, h in enumerate(headers))
    print(header_line)

    # Print separator
    separator = "  ".join(dim("─" * widths[i]) for i in range(len(headers)))
    print(separator)

    # Print rows
    for row in rows:
        cells: list[str] = []
        for i, cell in enumerate(row):
            if i < len(widths):
                cells.append(_pad(cell, widths[i]))
            else:
                cells.append(cell)
        print("  ".join(cells))
