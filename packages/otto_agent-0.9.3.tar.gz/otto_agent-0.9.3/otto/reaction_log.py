"""
Reaction log — append-only JSONL store for Telegram message reactions.

Multi-agent aware: each entry includes bot_name so signals from Otto,
Grizzly, and any other bot can be reconciled in one place.

Log location: ~/.otto/reaction_log.jsonl
"""

import json
import os
from datetime import UTC, datetime
from pathlib import Path

_LOG_PATH = Path(os.environ.get("OTTO_HOME", "~/.otto")).expanduser() / "reaction_log.jsonl"


def log_reaction(
    *,
    bot_name: str,
    chat_id: int | str,
    message_id: int,
    reaction: str,
    is_added: bool,
    user_id: int | str | None = None,
) -> None:
    """Append a single reaction event to the shared JSONL log."""
    entry = {
        "ts": datetime.now(UTC).isoformat(),
        "bot": bot_name,
        "chat_id": str(chat_id),
        "message_id": message_id,
        "reaction": reaction,
        "added": is_added,
        "user_id": str(user_id) if user_id is not None else None,
    }
    _LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
