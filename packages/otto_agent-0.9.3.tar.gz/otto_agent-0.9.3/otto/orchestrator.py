"""
Agent orchestrator — spawns and manages async sub-agent jobs.

Otto evaluates incoming tasks and decides whether to handle them directly
or delegate to a sub-agent. When delegated, a DelegatedJob is created,
an asyncio.Task is spawned, and control immediately returns to the user.

On completion, the orchestrator fires the session's notify callback so the
user receives a Telegram message with the result — no polling required.

Architecture:
    - One Orchestrator per Otto process (singleton via get_orchestrator()).
    - Each sub-agent gets its own isolated message history.
    - Jobs share the same tool set as the main Otto agent (MVP; configurable later).
    - State is tracked in-memory via JobRegistry + append-only events.jsonl.
"""

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from otto.auth import AuthStorage
from otto.delegation import DelegatedJob, DelegationContract, JobRegistry, JobStatus
from otto.errors import OttoAuthError, OttoTransientError, classify_otto_error
from otto.log import get_logger
from otto.model_catalog import get_default_oauth_model
from otto.providers import resolve_provider
from otto.subagents import load_subagent_profiles


@dataclass
class _DeferredParams:
    """Run parameters stashed for jobs waiting on dependencies."""

    tools: list[Any]
    notify: Callable[[str], Awaitable[None]]
    auth_storage: Any | None = None
    output_format: str = "plain"


@dataclass
class _RuntimeRoute:
    """In-memory routing snapshot for a delegated job."""

    model_chain: list[str]
    session_model: str
    subagent_prompt: str | None = None
    warning: str | None = None
    warning_sent: bool = False


_log = get_logger("otto.orchestrator")

# Maximum concurrent sub-agent jobs per orchestrator instance.
_MAX_PARALLEL_JOBS = 10

# On upstream rate-limit (429-like) errors, retry same model this many times
# before advancing to the next model in the fallback chain.
_MAX_RATE_LIMIT_RETRIES = 3
_RATE_LIMIT_RETRY_DELAY_SECONDS = 1.0
_MODEL_SWITCH_DELAY_SECONDS = 1.0


def _normalize_model_id(value: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _dedupe_models(candidates: list[str | None]) -> list[str]:
    deduped: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        model = _normalize_model_id(candidate)
        if model is None or model in seen:
            continue
        seen.add(model)
        deduped.append(model)
    return deduped


def _format_duration(seconds: float | None) -> str:
    """Human-readable duration string."""
    if seconds is None:
        return ""
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f}m"
    hours = minutes / 60
    return f"{hours:.1f}h"


def _summarize_result_text(text: str, *, max_chars: int = 1200) -> str:
    """Clean and summarize noisy sub-agent output for user notifications."""
    raw_lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not raw_lines:
        return "(sub-agent produced no text output)"

    noise_prefixes = (
        "ok",
        "proceed",
        "let's",
        "tool:",
        "tool call",
        "call edit_file",
        "stop chatter",
        "no filler",
        "i will call",
        "i'm failing to",
        "i will do tool",
    )

    cleaned: list[str] = []
    for line in raw_lines:
        lower = line.lower()
        if lower.startswith('{"command":'):
            continue
        if any(lower.startswith(prefix) for prefix in noise_prefixes):
            continue
        if cleaned and cleaned[-1] == line:
            continue
        cleaned.append(line)

    selected = cleaned if cleaned else raw_lines[:3]
    summary = "\n".join(selected[:12])
    if len(summary) > max_chars:
        summary = summary[:max_chars] + "\n... (truncated)"
    return summary


def _is_incomplete_result(text: str) -> bool:
    """Detect common patterns where a sub-agent admits it did not complete work."""
    lower = text.lower()
    markers = (
        "stuck in a loop",
        "didn't apply",
        "did not apply",
        "please allow me to proceed",
        "unable to complete",
        "couldn't complete",
        "i'm stuck",
        "i got stuck",
    )
    return any(marker in lower for marker in markers)


# ---------------------------------------------------------------------------
# Result polish — LLM rewrite of mechanical notifications
# ---------------------------------------------------------------------------

_POLISH_TIMEOUT_SECONDS = 15
_POLISH_MAX_TOKENS = 1024

_POLISH_SYSTEM_PROMPT = """\
You are writing a notification for a user who delegated a background task. \
Write a natural response as if you just finished the work yourself. \
Go straight to what was done and what they should know — don't re-explain \
what was asked. Don't mention job IDs, task IDs, attempt counts, durations, \
or any internal mechanics. Keep it concise but complete.\
"""

_POLISH_SYSTEM_PROMPT_FANIN = """\
You are writing a notification for a user who delegated a background task \
that involved multiple parallel sub-tasks. Summarize the combined outcome \
naturally. Don't list sub-task IDs or mention the parallel/fan-in structure. \
Go straight to results — don't re-explain what was asked. Don't mention job IDs, \
task IDs, attempt counts, durations, or any internal mechanics. \
Keep it concise but complete.\
"""


def _build_polish_prompt(job: DelegatedJob, output_format: str) -> str:
    """Build the user-message prompt for the polish LLM call."""
    parts: list[str] = []
    parts.append(f"Original task:\n{job.contract.task}")
    if job.result_summary:
        parts.append(f"\nResult from agent:\n{job.result_summary}")
    if job.log_entries:
        timeline = "\n".join(f"- {e}" for e in job.log_entries[-8:])
        parts.append(f"\nTimeline:\n{timeline}")
    fmt_note = {
        "telegram_html": "Format using Telegram HTML tags (<b>, <i>, <code>, <pre>). No Markdown.",
        "markdown": "Format using Markdown.",
        "plain": "Plain text, no formatting markup.",
    }.get(output_format, "Plain text, no formatting markup.")
    parts.append(f"\nOutput format: {fmt_note}")
    return "\n".join(parts)


async def _polish_result(
    job: DelegatedJob,
    *,
    model: str,
    output_format: str = "plain",
    auth_storage: AuthStorage | None = None,
) -> str | None:
    """Run a lightweight LLM call to rewrite a job result as a natural message.

    Returns the polished text, or None if the call fails or times out.
    """
    system = _POLISH_SYSTEM_PROMPT_FANIN if job.children else _POLISH_SYSTEM_PROMPT
    user_prompt = _build_polish_prompt(job, output_format)
    messages = [{"role": "user", "content": user_prompt}]

    try:
        provider = await resolve_provider(model, system, auth_storage=auth_storage)
        stream = await provider.stream_completion(
            model=model,
            messages=[{"role": "system", "content": system}, *messages],
            tools=[],
            tool_choice=None,
            max_tokens=_POLISH_MAX_TOKENS,
        )
        text_parts: list[str] = []
        polished = await asyncio.wait_for(
            _consume_polish_stream(stream, text_parts),
            timeout=_POLISH_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        mapped_exc = classify_otto_error(exc)
        _log.warning(
            "Polish call failed for job %s on %s (%s): %s",
            job.id,
            model,
            type(mapped_exc).__name__,
            mapped_exc,
        )
        return None

    if not polished:
        _log.warning("Polish call returned empty text for job %s on %s", job.id, model)
        return None
    return polished


async def _consume_polish_stream(stream: Any, text_parts: list[str]) -> str | None:
    """Consume a streaming LLM response, return assembled text or None."""
    async for chunk in stream:
        choices = getattr(chunk, "choices", None)
        if not choices:
            continue
        delta = getattr(choices[0], "delta", None)
        if delta is None:
            continue
        content = getattr(delta, "content", None)
        if content:
            text_parts.append(content)
    result = "".join(text_parts).strip()
    return result if result else None


def _format_notification(
    job: DelegatedJob,
    *,
    full_result: str | None = None,
    output_format: str = "plain",
) -> str:
    """Build a notification message for the given job state and output format.

    Supports telegram_html, markdown, and plain formats.
    """
    task_preview = job.contract.task[:80]
    use_html = output_format == "telegram_html"
    use_md = output_format == "markdown"

    # Format job ID
    if use_html:
        job_ref = f"<code>{job.id}</code>"
        task_ref = f"<i>{task_preview}</i>"
    elif use_md:
        job_ref = f"`{job.id}`"
        task_ref = f"*{task_preview}*"
    else:
        job_ref = job.id
        task_ref = task_preview

    # Metrics line (duration + attempts)
    metrics_parts: list[str] = []
    if job.duration is not None:
        metrics_parts.append(f"Duration: {_format_duration(job.duration)}")
    if job.attempts > 1:
        metrics_parts.append(f"Attempts: {job.attempts}")
    metrics_line = " | ".join(metrics_parts)

    if job.status == JobStatus.DONE:
        body = full_result or job.result_summary or "(no summary)"
        if len(body) > 4000:
            body = body[:4000] + "\n... (truncated)"
        parts = [f"✅ Job {job_ref} complete.", task_ref]
        if metrics_line:
            parts.append(metrics_line)
        parts.append("")
        parts.append(body)
        return "\n".join(parts)

    if job.status == JobStatus.CANCELLED:
        return f"🚫 Job {job_ref} was cancelled.\n{task_ref}"

    # FAILED
    error = job.error or "Unknown error"
    parts = [
        f"❌ Job {job_ref} failed after {job.attempts} attempt(s).",
        task_ref,
    ]
    if metrics_line:
        parts.append(metrics_line)
    if use_html:
        parts.append(f"Error: <code>{error[:200]}</code>")
    elif use_md:
        parts.append(f"Error: `{error[:200]}`")
    else:
        parts.append(f"Error: {error[:200]}")
    return "\n".join(parts)


class Orchestrator:
    """
    Manages the full lifecycle of delegated sub-agent jobs.

    Usage:
        orchestrator = get_orchestrator()
        job_id = await orchestrator.delegate(contract, chat_id, notify=notify_fn, tools=tools)
        # user keeps chatting; notify fires when the job is done
    """

    def __init__(
        self,
        max_parallel: int = _MAX_PARALLEL_JOBS,
        default_timeout: int = 1800,
    ) -> None:
        self._registry = JobRegistry()
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._deferred: dict[str, _DeferredParams] = {}
        self._runtime_routes: dict[str, _RuntimeRoute] = {}
        self._lock = asyncio.Lock()
        self._max_parallel = max_parallel
        self._default_timeout = default_timeout
        self._default_session_model = self._load_default_session_model()
        # Startup state restore: reload persisted jobs from board/ on every start.
        recovered = self._registry.load_from_board()
        if recovered:
            _log.info("Startup: restored %d jobs from board", recovered)
        self._registry.cleanup_terminal()

    @staticmethod
    def _load_default_session_model() -> str:
        try:
            from otto.config import load_config

            return load_config().agent.model
        except Exception:
            return get_default_oauth_model("openai") or "openai/gpt-5"

    def _snapshot_runtime_route(
        self,
        job: DelegatedJob,
        *,
        session_model: str | None = None,
        force: bool = False,
        explicit_model_chain: list[str] | None = None,
    ) -> _RuntimeRoute:
        if not force:
            existing = self._runtime_routes.get(job.id)
            if existing is not None:
                return existing

        previous = self._runtime_routes.get(job.id)
        resolved_session_model = _normalize_model_id(session_model)
        if resolved_session_model is None and previous is not None:
            resolved_session_model = previous.session_model
        if resolved_session_model is None:
            resolved_session_model = _normalize_model_id(self._default_session_model)
        if resolved_session_model is None:
            resolved_session_model = (
                _normalize_model_id(job.model)
                or get_default_oauth_model("openai")
                or "openai/gpt-5"
            )

        prompt: str | None = None
        warning: str | None = None

        if explicit_model_chain:
            model_chain = _dedupe_models(explicit_model_chain)
        elif job.subagent_name:
            profiles = {profile.name: profile for profile in load_subagent_profiles()}
            profile = profiles.get(job.subagent_name)
            if profile is None:
                model_chain = _dedupe_models(
                    [resolved_session_model, job.model, job.contract.model]
                )
                warning = (
                    f"Subagent profile '{job.subagent_name}' was not found at run time; "
                    "used main session routing instead."
                )
                _log.warning("job %s missing subagent profile '%s'", job.id, job.subagent_name)
            else:
                model_chain = _dedupe_models(
                    [
                        profile.model,
                        profile.fallback,
                        resolved_session_model,
                        job.model,
                        job.contract.model,
                    ]
                )
                prompt = (
                    profile.prompt.strip()
                    if isinstance(profile.prompt, str) and profile.prompt.strip()
                    else None
                )
        else:
            model_chain = _dedupe_models([job.model, resolved_session_model, job.contract.model])

        if not model_chain:
            raise RuntimeError(f"No runnable model route for delegated job {job.id}")

        job.model_chain = list(model_chain)
        job.model_index = 0
        job.model = model_chain[0]

        route = _RuntimeRoute(
            model_chain=list(model_chain),
            session_model=resolved_session_model,
            subagent_prompt=prompt,
            warning=warning,
            warning_sent=previous.warning_sent if previous else False,
        )
        self._runtime_routes[job.id] = route
        return route

    async def delegate(
        self,
        contract: DelegationContract,
        chat_id: str,
        *,
        notify: Callable[[str], Awaitable[None]],
        tools: list[Any],
        subagent_name: str | None = None,
        session_model: str | None = None,
        model: str | None = None,
        model_chain: list[str] | None = None,
        auth_storage: AuthStorage | None = None,
        output_format: str = "plain",
        depends_on: list[str] | None = None,
    ) -> str:
        """
        Spawn a sub-agent for the given contract and return the job ID immediately.

        If ``depends_on`` is set, the job stays PENDING until all dependency
        jobs reach DONE. When a dependency finishes, ``_check_pending_deps``
        is called to launch any newly-unblocked jobs.

        Returns:
            The 8-character job ID string.

        Raises:
            RuntimeError: If the parallel job cap is already reached.
        """
        async with self._lock:
            job = DelegatedJob.create(
                contract=contract,
                chat_id=chat_id,
                model=model,
                model_chain=model_chain,
                subagent_name=subagent_name,
            )
            job.depends_on = depends_on or []
            self._snapshot_runtime_route(
                job,
                session_model=session_model,
                explicit_model_chain=model_chain,
            )

            if job.depends_on and not self._registry.deps_satisfied(job):
                # Hold in READY — will be launched by _check_pending_deps
                self._registry.add(job)
                # Stash run params so we can launch later
                self._deferred[job.id] = _DeferredParams(
                    tools=tools,
                    notify=notify,
                    auth_storage=auth_storage,
                    output_format=output_format,
                )
                _log.info(
                    "Delegated job %s (deferred, waiting on %s): %s",
                    job.id,
                    job.depends_on,
                    contract.task[:80],
                )
                return job.id

            running = self._registry.running_count()
            if running >= self._max_parallel:
                raise RuntimeError(
                    f"Max parallel jobs ({self._max_parallel}) reached."
                    " Wait for existing jobs to complete or cancel one."
                )

            job.transition(JobStatus.IN_PROGRESS)
            self._registry.add(job)

        self._launch(
            job.id,
            tools=tools,
            notify=notify,
            auth_storage=auth_storage,
            output_format=output_format,
        )
        _log.info("Delegated job %s: %s", job.id, contract.task[:80])
        return job.id

    async def _run_job(
        self,
        job_id: str,
        *,
        tools: list[Any],
        notify: Callable[[str], Awaitable[None]],
        auth_storage: AuthStorage | None = None,
        output_format: str = "plain",
    ) -> None:
        """
        Background coroutine: run the sub-agent with rework loop.

        On success, transitions job to DELIVERED → DONE and notifies user.
        On validation failure, injects feedback and retries up to max_attempts.
        On exception or cancellation, transitions to terminal state and notifies.
        """
        async with self._lock:
            job = self._registry.get(job_id)

        if job is None:
            _log.error("Job %s not found when starting run", job_id)
            return

        try:
            self._snapshot_runtime_route(job)
            rate_limit_retry_counts: dict[str, int] = {}
            while job.attempts < job.max_attempts:
                current_model = job.model or "unknown"
                job.attempts += 1
                _log.info("Job %s attempt %d/%d", job.id, job.attempts, job.max_attempts)

                async with self._lock:
                    job.transition(JobStatus.IN_PROGRESS)
                    self._registry.update(job, event_type="running")

                try:
                    result_text = await self._execute_agent(
                        job,
                        tools=tools,
                        auth_storage=auth_storage,
                    )
                except Exception as exc:
                    mapped_exc = classify_otto_error(exc)

                    err_text = str(mapped_exc).lower()
                    is_rate_limit = isinstance(mapped_exc, OttoTransientError) and any(
                        marker in err_text
                        for marker in ("429", "rate limit", "ratelimit", "too many requests")
                    )
                    if is_rate_limit:
                        retry_count = rate_limit_retry_counts.get(current_model, 0)
                        if retry_count < _MAX_RATE_LIMIT_RETRIES:
                            retry_count += 1
                            rate_limit_retry_counts[current_model] = retry_count
                            # Rate-limit retries are transport-level recoveries; do not
                            # consume a full job attempt budget.
                            job.attempts = max(0, job.attempts - 1)
                            async with self._lock:
                                _log.warning(
                                    "Job %s rate-limited on %s (retry %d/%d)",
                                    job.id,
                                    current_model,
                                    retry_count,
                                    _MAX_RATE_LIMIT_RETRIES,
                                )
                                job.transition(JobStatus.IN_PROGRESS)
                                job.error = str(mapped_exc)
                                job.log_entries.append(
                                    f"{job.updated_at.isoformat()}: Rate-limit retry {retry_count}/{_MAX_RATE_LIMIT_RETRIES} on {current_model}"
                                )
                                self._registry.update(job, event_type="rate_limit_retry")
                            await asyncio.sleep(_RATE_LIMIT_RETRY_DELAY_SECONDS)
                            continue

                    switched = (
                        isinstance(mapped_exc, (OttoTransientError, OttoAuthError))
                        and job.advance_model()
                    )
                    if switched:
                        route = self._runtime_routes.get(job.id)
                        if route is not None:
                            route.model_chain = list(job.model_chain)

                        async with self._lock:
                            previous_model = (
                                job.model_chain[job.model_index - 1]
                                if job.model_index > 0
                                and job.model_index - 1 < len(job.model_chain)
                                else "unknown"
                            )
                            _log.warning(
                                "Job %s switching model after error (%s): %s -> %s",
                                job.id,
                                type(mapped_exc).__name__,
                                previous_model,
                                job.model,
                            )
                            job.transition(JobStatus.IN_PROGRESS)
                            job.error = str(mapped_exc)
                            job.log_entries.append(
                                f"{job.updated_at.isoformat()}: Model fallback {previous_model} -> {job.model}"
                            )
                            self._registry.update(job, event_type="model_fallback")
                        await asyncio.sleep(_MODEL_SWITCH_DELAY_SECONDS)
                        continue

                    if mapped_exc is exc:
                        raise
                    raise mapped_exc from exc

                async with self._lock:
                    job.transition(JobStatus.DELIVERED)
                    job.result_summary = _summarize_result_text(result_text)
                    self._registry.update(job, event_type="delivered")

                incomplete = _is_incomplete_result(result_text)
                validation_passed = await self._validate(job) and not incomplete

                if validation_passed:
                    async with self._lock:
                        job.transition(JobStatus.DONE)
                        self._registry.update(job, event_type="done")
                    # Child tasks don't notify the user — only the parent does
                    if not self._registry.is_child(job):
                        try:
                            await self._notify_completion(
                                job,
                                notify,
                                output_format=output_format,
                                auth_storage=auth_storage,
                            )
                        except Exception as notify_exc:
                            _log.warning(
                                "Job %s notification failed (job still DONE): %s",
                                job.id,
                                notify_exc,
                            )
                    await self._check_pending_deps()
                    return

                # Validation failed or incomplete output — prepare rework feedback
                if incomplete:
                    feedback = (
                        "Previous attempt reported incomplete work (e.g., got stuck or "
                        "did not apply changes). Re-run the task and actually apply edits "
                        "with tools."
                    )
                    error = "Sub-agent reported incomplete work"
                else:
                    feedback = (
                        f"Attempt {job.attempts} failed validation.\n"
                        f"Validation commands: {', '.join(job.contract.validation_cmds)}\n"
                        f"Previous result summary: {_summarize_result_text(result_text, max_chars=300)}"
                    )
                    error = "Validation failed"

                if job.attempts < job.max_attempts:
                    # Retries remain — show as reworking, not failed
                    async with self._lock:
                        job.transition(JobStatus.REWORKING)
                        job.feedback = feedback
                        job.error = error
                        self._registry.update(job, event_type="reworking")

                    _log.info(
                        "Job %s rework: attempt %d/%d, retrying",
                        job.id,
                        job.attempts,
                        job.max_attempts,
                    )
                    await asyncio.sleep(1)
                else:
                    # No retries left — terminal failure
                    async with self._lock:
                        job.transition(JobStatus.FAILED)
                        job.feedback = feedback
                        job.error = error
                        self._registry.update(job, event_type="failed")

            # Exhausted all attempts
            if not self._registry.is_child(job):
                await self._notify_completion(
                    job,
                    notify,
                    output_format=output_format,
                    auth_storage=auth_storage,
                )
            await self._check_pending_deps()

        except asyncio.CancelledError:
            async with self._lock:
                job.transition(JobStatus.CANCELLED)
                self._registry.update(job, event_type="cancelled")
            if not self._registry.is_child(job):
                await self._notify_completion(
                    job,
                    notify,
                    output_format=output_format,
                    auth_storage=auth_storage,
                )
            await self._check_pending_deps()

        except Exception as exc:
            _log.exception("Job %s failed with exception", job_id)
            async with self._lock:
                job.transition(JobStatus.FAILED)
                job.error = str(exc)
                self._registry.update(job, event_type="failed")
            if not self._registry.is_child(job):
                await self._notify_completion(
                    job,
                    notify,
                    output_format=output_format,
                    auth_storage=auth_storage,
                )
            await self._check_pending_deps()

        finally:
            self._tasks.pop(job_id, None)

    async def _execute_agent(
        self, job: DelegatedJob, *, tools: list[Any], auth_storage: AuthStorage | None = None
    ) -> str:
        """
        Instantiate and run a sub-agent with an isolated message history.

        Uses otto.agent.run() with the contract as the opening prompt.
        The sub-agent's conversation is completely separate from the main chat.
        Injects feedback from previous attempts on rework. Enforces contract
        timeout via asyncio.wait_for if set.
        """
        from otto.agent import run
        from otto.prompts import build_system_prompt

        # If this is a parent task, gather child results for context injection
        child_results = None
        if job.children:
            child_results = []
            for child_id in job.children:
                child = self._registry.get(child_id)
                if child and child.result_summary:
                    child_results.append(
                        {
                            "id": child.id,
                            "task": child.contract.task[:120],
                            "result": child.result_summary,
                        }
                    )

        prompt = job.contract.to_prompt(
            feedback=job.feedback,
            attempt=job.attempts,
            child_results=child_results or None,
        )

        route = self._runtime_routes.get(job.id)
        if route is None:
            route = self._snapshot_runtime_route(job)

        model = job.model
        if model is None:
            raise RuntimeError(f"No resolved model for delegated job {job.id}")

        system = build_system_prompt(
            output_format="plain",
            active_tools=[t.name for t in tools],
        )
        if route.subagent_prompt:
            system = (
                f"{system}\n\n"
                "IMPORTANT SUBAGENT CONTEXT (apply throughout this task):\n"
                f"{route.subagent_prompt}"
            )

        messages: list[dict[str, Any]] = [{"role": "user", "content": prompt}]

        coro = run(
            model=model,
            system=system,
            messages=messages,
            tools=tools,
            auth_storage=auth_storage,
            agent_kind="delegated",
            delegation_id=job.id,
            agent_name=job.subagent_name or "main",
        )

        # Use contract timeout if set, otherwise fall back to orchestrator default
        timeout = (
            job.contract.timeout
            if job.contract.timeout and job.contract.timeout > 0
            else self._default_timeout
        )
        try:
            result = await asyncio.wait_for(coro, timeout=timeout)
        except TimeoutError:
            raise TimeoutError(f"Sub-agent timed out after {timeout}s") from None

        # agent.run() returns AgentResult with a .text attribute.
        return result.text or "(sub-agent produced no text output)"

    async def _validate(self, job: DelegatedJob) -> bool:
        """
        Run the contract's validation commands and return True if all pass.

        If no validation commands are specified, the job is considered valid
        by default (trusts the sub-agent's output).
        """
        cmds = job.contract.validation_cmds
        if not cmds:
            return True

        for cmd in cmds:
            try:
                proc = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
                if proc.returncode != 0:
                    _log.warning("Validation failed for job %s: %s", job.id, cmd)
                    return False
            except Exception as exc:
                _log.warning("Validation error for job %s (%s): %s", job.id, cmd, exc)
                return False

        return True

    async def _notify_completion(
        self,
        job: DelegatedJob,
        notify: Callable[[str], Awaitable[None]],
        *,
        full_result: str | None = None,
        output_format: str = "plain",
        auth_storage: AuthStorage | None = None,
    ) -> None:
        """Send a completion notification to the user.

        For DONE jobs, attempts an LLM polish pass to produce a natural,
        conversational message. Falls back to the mechanical format on failure.
        FAILED and CANCELLED jobs always use the mechanical format.
        """
        delivered_message = False

        if job.status == JobStatus.DONE:
            route = self._runtime_routes.get(job.id)
            polish_models = _dedupe_models(
                [route.session_model if route is not None else None, job.model]
            )

            for polish_model in polish_models:
                polished = await _polish_result(
                    job,
                    model=polish_model,
                    output_format=output_format,
                    auth_storage=auth_storage,
                )
                if polished:
                    await notify(polished)
                    delivered_message = True
                    break

        if not delivered_message:
            # Fallback: mechanical format
            msg = _format_notification(job, full_result=full_result, output_format=output_format)
            await notify(msg)

        route = self._runtime_routes.get(job.id)
        if route and route.warning and not route.warning_sent:
            route.warning_sent = True
            await notify(f"⚠️ Delegation routing warning: {route.warning}")

    def _launch(
        self,
        job_id: str,
        *,
        tools: list[Any],
        notify: Callable[[str], Awaitable[None]],
        auth_storage: AuthStorage | None = None,
        output_format: str = "plain",
    ) -> None:
        """Create an asyncio.Task for a job (must already be RUNNING)."""
        task = asyncio.create_task(
            self._run_job(
                job_id,
                tools=tools,
                notify=notify,
                auth_storage=auth_storage,
                output_format=output_format,
            ),
            name=f"otto-job-{job_id}",
        )
        self._tasks[job_id] = task

    async def _check_pending_deps(self) -> None:
        """Launch any PENDING jobs whose dependencies are now satisfied.

        Called after every job completion. Also fails jobs whose deps failed.
        """
        async with self._lock:
            pending = self._registry.pending_with_deps()
            for job in pending:
                failed_dep = self._registry.deps_failed(job)
                if failed_dep is not None:
                    job.transition(JobStatus.FAILED)
                    job.error = f"Dependency {failed_dep} failed"
                    self._registry.update(job, event_type="dep_failed")
                    params = self._deferred.pop(job.id, None)
                    if params:
                        await params.notify(
                            f"❌ Job {job.id} failed — dependency {failed_dep} did not complete."
                        )
                    continue

                if self._registry.deps_satisfied(job):
                    if self._registry.running_count() >= self._max_parallel:
                        continue  # Wait for a slot
                    params = self._deferred.pop(job.id, None)
                    if params is None:
                        _log.warning(
                            "Job %s deps resolved but no launch params "
                            "(lost after restart?) — keeping READY",
                            job.id,
                        )
                        continue
                    job.transition(JobStatus.IN_PROGRESS)
                    self._registry.update(job, event_type="deps_resolved")
                    self._launch(
                        job.id,
                        tools=params.tools,
                        notify=params.notify,
                        auth_storage=params.auth_storage,
                        output_format=params.output_format,
                    )
                    _log.info("Job %s deps resolved, launched", job.id)

            self._registry.cleanup_terminal()

    async def retry(
        self,
        job_id: str,
        *,
        notify: Callable[[str], Awaitable[None]],
        tools: list[Any],
        auth_storage: AuthStorage | None = None,
        output_format: str = "plain",
        feedback: str | None = None,
    ) -> bool:
        """Retry a failed job. Resets to RUNNING and re-launches.

        Returns True if the job was found and retried, False otherwise.
        """
        async with self._lock:
            job = self._registry.get(job_id)
            if job is None or job.status != JobStatus.FAILED:
                return False
            if feedback:
                job.feedback = feedback
            job.transition(JobStatus.IN_PROGRESS)
            self._registry.update(job, event_type="retried")

        self._launch(
            job_id,
            tools=tools,
            notify=notify,
            auth_storage=auth_storage,
            output_format=output_format,
        )
        _log.info("Job %s retried", job_id)
        return True

    async def redirect(
        self,
        job_id: str,
        feedback: str,
        *,
        notify: Callable[[str], Awaitable[None]],
        tools: list[Any],
        subagent_name: str | None = None,
        session_model: str | None = None,
        auth_storage: AuthStorage | None = None,
        output_format: str = "plain",
    ) -> bool:
        """Redirect a running job: cancel it, inject feedback, re-launch.

        The job keeps the same ID. The user sees one job, not two.
        Returns True if the redirect succeeded.
        """
        async with self._lock:
            job = self._registry.get(job_id)
            if job is None:
                return False
            if job.status not in (JobStatus.IN_PROGRESS, JobStatus.FAILED):
                return False

        # Cancel the running task if active
        task = self._tasks.get(job_id)
        if task and not task.done():
            task.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=2)
            except (asyncio.CancelledError, TimeoutError):
                pass

        async with self._lock:
            # Job may have been evicted by cleanup_terminal after cancellation;
            # re-insert the saved reference so the redirect can proceed.
            if self._registry.get(job_id) is None:
                self._registry._jobs[job_id] = job
            job.feedback = feedback
            if isinstance(subagent_name, str):
                normalized_subagent = subagent_name.strip()
                job.subagent_name = normalized_subagent or None
            self._snapshot_runtime_route(
                job,
                session_model=session_model,
                force=isinstance(subagent_name, str),
            )
            job.transition(JobStatus.IN_PROGRESS)
            self._registry.update(job, event_type="redirected")

        self._launch(
            job_id,
            tools=tools,
            notify=notify,
            auth_storage=auth_storage,
            output_format=output_format,
        )
        _log.info(
            "Job %s redirected with feedback: %s (subagent=%s)",
            job_id,
            feedback[:80],
            subagent_name,
        )
        return True

    async def cancel(self, job_id: str) -> bool:
        """
        Cancel a running job.

        Returns True if the job was found and cancellation was requested.
        Returns False if the job doesn't exist or is already terminal.
        """
        task = self._tasks.get(job_id)
        if task is None or task.done():
            return False
        task.cancel()
        return True

    async def list_jobs(self) -> list[dict[str, Any]]:
        """Return serialized info for all known jobs (any status)."""
        async with self._lock:
            return [j.to_dict() for j in self._registry.all_jobs()]

    async def list_running(self) -> list[dict[str, Any]]:
        """Return serialized info for currently running jobs only."""
        async with self._lock:
            return [j.to_dict() for j in self._registry.by_status(JobStatus.IN_PROGRESS)]

    async def get_job(self, job_id: str) -> dict[str, Any] | None:
        """Return serialized info for a single job, or None if not found."""
        async with self._lock:
            job = self._registry.get(job_id)
            return job.to_dict() if job else None


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_orchestrator: Orchestrator | None = None


def get_orchestrator() -> Orchestrator:
    """Return the process-wide Orchestrator singleton (lazy-created).

    Reads ``delegation_timeout`` from AgentConfig if available.
    """
    global _orchestrator
    if _orchestrator is None:
        timeout = 1800
        try:
            from otto.config import load_config

            cfg = load_config()
            timeout = cfg.agent.delegation_timeout
        except Exception:
            pass
        _orchestrator = Orchestrator(default_timeout=timeout)
    return _orchestrator
