"""Pulse scheduling — brainfile protocol native.

All scheduling (reminders, recurring tasks, autonomous pulses) is stored as
brainfile pulse task files in ``.brainfile/board/``.  Completed one-shot pulses
are archived to ``.brainfile/logs/``.

The PulseRunner scans the board directory on a timer and dispatches due tasks.
No SQLite — just YAML frontmatter markdown files.
"""

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from otto.log import get_logger

_log = get_logger("otto.autonomy")

AUTONOMY_PULSE_CHAT_ID = "__autonomy__"

_PULSE_ID_RE = re.compile(r"^pulse-(\d+)\.md$")


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


# ---------------------------------------------------------------------------
# YAML frontmatter helpers
# ---------------------------------------------------------------------------


def _read_frontmatter(path: Path) -> dict[str, Any] | None:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None
    if not text.startswith("---"):
        return None
    end = text.find("---", 3)
    if end == -1:
        return None
    try:
        return yaml.safe_load(text[3:end])
    except yaml.YAMLError:
        return None


def _update_frontmatter_field(path: Path, keys: list[str], value: Any) -> None:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return
    if not text.startswith("---"):
        return
    end = text.find("---", 3)
    if end == -1:
        return

    try:
        data = yaml.safe_load(text[3:end]) or {}
    except yaml.YAMLError:
        return

    target = data
    for key in keys[:-1]:
        if key not in target or not isinstance(target[key], dict):
            target[key] = {}
        target = target[key]
    target[keys[-1]] = value

    body = text[end + 3 :]
    new_front = yaml.dump(data, default_flow_style=False, sort_keys=False)
    path.write_text(f"---\n{new_front}---{body}", encoding="utf-8")


def _write_frontmatter_file(path: Path, frontmatter: dict, body: str = "") -> None:
    yaml_str = yaml.dump(
        frontmatter, sort_keys=False, default_flow_style=False, allow_unicode=True
    ).strip()
    content = f"---\n{yaml_str}\n---\n{body}"
    path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# PulseTask dataclass
# ---------------------------------------------------------------------------


@dataclass
class PulseTask:
    """A brainfile task of type 'pulse'."""

    id: str
    title: str
    due_at: datetime
    repeat: str | None
    chat_id: str
    file_path: Path


# ---------------------------------------------------------------------------
# Pulse CRUD — create, scan, list, cancel, archive
# ---------------------------------------------------------------------------


def _next_pulse_id(board: Path, logs: Path | None = None) -> str:
    max_n = 0
    for directory in (board, logs):
        if directory is None or not directory.exists():
            continue
        for path in directory.iterdir():
            m = _PULSE_ID_RE.match(path.name)
            if m:
                max_n = max(max_n, int(m.group(1)))
    return f"pulse-{max_n + 1}"


def create_pulse_task(
    board: Path,
    *,
    title: str,
    due_at: datetime,
    chat_id: str,
    repeat: str | None = None,
    logs: Path | None = None,
) -> PulseTask:
    """Create a new pulse task file in the board directory."""
    board.mkdir(parents=True, exist_ok=True)
    task_id = _next_pulse_id(board, logs)

    if due_at.tzinfo is None:
        due_at = due_at.replace(tzinfo=UTC)

    frontmatter: dict[str, Any] = {
        "id": task_id,
        "title": title,
        "type": "pulse",
        "column": "todo",
        "due_at": due_at.isoformat(),
        "repeat": repeat,
        "chat_id": chat_id,
        "contract": {"status": "ready"},
    }

    path = board / f"{task_id}.md"
    _write_frontmatter_file(path, frontmatter)

    return PulseTask(
        id=task_id,
        title=title,
        due_at=due_at,
        repeat=repeat,
        chat_id=chat_id,
        file_path=path,
    )


def scan_pulse_tasks(brainfile_board: Path) -> list[PulseTask]:
    """Read pulse-type tasks from the brainfile board directory.

    Returns only tasks with contract.status == 'ready' and a valid due_at.
    """
    if not brainfile_board.is_dir():
        return []

    tasks: list[PulseTask] = []
    for path in brainfile_board.iterdir():
        if not path.name.endswith(".md"):
            continue
        try:
            frontmatter = _read_frontmatter(path)
        except Exception:
            continue
        if not frontmatter:
            continue
        if frontmatter.get("type") != "pulse":
            continue

        contract = frontmatter.get("contract") or {}
        if contract.get("status") != "ready":
            continue

        due_at = _parse_iso(frontmatter.get("due_at"))
        if due_at is None:
            continue

        tasks.append(
            PulseTask(
                id=frontmatter.get("id", path.stem),
                title=frontmatter.get("title", ""),
                due_at=due_at,
                repeat=frontmatter.get("repeat"),
                chat_id=frontmatter.get("chat_id", AUTONOMY_PULSE_CHAT_ID),
                file_path=path,
            )
        )
    return tasks


def list_pulse_tasks(brainfile_board: Path, chat_id: str | None = None) -> list[PulseTask]:
    """List all pulse tasks (any ready status), optionally filtered by chat_id."""
    if not brainfile_board.is_dir():
        return []

    tasks: list[PulseTask] = []
    for path in brainfile_board.iterdir():
        if not path.name.endswith(".md"):
            continue
        try:
            frontmatter = _read_frontmatter(path)
        except Exception:
            continue
        if not frontmatter:
            continue
        if frontmatter.get("type") != "pulse":
            continue

        contract = frontmatter.get("contract") or {}
        status = contract.get("status")
        if status not in ("ready", "in_progress"):
            continue

        due_at = _parse_iso(frontmatter.get("due_at"))
        if due_at is None:
            continue

        task_chat_id = frontmatter.get("chat_id", AUTONOMY_PULSE_CHAT_ID)
        if chat_id is not None and task_chat_id != chat_id:
            continue

        tasks.append(
            PulseTask(
                id=frontmatter.get("id", path.stem),
                title=frontmatter.get("title", ""),
                due_at=due_at,
                repeat=frontmatter.get("repeat"),
                chat_id=task_chat_id,
                file_path=path,
            )
        )
    return sorted(tasks, key=lambda t: t.due_at)


def cancel_pulse_task(brainfile_board: Path, task_id: str, logs: Path | None = None) -> bool:
    """Cancel (archive) a pulse task. Returns True if found and cancelled."""
    path = brainfile_board / f"{task_id}.md"
    if not path.exists():
        return False

    fm = _read_frontmatter(path)
    if fm is None or fm.get("type") != "pulse":
        return False

    if logs is not None:
        logs.mkdir(parents=True, exist_ok=True)
        _update_frontmatter_field(path, ["contract", "status"], "cancelled")
        _update_frontmatter_field(path, ["column"], "done")
        dst = logs / path.name
        try:
            # Read updated content, write to logs, remove from board
            dst.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
            path.unlink()
        except OSError:
            pass
    else:
        path.unlink(missing_ok=True)
    return True


def _archive_pulse(task: PulseTask, logs: Path | None) -> None:
    """Move a completed one-shot pulse from board to logs."""
    if logs is None:
        return
    logs.mkdir(parents=True, exist_ok=True)
    dst = logs / task.file_path.name
    try:
        dst.write_text(task.file_path.read_text(encoding="utf-8"), encoding="utf-8")
        task.file_path.unlink()
    except OSError as exc:
        _log.warning("Could not archive pulse %s: %s", task.id, exc)


def check_due_pulses(brainfile_board: Path, now: datetime | None = None) -> list[PulseTask]:
    """Return pulse tasks that are due (due_at <= now)."""
    now = now or _utc_now()
    return [t for t in scan_pulse_tasks(brainfile_board) if t.due_at <= now]


def mark_pulse_in_progress(task: PulseTask) -> None:
    _update_frontmatter_field(task.file_path, ["contract", "status"], "in_progress")


def mark_pulse_done(task: PulseTask, *, logs: Path | None = None) -> None:
    """Mark a pulse task as done, or reset it for the next cycle if recurring."""
    if task.repeat:
        from croniter import croniter

        next_due = croniter(task.repeat, task.due_at).get_next(datetime)
        if next_due.tzinfo is None:
            next_due = next_due.replace(tzinfo=UTC)
        _update_frontmatter_field(task.file_path, ["due_at"], next_due.isoformat())
        _update_frontmatter_field(task.file_path, ["contract", "status"], "ready")
    else:
        _update_frontmatter_field(task.file_path, ["contract", "status"], "done")
        _update_frontmatter_field(task.file_path, ["column"], "done")
        _archive_pulse(task, logs)


# ---------------------------------------------------------------------------
# PulseRunner — the universal pulse dispatcher
# ---------------------------------------------------------------------------


class PulseRunner:
    """Scans brainfile board for due pulse tasks and dispatches them.

    Replaces both the SQLite scheduler and the old AutonomyKernel.
    Runs on a simple asyncio timer in the daemon.
    """

    def __init__(
        self,
        *,
        brainfile_board: Path,
        config: Any,
        dispatch: Any,
        logs: Path | None = None,
    ) -> None:
        self._board = brainfile_board
        self._logs = logs
        self._config = config
        self._dispatch = dispatch

    @property
    def board(self) -> Path:
        return self._board

    @property
    def logs(self) -> Path | None:
        return self._logs

    @property
    def enabled(self) -> bool:
        autonomy = getattr(self._config, "autonomy", None)
        return bool(getattr(autonomy, "enabled", False))

    @property
    def mode(self) -> str:
        autonomy = getattr(self._config, "autonomy", None)
        mode = str(getattr(autonomy, "mode", "passive")).strip().lower()
        if mode not in {"passive", "notify"}:
            return "passive"
        return mode

    @property
    def pulse_seconds(self) -> int:
        autonomy = getattr(self._config, "autonomy", None)
        pulse_minutes = int(getattr(autonomy, "pulse_minutes", 5))
        return max(30, pulse_minutes * 60)

    async def run_pulse(self) -> dict[str, int]:
        now = _utc_now()
        due = check_due_pulses(self._board, now)
        if not due:
            return {"checked": 0, "acted": 0, "skipped": 0}

        stats = {"checked": len(due), "acted": 0, "skipped": 0}

        for task in due:
            try:
                # Autonomous pulses respect the enabled/mode gate
                if task.chat_id == AUTONOMY_PULSE_CHAT_ID:
                    if not self.enabled:
                        stats["skipped"] += 1
                        continue
                    if self.mode == "passive":
                        _log.info("pulse due (passive)", task_id=task.id, title=task.title)
                        stats["skipped"] += 1
                        continue

                mark_pulse_in_progress(task)

                # Reminders use __notify__: prefix for simple message delivery
                prompt = task.title
                if not prompt.startswith("__notify__:"):
                    prompt = f"Pulse task due: {task.title}"

                delivered = await self._dispatch(task.chat_id, prompt)

                if delivered is False:
                    _log.warning("pulse dispatch failed", task_id=task.id)
                    stats["skipped"] += 1
                    continue

                mark_pulse_done(task, logs=self._logs)
                stats["acted"] += 1
            except Exception as exc:
                _log.warning("pulse error", task_id=task.id, error=str(exc))
                stats["skipped"] += 1

        return stats
