"""LSP-based code intelligence for Otto workspaces."""

from otto.lsp.diagnostics import auto_diagnostics
from otto.lsp.pool import LSPPool
from otto.lsp.symbols import lsp_document_symbols, query_symbols

__all__ = [
    "LSPPool",
    "auto_diagnostics",
    "lsp_document_symbols",
    "query_symbols",
]
