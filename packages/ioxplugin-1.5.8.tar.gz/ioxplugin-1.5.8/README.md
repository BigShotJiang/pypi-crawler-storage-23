# ioxplugin
ioxplugin is a python package that helps you create plugin code from simple JSON.

Use pip to install:

```bash
pip install ioxplugin

