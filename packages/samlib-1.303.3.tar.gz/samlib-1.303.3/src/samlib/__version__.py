
# This is a generated file

import typing as _typing

VERSION: _typing.Final = '1.303.3'
SSC_RELEASE: _typing.Final = '2025.4.16.r1.ssc.303'
