"""model - subpackage for spectrospatial models using our framework."""

# TODO: currently still tied up in spectracles/model , needs to be refactored/separated
