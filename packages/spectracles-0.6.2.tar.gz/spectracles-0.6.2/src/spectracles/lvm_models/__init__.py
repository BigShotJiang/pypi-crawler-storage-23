"""lvm_models.py - subpackage for LVM spectrospatial models."""
