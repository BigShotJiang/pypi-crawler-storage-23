import astropy.constants as const

C_KMS = const.c.to_value("km/s")
