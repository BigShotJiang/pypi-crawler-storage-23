"""Atlassian Cloud CLI tools for Confluence and Jira."""

__version__ = '0.3.0'
