"""Compatibility module for configuration exports."""

from databricks_api.config import AccountConfig, AuthConfig, UnifiedConfig, WorkspaceConfig

__all__ = ["AccountConfig", "AuthConfig", "UnifiedConfig", "WorkspaceConfig"]
