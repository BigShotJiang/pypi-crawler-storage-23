import lamindb as ln

# different from the one in duplicate4
ln.track()

ln.finish()
