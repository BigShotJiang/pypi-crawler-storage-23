# examples

Self-contained examples of using `heavylight`

## Examples Included

Protection Risk Model (with excel equivalent)

- using numpy / vectorised

- without vectorisation

- 'feature' model which demonstrates some features

