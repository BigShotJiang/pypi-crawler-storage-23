# Protection Model

This example contains a protection model, coded both non-vectorised and vectorised.