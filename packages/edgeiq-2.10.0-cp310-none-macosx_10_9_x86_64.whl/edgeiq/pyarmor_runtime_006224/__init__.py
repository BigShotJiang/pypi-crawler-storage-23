# Pyarmor 8.5.12 (group), 006224, 2026-02-20T20:58:08.245850
from .pyarmor_runtime import __pyarmor__
