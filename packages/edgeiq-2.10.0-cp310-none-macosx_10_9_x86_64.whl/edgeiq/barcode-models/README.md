### WeChat QRCode

CNN models for `wechat_qrcode` module, including the detector model and the super scale model.

|file|MD5|
|----|----|
|detect.caffemodel|238e2b2d6f3c18d6c3a30de0c31e23cf|
|detect.prototxt|6fb4976b32695f9f5c6305c19f12537d|
|sr.caffemodel|cbfcd60361a73beb8c583eea7e8e6664|
|sr.prototxt|69db99927a70df953b471daaba03fbef|

Source: `https://github.com/WeChatCV/opencv_3rdparty`
