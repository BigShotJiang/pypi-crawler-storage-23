# rye:signed:2026-02-26T05:52:24Z:b9f2acbd0110656d9e859969b48adde6ca7a8ac254814ffa87e6a0ad68e77f9a:LCtQRkYUK54ev67ZEZ-YMDv9gqrEdu5zFwgvPVLTZLjdfIXcsVVAdgSklqonU8P4qk4RnvCasTYt18RhZblKAQ==:4b987fd4e40303ac
"""Extractor tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/extractors"
__tool_description__ = "Extractor tools package"
