"""Test utils package imports."""

from __future__ import annotations


def test_utils_imports():
    """Test that utils package can be imported."""
    import hud.utils

    assert hud.utils is not None
