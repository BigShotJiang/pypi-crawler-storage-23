"""Tests for hud.cli module commands."""

from __future__ import annotations

import json
import logging
import tempfile
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from hud.cli import app, main

runner = CliRunner()

logger = logging.getLogger(__name__)


class TestCLICommands:
    """Test CLI command handling."""

    def test_main_shows_help_when_no_args(self) -> None:
        """Test that main() shows help when no arguments provided."""
        result = runner.invoke(app)
        assert result.exit_code == 2
        assert "Usage:" in result.output

    def test_analyze_docker_image(self) -> None:
        """Test analyze command with Docker image."""
        with patch("hud.cli.analyze.asyncio.run") as mock_run:
            result = runner.invoke(app, ["analyze", "test-image:latest"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            coro = mock_run.call_args[0][0]
            assert coro.__name__ == "analyze_from_metadata"

    def test_analyze_with_docker_args(self) -> None:
        """Test analyze command with additional Docker arguments."""
        with patch("hud.cli.analyze.asyncio.run") as mock_run:
            result = runner.invoke(
                app, ["analyze", "test-image", "--", "-e", "KEY=value", "-p", "8080:8080"]
            )
            assert result.exit_code == 0
            mock_run.assert_called_once()

    def test_analyze_with_config_file(self) -> None:
        """Test analyze command with config file."""
        import os

        fd, temp_path = tempfile.mkstemp(suffix=".json")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump({"test": {"command": "python", "args": ["server.py"]}}, f)

            with patch("hud.cli.analyze.asyncio.run") as mock_run:
                result = runner.invoke(app, ["analyze", "dummy", "--config", temp_path])
                assert result.exit_code == 0
                mock_run.assert_called_once()
                coro = mock_run.call_args[0][0]
                assert coro.__name__ == "analyze_environment_from_config"
        finally:
            try:
                os.unlink(temp_path)
            except Exception:
                logger.exception("Error deleting temp file")

    def test_analyze_no_arguments_shows_error(self) -> None:
        """Test analyze without arguments shows error."""
        result = runner.invoke(app, ["analyze"])
        assert result.exit_code == 1
        assert "Error" in result.output

    def test_analyze_output_formats(self) -> None:
        """Test analyze with different output formats."""
        for format_type in ["interactive", "json", "markdown"]:
            with patch("hud.cli.analyze.asyncio.run"):
                result = runner.invoke(app, ["analyze", "test-image", "--format", format_type])
                assert result.exit_code == 0

    def test_debug_docker_image(self) -> None:
        """Test debug command with Docker image."""
        with patch("hud.cli.debug.asyncio.run") as mock_run:
            mock_run.return_value = 5
            result = runner.invoke(app, ["debug", "test-image:latest"])
            assert result.exit_code == 0
            mock_run.assert_called_once()

    def test_debug_with_max_phase(self) -> None:
        """Test debug command with max phase limit."""
        with patch("hud.cli.debug.asyncio.run") as mock_run:
            mock_run.return_value = 3
            result = runner.invoke(app, ["debug", "test-image", "--max-phase", "3"])
            assert result.exit_code == 0

    def test_debug_with_config_file(self) -> None:
        """Test debug command with config file."""
        import os

        fd, temp_path = tempfile.mkstemp(suffix=".json")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump({"test": {"command": "python", "args": ["server.py"]}}, f)

            with patch("hud.cli.debug.asyncio.run") as mock_run:
                mock_run.return_value = 5
                result = runner.invoke(app, ["debug", "dummy", "--config", temp_path])
                assert result.exit_code == 0
        finally:
            try:
                os.unlink(temp_path)
            except Exception:
                logger.exception("Error deleting temp file")

    def test_debug_no_arguments_shows_error(self) -> None:
        """Test debug without arguments shows error."""
        result = runner.invoke(app, ["debug"])
        assert result.exit_code == 1
        assert "Error" in result.output

    def test_version_command(self) -> None:
        """Test version command."""
        import re

        ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
        with patch("hud.__version__", "1.2.3"):
            result = runner.invoke(app, ["version"])
            assert result.exit_code == 0
            clean_output = ansi_escape.sub("", result.output)
            assert "1.2.3" in clean_output

    def test_version_import_error(self) -> None:
        """Test version command when version unavailable."""
        with patch.dict("sys.modules", {"hud": None}):
            result = runner.invoke(app, ["version"])
            assert result.exit_code == 0
            assert "HUD CLI version: unknown" in result.output

    def test_mcp_command(self) -> None:
        """Test mcp server command."""
        result = runner.invoke(app, ["mcp"])
        assert result.exit_code == 2

    def test_help_command(self) -> None:
        """Test help command shows proper info."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "analyze" in result.output
        assert "debug" in result.output


class TestMainFunction:
    """Test the main() function specifically."""

    def test_main_with_help_flag(self) -> None:
        """Test main() with --help flag."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = ["hud", "--help"]
            with (
                patch("hud.cli.console") as mock_console,
                patch("hud.cli.app") as mock_app,
            ):
                main()
                assert mock_console.print.called or mock_app.called
        finally:
            sys.argv = original_argv

    def test_main_with_no_args(self) -> None:
        """Test main() with no arguments."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = ["hud"]
            with patch("hud.cli.console") as mock_console:
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 2
                assert any("Quick Start" in str(call) for call in mock_console.print.call_args_list)
        finally:
            sys.argv = original_argv


if __name__ == "__main__":
    pytest.main([__file__])
