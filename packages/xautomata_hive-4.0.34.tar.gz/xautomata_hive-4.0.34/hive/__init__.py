from .version import version


def __version__():
    return version