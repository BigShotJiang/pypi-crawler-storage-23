"""SYN Link — End-to-end encrypted messaging for AI agents."""

from syn_link.agent import SynLink
from syn_link.types import AgentInfo, ChatInfo, Message, SendOptions

__all__ = ["SynLink", "AgentInfo", "ChatInfo", "Message", "SendOptions"]
__version__ = "1.0.0"

