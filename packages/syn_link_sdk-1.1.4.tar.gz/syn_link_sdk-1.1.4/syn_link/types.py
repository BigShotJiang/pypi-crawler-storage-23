"""SYN Link — Type definitions (Protocol v1)."""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class AgentInfo:
    id: str
    username: str
    name: str
    description: str
    public_key: str
    signing_public_key: str = ""
    visibility: str = "private"
    status: Optional[str] = None  # May be None if status_visibility = 'hidden'
    status_visibility: str = "visible"
    created_at: str = ""
    is_you: bool = False


@dataclass
class ChatParticipant:
    id: str
    username: str
    name: str
    description: str
    public_key: str
    signing_public_key: str = ""
    status: Optional[str] = None
    status_visibility: str = "visible"


@dataclass
class ChatInfo:
    id: str
    created_by: str
    created_at: str
    updated_at: str
    participants: List[ChatParticipant] = field(default_factory=list)


@dataclass
class Message:
    id: str
    chat_id: str
    from_agent: str
    from_username: str
    from_name: str
    content: str
    content_type: str
    reply_expected: bool
    reply_to: Optional[str]
    timestamp: str
    mentions: Optional[List[str]] = None


@dataclass
class RawIncomingMessage:
    id: str
    chat_id: str
    from_agent: str
    from_username: str
    from_name: str
    content_type: str
    reply_expected: int
    reply_to: Optional[str]
    timestamp: str
    encrypted_content: str
    nonce: str
    mentions: Optional[List[str]] = None
    version: Optional[int] = None
    ratchet_header: Optional[str] = None
    group_encrypted_content: Optional[str] = None
    group_nonce: Optional[str] = None
    group_key_version: Optional[int] = None


@dataclass
class SendOptions:
    content_type: str = "text"
    reply_expected: bool = False
    reply_to: Optional[str] = None
    mentions: Optional[List[str]] = None


@dataclass
class BlockRule:
    type: str  # "agent", "username_pattern", or "content_type"
    value: str


@dataclass
class RateLimitConfig:
    global_limit_count: int = 0
    global_limit_window: int = 60
    per_sender_limit_count: int = 0
    per_sender_limit_window: int = 60
