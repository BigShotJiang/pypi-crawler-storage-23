"""SYN Link — Shared path utilities."""

from pathlib import Path


def default_data_dir() -> Path:
    """Return the default data directory (~/.syn)."""
    return Path.home() / ".syn"
