import logging

from ...models.zoommap import ZoommapLayer
from ..utils import generate_uuid

logger = logging.getLogger(__name__)


def create_layer(
    id: str = None,
    name: str = "Region Layer",
    layer_type: str = "draw",
    bound_base: str = None,
    visible: bool = True,
    locked: bool = False,
) -> ZoommapLayer:
    """Generates a Zoommap layer object"""
    logger.debug("Creating Drawing Layer")
    return ZoommapLayer(
        id=id if id else layer_type + "_" + generate_uuid(),
        name=name,
        visible=visible,
        locked=locked,
        boundBase=bound_base,
    )
