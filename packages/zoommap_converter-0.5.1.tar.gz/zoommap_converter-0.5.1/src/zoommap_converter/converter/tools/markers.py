import logging
from pathlib import Path
import re

from ...models.zoommap import ZoommapMarker
from ...models.leaflet import LeafletMapMarker, LeafletMarkerIcon
from ..utils import clean_image_name, decode_utf8_url_encoded
from .layers import create_layer
from .scale import calculate_position

logger = logging.getLogger(__name__)

DEFAULT_MARKER_TYPE = "pinRed"


def convert_markers(
    leaflet_markers: LeafletMapMarker,
    marker_icons: list[LeafletMarkerIcon],
    bounds: dict,
    images: list | None = None,
) -> list[ZoommapMarker]:
    """Converts Leaflet Markers to Zoommap format."""
    logger.debug("Converting Markers")
    new_markers = []
    images = images or []
    new_layers = [create_layer(layer_type="layer", name="Default")]
    if leaflet_markers:
        for marker in leaflet_markers.markers:
            # Get the marker icon type
            marker_type = marker.type

            # Identify the marker_icon to match icon and colours
            logger.debug("Marker Icons: %s", marker_icons)
            logger.debug("Marker Type: %s", marker_type)
            marker_icon = next(
                (icon for icon in marker_icons if icon.type == marker_type), None
            )
            if marker_icon is None:
                logger.warning(
                    f"No marker icon found for type '{marker_type}', using default"
                )
                marker_icon = LeafletMarkerIcon()  # Use default marker icon
            else:
                logger.debug("Marker Type found: %s", marker_icon)
            if marker_type == "default":
                marker_type = DEFAULT_MARKER_TYPE

            # Deduce the x/y coords
            # Leaflet goes from [0,0] at the bottom-left and coords in y,x (long, lat?) format
            # Zoommap has [0, 0] at the top-left
            y, x = marker.loc
            logger.debug("Bounds: %s", bounds)
            x, y = calculate_position(x, y, bounds)
            logger.debug("--- Marker Comparison ---")
            logger.debug("Old Position: %s", marker.loc)
            logger.debug("New Position: %s", (x, y))

            # Find existing layer or create new one
            logger.debug("Original layer name: %s", marker.layer)
            pattern = r"\[\[(.*?)(?:\|(.*?))?\]\]"
            decoded_layer = decode_utf8_url_encoded(marker.layer)
            logger.debug("URL decoded layer: %s", decoded_layer)
            match = re.search(pattern, decoded_layer)
            # Get the layer name from the image label, if it exists
            layer_name = ""
            if match and images:
                logger.debug("Layer Match Found!")
                image_name = match.group(1)
                logger.debug("Image Name: %s", image_name)
                for image in images:
                    clean_image = clean_image_name(image_name)
                    clean_file = clean_image_name(Path(image["path"]).name)
                    logger.debug("Cleaned Image: %s", clean_image)
                    logger.debug("Image Path: %s", clean_file)
                    if clean_image == clean_file:
                        layer_name = image["name"]

                # If no matching image label found, fallback to using layer name as the label
                if not layer_name:
                    layer_name = match.group(2) or clean_image_name(image_name)
                    logger.debug(
                        "Layer Name (Original): %s, Layer Label: %s",
                        image_name,
                        match.group(2),
                    )
            else:
                # Handle cases where the string isn't a valid wiki-link
                logger.debug("No match found")
                layer_name = clean_image_name(decode_utf8_url_encoded(marker.layer))

            logger.debug("Adding new layer: %s", layer_name)
            existing_layer = next(
                (layer for layer in new_layers if layer.name == layer_name), None
            )
            if existing_layer is None:
                new_layer = create_layer(layer_type="layer", name=layer_name)
                new_layers.append(new_layer)
                layer_id = new_layer.id
            else:
                layer_id = existing_layer.id

            new_markers.append(
                ZoommapMarker(
                    id=marker.id,
                    type="pin",
                    x=x,
                    y=y,
                    layer=layer_id,
                    link=marker.link,
                    iconKey=marker_icon.iconName,
                    tooltip=marker.description,
                    minZoom=marker.minZoom,
                    maxZoom=marker.maxZoom,
                    iconColor=marker_icon.color,
                    scaleLikeSticker=False,
                )
            )

    return new_markers, new_layers
