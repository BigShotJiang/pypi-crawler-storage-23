import logging
from obsidian_parser import Vault
from pathlib import Path
from collections import defaultdict

from .converter import (
    parse_leaflet_notes,
    associate_notes_to_maps,
    scrape_vault,
    convert_note,
    merge_zoommap_jsons,
    render_zoommap,
    read_json,
)
from .models.leaflet import LeafletJsonData
from .models.models import ZoommapConversion

logger = logging.getLogger(__name__)

NON_IMAGE_SUFFIXES = (
    # Code/files
    ".md",
    ".json",
    ".js",
    ".py",
    ".ts",
    ".jsx",
    ".tsx",
    ".html",
    ".css",
    ".scss",
    ".less",
    ".php",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".cs",
    ".go",
    ".rb",
    ".sh",
    ".bat",
    ".ps1",
    ".sql",
    ".yml",
    ".yaml",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".log",
    ".txt",
    ".csv",
    ".tsv",
    ".xml",
    # Documents
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".odt",
    ".ods",
    ".odp",
    ".rtf",
    # Archives/compressed
    ".zip",
    ".tar",
    ".gz",
    ".bz2",
    ".7z",
    ".rar",
    ".xz",
    # System/files
    ".gitignore",
    ".gitattributes",
    ".gitkeep",
    ".gitmodules",
    ".dockerignore",
    ".env",
    ".htaccess",
    ".htpasswd",
    # Build/config
    ".lock",
    ".min.js",
    ".min.css",
    ".map",
    ".d.ts",
    ".dll",
    ".exe",
    ".so",
    ".dylib",
    ".a",
    ".o",
    ".class",
    # Temporary/cache
    ".tmp",
    ".temp",
    ".bak",
    ".backup",
    ".swp",
    ".swo",
    ".cache",
    # Media (non-image)
    ".mp3",
    ".wav",
    ".ogg",
    ".flac",
    ".m4a",
    ".aac",
    ".mp4",
    ".mov",
    ".avi",
    ".mkv",
    ".webm",
    ".flv",
    ".wmv",
)


def merge_markers(
    zoommap_data: list[ZoommapConversion], vault: Vault, merge_by: str = None
) -> list[ZoommapConversion]:
    """Groups conversions by image or marker tags and merges their markers/layers."""
    logger.info("Merging markers by %s", merge_by)
    if not merge_by:
        return zoommap_data
    groups = defaultdict(list)
    standalone_results = []

    for conv in zoommap_data:
        # Use the relative image path as the key
        if merge_by == "image":
            merge_key = conv.zoommap_block.image
            groups[merge_key].append(conv)
        # Use the relative image and marker tags as the key
        elif merge_by == "marker_tags":
            if conv.marker_tag:
                # Participants in the merge
                marker_tags = "_".join(sorted(conv.marker_tag))
                merge_key = f"{conv.zoommap_block.image}_{marker_tags}"
                groups[merge_key].append(conv)
            else:
                # Notes without tags should not be discarded!
                standalone_results.append(conv)
        else:
            standalone_results.append(conv)

    merged_results = standalone_results
    logger.debug("Merge Keys: %s", groups.keys())
    for merge_key, group in groups.items():
        if len(group) == 1:
            merged_results.extend(group)
            continue

        logger.info("Merging %s map instances for merge key: %s", len(group), merge_key)

        # 1. Create the unified JSON structure
        unified_json = merge_zoommap_jsons(
            [conversion.zoommap_json for conversion in group]
        )

        # 2. Define the new shared path: image.ext.markers.json
        shared_marker_path = Path(f"{merge_key}.markers.json")

        for conv in group:
            conv.zoommap_json = unified_json
            conv.marker_json_path = vault.path / shared_marker_path
            conv.zoommap_block.markers = shared_marker_path
            merged_results.append(conv)

    return merged_results


def run(
    vault_path: Path,
    filters: list,
    json_path: Path,
    merge_by_image: bool = False,
    ignore_marker_tags: bool = False,
):
    # 0. Setting up the run.
    logger.info("Hello from zoommap-converter!")
    logger.info("Loading vault at: %s", vault_path)
    logger.info("Warning: for large vaults, this may take some time! %s", vault_path)
    vault = Vault(vault_path)
    logger.debug("Vault imported. Found %s notes", len(vault.notes))
    NON_NOTE_FILES = [
        file
        for file in vault.file_paths
        if not file.as_posix().endswith(NON_IMAGE_SUFFIXES)
    ]
    logger.debug("Vault Path: %s", vault.path.as_posix())

    # 1. Scraping the vault for leaflet code blocks.
    logger.debug("Filters: %s", filters)
    notes_with_leaflet_blocks = scrape_vault(vault, filters)
    logger.info(
        "Found %s notes containing Leaflet codeblocks.", len(notes_with_leaflet_blocks)
    )
    logger.debug("-" * 50)
    logger.debug(
        "Filtered Notes: %s", [note.name for note in notes_with_leaflet_blocks]
    )
    logger.debug("-" * 50)

    # 2. Parsing Leaflet code blocks
    parsed_notes = parse_leaflet_notes(notes_with_leaflet_blocks)
    # logger.debug("Leaflet Dicts: %s", [item.note.name for item in leaflet_dict])
    # logger.debug("Sample Leaflet Objects: %s", [item.leaflet_blocks[0] for item in leaflet_dict])
    logger.debug("Leaflet Dicts: %s", parsed_notes)
    logger.debug("-" * 50)
    # Collect failed blocks for reporting
    failed_blocks = [
        (pn.note.name, block.error)
        for pn in parsed_notes
        for block in pn.leaflet_blocks
        if block.error
    ]
    # Create filtered list of notes containing only the valid codeblocks
    valid_parsed_notes = []
    for pn in parsed_notes:
        valid_blocks = [
            block for block in pn.leaflet_blocks if not block.error and block.data
        ]
        if valid_blocks:
            pn.leaflet_blocks = valid_blocks
            valid_parsed_notes.append(pn)
    leaflet_json_data = LeafletJsonData(**read_json(file_path=vault.path / json_path))
    # 3. Only use the valid parsed notes to find markerTags
    if any(
        block.data.markerTag for pn in valid_parsed_notes for block in pn.leaflet_blocks
    ):
        leaflet_json_data = associate_notes_to_maps(
            parsed_notes=valid_parsed_notes,
            all_notes=vault.notes,
            leaflet_json=leaflet_json_data,
        )
    else:
        logger.info("No valid maps with 'markerTag' found. Skipping association.")
    logger.debug("Leaflet's data.json: %s", leaflet_json_data)

    # 4. Convert the valid Leaflet codeblocks to Zoommap
    zoommap_data = [
        convert_note(
            leaflet_note=note,
            leaflet_data=leaflet_json_data,
            non_note_files=NON_NOTE_FILES,
            vault_path=vault.path,
        )
        for note in valid_parsed_notes
    ]
    if not zoommap_data:
        logger.info("No zoommap data converted. Exiting...")
        raise Exception
    logger.debug("Sample Converted Zoommap Data: %s", zoommap_data[0])

    # 5. Render the zoommap codeblocks in markdown
    zoommap_data_flat = [item for sublist in zoommap_data for item in sublist]
    if merge_by_image:
        zoommap_data_flat = merge_markers(
            zoommap_data=zoommap_data_flat, vault=vault, merge_by="image"
        )
    elif not ignore_marker_tags:
        if any(zoommap.marker_tag for zoommap in zoommap_data_flat):
            zoommap_data_flat = merge_markers(
                zoommap_data=zoommap_data_flat, vault=vault, merge_by="marker_tags"
            )

    replacements = {data.note.name: render_zoommap(data) for data in zoommap_data_flat}
    logger.info("The following codeblock replacements failed.")
    logger.info("Replacements: %s", replacements)
    # Report failures back to the user.
    failures = {
        name: status for name, status in replacements.items() if status is False
    }

    if failures:
        logger.warning("-" * 50)
        logger.warning("FAILED CONVERSIONS:")
        logger.warning("The following codeblock replacements failed:")
        logger.warning("Parsing Failures: %s", failed_blocks)
        logger.warning("Replacements: %s", failures)
        for note_name in failures:
            logger.warning(f"  - {note_name}")
        logger.warning("-" * 50)
    else:
        logger.info("All codeblock replacements were successful.")
    logger.info("Conversion Complete! Processed %d notes.", len(replacements))
