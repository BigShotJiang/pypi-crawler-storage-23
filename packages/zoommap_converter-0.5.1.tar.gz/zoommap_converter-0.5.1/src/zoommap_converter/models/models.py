import os
from obsidian_parser import Note
from pathlib import Path
from pydantic import BaseModel, ConfigDict, Field, field_validator, BeforeValidator
from typing import Optional, Any, Annotated
from ..conf.settings import Settings
from .defaults import load_defaults

settings = Settings(settings_path=os.getenv("SETTINGS")).settings

VAULT_PATH = settings.get("vault_path", None)
ZOOM_SETTINGS = settings.get("zoommap_settings", {})
DEFAULT_RENDER_MODE = ZOOM_SETTINGS.get("render", "canvas")
DEFAULT_MIN_ZOOM = ZOOM_SETTINGS.get("min_zoom", 0.0025)
DEFAULT_MAX_ZOOM = ZOOM_SETTINGS.get("max_zoom", 3.0)


def ensure_list(v: any) -> any:
    if isinstance(v, str):
        return [v]
    return v


############# PARSING OBJECTS #############


class LeafletYamlBlock(BaseModel):
    id: str
    image: Annotated[list[str] | None, BeforeValidator(ensure_list)] = None
    bounds: list | None = None
    height: str | int | None = None
    width: str | int | None = None
    lat: str | float | None = None
    long: str | float | None = None
    minZoom: str | float | None = None
    maxZoom: str | float | None = None
    defaultZoom: str | float | None = None
    zoomDelta: str | float | None = None
    unit: str | None = None
    scale: str | float | None = None
    recenter: bool | None = None
    darkmode: bool | None = None
    markerTag: Annotated[list[str] | None, BeforeValidator(ensure_list)] = None
    markerFolder: Annotated[list[str] | None, BeforeValidator(ensure_list)] = None
    markerFile: Annotated[list[str] | None, BeforeValidator(ensure_list)] = None

    @field_validator("image", mode="before")
    def parse_image_field(cls, v):
        if isinstance(v, str):
            return [v]
        return v


class ParsedBlock(BaseModel):
    data: LeafletYamlBlock | None = None
    in_callout: bool
    callout_depth: int
    raw_block: str
    error: Any | None = None


class ParsedNote(BaseModel):
    note: Note
    leaflet_blocks: list[ParsedBlock]

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ZoommapView(BaseModel):
    zoom: float = None  # Default Zoom value
    centerX: float = None
    centerY: float = None


class ZoommapBlock(BaseModel):
    id: str
    imageBases: list[dict]
    minZoom: float | None = float(DEFAULT_MIN_ZOOM)
    maxZoom: float | None = float(DEFAULT_MAX_ZOOM)
    height: Optional[str] = Field(
        default_factory=lambda: load_defaults(Path("zoom-map") / "data.json")[
            "defaultHeight"
        ]
    )  # Set the map viewport size. If the checkbox is enabled,
    width: Optional[str] = Field(
        default_factory=lambda: load_defaults(Path("zoom-map") / "data.json")[
            "defaultWidth"
        ]
    )  # the value is stored in YAML and the map will always reopen in that size
    markerLayers: list = ["Default"]
    imageOverlays: Optional[list] = None
    render: str = DEFAULT_RENDER_MODE  # canvas | dom
    resizable: bool = Field(
        default_factory=lambda: load_defaults(Path("zoom-map") / "data.json")[
            "defaultResizable"
        ]
    )  # If enabled, you can resize the map window by dragging in the note.
    resizeHandle: str = Field(
        default_factory=lambda: load_defaults(Path("zoom-map") / "data.json")[
            "defaultResizeHandle"
        ]
    )  # Only appears if Resizable is enabled. Options are left, right, both, and native.
    responsive: bool = False  # Always sets width to 100% of the window and keeps the image aspect ratio.
    align: str = "center"  # Show the map left/right/center in the note.
    wrap: bool = False  # Allows text to wrap around map
    markers: str = None
    image: Optional[str] = None
    view: Optional[ZoommapView] = None


class ZoommapConversion(BaseModel):
    note: Note
    leaflet_block: ParsedBlock
    zoommap_block: ZoommapBlock
    zoommap_json: Any
    marker_json_path: Any
    marker_tag: Annotated[list[str] | None, BeforeValidator(ensure_list)] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


def find_all_extras(obj: Any, path=""):
    extras = {}
    if isinstance(obj, BaseModel):
        if obj.model_extra:
            extras[path or "<root>"] = obj.model_extra
        for field_name in obj.model_fields:
            value = getattr(obj, field_name)
            new_path = f"{path}.{field_name}" if path else field_name
            extras.update(find_all_extras(value, new_path))
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            extras.update(find_all_extras(item, f"{path}[{i}]"))
    return extras
