"""Schema data files for highflame_policy package."""
