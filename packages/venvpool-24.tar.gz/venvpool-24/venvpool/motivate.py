'Create and maintain wrapper scripts in ~/.local/bin for all runnable modules in the given projects, or the current project if none given.'
from . import main

if '__main__' == __name__:
    main()
