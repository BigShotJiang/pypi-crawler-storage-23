"""Skill integration package."""
