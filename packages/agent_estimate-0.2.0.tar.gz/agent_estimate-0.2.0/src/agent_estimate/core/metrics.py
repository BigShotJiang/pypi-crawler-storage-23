"""Metrics and calibration math helpers (stub)."""
