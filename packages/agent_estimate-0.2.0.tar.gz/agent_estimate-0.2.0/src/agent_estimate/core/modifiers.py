"""Runtime and risk modifiers for baseline estimates."""

from __future__ import annotations

import logging

from agent_estimate.core.models import ModifierSet, ReviewMode

logger = logging.getLogger(__name__)

_MODIFIER_FLOOR = 0.10

# Review overhead constants (additive, minutes)
# Evidence from 33 validated dispatches — see issue #46.
_REVIEW_OVERHEAD: dict[ReviewMode, float] = {
    ReviewMode.NONE: 0.0,      # self-merge, no cross-agent review
    ReviewMode.STANDARD: 15.0,  # clean 2x-LGTM, 1-2 rounds
    ReviewMode.COMPLEX: 25.0,   # 3+ rounds, security-sensitive, new algorithms
}


def build_modifier_set(
    *,
    spec_clarity: float = 1.0,
    warm_context: float = 1.0,
    agent_fit: float = 1.0,
) -> ModifierSet:
    """Build a modifier set from individual factors.

    Args:
        spec_clarity: How clear/complete the spec is (0.3=crystal clear spec with design doc,
            1.0=normal, 1.3=vague).
        warm_context: Whether the agent has prior context (0.3=agent just completed closely
            related work, 0.5=same project recently, 1.0=cold, 1.15=very cold/new domain).
        agent_fit: How well the agent suits this task type (0.9=great, 1.2=poor).

    Raises:
        ValueError: If any modifier is outside its valid range.
    """
    _validate_range("spec_clarity", spec_clarity, 0.3, 1.3)
    _validate_range("warm_context", warm_context, 0.3, 1.15)
    _validate_range("agent_fit", agent_fit, 0.9, 1.2)

    raw_combined = spec_clarity * warm_context * agent_fit
    clamped = raw_combined < _MODIFIER_FLOOR
    combined = raw_combined
    if clamped:
        combined = _MODIFIER_FLOOR
        logger.warning(
            "Modifier product %.4f clamped to %.2f (prevents sub-10m pathology)",
            raw_combined,
            _MODIFIER_FLOOR,
        )
    return ModifierSet(
        spec_clarity=spec_clarity,
        warm_context=warm_context,
        agent_fit=agent_fit,
        combined=combined,
        raw_combined=raw_combined,
        clamped=clamped,
    )


def apply_modifiers(
    base_minutes: float,
    modifiers: ModifierSet,
) -> float:
    """Apply a modifier set to a base estimate."""
    return base_minutes * modifiers.combined


def compute_review_overhead(review_mode: ReviewMode) -> float:
    """Return the additive review overhead in minutes."""
    return _REVIEW_OVERHEAD[review_mode]


def _validate_range(name: str, value: float, lo: float, hi: float) -> None:
    if not (lo <= value <= hi):
        raise ValueError(f"{name} must be between {lo} and {hi}, got {value}")
