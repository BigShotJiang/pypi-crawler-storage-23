# aocstat

A command line tool for interacting with Advent of Code.
