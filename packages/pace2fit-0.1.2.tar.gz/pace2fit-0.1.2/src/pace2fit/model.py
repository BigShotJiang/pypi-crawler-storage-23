"""Intermediate representation for parsed workouts."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class DurationType(Enum):
    """How a workout step's duration is measured."""

    TIME = "time"
    DISTANCE = "distance"
    OPEN = "open"


class IntensityType(Enum):
    """FIT intensity classification for a workout step."""

    WARMUP = "warmup"
    ACTIVE = "active"
    COOLDOWN = "cooldown"
    REST = "rest"
    RECOVERY = "recovery"


# ---------------------------------------------------------------------------
# Targets
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PaceTarget:
    """Target pace expressed as a speed range in m/s.

    *low* is the slower speed (higher min/km number),
    *high* is the faster speed (lower min/km number).
    """

    low: float  # m/s (slower end)
    high: float  # m/s (faster end)


@dataclass(frozen=True)
class ZoneTarget:
    """Target heart-rate zone (1-5)."""

    zone: int


Target = PaceTarget | ZoneTarget | None


# ---------------------------------------------------------------------------
# Steps
# ---------------------------------------------------------------------------


@dataclass
class WorkoutStep:
    """A single segment of a workout (e.g. "10min @Z2")."""

    duration_type: DurationType
    duration_value: float | None = None  # seconds for TIME, metres for DISTANCE
    target: Target = None
    intensity: IntensityType = IntensityType.ACTIVE
    name: str | None = None


@dataclass
class RepeatStep:
    """A block of steps to be repeated N times (e.g. "3x(8min@5:00+2min@6:00)")."""

    count: int
    steps: list[WorkoutStep] = field(default_factory=list)


Step = WorkoutStep | RepeatStep


@dataclass
class Workout:
    """Top-level workout containing an ordered list of steps."""

    name: str
    steps: list[Step] = field(default_factory=list)
