"""
Utility Functions

Helper functions and utilities for StatCan API coordinate handling,
SQL query construction, and other common operations.
"""
