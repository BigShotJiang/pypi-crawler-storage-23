"""
Database Operations

Handles SQLite database connections, schema management, and query operations
for persistent storage of Statistics Canada data.
"""
