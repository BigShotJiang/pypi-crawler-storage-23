"""
StatCan API Client and Tools

Provides MCP tools for interacting with Statistics Canada's Web Data Service API.
Includes functions for cube operations, vector operations, and metadata queries.
"""
