# AuraView
a minimal, elegant image viewer inspired by the art of melody.

---

## ✨ About

AuraView is a minimalist photo viewer designed to stay out of your way.
No clutter. No unnecessary controls. Just your images — fast and clear.

It focuses on:

- ⚡ Speed
- 🧼 Clean interface
- 🖼️ Smooth image viewing
- 🪶 Lightweight footprint

---

## 🐍 Requirements

- Python 3.14.2 (Tested)
- pandas
- pillow
- pillow_heif

---

## 🚀 Features

- View photos smoothly and instantly
- Supports Apple image formats (including HEIF/HEIC)
- Keyboard-based image navigation
- Image rotation support
- In-place rotation (changes persist)
- Copy images to another location
- Move images between directories

---

## 📦 Installation

Install AuraView using pip:

```bash
pip install auraview
```

## 🖥️ Usage

Launch AuraView:

```bash
auraview
````

Open a specific directory:

```bash
auraview /path/to/folder
```

Open a specific image file:

```bash
auraview /path/to/image.jpg
```

---

### 📌 Command Line Options

Show version:

```bash
auraview --version
auraview -v
```

Show help:

```bash
auraview --help
auraview -h
```

Show author:

```bash
auraview --author
auraview -a
```

Show author email:

```bash
auraview --email
auraview -e
```

Show release date:

```bash
auraview --date
auraview -d
```
## Version 0.4.0 23-02-2026
- removed recursive selection of all images while using file as input.
## Version 0.3.0 23-02-2026
- added additional requirement to pyproject.toml
## Version 0.2.0 23-02-2026
- Added image counter
- Added go to image index feature
- added copy, move
# Changelog
## Version 0.1.0 - 19-02-2026
- Initial release
- Able to view photos.
- supports apple image extensions.
- Navigation supported.
- Image transform: Rotation possible.
- Rotations are considered inplace.
- Copy and Move functions available.
