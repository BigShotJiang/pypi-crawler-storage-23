## Version 0.4.0 23-02-2026
- removed recursive selection of all images while using file as input.
## Version 0.3.0 23-02-2026
- added additional requirement to pyproject.toml
## Version 0.2.0 23-02-2026
- Added image counter
- Added go to image index feature
- added copy, move
# Changelog
## Version 0.1.0 - 19-02-2026
- Initial release
- Able to view photos.
- supports apple image extensions.
- Navigation supported.
- Image transform: Rotation possible.
- Rotations are considered inplace.
- Copy and Move functions available.
