from .main import app


def main() -> None:
    app()
