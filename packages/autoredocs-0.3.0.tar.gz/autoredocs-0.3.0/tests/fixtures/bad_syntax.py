# This file has a syntax error — used to test graceful handling
def broken_function(:
    pass
