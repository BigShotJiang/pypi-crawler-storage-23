from gt_telem.events.driver_events import DriverEvents
from gt_telem.events.game_events import GameEvents
from gt_telem.events.race_events import RaceEvents
from gt_telem.trackdetector import TRACK_NAMES
from gt_telem.turismo_client import TurismoClient

__version__ = "1.2.1"
