def get_hstrat_version() -> str:
    return "1.21.2"
