# HOW-TO TEST django-modshib

## Requirements

- python 3.9
- poetry

## init project

```shell
mkdir django-test
cd django-test
poetry init
poetry add django
poetry add django-modshib-certic
poetry run django-admin startproject project .
poetry run python manage.py migrate
poetry run python manage.py startapp pages
```

### project/settings.py

```python
TEMPLATES = [
    [...]
    "DIRS": [str(BASE_DIR.joinpath('templates'))],
    [...]
]

INSTALLED_APPS = [
    [...]
    "modshib.apps.ModshibConfig",
    "authcli.apps.AuthcliConfig",
]

# Pour une utilisation en subdir
BASE_URL = 'django/'
ALLOWED_HOSTS = ['127.0.0.1', 'your-sp.certic.unicaen.fr']
CSRF_TRUSTED_ORIGINS = ['http://127.0.0.1', 'https://your-sp.certic.unicaen.fr']

[...]

STATIC_URL = os.path.join(BASE_URL, "static/")

STATICFILES_DIRS = [
    BASE_DIR / "static",
]

[...]

MODSHIB_CREATE_ACCOUNT = True
MODSHIB_ACTIVATE_ACCOUNT = True
MODSHIB_FORMS_TITLE = "My test"
MODSHIB_STYLESHEET_URL = "/" + STATIC_URL + "css/modshib-auth.css"
LOGIN_REDIRECT_URL = "/" + BASE_URL
LOGOUT_REDIRECT_URL = "/" + BASE_URL
LOGIN_URL = "/" + BASE_URL + "accounts/login/"
```

Du côté Apache, on peut forcer la demande de SSO sur l'URL défini par modshib :

```xml
 <LocationMatch "/django/">
    ProxyPass http://127.0.0.1:8000/django/
    ProxyPassReverse http://127.0.0.1:8000/django/
    ProxyPreserveHost on
    ShibDisable Off
    ShibUseHeaders On
    # Needed if you want an alternative authentication
    ShibRequireSession Off
    # See https://wiki.shibboleth.net/confluence/display/SHIB2/isPassive
    ShibRequestSetting isPassive On
 </LocationMatch>

 <LocationMatch "/modshib/sso/">
    ShibDisable Off
    ShibUseHeaders On
    ShibRequireSession On
    ShibRequestSetting isPassive Off
 </LocationMatch>
```

### project/urls.py

```python
from django.contrib import admin
from django.urls import path, include
from . import settings

urlpatterns = [
    path(settings.BASE_URL + "admin/", admin.site.urls),
    path(settings.BASE_URL + "modshib/", include("modshib.urls")),
    path(settings.BASE_URL + "accounts/", include("django.contrib.auth.urls")),
    path(settings.BASE_URL + "", include("pages.urls")),
]
```

### pages/urls.py

```python
from django.urls import path

from .views import HomeView

urlpatterns = [
   path("", HomeView.as_view(), name="home"),
]
```

### templates/base.html

```shell
mkdir templates
touch templates/base.html
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Basic Django Project</title>
  </head>
  <body>
    {% block content %} {% endblock %}
  </body>
</html>
```

### templates/pages/home.html

```shell
mkdir templates/pages
touch templates/pages/home.html
```

```html
{% extends 'base.html' %} {% block content %}
<h1>Helllloooooo!</h1>
{% if user.is_authenticated %}
<h2>{{ user.username }} is connected</h2>
<a href="{% url 'logout' %}">Déconnexion</a>
{% else %}
<a href="{% url 'login' %}">Connexion</a>
{% endif %} {% endblock content %}
```

### static/css/modshib-auth.css

```shell
mkdir -p static/css
touch static/css/modshib-auth.css
```

```css
body#modshib-auth {
  background-color: cornflowerblue;
}
```

## Run run run!

```shell
poetry run python manage.py runserver
```
