"""Allow running with `python -m screaming_frog_mcp`."""

from screaming_frog_mcp import main

main()
