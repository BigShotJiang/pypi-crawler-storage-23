from . import render


render_to_response = render._to_response
render_to_bytes = render._to_bytes
render_to_file = render._to_file