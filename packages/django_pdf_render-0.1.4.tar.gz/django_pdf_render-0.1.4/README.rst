=================
Django PDF Render
=================

This package is archived and no longer maintained.

Please use **django-gotenberg** instead:

`https://pypi.org/project/django-gotenberg/ <https://pypi.org/project/django-gotenberg/>`_


