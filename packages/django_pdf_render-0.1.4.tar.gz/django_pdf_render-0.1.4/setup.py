"""Archived package. Use django-gotenberg instead."""

from setuptools import setup

setup()
