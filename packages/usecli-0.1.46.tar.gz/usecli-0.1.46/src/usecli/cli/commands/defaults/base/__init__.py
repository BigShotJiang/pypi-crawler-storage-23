"""Base script commands for usecli CLI."""

from __future__ import annotations
