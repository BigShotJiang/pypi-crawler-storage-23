#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Allow running as: python -m bitbake_project
"""

from .cli import main

if __name__ == "__main__":
    import sys
    sys.exit(main())
