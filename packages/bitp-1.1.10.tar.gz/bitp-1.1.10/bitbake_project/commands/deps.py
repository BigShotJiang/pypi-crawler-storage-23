#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Deps command - show layer and recipe dependencies."""

import glob
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from ..core import Colors, fzf_available, get_fzf_color_args, get_fzf_preview_resize_bindings
from ..fzf_bindings import (
    get_exit_bindings,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_preview_toggle_binding,
)
from .common import resolve_bblayers_path, extract_layer_paths, parse_layer_conf, LayerInfo, get_project_header_prefix
from .projects import get_preview_window_arg, get_preferred_graph_renderer, set_graph_renderer


# =============================================================================
# Layer Dependency Graph
# =============================================================================

def build_layer_dependency_graph(layer_paths: List[str]) -> Dict[str, LayerInfo]:
    """
    Build a dependency graph from all layer paths.

    Returns a dict mapping collection name -> LayerInfo for all parsed layers.
    """
    layers: Dict[str, LayerInfo] = {}

    for layer_path in layer_paths:
        info = parse_layer_conf(layer_path)
        if info:
            # Use collection name as key, but handle duplicates
            key = info.name
            if key in layers:
                # Prefer layer with higher priority, or first one found
                if info.priority <= layers[key].priority:
                    continue
            layers[key] = info

    return layers


def get_forward_deps(layers: Dict[str, LayerInfo], layer_name: str) -> Set[str]:
    """Get all dependencies of a layer (what it depends on)."""
    if layer_name not in layers:
        return set()
    info = layers[layer_name]
    return set(info.depends)


def get_reverse_deps(layers: Dict[str, LayerInfo], layer_name: str) -> Set[str]:
    """Get all layers that depend on this layer (reverse dependencies)."""
    reverse = set()
    for name, info in layers.items():
        if layer_name in info.depends:
            reverse.add(name)
    return reverse


def get_all_deps_recursive(
    layers: Dict[str, LayerInfo],
    layer_name: str,
    reverse: bool = False,
    visited: Optional[Set[str]] = None,
) -> Dict[str, Set[str]]:
    """
    Get full dependency tree recursively.

    Returns dict mapping each layer to its direct dependencies (or dependents if reverse).
    """
    if visited is None:
        visited = set()

    result: Dict[str, Set[str]] = {}

    if layer_name in visited:
        return result
    visited.add(layer_name)

    if reverse:
        deps = get_reverse_deps(layers, layer_name)
    else:
        deps = get_forward_deps(layers, layer_name)

    result[layer_name] = deps

    for dep in deps:
        sub_tree = get_all_deps_recursive(layers, dep, reverse, visited)
        result.update(sub_tree)

    return result


# =============================================================================
# Tree Rendering
# =============================================================================

def _render_tree_recursive(
    name: str,
    graph: Dict[str, Set[str]],
    visited: Set[str],
    prefix: str = "",
    is_last: bool = True,
    is_root: bool = False,
) -> List[str]:
    """Recursive tree rendering with box-drawing characters."""
    lines = []

    if is_root:
        lines.append(f"{Colors.bold(name)}")
    else:
        connector = "\u2514\u2500\u2500 " if is_last else "\u251c\u2500\u2500 "
        lines.append(f"{prefix}{connector}{name}")

    if name in visited:
        return lines
    visited.add(name)

    children = sorted(graph.get(name, []))
    if is_root:
        child_prefix = ""
    else:
        child_prefix = prefix + ("    " if is_last else "\u2502   ")

    for i, child in enumerate(children):
        is_last_child = (i == len(children) - 1)
        if child not in visited:
            lines.extend(_render_tree_recursive(
                child, graph, visited, child_prefix, is_last_child
            ))
        else:
            # Already visited - show with marker
            connector = "\u2514\u2500\u2500 " if is_last_child else "\u251c\u2500\u2500 "
            lines.append(f"{child_prefix}{connector}{child} {Colors.dim('(see above)')}")

    return lines


def render_tree_ascii(
    layers: Dict[str, LayerInfo],
    root: str,
    reverse: bool = False,
) -> str:
    """Render dependency tree as ASCII using box-drawing characters."""
    graph = get_all_deps_recursive(layers, root, reverse)
    visited: Set[str] = set()
    lines = _render_tree_recursive(root, graph, visited, is_root=True)
    return "\n".join(lines)


def render_tree_grapheasy(
    layers: Dict[str, LayerInfo],
    root: str,
    reverse: bool = False,
) -> Optional[str]:
    """Use graph-easy for better ASCII rendering if available."""
    if not shutil.which("graph-easy"):
        return None

    graph = get_all_deps_recursive(layers, root, reverse)

    # Build DOT format
    dot_lines = ["digraph deps {", '  rankdir=TB;', '  node [shape=box];']

    # Highlight root node
    dot_lines.append(f'  "{root}" [style=bold];')

    for node, deps in graph.items():
        for dep in deps:
            if reverse:
                # Reverse: dep depends on node, so arrow from dep to node
                dot_lines.append(f'  "{dep}" -> "{node}";')
            else:
                # Forward: node depends on dep, so arrow from node to dep
                dot_lines.append(f'  "{node}" -> "{dep}";')
    dot_lines.append("}")

    dot_content = "\n".join(dot_lines)

    try:
        result = subprocess.run(
            ["graph-easy", "--as_ascii"],
            input=dot_content,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    return None


def render_tree_preferred(
    layers: Dict[str, LayerInfo],
    root: str,
    reverse: bool = False,
) -> str:
    """Render tree using the configured graph renderer preference."""
    preference = get_preferred_graph_renderer()

    if preference == "graph-easy":
        ge_output = render_tree_grapheasy(layers, root, reverse)
        if ge_output:
            return ge_output
        # Fall back to ASCII if graph-easy fails
        return render_tree_ascii(layers, root, reverse)
    else:
        # ASCII or unknown preference
        return render_tree_ascii(layers, root, reverse)


def render_dot(
    layers: Dict[str, LayerInfo],
    root: Optional[str] = None,
    reverse: bool = False,
) -> str:
    """Output DOT format for external tools like graphviz."""
    dot_lines = [
        "digraph layer_deps {",
        '  rankdir=TB;',
        '  node [shape=box, fontname="sans-serif"];',
        '  edge [fontname="sans-serif"];',
    ]

    if root:
        graph = get_all_deps_recursive(layers, root, reverse)
        dot_lines.append(f'  "{root}" [style=bold, color=blue];')
    else:
        # Full graph of all layers
        graph = {name: set(info.depends) for name, info in layers.items()}

    for node, deps in graph.items():
        for dep in deps:
            if reverse:
                dot_lines.append(f'  "{dep}" -> "{node}";')
            else:
                dot_lines.append(f'  "{node}" -> "{dep}";')

    dot_lines.append("}")
    return "\n".join(dot_lines)


def render_list(
    layers: Dict[str, LayerInfo],
    root: Optional[str] = None,
    reverse: bool = False,
) -> str:
    """Simple list format output."""
    lines = []

    if root:
        graph = get_all_deps_recursive(layers, root, reverse)
        direction = "depends on" if not reverse else "is required by"
        lines.append(f"{root} {direction}:")
        deps = graph.get(root, set())
        for dep in sorted(deps):
            lines.append(f"  {dep}")
    else:
        # List all layers with their dependencies
        for name in sorted(layers.keys()):
            info = layers[name]
            if info.depends:
                lines.append(f"{name}: {', '.join(info.depends)}")
            else:
                lines.append(f"{name}: (no dependencies)")

    return "\n".join(lines)


# =============================================================================
# FZF Browser
# =============================================================================

def _build_layer_menu(layers: Dict[str, LayerInfo]) -> str:
    """Build fzf menu input for layer browser."""
    lines = []
    for name in sorted(layers.keys()):
        info = layers[name]
        dep_count = len(info.depends)
        rec_count = len(info.recommends)

        # Format: name<TAB>priority<TAB>deps<TAB>recommends
        deps_str = f"{dep_count} deps" if dep_count else "no deps"
        recs_str = f", {rec_count} recs" if rec_count else ""

        line = f"{name}\t{info.priority}\t{deps_str}{recs_str}"
        lines.append(line)

    return "\n".join(lines)


def _deps_fzf_browser(layers: Dict[str, LayerInfo]) -> int:
    """
    Interactive fzf browser for layer dependencies.

    Key bindings:
    - Enter: Show dependency tree
    - r: Show reverse dependencies (what depends on this)
    - d: Output DOT format
    - a: Show all layers full graph (DOT)
    - ?: Toggle preview
    - q/esc: Quit
    """
    if not layers:
        print("No layers found.")
        return 1

    if not fzf_available():
        # Fall back to text list
        for name in sorted(layers.keys()):
            info = layers[name]
            deps_str = ", ".join(info.depends) if info.depends else "(none)"
            print(f"  {Colors.green(name):<30}  priority={info.priority}  deps={deps_str}")
        return 0

    menu_input = _build_layer_menu(layers)

    # Create preview data file
    preview_data = {}
    for name, info in layers.items():
        preview_data[name] = {
            "name": info.name,
            "path": info.path,
            "depends": info.depends,
            "recommends": info.recommends,
            "priority": info.priority,
        }

    preview_data_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(preview_data, preview_data_file)
    preview_data_file.close()

    # Create layers graph for tree preview
    layers_graph = {}
    for name, info in layers.items():
        layers_graph[name] = {
            "depends": info.depends,
            "recommends": info.recommends,
        }
    graph_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(layers_graph, graph_file)
    graph_file.close()

    # Create preview script
    preview_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_script.write(f'''#!/usr/bin/env python3
import json
import sys

key = sys.argv[1] if len(sys.argv) > 1 else ""
key = key.strip("'\\"").split("\\t")[0]

with open("{preview_data_file.name}", "r") as f:
    data = json.load(f)

with open("{graph_file.name}", "r") as f:
    graph = json.load(f)

info = data.get(key, {{}})
if not info:
    print(f"No data for: {{key}}")
    sys.exit(0)

name = info.get("name", "")
path = info.get("path", "")
depends = info.get("depends", [])
recommends = info.get("recommends", [])
priority = info.get("priority", 0)

print(f"\\033[1m{{name}}\\033[0m")
print(f"Priority: {{priority}}")
print(f"Path: {{path}}")
print()

# Show dependency tree
def render_tree(node, g, visited, prefix="", is_last=True, is_root=False):
    lines = []
    if is_root:
        lines.append(f"\\033[36mDepends on:\\033[0m")
    connector = "\\u2514\\u2500\\u2500 " if is_last else "\\u251c\\u2500\\u2500 "
    if not is_root:
        lines.append(f"{{prefix}}{{connector}}{{node}}")
    if node in visited:
        return lines
    visited.add(node)
    children = sorted(g.get(node, {{}}).get("depends", []))
    child_prefix = prefix + ("    " if is_last else "\\u2502   ")
    for i, child in enumerate(children):
        is_last_child = (i == len(children) - 1)
        lines.extend(render_tree(child, g, visited, child_prefix if not is_root else "", is_last_child))
    return lines

if depends:
    visited = set()
    visited.add(key)
    for i, dep in enumerate(sorted(depends)):
        is_last = (i == len(depends) - 1)
        lines = render_tree(dep, graph, visited, "", is_last)
        for line in lines:
            print(f"  {{line}}")
else:
    print("\\033[36mDepends on:\\033[0m (none)")

print()

# Show what depends on this layer (reverse)
reverse_deps = []
for n, g in graph.items():
    if key in g.get("depends", []):
        reverse_deps.append(n)

if reverse_deps:
    print("\\033[36mRequired by:\\033[0m")
    for rd in sorted(reverse_deps):
        print(f"  {{rd}}")
else:
    print("\\033[36mRequired by:\\033[0m (none)")

if recommends:
    print()
    print("\\033[36mRecommends:\\033[0m")
    for rec in sorted(recommends):
        print(f"  {{rec}}")
''')
    preview_script.close()

    preview_cmd = f'python3 "{preview_script.name}" {{1}}'

    header = f"""{get_project_header_prefix()}Layer Dependencies Browser
Enter=tree | r=reverse deps | d=DOT output | a=all DOT | ?=preview | q=quit
{get_preview_header_suffix()}"""

    # Note: esc NOT in expect_keys - using --bind esc:abort allows ESC+key as alt-key (Mac)
    expect_keys = ["ctrl-r", "ctrl-d", "ctrl-a"]

    preview_window = get_preview_window_arg("50%")

    # Pad to fill terminal height so list top-aligns with preview top
    try:
        term_lines = os.get_terminal_size().lines
    except OSError:
        term_lines = 40
    header_line_count = header.count('\n') + 1
    chrome_lines = header_line_count + 2  # header + prompt + info line
    if preview_window.startswith("right"):
        available = term_lines - chrome_lines
    else:
        available = (term_lines // 2) - chrome_lines
    menu_line_count = menu_input.count('\n') + 1
    if menu_line_count < available:
        menu_input += "\n" + "\n".join("---\t" for _ in range(available - menu_line_count))

    fzf_args = [
        "fzf",
        "--no-multi",
        "--ansi",
        "--height", "100%",
        "--layout=reverse-list",
        "--header", header,
        "--prompt", "Layer: ",
        "--with-nth", "1",
        "--delimiter", "\t",
        "--preview", preview_cmd,
        "--preview-window", preview_window,
        "--expect", ",".join(expect_keys),
    ]

    # Add standard bindings from fzf_bindings module
    fzf_args.extend(get_preview_toggle_binding())
    fzf_args.extend(get_preview_scroll_bindings(include_half_page=False))
    fzf_args.extend(get_exit_bindings(mode="abort"))

    fzf_args.extend(get_fzf_preview_resize_bindings())
    fzf_args.extend(get_fzf_color_args())

    try:
        while True:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )

            if result.returncode != 0 or not result.stdout.strip():
                break

            lines = result.stdout.split("\n")
            key = lines[0].strip() if lines else ""
            selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

            if not selected:
                break

            if key == "ctrl-d":
                # DOT output for selected layer
                print(render_dot(layers, selected, reverse=False))
                input("\nPress Enter to continue...")
                continue

            if key == "ctrl-r":
                # Reverse dependency tree
                print(f"\n{Colors.bold(selected)} is required by:\n")
                print(render_tree_ascii(layers, selected, reverse=True))
                input("\nPress Enter to continue...")
                continue

            if key == "ctrl-a":
                # Full DOT graph
                print(render_dot(layers, root=None, reverse=False))
                input("\nPress Enter to continue...")
                continue

            # Default: show forward dependency tree
            print(f"\n{Colors.bold(selected)} depends on:\n")

            # Use configured graph renderer preference
            print(render_tree_preferred(layers, selected, reverse=False))

            input("\nPress Enter to continue...")

    finally:
        # Clean up temp files
        for f in [preview_data_file.name, preview_script.name, graph_file.name]:
            try:
                os.unlink(f)
            except OSError:
                pass

    return 0


# =============================================================================
# Text Output (no fzf)
# =============================================================================

def _list_layers_text(layers: Dict[str, LayerInfo], verbose: bool = False) -> int:
    """List layers in text format (no fzf)."""
    if not layers:
        print("No layers found.")
        return 1

    for name in sorted(layers.keys()):
        info = layers[name]
        deps_str = ", ".join(info.depends) if info.depends else "(none)"

        if verbose:
            print(f"{Colors.bold(name)}")
            print(f"  Path: {info.path}")
            print(f"  Priority: {info.priority}")
            print(f"  Depends: {deps_str}")
            if info.recommends:
                print(f"  Recommends: {', '.join(info.recommends)}")
            print()
        else:
            print(f"  {Colors.green(name):<30}  deps: {deps_str}")

    return 0


# =============================================================================
# Recipe Dependencies
# =============================================================================

@dataclass
class RecipeInfo:
    """Recipe metadata for dependency visualization."""
    name: str           # Recipe name (PN)
    version: str        # Recipe version (PV)
    path: str           # Path to .bb file
    layer: str          # Layer name
    depends: List[str]  # Build-time dependencies (DEPENDS)
    rdepends: List[str] # Runtime dependencies (RDEPENDS)


def _is_valid_package_name(name: str) -> bool:
    """Check if a string looks like a valid BitBake package name."""
    if not name:
        return False
    # Must start with a letter and contain only valid chars
    # Valid: letters, digits, hyphens, underscores, plus (for virtual/), periods
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9+._-]*$', name):
        return False
    # Skip things that look like Python/shell fragments
    if any(c in name for c in "(){}[]'\"@$=,"):
        return False
    # Skip single letters (likely variable fragments like 'd')
    if len(name) == 1:
        return False
    return True


def _clean_deps_string(deps_str: str) -> str:
    """Remove inline Python expressions and clean up a dependency string."""
    # Remove ${@...} inline Python expressions (can be nested)
    # Handle nested braces by iterating
    while '${@' in deps_str:
        start = deps_str.find('${@')
        if start == -1:
            break
        # Find matching closing brace
        depth = 0
        end = start
        for i, c in enumerate(deps_str[start:], start):
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    end = i
                    break
        if end > start:
            deps_str = deps_str[:start] + deps_str[end + 1:]
        else:
            # Malformed expression, just remove from ${@ onwards
            deps_str = deps_str[:start]
            break

    # Also remove simple ${...} variable references
    deps_str = re.sub(r'\$\{[^}]*\}', ' ', deps_str)

    return deps_str


def _parse_recipe_depends(filepath: str) -> Tuple[List[str], List[str]]:
    """
    Extract DEPENDS and RDEPENDS from a recipe file.

    Returns (depends, rdepends) as lists of package names.
    """
    depends = []
    rdepends = []

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return depends, rdepends

    # Handle line continuations
    content = content.replace("\\\n", " ")

    # Extract DEPENDS
    # Match DEPENDS = "...", DEPENDS += "...", DEPENDS:append = "..."
    depends_patterns = [
        r'^DEPENDS\s*[+:]?=\s*"([^"]*)"',
        r"^DEPENDS\s*[+:]?=\s*'([^']*)'",
    ]
    for pattern in depends_patterns:
        for match in re.finditer(pattern, content, re.MULTILINE):
            deps_str = _clean_deps_string(match.group(1))
            for dep in deps_str.split():
                if _is_valid_package_name(dep) and dep not in depends:
                    depends.append(dep)

    # Extract RDEPENDS (can be RDEPENDS:${PN} or just RDEPENDS)
    rdepends_patterns = [
        r'^RDEPENDS[:\w${}\-]*\s*[+:]?=\s*"([^"]*)"',
        r"^RDEPENDS[:\w${}\-]*\s*[+:]?=\s*'([^']*)'",
    ]
    for pattern in rdepends_patterns:
        for match in re.finditer(pattern, content, re.MULTILINE):
            deps_str = _clean_deps_string(match.group(1))
            for dep in deps_str.split():
                if _is_valid_package_name(dep) and dep not in rdepends:
                    rdepends.append(dep)

    return depends, rdepends


def _find_recipes(layer_paths: List[str], recipe_name: str) -> List[RecipeInfo]:
    """
    Find recipes matching the given name across all layers.

    Returns list of RecipeInfo for matching recipes.
    """
    recipes = []
    recipe_name_lower = recipe_name.lower()

    for layer_path in layer_paths:
        layer_name = os.path.basename(layer_path)

        # Glob for recipes matching the name
        patterns = [
            os.path.join(layer_path, "recipes-*", "*", f"{recipe_name}_*.bb"),
            os.path.join(layer_path, "recipes-*", "*", f"{recipe_name}.bb"),
            os.path.join(layer_path, "recipes-*", f"{recipe_name}_*.bb"),
            os.path.join(layer_path, "recipes-*", f"{recipe_name}.bb"),
        ]

        for pattern in patterns:
            for filepath in glob.glob(pattern):
                filename = os.path.basename(filepath)
                # Extract PN and PV from filename
                if "_" in filename:
                    parts = filename.rsplit("_", 1)
                    pn = parts[0]
                    pv = parts[1].replace(".bb", "")
                else:
                    pn = filename.replace(".bb", "")
                    pv = ""

                depends, rdepends = _parse_recipe_depends(filepath)

                recipes.append(RecipeInfo(
                    name=pn,
                    version=pv,
                    path=filepath,
                    layer=layer_name,
                    depends=depends,
                    rdepends=rdepends,
                ))

    # Also try partial match if no exact matches
    if not recipes:
        for layer_path in layer_paths:
            layer_name = os.path.basename(layer_path)
            pattern = os.path.join(layer_path, "recipes-*", "*", "*.bb")

            for filepath in glob.glob(pattern):
                filename = os.path.basename(filepath)
                pn = filename.split("_")[0] if "_" in filename else filename.replace(".bb", "")

                if recipe_name_lower in pn.lower():
                    if "_" in filename:
                        parts = filename.rsplit("_", 1)
                        pv = parts[1].replace(".bb", "")
                    else:
                        pv = ""

                    depends, rdepends = _parse_recipe_depends(filepath)

                    recipes.append(RecipeInfo(
                        name=pn,
                        version=pv,
                        path=filepath,
                        layer=layer_name,
                        depends=depends,
                        rdepends=rdepends,
                    ))

    return recipes


def _render_recipe_tree_ascii(
    recipe: RecipeInfo,
    include_rdepends: bool = False,
) -> str:
    """Render recipe dependency tree as ASCII."""
    lines = []
    lines.append(f"{Colors.bold(recipe.name)}")
    if recipe.version:
        lines.append(f"Version: {recipe.version}")
    lines.append(f"Layer: {recipe.layer}")
    lines.append(f"Path: {recipe.path}")
    lines.append("")

    if recipe.depends:
        lines.append(f"{Colors.cyan('Build dependencies (DEPENDS):')}")
        for i, dep in enumerate(sorted(recipe.depends)):
            is_last = (i == len(recipe.depends) - 1) and not (include_rdepends and recipe.rdepends)
            connector = "\u2514\u2500\u2500 " if is_last else "\u251c\u2500\u2500 "
            lines.append(f"  {connector}{dep}")
    else:
        lines.append(f"{Colors.cyan('Build dependencies (DEPENDS):')} (none)")

    if include_rdepends:
        lines.append("")
        if recipe.rdepends:
            lines.append(f"{Colors.cyan('Runtime dependencies (RDEPENDS):')}")
            for i, dep in enumerate(sorted(recipe.rdepends)):
                is_last = (i == len(recipe.rdepends) - 1)
                connector = "\u2514\u2500\u2500 " if is_last else "\u251c\u2500\u2500 "
                lines.append(f"  {connector}{dep}")
        else:
            lines.append(f"{Colors.cyan('Runtime dependencies (RDEPENDS):')} (none)")

    return "\n".join(lines)


def _render_recipe_dot(
    recipe: RecipeInfo,
    include_rdepends: bool = False,
) -> str:
    """Render recipe dependencies as DOT graph."""
    dot_lines = [
        "digraph recipe_deps {",
        '  rankdir=TB;',
        '  node [shape=box, fontname="sans-serif"];',
        f'  "{recipe.name}" [style=bold, color=blue];',
    ]

    for dep in recipe.depends:
        dot_lines.append(f'  "{recipe.name}" -> "{dep}";')

    if include_rdepends:
        for dep in recipe.rdepends:
            dot_lines.append(f'  "{recipe.name}" -> "{dep}" [style=dashed, color=gray];')

    dot_lines.append("}")
    return "\n".join(dot_lines)


# =============================================================================
# Main Entry Point
# =============================================================================

def run_deps(args) -> int:
    """Main entry point for deps command."""
    deps_command = getattr(args, "deps_command", None)
    layer_name = getattr(args, "layer", None)
    reverse = getattr(args, "reverse", False)
    output_format = getattr(args, "format", "tree")
    list_mode = getattr(args, "list", False)

    # Get layer paths from bblayers.conf
    bblayers_path = resolve_bblayers_path(getattr(args, "bblayers", None))
    if not bblayers_path:
        print("Could not find bblayers.conf")
        return 1

    layer_paths = extract_layer_paths(bblayers_path)
    if not layer_paths:
        print("No layers found in bblayers.conf")
        return 1

    # Build dependency graph
    layers = build_layer_dependency_graph(layer_paths)
    if not layers:
        print("No layer.conf files found")
        return 1

    # Handle subcommands
    if deps_command == "layers" or deps_command is None:
        # Layer dependencies

        if layer_name:
            # Specific layer requested
            if layer_name not in layers:
                # Try partial match
                matches = [n for n in layers if layer_name in n]
                if len(matches) == 1:
                    layer_name = matches[0]
                elif matches:
                    print(f"Ambiguous layer name '{layer_name}'. Matches: {', '.join(matches)}")
                    return 1
                else:
                    print(f"Layer '{layer_name}' not found. Available: {', '.join(sorted(layers.keys()))}")
                    return 1

            if output_format == "dot":
                print(render_dot(layers, layer_name, reverse))
            elif output_format == "list":
                print(render_list(layers, layer_name, reverse))
            else:
                # Tree format - use configured preference
                direction = "is required by" if reverse else "depends on"
                print(f"{Colors.bold(layer_name)} {direction}:\n")
                print(render_tree_preferred(layers, layer_name, reverse))
            return 0

        # No specific layer - interactive or list mode
        if list_mode or not fzf_available():
            return _list_layers_text(layers, verbose=getattr(args, "verbose", False))

        return _deps_fzf_browser(layers)

    if deps_command == "recipe":
        recipe_name = getattr(args, "recipe", None)
        if not recipe_name:
            print("Recipe name required")
            return 1

        include_rdepends = getattr(args, "rdepends", False)

        # Find recipes matching the name
        recipes = _find_recipes(layer_paths, recipe_name)

        if not recipes:
            print(f"No recipe found matching '{recipe_name}'")
            return 1

        # If multiple matches, let user pick or show all
        if len(recipes) > 1:
            print(f"Found {len(recipes)} recipes matching '{recipe_name}':")
            for i, r in enumerate(recipes, 1):
                ver_str = f" ({r.version})" if r.version else ""
                print(f"  {i}. {r.name}{ver_str} - {r.layer}")
            print()

            # Use first one for now, or could add interactive selection
            recipe = recipes[0]
            print(f"Showing dependencies for: {recipe.name} from {recipe.layer}\n")
        else:
            recipe = recipes[0]

        if output_format == "dot":
            print(_render_recipe_dot(recipe, include_rdepends))
        elif output_format == "list":
            # Simple list format
            print(f"{recipe.name}:")
            print(f"  DEPENDS: {', '.join(recipe.depends) if recipe.depends else '(none)'}")
            if include_rdepends:
                print(f"  RDEPENDS: {', '.join(recipe.rdepends) if recipe.rdepends else '(none)'}")
        else:
            # Tree format
            print(_render_recipe_tree_ascii(recipe, include_rdepends))

        return 0

    return 0
