#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Layers command - search and browse OpenEmbedded Layer Index."""

import json
import os
import shutil
import subprocess
import sys
import urllib.request
from typing import List, Optional

from ..core import Colors, terminal_color
from ..fzf_bindings import get_exit_bindings, get_preview_header_suffix
from ..tui import ExploreMenuState, confirm_action_dialog, text_input_dialog
from .common import (
    add_layer_to_bblayers,
    build_layer_collection_map,
    discover_layers,
    extract_layer_paths,
    repo_origin_url,
)
from .projects import get_fzf_preview_args
from .setup import _fetch_layer_index, _fetch_layer_dependencies, _fetch_layer_deps_bulk

def _normalize_vcs_url(url: str) -> str:
    """Normalize a VCS URL for comparison."""
    url = url.strip().rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    # git@github.com:org/repo -> github.com/org/repo
    if ":" in url and "://" not in url:
        host, path = url.split(":", 1)
        host = host.split("@")[-1] if "@" in host else host
        url = f"{host}/{path}"
    # https://github.com/org/repo -> github.com/org/repo
    if "://" in url:
        url = url.split("://", 1)[1]
    return url.lower()


def _build_local_layer_status(layers: List[dict]) -> dict:
    """Build a map of layer status: {layer_name: ("configured"|"cloned"|None, local_layer_path|None)}.

    - "configured": layer is in bblayers.conf
    - "cloned": layer's repo is cloned locally but layer not in bblayers.conf
    - None: not found locally
    """
    status = {}

    # 1. Find bblayers.conf
    bblayers_conf = None
    for cand in ["conf/bblayers.conf", "build/conf/bblayers.conf"]:
        if os.path.isfile(cand):
            bblayers_conf = cand
            break
    if not bblayers_conf:
        return {l["name"]: (None, None) for l in layers}

    # 2. Get configured layer paths from bblayers.conf
    configured_paths = set()
    try:
        configured_paths = set(extract_layer_paths(bblayers_conf))
    except SystemExit:
        pass

    # 3. Discover all local layers (including those in bblayers.conf)
    all_local = discover_layers(peer_dirs=set())  # returns [(layer_path, repo_path)]

    # 4. Build URL -> [(layer_path, repo_path)] map from local repos
    url_to_local = {}  # normalized_url -> [(layer_path, repo_path)]
    seen_repos = set()
    for layer_path, repo_path in all_local:
        if repo_path not in seen_repos:
            seen_repos.add(repo_path)
        url = repo_origin_url(repo_path)
        if url:
            norm = _normalize_vcs_url(url)
            if (layer_path, repo_path) not in url_to_local.get(norm, []):
                url_to_local.setdefault(norm, []).append((layer_path, repo_path))

    # 5. Match each OE index layer to local status
    configured_abs = {os.path.abspath(p) for p in configured_paths}
    for layer in layers:
        vcs_url = layer.get("vcs_url", "")
        vcs_subdir = layer.get("vcs_subdir", "")
        name = layer["name"]

        if not vcs_url:
            status[name] = (None, None)
            continue

        norm_url = _normalize_vcs_url(vcs_url)
        local_matches = url_to_local.get(norm_url, [])

        if not local_matches:
            status[name] = (None, None)
            continue

        # Repo is cloned locally. Find the specific layer path.
        matched_layer_path = None
        for lp, rp in local_matches:
            if vcs_subdir:
                if lp == os.path.join(rp, vcs_subdir) or lp.endswith("/" + vcs_subdir):
                    matched_layer_path = lp
                    break
            else:
                if lp == rp:  # layer is at repo root
                    matched_layer_path = lp
                    break

        if not matched_layer_path:
            # Repo exists but specific layer subdir not matched — still "cloned"
            matched_layer_path = local_matches[0][1]  # use repo path

        # Check if this specific layer path is in bblayers.conf
        if os.path.abspath(matched_layer_path) in configured_abs:
            status[name] = ("configured", matched_layer_path)
        else:
            status[name] = ("cloned", matched_layer_path)

    return status


def run_search(args) -> int:
    """Search OpenEmbedded Layer Index for layers."""
    branch = args.branch
    query = args.query
    force = getattr(args, "force", False)

    # Fetch layers (from cache or API)
    data = _fetch_layer_index(force=force)
    if data is None:
        return 1

    # Filter by branch and deduplicate
    seen = set()
    layers = []
    for entry in data:
        entry_branch = entry.get("branch", {}).get("name", "")
        if entry_branch != branch:
            continue
        layer_info = entry.get("layer", {})
        name = layer_info.get("name", "")
        if name in seen:
            continue
        seen.add(name)
        layers.append({
            "name": name,
            "summary": layer_info.get("summary", ""),
            "description": layer_info.get("description", ""),
            "vcs_url": layer_info.get("vcs_url", ""),
            "vcs_subdir": entry.get("vcs_subdir", ""),
        })

    # Filter by query if provided
    if query:
        query_lower = query.lower()
        layers = [
            l for l in layers
            if query_lower in l["name"].lower()
            or query_lower in l["summary"].lower()
            or query_lower in l["description"].lower()
        ]

    if not layers:
        if query:
            print(f"No layers found matching '{query}' on branch '{branch}'")
        else:
            print(f"No layers found on branch '{branch}'")
        return 1

    # Handle --clone flag
    do_clone = getattr(args, "clone", False)
    clone_target = getattr(args, "target", None)
    if do_clone:
        # Try exact match first
        exact = next((l for l in layers if l["name"].lower() == query.lower()), None) if query else None
        if exact:
            layer = exact
        elif len(layers) == 1:
            layer = layers[0]
        else:
            print(f"Multiple layers match '{query}' - be more specific or use exact name:")
            for l in sorted(layers, key=lambda x: x["name"])[:10]:
                print(f"  {l['name']}")
            if len(layers) > 10:
                print(f"  ... and {len(layers) - 10} more")
            return 1

        if not layer["vcs_url"]:
            print(f"No VCS URL for {layer['name']}")
            return 1

        # Check if already present locally
        cli_layer_status = _build_local_layer_status([layer])
        st, local_path = cli_layer_status.get(layer["name"], (None, None))
        if st == "configured":
            print(f"{layer['name']} is already in bblayers.conf")
            return 0
        if st == "cloned" and local_path:
            if getattr(args, "add", False):
                _try_add_layer_to_project(local_path, "", indent="")
                return 0
            else:
                print(f"{layer['name']} is already cloned at {local_path}")
                print(f"Use --add to add it to bblayers.conf")
                return 0

        # Show dependencies
        deps = _fetch_layer_dependencies(layer["name"], branch)
        if deps:
            required = [d["name"] for d in deps if d["required"]]
            optional = [d["name"] for d in deps if not d["required"]]
            if required:
                print(f"{Colors.yellow('Dependencies')}: {', '.join(required)}")
            if optional:
                print(f"{Colors.dim('Optional')}: {', '.join(optional)}")

        # Determine target directory
        target = clone_target or f"layers/{layer['name']}"
        if os.path.exists(target):
            print(f"Target already exists: {target}")
            return 1

        print(f"Cloning {layer['name']} ({layer['vcs_url']}) -> {target}")
        try:
            subprocess.run(
                ["git", "clone", "-b", branch, layer["vcs_url"], target],
                check=True,
            )
            print(f"{Colors.green('Done.')}")
            if layer["vcs_subdir"]:
                print(f"Layer path: {target}/{layer['vcs_subdir']}")
            if getattr(args, "add", False):
                _try_add_layer_to_project(target, layer.get("vcs_subdir", ""))
            return 0
        except subprocess.CalledProcessError as e:
            print(f"{Colors.red('Clone failed')}: {e}")
            return 1

    # Handle --info flag (scriptable output)
    do_info = getattr(args, "info", False)
    if do_info:
        if not query:
            print("Error: --info requires a layer name", file=sys.stderr)
            return 1
        # Try exact match first
        exact = next((l for l in layers if l["name"].lower() == query.lower()), None)
        if exact:
            layer = exact
        elif len(layers) == 1:
            layer = layers[0]
        else:
            print(f"Error: Multiple layers match '{query}' - be more specific:", file=sys.stderr)
            for l in sorted(layers, key=lambda x: x["name"])[:10]:
                print(f"  {l['name']}", file=sys.stderr)
            return 1

        # Output machine-readable info
        print(f"name={layer['name']}")
        print(f"url={layer['vcs_url']}")
        if layer["vcs_subdir"]:
            print(f"subdir={layer['vcs_subdir']}")
        deps = _fetch_layer_dependencies(layer["name"], branch)
        if deps:
            required = [d["name"] for d in deps if d["required"]]
            optional = [d["name"] for d in deps if not d["required"]]
            if required:
                print(f"depends={','.join(required)}")
            if optional:
                print(f"optional={','.join(optional)}")
        return 0

    # Calculate max name length for alignment
    max_name_len = max(len(l["name"]) for l in layers)
    max_name_len = min(max_name_len, 35)  # Cap at 35 chars

    # Interactive selection with fzf if available
    if shutil.which("fzf") and not query:
        layer_status = _build_local_layer_status(layers)
        layer_deps = _fetch_layer_deps_bulk(branch, data)

        # Calculate summary width from terminal size
        # fzf preview takes ~50%, so list area is roughly half the terminal
        try:
            term_cols = os.get_terminal_size().columns
        except OSError:
            term_cols = 120
        list_cols = term_cols // 2
        # name + 2 spaces of padding; leave some margin
        max_summary_len = max(list_cols - max_name_len - 4, 20)

        # Build menu for fzf with alignment
        # Format: name\tdisplay\tsummary\tdescription\tvcs_url\tvcs_subdir\tdeps
        def _format_deps(layer_name):
            deps = layer_deps.get(layer_name, [])
            if not deps:
                return ""
            required = [d["name"] for d in deps if d["required"]]
            optional = [d["name"] for d in deps if not d["required"]]
            parts = []
            if required:
                parts.append(f"Requires: {', '.join(required)}")
            if optional:
                parts.append(f"Optional: {', '.join(optional)}")
            return " | ".join(parts)

        def _build_menu_lines():
            lines = []
            for l in sorted(layers, key=lambda x: x["name"]):
                name = l["name"][:35]
                summary = l["summary"][:max_summary_len] if l["summary"] else ""
                display = f"{name:<{max_name_len}}  {summary}"
                # Color based on local status
                st, _ = layer_status.get(l["name"], (None, None))
                if st == "configured":
                    display = terminal_color("repo", display)
                elif st == "cloned":
                    display = terminal_color("repo_discovered", display)
                # Escape special chars in description for shell
                desc = l["description"].replace("'", "'\\''").replace("\n", " ") if l["description"] else ""
                vcs_url = l["vcs_url"] or ""
                vcs_subdir = l["vcs_subdir"] or ""
                deps_str = _format_deps(l["name"])
                lines.append(f"{l['name']}\t{display}\t{desc}\t{vcs_url}\t{vcs_subdir}\t{deps_str}")
            return lines

        base_menu_lines = _build_menu_lines()

        # Preview command to format layer details
        preview_cmd = r'''
            echo -e "\033[1m{1}\033[0m"
            echo
            echo "{3}" | fold -s -w 70
            echo
            if [ -n "{4}" ]; then
                echo -e "\033[36mClone:\033[0m git clone {4}"
            fi
            if [ -n "{5}" ]; then
                echo -e "\033[36mLayer:\033[0m {5}"
            fi
            if [ -n "{6}" ]; then
                echo
                echo -e "\033[33m{6}\033[0m"
            fi
        '''

        dialog_state = ExploreMenuState()
        pending_clone_info: Optional[tuple] = None  # (layer_name, vcs_url, default_target)
        pending_add_info: Optional[tuple] = None  # (target, vcs_subdir)

        while True:
            has_dialog = dialog_state.has_dialog()

            # Build menu with dialog items prepended if active
            if has_dialog:
                dialog_items = dialog_state.get_dialog_menu_lines()
                # Format dialog items with tab delimiter to match menu format
                dialog_lines = [f"{item[0]}\t{item[1]}\t\t\t\t" for item in dialog_items]
                menu_lines = dialog_lines + base_menu_lines
                if pending_add_info:
                    header = "Add layer to bblayers.conf?\nEnter=confirm | Esc=cancel"
                else:
                    layer_name, _, default_target = pending_clone_info
                    header = f"Clone {layer_name} to: (default: {default_target})\nType path in query, Enter=confirm | Esc=cancel"
            else:
                menu_lines = base_menu_lines
                header = f"OpenEmbedded Layers ({branch}) | Enter/Ctrl-y=clone | Alt-c=copy | Esc=quit\n{get_preview_header_suffix()}"

            # Build fzf command
            fzf_cmd = [
                "fzf",
                "--ansi",
                "--height", "100%",
                "--header", header,
                "--prompt", "> " if pending_add_info else "Target: " if has_dialog else "Search: ",
                "--with-nth", "2",
                "--delimiter", "\t",
            ]
            fzf_cmd.extend(get_fzf_preview_args(preview_cmd, size="50%"))

            if has_dialog:
                fzf_cmd.extend(["--print-query"])
                fzf_cmd.extend(get_exit_bindings(mode="abort"))
            else:
                fzf_cmd.extend([
                    "--bind", r"enter:become(printf 'CLONE\t%s\t%s\n' {1} {4})",
                    "--bind", r"ctrl-y:become(printf 'CLONE\t%s\t%s\n' {1} {4})",
                    "--bind", "alt-c:execute-silent(printf 'git clone %s' {4} | xclip -selection clipboard 2>/dev/null || printf 'git clone %s' {4} | xsel --clipboard --input 2>/dev/null)",
                ])

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                break

            # Handle interrupt (Esc)
            if result.returncode != 0:
                if has_dialog:
                    dialog_state.clear_dialog()
                    pending_clone_info = None
                    pending_add_info = None
                    continue
                break

            # Parse output based on dialog state
            if has_dialog:
                output_lines = result.stdout.split("\n") if result.stdout else []
                query_input = output_lines[0].strip() if output_lines else ""
                selected_line = output_lines[1].strip() if len(output_lines) > 1 else ""

                # Check if dialog item was selected
                if dialog_state._renderer.is_dialog_item(selected_line.split("\t")[0]):
                    dlg_result = dialog_state.handle_dialog_selection(selected_line.split("\t")[0], query_input)
                    if dlg_result.confirmed and pending_add_info:
                        # User confirmed adding layer to bblayers.conf
                        add_target, add_subdir = pending_add_info
                        _try_add_layer_to_project(add_target, add_subdir, indent="  ")
                        # Refresh status so menu colors update
                        layer_status = _build_local_layer_status(layers)
                        base_menu_lines = _build_menu_lines()
                    elif dlg_result.confirmed and pending_clone_info:
                        layer_name, vcs_url, default_target = pending_clone_info
                        target = dlg_result.value.strip() if dlg_result.value else ""
                        if not target:
                            target = default_target

                        if os.path.exists(target):
                            print(f"  {Colors.yellow('exists')}: {target}")
                        else:
                            print(f"  Cloning {vcs_url} -> {target}...")
                            try:
                                subprocess.run(
                                    ["git", "clone", "-b", branch, vcs_url, target],
                                    check=True,
                                )
                                print(f"  {Colors.green('done')}")
                                # Refresh status after clone
                                layer_status = _build_local_layer_status(layers)
                                base_menu_lines = _build_menu_lines()
                                # Offer to add to bblayers.conf
                                bblayers_found = any(
                                    os.path.isfile(c) for c in ["conf/bblayers.conf", "build/conf/bblayers.conf"]
                                )
                                if bblayers_found:
                                    layer_info = next((l for l in layers if l["name"] == layer_name), None)
                                    vcs_subdir = layer_info.get("vcs_subdir", "") if layer_info else ""
                                    pending_add_info = (target, vcs_subdir)
                                    pending_clone_info = None
                                    dialog_state.clear_dialog()
                                    dialog_state.show_dialog(confirm_action_dialog(
                                        f"Add {layer_name} to bblayers.conf?",
                                    ))
                                    continue
                            except subprocess.CalledProcessError as e:
                                print(f"  {Colors.red('failed')}: {e}")
                    dialog_state.clear_dialog()
                    pending_clone_info = None
                    pending_add_info = None
                    continue
                dialog_state.clear_dialog()
                pending_clone_info = None
                pending_add_info = None
                continue

            if not result.stdout.strip():
                break

            output = result.stdout.strip()

            if output.startswith("CLONE\t"):
                # Clone the layer repo - output is "CLONE\t<name>\t<url>"
                parts = output.split("\t")
                layer_name = parts[1] if len(parts) > 1 else ""
                vcs_url = parts[2] if len(parts) > 2 else ""
                if not vcs_url:
                    print(f"\n  No VCS URL for {layer_name}")
                    continue

                # Check if already cloned locally
                st, local_path = layer_status.get(layer_name, (None, None))
                if st == "configured":
                    print(f"\n  {layer_name} is already in bblayers.conf")
                    continue
                if st == "cloned" and local_path:
                    # Repo exists but layer not in bblayers.conf — offer to add
                    bblayers_found = any(
                        os.path.isfile(c) for c in ["conf/bblayers.conf", "build/conf/bblayers.conf"]
                    )
                    if bblayers_found:
                        print(f"\n  {layer_name} is already cloned at {local_path}")
                        layer_info = next((l for l in layers if l["name"] == layer_name), None)
                        vcs_subdir = layer_info.get("vcs_subdir", "") if layer_info else ""
                        pending_add_info = (local_path, vcs_subdir)
                        dialog_state.show_dialog(confirm_action_dialog(
                            f"Add {layer_name} to bblayers.conf?",
                        ))
                        continue

                # Show dependencies
                print()
                deps = _fetch_layer_dependencies(layer_name, branch)
                if deps:
                    required = [d["name"] for d in deps if d["required"]]
                    optional = [d["name"] for d in deps if not d["required"]]
                    if required:
                        print(f"  {Colors.yellow('Dependencies')}: {', '.join(required)}")
                    if optional:
                        print(f"  {Colors.dim('Optional')}: {', '.join(optional)}")

                # Show inline dialog for target directory
                default_target = f"layers/{layer_name}"
                pending_clone_info = (layer_name, vcs_url, default_target)
                dialog_state.show_dialog(text_input_dialog(f"Clone to [{default_target}]:"))
                continue

            # Enter now triggers CLONE via fzf binding, so this is unreachable
            pass

        return 0

    # Text output with alignment
    try:
        term_cols = os.get_terminal_size().columns
    except OSError:
        term_cols = 120
    # name + leading indent (2) + gap (2); leave some margin
    text_summary_len = max(term_cols - max_name_len - 6, 20)
    print(f"\n{Colors.bold(f'Layers on {branch} branch')} ({len(layers)} results)\n")
    for l in sorted(layers, key=lambda x: x["name"]):
        name = l["name"][:35]
        summary = l["summary"][:text_summary_len] if l["summary"] else ""
        print(f"  {Colors.green(f'{name:<{max_name_len}}')}  {summary}")
        if l["vcs_url"]:
            subdir = f" (subdir: {l['vcs_subdir']})" if l["vcs_subdir"] else ""
            print(f"  {' ' * max_name_len}  {Colors.dim(l['vcs_url'])}{Colors.dim(subdir)}")

    return 0



def _try_add_layer_to_project(target: str, vcs_subdir: str = "", indent: str = "") -> None:
    """After cloning, try to add the layer to bblayers.conf."""
    # Find bblayers.conf (non-exiting check)
    bblayers_conf = None
    for cand in ["conf/bblayers.conf", "build/conf/bblayers.conf"]:
        if os.path.isfile(cand):
            bblayers_conf = cand
            break
    if not bblayers_conf:
        return

    # Determine layer path
    layer_path = os.path.join(target, vcs_subdir) if vcs_subdir else target
    layer_path = os.path.abspath(layer_path)

    # Verify it's actually a layer
    if not os.path.isfile(os.path.join(layer_path, "conf", "layer.conf")):
        # Scan target for layers (repo may contain multiple)
        found = []
        for root, dirs, _files in os.walk(os.path.abspath(target)):
            if os.path.isfile(os.path.join(root, "conf", "layer.conf")):
                found.append(root)
            if root[len(os.path.abspath(target)):].count(os.sep) >= 2:
                dirs[:] = []
        if not found:
            return
        layer_path = found[0]

    # Build collection map from discovered layers
    peer_dirs = {os.path.dirname(os.path.abspath(target))}
    all_discovered = discover_layers(peer_dirs=peer_dirs)
    all_layer_paths = [lp for lp, _ in all_discovered]
    if layer_path not in all_layer_paths:
        all_layer_paths.append(layer_path)
    collection_map = build_layer_collection_map(all_layer_paths)

    layer_name = os.path.basename(layer_path)
    print(f"{indent}Adding {layer_name} to bblayers.conf...")
    success, message, added = add_layer_to_bblayers(
        layer_path, bblayers_conf, collection_map
    )
    print(f"{indent}{message}")


