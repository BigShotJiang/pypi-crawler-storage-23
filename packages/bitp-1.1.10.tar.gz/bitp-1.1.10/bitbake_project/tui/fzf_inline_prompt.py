#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Experimental: In-line prompts within fzf menus.

Instead of exiting fzf to show a prompt, we:
1. Dynamically add prompt items to the menu via reload
2. Change the prompt text via transform-prompt
3. Use the query as input
4. Handle confirmation via special selection

This keeps the menu visible while getting user input.

Example usage:
    # In your fzf menu loop:
    if key == "ctrl-b":  # User wants to enter branch name
        # Switch to prompt mode
        prompt_items = create_prompt_section("Enter branch name:")
        # Reload menu with prompt items at top
        # Change prompt to show we're in input mode
        # When user presses Enter, capture query as branch name
"""

import os
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

from ..core import Colors


@dataclass
class InlinePromptState:
    """State for managing inline prompts within fzf."""
    active: bool = False
    prompt_message: str = ""
    original_prompt: str = ""
    on_confirm: Optional[Callable[[str], None]] = None
    on_cancel: Optional[Callable[[], None]] = None


def create_prompt_menu_items(
    message: str,
    help_text: str = "Type value, Enter=confirm, Esc=cancel",
) -> List[Tuple[str, str]]:
    """Create menu items for an inline prompt section.

    Returns list of (value, display) tuples to prepend to menu.
    These use special prefixes so they can be identified.
    """
    return [
        ("__PROMPT_MSG__", Colors.cyan(f"┌─ {message} ─")),
        ("__PROMPT_HELP__", Colors.dim(f"│  {help_text}")),
        ("__PROMPT_CONFIRM__", Colors.green("│  [ ✓ Confirm ]")),
        ("__PROMPT_CANCEL__", Colors.yellow("│  [ ✗ Cancel ]")),
        ("__PROMPT_SEP__", Colors.cyan("└" + "─" * 40)),
    ]


def is_prompt_selection(value: str) -> bool:
    """Check if a selection is from the prompt section."""
    return value.startswith("__PROMPT_")


def handle_prompt_selection(
    value: str,
    query: str,
) -> Tuple[bool, Optional[str]]:
    """Handle a selection from the prompt section.

    Returns:
        (confirmed, value) - confirmed is True if user confirmed,
        value is the query text if confirmed, None if cancelled
    """
    if value == "__PROMPT_CONFIRM__":
        return True, query
    elif value == "__PROMPT_CANCEL__":
        return False, None
    else:
        # Header/help/separator - ignore
        return False, None


# --- fzf binding helpers ---

def get_prompt_mode_bindings(
    trigger_key: str,
    prompt_message: str,
    state_file: str,
) -> List[str]:
    """Get fzf bindings to enable prompt mode.

    When trigger_key is pressed:
    1. Write state to state_file
    2. Reload menu with prompt items
    3. Change prompt

    Args:
        trigger_key: Key that triggers prompt mode (e.g., "ctrl-b")
        prompt_message: Message to show in prompt
        state_file: Temp file for state communication

    Returns:
        List of fzf --bind arguments
    """
    # Script to run when trigger is pressed
    enter_prompt_script = (
        f"echo 'PROMPT:{prompt_message}' > {state_file}; "
    )

    return [
        "--bind", f"{trigger_key}:execute-silent({enter_prompt_script})+abort",
    ]


# --- Example integration pattern ---

def example_menu_with_inline_prompt():
    """
    Example showing how to integrate inline prompts with an existing menu.

    This demonstrates the pattern - actual implementation would be in
    the specific command files.
    """
    # State file for communication
    state_file = tempfile.mktemp(prefix="fzf-prompt-")

    # Normal menu items
    normal_items = [
        ("repo1", "  Repository One      [clean]"),
        ("repo2", "  Repository Two      [dirty]"),
        ("repo3", "  Repository Three    [clean]"),
    ]

    prompt_active = False
    prompt_message = ""

    while True:
        # Build menu
        if prompt_active:
            # Prepend prompt items
            prompt_items = create_prompt_menu_items(prompt_message)
            menu_items = prompt_items + normal_items
            current_prompt = f"{prompt_message}: "
        else:
            menu_items = normal_items
            current_prompt = "Select: "

        # Build fzf input
        menu_input = "\n".join(f"{v}\t{d}" for v, d in menu_items)

        # Build fzf command
        fzf_args = [
            "fzf",
            "--ansi",
            "--height", "~50%",
            "--prompt", current_prompt,
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--print-query",  # Capture query for prompt mode
        ]

        if not prompt_active:
            # Normal mode - add trigger binding
            fzf_args.extend([
                "--header", "b=branch all | q=quit",
                "--expect", "b,q",
            ])

        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )

        if result.returncode != 0:
            if prompt_active:
                # Cancelled in prompt mode - return to normal
                prompt_active = False
                continue
            else:
                break

        lines = result.stdout.split("\n")

        if prompt_active:
            # In prompt mode - query is on first line (due to --print-query)
            query = lines[0] if lines else ""
            selected = lines[1].split("\t")[0] if len(lines) > 1 else ""

            if is_prompt_selection(selected):
                confirmed, value = handle_prompt_selection(selected, query)
                if confirmed:
                    print(f"User entered: {value}")
                    # Do something with the value
                prompt_active = False
            else:
                # User selected a normal item while in prompt mode
                # Could either confirm with that item, or ignore
                prompt_active = False

        else:
            # Normal mode - check for key press
            # With --print-query, format is: query\nkey\nselection
            query = lines[0] if lines else ""
            key = lines[1] if len(lines) > 1 else ""
            selected = lines[2].split("\t")[0] if len(lines) > 2 else ""

            if key == "b":
                # Enter prompt mode for branch name
                prompt_active = True
                prompt_message = "Enter branch name"
                continue

            if key == "q":
                break

            if selected:
                print(f"Selected: {selected}")

    # Cleanup
    if os.path.exists(state_file):
        os.unlink(state_file)


if __name__ == "__main__":
    example_menu_with_inline_prompt()
