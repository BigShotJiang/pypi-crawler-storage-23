#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
BitBake project helper.

A command-line tool for managing BitBake/Yocto projects.
"""

__version__ = "1.0.0"
__author__ = "Bruce Ashfield <bruce.ashfield@gmail.com>"

from .core import (
    Colors,
    GitRepo,
    FzfMenu,
    fzf_available,
    fzf_expandable_menu,
    parse_help_options,
    FZF_THEMES,
    FZF_TEXT_COLORS,
    FZF_COLOR_ELEMENTS,
    COLOR_VALUES,
    COLOR_MODES,
    get_fzf_theme,
    get_fzf_text_color,
    get_fzf_color_args,
    get_custom_colors,
    set_custom_color,
    clear_custom_colors,
    run_fzf,
    set_fzf_theme,
    set_fzf_text_color,
    get_current_theme_name,
    get_current_text_color_name,
    get_color_mode,
    set_color_mode,
    fzf_theme_picker,
    fzf_text_color_picker,
    fzf_custom_color_menu,
    git_toplevel,
    current_branch,
    current_head,
    repo_is_clean,
    load_defaults,
    save_defaults,
    load_prep_state,
    save_prep_state,
    load_export_state,
    save_export_state,
)

__all__ = [
    "Colors",
    "GitRepo",
    "FzfMenu",
    "fzf_available",
    "fzf_expandable_menu",
    "parse_help_options",
    "FZF_THEMES",
    "FZF_TEXT_COLORS",
    "FZF_COLOR_ELEMENTS",
    "COLOR_VALUES",
    "COLOR_MODES",
    "get_fzf_theme",
    "get_fzf_text_color",
    "get_fzf_color_args",
    "get_custom_colors",
    "set_custom_color",
    "clear_custom_colors",
    "run_fzf",
    "set_fzf_theme",
    "set_fzf_text_color",
    "get_current_theme_name",
    "get_current_text_color_name",
    "get_color_mode",
    "set_color_mode",
    "fzf_theme_picker",
    "fzf_text_color_picker",
    "fzf_custom_color_menu",
    "git_toplevel",
    "current_branch",
    "current_head",
    "repo_is_clean",
    "load_defaults",
    "save_defaults",
    "load_prep_state",
    "save_prep_state",
    "load_export_state",
    "save_export_state",
    "__version__",
]
