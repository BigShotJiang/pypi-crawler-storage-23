#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Integration tests for projects command."""

import json
import os

import pytest

from bitbake_project.commands.projects import (
    add_project,
    remove_project,
    load_projects,
    save_projects,
    get_current_project,
    set_current_project,
    _get_projects_file,
)


@pytest.fixture
def mock_projects_file(tmp_path, monkeypatch):
    """Mock the projects file location."""
    config_dir = tmp_path / ".config" / "bit"
    config_dir.mkdir(parents=True)
    projects_file = config_dir / "projects.json"

    # Patch _get_projects_file to return our temp path
    monkeypatch.setattr(
        "bitbake_project.commands.projects._get_projects_file",
        lambda: str(projects_file)
    )

    return projects_file


class TestLoadProjects:
    """Tests for load_projects function."""

    def test_load_empty_when_no_file(self, mock_projects_file):
        """Returns empty dict when file doesn't exist."""
        result = load_projects()
        assert result == {}

    def test_load_existing_projects(self, mock_projects_file):
        """Loads projects from existing file."""
        data = {
            "/path/to/project1": {"name": "Project1", "description": ""},
            "/path/to/project2": {"name": "Project2", "description": "desc"},
        }
        mock_projects_file.write_text(json.dumps(data))

        result = load_projects()

        assert len(result) == 2
        assert "/path/to/project1" in result
        assert result["/path/to/project1"]["name"] == "Project1"

    def test_filters_internal_keys(self, mock_projects_file):
        """Filters out __ prefixed internal keys."""
        data = {
            "/path/to/project": {"name": "Project", "description": ""},
            "__current_project__": "/path/to/project",
            "__directory_browser__": "fzf",
        }
        mock_projects_file.write_text(json.dumps(data))

        result = load_projects()

        assert len(result) == 1
        assert "__current_project__" not in result
        assert "__directory_browser__" not in result


class TestSaveProjects:
    """Tests for save_projects function."""

    def test_save_creates_file(self, mock_projects_file):
        """Saving creates the file."""
        projects = {"/path/to/project": {"name": "Project"}}

        save_projects(projects)

        assert mock_projects_file.exists()

    def test_save_writes_valid_json(self, mock_projects_file):
        """Saved data is valid JSON."""
        projects = {"/path/to/project": {"name": "Project"}}

        save_projects(projects)

        data = json.loads(mock_projects_file.read_text())
        assert data == projects


class TestAddProject:
    """Tests for add_project function."""

    def test_add_new_project(self, mock_projects_file, tmp_path, capsys):
        """Adding a new project works."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        result = add_project(str(project_dir), "MyProject")

        assert result is True
        projects = load_projects()
        assert str(project_dir) in projects
        assert projects[str(project_dir)]["name"] == "MyProject"

    def test_add_uses_basename_as_default_name(self, mock_projects_file, tmp_path, capsys):
        """Default name is directory basename."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        add_project(str(project_dir))

        projects = load_projects()
        assert projects[str(project_dir)]["name"] == "my_project"

    def test_add_nonexistent_fails(self, mock_projects_file, tmp_path, capsys):
        """Adding nonexistent directory fails."""
        result = add_project(str(tmp_path / "nonexistent"))

        assert result is False

    def test_add_duplicate_fails(self, mock_projects_file, tmp_path, capsys):
        """Adding same project twice fails."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        add_project(str(project_dir))
        result = add_project(str(project_dir))

        assert result is False


class TestRemoveProject:
    """Tests for remove_project function."""

    def test_remove_existing_project(self, mock_projects_file, tmp_path, capsys):
        """Removing existing project works."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()
        add_project(str(project_dir))

        result = remove_project(str(project_dir))

        assert result is True
        projects = load_projects()
        assert str(project_dir) not in projects

    def test_remove_nonexistent_fails(self, mock_projects_file, capsys):
        """Removing nonexistent project fails."""
        result = remove_project("/nonexistent/path")

        assert result is False


class TestCurrentProject:
    """Tests for get/set current project."""

    def test_get_current_when_not_set(self, mock_projects_file):
        """get_current_project returns None when not set."""
        result = get_current_project()
        assert result is None

    def test_set_and_get_current(self, mock_projects_file, tmp_path):
        """Can set and get current project."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()

        set_current_project(str(project_dir))
        result = get_current_project()

        assert result == str(project_dir)

    def test_clear_current(self, mock_projects_file, tmp_path):
        """Can clear current project with None."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()
        set_current_project(str(project_dir))

        set_current_project(None)
        result = get_current_project()

        assert result is None

    def test_get_current_returns_none_if_dir_missing(self, mock_projects_file, tmp_path):
        """get_current_project returns None if directory no longer exists."""
        project_dir = tmp_path / "my_project"
        project_dir.mkdir()
        set_current_project(str(project_dir))

        # Delete the directory
        project_dir.rmdir()

        result = get_current_project()
        assert result is None


class TestProjectsIntegration:
    """Integration tests for projects workflow."""

    def test_full_add_remove_workflow(self, mock_projects_file, tmp_path, capsys):
        """Full add and remove workflow."""
        # Create two project directories
        proj1 = tmp_path / "project1"
        proj2 = tmp_path / "project2"
        proj1.mkdir()
        proj2.mkdir()

        # Add projects
        add_project(str(proj1), "Project One")
        add_project(str(proj2), "Project Two")

        # Verify both added
        projects = load_projects()
        assert len(projects) == 2

        # Remove one
        remove_project(str(proj2))
        projects = load_projects()
        assert len(projects) == 1
        assert str(proj2) not in projects

    def test_set_current_after_add(self, mock_projects_file, tmp_path, capsys):
        """Setting current project works after adding."""
        proj1 = tmp_path / "project1"
        proj1.mkdir()

        # Add project first
        add_project(str(proj1), "Project One")

        # Set current (after add, so the file already exists)
        set_current_project(str(proj1))
        assert get_current_project() == str(proj1)
