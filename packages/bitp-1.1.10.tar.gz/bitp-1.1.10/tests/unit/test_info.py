#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for info command module."""

import os
import tempfile
import pytest

from bitbake_project.commands.info import (
    parse_local_conf_variables,
    format_info_text,
    get_build_info,
    INFO_VARIABLES,
    _parse_getvar_output,
    _get_conf_checksum,
)


class TestParseLocalConfVariables:
    """Tests for parse_local_conf_variables function."""

    def test_parse_simple_assignments(self, tmp_path):
        """Parse simple variable assignments."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text('''
MACHINE = "qemuarm64"
DISTRO = "poky"
''')
        result = parse_local_conf_variables(str(tmp_path))
        assert result.get("MACHINE") == "qemuarm64"
        assert result.get("DISTRO") == "poky"

    def test_parse_with_comments(self, tmp_path):
        """Parse with comment lines."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text('''
# This is a comment
MACHINE = "qemuarm64"
# DISTRO = "ignored"
DISTRO = "poky"
''')
        result = parse_local_conf_variables(str(tmp_path))
        assert result.get("MACHINE") == "qemuarm64"
        assert result.get("DISTRO") == "poky"

    def test_parse_single_quotes(self, tmp_path):
        """Parse with single quotes."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text("MACHINE = 'qemuarm64'\n")
        result = parse_local_conf_variables(str(tmp_path))
        assert result.get("MACHINE") == "qemuarm64"

    def test_parse_inline_comments(self, tmp_path):
        """Parse with inline comments."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text('MACHINE = "qemuarm64" # my machine\n')
        result = parse_local_conf_variables(str(tmp_path))
        assert result.get("MACHINE") == "qemuarm64"

    def test_parse_distro_version(self, tmp_path):
        """Parse DISTRO_VERSION."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text('DISTRO_VERSION = "3.5"\n')
        result = parse_local_conf_variables(str(tmp_path))
        assert result.get("DISTRO_VERSION") == "3.5"

    def test_missing_file(self, tmp_path):
        """Handle missing local.conf gracefully."""
        result = parse_local_conf_variables(str(tmp_path))
        assert result == {}

    def test_empty_file(self, tmp_path):
        """Handle empty local.conf."""
        conf_file = tmp_path / "local.conf"
        conf_file.write_text("")
        result = parse_local_conf_variables(str(tmp_path))
        assert result == {}


class TestFormatInfoText:
    """Tests for format_info_text function."""

    def test_format_vars_only(self):
        """Format with variables only."""
        info = {
            "variables": {"MACHINE": "qemuarm64", "DISTRO": "poky"},
            "layers": [],
            "getvar_available": False,
            "bitbake_available": False,
        }
        result = format_info_text(info, show_layers=False, show_vars=True)
        assert "Build Configuration:" in result
        assert "MACHINE" in result
        assert "qemuarm64" in result
        assert "DISTRO" in result
        assert "poky" in result

    def test_format_layers_only(self):
        """Format with layers only."""
        info = {
            "variables": {},
            "layers": [
                ("meta", "master", "abc123def456", "/path/to/oe-core"),
                ("meta-poky", "master", "def789abc012", "/path/to/poky"),
            ],
            "getvar_available": False,
            "bitbake_available": False,
        }
        result = format_info_text(info, show_layers=True, show_vars=False)
        assert "Layers:" in result
        assert "meta" in result
        assert "master:abc123def456" in result
        assert "meta-poky" in result

    def test_format_grouped_layers(self):
        """Format layers from same repo (should be grouped)."""
        info = {
            "variables": {},
            "layers": [
                ("meta", "master", "abc123def456", "/path/to/oe-core"),
                ("meta-selftest", "master", "abc123def456", "/path/to/oe-core"),
            ],
            "getvar_available": False,
            "bitbake_available": False,
        }
        result = format_info_text(info, show_layers=True, show_vars=False)
        # First layer should have branch:commit, second should not (same repo)
        lines = result.splitlines()
        meta_line = [l for l in lines if "meta " in l or l.strip().startswith("meta ")]
        selftest_line = [l for l in lines if "meta-selftest" in l]
        assert len(meta_line) > 0
        assert len(selftest_line) > 0
        # The first layer should have the = "branch:commit"
        assert "=" in meta_line[0]

    def test_format_empty_info(self):
        """Format with no data."""
        info = {
            "variables": {},
            "layers": [],
            "getvar_available": False,
            "bitbake_available": False,
        }
        result = format_info_text(info, show_layers=True, show_vars=True)
        assert "Build Configuration:" in result

    def test_format_shows_getvar_note(self):
        """Show note when getvar not available."""
        info = {
            "variables": {"MACHINE": "qemu"},
            "layers": [],
            "getvar_available": False,
            "bitbake_available": False,
        }
        result = format_info_text(info, show_layers=False, show_vars=True)
        assert "bitbake-getvar not available" in result


class TestParseGetvarOutput:
    """Tests for _parse_getvar_output function."""

    def test_parse_double_quoted_value(self):
        """Parse value with double quotes."""
        output = '''#
# $MACHINE [2 operations]
#   set? /path/local.conf:23
#     "qemuarm64"
MACHINE="qemuarm64"
'''
        result = _parse_getvar_output(output, "MACHINE")
        assert result == "qemuarm64"

    def test_parse_single_quoted_value(self):
        """Parse value with single quotes."""
        output = "DISTRO='poky'\n"
        result = _parse_getvar_output(output, "DISTRO")
        assert result == "poky"

    def test_parse_complex_value(self):
        """Parse complex value with special chars."""
        output = '''#
# $DISTRO_VERSION
DISTRO_VERSION="5.3.99+snapshot-01a65e8d"
'''
        result = _parse_getvar_output(output, "DISTRO_VERSION")
        assert result == "5.3.99+snapshot-01a65e8d"

    def test_parse_multiline_comments(self):
        """Parse value with extensive comments above."""
        output = '''#
# $BUILD_SYS
#   set /path/bitbake.conf:133
#     "${BUILD_ARCH}${BUILD_VENDOR}-${BUILD_OS}"
BUILD_SYS="x86_64-linux"
'''
        result = _parse_getvar_output(output, "BUILD_SYS")
        assert result == "x86_64-linux"

    def test_parse_missing_value(self):
        """Return None when value not found."""
        output = "# comment only\n"
        result = _parse_getvar_output(output, "NOTFOUND")
        assert result is None


class TestConfChecksum:
    """Tests for _get_conf_checksum function."""

    def test_checksum_changes_with_file_mod(self, tmp_path):
        """Checksum changes when file is modified."""
        # This test requires mocking resolve_bblayers_path
        # For now, just verify function exists and handles missing files
        # Full test would need integration setup
        pass


class TestInfoVariables:
    """Tests for INFO_VARIABLES constant."""

    def test_info_variables_not_empty(self):
        """INFO_VARIABLES has entries."""
        assert len(INFO_VARIABLES) > 0

    def test_info_variables_structure(self):
        """INFO_VARIABLES entries have correct structure."""
        for entry in INFO_VARIABLES:
            assert len(entry) == 3
            var_name, desc, category = entry
            assert isinstance(var_name, str)
            assert isinstance(desc, str)
            assert isinstance(category, str)

    def test_expected_variables_present(self):
        """Expected key variables are in INFO_VARIABLES."""
        var_names = [v[0] for v in INFO_VARIABLES]
        expected = ["MACHINE", "DISTRO", "BB_VERSION"]
        for expected_var in expected:
            assert expected_var in var_names, f"Expected {expected_var} in INFO_VARIABLES"
