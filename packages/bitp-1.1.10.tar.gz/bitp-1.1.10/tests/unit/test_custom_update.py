#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for custom command in the update flow."""

import argparse
import subprocess
from unittest.mock import MagicMock, patch, call

import pytest

from bitbake_project.core import (
    is_custom_default,
    get_custom_command,
    get_custom_commands,
    get_active_custom_name,
    get_saved_custom_command,
    save_custom_command,
    delete_custom_command,
    activate_custom_command,
    _normalize_custom_entry,
    load_defaults,
)
from bitbake_project.commands.common import (
    prompt_action,
    fzf_prompt_action,
    run_cmd,
)
from bitbake_project.commands.update import run_update


class TestRunCmdCustom:
    """Tests for run_cmd with shell=True (custom commands)."""

    def test_custom_cmd_dry_run(self, capsys):
        """Dry-run prints command without executing."""
        run_cmd("/path/to/repo", "git pull --rebase origin/master", dry_run=True, shell=True)
        out = capsys.readouterr().out
        assert "[dry-run]" in out
        assert "git pull --rebase origin/master" in out
        assert "/path/to/repo" in out

    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_cmd_runs_with_shell(self, mock_run):
        """Custom command is executed with shell=True and correct cwd."""
        run_cmd("/path/to/repo", "git pull --rebase origin/master", dry_run=False, shell=True)
        mock_run.assert_called_once_with(
            "git pull --rebase origin/master",
            check=True,
            cwd="/path/to/repo",
            shell=True,
        )


class TestPromptActionCustom:
    """Tests for text-based prompt_action custom command path."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c git fetch --all")
    def test_custom_command_returns_tuple(self, mock_input, mock_upstream, mock_fzf):
        """'c <cmd>' input returns ('custom', cmd, None)."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result == ("custom", "git fetch --all", None)

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c ")
    def test_custom_command_empty_returns_none(self, mock_input, mock_upstream, mock_fzf):
        """'c ' with no actual command returns None."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result is None

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="c git log --oneline -5")
    def test_custom_command_preserves_full_string(self, mock_input, mock_upstream, mock_fzf):
        """Full command string after 'c ' is preserved."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result[0] == "custom"
        assert result[1] == "git log --oneline -5"


class TestFzfPromptActionCustom:
    """Tests for fzf-based custom command dialog (the --disabled fix)."""

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_command_dialog_uses_disabled(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """When 'Custom command...' is selected, the next fzf invocation uses --disabled."""
        # First call: user selects "Custom command..."
        first_result = MagicMock()
        first_result.returncode = 0
        first_result.stdout = "   Custom command..."

        # Second call: dialog mode with --disabled, user types a command
        # fzf outputs: line 0 = query (--print-query), line 1 = selected item
        # Dialog items are tab-delimited: __DLG_CONFIRM__\t<display>
        second_result = MagicMock()
        second_result.returncode = 0
        second_result.stdout = "git pull --rebase origin/master\n__DLG_CONFIRM__\t│  [ ✓ Confirm ]"

        mock_run.side_effect = [first_result, second_result]

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            result = fzf_prompt_action("/repo", "main", "rebase")

        # Verify the second fzf call included --disabled
        assert mock_run.call_count == 2
        second_call_args = mock_run.call_args_list[1]
        fzf_cmd = second_call_args[0][0]
        assert "--disabled" in fzf_cmd
        assert "--print-query" in fzf_cmd

        # Should return the custom command
        assert result == ("custom", "git pull --rebase origin/master", None)

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_custom_command_dialog_esc_cancels(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """Esc in custom command dialog returns to menu, not skip."""
        # First call: user selects "Custom command..."
        first_result = MagicMock()
        first_result.returncode = 0
        first_result.stdout = "   Custom command..."

        # Second call: user presses Esc (returncode != 0)
        second_result = MagicMock()
        second_result.returncode = 130
        second_result.stdout = ""

        # Third call: user selects Skip
        third_result = MagicMock()
        third_result.returncode = 0
        third_result.stdout = "   Skip this repo (s)"

        mock_run.side_effect = [first_result, second_result, third_result]

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            result = fzf_prompt_action("/repo", "main", "rebase")

        # Should have gone back to menu and then skipped
        assert mock_run.call_count == 3
        assert result == ("skip", "main", None)

    @patch("bitbake_project.commands.common.get_fzf_color_args", return_value=[])
    @patch("bitbake_project.commands.common.get_action_binding", return_value=[])
    @patch("bitbake_project.commands.common.get_terminal_color", return_value="yellow")
    @patch("bitbake_project.commands.common.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.common.subprocess.run")
    def test_first_fzf_call_does_not_use_disabled(
        self, mock_run, mock_display, mock_color, mock_binding, mock_fzf_colors
    ):
        """The initial action menu should NOT use --disabled (needs fuzzy matching)."""
        result_obj = MagicMock()
        result_obj.returncode = 0
        result_obj.stdout = "   Skip this repo (s)"
        mock_run.return_value = result_obj

        with patch("bitbake_project.commands.branch.get_upstream_ref", return_value="origin/main"):
            fzf_prompt_action("/repo", "main", "rebase")

        first_call_args = mock_run.call_args_list[0]
        fzf_cmd = first_call_args[0][0]
        assert "--disabled" not in fzf_cmd


class TestRunUpdateCustomCommand:
    """Tests for custom command through the full run_update flow."""

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults", return_value={})
    def test_custom_command_dispatched_with_shell(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd
    ):
        """Custom command from prompt_action is passed to run_cmd with shell=True."""
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))
        mock_prompt.return_value = ("custom", "git pull --rebase origin/master", None)

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults", return_value={})
    def test_custom_command_target_is_the_command_string(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd
    ):
        """The 'target' field in the custom tuple is the command string, not a branch."""
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))
        mock_prompt.return_value = ("custom", "git fetch --all && git rebase", None)

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        # The second arg to run_cmd is the custom command string
        cmd_arg = mock_run_cmd.call_args[0][1]
        assert cmd_arg == "git fetch --all && git rebase"


class TestCustomDefaultHelpers:
    """Tests for is_custom_default() and get_custom_command() helpers."""

    def test_is_custom_default_true(self):
        assert is_custom_default("custom:git pull --rebase") is True

    def test_is_custom_default_false_rebase(self):
        assert is_custom_default("rebase") is False

    def test_is_custom_default_false_merge(self):
        assert is_custom_default("merge") is False

    def test_is_custom_default_false_skip(self):
        assert is_custom_default("skip") is False

    def test_is_custom_default_false_empty(self):
        assert is_custom_default("") is False

    def test_is_custom_default_true_bare_custom(self):
        """Bare 'custom' (new format) is recognized."""
        assert is_custom_default("custom") is True

    def test_get_custom_command_basic(self):
        assert get_custom_command("custom:git pull --rebase") == "git pull --rebase"

    def test_get_custom_command_with_spaces(self):
        assert get_custom_command("custom:git fetch --all && git rebase") == "git fetch --all && git rebase"

    def test_get_custom_command_empty_after_prefix(self):
        assert get_custom_command("custom:") == ""


class TestRunUpdateCustomDefault:
    """Tests for run_update with --yes and custom: defaults."""

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_custom_default(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd
    ):
        """--yes with a custom: default executes the custom command."""
        mock_defaults.return_value = {"/repo/meta-oe": "custom:git pull --rebase origin/master"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_custom_default_prints_info(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd, capsys
    ):
        """--yes with custom: default prints descriptive info."""
        mock_defaults.return_value = {"/repo/poky": "custom:make update"}
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        out = capsys.readouterr().out
        assert "custom" in out
        assert "make update" in out

    @patch("bitbake_project.commands.update.get_pull_args", return_value=(["git", "pull", "--rebase", "origin", "main"], "git pull --rebase origin/main"))
    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_standard_default_still_works(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd, mock_pull_args
    ):
        """--yes with standard rebase default still works normally."""
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        # Should call run_cmd without shell=True (standard pull)
        mock_run_cmd.assert_called_once()
        call_kwargs = mock_run_cmd.call_args
        assert call_kwargs[0][1] == ["git", "pull", "--rebase", "origin", "main"]


class TestPromptActionCustomDefault:
    """Tests for text-based prompt_action with d custom <cmd>."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom git pull --rebase origin/master")
    def test_d_custom_sets_default(self, mock_input, mock_upstream, mock_fzf):
        """'d custom <cmd>' returns custom tuple with new_default."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result == ("custom", "git pull --rebase origin/master", "custom:git pull --rebase origin/master")

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom ")
    def test_d_custom_empty_returns_none(self, mock_input, mock_upstream, mock_fzf):
        """'d custom ' with no command returns None."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result is None

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="")
    def test_enter_with_custom_default_runs_custom(self, mock_input, mock_upstream, mock_fzf):
        """Pressing Enter with a custom: default returns the custom command."""
        result = prompt_action("/repo", "main", "custom:git fetch --all", use_fzf=False)
        assert result == ("custom", "git fetch --all", None)


class TestConfigUpdateDefaultValidation:
    """Tests for CLI --update-default validation."""

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_custom_update_default_accepted(
        self, mock_defaults, mock_collect, mock_display, mock_save
    ):
        """--update-default 'custom:git pull' is accepted and saved via __custom_commands__."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom:git pull --rebase",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        # Verify the custom value was saved via save_custom_command
        defaults = mock_defaults.return_value
        assert defaults["/repo/meta-oe"] == "custom"
        entry = defaults["__custom_commands__"]["/repo/meta-oe"]
        assert isinstance(entry, dict)
        assert entry[entry["__active__"]] == "git pull --rebase"

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_invalid_update_default_rejected(
        self, mock_defaults, mock_collect, mock_display, mock_save
    ):
        """--update-default 'invalid' returns error."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="invalid",
            edit=False,
        )

        result = run_config(args)
        assert result == 1


class TestSavedCustomCommandHelpers:
    """Tests for get_saved_custom_command / save_custom_command / delete_custom_command."""

    def test_get_saved_from_custom_commands(self):
        """get_saved_custom_command returns from __custom_commands__."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase origin/master"},
        }
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull --rebase origin/master"

    def test_get_saved_falls_back_to_inline(self):
        """Falls back to legacy custom: inline format."""
        defaults = {"/repo/poky": "custom:make update"}
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

    def test_get_saved_returns_none_when_missing(self):
        """Returns None when no command is available."""
        defaults = {"/repo/poky": "rebase"}
        assert get_saved_custom_command(defaults, "/repo/poky") is None

    def test_get_saved_returns_none_for_bare_custom_without_storage(self):
        """Returns None when active is 'custom' but no __custom_commands__ entry."""
        defaults = {"/repo/poky": "custom"}
        assert get_saved_custom_command(defaults, "/repo/poky") is None

    def test_save_custom_command(self):
        """save_custom_command stores command and sets active to 'custom'."""
        defaults = {"/repo/poky": "rebase"}
        save_custom_command(defaults, "/repo/poky", "git pull --rebase")
        assert defaults["/repo/poky"] == "custom"
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert isinstance(entry, dict)
        assert entry["__active__"] == "default"
        assert entry["default"] == "git pull --rebase"

    def test_save_custom_command_overwrites(self):
        """save_custom_command overwrites existing command."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "old cmd"},
        }
        save_custom_command(defaults, "/repo/poky", "new cmd")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert isinstance(entry, dict)
        assert entry["default"] == "new cmd"

    def test_delete_custom_command(self):
        """delete_custom_command removes command and reverts to rebase."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        delete_custom_command(defaults, "/repo/poky")
        assert defaults["/repo/poky"] == "rebase"
        assert "/repo/poky" not in defaults["__custom_commands__"]

    def test_delete_custom_command_with_legacy_format(self):
        """delete_custom_command handles legacy custom: format."""
        defaults = {"/repo/poky": "custom:make update"}
        delete_custom_command(defaults, "/repo/poky")
        assert defaults["/repo/poky"] == "rebase"

    def test_delete_custom_command_noop_when_not_custom(self):
        """delete_custom_command is safe when not custom active."""
        defaults = {"/repo/poky": "merge"}
        delete_custom_command(defaults, "/repo/poky")
        assert defaults["/repo/poky"] == "merge"


class TestCustomCommandTogglePersistence:
    """Tests for toggling between modes while preserving custom command."""

    def test_switch_to_rebase_preserves_custom_command(self):
        """Switching to rebase leaves __custom_commands__ untouched."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        defaults["/repo/poky"] = "rebase"
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull --rebase"

    def test_switch_back_to_custom(self):
        """Switching back to custom finds the persisted command."""
        defaults = {
            "/repo/poky": "rebase",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        defaults["/repo/poky"] = "custom"
        assert is_custom_default(defaults["/repo/poky"]) is True
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull --rebase"

    def test_full_cycle_rebase_merge_skip_custom(self):
        """Full cycle through all modes preserves custom command."""
        defaults = {}
        save_custom_command(defaults, "/repo/poky", "make update")
        assert defaults["/repo/poky"] == "custom"

        # Switch to rebase
        defaults["/repo/poky"] = "rebase"
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

        # Switch to merge
        defaults["/repo/poky"] = "merge"
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

        # Switch to skip
        defaults["/repo/poky"] = "skip"
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

        # Switch back to custom
        defaults["/repo/poky"] = "custom"
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"


class TestRunUpdateCustomSaved:
    """Tests for run_update --yes with saved custom commands."""

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_saved_custom_command(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd
    ):
        """--yes with 'custom' active + saved command executes it."""
        mock_defaults.return_value = {
            "/repo/meta-oe": "custom",
            "__custom_commands__": {"/repo/meta-oe": "git pull --rebase origin/master"},
        }
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_bare_custom_no_command_skips(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd, capsys
    ):
        """--yes with 'custom' active but no saved command skips."""
        mock_defaults.return_value = {"/repo/meta-oe": "custom"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_not_called()
        out = capsys.readouterr().out
        assert "no command saved" in out


class TestPromptActionDeleteCustom:
    """Tests for text-based 'd delete-custom' and 'd custom' (no cmd)."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d delete-custom")
    def test_d_delete_custom(self, mock_input, mock_upstream, mock_fzf):
        """'d delete-custom' returns delete-custom marker."""
        result = prompt_action("/repo", "main", "custom", use_fzf=False)
        assert result == ("rebase", "main", "delete-custom")

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom")
    def test_d_custom_activates_saved(self, mock_input, mock_upstream, mock_fzf):
        """'d custom' (no cmd) activates existing saved command."""
        defaults = {"__custom_commands__": {"/repo": "git pull --rebase"}}
        result = prompt_action("/repo", "main", "rebase", defaults=defaults, use_fzf=False)
        assert result == ("custom", "git pull --rebase", "custom:git pull --rebase")

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom")
    def test_d_custom_no_saved_returns_none(self, mock_input, mock_upstream, mock_fzf):
        """'d custom' with no saved command returns None."""
        result = prompt_action("/repo", "main", "rebase", defaults={}, use_fzf=False)
        assert result is None


class TestConfigCLIDeleteCustom:
    """Tests for CLI --update-default delete-custom and custom."""

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_delete_custom(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default delete-custom removes custom command."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {
            "/repo/meta-oe": "custom",
            "__custom_commands__": {"/repo/meta-oe": "git pull --rebase"},
        }
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="delete-custom",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        defaults = mock_defaults.return_value
        assert defaults["/repo/meta-oe"] == "rebase"
        assert "/repo/meta-oe" not in defaults["__custom_commands__"]

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_activate_existing_custom(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default custom activates existing saved command."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {
            "/repo/meta-oe": "rebase",
            "__custom_commands__": {"/repo/meta-oe": "git pull --rebase"},
        }
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        assert mock_defaults.return_value["/repo/meta-oe"] == "custom"

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_activate_custom_no_saved_fails(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default custom with no saved command returns error."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom",
            edit=False,
        )

        result = run_config(args)
        assert result == 1


class TestLoadDefaultsPreservesCustomCommands:
    """Tests for load_defaults preserving __custom_commands__."""

    def test_load_defaults_preserves_custom_commands(self, tmp_path):
        """__custom_commands__ dict is preserved through save/load cycle."""
        import json
        from bitbake_project.core import save_defaults

        defaults_file = str(tmp_path / "defaults.json")
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        save_defaults(defaults_file, defaults)
        loaded = load_defaults(defaults_file)
        assert loaded["__custom_commands__"] == {"/repo/poky": "git pull --rebase"}
        assert loaded["/repo/poky"] == "custom"

    def test_load_defaults_handles_missing_custom_commands(self, tmp_path):
        """Defaults without __custom_commands__ load fine."""
        import json
        from bitbake_project.core import save_defaults

        defaults_file = str(tmp_path / "defaults.json")
        defaults = {"/repo/poky": "rebase"}
        save_defaults(defaults_file, defaults)
        loaded = load_defaults(defaults_file)
        assert "__custom_commands__" not in loaded
        assert loaded["/repo/poky"] == "rebase"


class TestBackwardCompatCustomInline:
    """Backward compatibility: legacy custom:<cmd> inline format still works."""

    def test_is_custom_default_legacy(self):
        """Legacy custom:cmd is still recognized."""
        assert is_custom_default("custom:git pull --rebase") is True

    def test_get_saved_custom_command_legacy(self):
        """get_saved_custom_command falls back to inline format."""
        defaults = {"/repo/poky": "custom:make update"}
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_legacy_custom_default(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd
    ):
        """--yes with legacy custom:cmd format still executes."""
        mock_defaults.return_value = {"/repo/meta-oe": "custom:git pull --rebase origin/master"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/meta-oe", "git pull --rebase origin/master", False, shell=True
        )


# ====================================================================
# Named custom commands — new dict storage format
# ====================================================================


class TestNormalizeCustomEntry:
    """Tests for _normalize_custom_entry helper."""

    def test_dict_passthrough(self):
        entry = {"__active__": "my-cmd", "my-cmd": "git pull"}
        assert _normalize_custom_entry(entry) == entry

    def test_string_to_dict(self):
        result = _normalize_custom_entry("git pull --rebase")
        assert result == {"__active__": "default", "default": "git pull --rebase"}

    def test_empty_string_with_legacy_inline(self):
        result = _normalize_custom_entry("", "custom:make update")
        assert result == {"__active__": "default", "default": "make update"}

    def test_none_returns_empty(self):
        assert _normalize_custom_entry(None) == {}

    def test_empty_string_no_fallback(self):
        assert _normalize_custom_entry("") == {}


class TestCustomCommandsDict:
    """Tests for get_custom_commands() with new dict format."""

    def test_new_dict_format(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase origin/master",
                    "full-sync": "git fetch --all && git rebase",
                }
            },
        }
        result = get_custom_commands(defaults, "/repo/poky")
        assert result == {
            "rebase-master": "git pull --rebase origin/master",
            "full-sync": "git fetch --all && git rebase",
        }
        assert "__active__" not in result

    def test_string_migration(self):
        """Old string entry is migrated transparently."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        result = get_custom_commands(defaults, "/repo/poky")
        assert result == {"default": "git pull --rebase"}

    def test_inline_legacy(self):
        """Legacy custom:<cmd> inline format."""
        defaults = {"/repo/poky": "custom:make update"}
        result = get_custom_commands(defaults, "/repo/poky")
        assert result == {"default": "make update"}

    def test_empty_when_not_custom(self):
        defaults = {"/repo/poky": "rebase"}
        assert get_custom_commands(defaults, "/repo/poky") == {}

    def test_empty_when_no_entry(self):
        defaults = {}
        assert get_custom_commands(defaults, "/repo/poky") == {}


class TestActiveCustomName:
    """Tests for get_active_custom_name()."""

    def test_new_format(self):
        defaults = {
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "my-cmd",
                    "my-cmd": "git pull",
                }
            }
        }
        assert get_active_custom_name(defaults, "/repo/poky") == "my-cmd"

    def test_string_entry_returns_default(self):
        defaults = {
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        assert get_active_custom_name(defaults, "/repo/poky") == "default"

    def test_legacy_inline_returns_default(self):
        defaults = {"/repo/poky": "custom:make update"}
        assert get_active_custom_name(defaults, "/repo/poky") == "default"

    def test_missing_returns_none(self):
        defaults = {"/repo/poky": "rebase"}
        assert get_active_custom_name(defaults, "/repo/poky") is None


class TestSaveCustomCommandNamed:
    """Tests for save_custom_command with name parameter."""

    def test_new_repo(self):
        defaults = {"/repo/poky": "rebase"}
        save_custom_command(defaults, "/repo/poky", "git pull --rebase", name="rebase-master")
        assert defaults["/repo/poky"] == "custom"
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert entry["__active__"] == "rebase-master"
        assert entry["rebase-master"] == "git pull --rebase"

    def test_add_second_command(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase",
                }
            },
        }
        save_custom_command(defaults, "/repo/poky", "git fetch --all", name="full-sync")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert entry["__active__"] == "full-sync"
        assert entry["rebase-master"] == "git pull --rebase"
        assert entry["full-sync"] == "git fetch --all"

    def test_migrates_string_on_write(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        save_custom_command(defaults, "/repo/poky", "git fetch", name="my-fetch")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert isinstance(entry, dict)
        assert entry["default"] == "git pull --rebase"
        assert entry["my-fetch"] == "git fetch"
        assert entry["__active__"] == "my-fetch"

    def test_overwrites_existing_name(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "rebase-master",
                    "rebase-master": "old cmd",
                }
            },
        }
        save_custom_command(defaults, "/repo/poky", "new cmd", name="rebase-master")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert entry["rebase-master"] == "new cmd"

    def test_sets_active(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                }
            },
        }
        save_custom_command(defaults, "/repo/poky", "cmd2", name="second")
        assert defaults["__custom_commands__"]["/repo/poky"]["__active__"] == "second"

    def test_rejects_colon_in_name(self):
        defaults = {}
        with pytest.raises(ValueError):
            save_custom_command(defaults, "/repo/poky", "cmd", name="bad:name")

    def test_rejects_empty_name(self):
        defaults = {}
        with pytest.raises(ValueError):
            save_custom_command(defaults, "/repo/poky", "cmd", name="")

    def test_rejects_active_keyword(self):
        defaults = {}
        with pytest.raises(ValueError):
            save_custom_command(defaults, "/repo/poky", "cmd", name="__active__")


class TestDeleteCustomCommandNamed:
    """Tests for delete_custom_command with name parameter."""

    def test_delete_specific_keeps_others(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                    "second": "cmd2",
                }
            },
        }
        delete_custom_command(defaults, "/repo/poky", name="second")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert "second" not in entry
        assert entry["first"] == "cmd1"
        assert defaults["/repo/poky"] == "custom"

    def test_delete_active_switches(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                    "second": "cmd2",
                }
            },
        }
        delete_custom_command(defaults, "/repo/poky", name="first")
        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert "first" not in entry
        assert entry["__active__"] == "second"

    def test_delete_last_reverts(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "only",
                    "only": "cmd1",
                }
            },
        }
        delete_custom_command(defaults, "/repo/poky", name="only")
        assert "/repo/poky" not in defaults.get("__custom_commands__", {})
        assert defaults["/repo/poky"] == "rebase"

    def test_delete_all(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                    "second": "cmd2",
                }
            },
        }
        delete_custom_command(defaults, "/repo/poky")
        assert "/repo/poky" not in defaults.get("__custom_commands__", {})
        assert defaults["/repo/poky"] == "rebase"

    def test_delete_from_migrated_string(self):
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        delete_custom_command(defaults, "/repo/poky", name="default")
        assert "/repo/poky" not in defaults.get("__custom_commands__", {})
        assert defaults["/repo/poky"] == "rebase"


class TestActivateCustomCommand:
    """Tests for activate_custom_command()."""

    def test_activate_existing(self):
        defaults = {
            "/repo/poky": "rebase",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                    "second": "cmd2",
                }
            },
        }
        assert activate_custom_command(defaults, "/repo/poky", "second") is True
        assert defaults["__custom_commands__"]["/repo/poky"]["__active__"] == "second"
        assert defaults["/repo/poky"] == "custom"

    def test_activate_nonexistent_returns_false(self):
        defaults = {
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                }
            },
        }
        assert activate_custom_command(defaults, "/repo/poky", "nope") is False

    def test_activate_sets_repo_to_custom(self):
        defaults = {
            "/repo/poky": "rebase",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                }
            },
        }
        activate_custom_command(defaults, "/repo/poky", "first")
        assert defaults["/repo/poky"] == "custom"

    def test_activate_with_string_entry(self):
        """Activating 'default' on a migrated string entry works."""
        defaults = {
            "/repo/poky": "rebase",
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        assert activate_custom_command(defaults, "/repo/poky", "default") is True
        assert defaults["/repo/poky"] == "custom"

    def test_activate_no_repo_returns_false(self):
        defaults = {}
        assert activate_custom_command(defaults, "/repo/poky", "anything") is False


class TestGetSavedCustomCommandMigration:
    """Tests for get_saved_custom_command with dict and migration."""

    def test_active_from_dict(self):
        defaults = {
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase origin/master",
                    "full-sync": "git fetch --all",
                }
            }
        }
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull --rebase origin/master"

    def test_from_string(self):
        defaults = {
            "__custom_commands__": {"/repo/poky": "git pull --rebase"},
        }
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull --rebase"

    def test_from_legacy_inline(self):
        defaults = {"/repo/poky": "custom:make update"}
        assert get_saved_custom_command(defaults, "/repo/poky") == "make update"

    def test_dict_with_bad_active_returns_none(self):
        defaults = {
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "deleted",
                    "first": "cmd1",
                }
            }
        }
        assert get_saved_custom_command(defaults, "/repo/poky") is None


class TestBackwardCompatSaveLoad:
    """Round-trip preserves dict format, mixed old/new repos."""

    def test_round_trip_preserves_dict(self, tmp_path):
        import json
        from bitbake_project.core import save_defaults

        defaults_file = str(tmp_path / "defaults.json")
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase origin/master",
                    "full-sync": "git fetch --all",
                }
            },
        }
        save_defaults(defaults_file, defaults)
        loaded = load_defaults(defaults_file)
        assert loaded["__custom_commands__"]["/repo/poky"] == {
            "__active__": "rebase-master",
            "rebase-master": "git pull --rebase origin/master",
            "full-sync": "git fetch --all",
        }

    def test_mixed_old_new(self):
        """Mixed old string and new dict repos coexist."""
        defaults = {
            "/repo/poky": "custom",
            "/repo/meta-oe": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "my-cmd",
                    "my-cmd": "git pull",
                },
                "/repo/meta-oe": "old string cmd",
            },
        }
        assert get_saved_custom_command(defaults, "/repo/poky") == "git pull"
        assert get_saved_custom_command(defaults, "/repo/meta-oe") == "old string cmd"
        assert get_custom_commands(defaults, "/repo/poky") == {"my-cmd": "git pull"}
        assert get_custom_commands(defaults, "/repo/meta-oe") == {"default": "old string cmd"}


class TestPromptActionNamedCustom:
    """Tests for text-based prompt_action with named custom commands."""

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom rebase-master:git pull --rebase origin/master")
    def test_d_custom_name_cmd(self, mock_input, mock_upstream, mock_fzf):
        """'d custom name:cmd' returns named custom."""
        result = prompt_action("/repo", "main", "rebase", use_fzf=False)
        assert result[0] == "custom"
        assert result[1] == "git pull --rebase origin/master"
        assert result[2] == "custom:rebase-master:git pull --rebase origin/master"

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom rebase-master")
    def test_d_custom_name_activates_existing(self, mock_input, mock_upstream, mock_fzf):
        """'d custom name' activates existing named command."""
        defaults = {
            "__custom_commands__": {
                "/repo": {
                    "__active__": "other",
                    "other": "cmd1",
                    "rebase-master": "git pull --rebase",
                }
            }
        }
        result = prompt_action("/repo", "main", "rebase", defaults=defaults, use_fzf=False)
        assert result[0] == "custom"
        assert result[1] == "git pull --rebase"
        assert result[2] == "custom:rebase-master"

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d delete-custom rebase-master")
    def test_d_delete_custom_named(self, mock_input, mock_upstream, mock_fzf):
        """'d delete-custom name' returns delete marker for specific command."""
        result = prompt_action("/repo", "main", "custom", use_fzf=False)
        assert result == ("rebase", "main", "delete-custom:rebase-master")

    @patch("bitbake_project.commands.common.fzf_available", return_value=False)
    @patch("bitbake_project.commands.common.get_upstream_count_ls_remote", return_value=None)
    @patch("builtins.input", return_value="d custom unknown-name")
    def test_d_custom_name_not_found_treats_as_cmd(self, mock_input, mock_upstream, mock_fzf):
        """'d custom unknown' when name doesn't exist treats as legacy cmd."""
        defaults = {}
        result = prompt_action("/repo", "main", "rebase", defaults=defaults, use_fzf=False)
        assert result[0] == "custom"
        assert result[1] == "unknown-name"
        assert result[2] == "custom:unknown-name"


class TestConfigCLINamedCustom:
    """Tests for CLI --update-default with named custom commands."""

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_custom_name_cmd(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default 'custom:my-rebase:git pull --rebase'"""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {"/repo/meta-oe": "rebase"}
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom:my-rebase:git pull --rebase",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        defaults = mock_defaults.return_value
        assert defaults["/repo/meta-oe"] == "custom"
        entry = defaults["__custom_commands__"]["/repo/meta-oe"]
        assert entry["my-rebase"] == "git pull --rebase"
        assert entry["__active__"] == "my-rebase"

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_custom_name_activate(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default 'custom:full-sync' activates existing."""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {
            "/repo/meta-oe": "custom",
            "__custom_commands__": {
                "/repo/meta-oe": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase",
                    "full-sync": "git fetch --all",
                }
            },
        }
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="custom:full-sync",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        entry = mock_defaults.return_value["__custom_commands__"]["/repo/meta-oe"]
        assert entry["__active__"] == "full-sync"

    @patch("bitbake_project.commands.config.save_defaults")
    @patch("bitbake_project.commands.config.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.config.collect_repos")
    @patch("bitbake_project.commands.config.load_defaults")
    def test_delete_custom_named(self, mock_defaults, mock_collect, mock_display, mock_save):
        """--update-default 'delete-custom:rebase-master'"""
        from bitbake_project.commands.config import run_config
        mock_defaults.return_value = {
            "/repo/meta-oe": "custom",
            "__custom_commands__": {
                "/repo/meta-oe": {
                    "__active__": "rebase-master",
                    "rebase-master": "git pull --rebase",
                    "full-sync": "git fetch --all",
                }
            },
        }
        mock_collect.return_value = (["/repo/meta-oe"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            repo="1",
            extra_arg=None,
            value_arg=None,
            display_name=None,
            update_default="delete-custom:rebase-master",
            edit=False,
        )

        result = run_config(args)
        assert result == 0
        entry = mock_defaults.return_value["__custom_commands__"]["/repo/meta-oe"]
        assert "rebase-master" not in entry
        assert entry["__active__"] == "full-sync"


class TestRunUpdateNamedCustom:
    """Tests for run_update with named custom commands in new_default."""

    @patch("bitbake_project.commands.update.save_defaults")
    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_custom_name_cmd_in_new_default(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd, mock_save
    ):
        """new_default 'custom:my-rebase:git pull --rebase' saves named command."""
        defaults = {"/repo/poky": "rebase"}
        mock_defaults.return_value = defaults
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))
        mock_prompt.return_value = ("custom", "git pull --rebase", "custom:my-rebase:git pull --rebase")

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert entry["my-rebase"] == "git pull --rebase"
        assert entry["__active__"] == "my-rebase"

    @patch("bitbake_project.commands.update.save_defaults")
    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.prompt_action")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_delete_custom_named_in_new_default(
        self, mock_defaults, mock_collect, mock_branch, mock_prompt, mock_run_cmd, mock_save
    ):
        """new_default 'delete-custom:first' deletes specific command."""
        defaults = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "first",
                    "first": "cmd1",
                    "second": "cmd2",
                }
            },
        }
        mock_defaults.return_value = defaults
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))
        mock_prompt.return_value = ("rebase", "main", "delete-custom:first")

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=False,
            all=False,
            repo=None,
        )

        run_update(args)

        entry = defaults["__custom_commands__"]["/repo/poky"]
        assert "first" not in entry
        assert entry["__active__"] == "second"

    @patch("bitbake_project.commands.update.run_cmd")
    @patch("bitbake_project.commands.update.repo_display_name", return_value="my-repo")
    @patch("bitbake_project.commands.update.current_branch", return_value="main")
    @patch("bitbake_project.commands.update.collect_repos")
    @patch("bitbake_project.commands.update.load_defaults")
    def test_yes_with_named_custom(
        self, mock_defaults, mock_collect, mock_branch, mock_display, mock_run_cmd
    ):
        """--yes with named custom commands resolves active command."""
        mock_defaults.return_value = {
            "/repo/poky": "custom",
            "__custom_commands__": {
                "/repo/poky": {
                    "__active__": "full-sync",
                    "rebase-master": "git pull --rebase",
                    "full-sync": "git fetch --all && git rebase",
                }
            },
        }
        mock_collect.return_value = (["/repo/poky"], MagicMock(external=[]))

        args = argparse.Namespace(
            bblayers="bblayers.conf",
            defaults_file=".bit.defaults",
            resume=False,
            resume_file=".bit.resume",
            dry_run=False,
            plain=False,
            yes=True,
            all=False,
            repo=None,
        )

        run_update(args)

        mock_run_cmd.assert_called_once_with(
            "/repo/poky", "git fetch --all && git rebase", False, shell=True
        )
