#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for setup commands (registry-copy, export, configs)."""

import argparse
import json
import os
import shutil
import tempfile

import pytest

from bitbake_project.commands.setup import (
    run_setup_export, run_setup_registry_copy,
    _gather_export_sources, _write_export, gather_export_data,
    _resolve_project_dir,
)


def _make_conf_json(directory, name="test.conf.json"):
    """Create a minimal valid .conf.json file for testing."""
    content = {
        "version": "1",
        "sources": {
            "openembedded-core": {
                "remote": {"origin": {"uri": "https://git.openembedded.org/openembedded-core"}},
                "rev": "master",
                "path": "openembedded-core",
            }
        },
        "configurations": {
            "default": {
                "description": "Test configuration",
                "bb-layers": ["openembedded-core/meta"],
            }
        },
    }
    path = os.path.join(directory, name)
    with open(path, "w") as f:
        json.dump(content, f)
    return path


class TestRunSetupRegistryCopy:
    """Tests for run_setup_registry_copy function."""

    @pytest.fixture
    def tmpdir(self):
        d = tempfile.mkdtemp()
        yield d
        shutil.rmtree(d)

    @pytest.fixture
    def registry_dir(self, tmpdir, monkeypatch):
        reg = os.path.join(tmpdir, ".config", "bit", "registry")
        monkeypatch.setenv("HOME", tmpdir)
        # Patch expanduser to use our tmpdir
        monkeypatch.setattr(os.path, "expanduser", lambda p: p.replace("~", tmpdir))
        return reg

    def _make_args(self, file_path, force=False, as_name=None):
        return argparse.Namespace(file=file_path, force=force, as_name=as_name)

    def test_save_valid_file(self, tmpdir, registry_dir):
        """Save copies a valid .conf.json to the registry."""
        conf_path = _make_conf_json(tmpdir)
        args = self._make_args(conf_path)
        rc = run_setup_registry_copy(args)
        assert rc == 0
        assert os.path.isfile(os.path.join(registry_dir, "test.conf.json"))

    def test_save_appends_extension(self, tmpdir, registry_dir):
        """Save appends .conf.json if missing."""
        conf_path = _make_conf_json(tmpdir, name="myconfig")
        args = self._make_args(conf_path)
        rc = run_setup_registry_copy(args)
        assert rc == 0
        assert os.path.isfile(os.path.join(registry_dir, "myconfig.conf.json"))

    def test_save_file_not_found(self, tmpdir, registry_dir):
        """Save returns error for missing file."""
        args = self._make_args(os.path.join(tmpdir, "nonexistent.conf.json"))
        rc = run_setup_registry_copy(args)
        assert rc == 1

    def test_save_invalid_json(self, tmpdir, registry_dir):
        """Save returns error for invalid JSON."""
        bad_path = os.path.join(tmpdir, "bad.conf.json")
        with open(bad_path, "w") as f:
            f.write("not json")
        args = self._make_args(bad_path)
        rc = run_setup_registry_copy(args)
        assert rc == 1

    def test_save_force_overwrite(self, tmpdir, registry_dir):
        """Save with --force overwrites without prompting."""
        conf_path = _make_conf_json(tmpdir)
        args = self._make_args(conf_path, force=False)
        rc = run_setup_registry_copy(args)
        assert rc == 0

        # Save again with force
        args = self._make_args(conf_path, force=True)
        rc = run_setup_registry_copy(args)
        assert rc == 0

    def test_save_creates_registry_dir(self, tmpdir, registry_dir):
        """Save creates the registry directory if it doesn't exist."""
        assert not os.path.isdir(registry_dir)
        conf_path = _make_conf_json(tmpdir)
        args = self._make_args(conf_path)
        rc = run_setup_registry_copy(args)
        assert rc == 0
        assert os.path.isdir(registry_dir)

    def test_as_name(self, tmpdir, registry_dir):
        """--as renames the file in the registry."""
        conf_path = _make_conf_json(tmpdir)
        args = self._make_args(conf_path, as_name="my-build")
        rc = run_setup_registry_copy(args)
        assert rc == 0
        assert os.path.isfile(os.path.join(registry_dir, "my-build.conf.json"))
        assert not os.path.isfile(os.path.join(registry_dir, "test.conf.json"))

    def test_as_name_with_extension(self, tmpdir, registry_dir):
        """--as with .conf.json extension doesn't double-append."""
        conf_path = _make_conf_json(tmpdir)
        args = self._make_args(conf_path, as_name="my-build.conf.json")
        rc = run_setup_registry_copy(args)
        assert rc == 0
        assert os.path.isfile(os.path.join(registry_dir, "my-build.conf.json"))


# =============================================================================
# Helpers for export tests
# =============================================================================

def _init_git_repo(path, remote_url="https://example.com/repo.git", branch="main"):
    """Initialize a git repo with a remote and an initial commit."""
    import subprocess as sp
    env = {**os.environ,
           "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
           "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"}
    sp.run(["git", "init", path], capture_output=True, check=True, env=env)
    sp.run(["git", "-C", path, "remote", "add", "origin", remote_url],
           capture_output=True, check=True, env=env)
    dummy = os.path.join(path, ".gitkeep")
    with open(dummy, "w") as f:
        f.write("")
    sp.run(["git", "-C", path, "add", "."], capture_output=True, check=True, env=env)
    sp.run(["git", "-C", path, "commit", "-m", "init"],
           capture_output=True, check=True, env=env)
    if branch != "master":
        sp.run(["git", "-C", path, "checkout", "-b", branch],
               capture_output=True, check=True, env=env)


# =============================================================================
# Tests: run_setup_export
# =============================================================================

class TestRunSetupExport:
    """Tests for run_setup_export function."""

    def test_export_no_bblayers(self, tmp_path, monkeypatch):
        """Returns 1 when no bblayers.conf found."""
        monkeypatch.chdir(tmp_path)
        args = argparse.Namespace(output=None, registry=False, layers_dir="layers", bblayers=None)
        assert run_setup_export(args) == 1

    def test_export_basic(self, tmp_path, monkeypatch):
        """Exports a valid .conf.json with sources and layers."""
        monkeypatch.chdir(tmp_path)

        # Set up layers directory with a git repo containing a layer
        layers_dir = tmp_path / "layers"
        repo_dir = layers_dir / "my-repo"
        layer_dir = repo_dir / "meta-test"
        conf_dir = layer_dir / "conf"
        conf_dir.mkdir(parents=True)
        (conf_dir / "layer.conf").write_text("# layer conf\n")

        _init_git_repo(str(repo_dir), remote_url="https://example.com/my-repo.git", branch="main")

        # Write bblayers.conf
        build_conf = tmp_path / "conf"
        build_conf.mkdir()
        bblayers = build_conf / "bblayers.conf"
        bblayers.write_text(f'BBLAYERS = "{layer_dir}"\n')

        output = str(tmp_path / "out.conf.json")
        args = argparse.Namespace(
            output=output, registry=False,
            layers_dir=str(layers_dir), bblayers=str(bblayers),
        )
        rc = run_setup_export(args)
        assert rc == 0

        with open(output) as f:
            data = json.load(f)

        assert data["version"] == "1.0.0"
        assert "my-repo" in data["sources"]
        src = data["sources"]["my-repo"]
        assert src["git-remote"]["remotes"]["origin"]["uri"] == "https://example.com/my-repo.git"

        configs = data["bitbake-setup"]["configurations"]
        assert len(configs) == 1
        assert len(configs[0]["bb-layers"]) == 1

    def test_export_registry(self, tmp_path, monkeypatch):
        """--registry copies the output to user registry."""
        monkeypatch.chdir(tmp_path)

        layers_dir = tmp_path / "layers"
        repo_dir = layers_dir / "oe-core"
        layer_dir = repo_dir / "meta"
        conf_dir = layer_dir / "conf"
        conf_dir.mkdir(parents=True)
        (conf_dir / "layer.conf").write_text("# layer\n")

        _init_git_repo(str(repo_dir), remote_url="https://example.com/oe-core.git")

        build_conf = tmp_path / "conf"
        build_conf.mkdir()
        bblayers = build_conf / "bblayers.conf"
        bblayers.write_text(f'BBLAYERS = "{layer_dir}"\n')

        # Use a custom home for registry
        fake_home = tmp_path / "fakehome"
        registry_dir = fake_home / ".config" / "bit" / "registry"
        monkeypatch.setattr(os.path, "expanduser", lambda p: p.replace("~", str(fake_home)))

        output = str(tmp_path / "export.conf.json")
        args = argparse.Namespace(
            output=output, registry=True,
            layers_dir=str(layers_dir), bblayers=str(bblayers),
        )
        rc = run_setup_export(args)
        assert rc == 0
        assert os.path.isfile(output)
        assert os.path.isfile(str(registry_dir / "export.conf.json"))

    def test_export_default_filename(self, tmp_path, monkeypatch):
        """Default output filename is <project-name>.conf.json."""
        monkeypatch.chdir(tmp_path)

        layers_dir = tmp_path / "layers"
        repo_dir = layers_dir / "repo"
        layer_dir = repo_dir / "meta"
        conf_dir = layer_dir / "conf"
        conf_dir.mkdir(parents=True)
        (conf_dir / "layer.conf").write_text("# layer\n")

        _init_git_repo(str(repo_dir))

        build_conf = tmp_path / "conf"
        build_conf.mkdir()
        bblayers = build_conf / "bblayers.conf"
        bblayers.write_text(f'BBLAYERS = "{layer_dir}"\n')

        args = argparse.Namespace(
            output=None, registry=False,
            layers_dir=str(layers_dir), bblayers=str(bblayers),
        )
        rc = run_setup_export(args)
        assert rc == 0

        project_name = os.path.basename(str(tmp_path))
        expected = tmp_path / f"{project_name}.conf.json"
        assert expected.exists()

    def test_export_with_project_path(self, tmp_path, monkeypatch):
        """--project with a directory path exports from that project."""
        project_dir = tmp_path / "my-project"
        layers_dir = project_dir / "layers"
        repo_dir = layers_dir / "repo"
        layer_dir = repo_dir / "meta"
        conf_dir = layer_dir / "conf"
        conf_dir.mkdir(parents=True)
        (conf_dir / "layer.conf").write_text("# layer\n")

        _init_git_repo(str(repo_dir))

        build_conf = project_dir / "conf"
        build_conf.mkdir()
        bblayers = build_conf / "bblayers.conf"
        bblayers.write_text(f'BBLAYERS = "{layer_dir}"\n')

        # Run from a different directory
        monkeypatch.chdir(tmp_path)

        output = str(tmp_path / "out.conf.json")
        args = argparse.Namespace(
            output=output, registry=False,
            layers_dir="layers", bblayers=None,
            project=str(project_dir),
        )
        rc = run_setup_export(args)
        assert rc == 0
        assert os.path.isfile(output)

    def test_export_with_project_not_found(self, tmp_path, monkeypatch):
        """--project with a nonexistent path returns error."""
        monkeypatch.chdir(tmp_path)
        args = argparse.Namespace(
            output=None, registry=False,
            layers_dir="layers", bblayers=None,
            project="/nonexistent/path",
        )
        rc = run_setup_export(args)
        assert rc == 1


class TestGatherExportSources:
    """Tests for _gather_export_sources helper."""

    def test_gathers_sources(self, tmp_path):
        """Gathers git remotes and branches from layer paths."""
        layers_dir = tmp_path / "layers"
        repo_dir = layers_dir / "my-repo"
        layer_dir = repo_dir / "meta"
        layer_dir.mkdir(parents=True)

        _init_git_repo(str(repo_dir), remote_url="https://example.com/r.git", branch="main")

        sources, git_roots = _gather_export_sources([str(layer_dir)], str(layers_dir))

        assert "my-repo" in sources
        assert sources["my-repo"]["git-remote"]["remotes"]["origin"]["uri"] == "https://example.com/r.git"
        assert len(git_roots) == 1

    def test_no_git_repos(self, tmp_path):
        """Returns empty when no git repos found."""
        layer_dir = tmp_path / "plain-layer"
        layer_dir.mkdir()

        sources, git_roots = _gather_export_sources([str(layer_dir)], str(tmp_path))
        assert sources == {}
        assert git_roots == {}


class TestWriteExport:
    """Tests for _write_export helper."""

    def test_writes_conf_json(self, tmp_path):
        """Writes a valid .conf.json file."""
        output = str(tmp_path / "test.conf.json")
        _write_export("myproject", {"repo": {"path": "repo"}},
                      ["repo/meta"], ["machine/qemu"], output)

        assert os.path.isfile(output)
        with open(output) as f:
            data = json.load(f)
        assert data["version"] == "1.0.0"
        assert data["sources"]["repo"]["path"] == "repo"
        configs = data["bitbake-setup"]["configurations"]
        assert configs[0]["oe-fragments"] == ["machine/qemu"]

    def test_writes_to_registry(self, tmp_path, monkeypatch):
        """to_registry=True copies file to registry dir."""
        fake_home = tmp_path / "home"
        monkeypatch.setattr(os.path, "expanduser", lambda p: p.replace("~", str(fake_home)))

        output = str(tmp_path / "test.conf.json")
        _write_export("proj", {}, [], [], output, to_registry=True)

        registry = fake_home / ".config" / "bit" / "registry" / "test.conf.json"
        assert registry.exists()


class TestGatherExportData:
    """Tests for gather_export_data function."""

    def test_returns_data(self, tmp_path, monkeypatch):
        """Returns dict with project info when valid project."""
        monkeypatch.chdir(tmp_path)

        layers_dir = tmp_path / "layers"
        repo_dir = layers_dir / "repo"
        layer_dir = repo_dir / "meta"
        conf_dir = layer_dir / "conf"
        conf_dir.mkdir(parents=True)
        (conf_dir / "layer.conf").write_text("# layer\n")

        _init_git_repo(str(repo_dir))

        build_conf = tmp_path / "conf"
        build_conf.mkdir()
        (build_conf / "bblayers.conf").write_text(f'BBLAYERS = "{layer_dir}"\n')

        data = gather_export_data(layers_dir="layers")
        assert data is not None
        assert data["project_name"] == os.path.basename(str(tmp_path))
        assert len(data["sources"]) == 1
        assert len(data["relative_layers"]) == 1
        assert isinstance(data["fragments"], list)

    def test_returns_none_no_bblayers(self, tmp_path, monkeypatch):
        """Returns None when no bblayers.conf found."""
        monkeypatch.chdir(tmp_path)
        assert gather_export_data() is None


class TestResolveProjectDir:
    """Tests for _resolve_project_dir helper."""

    def test_none_input(self):
        """Returns None when no project specified."""
        assert _resolve_project_dir(None) is None

    def test_direct_path(self, tmp_path):
        """Resolves a direct directory path."""
        result = _resolve_project_dir(str(tmp_path))
        assert result == str(tmp_path)

    def test_nonexistent_path(self):
        """Returns None for nonexistent path."""
        assert _resolve_project_dir("/nonexistent/path/xyz") is None

    def test_registered_name(self, tmp_path, monkeypatch):
        """Resolves a registered project name."""
        projects_data = {
            str(tmp_path): {"name": "my-build", "description": ""},
        }
        import bitbake_project.commands.projects as proj_mod
        monkeypatch.setattr(proj_mod, "load_projects", lambda: projects_data)

        result = _resolve_project_dir("my-build")
        assert result == str(tmp_path)
