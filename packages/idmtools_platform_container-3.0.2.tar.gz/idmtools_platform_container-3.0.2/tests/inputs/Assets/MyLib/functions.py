def add(a: int, b: int):
    return a + b
