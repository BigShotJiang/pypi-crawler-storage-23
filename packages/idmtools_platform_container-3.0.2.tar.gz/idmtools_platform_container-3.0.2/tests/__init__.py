from os.path import dirname, realpath, join

current_directory = dirname(realpath(__file__))
COMMON_INPUT_PATH = join(current_directory, "inputs")
