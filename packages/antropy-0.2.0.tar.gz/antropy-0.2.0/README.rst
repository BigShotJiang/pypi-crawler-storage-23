.. -*- mode: rst -*-

|

.. image:: https://badge.fury.io/py/antropy.svg
  :target: https://badge.fury.io/py/antropy

.. image:: https://img.shields.io/conda/vn/conda-forge/antropy.svg
  :target: https://anaconda.org/conda-forge/antropy

.. image:: https://img.shields.io/github/license/raphaelvallat/antropy.svg
  :target: https://github.com/raphaelvallat/antropy/blob/master/LICENSE

.. image:: https://github.com/raphaelvallat/antropy/actions/workflows/python_tests.yml/badge.svg
  :target: https://github.com/raphaelvallat/antropy/actions/workflows/python_tests.yml

.. image:: https://codecov.io/gh/raphaelvallat/antropy/branch/master/graph/badge.svg
  :target: https://codecov.io/gh/raphaelvallat/antropy

.. image:: https://static.pepy.tech/badge/antropy
  :target: https://pepy.tech/projects/antropy

.. image:: https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
  :target: https://github.com/astral-sh/ruff
  :alt: Ruff

----------------

.. figure:: https://raw.githubusercontent.com/raphaelvallat/antropy/master/docs/pictures/logo.png
   :align: center

**AntroPy** is a Python 3 package providing several time-efficient algorithms for computing
the complexity of time-series. It can be used for example to extract features from EEG signals.

- `Link to documentation <https://raphaelvallat.com/antropy/>`_

Installation
============

Dependencies
------------

AntroPy is a Python 3 package and is currently tested for Python 3.10+.

The main dependencies of AntroPy are:

* `NumPy <https://numpy.org/>`_ >= 1.22.4
* `SciPy <https://scipy.org/>`_ >= 1.8.0
* `scikit-learn <https://scikit-learn.org/>`_ >= 1.2.0
* `Numba <https://numba.readthedocs.io/>`_ >= 0.57

User installation
-----------------

AntroPy can be easily installed using `uv <https://docs.astral.sh/uv/>`_

.. code-block:: shell

  uv pip install antropy

pip

.. code-block:: shell

  pip install antropy

or conda

.. code-block:: shell

  conda install -c conda-forge antropy

Development
-----------

To build and install from source, clone this repository and install in editable mode with `uv <https://docs.astral.sh/uv/>`_

.. code-block:: shell

  git clone https://github.com/raphaelvallat/antropy.git
  cd antropy
  uv pip install --group=test --editable .

  # test the package
  pytest --verbose

Functions
=========

**Entropy**

.. code-block:: python

    import numpy as np
    import antropy as ant
    np.random.seed(1234567)
    x = np.random.normal(size=3000)
    # Permutation entropy
    print(ant.perm_entropy(x, normalize=True))
    # Spectral entropy
    print(ant.spectral_entropy(x, sf=100, method='welch', normalize=True))
    # Singular value decomposition entropy
    print(ant.svd_entropy(x, normalize=True))
    # Approximate entropy
    print(ant.app_entropy(x))
    # Sample entropy
    print(ant.sample_entropy(x))
    # Hjorth mobility and complexity
    print(ant.hjorth_params(x))
    # Number of zero-crossings
    print(ant.num_zerocross(x))
    # Lempel-Ziv complexity
    print(ant.lziv_complexity('01111000011001', normalize=True))

.. parsed-literal::

    0.9995371694290871
    0.9940882825422431
    0.9999110978316078
    2.015221318528564
    2.198595813245399
    (1.4313385010057378, 1.215335712274099)
    1531
    1.3597696150205727

**Fractal dimension**

.. code-block:: python

    # Petrosian fractal dimension
    print(ant.petrosian_fd(x))
    # Katz fractal dimension
    print(ant.katz_fd(x))
    # Higuchi fractal dimension
    print(ant.higuchi_fd(x))
    # Detrended fluctuation analysis
    print(ant.detrended_fluctuation(x))

.. parsed-literal::

    1.0310643385753608
    5.954272156665926
    2.005040632258251
    0.47903505674073327

Execution time
--------------

Here are some benchmarks computed on a MacBook Pro (2020).

.. code-block:: python

    import numpy as np
    import antropy as ant
    np.random.seed(1234567)
    x = np.random.rand(1000)
    # Entropy
    %timeit ant.perm_entropy(x)
    %timeit ant.spectral_entropy(x, sf=100)
    %timeit ant.svd_entropy(x)
    %timeit ant.app_entropy(x)  # Slow
    %timeit ant.sample_entropy(x)  # Numba
    # Fractal dimension
    %timeit ant.petrosian_fd(x)
    %timeit ant.katz_fd(x)
    %timeit ant.higuchi_fd(x) # Numba
    %timeit ant.detrended_fluctuation(x) # Numba

.. parsed-literal::

    106 µs ± 5.49 µs per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    138 µs ± 3.53 µs per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    40.7 µs ± 303 ns per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    2.44 ms ± 134 µs per loop (mean ± std. dev. of 7 runs, 100 loops each)
    2.21 ms ± 35.4 µs per loop (mean ± std. dev. of 7 runs, 100 loops each)
    23.5 µs ± 695 ns per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    40.1 µs ± 2.09 µs per loop (mean ± std. dev. of 7 runs, 10000 loops each)
    13.7 µs ± 251 ns per loop (mean ± std. dev. of 7 runs, 100000 loops each)
    315 µs ± 10.7 µs per loop (mean ± std. dev. of 7 runs, 1000 loops each)

Development
===========

AntroPy was created and is maintained by `Raphael Vallat <https://raphaelvallat.com>`_. Contributions are more than welcome so feel free to contact me, open an issue or submit a pull request!

To see the code or report a bug, please visit the `GitHub repository <https://github.com/raphaelvallat/antropy>`_.

Note that this program is provided with **NO WARRANTY OF ANY KIND**. Always double check the results.

Acknowledgement
===============

Several functions of AntroPy were adapted from:

- `MNE-features <https://github.com/mne-tools/mne-features>`_
- `pyEntropy <https://github.com/nikdon/pyEntropy>`_
- `pyrem <https://github.com/gilestrolab/pyrem>`_
- `nolds <https://github.com/CSchoel/nolds>`_

All the credit goes to the authors of these excellent packages.
