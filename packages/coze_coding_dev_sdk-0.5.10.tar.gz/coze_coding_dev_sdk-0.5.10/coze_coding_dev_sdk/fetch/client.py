from typing import Dict, Optional

from coze_coding_utils.runtime_ctx.context import Context
from cozeloop.decorator import observe

from ..core.client import BaseClient
from ..core.config import Config
from ..core.exceptions import APIError
from .models import (
    FetchContentItem,
    FetchDisplayInfo,
    FetchImage,
    FetchRequest,
    FetchResponse,
)


def _convert_content_item(item: dict) -> FetchContentItem:
    image_data = item.get("image")
    image = None
    if image_data:
        image = FetchImage(
            image_url=image_data.get("image_url"),
            display_url=image_data.get("display_url"),
            width=image_data.get("width"),
            height=image_data.get("height"),
            thumbnail_display_url=image_data.get("thumbnail_display_url"),
        )

    return FetchContentItem(
        type=item.get("type", "text"),
        text=item.get("text"),
        url=item.get("url"),
        image=image,
    )


def _convert_display_info(data: dict) -> FetchDisplayInfo:
    return FetchDisplayInfo(
        no_display=data.get("no_display"),
        no_display_reason=data.get("no_display_reason"),
    )


class FetchClient(BaseClient):
    def __init__(
        self,
        config: Optional[Config] = None,
        ctx: Optional[Context] = None,
        custom_headers: Optional[Dict[str, str]] = None,
        verbose: bool = False,
    ):
        super().__init__(config, ctx, custom_headers, verbose)
        self.base_url = self.config.base_url

    @observe(name="fetch_url")
    def fetch(self, url: str) -> FetchResponse:
        request = FetchRequest(url=url)

        response = self._request(
            method="POST",
            url=f"{self.base_url}/api/v1/integration/fetch_tool",
            json=request.model_dump(),
        )

        if response.get("code") and response.get("code") != 0:
            raise APIError(f"Fetch failed: {response.get('message', 'Unknown error')}")

        data = response.get("data", response)

        content_items = []
        if data.get("content"):
            content_items = [
                _convert_content_item(item) for item in data.get("content", [])
            ]

        display_info = None
        if data.get("display_info"):
            display_info = _convert_display_info(data.get("display_info"))

        return FetchResponse(
            fetch_id=data.get("fetch_id"),
            status_code=data.get("status_code"),
            status_message=data.get("status_message"),
            url=data.get("url"),
            doc_id=data.get("doc_id"),
            title=data.get("title"),
            publish_time=data.get("publish_time"),
            filetype=data.get("filetype"),
            content=content_items,
            display_info=display_info,
        )
