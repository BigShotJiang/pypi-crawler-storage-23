import json
from typing import Optional

import click
from coze_coding_utils.runtime_ctx.context import new_context
from rich.console import Console

from ..core.config import Config
from ..supabase import SupabaseClient
from .constants import RUN_MODE_HEADER, RUN_MODE_TEST

console = Console()


@click.group()
def supabase():
    """Supabase 管理命令，包括 Edge Functions、Storage Buckets 和 Auth 配置管理。"""
    pass


@supabase.group("func")
def func():
    """Edge Functions（边缘函数）管理命令。"""
    pass


@func.command("list")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def func_list(mock: bool, header: tuple, verbose: bool):
    """列出所有 Edge Functions。"""
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.func.list", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.list_functions()

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps([f.__dict__ for f in response.functions], indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@func.command("get")
@click.argument("slug", metavar="SLUG")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def func_get(slug: str, mock: bool, header: tuple, verbose: bool):
    """获取 Edge Function 详情和源码。

    SLUG: 函数标识符，即函数的唯一名称（如 'hello-world'），可通过 'func list' 命令查看所有函数的 slug。
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.func.get", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.get_function(slug)

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        result = {
            "function": response.function.__dict__ if response.function else None,
            "files": [f.__dict__ for f in response.files],
        }
        console.print(json.dumps(result, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@func.command("deploy")
@click.argument("slug", metavar="SLUG")
@click.option("--code", "-c", help="函数代码字符串（用于单文件函数），与 --file 二选一")
@click.option(
    "--file",
    "-f",
    "files",
    multiple=True,
    nargs=2,
    type=str,
    help="文件名和内容对（可多次使用），格式：--file <文件名> <内容>，例如：--file index.ts 'Deno.serve(...)'",
)
@click.option("--name", "-n", help="函数显示名称，用于在控制台中展示")
@click.option("--entrypoint", "-e", help="入口文件名称，多文件部署时必需，指定主入口文件（如 'index.ts'）")
@click.option("--verify-jwt/--no-verify-jwt", default=None, help="启用/禁用 JWT 验证，启用后调用函数需要携带有效的 JWT token")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def func_deploy(
    slug: str,
    code: Optional[str],
    files: tuple,
    name: Optional[str],
    entrypoint: Optional[str],
    verify_jwt: Optional[bool],
    mock: bool,
    header: tuple,
    verbose: bool,
):
    """部署或更新 Edge Function。

    SLUG: 函数标识符，即函数的唯一名称（如 'hello-world'），只能包含小写字母、数字和连字符。
    如果函数已存在则更新，不存在则创建新函数。

    \b
    示例：
      # 单文件部署
      coze-coding-ai supabase func deploy my-func --code 'Deno.serve(() => new Response("Hello"))'

      # 多文件部署
      coze-coding-ai supabase func deploy my-func \\
        --file index.ts 'import { handler } from "./handler.ts"; Deno.serve(handler)' \\
        --file handler.ts 'export const handler = () => new Response("Hello")' \\
        --entrypoint index.ts
    """
    try:
        from .utils import parse_headers

        files_list = None
        if files:
            files_list = [{"name": f[0], "content": f[1]} for f in files]

        if not code and not files_list:
            console.print("[red]Error: 必须提供 --code 或 --file 参数[/red]")
            return

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.func.deploy", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.deploy_function(
            slug=slug,
            code=code,
            files=files_list,
            name=name,
            entrypoint=entrypoint,
            verify_jwt=verify_jwt,
        )

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        result = {
            "success": response.success,
            "slug": response.slug,
            "version": response.version,
        }
        console.print(json.dumps(result, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@func.command("delete")
@click.argument("slug", metavar="SLUG")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def func_delete(slug: str, mock: bool, header: tuple, verbose: bool):
    """删除 Edge Function。

    SLUG: 函数标识符，即函数的唯一名称（如 'hello-world'），可通过 'func list' 命令查看所有函数的 slug。

    ⚠️ 警告：此操作不可逆，删除后函数将无法恢复。
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.func.delete", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.delete_function(slug)

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps({"success": response.success}, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@supabase.group("bucket")
def bucket():
    """Storage Buckets（存储桶）管理命令。"""
    pass


@bucket.command("list")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def bucket_list(mock: bool, header: tuple, verbose: bool):
    """列出所有 Storage Buckets。"""
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.bucket.list", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.list_buckets()

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps([b.__dict__ for b in response.buckets], indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@bucket.command("get")
@click.argument("bucket_id", metavar="BUCKET_ID")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def bucket_get(bucket_id: str, mock: bool, header: tuple, verbose: bool):
    """获取 Storage Bucket 详情。

    BUCKET_ID: 存储桶 ID，即存储桶的唯一标识符（如 'avatars'），可通过 'bucket list' 命令查看所有存储桶的 ID。
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.bucket.get", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.get_bucket(bucket_id)

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps(response.bucket.__dict__ if response.bucket else None, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@bucket.command("create")
@click.argument("bucket_id", metavar="BUCKET_ID")
@click.option("--name", "-n", help="存储桶显示名称，用于在控制台中展示")
@click.option("--public/--private", default=None, help="设置存储桶访问权限：--public 公开访问，--private 私有访问")
@click.option("--file-size-limit", type=int, help="单个文件大小限制（字节），例如 10485760 表示 10MB")
@click.option("--allowed-mime-types", help="允许上传的文件 MIME 类型（逗号分隔），例如 'image/png,image/jpeg'")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def bucket_create(
    bucket_id: str,
    name: Optional[str],
    public: Optional[bool],
    file_size_limit: Optional[int],
    allowed_mime_types: Optional[str],
    mock: bool,
    header: tuple,
    verbose: bool,
):
    """创建新的 Storage Bucket。

    BUCKET_ID: 存储桶 ID，即存储桶的唯一标识符，只能包含小写字母、数字和连字符（如 'user-avatars'）。

    \b
    示例：
      coze-coding-ai supabase bucket create my-bucket --name "My Bucket" --public
      coze-coding-ai supabase bucket create images --public --file-size-limit 10485760 --allowed-mime-types "image/png,image/jpeg"
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.bucket.create", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        mime_types = None
        if allowed_mime_types:
            mime_types = [t.strip() for t in allowed_mime_types.split(",")]

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.create_bucket(
            bucket_id=bucket_id,
            name=name,
            public=public,
            file_size_limit=file_size_limit,
            allowed_mime_types=mime_types,
        )

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        result = {"success": response.success, "bucket_id": response.bucket_id}
        console.print(json.dumps(result, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@bucket.command("update")
@click.argument("bucket_id", metavar="BUCKET_ID")
@click.option("--public/--private", default=None, help="设置存储桶访问权限：--public 公开访问，--private 私有访问")
@click.option("--file-size-limit", type=int, help="单个文件大小限制（字节），例如 10485760 表示 10MB")
@click.option("--allowed-mime-types", help="允许上传的文件 MIME 类型（逗号分隔），例如 'image/png,image/jpeg'")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def bucket_update(
    bucket_id: str,
    public: Optional[bool],
    file_size_limit: Optional[int],
    allowed_mime_types: Optional[str],
    mock: bool,
    header: tuple,
    verbose: bool,
):
    """更新 Storage Bucket 配置。

    BUCKET_ID: 存储桶 ID，即存储桶的唯一标识符（如 'avatars'），可通过 'bucket list' 命令查看所有存储桶的 ID。
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.bucket.update", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        mime_types = None
        if allowed_mime_types:
            mime_types = [t.strip() for t in allowed_mime_types.split(",")]

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.update_bucket(
            bucket_id=bucket_id,
            public=public,
            file_size_limit=file_size_limit,
            allowed_mime_types=mime_types,
        )

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps({"success": response.success}, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@bucket.command("delete")
@click.argument("bucket_id", metavar="BUCKET_ID")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def bucket_delete(bucket_id: str, mock: bool, header: tuple, verbose: bool):
    """删除 Storage Bucket。

    BUCKET_ID: 存储桶 ID，即存储桶的唯一标识符（如 'avatars'），可通过 'bucket list' 命令查看所有存储桶的 ID。

    ⚠️ 警告：此操作不可逆，删除后存储桶及其中的所有文件将无法恢复。
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.bucket.delete", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.delete_bucket(bucket_id)

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps({"success": response.success}, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@supabase.group("auth")
def auth():
    """Auth（认证配置）管理命令。"""
    pass


@auth.command("get-config")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def auth_get_config(mock: bool, header: tuple, verbose: bool):
    """获取 Auth 认证配置，包括邮箱认证、SMTP 等设置。"""
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.auth.get_config", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.get_auth_config()

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps(response.config.__dict__ if response.config else None, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()


@auth.command("update-config")
@click.option("--site-url", help="站点 URL，用于邮件中的链接跳转地址（如 'https://myapp.com'）")
@click.option("--disable-signup/--enable-signup", default=None, help="禁用/启用用户自助注册功能")
@click.option("--external-email-enabled/--external-email-disabled", default=None, help="启用/禁用邮箱认证方式")
@click.option("--mailer-autoconfirm/--no-mailer-autoconfirm", default=None, help="启用/禁用邮箱自动确认（跳过邮件验证）")
@click.option("--double-confirm-changes/--no-double-confirm-changes", default=None, help="启用/禁用敏感操作的双重确认")
@click.option("--mailer-secure-email-change-enabled/--mailer-secure-email-change-disabled", default=None, help="启用/禁用安全邮箱更改流程")
@click.option("--mailer-otp-exp", type=int, help="OTP 验证码过期时间（秒），例如 3600 表示 1 小时")
@click.option("--password-min-length", type=int, help="用户密码最小长度要求，例如 8")
@click.option("--password-required-characters", help="密码必需包含的字符类型，例如 'abcABC123'")
@click.option("--smtp-host", help="SMTP 邮件服务器地址，例如 'smtp.sendgrid.net'")
@click.option("--smtp-port", type=int, help="SMTP 邮件服务器端口，例如 587")
@click.option("--smtp-user", help="SMTP 认证用户名")
@click.option("--smtp-pass", help="SMTP 认证密码或 API Key")
@click.option("--smtp-admin-email", help="发件人邮箱地址，例如 'noreply@myapp.com'")
@click.option("--smtp-sender-name", help="发件人显示名称，例如 'My App'")
@click.option("--smtp-max-frequency", type=int, help="同一邮箱的最小发送间隔（秒），用于防止滥用")
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def auth_update_config(
    site_url: Optional[str],
    disable_signup: Optional[bool],
    external_email_enabled: Optional[bool],
    mailer_autoconfirm: Optional[bool],
    double_confirm_changes: Optional[bool],
    mailer_secure_email_change_enabled: Optional[bool],
    mailer_otp_exp: Optional[int],
    password_min_length: Optional[int],
    password_required_characters: Optional[str],
    smtp_host: Optional[str],
    smtp_port: Optional[int],
    smtp_user: Optional[str],
    smtp_pass: Optional[str],
    smtp_admin_email: Optional[str],
    smtp_sender_name: Optional[str],
    smtp_max_frequency: Optional[int],
    mock: bool,
    header: tuple,
    verbose: bool,
):
    """更新 Auth 认证配置。

    至少需要提供一个配置项。更新 SMTP 配置后建议测试邮件发送功能。

    \b
    示例：
      # 更新站点 URL 和启用注册
      coze-coding-ai supabase auth update-config --site-url "https://myapp.com" --enable-signup

      # 配置 SMTP 邮件服务
      coze-coding-ai supabase auth update-config \\
        --smtp-host "smtp.sendgrid.net" \\
        --smtp-port 587 \\
        --smtp-user "apikey" \\
        --smtp-pass "SG.xxx" \\
        --smtp-admin-email "noreply@myapp.com" \\
        --smtp-sender-name "My App"
    """
    try:
        from .utils import parse_headers

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="supabase.auth.update_config", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        auth_config = {}
        if site_url is not None:
            auth_config["site_url"] = site_url
        if disable_signup is not None:
            auth_config["disable_signup"] = disable_signup
        if external_email_enabled is not None:
            auth_config["external_email_enabled"] = external_email_enabled
        if mailer_autoconfirm is not None:
            auth_config["mailer_autoconfirm"] = mailer_autoconfirm
        if double_confirm_changes is not None:
            auth_config["double_confirm_changes"] = double_confirm_changes
        if mailer_secure_email_change_enabled is not None:
            auth_config["mailer_secure_email_change_enabled"] = mailer_secure_email_change_enabled
        if mailer_otp_exp is not None:
            auth_config["mailer_otp_exp"] = mailer_otp_exp
        if password_min_length is not None:
            auth_config["password_min_length"] = password_min_length
        if password_required_characters is not None:
            auth_config["password_required_characters"] = password_required_characters
        if smtp_host is not None:
            auth_config["smtp_host"] = smtp_host
        if smtp_port is not None:
            auth_config["smtp_port"] = smtp_port
        if smtp_user is not None:
            auth_config["smtp_user"] = smtp_user
        if smtp_pass is not None:
            auth_config["smtp_pass"] = smtp_pass
        if smtp_admin_email is not None:
            auth_config["smtp_admin_email"] = smtp_admin_email
        if smtp_sender_name is not None:
            auth_config["smtp_sender_name"] = smtp_sender_name
        if smtp_max_frequency is not None:
            auth_config["smtp_max_frequency"] = smtp_max_frequency

        if not auth_config:
            console.print("[red]Error: 至少需要提供一个配置项[/red]")
            return

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.update_auth_config(auth_config)

        if response.code != 0:
            console.print(f"[red]Error: {response.msg}[/red]")
            return

        console.print(json.dumps({"success": response.success}, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()
