import json
import os
import sys
from typing import Optional

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from ..document import (
    DocumentGenerationClient,
    DocumentFormat,
    DOCXConfig,
    PDFConfig,
    PPTXConfig,
    XLSXConfig,
)

console = Console()


@click.group()
def document():
    """Document generation commands (PDF, DOCX, PPTX, XLSX)."""
    pass


@document.command("pdf")
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), help="输入文件路径（Markdown 或 HTML）")
@click.option("--content", "-c", help="直接输入内容（Markdown 或 HTML）")
@click.option("--title", "-t", required=True, help="文档标题（用于生成文件名）")
@click.option("--format", "-f", "content_format", type=click.Choice(["markdown", "html"]), default="markdown", help="内容格式")
@click.option("--page-size", type=click.Choice(["A4", "LETTER"]), default="A4", help="页面尺寸")
def pdf(
    input_file: Optional[str],
    content: Optional[str],
    title: str,
    content_format: str,
    page_size: str,
):
    """从 Markdown 或 HTML 生成 PDF 文件，上传至 S3 并返回下载链接。"""
    try:
        if not input_file and not content:
            if not sys.stdin.isatty():
                content = sys.stdin.read()
            else:
                raise click.UsageError("必须提供 --input 或 --content 参数，或通过管道输入内容")

        if input_file:
            with open(input_file, "r", encoding="utf-8") as f:
                content = f.read()

        config = PDFConfig(page_size=page_size)
        client = DocumentGenerationClient(pdf_config=config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]生成 PDF...", total=None)

            if content_format == "markdown":
                result = client.create_pdf_from_markdown(content, title)
            else:
                result = client.create_pdf_from_html(content, title)

            progress.update(task, description="[green]✓ PDF 生成完成!")

        console.print(f"[green]✓[/green] PDF 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@document.command("docx")
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), help="输入文件路径（Markdown 或 HTML）")
@click.option("--content", "-c", help="直接输入内容（Markdown 或 HTML）")
@click.option("--title", "-t", required=True, help="文档标题（用于生成文件名）")
@click.option("--format", "-f", "content_format", type=click.Choice(["markdown", "html"]), default="markdown", help="内容格式")
@click.option("--font", default="Noto Sans CJK SC", help="字体名称")
@click.option("--font-size", type=int, default=11, help="字体大小（点）")
def docx(
    input_file: Optional[str],
    content: Optional[str],
    title: str,
    content_format: str,
    font: str,
    font_size: int,
):
    """从 Markdown 或 HTML 生成 DOCX 文件，上传至 S3 并返回下载链接。"""
    try:
        if not input_file and not content:
            if not sys.stdin.isatty():
                content = sys.stdin.read()
            else:
                raise click.UsageError("必须提供 --input 或 --content 参数，或通过管道输入内容")

        if input_file:
            with open(input_file, "r", encoding="utf-8") as f:
                content = f.read()

        config = DOCXConfig(font_name=font, font_size=font_size)
        client = DocumentGenerationClient(docx_config=config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]生成 DOCX...", total=None)

            if content_format == "markdown":
                result = client.create_docx_from_markdown(content, title)
            else:
                result = client.create_docx_from_html(content, title)

            progress.update(task, description="[green]✓ DOCX 生成完成!")

        console.print(f"[green]✓[/green] DOCX 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@document.group("pptx")
def pptx():
    """PPTX 文档操作命令组（生成、提取清单、替换文本、重排幻灯片）。"""
    pass


@pptx.command("create")
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), help="输入文件路径（Markdown 或 HTML）")
@click.option("--content", "-c", help="直接输入内容（Markdown 或 HTML）")
@click.option("--title", "-t", required=True, help="文档标题（用于生成文件名）")
@click.option("--format", "-f", "content_format", type=click.Choice(["markdown", "html"]), default="markdown", help="内容格式")
def pptx_create(
    input_file: Optional[str],
    content: Optional[str],
    title: str,
    content_format: str,
):
    """从 Markdown 或 HTML 生成 PPTX 文件，上传至 S3 并返回下载链接。"""
    try:
        if not input_file and not content:
            if not sys.stdin.isatty():
                content = sys.stdin.read()
            else:
                raise click.UsageError("必须提供 --input 或 --content 参数，或通过管道输入内容")

        if input_file:
            with open(input_file, "r", encoding="utf-8") as f:
                content = f.read()

        client = DocumentGenerationClient()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]生成 PPTX...", total=None)

            if content_format == "markdown":
                result = client.create_pptx_from_markdown(content, title)
            else:
                result = client.create_pptx_from_html(content, title)

            progress.update(task, description="[green]✓ PPTX 生成完成!")

        console.print(f"[green]✓[/green] PPTX 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@pptx.command("inventory")
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True), help="输入 PPTX 文件路径")
@click.option("--output", "-o", "output_file", type=click.Path(), help="输出 JSON 文件路径（可选，默认输出到控制台）")
@click.option("--issues-only", is_flag=True, help="仅显示有问题的形状（溢出或重叠）")
def pptx_inventory(
    input_file: str,
    output_file: Optional[str],
    issues_only: bool,
):
    """提取 PPTX 文件的文本清单，检测溢出和重叠问题。"""
    try:
        client = DocumentGenerationClient()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]提取清单...", total=None)

            inventory = client.get_pptx_inventory(input_file, issues_only=issues_only)

            progress.update(task, description="[green]✓ 清单提取完成!")

        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(inventory, f, ensure_ascii=False, indent=2)
            console.print(f"[green]✓[/green] 清单已保存至: [bold]{output_file}[/bold]")
        else:
            console.print_json(data=inventory)

        total_shapes = sum(len(shapes) for shapes in inventory.values())
        issues_count = sum(
            1 for shapes in inventory.values()
            for shape in shapes.values()
            if (shape.get("overflow") or shape.get("overlap") or shape.get("warnings"))
        )

        table = Table(title="清单统计")
        table.add_column("属性", style="cyan")
        table.add_column("值", style="green")
        table.add_row("幻灯片数", str(len(inventory)))
        table.add_row("形状总数", str(total_shapes))
        table.add_row("问题数", str(issues_count))
        console.print(table)

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@pptx.command("replace")
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True), help="输入 PPTX 文件路径")
@click.option("--replacements", "-r", "replacements_file", required=True, type=click.Path(exists=True), help="替换内容 JSON 文件路径")
@click.option("--title", "-t", required=True, help="输出文档标题（用于生成文件名）")
@click.option("--no-validate", is_flag=True, help="跳过溢出验证")
def pptx_replace(
    input_file: str,
    replacements_file: str,
    title: str,
    no_validate: bool,
):
    """替换 PPTX 文件中的文本内容，保留原有格式，上传至 S3 并返回下载链接。"""
    try:
        with open(replacements_file, "r", encoding="utf-8") as f:
            replacements = json.load(f)

        client = DocumentGenerationClient()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]替换文本...", total=None)

            result = client.replace_pptx_text(
                input_file, replacements, title, validate_overflow=not no_validate
            )

            progress.update(task, description="[green]✓ 文本替换完成!")

        console.print(f"[green]✓[/green] PPTX 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@pptx.command("rearrange")
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True), help="输入 PPTX 模板文件路径")
@click.option("--title", "-t", required=True, help="输出文档标题（用于生成文件名）")
@click.option("--sequence", "-s", required=True, help="幻灯片序列（逗号分隔的索引，如 0,2,1,3,2）")
def pptx_rearrange(
    input_file: str,
    title: str,
    sequence: str,
):
    """重排 PPTX 幻灯片顺序（支持复制和删除），上传至 S3 并返回下载链接。"""
    try:
        slide_sequence = [int(x.strip()) for x in sequence.split(",")]

        client = DocumentGenerationClient()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]重排幻灯片...", total=None)

            result = client.rearrange_pptx_slides(input_file, title, slide_sequence)

            progress.update(task, description="[green]✓ 幻灯片重排完成!")

        console.print(f"[green]✓[/green] PPTX 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@document.command("xlsx")
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), help="输入 JSON 文件路径")
@click.option("--content", "-c", help="直接输入 JSON 内容")
@click.option("--title", "-t", required=True, help="文档标题（用于生成文件名）")
@click.option("--sheet-name", default="Sheet1", help="工作表名称")
@click.option("--header-color", default="D9E1F2", help="表头背景颜色（十六进制）")
def xlsx(
    input_file: Optional[str],
    content: Optional[str],
    title: str,
    sheet_name: str,
    header_color: str,
):
    """从 JSON 数据生成 XLSX 文件，上传至 S3 并返回下载链接。
    
    JSON 格式支持：
    - 字典列表: [{"col1": "val1", "col2": "val2"}, ...]
    - 二维列表: [["header1", "header2"], ["val1", "val2"], ...]
    """
    try:
        if not input_file and not content:
            if not sys.stdin.isatty():
                content = sys.stdin.read()
            else:
                raise click.UsageError("必须提供 --input 或 --content 参数，或通过管道输入内容")

        if input_file:
            with open(input_file, "r", encoding="utf-8") as f:
                content = f.read()

        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            raise click.UsageError(f"JSON 解析错误: {e}")

        if not isinstance(data, list):
            raise click.UsageError("JSON 数据必须是列表格式")

        config = XLSXConfig(header_bg_color=header_color)
        client = DocumentGenerationClient(xlsx_config=config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]生成 XLSX...", total=None)

            result = client.create_xlsx(data, title, sheet_name)

            progress.update(task, description="[green]✓ XLSX 生成完成!")

        console.print(f"[green]✓[/green] XLSX 下载链接: [bold]{result}[/bold]")

        table = Table(title="生成结果")
        table.add_column("属性", style="cyan")
        table.add_column("值", style="green")
        table.add_row("行数", str(len(data)))
        if data and isinstance(data[0], dict):
            table.add_row("列数", str(len(data[0])))
            table.add_row("列名", ", ".join(data[0].keys()))
        elif data and isinstance(data[0], list):
            table.add_row("列数", str(len(data[0])))
        console.print(table)

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()


@document.command("convert")
@click.option("--input", "-i", "input_file", required=True, type=click.Path(exists=True), help="输入文件路径")
@click.option("--title", "-t", required=True, help="文档标题（用于生成文件名）")
@click.option("--from", "from_format", type=click.Choice(["markdown", "html"]), default="markdown", help="输入格式")
@click.option("--to", "to_format", type=click.Choice(["pdf", "docx", "pptx"]), required=True, help="输出格式")
def convert(
    input_file: str,
    title: str,
    from_format: str,
    to_format: str,
):
    """通用文档格式转换命令，上传至 S3 并返回下载链接。"""
    try:
        with open(input_file, "r", encoding="utf-8") as f:
            content = f.read()

        client = DocumentGenerationClient()

        format_map = {
            "pdf": DocumentFormat.PDF,
            "docx": DocumentFormat.DOCX,
            "pptx": DocumentFormat.PPTX,
        }

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"[cyan]转换为 {to_format.upper()}...", total=None)

            result = client.generate(
                content=content,
                title=title,
                format=format_map[to_format],
                content_type=from_format,
            )

            progress.update(task, description=f"[green]✓ {to_format.upper()} 生成完成!")

        console.print(f"[green]✓[/green] 下载链接: [bold]{result}[/bold]")

    except Exception as e:
        console.print(f"[red]✗ 错误: {str(e)}[/red]")
        raise click.Abort()
