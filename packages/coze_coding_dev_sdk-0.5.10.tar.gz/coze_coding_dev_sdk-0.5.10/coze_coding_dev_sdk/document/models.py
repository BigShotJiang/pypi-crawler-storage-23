import os
from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, Field


class DocumentFormat(str, Enum):
    PDF = "pdf"
    DOCX = "docx"
    PPTX = "pptx"
    XLSX = "xlsx"


class DocumentConfig:
    DEFAULT_FONT_NAME = "Noto Sans CJK SC"
    CJK_FONT_ENV_KEY = "DOCGEN_CJK_FONT"
    CJK_FONT_NAME_ENV_KEY = "DOCGEN_CJK_FONT_NAME"

    @classmethod
    def get_cjk_font_path(cls) -> Optional[str]:
        return os.environ.get(cls.CJK_FONT_ENV_KEY)

    @classmethod
    def get_cjk_font_name(cls) -> str:
        return os.environ.get(cls.CJK_FONT_NAME_ENV_KEY, cls.DEFAULT_FONT_NAME)


class PDFConfig(BaseModel):
    page_size: Literal["A4", "LETTER"] = Field(default="A4", description="页面尺寸")
    left_margin: int = Field(default=72, description="左边距（点）")
    right_margin: int = Field(default=72, description="右边距（点）")
    top_margin: int = Field(default=72, description="上边距（点）")
    bottom_margin: int = Field(default=18, description="下边距（点）")


class DOCXConfig(BaseModel):
    font_name: str = Field(
        default_factory=DocumentConfig.get_cjk_font_name,
        description="字体名称"
    )
    font_size: int = Field(default=11, description="字体大小（点）")
    top_margin: float = Field(default=0.75, description="上边距（英寸）")
    bottom_margin: float = Field(default=0.75, description="下边距（英寸）")
    left_margin: float = Field(default=0.75, description="左边距（英寸）")
    right_margin: float = Field(default=0.75, description="右边距（英寸）")


class PPTXConfig(BaseModel):
    slide_width: float = Field(default=10.0, description="幻灯片宽度（英寸）")
    slide_height: float = Field(default=7.5, description="幻灯片高度（英寸）")


class XLSXConfig(BaseModel):
    header_bg_color: str = Field(default="D9E1F2", description="表头背景颜色（十六进制）")
    auto_width: bool = Field(default=True, description="是否自动调整列宽")


class TextStyle(BaseModel):
    font_size: Optional[float] = Field(default=None, description="字体大小（点）")
    color: Optional[str] = Field(default=None, description="颜色（十六进制）")
    align: Literal["left", "center", "right"] = Field(default="left", description="对齐方式")
    bold: bool = Field(default=False, description="是否加粗")
    italic: bool = Field(default=False, description="是否斜体")
    underline: bool = Field(default=False, description="是否下划线")


class ShapeStyle(BaseModel):
    fill_color: Optional[str] = Field(default=None, description="填充颜色（十六进制）")
    line_color: Optional[str] = Field(default=None, description="边框颜色（十六进制）")
    line_width: Optional[float] = Field(default=None, description="边框宽度（点）")


class SlideElement(BaseModel):
    element_type: Literal["text", "image", "shape", "list"] = Field(
        ..., description="元素类型"
    )
    x: float = Field(default=0, description="X 坐标（英寸）")
    y: float = Field(default=0, description="Y 坐标（英寸）")
    width: float = Field(default=1, description="宽度（英寸）")
    height: float = Field(default=1, description="高度（英寸）")
    content: Optional[str] = Field(default=None, description="文本内容或图片路径")
    style: Optional[TextStyle] = Field(default=None, description="文本样式")
    shape_style: Optional[ShapeStyle] = Field(default=None, description="形状样式")
    items: Optional[list] = Field(default=None, description="列表项（用于 list 类型）")


class SlideData(BaseModel):
    background_color: Optional[str] = Field(default=None, description="背景颜色（十六进制）")
    elements: list[SlideElement] = Field(default_factory=list, description="幻灯片元素")
