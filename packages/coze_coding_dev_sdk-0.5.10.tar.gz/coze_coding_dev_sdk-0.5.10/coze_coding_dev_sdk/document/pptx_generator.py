import io
import logging
import os
import platform
import re
import tempfile
import uuid
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import cssutils
import markdown
import requests
import six
from bs4 import BeautifulSoup
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls
from pptx.oxml.xmlchemy import OxmlElement
from pptx.shapes.base import BaseShape
from pptx.util import Inches, Pt

from .models import PPTXConfig
from ..s3 import S3SyncStorage

cssutils.log.setLevel(logging.CRITICAL)

logger = logging.getLogger(__name__)

JsonValue = Union[str, int, float, bool, None]
ParagraphDict = Dict[str, JsonValue]
ShapeDict = Dict[str, Union[str, float, bool, List[ParagraphDict], List[str], Dict[str, Any], None]]
InventoryData = Dict[str, Dict[str, "ShapeData"]]
InventoryDict = Dict[str, Dict[str, ShapeDict]]

PT_PER_PX = 0.75
PX_PER_IN = 96

SHAPE_TYPE_MAP = {
    "RECTANGLE": MSO_SHAPE.RECTANGLE,
    "RECT": MSO_SHAPE.RECTANGLE,
    "OVAL": MSO_SHAPE.OVAL,
    "CIRCLE": MSO_SHAPE.OVAL,
    "ELLIPSE": MSO_SHAPE.OVAL,
    "ROUNDED_RECTANGLE": MSO_SHAPE.ROUNDED_RECTANGLE,
    "ROUNDED_RECT": MSO_SHAPE.ROUNDED_RECTANGLE,
    "ROUND_RECT": MSO_SHAPE.ROUNDED_RECTANGLE,
    "TRIANGLE": MSO_SHAPE.ISOSCELES_TRIANGLE,
    "ISOSCELES_TRIANGLE": MSO_SHAPE.ISOSCELES_TRIANGLE,
    "RIGHT_TRIANGLE": MSO_SHAPE.RIGHT_TRIANGLE,
    "DIAMOND": MSO_SHAPE.DIAMOND,
    "PARALLELOGRAM": MSO_SHAPE.PARALLELOGRAM,
    "TRAPEZOID": MSO_SHAPE.TRAPEZOID,
    "PENTAGON": MSO_SHAPE.PENTAGON,
    "HEXAGON": MSO_SHAPE.HEXAGON,
    "HEPTAGON": MSO_SHAPE.HEPTAGON,
    "OCTAGON": MSO_SHAPE.OCTAGON,
    "DECAGON": MSO_SHAPE.DECAGON,
    "DODECAGON": MSO_SHAPE.DODECAGON,
    "STAR": MSO_SHAPE.STAR_5_POINT,
    "STAR_4": MSO_SHAPE.STAR_4_POINT,
    "STAR_5": MSO_SHAPE.STAR_5_POINT,
    "STAR_6": MSO_SHAPE.STAR_6_POINT,
    "STAR_8": MSO_SHAPE.STAR_8_POINT,
    "STAR_16": MSO_SHAPE.STAR_16_POINT,
    "STAR_24": MSO_SHAPE.STAR_24_POINT,
    "STAR_32": MSO_SHAPE.STAR_32_POINT,
    "ARROW": MSO_SHAPE.RIGHT_ARROW,
    "ARROW_RIGHT": MSO_SHAPE.RIGHT_ARROW,
    "ARROW_LEFT": MSO_SHAPE.LEFT_ARROW,
    "ARROW_UP": MSO_SHAPE.UP_ARROW,
    "ARROW_DOWN": MSO_SHAPE.DOWN_ARROW,
    "ARROW_LEFT_RIGHT": MSO_SHAPE.LEFT_RIGHT_ARROW,
    "ARROW_UP_DOWN": MSO_SHAPE.UP_DOWN_ARROW,
    "CHEVRON": MSO_SHAPE.CHEVRON,
    "HEART": MSO_SHAPE.HEART,
    "LIGHTNING_BOLT": MSO_SHAPE.LIGHTNING_BOLT,
    "SUN": MSO_SHAPE.SUN,
    "MOON": MSO_SHAPE.MOON,
    "CLOUD": MSO_SHAPE.CLOUD,
    "ARC": MSO_SHAPE.ARC,
    "DONUT": MSO_SHAPE.DONUT,
    "CROSS": MSO_SHAPE.CROSS,
    "PLUS": MSO_SHAPE.CROSS,
    "CUBE": MSO_SHAPE.CUBE,
    "CAN": MSO_SHAPE.CAN,
    "CYLINDER": MSO_SHAPE.CAN,
    "BEVEL": MSO_SHAPE.BEVEL,
    "FRAME": MSO_SHAPE.FRAME,
    "PLAQUE": MSO_SHAPE.PLAQUE,
    "FLOWCHART_PROCESS": MSO_SHAPE.FLOWCHART_PROCESS,
    "FLOWCHART_DECISION": MSO_SHAPE.FLOWCHART_DECISION,
    "FLOWCHART_DATA": MSO_SHAPE.FLOWCHART_DATA,
    "FLOWCHART_TERMINATOR": MSO_SHAPE.FLOWCHART_TERMINATOR,
    "CALLOUT": MSO_SHAPE.RECTANGULAR_CALLOUT,
    "CALLOUT_RECT": MSO_SHAPE.RECTANGULAR_CALLOUT,
    "CALLOUT_ROUNDED": MSO_SHAPE.ROUNDED_RECTANGULAR_CALLOUT,
    "CALLOUT_OVAL": MSO_SHAPE.OVAL_CALLOUT,
    "CALLOUT_CLOUD": MSO_SHAPE.CLOUD_CALLOUT,
    "LINE_CALLOUT": MSO_SHAPE.LINE_CALLOUT_1,
    "EXPLOSION": MSO_SHAPE.EXPLOSION1,
    "EXPLOSION1": MSO_SHAPE.EXPLOSION1,
    "EXPLOSION2": MSO_SHAPE.EXPLOSION2,
    "NO_SYMBOL": MSO_SHAPE.NO_SYMBOL,
    "BLOCK_ARC": MSO_SHAPE.BLOCK_ARC,
    "SMILEY_FACE": MSO_SHAPE.SMILEY_FACE,
}


def px_to_inch(px: float) -> float:
    return float(px) / PX_PER_IN


def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join([c * 2 for c in hex_color])
    return (
        int(hex_color[0:2], 16),
        int(hex_color[2:4], 16),
        int(hex_color[4:6], 16),
    )


def px_to_points(px_str: str) -> float:
    if not px_str:
        return 0
    px_str = str(px_str).strip()
    match = re.match(r"^([\d.]+)", px_str)
    if not match:
        return 0
    try:
        return float(match.group(1)) * PT_PER_PX
    except ValueError:
        return 0


def parse_color(color_str: str) -> Tuple[Optional[str], float]:
    if not color_str or color_str == "transparent":
        return None, 0

    color_str = color_str.replace(" ", "").lower()

    if color_str.startswith("#"):
        hex_val = color_str[1:]
        if len(hex_val) == 3:
            hex_val = "".join([c * 2 for c in hex_val])
        return hex_val, 1.0

    if color_str.startswith("rgb"):
        match = re.match(r"rgba?\((\d+),(\d+),(\d+)(?:,([\d.]+))?\)", color_str)
        if match:
            r, g, b = map(int, match.group(1, 2, 3))
            a = float(match.group(4)) if match.group(4) else 1.0
            hex_val = "{:02x}{:02x}{:02x}".format(r, g, b)
            return hex_val, a

    colors = {
        "black": "000000",
        "white": "ffffff",
        "red": "ff0000",
        "green": "008000",
        "blue": "0000ff",
        "yellow": "ffff00",
    }
    if color_str in colors:
        return colors[color_str], 1.0

    return "000000", 1.0


def get_style_map(element) -> Dict[str, str]:
    style_map = {}
    if element.has_attr("style"):
        try:
            style = cssutils.parseStyle(element["style"])
            for prop in style:
                style_map[prop.name] = prop.value
        except Exception:
            pass
    return style_map


@dataclass
class ShapeWithPosition:
    shape: BaseShape
    absolute_left: int
    absolute_top: int


class ParagraphData:
    def __init__(self, paragraph: Any):
        self.text: str = paragraph.text.strip()
        self.bullet: bool = False
        self.level: Optional[int] = None
        self.alignment: Optional[str] = None
        self.space_before: Optional[float] = None
        self.space_after: Optional[float] = None
        self.font_name: Optional[str] = None
        self.font_size: Optional[float] = None
        self.bold: Optional[bool] = None
        self.italic: Optional[bool] = None
        self.underline: Optional[bool] = None
        self.color: Optional[str] = None
        self.theme_color: Optional[str] = None
        self.line_spacing: Optional[float] = None

        if (
            hasattr(paragraph, "_p")
            and paragraph._p is not None
            and paragraph._p.pPr is not None
        ):
            pPr = paragraph._p.pPr
            ns = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
            if (
                pPr.find(f"{ns}buChar") is not None
                or pPr.find(f"{ns}buAutoNum") is not None
            ):
                self.bullet = True
                if hasattr(paragraph, "level"):
                    self.level = paragraph.level

        if hasattr(paragraph, "alignment") and paragraph.alignment is not None:
            alignment_map = {
                PP_ALIGN.CENTER: "CENTER",
                PP_ALIGN.RIGHT: "RIGHT",
                PP_ALIGN.JUSTIFY: "JUSTIFY",
            }
            if paragraph.alignment in alignment_map:
                self.alignment = alignment_map[paragraph.alignment]

        if hasattr(paragraph, "space_before") and paragraph.space_before:
            self.space_before = paragraph.space_before.pt
        if hasattr(paragraph, "space_after") and paragraph.space_after:
            self.space_after = paragraph.space_after.pt

        if paragraph.runs:
            first_run = paragraph.runs[0]
            if hasattr(first_run, "font"):
                font = first_run.font
                if font.name:
                    self.font_name = font.name
                if font.size:
                    self.font_size = font.size.pt
                if font.bold is not None:
                    self.bold = font.bold
                if font.italic is not None:
                    self.italic = font.italic
                if font.underline is not None:
                    self.underline = font.underline

                try:
                    if font.color.rgb:
                        self.color = str(font.color.rgb)
                except (AttributeError, TypeError):
                    try:
                        if font.color.theme_color:
                            self.theme_color = font.color.theme_color.name
                    except (AttributeError, TypeError):
                        pass

        if hasattr(paragraph, "line_spacing") and paragraph.line_spacing is not None:
            if hasattr(paragraph.line_spacing, "pt"):
                self.line_spacing = round(paragraph.line_spacing.pt, 2)
            else:
                font_size = self.font_size if self.font_size else 12.0
                self.line_spacing = round(paragraph.line_spacing * font_size, 2)

    def to_dict(self) -> ParagraphDict:
        result: ParagraphDict = {"text": self.text}

        if self.bullet:
            result["bullet"] = self.bullet
        if self.level is not None:
            result["level"] = self.level
        if self.alignment:
            result["alignment"] = self.alignment
        if self.space_before is not None:
            result["space_before"] = self.space_before
        if self.space_after is not None:
            result["space_after"] = self.space_after
        if self.font_name:
            result["font_name"] = self.font_name
        if self.font_size is not None:
            result["font_size"] = self.font_size
        if self.bold is not None:
            result["bold"] = self.bold
        if self.italic is not None:
            result["italic"] = self.italic
        if self.underline is not None:
            result["underline"] = self.underline
        if self.color:
            result["color"] = self.color
        if self.theme_color:
            result["theme_color"] = self.theme_color
        if self.line_spacing is not None:
            result["line_spacing"] = self.line_spacing

        return result


class ShapeData:
    @staticmethod
    def emu_to_inches(emu: int) -> float:
        return emu / 914400.0

    @staticmethod
    def inches_to_pixels(inches: float, dpi: int = 96) -> int:
        return int(inches * dpi)

    @staticmethod
    def get_font_path(font_name: str) -> Optional[str]:
        system = platform.system()

        font_variations = [
            font_name,
            font_name.lower(),
            font_name.replace(" ", ""),
            font_name.replace(" ", "-"),
        ]

        if system == "Darwin":
            font_dirs = [
                "/System/Library/Fonts/",
                "/Library/Fonts/",
                "~/Library/Fonts/",
            ]
            extensions = [".ttf", ".otf", ".ttc", ".dfont"]
        else:
            font_dirs = [
                "/usr/share/fonts/truetype/",
                "/usr/local/share/fonts/",
                "~/.fonts/",
            ]
            extensions = [".ttf", ".otf"]

        for font_dir in font_dirs:
            font_dir_path = Path(font_dir).expanduser()
            if not font_dir_path.exists():
                continue

            for variant in font_variations:
                for ext in extensions:
                    font_path = font_dir_path / f"{variant}{ext}"
                    if font_path.exists():
                        return str(font_path)

            try:
                for file_path in font_dir_path.iterdir():
                    if file_path.is_file():
                        file_name_lower = file_path.name.lower()
                        font_name_lower = font_name.lower().replace(" ", "")
                        if font_name_lower in file_name_lower and any(
                            file_name_lower.endswith(ext) for ext in extensions
                        ):
                            return str(file_path)
            except (OSError, PermissionError):
                continue

        return None

    @staticmethod
    def get_slide_dimensions(slide: Any) -> tuple[Optional[int], Optional[int]]:
        try:
            prs = slide.part.package.presentation_part.presentation
            return prs.slide_width, prs.slide_height
        except (AttributeError, TypeError):
            return None, None

    @staticmethod
    def get_default_font_size(shape: BaseShape, slide_layout: Any) -> Optional[float]:
        try:
            if not hasattr(shape, "placeholder_format"):
                return None

            shape_type = shape.placeholder_format.type
            for layout_placeholder in slide_layout.placeholders:
                if layout_placeholder.placeholder_format.type == shape_type:
                    for elem in layout_placeholder.element.iter():
                        if "defRPr" in elem.tag and (sz := elem.get("sz")):
                            return float(sz) / 100.0
                    break
        except Exception:
            pass
        return None

    def __init__(
        self,
        shape: BaseShape,
        absolute_left: Optional[int] = None,
        absolute_top: Optional[int] = None,
        slide: Optional[Any] = None,
    ):
        self.shape = shape
        self.shape_id: str = ""

        self.slide_width_emu, self.slide_height_emu = (
            self.get_slide_dimensions(slide) if slide else (None, None)
        )

        self.placeholder_type: Optional[str] = None
        self.default_font_size: Optional[float] = None
        if hasattr(shape, "is_placeholder") and shape.is_placeholder:
            if shape.placeholder_format and shape.placeholder_format.type:
                self.placeholder_type = (
                    str(shape.placeholder_format.type).split(".")[-1].split(" ")[0]
                )

                if slide and hasattr(slide, "slide_layout"):
                    self.default_font_size = self.get_default_font_size(
                        shape, slide.slide_layout
                    )

        left_emu = (
            absolute_left
            if absolute_left is not None
            else (shape.left if hasattr(shape, "left") else 0)
        )
        top_emu = (
            absolute_top
            if absolute_top is not None
            else (shape.top if hasattr(shape, "top") else 0)
        )

        self.left: float = round(self.emu_to_inches(left_emu), 2)
        self.top: float = round(self.emu_to_inches(top_emu), 2)
        self.width: float = round(
            self.emu_to_inches(shape.width if hasattr(shape, "width") else 0), 2
        )
        self.height: float = round(
            self.emu_to_inches(shape.height if hasattr(shape, "height") else 0), 2
        )

        self.left_emu = left_emu
        self.top_emu = top_emu
        self.width_emu = shape.width if hasattr(shape, "width") else 0
        self.height_emu = shape.height if hasattr(shape, "height") else 0

        self.frame_overflow_bottom: Optional[float] = None
        self.slide_overflow_right: Optional[float] = None
        self.slide_overflow_bottom: Optional[float] = None
        self.overlapping_shapes: Dict[str, float] = {}
        self.warnings: List[str] = []
        self._estimate_frame_overflow()
        self._calculate_slide_overflow()
        self._detect_bullet_issues()

    @property
    def paragraphs(self) -> List[ParagraphData]:
        if not self.shape or not hasattr(self.shape, "text_frame"):
            return []

        paragraphs = []
        for paragraph in self.shape.text_frame.paragraphs:
            if paragraph.text.strip():
                paragraphs.append(ParagraphData(paragraph))
        return paragraphs

    def _get_default_font_size(self) -> int:
        try:
            if not (
                hasattr(self.shape, "part") and hasattr(self.shape.part, "slide_layout")
            ):
                return 14

            slide_master = self.shape.part.slide_layout.slide_master
            if not hasattr(slide_master, "element"):
                return 14

            style_name = "bodyStyle"
            if self.placeholder_type and "TITLE" in self.placeholder_type:
                style_name = "titleStyle"

            for child in slide_master.element.iter():
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                if tag == style_name:
                    for elem in child.iter():
                        if "sz" in elem.attrib:
                            return int(elem.attrib["sz"]) // 100
        except Exception:
            pass

        return 14

    def _get_usable_dimensions(self, text_frame) -> Tuple[int, int]:
        margins = {"top": 0.05, "bottom": 0.05, "left": 0.1, "right": 0.1}

        if hasattr(text_frame, "margin_top") and text_frame.margin_top:
            margins["top"] = self.emu_to_inches(text_frame.margin_top)
        if hasattr(text_frame, "margin_bottom") and text_frame.margin_bottom:
            margins["bottom"] = self.emu_to_inches(text_frame.margin_bottom)
        if hasattr(text_frame, "margin_left") and text_frame.margin_left:
            margins["left"] = self.emu_to_inches(text_frame.margin_left)
        if hasattr(text_frame, "margin_right") and text_frame.margin_right:
            margins["right"] = self.emu_to_inches(text_frame.margin_right)

        usable_width = self.width - margins["left"] - margins["right"]
        usable_height = self.height - margins["top"] - margins["bottom"]

        return (
            self.inches_to_pixels(usable_width),
            self.inches_to_pixels(usable_height),
        )

    def _wrap_text_line(self, line: str, max_width_px: int, draw, font) -> List[str]:
        if not line:
            return [""]

        if draw.textlength(line, font=font) <= max_width_px:
            return [line]

        wrapped = []
        words = line.split(" ")
        current_line = ""

        for word in words:
            test_line = current_line + (" " if current_line else "") + word
            if draw.textlength(test_line, font=font) <= max_width_px:
                current_line = test_line
            else:
                if current_line:
                    wrapped.append(current_line)
                current_line = word

        if current_line:
            wrapped.append(current_line)

        return wrapped

    def _estimate_frame_overflow(self) -> None:
        if not self.shape or not hasattr(self.shape, "text_frame"):
            return

        text_frame = self.shape.text_frame
        if not text_frame or not text_frame.paragraphs:
            return

        usable_width_px, usable_height_px = self._get_usable_dimensions(text_frame)
        if usable_width_px <= 0 or usable_height_px <= 0:
            return

        dummy_img = Image.new("RGB", (1, 1))
        draw = ImageDraw.Draw(dummy_img)

        default_font_size = self._get_default_font_size()

        total_height_px = 0

        for para_idx, paragraph in enumerate(text_frame.paragraphs):
            if not paragraph.text.strip():
                continue

            para_data = ParagraphData(paragraph)

            font_name = para_data.font_name or "Arial"
            font_size = int(para_data.font_size or default_font_size)

            font = None
            font_path = self.get_font_path(font_name)
            if font_path:
                try:
                    font = ImageFont.truetype(font_path, size=font_size)
                except Exception:
                    font = ImageFont.load_default()
            else:
                font = ImageFont.load_default()

            all_wrapped_lines = []
            for line in paragraph.text.split("\n"):
                wrapped = self._wrap_text_line(line, usable_width_px, draw, font)
                all_wrapped_lines.extend(wrapped)

            if all_wrapped_lines:
                if para_data.line_spacing:
                    line_height_px = para_data.line_spacing * 96 / 72
                else:
                    line_height_px = font_size * 96 / 72

                if para_idx > 0 and para_data.space_before:
                    total_height_px += para_data.space_before * 96 / 72

                total_height_px += len(all_wrapped_lines) * line_height_px

                if para_data.space_after:
                    total_height_px += para_data.space_after * 96 / 72

        if total_height_px > usable_height_px:
            overflow_px = total_height_px - usable_height_px
            overflow_inches = round(overflow_px / 96.0, 2)
            if overflow_inches > 0.05:
                self.frame_overflow_bottom = overflow_inches

    def _calculate_slide_overflow(self) -> None:
        if self.slide_width_emu is None or self.slide_height_emu is None:
            return

        right_edge_emu = self.left_emu + self.width_emu
        if right_edge_emu > self.slide_width_emu:
            overflow_emu = right_edge_emu - self.slide_width_emu
            overflow_inches = round(self.emu_to_inches(overflow_emu), 2)
            if overflow_inches > 0.01:
                self.slide_overflow_right = overflow_inches

        bottom_edge_emu = self.top_emu + self.height_emu
        if bottom_edge_emu > self.slide_height_emu:
            overflow_emu = bottom_edge_emu - self.slide_height_emu
            overflow_inches = round(self.emu_to_inches(overflow_emu), 2)
            if overflow_inches > 0.01:
                self.slide_overflow_bottom = overflow_inches

    def _detect_bullet_issues(self) -> None:
        if not self.shape or not hasattr(self.shape, "text_frame"):
            return

        text_frame = self.shape.text_frame
        if not text_frame or not text_frame.paragraphs:
            return

        bullet_symbols = ["•", "●", "○"]

        for paragraph in text_frame.paragraphs:
            text = paragraph.text.strip()
            if text and any(text.startswith(symbol + " ") for symbol in bullet_symbols):
                self.warnings.append(
                    "manual_bullet_symbol: use proper bullet formatting"
                )
                break

    @property
    def has_any_issues(self) -> bool:
        return (
            self.frame_overflow_bottom is not None
            or self.slide_overflow_right is not None
            or self.slide_overflow_bottom is not None
            or len(self.overlapping_shapes) > 0
            or len(self.warnings) > 0
        )

    def to_dict(self) -> ShapeDict:
        result: ShapeDict = {
            "left": self.left,
            "top": self.top,
            "width": self.width,
            "height": self.height,
        }

        if self.placeholder_type:
            result["placeholder_type"] = self.placeholder_type

        if self.default_font_size:
            result["default_font_size"] = self.default_font_size

        overflow_data = {}

        if self.frame_overflow_bottom is not None:
            overflow_data["frame"] = {"overflow_bottom": self.frame_overflow_bottom}

        slide_overflow = {}
        if self.slide_overflow_right is not None:
            slide_overflow["overflow_right"] = self.slide_overflow_right
        if self.slide_overflow_bottom is not None:
            slide_overflow["overflow_bottom"] = self.slide_overflow_bottom
        if slide_overflow:
            overflow_data["slide"] = slide_overflow

        if overflow_data:
            result["overflow"] = overflow_data

        if self.overlapping_shapes:
            result["overlap"] = {"overlapping_shapes": self.overlapping_shapes}

        if self.warnings:
            result["warnings"] = self.warnings

        result["paragraphs"] = [para.to_dict() for para in self.paragraphs]

        return result


def _is_valid_shape(shape: BaseShape) -> bool:
    if not hasattr(shape, "text_frame") or not shape.text_frame:
        return False

    text = shape.text_frame.text.strip()
    if not text:
        return False

    if hasattr(shape, "is_placeholder") and shape.is_placeholder:
        if shape.placeholder_format and shape.placeholder_format.type:
            placeholder_type = (
                str(shape.placeholder_format.type).split(".")[-1].split(" ")[0]
            )
            if placeholder_type == "SLIDE_NUMBER":
                return False
            if placeholder_type == "FOOTER" and text.isdigit():
                return False

    return True


def _collect_shapes_with_absolute_positions(
    shape: BaseShape, parent_left: int = 0, parent_top: int = 0
) -> List[ShapeWithPosition]:
    if hasattr(shape, "shapes"):
        result = []
        group_left = shape.left if hasattr(shape, "left") else 0
        group_top = shape.top if hasattr(shape, "top") else 0

        abs_group_left = parent_left + group_left
        abs_group_top = parent_top + group_top

        for child in shape.shapes:
            result.extend(
                _collect_shapes_with_absolute_positions(
                    child, abs_group_left, abs_group_top
                )
            )
        return result

    if _is_valid_shape(shape):
        shape_left = shape.left if hasattr(shape, "left") else 0
        shape_top = shape.top if hasattr(shape, "top") else 0

        return [
            ShapeWithPosition(
                shape=shape,
                absolute_left=parent_left + shape_left,
                absolute_top=parent_top + shape_top,
            )
        ]

    return []


def _sort_shapes_by_position(shapes: List[ShapeData]) -> List[ShapeData]:
    if not shapes:
        return shapes

    shapes = sorted(shapes, key=lambda s: (s.top, s.left))

    result = []
    row = [shapes[0]]
    row_top = shapes[0].top

    for shape in shapes[1:]:
        if abs(shape.top - row_top) <= 0.5:
            row.append(shape)
        else:
            result.extend(sorted(row, key=lambda s: s.left))
            row = [shape]
            row_top = shape.top

    result.extend(sorted(row, key=lambda s: s.left))
    return result


def _calculate_overlap(
    rect1: Tuple[float, float, float, float],
    rect2: Tuple[float, float, float, float],
    tolerance: float = 0.05,
) -> Tuple[bool, float]:
    left1, top1, w1, h1 = rect1
    left2, top2, w2, h2 = rect2

    overlap_width = min(left1 + w1, left2 + w2) - max(left1, left2)
    overlap_height = min(top1 + h1, top2 + h2) - max(top1, top2)

    if overlap_width > tolerance and overlap_height > tolerance:
        overlap_area = overlap_width * overlap_height
        return True, round(overlap_area, 2)

    return False, 0


def _detect_overlaps(shapes: List[ShapeData]) -> None:
    n = len(shapes)

    for i in range(n):
        for j in range(i + 1, n):
            shape1 = shapes[i]
            shape2 = shapes[j]

            rect1 = (shape1.left, shape1.top, shape1.width, shape1.height)
            rect2 = (shape2.left, shape2.top, shape2.width, shape2.height)

            overlaps, overlap_area = _calculate_overlap(rect1, rect2)

            if overlaps:
                shape1.overlapping_shapes[shape2.shape_id] = overlap_area
                shape2.overlapping_shapes[shape1.shape_id] = overlap_area


def _clear_paragraph_bullets(paragraph):
    pPr = paragraph._element.get_or_add_pPr()

    for child in list(pPr):
        if (
            child.tag.endswith("buChar")
            or child.tag.endswith("buNone")
            or child.tag.endswith("buAutoNum")
            or child.tag.endswith("buFont")
        ):
            pPr.remove(child)

    return pPr


def _apply_paragraph_properties(paragraph, para_data: Dict[str, Any]):
    text = para_data.get("text", "")

    pPr = _clear_paragraph_bullets(paragraph)

    if para_data.get("bullet", False):
        level = para_data.get("level", 0)
        paragraph.level = level

        font_size = para_data.get("font_size", 18.0)
        level_indent_emu = int((font_size * (1.6 + level * 1.6)) * 12700)
        hanging_indent_emu = int(-font_size * 0.8 * 12700)

        pPr.attrib["marL"] = str(level_indent_emu)
        pPr.attrib["indent"] = str(hanging_indent_emu)

        buChar = OxmlElement("a:buChar")
        buChar.set("char", "•")
        pPr.append(buChar)

        if "alignment" not in para_data:
            paragraph.alignment = PP_ALIGN.LEFT
    else:
        pPr.attrib["marL"] = "0"
        pPr.attrib["indent"] = "0"

        buNone = OxmlElement("a:buNone")
        pPr.insert(0, buNone)

    if "alignment" in para_data:
        alignment_map = {
            "LEFT": PP_ALIGN.LEFT,
            "CENTER": PP_ALIGN.CENTER,
            "RIGHT": PP_ALIGN.RIGHT,
            "JUSTIFY": PP_ALIGN.JUSTIFY,
        }
        if para_data["alignment"] in alignment_map:
            paragraph.alignment = alignment_map[para_data["alignment"]]

    if "space_before" in para_data:
        paragraph.space_before = Pt(para_data["space_before"])
    if "space_after" in para_data:
        paragraph.space_after = Pt(para_data["space_after"])
    if "line_spacing" in para_data:
        paragraph.line_spacing = Pt(para_data["line_spacing"])

    if not paragraph.runs:
        run = paragraph.add_run()
        run.text = text
    else:
        run = paragraph.runs[0]
        run.text = text

    _apply_font_properties(run, para_data)


def _apply_font_properties(run, para_data: Dict[str, Any]):
    if "bold" in para_data:
        run.font.bold = para_data["bold"]
    if "italic" in para_data:
        run.font.italic = para_data["italic"]
    if "underline" in para_data:
        run.font.underline = para_data["underline"]
    if "font_size" in para_data:
        font_size = para_data["font_size"]
        if font_size < 1:
            font_size = 12
        elif font_size > 400:
            font_size = 400
        run.font.size = Pt(font_size)
    if "font_name" in para_data:
        run.font.name = para_data["font_name"]

    if "color" in para_data:
        color_hex = para_data["color"].lstrip("#")
        if len(color_hex) == 6:
            r = int(color_hex[0:2], 16)
            g = int(color_hex[2:4], 16)
            b = int(color_hex[4:6], 16)
            run.font.color.rgb = RGBColor(r, g, b)
    elif "theme_color" in para_data:
        theme_name = para_data["theme_color"]
        try:
            run.font.color.theme_color = getattr(MSO_THEME_COLOR, theme_name)
        except AttributeError:
            logger.warning(f"Unknown theme color name '{theme_name}'")


def _duplicate_slide(pres, index):
    source = pres.slides[index]

    new_slide = pres.slides.add_slide(source.slide_layout)

    image_rels = {}
    for rel_id, rel in six.iteritems(source.part.rels):
        if "image" in rel.reltype or "media" in rel.reltype:
            image_rels[rel_id] = rel

    for shape in new_slide.shapes:
        sp = shape.element
        sp.getparent().remove(sp)

    for shape in source.shapes:
        el = shape.element
        new_el = deepcopy(el)
        new_slide.shapes._spTree.insert_element_before(new_el, "p:extLst")

        blips = new_el.xpath(".//a:blip[@r:embed]")
        for blip in blips:
            old_rId = blip.get(
                "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
            )
            if old_rId in image_rels:
                old_rel = image_rels[old_rId]
                new_rId = new_slide.part.rels.get_or_add(
                    old_rel.reltype, old_rel._target
                )
                blip.set(
                    "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed",
                    new_rId,
                )

    for rel_id, rel in image_rels.items():
        try:
            new_slide.part.rels.get_or_add(rel.reltype, rel._target)
        except Exception:
            pass

    return new_slide


def _delete_slide(pres, index):
    rId = pres.slides._sldIdLst[index].rId
    pres.part.drop_rel(rId)
    del pres.slides._sldIdLst[index]


def _reorder_slides(pres, slide_index, target_index):
    slides = pres.slides._sldIdLst

    slide_element = slides[slide_index]
    slides.remove(slide_element)

    slides.insert(target_index, slide_element)


class HTMLParser:

    SLIDE_WIDTH_PX = 960
    SLIDE_HEIGHT_PX = 720

    def __init__(self):
        self.elements: List[Dict] = []
        self.background: Optional[Dict] = None
        self.errors: List[str] = []
        self.style_rules: Dict[str, Dict[str, str]] = {}

    def reset(self):
        self.elements = []
        self.background = None
        self.errors = []
        self.style_rules = {}

    def _parse_style_tag(self, soup) -> None:
        for style_tag in soup.find_all("style"):
            if not style_tag.string:
                continue
            try:
                sheet = cssutils.parseString(style_tag.string)
                for rule in sheet:
                    if rule.type == rule.STYLE_RULE:
                        selector = rule.selectorText
                        styles = {}
                        for prop in rule.style:
                            styles[prop.name] = prop.value
                        for sel in selector.split(","):
                            sel = sel.strip()
                            if sel in self.style_rules:
                                self.style_rules[sel].update(styles)
                            else:
                                self.style_rules[sel] = styles.copy()
            except Exception as e:
                logger.debug(f"Error parsing style tag: {e}")

    def _get_element_styles(self, el) -> Dict[str, str]:
        combined_styles: Dict[str, str] = {}
        
        tag_selector = el.name
        if tag_selector in self.style_rules:
            combined_styles.update(self.style_rules[tag_selector])
        
        if el.get("id"):
            id_selector = f"#{el['id']}"
            if id_selector in self.style_rules:
                combined_styles.update(self.style_rules[id_selector])
        
        if el.get("class"):
            classes = el["class"] if isinstance(el["class"], list) else el["class"].split()
            for cls in classes:
                class_selector = f".{cls}"
                if class_selector in self.style_rules:
                    combined_styles.update(self.style_rules[class_selector])
        
        inline_styles = get_style_map(el)
        combined_styles.update(inline_styles)
        
        return combined_styles

    def parse(self, html_content: str) -> Dict:
        soup = BeautifulSoup(html_content, "html.parser")

        self._parse_style_tag(soup)

        body = soup.body
        if body:
            style = self._get_element_styles(body)
            bg_color = style.get("background-color", "white")
            hex_color, _ = parse_color(bg_color)
            self.background = {"type": "color", "value": hex_color}

        self._parse_element(soup.body or soup)

        return {
            "background": self.background,
            "elements": self.elements,
            "errors": self.errors,
        }

    def _parse_element(self, parent, container_x: float = 0, container_y: float = 0, 
                       container_w: float = 0, container_h: float = 0, y_cursor: float = 0):
        if parent is None:
            return y_cursor

        is_root = container_w == 0
        if is_root:
            container_w = self.SLIDE_WIDTH_PX
            container_h = self.SLIDE_HEIGHT_PX

        current_y_cursor = y_cursor

        for el in parent.children:
            if not hasattr(el, 'name') or el.name is None:
                continue

            if el.name in [
                "html",
                "body",
                "head",
                "meta",
                "title",
                "style",
                "script",
                "link",
                "li",
            ]:
                continue

            style = self._get_element_styles(el)

            has_left = "left" in style
            has_top = "top" in style
            has_right = "right" in style
            has_bottom = "bottom" in style
            has_explicit_position = has_left or has_top or has_right or has_bottom

            w_px = px_to_points(style.get("width", "0")) / PT_PER_PX
            h_px = px_to_points(style.get("height", "0")) / PT_PER_PX

            if has_explicit_position:
                if has_left:
                    x_px = container_x + px_to_points(style.get("left", "0")) / PT_PER_PX
                elif has_right:
                    right_px = px_to_points(style.get("right", "0")) / PT_PER_PX
                    x_px = self.SLIDE_WIDTH_PX - right_px - w_px
                else:
                    x_px = container_x

                if has_top:
                    y_px = container_y + px_to_points(style.get("top", "0")) / PT_PER_PX
                elif has_bottom:
                    bottom_px = px_to_points(style.get("bottom", "0")) / PT_PER_PX
                    y_px = self.SLIDE_HEIGHT_PX - bottom_px - h_px
                else:
                    y_px = container_y
                
                flow = False
            else:
                x_px = container_x
                y_px = container_y + current_y_cursor
                flow = True

            x = px_to_inch(x_px)
            y = px_to_inch(y_px)
            w = px_to_inch(w_px) if w_px > 0 else px_to_inch(container_w)
            h = px_to_inch(h_px) if h_px > 0 else 0.6

            element_data = {
                "position": {"x": x, "y": y, "w": w, "h": h},
                "style": self._extract_text_style(el, style),
                "flow": flow,
            }

            if el.name == "img":
                element_data["type"] = "image"
                element_data["src"] = el.get("src")
                self.elements.append(element_data)
                if flow:
                    current_y_cursor += h_px if h_px > 0 else 50

            elif el.name in ["div"]:
                bg_color = style.get("background-color")
                border_width = style.get("border-width")
                shape_type = el.get("data-shape", "rectangle").lower()

                if bg_color or border_width or shape_type != "rectangle":
                    hex_bg, alpha = parse_color(bg_color) if bg_color else (None, 0)

                    element_data["type"] = "shape"
                    element_data["shape"] = {
                        "fill": hex_bg if bg_color else None,
                        "line": None,
                        "shape_type": shape_type,
                    }
                    if border_width:
                        border_color = style.get("border-color", "black")
                        hex_border, _ = parse_color(border_color)
                        element_data["shape"]["line"] = {
                            "color": hex_border,
                            "width": px_to_points(border_width),
                        }
                    self.elements.append(element_data)

                padding_px = px_to_points(style.get("padding", "0")) / PT_PER_PX
                
                if has_explicit_position:
                    child_container_x = x_px + padding_px
                    child_container_y = y_px + padding_px
                    child_container_w = w_px - 2 * padding_px if w_px > 0 else container_w
                    child_container_h = h_px - 2 * padding_px if h_px > 0 else container_h
                    child_y_cursor = 0
                else:
                    child_container_x = container_x + padding_px
                    child_container_y = container_y
                    child_container_w = container_w - 2 * padding_px
                    child_container_h = container_h
                    child_y_cursor = current_y_cursor

                child_end_cursor = self._parse_element(
                    el, 
                    container_x=child_container_x, 
                    container_y=child_container_y,
                    container_w=child_container_w,
                    container_h=child_container_h,
                    y_cursor=child_y_cursor
                )

                if flow:
                    if has_explicit_position:
                        current_y_cursor += h_px if h_px > 0 else 50
                    else:
                        current_y_cursor = child_end_cursor + 15

            elif el.name in ["p", "h1", "h2", "h3", "h4", "h5", "h6"]:
                element_data["type"] = el.name
                element_data["text"] = self._extract_text_with_formatting(el)
                self.elements.append(element_data)

                if flow:
                    font_size_px = px_to_points(style.get("font-size", "16px")) / PT_PER_PX
                    current_y_cursor += font_size_px * 1.8 + 8

            elif el.name in ["ul", "ol"]:
                items = []
                for li in el.find_all("li", recursive=False):
                    items.append({"text": self._extract_text_with_formatting(li), "options": {}})

                element_data["type"] = "list"
                element_data["items"] = items
                self.elements.append(element_data)

                if flow:
                    font_size_px = px_to_points(style.get("font-size", "16px")) / PT_PER_PX
                    current_y_cursor += len(items) * (font_size_px * 1.5 + 5) + 10

        return current_y_cursor

    def _calculate_position(self, style: Dict[str, str], parent_x: float, parent_y: float) -> Tuple[float, float, float, float, bool]:
        has_left = "left" in style
        has_top = "top" in style
        has_right = "right" in style
        has_bottom = "bottom" in style

        w = px_to_inch(px_to_points(style.get("width", "0")) / PT_PER_PX)
        h = px_to_inch(px_to_points(style.get("height", "0")) / PT_PER_PX)

        x = px_to_inch(parent_x)
        y = px_to_inch(parent_y)

        if has_left:
            left_px = px_to_points(style.get("left", "0")) / PT_PER_PX
            x = px_to_inch(parent_x + left_px)
        elif has_right:
            right_px = px_to_points(style.get("right", "0")) / PT_PER_PX
            width_px = w * PX_PER_IN
            x = px_to_inch(self.SLIDE_WIDTH_PX - right_px - width_px)

        if has_top:
            top_px = px_to_points(style.get("top", "0")) / PT_PER_PX
            y = px_to_inch(parent_y + top_px)
        elif has_bottom:
            bottom_px = px_to_points(style.get("bottom", "0")) / PT_PER_PX
            height_px = h * PX_PER_IN
            y = px_to_inch(self.SLIDE_HEIGHT_PX - bottom_px - height_px)

        has_position = has_left or has_top or has_right or has_bottom
        has_inherited_position = parent_x > 0 or parent_y > 0

        return x, y, w, h, has_position or has_inherited_position

    def _extract_text_with_formatting(self, el) -> str:
        return el.get_text(separator=" ", strip=True)

    def _extract_text_style(self, el, style: Dict[str, str]) -> Dict:
        hex_color, _ = parse_color(style.get("color", "black"))

        bold = style.get("font-weight") == "bold"
        italic = style.get("font-style") == "italic"

        if el.find("strong") or el.find("b"):
            bold = True
        if el.find("em") or el.find("i"):
            italic = True

        return {
            "fontSize": px_to_points(style.get("font-size", "16px")),
            "color": hex_color,
            "align": style.get("text-align", "left"),
            "bold": bold,
            "italic": italic,
            "underline": "underline" in style.get("text-decoration", ""),
        }


def add_background(slide_data: Dict, slide) -> None:
    bg = slide_data.get("background", {})
    if bg.get("type") == "color" and bg.get("value"):
        background = slide.background
        fill = background.fill
        fill.solid()
        try:
            r, g, b = hex_to_rgb(bg["value"])
            fill.fore_color.rgb = RGBColor(r, g, b)
        except Exception:
            pass


def apply_text_properties(run, style: Dict) -> None:
    font = run.font
    if style.get("fontSize"):
        font_size = style["fontSize"]
        if font_size < 1:
            font_size = 12
        elif font_size > 400:
            font_size = 400
        font.size = Pt(font_size)
    if style.get("color"):
        try:
            r, g, b = hex_to_rgb(style["color"])
            font.color.rgb = RGBColor(r, g, b)
        except Exception:
            pass

    if style.get("bold"):
        font.bold = True
    if style.get("italic"):
        font.italic = True
    if style.get("underline"):
        font.underline = True


def add_glow_effect(shape, color_hex: str = "FFFF00", radius: int = 10) -> None:
    sp = shape.element
    spPr = sp.find("p:spPr", namespaces=sp.nsmap)

    if spPr is not None:
        effectLst = spPr.find("a:effectLst", namespaces=sp.nsmap)
        if effectLst is None:
            effectLst = parse_xml(f'<a:effectLst {nsdecls("a")}/>')
            spPr.append(effectLst)

        rad_emu = int(radius * 12700)
        glow_xml = f"""
        <a:glow rad="{rad_emu}" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:srgbClr val="{color_hex}">
                <a:alpha val="40000"/>
            </a:srgbClr>
        </a:glow>
        """
        glow_element = parse_xml(glow_xml)
        effectLst.append(glow_element)


def add_elements(slide_data: Dict, slide) -> None:
    y_cursor_in = 0.5
    for el in slide_data.get("elements", []):
        el_type = el.get("type")
        pos = el.get("position", {})
        flow = el.get("flow", False)
        
        has_explicit_pos = pos.get("x", 0) > 0.5 or pos.get("y", 0) > 0
        
        if flow and not has_explicit_pos:
            left = Inches(0.5)
            top = Inches(y_cursor_in)
            width = Inches(9.0)
            height = Inches(pos.get("h", 0.6))
        else:
            left = Inches(pos.get("x", 0))
            top = Inches(pos.get("y", 0))
            width = Inches(pos.get("w", 1))
            height = Inches(pos.get("h", 1))

        if el_type == "image":
            src = el.get("src")
            if src:
                try:
                    image_source = None
                    if src.startswith("file://"):
                        image_source = src[7:]
                    elif src.startswith(("http://", "https://")):
                        response = requests.get(src, timeout=30)
                        response.raise_for_status()
                        image_source = io.BytesIO(response.content)
                    else:
                        image_source = src
                    
                    if image_source:
                        if flow:
                            img_width = width if pos.get("w", 0) > 0.6 else Inches(6.0)
                            img_height = height if pos.get("h", 0) > 0.6 else None
                            if img_height:
                                pic = slide.shapes.add_picture(image_source, left, top, img_width, img_height)
                            else:
                                pic = slide.shapes.add_picture(image_source, left, top, width=img_width)
                            y_cursor_in += float(pic.height) / 914400.0 + 0.2
                        else:
                            slide.shapes.add_picture(image_source, left, top, width, height)
                except Exception as e:
                    logger.warning(f"Error adding image {src}: {e}")

        elif el_type == "shape":
            shape_style = el.get("shape", {})
            shape_type_name = shape_style.get("shape_type", "rectangle").upper()
            mso_shape = SHAPE_TYPE_MAP.get(shape_type_name, MSO_SHAPE.RECTANGLE)
            shape = slide.shapes.add_shape(mso_shape, left, top, width, height)

            if shape_style.get("fill"):
                shape.fill.solid()
                r, g, b = hex_to_rgb(shape_style["fill"])
                shape.fill.fore_color.rgb = RGBColor(r, g, b)

            if shape_style.get("line"):
                line_style = shape_style["line"]
                r, g, b = hex_to_rgb(line_style["color"])
                shape.line.color.rgb = RGBColor(r, g, b)
                shape.line.width = Pt(line_style["width"])

            if shape_style.get("line") and shape_style["line"]["color"] == "ffd700":
                add_glow_effect(shape, color_hex="FFD700")

        elif el_type in ["p", "h1", "h2", "h3", "h4", "h5", "h6", "list"]:
            textbox = slide.shapes.add_textbox(left, top, width, height)
            text_frame = textbox.text_frame
            text_frame.word_wrap = True

            style = el.get("style", {})

            default_styles = {
                "h1": {"fontSize": 44, "bold": True},
                "h2": {"fontSize": 36, "bold": True},
                "h3": {"fontSize": 28, "bold": True},
                "h4": {"fontSize": 24, "bold": True},
                "h5": {"fontSize": 20, "bold": True},
                "h6": {"fontSize": 18, "bold": True},
                "p": {"fontSize": 18},
                "list": {"fontSize": 18},
            }
            default_style = default_styles.get(el_type, {})
            merged_style = {**default_style, **{k: v for k, v in style.items() if v}}

            if el_type == "list":
                for idx, item in enumerate(el.get("items", [])):
                    if idx == 0:
                        p = text_frame.paragraphs[0]
                    else:
                        p = text_frame.add_paragraph()
                    
                    p.level = item.get("level", 0)
                    
                    pPr = p._element.get_or_add_pPr()
                    font_size = merged_style.get("fontSize", 18)
                    level = p.level
                    level_indent_emu = int((font_size * (1.2 + level * 1.2)) * 12700)
                    hanging_indent_emu = int(-font_size * 0.6 * 12700)
                    pPr.attrib["marL"] = str(level_indent_emu)
                    pPr.attrib["indent"] = str(hanging_indent_emu)
                    
                    buChar = OxmlElement("a:buChar")
                    buChar.set("char", "•")
                    pPr.append(buChar)
                    
                    run = p.add_run()
                    run.text = item.get("text", "")
                    apply_text_properties(run, merged_style)
                if flow:
                    y_cursor_in += 0.4 * max(1, len(el.get("items", []))) + 0.2
            else:
                p = text_frame.paragraphs[0]
                run = p.add_run()
                run.text = el.get("text", "")
                apply_text_properties(run, merged_style)

                align = merged_style.get("align", "left")
                if align == "center":
                    p.alignment = PP_ALIGN.CENTER
                elif align == "right":
                    p.alignment = PP_ALIGN.RIGHT
                if flow:
                    fs = merged_style.get("fontSize") or 18
                    y_cursor_in += max(0.6, fs / 72.0 + 0.2)


class PPTXGenerator:

    def __init__(self, config: Optional[PPTXConfig] = None):
        self.config = config or PPTXConfig()

    def _save_and_upload(self, prs: Presentation, title: str) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        uniq = uuid.uuid4().hex[:8]
        file_name = f"{title}_{timestamp}_{uniq}.pptx"
        local_file_path = os.path.join("/tmp", file_name)

        prs.save(local_file_path)

        with open(local_file_path, 'rb') as f:
            pptx_content = f.read()

        storage = S3SyncStorage()

        file_key = storage.upload_file(
            file_content=pptx_content,
            file_name=file_name,
            content_type="application/vnd.openxmlformats-officedocument.presentationml.presentation"
        )

        file_url = storage.generate_presigned_url(key=file_key, expire_time=86400)
        logger.info(f"Generated PPTX: {file_url}")
        return file_url

    def generate_from_html(self, html_files: Union[str, List[str]], title: str) -> str:
        if isinstance(html_files, str):
            html_files = [html_files]

        html_contents = []
        for html_file in html_files:
            try:
                with open(html_file, "r", encoding="utf-8") as f:
                    html_contents.append(f.read())
            except UnicodeDecodeError:
                with open(html_file, "r", encoding="gbk") as f:
                    html_contents.append(f.read())

        return self.generate_from_html_content(html_contents, title)

    def generate_from_html_content(self, html_contents: Union[str, List[str]], title: str) -> str:
        if isinstance(html_contents, str):
            html_contents = [html_contents]

        prs = Presentation()
        slide_layout = prs.slide_layouts[6]
        parser = HTMLParser()

        for html_content in html_contents:
            parser.reset()

            if not re.search(r'<html|<body', html_content, re.IGNORECASE):
                html_content = f"<html><body>{html_content}</body></html>"

            slide_data = parser.parse(html_content)
            slide = prs.slides.add_slide(slide_layout)

            add_background(slide_data, slide)
            add_elements(slide_data, slide)

        return self._save_and_upload(prs, title)

    def generate_from_markdown(self, markdown_content: str, title: str) -> str:
        markdown_content = re.sub(
            r"^! (https?://\S+)", r"![](\1)", markdown_content, flags=re.MULTILINE
        )

        slide_sections = re.split(r'\n---\n|\n---$|^---\n', markdown_content)
        slide_sections = [s.strip() for s in slide_sections if s.strip()]

        if not slide_sections:
            slide_sections = [markdown_content]

        prs = Presentation()
        slide_layout = prs.slide_layouts[6]
        parser = HTMLParser()

        for section in slide_sections:
            parser.reset()

            html_content = markdown.markdown(
                section, extensions=["tables", "fenced_code"]
            )
            html_content = f"<html><body>{html_content}</body></html>"

            slide_data = parser.parse(html_content)
            slide = prs.slides.add_slide(slide_layout)

            add_background(slide_data, slide)
            add_elements(slide_data, slide)

        return self._save_and_upload(prs, title)

    def extract_inventory(
        self,
        pptx_path: Union[str, Path],
        prs: Optional[Any] = None,
        issues_only: bool = False,
    ) -> InventoryData:
        pptx_path = Path(pptx_path)
        if prs is None:
            prs = Presentation(str(pptx_path))
        inventory: InventoryData = {}

        for slide_idx, slide in enumerate(prs.slides):
            shapes_with_positions = []
            for shape in slide.shapes:
                shapes_with_positions.extend(_collect_shapes_with_absolute_positions(shape))

            if not shapes_with_positions:
                continue

            shape_data_list = [
                ShapeData(
                    swp.shape,
                    swp.absolute_left,
                    swp.absolute_top,
                    slide,
                )
                for swp in shapes_with_positions
            ]

            sorted_shapes = _sort_shapes_by_position(shape_data_list)
            for idx, shape_data in enumerate(sorted_shapes):
                shape_data.shape_id = f"shape-{idx}"

            if len(sorted_shapes) > 1:
                _detect_overlaps(sorted_shapes)

            if issues_only:
                sorted_shapes = [sd for sd in sorted_shapes if sd.has_any_issues]

            if not sorted_shapes:
                continue

            inventory[f"slide-{slide_idx}"] = {
                shape_data.shape_id: shape_data for shape_data in sorted_shapes
            }

        return inventory

    def get_inventory_as_dict(
        self, pptx_path: Union[str, Path], issues_only: bool = False
    ) -> InventoryDict:
        inventory = self.extract_inventory(pptx_path, issues_only=issues_only)

        dict_inventory: InventoryDict = {}
        for slide_key, shapes in inventory.items():
            dict_inventory[slide_key] = {
                shape_key: shape_data.to_dict() for shape_key, shape_data in shapes.items()
            }

        return dict_inventory

    def apply_replacements(
        self,
        pptx_file: Union[str, Path],
        replacements: Dict,
        title: str,
        validate_overflow: bool = True,
    ) -> str:
        pptx_file = str(pptx_file)

        prs = Presentation(pptx_file)

        inventory = self.extract_inventory(Path(pptx_file), prs)

        original_overflow = self._detect_frame_overflow(inventory)

        errors = self._validate_replacements(inventory, replacements)
        if errors:
            logger.error("Invalid shapes in replacement JSON:")
            for error in errors:
                logger.error(f"  - {error}")
            raise ValueError(f"Found {len(errors)} validation error(s)")

        shapes_processed = 0
        shapes_cleared = 0
        shapes_replaced = 0

        for slide_key, shapes_dict in inventory.items():
            if not slide_key.startswith("slide-"):
                continue

            slide_index = int(slide_key.split("-")[1])

            if slide_index >= len(prs.slides):
                logger.warning(f"Slide {slide_index} not found")
                continue

            for shape_key, shape_data in shapes_dict.items():
                shapes_processed += 1

                shape = shape_data.shape
                if not shape:
                    logger.warning(f"{shape_key} has no shape reference")
                    continue

                text_frame = shape.text_frame

                text_frame.clear()
                shapes_cleared += 1

                replacement_shape_data = replacements.get(slide_key, {}).get(shape_key, {})
                if "paragraphs" not in replacement_shape_data:
                    continue

                shapes_replaced += 1

                for i, para_data in enumerate(replacement_shape_data["paragraphs"]):
                    if i == 0:
                        p = text_frame.paragraphs[0]
                    else:
                        p = text_frame.add_paragraph()

                    _apply_paragraph_properties(p, para_data)

        if validate_overflow:
            with tempfile.NamedTemporaryFile(suffix=".pptx", delete=False) as tmp:
                tmp_path = Path(tmp.name)
                prs.save(str(tmp_path))

            try:
                updated_inventory = self.extract_inventory(tmp_path)
                updated_overflow = self._detect_frame_overflow(updated_inventory)
            finally:
                tmp_path.unlink()

            overflow_errors = []
            for slide_key, shape_overflows in updated_overflow.items():
                for shape_key, new_overflow in shape_overflows.items():
                    original = original_overflow.get(slide_key, {}).get(shape_key, 0.0)

                    if new_overflow > original + 0.01:
                        increase = new_overflow - original
                        overflow_errors.append(
                            f'{slide_key}/{shape_key}: overflow worsened by {increase:.2f}" '
                            f'(was {original:.2f}", now {new_overflow:.2f}")'
                        )

            warnings = []
            for slide_key, shapes_dict in updated_inventory.items():
                for shape_key, shape_data in shapes_dict.items():
                    if shape_data.warnings:
                        for warning in shape_data.warnings:
                            warnings.append(f"{slide_key}/{shape_key}: {warning}")

            if overflow_errors or warnings:
                logger.error("Issues detected in replacement output:")
                if overflow_errors:
                    logger.error("Text overflow worsened:")
                    for error in overflow_errors:
                        logger.error(f"  - {error}")
                if warnings:
                    logger.error("Formatting warnings:")
                    for warning in warnings:
                        logger.error(f"  - {warning}")
                raise ValueError(
                    f"Found {len(overflow_errors)} overflow error(s) and {len(warnings)} warning(s)"
                )

        return self._save_and_upload(prs, title)

    def rearrange_slides(
        self,
        template_path: Union[str, Path],
        title: str,
        slide_sequence: List[int],
    ) -> str:
        template_path = Path(template_path)

        prs = Presentation(str(template_path))

        total_slides = len(prs.slides)

        for idx in slide_sequence:
            if idx < 0 or idx >= total_slides:
                raise ValueError(f"Slide index {idx} out of range (0-{total_slides - 1})")

        slide_map = []
        duplicated = {}

        logger.info(f"Processing {len(slide_sequence)} slides from template...")
        for i, template_idx in enumerate(slide_sequence):
            if template_idx in duplicated and duplicated[template_idx]:
                slide_map.append(duplicated[template_idx].pop(0))
                logger.debug(f"  [{i}] Using duplicate of slide {template_idx}")
            elif slide_sequence.count(template_idx) > 1 and template_idx not in duplicated:
                slide_map.append(template_idx)
                duplicates = []
                count = slide_sequence.count(template_idx) - 1
                logger.debug(
                    f"  [{i}] Using original slide {template_idx}, creating {count} duplicate(s)"
                )
                for _ in range(count):
                    _duplicate_slide(prs, template_idx)
                    duplicates.append(len(prs.slides) - 1)
                duplicated[template_idx] = duplicates
            else:
                slide_map.append(template_idx)
                logger.debug(f"  [{i}] Using original slide {template_idx}")

        slides_to_keep = set(slide_map)
        logger.info(f"Deleting {len(prs.slides) - len(slides_to_keep)} unused slides...")
        for i in range(len(prs.slides) - 1, -1, -1):
            if i not in slides_to_keep:
                _delete_slide(prs, i)
                slide_map = [idx - 1 if idx > i else idx for idx in slide_map]

        logger.info(f"Reordering {len(slide_map)} slides to final sequence...")
        for target_pos in range(len(slide_map)):
            current_pos = slide_map[target_pos]
            if current_pos != target_pos:
                _reorder_slides(prs, current_pos, target_pos)
                for i in range(len(slide_map)):
                    if slide_map[i] > current_pos and slide_map[i] <= target_pos:
                        slide_map[i] -= 1
                    elif slide_map[i] < current_pos and slide_map[i] >= target_pos:
                        slide_map[i] += 1
                slide_map[target_pos] = target_pos

        logger.info(f"Final presentation has {len(prs.slides)} slides")

        return self._save_and_upload(prs, title)

    def _detect_frame_overflow(self, inventory: InventoryData) -> Dict[str, Dict[str, float]]:
        overflow_map = {}

        for slide_key, shapes_dict in inventory.items():
            for shape_key, shape_data in shapes_dict.items():
                if shape_data.frame_overflow_bottom is not None:
                    if slide_key not in overflow_map:
                        overflow_map[slide_key] = {}
                    overflow_map[slide_key][shape_key] = shape_data.frame_overflow_bottom

        return overflow_map

    def _validate_replacements(self, inventory: InventoryData, replacements: Dict) -> List[str]:
        errors = []

        for slide_key, shapes_data in replacements.items():
            if not slide_key.startswith("slide-"):
                continue

            if slide_key not in inventory:
                errors.append(f"Slide '{slide_key}' not found in inventory")
                continue

            for shape_key in shapes_data.keys():
                if shape_key not in inventory[slide_key]:
                    unused_with_content = []
                    for k in inventory[slide_key].keys():
                        if k not in shapes_data:
                            shape_data = inventory[slide_key][k]
                            paragraphs = shape_data.paragraphs
                            if paragraphs and paragraphs[0].text:
                                first_text = paragraphs[0].text[:50]
                                if len(paragraphs[0].text) > 50:
                                    first_text += "..."
                                unused_with_content.append(f"{k} ('{first_text}')")
                            else:
                                unused_with_content.append(k)

                    errors.append(
                        f"Shape '{shape_key}' not found on '{slide_key}'. "
                        f"Shapes without replacements: {', '.join(sorted(unused_with_content)) if unused_with_content else 'none'}"
                    )

        return errors

    @staticmethod
    def _check_duplicate_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate key found in JSON: '{key}'")
            result[key] = value
        return result
