"""Gap lifecycle — detect, fix, defer, dismiss, re-detect.

Gaps are stored in .tlm/gaps.json as a list of gap dicts.
Each gap has: id, type, category, severity, description, status,
dismiss_reason, detected_at, resolved_at.
"""

import json
import datetime
from enum import Enum
from pathlib import Path


class GapStatus(str, Enum):
    DETECTED = "detected"
    FIXING = "fixing"
    RESOLVED = "resolved"
    DEFERRED = "deferred"
    DISMISSED = "dismissed"


def load_gaps(project_root: str) -> list[dict]:
    """Load gaps from .tlm/gaps.json. Returns [] if missing."""
    gaps_path = Path(project_root) / ".tlm" / "gaps.json"
    if not gaps_path.exists():
        return []
    try:
        return json.loads(gaps_path.read_text())
    except (json.JSONDecodeError, OSError):
        return []


def save_gaps(project_root: str, gaps: list[dict]):
    """Save gaps to .tlm/gaps.json."""
    gaps_path = Path(project_root) / ".tlm" / "gaps.json"
    gaps_path.parent.mkdir(parents=True, exist_ok=True)
    gaps_path.write_text(json.dumps(gaps, indent=2))


def add_gap(project_root: str, gap_data: dict):
    """Add a gap. Deduplicates by ID — won't add if ID already exists."""
    gaps = load_gaps(project_root)

    # Check for existing gap with same ID
    for existing in gaps:
        if existing["id"] == gap_data["id"]:
            return  # Already exists, don't duplicate

    gap = {
        "id": gap_data["id"],
        "type": gap_data.get("type", gap_data["id"]),
        "category": gap_data.get("category", ""),
        "severity": gap_data.get("severity", "medium"),
        "description": gap_data.get("description", ""),
        "status": GapStatus.DETECTED.value,
        "dismiss_reason": None,
        "detected_at": datetime.date.today().isoformat(),
        "resolved_at": None,
    }

    gaps.append(gap)
    save_gaps(project_root, gaps)


def update_gap_status(project_root: str, gap_id: str, status: GapStatus, reason: str = None):
    """Update a gap's status. Sets resolved_at when resolving, dismiss_reason when dismissing."""
    gaps = load_gaps(project_root)

    for gap in gaps:
        if gap["id"] == gap_id:
            gap["status"] = status.value
            if status == GapStatus.RESOLVED:
                gap["resolved_at"] = datetime.date.today().isoformat()
            if status == GapStatus.DISMISSED and reason:
                gap["dismiss_reason"] = reason
            break

    save_gaps(project_root, gaps)


def get_active_gaps(project_root: str) -> list[dict]:
    """Get gaps that are not resolved or dismissed."""
    gaps = load_gaps(project_root)
    return [g for g in gaps if g["status"] not in (GapStatus.RESOLVED.value, GapStatus.DISMISSED.value)]


def get_gap_by_id(project_root: str, gap_id: str) -> dict | None:
    """Get a specific gap by ID. Returns None if not found."""
    gaps = load_gaps(project_root)
    for gap in gaps:
        if gap["id"] == gap_id:
            return gap
    return None
