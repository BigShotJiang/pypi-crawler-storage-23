"""Installer — full install flow: scan → assess → quality → gaps → hooks → finalize.

All computed data (scan results, server responses) is cached in .tlm/cache/
so retries don't recompute.
"""

import asyncio
import hashlib
import json
from pathlib import Path

from tlm.client import TLMClient
from tlm.config import save_project_config, load_project_config
from tlm.gaps import add_gap
from tlm.hooks_format import build_all_hooks
from tlm.scanner import scan_project
from tlm.state import write_state


class Installer:
    """Manages the full TLM install flow for a project."""

    def __init__(self, project_root: str, server_url: str, api_key: str):
        self.root = Path(project_root)
        self.tlm_dir = self.root / ".tlm"
        self.cache_dir = self.tlm_dir / "cache"
        self.server_url = server_url
        self.api_key = api_key

    def _get_client(self) -> TLMClient:
        return TLMClient(server_url=self.server_url, api_key=self.api_key)

    # ── Phase 1: Init ────────────────────────────────────────

    def init_project_dir(self):
        """Create .tlm/ directory structure."""
        self.tlm_dir.mkdir(parents=True, exist_ok=True)
        (self.tlm_dir / "specs").mkdir(exist_ok=True)
        (self.tlm_dir / "cache").mkdir(exist_ok=True)

    # ── Phase 1b: Create/get project on server ──────────────

    def ensure_project(self) -> int:
        """Create or get project on server. Returns project_id.

        Uses directory name as project name, and a hash of the path as fingerprint.
        Caches project_id in .tlm/config.json.
        """
        config = load_project_config(str(self.root))
        if config.get("project_id"):
            return int(config["project_id"])

        name = self.root.resolve().name
        fingerprint = hashlib.sha256(
            str(self.root.resolve()).encode()
        ).hexdigest()[:16]

        client = self._get_client()
        result = asyncio.run(client.create_project(name, fingerprint))
        project_id = result["project_id"]

        save_project_config(str(self.root), {"project_id": project_id})
        return project_id

    # ── Phase 2: Scan ────────────────────────────────────────

    def scan_project(self) -> dict:
        """Scan project and cache results in .tlm/cache/scan_result.json."""
        result = scan_project(str(self.root))

        # Cache locally
        cache_file = self.cache_dir / "scan_result.json"
        cache_file.write_text(json.dumps(result, indent=2))

        return result

    # ── Phase 3: Assess ──────────────────────────────────────

    def assess(self, scan_data: dict) -> dict:
        """Send scan data to server for assessment. Caches result.

        Uses cached result if scan data hash matches previous call.
        Reads project_id from .tlm/config.json (set by ensure_project).
        """
        scan_hash = hashlib.sha256(
            json.dumps(scan_data, sort_keys=True).encode()
        ).hexdigest()[:16]

        cache_file = self.cache_dir / "assess_result.json"

        # Check cache
        if cache_file.exists():
            try:
                cached = json.loads(cache_file.read_text())
                if cached.get("_scan_hash") == scan_hash:
                    return cached["result"]
            except (json.JSONDecodeError, OSError):
                pass

        # Get project_id from config
        config = load_project_config(str(self.root))
        project_id = config.get("project_id", 0)

        # Call server
        client = self._get_client()
        result = asyncio.run(client.assess(
            project_id,
            scan_data["file_tree"],
            scan_data["samples"],
        ))

        # Cache with hash
        cache_file.write_text(json.dumps({
            "_scan_hash": scan_hash,
            "result": result,
        }, indent=2))

        return result

    # ── Phase 4: Quality tier ────────────────────────────────

    def save_quality_tier(self, tier: str):
        """Save quality tier to project config."""
        save_project_config(str(self.root), {"quality_control": tier})

    # ── Phase 5: Gaps ────────────────────────────────────────

    def populate_gaps(self, recommendations: list[dict]):
        """Create gap entries from server recommendations."""
        for rec in recommendations:
            add_gap(str(self.root), {
                "id": rec["id"],
                "type": rec.get("type", rec["id"]),
                "category": rec.get("category", ""),
                "severity": rec.get("severity", "medium"),
                "description": rec.get("description", ""),
            })

    # ── Phase 7: Hooks ───────────────────────────────────────

    def install_hooks(self):
        """Install Claude Code hooks into .claude/settings.json."""
        settings_path = self.root / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)

        existing = {}
        if settings_path.exists():
            try:
                existing = json.loads(settings_path.read_text())
            except (json.JSONDecodeError, OSError):
                pass

        existing["hooks"] = build_all_hooks()
        settings_path.write_text(json.dumps(existing, indent=2))

    # ── Phase 8: Finalize ────────────────────────────────────

    def finalize(self):
        """Set state to idle. Install complete."""
        write_state(str(self.root), {"phase": "idle"})
