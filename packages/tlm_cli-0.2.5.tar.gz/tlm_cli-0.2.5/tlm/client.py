"""HTTP client for TLM server endpoints (V1 + V2)."""

import httpx


class TLMClient:
    """Client for TLM server API."""

    def __init__(self, server_url: str, api_key: str):
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}"}

    # ── V2 Endpoints ──────────────────────────────────────────

    async def assess(self, project_id: int, file_tree: str, samples: str) -> dict:
        """POST /api/v2/projects/{id}/assess"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/projects/{project_id}/assess",
                json={"file_tree": file_tree, "samples": samples},
                headers=self._headers(),
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()

    async def get_interview(
        self, project_id: int, rec_id: str, project_state: dict, quality_tier: str
    ) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/interview"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/projects/{project_id}/recommendations/{rec_id}/interview",
                json={"project_state": project_state, "quality_tier": quality_tier},
                headers=self._headers(),
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()

    async def build_context(
        self, project_id: int, rec_id: str, answers: dict,
        project_state: dict, quality_tier: str,
    ) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/context"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/projects/{project_id}/recommendations/{rec_id}/context",
                json={
                    "answers": answers,
                    "project_state": project_state,
                    "quality_tier": quality_tier,
                },
                headers=self._headers(),
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()

    async def review_plan(
        self, project_id: int, rec_id: str, plan_output: str,
        project_state: dict, quality_tier: str,
    ) -> dict:
        """POST /api/v2/projects/{id}/recommendations/{rec_id}/review"""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/projects/{project_id}/recommendations/{rec_id}/review",
                json={
                    "plan_output": plan_output,
                    "project_state": project_state,
                    "quality_tier": quality_tier,
                },
                headers=self._headers(),
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()

    # ── Auth Endpoints ─────────────────────────────────────────

    async def exchange_firebase_token(self, firebase_token: str) -> dict:
        """POST /api/v1/auth/firebase — exchange Firebase token for TLM API key.

        Does NOT send Authorization header (user has no API key yet).
        """
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v1/auth/firebase",
                json={"firebase_token": firebase_token},
                timeout=15,
            )
            resp.raise_for_status()
            return resp.json()

    # ── V1 Endpoints ──────────────────────────────────────────

    async def create_project(self, name: str, fingerprint: str) -> dict:
        """POST /api/v1/projects — create or get existing project."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v1/projects",
                json={"name": name, "fingerprint": fingerprint},
                headers=self._headers(),
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()

    async def me(self) -> dict:
        """GET /api/v1/auth/me — get current user info."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.server_url}/api/v1/auth/me",
                headers=self._headers(),
                timeout=15,
            )
            resp.raise_for_status()
            return resp.json()

    async def scan(self, project_id: int, file_tree: str, samples: str) -> dict:
        """POST /api/v1/projects/{id}/scan — V1 scan endpoint."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v1/projects/{project_id}/scan",
                json={"file_tree": file_tree, "samples": samples},
                headers=self._headers(),
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()

    async def review_code(
        self, project_id: int, spec: str, code: str,
        files_changed: list[str], project_knowledge: str = "",
        timeout: int = 120,
    ) -> dict:
        """POST /api/v2/review/code — server-side code review."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/review/code",
                json={
                    "project_id": project_id,
                    "spec": spec,
                    "code": code,
                    "files_changed": files_changed,
                    "project_knowledge": project_knowledge,
                },
                headers=self._headers(),
                timeout=timeout,
            )
            resp.raise_for_status()
            return resp.json()

    async def review_spec(
        self, project_id: int, spec: str,
        project_knowledge: str, quality_level: str,
        timeout: int = 120,
    ) -> dict:
        """POST /api/v2/review/spec — server-side spec review."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.server_url}/api/v2/review/spec",
                json={
                    "project_id": project_id,
                    "spec": spec,
                    "project_knowledge": project_knowledge,
                    "quality_level": quality_level,
                },
                headers=self._headers(),
                timeout=timeout,
            )
            resp.raise_for_status()
            return resp.json()
