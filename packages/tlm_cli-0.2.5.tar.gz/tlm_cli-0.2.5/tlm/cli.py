"""CLI entry point — tlm auth, install, scan, gaps, check, review, _hook."""

import asyncio
import json
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from tlm.config import (
    get_server_url,
    get_api_key,
    save_credentials,
    load_project_config,
)
from tlm.client import TLMClient
from tlm.installer import Installer
from tlm.gaps import load_gaps, get_active_gaps, get_gap_by_id, update_gap_status, GapStatus
from tlm.state import read_state, write_state, set_phase
from tlm.interviewer import Interviewer
from tlm.executor import Executor
from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_spec_review,
    hook_stop,
)

console = Console()

AUTH_URL = "https://tlm-auth-app.web.app"


def _is_firebase_token(token: str) -> bool:
    """Detect if a token is a Firebase JWT (3-part dot-separated, >100 chars)."""
    parts = token.split(".")
    return len(parts) == 3 and len(token) > 100


@click.group()
def main():
    """TLM — Tech Lead & Manager for your codebase."""
    pass


# ── Auth ──────────────────────────────────────────────────────

@main.command()
@click.argument("token", required=False, default=None)
@click.option("--server", default=None, help="TLM server URL")
def auth(token: str, server: str):
    """Authenticate with TLM server."""
    server_url = server or get_server_url()

    # Interactive mode: no token provided
    if token is None:
        console.print(f"\n1. Open: [bold]{AUTH_URL}[/bold]")
        console.print("2. Sign in with Google or email")
        console.print("3. Copy your token and paste it below\n")
        token = click.prompt("Paste your token").strip()

    client = TLMClient(server_url=server_url, api_key="")

    if token.startswith("tlm_sk_"):
        # Direct API key — verify with /auth/me
        client.api_key = token
        try:
            user = asyncio.run(client.me())
        except Exception as e:
            console.print(f"[red]Authentication failed: {e}[/red]")
            raise SystemExit(1)
        save_credentials(server_url, token)
        console.print(f"[green]Authenticated as {user.get('email', user.get('user_id', 'unknown'))}[/green]")

    elif _is_firebase_token(token):
        # Firebase JWT — exchange for API key
        try:
            result = asyncio.run(client.exchange_firebase_token(token))
        except Exception as e:
            console.print(f"[red]Token exchange failed: {e}[/red]")
            raise SystemExit(1)
        api_key = result["api_key"]
        save_credentials(server_url, api_key)
        console.print(f"[green]Authenticated as {result.get('email', result.get('user_id', 'unknown'))}[/green]")

    else:
        console.print("[red]Invalid token. Expected a TLM API key (tlm_sk_...) or a Firebase token.[/red]")
        raise SystemExit(1)

    console.print("Credentials saved to ~/.tlm/credentials.json")


# ── Install ───────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def install(path: str):
    """Install TLM in a project: scan, assess, set quality, track gaps, install hooks."""
    server_url = get_server_url()
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Welcome banner
    logo = Text()
    logo.append("████████╗██╗     ███╗   ███╗\n", style="bold cyan")
    logo.append("╚══██╔══╝██║     ████╗ ████║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██╔████╔██║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██║╚██╔╝██║\n", style="bold cyan")
    logo.append("   ██║   ███████╗██║ ╚═╝ ██║\n", style="bold cyan")
    logo.append("   ╚═╝   ╚══════╝╚═╝     ╚═╝\n", style="bold cyan")
    logo.append("  Your personal Tech Lead & Manager", style="dim")
    console.print(Panel(logo, border_style="cyan", padding=(1, 4)))

    installer = Installer(path, server_url=server_url, api_key=api_key)

    # Scan project
    with console.status("[cyan]Scanning your project...[/cyan]", spinner="dots"):
        installer.init_project_dir()
        project_id = installer.ensure_project()
        scan_data = installer.scan_project()
    console.print("  [green]✓[/green] Project structure analyzed")

    # Assess
    with console.status("[cyan]Analyzing recommendations...[/cyan]", spinner="dots"):
        result = installer.assess(scan_data)
    console.print("  [green]✓[/green] Recommendations ready")

    recommendations = result.get("recommendations", [])
    profile = result.get("profile", {})

    if profile:
        console.print(f"  [dim]Stack: {profile.get('stack', 'unknown')}[/dim]")

    # Quality tier
    console.print("\n[bold]Quality tier[/bold] — how strict should TLM be?\n")
    console.print(
        "  [bold]HIGH[/bold]     — Block on any gap. Spec review required. Multi-model code review.\n"
        "  [bold]STANDARD[/bold] — Block on critical gaps. Spec review on blockers. Single-model review.\n"
        "  [bold]RELAXED[/bold]  — Warn only. No spec blocking. Mechanical checks only.\n"
    )

    tier_input = click.prompt(
        "Recommended: HIGH [Enter to accept, or type standard/relaxed]",
        default="high",
        show_default=False,
    ).strip().lower()

    if tier_input not in ("high", "standard", "relaxed"):
        tier_input = "high"

    installer.save_quality_tier(tier_input)
    console.print(f"  [green]✓[/green] Quality tier: [bold]{tier_input}[/bold]")

    # Gaps
    if recommendations:
        console.print(f"\n[yellow]⚠[/yellow] [bold]{len(recommendations)} gap(s) found[/bold]")

        table = Table()
        table.add_column("Severity", style="bold")
        table.add_column("Category")
        table.add_column("Description")

        severity_colors = {
            "critical": "red",
            "high": "yellow",
            "medium": "blue",
            "low": "dim",
        }

        for rec in recommendations:
            sev = rec["severity"]
            color = severity_colors.get(sev, "white")
            table.add_row(
                f"[{color}]{sev}[/{color}]",
                rec["category"],
                rec["description"],
            )

        console.print(table)

        installer.populate_gaps(recommendations)

        handle = click.prompt(
            "\nFix these gaps now? [Y/n]",
            default="n",
            show_default=False,
        ).strip().lower()

        if handle == "y":
            console.print("[dim]Run 'tlm fix' to address gaps.[/dim]")
    else:
        console.print("\n[green]✓ No gaps detected![/green]")

    # Hooks
    installer.install_hooks()
    console.print("  [green]✓[/green] Hooks installed")

    # Finalize
    installer.finalize()
    console.print("\n[green bold]✓ TLM installed![/green bold]")
    console.print("\n[bold]Next step:[/bold] restart Claude Code so hooks take effect.")
    console.print("[dim]  Press [bold]q[/bold] or [bold]Ctrl+C[/bold] to exit, then:[/dim]")
    console.print("[dim]  • [bold]claude[/bold]                        → start fresh[/dim]")
    console.print("[dim]  • [bold]claude --continue[/bold]             → resume last conversation[/dim]")
    console.print("[dim]  • [bold]claude --resume <session_id>[/bold]  → resume a specific session[/dim]")


# ── Fix ──────────────────────────────────────────────────────

@main.command()
@click.argument("gap_id", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
@click.option("--skip-review", is_flag=True, help="Skip server review step")
def fix(gap_id: str, path: str, skip_review: bool):
    """Fix a project gap: interview, plan, execute, review."""
    api_key = get_api_key()
    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    active = get_active_gaps(path)
    if not active:
        console.print("[green]No active gaps to fix.[/green]")
        return

    # Gap selection
    if gap_id:
        gap = get_gap_by_id(path, gap_id)
        if not gap:
            console.print(f"[red]Gap '{gap_id}' not found.[/red]")
            raise SystemExit(1)
    else:
        console.print("[bold]Active gaps:[/bold]")
        for i, g in enumerate(active, 1):
            console.print(f"  {i}. [{g['severity']}] {g['id']} — {g['description']}")

        choice = click.prompt("Select gap to fix", type=int)
        if choice < 1 or choice > len(active):
            console.print("[red]Invalid selection.[/red]")
            raise SystemExit(1)
        gap = active[choice - 1]
        gap_id = gap["id"]

    server_url = get_server_url()
    config = load_project_config(path)
    project_id = config.get("project_id")
    quality_tier = config.get("quality_tier", "high")
    project_state = read_state(path)

    client = TLMClient(server_url=server_url, api_key=api_key)

    # Phase 1: Interview
    write_state(path, {"phase": "tlm_active", "activity_type": "gap_fix"})
    console.print(f"\n[bold]Fixing gap: {gap_id}[/bold]")

    interview_data = asyncio.run(
        client.get_interview(project_id, gap_id, project_state, quality_tier)
    )

    intro = interview_data.get("intro", "")
    questions = interview_data.get("questions", [])

    if intro:
        console.print(f"\n{intro}\n")

    interviewer = Interviewer(questions)
    answers = interviewer.run()

    # Phase 2: Build context
    context = asyncio.run(
        client.build_context(project_id, gap_id, answers, project_state, quality_tier)
    )

    system_prompt = context.get("system_prompt", "")
    instructions = context.get("instructions", "")

    # Phase 3: Plan + Execute
    set_phase(path, "implementation")

    executor = Executor()
    plan_output = executor.plan(system_prompt, instructions)

    console.print("\n[bold]Plan:[/bold]")
    console.print(plan_output)

    approve = click.prompt("\nApprove this plan? [y/n]", default="y").strip().lower()
    if approve != "y":
        set_phase(path, "idle")
        console.print("[yellow]Plan rejected. Gap not fixed.[/yellow]")
        return

    execution_output = executor.execute(plan_output)
    console.print("\n[bold]Execution complete.[/bold]")

    # Phase 4: Review
    if not skip_review:
        review = asyncio.run(
            client.review_plan(project_id, gap_id, plan_output, project_state, quality_tier)
        )

        verdict = review.get("verdict", "unknown")
        feedback = review.get("feedback", "")

        console.print(f"\n[bold]Review verdict: {verdict}[/bold]")
        if feedback:
            console.print(f"Feedback: {feedback}")

        if verdict in ("pass", "warn"):
            update_gap_status(path, gap_id, GapStatus.RESOLVED)
            console.print(f"[green]Gap '{gap_id}' resolved.[/green]")
        else:
            console.print(f"[yellow]Gap '{gap_id}' not resolved — review failed.[/yellow]")
    else:
        update_gap_status(path, gap_id, GapStatus.RESOLVED)
        console.print(f"[green]Gap '{gap_id}' resolved (review skipped).[/green]")

    set_phase(path, "idle")


# ── Scan ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def scan(path: str):
    """Scan project and show recommendations."""
    server_url = get_server_url()
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    installer = Installer(path, server_url=server_url, api_key=api_key)
    installer.init_project_dir()
    installer.ensure_project()

    scan_data = installer.scan_project()
    result = installer.assess(scan_data)

    recommendations = result.get("recommendations", [])
    if not recommendations:
        console.print("[green]No issues found![/green]")
        return

    table = Table(title="Project Recommendations")
    table.add_column("ID", style="cyan")
    table.add_column("Category", style="white")
    table.add_column("Severity", style="bold")
    table.add_column("Description")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for rec in recommendations:
        sev = rec["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            rec["id"],
            rec["category"],
            f"[{color}]{sev}[/{color}]",
            rec["description"],
        )

    console.print(table)


# ── Gaps ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def gaps(path: str):
    """Show current project gaps."""
    active = get_active_gaps(path)

    if not active:
        console.print("[green]No active gaps. Project is clean.[/green]")
        return

    table = Table(title=f"Active Gaps ({len(active)})")
    table.add_column("ID", style="cyan")
    table.add_column("Severity", style="bold")
    table.add_column("Category")
    table.add_column("Description")
    table.add_column("Status")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for gap in active:
        sev = gap["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            gap["id"],
            f"[{color}]{sev}[/{color}]",
            gap.get("category", ""),
            gap["description"],
            gap["status"],
        )

    console.print(table)


# ── Check ─────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
def check(path: str):
    """Run quality checks before deployment."""
    state = read_state(path)
    active = get_active_gaps(path)

    console.print("[bold]TLM Quality Check[/bold]\n")
    console.print(f"Phase: {state.get('phase', 'unknown')}")

    if active:
        critical = [g for g in active if g["severity"] == "critical"]
        console.print(f"Active gaps: {len(active)} ({len(critical)} critical)")
        if critical:
            console.print("[red]Cannot deploy with critical gaps.[/red]")
            raise SystemExit(1)
    else:
        console.print("[green]No active gaps.[/green]")

    console.print("\n[green]Quality check passed.[/green]")


# ── Review ───────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--show-last", is_flag=True, default=False, help="Display cached last review result")
@click.option("--path", default=".", help="Project root path")
@click.pass_context
def review(ctx, show_last: bool, path: str):
    """Review specs or code against TLM server."""
    ctx.ensure_object(dict)
    ctx.obj["path"] = path

    if not show_last and ctx.invoked_subcommand is not None:
        return

    if show_last:
        cache_file = Path(path) / ".tlm" / "cache" / "last_review.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text())
                severity = data.get("severity", data.get("combined_verdict", "unknown"))
                console.print(f"[bold]Last review result:[/bold] {severity}")

                gaps = data.get("gaps", [])
                if gaps:
                    console.print(f"\nGaps ({len(gaps)}):")
                    for gap in gaps:
                        console.print(f"  [{gap.get('severity', 'medium')}] {gap.get('description', '')}")

                issues = data.get("issues", [])
                if issues:
                    console.print(f"\nIssues ({len(issues)}):")
                    for issue in issues:
                        console.print(f"  [{issue.get('severity', 'medium')}] {issue.get('description', '')}")

                questions = data.get("follow_up_questions", [])
                if questions:
                    console.print("\nFollow-up questions:")
                    for q in questions:
                        console.print(f"  - {q}")
            except (json.JSONDecodeError, OSError):
                console.print("[red]Cannot read cached review.[/red]")
        else:
            console.print("[dim]No cached review found. Run 'tlm review spec' or 'tlm review code' first.[/dim]")


@review.command(name="spec")
@click.argument("spec_path", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
def review_spec(spec_path: str, path: str):
    """Review a spec file (default: latest in .tlm/specs/)."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Find spec
    if spec_path is None:
        specs_dir = Path(path) / ".tlm" / "specs"
        if not specs_dir.exists():
            console.print("[red]No .tlm/specs/ directory found.[/red]")
            raise SystemExit(1)

        spec_files = sorted(specs_dir.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)
        if not spec_files:
            console.print("[red]No spec files found in .tlm/specs/.[/red]")
            raise SystemExit(1)

        spec_path = str(spec_files[0])
        console.print(f"[dim]Using latest spec: {spec_files[0].name}[/dim]")

    # Read spec
    try:
        spec_content = Path(spec_path).read_text()
    except OSError:
        console.print(f"[red]Cannot read spec: {spec_path}[/red]")
        raise SystemExit(1)

    # Load config
    config = load_project_config(path)
    project_id = config.get("project_id", 0)
    quality = config.get("quality_control", "standard")

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    # Call server
    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print("[dim]Reviewing spec...[/dim]")
    try:
        result = asyncio.run(client.review_spec(
            project_id=project_id,
            spec=spec_content,
            project_knowledge=knowledge,
            quality_level=quality,
        ))
    except Exception as e:
        console.print(f"[red]Review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    severity = result.get("severity", "unknown")
    severity_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = severity_colors.get(severity, "white")
    console.print(f"\n[bold]Spec Review: [{color}]{severity.upper()}[/{color}][/bold]")

    gaps = result.get("gaps", [])
    if gaps:
        table = Table(title=f"Gaps ({len(gaps)})")
        table.add_column("Severity", style="bold")
        table.add_column("Description")
        for gap in gaps:
            table.add_row(gap.get("severity", "medium"), gap.get("description", ""))
        console.print(table)

    questions = result.get("follow_up_questions", [])
    if questions:
        console.print("\n[bold]Follow-up questions:[/bold]")
        for q in questions:
            console.print(f"  - {q}")


@review.command(name="code")
@click.option("--path", default=".", help="Project root path")
def review_code(path: str):
    """Review staged git changes against active spec."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Get git diff
    try:
        diff_result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, cwd=path, timeout=10,
        )
        names_result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True, text=True, cwd=path, timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        console.print(f"[red]git diff failed: {e}[/red]")
        raise SystemExit(1)

    diff_text = diff_result.stdout.strip()
    files_changed = [f for f in names_result.stdout.strip().split("\n") if f]

    if not diff_text:
        console.print("[yellow]No staged changes to review. Stage changes with 'git add' first.[/yellow]")
        raise SystemExit(1)

    # Load active spec
    state = read_state(path)
    active_spec = state.get("active_spec")
    spec_content = ""
    if active_spec:
        try:
            spec_content = Path(active_spec).read_text()
        except OSError:
            pass

    if not spec_content:
        console.print("[yellow]No active spec found. Run 'tlm review spec' first.[/yellow]")
        raise SystemExit(1)

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    config = load_project_config(path)
    project_id = config.get("project_id", 0)

    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print(f"[dim]Reviewing {len(files_changed)} changed file(s)...[/dim]")
    try:
        result = asyncio.run(client.review_code(
            project_id=project_id,
            spec=spec_content,
            code=diff_text,
            files_changed=files_changed,
            project_knowledge=knowledge,
        ))
    except Exception as e:
        console.print(f"[red]Code review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    verdict = result.get("combined_verdict", "unknown")
    verdict_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = verdict_colors.get(verdict, "white")
    console.print(f"\n[bold]Code Review: [{color}]{verdict.upper()}[/{color}][/bold]")

    issues = result.get("issues", [])
    if issues:
        table = Table(title=f"Issues ({len(issues)})")
        table.add_column("Severity", style="bold")
        table.add_column("Description")
        for issue in issues:
            table.add_row(issue.get("severity", "medium"), issue.get("description", ""))
        console.print(table)

    reviews = result.get("reviews", [])
    if reviews:
        console.print("\n[bold]Model reviews:[/bold]")
        for r in reviews:
            console.print(f"  {r.get('model', 'unknown')}: {r.get('verdict', 'unknown')}")


# ── Hook dispatch ─────────────────────────────────────────────

@main.command(name="_hook")
@click.argument("hook_name")
@click.option("--path", default=".", help="Project root path")
def hook_dispatch(hook_name: str, path: str):
    """Internal: dispatch to hook handlers. Called by Claude Code hooks."""
    if hook_name == "session_start":
        result = hook_session_start(path)
        # session_start returns a string, print it directly
        print(result)

    elif hook_name == "prompt_submit":
        # Read prompt from stdin if available
        prompt_text = ""
        if not sys.stdin.isatty():
            try:
                data = json.loads(sys.stdin.read())
                prompt_text = data.get("prompt", "")
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_prompt_submit(path, prompt_text)
        print(json.dumps(result))

    elif hook_name == "guard":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_guard(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "compliance":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_compliance_gate(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "deployment":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_deployment_gate(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "spec_review":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_spec_review(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "stop":
        result = hook_stop(path)
        print(json.dumps(result))

    else:
        console.print(f"[red]Unknown hook: {hook_name}[/red]")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
