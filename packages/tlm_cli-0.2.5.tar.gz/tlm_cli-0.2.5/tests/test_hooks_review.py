"""Tests for server-backed review hooks — spec review + enhanced compliance."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, AsyncMock, MagicMock

from tlm.hooks import (
    _is_spec_file,
    _get_review_client,
    _run_spec_review,
    _run_code_review,
    _format_review_context,
    hook_spec_review,
    hook_compliance_gate,
)
from tlm.state import write_state
from tlm.config import save_project_config


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": 42,
    })
    return tmp_path


# ── _is_spec_file ──────────────────────────────────────────────


class TestIsSpecFile:
    def test_spec_in_tlm_specs_dir(self):
        """Files in .tlm/specs/ should be detected as spec files."""
        assert _is_spec_file("/project/.tlm/specs/auth.md") is True

    def test_spec_in_nested_tlm_specs(self):
        """Nested .tlm/specs/ path should match."""
        assert _is_spec_file("/home/user/project/.tlm/specs/feature-login.md") is True

    def test_non_spec_file(self):
        """Regular source files should not be spec files."""
        assert _is_spec_file("/project/src/app.py") is False

    def test_tlm_non_spec_file(self):
        """Files in .tlm/ but not in specs/ should not be spec files."""
        assert _is_spec_file("/project/.tlm/config.json") is False

    def test_specs_dir_outside_tlm(self):
        """specs/ directory not inside .tlm/ should not match."""
        assert _is_spec_file("/project/specs/design.md") is False


# ── _get_review_client ─────────────────────────────────────────


class TestGetReviewClient:
    @patch("tlm.hooks.get_api_key", return_value="tlm_sk_abc")
    @patch("tlm.hooks.get_server_url", return_value="http://test:8003")
    def test_returns_client_when_authenticated(self, mock_url, mock_key, tlm_project):
        """Should return a TLMClient when credentials are available."""
        client = _get_review_client(str(tlm_project))
        assert client is not None
        assert client.api_key == "tlm_sk_abc"
        assert client.server_url == "http://test:8003"

    @patch("tlm.hooks.get_api_key", return_value="")
    def test_returns_none_when_not_authenticated(self, mock_key, tlm_project):
        """Should return None when no API key is available."""
        client = _get_review_client(str(tlm_project))
        assert client is None


# ── _run_spec_review ───────────────────────────────────────────


class TestRunSpecReview:
    @patch("tlm.hooks._get_review_client")
    def test_returns_review_result_on_success(self, mock_get_client, tlm_project):
        """Should return server review result on success."""
        mock_client = AsyncMock()
        mock_client.review_spec = AsyncMock(return_value={
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        })
        mock_get_client.return_value = mock_client

        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec\n\nImplement OAuth2")

        result = _run_spec_review(str(tlm_project), str(spec_path))
        assert result.get("severity") == "pass"

    @patch("tlm.hooks._get_review_client")
    def test_returns_error_on_timeout(self, mock_get_client, tlm_project):
        """Should return error dict on timeout."""
        import httpx
        mock_client = AsyncMock()
        mock_client.review_spec = AsyncMock(
            side_effect=httpx.TimeoutException("timeout")
        )
        mock_get_client.return_value = mock_client

        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")

        result = _run_spec_review(str(tlm_project), str(spec_path))
        assert "error" in result

    @patch("tlm.hooks._get_review_client")
    def test_returns_error_when_not_authenticated(self, mock_get_client, tlm_project):
        """Should return error dict when client is None."""
        mock_get_client.return_value = None

        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")

        result = _run_spec_review(str(tlm_project), str(spec_path))
        assert "error" in result


# ── _run_code_review ───────────────────────────────────────────


class TestRunCodeReview:
    @patch("tlm.hooks._get_review_client")
    @patch("tlm.hooks.subprocess.run")
    def test_returns_review_result_on_success(self, mock_run, mock_get_client, tlm_project):
        """Should return server code review on success."""
        # Mock git diff and git diff --name-only
        mock_run.side_effect = [
            MagicMock(stdout="diff --git a/app.py\n+new code", returncode=0),
            MagicMock(stdout="app.py\n", returncode=0),
        ]

        mock_client = AsyncMock()
        mock_client.review_code = AsyncMock(return_value={
            "combined_verdict": "pass",
            "reviews": [],
            "issues": [],
        })
        mock_get_client.return_value = mock_client

        # Set active spec
        spec_path = tlm_project / ".tlm" / "specs" / "auth.md"
        spec_path.write_text("# Auth Spec")
        write_state(str(tlm_project), {
            "phase": "implementation",
            "active_spec": str(spec_path),
        })

        result = _run_code_review(str(tlm_project), "git commit -m 'test'")
        assert result.get("combined_verdict") == "pass"

    @patch("tlm.hooks._get_review_client")
    @patch("tlm.hooks.subprocess.run")
    def test_returns_error_on_empty_diff(self, mock_run, mock_get_client, tlm_project):
        """Should return error when git diff is empty."""
        mock_run.side_effect = [
            MagicMock(stdout="", returncode=0),
            MagicMock(stdout="", returncode=0),
        ]

        mock_client = AsyncMock()
        mock_get_client.return_value = mock_client

        result = _run_code_review(str(tlm_project), "git commit -m 'test'")
        assert "error" in result

    @patch("tlm.hooks._get_review_client")
    def test_returns_error_when_not_authenticated(self, mock_get_client, tlm_project):
        """Should return error when client is None."""
        mock_get_client.return_value = None

        result = _run_code_review(str(tlm_project), "git commit -m 'test'")
        assert "error" in result


# ── _format_review_context ─────────────────────────────────────


class TestFormatReviewContext:
    def test_formats_spec_review_pass(self):
        """Should format a passing spec review."""
        result = {
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        }
        output = _format_review_context(result, "spec")
        assert "pass" in output.lower() or "PASS" in output or "approved" in output.lower()

    def test_formats_spec_review_with_gaps(self):
        """Should include gap details in formatted output."""
        result = {
            "severity": "warn",
            "gaps": [{"description": "Missing error handling", "severity": "medium"}],
            "follow_up_questions": ["What happens on timeout?"],
        }
        output = _format_review_context(result, "spec")
        assert "error handling" in output.lower() or "gap" in output.lower()

    def test_formats_code_review(self):
        """Should format a code review result."""
        result = {
            "combined_verdict": "pass",
            "reviews": [{"model": "anthropic", "verdict": "pass"}],
            "issues": [],
        }
        output = _format_review_context(result, "code")
        assert "pass" in output.lower() or "PASS" in output

    def test_formats_error_result(self):
        """Should handle error results gracefully."""
        result = {"error": "Connection timeout"}
        output = _format_review_context(result, "spec")
        assert "timeout" in output.lower() or "error" in output.lower() or "warning" in output.lower()


# ── hook_spec_review ───────────────────────────────────────────


class TestHookSpecReview:
    def test_ignores_non_spec_files(self, tlm_project):
        """Should return empty dict for non-spec files."""
        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/src/app.py"},
        })
        assert result == {}

    def test_auto_approves_on_relaxed_quality(self, tlm_project):
        """Should auto-approve spec on relaxed quality tier."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")

        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        # Should set spec_review_status to approved in state
        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("spec_review_status") == "approved"

    @patch("tlm.hooks._run_spec_review")
    def test_approves_on_pass(self, mock_run, tlm_project):
        """Should set spec_review_status to approved on pass severity."""
        mock_run.return_value = {
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        }

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("spec_review_status") == "approved"
        assert "additionalContext" in result

    @patch("tlm.hooks._run_spec_review")
    def test_approves_on_warn(self, mock_run, tlm_project):
        """Should set spec_review_status to approved on warn severity."""
        mock_run.return_value = {
            "severity": "warn",
            "gaps": [{"description": "Minor gap", "severity": "low"}],
            "follow_up_questions": [],
        }

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("spec_review_status") == "approved"

    @patch("tlm.hooks._run_spec_review")
    def test_rejects_on_fail(self, mock_run, tlm_project):
        """Should set spec_review_status to rejected on fail severity."""
        mock_run.return_value = {
            "severity": "fail",
            "gaps": [{"description": "Critical flaw", "severity": "critical"}],
            "follow_up_questions": ["How do you handle X?"],
        }

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("spec_review_status") == "rejected"

    @patch("tlm.hooks._run_spec_review")
    def test_degrades_on_error(self, mock_run, tlm_project):
        """Should degrade to approved with warning on server error."""
        mock_run.return_value = {"error": "Connection timeout"}

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        result = hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("spec_review_status") == "approved"

    @patch("tlm.hooks._run_spec_review")
    def test_caches_result(self, mock_run, tlm_project):
        """Should cache review result to .tlm/cache/last_review.json."""
        mock_run.return_value = {
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        }

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        cache_file = tlm_project / ".tlm" / "cache" / "last_review.json"
        assert cache_file.exists()

    @patch("tlm.hooks._run_spec_review")
    def test_sets_active_spec(self, mock_run, tlm_project):
        """Should set active_spec in state when spec is reviewed."""
        mock_run.return_value = {
            "severity": "pass",
            "gaps": [],
            "follow_up_questions": [],
        }

        spec_path = str(tlm_project / ".tlm" / "specs" / "auth.md")
        (Path(spec_path)).write_text("# Auth Spec")

        hook_spec_review(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": spec_path},
        })

        from tlm.state import read_state
        state = read_state(str(tlm_project))
        assert state.get("active_spec") == spec_path


# ── Enhanced hook_compliance_gate ──────────────────────────────


class TestEnhancedComplianceGate:
    def test_relaxed_uses_text_only(self, tlm_project):
        """Relaxed quality should keep text-only behavior (no server call)."""
        save_project_config(str(tlm_project), {"quality_control": "relaxed"})

        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })

        assert "additionalContext" in result
        assert result.get("decision") != "block"

    @patch("tlm.hooks._run_code_review")
    def test_standard_warns_on_fail(self, mock_run, tlm_project):
        """Standard quality should warn (not block) on code review fail."""
        save_project_config(str(tlm_project), {"quality_control": "standard"})

        mock_run.return_value = {
            "combined_verdict": "fail",
            "issues": [{"description": "Security issue", "severity": "high"}],
        }

        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })

        assert "additionalContext" in result
        assert result.get("decision") != "block"

    @patch("tlm.hooks._run_code_review")
    def test_high_blocks_on_fail(self, mock_run, tlm_project):
        """High quality should block on code review fail."""
        save_project_config(str(tlm_project), {"quality_control": "high"})

        mock_run.return_value = {
            "combined_verdict": "fail",
            "issues": [{"description": "Security issue", "severity": "critical"}],
        }

        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })

        assert result.get("decision") == "block"

    @patch("tlm.hooks._run_code_review")
    def test_passes_on_pass_verdict(self, mock_run, tlm_project):
        """Should return context (not block) when code review passes."""
        save_project_config(str(tlm_project), {"quality_control": "high"})

        mock_run.return_value = {
            "combined_verdict": "pass",
            "issues": [],
        }

        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })

        assert result.get("decision") != "block"
        assert "additionalContext" in result

    @patch("tlm.hooks._run_code_review")
    def test_degrades_on_server_error(self, mock_run, tlm_project):
        """Should fall back to text-only on server error."""
        save_project_config(str(tlm_project), {"quality_control": "high"})

        mock_run.return_value = {"error": "Connection timeout"}

        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })

        # Should NOT block — graceful degradation
        assert result.get("decision") != "block"
        assert "additionalContext" in result
