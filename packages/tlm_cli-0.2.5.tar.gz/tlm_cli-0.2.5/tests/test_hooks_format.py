"""Tests for hooks_format — hook entry builder and format abstraction."""

import pytest

from tlm.hooks_format import build_hook_entry, build_all_hooks


class TestBuildHookEntry:
    def test_basic_hook(self):
        """Build a hook with just a command (no matcher)."""
        entry = build_hook_entry("tlm _hook session_start")
        assert entry == {
            "hooks": [{"type": "command", "command": "tlm _hook session_start"}],
        }

    def test_hook_with_matcher(self):
        """Build a hook with a tool matcher."""
        entry = build_hook_entry("tlm _hook guard", matcher="Write")
        assert entry == {
            "matcher": "Write",
            "hooks": [{"type": "command", "command": "tlm _hook guard"}],
        }

    def test_hook_without_matcher_has_no_matcher_key(self):
        """When matcher is None, entry should not have matcher key."""
        entry = build_hook_entry("tlm _hook stop")
        assert "matcher" not in entry


class TestBuildAllHooks:
    def test_returns_dict(self):
        """build_all_hooks should return a dict keyed by event name."""
        hooks = build_all_hooks()
        assert isinstance(hooks, dict)

    def test_has_session_start(self):
        """Should include SessionStart event."""
        hooks = build_all_hooks()
        assert "SessionStart" in hooks

    def test_has_user_prompt_submit(self):
        """Should include UserPromptSubmit event."""
        hooks = build_all_hooks()
        assert "UserPromptSubmit" in hooks

    def test_has_pre_tool_use(self):
        """Should include PreToolUse event."""
        hooks = build_all_hooks()
        assert "PreToolUse" in hooks

    def test_has_post_tool_use(self):
        """Should include PostToolUse event."""
        hooks = build_all_hooks()
        assert "PostToolUse" in hooks

    def test_has_stop(self):
        """Should include Stop event."""
        hooks = build_all_hooks()
        assert "Stop" in hooks

    def test_pre_tool_use_has_write_guard(self):
        """PreToolUse should include Write guard."""
        hooks = build_all_hooks()
        write_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Write"]
        assert len(write_hooks) == 1

    def test_pre_tool_use_has_edit_guard(self):
        """PreToolUse should include Edit guard."""
        hooks = build_all_hooks()
        edit_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Edit"]
        assert len(edit_hooks) == 1

    def test_pre_tool_use_has_bash_compliance(self):
        """PreToolUse should include Bash compliance hook."""
        hooks = build_all_hooks()
        bash_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Bash"]
        assert len(bash_hooks) == 1

    def test_post_tool_use_has_write_spec_review(self):
        """PostToolUse should include Write spec_review hook."""
        hooks = build_all_hooks()
        write_hooks = [h for h in hooks["PostToolUse"] if h.get("matcher") == "Write"]
        assert len(write_hooks) == 1

    def test_all_hooks_have_correct_structure(self):
        """Every hook entry should have hooks list with command type."""
        hooks = build_all_hooks()
        for event, entries in hooks.items():
            assert isinstance(entries, list), f"{event} should be a list"
            for entry in entries:
                assert "hooks" in entry
                assert isinstance(entry["hooks"], list)
                assert len(entry["hooks"]) == 1
                assert entry["hooks"][0]["type"] == "command"
                assert entry["hooks"][0]["command"].startswith("tlm _hook")

    def test_event_without_matcher_has_no_matcher_key(self):
        """SessionStart/Stop entries should not have matcher key."""
        hooks = build_all_hooks()
        for entry in hooks["SessionStart"]:
            assert "matcher" not in entry
        for entry in hooks["Stop"]:
            assert "matcher" not in entry
