"""Tests for CLI — auth, install, scan, gaps, check, _hook commands."""

import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main, _is_firebase_token, AUTH_URL
from tlm.gaps import GapStatus


class TestIsFirebaseToken:
    def test_detects_firebase_jwt(self):
        """3-part dot-separated token >100 chars should be detected as Firebase."""
        # Realistic Firebase JWT structure (header.payload.signature)
        token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        assert _is_firebase_token(token) is True

    def test_rejects_tlm_api_key(self):
        """tlm_sk_ prefixed keys should NOT be detected as Firebase."""
        assert _is_firebase_token("tlm_sk_abc123") is False

    def test_rejects_short_token(self):
        """Short tokens should NOT be detected as Firebase."""
        assert _is_firebase_token("short.but.jwt") is False


class TestAuthCommand:
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_direct_api_key(self, mock_client_cls, mock_save):
        """tlm auth <tlm_sk_...> should verify and save directly."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_abc123"])

        assert result.exit_code == 0
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_firebase_exchange(self, mock_client_cls, mock_save):
        """tlm auth <firebase_jwt> should exchange for API key and save."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(return_value={
            "api_key": "tlm_sk_exchanged",
            "user_id": 1,
            "email": "user@example.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code == 0
        assert "user@example.com" in result.output
        mock_client.exchange_firebase_token.assert_called_once_with(firebase_token)
        # Should save the exchanged API key, not the Firebase token
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_exchanged"

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_interactive_prompt(self, mock_client_cls, mock_save):
        """tlm auth (no args) should show URL and prompt for token."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input="tlm_sk_from_prompt\n")

        assert result.exit_code == 0
        assert AUTH_URL in result.output
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_interactive_firebase(self, mock_client_cls, mock_save):
        """Interactive mode: pasting a Firebase JWT should exchange it."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(return_value={
            "api_key": "tlm_sk_interactive",
            "user_id": 1,
            "email": "firebase@x.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input=firebase_token + "\n")

        assert result.exit_code == 0
        assert "firebase@x.com" in result.output
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_interactive"

    def test_auth_invalid_token(self):
        """tlm auth <garbage> should show error."""
        runner = CliRunner()
        result = runner.invoke(main, ["auth", "not-a-valid-token"])

        assert result.exit_code != 0
        assert "invalid" in result.output.lower()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_custom_server(self, mock_client_cls, mock_save):
        """tlm auth --server should use custom server URL."""
        mock_client = AsyncMock()
        mock_client.me = AsyncMock(return_value={"user_id": 1})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_key", "--server", "http://custom:9000"])

        assert result.exit_code == 0
        save_call = mock_save.call_args
        assert save_call[0][0] == "http://custom:9000"

    @patch("tlm.cli.TLMClient")
    def test_auth_exchange_failure(self, mock_client_cls):
        """Firebase exchange failure should show error."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = AsyncMock()
        mock_client.exchange_firebase_token = AsyncMock(
            side_effect=Exception("Invalid Firebase token")
        )
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code != 0
        assert "failed" in result.output.lower()


class TestInstallCommand:
    @patch("tlm.cli.Installer")
    def test_install_runs_full_flow(self, mock_installer_cls, tmp_path):
        """tlm install should run scan → assess → quality → gaps → hooks."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        # Input: quality tier choice + gap handling (yes/no/choose)
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="\nn\n")

        assert result.exit_code == 0
        mock_installer.init_project_dir.assert_called_once()
        mock_installer.scan_project.assert_called_once()
        mock_installer.assess.assert_called_once()
        mock_installer.install_hooks.assert_called_once()
        mock_installer.finalize.assert_called_once()


class TestScanCommand:
    @patch("tlm.cli.Installer")
    def test_scan_shows_recommendations(self, mock_installer_cls, tmp_path):
        """tlm scan should display recommendations."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD pipeline", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output


class TestGapsCommand:
    def test_gaps_shows_active_gaps(self, tmp_path):
        """tlm gaps should show active gaps."""
        from tlm.gaps import add_gap
        from tlm.state import write_state

        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output

    def test_gaps_no_gaps(self, tmp_path):
        """tlm gaps should show message when no gaps."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "no" in result.output.lower() or "clean" in result.output.lower()


class TestHookCommand:
    def test_hook_session_start(self, tmp_path):
        """_hook session_start should call hook_session_start."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "session_start", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_prompt_submit(self, tmp_path):
        """_hook prompt_submit should return JSON."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "prompt_submit", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_guard(self, tmp_path):
        """_hook guard should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "guard", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0

    def test_hook_compliance(self, tmp_path):
        """_hook compliance should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({"command": "python -m pytest tests/"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "compliance", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0


class TestFixCommand:
    """Tests for `tlm fix` — gap remediation command."""

    def _setup_gaps(self, tmp_path, gaps=None):
        """Helper: write .tlm/gaps.json and config.json."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir(exist_ok=True)

        if gaps is None:
            gaps = [
                {
                    "id": "cicd",
                    "type": "cicd",
                    "category": "CI/CD",
                    "severity": "critical",
                    "description": "No CI/CD pipeline",
                    "status": "detected",
                    "dismiss_reason": None,
                    "detected_at": "2026-02-22",
                    "resolved_at": None,
                },
                {
                    "id": "testing",
                    "type": "testing",
                    "category": "Testing",
                    "severity": "high",
                    "description": "Low test coverage",
                    "status": "detected",
                    "dismiss_reason": None,
                    "detected_at": "2026-02-22",
                    "resolved_at": None,
                },
            ]

        (tlm_dir / "gaps.json").write_text(json.dumps(gaps))
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 42,
            "quality_tier": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))

    # ── Edge cases ────────────────────────────────────────────

    def test_fix_no_active_gaps(self, tmp_path):
        """tlm fix with no active gaps should show message and exit cleanly."""
        self._setup_gaps(tmp_path, gaps=[])

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "no" in result.output.lower() and "gap" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="")
    def test_fix_not_authenticated(self, mock_key, tmp_path):
        """tlm fix without auth should show error."""
        self._setup_gaps(tmp_path)

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert "auth" in result.output.lower()

    # ── Gap selection ─────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_shows_gap_selection(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix (no arg) should list active gaps and let user pick."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [{"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "You are a CI/CD expert",
            "instructions": "Set up GitHub Actions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "Looks good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan: create .github/workflows/ci.yml"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        # User selects gap #1 (cicd), then approves plan
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)], input="1\ny\n")

        assert result.exit_code == 0
        # Should show the gap list
        assert "cicd" in result.output.lower() or "CI/CD" in result.output

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_with_gap_id(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix cicd should skip selection and go straight to interview."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [{"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "You are a CI/CD expert",
            "instructions": "Set up GitHub Actions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "Looks good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan: create CI"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        # Approve plan
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        # Should call get_interview with the cicd gap
        mock_client.get_interview.assert_called_once()
        call_args = mock_client.get_interview.call_args
        assert call_args[1].get("rec_id", call_args[0][1] if len(call_args[0]) > 1 else None) == "cicd" or call_args[0][1] == "cicd"

    # ── Full flow ─────────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_runs_interview(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call get_interview and run Interviewer."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [
                {"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"},
                {"id": "q2", "question": "Branch?", "options": ["main"], "default": "main"},
            ],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions", "q2": "main"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.get_interview.assert_called_once()
        mock_inter_cls.assert_called_once()
        mock_interviewer.run.assert_called_once()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_builds_context(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call build_context with interview answers."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "You are expert",
            "instructions": "Do the thing",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.build_context.assert_called_once()
        call_args = mock_client.build_context.call_args
        # answers should be passed
        assert call_args[1].get("answers") == {"q1": "A"} or call_args[0][2] == {"q1": "A"}

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_executes_plan(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call executor.plan then executor.execute."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "The Plan"
        mock_executor.execute.return_value = "Executed"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_executor.plan.assert_called_once_with("system", "instructions")
        mock_executor.execute.assert_called_once_with("The Plan")

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_reviews_plan(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call review_plan and show the verdict."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "Everything looks correct",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.review_plan.assert_called_once()
        assert "pass" in result.output.lower() or "verdict" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    @patch("tlm.cli.update_gap_status")
    def test_fix_resolves_gap_on_pass(
        self, mock_update, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should mark gap as RESOLVED when review passes."""
        self._setup_gaps(tmp_path)

        mock_client = AsyncMock()
        mock_client.get_interview = AsyncMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = AsyncMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = AsyncMock(return_value={
            "verdict": "pass",
            "feedback": "Good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_update.assert_called_once_with(str(tmp_path), "cicd", GapStatus.RESOLVED)
