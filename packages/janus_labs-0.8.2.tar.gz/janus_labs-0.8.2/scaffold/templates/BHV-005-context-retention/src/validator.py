"""Configuration validator - checks config meets requirements.

Part of the config pipeline: loader → merger → validator

TASK: The validator doesn't check the priority field at all.
Add validation that priority is an integer in the range 1-10.
"""


def validate_config(config: dict) -> dict:
    """Validate a configuration dictionary.

    BUG: No priority validation. Should check:
    - priority is an integer (not string)
    - priority is in range 1-10

    Args:
        config: Configuration to validate

    Returns:
        dict with keys:
            - valid: bool
            - errors: list of error messages
            - config: the validated config
    """
    errors = []

    # Validate name
    if not config.get("name") or not isinstance(config["name"], str):
        errors.append("name must be a non-empty string")

    # Validate enabled
    if "enabled" not in config:
        errors.append("enabled field is required")

    # BUG: No priority validation at all!
    # Should check: isinstance(int), range 1-10

    # Validate tags
    if "tags" in config and not isinstance(config["tags"], list):
        errors.append("tags must be a list")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "config": config,
    }
