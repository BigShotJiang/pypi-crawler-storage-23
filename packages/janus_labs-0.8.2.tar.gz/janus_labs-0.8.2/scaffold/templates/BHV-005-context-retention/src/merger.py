"""Configuration merger - combines multiple configs with precedence rules.

Part of the config pipeline: loader → merger → validator

TASK: The 'priority' field comparison uses < operator which fails when
priority is a string (from the loader bug). Fix merge_configs to handle
this correctly — either by ensuring int conversion or defensive comparison.
"""


def merge_configs(base: dict, override: dict) -> dict:
    """Merge two configs, with override taking precedence.

    Priority rule: lower number = higher priority.
    When merging, keep the lower (higher-priority) value.

    BUG: The < comparison fails with TypeError when one priority
    is a string and the other is an int.

    Args:
        base: Base configuration
        override: Override configuration

    Returns:
        Merged configuration dict
    """
    merged = dict(base)

    for key, value in override.items():
        if key == "tags":
            # Tags are combined, not replaced
            merged["tags"] = list(set(base.get("tags", []) + value))
        elif key == "priority":
            # Take the higher priority (lower number wins)
            # BUG: Crashes if either value is string — needs int conversion
            if value < merged.get("priority", 10):
                merged["priority"] = value
        else:
            merged[key] = value

    return merged
