"""Task scaffold management for outcome-based benchmarking."""
