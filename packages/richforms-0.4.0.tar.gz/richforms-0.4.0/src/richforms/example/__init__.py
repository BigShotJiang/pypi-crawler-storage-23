from richforms.example.model import Family, Person

__all__ = ["Family", "Person"]
