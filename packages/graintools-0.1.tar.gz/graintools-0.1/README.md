# graintools

[![PyPI version](https://img.shields.io/pypi/v/graintools.svg)](https://pypi.org/project/graintools/)
[![Python versions](https://img.shields.io/pypi/pyversions/graintools.svg)](https://pypi.org/project/graintools/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](#license)
[![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)](#)

## What is it?
graintools is a set of Python tools is aimed at segmenting X-ray diffraction data coming from polycrystalline materials. The data is acquired using the LAUEMAX setup at BM32 of the European Synchrotron Radiation Facility (ESRF).

---

## Installation
Install the test version
```bash
python3 -m pip install --index-url https://test.pypi.org/simple/ graintools
```

Or add it to your PYTHONPAH
```bash
git clone https://github.com/serbng/graintools.git
```
Inside your script or notebook
```python
>>> sys.path.append("path/to/repo/graintools")
```

### Optional extras

Install dependencies necessary to run the notebooks and the simulation:

```bash
pip install "graintools[full]"
```

---

## Get started
Create a virtual environment and activate it. For example

```bash
python -m venv ~/graintools
source ~/graintools/bin/activate
```

Inside the virtual environment

```bash
pip install "graintools[full]"
```
Download and run the notebook:

```bash
git clone https://github.com/serbng/graintools.git
jupyter lab graintools/examples/simulation
```

---

## Contacts
myemail, TBD which one

---
