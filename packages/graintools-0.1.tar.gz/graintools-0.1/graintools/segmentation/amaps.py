import numpy as np
import cv2 as cv

def to_binary_image(indices, shape, order='C'):
    """Construct a matrix where at the positions specified by the linear indices `indices` the value
    is set to 1, and 0 elsewhere.
    

    Args:
        positions (numpy.ndarray): array with the indices whose values will be set to 1
        shape        (tuple[int]): shape of the image
        order        ({'C', 'F'}): 'C' if the indices reference a row-major matrix, 'F' otherwise.
                                   See numpy.reshape documentation:
                                   https://numpy.org/doc/2.0/reference/generated/numpy.reshape.html

    Returns:
        image (numpy.ndarray): constructed image.
        
    Example:
    >>> to_binary_image(np.array([3,5,7,8]), (3,4))
        array([[0, 0, 0, 1],
               [0, 1, 0, 1],
               [1, 0, 0, 0]], dtype=uint8)
           
    >>> to_binary_image(np.array([3,5,7,8]), (3,4), order='F')
        array([[0, 1, 0, 0],
               [0, 0, 1, 0],
               [0, 1, 1, 0]], dtype=uint8)
    """
    # Linear array to be reshaped later
    image = np.zeros(shape[0]*shape[1], dtype=np.uint8)
    # Set values where they need be
    image[indices.astype(np.uint64)] = 1
    # ??? Profit
    return image.reshape(shape, order=order)

def _largest_cc_label(stats):
    """Return the label of the largest connected component, after the background. 
    (cv2.connectedComponentWithStats() does not guarantee that the largest component
    has index 1)

    Args:
        stats (np.ndarray): statistics on the result of connected component analysis 
                            as returned by cv2.connectedComponentWithStats()

    Returns:
        label  (np.uint64): label value, i.e. the index of the row of the stats array
                            corresponding to the largest connected component
    """
    # Order goes from smallest to largest. 
    # The background is expected to have the largest area, so the largest blob is the second last
    # (Background index would be -1)                                                     │
    return np.argsort(stats[:, cv.CC_STAT_AREA])[-2] # <─────────────────────────────────┘

def _get_cc(labeled_image, label):
    """Return only the components with the specified label.
    
    Args:
        labeled_image  (np.ndarray): labeled image resulting from connected component analysis
                                 as returned by cv2.connectedComponentWithStats()
                               
    Returns:
        result         (np.ndarray): result[i,j] = 1 if labeled_image(i,j)=label, 0 otherwise
    """
    return np.where(labeled_image != label, 0, 1).astype(np.uint8)

def get_largest_cc(image):
    """Perform connected component analysis and return a binary image with the largest
    component (after the background).

    Args:
        image    (np.ndarray): array with dtype np.uint8 containing image data

    Returns:
        result   (np.ndarray): array with data of the largest connected component
    """
    if np.count_nonzero(image) > image.size/2:
        return image # if the image has more ones than zeros, that is if there is the risk
                     # that the second largest cc is the background, do nothing.
                     # TODO be smarter about it maybe, even though working with the binary
                     # image for matching won't be such a big issue for big grains.
    
    num_labels, labeled_image, stats, centroids = cv.connectedComponentsWithStats(image)
    return _get_cc(labeled_image, _largest_cc_label(stats))