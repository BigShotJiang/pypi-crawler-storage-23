import numpy as np
import multiprocess as mp
from sklearn.neighbors import KDTree
from tqdm.autonotebook import tqdm

from ..utils import linear_chunks, grid_chunks

def _remove_duplicates(peak_positions, tol=1.0):
    """Removed duplicate positions, within given tolerance, inside peak_positions.
    Used in buildLUT -> _process_chunk

    Args:
        peak_positions (np.ndarray): Array with shape (N, 2), containing the (X, Y) peak positions
        tol                 (float): Tolerance in the distance between peaks. If there are peaks with euclidean 
                                     distance less than tol then only the average position is kept. 
                                     Defaults to 1.0.

    Returns:
        result (np.ndarray): Array with peaks that are at least `tol` apart.
    """
    if len(peak_positions) == 0:
        return peak_positions
    
    tree = KDTree(peak_positions)
    used = np.zeros(len(peak_positions), dtype=bool)
    unique_positions = []
    
    for i, peak in enumerate(peak_positions):
        if used[i]:
            continue
        # Find closes spots within a given tolerance
        # Peak is expected to be a np.array with ndim=2
        idx = tree.query_radius(peak.reshape(1, -1), r=tol)
        neighbors = idx[0]
        used[neighbors] = True
        # Append the mean position of the neighbouring peaks
        unique_positions.append(peak_positions[neighbors].mean(axis=0))
    
    return np.array(unique_positions)
    
def _process_chunk(dataset, chunk_indices, tol=1.0):
    """Worker function used in buildLUT.
    1) Access a portion of the full dataset specified by chunk_indices, that can be generated either by
    `..utils.grid_chunks` if the dataset shape is provided to buildLUT or by `..utils.linear_chunks` otherwise;
    2) Concatenate the peaklists of the dataset chunk;
    3) Apply to the resulting array _remove_duplicates;
    4) Return result.

    Args:
        dataset      (list[np.ndarray]): list containing the peak positions of each image in the dataset
        chunk_indices (list[list[int]]): list containing the indices corresponding to one chunk of dataset
        tol           (float, optional): Used in _remove_duplicates. Defaults to 1.0.

    Returns:
        result (np.ndarray): Array with "unique" positions within the chunk of dataset
    """
    chunk_peaks_list = []
    for image_number in chunk_indices:
        peaks = dataset[image_number][:,:2]
        chunk_peaks_list.append(peaks)
    
    if len(chunk_peaks_list) == 0:
        return np.zeros((0,2))
    
    # Concatena tutte le posizioni del chunk
    chunk_peaks = np.vstack(chunk_peaks_list)
    # Deduplica internamente
    chunk_peaks = _remove_duplicates(chunk_peaks, tol)
    return chunk_peaks

def _merge_chunks(peak_positions, chunk_peaks, tol=1.0):
    """Used in buildLUT. Updates the global list of peaks `peak_positions` with the new peaks
    found in another chunk.
    For each of the new peaks in `chunk_peaks` check if there is already one present inside
    `peak_positions` within a distance `tol`. If not, add it to the global peak list.

    Args:
        peak_positions (np.ndarray): Global peak list to be updated 
        chunk_peaks    (np.ndarray): New peak list
        tol                 (float): Distance used to query the KDTree. Defaults to 1.0.

    Returns:
        result (np.ndarray): _description_
    """
    if len(peak_positions) == 0:
        return chunk_peaks.copy()
    
    tree = KDTree(peak_positions)
    to_add = []
    
    for chunk_peak in chunk_peaks:
        dist, _ = tree.query(chunk_peak.reshape(1, -1), k=1)
        if dist[0][0] > tol:
            to_add.append(chunk_peak)
    
    if len(to_add) == 0:
        return peak_positions
    
    to_add = np.array(to_add)
    return np.concatenate([peak_positions, to_add], axis=0)

def buildLUT(dataset, shape=None, tol=3.0, chunksize=400, workers=4):
    """Compute the average positions on the detector of the peaks that appear within `tol` throughout
    the dataset. Using this look-up table lowers the computation load of the segmentation procedure.
    
    The dataset is divided in portions, each portion is processed in parallel, and their results are then
    merged together. In each chunk of dataset the lists of peaks are concatenated and for neighbouring
    peaks their average position on the detector is returned.

    Args:
        dataset (list[np.ndarray]): list containing the peak positions of each image in the dataset
        shape         (tuple[int]): If a value is specified, it is used to determine the shape of the
                                    dataset portions (square as opposed to linear). Defaults to None.
        tol                (float): Tolerance in the distance between peaks. If there are peaks with euclidean 
                                    distance less than tol then only the average position is kept. 
                                    Defaults to 3.0.
        chunksize            (int): Size of the chunks of data. If shape is specified, chunksize is interpreted
                                    as the area of the square sub-grid, otherwise it is the length of the sub-
                                    lists into which the dataset is subdivided. Defaults to 400.
        workers              (int): Number of cpu cores used for parallelization. Defaults to 4.

    Raises:
        IndexError: If shape is provided and shape[0]*shape[1] != len(dataset), either we don't use all
                    the dataset, or the indices will go beyond the list, eventually raising an IndexError.

    Returns:
        LUT (np.ndarray): Array (N, 2) of positions on the detector 
    """
    
    if shape is None:
        chunks = linear_chunks(len(dataset), chunksize)
    # If shape is provided, working with square chunks reflects more the physical properties
    # of the dataset 
    else:
        num_rows, num_cols = shape
        
        if num_rows*num_cols != len(dataset):
            raise IndexError(
                f"dataset shape {shape} incompatible with dataset length ({len(dataset)})."
                f"{shape[0]} * {shape[1]} != {len(dataset)}."
            )
            
        chunksize = int(np.sqrt(chunksize))
        chunks = grid_chunks(num_rows, num_cols, chunksize)
            
    with mp.Pool(processes=workers) as pool:
        # Mapping the function _process_chunk onto each chunk
        # imap_unordered returns a generator of results, computed in parallel
        results = pool.imap_unordered(
            lambda chunk: _process_chunk(dataset, chunk, tol), 
            tqdm(chunks, total=len(chunks), desc='Processing chunks')
        )
        
        # Initial global peak list is empty
        LUT = np.zeros((0, 2))
        # Update look-up table with peaks coming from each chunk of dataset
        for chunk_peaks in results:
            LUT = _merge_chunks(LUT, chunk_peaks, tol=tol)
            
    return LUT