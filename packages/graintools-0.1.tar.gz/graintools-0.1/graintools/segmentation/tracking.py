import numpy as np
import multiprocess as mp
from tqdm.autonotebook import tqdm
from numba.typed import List
from numba import njit

from ..utils import linear_chunks

def to_numba_list(dataset):
    """Convert built-in python list of np.arrays to a numba.typed.List of np.arrays.
    Makes the dataset compatible with functions that use numba just-in-time compiler numba.njit

    Args:
        dataset (list[np.ndarray]) : list containing the peak positions of each image in the dataset.

    Returns:
        dataset (numba.typed.List[np.ndarray]): list of C-contiguous, np.float64 arrays.
    """
    numba_list = List()
    for peaklist in dataset:
        numba_list.append(np.ascontiguousarray(peaklist, dtype=np.float64))
    return numba_list

@njit
def track_one_peak(dataset, peak_x, peak_y, tol, use_intensity):
    """Track a peak across the dataset and keep the closest one found in each image (if any).
    This function uses numba.njit just-in-time compiler to spead up this very repetitive operation 
    over a very large number of peaks

    Args:
        dataset (numba.typed.List[np.ndarray]): list containing the peak positions of each image in the dataset.
                                                Each array is expected to have the X, Y positions of the peaks
                                                in the first two columns. If use_intensity=True, then the third
                                                column is expected to contain the intensity of the peaks.
        peak_x  (np.float64): X-coordinate (in pixels) of the peak to track.
        peak_y  (np.float64): Y-coordinate (in pixels) of the peak to track
        tol     (np.float64): tolerance distance from the tracked position
        use_intensity (bool): If True, when there is more than one peak close to (peak_x, peak_y) keep the closest
                              in intensity to the previous match. If false, the closest is kept


    Returns:
        result (np.ndarray): 2D array of shape (N, M+1) where:
                                * N is the number of matches found
                                * M is the number of columns of each array of the dataset
                                * An additional column is prepended containing the image index of the peak that matched
    """
    # numba.typed.List of 1D arrays
    # At the end of the function the arrays will be stacked to make a 2D one
    rows = List() 
    have_prev = False
    I_prev    = 0.0

    for image_index in range(len(dataset)):
        peaks = dataset[image_index]
        
        if peaks.shape[0] == 0:
            continue # List is empty, nothing to find
        
        x_dist = np.abs(peaks[:, 0] - peak_x)
        y_dist = np.abs(peaks[:, 1] - peak_y)
        mask   = (x_dist < tol) & (y_dist < tol)

        if not mask.any():
            continue # Nothing matched, move on

        matching_indices = np.where(mask)[0]
        
        best_match = matching_indices[0]
        # If I have more than one match
        if matching_indices.size > 1:
            # Choose the closest in intensity
            if use_intensity and have_prev:
                smallest_Idiff = 1.0e300
                for k in matching_indices:
                    Idiff = np.abs(peaks[k, 2] - I_prev)
                    if Idiff < smallest_Idiff:
                        smallest_Idiff = Idiff
                        best_match     = k
            # Choose the closest on the detector
            else:
                smallest_dist = 1.0e300
                for k in matching_indices:
                    dist = x_dist[k] + y_dist[k]
                    if dist < smallest_dist:
                        smallest_dist = dist
                        best_match    = k

        # Build the row of the result
        # [image_index, peak_x, peak_y, I, ... additional peak data]
        M = peaks.shape[1]
        row = np.empty(M+1, dtype=np.float64)
        row[0] = float(image_index) # To be consistent with typing
        for j in range(M):
            row[j + 1] = peaks[best_match, j]
        # Append intermediate result to overall list
        rows.append(row)
        # Update intensity value
        I_prev    = peaks[best_match, 2]
        have_prev = True

    # np.vstack does not work with njit, so we implement the same functionality by ourselves
    N = len(rows)
    if N == 0: # If no matches
        M = dataset[0].shape[1]+1
        return np.empty((0, M), dtype=np.float64)
    
    else:
        # number of columns = length of the row (mindblowing, I know)
        M = rows[0].shape[0]
        result = np.empty((N, M), dtype=np.float64)
        for i in range(N):
            result[i, :] = rows[i]
        return result
    

def _track_chunk(dataset, LUT, chunk_indices, tol, use_intensity):
    """Track a portion (aka a chunk) of the peaks in the LUT to parallelize the whole operation. It will later
    be wrapped in the actual worker function "_worker"

    Args:
        dataset (numba.typed.List[np.ndarray]): list containing the peak positions of each image in the dataset.
                                                Each array is expected to have the X, Y positions of the peaks
                                                in the first two columns. If use_intensity=True, then the third
                                                column is expected to contain the intensity of the peaks.
        LUT          (np.ndarray): array of shape (N,2) containing the positions to track around
        chunk_indices (list[int]): list of indices corresponding to a subset (aka a chunk) of the entire LUT.
        tol               (float): tolerance distance from the tracked position 
        use_intensity      (bool): when multiple peaks of the dataset fall within tol from the position of the
                                   LUT, take the closest in intensity to disambiguate. If False, the closest
                                   in terms of position is kept.

    Returns:
        result (dict): * key          (int): index of the peak in the LUT
                       * value (np.ndarray): result of the tracking
    """
    result = {}
    for idx in chunk_indices:
        matches = track_one_peak(dataset, LUT[idx, 0], LUT[idx, 1], tol, use_intensity)
        result[idx] = matches
    return result

# global variables initialized in each worker process
NUMBA_DATASET = None
GLOBAL_LUT    = None
GLOBAL_TOL    = None
GLOBAL_INTENSITY_FLAG = None

def init_worker(dataset, LUT, tol, use_intensity):
    """Worker initializer to set up the global variables that will be used by the multiprocessing Pool.
    Convert built-in python list of np.arrays to a numba.typed.List of np.arrays.

    Args:
        dataset (numba.typed.List[np.ndarray]): list containing the peak positions of each image in the dataset.
                                                Each array is expected to have the X, Y positions of the peaks
                                                in the first two columns. If use_intensity=True, then the third
                                                column is expected to contain the intensity of the peaks.
        LUT          (np.ndarray): array of shape (N,2) containing the positions to track around
        tol               (float): tolerance distance from the tracked position 
        use_intensity      (bool): when multiple peaks of the dataset fall within tol from the position of the
                                   LUT, take the closest in intensity to disambiguate. If False, the closest
                                   in terms of position is kept.
    """
    global NUMBA_DATASET, GLOBAL_LUT, GLOBAL_TOL, GLOBAL_INTENSITY_FLAG
    
    NUMBA_DATASET = to_numba_list(dataset)
    GLOBAL_LUT    = LUT
    GLOBAL_TOL    = tol
    GLOBAL_INTENSITY_FLAG = use_intensity
    
def _worker(chunk_indices):
    """Worker function in "track_positions". It is a wrapper of _track_chunk
    
    Args:
        chunk_indices (list[int]): list of indices corresponding to a subset (aka a chunk) of the entire LUT.

    Returns:
        result (dict): * key          (int): index of the peak in the LUT
                       * value (np.ndarray): result of the tracking
    """
    return _track_chunk(
        NUMBA_DATASET,
        GLOBAL_LUT,     
        chunk_indices,
        GLOBAL_TOL,     
        GLOBAL_INTENSITY_FLAG
    )

def track_positions(dataset, LUT, tol, workers=4, chunksize=1000, use_intensity=False):
    """Track in the dataset the peak positions contained in the LUT. For each peak tracked, a 
    "spot family" is returned. A spot family is a numpy array containing the information on 
    where a peak appeared in the dataset and its properties.
    A spot family has shape (N, M+1) where N is the number of times a peak of the dataset was 
    found within tol of the peak in the LUT and M is the number of columns that each array of
    the dataset has. A column is prepended to the array to save in which position of the
    dataset the peak was found. Therefore:
    spot_family = np.array([[image_index0, x0, y0, I0, ...],
                            [image_index1, x1, y1, I1, ...],
                            ...
                            [image_indexN-1, xN-1, yN-1, IN-1, ...]])

    Args:
        dataset (list[np.ndarray]): list containing the peak positions of each image in the dataset.
        LUT           (np.ndarray): array of shape (N,2) containing the positions to track around
        tol                (float): tolerance distance from the tracked position 
        workers        (int, optional): number of cpus to use in parallel to perform the operation. 
                                        Defaults to 4.
        chunksize      (int, optional): length of the chunks onto which the LUT will be divided. 
                                        Defaults to 1000.
        use_intensity (bool, optional): when multiple peaks of the dataset fall within tol from the position of the
                                        LUT, take the closest in intensity to disambiguate. If False, the closest
                                        in terms of position is kept. Defaults to False.

    Returns:
        spot_families (list[np.ndarray]): result of the tracking
    """
    N       = len(LUT)
    chunks  = linear_chunks(N, chunksize)
    results = [None] * N

    # Create and initialize pool
    with mp.Pool(
        processes=workers, 
        initializer=init_worker, 
        initargs=(dataset, LUT, tol, use_intensity)) as pool:
        
        imap = pool.imap_unordered(_worker, tqdm(chunks, total=len(chunks), desc='Processing chunks'))
        for chunk_result in imap:
            for peak_idx, arr in chunk_result.items():
                results[peak_idx] = arr

    return results