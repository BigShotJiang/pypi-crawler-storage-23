import numpy as np
import multiprocess as mp
import h5py
from tqdm import tqdm

from ..peaks import remove_duplicates
from .amaps import to_binary_image, get_largest_cc

def families_largest_cc(spot_families, shape, order='C'):
    """Compute the largest connected component of each family and remove the entries that have an image
    index that doesn't belong to the largest cc.

    Args:
        spot_families (list[np.ndarray]): list of spot families as built using segmentation.track_positions.
                                          Each element has the structure
                                          spot_family = np.array([[image_index0, x0, y0, I0, ...],
                                                                  [image_index1, x1, y1, I1, ...],
                                                                  ...
                                                                  [image_indexN-1, xN-1, yN-1, IN-1, ...]])
        shape  (tuple[int]): shape of the dataset.
        order  ({'C', 'F'}): 'C' if the dataset has been acquired scanning row-by-row, 'F' otherwise.

    Returns:
        _type_: _description_
    """
    filtered_families = []
    for family in spot_families:
        if family.size == 0 or family.ndim == 1:
            filtered_families.append(family)
            continue
        
        image_indices = family[:, 0].astype(int)
        largest_cc = get_largest_cc(to_binary_image(image_indices, shape=shape, order=order))
        cc_indices = np.flatnonzero(largest_cc)  

        # Boolean mask of which rows to keep
        to_keep = np.isin(image_indices, cc_indices)

        filtered_families.append(family[to_keep])

    return filtered_families

def grain_contour_and_pattern(matching_families, shape, order='C'):
    """Given the list of families that belong to the same grain, return its contour, i.e. which scan
    points belong to it, and its average pattern.

    Args:
        matching_families (list[np.ndarray]): list of spot families that belong to the same grain
        shape                   (tuple[int]): shape of the dataset
        order         ({'C', 'F'}, optional): 'C' if the dataset has been acquired scanning row-
                                              by-row, 'F' otherwise.

    Returns:
        contour (np.ndarray): appearance map of the grain
        pattern (np.ndarray): average pattern. Each row in the pattern contains the average peak
                              properties:
                              pattern = np.array([[x0_avg, y0_avg, I0_avg, ...],
                                                  [x1_avg, y1_avg, I1_avg, ...],
                                                  ...
                                                  [xN_avg, yN_avg, IN_avg, ...]])
    """
    if matching_families == []:
        return (
            np.array([], dtype=np.uint64),
            np.empty((1,0), dtype=float)
        )
    
    image_indices   = []
    spots_avg_props = []
    for family in matching_families:
        image_indices.append(family[:,0].astype(np.uint64, copy=False))
        spots_avg_props.append(family[:,1:].mean(axis=0))
    
    unique_indices = np.unique(np.concatenate(image_indices))
    
    contour = to_binary_image(unique_indices, shape=shape, order=order)
    pattern = remove_duplicates(np.vstack(spots_avg_props))
    
    return contour, pattern
    
def build(spot_families, matching_indices, shape, order='C', keep_largest_cc=True, workers=4):
    """Put together the pieces returned by the segmentation for a more readable result.

    Args:
        spot_families   (list[np.ndarray]): list of spot families as built using segmentation.track_positions.
        matching_indices (list[list[int]]): list of list of indices. Sub-list i contains the indices of
                                            spot_families that have the similar appearance maps.
        shape                 (tuple[int]): shape of the dataset.
        order       ({'C', 'F'}, optional): 'C' if the dataset has been acquired scanning row-by-row, 'F' otherwise.
        keep_largest_cc   (bool, optional): whether to remove from each spot family the rows that don't belong to the
                                             largest connected component. Defaults to True.
        workers            (int, optional): number of cpus to use in parallel to perform the operation. 
                                            Defaults to 4.

    Returns:
        result (list[tuple[np.ndarray]]): list of (contour, pattern) of each grain. The contour is the appearance 
                                          map of the grain whereas the pattern is considered to be its average 
                                          diffraction pattern. Therefore, each row in the pattern contains the 
                                          average peak properties:
                                          pattern = np.array([[x0_avg, y0_avg, I0_avg, ...],
                                                              [x1_avg, y1_avg, I1_avg, ...],
                                                              ...
                                                              [xN_avg, yN_avg, IN_avg, ...]])
    """
    if keep_largest_cc:
        spot_families = families_largest_cc(spot_families, shape=shape, order=order)
    
    matching_families_list = [
        [spot_families[i] for i in indices] for indices in matching_indices
    ]
        
    with mp.Pool(workers) as pool:
        result = pool.starmap(
            grain_contour_and_pattern,
            [(x, shape, order) for x in matching_families_list],
            chunksize=1
        )
    
    return result

def write_toh5(h5path, result, compression='gzip', compression_opts=4):
    """Save segmentation result to h5 file. The file will have a group for each grain.
    Each group has a dataset containing its contour and the diffraction pattern.

    Args:
        h5path (str): path of the h5 file to write.
        result (list[tuple[np.ndarray]]): Result of the segmentation as built by segmentation.result.build.
                                          list of (contour, pattern) of each grain. The contour is the 
                                          appearance map of the grain whereas the pattern is considered to
                                          be its average diffraction pattern.
        compression (str, optional): compression filter. Defaults to 'gzip'.
        compression_opts (int, optional): compression level. Defaults to 4.
        
        For more info on compression refer to
        https://docs.h5py.org/en/stable/high/dataset.html#lossless-compression-filters
    """
    with h5py.File(h5path, "w") as h5f:
        for i, (contour, pattern) in enumerate(result):
            group = h5f.create_group(f"grain{i:0>4d}")
            group.create_dataset(
                "contour",
                data=contour,
                compression=compression,
                compression_opts=compression_opts,
                dtype=contour.dtype
            )
            group.create_dataset(
                "pattern",
                data=pattern,
                compression=compression,
                compression_opts=compression_opts,
                dtype=pattern.dtype
            )

def read_fromh5(h5path):
    """Load segmentation result from an h5 file written by write_toh5.
    The file is expected to have a group for each grain; each group contains
    two datasets: 'contour' (appearance map) and 'pattern' (average diffraction pattern).

    Args:
        h5path (str): Path of the h5 file to read.

    Returns:
        list[tuple[np.ndarray]]: Result of the segmentation as built by
            segmentation.result.build, i.e., a list of (contour, pattern)
            for each grain. The order follows the lexicographic order of
            the grain groups (e.g., grain0000, grain0001, ...).

    Notes:
        Files created with lossless compression (e.g., 'gzip') are
        transparently decompressed by h5py on read. See
        https://docs.h5py.org/en/stable/high/dataset.html#lossless-compression-filters
        for details.
    """
    result = []
    with h5py.File(h5path, "r") as h5f:
        # Collect grain-like groups and iterate in sorted order for stable output
        grain_groups = [name for name, obj in h5f.items() if isinstance(obj, h5py.Group) and name.startswith("grain")]
        for gname in sorted(grain_groups):
            group = h5f[gname]
            if "contour" not in group or "pattern" not in group:
                raise KeyError(f"Group '{gname}' is missing required datasets 'contour' and/or 'pattern'.")
            contour = group["contour"][()]
            pattern = group["pattern"][()]
            result.append((contour, pattern))
    return result
