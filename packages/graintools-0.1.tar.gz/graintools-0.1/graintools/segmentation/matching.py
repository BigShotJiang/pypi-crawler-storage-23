import numpy as np
from tqdm.autonotebook import tqdm
from numba import njit, prange

def prepare_amaps(amaps):
    """For each appearance map, return its flattened version and L2 norm

    Args:
        amaps (Iterable[np.ndarray]): list or np.array containing the appearance maps

    Returns:
        flat_amaps (np.ndarray): array of shape (N,P) where N is the number of amaps
                                 and P is their size. dtype=np.uint8
        norms      (np.ndarray): array of shape (N,), dtype=np.float32
    """
    N = len(amaps)
    P = amaps[0].size 
    
    flat_amaps = np.zeros((N, P), dtype=np.uint8)
    norms      = np.zeros(N, dtype=np.float32)
    
    for i, map in enumerate(amaps):
        vect_amap = map.ravel().astype(np.uint8)
        flat_amaps[i] = vect_amap
        # When the vector contains only 0/1, no need to square
        norms[i] = np.sqrt(vect_amap.sum())
        
    return flat_amaps, norms

@njit(parallel=True)
def match_one_map(flat_amap1, flat_amaps, norms, threshold):
    """Find the matches of flat_amap1 in flat_amaps. The cosine similarity is computed
    
    cos(flat_amap1, flat_amap2) = (flat_amap1 dot flat_amap2) / (norm1 * norm2) 
    
    for each flat_amap2 in flat_amaps. A boolean array is returned where True corresponds
    to cos(flat_amap1, flat_amap2) >= threshold.
    
    This function uses numba.njit just-in-time compiler.

    Args:
        flat_amap1 (np.ndarray): array of shape (P, ) with 0/1 values. dtype=np.uint8
        flat_amaps (np.ndarray): array of shape (N,P) with 0/1 values. dtype=np.uint8
        norms      (np.ndarray): array of shape (N, ). dtype=np.float32
        threshold  (np.float32): cosine similarity threshold

    Returns:
        mask (np.ndarray): boolean array of shape (N, ). If mask[i] is True it means that
                           flat_amaps[i] matches with flat_amap1. dtype=bool
    """
    N, P = flat_amaps.shape
    mask = np.zeros(N, dtype=np.bool_)

    # Compute norm1 = ||image1||
    sum1 = 0
    for j in range(P):
        sum1 += flat_amap1[j]
    norm1 = np.sqrt(sum1)
    
    # If the image is empty, return early
    if norm1 == 0.0:
        return mask

    for i in prange(N): # For each amap
        norm2 = norms[i]
        
        if norm2 == 0.0:
            continue  # amap is empty, can't match

        # Intersection count = image1 \cdot flat_maps[i]
        intersection = 0
        amap = flat_amaps[i]
        for j in range(P):
            intersection += flat_amap1[j] & amap[j]

        # cosine similarity
        cosine_similarity = intersection / (norm1 * norm2)
        
        if cosine_similarity >= threshold:
            mask[i] = True

    return mask

def find_matches(amaps, threshold):
    """Find similar appearance maps using the cosine similarity criterion. For each amap1 in
    amaps, calculate 
    
     cos(amap1, amap2) = (amap1 dot amap2) / (||amap1|| ||amap2||)
     
     for each amap2 in amaps. If cos(amap1, amap2) >= threshold, it means that amap1 and amap2
     are a match. For each amap1 the result of this operation is stored in a list. The list
     contains the indices of amaps that matched with amap1.
     
     Overall, the result is then a list of lists such that
     result[0] is a list containing the matches of amaps[0],
     result[1] is a list containing the matches of amaps[1], etc...

    Args:
        amaps (Iterable[np.ndarray]): list | numpy array | tuple containing the appearance maps.
                                      dtype will be cast to np.uint8
        threshold (float): threshold value of cosine similarity. If greater than threshold, the
                           maps are considered a match.

    Returns:
        matches (list[list[int]]): list of list of indices. Sub-list i contains the indices of
                                   amaps that match amaps[i]
    """
    # 1) Prepare flat_maps and norms once
    flat_amaps, norms = prepare_amaps(amaps)
    N = flat_amaps.shape[0]

    seen = np.zeros(N, dtype=bool)
    matches_list = []

    for i in tqdm(range(N-1), total=N-1, desc='Finding matches'):
        if seen[i]:
            continue

        # compare i only to j's with j>i
        leftover_amaps = flat_amaps[i+1:]
        leftover_norms = norms[i+1:]
        mask = match_one_map(
            flat_amaps[i],
            leftover_amaps,
            leftover_norms,
            np.float32(threshold)
        )
        # absolute indices of matches (need to add the starting index, i.e. i+1)
        js = np.nonzero(mask)[0] + (i+1)

        # matches are itself + the j's
        matches = [i] + js.tolist()
        matches_list.append(matches)

        # mark them all as seen
        seen[matches] = True

    return matches_list