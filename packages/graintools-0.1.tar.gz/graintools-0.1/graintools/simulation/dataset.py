import numpy as np
import matplotlib.pyplot as plt
import ipywidgets as widgets
from IPython.display import display
from matplotlib.patches import PathPatch

from ..utils.scan import mesh_points

from .grain import Grain, draw_contour
from .pattern import simulate_pattern, rotation_matrix

class Dataset:
    def __init__(self, scan_start, scan_end, scan_step):
        """Class containing all the information that make up a dataset. Initial values are used to determine
        the scanned area (i.e. the canvas) and the number and position of the scan points.

        Args:
            scan_start (tuple[float]): Position (x_i, y_i) where the scan begins
            scan_end   (tuple[float]): Position (x_f, y_f) where the scan ends
            scan_step  (tuple[float]): Step sizes along x and y

        """
        self.scan_start  = scan_start
        self.scan_end    = scan_end
        self.scan_step   = scan_step
        self.scan_points = mesh_points(scan_start, scan_end, scan_step)
        self.length      = len(self.scan_points)
        self.shape       = (int((scan_end[0] - scan_start[0]) / scan_step[0] + 1),
                            int((scan_end[1] - scan_start[1]) / scan_step[1] + 1))
        
        self.grains  = []
        self.orientations_ = []
        self.spots = []
    
        
    def generate_grains(self, centers=None, radii=None, **kwargs):
        """Fill the area of the dataset with grains, as drawn by graintools.simulation.grain.draw_contour.
        If centers and radii are not provided, reasonable values are inferred from the canvas parameters
        as to cover its extension.

        Args:
            centers (Iterable[float]): list/array of center positions. The number of grains will match the
                                       number of centers provided.
            r_range (Iterable[float]): list/array of radius values. The number of grains will match the
                                       number of radii provided.
                                       
        kwargs:
            num_edges: passed to draw_contour
                    d: passed to draw_contour
        """
        self.grains = []
        self.orientations_ = []
        
        if centers is None and radii is None:
            centers = mesh_points(
                np.array(self.scan_start) + np.array([1, 1]),
                np.array(self.scan_end)   - np.array([1, 1]),
                np.array(self.scan_step)*8
            )
            
            r_large = max(self.scan_step)
            r_range = (5*r_large, 6.25*r_large)
            radii = np.random.uniform(*r_range, size=centers.shape)
        
        if len(centers) > self.length:
            raise ValueError("I can't have more grains than scan points")
               
        for center, radius in zip(centers, radii):
            grain  = Grain()
            grain.center = center
            grain.radius = radius
            grain.contour = draw_contour(grain.center, grain.radius, **kwargs)
            grain.euler_angles = np.random.uniform(0, 2*np.pi, size=(3,))
            
            # Each grain will have this average orientation
            self.orientations_.append(rotation_matrix(*grain.euler_angles))
            
            self.grains.append(grain)
            
    def simulate(self, material, calibration_parameters, orientation_noise=0.001, **kwargs):
        """Assign an orientation to each grain and simulate its Laue pattern. At each scan position,
        to each Euler angle, that gives the orientation of the grain, a white gaussian noise with
        standard deviation orientation_noise is added.

        Args:
            material                    (str): Name of the material. Must match a key of the materials dictionary.
                                               see also graintools.simulation.pattern.simulate_pattern
            calibration_parameters (Iterable): List of the five calibration parameters [detector_distance, x_center,
                                               y_center, x_beta, x_gamma]
            orientation_noise         (float): Standard deviation of the WGN added to the Euler angles expressed in
                                               degrees. Defaults to 0.001.
        """
        if self.grains == []:
            raise ValueError("You must first generate some grains")
        
        # Convert angle in radians
        orientation_noise *= np.pi/180
        
        self.spots = []
        for point in self.scan_points:
            simulations = []
            
            for grain in self.grains:
                if not grain.contour.contains_point(point):
                    continue # point is not inside a grain, skip it
                
                euler_angles = grain.euler_angles + np.random.normal(0, orientation_noise, 3)
                orientation = rotation_matrix(*euler_angles)
                
                simulated_spots_XY = simulate_pattern(
                    material, orientation, calibration_parameters, **kwargs
                )[["X", "Y"]].values.astype(float)
                
                simulations.append(simulated_spots_XY)
                
            if simulations == []:
                to_append = np.empty((0,2))
            else:
                to_append = np.vstack(simulations)
                
            self.spots.append(to_append)
            
    @property
    def grain_map(self):
        """
        Plots the scanned area along with the generated grain contours.
        """
        fig, ax = plt.subplots(figsize=(5, 5))
        # Optional: visualize the scan grid points.
        #ax.plot(self.scan_points[:, 0], self.scan_points[:, 1], 'k.', markersize=2, alpha=0.3)
        
        # Plot each grain's contour.
        for grain in self.grains:
            # Draw the distorted contour.
            patch = PathPatch(grain.contour, facecolor='none', edgecolor='dodgerblue', lw=1.2)
            ax.add_patch(patch)
        
        ax.set_xlim(self.scan_start[0], self.scan_end[0])
        ax.set_ylim(self.scan_start[1], self.scan_end[1])
        ax.set_aspect('equal')
        ax.set_title("Simulated grain contours")

    def navigate(self):
        """
        Navigate the dataset using the arrow widgets and the text box to choose the index of the 
        scan point to display.
        """
        # grid dims and total points
        nx, ny = self.shape
        n_total = self.length

        # --- Widgets ---
        btn_left  = widgets.Button(description="← Left",  layout=widgets.Layout(width="75px"))
        btn_right = widgets.Button(description="Right →", layout=widgets.Layout(width="75px"))
        btn_up    = widgets.Button(description="↑ Up",    layout=widgets.Layout(width="75px"))
        btn_down  = widgets.Button(description="Down ↓",  layout=widgets.Layout(width="75px"))
        idx_box   = widgets.BoundedIntText(
            value=0, min=0, max=n_total-1, step=1, layout=widgets.Layout(width="75px")
        )
        
        grid = widgets.GridspecLayout(3, 3, width='300px', height='150px')
        grid[0, 1] = btn_up
        grid[1, 0] = btn_left
        grid[1, 1] = idx_box
        grid[1, 2] = btn_right
        grid[2, 1] = btn_down

        controls = widgets.VBox([grid])

        output = widgets.Output()

        # --- Create the figure & axes once ---
        with output:
            fig, (axL, axR) = plt.subplots(1, 2, figsize=(10, 5))
            plt.show()

        # --- Drawing helper ---
        def draw_index(i):
            """Clear both axes and redraw for scan-point i."""
            # Left subplot: scan grid + grain contours
            axL.clear()
            
            for g in self.grains:
                axL.add_patch(PathPatch(g.contour, facecolor='none',edgecolor='dodgerblue', lw=1.2))
                
            pt = self.scan_points[i]
            axL.plot(pt[0], pt[1], 'o', color='orange', ms=5)
            
            for g in self.grains:
                if g.contour.contains_point(pt):
                    axL.add_patch(PathPatch(g.contour, facecolor='none',edgecolor='orange', lw=2))
                    
            axL.set_xlim(self.scan_start[0], self.scan_end[0])
            axL.set_ylim(self.scan_start[1], self.scan_end[1])
            axL.set_aspect('equal')
            axL.set_title(f"Scan Grid (pt={i})")
            axL.set_xlabel("Position [µm]")
            axL.set_ylabel("Position [µm]")

            # Right subplot: Laue pattern
            axR.clear()
            spots = self.spots[i]
            axR.scatter(spots[:,0], spots[:,1], s=5, c='purple')
            axR.set_title("Simulated Pattern")
            axR.set_xlim(0, 2018)
            axR.set_ylim(0, 2018)
            axR.invert_yaxis()
            axR.set_aspect('equal')
            axR.set_xlabel("X pixel")
            axR.set_ylabel("Y pixel")

            # Trigger a redraw
            fig.tight_layout()
            fig.canvas.draw_idle()

        # --- Button callbacks ---
        def go_left(_):
            if idx_box.value % nx > 0:
                idx_box.value -= 1

        def go_right(_):
            if idx_box.value % nx < nx - 1:
                idx_box.value += 1

        def go_up(_):
            row = idx_box.value // nx
            if row < ny - 1:
                idx_box.value += nx

        def go_down(_):
            row = idx_box.value // nx
            if row > 0:
                idx_box.value -= nx
                
        def on_index_change(change):
            draw_index(change['new'])

        btn_left.on_click(go_left)
        btn_right.on_click(go_right)
        btn_up.on_click(go_up)
        btn_down.on_click(go_down)
        idx_box.observe(on_index_change, names='value')

        # --- Display ---
        display(controls, output)
        draw_index(0)