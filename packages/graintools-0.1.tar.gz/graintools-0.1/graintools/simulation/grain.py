import numpy as np
from matplotlib.patches import Path

class Grain:
    def __init__(self):
        self.euler_angles = []
        self.center = []
        self.radius = None
        self.contour = None
        
def draw_contour(center, radius, num_edges = 7, d = 0.25):
    """
    Create a matplotlib.path.Path object to describe the contour of a grain.
    
    The path consists of cubic Bezier curves with points on a distorted 
    circle with the specified center and radius.
   
    Args:
    center  (tuple[float]): coordinates of the center of the circle
    radius         (float): radius of the circle
    num_edges        (int): number of sides to approximate the circle
    d              (float): degree of the distortion. 0.25 means that
                            the radius changes by +- 25% randomly.  
    Returns:
    path  (matpotlib.path.Path): Path object
    """
    # number of points in the Path
    # There is the initial point and 3 points per cubic bezier curve.
    N = 3*num_edges + 1
    angles   = np.linspace(0, 2*np.pi, N)
    codes    = np.full(N, Path.CURVE4)
    codes[0] = Path.MOVETO # Close path onto itself, instead of changing last code to Path.CLOSEPOLY, 
                           # which would close the path using a straight line

    # Distorted points on the unit circle
    points = np.vstack((np.cos(angles), np.sin(angles))).T * (2*d*np.random.random(N) + 1 - d)[:, None]
    # Path vertices
    vertices = center + points * radius
    # Make it a closed path
    vertices[-1,:] = vertices[0,:]
    
    return Path(vertices, codes)