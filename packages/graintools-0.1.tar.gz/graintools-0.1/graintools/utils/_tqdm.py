tqdm_kwargs = {"ascii": False,
               "bar_format": "{desc: <20}: {percentage:3.0f}%|{bar:20}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]",
               "ncols": 80}