import numpy as np

def mesh_points(start, end, step):
    """Generate an array of (x,y) positions spanning the area between the start and end points, with the specified step

    Args:
        start (tuple[float]): Position (x_i, y_i) where the scan begins
        end   (tuple[float]): Position (x_f, y_f) where the scan ends
        step  (tuple[float]): Step sizes along x and y

    Returns:
        points (np.ndarray): array with shape (N,2) containing the (x,y) positions
    """
    xpoints = ((end[0] - start[0]) / step[0] + 1) * 1j
    ypoints = ((end[1] - start[1]) / step[1] + 1) * 1j
    
    return np.mgrid[start[0]:end[0]:xpoints,
                    start[1]:end[1]:ypoints].reshape(2,-1, order = 'F').T
    
    
    
# To insert a function to remove duplicates OK
import os, shutil
# ----------------------------------------------------------------------


def convertidx_position_to_file(position_index: list, scan_shape: tuple):
    #position index should be an array
    # [[10, 10], [10,11], [10,12], ... ,[11,10], ...]
    file_index = []
    for index in position_index:
        file_index.append(index[0] * scan_shape[0] + index[1])
    return file_index

def copy_and_rename(fileabspath, destination_folder, new_name):
    shutil.copy(fileabspath, destination_folder)
    old_name = os.path.join(destination_folder, fileabspath.split('/')[-1])
    new_name = os.path.join(destination_folder, new_name)
    shutil.move(old_name, new_name)
    

if __name__ == '__main__':
    position_indices = []
    # portion of the scan 10 by 10 at the center of image
    for x in range(30,50):
        for y in range(30,50):
            position_indices.append((x,y))
    
    file_indices = convertidx_position_to_file(position_indices, (81,81))
    
    source_folder      = os.path.join(os.getcwd(), 'datfiles')
    destination_folder = os.path.join(os.getcwd(), 'datfiles_10x10um')
    os.mkdir(destination_folder)
    
    for new_index, curr_index in enumerate(file_indices):
        filename     = f'img_{curr_index:0>4d}.dat'
        fileabspath  = os.path.join(source_folder, filename)
        new_filename = f'img_{new_index:0>4d}.dat'
        copy_and_rename(fileabspath, destination_folder, new_filename)