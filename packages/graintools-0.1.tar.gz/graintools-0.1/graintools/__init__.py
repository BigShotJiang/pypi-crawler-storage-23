__author__ = "Sergio Bongiorno"
__version__ = "0.2"

from . import peaks, segmentation, simulation, utils