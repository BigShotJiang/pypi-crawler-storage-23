"""Karrio Mapper abstract class definition module."""

import abc
import attr
import typing
import karrio.lib as lib
import karrio.core.models as models
import karrio.core.errors as errors
import karrio.core.settings as settings


@attr.s(auto_attribs=True)
class Mapper(abc.ABC):
    """Unified Shipping API Mapper (Interface)"""

    settings: settings.Settings

    def create_address_validation_request(
        self, payload: models.AddressValidationRequest
    ) -> lib.Serializable:
        """Create a carrier specific address validation request data from the payload

        Args:
            payload (AddressValidationRequest): the address validation request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_address_validation_request.__name__,
            self.settings.carrier_name,
        )

    def create_rate_request(self, payload: models.RateRequest) -> lib.Serializable:
        """Create a carrier specific rate request data from payload

        Args:
            payload (AddressValidationRequest): the rate request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_rate_request.__name__, self.settings.carrier_name
        )

    def create_tracking_request(
        self, payload: models.TrackingRequest
    ) -> lib.Serializable:
        """Create a carrier specific tracking request data from payload

        Args:
            payload (AddressValidationRequest): the tracking request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_tracking_request.__name__, self.settings.carrier_name
        )

    def create_return_shipment_request(
        self, payload: models.ShipmentRequest
    ) -> lib.Serializable:
        """Create a carrier specific return shipment request data from the payload

        Args:
            payload (ShipmentRequest): the return shipment request payload
                (addresses already swapped by gateway)

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration
                does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_return_shipment_request.__name__,
            self.settings.carrier_name,
        )

    def create_shipment_request(
        self, payload: models.ShipmentRequest
    ) -> lib.Serializable:
        """Create a carrier specific shipment creation request data from payload

        Args:
            payload (AddressValidationRequest): the shipment request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_shipment_request.__name__, self.settings.carrier_name
        )

    def create_cancel_shipment_request(
        self, payload: models.ShipmentCancelRequest
    ) -> lib.Serializable:
        """Create a carrier specific void shipment request data from payload

        Args:
            payload (AddressValidationRequest): the shipment cancellation request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_cancel_shipment_request.__name__,
            self.settings.carrier_name,
        )

    def create_pickup_request(self, payload: models.PickupRequest) -> lib.Serializable:
        """Create a carrier specific pickup request xml data from payload

        Args:
            payload (AddressValidationRequest): the pickup request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_pickup_request.__name__, self.settings.carrier_name
        )

    def create_pickup_update_request(
        self, payload: models.PickupUpdateRequest
    ) -> lib.Serializable:
        """Create a carrier specific pickup modification request data from payload

        Args:
            payload (AddressValidationRequest): the pickup updated request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_pickup_update_request.__name__,
            self.settings.carrier_name,
        )

    def create_cancel_pickup_request(
        self, payload: models.PickupCancelRequest
    ) -> lib.Serializable:
        """Create a carrier specific pickup cancellation request data from payload

        Args:
            payload (AddressValidationRequest): the pickup cancellation request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_cancel_pickup_request.__name__,
            self.settings.carrier_name,
        )

    def create_document_upload_request(
        self, payload: models.DocumentUploadRequest
    ) -> lib.Serializable:
        """Create a carrier specific document upload request data from payload

        Args:
            payload (DocumentUploadRequest): the document upload request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_document_upload_request.__name__,
            self.settings.carrier_name,
        )

    def create_manifest_request(
        self, payload: models.ManifestRequest
    ) -> lib.Serializable:
        """Create a carrier specific manifest request data from payload

        Args:
            payload (ManifestRequest): the manifest request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_manifest_request.__name__,
            self.settings.carrier_name,
        )

    def create_duties_calculation_request(
        self, payload: models.DutiesCalculationRequest
    ) -> lib.Serializable:
        """Create a carrier specific duties calculation request data from payload

        Args:
            payload (DutiesCalculationRequest): the duties calculation request payload
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_duties_calculation_request.__name__,
            self.settings.carrier_name,
        )

    def create_insurance_request(
        self, payload: models.InsuranceRequest
    ) -> lib.Serializable:
        """Create a carrier specific insurance request data from payload

        Args:
            payload (InsuranceRequest): the insurance request payload
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_insurance_request.__name__,
            self.settings.carrier_name,
        )

    def create_webhook_registration_request(
        self, payload: models.WebhookRegistrationRequest
    ) -> lib.Serializable:
        """Create a carrier specific webhook registration request data from payload

        Args:
            payload (WebhookRegistrationRequest): the webhook registration request payload

        Returns:
            Serializable: a carrier specific serializable request data type

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_webhook_registration_request.__name__,
            self.settings.carrier_name,
        )

    def create_webhook_deregistration_request(
        self, payload: models.WebhookDeregistrationRequest
    ) -> lib.Serializable:
        """Create a carrier specific webhook deregistration request data from payload

        Args:
            payload (WebhookDeregistrationRequest): the webhook deregistration request payload
        """
        raise errors.MethodNotSupportedError(
            self.__class__.create_webhook_deregistration_request.__name__,
            self.settings.carrier_name,
        )

    """Response Parsers"""

    def parse_address_validation_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.AddressValidationDetails, typing.List[models.Message]]:
        """Create a unified API address validation details from the carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[AddressValidationDetails, List[Message]]: the address validation details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_address_validation_response.__name__,
            self.settings.carrier_name,
        )

    def parse_shipment_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ShipmentDetails, typing.List[models.Message]]:
        """Create a unified API shipment creation result from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[ShipmentDetails, List[Message]]: the shipment details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_shipment_response.__name__, self.settings.carrier_name
        )

    def parse_return_shipment_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ShipmentDetails, typing.List[models.Message]]:
        """Create a unified API return shipment result from carrier response

        Args:
            response (Deserializable): a deserializable return shipment response (xml, json, text...)

        Returns:
            Tuple[ShipmentDetails, List[Message]]: the return shipment details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_return_shipment_response.__name__,
            self.settings.carrier_name,
        )

    def parse_cancel_shipment_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ConfirmationDetails, typing.List[models.Message]]:
        """Create a unified API operation confirmation detail from the carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[ConfirmationDetails, List[Message]]: the operation confirmation details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_cancel_shipment_response.__name__,
            self.settings.carrier_name,
        )

    def parse_pickup_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.PickupDetails, typing.List[models.Message]]:
        """Create a unified API pickup result from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[PickupDetails, List[Message]]: the pickup details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_pickup_response.__name__, self.settings.carrier_name
        )

    def parse_pickup_update_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.PickupDetails, typing.List[models.Message]]:
        """Create a unified API pickup result from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[PickupDetails, List[Message]]: the pickup update details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_pickup_update_response.__name__,
            self.settings.carrier_name,
        )

    def parse_cancel_pickup_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ConfirmationDetails, typing.List[models.Message]]:
        """Create a united API pickup cancellation result from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[ConfirmationDetails, List[Message]]: the operation confirmation details

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_cancel_pickup_response.__name__,
            self.settings.carrier_name,
        )

    def parse_tracking_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[typing.List[models.TrackingDetails], typing.List[models.Message]]:
        """Create a unified API tracking result list from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[List[TrackingDetails], List[Message]]: the tracking details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_tracking_response.__name__, self.settings.carrier_name
        )

    def parse_rate_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[typing.List[models.RateDetails], typing.List[models.Message]]:
        """Create a unified API quote result list from carrier response

        Args:
            response (Deserializable): a deserializable tracking response (xml, json, text...)

        Returns:
            Tuple[List[RateDetails], List[Message]]: the rate details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_rate_response.__name__, self.settings.carrier_name
        )

    def parse_document_upload_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.DocumentUploadDetails, typing.List[models.Message]]:
        """Create a unified API quote result list from carrier response

        Args:
            response (Deserializable): a deserializable document upload details (xml, json, text...)

        Returns:
            Tuple[Deserializable, List[Message]]: the uploaded document details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_document_upload_response.__name__,
            self.settings.carrier_name,
        )

    def parse_manifest_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ManifestDetails, typing.List[models.Message]]:
        """Create a unified API manifest result from carrier response

        Args:
            response (Deserializable): a deserializable manifest response (xml, json, text...)

        Returns:
            Tuple[ManifestDetails, List[Message]]: the manifest details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_manifest_response.__name__,
            self.settings.carrier_name,
        )

    def parse_duties_calculation_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.DutiesCalculationDetails, typing.List[models.Message]]:
        """Create a unified API duties calculation result from carrier response

        Args:
            response (Deserializable): a deserializable duties calculation response (xml, json, text...)
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_duties_calculation_response.__name__,
            self.settings.carrier_name,
        )

    def parse_insurance_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.InsuranceDetails, typing.List[models.Message]]:
        """Create a unified API insurance result from carrier response

        Args:
            response (Deserializable): a deserializable insurance response (xml, json, text...)
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_insurance_response.__name__,
            self.settings.carrier_name,
        )

    def parse_webhook_registration_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.WebhookRegistrationDetails, typing.List[models.Message]]:
        """Create a unified API webhook registration result from carrier response

        Args:
            response (Deserializable): a deserializable webhook registration response (xml, json, text...)

        Returns:
            Tuple[WebhookRegistrationDetails, List[Message]]: the webhook registration details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_webhook_registration_response.__name__,
            self.settings.carrier_name,
        )

    def parse_webhook_deregistration_response(
        self, response: lib.Deserializable
    ) -> typing.Tuple[models.ConfirmationDetails, typing.List[models.Message]]:
        """Create a unified API webhook deregistration result from carrier response

        Args:
            response (Deserializable): a deserializable webhook deregistration response (xml, json, text...)

        Returns:
            Tuple[ConfirmationDetails, List[Message]]: the operation confirmation details
                as well as errors and messages returned

        Raises:
            MethodNotSupportedError: Is raised when the carrier integration does not implement this method
        """
        raise errors.MethodNotSupportedError(
            self.__class__.parse_webhook_deregistration_response.__name__,
            self.settings.carrier_name,
        )
