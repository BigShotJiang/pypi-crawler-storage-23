_**by Edgar Allan Poe**  
(published 1845)_

    

Of course I shall not pretend to consider it any matter for wonder, that the extraordinary case of M. Valdemar has excited discussion. It would have been a miracle had it not -- especially under the circumstances. Through the desire of all parties concerned, to keep the affair from the public, at least for the present, or until we had farther opportunities for investigation -- through our endeavors to effect this -- a garbled or exaggerated account made its way into society, and became the source of many unpleasant misrepresentations; and, very naturally, of a great deal of disbelief.  
  
    It is now rendered necessary that I give the facts -- as far as I comprehend them myself. They are, succinctly, these:  
  
    My attention, for the last three years, had been repeatedly drawn to the subject of Mesmerism; and, about nine months ago, it occurred to me, quite suddenly, that in the series of experiments made hitherto, there had been a very remarkable and most unaccountable omission: no person had as yet been mesmerized in articulo mortis. It remained to be seen, first, whether, in such condition, there existed in the patient any susceptibility to the magnetic influence; secondly, whether, if any existed, it was impaired or increased by the condition; thirdly, to what extent, or for how long a period, the encroachments of Death might be arrested by the process. There were other points to be ascertained, but these most excited my curiosity -- the last in especial, from the immensely important character of its consequences.  
  
    In looking around me for some subject by whose means I might test these particulars, I was brought to think of my friend, M. Ernest Valdemar, the well-known compiler of the "Bibliotheca Forensica," and author (under the nom de plume of Issachar Marx) of the Polish versions of "Wallenstein" and "Gargantua." M. Valdemar, who has resided principally at Harlem, N. Y., since the year 1839, is (or was) particularly noticeable for the extreme spareness of his person -- his lower limbs much resembling those of John Randolph; and, also, for the whiteness of his whiskers, in violent contrast to the blackness of his hair -- the latter, in consequence, being very generally mistaken for a wig. His temperament was markedly nervous, and rendered him a good subject for mesmeric experiment. On two or three occasions I had put him to sleep with little difficulty, but was disappointed in other results which his peculiar constitution had naturally led me to anticipate. His will was at no period positively, or thoroughly, under my control, and in regard to clairvoyance, I could accomplish with him nothing to be relied upon. I always attributed my failure at these points to the disordered state of his health. For some months previous to my becoming acquainted with him, his physicians had declared him in a confirmed phthisis. It was his custom, indeed, to speak calmly of his approaching dissolution, as of a matter neither to be avoided nor regretted.  
  
    When the ideas to which I have alluded first occurred to me, it was of course very natural that I should think of M. Valdemar. I knew the steady philosophy of the man too well to apprehend any scruples from him; and he had no relatives in America who would be likely to interfere. I spoke to him frankly upon the subject; and, to my surprise, his interest seemed vividly excited. I say to my surprise; for, although he had always yielded his person freely to my experiments, he had never before given me any tokens of sympathy with what I did. His disease was of that character which would admit of exact calculation in respect to the epoch of its termination in death; and it was finally arranged between us that he would send for me about twenty-four hours before the period announced by his physicians as that of his decease.  
  
    It is now rather more than seven months since I received, from M. Valdemar himself, the subjoined note:  
  
    "MY DEAR P___,  
  
    You may as well come now. D___ and F___ are agreed that I cannot hold out beyond to-morrow midnight; and I think they have hit the time very nearly.  
VALDEMAR."      
  
    I received this note within half an hour after it was written, and in fifteen minutes more I was in the dying man's chamber. I had not seen him for ten days, and was appalled by the fearful alteration which the brief interval had wrought in him. His face wore a leaden hue; the eyes were utterly lustreless; and the emaciation was so extreme, that the skin had been broken through by the cheek-bones. His expectoration was excessive. The pulse was barely perceptible. He retained, nevertheless, in a very remarkable manner, both his mental power and a certain degree of physical strength. He spoke with distinctness -- took some palliative medicines without aid -- and, when I entered the room, was occupied in penciling memoranda in a pocket-book. He was propped up in the bed by pillows. Doctors D___ and F___ were in attendance.  
  
    After pressing Valdemar's hand, I took these gentlemen aside, and obtained from them a minute account of the patient's condition. The left lung had been for eighteen months in a semi-osseous or cartilaginous state, and was, of course, entirely useless for all purposes of vitality. The right, in its upper portion, was also partially, if not thoroughly, ossified, while the lower region was merely a mass of purulent tubercles, running one into another. Several extensive perforations existed; and, at one point, permanent adhesion to the ribs had taken place. These appearances in the right lobe were of comparatively recent date. The ossification had proceeded with very unusual rapidity; no sign of it had discovered a month before, and the adhesion had only been observed during the three previous days. Independently of the phthisis, the patient was suspected of aneurism of the aorta; but on this point the osseous symptoms rendered an exact diagnosis impossible. It was the opinion of both physicians that M. Valdemar would die about midnight on the morrow (Sunday.) It was then seven o'clock on Saturday evening.  
  
    On quitting the invalid's bed-side to hold conversation with myself, Doctors D___ and F___ had bidden him a final farewell. It had not been their intention to return; but, at my request, they agreed to look in upon the patient about ten the next night.  
  
    When they had gone, I spoke freely with M. Valdemar on the subject of his approaching dissolution, as well as, more particularly, of the experiment proposed. He still professed himself quite willing and even anxious to have it made, and urged me to commence it at once. A male and a female nurse were in attendance; but I did not feel myself altogether at liberty to engage in a task of this character with no more reliable witnesses than these people, in case of sudden accident, might prove. I therefore postponed operations until about eight the next night, when the arrival of a medical student, with whom I had some acquaintance, (Mr. Theodore L___l,) relieved me from farther embarrassment. It had been my design, originally, to wait for the physicians; but I was induced to proceed, first, by the urgent entreaties of M. Valdemar, and secondly, by my conviction that I had not a moment to lose, as he was evidently sinking fast.  
  
    Mr. L___l was so kind as to accede to my desire that he would take notes of all that occurred; and it is from his memoranda that what I now have to relate is, for the most part, either condensed or copied verbatim.  
  
    It wanted about five minutes of eight when, taking the patient's hand, I begged him to state, as distinctly as he could, to Mr. L___l, whether he (M. Valdemar,) was entirely willing that I should make the experiment of mesmerizing him in his then condition.  
  
    He replied feebly, yet quite audibly, "Yes, I wish to be mesmerized" -- adding immediately afterwards, "I fear you have deferred it too long."  
  
    While he spoke thus, I commenced the passes which I had already found most effectual in subduing him. He was evidently influenced with the first lateral stroke of my hand across his forehead; but although I exerted all my powers, no farther perceptible effect was induced until some minutes after ten o'clock, when Doctors D___ and F___ called, according to appointment. I explained to them, in a few words, what I designed, and as they opposed no objection, saying that the patient was already in the death agony, I proceeded without hesitation -- exchanging, however, the lateral passes for downward ones, and directing my gaze entirely into the right eye of the sufferer.  
  
    By this time his pulse was imperceptible and his breathing was stertorous, and at intervals of half a minute.  
  
    This condition was nearly unaltered for a quarter of an hour. At the expiration of this period, however, a natural although a very deep sigh escaped the bosom of the dying man, and the stertorous breathing ceased -- that is to say, its stertorousness was no longer apparent; the intervals were undiminished. The patient's extremities were of an icy coldness.  
  
    At five minutes before eleven, I perceived unequivocal signs of the mesmeric influence. The glassy roll of the eye was changed for that expression of uneasy inward examination which is never seen except in cases of sleep-waking, and which it is quite impossible to mistake. With a few rapid lateral passes I made the lids quiver, as in incipient sleep, and with a few more I closed them altogether. I was not satisfied, however, with this, but continued the manipulations vigorously, and with the fullest exertion of the will, until I had completely stiffened the limbs of the slumberer, after placing them in a seemingly easy position. The legs were at full length; the arms were nearly so, and reposed on the bed at a moderate distance from the loins. The head was very slightly elevated.  
  
    When I had accomplished this, it was fully midnight, and I requested the gentlemen present to examine M. Valdemar's condition. After a few experiments, they admitted him to be in an unusually perfect state of mesmeric trance. The curiosity of both the physicians was greatly excited. Dr. D___ resolved at once to remain with the patient all night, while Dr. F___ took leave with a promise to return at daybreak. Mr. L___l and the nurses remained.  
  
    We left M. Valdemar entirely undisturbed until about three o'clock in the morning, when I approached him and found him in precisely the same condition as when Dr. F___ went away -- that is to say, he lay in the same position; the pulse was imperceptible; the breathing was gentle (scarcely noticeable, unless through the application of a mirror to the lips;) the eyes were closed naturally; and the limbs were as rigid and as cold as marble. Still, the general appearance was certainly not that of death.  
  
    As I approached M. Valdemar I made a kind of half effort to influence his right arm into pursuit of my own, as I passed the latter gently to and fro above his person. In such experiments with this patient, I had never perfectly succeeded before, and assuredly I had little thought of succeeding now; but to my astonishment, his arm very readily, although feebly, followed every direction I assigned it with mine. I determined to hazard a few words of conversation.  
  
    "M. Valdemar," I said, "are you asleep?" He made no answer, but I perceived a tremor about the lips, and was thus induced to repeat the question, again and again. At its third repetition, his whole frame was agitated by a very slight shivering; the eye-lids unclosed themselves so far as to display a white line of a ball; the lips moved sluggishly, and from between them, in a barely audible whisper, issued the words:  
  
    "Yes; asleep now. Do not wake me! -- let me die so!"  
  
    I here felt the limbs and found them as rigid as ever. The right arm, as before, obeyed the direction of my hand. I questioned the sleep-waker again:  
  
    "Do you still feel pain in the breast, M. Valdemar?"  
  
    The answer now was immediate, but even less audible than before:  
  
    "No pain -- I am dying."  
  
    I did not think it advisable to disturb him farther just then, and nothing more was said or done until the arrival of Dr. F___, who came a little before sunrise, and expressed unbounded astonishment at finding the patient still alive. After feeling the pulse and applying a mirror to the lips, he requested me to speak to the sleep-waker again. I did so, saying:  
  
    "M. Valdemar, do you still sleep?"  
  
    As before, some minutes elapsed ere a reply was made; and during the interval the dying man seemed to be collecting his energies to speak. At my fourth repetition of the question, he said very faintly, almost inaudibly:  
  
    "Yes; still asleep -- dying."  
  
    It was now the opinion, or rather the wish, of the physicians, that M. Valdemar should be suffered to remain undisturbed in his present apparently tranquil condition, until death should supervene -- and this, it was generally agreed, must now take place within a few minutes. I concluded, however, to speak to him once more, and merely repeated my previous question.  
  
    While I spoke, there came a marked change over the countenance of the sleep-waker. The eyes rolled themselves slowly open, the pupils disappearing upwardly; the skin generally assumed a cadaverous hue, resembling not so much parchment as white paper; and the circular hectic spots which, hitherto, had been strongly defined in the centre of each cheek, went out at once. I use this expression, because the suddenness of their departure put me in mind of nothing so much as the extinguishment of a candle by a puff of the breath. The upper lip, at the same time, writhed itself away from the teeth, which it had previously covered completely; while the lower jaw fell with an audible jerk, leaving the mouth widely extended, and disclosing in full view the swollen and blackened tongue. I presume that no member of the party then present had been unaccustomed to death-bed horrors; but so hideous beyond conception was the appearance of M. Valdemar at this moment, that there was a general shrinking back from the region of the bed.  
  
    I now feel that I have reached a point of this narrative at which every reader will be startled into positive disbelief. It is my business, however, simply to proceed.  
  
    There was no longer the faintest sign of vitality in M. Valdemar; and concluding him to be dead, we were consigning him to the charge of the nurses, when a strong vibratory motion was observable in the tongue. This continued for perhaps a minute. At the expiration of this period, there issued from the distended and motionless jaws a voice -- such as it would be madness in me to attempt describing. There are, indeed, two or three epithets which might be considered as applicable to it in part; I might say, for example, that the sound was harsh, and broken and hollow; but the hideous whole is indescribable, for the simple reason that no similar sounds have ever jarred upon the ear of humanity. There were two particulars, nevertheless, which I thought then, and still think, might fairly be stated as characteristic of the intonation -- as well adapted to convey some idea of its unearthly peculiarity. In the first place, the voice seemed to reach our ears -- at least mine -- from a vast distance, or from some deep cavern within the earth. In the second place, it impressed me (I fear, indeed, that it will be impossible to make myself comprehended) as gelatinous or glutinous matters impress the sense of touch.  
  
    I have spoken both of "sound" and of "voice." I mean to say that the sound was one of distinct -- of even wonderfully, thrillingly distinct -- syllabification. M. Valdemar spoke -- obviously in reply to the question I had propounded to him a few minutes before. I had asked him, it will be remembered, if he still slept. He now said:  
  
    "Yes; -- no; -- I have been sleeping -- and now -- now -- I am dead.  
  
    No person present even affected to deny, or attempted to repress, the unutterable, shuddering horror which these few words, thus uttered, were so well calculated to convey. Mr. L___l (the student) swooned. The nurses immediately left the chamber, and could not be induced to return. My own impressions I would not pretend to render intelligible to the reader. For nearly an hour, we busied ourselves, silently -- without the utterance of a word -- in endeavors to revive Mr. L___l. When he came to himself, we addressed ourselves again to an investigation of M. Valdemar's condition.  
  
    It remained in all respects as I have last described it, with the exception that the mirror no longer afforded evidence of respiration. An attempt to draw blood from the arm failed. I should mention, too, that this limb was no farther subject to my will. I endeavored in vain to make it follow the direction of my hand. The only real indication, indeed, of the mesmeric influence, was now found in the vibratory movement of the tongue, whenever I addressed M. Valdemar a question. He seemed to be making an effort to reply, but had no longer sufficient volition. To queries put to him by any other person than myself he seemed utterly insensible -- although I endeavored to place each member of the company in mesmeric rapport with him. I believe that I have now related all that is necessary to an understanding of the sleep-waker's state at this epoch. Other nurses were procured; and at ten o'clock I left the house in company with the two physicians and Mr. L___l.  
  
    In the afternoon we all called again to see the patient. His condition remained precisely the same. We had now some discussion as to the propriety and feasibility of awakening him; but we had little difficulty in agreeing that no good purpose would be served by so doing. It was evident that, so far, death (or what is usually termed death) had been arrested by the mesmeric process. It seemed clear to us all that to awaken M. Valdemar would be merely to insure his instant, or at least his speedy dissolution.  
  
    From this period until the close of last week -- an interval of nearly seven months -- we continued to make daily calls at M. Valdemar's house, accompanied, now and then, by medical and other friends. All this time the sleeper-waker remained exactly as I have last described him. The nurses' attentions were continual.  
  
    It was on Friday last that we finally resolved to make the experiment of awakening, or attempting to awaken him; and it is the (perhaps) unfortunate result of this latter experiment which has given rise to so much discussion in private circles -- to so much of what I cannot help thinking unwarranted popular feeling.  
  
    For the purpose of relieving M. Valdemar from the mesmeric trance, I made use of the customary passes. These, for a time, were unsuccessful. The first indication of revival was afforded by a partial descent of the iris. It was observed, as especially remarkable, that this lowering of the pupil was accompanied by the profuse out-flowing of a yellowish ichor (from beneath the lids) of a pungent and highly offensive odor.  
  
    It was now suggested that I should attempt to influence the patient's arm, as heretofore. I made the attempt and failed. Dr. F___ then intimated a desire to have me put a question. I did so, as follows:  
  
    "M. Valdemar, can you explain to us what are your feelings or wishes now?"  
  
    There was an instant return of the hectic circles on the cheeks; the tongue quivered, or rather rolled violently in the mouth (although the jaws and lips remained rigid as before;) and at length the same hideous voice which I have already described, broke forth:  
  
    "For God's sake! -- quick! -- quick! -- put me to sleep -- or, quick! -- waken me! -- quick! -- I say to you that I am dead!"  
  
    I was thoroughly unnerved, and for an instant remained undecided what to do. At first I made an endeavor to re-compose the patient; but, failing in this through total abeyance of the will, I retraced my steps and as earnestly struggled to awaken him. In this attempt I soon saw that I should be successful -- or at least I soon fancied that my success would be complete -- and I am sure that all in the room were prepared to see the patient awaken.  
  
    For what really occurred, however, it is quite impossible that any human being could have been prepared.  
  
    As I rapidly made the mesmeric passes, amid ejaculations of "dead! dead!" absolutely bursting from the tongue and not from the lips of the sufferer, his whole frame at once -- within the space of a single minute, or even less, shrunk -- crumbled -- absolutely rotted away beneath my hands. Upon the bed, before that whole company, there lay a nearly liquid mass of loathsome -- of detestable putridity.