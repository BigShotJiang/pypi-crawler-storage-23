*by Edgar Allan Poe*
*(published 1829)*

Thy soul shall find itself alone  
'Mid dark thoughts of the grey tomb-stone --  
Not one, of all the crowd, to pry  
Into thine hour of secrecy:  
Be silent in that solitude  
    Which is not loneliness -- for then  
The spirits of the dead who stood  
    In life before thee are again  
In death around thee --  and their will  
Shall then overshadow thee: be still.  

For the night -- tho' clear -- shall frown --  
And the stars shall look not down,  
From their high thrones in the Heaven,  
With light like Hope to mortals given --  
But their red orbs, without beam,  
To thy weariness shall seem  
As a burning and a fever  
Which would cling to thee for ever :  

Now are thoughts thou shalt not banish --  
Now are visions ne'er to vanish --  
From thy spirit shall they pass  
No more -- like dew-drop from the grass:  

The breeze -- the breath of God -- is still --  
And the mist upon the hill  
Shadowy -- shadowy -- yet unbroken,  
Is a symbol and a token --  
How it hangs upon the trees,  
A mystery of mysteries! --