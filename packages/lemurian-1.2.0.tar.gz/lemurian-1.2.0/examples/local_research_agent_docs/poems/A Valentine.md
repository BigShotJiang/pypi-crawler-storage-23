**by Edgar Allan Poe**
*(published 1850)*

For her this rhyme is penned, whose luminous eyes,  
     Brightly expressive as the twins of Leda,  
Shall find her own sweet name, that, nestling lies  
     Upon the page, enwrapped from every reader.  
Search narrowly the lines! -- they hold a treasure  
     Divine -- a talisman -- an amulet  
That must be worn at heart. Search well the measure --  
     The words -- the syllables! Do not forget  
The trivialest point, or you may lose your labor!  
     And yet there is in this no Gordian knot  
Which one might not undo without a sabre,  
     If one could merely comprehend the plot.  
Enwritten upon the leaf where now are peering  
     Eyes scintillating soul, there lie _perdu_,  
Three eloquent words oft uttered in the hearing  
     Of poets, by poets -- as the name is a poet's, too.  
Its letters, although naturally lying  
     Like the knight Pinto -- Mendez Ferdinando --  
Still form a synonym for Truth. -- Cease trying!  
     You will not read the riddle, though you do the best you _can_ do.