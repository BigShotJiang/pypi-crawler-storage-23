*by Edgar Allan Poe*  
*(published 1843)*

Lo! 'tis a gala night  
   Within the lonesome latter years!  
An angel throng, bewinged, bedight  
   In veils, and drowned in tears,  
Sit in a theatre, to see  
   A play of hopes and fears,  
While the orchestra breathes fitfully  
   The music of the spheres.

Mimes, in the form of God on high,  
   Mutter and mumble low,  
And hither and thither fly-  
   Mere puppets they, who come and go  
At bidding of vast formless things  
   That shift the scenery to and fro,  
Flapping from out their Condor wings  
   Invisible Woe!

That motley drama- oh, be sure  
   It shall not be forgot!  
With its Phantom chased for evermore,  
   By a crowd that seize it not,  
Through a circle that ever returneth in  
   To the self-same spot,  
And much of Madness, and more of Sin,  
   And Horror the soul of the plot.

But see, amid the mimic rout  
   A crawling shape intrude!  
A blood-red thing that writhes from out  
   The scenic solitude!  
It writhes!- it writhes!- with mortal pangs  
   The mimes become its food,  
And seraphs sob at vermin fangs  
   In human gore imbued.

Out- out are the lights- out all!  
   And, over each quivering form,  
The curtain, a funeral pall,  
   Comes down with the rush of a storm,  
While the angels, all pallid and wan,  
   Uprising, unveiling, affirm  
That the play is the tragedy, "Man,"  
   And its hero the Conqueror Worm.