**by Edgar Allan Poe**
*(published 1844)*

By a route obscure and lonely,
Haunted by ill angels only,
Where an Eidolon, named NIGHT,
On a black throne reigns upright,
I have reached these lands but newly
From an ultimate dim Thule --
From a wild weird clime that lieth, sublime,
      Out of SPACE -- out of TIME.

Bottomless vales and boundless floods,[[stories/Manuscript Found in a Bottle.md|Manuscript Found in a Bottle.md]]
And chasms, and caves, and Titan woods,
With forms that no man can discover
For the dews that drip all over;
Mountains toppling evermore
Into seas without a shore;
Seas that restlessly aspire,
Surging, unto skies of fire;
Lakes that endlessly outspread
Their lone waters -- lone and dead, --
Their still waters -- still and chilly
With the snows of the lolling lily.

By the lakes that thus outspread
Their lone waters, lone and dead, --
Their sad waters, sad and chilly
With the snows of the lolling lily, --
By the mountains -- near the river
Murmuring lowly, murmuring ever, --
By the grey woods, -- by the swamp
Where the toad and the newt encamp, --
By the dismal tarns and pools
Where dwell the Ghouls, --
By each spot the most unholy --
In each nook most melancholy, --
There the traveller meets aghast
Sheeted Memories of the Past --
Shrouded forms that start and sigh
As they pass the wanderer by --
White-robed forms of friends long given,
In agony, to the Earth -- and Heaven.

For the heart whose woes are legion
'Tis a peaceful, soothing region --
For the spirit that walks in shadow
'Tis -- oh 'tis an Eldorado!
But the traveller, travelling through it,
May not -- dare not openly view it;
Never its mysteries are exposed
To the weak human eye unclosed;
So wills its King, who hath forbid
The uplifting of the fringed lid;
And thus the sad Soul that here passes
Beholds it but through darkened glasses.

By a route obscure and lonely,
Haunted by ill angels only,
Where an Eidolon, named NIGHT,
On a black throne reigns upright,
I have wandered home but newly
From this ultimate dim Thule.