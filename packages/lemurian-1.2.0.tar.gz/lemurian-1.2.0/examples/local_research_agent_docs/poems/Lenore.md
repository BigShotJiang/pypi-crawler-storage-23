Ah broken is the golden bowl! the spirit flown forever!  
Let the bell toll!--a saintly soul floats on the Stygian river;  
And, Guy De Vere, hast _thou_ no tear?--weep now or never more!  
See! on yon drear and rigid bier low lies thy love, Lenore!  
Come! let the burial rite be read--the funeral song be sung!--  
An anthem for the queenliest dead that ever died so young--  
A dirge for her the doubly dead in that she died so young.

"Wretches! ye loved her for her wealth and hated her for her pride,  
"And when she fell in feeble health, ye blessed her--that she died!  
"How _shall_ the ritual, then, be read?--the requiem how be sung  
"By you--by yours, the evil eye,--by yours, the slanderous tongue  
"That did to death the innocent that died, and died so young?"

_Peccavimus;_ but rave not thus! and let a Sabbath song  
Go up to God so solemnly the dead may feel so wrong!  
The sweet Lenore hath "gone before," with Hope, that flew beside  
Leaving thee wild for the dear child that should have been thy bride--  
For her, the fair and _debonair_, that now so lowly lies,  
The life upon her yellow hair but not within her eyes--  
The life still there, upon her hair--the death upon her eyes.

"Avaunt! to-night my heart is light. No dirge will I upraise,  
"But waft the angel on her flight with a Pæan of old days!  
"Let _no_ bell toll!--lest her sweet soul, amid its hallowed mirth,  
"Should catch the note, as it doth float up from the damnéd Earth.  
"To friends above, from fiends below, the indignant ghost is riven--  
"From Hell unto a high estate far up within the Heaven--  
"From grief and groan, to a golden throne, beside the King of Heaven."