*by Edgar Allan Poe*
*(published 1845)*

SCIENCE! true daughter of Old Time thou art!
     Who alterest all things with thy peering eyes.
Why preyest thou thus upon the poet's heart,
     Vulture, whose wings are dull realities?
How should he love thee? or how deem thee wise,
     Who wouldst not leave him in his wandering
To seek for treasure in the jewelled skies
     Albeit he soared with an undaunted wing?
Hast thou not dragged Diana from her car?
     And driven the Hamadryad from the wood
To seek a shelter in some happier star?
     Hast thou not torn the Naiad from her flood,
The Elfin from the green grass, and from me
     The summer dream beneath the tamarind tree?