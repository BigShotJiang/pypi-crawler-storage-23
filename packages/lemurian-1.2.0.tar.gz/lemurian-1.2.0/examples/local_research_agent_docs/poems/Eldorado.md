*by Edgar Allan Poe*  
*(published 1849)*

GAILY bedight,  
        A gallant knight,  
In sunshine and in shadow,  
        Had journeyed long,  
        Singing a song,  
In search of Eldorado.

        But he grew old --  
        This knight so bold --  
And o'er his heart a shadow  
        Fell as he found  
        No spot of ground  
That looked like Eldorado.

        And, as his strength  
        Failed him at length,  
He met a pilgrim shadow --  
        "Shadow," said he,  
        "Where can it be --  
This land of Eldorado?"

        "Over the Mountains  
        Of the Moon,  
Down the Valley of the Shadow,  
        Ride, boldly ride,"  
        The shade replied, --  
"If you seek for Eldorado!"