*by Edgar Allan Poe*
*(published 1829)*

Fair river! in thy bright, clear flow  
    Of crystal, wandering water,  
Thou art an emblem of the glow  
        Of beauty -- the unhidden heart --  
        The playful maziness of art  
  In old Alberto's daughter;  

But when within thy wave she looks --  
        Which glistens then, and trembles --  
Why, then, the prettiest of brooks  
        Her worshipper resembles;  
For in my heart, as in thy stream,  
    Her image deeply lies --  
The heart which trembles at the beam  
    Of her soul-searching eyes.