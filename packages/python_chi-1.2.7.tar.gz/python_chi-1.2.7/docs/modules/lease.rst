.. _lease-module:

=========
chi.lease
=========

The :mod:`chi.lease` module can be used for interacting with resource leases.

.. automodule:: chi.lease
   :members:
