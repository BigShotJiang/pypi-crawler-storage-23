.. _ssh-module:

===========
chi.ssh
===========

The :mod:`chi.ssh` module allows you to create a remote connection to your instance.

.. automodule:: chi.ssh
   :members:
