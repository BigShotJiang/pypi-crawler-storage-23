"""ML3Seq implementation."""

import json
import os
from functools import cached_property
from typing import Any, Optional, Self

from ml3macro.utils.optional import obj_get_or_else
from ml3macro.utils.strings import strip_margin
from ml3on.core.config.config import ML3SeqFormatConfig
from ml3on.core.config.constants import (
    ML3Seq_FORMAT_SEPARATOR_PREFIX_DEFAULT,
    ML3Seq_FORMAT_SEPARATOR_PREFIX_ENV_VAR,
)
from ml3on.core.config.protocol import ML3SeqFormatConfigProtocol
from ml3on.core.item import ML3SeqItem


class ML3Seq:
    """The ML3Seq Format.

    What this format is good for: representing a sequence of items that may have  attributes/properties that
      are multi-line strings, especially in the context of LLMs. Because multi-line strings are unescaped
      in this format, it reduces the LLM's cognitive load, leading to better results and reliability.

    This format splits multi-line strings into unescaped text blocks.
    An unusual char sequence (default: `-~<§`, without ticks) is used as a prefix for separator lines that
     split up the sections of an item.
    The separator prefix is a configurable string and can be provided as an argument or environment variable
     (ML3Seq_FORMAT_SEPARATOR_PREFIX).

    The layout of a single item in the sequence, when serialized:
      1. {separatorPrefix}BEGIN:{kind} -- required
      2. {jsonWithNonMultilineValues} -- optional
      3. {separatorPrefix}{multilineVar1.name} -- for string in list of multiline strings, optional
         {multilineVar1.value}
         ...
         {separatorPrefix}{multilineVarN.name}
         {multilineVarN.value}
      4. {separatorPrefix}END:{kind} -- required

    The layout of a sequence, when serialized:
      1. {ml3SeqConfigJson} -- optional
      2. {item1.serialized} -- for item in sequence, optional
         ...
         {itemN.serialized}

    Examples:

        no config, one item:
            ```ml3seq
                -~<§BEGIN:TEST_ASSERTION
                {"idx": 0, "label": "happy path", "expect_exception": false, "condition": "equals", "is_success": false}
                -~<§actual
                Line 0.
                Line 1.
                -~<§expected
                Line 1.
                Line 2.
                -~<§END:TEST_ASSERTION
            ```
            this sequence could also be represented as json -- `actual` and `expected` are simply fields like the others:
            ```json
                [
                    {
                        "idx": 0,
                        "label": "happy path",
                        "expect_exception": false,
                        "condition": "equals",
                        "is_success": false,
                        "actual": "Line 0.\nLine 1.",
                        "expected": "Line 1.\nLine 2.",
                    }
                ]
            ```

        no config, two items (one with a multi-line string, one without):
            ```ml3seq
                -~<§BEGIN:FILE_CREATE
                {"project": "myproject", "filepath": "README.md"}
                -~<§content
                # My Project
                This is a sample README file created by Changesets.
                It can contain multiple lines of content.
                The file content continues until the END marker.
                -~<§END:FILE_CREATE
                -~<§BEGIN:FILE_DELETE
                {"project": "myproject", "filepath": "README-old.md"}
                -~<§END:FILE_DELETE
            ```

        with config, custom separator prefix:
            ```ml3seq
                {"separator_prefix": "BOOP|"}
                BOOP|BEGIN:FILE_CREATE
                {"project": "myproject", "filepath": "README.md"}
                BOOP|content
                # My Project

                ## Welcome to my project.

                _placeholder_
                   - thing 1
                   - thing 2
                BOOP|END:FILE_CREATE
            ```

    Here are the rules:
    1. The ML3Seq config is optional -- if the first line is valid json, that is the config
    2. Next


    """

    __config: Optional[ML3SeqFormatConfigProtocol]
    __items: tuple[ML3SeqItem, ...]
    __separator_prefix: str

    def __init__(
        self,
        /,
        *args: ML3SeqItem,
        config: Optional[ML3SeqFormatConfigProtocol] = None,
        **kwargs: Any,
    ) -> None:
        # Handle both positional and keyword items
        items_list = kwargs.get("items")

        if items_list is not None:
            # If items is provided as keyword argument, use it
            self.__items = tuple(items_list)
        elif args:
            # If positional arguments are provided, treat them as items
            self.__items = tuple(args)
        else:
            # No items provided
            self.__items = ()

        self.__config = config
        self.__separator_prefix = obj_get_or_else(
            obj=self.__config,
            get_value=lambda provided_config: provided_config.separator_prefix(),
            default=lambda: str(
                os.environ.get(
                    ML3Seq_FORMAT_SEPARATOR_PREFIX_ENV_VAR,
                    ML3Seq_FORMAT_SEPARATOR_PREFIX_DEFAULT,
                )
            ),
        )

    @property
    def separator_prefix(self) -> str:
        return self.__separator_prefix

    @property
    def config(self) -> Optional[ML3SeqFormatConfigProtocol]:
        return self.__config

    @property
    def items(self) -> tuple[ML3SeqItem, ...]:
        return self.__items

    @cached_property
    def __as_ml3seq(self) -> str:
        # Only include config if it has actual configuration values
        config_lines = []
        if self.__config is not None:
            config_dict = self.__config.to_dict()
            # Only include config if it has non-default/non-null values
            if config_dict and any(value is not None for value in config_dict.values()):
                config_lines = [json.dumps(config_dict)]

        # Use the actual config object, not the frozendict
        actual_config = self.__config if self.__config else ML3SeqFormatConfig()
        return "\n".join(
            config_lines + [item.to_ml3seq(actual_config) for item in self.items]
        )

    @property
    def as_ml3seq(self) -> str:
        return self.__as_ml3seq

    @classmethod
    def from_ml3seq(cls, value: str) -> Self:
        """Parse ML3Seq format string into ML3Sequence.

        Args:
            value: ML3Seq format string to parse

        Returns:
            Parsed ML3Sequence

        Raises:
            ValueError: If format is invalid
        """
        # Don't strip the entire value - preserve leading/trailing whitespace
        # Don't strip individual lines - preserve trailing whitespace
        # Do strip margins (fixed margin width on all lines expected based on the first line's indent)
        lines = tuple(
            strip_margin(value).split("\n")
        )  # Preserve all whitespace exactly
        if not lines:
            return cls()  # Empty sequence

        # Check if first line is config JSON
        config = None
        start_index = 0
        first_line = lines[0].strip()  # Only strip for JSON parsing

        # Try to parse as config if it looks like JSON
        if first_line.startswith("{") and first_line.endswith("}"):
            try:
                config_dict = json.loads(first_line)
                if "separator_prefix" in config_dict:  # Looks like config
                    config = ML3SeqFormatConfig(
                        separator_prefix=config_dict["separator_prefix"]
                    )
                    start_index = 1
            except json.JSONDecodeError:
                pass  # Not config, proceed with items

        # Determine separator prefix to use
        separator_prefix = obj_get_or_else(
            obj=config,
            get_value=lambda cfg: cfg.separator_prefix(),
            default=lambda: str(
                os.environ.get(
                    ML3Seq_FORMAT_SEPARATOR_PREFIX_ENV_VAR,
                    ML3Seq_FORMAT_SEPARATOR_PREFIX_DEFAULT,
                )
            ),
        )

        # Parse items
        items_builder: list[ML3SeqItem] = []
        current_item_lines: list[str] = []

        for line in lines[start_index:]:
            # Only recognize BEGIN markers when they appear at the very start of a line (no leading whitespace)
            # This ensures indented control markers are treated as content
            if line.startswith(f"{separator_prefix}BEGIN:"):
                if current_item_lines:  # Save previous item
                    item_str = "\n".join(current_item_lines)
                    if item_str.strip():  # Only parse non-empty items
                        parsed_config = config if config else ML3SeqFormatConfig()
                        items_builder.append(
                            ML3SeqItem.from_ml3seq(item_str, config=parsed_config)
                        )
                current_item_lines = [line]
            else:
                current_item_lines.append(line)

        # Don't forget the last item
        if current_item_lines:
            item_str = "\n".join(current_item_lines)
            if item_str.strip():  # Only parse non-empty items
                parsed_config = config if config else ML3SeqFormatConfig()
                items_builder.append(
                    ML3SeqItem.from_ml3seq(item_str, config=parsed_config)
                )

        return cls(*items_builder, config=config)
