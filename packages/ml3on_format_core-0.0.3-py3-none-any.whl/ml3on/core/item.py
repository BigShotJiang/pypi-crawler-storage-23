"""ML3Seq Item implementation."""

from __future__ import annotations

import json
from typing import Any, Optional, Self

from frozendict import frozendict
from ml3macro.utils.iterables import partition
from ml3on.core.config.protocol import ML3SeqFormatConfigProtocol
from ml3on.core.multiline import ML3SeqMultilineString


class ML3SeqItem:
    __kind: str
    __kv_pairs: tuple[tuple[str, Any], ...]

    def __init__(self, kind: str, /, **kwargs: Any):
        # Validate field names
        for field_name in kwargs.keys():
            if not isinstance(field_name, str):
                raise ValueError(f"Field names must be strings, got {type(field_name)}")
            if not field_name.strip():
                raise ValueError("Field names cannot be empty or whitespace-only")

        self.__kind = kind
        self.__kv_pairs = tuple((k, v) for k, v in kwargs.items())

    @property
    def kind(self) -> str:
        return self.__kind

    @property
    def kv_pairs(self) -> tuple[tuple[str, Any], ...]:
        return self.__kv_pairs

    def __getattr__(self, name: str) -> Any:
        """Allow attribute access to fields."""
        if name == "_ML3SeqItem__kind":
            return self.__kind
        elif name == "_ML3SeqItem__kv_pairs":
            return self.__kv_pairs

        # Look for the field in kv_pairs
        for key, value in self.__kv_pairs:
            if key == name:
                return value

        # If not found, raise AttributeError as expected
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'"
        )

    def to_ml3seq(self, config: ML3SeqFormatConfigProtocol, /) -> str:
        separator_prefix = config.separator_prefix()

        # Check if value should be in multiline block
        def should_be_multiline(kv: tuple[str, Any]) -> bool:
            _, value = kv
            return isinstance(value, ML3SeqMultilineString) or (
                isinstance(value, str) and "\n" in value
            )

        multiline_strings, non_multiline_strings = partition(
            self.__kv_pairs, condition=should_be_multiline
        )

        # Extract raw string values for serialization
        def get_raw_value(kv: tuple[str, Any]) -> str | Any:
            _, value = kv
            if isinstance(value, ML3SeqMultilineString):
                return str(value)
            return value

        non_multiline_dict = frozendict(
            {k: get_raw_value((k, v)) for k, v in non_multiline_strings}
        )

        def multiline_string_to_block(k: str, v: str, /) -> str:
            # Don't use strip_margin for multiline content to preserve original formatting
            return f"{separator_prefix}{k}\n{get_raw_value((k, v))}"

        multiline_blocks: tuple[str, ...] = tuple(
            multiline_string_to_block(multiline_k, multiline_v)
            for multiline_k, multiline_v in multiline_strings
        )

        # Build the final string
        json_part = json.dumps(non_multiline_dict)
        multiline_part = "\n".join(multiline_blocks)

        # Combine parts with proper newlines
        if multiline_blocks:
            # If we have multiline blocks, separate JSON and multiline parts with newline
            return f"{separator_prefix}BEGIN:{self.kind}\n{json_part}\n{multiline_part}\n{separator_prefix}END:{self.kind}"
        else:
            # If no multiline blocks, just JSON
            return f"{separator_prefix}BEGIN:{self.kind}\n{json_part}\n{separator_prefix}END:{self.kind}"

    @classmethod
    def from_ml3seq(cls, value: str, /, config: ML3SeqFormatConfigProtocol) -> Self:
        """Parse ML3Seq format string into ML3SeqItem.

        Args:
            value: ML3Seq format string to parse
            config: Configuration with separator prefix

        Returns:
            Parsed ML3SeqItem

        Raises:
            ValueError: If format is invalid
        """
        # Don't strip the entire value - preserve leading/trailing whitespace
        lines = tuple(value.split("\n"))  # Preserve all lines exactly as-is
        separator_prefix = config.separator_prefix()

        if not lines:
            raise ValueError("Empty ML3Seq item")

        # Parse BEGIN line - must be at start of line (no leading whitespace)
        # Use line.startswith() instead of begin_line.strip().startswith() to be strict about leading whitespace
        begin_line = lines[0]
        if not begin_line.startswith(f"{separator_prefix}BEGIN:"):
            raise ValueError(
                f"Invalid ML3Seq format: expected BEGIN marker, got {begin_line}"
            )

        kind = begin_line[len(f"{separator_prefix}BEGIN:") :].strip()
        if not kind:
            raise ValueError("ML3Seq item kind cannot be empty")

        # Parse JSON and multiline blocks immutably
        json_data: frozendict[str, Any] = frozendict({})
        multiline_blocks_builder: list[tuple[str, list[str]]] = []
        current_field: Optional[str] = None
        found_end_marker = False

        for line in lines[1:]:
            # Check for END marker - must be at start of line (no leading whitespace)
            if line.startswith(f"{separator_prefix}END:"):
                end_kind = line[len(f"{separator_prefix}END:") :].strip()
                if end_kind != kind:
                    raise ValueError(
                        f"BEGIN kind '{kind}' doesn't match END kind '{end_kind}'"
                    )
                found_end_marker = True
                break

            # Check for multiline field marker - must be at start of line
            if line.startswith(separator_prefix):
                # Extract field name and validate it
                field_name = line[len(separator_prefix) :].strip()

                # Validate field name is not empty
                if not field_name:
                    raise ValueError("Multiline field name cannot be empty")

                # Validate field name doesn't start with BEGIN: or END:
                if field_name.startswith("BEGIN:") or field_name.startswith("END:"):
                    # This is actually a control marker, not a field name
                    # This shouldn't happen if the format is correct, but let's handle it
                    raise ValueError(
                        f"Invalid field name: '{field_name}' - field names cannot start with BEGIN: or END:"
                    )

                # If we're already in a field, this means we're starting a new field
                # So finalize the current field first
                if current_field is not None:
                    # This is expected when we have multiple multiline fields
                    pass  # Just start the new field

                current_field = field_name
                multiline_blocks_builder.append((field_name, []))

            # Check for JSON data (only if not in a multiline block)
            elif current_field is None and not line.startswith(separator_prefix):
                json_result = _load_json_maybe(line)
                if json_result is not None:
                    json_data = json_result
                else:
                    # This might be content without a field marker (invalid format)
                    raise ValueError(f"Expected JSON or field marker, got: {line}")

            # This is content for current multiline field
            # (including lines that start with separator prefix - they're just content if indented)
            elif current_field is not None:
                # Find the current field in builder and append immutably
                new_builder = []
                for field, content_lines in multiline_blocks_builder:
                    if field == current_field:
                        new_builder.append((field, content_lines + [line]))
                    else:
                        new_builder.append((field, content_lines))
                multiline_blocks_builder = new_builder

        # Check if we found an END marker
        if not found_end_marker:
            raise ValueError(f"Missing END marker for ML3Seq item of kind '{kind}'")

        # Combine multiline content immutably - preserve exact whitespace
        multiline_blocks = frozendict(
            {
                field: "\n".join(
                    content_lines
                )  # Preserve exact line endings and whitespace
                for field, content_lines in multiline_blocks_builder
            }
        )

        # Combine all data immutably
        # Multiline blocks always become ML3SeqMultilineString
        all_data = frozendict(
            {
                **json_data,
                **{
                    field: ML3SeqMultilineString(content)
                    for field, content in multiline_blocks.items()
                },
            }
        )

        # Create item with positional kind argument
        return cls(kind, **dict(all_data))


def _load_json_maybe(value: str, /) -> Optional[frozendict[str, Any]]:
    """Try to parse a string as JSON, return None if not valid JSON."""
    try:
        return frozendict(json.loads(value))
    except (json.JSONDecodeError, TypeError):
        return None
