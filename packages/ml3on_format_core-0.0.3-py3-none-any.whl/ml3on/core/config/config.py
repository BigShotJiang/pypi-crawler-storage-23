from typing import Any, ClassVar, Mapping, Optional

from frozendict import frozendict


class ML3SeqFormatConfig:
    __dict: frozendict[str, Any]
    __separator_prefix_key: ClassVar[str] = "separator_prefix"

    def __init__(self, separator_prefix: Optional[str] = None, **kwargs: Any) -> None:
        # Validate separator prefix
        if separator_prefix is not None and len(separator_prefix) < 1:
            raise ValueError("separator_prefix must be >= 1 character when provided")

        # Use provided separator or None (will be handled by getter)
        prefix_dict = frozendict({self.__separator_prefix_key: separator_prefix})
        self.__dict = frozendict(kwargs) | prefix_dict

    def separator_prefix(self) -> str:
        """Get separator prefix, using default if not set."""
        prefix = self.__dict.get(self.__separator_prefix_key)
        if prefix is None:
            # Try environment variable, then default constant
            import os

            from ml3on.core.config.constants import (
                ML3Seq_FORMAT_SEPARATOR_PREFIX_DEFAULT,
                ML3Seq_FORMAT_SEPARATOR_PREFIX_ENV_VAR,
            )

            return os.environ.get(
                ML3Seq_FORMAT_SEPARATOR_PREFIX_ENV_VAR,
                ML3Seq_FORMAT_SEPARATOR_PREFIX_DEFAULT,
            )
        return str(prefix)

    def to_dict(self) -> Mapping[str, Any]:
        return frozendict(self.__dict)
