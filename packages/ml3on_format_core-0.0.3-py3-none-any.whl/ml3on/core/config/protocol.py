from typing import Any, Mapping, Protocol, runtime_checkable


@runtime_checkable
class ML3SeqFormatConfigProtocol(Protocol):
    def to_dict(self) -> Mapping[str, Any]: ...

    def separator_prefix(self) -> str: ...
