"""ML3SeqMultilineString - A string subclass for explicit multiline serialization control."""

from __future__ import annotations

from typing import Any


class ML3SeqMultilineString(str):
    """String subclass that marks values for multiline/unescaped serialization.

    This class inherits from str to ensure it behaves exactly like a string
    in all contexts, while providing explicit control over ML3Seq serialization
    format. The only difference from regular strings is how they're serialized.

    ML3SeqMultilineString instances are always serialized in multiline blocks,
    regardless of whether they contain newlines. This provides explicit control
    over the serialization format and ensures round-trip type preservation.

    Examples:
        >>> ml_str = ML3SeqMultilineString("single line")
        >>> isinstance(ml_str, str)
        True
        >>> isinstance(ml_str, ML3SeqMultilineString)
        True
        >>> str(ml_str)
        'single line'
        >>> ml_str.upper()
        'SINGLE LINE'
    """

    def __new__(cls, value: str | bytes) -> ML3SeqMultilineString:
        """Create a new ML3SeqMultilineString instance.

        Args:
            value: The string value to wrap (can be str or bytes)

        Returns:
            A new ML3SeqMultilineString instance

        Raises:
            TypeError: If value is not a string or bytes
        """
        if isinstance(value, bytes):
            # Convert bytes to string using UTF-8 encoding
            value = value.decode("utf-8")
        elif not isinstance(value, str):
            raise TypeError(
                f"ML3SeqMultilineString requires a string argument, got {type(value).__name__}"
            )
        return super().__new__(cls, value)

    def __hash__(self) -> int:
        """Return hash of the string value.

        Returns:
            Hash of the string value
        """
        return super().__hash__()

    def __repr__(self) -> str:
        """Return a representation showing this is a ML3SeqMultilineString.

        Returns:
            A string representation including the class name
        """
        return f"{type(self).__qualname__}({super().__repr__()})"

    def __eq__(self, other: Any) -> bool:
        """Compare with other strings or ML3SeqMultilineString instances.

        Args:
            other: The value to compare with

        Returns:
            True if equal, False otherwise
        """
        if isinstance(other, ML3SeqMultilineString):
            return super().__eq__(other)
        return super().__eq__(other)

    def __lt__(self, other: Any) -> bool:
        """Enable sorting by comparing string values.

        Args:
            other: The value to compare with

        Returns:
            True if this string is less than the other
        """
        if isinstance(other, ML3SeqMultilineString):
            return super().__lt__(other)
        return super().__lt__(other)

    def __reduce__(self) -> tuple[type, tuple[str]]:
        """Support for pickle serialization.

        Returns:
            Tuple for pickle reconstruction
        """
        return (type(self), (str(self),))
