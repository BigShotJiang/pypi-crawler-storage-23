from typing import TypeAlias

AgentQueue: TypeAlias = str | None
