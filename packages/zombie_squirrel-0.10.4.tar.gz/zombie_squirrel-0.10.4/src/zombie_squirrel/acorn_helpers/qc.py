"""Quality control data acorn."""

import logging
from datetime import datetime

import pandas as pd
from aind_data_access_api.document_db import MetadataDbClient

import zombie_squirrel.acorns as acorns
from zombie_squirrel.utils import (
    SquirrelMessage,
    load_columns_from_metadata,
    setup_logging,
)


@acorns.register_acorn(acorns.NAMES["qc"])
def qc(
    subject_id: str,
    asset_names: str | list[str] | None = None,
    force_update: bool = False,
    write_metadata: bool = True,
    lazy: bool = False,
) -> pd.DataFrame | str:
    """Fetch quality control metrics for assets belonging to a subject.

    Returns a DataFrame with columns from the quality_control metrics
    including: name, stage, object_type, modality, value, tags, status,
    status_history, asset_name, subject_id, and timestamp. Special handling:
    - modality: extracts the "abbreviation" field from the dict
    - status_history: takes the last element and extracts the "status" field
    Timestamp is the unix timestamp (seconds since epoch) from 
    acquisition.acquisition_start_time.

    Data is cached per subject_id. All assets for the subject are stored
    in cache, but can be filtered using the asset_names parameter.

    Args:
        subject_id: Subject ID to fetch QC data for (from subject.subject_id field).
        asset_names: Optional asset name or list of asset names to filter to.
                    If None, returns QC data for all assets of the subject.
        force_update: If True, bypass cache and fetch fresh data from database.
        write_metadata: If True, write metadata JSON with column names when caching.
                       Default True. Set to False to skip metadata writes on subsequent calls.
        lazy: If True, return the S3 path to the parquet file instead of loading the DataFrame.
              Default False. Path format is suitable for use with DuckDB.

    Returns:
        DataFrame with quality control metrics for the subject's asset(s), or
        string path to the S3 parquet file if lazy=True.

    Raises:
        ValueError: If requested asset_names are not found in the subject's cache."""
    cache_key = f"qc/{subject_id}"
    
    if lazy:
        if force_update:
            _fetch_subject_qc(subject_id, write_metadata=write_metadata)
        return acorns.TREE.get_path(cache_key)
    
    df = acorns.TREE.scurry(cache_key)

    if df.empty and not force_update:
        logging.error(
            SquirrelMessage(
                tree=acorns.TREE.__class__.__name__,
                acorn=acorns.NAMES["qc"],
                message=f"Cache is empty for subject {subject_id}. Use force_update=True to fetch data from database.",
            ).to_json()
        )

    if force_update:
        df = _fetch_subject_qc(subject_id, write_metadata=write_metadata)

    if asset_names is not None:
        df = _filter_by_asset_names(df, asset_names, subject_id)

    return df


def _fetch_subject_qc(subject_id: str, write_metadata: bool = True) -> pd.DataFrame:
    """Fetch QC data for all assets belonging to a subject.

    Args:
        subject_id: Subject ID to fetch QC data for.
        write_metadata: If True, write metadata JSON with column names when caching.
    """
    setup_logging()
    cache_key = f"qc/{subject_id}"

    logging.info(
        SquirrelMessage(
            tree=acorns.TREE.__class__.__name__,
            acorn=acorns.NAMES["qc"],
            message=f"Updating cache for subject {subject_id}",
        ).to_json()
    )

    client = MetadataDbClient(
        host=acorns.API_GATEWAY_HOST,
        version="v2",
    )

    records = client.retrieve_docdb_records(
        filter_query={"subject.subject_id": subject_id},
        projection={
            "_id": 1,
            "name": 1,
            "quality_control": 1,
            "acquisition.acquisition_start_time": 1,
            "subject.subject_id": 1,
        },
        limit=100,
    )

    if not records:
        logging.warning(
            SquirrelMessage(
                tree=acorns.TREE.__class__.__name__,
                acorn=acorns.NAMES["qc"],
                message=f"No records found for subject {subject_id}",
            ).to_json()
        )
        return pd.DataFrame()

    # Define explicit columns to extract from QC metrics
    qc_columns = [
        "object_type",
        "name",
        "modality",
        "stage",
        "value",
        "status_history",
        "description",
        "reference",
        "tags",
        "evaluated_assets",
    ]

    all_metrics = []
    for record in records:
        asset_name = record.get("name", "")
        quality_control = record.get("quality_control", {})
        acquisition = record.get("acquisition", {})
        subject = record.get("subject", {})
        
        subject_id_value = subject.get("subject_id", "")
        
        acquisition_start_time = acquisition.get("acquisition_start_time", None)
        timestamp = None
        if acquisition_start_time:
            try:
                dt = datetime.fromisoformat(acquisition_start_time.replace("Z", "+00:00"))
                timestamp = int(dt.timestamp())
            except (ValueError, AttributeError):
                timestamp = None

        if not quality_control or "metrics" not in quality_control:
            continue

        for metric in quality_control["metrics"]:
            metric_data = {}
            for col in qc_columns:
                value = metric.get(col, None)
                
                # Special handling for specific fields
                if col == "modality" and isinstance(value, dict):
                    value = value.get("abbreviation", None)
                elif col == "status_history" and isinstance(value, list) and len(value) > 0:
                    value = value[-1].get("status", None) if isinstance(value[-1], dict) else None
                
                metric_data[col] = value
            metric_data["asset_name"] = asset_name
            metric_data["subject_id"] = subject_id_value
            metric_data["timestamp"] = timestamp
            all_metrics.append(metric_data)

    if not all_metrics:
        logging.warning(
            SquirrelMessage(
                tree=acorns.TREE.__class__.__name__,
                acorn=acorns.NAMES["qc"],
                message=f"No quality_control metrics found for subject {subject_id}",
            ).to_json()
        )
        return pd.DataFrame()

    df = pd.DataFrame.from_records(all_metrics)
    acorns.TREE.hide(cache_key, df, write_metadata=write_metadata)

    logging.info(
        SquirrelMessage(
            tree=acorns.TREE.__class__.__name__,
            acorn=acorns.NAMES["qc"],
            message=f"Cached QC data for subject {subject_id} ({len(records)} assets, {len(all_metrics)} metrics)",
        ).to_json()
    )

    return df


def _filter_by_asset_names(df: pd.DataFrame, asset_names: str | list[str], subject_id: str) -> pd.DataFrame:
    """Filter QC DataFrame to specific asset names and validate they exist."""
    if df.empty:
        return df

    if isinstance(asset_names, str):
        asset_names = [asset_names]

    available_assets = df["asset_name"].unique().tolist()
    missing_assets = [name for name in asset_names if name not in available_assets]

    if missing_assets:
        logging.warning(
            SquirrelMessage(
                tree=acorns.TREE.__class__.__name__,
                acorn=acorns.NAMES["qc"],
                message=f"Requested asset(s) {missing_assets} not found in cache for subject {subject_id}. "
                f"Available assets: {available_assets}",
            ).to_json()
        )

    return df[df["asset_name"].isin(asset_names)].reset_index(drop=True)


def qc_columns() -> list[str]:
    """Get column names from quality control metadata.

    Returns:
        List of column names from the cached metadata."""
    return load_columns_from_metadata("qc")
