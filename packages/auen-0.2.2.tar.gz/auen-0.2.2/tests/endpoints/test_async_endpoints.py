"""Direct async endpoint tests and endpoint utilities."""

from __future__ import annotations

import pytest
from fastapi import APIRouter
from fastapi.routing import APIRoute
from pydantic import BaseModel, create_model
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlmodel import Field, SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession
from tests.conftest import Book, SessionFactory

from auen import (
    CrudRouterBuilder,
    FilterConfig,
    FilterFieldConfig,
    HooksConfig,
    Operation,
    PaginationConfig,
    SoftDeleteConfig,
    derive_schemas,
)
from auen._async_endpoints import _apply_soft_delete_filter
from auen._endpoints import RouterContext, _build_filter_model
from auen.exceptions import ForbiddenError, NotFoundError
from auen.policy import AllowAll
from auen.repository import AsyncSqlModelRepository
from auen.types import SelectQuery, User


def _get_route(router: APIRouter, path: str, method: str) -> APIRoute:
    prefix = router.prefix or ""
    full_path = f"{prefix}{path}"
    for route in router.routes:
        if (
            isinstance(route, APIRoute)
            and route.path == full_path
            and method in route.methods
        ):
            return route
    msg = f"Route {method} {full_path} not found"
    raise AssertionError(msg)


async def test_direct_endpoints_roundtrip(get_session: SessionFactory) -> None:
    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_pagination(PaginationConfig(include_total=True))
        .with_operations(
            {
                Operation.CREATE,
                Operation.READ,
                Operation.UPDATE,
                Operation.DELETE,
                Operation.LIST,
                Operation.BULK_CREATE,
                Operation.BULK_UPDATE,
                Operation.BULK_DELETE,
            }
        )
        .build()
    )

    create_ep = _get_route(router, "/", "POST").endpoint
    list_ep = _get_route(router, "/", "GET").endpoint
    read_ep = _get_route(router, "/{item_id}", "GET").endpoint
    update_ep = _get_route(router, "/{item_id}", "PATCH").endpoint
    delete_ep = _get_route(router, "/{item_id}", "DELETE").endpoint
    bulk_create_ep = _get_route(router, "/bulk", "POST").endpoint
    bulk_update_ep = _get_route(router, "/bulk", "PATCH").endpoint
    bulk_delete_ep = _get_route(router, "/bulk", "DELETE").endpoint

    BulkUpdateItem = create_model(
        "BookBulkUpdateItem",
        __base__=BaseModel,
        id=(int, ...),
        title=(str | None, None),
        pages=(int | None, None),
    )

    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="A", isbn="1"),
            session=session,
            user=None,
        )
        created_id = created.id
        await create_ep(
            obj_in=schemas.create(title="B", isbn="2"),
            session=session,
            user=None,
        )

        payload = await list_ep(
            session=session,
            user=None,
            offset=0,
            limit=10,
            sort=None,
            filter_params=None,
        )
        assert payload["total"] >= 2

        found = await read_ep(
            item_id=created_id,
            session=session,
            user=None,
        )
        assert found.id == created_id

        updated = await update_ep(
            item_id=created_id,
            obj_in=schemas.update(pages=123),
            session=session,
            user=None,
        )
        assert updated.pages == 123

        bulk_created = await bulk_create_ep(
            objects_in=[
                schemas.create(title="C", isbn="3"),
                schemas.create(title="D", isbn="4"),
            ],
            session=session,
            user=None,
        )
        bulk_ids = [obj.id for obj in bulk_created]
        bulk_update = await bulk_update_ep(
            items_in=[
                BulkUpdateItem(id=bulk_ids[0], title="C2"),
            ],
            session=session,
            user=None,
        )
        assert bulk_update[0].title == "C2"

        await bulk_delete_ep(
            ids=[bulk_ids[1]],
            session=session,
            user=None,
        )

        await delete_ep(item_id=created_id, session=session, user=None)


async def test_soft_delete_endpoints(
    engine: AsyncEngine, get_session: SessionFactory
) -> None:
    class SoftBookExtra(SQLModel, table=True):
        __tablename__ = "softbook_extra"
        id: int | None = Field(default=None, primary_key=True)
        title: str
        isbn: str
        deleted_at: str | None = None

    schemas = derive_schemas(SoftBookExtra)
    router = (
        CrudRouterBuilder.for_model(SoftBookExtra, get_session)
        .with_soft_delete(SoftDeleteConfig())
        .with_operations(
            {
                Operation.CREATE,
                Operation.READ,
                Operation.DELETE,
                Operation.LIST,
                Operation.BULK_DELETE,
            }
        )
        .build()
    )

    create_ep = _get_route(router, "/", "POST").endpoint
    list_ep = _get_route(router, "/", "GET").endpoint
    read_ep = _get_route(router, "/{item_id}", "GET").endpoint
    delete_ep = _get_route(router, "/{item_id}", "DELETE").endpoint
    bulk_delete_ep = _get_route(router, "/bulk", "DELETE").endpoint

    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="Soft", isbn="S1"),
            session=session,
            user=None,
        )
        created_id = created.id
        await delete_ep(item_id=created_id, session=session, user=None)
        with pytest.raises(NotFoundError):
            await read_ep(item_id=created_id, session=session, user=None)

        await list_ep(
            session=session,
            user=None,
            offset=0,
            limit=10,
            sort=None,
            filter_params=None,
        )

        created2 = await create_ep(
            obj_in=schemas.create(title="Soft2", isbn="S2"),
            session=session,
            user=None,
        )
        await bulk_delete_ep(
            ids=[created2.id],
            session=session,
            user=None,
        )


async def test_create_forbidden(get_session: SessionFactory) -> None:
    class DenyCreate:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return False

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return True

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyCreate())
        .with_operations({Operation.CREATE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint

    async for session in get_session():
        with pytest.raises(ForbiddenError):
            await create_ep(
                obj_in=schemas.create(title="Nope", isbn="X"),
                session=session,
                user=None,
            )


async def test_create_after_hook(get_session: SessionFactory) -> None:
    schemas = derive_schemas(Book)
    called = []

    async def after_create(session: AsyncSession, obj: Book, user: User) -> None:
        called.append(obj.title)

    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_hooks(HooksConfig(after_create=after_create))
        .with_operations({Operation.CREATE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint

    async for session in get_session():
        await create_ep(
            obj_in=schemas.create(title="Hooked", isbn="H"),
            session=session,
            user=None,
        )

    assert called == ["Hooked"]


def test_build_filter_model_skips_missing_fields() -> None:
    cfg = FilterConfig(fields={"missing": FilterFieldConfig()})
    model = _build_filter_model(Book, cfg)
    assert model.model_fields == {}


def test_apply_soft_delete_filter_missing_column() -> None:
    class ModelNoSoft(SQLModel, table=True):
        __tablename__ = "model_no_soft"
        id: int | None = Field(default=None, primary_key=True)
        title: str

    schemas = derive_schemas(ModelNoSoft)
    ctx = RouterContext(
        router=APIRouter(),
        model=ModelNoSoft,
        model_name="ModelNoSoft",
        schemas=schemas,
        policy=AllowAll(),
        session_dep=lambda: None,
        auth=None,
        pk_name="id",
        pk_type=int,
        pagination=PaginationConfig(),
        filters=None,
        repository_factory=AsyncSqlModelRepository,
        hooks=HooksConfig(),
        soft_delete=SoftDeleteConfig(field="missing"),
        include_in_schema=set(),
        operation_id_prefix="modelnosoft",
    )
    query = select(ModelNoSoft)
    assert _apply_soft_delete_filter(ctx, query) is query


async def test_list_without_total_returns_items(get_session: SessionFactory) -> None:
    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_pagination(PaginationConfig(include_total=False))
        .with_operations({Operation.CREATE, Operation.LIST})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    list_ep = _get_route(router, "/", "GET").endpoint
    async for session in get_session():
        await create_ep(
            obj_in=schemas.create(title="NoTotal", isbn="NT"),
            session=session,
            user=None,
        )
        payload = await list_ep(
            session=session,
            user=None,
            offset=0,
            limit=10,
            sort=None,
            filter_params=None,
        )
        assert isinstance(payload, list)


async def test_read_not_found_and_forbidden(get_session: SessionFactory) -> None:
    class DenyRead:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return True

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return False

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return True

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyRead())
        .with_operations({Operation.CREATE, Operation.READ})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    read_ep = _get_route(router, "/{item_id}", "GET").endpoint
    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="Denied", isbn="DR"),
            session=session,
            user=None,
        )
        with pytest.raises(ForbiddenError):
            await read_ep(item_id=created.id, session=session, user=None)
        with pytest.raises(NotFoundError):
            await read_ep(item_id=9999, session=session, user=None)


async def test_update_branches(get_session: SessionFactory) -> None:
    class DenyUpdate:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return True

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return False

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    called = []

    async def before_update(session: AsyncSession, obj: SQLModel, user: User) -> None:
        called.append("before")

    async def after_update(session: AsyncSession, obj: SQLModel, user: User) -> None:
        called.append("after")

    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_hooks(HooksConfig(before_update=before_update, after_update=after_update))
        .with_operations({Operation.CREATE, Operation.UPDATE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    update_ep = _get_route(router, "/{item_id}", "PATCH").endpoint
    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="Up", isbn="U"),
            session=session,
            user=None,
        )
        result = await update_ep(
            item_id=created.id,
            obj_in=schemas.update(title="Up2"),
            session=session,
            user=None,
        )
        assert result.title == "Up2"
        assert called == ["before", "after"]

    router_forbidden = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyUpdate())
        .with_operations({Operation.CREATE, Operation.UPDATE})
        .build()
    )
    create_forbidden = _get_route(router_forbidden, "/", "POST").endpoint
    update_forbidden = _get_route(router_forbidden, "/{item_id}", "PATCH").endpoint
    async for session in get_session():
        created = await create_forbidden(
            obj_in=schemas.create(title="DeniedUp", isbn="DU"),
            session=session,
            user=None,
        )
        with pytest.raises(ForbiddenError):
            await update_forbidden(
                item_id=created.id,
                obj_in=schemas.update(title="x"),
                session=session,
                user=None,
            )
        with pytest.raises(NotFoundError):
            await update_forbidden(
                item_id=9999,
                obj_in=schemas.update(title="x"),
                session=session,
                user=None,
            )


async def test_delete_branches(get_session: SessionFactory) -> None:
    class DenyDelete:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return True

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return True

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return False

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    called = []

    async def before_delete(session: AsyncSession, obj: SQLModel, user: User) -> None:
        called.append("before")

    async def after_delete(session: AsyncSession, obj: SQLModel, user: User) -> None:
        called.append("after")

    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_hooks(HooksConfig(before_delete=before_delete, after_delete=after_delete))
        .with_operations({Operation.CREATE, Operation.DELETE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    delete_ep = _get_route(router, "/{item_id}", "DELETE").endpoint
    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="Del", isbn="D"),
            session=session,
            user=None,
        )
        await delete_ep(item_id=created.id, session=session, user=None)
        assert called == ["before", "after"]

    router_forbidden = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyDelete())
        .with_operations({Operation.CREATE, Operation.DELETE})
        .build()
    )
    create_forbidden = _get_route(router_forbidden, "/", "POST").endpoint
    delete_forbidden = _get_route(router_forbidden, "/{item_id}", "DELETE").endpoint
    async for session in get_session():
        created = await create_forbidden(
            obj_in=schemas.create(title="DeniedDel", isbn="DD"),
            session=session,
            user=None,
        )
        with pytest.raises(ForbiddenError):
            await delete_forbidden(item_id=created.id, session=session, user=None)
        with pytest.raises(NotFoundError):
            await delete_forbidden(item_id=9999, session=session, user=None)


async def test_bulk_create_forbidden(get_session: SessionFactory) -> None:
    class DenyCreate:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return False

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return True

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyCreate())
        .with_operations({Operation.BULK_CREATE})
        .build()
    )
    bulk_create_ep = _get_route(router, "/bulk", "POST").endpoint
    async for session in get_session():
        with pytest.raises(ForbiddenError):
            await bulk_create_ep(
                objects_in=[derive_schemas(Book).create(title="T", isbn="I")],
                session=session,
                user=None,
            )


async def test_bulk_update_forbidden_and_not_found(
    get_session: SessionFactory,
) -> None:
    class DenyUpdate:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return True

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return False

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_operations({Operation.CREATE, Operation.BULK_UPDATE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    bulk_update_ep = _get_route(router, "/bulk", "PATCH").endpoint

    BulkUpdateItem = create_model(
        "BulkUpdateForbidden",
        __base__=BaseModel,
        id=(int, ...),
        title=(str | None, None),
    )

    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="Bulk", isbn="B"),
            session=session,
            user=None,
        )
        with pytest.raises(NotFoundError):
            await bulk_update_ep(
                items_in=[BulkUpdateItem(id=9999, title="X")],
                session=session,
                user=None,
            )

    router_forbidden = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyUpdate())
        .with_operations({Operation.CREATE, Operation.BULK_UPDATE})
        .build()
    )
    create_ep2 = _get_route(router_forbidden, "/", "POST").endpoint
    bulk_update_forbidden = _get_route(router_forbidden, "/bulk", "PATCH").endpoint
    async for session in get_session():
        created = await create_ep2(
            obj_in=schemas.create(title="Bulk2", isbn="B2"),
            session=session,
            user=None,
        )
        with pytest.raises(ForbiddenError):
            await bulk_update_forbidden(
                items_in=[BulkUpdateItem(id=created.id, title="X")],
                session=session,
                user=None,
            )


async def test_bulk_delete_branches(
    engine: AsyncEngine, get_session: SessionFactory
) -> None:
    class SoftBookBulk(SQLModel, table=True):
        __tablename__ = "softbook_bulk_branch"
        id: int | None = Field(default=None, primary_key=True)
        title: str
        deleted_at: str | None = None

    schemas = derive_schemas(SoftBookBulk)
    router_soft = (
        CrudRouterBuilder.for_model(SoftBookBulk, get_session)
        .with_soft_delete(SoftDeleteConfig())
        .with_operations({Operation.CREATE, Operation.BULK_DELETE})
        .build()
    )
    create_ep = _get_route(router_soft, "/", "POST").endpoint
    bulk_delete_ep = _get_route(router_soft, "/bulk", "DELETE").endpoint

    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="SB", deleted_at=None),
            session=session,
            user=None,
        )
        await bulk_delete_ep(ids=[created.id], session=session, user=None)
        with pytest.raises(NotFoundError):
            await bulk_delete_ep(ids=[9999], session=session, user=None)


async def test_bulk_delete_forbidden(get_session: SessionFactory) -> None:
    class DenyDelete:
        def can_create(self, user: User, obj_in: BaseModel) -> bool:
            return True

        def can_read(self, user: User, db_obj: SQLModel) -> bool:
            return True

        def can_update(self, user: User, db_obj: SQLModel, obj_in: BaseModel) -> bool:
            return True

        def can_delete(self, user: User, db_obj: SQLModel) -> bool:
            return False

        def filter_list_query(
            self, user: User, query: SelectQuery[SQLModel]
        ) -> SelectQuery[SQLModel]:
            return query

    schemas = derive_schemas(Book)
    router = (
        CrudRouterBuilder.for_model(Book, get_session)
        .with_policy(DenyDelete())
        .with_operations({Operation.CREATE, Operation.BULK_DELETE})
        .build()
    )
    create_ep = _get_route(router, "/", "POST").endpoint
    bulk_delete_ep = _get_route(router, "/bulk", "DELETE").endpoint
    async for session in get_session():
        created = await create_ep(
            obj_in=schemas.create(title="FD", isbn="FD"),
            session=session,
            user=None,
        )
        with pytest.raises(ForbiddenError):
            await bulk_delete_ep(ids=[created.id], session=session, user=None)


def test_apply_soft_delete_filter_direct() -> None:
    class SoftModel(SQLModel, table=True):
        __tablename__ = "soft_model_direct"
        id: int | None = Field(default=None, primary_key=True)
        deleted_at: str | None = None

    schemas = derive_schemas(SoftModel)
    ctx = RouterContext(
        router=APIRouter(),
        model=SoftModel,
        model_name="SoftModel",
        schemas=schemas,
        policy=AllowAll(),
        session_dep=lambda: None,
        auth=None,
        pk_name="id",
        pk_type=int,
        pagination=PaginationConfig(),
        filters=None,
        repository_factory=AsyncSqlModelRepository,
        hooks=HooksConfig(),
        soft_delete=SoftDeleteConfig(),
        include_in_schema=set(),
        operation_id_prefix="softmodel",
    )
    query = select(SoftModel)
    filtered = _apply_soft_delete_filter(ctx, query)
    assert filtered is not None
