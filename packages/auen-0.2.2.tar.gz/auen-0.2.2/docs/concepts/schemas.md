# Schema Separation

Auen requires separate schemas for Create, Read, and Update operations. This prevents accidentally exposing internal fields (like `hashed_password`) or allowing clients to set server-managed fields (like `created_at`).

## Why not use the table model directly?

Using `Hero` as both the request and response model leaks every column to clients and lets them set fields like `id` on creation. This is a common security footgun.

## Explicit schemas (recommended)

```python
from pydantic import BaseModel

class HeroCreate(BaseModel):
    name: str
    secret_name: str
    age: int | None = None

class HeroRead(BaseModel):
    id: int
    name: str
    secret_name: str
    age: int | None = None

class HeroUpdate(BaseModel):
    name: str | None = None
    age: int | None = None
```

## Auto-derived schemas (quick prototyping)

```python
from auen import derive_schemas

schemas = derive_schemas(Hero)
# schemas.create excludes PK fields
# schemas.update makes all non-PK fields optional
# schemas.read includes all fields
```

Use `derive_schemas` for prototyping, but define explicit schemas for production APIs.
