# Pagination & Filtering

## Pagination

All LIST endpoints support `offset` and `limit` query parameters.

```python
from auen import PaginationConfig

pagination = PaginationConfig(
    default_limit=20,   # default if client omits limit
    max_limit=100,      # 422 if client requests more
)
```

## Sorting

Enable sorting on specific fields:

```python
from auen import FilterConfig

filters = FilterConfig(sort_fields=["name", "age"])
```

Clients sort with `?sort=name` (ascending) or `?sort=-name` (descending). Sorting on non-allowlisted fields returns 422.

## Field filtering

Allow filtering on specific fields with specific operations:

```python
from auen import FilterConfig, FilterFieldConfig

filters = FilterConfig(
    fields={
        "name": FilterFieldConfig(ops=frozenset({"eq"})),
        "age": FilterFieldConfig(ops=frozenset({"eq"})),
    },
    sort_fields=["name", "age"],
)
```
