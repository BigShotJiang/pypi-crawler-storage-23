# Changelog

## 0.1.0 (unreleased)

- Initial release
- CRUD router generation from SQLModel models
- Policy-based authorization hooks
- Configurable pagination and filtering
- Schema separation (Create / Read / Update)
