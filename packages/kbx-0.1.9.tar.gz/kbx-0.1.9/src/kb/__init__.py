"""kbx — local knowledge base CLI with hybrid search over markdown files."""

from kb.api import KnowledgeBase

__all__ = ["KnowledgeBase"]
