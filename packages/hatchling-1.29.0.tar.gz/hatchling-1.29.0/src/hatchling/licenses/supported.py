from packaging.licenses._spdx import VERSION  # noqa: F401, PLC2701
