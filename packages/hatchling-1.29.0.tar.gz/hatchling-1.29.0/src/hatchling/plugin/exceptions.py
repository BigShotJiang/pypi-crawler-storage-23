class UnknownPluginError(ValueError):
    pass
