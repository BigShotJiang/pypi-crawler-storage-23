import binascii

class UDTP_Checker:
    @staticmethod
    def calculate_crc32(data: bytes) -> int:
        return binascii.crc32(data) & 0xFFFFFFFF

    @staticmethod
    def validate_integrity(data: bytes, expected_crc: int) -> bool:
        return UDTP_Checker.calculate_crc32(data) == expected_crc