import logging
import sys

class UDTP_Logger:
    _instance = None

    @staticmethod
    def get_instance():
        if UDTP_Logger._instance is None:
            UDTP_Logger._instance = UDTP_Logger._setup()
        return UDTP_Logger._instance

    @staticmethod
    def _setup():
        logger = logging.getLogger("UDTP_SYSTEM")
        logger.setLevel(logging.INFO)
        
        formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(module)s: %(message)s')
        
        # Консольный вывод
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        
        return logger