import time
class UDTP_Performance:
    @staticmethod
    def profile_operation(label, func, *args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"[PERF] {label}: {(end-start)*1000:.2f} ms")
        return result