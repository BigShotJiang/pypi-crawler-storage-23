class UDTP_Vault:
    SESSIONS = {}
    TRUSTED_KEYS = []