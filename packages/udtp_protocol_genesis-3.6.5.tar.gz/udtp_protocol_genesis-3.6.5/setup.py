from setuptools import setup, find_packages

setup(
    name='udtp-protocol-genesis',
    version='3.6.5',
    author='UDTP_ARCHITECT',
    description='Universal Data Transfer Protocol - Genesis Build 3.6.5',
    packages=find_packages(),
    python_requires='>=3.7',
    install_requires=[],
)