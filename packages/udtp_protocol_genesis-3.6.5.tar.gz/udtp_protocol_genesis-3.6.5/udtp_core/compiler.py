import os
import time
from .engine import UDTP_Engine
from udtp_utils.logger import UDTP_Logger

class UDTP_Compiler:
    """
    Компилятор файлов в поток пакетов UDTP.
    Реализует сегментацию данных с учетом MTU.
    """
    def __init__(self, mtu=1400):
        self.mtu = mtu
        self.log = UDTP_Logger.get_instance()

    def compile_file(self, source_path, dest_path, session_id=1001):
        if not os.path.exists(source_path):
            self.log.error(f"Файл {source_path} не найден!")
            return False
            
        start_time = time.time()
        file_size = os.path.getsize(source_path)
        packet_count = 0
        
        with open(source_path, 'rb') as f_src, open(dest_path, 'wb') as f_dst:
            seq = 0
            while True:
                chunk = f_src.read(self.mtu)
                if not chunk:
                    break
                
                # Создание и упаковка пакета
                packet = UDTP_Engine.pack(
                    data=chunk, 
                    sid=session_id, 
                    seq=seq, 
                    flags=0x04 # PSH Flag
                )
                f_dst.write(packet)
                seq += len(chunk)
                packet_count += 1
                
        duration = time.time() - start_time
        self.log.info(f"Компиляция завершена: {packet_count} пакетов создано за {duration:.4f} сек.")
        return True