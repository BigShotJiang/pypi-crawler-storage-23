import struct
import zlib
import binascii
import random
from udtp_security.crypto import UDTP_Crypto
from udtp_utils.checker import UDTP_Checker

class UDTP_Engine:
    """
    Ядро протокола UDTP v3.6.5.
    Структура заголовка (28 байт):
    [Signature:4s][Version:H][Flags:B][SessionID:H][Seq:I][Ack:I][Window:H][Entropy:H][Checksum:I]
    """
    HEADER_FORMAT = "!4sHBHIIHHI"
    SIGNATURE = b"UDTP"
    VERSION = 0x0365

    @staticmethod
    def pack(data=b"", sid=0, seq=0, ack=0, flags=0x04, win=65535):
        # 1. Генерация энтропии для защиты от Replay-атак
        entropy = random.randint(0, 65535)
        
        # 2. Обработка полезной нагрузки (Payload)
        payload = b""
        if data:
            # Сжатие перед шифрованием для максимальной эффективности
            compressed = zlib.compress(data)
            # Применение динамического XOR-шифрования v3.6.5
            payload = UDTP_Crypto.encrypt_v3(compressed)
            
        # 3. Предварительная сборка заголовка с нулевым Checksum
        header_pre = struct.pack(
            UDTP_Engine.HEADER_FORMAT, 
            UDTP_Engine.SIGNATURE, 
            UDTP_Engine.VERSION,
            flags, sid, seq, ack, win, entropy, 0
        )
        
        # 4. Расчет контрольной суммы (Header + Payload)
        checksum = binascii.crc32(header_pre + payload) & 0xFFFFFFFF
        
        # 5. Финальная сборка пакета
        return struct.pack(
            UDTP_Engine.HEADER_FORMAT, 
            UDTP_Engine.SIGNATURE, 
            UDTP_Engine.VERSION,
            flags, sid, seq, ack, win, entropy, checksum
        ) + payload

    @staticmethod
    def unpack(raw_packet):
        h_size = struct.calcsize(UDTP_Engine.HEADER_FORMAT)
        if len(raw_packet) < h_size:
            raise ValueError("UDTP_ERROR: Пакет слишком мал для заголовка")
            
        # Распаковка заголовка
        h_data = struct.unpack(UDTP_Engine.HEADER_FORMAT, raw_packet[:h_size])
        sign, ver, flags, sid, seq, ack, win, entropy, r_checksum = h_data
        payload = raw_packet[h_size:]
        
        # Валидация сигнатуры и версии
        if sign != UDTP_Engine.SIGNATURE:
            raise ValueError("UDTP_ERROR: Неверная сигнатура протокола")
            
        # Проверка целостности данных (CRC32)
        h_check = struct.pack(
            UDTP_Engine.HEADER_FORMAT, 
            sign, ver, flags, sid, seq, ack, win, entropy, 0
        )
        actual_crc = binascii.crc32(h_check + payload) & 0xFFFFFFFF
        
        if actual_crc != r_checksum:
            raise ValueError(f"UDTP_INTEGRITY_ERROR: Ошибка контрольной суммы (Received: {r_checksum}, Actual: {actual_crc})")
            
        # Дешифровка и декомпрессия данных
        data = b""
        if payload:
            decrypted = UDTP_Crypto.decrypt_v3(payload)
            data = zlib.decompress(decrypted)
            
        return {
            "version": ver,
            "flags": flags,
            "sid": sid,
            "seq": seq,
            "ack": ack,
            "window": win,
            "data": data
        }