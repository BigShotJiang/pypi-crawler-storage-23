from udtp_core.engine import UDTP_Engine
from udtp_utils.logger import UDTP_Logger

class UDTP_Stack:
    def __init__(self, sid=None):
        self.sid = sid or 0x777
        self.seq = 0
        self.ack = 0
        self.state = "CLOSED"
        self.log = UDTP_Logger.get_instance()

    def create_handshake_syn(self):
        self.log.info(f"Инициализация Handshake SYN для SID: {self.sid}")
        self.state = "SYN_SENT"
        return UDTP_Engine.pack(sid=self.sid, seq=self.seq, flags=0x01) # SYN

    def process_incoming(self, raw_packet):
        try:
            packet = UDTP_Engine.unpack(raw_packet)
            self.log.info(f"Получен пакет: Seq={packet['seq']}, Flags={packet['flags']}")
            return packet
        except Exception as e:
            self.log.error(f"Ошибка при обработке входящего пакета: {e}")
            return None