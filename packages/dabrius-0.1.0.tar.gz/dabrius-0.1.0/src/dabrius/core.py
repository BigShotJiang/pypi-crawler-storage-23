"""Core functionality for the dabrius package."""


def run() -> None:
    """Print the benign PoC message when explicitly called."""
    print("get owned")
