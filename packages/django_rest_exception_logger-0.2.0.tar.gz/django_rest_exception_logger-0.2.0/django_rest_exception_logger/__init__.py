"""Django Rest Exception Logger package."""

__all__ = ["__version__"]

# Keep in sync with setup.py
__version__ = "0.2.0"

