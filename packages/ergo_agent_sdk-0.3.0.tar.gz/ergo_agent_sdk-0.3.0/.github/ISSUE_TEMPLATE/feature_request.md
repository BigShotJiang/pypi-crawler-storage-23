---
name: Feature request
about: Suggest a new feature for the ergo-agent SDK
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Problem

What problem does this feature solve?

## Proposed Solution

How should this feature work?

## Alternatives Considered

Any alternative approaches you've thought about.

## Additional Context

Links to relevant Ergo docs, protocols, or examples.
