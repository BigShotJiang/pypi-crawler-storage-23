from macro_studio import MacroStudio


def main():
    studio = MacroStudio()
    studio.launch()


if __name__ == "__main__":
    main()