<script>
window.location.replace("https://pycqa.github.io/isort/");
</script>

The latest isort docs are not on ReadTheDocs. This page contains a javascript redirect to the latest documentation.
If this redirect doesn't work, please [click here for the latest documentation](https://pycqa.github.io/isort/).
