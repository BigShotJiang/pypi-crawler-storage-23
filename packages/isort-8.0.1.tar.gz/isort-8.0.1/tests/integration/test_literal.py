"""Tests that need installation of other packages."""

# TODO: find a way to install example-isort-formatting-plugin to pass tests
# import isort.literal

# from isort.settings import Config


# def test_value_assignment_list():
#     assert isort.literal.assignment("x = ['b', 'a']", "list", "py") == "x = ['a', 'b']"
#     assert (
#         isort.literal.assignment("x = ['b', 'a']", "list", "py", Config(formatter="example"))
#         == 'x = ["a", "b"]'
#     )
