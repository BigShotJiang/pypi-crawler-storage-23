.. meta::
   :description: Advanced diwire usage: tuning auto-registration, compilation/performance, and concurrency considerations.

Advanced
========

.. toctree::
   :maxdepth: 1

   autoregister
   performance
   concurrency
