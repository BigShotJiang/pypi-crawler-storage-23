from __future__ import annotations

import unittest

from bridge import tunnel


class TunnelBackoffTests(unittest.TestCase):
    def test_auth_backoff_uses_attempt_and_grows(self) -> None:
        first = tunnel._compute_reconnect_backoff(1, min_backoff=10.0)
        second = tunnel._compute_reconnect_backoff(2, min_backoff=10.0)
        third = tunnel._compute_reconnect_backoff(3, min_backoff=10.0)

        self.assertGreaterEqual(second, first)
        self.assertGreaterEqual(third, second)
        self.assertEqual(first, 10.0)

    def test_backoff_rejects_non_positive_attempt(self) -> None:
        with self.assertRaises(ValueError):
            tunnel._compute_reconnect_backoff(0)
