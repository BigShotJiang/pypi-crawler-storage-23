'''
Quarch Power Module Calibration Functions
Written for Python 3.6 64 bit

M Dearman April 2019
'''

'''
Calibration Flow
    Connect to PPM
    Connect to Keithley
    step through a set of values and get ADC vs Reference Value
    evaluate results vs defined limits

'''

#Imports QuarchPy library, providing the functions needed to use Quarch modules
#from quarchpy import quarchDevice #, scanDevices

## Import other libraries used in the examples
#from functools import reduce
import quarchpy
#import types
#from time import sleep,time
#from math import ceil
from quarchCalibration import *
#import threading
#from calibrationConfig import*
#from quarchpy.user_interface import *
#from quarchpy.user_interface import logSimpleResult,storeResult
#from quarchpy.device.device import *
#from quarchpy.device.scanDevices import userSelectDevice
#import datetime
#from keithley_2460_control import *
#from quarchpy.utilities.BitManipulation import *

def parseFixtureData(response,start,length):

    # split the multiline response into a list
    response = response.splitlines()
    result = ""
    # for each line
    for line in response:
        # remove 0x, swap bytes
        line = line[4:6] + line[2:4]
        # convert 4 char Hex to 16 bit binary string
        line = "{0:016b}".format(int(line,16))
        # concatenate all the strings
        result += line
    # pick out the section we want
    result = int(result[start:(start+length)],2)
    # convert two's compliment
    if (result >= 2**(length-1)):
        result -= 2**length
    return result


def getFixtureData(device,channel):
    #hold measurement
    response = device.sendCommand("read 0x0000")
    device.sendCommand("write 0x0000 " + setBit(response,3))
    #read measurement
    data = device.sendCommand("read 0x1000 to 0x1007")
    #release measurement
    response = device.sendCommand("read 0x0000")
    device.sendCommand("write 0x0000 " + clearBit(response,3))

    if (channel == "POWER_1 V"):
        return parseFixtureData(data,0,16)
    elif (channel == "POWER_1 A"):
        return parseFixtureData(data,16,25)
    elif (channel == "POWER_2 V"):
        return parseFixtureData(data,41,16)
    elif (channel == "POWER_2 A"):
        return parseFixtureData(data,57,25)

def bcdString(bcd,padding):
    # strip off "0x" if present
    if bcd[:2] == "0x":
        bcd = bcd [2:]
    # strip off leading 0's
    # loop while we have more the required minimum number of characters left
    while(len(bcd)>padding):
        # if the leading character is 0, remove it
        if bcd[0] == '0':
            bcd = bcd[1:]
        # else exit loop
        else:
            break
    return bcd


    class PAMVoltageCalibration (QTL2621Calibration,channelName,mulitiplierAddr,offsetAddr):

        def __init__(self,powerModule):

            self.title = channelName + " Voltage Calibration"
            self.powerModule = powerModule
            self.absErrorLimit = 2                  # 2mV
            self.relErrorLimit = 1                  # 1%
            self.test_min = 40                      # 40mV
            self.test_max = 14400                   # 14.4V
            self.test_steps = 20
            self.units = "mV"
            self.scaling = 4
            self.multiplier_signed = False
            self.multiplier_int_width = 1
            self.multiplier_frac_width = 16
            self.offset_signed = True
            self.offset_int_width = 10
            self.offset_frac_width = 6

        def init(self):

            super().init_cal("POWER_1")

            # clear the multiplier and offset registers by setting them to zero
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_MULTIPLIER_ADDR + " 0x0000")
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_OFFSET_ADDR + " 0x0000")

            self.powerModule.setConnections("POWER_1",None)

            # Check Host Power is present
            #while (super().checkLoadVoltage(500,500) != True):
            #    self.powerModule.setConnections("POWER_1",None,reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceVoltage(value/1000,currentLimit="1e-1")

        def readRef(self):

            return self.powerModule.calInstrument.measureLoadVoltage()*1000

        def readVal(self):

            return super().meas_POWER_1_volt()

        def setCoefficients(self):

            result1 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_MULTIPLIER_ADDR + " " + self.multiplier.hexString(4))
            result2 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_OFFSET_ADDR + " " + self.offset.hexString(4))
            if result1 and result2:
                result = True
            else:
                result = False
            logSimpleResult("Set POWER_1 voltage", result)

        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("calibrate",data)

        def readCoefficients(self):

            coefficients = {}
            # get POWER_1 voltage multiplier
            coefficients["multiplier"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_VOLT_MULTIPLIER_ADDR)
            # get POWER_1 voltage offset
            coefficients["offset"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_VOLT_OFFSET_ADDR)
            return coefficients

        def writeCoefficients(self,coefficients):

            # write POWER_1 voltage multiplier
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_MULTIPLIER_ADDR + " " + coefficients["multiplier"])
            # write POWER_1 voltage offset
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_VOLT_OFFSET_ADDR + " " + coefficients["offset"])

    class QTL2621_POWER_1_LowCurrentCalibration (QTL2621Calibration):

        def __init__(self,powerModule):

            self.title = "POWER_1 Low Current Calibration"
            self.powerModule = powerModule
            self.absErrorLimit = 10                 # 10uA
            self.relErrorLimit = 1                  # 1%
            self.test_min = 10                      # 10uA
            self.test_max = 85000                   # 85mA
            self.test_steps = 20
            self.units = "uA"
            self.scaling = 32
            self.multiplier_signed = False
            self.multiplier_int_width = 1
            self.multiplier_frac_width = 16
            self.offset_signed = True
            self.offset_int_width = 10
            self.offset_frac_width = 6

        def init(self):

            super().init_cal("POWER_1")

            #set manual range, full averaging, POWER_1 low current mode, POWER_2 all off (so we can detect we're connected to the wrong channel
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.CALIBRATION_CONTROL_ADDR + " 0x00F1")
            # clear the multiplier and offset registers by setting them to zero
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_MULTIPLIER_ADDR + " 0x0000")
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_OFFSET_ADDR + " 0x0000")

            self.powerModule.setConnections("POWER_1","POWER_1")

            # Check Host Power is present
            while (super().checkLoadVoltage(QTL2621.HOST_VOLTAGE,1000) != True):
                self.powerModule.setConnections("POWER_1","POWER_1",reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceCurrent(value/1000000)

        def readRef(self):

            # read device voltage and add leakage current to the reference
            voltage =  super().meas_POWER_1_volt()
            return self.powerModule.calInstrument.measureLoadCurrent()*1000000

        def readVal(self):

            return super().meas_POWER_1_cur()

        def setCoefficients(self):

            result1 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_MULTIPLIER_ADDR + " " + self.multiplier.hexString(4))
            result2 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_OFFSET_ADDR + " " + self.offset.hexString(4))
            if result1 and result2:
                result = True
            else:
                result = False
            logSimpleResult("Set POWER_1 low current", result)
        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("calibrate",data)

        def readCoefficients(self):

            coefficients = {}
            # get POWER_1 low current multiplier
            coefficients["multiplier"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_LOW_MULTIPLIER_ADDR)
            # get POWER_1 low current offset
            coefficients["offset"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_LOW_OFFSET_ADDR)
            return coefficients

        def writeCoefficients(self,coefficients):

            # write POWER_1 low current multiplier
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_MULTIPLIER_ADDR + " " + coefficients["multiplier"])
            # write POWER_1 low current offset
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LOW_OFFSET_ADDR + " " + coefficients["offset"])

    class QTL2621_POWER_1_HighCurrentCalibration (QTL2621Calibration):

        def __init__(self,powerModule):

            self.title = "POWER_1 High Current Calibration"
            self.powerModule = powerModule
            self.absErrorLimit = 2000               # 2mA
            self.relErrorLimit = 1                  # 1%
            self.test_min = 1000                    # 1mA
            self.test_max = 4000000                 # 4A
            self.test_steps = 20
            self.units = "uA"
            self.scaling = 2048
            self.multiplier_signed = False
            self.multiplier_int_width = 1
            self.multiplier_frac_width = 16
            self.offset_signed = True
            self.offset_int_width = 10
            self.offset_frac_width = 6

        def init(self):

            super().init_cal("POWER_1")

            #set manual range, full averaging, POWER_1 high current mode, POWER_2 all off (so we can detect we're connected to the wrong channel
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.CALIBRATION_CONTROL_ADDR + " 0x00F2")
            # clear the multiplier and offset registers by setting them to zero
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_MULTIPLIER_ADDR + " 0x0000")
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_OFFSET_ADDR + " 0x0000")

            self.powerModule.setConnections("POWER_1","POWER_1")

            # Check Host Power is present
            while (super().checkLoadVoltage(QTL2621.HOST_VOLTAGE,1000) != True):
                self.powerModule.setConnections("POWER_1","POWER_1",reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceCurrent(value/1000000)

        def readRef(self):

            # read device voltage and add leakage current to the reference
            voltage =  super().meas_POWER_1_volt()
            #leakage = voltage*self.powerModule.calibrations["POWER_1"]["Leakage"].multiplier.originalValue() + self.powerModule.calibrations["POWER_1"]["Leakage"].offset.originalValue()
            return self.powerModule.calInstrument.measureLoadCurrent()*1000000# + leakage

        def readVal(self):

            return super().meas_POWER_1_cur()

        def setCoefficients(self):

            result1 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_MULTIPLIER_ADDR + " " + self.multiplier.hexString(4))
            result2 = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_OFFSET_ADDR + " " + self.offset.hexString(4))
            if result1 and result2:
                result = True
            else:
                result = False
            logSimpleResult("Set POWER_1 high current", result)

            # once we've completed low and high current we can set leakage on the fixture
            #result = self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_LEAKAGE_MULTIPLIER_ADDR + " " + self.powerModule.calibrations["POWER_1"]["Leakage"].multiplier.hexString(4))

        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("calibrate",data)

        def readCoefficients(self):

            coefficients = {}
            # get POWER_1 high current multiplier
            coefficients["multiplier"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_HIGH_MULTIPLIER_ADDR)
            # get POWER_1 high current offset
            coefficients["offset"] = self.powerModule.dut.sendCommand("read " + QTL2621.POWER_1_HIGH_OFFSET_ADDR)
            return coefficients

        def writeCoefficients(self,coefficients):

            # write POWER_1 high current multiplier
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_MULTIPLIER_ADDR + " " + coefficients["multiplier"])
            # write POWER_1 high current offset
            self.powerModule.dut.sendAndVerifyCommand("write " + QTL2621.POWER_1_HIGH_OFFSET_ADDR + " " + coefficients["offset"])

    class QTL2621_POWER_2_VoltageVerification (QTL2621Calibration):

        def __init__(self,powerModule):

            self.title = "POWER_2 Voltage Verification"
            self.powerModule = powerModule
            self.absErrorLimit = 2      # 2mV
            self.relErrorLimit = 1      # 1%
            self.test_min = 40          # 40mV
            self.test_max = 14400       # 14.4V
            self.test_steps = 20
            self.units = "mV"

        def init(self):

            super().init_cal("POWER_2")

            self.powerModule.setConnections("POWER_2",None)

            # Check Host Power is present
            #while (super().checkLoadVoltage(500,500) != True):
                #self.powerModule.setConnections("POWER_2",None,reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceVoltage(value/1000,currentLimit="1e-1")

        def readRef(self):

            return self.powerModule.calInstrument.measureLoadVoltage()*1000

        def readVal(self):

            return super().meas_POWER_2_volt()

        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("verify",data)

    class QTL2621_POWER_2_LowCurrentVerification (QTL2621Calibration):

        def __init__(self,powerModule):

            self.title = "POWER_2 Low Current Verification"
            self.powerModule = powerModule
            self.absErrorLimit = 10     # 10uA
            self.relErrorLimit = 1      # 1% tolerance
            self.test_min = 100         # 100uA
            self.test_max = 1000        # 1mA
            self.test_steps = 20
            self.units = "uA"

        def init(self):

            super().init_cal("POWER_2")

            self.powerModule.setConnections("POWER_2","POWER_2")

            # Check Host Power is present
            while (super().checkLoadVoltage(QTL2621.HOST_VOLTAGE,1000) != True):
                self.powerModule.setConnections("POWER_2","POWER_2",reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceCurrent(value/1000000)

        def readRef(self):

            return self.powerModule.calInstrument.measureLoadCurrent()*1000000

        def readVal(self):

            return super().meas_POWER_2_cur()

        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("verify",data)

    class QTL2621_POWER_2_HighCurrentVerification (QTL2621Calibration):

        def __init__(self,powerModule):

            self.title = "POWER_2 High Current Verification"
            self.powerModule = powerModule
            self.absErrorLimit = 2000       # 2mA
            self.relErrorLimit = 1          # 1% tolerance
            self.test_min = 1000            # 1mA
            self.test_max = 4000000         # 4A
            self.test_steps = 20
            self.units = "uA"

        def init(self):

            super().init_cal("POWER_2")

            self.powerModule.setConnections("POWER_2","POWER_2")

            # Check Host Power is present
            while (super().checkLoadVoltage(QTL2621.HOST_VOLTAGE,1000) != True):
                self.powerModule.setConnections("POWER_2","POWER_2",reset=True)

        def setRef(self,value):

            self.powerModule.calInstrument.setReferenceCurrent(value/1000000)

        def readRef(self):

            return self.powerModule.calInstrument.measureLoadCurrent()*1000000

        def readVal(self):

            return super().meas_POWER_2_cur()

        def finish(self):

            super().finish_cal()

        def report(self,data):

            return super().report("verify",data)

    def __init__(self,dut):

        # set the name of this module
        self.name = "PCIe x16 Power Measurement Fixture"
        self.dut = dut
        
        # Serial numbers (ensure QTL at start)
        self.enclosureSerial = self.dut.sendCommand("*ENCLOSURE?")
        if (self.enclosureSerial.find ("QTL") == -1):
            self.enclosureSerial = "QTL" + self.enclosureSerial
        # fetch the enclosure position
        self.enclosurePosition = self.dut.sendCommand("*POSITION?")
        self.PAMSerial = self.dut.sendCommand ("*SERIAL?")
        if (self.PAMSerial.find ("QTL") == -1):
            self.PAMSerial = "QTL" + self.PAMSerial
        # Fixture Serial
        # fixture serial is retrieved as BCD, we need to convert and pad it
        self.FixtureSerial = "QTL" + bcdString(dut.sendCommand("read 0xA102"),4) + "-" + bcdString(dut.sendCommand("read 0xA103"),2) + "-" + bcdString(dut.sendCommand("read 0xA104"),3) # TODO: this should be replaced with fix:serial? command when implemented
        # calObjectSerial Serial
        self.calObjectSerial = self.FixtureSerial
        # Filename String
        self.filenameString = self.FixtureSerial
        # Code version (FPGA)
        self.idnStr = dut.sendCommand ("*IDN?")
        pos = self.idnStr.upper().find ("FPGA 1:")
        if (pos != -1):
            versionStr = self.idnStr[pos+7:]
            pos = versionStr.find ("\n")
            if (pos != -1):
                versionStr = versionStr[:pos].strip()
            else:
                pass
        else:
            versionStr = "NOT-FOUND"    
        self.Fpga = versionStr.strip()
    
        # Code version (FW)    
        pos = self.idnStr.upper().find ("PROCESSOR:")
        if (pos != -1):
            versionStr = self.idnStr[pos+10:]
            pos = versionStr.find ("\n")
            if (pos != -1):
                versionStr = versionStr[:pos].strip()            
            else:
                pass
        else:
            versionStr = "NOT-FOUND"    
        self.Firmware = versionStr.strip()

        self.calibrations = {}
        # populate POWER_1 channel with calibrations
        self.calibrations["POWER_1"] = {
            "Voltage":self.QTL2621_POWER_1_VoltageCalibration(self),
            #"Leakage":self.QTL2621_POWER_1_LeakageCalibration(self),
            "Low Current":self.QTL2621_POWER_1_LowCurrentCalibration(self),
            "High Current":self.QTL2621_POWER_1_HighCurrentCalibration(self)
            }
        # populate POWER_2 channel with calibrations
        self.calibrations["POWER_2"] = {
            "Voltage":self.QTL2621_POWER_2_VoltageCalibration(self),
            #"Leakage":self.QTL2621_POWER_2_LeakageCalibration(self),
            "Low Current":self.QTL2621_POWER_2_LowCurrentCalibration(self),
            "High Current":self.QTL2621_POWER_2_HighCurrentCalibration(self)
            }

        self.verifications = {}
        # populate POWER_1 channel with verifications
        self.verifications["POWER_1"] = {
            "Voltage":self.QTL2621_POWER_1_VoltageVerification(self),
            "Low Current":self.QTL2621_POWER_1_LowCurrentVerification(self),
            "High Current":self.QTL2621_POWER_1_HighCurrentVerification(self)
            }
        # populate POWER_2 channel with verifications
        self.verifications["POWER_2"] = {
            "Voltage":self.QTL2621_POWER_2_VoltageVerification(self),
            "Low Current":self.QTL2621_POWER_2_LowCurrentVerification(self),
            "High Current":self.QTL2621_POWER_2_HighCurrentVerification(self)
            }

if __name__== "__main__":
    main()

