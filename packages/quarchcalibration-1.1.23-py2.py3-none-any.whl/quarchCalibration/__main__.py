import sys
from quarchCalibration.calibrationUtil import main
main(sys.argv[1:])