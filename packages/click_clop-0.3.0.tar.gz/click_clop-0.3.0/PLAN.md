# click-clop Implementation Plan

## Architecture

click-clop is **both** a library and a scaffold generator:

1. **`click-clop` library** — pip-installable framework providing the service-layer pattern,
   decorators, and utilities for building CLI+MCP+REST apps
2. **`click-clop new <name>` CLI** — scaffolds a new project that depends on click-clop

### Service Layer Pattern

```
┌─────────┐  ┌──────────┐  ┌──────────────┐
│ Click   │  │ FastMCP  │  │ FastAPI/REST │
│ CLI     │  │ Server   │  │ Endpoints    │
└────┬────┘  └────┬─────┘  └──────┬───────┘
     │            │               │
     └────────────┼───────────────┘
                  │
          ┌───────▼───────┐
          │ Service Layer  │  ← Core business logic lives here
          │ (plain funcs)  │
          └───────┬───────┘
                  │
          ┌───────▼───────┐
          │   Config /     │
          │   Telemetry /  │
          │   Secrets      │
          └───────────────┘
```

## Directory Structure (click-clop itself)

```
click-clop/
├── src/
│   └── click_clop/
│       ├── __init__.py              # Public API exports
│       ├── __main__.py              # python -m click_clop
│       ├── cli.py                   # click-clop CLI (new, version, etc.)
│       ├── scaffold.py              # Project generation logic
│       ├── service.py               # ServiceBase class & registration
│       ├── expose.py                # Thin wrapper generators (cli/mcp/rest)
│       ├── config.py                # TOML config loading
│       ├── secrets.py               # 1Password integration (read, create, update items)
│       ├── system_detect.py         # Detect system capabilities (docker/podman, etc.)
│       ├── telemetry.py             # OpenTelemetry + Alloy setup
│       ├── logging.py               # Structured logging
│       └── template/                # Copier template (the scaffold)
│           ├── copier.yml           # Copier config + wizard questions
│           ├── {{project_name}}/
│           │   ├── src/
│           │   │   └── {{module_name}}/
│           │   │       ├── __init__.py.jinja
│           │   │       ├── __main__.py.jinja
│           │   │       ├── cli.py.jinja
│           │   │       ├── server.py.jinja        # MCP + REST server
│           │   │       ├── services/
│           │   │       │   ├── __init__.py.jinja
│           │   │       │   └── hello.py.jinja      # Example service
│           │   │       ├── config.py.jinja
│           │   │       └── secrets.py.jinja        # 1Password item CRUD helpers
│           │   ├── tests/
│           │   │   ├── conftest.py.jinja
│           │   │   └── unit/
│           │   │       └── test_hello.py.jinja
│           │   ├── features/
│           │   │   ├── steps/
│           │   │   │   └── hello_steps.py.jinja
│           │   │   └── hello.feature.jinja
│           │   ├── docs/
│           │   │   ├── conf.py.jinja
│           │   │   ├── index.rst.jinja
│           │   │   └── Makefile.jinja
│           │   ├── helm/
│           │   │   └── {{project_name}}/
│           │   │       ├── Chart.yaml.jinja
│           │   │       ├── values.yaml.jinja
│           │   │       └── templates/
│           │   │           ├── deployment.yaml.jinja
│           │   │           ├── service.yaml.jinja
│           │   │           ├── configmap.yaml.jinja
│           │   │           ├── onepassworditem.yaml.jinja  # 1Password CRD
│           │   │           └── NOTES.txt.jinja
│           │   ├── .git-hooks/
│           │   │   ├── pre-commit
│           │   │   └── commit-msg
│           │   ├── .git-templates/
│           │   │   └── commit-message.txt
│           │   ├── alloy/
│           │   │   └── config.alloy.jinja
│           │   ├── CLAUDE.md.jinja
│           │   ├── .claude/
│           │   │   └── settings.json.jinja
│           │   ├── Makefile.jinja
│           │   ├── Dockerfile.jinja
│           │   ├── pyproject.toml.jinja
│           │   ├── config.toml.jinja
│           │   ├── config.dev.toml.jinja
│           │   ├── .gitignore.jinja
│           │   ├── .python-version.jinja
│           │   └── README.md.jinja
├── tests/
│   ├── conftest.py
│   └── unit/
│       ├── test_service.py
│       ├── test_config.py
│       └── test_scaffold.py
├── features/
│   ├── steps/
│   │   └── scaffold_steps.py
│   └── scaffold.feature
├── docs/
│   └── conf.py
├── CLAUDE.md
├── Makefile
├── Dockerfile
├── pyproject.toml
├── .gitignore
└── .python-version
```

## Implementation Steps

### Phase 1: Core Library
1. Set up src/ layout, pyproject.toml with all dependencies
2. Implement `ServiceBase` — register plain functions, autodiscover services
3. Implement `expose.py` — generate Click commands, FastMCP tools, FastAPI routes from services
4. Implement `config.py` — TOML config loading with env overlay
5. Implement `secrets.py` — 1Password integration (read, create, update, delete items via `op` CLI)
6. Implement `telemetry.py` — OpenTelemetry SDK + OTLP export (Alloy-compatible)
7. Implement `logging.py` — structlog with JSON output
8. Implement `system_detect.py` — auto-detect system capabilities:
   - Container runtime: `docker` vs `podman` (check which is available, prefer podman)
   - Helm availability and version
   - 1Password CLI (`op`) availability
   - Python version, uv version
   - Git version and config
   - Available shell (bash/zsh)
   - OS/platform info

### Phase 2: Scaffold Generator
9. Create copier template with minimal wizard (name, description, author)
   - Wizard auto-detects and pre-fills: container runtime, python version, author from git config
   - User confirms or overrides detected values
10. Implement `click-clop new` CLI command (wraps copier + system detection)
11. Template: Makefile with uv/docker/helm proxies
    - Uses detected container runtime (`docker` or `podman`) as variable
12. Template: Dockerfile (multi-stage, uv-based)
13. Template: Helm chart
    - Includes `OnePasswordItem` CRD resources for secret injection
    - Chart.yaml declares 1password-connect dependency
    - values.yaml has `onepassword.vault` and `onepassword.items[]` config
14. Template: git hooks (pre-commit: lint+test, commit-msg: conventional commits)
15. Template: git commit message template
16. Template: CLAUDE.md + .claude/settings.json with agent rules
17. Template: Sphinx docs with autodoc
18. Template: Grafana Alloy config
    - OTLP receiver for traces/metrics/logs from the app
    - Prometheus remote-write export
    - Loki log export
    - Tempo trace export
    - Configurable endpoints via config.toml
19. Template: Gherkin feature file + behave steps
20. Template: Swagger UI via FastAPI
21. Template: config.toml + config.dev.toml
22. Template: pyproject.toml with all tasks
23. Template: .gitignore, .python-version, README.md
24. Template: secrets.py — helper module for 1Password item CRUD in generated projects
    - `create_secret(vault, title, fields)` — create a new 1Password item
    - `get_secret(vault, title)` — read an item
    - `update_secret(vault, title, fields)` — update fields
    - `ensure_secret(vault, title, fields)` — idempotent create-or-update
    - Exposed as CLI commands, MCP tools, and REST endpoints via the service layer

### Phase 3: Self-hosting
25. click-clop's own Makefile, Dockerfile, CLAUDE.md, tests
26. Verify `click-clop new testapp` generates a working project
