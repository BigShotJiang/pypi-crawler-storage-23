"""TOML configuration loading with environment variable overlay."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import tomllib


_DEFAULT_CONFIG_FILES = ["config.toml", "config.dev.toml", "config.local.toml"]


def load_config(
    config_path: str | Path | None = None,
    env_prefix: str = "APP_",
) -> dict[str, Any]:
    """Load configuration from TOML files with environment variable overrides.

    Loading order (later values win):
    1. config.toml (base/defaults)
    2. config.dev.toml (development overrides)
    3. config.local.toml (local/gitignored overrides)
    4. Explicit config_path if provided
    5. Environment variables prefixed with env_prefix

    Environment variables map to nested keys via double underscore:
        APP_SERVER__HOST=0.0.0.0  ->  config["server"]["host"] = "0.0.0.0"
    """
    merged: dict[str, Any] = {}

    for name in _DEFAULT_CONFIG_FILES:
        path = Path(name)
        if path.exists():
            merged = _deep_merge(merged, _load_toml(path))

    if config_path:
        path = Path(config_path)
        if path.exists():
            merged = _deep_merge(merged, _load_toml(path))

    merged = _apply_env_overrides(merged, env_prefix)

    return merged


def _load_toml(path: Path) -> dict[str, Any]:
    with open(path, "rb") as f:
        return tomllib.load(f)


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge override into base."""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _apply_env_overrides(config: dict[str, Any], prefix: str) -> dict[str, Any]:
    """Apply environment variables as overrides.

    APP_SERVER__HOST=x  ->  config["server"]["host"] = "x"
    """
    result = dict(config)

    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue

        parts = key[len(prefix):].lower().split("__")
        _set_nested(result, parts, value)

    return result


def _set_nested(d: dict[str, Any], keys: list[str], value: str) -> None:
    """Set a nested dict value from a list of keys."""
    for key in keys[:-1]:
        d = d.setdefault(key, {})
    d[keys[-1]] = value
