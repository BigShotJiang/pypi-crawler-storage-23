"""Auto-detect system capabilities for the scaffold wizard.

Probes the local environment to find available tools, their versions,
and sensible defaults for project generation.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field


@dataclass
class SystemInfo:
    """Detected system capabilities."""

    # Container runtime
    container_runtime: str = ""  # "docker", "podman", or ""
    container_runtime_version: str = ""

    # Orchestration
    helm_available: bool = False
    helm_version: str = ""

    # Secrets
    op_available: bool = False
    op_version: str = ""

    # Python tooling
    python_version: str = ""
    uv_version: str = ""

    # Git
    git_version: str = ""
    git_user_name: str = ""
    git_user_email: str = ""

    # Platform
    os_name: str = ""
    arch: str = ""
    shell: str = ""

    def summary(self) -> dict[str, str]:
        """Return a flat summary dict suitable for display."""
        return {
            "Container runtime": f"{self.container_runtime} {self.container_runtime_version}" if self.container_runtime else "not found",
            "Helm": self.helm_version if self.helm_available else "not found",
            "1Password CLI": self.op_version if self.op_available else "not found",
            "Python": self.python_version,
            "uv": self.uv_version or "not found",
            "Git": self.git_version,
            "Git user": f"{self.git_user_name} <{self.git_user_email}>",
            "OS": f"{self.os_name} {self.arch}",
            "Shell": self.shell,
        }


def _get_version(cmd: list[str]) -> str:
    """Run a command and return its stdout, stripped. Empty string on failure."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=5)
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return ""


def _git_config(key: str) -> str:
    return _get_version(["git", "config", "--global", key])


def detect_system() -> SystemInfo:
    """Probe the local system and return detected capabilities."""
    info = SystemInfo()

    # Container runtime — prefer podman
    if shutil.which("podman"):
        info.container_runtime = "podman"
        info.container_runtime_version = _get_version(["podman", "--version"])
    elif shutil.which("docker"):
        info.container_runtime = "docker"
        info.container_runtime_version = _get_version(["docker", "--version"])

    # Helm
    if shutil.which("helm"):
        info.helm_available = True
        info.helm_version = _get_version(["helm", "version", "--short"])

    # 1Password CLI
    if shutil.which("op"):
        info.op_available = True
        info.op_version = _get_version(["op", "--version"])

    # Python
    info.python_version = platform.python_version()

    # uv
    info.uv_version = _get_version(["uv", "--version"])

    # Git
    info.git_version = _get_version(["git", "--version"])
    info.git_user_name = _git_config("user.name")
    info.git_user_email = _git_config("user.email")

    # Platform
    info.os_name = platform.system()
    info.arch = platform.machine()
    info.shell = os.environ.get("SHELL", "")

    return info
