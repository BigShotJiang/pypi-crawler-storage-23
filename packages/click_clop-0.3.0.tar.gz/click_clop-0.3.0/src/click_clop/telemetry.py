"""OpenTelemetry setup for traces, metrics, and logs — exports to Grafana Alloy via OTLP."""

from __future__ import annotations

from typing import Any

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter


_tracer_provider: TracerProvider | None = None


def setup_telemetry(
    service_name: str,
    otlp_endpoint: str = "http://localhost:4317",
    extra_resource: dict[str, Any] | None = None,
) -> TracerProvider:
    """Initialize OpenTelemetry with OTLP export.

    Args:
        service_name: The service name for resource identification.
        otlp_endpoint: OTLP gRPC endpoint (default: localhost:4317 for Alloy).
        extra_resource: Additional resource attributes.

    Returns:
        The configured TracerProvider.
    """
    global _tracer_provider

    resource_attrs: dict[str, Any] = {"service.name": service_name}
    if extra_resource:
        resource_attrs.update(extra_resource)

    resource = Resource.create(resource_attrs)

    provider = TracerProvider(resource=resource)

    exporter = OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True)
    provider.add_span_processor(BatchSpanProcessor(exporter))

    trace.set_tracer_provider(provider)
    _tracer_provider = provider

    return provider


def get_tracer(name: str) -> trace.Tracer:
    """Get a tracer instance."""
    return trace.get_tracer(name)


def shutdown_telemetry() -> None:
    """Flush and shut down the tracer provider."""
    global _tracer_provider
    if _tracer_provider:
        _tracer_provider.shutdown()
        _tracer_provider = None
