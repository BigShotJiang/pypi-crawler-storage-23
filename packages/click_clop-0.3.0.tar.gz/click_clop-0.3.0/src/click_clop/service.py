"""Service layer pattern — the core of click-clop's architecture.

Services are plain classes whose public methods become the business logic.
The expose module wraps them as CLI commands, MCP tools, and REST endpoints.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class ServiceMethod:
    """Metadata about a registered service method."""

    name: str
    func: Callable[..., Any]
    description: str
    parameters: dict[str, inspect.Parameter]
    return_type: Any
    service_name: str


class ServiceRegistry:
    """Global registry of all services and their methods."""

    _instance: ServiceRegistry | None = None
    _services: dict[str, Service]

    def __init__(self) -> None:
        self._services = {}

    @classmethod
    def get(cls) -> ServiceRegistry:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the global registry (useful for testing)."""
        cls._instance = None

    def register(self, service: Service) -> None:
        self._services[service.name] = service

    def get_service(self, name: str) -> Service | None:
        return self._services.get(name)

    @property
    def services(self) -> dict[str, Service]:
        return dict(self._services)

    def all_methods(self) -> list[ServiceMethod]:
        """Return all methods across all registered services."""
        methods = []
        for service in self._services.values():
            methods.extend(service.methods())
        return methods


@dataclass
class Service:
    """Base class for services. Subclass and add public methods.

    Public methods (not starting with _) are automatically discovered
    and can be exposed as CLI commands, MCP tools, and REST endpoints.

    Example:
        class GreetService(Service):
            name = "greet"
            description = "Greeting service"

            def hello(self, name: str = "world") -> str:
                '''Say hello to someone.'''
                return f"Hello, {name}!"
    """

    name: str = ""
    description: str = ""
    _auto_register: bool = field(default=True, repr=False)

    def __post_init__(self) -> None:
        # Class-level attributes (e.g. `name = "calc"`) are overridden by
        # the dataclass __init__ default. Check the class dict to recover them.
        if not self.name:
            cls_name = type(self).__dict__.get("name", "")
            if cls_name:
                self.name = cls_name
            else:
                self.name = type(self).__name__.lower().removesuffix("service")
        if not self.description:
            cls_desc = type(self).__dict__.get("description", "")
            if cls_desc:
                self.description = cls_desc
            else:
                self.description = type(self).__doc__ or f"{self.name} service"
        if self._auto_register:
            ServiceRegistry.get().register(self)

    def methods(self) -> list[ServiceMethod]:
        """Discover all public methods on this service."""
        result = []
        for attr_name in dir(self):
            if attr_name.startswith("_"):
                continue
            attr = getattr(self, attr_name)
            if not callable(attr) or attr_name in ("methods",):
                continue
            sig = inspect.signature(attr)
            params = {
                k: v for k, v in sig.parameters.items() if k != "self"
            }
            result.append(
                ServiceMethod(
                    name=attr_name,
                    func=attr,
                    description=inspect.getdoc(attr) or f"{self.name}.{attr_name}",
                    parameters=params,
                    return_type=sig.return_annotation,
                    service_name=self.name,
                )
            )
        return result
