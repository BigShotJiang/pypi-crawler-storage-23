"""click-clop CLI — the main entry point for project scaffolding and management."""

from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table

from click_clop import __version__
from click_clop.system_detect import detect_system
from click_clop.scaffold import scaffold_project


console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="click-clop")
def main() -> None:
    """click-clop: Framework and scaffold for Python CLI applications."""


@main.command()
@click.argument("project_name")
@click.option("--description", "-d", default="", help="Project description.")
@click.option("--author", "-a", default="", help="Author name (auto-detected from git).")
@click.option("--output-dir", "-o", default=".", help="Parent directory for the new project.")
def new(project_name: str, description: str, author: str, output_dir: str) -> None:
    """Create a new click-clop project.

    Scaffolds a complete Python CLI project with MCP, REST, Helm, telemetry,
    and all the click-clop conventions.
    """
    console.print(f"\n[bold]click-clop[/bold] — creating project [cyan]{project_name}[/cyan]\n")

    # Detect system
    console.print("[dim]Detecting system capabilities...[/dim]")
    system_info = detect_system()

    # Show what was detected
    table = Table(title="Detected System", show_header=False, border_style="dim")
    for key, value in system_info.summary().items():
        table.add_row(f"[bold]{key}[/bold]", value)
    console.print(table)
    console.print()

    # Scaffold
    try:
        project_path = scaffold_project(
            project_name=project_name,
            output_dir=output_dir,
            description=description,
            author=author,
            system_info=system_info,
        )
        console.print(f"[green bold]Project created at:[/green bold] {project_path}\n")
        console.print("Next steps:")
        console.print(f"  cd {project_path}")
        console.print("  make install")
        console.print("  make test")
        console.print(f"  uv run {project_name} --help")
    except Exception as e:
        console.print(f"[red bold]Error:[/red bold] {e}")
        raise SystemExit(1)


@main.command()
def detect() -> None:
    """Show detected system capabilities."""
    system_info = detect_system()
    table = Table(title="System Capabilities", show_header=False, border_style="dim")
    for key, value in system_info.summary().items():
        table.add_row(f"[bold]{key}[/bold]", value)
    console.print(table)
