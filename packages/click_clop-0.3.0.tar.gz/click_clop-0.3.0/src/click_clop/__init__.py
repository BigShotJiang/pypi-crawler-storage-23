"""click-clop: A reusable framework and scaffold for Python CLI applications."""

from click_clop.service import Service, ServiceRegistry
from click_clop.config import load_config
from click_clop.expose import expose_cli, expose_mcp, expose_rest

__version__ = "0.1.0"

__all__ = [
    "Service",
    "ServiceRegistry",
    "load_config",
    "expose_cli",
    "expose_mcp",
    "expose_rest",
]
