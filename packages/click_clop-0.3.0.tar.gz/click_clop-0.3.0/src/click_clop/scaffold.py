"""Project scaffolding logic — wraps Copier to generate new projects."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from copier import run_copy

from click_clop.system_detect import SystemInfo, detect_system


TEMPLATE_DIR = Path(__file__).parent / "template"


def scaffold_project(
    project_name: str,
    output_dir: str | Path = ".",
    description: str = "",
    author: str = "",
    system_info: SystemInfo | None = None,
    extra_data: dict[str, Any] | None = None,
) -> Path:
    """Generate a new project from the click-clop template.

    Args:
        project_name: Name of the new project (used for directory and package).
        output_dir: Parent directory to create the project in.
        description: Project description.
        author: Author name (auto-detected from git config if empty).
        system_info: Pre-detected system info (auto-detected if None).
        extra_data: Additional template variables.

    Returns:
        Path to the created project directory.
    """
    if system_info is None:
        system_info = detect_system()

    if not author:
        author = system_info.git_user_name or "Unknown"

    module_name = project_name.replace("-", "_").replace(" ", "_").lower()

    data: dict[str, str] = {
        "project_name": project_name,
        "module_name": module_name,
        "description": description or f"{project_name} — a click-clop project",
        "author": author,
        "author_email": system_info.git_user_email or "",
        "python_version": system_info.python_version,
        "container_runtime": system_info.container_runtime or "docker",
        "container_runtime_version": system_info.container_runtime_version,
    }
    if extra_data:
        data.update({k: str(v) for k, v in extra_data.items()})

    dst_path = Path(output_dir) / project_name

    run_copy(
        str(TEMPLATE_DIR),
        dst_path,
        data=data,
        defaults=True,
        unsafe=True,
    )

    return dst_path
