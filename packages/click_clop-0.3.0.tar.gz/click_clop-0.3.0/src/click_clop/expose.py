"""Thin wrapper generators that expose service methods as CLI, MCP, and REST."""

from __future__ import annotations

import inspect
from typing import Any

import click
from fastapi import FastAPI, APIRouter

from click_clop.service import ServiceMethod, ServiceRegistry


# --- Type mapping for Click ---

_TYPE_MAP: dict[type | str, click.ParamType] = {
    str: click.STRING,
    int: click.INT,
    float: click.FLOAT,
    bool: click.BOOL,
    # String forms (from `from __future__ import annotations`)
    "str": click.STRING,
    "int": click.INT,
    "float": click.FLOAT,
    "bool": click.BOOL,
}


def _click_type(annotation: Any) -> click.ParamType:
    if annotation is inspect.Parameter.empty:
        return click.STRING
    return _TYPE_MAP.get(annotation, click.STRING)


# --- CLI exposure ---


def expose_cli(group: click.Group, registry: ServiceRegistry | None = None) -> click.Group:
    """Add all registered service methods as Click subcommands to the group.

    Creates a sub-group per service, with each method as a command under it.
    """
    reg = registry or ServiceRegistry.get()

    for svc_name, service in reg.services.items():
        svc_group = click.Group(name=svc_name, help=service.description)

        for method in service.methods():
            cmd = _make_click_command(method)
            svc_group.add_command(cmd)

        group.add_command(svc_group)

    return group


def _make_click_command(method: ServiceMethod) -> click.Command:
    """Build a Click command from a ServiceMethod."""
    params: list[click.Parameter] = []

    for param_name, param in method.parameters.items():
        has_default = param.default is not inspect.Parameter.empty
        option_name = f"--{param_name.replace('_', '-')}"

        if param.annotation is bool or param.default is False:
            params.append(
                click.Option(
                    [f"--{param_name.replace('_', '-')}/--no-{param_name.replace('_', '-')}"],
                    default=param.default if has_default else False,
                    help=f"{param_name} flag",
                )
            )
        elif has_default:
            params.append(
                click.Option(
                    [option_name],
                    default=param.default,
                    type=_click_type(param.annotation),
                    help=f"{param_name} (default: {param.default})",
                )
            )
        else:
            params.append(
                click.Option(
                    [option_name],
                    required=True,
                    type=_click_type(param.annotation),
                    help=param_name,
                )
            )

    def make_callback(m: ServiceMethod):
        def callback(**kwargs: Any) -> None:
            result = m.func(**kwargs)
            if result is not None:
                click.echo(result)
        return callback

    return click.Command(
        name=method.name,
        callback=make_callback(method),
        params=params,
        help=method.description,
    )


# --- MCP exposure ---


def expose_mcp(mcp_server: Any, registry: ServiceRegistry | None = None) -> Any:
    """Register all service methods as FastMCP tools.

    Args:
        mcp_server: A FastMCP server instance.
        registry: Optional ServiceRegistry (defaults to global).

    Returns:
        The mcp_server with tools registered.
    """
    reg = registry or ServiceRegistry.get()

    for method in reg.all_methods():
        tool_name = f"{method.service_name}_{method.name}"
        mcp_server.tool(name=tool_name, description=method.description)(method.func)

    return mcp_server


# --- REST exposure ---


def expose_rest(app: FastAPI | None = None, registry: ServiceRegistry | None = None) -> FastAPI:
    """Create FastAPI routes for all service methods.

    Creates POST /api/{service}/{method} for each method.
    """
    if app is None:
        app = FastAPI(title="click-clop API")

    reg = registry or ServiceRegistry.get()

    for svc_name, service in reg.services.items():
        router = APIRouter(prefix=f"/api/{svc_name}", tags=[svc_name])

        for method in service.methods():
            _add_rest_route(router, method)

        app.include_router(router)

    return app


def _add_rest_route(router: APIRouter, method: ServiceMethod) -> None:
    """Add a POST route for a service method."""

    def make_handler(m: ServiceMethod):
        async def handler(**kwargs: Any) -> dict[str, Any]:
            result = m.func(**kwargs)
            return {"result": result}
        # Preserve signature for FastAPI's dependency injection
        handler.__signature__ = inspect.Signature(  # type: ignore[attr-defined]
            parameters=[
                inspect.Parameter(
                    name=name,
                    kind=inspect.Parameter.KEYWORD_ONLY,
                    default=param.default,
                    annotation=param.annotation if param.annotation is not inspect.Parameter.empty else str,
                )
                for name, param in m.parameters.items()
            ]
        )
        handler.__name__ = f"{m.service_name}_{m.name}"
        handler.__doc__ = m.description
        return handler

    router.add_api_route(
        f"/{method.name}",
        make_handler(method),
        methods=["POST"],
        summary=method.description,
    )
