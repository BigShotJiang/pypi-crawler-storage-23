"""Allow running click-clop as `python -m click_clop`."""

from click_clop.cli import main

main()
