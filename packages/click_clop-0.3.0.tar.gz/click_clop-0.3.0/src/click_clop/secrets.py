"""1Password integration for secret management.

Wraps the `op` CLI to provide CRUD operations on 1Password items.
Used both by the framework itself and exposed as service methods
in generated projects.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from typing import Any


class OpCLIError(Exception):
    """Raised when the 1Password CLI fails."""

    def __init__(self, message: str, returncode: int = 1) -> None:
        super().__init__(message)
        self.returncode = returncode


@dataclass
class SecretField:
    """A field within a 1Password item."""

    label: str
    value: str
    type: str = "concealed"  # concealed, text, url, email, etc.


def _run_op(*args: str, input_data: str | None = None) -> str:
    """Run an `op` CLI command and return stdout."""
    cmd = ["op", *args, "--format", "json"]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            input=input_data,
            check=False,
        )
    except FileNotFoundError:
        raise OpCLIError(
            "1Password CLI (`op`) not found. Install it from https://1password.com/downloads/command-line/"
        )

    if result.returncode != 0:
        raise OpCLIError(result.stderr.strip(), result.returncode)

    return result.stdout


def check_op_available() -> bool:
    """Check if the 1Password CLI is installed and authenticated."""
    try:
        _run_op("whoami")
        return True
    except OpCLIError:
        return False


def get_secret(vault: str, title: str) -> dict[str, Any]:
    """Read a 1Password item by vault and title.

    Returns the full item as a dict.
    """
    output = _run_op("item", "get", title, "--vault", vault)
    return json.loads(output)


def get_secret_field(vault: str, title: str, field: str) -> str:
    """Read a single field value from a 1Password item."""
    ref = f"op://{vault}/{title}/{field}"
    result = subprocess.run(
        ["op", "read", ref],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise OpCLIError(result.stderr.strip(), result.returncode)
    return result.stdout.strip()


def create_secret(
    vault: str,
    title: str,
    fields: list[SecretField],
    category: str = "Secure Note",
) -> dict[str, Any]:
    """Create a new 1Password item.

    Args:
        vault: The vault to create the item in.
        title: The item title.
        fields: List of fields to set on the item.
        category: Item category (default: Secure Note).

    Returns:
        The created item as a dict.
    """
    field_args: list[str] = []
    for f in fields:
        field_args.extend([f"{f.label}[{f.type}]={f.value}"])

    cmd_args = [
        "item", "create",
        "--vault", vault,
        "--title", title,
        "--category", category,
    ]
    for fa in field_args:
        cmd_args.append(fa)

    output = _run_op(*cmd_args)
    return json.loads(output)


def update_secret(
    vault: str,
    title: str,
    fields: list[SecretField],
) -> dict[str, Any]:
    """Update fields on an existing 1Password item.

    Args:
        vault: The vault containing the item.
        title: The item title.
        fields: Fields to update.

    Returns:
        The updated item as a dict.
    """
    field_args: list[str] = []
    for f in fields:
        field_args.append(f"{f.label}[{f.type}]={f.value}")

    cmd_args = ["item", "edit", title, "--vault", vault]
    for fa in field_args:
        cmd_args.append(fa)

    output = _run_op(*cmd_args)
    return json.loads(output)


def delete_secret(vault: str, title: str) -> None:
    """Delete a 1Password item."""
    subprocess.run(
        ["op", "item", "delete", title, "--vault", vault],
        capture_output=True,
        text=True,
        check=False,
    )


def ensure_secret(
    vault: str,
    title: str,
    fields: list[SecretField],
    category: str = "Secure Note",
) -> dict[str, Any]:
    """Idempotent create-or-update for a 1Password item.

    If the item exists, updates it. Otherwise creates it.
    """
    try:
        get_secret(vault, title)
        return update_secret(vault, title, fields)
    except OpCLIError:
        return create_secret(vault, title, fields, category)
