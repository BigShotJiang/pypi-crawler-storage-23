# click-clop — Claude Code Guidelines

## Project Overview

click-clop is a **framework + scaffold** for Python CLI applications.
It's both a pip-installable library and a project generator (`click-clop new <name>`).

Every feature in a generated project is simultaneously a CLI command (Click),
MCP tool (FastMCP), and REST endpoint (FastAPI) via the service-layer pattern.

## Architecture

```
┌── click-clop (this project) ──────────────────┐
│                                                │
│  Library (pip install click-clop):             │
│    service.py   — Service base + registry      │
│    expose.py    — CLI/MCP/REST auto-wrappers   │
│    config.py    — TOML config loading          │
│    secrets.py   — 1Password CRUD               │
│    telemetry.py — OpenTelemetry + Alloy        │
│    logging.py   — structlog setup              │
│    system_detect.py — env detection            │
│                                                │
│  Scaffold (click-clop new):                    │
│    cli.py       — CLI entry point              │
│    scaffold.py  — Copier wrapper               │
│    template/    — Copier template files         │
└────────────────────────────────────────────────┘
```

## Directory Structure

```
src/click_clop/
├── __init__.py         # Public API
├── cli.py              # click-clop CLI (new, detect)
├── scaffold.py         # Project generation
├── service.py          # Service pattern
├── expose.py           # Auto-exposure wrappers
├── config.py           # TOML config
├── secrets.py          # 1Password
├── telemetry.py        # OpenTelemetry
├── logging.py          # structlog
├── system_detect.py    # System probing
└── template/           # Copier template (generated projects)
    ├── copier.yml
    ├── src/{{module_name}}/
    ├── tests/
    ├── features/
    ├── helm/
    ├── docs/
    ├── alloy/
    ├── Makefile.jinja
    ├── Dockerfile.jinja
    ├── CLAUDE.md.jinja
    └── ...
```

## Development

| Task | Command |
|------|---------|
| Install | `make install-dev` |
| Test | `make test` |
| Lint | `make lint` |
| Format | `make format` |
| Build | `make build` |

## Agent Rules

When implementing changes to click-clop itself:

1. **Use worktrees**: Use Claude Code's built-in `EnterWorktree` to work in isolation
2. **Leave changes unstaged** for review
3. **Service pattern**: core logic in service.py, thin wrappers in expose.py
4. **Template changes**: update both the template files AND the self-hosting equivalents
5. **Write tests**: `tests/unit/` for library code
6. **Conventional commits**: `feat:`, `fix:`, `docs:`, etc.
