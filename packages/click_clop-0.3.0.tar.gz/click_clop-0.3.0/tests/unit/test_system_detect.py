"""Tests for system detection."""

from __future__ import annotations

from click_clop.system_detect import detect_system, SystemInfo


class TestSystemDetect:
    def test_returns_system_info(self):
        info = detect_system()
        assert isinstance(info, SystemInfo)

    def test_python_version_detected(self):
        info = detect_system()
        assert info.python_version  # Should always be non-empty

    def test_os_detected(self):
        info = detect_system()
        assert info.os_name in ("Linux", "Darwin", "Windows")

    def test_summary(self):
        info = detect_system()
        summary = info.summary()
        assert "Python" in summary
        assert "OS" in summary
        assert "Container runtime" in summary

    def test_git_version_detected(self):
        info = detect_system()
        # Git should be available in dev environments
        assert info.git_version
