"""Tests for the click-clop CLI."""

from __future__ import annotations

from click.testing import CliRunner
from click_clop.cli import main


class TestCLI:
    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "click-clop" in result.output

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "new" in result.output
        assert "detect" in result.output

    def test_detect(self):
        runner = CliRunner()
        result = runner.invoke(main, ["detect"])
        assert result.exit_code == 0
        assert "Python" in result.output
