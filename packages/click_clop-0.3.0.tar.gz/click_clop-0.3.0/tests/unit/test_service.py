"""Tests for the service layer."""

from __future__ import annotations

import pytest
from click_clop.service import Service, ServiceRegistry


class TestServiceRegistry:
    def test_singleton(self):
        r1 = ServiceRegistry.get()
        r2 = ServiceRegistry.get()
        assert r1 is r2

    def test_reset(self):
        r1 = ServiceRegistry.get()
        ServiceRegistry.reset()
        r2 = ServiceRegistry.get()
        assert r1 is not r2

    def test_register_and_get(self):
        svc = Service(name="test", description="test service", _auto_register=False)
        reg = ServiceRegistry.get()
        reg.register(svc)
        assert reg.get_service("test") is svc

    def test_get_missing(self):
        reg = ServiceRegistry.get()
        assert reg.get_service("nonexistent") is None


class TestService:
    def test_auto_register(self):
        svc = Service(name="auto", description="auto service")
        assert ServiceRegistry.get().get_service("auto") is svc

    def test_name_from_class(self):
        class MyFeatureService(Service):
            pass

        svc = MyFeatureService()
        assert svc.name == "myfeature"

    def test_methods_discovery(self):
        class CalcService(Service):
            name = "calc"
            description = "Calculator"

            def add(self, a: int, b: int) -> int:
                """Add two numbers."""
                return a + b

            def _private(self):
                pass

        svc = CalcService()
        methods = svc.methods()
        names = [m.name for m in methods]
        assert "add" in names
        assert "_private" not in names

    def test_method_execution(self):
        class CalcService(Service):
            name = "calc"

            def add(self, a: int, b: int) -> int:
                """Add two numbers."""
                return a + b

        svc = CalcService()
        add_method = next(m for m in svc.methods() if m.name == "add")
        assert add_method.func(a=2, b=3) == 5

    def test_all_methods(self):
        class Svc1(Service):
            name = "svc1"

            def m1(self) -> str:
                return "1"

        class Svc2(Service):
            name = "svc2"

            def m2(self) -> str:
                return "2"

        Svc1()
        Svc2()
        all_methods = ServiceRegistry.get().all_methods()
        names = [m.name for m in all_methods]
        assert "m1" in names
        assert "m2" in names
