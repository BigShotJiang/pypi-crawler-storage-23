"""Tests for the expose module (CLI/MCP/REST wrapper generation)."""

from __future__ import annotations

import click
from click.testing import CliRunner
from fastapi.testclient import TestClient

from click_clop.service import Service, ServiceRegistry
from click_clop.expose import expose_cli, expose_rest


class _TestService(Service):
    """Test service for expose tests."""

    name = "calc"
    description = "Calculator service"

    def add(self, a: int = 0, b: int = 0) -> int:
        """Add two numbers."""
        return a + b

    def greet(self, name: str = "world") -> str:
        """Say hello."""
        return f"Hello, {name}!"


class TestExposeCLI:
    def test_creates_subgroup(self):
        _TestService()
        group = click.Group("test")
        expose_cli(group)
        assert "calc" in [c.name for c in group.commands.values()]

    def test_command_execution(self):
        _TestService()
        group = click.Group("test")
        expose_cli(group)
        runner = CliRunner()
        result = runner.invoke(group, ["calc", "add", "--a", "2", "--b", "3"])
        assert result.exit_code == 0
        assert "5" in result.output

    def test_string_command(self):
        _TestService()
        group = click.Group("test")
        expose_cli(group)
        runner = CliRunner()
        result = runner.invoke(group, ["calc", "greet", "--name", "Claude"])
        assert result.exit_code == 0
        assert "Hello, Claude!" in result.output


class TestExposeREST:
    def test_creates_routes(self):
        _TestService()
        app = expose_rest()
        routes = [r.path for r in app.routes]
        assert "/api/calc/add" in routes
        assert "/api/calc/greet" in routes

    def test_post_endpoint(self):
        _TestService()
        app = expose_rest()
        client = TestClient(app)
        resp = client.post("/api/calc/add", params={"a": 2, "b": 3})
        assert resp.status_code == 200
        assert resp.json()["result"] == 5
