"""Tests for config loading."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest
from click_clop.config import load_config, _deep_merge, _apply_env_overrides


class TestDeepMerge:
    def test_flat(self):
        assert _deep_merge({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}

    def test_override(self):
        assert _deep_merge({"a": 1}, {"a": 2}) == {"a": 2}

    def test_nested(self):
        base = {"server": {"host": "localhost", "port": 8000}}
        override = {"server": {"host": "0.0.0.0"}}
        result = _deep_merge(base, override)
        assert result == {"server": {"host": "0.0.0.0", "port": 8000}}


class TestEnvOverrides:
    def test_simple(self, monkeypatch):
        monkeypatch.setenv("APP_KEY", "value")
        result = _apply_env_overrides({}, "APP_")
        assert result == {"key": "value"}

    def test_nested(self, monkeypatch):
        monkeypatch.setenv("APP_SERVER__HOST", "0.0.0.0")
        result = _apply_env_overrides({}, "APP_")
        assert result == {"server": {"host": "0.0.0.0"}}


class TestLoadConfig:
    def test_load_toml_file(self, tmp_path, monkeypatch):
        config_file = tmp_path / "config.toml"
        config_file.write_text('[server]\nhost = "localhost"\nport = 8080\n')
        monkeypatch.chdir(tmp_path)
        result = load_config()
        assert result["server"]["host"] == "localhost"
        assert result["server"]["port"] == 8080

    def test_explicit_path(self, tmp_path):
        config_file = tmp_path / "custom.toml"
        config_file.write_text('[app]\nname = "test"\n')
        result = load_config(config_path=config_file)
        assert result["app"]["name"] == "test"
