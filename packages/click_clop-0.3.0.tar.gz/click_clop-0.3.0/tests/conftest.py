"""Shared test fixtures for click-clop."""

from __future__ import annotations

import pytest
from click_clop.service import ServiceRegistry


@pytest.fixture(autouse=True)
def _reset_registry():
    """Reset the service registry between tests."""
    ServiceRegistry.reset()
    yield
    ServiceRegistry.reset()
