import requests


def verify_project(config):
    try:
        r = requests.post(
            f"{config.base_url}/agent/verify",
            json={
                "project_id": config.project_id,
                "project_secret": config.secret,
            },
            timeout=5,
        )

        if r.status_code != 200:
            raise Exception("Invalid RADAR credentials")

    except Exception as e:
        raise Exception(f"RADAR verification failed: {e}")



def send_log(config, level, message):
    try:
        requests.post(
            f"{config.base_url}/logs/ingest",
            json={
                "project_id": config.project_id,
                "project_secret": config.secret,
                "service": config.service,
                "level": level,
                "message": message,
            },
            timeout=3,
        )
    except Exception:
        pass  # silent fail


def send_structure(config, files):
    try:
        requests.post(
            f"{config.base_url}/agent/structure",
            json={
                "project_id": config.project_id,
                "project_secret": config.secret,
                "files": files,
            },
            timeout=5,
        )
    except Exception:
        pass


def poll_for_file(config):
    try:
        r = requests.get(
            f"{config.base_url}/agent/poll",
            params={
                "project_id": config.project_id,
                "project_secret": config.secret,
            },
            timeout=5,
        )

        if r.status_code == 200:
            return r.json().get("file")

    except Exception:
        pass

    return None


def send_file_content(config, path, content):
    try:
        requests.post(
            f"{config.base_url}/agent/file-content",
            json={
                "project_id": config.project_id,
                "project_secret": config.secret,
                "path": path,
                "content": content,
            },
            timeout=5,
        )
    except Exception:
        pass