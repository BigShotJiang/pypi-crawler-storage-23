PYPROJECT_TOML = "pyproject.toml"
REQUIREMENTS_TXT = "requirements.txt"
MAIN_PY = "main.py"
VENV_DIR = ".venv"
