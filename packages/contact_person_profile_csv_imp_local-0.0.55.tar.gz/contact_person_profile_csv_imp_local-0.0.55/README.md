

# Facebook Export
https://directlync.com/resources/faq/can-i-export-contacts-from-facebook
https://sourcetable.com/export-csv/facebook-contacts

# sanity tests
contact-person-profile-csv-imp-local-python-package
uses
contact-user-external-local-python
uses
user-external-local-python
uses
UserExternaslLoal
TokenUserExternal