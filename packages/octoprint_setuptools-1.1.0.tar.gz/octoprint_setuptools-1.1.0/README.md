# OctoPrint-Setuptools

Setuptools helpers for installing OctoPrint & OctoPrint plugins. Provided as a separate package
to allow for easy reuse and as build dependency for OctoPrint plugins.
