from .servers import latex_mcp


def main() -> None:
    latex_mcp.run()


if __name__ == "__main__":
    main()
