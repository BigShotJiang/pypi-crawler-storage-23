"""OAuth helper functions for authentication."""

from typing import Optional

import httpx
from fastapi import HTTPException

from ...utils.env import (
  GITHUB_CLIENT_ID,
  GITHUB_CLIENT_SECRET,
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  MICROSOFT_CLIENT_ID,
  MICROSOFT_CLIENT_SECRET,
  MICROSOFT_TENANT_ID,
)
from ...utils.logger import get_logger

logger = get_logger(__name__)


class OAuthUserInfo:
  """Represents user information retrieved from OAuth provider."""

  def __init__(
    self,
    provider: str,
    provider_user_id: str,
    email: str,
    name: str,
    access_token: str,
    refresh_token: Optional[str] = None,
    avatar_url: Optional[str] = None,
  ):
    self.provider = provider
    self.provider_user_id = provider_user_id
    self.email = email
    self.name = name
    self.access_token = access_token
    self.refresh_token = refresh_token
    self.avatar_url = avatar_url


async def exchange_google_code(code: str, code_verifier: str, redirect_uri: Optional[str] = None) -> OAuthUserInfo:
  """Exchange Google authorization code for user info."""
  logger.warning(f"google client id: {GOOGLE_CLIENT_ID}")
  logger.warning(f"google client secret: {GOOGLE_CLIENT_SECRET}")
  if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
    raise HTTPException(status_code=500, detail="Google OAuth is not configured")

  GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
  GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"

  async with httpx.AsyncClient() as client:
    token_data = {
      "client_id": GOOGLE_CLIENT_ID,
      "client_secret": GOOGLE_CLIENT_SECRET,
      "code": code,
      "code_verifier": code_verifier,
      "redirect_uri": redirect_uri,
      "grant_type": "authorization_code",
    }

    request_context = "token"
    json_context = "token_payload"

    try:
      logger.warning("Exchanging Google authorization code for tokens")
      # Exchange code for tokens
      token_response = await client.post(GOOGLE_TOKEN_URL, data=token_data, timeout=10.0)
      logger.warning("Google OAuth token exchange response: %s", token_response.json())
      if token_response.status_code != 200:
        json_context = "token_error_payload"
        error_payload = token_response.json()
        detail = error_payload.get(
          "error_description", error_payload.get("error", "Invalid or expired authorization code")
        )
        logger.warning("Google OAuth token exchange failed with status %s: %s", token_response.status_code, detail)
        raise HTTPException(status_code=401, detail=detail)

      json_context = "token_payload"
      tokens = token_response.json()
      access_token = tokens.get("access_token")
      refresh_token = tokens.get("refresh_token")

      if not access_token:
        logger.error("Google OAuth token response missing access token")
        raise HTTPException(status_code=502, detail="Google OAuth token response missing access token")

      logger.info("Google OAuth token exchange succeeded")

      # Get user info
      headers = {"Authorization": f"Bearer {access_token}"}
      request_context = "userinfo"
      userinfo_response = await client.get(GOOGLE_USERINFO_URL, headers=headers, timeout=10.0)

      if userinfo_response.status_code != 200:
        logger.warning("Google user info request failed with status %s", userinfo_response.status_code)
        raise HTTPException(status_code=401, detail="Failed to retrieve user information from Google")

      json_context = "userinfo_payload"
      userinfo = userinfo_response.json()

      logger.info("Retrieved user info from Google for '%s'", userinfo.get("email"))

    except httpx.RequestError as exc:
      if request_context == "token":
        detail = "Unable to reach Google OAuth service"
      else:
        detail = "Unable to reach Google user info service"
      logger.exception("Network error while contacting Google OAuth %s endpoint", request_context)
      raise HTTPException(status_code=503, detail=detail) from exc
    except ValueError as exc:
      if json_context == "token_error_payload":
        status_code = 401
        detail = "Invalid or expired authorization code"
      elif json_context == "token_payload":
        status_code = 502
        detail = "Invalid response from Google OAuth token endpoint"
      elif json_context == "userinfo_payload":
        status_code = 502
        detail = "Invalid response from Google user info endpoint"
      else:
        status_code = 502
        detail = "Unexpected response from Google OAuth"
      logger.exception("Failed to parse JSON from Google OAuth response (%s)", json_context)
      raise HTTPException(status_code=status_code, detail=detail) from exc

    return OAuthUserInfo(
      provider="google",
      provider_user_id=userinfo.get("id"),
      email=userinfo.get("email"),
      name=userinfo.get("name", userinfo.get("email", "").split("@")[0]),
      access_token=access_token,
      refresh_token=refresh_token,
      avatar_url=userinfo.get("picture"),
    )


async def exchange_github_code(code: str, redirect_uri: Optional[str] = None) -> OAuthUserInfo:
  """Exchange GitHub authorization code for user info."""
  if not GITHUB_CLIENT_ID or not GITHUB_CLIENT_SECRET:
    raise HTTPException(status_code=500, detail="GitHub OAuth is not configured")

  token_url = "https://github.com/login/oauth/access_token"
  userinfo_url = "https://api.github.com/user"
  emails_url = "https://api.github.com/user/emails"

  async with httpx.AsyncClient() as client:
    # Exchange code for token
    token_data = {
      "client_id": GITHUB_CLIENT_ID,
      "client_secret": GITHUB_CLIENT_SECRET,
      "code": code,
    }
    if redirect_uri:
      token_data["redirect_uri"] = redirect_uri

    headers = {"Accept": "application/json"}
    token_response = await client.post(token_url, data=token_data, headers=headers)

    if token_response.status_code != 200:
      raise HTTPException(status_code=401, detail="Invalid or expired authorization code")

    tokens = token_response.json()
    if "error" in tokens:
      raise HTTPException(status_code=401, detail=tokens.get("error_description", "Invalid authorization code"))

    access_token = tokens.get("access_token")

    # Get user info
    auth_headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}
    userinfo_response = await client.get(userinfo_url, headers=auth_headers)

    if userinfo_response.status_code != 200:
      raise HTTPException(status_code=401, detail="Failed to retrieve user information from GitHub")

    userinfo = userinfo_response.json()

    # Get primary email if not public
    email = userinfo.get("email")
    if not email:
      emails_response = await client.get(emails_url, headers=auth_headers)
      if emails_response.status_code == 200:
        emails = emails_response.json()
        primary_email = next((e for e in emails if e.get("primary") and e.get("verified")), None)
        if primary_email:
          email = primary_email.get("email")

    if not email:
      raise HTTPException(status_code=400, detail="Unable to retrieve email from GitHub account")

    return OAuthUserInfo(
      provider="github",
      provider_user_id=str(userinfo.get("id")),
      email=email,
      name=userinfo.get("name") or userinfo.get("login", ""),
      access_token=access_token,
      refresh_token=None,
      avatar_url=userinfo.get("avatar_url"),
    )


async def exchange_microsoft_code(code: str, redirect_uri: Optional[str] = None) -> OAuthUserInfo:
  """Exchange Microsoft authorization code for user info."""
  if not MICROSOFT_CLIENT_ID or not MICROSOFT_CLIENT_SECRET:
    raise HTTPException(status_code=500, detail="Microsoft OAuth is not configured")

  token_url = f"https://login.microsoftonline.com/{MICROSOFT_TENANT_ID}/oauth2/v2.0/token"
  userinfo_url = "https://graph.microsoft.com/v1.0/me"

  async with httpx.AsyncClient() as client:
    # Exchange code for tokens
    token_data = {
      "client_id": MICROSOFT_CLIENT_ID,
      "client_secret": MICROSOFT_CLIENT_SECRET,
      "code": code,
      "grant_type": "authorization_code",
      "scope": "openid email profile User.Read",
    }
    if redirect_uri:
      token_data["redirect_uri"] = redirect_uri

    token_response = await client.post(
      token_url, data=token_data, headers={"Content-Type": "application/x-www-form-urlencoded"}
    )

    if token_response.status_code != 200:
      raise HTTPException(status_code=401, detail="Invalid or expired authorization code")

    tokens = token_response.json()
    access_token = tokens.get("access_token")
    refresh_token = tokens.get("refresh_token")

    # Get user info
    headers = {"Authorization": f"Bearer {access_token}"}
    userinfo_response = await client.get(userinfo_url, headers=headers)

    if userinfo_response.status_code != 200:
      raise HTTPException(status_code=401, detail="Failed to retrieve user information from Microsoft")

    userinfo = userinfo_response.json()

    email = userinfo.get("mail") or userinfo.get("userPrincipalName")
    if not email:
      raise HTTPException(status_code=400, detail="Unable to retrieve email from Microsoft account")

    return OAuthUserInfo(
      provider="microsoft",
      provider_user_id=userinfo.get("id"),
      email=email,
      name=userinfo.get("displayName", email.split("@")[0]),
      access_token=access_token,
      refresh_token=refresh_token,
      avatar_url=None,  # Microsoft Graph requires separate photo endpoint
    )


async def get_oauth_user_info(
  provider: str, code: str, code_verifier: str, redirect_uri: Optional[str] = None
) -> OAuthUserInfo:
  """Get user info from OAuth provider based on authorization code."""
  if provider == "google":
    return await exchange_google_code(code, code_verifier, redirect_uri)
  elif provider == "github":
    return await exchange_github_code(code, redirect_uri)
  elif provider == "microsoft":
    return await exchange_microsoft_code(code, redirect_uri)
  else:
    raise HTTPException(status_code=400, detail=f"Unsupported OAuth provider: {provider}")
