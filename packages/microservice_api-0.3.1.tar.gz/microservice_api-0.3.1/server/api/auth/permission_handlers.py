from typing import Optional

from fastapi import Depends, HTTPException, Query

from ...models.schema import Pagination
from ...models.auth import User
from ...models.auth.schemas import (
  PermissionType,
  Response,
  UserPermissionsCreate,
  UserPermissionsDelete,
  UserPermissionUpdate,
)
from ...service.auth import permission_service

from .helper import (
  build_permission_response,
  get_current_user,
)


async def list_user_permissions(
  user_id: int,
  page: int = Query(1, ge=1),
  limit: int = Query(20, ge=1, le=100),
  resourceId: Optional[int] = None,
  type: Optional[PermissionType] = None,
  current_user: User = Depends(get_current_user),
):
  """Retrieve all direct permissions for a specific user."""
  result = await permission_service.get_user_permissions_list(
    user_id=user_id,
    page=page,
    limit=limit,
    resource_id=resourceId,
    permission_type=type,
  )

  permission_responses = []
  for perm in result["permissions"]:
    resource = await perm.resource
    permission_responses.append(build_permission_response(perm, user_id, resource))

  pagination = Pagination()
  pagination.set(page=page, limit=limit, total=result["total"])

  return Response(
    data={
      "userId": user_id,
      "permissions": permission_responses,
      "pagination": pagination,
    }
  )


async def create_user_permissions(
  user_id: int,
  request: UserPermissionsCreate,
  current_user: User = Depends(get_current_user),
):
  """Grant new permissions to a user for specified resource paths."""

  # Validate input: must include at least one mapping entry
  if not request.root or len(request.root) == 0:
    raise HTTPException(status_code=422, detail="No permissions provided")

  # Validate resource paths are present and non-empty strings (guard against JSON null->"null")
  for path in request.root.keys():
    if not isinstance(path, str) or path.strip() == "" or path.strip().lower() == "null":
      raise HTTPException(status_code=422, detail="Resource path missing")

  try:
    permissions = await permission_service.create_permissions_for_user(
      user_id=user_id,
      permissions=request.root,
      current_user_id=current_user.id,
    )
  except HTTPException as e:
    raise e
  except Exception as e:
    raise HTTPException(status_code=500, detail=f"Failed to create user permissions: {e!s}")

  # Build response objects
  permission_responses = []
  for perm in permissions:
    resource = await perm.resource
    permission_responses.append(build_permission_response(perm, user_id, resource))

  # If a single permission was created, return it directly for backward compatibility
  if len(permission_responses) == 1:
    return Response(data=permission_responses[0])

  return Response(data={"permissions": permission_responses})


async def delete_user_permissions(
  user_id: int,
  request: Optional[UserPermissionsDelete] = None,
  current_user: User = Depends(get_current_user),
):
  """Remove given permissions or all direct permissions if none provided for a specific user."""
  deleted_count = 0
  if request and request.permissionIds:
    deleted_count = await permission_service.delete_permissions_for_user(
      user_id=user_id,
      permission_ids=request.permissionIds,
    )
  else:
    deleted_count = await permission_service.delete_all_permissions_for_user(user_id)

  return Response(
    data={
      "message": f"{deleted_count} permissions deleted for user {user_id}",
    }
  )


async def get_user_permission_by_id(
  user_id: int,
  permission_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve a specific permission for a user."""
  permission, resource = await permission_service.get_permission_by_id(
    user_id=user_id,
    permission_id=permission_id,
  )

  return Response(data=build_permission_response(permission, user_id, resource))


async def update_user_permission(
  user_id: int,
  permission_id: int,
  request: UserPermissionUpdate,
  current_user: User = Depends(get_current_user),
):
  """Update a specific permission for a user."""
  permission, resource = await permission_service.update_permission_for_user(
    user_id=user_id,
    permission_id=permission_id,
    resource_id=request.resourceId,
    permission_type=request.type.value if request.type else None,
    updated_by=current_user.id,
  )

  return Response(data=build_permission_response(permission, user_id, resource))


async def delete_user_permission(
  user_id: int,
  permission_id: int,
  current_user: User = Depends(get_current_user),
):
  """Remove a specific permission from a user."""
  await permission_service.delete_permission_for_user(
    user_id=user_id,
    permission_id=permission_id,
  )

  return Response(data={"message": "Permission deleted successfully"})
