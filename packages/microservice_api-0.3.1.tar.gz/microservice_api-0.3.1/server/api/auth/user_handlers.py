from typing import Optional

import asyncpg
from fastapi import Depends, HTTPException, Query, Request
from tortoise.exceptions import IntegrityError
from tortoise.expressions import Q

from ...models.auth import Group, User, UserGroup
from ...models.auth.schemas import (
  AddUserToGroupsRequest,
  GroupResponse,
  RemoveUserFromGroupsRequest,
  Response,
  UserCreate,
  UserUpdate,
)
from ...models.schema import Pagination

from .helper import (
  filter_by_accessible_resources,
  get_current_user,
  hash_password,
  user_to_response,
)


async def list_users(
  request: Request,
  page: int = Query(1, ge=1),
  limit: int = Query(20, ge=1, le=100),
  search: Optional[str] = None,
  current_user: User = Depends(get_current_user),
):
  """
  Retrieve a list of users with pagination and optional search.

  This endpoint is secured by the authorization middleware and requires
  appropriate permissions (typically admin-level) via the /auth/users resources.
  """
  skip = (page - 1) * limit

  if search:
    users = await User.search_by_name_or_email(search, skip=skip, limit=limit)
    total = await User.filter(Q(name__icontains=search) | Q(email__icontains=search)).count()
  else:
    users = await User.get_all(skip=skip, limit=limit)
    total = await User.all().count()

  # Filter by accessible resources
  accessible_resources = getattr(request.state, "accessible_resources", [])
  users = filter_by_accessible_resources(users, accessible_resources, "/auth/users")

  user_responses = [await user_to_response(u) for u in users]

  # Pagination metadata (using total count from query)
  pagination = Pagination()
  pagination.set(page=page, limit=limit, total=total)

  return Response(data={"users": user_responses, "pagination": pagination})


async def create_user(
  request: UserCreate,
  current_user: User = Depends(get_current_user),
):
  """Create a new user account."""
  existing_user = await User.get_by_email(request.email)
  if existing_user:
    raise HTTPException(status_code=409, detail="User with this email already exists")

  password_hash = hash_password(request.password)
  user = await User.create_user(
    email=request.email,
    name=request.name,
    password_hash=password_hash,
    created_by=current_user.id,
  )

  # Add user to groups if specified
  if request.groupIds:
    for group_id in request.groupIds:
      group = await Group.get_by_id(group_id)
      if group:
        await UserGroup.add_user_to_group(user.id, group_id, created_by=current_user.id)

  user_response = await user_to_response(user)
  return Response(data=user_response)


async def get_user_by_id(
  user_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve details of a specific user."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  user_response = await user_to_response(user)
  return Response(data=user_response)


async def update_user(
  user_id: int,
  request: UserUpdate,
  current_user: User = Depends(get_current_user),
):
  """Update user details (admin or own profile)."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  # Check if any fields are provided for update
  if not request.model_dump(exclude_unset=True):
    raise HTTPException(status_code=422, detail="At least one field must be provided for update")

  # Validate password length if provided (Pydantic validator may not catch Optional fields)
  if request.password is not None and (len(request.password) < 8 or len(request.password) > 64):
    raise HTTPException(status_code=422, detail="Password must be between 8 and 64 characters long")

  # Check for email conflict if email is being updated
  if request.email is not None and request.email != user.email:
    existing_user = await User.get_by_email(request.email)
    if existing_user is not None and existing_user.id != user_id:
      raise HTTPException(status_code=409, detail="Email already in use")

  # Prepare update data, excluding groupIds and password (handle separately)
  update_data = request.model_dump(exclude_unset=True, exclude={"groupIds", "password"})

  # Hash password if provided
  if request.password is not None:
    update_data["password_hash"] = hash_password(request.password)

  # Update user fields if any
  if update_data:
    try:
      update_data["updated_by"] = current_user.id
      await user.update_user(**update_data)
    except (IntegrityError, asyncpg.exceptions.UniqueViolationError) as e:
      # Catch database constraint violations (e.g., duplicate email)
      error_msg = str(e)
      if "email" in error_msg.lower() or "users_email_key" in error_msg or "unique constraint" in error_msg.lower():
        raise HTTPException(status_code=409, detail="Email already in use")
      raise HTTPException(status_code=400, detail=f"Database constraint violation: {error_msg}")
    except Exception as e:
      # Catch any other database errors that might be IntegrityError wrapped
      error_msg = str(e)
      if "duplicate key" in error_msg.lower() and "email" in error_msg.lower():
        raise HTTPException(status_code=409, detail="Email already in use")
      # Re-raise if it's not an email conflict
      raise
    user = await User.get_by_id(user_id)

  # Add to new groups if specified
  # If only groups are being updated (no other fields), we still need to set updated_by
  if request.groupIds is not None:
    # If no other fields were updated, set updated_by when updating groups
    if not update_data:
      try:
        await user.update_user(updated_by=current_user.id)
        user = await User.get_by_id(user_id)
      except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update user: {e!s}")
    for group_id in request.groupIds:
      group = await Group.get_by_id(group_id)
      if group:
        await UserGroup.add_user_to_group(user_id, group_id, created_by=current_user.id)

  user_response = await user_to_response(user)
  return Response(data=user_response)


async def delete_user(
  user_id: int,
  current_user: User = Depends(get_current_user),
):
  """Delete a user account."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  if user.id == current_user.id:
    raise HTTPException(status_code=403, detail="Insufficient permissions")

  await user.delete()
  return Response(data={"message": "User deleted successfully"})


async def get_user_groups(
  user_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve all groups that a user belongs to."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  # Get groups using ORM
  group_ids = await UserGroup.filter(user_id=user_id).values_list("group_id", flat=True)
  groups = await Group.filter(id__in=list(group_ids)).all() if group_ids else []

  group_responses = [
    GroupResponse(
      id=g.id,
      name=g.name,
      description=g.description,
      createdBy=g.created_by,
      createdAt=g.created_at,
      updatedAt=g.updated_at,
    )
    for g in groups
  ]

  return Response(data={"userId": user_id, "groups": group_responses})


async def add_user_to_groups(
  user_id: int,
  request: AddUserToGroupsRequest,
  current_user: User = Depends(get_current_user),
):
  """Add a user to groups."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  for groupId in request.groupIds:
    group = await Group.get_by_id(groupId)
    if not group:
      raise HTTPException(status_code=404, detail=f"Group with id {groupId} not found")

  try:
    await UserGroup.add_user_to_groups(user_id, request.groupIds, created_by=current_user.id)
  except Exception as e:
    raise HTTPException(status_code=500, detail=f"Failed to add user to groups: {e!s}")

  return Response(
    data={
      "message": "User added to groups successfully",
      "userId": user_id,
      "groupIds": request.groupIds,
    }
  )


async def remove_user_from_groups(
  user_id: int,
  request: RemoveUserFromGroupsRequest,
  current_user: User = Depends(get_current_user),
):
  """Remove a user from one or more groups."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail="User not found")

  await UserGroup.remove_user_from_groups(user_id, request.groupIds)

  return Response(data={"message": "User removed from groups successfully"})
