from typing import Optional

from fastapi import Depends, HTTPException, Query, Request

from ...models.auth import Group, Permission, User, UserGroup
from ...models.auth.schemas import (
  AddUsersToGroupRequest,
  GroupCreate,
  GroupPermissionsCreate,
  GroupPermissionsDelete,
  GroupPermissionUpdate,
  GroupResponse,
  GroupUpdate,
  PermissionResponse,
  RemoveUsersFromGroupRequest,
  Response,
)
from ...models.schema import Pagination
from ...service.auth import permission_service

from .helper import (
  filter_by_accessible_resources,
  get_current_user,
  user_to_response,
)


async def list_groups(
  request: Request,
  page: int = Query(1, ge=1),
  limit: int = Query(20, ge=1, le=100),
  search: Optional[str] = None,
  current_user: User = Depends(get_current_user),
):
  """Retrieve a list of all groups."""
  skip = (page - 1) * limit

  if search:
    groups = await Group.search_by_name(search, skip=skip, limit=limit)
  else:
    groups = await Group.get_all(skip=skip, limit=limit)

  # Filter by accessible resources
  accessible_resources = getattr(request.state, "accessible_resources", [])
  groups = filter_by_accessible_resources(groups, accessible_resources, "/auth/groups")

  group_responses = [
    GroupResponse(
      id=g.id,
      name=g.name,
      description=g.description,
      createdBy=g.created_by,
      updatedBy=g.updated_by,
      createdAt=g.created_at,
      updatedAt=g.updated_at,
    )
    for g in groups
  ]

  # Update pagination with filtered count
  filtered_total = len(groups)
  pagination = Pagination()
  pagination.set(page=page, limit=limit, total=filtered_total)

  return Response(data={"groups": group_responses, "pagination": pagination})


async def create_group(
  request: GroupCreate,
  current_user: User = Depends(get_current_user),
):
  """Create a new group."""
  existing = await Group.get_by_name(request.name)
  if existing:
    raise HTTPException(status_code=409, detail="Group already exists")

  group = await Group.create_group(name=request.name, description=request.description, created_by=current_user.id)

  return Response(
    data=GroupResponse(
      id=group.id,
      name=group.name,
      description=group.description,
      createdBy=group.created_by,
      createdAt=group.created_at,
      updatedAt=group.updated_at,
    )
  )


async def get_group_by_id(
  group_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve details of a specific group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  return Response(
    data=GroupResponse(
      id=group.id,
      name=group.name,
      description=group.description,
      createdBy=group.created_by,
      updatedBy=group.updated_by,
      createdAt=group.created_at,
      updatedAt=group.updated_at,
    )
  )


async def update_group(
  group_id: int,
  request: GroupUpdate,
  current_user: User = Depends(get_current_user),
):
  """Update group details."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  update_data = request.model_dump(exclude_unset=True)

  if update_data:

    # Check for duplicate name if name is being updated
    if "name" in update_data:
      existing = await Group.get_by_name(update_data["name"])
      if existing and existing.id != group_id:
        raise HTTPException(status_code=409, detail="Group with this name already exists")

    update_data["updated_by"] = current_user.id
    await group.update_group(**update_data)
    group = await Group.get_by_id(group_id)

  return Response(
    data=GroupResponse(
      id=group.id,
      name=group.name,
      description=group.description,
      createdBy=group.created_by,
      updatedBy=group.updated_by,
      createdAt=group.created_at,
      updatedAt=group.updated_at,
    )
  )


async def delete_group(
  group_id: int,
  current_user: User = Depends(get_current_user),
):
  """Delete a group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  await group.delete()

  return Response(data={"message": "Group deleted successfully"})


async def get_group_users(
  group_id: int,
  page: int = Query(1, ge=1),
  limit: int = Query(20, ge=1, le=100),
  current_user: User = Depends(get_current_user),
):
  """Retrieve all users belonging to a specific group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  skip = (page - 1) * limit

  user_groups = await UserGroup.get_users_in_group(group_id, skip=skip, limit=limit)
  user_ids = [ug.user_id for ug in user_groups]
  users = await User.filter(id__in=user_ids)

  total = await UserGroup.filter(group_id=group_id).count()

  user_responses = [await user_to_response(u) for u in users]
  pagination = Pagination()
  pagination.set(page=page, limit=limit, total=total)

  return Response(data={"users": user_responses, "pagination": pagination})


async def add_users_to_group(
  group_id: int,
  request: AddUsersToGroupRequest,
  current_user: User = Depends(get_current_user),
):
  """Add multiple users to a group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  for user_id in request.userIds:
    user = await User.get_by_id(user_id)
    if not user:
      raise HTTPException(status_code=404, detail=f"User with id {user_id} not found")

  try:
    await UserGroup.add_users_to_group(group_id, request.userIds, created_by=current_user.id)
  except Exception as e:
    raise HTTPException(status_code=500, detail=f"Failed to add users to group: {e!s}")

  return Response(
    data={
      "message": "Users added to group successfully",
      "groupId": group_id,
      "userIds": request.userIds,
    }
  )


async def remove_users_from_group(
  group_id: int,
  request: RemoveUsersFromGroupRequest,
  current_user: User = Depends(get_current_user),
):
  """Remove multiple users from a group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  await UserGroup.remove_users_from_group(group_id, request.userIds)

  return Response(data={"message": "Users removed from group successfully"})


async def get_group_permissions(
  group_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve all resource access patterns for a specific group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  permissions = await Permission.filter(entity_type="group", entity_id=group_id).prefetch_related("resource")

  permission_responses = []
  for perm in permissions:
    resource = await perm.resource
    # Use created_at as fallback for updated_at if not set (shouldn't happen with auto_now=True)
    updated_at = perm.updated_at if perm.updated_at is not None else perm.created_at
    permission_responses.append(
      PermissionResponse(
        id=perm.id,
        entityType="group",
        entityId=group_id,
        resourcePattern=resource.path if resource else "",
        description=resource.description if resource else None,
        type=perm.type,
        createdAt=perm.created_at,
        createdBy=perm.created_by,
        updatedAt=updated_at,
        updatedBy=perm.updated_by,
      )
    )

  return Response(data={"groupId": group_id, "permissions": permission_responses})


async def create_group_permissions(
  group_id: int,
  request: GroupPermissionsCreate,
  current_user: User = Depends(get_current_user),
):
  """Grant a new resource access pattern to a group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  try:
    # Extract mapping from request (support RootModel and plain dict)
    if hasattr(request, "root"):
      permissions_map = request.root
    elif isinstance(request, dict):
      permissions_map = request
    else:
      try:
        permissions_map = request.model_dump()
      except Exception:
        permissions_map = None

    # Ensure permission mapping exists and is not empty
    if not isinstance(permissions_map, dict) or len(permissions_map) == 0:
      raise HTTPException(status_code=422, detail="resourcePattern is required")

    # Find or create the resources and create permissions
    permissions = await permission_service.create_permissions_for_group(
      group_id=group_id,
      permissions=permissions_map,
      current_user_id=current_user.id,
    )

    # Build response objects
    permission_responses = []
    for perm in permissions:
      resource = await perm.resource
      # Use created_at as fallback for updated_at if not set
      updated_at = perm.updated_at if perm.updated_at is not None else perm.created_at
      permission_responses.append(
        PermissionResponse(
          id=perm.id,
          entityType="group",
          entityId=group_id,
          resourcePattern=resource.path if resource else "",
          description=resource.description if resource else None,
          type=perm.type,
          createdAt=perm.created_at,
          createdBy=perm.created_by,
          updatedAt=updated_at,
          updatedBy=perm.updated_by,
        )
      )

    # If a single permission was created, return it directly for backward compatibility
    if len(permission_responses) == 1:
      return Response(data=permission_responses[0])

    return Response(data={"permissions": permission_responses})
  except HTTPException as e:
    raise e
  except Exception as e:
    raise HTTPException(status_code=500, detail=f"Failed to create group permissions: {e!s}")


async def remove_group_permissions(
  group_id: int,
  request: Optional[GroupPermissionsDelete] = None,
  current_user: User = Depends(get_current_user),
):
  """Remove specific paths or all if no paths provided from a group."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail="Group not found")

  deleted_count = 0
  if request and request.permissionIds:
    deleted_count = await permission_service.delete_permissions_for_group(
      group_id=group_id,
      permission_ids=request.permissionIds,
    )
  else:
    deleted_count = await permission_service.delete_all_permissions_for_group(group_id=group_id)

  return Response(data={"message": f"{deleted_count} permissions deleted for group {group_id}"})


async def get_group_permission_by_id(
  group_id: int,
  permission_id: int,
  current_user: User = Depends(get_current_user),
):
  """Retrieve a specific permission for a group."""
  permission, resource = await permission_service.get_permission_by_id_for_group(
    group_id=group_id,
    permission_id=permission_id,
  )

  return Response(
    data=PermissionResponse(
      id=permission.id,
      entityType="group",
      entityId=group_id,
      resourcePattern=resource.path if resource else "",
      description=resource.description if resource else None,
      type=permission.type,
      createdAt=permission.created_at,
      createdBy=permission.created_by,
      updatedAt=permission.updated_at if permission.updated_at is not None else permission.created_at,
      updatedBy=permission.updated_by,
    )
  )


async def update_group_permission(
  group_id: int,
  permission_id: int,
  request: GroupPermissionUpdate,
  current_user: User = Depends(get_current_user),
):
  """Update a specific permission for a group."""
  permission, resource = await permission_service.update_permission_for_group(
    group_id=group_id,
    permission_id=permission_id,
    resource_id=request.resourceId,
    permission_type=request.type.value if request.type else None,
    updated_by=current_user.id,
  )

  return Response(
    data=PermissionResponse(
      id=permission.id,
      entityType="group",
      entityId=group_id,
      resourcePattern=resource.path if resource else "",
      description=resource.description if resource else None,
      type=permission.type,
      createdAt=permission.created_at,
      createdBy=permission.created_by,
      updatedAt=permission.updated_at if permission.updated_at is not None else permission.created_at,
      updatedBy=permission.updated_by,
    )
  )


async def delete_group_permission(
  group_id: int,
  permission_id: int,
  current_user: User = Depends(get_current_user),
):
  """Remove a specific permission from a group."""
  await permission_service.delete_permission_for_group(
    group_id=group_id,
    permission_id=permission_id,
  )

  return Response(data={"message": "Permission deleted successfully"})
