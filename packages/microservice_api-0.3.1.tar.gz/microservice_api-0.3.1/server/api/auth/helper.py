"""Helper functions for authentication."""

import hashlib
from datetime import UTC, datetime, timedelta
from typing import Optional

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ...models.auth import Permission, Resource, User
from ...models.auth.group import Group
from ...models.auth.schemas import (
  ResourceResponse,
  UserPermissionResponse,
  UserResponse,
)
from ...models.auth.user_group import UserGroup
from ...utils.env import AUTH_JWT_ALGORITHM, AUTH_JWT_EXPIRATION_HOURS, AUTH_JWT_SECRET

security = HTTPBearer()

# Token blacklist (in production, use Redis or database)
token_blacklist: set[str] = set()


def hash_password(password: str) -> str:
  """Hash password using SHA-256."""
  return hashlib.sha256(password.encode()).hexdigest()


def verify_password(password: str, password_hash: str) -> bool:
  """Verify password against hash."""
  return hash_password(password) == password_hash


def create_access_token(user_id: int, email: str) -> str:
  """Create JWT access token."""
  expiration = datetime.now(UTC) + timedelta(hours=AUTH_JWT_EXPIRATION_HOURS)
  payload = {
    "sub": str(user_id),
    "email": email,
    "exp": expiration,
    "iat": datetime.now(UTC),
  }
  return jwt.encode(payload, AUTH_JWT_SECRET, algorithm=AUTH_JWT_ALGORITHM)


async def get_current_user(
  request: Request,
  credentials: HTTPAuthorizationCredentials = Depends(security),
) -> User:
  """Dependency to get current authenticated user using middleware-extracted user ID."""
  token = credentials.credentials

  if token in token_blacklist:
    raise HTTPException(status_code=401, detail="Token has been revoked")

  # Use user_id from request state (set by middleware)
  user_id = getattr(request.state, "user_id", None)
  if not user_id:
    raise HTTPException(status_code=401, detail="Invalid or missing token")

  user = await User.get_by_id(int(user_id))
  if not user:
    raise HTTPException(status_code=401, detail="User not found")

  return user


async def user_to_response(user: User) -> UserResponse:
  """Convert User model to UserResponse."""
  # Get group IDs using ORM
  group_ids = await UserGroup.filter(user_id=user.id).values_list("group_id", flat=True)
  groups = await Group.filter(id__in=list(group_ids)).all() if group_ids else []

  permissions = await Permission.filter(entity_id=user.id, entity_type="user").prefetch_related("resource").all()

  return UserResponse(
    id=user.id,
    email=user.email,
    phone=user.phone,
    name=user.name,
    google_id=user.google_id,
    google_avatar_url=user.google_avatar_url,
    groupIds=[g.id for g in groups],
    permissions=[build_permission_response(p, user.id, p.resource) for p in permissions],
    createdBy=user.created_by,
    updatedBy=user.updated_by,
    createdAt=user.created_at,
    updatedAt=user.updated_at,
  )


def build_resource_response(resource: Resource) -> ResourceResponse:
  """Build a ResourceResponse from a Resource model."""
  return ResourceResponse(
    id=resource.id,
    path=resource.path,
    name=resource.name,
    description=resource.description,
    createdAt=resource.created_at,
    updatedAt=resource.updated_at,
  )


def build_permission_response(
  permission: Permission, user_id: int, resource: Optional[Resource]
) -> UserPermissionResponse:
  """Build a UserPermissionResponse from a Permission model."""
  # Ensure updated_at is always a valid datetime (use created_at as fallback if None)
  updated_at = permission.updated_at if permission.updated_at is not None else permission.created_at
  updated_by = permission.updated_by

  return UserPermissionResponse(
    id=permission.id,
    userId=user_id,
    resourceId=permission.resource_id,
    resource=build_resource_response(resource) if resource else None,
    type=permission.type,
    createdAt=permission.created_at,
    createdBy=permission.created_by,
    updatedAt=updated_at,
    updatedBy=updated_by,
  )


def filter_by_accessible_resources(items: list, accessible_resources: list[str], base_path: str) -> list:
  """Filter items based on accessible resources.

  Args:
      items: List of items with 'id' attribute
      accessible_resources: List of accessible resource paths
      base_path: Base path for the resource (e.g., '/auth/groups')

  Returns:
      Filtered list of items
  """
  if not accessible_resources:
    return []

  # Check if user has wildcard access
  wildcard_path = f"{base_path}/*"
  if wildcard_path in accessible_resources:
    return items

  # Check if user has parent wildcard access (e.g., /udemy/* grants access to /udemy/courses/*)
  # Check each parent path level
  path_parts = base_path.strip("/").split("/")
  for i in range(len(path_parts)):
    parent_path = "/" + "/".join(path_parts[: i + 1])
    parent_wildcard = f"{parent_path}/*"
    if parent_wildcard in accessible_resources:
      return items

  # Extract IDs from accessible resources
  accessible_ids = set()
  for resource_path in accessible_resources:
    if resource_path.startswith(base_path + "/"):
      # Extract ID from path like '/auth/groups/1'
      id = resource_path.lstrip(base_path + "/").split("/")[0]
      if id.isdigit():
        accessible_ids.add(int(id))

  # Filter items by accessible IDs
  # Handle both objects with .id attribute and dicts with 'id' key
  filtered_items = []
  for item in items:
    try:
      item_id = item.id if hasattr(item, "id") else (item.get("id") if isinstance(item, dict) else None)
      if item_id is not None and item_id in accessible_ids:
        filtered_items.append(item)
    except (AttributeError, KeyError, TypeError):
      # Skip items that don't have an ID we can extract
      continue
  return filtered_items
