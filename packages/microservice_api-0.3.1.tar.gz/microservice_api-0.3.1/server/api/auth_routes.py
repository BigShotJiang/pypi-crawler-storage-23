from fastapi import APIRouter, status

from ..models.auth.schemas import Response

from .auth.auth_handlers import login, logout, oauth_login
from .auth.group_handlers import (
  add_users_to_group,
  create_group,
  create_group_permissions,
  delete_group,
  delete_group_permission,
  get_group_by_id,
  get_group_permission_by_id,
  get_group_permissions,
  get_group_users,
  list_groups,
  remove_group_permissions,
  remove_users_from_group,
  update_group,
  update_group_permission,
)
from .auth.permission_handlers import (
  create_user_permissions,
  delete_user_permission,
  delete_user_permissions,
  get_user_permission_by_id,
  list_user_permissions,
  update_user_permission,
)
from .auth.user_handlers import (
  add_user_to_groups,
  create_user,
  delete_user,
  get_user_by_id,
  get_user_groups,
  list_users,
  remove_user_from_groups,
  update_user,
)

auth_router = APIRouter(prefix="/auth")


# ===================
# Authentication Routes
# ===================
auth_router.add_api_route("/login", login, methods=["POST"], response_model=Response, tags=["Authentication"])
auth_router.add_api_route("/logout", logout, methods=["POST"], response_model=Response, tags=["Authentication"])
auth_router.add_api_route(
  "/oauth/google", oauth_login, methods=["POST"], response_model=Response, tags=["Authentication"]
)

# ===================
# User Routes
# ===================
auth_router.add_api_route("/users", list_users, methods=["GET"], response_model=Response, tags=["Users"])
auth_router.add_api_route(
  "/users", create_user, methods=["POST"], response_model=Response, status_code=status.HTTP_201_CREATED, tags=["Users"]
)
auth_router.add_api_route("/users/{user_id}", get_user_by_id, methods=["GET"], response_model=Response, tags=["Users"])
auth_router.add_api_route("/users/{user_id}", update_user, methods=["PATCH"], response_model=Response, tags=["Users"])
auth_router.add_api_route("/users/{user_id}", delete_user, methods=["DELETE"], response_model=Response, tags=["Users"])

# ===================
# User Groups Routes
# ===================
auth_router.add_api_route(
  "/users/{user_id}/groups", get_user_groups, methods=["GET"], response_model=Response, tags=["Users"]
)
auth_router.add_api_route(
  "/users/{user_id}/groups", add_user_to_groups, methods=["POST"], response_model=Response, tags=["Users"]
)
auth_router.add_api_route(
  "/users/{user_id}/groups",
  remove_user_from_groups,
  methods=["DELETE"],
  response_model=Response,
  tags=["Users"],
)

# ===================
# Permissions Routes - User Permissions
# ===================
auth_router.add_api_route(
  "/permissions/users/{user_id}", list_user_permissions, methods=["GET"], response_model=Response, tags=["Permissions"]
)
auth_router.add_api_route(
  "/permissions/users/{user_id}",
  create_user_permissions,
  methods=["POST"],
  response_model=Response,
  status_code=status.HTTP_201_CREATED,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/users/{user_id}",
  delete_user_permissions,
  methods=["DELETE"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/users/{user_id}/{permission_id}",
  get_user_permission_by_id,
  methods=["GET"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/users/{user_id}/{permission_id}",
  update_user_permission,
  methods=["PATCH"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/users/{user_id}/{permission_id}",
  delete_user_permission,
  methods=["DELETE"],
  response_model=Response,
  tags=["Permissions"],
)

# ===================
# Group Routes
# ===================
auth_router.add_api_route("/groups", list_groups, methods=["GET"], response_model=Response, tags=["Groups"])
auth_router.add_api_route(
  "/groups",
  create_group,
  methods=["POST"],
  response_model=Response,
  status_code=status.HTTP_201_CREATED,
  tags=["Groups"],
)
auth_router.add_api_route(
  "/groups/{group_id}", get_group_by_id, methods=["GET"], response_model=Response, tags=["Groups"]
)
auth_router.add_api_route(
  "/groups/{group_id}", update_group, methods=["PATCH"], response_model=Response, tags=["Groups"]
)
auth_router.add_api_route(
  "/groups/{group_id}", delete_group, methods=["DELETE"], response_model=Response, tags=["Groups"]
)
auth_router.add_api_route(
  "/groups/{group_id}/users", get_group_users, methods=["GET"], response_model=Response, tags=["Groups"]
)
auth_router.add_api_route(
  "/groups/{group_id}/users", add_users_to_group, methods=["POST"], response_model=Response, tags=["Groups"]
)
auth_router.add_api_route(
  "/groups/{group_id}/users",
  remove_users_from_group,
  methods=["DELETE"],
  response_model=Response,
  tags=["Groups"],
)

# ===================
# Permissions Routes - Group Permissions
# ===================
# Note: More specific routes (with permission_id) must come BEFORE less specific routes
auth_router.add_api_route(
  "/permissions/groups/{group_id}/{permission_id}",
  get_group_permission_by_id,
  methods=["GET"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/groups/{group_id}/{permission_id}",
  update_group_permission,
  methods=["PATCH"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/groups/{group_id}/{permission_id}",
  delete_group_permission,
  methods=["DELETE"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/groups/{group_id}",
  get_group_permissions,
  methods=["GET"],
  response_model=Response,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/groups/{group_id}",
  create_group_permissions,
  methods=["POST"],
  response_model=Response,
  status_code=status.HTTP_201_CREATED,
  tags=["Permissions"],
)
auth_router.add_api_route(
  "/permissions/groups/{group_id}",
  remove_group_permissions,
  methods=["DELETE"],
  response_model=Response,
  tags=["Permissions"],
)
