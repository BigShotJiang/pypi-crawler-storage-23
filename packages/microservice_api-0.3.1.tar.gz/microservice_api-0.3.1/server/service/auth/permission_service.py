"""Permission service - business logic for permission operations."""

import logging
from typing import List, Optional

from fastapi import HTTPException
from tortoise.expressions import Q

from ...models.auth import Permission, Resource, User
from ...models.auth.group import Group
from ...models.auth.schemas import PermissionType

logger = logging.getLogger(__name__)


def _get_permission_type_or_422(permission_type: str) -> str:
  """Validate and return permission type or raise 422."""
  try:
    if isinstance(permission_type, PermissionType):
      return permission_type.value
    return PermissionType(permission_type).value
  except Exception:
    raise HTTPException(status_code=422, detail="Invalid permission type")


async def _get_user_or_404(user_id: int) -> User:
  """Get user by ID or raise 404."""
  user = await User.get_by_id(user_id)
  if not user:
    raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found")
  return user


async def _get_group_or_404(group_id: int) -> Group:
  """Get group by ID or raise 404."""
  group = await Group.get_by_id(group_id)
  if not group:
    raise HTTPException(status_code=404, detail=f"Group with ID {group_id} not found")
  return group


def _default_description_for_path(path: str) -> str:
  """Generate a friendly default description from a resource path.

  Examples:
    /auth/new-resource -> "New resource permission"
    /auth/verify-resource -> "Verify resource permission"
  """
  # Strip leading/trailing slashes and split into segments
  segments = [s for s in path.strip("/").split("/") if s]
  if not segments:
    return ""

  last = segments[-1]
  # Handle wildcard paths like '*' by using the previous segment if present
  if last == "*" and len(segments) >= 2:
    last = segments[-2]
  # Replace dashes/underscores with spaces and normalize case to match expectations
  friendly = last.replace("-", " ").replace("_", " ").lower()
  friendly = friendly.capitalize()
  return f"{friendly} permission"


async def _get_or_create_resource(path: str) -> Resource:
  """Get resource by path or create missing resources automatically."""
  res = await Resource.get_by_path(path)
  description = _default_description_for_path(path)
  if not res:
    # When creating a new resource automatically, provide a friendly description
    res = await Resource.create_resource(path=path, name=path, description=description)
  else:
    # If resource exists but has no description, set a default description
    if getattr(res, "description", None) is None:
      await res.update_resource(description=description)
  return res


async def _get_resource_or_404(resource_id: int) -> Resource:
  """Get resource by ID or raise 404."""
  resource = await Resource.get_by_id(resource_id)
  if not resource:
    raise HTTPException(status_code=404, detail="Resource not found")
  return resource


async def _get_permission_or_404(permission_id: int, entity: str, entity_id: int) -> Permission:
  """Get permission by ID for a user or raise 404."""
  permission = (
    await Permission.filter(id=permission_id, entity_type=entity, entity_id=entity_id)
    .prefetch_related("resource")
    .first()
  )
  if not permission:
    raise HTTPException(status_code=404, detail="Permission not found")
  return permission


async def get_user_permissions_list(
  user_id: int,
  page: int,
  limit: int,
  resource_id: Optional[int],
  permission_type: Optional[PermissionType],
) -> dict:
  """Get paginated list of user permissions. Returns permissions and total count."""
  await _get_user_or_404(user_id)

  skip = (page - 1) * limit

  filters = {"entity_type": "user", "entity_id": user_id}
  if resource_id:
    filters["resource_id"] = resource_id

  # If a permission_type filter is provided, expand it according to permission
  # hierarchy so that requesting 'r' includes rows with r, w, or d, etc.
  if permission_type:
    pt_val = _get_permission_type_or_422(permission_type)
    if pt_val == "r":
      perm_filter = Q(type="r") | Q(type="w") | Q(type="d")
    elif pt_val == "w":
      perm_filter = Q(type="w") | Q(type="d")
    else:
      perm_filter = Q(type="d")

    base_query = Permission.filter(Q(entity_type="user", entity_id=user_id) & perm_filter)
    if resource_id:
      base_query = base_query.filter(resource_id=resource_id)

    permissions = await base_query.offset(skip).limit(limit).prefetch_related("resource")
    total = await base_query.count()
  else:
    permissions = await Permission.filter(**filters).offset(skip).limit(limit).prefetch_related("resource")
    total = await Permission.filter(**filters).count()

  return {
    "permissions": permissions,
    "total": total,
  }


async def create_permissions_for_user(
  user_id: int,
  permissions: dict[str, PermissionType],
  current_user_id: int,
) -> List[Permission]:
  """Create new permissions for a user. Validates resources and types, raises on conflicts."""
  await _get_user_or_404(user_id)

  # Validate resources exist and that no requested permission already exists
  permission_list = []
  for path, perm_type in permissions.items():
    # Ensure resource exists
    res = await _get_or_create_resource(path)

    type = _get_permission_type_or_422(perm_type)

    permission = await Permission.filter(
      entity_type="user",
      entity_id=user_id,
      resource_id=res.id,
    ).first()

    if not permission:
      permission = await Permission.create_permission(
        entity_type="user",
        entity_id=user_id,
        resource_id=res.id,
        type=type,
        created_by=current_user_id,
      )
    else:
      if permission.type != type:
        # Update existing permission type if different
        permission.type = type
        permission.updated_by = current_user_id
        await permission.save()

    permission_list.append(permission)

  return permission_list


async def delete_all_permissions_for_user(user_id: int) -> int:
  """Delete all permissions for a user. Returns deleted count."""
  await _get_user_or_404(user_id)

  deleted_count = await Permission.filter(entity_type="user", entity_id=user_id).delete()

  return deleted_count


async def delete_permissions_for_user(user_id: int, permission_ids: List[int]) -> int:
  """Delete specified permissions for a user. Returns deleted count."""
  await _get_user_or_404(user_id)

  deleted_count = await Permission.filter(entity_type="user", entity_id=user_id, id__in=permission_ids).delete()
  return deleted_count


async def get_permission_by_id(user_id: int, permission_id: int) -> tuple[Permission, Resource]:
  """Get a specific permission for a user. Returns permission and resource."""
  await _get_user_or_404(user_id)

  permission = await _get_permission_or_404(permission_id, "user", user_id)
  if not permission:
    raise HTTPException(status_code=404, detail="Permission not found")

  resource = await permission.resource

  return permission, resource


async def update_permission_for_user(
  user_id: int,
  permission_id: int,
  resource_id: Optional[int],
  permission_type: Optional[str],
  updated_by: Optional[int] = None,
) -> tuple[Permission, Resource]:
  """Update a specific permission for a user. Returns updated permission and resource."""
  await _get_user_or_404(user_id)

  permission = await _get_permission_or_404(permission_id, "user", user_id)

  # Resolve resource: either the new one or the existing related resource
  if resource_id is not None:
    resource = await _get_resource_or_404(resource_id)
    permission.resource_id = resource.id
  else:
    resource = await permission.resource

  # Validate and apply permission type if provided
  if permission_type is not None:
    validated_type = _get_permission_type_or_422(permission_type)
    permission.type = validated_type

  permission.updated_by = updated_by
  await permission.save()

  return permission, resource


async def delete_permission_for_user(user_id: int, permission_id: int) -> None:
  """Delete a specific permission for a user."""
  await _get_user_or_404(user_id)
  permission = await _get_permission_or_404(permission_id, "user", user_id)
  await permission.delete()


async def create_permissions_for_group(
  group_id: int,
  permissions: dict[str, PermissionType],
  current_user_id: int,
) -> List[Permission]:
  """Create new permissions for a user. Validates resources and types, raises on conflicts."""
  await _get_group_or_404(group_id)

  # Validate resources exist and that no requested permission already exists
  permission_list = []
  for path, perm_type in permissions.items():
    # Ensure resource exists
    res = await _get_or_create_resource(path)

    type = _get_permission_type_or_422(perm_type)

    # If an identical permission already exists, abort with conflict
    permission = await Permission.filter(
      entity_type="group",
      entity_id=group_id,
      resource_id=res.id,
    ).first()

    if not permission:
      permission = await Permission.create_permission(
        entity_type="group",
        entity_id=group_id,
        resource_id=res.id,
        type=type,
        created_by=current_user_id,
      )
    else:
      if permission.type != type:
        # Update existing permission type if different
        permission.type = type
        permission.updated_by = current_user_id
        await permission.save()
    permission_list.append(permission)

  return permission_list


async def delete_all_permissions_for_group(group_id: int) -> int:
  """Delete all permissions for a group. Returns deleted count."""
  await _get_group_or_404(group_id)

  deleted_count = await Permission.filter(entity_type="group", entity_id=group_id).delete()

  return deleted_count


async def delete_permissions_for_group(group_id: int, permission_ids: List[int]) -> int:
  """Delete specified permissions for a group. Returns deleted count."""
  await _get_group_or_404(group_id)

  deleted_count = await Permission.filter(entity_type="group", entity_id=group_id, id__in=permission_ids).delete()
  return deleted_count


async def get_permission_by_id_for_group(group_id: int, permission_id: int) -> tuple[Permission, Resource]:
  """Get a specific permission for a group. Returns permission and resource."""
  await _get_group_or_404(group_id)

  permission = await _get_permission_or_404(permission_id, "group", group_id)

  resource = await permission.resource

  return permission, resource


async def update_permission_for_group(
  group_id: int,
  permission_id: int,
  resource_id: Optional[int],
  permission_type: Optional[str],
  updated_by: Optional[int] = None,
) -> tuple[Permission, Resource]:
  """Update a specific permission for a group. Returns updated permission and resource."""
  await _get_group_or_404(group_id)

  permission = await _get_permission_or_404(permission_id, "group", group_id)

  # Resolve resource: either the new one or the existing related resource
  if resource_id is not None:
    resource = await _get_resource_or_404(resource_id)
    permission.resource_id = resource.id
  else:
    resource = await permission.resource

  # Validate and apply permission type if provided
  if permission_type is not None:
    validated_type = _get_permission_type_or_422(permission_type)
    permission.type = validated_type

  permission.updated_by = updated_by
  await permission.save()

  return permission, resource


async def delete_permission_for_group(group_id: int, permission_id: int) -> None:
  """Delete a specific permission for a group."""
  await _get_group_or_404(group_id)

  permission = await _get_permission_or_404(permission_id, "group", group_id)

  await permission.delete()
