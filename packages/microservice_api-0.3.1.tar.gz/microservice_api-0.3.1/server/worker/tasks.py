import asyncio
from collections.abc import Callable
from datetime import datetime

from ..utils.db_locks import acquire_lock, release_lock
from ..utils.logger import get_logger

logger = get_logger(__name__)


async def run_with_lock(lock_name: str, task: Callable, task_name: str) -> None:
  """Execute an async task with database lock to prevent concurrent runs."""
  acquired = await acquire_lock(lock_name)

  if acquired:
    try:
      logger.info(f"Lock acquired, executing {task_name} at {datetime.now()}")
      await task()
      logger.info(f"{task_name} completed successfully")
    except Exception as e:
      logger.error(f"{task_name} failed: {e}", exc_info=True)
      raise
    finally:
      await release_lock(lock_name)
  else:
    logger.info(f"Another instance is running {task_name}, skipping")

async def run_test() -> None:
  """Run test task with locking."""

  async def task():
    logger.info("Starting test task...")
    await asyncio.sleep(5)  # Simulate a long-running task
    logger.info("Test task executed")

  await run_with_lock("test_task", task, "test task")