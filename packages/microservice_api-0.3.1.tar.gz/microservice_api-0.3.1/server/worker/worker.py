import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger

from ..utils.logger import get_logger
from .tasks import (
  run_test,
)
logger = get_logger(__name__)

worker = AsyncIOScheduler()
