from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse
from tortoise import Tortoise
from tortoise.context import TortoiseContext

from .api.middleware import register_middlewares
from .utils.env import SERVICE_API_PREFIX, SERVICE_ENABLE_AUTH, SERVICE_ENABLE_DB, DB_TYPE, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD, SERVICE_ENABLE_DOCS, SERVICE_ENABLE_WORKER
from .utils.logger import get_logger
from .worker.worker import worker

logger = get_logger(__name__)


def _build_db_url() -> str:
  """Build the database URL from environment variables."""
  if DB_TYPE == "postgres":
    return f"postgres://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
  elif DB_TYPE == "mysql":
    return f"mysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
  else:
    raise ValueError(f"Unsupported DB_TYPE: {DB_TYPE}")


async def init_db(models: list[str]) -> TortoiseContext:
  """Initialize database connection and return the entered TortoiseContext."""
  DATABASE_URL = _build_db_url()
  logger.info(f"Connecting to database at {DB_HOST}:{DB_PORT} ({DB_TYPE})")
  ctx = await Tortoise.init(
    db_url=DATABASE_URL,
    modules={"models": models},
    _enable_global_fallback=False,
  )
  # __aenter__ sets this context as active via contextvars
  await ctx.__aenter__()
  return ctx


async def close_db(ctx: TortoiseContext) -> None:
  """Close database connections."""
  try:
    # __aexit__ closes connections and clears the contextvar
    await ctx.__aexit__(None, None, None)
    logger.info("Database connections closed")
  except Exception as e:
    logger.error(f"Error closing database connections: {e}")

# ============================================
# FastAPI Lifespan
# ============================================
@asynccontextmanager
async def lifespan(app: FastAPI, models: list[str]):
  db_ctx = None
  if SERVICE_ENABLE_DB:
    db_ctx = await init_db(models)

  if SERVICE_ENABLE_WORKER:
    worker.start()
    logger.info("Worker started")

  yield

  if SERVICE_ENABLE_WORKER:
    logger.info("Shutting down worker...")
    worker.shutdown(wait=True)
    logger.info("Worker shutdown complete")

  if SERVICE_ENABLE_DB and db_ctx is not None:
    await close_db(db_ctx)

def create_app(models: list[str] = None) -> FastAPI:
  """Create and configure FastAPI application."""
  if SERVICE_ENABLE_AUTH:
    auth_models = ["models.auth"]  # Default to auth models if auth is enabled
    models = (models or []) + auth_models

  app = FastAPI(
    lifespan=lambda app: lifespan(app, models or []),
    title="Itversity Operations API",
    description="Itversity Operations System API",
    version="1.0.0",
    docs_url="/docs" if SERVICE_ENABLE_DOCS else None,
    redoc_url="/redoc" if SERVICE_ENABLE_DOCS else None,
    openapi_url="/openapi.json" if SERVICE_ENABLE_DOCS else None,
  )


  @app.exception_handler(HTTPException)
  async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Handle HTTPException and convert to standardized error response format."""
    # Allow FastAPI's default validation error format for 422
    if exc.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY:
      return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
      )
    # Convert all other HTTPExceptions to standardized format
    message = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
    return JSONResponse(
      status_code=exc.status_code,
      content={"ok": False, "error": message, "data": None},
    )


  @app.exception_handler(Exception)
  async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handle all unhandled exceptions and return standardized error response."""
    # TODO: integrate structured logging here if needed
    return JSONResponse(
      status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
      content={"ok": False, "error": "Internal server error", "data": None},
    )


  register_middlewares(app)


  # health check endpoint
  @app.get(f"{SERVICE_API_PREFIX}/health", tags=["Health"])
  async def health_check():
    return {"ok": True, "message": "API is healthy"}


  # ===================

  if SERVICE_ENABLE_AUTH:
    # Import lazily to avoid loading auth modules when auth is disabled.
    from .api.auth_routes import auth_router

    # Include routers
    app.include_router(auth_router, prefix=SERVICE_API_PREFIX)

  return app
