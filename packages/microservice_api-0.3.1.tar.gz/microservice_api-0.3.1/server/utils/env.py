"""Environment configuration module."""

import os

# Environment
SERVICE_NAME = os.getenv("SERVICE_NAME", "itversity-operations-api")
SERVICE_CORS = os.getenv("SERVICE_CORS", "*").split(",")
SERVICE_HOST = os.getenv("SERVICE_HOST", "0.0.0.0")
SERVICE_PORT = int(os.getenv("SERVICE_PORT", "8000"))
SERVICE_PUBLIC_PATHS = os.getenv("SERVICE_PUBLIC_PATHS", "").split(",")
SERVICE_ENABLE_DB = os.getenv("SERVICE_ENABLE_DB", "true").lower() == "true"
SERVICE_ENABLE_AUTH = os.getenv("SERVICE_ENABLE_AUTH", "true").lower() == "true"
SERVICE_ENABLE_DOCS = os.getenv("SERVICE_ENABLE_DOCS", "true").lower() == "true"
SERVICE_ENABLE_WORKER = os.getenv("SERVICE_ENABLE_WORKER", "true").lower() == "true"
SERVICE_API_PREFIX = os.getenv("SERVICE_API_PREFIX", "/api/v1")

# Database Configuration
DB_TYPE = os.getenv("DB_TYPE", "postgres")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "cms_db")
DB_USER = os.getenv("DB_USER", "cms_user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "cms_password")

# Logger configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_DATE_FORMAT = os.getenv("LOG_DATE_FORMAT", "%Y-%m-%dT%H:%M:%S")

# Auth Configuration
# JWT Configuration
AUTH_JWT_SECRET = os.getenv("AUTH_JWT_SECRET", "your-secret-key")
AUTH_JWT_ALGORITHM = os.getenv("AUTH_JWT_ALGORITHM", "HS256")
AUTH_JWT_EXPIRATION_HOURS = int(os.getenv("AUTH_JWT_EXPIRATION_HOURS", "1"))
JWT_EXPIRATION_HOURS = AUTH_JWT_EXPIRATION_HOURS
AUTH_ENABLE_GOOGLE = os.getenv("AUTH_ENABLE_GOOGLE", "true").lower() == "true"
AUTH_ENABLE_GITHUB = os.getenv("AUTH_ENABLE_GITHUB", "true").lower() == "true"
AUTH_ENABLE_MICROSOFT = os.getenv("AUTH_ENABLE_MICROSOFT", "true").lower() == "true"

# OAuth Configuration - Google
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")

# OAuth Configuration - GitHub
GITHUB_CLIENT_ID = os.getenv("GITHUB_CLIENT_ID", "")
GITHUB_CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET", "")

# OAuth Configuration - Microsoft
MICROSOFT_CLIENT_ID = os.getenv("MICROSOFT_CLIENT_ID", "")
MICROSOFT_CLIENT_SECRET = os.getenv("MICROSOFT_CLIENT_SECRET", "")
MICROSOFT_TENANT_ID = os.getenv("MICROSOFT_TENANT_ID", "common")
