import hashlib

from tortoise import Tortoise

from .logger import get_logger

logger = get_logger(__name__)


def get_lock_id(lock_name: str) -> int:
  """Convert string lock name to integer ID"""
  hash_value = int(hashlib.md5(lock_name.encode()).hexdigest(), 16)
  return hash_value % (2**31 - 1)


async def acquire_lock(lock_name: str, timeout: int = 0) -> bool:
  """Acquire PostgreSQL advisory lock using Tortoise ORM connection.

  Args:
    lock_name: Name of the lock
    timeout: Timeout in seconds (0 = no wait, try once)

  Returns:
    True if lock was acquired, False otherwise
  """
  try:
    lock_id = get_lock_id(lock_name)
    conn = Tortoise.get_connection("default")

    # Use Tortoise connection to execute raw SQL
    result = await conn.execute_query_dict("SELECT pg_try_advisory_lock($1) as acquired", [lock_id])
    acquired = result[0]["acquired"] if result else False

    if acquired:
      logger.info(f"Lock '{lock_name}' (id: {lock_id}) acquired")
    else:
      logger.info(f"Lock '{lock_name}' (id: {lock_id}) already held by another session")
    return acquired
  except Exception as e:
    logger.error(f"Failed to acquire lock '{lock_name}': {e}")
    return False


async def release_lock(lock_name: str) -> bool:
  """Release PostgreSQL advisory lock using Tortoise ORM connection.

  Returns:
    True if lock was released, False if it wasn't held

  Note: PostgreSQL advisory locks are session-scoped and auto-release when
  the session ends. If the lock was already released, this is not an error.
  """
  try:
    lock_id = get_lock_id(lock_name)
    conn = Tortoise.get_connection("default")

    # Use Tortoise connection to execute raw SQL
    result = await conn.execute_query_dict("SELECT pg_advisory_unlock($1) as released", [lock_id])
    released = result[0]["released"] if result else False

    if released:
      logger.info(f"Lock '{lock_name}' (id: {lock_id}) released")
    else:
      # This is normal - lock was already auto-released when connection closed/recycled
      logger.debug(f"Lock '{lock_name}' (id: {lock_id}) was not held (already auto-released)")
    return released
  except Exception as e:
    logger.error(f"Failed to release lock '{lock_name}': {e}")
    return False


async def list_held_locks() -> list:
  """List all currently held advisory locks for debugging.

  Returns:
    List of lock information dictionaries
  """
  try:
    conn = Tortoise.get_connection("default")
    result = await conn.execute_query_dict("""
      SELECT
        locktype,
        classid,
        objid,
        pid,
        granted
      FROM pg_locks
      WHERE locktype = 'advisory'
    """)
    return result
  except Exception as e:
    logger.error(f"Failed to list locks: {e}")
    return []
