from datetime import datetime
from enum import Enum
from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, RootModel

from ..schema import Response


class PermissionType(str, Enum):
  READ = "r"
  WRITE = "w"
  DELETE = "d"


class EntityType(str, Enum):
  USER = "user"
  GROUP = "group"


class OAuthProvider(str, Enum):
  GOOGLE = "google"
  GITHUB = "github"
  MICROSOFT = "microsoft"


# User Schemas
class UserBase(BaseModel):
  email: EmailStr
  name: str


class UserCreate(UserBase):
  password: str = Field(min_length=8, max_length=64)
  groupIds: Optional[List[int]] = None


class UserUpdate(BaseModel):
  name: Optional[str] = None
  email: Optional[EmailStr] = None
  phone: Optional[str] = None
  password: Optional[str] = Field(default=None, min_length=8, max_length=64)
  groupIds: Optional[List[int]] = None


class UserResponse(BaseModel):
  model_config = ConfigDict(from_attributes=True)
  id: int
  email: str
  phone: Optional[str]
  name: str
  google_id: Optional[str] = None
  google_avatar_url: Optional[str] = None
  groupIds: List[int] = []
  permissions: List["UserPermissionResponse"] = []
  createdBy: Optional[int] = None
  updatedBy: Optional[int] = None
  createdAt: datetime
  updatedAt: datetime


# Auth Schemas
class LoginRequest(BaseModel):
  email: EmailStr
  password: str


class LoginResponse(BaseModel):
  token: str
  expiresIn: int
  user: UserResponse


class LogoutResponse(BaseModel):
  message: str


class OAuthLoginRequest(BaseModel):
  provider: OAuthProvider
  code: str
  codeVerifier: str
  redirectUri: str


class OAuthLoginResponse(BaseModel):
  token: str
  expiresIn: int
  user: UserResponse
  isNewUser: bool


# Group Schemas
class GroupBase(BaseModel):
  model_config = ConfigDict(str_strip_whitespace=True)
  name: str = Field(min_length=2, max_length=64)
  description: Optional[str] = Field(default=None, min_length=1, max_length=512)


class GroupCreate(GroupBase):
  pass


class GroupUpdate(BaseModel):
  model_config = ConfigDict(str_strip_whitespace=True)
  name: Optional[str] = Field(default=None, min_length=2, max_length=64)
  description: Optional[str] = Field(default=None, min_length=1, max_length=512)


class GroupResponse(BaseModel):
  model_config = ConfigDict(from_attributes=True)

  id: int
  name: str
  description: Optional[str] = None
  createdBy: Optional[int]
  updatedBy: Optional[int] = None
  createdAt: datetime
  updatedAt: datetime


# Resource Schemas
class ResourceResponse(BaseModel):
  model_config = ConfigDict(from_attributes=True)

  id: int
  path: str
  name: str
  description: Optional[str]
  createdAt: datetime
  updatedAt: datetime


# Group Permission Schemas
class GroupPermissionsCreate(RootModel[dict[str, PermissionType]]):
  root: dict[str, PermissionType]


class PermissionResponse(BaseModel):
  model_config = ConfigDict(from_attributes=True)

  id: int
  entityType: EntityType
  entityId: int
  resourcePattern: str
  description: Optional[str]
  type: PermissionType
  createdAt: datetime
  createdBy: Optional[int]
  updatedAt: Optional[datetime] = None
  updatedBy: Optional[int] = None


# User Permission Schemas
class UserPermissionsCreate(RootModel[dict[str, PermissionType]]):
  root: dict[str, PermissionType]


class UserPermissionsDelete(BaseModel):
  permissionIds: List[int]


class UserPermissionUpdate(BaseModel):
  resourceId: Optional[int] = None
  type: Optional[PermissionType] = None


class UserPermissionResponse(BaseModel):
  model_config = ConfigDict(from_attributes=True)

  id: int
  userId: int
  resourceId: int
  resource: Optional[ResourceResponse] = None
  type: PermissionType
  createdAt: datetime
  createdBy: Optional[int]
  updatedAt: datetime
  updatedBy: Optional[int] = None


# Add User to Group Request
class AddUserToGroupsRequest(BaseModel):
  groupIds: list[int]


class GroupPermissionsDelete(BaseModel):
  permissionIds: List[int]


class GroupPermissionUpdate(BaseModel):
  resourceId: Optional[int] = None
  type: Optional[PermissionType] = None


# Remove User from Groups Request
class RemoveUserFromGroupsRequest(BaseModel):
  groupIds: list[int]


# Add Users to Group Request
class AddUsersToGroupRequest(BaseModel):
  userIds: list[int]


# Remove Users from Group Request
class RemoveUsersFromGroupRequest(BaseModel):
  userIds: list[int]
