from datetime import datetime, timezone
from typing import List, Optional

from tortoise import fields
from ..schema import BaseModelWithAudit

class Resource(BaseModelWithAudit):
  """Resource model representing the resources table."""

  path = fields.CharField(max_length=500, unique=True)
  name = fields.CharField(max_length=255)
  description = fields.TextField(null=True)

  # Relationships
  permissions: fields.ReverseRelation["Permission"]

  class Meta:
    table = "resources"
    indexes = [("name",)]

  def __str__(self) -> str:
    return f"<Resource(id={self.id}, path='{self.path}', name='{self.name}')>"

  # CRUD Operations
  @classmethod
  async def create_resource(
    cls, path: str, name: str, description: Optional[str] = None, created_by: Optional[int] = None
  ) -> "Resource":
    """Create a new resource."""
    return await cls.create(path=path, name=name, description=description, created_by=created_by)

  @classmethod
  async def get_by_id(cls, resource_id: int) -> Optional["Resource"]:
    """Get a resource by ID."""
    return await cls.filter(id=resource_id, deleted_at=None).first()

  @classmethod
  async def get_by_path(cls, path: str) -> Optional["Resource"]:
    """Get a resource by path."""
    return await cls.filter(path=path, deleted_at=None).first()

  @classmethod
  async def get_all(cls, skip: int = 0, limit: int = 100) -> List["Resource"]:
    """Get all resources with pagination."""
    return await cls.filter(deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def search_by_name(cls, name_pattern: str, skip: int = 0, limit: int = 100) -> List["Resource"]:
    """Search resources by name pattern."""
    return await cls.filter(name__icontains=name_pattern, deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def search_by_path(cls, path_pattern: str, skip: int = 0, limit: int = 100) -> List["Resource"]:
    """Search resources by path pattern."""
    return await cls.filter(path__icontains=path_pattern, deleted_at=None).offset(skip).limit(limit)

  async def update_resource(self, **kwargs) -> "Resource":
    """Update resource fields."""
    for key, value in kwargs.items():
      if hasattr(self, key) and value is not None:
        setattr(self, key, value)
    await self.save()
    return self

  async def delete_resource(self) -> None:
    """Delete the resource."""
    self.deleted_at = datetime.now(timezone.utc)
    await self.save()

  @classmethod
  async def delete_by_id(cls, resource_id: int) -> bool:
    """Delete a resource by ID. Returns True if deleted."""
    deleted_count = await cls.filter(id=resource_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))
    return deleted_count > 0

  @classmethod
  async def count(cls) -> int:
    """Count total resources."""
    return await cls.filter(deleted_at=None).count()

  async def get_permissions(self) -> List["Permission"]:
    """Get all permissions for this resource."""
    return await self.permissions.all()


# Import at bottom to avoid circular imports
from .permission import Permission
