from datetime import datetime, timezone
from typing import List, Optional

from tortoise import fields
from ..schema import BaseModelWithAudit


class Permission(BaseModelWithAudit):
  """Permission model representing the permissions table for both user and group permissions."""

  entity_type = fields.CharField(max_length=50)  # 'user' or 'group'
  entity_id = fields.IntField()
  resource = fields.ForeignKeyField("models.Resource", related_name="permissions", on_delete=fields.CASCADE)
  type = fields.CharField(max_length=1)  # 'r', 'w', or 'd'

  class Meta:
    table = "permissions"
    unique_together = (("entity_type", "entity_id", "resource"),)
    indexes = [
      ("entity_type", "entity_id"),
      ("resource_id"),
    ]

  def __str__(self) -> str:
    return (
      f"<Permission(id={self.id}, entity_type='{self.entity_type}', "
      f"entity_id={self.entity_id}, resource_id={self.resource_id}, type='{self.type}')>"
    )

  # CRUD Operations
  @classmethod
  async def create_permission(
    cls, entity_type: str, entity_id: int, resource_id: int, type: str, created_by: Optional[int] = None
  ) -> "Permission":
    """Create a new permission."""
    return await cls.create(
      entity_type=entity_type,
      entity_id=entity_id,
      resource_id=resource_id,
      type=type,
      created_by=created_by,
    )

  @classmethod
  async def get_by_id(cls, permission_id: int) -> Optional["Permission"]:
    """Get a permission by ID."""
    return await cls.filter(id=permission_id, deleted_at=None).first()

  @classmethod
  async def get_all(cls, skip: int = 0, limit: int = 100) -> List["Permission"]:
    """Get all permissions with pagination."""
    return await cls.filter(deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def get_by_entity(cls, entity_type: str, entity_id: int) -> List["Permission"]:
    """Get all permissions for a specific entity (user or group)."""
    return await cls.filter(entity_type=entity_type, entity_id=entity_id, deleted_at=None).all()

  @classmethod
  async def get_user_permissions(cls, user_id: int) -> List["Permission"]:
    """Get all permissions for a user."""
    return await cls.get_by_entity("user", user_id)

  @classmethod
  async def get_group_permissions(cls, group_id: int) -> List["Permission"]:
    """Get all permissions for a group."""
    return await cls.get_by_entity("group", group_id)

  @classmethod
  async def get_by_resource(cls, resource_id: int) -> List["Permission"]:
    """Get all permissions for a resource."""
    return await cls.filter(resource_id=resource_id, deleted_at=None).all()

  @classmethod
  async def get_by_type(cls, permission_type: str, skip: int = 0, limit: int = 100) -> List["Permission"]:
    """Get permissions by type (r, w, d)."""
    return await cls.filter(type=permission_type, deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def check_permission(cls, entity_type: str, entity_id: int, resource_id: int, permission_type: str) -> bool:
    """Check if an entity has a specific permission on a resource."""
    permission = await cls.filter(
      entity_type=entity_type,
      entity_id=entity_id,
      resource_id=resource_id,
      type=permission_type,
      deleted_at=None,
    ).first()
    return permission is not None

  async def update_permission(self, **kwargs) -> "Permission":
    """Update permission fields."""
    for key, value in kwargs.items():
      if hasattr(self, key) and value is not None:
        setattr(self, key, value)
    await self.save()
    return self

  async def delete_permission(self) -> None:
    """Delete the permission."""
    self.deleted_at = datetime.now(timezone.utc)
    await self.save()

  @classmethod
  async def delete_by_id(cls, permission_id: int) -> bool:
    """Delete a permission by ID. Returns True if deleted."""
    deleted_count = await cls.filter(id=permission_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))
    return deleted_count > 0

  @classmethod
  async def delete_by_entity(cls, entity_type: str, entity_id: int) -> int:
    """Delete all permissions for a specific entity. Returns count of deleted permissions."""
    return await cls.filter(entity_type=entity_type, entity_id=entity_id, deleted_at=None).update(
      deleted_at=datetime.now(timezone.utc)
    )

  @classmethod
  async def delete_by_resource(cls, resource_id: int) -> int:
    """Delete all permissions for a resource. Returns count of deleted permissions."""
    return await cls.filter(resource_id=resource_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))

  @classmethod
  async def count(cls) -> int:
    """Count total permissions."""
    return await cls.filter(deleted_at=None).count()
