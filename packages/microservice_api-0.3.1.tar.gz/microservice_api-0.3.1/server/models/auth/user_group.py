from datetime import datetime, timezone
from typing import TYPE_CHECKING, List, Optional

from tortoise import fields
from ..schema import BaseModelWithAudit

if TYPE_CHECKING:
  from models.auth.group import Group
  from models.auth.user import User


class UserGroup(BaseModelWithAudit):
  """UserGroup model representing the user_groups junction table.

  Note: This model is primarily for direct access to the junction table.
  The many-to-many relationship is handled through User.groups field.
  """

  user: fields.ForeignKeyRelation["User"] = fields.ForeignKeyField(
    "models.User", related_name="user_group_entries", db_constraint=False
  )
  group: fields.ForeignKeyRelation["Group"] = fields.ForeignKeyField(
    "models.Group", related_name="group_user_entries", db_constraint=False
  )

  class Meta:
    table = "user_groups"
    unique_together = (("user_id", "group_id"),)
    indexes = [("user_id",), ("group_id",)]

  def __str__(self) -> str:
    return f"<UserGroup(user_id={self.user_id}, group_id={self.group_id})>"

  # CRUD Operations
  @classmethod
  async def add_user_to_group(cls, user_id: int, group_id: int, created_by: Optional[int] = None) -> "UserGroup":
    """Add a user to a group. Returns existing association if already exists."""
    existing = await cls.filter(user_id=user_id, group_id=group_id).first()
    if existing:
      if existing.deleted_at is not None:
        existing.deleted_at = None
        if created_by is not None:
          existing.updated_by = created_by
        await existing.save()
      return existing
    return await cls.create(user_id=user_id, group_id=group_id, created_by=created_by)

  @classmethod
  async def add_user_to_groups(cls, user_id: int, group_ids: List[int], created_by: Optional[int] = None) -> None:
    """Add a user to multiple groups."""
    for group_id in group_ids:
      existing = await cls.filter(user_id=user_id, group_id=group_id).first()
      if existing:
        if existing.deleted_at is not None:
          existing.deleted_at = None
          if created_by is not None:
            existing.updated_by = created_by
          await existing.save()
        continue
      await cls.create(user_id=user_id, group_id=group_id, created_by=created_by)

  @classmethod
  async def remove_user_from_group(cls, user_id: int, group_id: int) -> bool:
    """Remove a user from a group. Returns True if removed."""
    deleted_count = await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).update(
      deleted_at=datetime.now(timezone.utc)
    )
    return deleted_count > 0

  @classmethod
  async def remove_user_from_groups(cls, user_id: int, group_ids: List[int]) -> None:
    """Remove a user from multiple groups."""
    for group_id in group_ids:
      existing = await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).first()
      if not existing:
        continue
      await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).update(
        deleted_at=datetime.now(timezone.utc)
      )

  @classmethod
  async def get_user_group_ids(cls, user_id: int) -> List[int]:
    """Get all group IDs for a user."""
    associations = await cls.filter(user_id=user_id, deleted_at=None).all()
    return [assoc.group_id for assoc in associations]

  @classmethod
  async def get_group_user_ids(cls, group_id: int) -> List[int]:
    """Get all user IDs in a group."""
    associations = await cls.filter(group_id=group_id, deleted_at=None).all()
    return [assoc.user_id for assoc in associations]

  @classmethod
  async def is_user_in_group(cls, user_id: int, group_id: int) -> bool:
    """Check if a user is in a group."""
    result = await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).first()
    return result is not None

  @classmethod
  async def get_users_in_group(cls, group_id: int, skip: int = 0, limit: int = 100) -> List["UserGroup"]:
    """Get user-group associations for a specific group with pagination."""
    return await cls.filter(group=group_id, deleted_at=None).offset(skip).limit(limit).all()

  @classmethod
  async def get_all(cls, skip: int = 0, limit: int = 100) -> List["UserGroup"]:
    """Get all user-group associations with pagination."""
    return await cls.filter(deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def count_users_in_group(cls, group_id: int) -> int:
    """Count users in a group."""
    return await cls.filter(group=group_id, deleted_at=None).count()

  @classmethod
  async def count_groups_for_user(cls, user_id: int) -> int:
    """Count groups for a user."""
    return await cls.filter(user=user_id, deleted_at=None).count()

  @classmethod
  async def remove_all_users_from_group(cls, group_id: int) -> int:
    """Remove all users from a group. Returns count of removed associations."""
    return await cls.filter(group=group_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))

  @classmethod
  async def remove_user_from_all_groups(cls, user_id: int) -> int:
    """Remove a user from all groups. Returns count of removed associations."""
    return await cls.filter(user=user_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))

  @classmethod
  async def add_users_to_group(cls, group_id: int, user_ids: List[int], created_by: Optional[int] = None) -> None:
    """Add multiple users to a group."""
    for user_id in user_ids:
      existing = await cls.filter(user_id=user_id, group_id=group_id).first()
      if existing:
        if existing.deleted_at is not None:
          existing.deleted_at = None
          if created_by is not None:
            existing.updated_by = created_by
          await existing.save()
        continue
      await cls.create(user_id=user_id, group_id=group_id, created_by=created_by)

  @classmethod
  async def remove_users_from_group(cls, group_id: int, user_ids: List[int]) -> None:
    """Remove multiple users from a group."""
    for user_id in user_ids:
      existing = await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).first()
      if not existing:
        continue
      await cls.filter(user_id=user_id, group_id=group_id, deleted_at=None).update(
        deleted_at=datetime.now(timezone.utc)
      )
