from datetime import datetime, timezone
from typing import List, Optional

from tortoise import fields
from tortoise.models import Model

from ..schema import BaseModelWithAudit


class Group(BaseModelWithAudit):
  """Group model representing the groups table."""

  name = fields.CharField(max_length=255, unique=True)
  description = fields.TextField(null=True)

  # Relationships (reverse side of ManyToMany defined in User)
  users: fields.ManyToManyRelation["User"]

  class Meta:
    table = "groups"
    indexes = [("name",)]

  def __str__(self) -> str:
    return f"<Group(id={self.id}, name='{self.name}')>"

  # CRUD Operations
  @classmethod
  async def create_group(
    cls, name: str, description: Optional[str] = None, created_by: Optional[int] = None
  ) -> "Group":
    """Create a new group."""
    return await cls.create(name=name, description=description, created_by=created_by)

  @classmethod
  async def get_by_id(cls, group_id: int) -> Optional["Group"]:
    """Get a group by ID."""
    return await cls.filter(id=group_id, deleted_at=None).first()

  @classmethod
  async def get_by_name(cls, name: str) -> Optional["Group"]:
    """Get a group by name."""
    return await cls.filter(name=name, deleted_at=None).first()

  @classmethod
  async def get_all(cls, skip: int = 0, limit: int = 100) -> List["Group"]:
    """Get all groups with pagination."""
    return await cls.filter(deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def search_by_name(cls, name_pattern: str, skip: int = 0, limit: int = 100) -> List["Group"]:
    """Search groups by name pattern."""
    return await cls.filter(name__icontains=name_pattern, deleted_at=None).offset(skip).limit(limit)

  async def update_group(self, **kwargs) -> "Group":
    """Update group fields."""
    for key, value in kwargs.items():
      if hasattr(self, key) and value is not None:
        setattr(self, key, value)
    await self.save()
    return self

  async def delete_group(self) -> None:
    """Delete the group."""
    self.deleted_at = datetime.now(timezone.utc)
    await self.save()

  @classmethod
  async def delete_by_id(cls, group_id: int) -> bool:
    """Delete a group by ID. Returns True if deleted."""
    deleted_count = await cls.filter(id=group_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))
    return deleted_count > 0

  @classmethod
  async def count(cls) -> int:
    """Count total groups."""
    return await cls.filter(deleted_at=None).count()

  async def get_users(self) -> List["User"]:
    """Get all users in this group."""
    return await self.users.filter(deleted_at=None).all()

  async def add_user(self, user: "User") -> None:
    """Add a user to this group."""
    from .user_group import UserGroup

    await UserGroup.add_user_to_group(user.id, self.id)

  async def remove_user(self, user: "User") -> None:
    """Remove a user from this group."""
    from .user_group import UserGroup

    await UserGroup.remove_user_from_group(user.id, self.id)


# Import at bottom to avoid circular imports
from .user import User
