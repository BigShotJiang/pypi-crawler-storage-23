"""Resource pack implementations."""
