"""JustMyResource - Resource discovery and resolution library."""

from justmyresource.core import ResourceRegistry, get_default_registry
from justmyresource.pack_utils import ZippedResourcePack
from justmyresource.types import (
    PackInfo,
    PrefixCollisionWarning,
    RegisteredPack,
    ResourceContent,
    ResourceInfo,
    ResourcePack,
)

__version__ = "0.2.0.dev0"

__all__ = [
    "PackInfo",
    "PrefixCollisionWarning",
    "RegisteredPack",
    "ResourceContent",
    "ResourceInfo",
    "ResourcePack",
    "ResourceRegistry",
    "ZippedResourcePack",
    "get_default_registry",
]
