#!/usr/bin/python
# coding: utf-8
from vector_mcp.mcp import mcp_server

if __name__ == "__main__":
    mcp_server()
