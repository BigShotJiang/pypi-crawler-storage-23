


class PlotNodeSolution:
    def __init__(self, dofs):
        pass
    pass
