

from xsection.library import * 


class ShellShape:
    def __init__(self, thickness, group=None, n: int = None):
        self.thickness = thickness
        self.group = group
        self.n = n



class CompositeShell:
    def __init__(self, shapes):
        pass

