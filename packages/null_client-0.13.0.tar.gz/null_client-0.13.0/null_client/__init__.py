"""
null-client: Python client for the null content-addressable storage system.
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("null-client")
except PackageNotFoundError:
    __version__ = "unknown"

from null_client._chunker import (
    Chunk,
    ChunkIterator,
    chunk_file,
    MIN_CHUNK_SIZE,
    AVG_CHUNK_SIZE,
    MAX_CHUNK_SIZE,
    MAX_TREE_ENTRIES,
)

from .backup import backup_file
from .client import (
    AndExpr,
    BatchBlobResult,
    BatchBlobStatus,
    BatchBlobsResponse,
    BlobNotFoundError,
    Client,
    CreatedAtFilter,
    Hash,
    created_at,
    MetadataFilter,
    NotExpr,
    OrExpr,
    SortBy,
    SortOrder,
    SortTiebreaker,
    ListRecordsResponse,
    RecordResponse,
    NullClientError,
    RecordConflictError,
    RecordAlreadyDeletedError,
)

__all__ = [
    "__version__",
    # From Rust extension
    "Chunk",
    "ChunkIterator",
    "chunk_file",
    "MIN_CHUNK_SIZE",
    "AVG_CHUNK_SIZE",
    "MAX_CHUNK_SIZE",
    "MAX_TREE_ENTRIES",
    # Python API
    "backup_file",
    "AndExpr",
    "BatchBlobResult",
    "BatchBlobStatus",
    "BatchBlobsResponse",
    "Client",
    "CreatedAtFilter",
    "Hash",
    "created_at",
    "MetadataFilter",
    "NotExpr",
    "OrExpr",
    "SortBy",
    "SortOrder",
    "SortTiebreaker",
    "ListRecordsResponse",
    "RecordResponse",
    # Exceptions
    "BlobNotFoundError",
    "NullClientError",
    "RecordConflictError",
    "RecordAlreadyDeletedError",
]
