import socket
from pathlib import Path

from null_client._chunker import chunk_file, MAX_TREE_ENTRIES

from .client import Client, RecordResponse, Hash


def _build_tree_from_hashes(client: Client, hashes: list[Hash]) -> Hash:
    if not hashes:
        raise ValueError("Cannot create tree from empty hash list")

    if len(hashes) <= MAX_TREE_ENTRIES:
        return client.create_tree(hashes).hash

    # Split into subtrees
    subtree_hashes: list[Hash] = []
    for i in range(0, len(hashes), MAX_TREE_ENTRIES):
        batch = hashes[i : i + MAX_TREE_ENTRIES]
        subtree_hashes.append(client.create_tree(batch).hash)

    # Recursively build parent tree
    return _build_tree_from_hashes(client, subtree_hashes)


def backup_file(
    path: str | Path,
    base_url: str = "http://localhost:3001",
    namespace: str | None = None,
) -> RecordResponse:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    absolute_path = path.resolve()
    file_size = path.stat().st_size

    with Client(base_url) as client:
        current_batch: list[Hash] = []
        tree_hashes: list[Hash] = []

        # Stream chunks from file using Rust chunker
        for chunk in chunk_file(str(path)):
            chunk_hash = client.put_blob(chunk.data)

            current_batch.append(chunk_hash)

            if len(current_batch) >= MAX_TREE_ENTRIES:
                tree_hash = client.create_tree(current_batch).hash
                tree_hashes.append(tree_hash)
                current_batch = []

        # Handle remaining chunks
        if current_batch:
            tree_hash = client.create_tree(current_batch).hash
            tree_hashes.append(tree_hash)

        # Build final tree
        if not tree_hashes:
            raise ValueError("No chunks in file")

        if len(tree_hashes) == 1:
            root_hash = tree_hashes[0]
        else:
            root_hash = _build_tree_from_hashes(client, tree_hashes)

        metadata = {
            "path": str(absolute_path),
            "size": file_size,
            "hostname": socket.gethostname(),
        }
        record = client.create_record(
            kind="file",
            content=root_hash,
            metadata=metadata,
            namespace=namespace,
        )

        return record
