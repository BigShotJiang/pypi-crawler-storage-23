from dechromium._cli import main

main()
