"""Annotator based on Facebook Duckling"""

__version__ = "0.6.13"
