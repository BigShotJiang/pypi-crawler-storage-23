# Migration to Python 3.12, Pydantic v2, and uv tooling

This document describes the migration steps performed on the `pyannotators_duckling` project.

## 1. Build system: flit → hatchling/uv

The build system was migrated from **flit** to **hatchling** with **uv** as the package manager.

- `pyproject.toml`: changed `build-system` to use `hatchling`
- Replaced `flit` commands with `uv build` and `uv publish`
- Jenkinsfile updated to use `uv pip install` and `uv build`/`uv publish`

## 2. Python version: 3.8+ → 3.12

- `requires-python` set to `>=3.12` in `pyproject.toml`
- `Dockerfile` updated to use Python 3.12 base image
- Classifiers updated accordingly

## 3. Pydantic v1 → v2

- Updated `pydantic` dependency to `>=2.0,<3.0`
- Replaced deprecated Pydantic v1 APIs:
  - `root_validator(pre=True)` → `model_validator(mode="before")` + `@classmethod`
  - `Field(..., extra="value")` → `Field(..., json_schema_extra={"extra": "value"})`
  - `.dict()` → `.model_dump()`
  - `.construct()` → `.model_construct()`
  - `Optional[X]` → `X | None` (PEP 604)

## 4. Python 3.12 type modernization

Leveraged Python 3.12 builtins and modern syntax (enforced by ruff `UP` rules):

- `str(Enum)` → `StrEnum` (from `enum` module, Python 3.11+)
- `typing.List[X]` → `list[X]` (PEP 585 builtin generics)
- `typing.Dict[K, V]` → `dict[K, V]`
- `typing.Type[X]` → `type[X]`
- `typing.Optional[X]` → `X | None` (PEP 604)
- Removed unused imports from `typing` (`List`, `Dict`, `Type`, `Optional`)

## 5. Linter: black + flake8 → ruff

- Removed `black` and `flake8` dependencies
- Added `ruff` to test dependencies
- Configured `[tool.ruff]` in `pyproject.toml`:
  - `line-length = 120`
  - `target-version = "py312"`
  - Lint rules: `E`, `W`, `F`, `I`, `B`, `C4`, `UP`, `ARG`, `SIM`
  - Format: double quotes, space indent

### Running the linter

```
uv run ruff check .
uv run ruff format --check .
```

To auto-fix formatting:

```
uv run ruff format .
```

## 6. Test runner: tox → uv

**tox** was removed entirely. The project now uses `uv run` to execute tests, linting, and doc generation directly.

### What changed

- Deleted `tox.ini`
- Removed `tox` from `[project.optional-dependencies].test`
- Moved pytest configuration from `tox.ini` to `pyproject.toml`:

```toml
[tool.pytest.ini_options]
addopts = "--durations=5"
norecursedirs = ["docs"]
```

### Running tests

```
uv run pytest
```

### Why tox was unnecessary

- The project targets a single Python version (3.12)
- The Jenkinsfile CI pipeline was already using `uv`, `ruff`, and `pytest` directly, not tox
- `uv run` provides virtual environment isolation without the extra layer

## 7. Documentation generation

Sphinx is used for documentation with the `docs` optional dependency group.

### Fix: added `lxml_html_clean` dependency

The `jupyter_sphinx` extension requires `lxml_html_clean` (split from `lxml` in recent versions). This was added to `[project.optional-dependencies].docs`.

### Generating docs

```
uv run --extra docs sphinx-build docs docs/_build
```

## 8. Jenkinsfile updates

- `__init__.py` generation now includes a blank line between the docstring and `__version__` to comply with `ruff format`
- Build/publish pipeline uses `uv build` and `uv publish`

## 9. .gitignore updates

Added the following entries:
- `uv.lock` — generated lock file, not committed
- `docs/_build/` — generated documentation output

## 10. Dependency fixes

### Replaced `pyduckling-native` with `pyduckling-native-phihos`

`pyduckling-native==0.1.0` uses a Cargo.toml format removed in maturin 0.14.0
(`classifier`, `requires-dist` fields in `[package.metadata.maturin]`), causing
the build to fail. `pyduckling-native-phihos` is a compatible fork that builds
correctly with current maturin versions.

### Bumped `pymultirole-plugins` to `>=0.6.0`

Version `0.5.x` of `pymultirole-plugins` was written against Pydantic v1 and uses
`__root__` root models and old `Field` extra syntax, which Pydantic v2 rejects with:

```
TypeError: To define root models, use `pydantic.RootModel` rather than a field called '__root__'
```

Version `>=0.6.0` is the Pydantic v2-compatible release.

### Removed stdlib `parser` import

`from parser import ParserError` referenced the Python stdlib `parser` module
(removed in Python 3.12). The exception was used as a catch-all in
`normalize_time_value()`. Replaced with `except ValueError:`, which is the
exception pendulum raises for invalid datetime strings.

## 11. Jenkinsfile fixes

### `uv sync` instead of `uv pip install --system`

The original install step used `uv pip install --system -e ".[test]"`, which
installs packages into the system Python. However, `uv run` uses the project's
`.venv`, which remained empty, causing `ModuleNotFoundError: No module named 'dirty_equals'`
at test collection time. Fixed by switching to:

```sh
uv sync --extra test
```

This creates and populates `.venv` with all project and test dependencies before
`uv run pytest` is called.

### Credentials: keep reading `FLIT_*` keys from `.passwd-pypi`

The server-side `.passwd-pypi` credential file still uses `FLIT_USERNAME` and
`FLIT_PASSWORD` key names. The Jenkinsfile helper functions were updated to keep
reading those keys, while exposing the values as `UV_PUBLISH_USERNAME` and
`UV_PUBLISH_PASSWORD` for `uv publish`.
