"""CLI interface for sutras management."""

from sutras.cli.main import cli

__all__ = ["cli"]
