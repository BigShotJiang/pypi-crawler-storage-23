"""Data models for NanoWiki using Pydantic."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class WikiPage(BaseModel):
    """A wiki page."""

    title: str = Field(description="Page title")
    content: str = Field(description="Markdown content")
    path: str = Field(description="Relative path from wiki root (e.g., 'overview.md')")
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
