import{ap as o,aq as n}from"./index-B1c7f9B3.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
