import{b as r}from"./graph-Be2AIA91.js";var e=4;function a(o){return r(o,e)}export{a as c};
