我要实现一个基于Claude agent sdk 的 cli 工具。它接受一个Project路径，使用agent分析该项目并在项目路径下生成一个.wiki文件夹，里面存放markdown格式的分析结果，包括：
- 项目的 Overview
    - 项目介绍
    - Architecture Layers
    - Core Systems Overview
    - 子系统介绍（如果有）
- 架构文档
- 模块/子系统功能文档
- 其他根据项目本身生成的wiki文档
使用 `mermaid` 辅助表达模块/子系统间的耦合关系，数据流或关键函数调用栈

然后提供一个子命令，该命令读取.wiki中的markdown渲染成wiki网站页面，并且提供一个对话UI，用户可以向Agent询问关于该项目的问题。.wiki文件只在首次分析改项目时保存分析结果，之后再载入该项目时应该直接读取.wiki文件夹。

我给这个cli工具取名为nanowiki，它可以帮助新参与目标项目的开发者快速了解目标项目，或帮助用户学习目标项目的一些思想、算法或功能实现方法。

- 使用 uv pip 来代替 pip
- 使用 pnpm 来代替 npm
