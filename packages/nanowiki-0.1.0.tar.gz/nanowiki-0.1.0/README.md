# NanoWiki

AI-powered project documentation generator using Claude Agent SDK.

## Features

- 🔍 **Intelligent Analysis**: Uses AI to analyze project structure, modules, and dependencies
- 📝 **Wiki Generation**: Automatically generates markdown documentation with Mermaid diagrams
- 🚀 **Web Interface**: Browse your wiki with a clean web interface
- 💬 **Q&A Chat**: Ask questions about your project with AI assistance
- ⚡ **Caching**: Fast subsequent loads with smart caching
- 🌐 **Multi-Language**: Supports projects in any programming language

## Installation

### From PyPI (Recommended)

```bash
pip install nanowiki
```

Or with uv:

```bash
uv pip install nanowiki
```

### From Source

```bash
# Clone the repository
git clone https://github.com/vtuber-plan/NanoWiki.git
cd nanowiki

# Install with uv
uv sync
```

## Usage

### Analyze a Project

Generate wiki documentation for any project:

```bash
nanowiki analyze ./my-project
```

This creates a `.wiki` folder in your project with:

- `overview.md` - Main overview page
- `architecture.md` - Architecture diagrams
- `dependencies.md` - Module dependency graphs
- `modules/` - Per-module documentation

Options:
- `--force, -f` - Re-analyze even if .wiki exists
- `--output, -o` - Custom output directory

### Serve the Wiki

Start the web server to browse your wiki:

```bash
nanowiki serve ./my-project
```

Options:
- `--host, -h` - Host to bind to (default: 127.0.0.1)
- `--port, -p` - Port to bind to (default: 8000)
- `--reload` - Enable auto-reload on file changes

Then open http://localhost:8000 in your browser.

## What Gets Generated

### Project Overview
- Project statistics (files, lines of code)
- Programming languages used
- Directory structure

### Architecture Diagrams
- Layer architecture using Mermaid
- Design patterns detected
- Entry points identified

### Module Documentation
- Purpose and description
- Files and their types
- Functions with parameters and return types
- Classes with inheritance
- Source references with line numbers

### Dependency Graphs
- Module-level dependencies
- Visual dependency diagrams

## Example

```bash
# Analyze a Python project
nanowiki analyze ~/projects/my-flask-app

# Serve the wiki
nanowiki serve ~/projects/my-flask-app

# Open in browser
open http://localhost:8000
```

## Development

```bash
# Install development dependencies
uv sync --group dev

# Run tests
uv run pytest

# Lint code
uv run ruff check src/
uv run mypy src/
```

## Requirements

- Python 3.10+
- Anthropic API key (set `ANTHROPIC_API_KEY` environment variable)

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
