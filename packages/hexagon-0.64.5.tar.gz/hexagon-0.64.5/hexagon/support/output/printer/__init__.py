from hexagon.support.output.printer.i18n import install
from hexagon.support.output.printer.logger import Logger

log = Logger("default")

install()
