from hexagon.support.input.prompt.prompt import Prompt

prompt = Prompt()
