import json

import requests


# ===================== Envios por wpp Propietario ===============================
def sends_template_wpp_1(phone: str):
    #phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes_5_prop", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


def sends_template_wpp_2(phone: str):
    #phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes_6_prop", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


# ===================== Envios por wpp Inquilino ===============================


def sends_template_inq_wpp_month_2(phone: str):
    #phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes2_inq", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json", "Cookie": "ASP.NET_SessionId=nh4gbaec3zfvckiapf3sw1hu"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


def sends_template_inq_wpp_month_4(phone: str):
    #phone = "573103555742"

    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes4_inq", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json", "Cookie": "ASP.NET_SessionId=l4fylvswc2qyg0zwfquowldf"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


def sends_template_inq_wpp_month_8(phone: str):
    #phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes8_inq", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json", "Cookie": "ASP.NET_SessionId=nh4gbaec3zfvckiapf3sw1hu"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


def sends_template_inq_wpp_month_10(phone: str):
    #phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes10_inq", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json", "Cookie": "ASP.NET_SessionId=nh4gbaec3zfvckiapf3sw1hu"}

    response = requests.request("GET", url, headers=headers, data=payload)
    return {"status_code": response.status_code, "shipping_summary": response.text}
