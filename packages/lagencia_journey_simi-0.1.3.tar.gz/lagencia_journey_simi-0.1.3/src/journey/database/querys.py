from pathlib import Path
from typing import List, Optional

from sqlalchemy import select

from journey.database.config_db import get_session_empatia
from journey.database.models import EmailTemplateJouneySimi, ShipmentJorneySimiInquilino, ShipmentJorneySimiPropietario


def create_email_template_from_path(file_path: Path, name: Optional[str] = None) -> EmailTemplateJouneySimi:
    """
    Lee un archivo HTML desde `path` y lo guarda en la tabla email_templates.

    :param path: Ruta al archivo HTML.
    :param name: Nombre lógico de la plantilla.
                 Si es None, se usa el nombre del archivo sin extensión.
    :return: La instancia de ShipmentJorneySimiPropietario creada.
    """

    if not file_path.exists():
        raise FileNotFoundError(f"El archivo no existe: {file_path}")

    # Leer el contenido HTML
    html_body = file_path.read_text(encoding="utf-8")

    # Si no se pasa name, tomamos el nombre del archivo sin extensión
    if name is None:
        name = file_path.stem  # p.ej., "testimonios_vc.html" -> "testimonios_vc"

    template = EmailTemplateJouneySimi(name=name, html_body=html_body)

    with get_session_empatia() as session:
        session.add(template)
        session.flush()  # para que se genere el id antes de salir, si lo necesitas

        # Aquí template.id ya está disponible
        return template


# template_name = "servicio_diferencial.html"
# path_template = Path("src/orion") / "journey" / "journey_villacruz" / "templates_gmail" / template_name
# create_email_template_from_path(path_template, "servicio_diferencial")

# template_name = "esto_dicen_de_nosotros.html"
# path_template = Path("src/orion") / "journey" / "journey_villacruz" / "templates_gmail" / template_name
# create_email_template_from_path(path_template, template_name)


# template_name = "invitacion_seccion_nosotros.html"
# path_template = Path("src/orion") / "journey" / "journey_villacruz" / "templates_gmail" / template_name
# create_email_template_from_path(path_template, template_name)


def select_template_from_email_for_table(name: Optional[str] = None) -> EmailTemplateJouneySimi:
    """
    Lee un archivo HTML desde `path` y lo guarda en la tabla email_templates.

    :param path: Ruta al archivo HTML.
    :param name: Nombre lógico de la plantilla.
                 Si es None, se usa el nombre del archivo sin extensión.
    :return: La instancia de ShipmentJorneySimiPropietario creada.
    """

    with get_session_empatia() as session:
        stmt = select(EmailTemplateJouneySimi).where(EmailTemplateJouneySimi.name == name)
        result = session.scalars(stmt).first()
        return result


# template_name = "invitacion_seccion_nosotros.html"
# print(select_email_template_table(template_name).html_body)
# ============================================================================
# +++  querys para las tablas de registros de envios



def select_record_shipment_propietario(contrato: int) -> ShipmentJorneySimiPropietario:
    with get_session_empatia() as session:
        stmt = select(ShipmentJorneySimiPropietario).where(ShipmentJorneySimiPropietario.contrato == contrato)
        result = session.scalars(statement=stmt).first()
        return result


def get_list_of_templates_sent(contrato: int) -> List[str]:
    with get_session_empatia() as session:
        stmt = select(ShipmentJorneySimiPropietario).where(ShipmentJorneySimiPropietario.contrato == contrato)
        result = session.scalars(statement=stmt).first()
        return result.list_of_templates_sent if result else []


def get_last_month_load(contrato: int) -> int:
    with get_session_empatia() as session:
        stmt = select(ShipmentJorneySimiPropietario).where(ShipmentJorneySimiPropietario.contrato == contrato)
        result = session.scalars(statement=stmt).first()
        return result.month if result else 0


def upsert_record_shipment_propietario(record: ShipmentJorneySimiPropietario):
    with get_session_empatia() as session:
        result = session.merge(record)
        return result


# ===========================================================
def select_record_shipment_inquilino(contrato: int) -> ShipmentJorneySimiInquilino:
    with get_session_empatia() as session:
        stmt = select(ShipmentJorneySimiInquilino).where(ShipmentJorneySimiInquilino.contrato == contrato)
        result = session.scalars(statement=stmt).first()
        return result

def upsert_record_shipment_inquilino(record: ShipmentJorneySimiInquilino):
    with get_session_empatia() as session:
        result = session.merge(record)
        return result
