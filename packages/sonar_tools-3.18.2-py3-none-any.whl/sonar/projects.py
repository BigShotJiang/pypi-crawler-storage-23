#
# sonar-tools
# Copyright (C) 2019-2026 Olivier Korach
# mailto:olivier.korach AT gmail DOT com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
"""Abstraction of the SonarQube "project" concept"""

from __future__ import annotations
from typing import Optional, Union, Any, TYPE_CHECKING
from types import MappingProxyType

import os
import re
import json
import concurrent.futures
from datetime import datetime
import traceback

from http import HTTPStatus
from requests import HTTPError, RequestException

import sonar.logging as log
from sonar.components import Component
import sonar.util.issue_defs as idefs
from sonar.util import cache
from sonar import exceptions
from sonar import qualityprofiles, settings, webhooks, devops
from sonar import qualitygates as qg
from sonar import pull_requests, branches
import sonar.util.misc as util
import sonar.permissions.project_permissions as pperms
import sonar.utilities as sutil

from sonar.audit import severities
from sonar.audit.rules import get_rule, RuleId
from sonar.audit.problem import Problem
import sonar.util.constants as c
import sonar.util.project_helper as phelp
from sonar.api.manager import ApiOperation as Oper
from sonar import measures

if TYPE_CHECKING:
    from sonar.tasks import Task
    from sonar.branches import Branch
    from sonar.pull_requests import PullRequest
    from sonar.issues import Issue
    from sonar.hotspots import Hotspot
    from sonar.platform import Platform
    from sonar.util.types import ApiParams, ApiPayload, ConfigSettings, KeyList, ObjectJsonRepr, PermissionDef

MAX_PAGE_SIZE = 500
_TREE_API = "components/tree"
_CONTAINS_AI_CODE = "containsAiCode"
_BIND_SEP = ":::"
_AUDIT_BRANCHES_PARAM = "audit.projects.branches"

ZIP_ZERO_LOC = "ZERO_LOC"
ZIP_ASYNC_SUCCESS = "ASYNC_SUCCESS"
ZIP_ERR_403 = "FAILED/INSUFFICIENT_PERMISSIONS"
ZIP_CONFLICT = "FAILED/ZIP_CONFLICT"
ZIP_PROJ_EXISTS = "FAILED/PROJECT_ALREADY_EXISTS"
ZIP_TIMEOUT = "FAILED/TIMEOUT"
ZIP_EXCEPTION = "FAILED/EXCEPTION"

_IMPORTABLE_PROPERTIES = (
    "key",
    "name",
    settings.NEW_CODE_PERIOD,
    "qualityGate",
    "qualityProfiles",
    "branches",
    "binding",
    "visibility",
    "permissions",
    "tags",
    "webhooks",
    "links",
    phelp.AI_CODE_FIX,
)

_PREDEFINED_LINKS = ("homepage", "scm", "issue")


class Project(Component):
    """Abstraction of the SonarQube project concept"""

    CACHE = cache.Cache()
    __PROJECT_FILTER = MappingProxyType({"filter": "qualifier=TRK"})

    def __init__(self, endpoint: Platform, data: ApiPayload) -> None:
        """
        :param Platform endpoint: Reference to the SonarQube platform
        :param str key: The project key
        """
        super().__init__(endpoint, data)
        self._branches_last_analysis: Optional[datetime] = None
        self._permissions: Optional[object] = None
        self._branches: Optional[dict[str, Branch]] = None
        self._pull_requests: Optional[dict[str, PullRequest]] = None
        self._ncloc_with_branches: Optional[int] = None
        self._binding: Optional[dict[str, str]] = None
        self._new_code: Optional[str] = None
        self._ci: Optional[str] = None
        self._revision: Optional[str] = None
        self.__class__.CACHE.put(self)
        self.reload(data)
        log.debug("Constructed object %s", self)

    def __str__(self) -> str:
        """Returns the string representation of the project"""
        return f"project '{self.key}'"

    @classmethod
    def get_object(cls, endpoint: Platform, key: str, use_cache: bool = True) -> Project:
        """Returns the project object from its project key"""
        o: Optional[Project] = cls.CACHE.get(endpoint.local_url, key)
        if use_cache and o:
            return o
        api, _, params, ret = endpoint.api.get_details(cls, Oper.GET, component=key)
        data = json.loads(endpoint.get(api, params=params).text)[ret]
        return o.reload(data) if o else cls.load(endpoint, data)

    @classmethod
    def create(cls, endpoint: Platform, key: str, name: str) -> Project:
        """Creates a Project object after creating it in SonarQube

        :param Platform endpoint: Reference to the SonarQube platform
        :param str key: Project key to create
        :param str name: Project name
        :return: The Project
        :rtype: Project
        """
        api, _, params, _ = endpoint.api.get_details(Project, Oper.CREATE, project=key, name=name)
        endpoint.post(api, params=params)
        o = cls.get_object(endpoint, key, use_cache=False)
        return o.refresh()

    @classmethod
    def search(cls, endpoint: Platform, threads: int = 8, use_cache: bool = False, **search_params: Any) -> dict[str, Project]:
        """Searches projects in SonarQube

        :param endpoint: Reference to the SonarQube platform
        :param params: list of parameters to narrow down the search
        :param threads: number of parallel threads to use for search
        :param use_cache: whether to use local cache or query SonarQube, default True (use cache)
        :returns: list of projects
        """
        if use_cache and len(search_params) == 0 and len(cls.CACHE.from_platform(endpoint)) > 0:
            return dict(sorted(cls.CACHE.from_platform(endpoint).items()))
        if not endpoint.is_sonarcloud():
            search_params |= cls.__PROJECT_FILTER
        return dict(sorted(cls.get_paginated(endpoint=endpoint, params=search_params, threads=threads).items()))

    @classmethod
    def count(cls, endpoint: Platform, **search_params: Any) -> int:
        """Counts projects"""
        proj_filter = {} if endpoint.is_sonarcloud() else cls.__PROJECT_FILTER
        return super().count(endpoint, **(search_params | proj_filter))

    @staticmethod
    def get_project_key(project: Union[str, Project]) -> str:
        """Loads a list of branches from a dataset"""
        if isinstance(project, str):
            return project
        return project.key

    @classmethod
    def get_project_object(cls, endpoint: Platform, project: Union[str, Project]) -> Project:
        """Loads a list of branches from a dataset"""
        if not isinstance(project, str):
            return project
        return cls.get_object(endpoint, project, use_cache=True)

    def reload(self, data: ApiPayload) -> Project:
        """Reloads a project with JSON data coming from api/components/search request

        :param dict data: Data to load
        :return: self
        """
        """Loads a project object with contents of an api/projects/search call"""
        super().reload(data)
        self.name = data["name"]
        self._visibility = data["visibility"]
        self._revision = data.get("revision", self._revision)
        return self

    def last_analysis(self, include_branches: bool = False) -> Optional[datetime]:
        """
        :param include_branches: Take into account branch to determine last analysis, defaults to False
        :type include_branches: bool, optional
        :returns: Project last analysis date or None if never analyzed
        """
        if not self._last_analysis:
            self.get_navigation_data()
        if not include_branches:
            return self._last_analysis
        if self._branches_last_analysis:
            return self._branches_last_analysis

        self._branches_last_analysis = self._last_analysis
        return self._branches_last_analysis

    def loc(self) -> int:
        """
        :return: Number of LoCs of the project, taking into account branches and pull requests, if any
        :rtype: int
        """
        if self._ncloc_with_branches is not None:
            return self._ncloc_with_branches
        if self.endpoint.edition() == c.CE:
            self._ncloc_with_branches = super().loc()
        else:
            self._ncloc_with_branches = max(b.loc() for b in list(self.branches().values()) + list(self.pull_requests().values()))
        return self._ncloc_with_branches

    def branches(self, use_cache: bool = True) -> dict[str, Branch]:
        """
        :return: Dict of branches of the project
        :param use_cache: Whether to use local cache or query SonarQube, default True (use cache)
        :type use_cache: bool
        :rtype: dict{<branchName>: <Branch>}
        """
        if not self._branches or not use_cache:
            try:
                self._branches = branches.Branch.search(self.endpoint, self)
            except exceptions.UnsupportedOperation:
                self._branches = {}
        return self._branches

    def main_branch_name(self) -> str:
        """
        :return: Project main branch name
        """
        if self.endpoint.edition() == c.CE:
            return self.sq_json.get("branch", "main")
        b = self.main_branch()
        return b.name if b else ""

    def main_branch(self) -> Optional[Branch]:
        """
        :return: Main branch of the project
        """
        if self.endpoint.edition() == c.CE:
            raise exceptions.UnsupportedOperation("Main branch is not supported in Community Edition")
        try:
            return next(b for b in self.branches().values() if b.is_main())
        except StopIteration:
            log.warning("Could not find main branch for %s", str(self))
        return None

    def pull_requests(self, use_cache: bool = True) -> dict[str, PullRequest]:
        """
        :return: List of pull requests of the project
        :param use_cache: Whether to use local cache or query SonarQube, default True (use cache)
        :type use_cache: bool
        :rtype: dict{PR_ID: PullRequest}
        """
        if self._pull_requests is None or not use_cache:
            self._pull_requests = pull_requests.PullRequest.search(self.endpoint, project=self)
        return self._pull_requests

    def delete(self) -> bool:
        """Deletes a project in SonarQube

        :raises ObjectNotFound: If object to delete was not found in SonarQube
        :raises request.HTTPError: In all other cases of HTTP Errors
        :return: Whether the operation succeeded
        """
        loc = int(self.get_measure("ncloc", fallback="0"))
        log.info("Deleting %s, name '%s' with %d LoCs", str(self), self.name, loc)
        return self.delete_object(project=self.key)

    def has_binding(self) -> bool:
        """Whether the project has a DevOps platform binding"""
        if not self._binding:
            self.binding()
        return self._binding.get("has_binding", False)

    def binding(self) -> Optional[dict[str, Any]]:
        """
        :return: The project DevOps platform binding
        :rtype: dict
        """
        if not self._binding:
            try:
                resp = self.get("alm_settings/get_binding", params={"project": self.key}, mute=(HTTPStatus.NOT_FOUND,))
                self._binding = {"has_binding": True, "binding": json.loads(resp.text)}
                self._binding["binding"].pop("repositoryUrl", None)
                if self._binding["binding"]["alm"] == devops.DEVOPS_AZURE:
                    self._binding["binding"]["projectName"] = self._binding["binding"].pop("slug")
                self._binding["binding"] = util.order_keys(self._binding["binding"], "key", "repository", "slug", "projectName", "monorepo")
            except exceptions.SonarException:
                # Hack: 8.9 returns 404, 9.x returns 400
                self._binding = {"has_binding": False}
        log.debug("%s binding = %s", str(self), str(self._binding.get("binding", None)))
        return self._binding.get("binding")

    def binding_key(self) -> Optional[str]:
        """Computes a unique project binding key"""
        if not self.has_binding():
            return None
        p_bind = self.binding()
        log.debug("%s binding_key = %s", str(self), str(p_bind))
        key = f'{p_bind["alm"]}{_BIND_SEP}{p_bind["repository"]}'
        if p_bind["alm"] == devops.DEVOPS_BITBUCKET:
            key += f'{_BIND_SEP}{p_bind["slug"]}'
        elif p_bind["alm"] == devops.DEVOPS_AZURE:
            key += f'{_BIND_SEP}{p_bind["projectName"]}'
        return key

    def is_part_of_monorepo(self) -> bool:
        """
        :return: From the DevOps binding, Whether the project is part of a monorepo
        :rtype: bool
        """
        bind = self.binding()
        return bind is not None and bind.get("has_binding", False) and bind.get("monorepo", False)

    def __audit_last_analysis(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits whether the last analysis of the project is too old or not

        :param audit_settings: Settings (thresholds) to raise problems
        :type audit_settings: dict
        :return: List of problems found, or empty list
        :rtype: list[Problem]
        """
        log.debug("Auditing %s last analysis date", str(self))
        problems = []
        age = util.age(self.last_analysis(include_branches=True), True)
        if age is None:
            if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
                return problems
            if not audit_settings.get("audit.projects.neverAnalyzed", True):
                log.debug("Auditing of never analyzed projects is disabled, skipping")
            else:
                problems.append(Problem(get_rule(RuleId.PROJ_NOT_ANALYZED), self, str(self)))
            return problems

        max_age = audit_settings.get("audit.projects.maxLastAnalysisAge", 180)
        if max_age == 0:
            log.debug("Auditing of projects with old analysis date is disabled, skipping")
        elif age > max_age:
            rule = get_rule(RuleId.PROJ_LAST_ANALYSIS)
            severity = severities.Severity.HIGH if age > 365 else rule.severity
            problems.append(Problem(rule, self, str(self), self.get_measure("ncloc", fallback="0"), age, severity=severity))

        log.debug("%s last analysis is %d days old", str(self), age)
        return problems

    def __audit_branches(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits project branches

        :param audit_settings: Settings (thresholds) to raise problems
        :type audit_settings: dict
        :return: List of problems found, or empty list
        :rtype: list[Problem]
        """
        if not audit_settings.get(_AUDIT_BRANCHES_PARAM, True):
            log.debug("Auditing of branchs is disabled, skipping...")
            return []
        log.debug("Auditing %s branches", str(self))
        problems = []
        main_br_count = 0
        for branch in self.branches().values():
            problems += branch.audit(audit_settings)
            if audit_settings.get(c.AUDIT_MODE_PARAM, "") != "housekeeper" and branch.name in ("main", "master"):
                main_br_count += 1
                if main_br_count > 1:
                    problems.append(Problem(get_rule(RuleId.PROJ_MAIN_AND_MASTER), self, str(self)))
        return problems

    def __audit_pull_requests(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits project pull requests

        :param ConfigSettings audit_settings: Settings (thresholds) to raise problems
        :return: List of problems found
        """
        problems = []
        for pr in self.pull_requests().values():
            problems += pr.audit(audit_settings)
        return problems

    def audit_languages(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits project utility languages and returns problems if too many LoCs of these

        :param audit_settings: Settings (thresholds) to raise problems
        :type audit_settings: dict
        :return: List of problems found, or empty list
        :rtype: list[Problem]
        """
        if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
            return []
        if not audit_settings.get("audit.projects.utilityLocs", False):
            log.debug("Utility LoCs audit disabled by configuration, skipping")
            return []
        log.debug("Auditing %s utility LoC count", str(self))

        total_locs = 0
        languages = {}
        resp = self.get_measure("ncloc_language_distribution")
        if resp is None:
            return []
        for lang in self.get_measure("ncloc_language_distribution").split(";"):
            (lang, ncloc) = lang.split("=")
            languages[lang] = int(ncloc)
            total_locs += int(ncloc)
        utility_locs = sum(lcount for lang, lcount in languages.items() if lang in ("xml", "json"))
        if total_locs > 100000 and (utility_locs / total_locs) > 0.5:
            return [Problem(get_rule(RuleId.PROJ_UTILITY_LOCS), self, str(self), utility_locs)]
        log.debug("%s utility LoCs count (%d) seems reasonable", str(self), utility_locs)
        return []

    def __audit_binding_valid(self, audit_settings: ConfigSettings) -> list[Problem]:
        if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
            return []
        if self.endpoint.edition() == c.CE:
            log.info("Community edition, skipping binding validation...")
            return []
        elif not audit_settings.get("audit.projects.bindings", True):
            log.info("%s binding validation disabled, skipped", str(self))
            return []
        elif not self.has_binding():
            log.info("%s has no binding, skipping binding validation...", str(self))
            return []
        try:
            self.get("alm_settings/validate_binding", params={"project": self.key})
            log.debug("%s binding is valid", self)
        except (ConnectionError, RequestException) as e:
            sutil.handle_error(e, f"auditing binding of {self}", catch_all=True)
            # Hack: 8.9 returns 404, 9.x returns 400
            if isinstance(e, HTTPError) and e.response.status_code in (HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND):
                return [Problem(get_rule(RuleId.PROJ_INVALID_BINDING), self, str(self))]
        return []

    def get_type(self) -> str:
        """Returns the project type (MAVEN, GRADLE, DOTNET, OTHER, UNKNOWN)"""
        data = json.loads(self.get(api=_TREE_API, params={"component": self.key, "ps": 500, "q": "pom.xml"}).text)
        for comp in data["components"]:
            if comp["name"] == "pom.xml":
                log.info("%s is a MAVEN project", str(self))
                return "MAVEN"
        data = json.loads(self.get(api=_TREE_API, params={"component": self.key, "ps": 500, "q": "gradle"}).text)
        for comp in data["components"]:
            if "gradle" in comp["name"]:
                return "GRADLE"
        data = json.loads(self.get(api=_TREE_API, params={"component": self.key, "ps": 500}).text)
        projtype = "UNKNOWN"
        for comp in data["components"]:
            if re.match(r".*\.(cs|csx|vb)$", comp["name"]):
                projtype = "DOTNET"
                break
            if re.match(r".*\.(java)$", comp["name"]):
                projtype = "JAVA"
                break
            if re.match(r".*\.(py|rb|cbl|vbs|go|js|ts)$", comp["name"]):
                projtype = "CLI"
                break
        log.info("%s is a %s project", str(self), projtype)
        return projtype

    def last_task(self) -> Optional[Task]:
        """Returns the last analysis background task of a problem, or none if not found"""
        from sonar.tasks import Task

        if task := Task.search_last(self.endpoint, component=self.key, type="REPORT"):
            task.concerned_object = self
        return task

    def task_history(self) -> list[Task]:
        """Returns the list of background tasks of a project"""
        from sonar.tasks import Task

        return Task.search(self.endpoint, component=self.key, type="REPORT")

    def scanner(self) -> str:
        """Returns the project type (MAVEN, GRADLE, DOTNET, OTHER, UNKNOWN)"""
        last_task = self.last_task()
        if not last_task:
            return "UNKNOWN"
        last_task.concerned_object = self
        return last_task.scanner()

    def ci(self) -> str:
        """Returns the detected CI tool used, or undetected, or unknown if HTTP request fails"""
        log.debug("Collecting detected CI")
        if not self._ci or not self._revision:
            self._ci, self._revision = "unknown", "unknown"
            try:
                data = json.loads(self.get("project_analyses/search", params={"project": self.key, "ps": 1}).text)["analyses"]
                if len(data) > 0:
                    self._ci, self._revision = data[0].get("detectedCI", "unknown"), data[0].get("revision", "unknown")
            except exceptions.SonarException:
                pass
            except KeyError:
                log.warning("KeyError, can't retrieve CI tool and revision")
        return self._ci

    def revision(self) -> str:
        """Returns the last analysis commit, or unknown if HTTP request fails or no revision"""
        log.debug("Collecting revision")
        if not self._revision:
            self.ci()
        return self._revision

    def project_key(self) -> str:
        """Returns the project key"""
        return self.key

    def ai_code_fix(self) -> Optional[str]:
        """Returns whether this project is enabled for AI Code Fix (if only enabled per project)"""
        log.debug("Getting project AI Code Fix suggestion flag for %s", str(self))
        global_setting = settings.Setting.get_object(self.endpoint, key=settings.AI_CODE_FIX)
        if not global_setting or global_setting.value != "ENABLED_FOR_SOME_PROJECTS":
            return None
        if "isAiCodeFixEnabled" not in self.sq_json:
            api, _, params, ret = self.endpoint.api.get_details(self, Oper.SEARCH, **self.__class__.__PROJECT_FILTER)
            data = self.endpoint.get_paginated(api=api, return_field=ret, **params)
            p_data = next((p for p in data[ret] if p["key"] == self.key), None)
            if p_data:
                self.sq_json.update(p_data)
        return self.sq_json.get("isAiCodeFixEnabled", None)

    def __audit_scanner(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits whether the project is analyzed with the right scanner"""
        if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
            return []
        if not audit_settings.get("audit.projects.scanner", True):
            log.debug("%s: Background task audit disabled, audit skipped", str(self))
            return []
        proj_type, scanner = self.get_type(), self.scanner()
        log.debug("%s is of type %s and uses scanner %s", str(self), proj_type, scanner)
        if proj_type == "UNKNOWN":
            log.info("%s project type can't be identified, skipping check", str(self))
            return []
        if scanner == "UNKNOWN":
            log.info("%s project type or scanner used can't be identified, skipping check", str(self))
            return []
        if proj_type == scanner:
            return []
        return [Problem(get_rule(RuleId.PROJ_WRONG_SCANNER), self, str(self), proj_type, scanner)]

    def __audit_key_pattern(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits whether the project key matches the desired pattern"""
        pattern = audit_settings.get("audit.projects.keyPattern")
        log.debug("Auditing %s project key pattern matches with '%s'", self, pattern)
        if pattern is None:
            log.debug("%s: audit project key pattern is disabled, audit skipped", self)
            return []
        if not re.match(rf"^{pattern}$", self.key):
            return [Problem(get_rule(RuleId.PROJ_NON_COMPLIANT_KEY_PATTERN), self, str(self), pattern)]
        log.debug("%s: matches the desired project key pattern '%s'", str(self), f"^{pattern}$")
        return []

    def audit(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits a project and returns the list of problems found

        :param dict audit_settings: Options of what to audit and thresholds to raise problems
        :return: List of problems found, or empty list
        """
        log.debug("Auditing %s with settings %s", str(self), util.json_dump(audit_settings))
        problems = []
        try:
            problems = self.__audit_last_analysis(audit_settings)
            if audit_settings.get(c.AUDIT_MODE_PARAM, "") != "housekeeper":
                problems += self.audit_visibility(audit_settings)
                problems += self.__audit_binding_valid(audit_settings)
                # Skip language audit, as this can be problematic
                # problems += self.__audit_languages(audit_settings)
                problems += self.permissions().audit(audit_settings)

                problems += self.__audit_scanner(audit_settings)
                problems += self._audit_component(audit_settings)
                problems += self.__audit_key_pattern(audit_settings)
            if self.endpoint.edition() != c.CE and audit_settings.get("audit.project.branches", True):
                problems += self.__audit_branches(audit_settings)
                problems += self.__audit_pull_requests(audit_settings)

        except exceptions.ObjectNotFound:
            self.__class__.CACHE.pop(self)
            raise

        return problems

    def export_zip(self, asynchronous: bool = False, timeout: int = 180) -> tuple[str, Optional[str]]:
        """Exports project as zip file, synchronously

        :param bool asynchronous: Whether to export the project asynchronously or not (if async, export_zip returns immediately)
        :param int timeout: timeout in seconds to complete the export operation
        :returns: export status (success/failure/timeout), and zip file path
        """
        from sonar.tasks import Task, SUCCESS

        log.info("Exporting %s (%s)", str(self), "asynchronously" if asynchronous else "synchronously")
        try:
            resp = self.post("project_dump/export", params={"key": self.key})
        except exceptions.ObjectNotFound:
            self.__class__.CACHE.pop(self)
            raise
        except exceptions.SonarException as e:
            return f"FAILED/{e.message}", None
        except RequestException as e:
            sutil.handle_error(e, f"exporting zip of {self}", catch_all=True)
            return f"FAILED/{sutil.http_error_string(e.response.status_code)}", None
        except ConnectionError as e:
            return str(e), None
        if asynchronous:
            return ZIP_ASYNC_SUCCESS, None
        data = json.loads(resp.text)
        task = Task.get_object(self.endpoint, data["taskId"])
        status = task.wait_for_completion(timeout=timeout)
        task.__class__.CACHE.pop(self)
        if status != SUCCESS:
            log.error("%s export %s", str(self), status)
            return status, None
        dump_file = json.loads(self.get("project_dump/status", params={"key": self.key}).text)["exportedDump"]
        log.debug("%s export %s, dump file %s", str(self), status, dump_file)
        if self.loc() == 0:
            return f"{SUCCESS}/{ZIP_ZERO_LOC}", dump_file
        return SUCCESS, dump_file

    def import_zip(self, asynchronous: bool = False, timeout: int = 180) -> str:
        """Imports a project zip file in SonarQube

        :param bool asynchronous: Whether to export the project asynchronously or not (if async, import_zip returns immediately)
        :param int timeout: timeout in seconds to complete the export operation
        :return: SUCCESS or FAILED with reason
        """
        from sonar.tasks import Task, ZIP_MISSING, SUCCESS

        mode = "asynchronously" if asynchronous else "synchronously"
        log.info("Importing %s (%s)", str(self), mode)
        if self.endpoint.edition() not in (c.EE, c.DCE):
            raise exceptions.UnsupportedOperation("Project import is only available with Enterprise and Datacenter Edition")
        try:
            resp = self.post("project_dump/import", params={"key": self.key})
        except exceptions.ObjectNotFound as e:
            if "Dump file does not exist" in e.message:
                return f"FAILED/{ZIP_MISSING}"
            self.__class__.CACHE.pop(self)
            raise
        except exceptions.SonarException as e:
            if "Dump file does not exist" in e.message:
                return f"FAILED/{ZIP_MISSING}"
            return f"FAILED/{e.message}"
        except ConnectionError as e:
            return f"FAILED/{str(e)}"

        if asynchronous:
            return ZIP_ASYNC_SUCCESS

        data = json.loads(resp.text)
        import_task = Task.get_object(self.endpoint, data["taskId"])
        status = import_task.wait_for_completion(timeout=timeout)
        log.log(log.INFO if status == SUCCESS else log.ERROR, "%s import background task %s", str(self), status)
        return status if status == SUCCESS else f"FAILED/BACKGROUND_TASK_{status}/{import_task.short_error()}"

    def get_branches_and_prs(self, filters: dict[str, str]) -> Optional[dict[str, object]]:
        """Get lists of branches and PR objects"""
        if not filters:
            return None
        f = filters.copy()
        br = f.pop("branch", None)
        pr = f.pop("pullRequest", None)
        if not br and not pr:
            return None
        objects = {}
        if br:
            if "*" in br:
                objects = self.branches()
            else:
                try:
                    objects = {b: branches.Branch.get_object(self.endpoint, project=self, branch_name=b) for b in br}
                except exceptions.SonarException as e:
                    log.error(e.message)
        if pr:
            if "*" in pr:
                objects.update(self.pull_requests())
            else:
                try:
                    objects.update({p: pull_requests.PullRequest.get_object(self.endpoint, project=self, pull_request_key=p) for p in pr})
                except exceptions.SonarException as e:
                    log.error(e.message)
        return objects

    def get_findings(self, **search_params: Any) -> dict[str, Union[Issue, Hotspot]]:
        """Returns a project list of findings (issues and hotspots)

        :param search_params: Any search parameter
        :return: List of all findings, with finding key as key
        """
        from sonar import issues, hotspots, findings

        log.info("Exporting findings for %s with params %s", str(self), search_params)
        findings_list: dict[str, Union[Issue, Hotspot]] = {}
        api, _, params, ret = self.endpoint.api.get_details(self, Oper.EXPORT_FINDINGS, **search_params | {"project": self.key})
        data = json.loads(self.get(api, params=params).text)
        for i in data[ret]:
            if i["type"] != idefs.TYPE_HOTSPOT:
                findings_list[i["key"]] = issues.Issue.get_object(self.endpoint, data=i, from_export=True)
            elif i.get("status", "") != "CLOSED":
                findings_list[i["key"]] = hotspots.Hotspot.get_object(self.endpoint, data=i, from_export=True)
        findings.Finding.add_branch_and_pr(findings_list, **search_params)
        for t in idefs.ALL_TYPES:
            log.debug("%d %s exported", sum(1 for i in findings_list.values() if i.type == t), t)
        return findings_list

    def count_third_party_issues(self, **search_params: Any) -> dict[str, int]:
        """Returns the nbr of thrid party issues for the project"""
        search_params = {k: [v] for k, v in search_params.items() if k in ("branch", "pullRequest")}
        branches_or_prs = self.get_branches_and_prs(search_params)
        if branches_or_prs is None:
            return super().count_third_party_issues(**search_params)
        log.debug("Getting 3rd party issues on branches/PR")
        issue_counts = {}
        for comp in [co for co in branches_or_prs.values() if co]:
            log.debug("Getting 3rd party issues for %s", str(comp))
            for k, total in comp.count_third_party_issues(**search_params).items():
                if k not in issue_counts:
                    issue_counts[k] = 0
                issue_counts[k] += total
        log.debug("Issues count = %s", str(issue_counts))
        return issue_counts

    def sync(self, another_project: Union[Project, Branch], sync_settings: ConfigSettings) -> tuple[list[dict[str, str]], dict[str, int]]:
        """Syncs project findings with another project

        :param Project|Branch another_project: other project to sync findings into
        :param dict sync_settings: Parameters to configure the sync
        :return: sync report as tuple, with counts of successful and unsuccessful issue syncs
        :rtype: tuple(report, counters)
        """
        from sonar import syncer

        log.info("Syncing %s with %s", str(self), str(another_project))
        if self.endpoint.edition() == c.CE or another_project.endpoint.edition() == c.CE or isinstance(another_project, branches.Branch):
            # Sync the project main branch only
            return syncer.sync_objects(self, another_project, sync_settings=sync_settings)

        src_branches = self.branches()
        tgt_branches = another_project.branches()
        src_branches_list = list(src_branches.keys())
        tgt_branches_list = list(tgt_branches.keys())
        diff = list(set(src_branches_list) - set(tgt_branches_list))
        if len(diff) > 0:
            log.warning(
                "Source %s has branches that do not exist for target %s, these branches will be ignored: %s",
                str(self),
                str(another_project),
                ", ".join(diff),
            )
        diff = list(set(tgt_branches_list) - set(src_branches_list))
        if len(diff) > 0:
            log.warning(
                "Target %s has branches that do not exist for source %s, these branches will be ignored: %s",
                str(another_project),
                str(self),
                ", ".join(diff),
            )
        report, counters = [], {}
        intersect = list(set(src_branches_list) & set(tgt_branches_list))
        for branch_name in intersect:
            (tmp_report, tmp_counts) = src_branches[branch_name].sync(tgt_branches[branch_name], sync_settings=sync_settings)
            report += tmp_report
            counters = util.dict_add(counters, tmp_counts)
        return (report, counters)

    def sync_branches(self, sync_settings: ConfigSettings) -> tuple[list[dict[str, str]], dict[str, int]]:
        """Syncs project issues across all its branches

        :param dict sync_settings: Parameters to configure the sync
        :return: sync report as tuple, with counts of successful and unsuccessful issue syncs
        :rtype: tuple(report, counters)
        """
        my_branches = self.branches().values()
        report, counters = [], {}
        for b_src in my_branches:
            for b_tgt in [b for b in my_branches if b.name != b_src.name]:
                (tmp_report, tmp_counts) = b_src.sync(b_tgt, sync_settings=sync_settings)
                report += tmp_report
                counters = util.dict_add(counters, tmp_counts)
        return (report, counters)

    def quality_profiles(self) -> dict[str, qualityprofiles.QualityProfile]:
        """Returns the project quality profiles

        :return: dict of quality profiles indexed by language
        :rtype: dict{language: QualityProfile}
        """
        log.debug("Getting %s quality profiles", str(self))
        qp_list = qualityprofiles.QualityProfile.search(self.endpoint, use_cache=True)
        return {qp.language: qp for qp in qp_list.values() if qp.used_by_project(self)}

    def quality_gate(self) -> Optional[tuple[str, bool]]:
        """Returns the project quality gate

        :return: name of quality gate and whether it's the default
        :rtype: tuple(name, is_default)
        """
        data = json.loads(self.get(api="qualitygates/get_by_project", params={"project": self.key}).text)
        return data["qualityGate"]["name"], data["qualityGate"]["default"]

    def webhooks(self) -> dict[str, webhooks.WebHook]:
        """
        :return: Project webhooks indexed by their key
        :rtype: dict{key: WebHook}
        """
        log.debug("Getting %s webhooks", str(self))
        return webhooks.WebHook.search(endpoint=self.endpoint, project=self.key)

    def links(self, custom_only: bool = True, with_id: bool = False) -> list[dict[str, str]]:
        """Returns the list of project links

        :param custom_only: Whether to only return custom links
        :return: list of project links
        :rtype: list[{type, name, url}]
        """
        log.debug("Getting %s links", self)
        try:
            data = json.loads(self.get(api="project_links/search", params={"projectKey": self.key}).text)
        except exceptions.SonarException:
            return []
        link_list = []
        fields = ["name", "url"] + (["id"] if with_id else [])
        for link in data["links"]:
            if custom_only and link["type"] in _PREDEFINED_LINKS:
                log.info("%s link %s is a standard one, not exported", self, link)
                continue
            link_list.append({k: v for k, v in link.items() if k in fields})
        log.debug("%s links = %s", self, link_list)
        return link_list

    def __export_get_binding(self) -> Optional[ObjectJsonRepr]:
        """Exports a binding as JSON"""
        binding = self.binding()
        if binding:
            binding = binding.copy()
            # Remove redundant fields
            if binding["alm"] == devops.DEVOPS_GITLAB:
                binding.pop("summaryCommentEnabled", None)
            binding.pop("alm", None)
            binding.pop("url", None)
            if not binding.get("monorepo", False):
                binding.pop("monorepo", None)
        return binding

    def __export_get_qp(self) -> Optional[ObjectJsonRepr]:
        """Exports a QP as JSON"""
        qp_json = {qp.language: f"{qp.name}" for qp in self.quality_profiles().values()}
        if len(qp_json) == 0:
            return None
        return qp_json

    def __get_branch_export(self, export_settings: ConfigSettings) -> Optional[ObjectJsonRepr]:
        """Export project branches as JSON"""
        branch_data = {name: branch.export(export_settings=export_settings) for name, branch in sorted(self.branches().items())}
        # If there is only 1 branch with no specific config except being main, don't return anything
        if len(branch_data) == 0 or (len(branch_data) == 1 and "main" in branch_data and len(branch_data["main"]) <= 1):
            return None
        main_br = {k: v for k, v in branch_data.items() if v and v.get("isMain")}
        return main_br | branch_data

    def migration_export(self, export_settings: ConfigSettings, **search_params: Any) -> ObjectJsonRepr:
        """Produces the data that is exported for SQ to SC migration"""
        json_data = super().migration_export(export_settings, project=self.key, **search_params)
        json_data["detectedCi"] = self.ci()
        json_data["revision"] = self.revision()
        last_task = self.last_task()
        json_data["backgroundTasks"] = {}
        if last_task:
            ctxt = last_task.scanner_context()
            if ctxt:
                ctxt = {k: v for k, v in ctxt.items() if k not in phelp.UNNEEDED_CONTEXT_DATA}
            t_hist = []
            for t in self.task_history():
                t_hist.append({k: v for k, v in t.sq_json.items() if k not in phelp.UNNEEDED_TASK_DATA})
            json_data["backgroundTasks"] = {
                "lastTaskScannerContext": ctxt,
                # "lastTaskWarnings": last_task.warnings(),
                "taskHistory": t_hist,
            }
        log.debug("Returning %s migration data %s", str(self), util.json_dump(json_data))
        return json_data

    def export(self, export_settings: ConfigSettings, settings_list: Optional[dict[str, str]] = None) -> ObjectJsonRepr:
        """Exports the entire project configuration as JSON

        :return: All project configuration settings
        """
        log.info("Exporting %s", str(self))
        json_data = self.sq_json.copy()
        json_data.update({"key": self.key, "name": self.name})
        try:
            json_data["binding"] = self.__export_get_binding()
            json_data["qualityProfiles"] = self.__export_get_qp()
            json_data["links"] = self.links()
            json_data["permissions"] = self.permissions().to_json()
            if self.endpoint.version() >= (10, 7, 0):
                json_data[phelp.AI_CODE_FIX] = self.ai_code_fix()
            json_data["branches"] = self.__get_branch_export(export_settings)
            json_data["tags"] = self.get_tags()
            json_data["visibility"] = self.visibility()
            (json_data["qualityGate"], qg_is_default) = self.quality_gate()
            if qg_is_default:
                json_data.pop("qualityGate")

            try:
                hooks = webhooks.export(self.endpoint, self.key)
            except exceptions.SonarException:
                hooks = None
            if hooks is not None:
                json_data["webhooks"] = hooks
            json_data = util.filter_export(json_data, _IMPORTABLE_PROPERTIES, export_settings.get("FULL_EXPORT", False))

            if export_settings.get("MODE", "") == "MIGRATION":
                json_data.update({"migrationData": self.migration_export(export_settings)})

            settings_dict = settings.Setting.search(self.endpoint, include_not_set=False, component=self.key, keys=settings_list)
            # json_data.update({s.to_json() for s in settings_dict.values() if include_inherited or not s.inherited})
            contains_ai = False
            try:
                ai = self.get_ai_code_assurance()
                contains_ai = ai is not None and ai != "NONE"
            except exceptions.UnsupportedOperation:
                pass
            if contains_ai:
                json_data[_CONTAINS_AI_CODE] = contains_ai
            with_inherited = export_settings.get("INCLUDE_INHERITED", False)
            json_data["settings"] = {}
            settings_to_export = {k: s for k, s in settings_dict.items() if with_inherited or not s.inherited and s.key != "visibility"}
            for key, s in settings_to_export.items():
                json_setting = s.to_json()
                if json_setting[key]["defaultValue"] == json_setting[key]["value"]:
                    continue
                json_setting[key].pop("defaultValue")
                if key == settings.NEW_CODE_PERIOD:
                    json_data[settings.NEW_CODE_PERIOD] = json_setting[settings.NEW_CODE_PERIOD]["value"]
                else:
                    json_data["settings"] |= json_setting
            log.debug("Exporting %s done, returning %s", str(self), util.json_dump(json_data))
        except Exception as e:
            traceback.print_exc()
            sutil.handle_error(e, f"exporting {self}, export of this project interrupted", catch_all=True)
            json_data["ERROR"] = f"{sutil.error_msg(e)} while exporting project"

        tmp_branches = json_data.pop("branches", None)
        json_data = util.clean_data(json_data, remove_none=True, remove_empty=True)
        if tmp_branches:
            json_data["branches"] = tmp_branches
        return util.order_keys(json_data, *_IMPORTABLE_PROPERTIES)

    def new_code(self) -> str:
        """
        :return: The project new code definition
        :rtype: str
        """
        if self._new_code is None:
            new_code = settings.Setting.get_object(self.endpoint, settings.NEW_CODE_PERIOD, self.key)
            self._new_code = new_code.value if new_code else ""
            log.info("%s new code is %s", self, self._new_code)
        return self._new_code

    def permissions(self) -> pperms.ProjectPermissions:
        """
        :return: The project permissions
        :rtype: ProjectPermissions
        """
        if self._permissions is None:
            self._permissions = pperms.ProjectPermissions(self)
        return self._permissions

    def set_permissions(self, desired_permissions: list[PermissionDef]) -> bool:
        """Sets project permissions

        :param desired_permissions: List of permissions
        :return: Nothing
        """
        return self.permissions().set(desired_permissions)

    def set_links(self, desired_links: list[dict[str, str]]) -> bool:
        """Sets project links

        :param desired_links: List of links
        :return: Whether the operation was successful
        """
        log.info("Setting links with %s", desired_links)
        dict_current = util.list_to_dict(self.links(with_id=True), "name", keep_in_values=True)
        dict_desired = util.list_to_dict(desired_links, "name", keep_in_values=True)
        ok = True
        # FIXME: Although not recommended it's possible to have multiple links with same name
        for link_name in [name for name in dict_desired if name not in dict_current]:
            link_name = dict_desired[link_name]
            if link_name.get("type", "") in _PREDEFINED_LINKS:
                log.warning("Link %s is not custom, can't recreate it, this will be automatic at first analysis", link_name)
                continue
            ok = ok and self.post("project_links/create", params={"projectKey": self.key} | {"name": link_name["name"], "url": link_name["url"]}).ok
        for link_name in [name for name in dict_current if name not in dict_desired]:
            link_id = next(v["id"] for k, v in link_name if k == link_name)
            ok = ok and self.post("project_links/delete", params={"id": link_id}).ok
        self.links()
        return ok

    def set_quality_gate(self, quality_gate: str) -> bool:
        """Sets project quality gate

        :param quality_gate: quality gate name
        :return: Whether the operation was successful
        """
        if quality_gate is None:
            return False
        _ = qg.QualityGate.get_object(self.endpoint, quality_gate)
        return self.post("qualitygates/select", params={"projectKey": self.key, "gateName": quality_gate}).ok

    def set_contains_ai_code(self, contains_ai_code: bool) -> bool:
        """Sets whether a project contains AI code

        :param contains_ai_code: Whether the project contains AI code
        :return: Whether the operation succeeded
        """
        if self.endpoint.version() < (10, 7, 0) or self.endpoint.edition() == c.CE:
            return False
        api = "projects/set_contains_ai_code"
        if self.endpoint.version() == (10, 7, 0):
            api = "projects/set_ai_code_assurance"
        return self.post(api, params={"project": self.key, "contains_ai_code": str(contains_ai_code).lower()}).ok

    def set_quality_profile(self, language: str, quality_profile: str) -> bool:
        """Sets project quality profile for a given language

        :param language: Language key, following SonarQube convention
        :param quality_profile: Name of the quality profile in the language
        :return: Whether the operation was successful
        """
        if not qualityprofiles.QualityProfile.exists(endpoint=self.endpoint, language=language, name=quality_profile):
            log.warning("Quality profile '%s' in language '%s' does not exist, can't set it for %s", quality_profile, language, str(self))
            return False
        log.debug("Setting quality profile '%s' of language '%s' for %s", quality_profile, language, str(self))
        return self.post("qualityprofiles/add_project", params={"project": self.key, "qualityProfile": quality_profile, "language": language}).ok

    def rename_main_branch(self, main_branch_name: str) -> bool:
        """Renames the project main branch

        :param str main_branch_name: New main branch name
        :return: Whether the operation was successful
        """
        br = self.main_branch()
        if br:
            return br.rename(main_branch_name)
        log.warning("No main branch to rename found for %s", str(self))
        return False

    def set_webhooks(self, webhook_data: list[dict[str, str]]) -> None:
        """Sets project webhooks

        :param list webhook_data: JSON describing the webhooks
        :return: Nothing
        """
        webhooks.import_config(self.endpoint, webhook_data, self.key)

    def set_settings(self, data: list[dict[str, Any]]) -> None:
        """Sets project settings (webhooks, settings, new code period)

        :param data: JSON describing the settings
        :return: Nothing
        """
        log.debug("XSetting %s settings with %s", str(self), util.json_dump(data))
        for key, value in {s["key"]: s["value"] for s in data}.items():
            if key in ("branches", settings.NEW_CODE_PERIOD):
                continue
            log.debug("Setting 2 %s settings with %s %s", str(self), key, value)
            settings.set_setting(self.endpoint, key, value, component=self.key)

    def set_devops_binding(self, binding_data: ObjectJsonRepr) -> bool:
        """Sets project devops binding settings

        :param data: JSON describing the devops binding
        :return: Nothing
        """
        log.debug("Setting devops binding of %s to %s", str(self), util.json_dump(binding_data))
        alm_key = binding_data["key"]
        if not devops.DevopsPlatform.exists(endpoint=self.endpoint, key=alm_key):
            log.warning("DevOps platform '%s' does not exists, can't set it for %s", alm_key, str(self))
            return False
        alm_type = devops.devops_type(endpoint=self.endpoint, key=alm_key)
        mono = binding_data.get("monorepo", False)
        repo = binding_data["repository"]
        try:
            if alm_type == devops.DEVOPS_GITHUB:
                self.set_binding_github(alm_key, repository=repo, monorepo=mono, summary_comment=binding_data.get("summaryCommentEnabled", True))
            elif alm_type == devops.DEVOPS_GITLAB:
                self.set_binding_gitlab(alm_key, repository=repo, monorepo=mono)
            elif alm_type == devops.DEVOPS_AZURE:
                self.set_binding_azure_devops(
                    alm_key,
                    repository=repo,
                    monorepo=mono,
                    project_name=binding_data["projectName"],
                    inline_annotations=binding_data.get("inlineAnnotations", False),
                )
            elif alm_type == devops.DEVOPS_BITBUCKET:
                self.set_binding_bitbucket_server(alm_key, repository=repo, slug=binding_data["slug"], monorepo=mono)
            elif alm_type == devops.DEVOPS_BITBUCKET_CLOUD:
                self.set_binding_bitbucket_cloud(alm_key, repository=repo, monorepo=mono)
            else:
                log.error("Invalid devops platform type '%s' for %s, setting skipped", alm_key, str(self))
                return False
        except exceptions.UnsupportedOperation as e:
            log.warning(e.message)
            return False
        self._binding = None
        self.binding()
        return True

    def __std_binding_params(self, alm_key: str, repo: str, monorepo: bool) -> ApiParams:
        return {"almSetting": alm_key, "project": self.key, "repository": repo, "monorepo": str(monorepo).lower()}

    def _check_binding_supported(self) -> bool:
        if self.endpoint.edition() == c.CE:
            raise exceptions.UnsupportedOperation(f"{str(self)}: Can't set project binding on Community Edition")
        return True

    def set_binding_github(self, devops_platform_key: str, repository: str, monorepo: bool = False, summary_comment: bool = True) -> bool:
        """Sets project devops binding for github

        :param devops_platform_key: key of the platform in the global admin devops configuration
        :param repository: project repository name in github
        :param monorepo: Whether the project is part of a monorepo, defaults to False
        :param summary_comment: Whether summary comments should be posted, defaults to True
        :return: Whether the operation succeeded
        """
        self._check_binding_supported()
        params = self.__std_binding_params(devops_platform_key, repository, monorepo) | {"summaryCommentEnabled": str(summary_comment).lower()}
        return self.post("alm_settings/set_github_binding", params=params).ok

    def set_binding_gitlab(self, devops_platform_key: str, repository: str, monorepo: bool = False) -> bool:
        """Sets project devops binding for gitlab

        :param devops_platform_key: key of the platform in the global admin devops configuration
        :param repository: project repository name in gitlab
        :param monorepo: Whether the project is part of a monorepo, defaults to False
        :return: Whether the operation succeeded
        """
        self._check_binding_supported()
        params = self.__std_binding_params(devops_platform_key, repository, monorepo)
        return self.post("alm_settings/set_gitlab_binding", params=params).ok

    def set_binding_bitbucket_server(self, devops_platform_key: str, repository: str, slug: str, monorepo: bool = False) -> bool:
        """Sets project devops binding for bitbucket server

        :param devops_platform_key: key of the platform in the global admin devops configuration
        :param repository: project repository name in bitbucket server
        :param slug: project repository SLUG
        :param monorepo: Whether the project is part of a monorepo, defaults to False
        :return: Whether the operation succeeded
        """
        self._check_binding_supported()
        params = self.__std_binding_params(devops_platform_key, repository, monorepo) | {"slug": slug}
        return self.post("alm_settings/set_bitbucket_binding", params=params).ok

    def set_binding_bitbucket_cloud(self, devops_platform_key: str, repository: str, monorepo: bool = False) -> bool:
        """Sets project devops binding for bitbucket cloud

        :param devops_platform_key: key of the platform in the global admin devops configuration
        :param repository: project repository name in bitbucket cloud
        :param monorepo: Whether the project is part of a monorepo, defaults to False
        :return: Whether the operation succeeded
        """
        self._check_binding_supported()
        params = self.__std_binding_params(devops_platform_key, repository, monorepo)
        return self.post("alm_settings/set_bitbucketcloud_binding", params=params).ok

    def set_binding_azure_devops(
        self, devops_platform_key: str, project_name: str, repository: str, monorepo: bool = False, inline_annotations: bool = False
    ) -> bool:
        """Sets project devops binding for azure devops

        :param devops_platform_key: key of the platform in the global admin devops configuration
        :param project_name: project name in Azure DevOps
        :param repository: project repository name in azure devops
        :param monorepo: Whether the project is part of a monorepo, defaults to False
        :param inline_annotations: Whether inline annotations are enabled, defaults to False
        :return: Whether the operation succeeded
        """
        self._check_binding_supported()
        params = self.__std_binding_params(devops_platform_key, repository, monorepo)
        params["projectName"] = project_name
        params["repositoryName"] = params.pop("repository")
        params["inlineAnnotations"] = str(inline_annotations).lower()
        return self.post("alm_settings/set_azure_binding", params=params).ok

    def get_measures_history(self, metrics_list: KeyList) -> dict[str, str]:
        """Returns the history of a project metrics"""
        return measures.get_history(self, metrics_list, component=self.key)

    def get_analyses(self, filter_in: Optional[list[str]] = None, filter_out: Optional[list[str]] = None, **search_params: Any) -> ApiPayload:
        """Returns a projects analyses"""
        return super().get_analyses(filter_in=filter_in, filter_out=filter_out, **(search_params | {"project": self.key}))

    def update(self, config: ObjectJsonRepr) -> None:
        """Updates a project with a whole configuration set

        :param config: JSON of configuration settings
        """
        props = {
            "visibility": self.set_visibility,
            "permissions": self.set_permissions,
            "links": self.set_links,
            "tags": self.set_tags,
            "qualityGate": self.set_quality_gate,
            "webhooks": self.set_webhooks,
            "binding": self.set_devops_binding,
        }
        for prop, func in props.items():
            if prop in config:
                try:
                    log.info("Setting %s of %s", prop, self)
                    func(config[prop])
                except exceptions.UnsupportedOperation as e:
                    log.warning(e.message)
            else:
                log.info("%s has no %s configuration, skipped", self, prop)

        if "qualityProfiles" in config:
            for qp_data in config["qualityProfiles"]:
                self.set_quality_profile(language=qp_data["language"], quality_profile=qp_data["name"])
        if "branches" in config:
            for branch_data in config["branches"]:
                try:
                    branch = branches.Branch.get_object(self.endpoint, project=self, branch_name=branch_data["name"])
                    branch.import_config(branch_data)
                except exceptions.ObjectNotFound:
                    log.warning("Branch '%s' of %s does not exists, can't update its configuration", branch_data["name"], str(self))

        if settings_to_apply := config.get("settings"):
            self.set_settings(settings_to_apply)
        if nc := config.get(settings.NEW_CODE_PERIOD):
            (nc_type, nc_val) = settings.decode(settings.NEW_CODE_PERIOD, nc)
            settings.set_new_code_period(self.endpoint, nc_type, nc_val, project_key=self.key)
        if "aiCodeAssurance" in config:
            log.warning("'aiCodeAssurance' project setting is deprecated, please use '%s' instead", _CONTAINS_AI_CODE)
        self.set_contains_ai_code(config.get(_CONTAINS_AI_CODE, config.get("aiCodeAssurance", False)))

        # TODO: Set branch settings See https://github.com/okorach/sonar-tools/issues/1828


def get_matching_list(endpoint: Platform, pattern: str, threads: int = 8) -> dict[str, Project]:
    """Returns the list of projects whose keys are matching the pattern

    :param Platform endpoint: Reference to the SonarQube platform
    :param str pattern: Regular expression to match project keys
    :return: the list of all projects matching the pattern
    """
    pattern = pattern or ".+"
    log.info("Listing projects matching regexp '%s' on %s", pattern, endpoint)
    matches = {k: v for k, v in Project.search(endpoint, use_cache=True, threads=threads).items() if re.match(rf"^{pattern}$", k)}
    log.info("%d project key matching regexp '%s' on %s", len(matches), pattern, endpoint)
    return matches


def __audit_duplicates(projects_list: dict[str, Project], audit_settings: ConfigSettings) -> list[Problem]:
    """Audits for suspected duplicate projects"""
    if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
        return []
    if not audit_settings.get("audit.projects.duplicates", True):
        log.info("Project duplicates auditing was disabled by configuration")
        return []
    log.info("Auditing for potential duplicate projects")
    duplicates = []
    pair_set = set()
    for key1, p in projects_list.items():
        for key2 in projects_list:
            pair = " ".join(sorted([key1, key2]))
            if sutil.similar_strings(key1, key2, audit_settings.get("audit.projects.duplicates.maxDifferences", 4)) and pair not in pair_set:
                duplicates.append(Problem(get_rule(RuleId.PROJ_DUPLICATE), p, str(p), key2))
            pair_set.add(pair)
    return duplicates


def __audit_bindings(projects_list: dict[str, Project], audit_settings: ConfigSettings) -> list[Problem]:
    """Audits for duplicate project bindings"""
    if audit_settings.get(c.AUDIT_MODE_PARAM, "") == "housekeeper":
        return []
    if not audit_settings.get("audit.projects.bindings", True):
        log.info("Project bindings auditing was disabled by configuration")
        return []

    log.info("Auditing for duplicate project bindings")
    bindings = {}
    problems = []
    for project in projects_list.values():
        if (bindkey := project.binding_key()) is not None and bindkey in bindings:
            problems.append(Problem(get_rule(RuleId.PROJ_DUPLICATE_BINDING), project, str(project), str(bindings[bindkey])))
        bindings[bindkey] = project
    return problems


def audit(endpoint: Platform, audit_settings: ConfigSettings, **kwargs: Any) -> list[Problem]:
    """Audits all or a list of projects

    :param Platform endpoint: reference to the SonarQube platform
    :param ConfigSettings audit_settings: Configuration of audit
    :return: list of problems found
    """
    if not audit_settings.get("audit.projects", True):
        log.info("Auditing projects is disabled, audit skipped...")
        return []
    log.info("--- Auditing projects: START ---")
    key_regexp = kwargs.get("key_list", ".+")
    threads = audit_settings.get("threads", 4)
    plist = {k: v for k, v in Project.search(endpoint, threads=threads).items() if not key_regexp or re.match(key_regexp, v.key)}
    write_q = kwargs.get("write_q", None)
    total, current = len(plist), 0
    problems = []
    futures, futures_map = [], {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads, thread_name_prefix="ProjectAudit") as executor:
        for project in plist.values():
            futures.append(future := executor.submit(Project.audit, project, audit_settings))
            futures_map[future] = project
        for future in concurrent.futures.as_completed(futures):
            try:
                problems += (proj_pbs := future.result(timeout=60))
                write_q and write_q.put(proj_pbs)
            except (TimeoutError, RequestException, exceptions.SonarException) as e:
                log.error(f"Exception {str(e)} when auditing {str(futures_map[future])}.")
            current += 1
            lvl = log.INFO if current % 10 == 0 or total - current < 10 else log.DEBUG
            log.log(lvl, "%d/%d projects audited (%d%%)", current, total, (current * 100) // total)
    log.debug("Projects audit complete, auditing bindings and duplicates")
    for audit_func in __audit_bindings, __audit_duplicates:
        problems += (more_pbs := audit_func(plist, audit_settings))
        write_q and write_q.put(more_pbs)
    log.info("--- Auditing projects: END ---")
    return problems


def export(endpoint: Platform, export_settings: ConfigSettings, **kwargs: Any) -> ObjectJsonRepr:
    """Exports all or a list of projects configuration as dict

    :param endpoint: reference to the SonarQube platform
    :param export_settings: Export parameters
    :return: list of projects settings
    """

    write_q = kwargs.get("write_q", None)
    key_regexp = kwargs.get("key_list", ".+")
    nb_threads = export_settings.get("threads", 8)
    for qp in qualityprofiles.QualityProfile.search(endpoint).values():
        qp.projects()
    proj_list = {k: v for k, v in Project.search(endpoint, threads=nb_threads).items() if not key_regexp or re.match(rf"^{key_regexp}$", k)}
    total, current = len(proj_list), 0
    log.info("Exporting %d projects", total)
    results = {}
    futures, futures_map = [], {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=nb_threads, thread_name_prefix="ProjectExport") as executor:
        for project in proj_list.values():
            futures.append(future := executor.submit(Project.export, project, export_settings, None))
            futures_map[future] = project
        for future in concurrent.futures.as_completed(futures):
            try:
                exp_json = future.result(timeout=60)
                write_q and write_q.put(phelp.convert_project_json(exp_json))
                results[futures_map[future].key] = exp_json
            except (TimeoutError, RequestException, exceptions.SonarException) as e:
                log.error(f"Exception {str(e)} when exporting {str(futures_map[future])}.")
            current += 1
            lvl = log.INFO if current % 10 == 0 or total - current < 10 else log.DEBUG
            log.log(lvl, "%d/%d projects exported (%d%%)", current, total, (current * 100) // total)
    log.debug("Projects export complete")
    write_q and write_q.put(sutil.WRITE_END)
    return dict(sorted(results.items()))


def import_config(endpoint: Platform, config_data: ObjectJsonRepr, key_list: KeyList = None) -> None:
    """Imports a configuration in SonarQube

    :param Platform endpoint: reference to the SonarQube platform
    :param ObjectJsonRepr config_data: the configuration to import
    :param KeyList key_list: List of project keys to be considered for the import, defaults to None (all projects)
    :returns: Nothing
    """
    if not (project_data := config_data.get("projects", None)):
        log.info("No projects to import")
        return
    log.info("Importing projects")
    Project.search(endpoint)
    project_data = util.list_to_dict(project_data, "key")
    nb_projects = len(project_data)
    i = 0
    new_key_list = util.csv_to_list(key_list)
    for key, data in project_data.items():
        if new_key_list and key not in new_key_list:
            continue
        log.info("Importing project key '%s'", key)
        try:
            if Project.exists(endpoint, key=key):
                if not Project.has_access(endpoint, key):
                    Project.restore_access(endpoint, key)
                o = Project.get_object(endpoint, key)
            else:
                o = Project.create(endpoint, key, data["name"])
        except exceptions.SonarException as e:
            log.error("Error during config import of project with key '%s', %s", key, e.message)
            continue
        try:
            o.update(data)
        except exceptions.SonarException as e:
            log.error("Error during config import of project with key '%s', %s", key, e.message)
            continue
        i += 1
        if i % 20 == 0 or i == nb_projects:
            log.info("Imported %d/%d projects (%d%%)", i, nb_projects, (i * 100 // nb_projects))


def __export_zip_thread(project: Project, export_timeout: int) -> dict[str, str]:
    """Thread callable for project zip export"""
    from sonar.tasks import SUCCESS

    try:
        status, file = project.export_zip(timeout=export_timeout)
    except exceptions.UnsupportedOperation as e:
        # chelp.clear_cache_and_exit(errcodes.UNSUPPORTED_OPERATION, "Zip export unsupported on your SonarQube version")
        raise exceptions.UnsupportedOperation("Zip export unsupported on your SonarQube version") from e
    log.debug("Exporting thread for %s done, status: %s", str(project), status)
    data = {"key": project.key, "name": project.name, "exportProjectUrl": project.url(), "exportStatus": status}
    if status.startswith(SUCCESS):
        data["file"] = os.path.basename(file)
        data["exportPath"] = file
        data["exportDate"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log.debug("Exporting thread for %s returns %s", str(project), str(data))
    return data


def export_zips(
    endpoint: Platform, key_regexp: Optional[str] = None, threads: int = 8, export_timeout: int = 30, skip_zero_loc: bool = False
) -> list[dict[str, str]]:
    """Export as zip all or a list of projects

    :param Platform endpoint: reference to the SonarQube platform
    :param str key_regexp: Regexp to filter projects to export, defaults to None (all projects)
    :param int threads: Number of parallel threads for export, defaults to 8
    :param int export_timeout: Timeout to export the project, defaults to 30
    :return: list of exported projects with export result
    """
    from sonar.tasks import SUCCESS

    statuses, results = {"SUCCESS": 0}, []
    projects_list = {k: p for k, p in Project.search(endpoint, threads=threads).items() if not key_regexp or re.match(rf"^{key_regexp}$", p.key)}
    nbr_projects = len(projects_list)
    if skip_zero_loc:
        results = [
            {"key": p.key, "name": p.name, "exportProjectUrl": p.url(), "exportStatus": f"SKIPPED/{ZIP_ZERO_LOC}"}
            for p in projects_list.values()
            if p.loc() == 0
        ]
        statuses[f"SKIPPED/{ZIP_ZERO_LOC}"] = len(results)
        projects_list = {k: v for k, v in projects_list.items() if v.loc() > 0}
        log.info("Skipping export of %d projects with 0 LoC", nbr_projects - len(projects_list))
        nbr_projects = len(projects_list)
    log.info("Exporting %d projects", nbr_projects)
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads, thread_name_prefix="ProjZipExport") as executor:
        futures, futures_map = [], {}
        for proj in projects_list.values():
            future = executor.submit(__export_zip_thread, proj, export_timeout)
            futures.append(future)
            futures_map[future] = proj
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result(timeout=export_timeout + 10)  # Retrieve result or raise an exception
                status = result["exportStatus"]
            except TimeoutError as e:
                status = f"{ZIP_TIMEOUT}({export_timeout}s)"
                o_proj = futures_map[future]
                result = {"key": o_proj.key, "name": o_proj.name, "exportProjectUrl": o_proj.url(), "exportStatus": status}
                log.error(f"Project Zip export timed out after {export_timeout} seconds for {str(future)}.")
            except exceptions.UnsupportedOperation:
                raise
            except Exception as e:
                status = f"{ZIP_EXCEPTION}({e})"
                o_proj = futures_map[future]
                result = {"key": o_proj.key, "name": o_proj.name, "exportProjectUrl": o_proj.url(), "exportStatus": status}

            if re.match(r"\d\d\d .*", status):
                status = f"FAILED/HTTP_ERROR {status[0:3]}"
            elif status.startswith("TIMEOUT"):
                status = ZIP_TIMEOUT
            elif status.startswith("EXCEPTION"):
                status = ZIP_EXCEPTION
            try:
                conflict = next(proj for proj in results if proj.get("file", "") == result.get("file", " "))
                conflict["exportStatus"] = ZIP_CONFLICT
                statuses[SUCCESS] -= 1
                log.critical("Zip file export conflict detected between project keys '%s' and '%s'", result["key"], conflict["key"])
                statuses[ZIP_CONFLICT] = 1 if ZIP_CONFLICT not in statuses else statuses[ZIP_CONFLICT] + 1
            except StopIteration:
                pass
            results.append(result)
            statuses[status] = 1 if status not in statuses else statuses[status] + 1
            log.info("%s", ", ".join([f"{k}:{v}" for k, v in statuses.items()]))

    return results


def import_zip(endpoint: Platform, project_key: str, project_name: Optional[str] = None, import_timeout: int = 30) -> tuple[Project, str]:
    """Imports a project zip file"""
    project_name = project_name or project_key
    try:
        o_proj = Project.create(key=project_key, endpoint=endpoint, name=project_name)
    except exceptions.ObjectAlreadyExists:
        o_proj = Project.get_object(key=project_key, endpoint=endpoint)
    if o_proj.last_analysis() is None:
        s = o_proj.import_zip(asynchronous=False, timeout=import_timeout)
    else:
        s = ZIP_PROJ_EXISTS
    return o_proj, s


def import_zips(endpoint: Platform, project_list: list[dict[str, str]], threads: int = 2, import_timeout: int = 60) -> dict[str, dict[str, str]]:
    """Imports as zip all or a list of projects

    :param Platform endpoint: reference to the SonarQube platform
    :param int threads: Number of parallel threads for export, defaults to 2
    :param int import_timeout: Timeout to import the project, defaults to 60 s
    :return: import results
    """
    from sonar.tasks import SUCCESS

    if endpoint.edition() not in (c.EE, c.DCE):
        raise exceptions.UnsupportedOperation(f"Zip import unsupported on {endpoint.edition()} edition")
    nb_projects = len(project_list)
    log.info("Importing zip of %d projects", nb_projects)
    i = 0
    statuses_count = {SUCCESS: 0}
    statuses: dict[str, dict[str, str]] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads, thread_name_prefix="ProjZipImport") as executor:
        futures, futures_map = [], {}
        for proj in project_list:
            future = executor.submit(import_zip, endpoint, proj["key"], proj["name"], import_timeout)
            futures.append(future)
            futures_map[future] = proj["key"]
        for future in concurrent.futures.as_completed(futures):
            o_proj = None
            try:
                o_proj, status = future.result(timeout=import_timeout + 10)  # Retrieve result or raise an exception
            except TimeoutError as e:
                status = f"TIMEOUT Exception {e}"
                log.error(f"Project Zip import timed out after {import_timeout} seconds for {str(future)}.")
            except Exception as e:
                status = f"EXCEPTION {e}"
            statuses_count[status] = statuses_count[status] + 1 if status in statuses_count else 1
            if o_proj is None:
                proj_key = futures_map[future]
                statuses[proj_key] = {"importStatus": status}
            else:
                proj_key = o_proj.key
                statuses[proj_key] = {
                    "importDate": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "importProjectUrl": o_proj.url(),
                    "importStatus": status,
                }

            i += 1
            log.info("%d/%d imports (%d%%) - Latest: %s - %s", i, nb_projects, int(i * 100 / nb_projects), proj_key, status)
            log.info("%s", ", ".join([f"{k}:{v}" for k, v in statuses_count.items()]))
    return statuses
