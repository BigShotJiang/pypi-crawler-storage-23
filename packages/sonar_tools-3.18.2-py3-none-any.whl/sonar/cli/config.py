#!/usr/bin/env python3
#
# sonar-tools
# Copyright (C) 2022-2026 Olivier Korach
# mailto:olivier.korach AT gmail DOT com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
"""
Exports SonarQube platform configuration as JSON
"""

from typing import TextIO, Any, Optional
from threading import Thread
from queue import Queue

import json
import jsonschema
import yaml
import pathlib

from cli import options
from sonar import exceptions, errcodes, version
from sonar.util import misc as util
import sonar.utilities as sutil
from sonar.util import types, constants as c
from sonar.util import platform_helper as pfhelp
from sonar.util import project_helper as pjhelp
from sonar.util import portfolio_helper as foliohelp
from sonar.util import qualityprofile_helper as qphelp
from sonar.util import rule_helper as rhelp
from sonar.util import misc

import sonar.logging as log
from sonar import platform, rules, qualityprofiles, qualitygates, users, groups
from sonar import projects, portfolios, applications
from sonar.util import component_helper
import sonar.util.common_helper as chelp


TOOL_NAME = "sonar-config"

FULL_EXPORT = "fullExport"
EXPORT_EMPTY = "exportEmpty"

_SECTIONS_TO_SORT = ("projects", "applications", "portfolios", "users", "groups", "qualityGates", "qualityProfiles")
_SECTIONS_ORDER = (
    "platform",
    "globalSettings",
    "qualityGates",
    "qualityProfiles",
    "projects",
    "applications",
    "portfolios",
    "users",
    "groups",
    "rules",
)

_MIGRATION_EXPORT_SETTINGS = {
    "FULL_EXPORT": False,
    "INLINE_LISTS": False,
    EXPORT_EMPTY: True,
}

_EXPORT_CALLS = {
    c.CONFIG_KEY_PLATFORM: [c.CONFIG_KEY_PLATFORM, platform.basics],
    options.WHAT_SETTINGS: [c.CONFIG_KEY_SETTINGS, platform.export],
    options.WHAT_RULES: [c.CONFIG_KEY_RULES, rules.export],
    options.WHAT_PROFILES: [c.CONFIG_KEY_PROFILES, qualityprofiles.export],
    options.WHAT_GATES: [c.CONFIG_KEY_GATES, qualitygates.export],
    options.WHAT_PROJECTS: [c.CONFIG_KEY_PROJECTS, projects.export],
    options.WHAT_APPS: [c.CONFIG_KEY_APPS, applications.export],
    options.WHAT_PORTFOLIOS: [c.CONFIG_KEY_PORTFOLIOS, portfolios.export],
    options.WHAT_USERS: [c.CONFIG_KEY_USERS, users.export],
    options.WHAT_GROUPS: [c.CONFIG_KEY_GROUPS, groups.export],
}

WHAT_EVERYTHING = list(_EXPORT_CALLS.keys())[1:]


def __parse_args(desc: str) -> object:
    """Sets and parses all sonar-config options"""
    parser = options.set_common_args(desc)
    parser = options.set_key_arg(parser)
    parser = options.set_output_file_args(parser, allowed_formats=("json", "yaml"))
    parser = options.add_thread_arg(parser, "project export")
    parser = options.set_what(parser, what_list=WHAT_EVERYTHING, operation="export or import")
    parser = options.add_import_export_arg(parser, "configuration")
    parser.add_argument(
        f"--{FULL_EXPORT}",
        required=False,
        default=False,
        action="store_true",
        help="Also exports informative data that would be ignored as part of an import. Informative field are prefixed with _."
        "This option is ignored in case of import",
    )
    parser.add_argument(
        "--exportDefaults",
        required=False,
        default=False,
        action="store_true",
        help="Also exports settings values that are the platform defaults. "
        f"By default the export will show the value as '{sutil.DEFAULT}' "
        "and the setting will not be imported at import time",
    )
    parser.add_argument(
        f"--{EXPORT_EMPTY}",
        required=False,
        default=False,
        action="store_true",
        help="By default, sonar-config does not export empty values, setting this flag will add empty values in the export",
    )
    parser.add_argument(
        f"--{options.CONVERT_FROM}",
        required=False,
        help="Source sonar-config old JSON format file to convert to the new format",
    )
    parser.add_argument(
        f"--{options.CONVERT_TO}",
        required=False,
        help="Target sonar-config new JSON format file to write the converted data to",
    )
    parser.add_argument(
        f"--{options.VALIDATE_FILE}",
        required=False,
        action="store_true",
        help="Validate the JSON file against the schema",
    )
    return options.parse_and_check(parser=parser, logger_name=TOOL_NAME, verify_token=False)


def __get_schema(fmt: Optional[str] = "json") -> dict[str, Any]:
    """Gets the JSON schema for sonar-config"""

    schema_file = pathlib.Path(__file__).parent / f"sonar-config.schema.{fmt}"
    with open(schema_file, encoding="utf-8") as fh:
        txt = fh.read()
    return yaml.safe_load(txt) if fmt == "yaml" else json.loads(txt)


def __normalize_json(json_data: dict[str, Any], remove_empty: bool = True, remove_none: bool = True) -> dict[str, Any]:
    """Sorts a JSON file and optionally remove empty and none values"""
    sort_fields = {"users": "login", "groups": "name", "qualityGates": "name", "qualityProfiles": "language"}
    log.debug("Normalizing JSON - remove empty = %s, remove nones = %s", str(remove_empty), str(remove_none))
    json_data = util.order_keys(json_data, *_SECTIONS_ORDER)
    for key in [k for k in _SECTIONS_TO_SORT if k in json_data]:
        if isinstance(json_data[key], dict):
            json_data[key] = {k: json_data[key][k] for k in sorted(json_data[key])}
        else:
            json_data[key] = util.sort_list_by_key(json_data[key], sort_fields.get(key, "key"))
    return json_data


def __normalize_file(file: str, format: str) -> bool:
    """Normalizes a JSON or YAML file to order keys in a meaningful order (not necessarily alphabetically)
    :param str file: Filename to normalize
    :param str format: File format (json or yaml)
    :return: whether normaizalization succeeded"""
    try:
        with util.open_file(file, mode="r") as fd:
            json_data = json.loads(fd.read())
    except json.decoder.JSONDecodeError:
        log.warning("JSON Decode error while normalizing JSON file '%s', is file complete?", file)
        return False
    json_data = __normalize_json(json_data, remove_empty=False, remove_none=True)
    with util.open_file(file, mode="w") as fd:
        if format == "yaml":
            print(yaml.dump(json_data, sort_keys=False), file=fd)
        else:
            print(util.json_dump(json_data), file=fd)
    return True


def write_objects(queue: Queue[types.ObjectJsonRepr], fd: TextIO, object_type: str, export_settings: types.ConfigSettings) -> None:
    """
    Thread to write projects in the JSON file
    """
    done = False
    prefix = ""
    log.info("Waiting %s to write...", object_type)
    objects_exported_as_lists = ("projects", "applications", "users", "portfolios")
    objects_exported_as_whole = ("qualityGates", "groups", "qualityProfiles")
    log.info("Waiting %s to write...", object_type)
    if object_type in objects_exported_as_lists:
        start, stop = ("[", "]")
    elif object_type in objects_exported_as_whole:
        start, stop = ("", "")
    else:
        start, stop = ("{", "}")
    print(f'"{object_type}": ' + start, file=fd)
    while not done:
        obj_json = queue.get()
        if not (done := obj_json is sutil.WRITE_END):
            if object_type in ("groups", "globalSettings"):
                obj_json = __prep_json_for_write(obj_json, {**export_settings, EXPORT_EMPTY: True})
            else:
                obj_json = __prep_json_for_write(obj_json, export_settings)
            key = "" if isinstance(obj_json, list) else obj_json.get("key", obj_json.get("login", obj_json.get("name", "unknown")))
            log.debug("Writing %s key '%s'", object_type[:-1], key)
            if object_type in objects_exported_as_lists or object_type in objects_exported_as_whole:
                print(f"{prefix}{util.json_dump(obj_json)}", end="", file=fd)
            else:
                log.debug("Writing %s", object_type)
                print(f"{prefix}{util.json_dump(obj_json)[2:-1]}", end="", file=fd)
            prefix = ",\n"
        queue.task_done()
    print("\n" + stop, file=fd, end="")
    log.info("Writing %s complete", object_type)


def export_config(endpoint: platform.Platform, what: list[str], **kwargs) -> None:
    """Exports a platform configuration in a JSON file"""
    file = kwargs[options.REPORT_FILE]
    mode = kwargs.get("mode", "CONFIG")
    export_settings = kwargs.copy()
    export_settings.update(
        {
            "EXPORT_DEFAULTS": kwargs.get(FULL_EXPORT, False),
            "FULL_EXPORT": kwargs.get(FULL_EXPORT, False),
            "MODE": mode,
            "SKIP_ISSUES": kwargs.get("skipIssues", False),
        }
    )
    if mode == "MIGRATION":
        export_settings |= _MIGRATION_EXPORT_SETTINGS
    log.info("Exporting with settings: %s", util.json_dump(sutil.redact_tokens(export_settings)))
    if "projects" in what and kwargs[options.KEY_REGEXP]:
        if len(component_helper.get_components(endpoint, "projects", kwargs[options.KEY_REGEXP])) == 0:
            chelp.clear_cache_and_exit(errcodes.WRONG_SEARCH_CRITERIA, f"No projects matching regexp '{kwargs[options.KEY_REGEXP]}'")

    what.append(c.CONFIG_KEY_PLATFORM)
    log.info("Exporting configuration from %s", kwargs[options.URL])

    is_first = True
    write_q = Queue(maxsize=0)
    with util.open_file(file, mode="w") as fd:
        print("{", file=fd)
        for what_item, call_data in _EXPORT_CALLS.items():
            if what_item not in what:
                continue
            ndx, func = call_data
            if not is_first:
                print(",", file=fd)
            is_first = False
            worker = Thread(target=write_objects, args=(write_q, fd, ndx, export_settings))
            worker.daemon = True
            worker.name = f"Write{ndx[:1].upper()}{ndx[1:10]}"
            worker.start()
            try:
                func(endpoint, export_settings=export_settings, key_list=kwargs[options.KEY_REGEXP], write_q=write_q)
            except exceptions.UnsupportedOperation as e:
                log.warning(e.message)
                write_q and write_q.put(sutil.WRITE_END)
            write_q.join()
        print("\n}", file=fd)

    if file:
        __normalize_file(file, kwargs[options.FORMAT])
    else:
        log.info("Output is stdout, skipping normalization")
    log.info("Exporting %s data from %s completed", mode.lower(), kwargs[options.URL])


def __prep_json_for_write(json_data: types.ObjectJsonRepr, export_settings: types.ConfigSettings) -> types.ObjectJsonRepr:
    """Cleans up the JSON before writing"""
    json_data = misc.sort_lists(json_data)
    if export_settings.get("MODE", "CONFIG") == "MIGRATION":
        return json_data
    if not export_settings.get("FULL_EXPORT", False):
        json_data = misc.clean_data(json_data, remove_none=True, remove_empty=not export_settings.get(EXPORT_EMPTY, False))
    return json_data


def validate_schema(file: str) -> dict[str, Any]:
    """Validates a sonar-config JSON file against the schema

    :param: file: JSON or YAML file to validate
    :return: The loaded schema in JSOn format
    :raises: SonarException if the JSON or YAML file is not valid
    :raises: FileNotFoundError if the file does not exist
    """
    fmt = "yaml" if file.split(".")[-1].lower() in ("yaml", "yml") else "json"
    log.info("Validating %s file %s", fmt.upper(), file)
    try:
        with open(file, encoding="utf-8") as fd:
            txt = fd.read()
        json_data = yaml.safe_load(txt) if fmt == "yaml" else json.loads(txt)
        jsonschema.validate(json_data, __get_schema(fmt))
    except jsonschema.ValidationError as e:
        json_path = e.json_path.split(".")
        json_path.pop(0)
        cur_obj = json_data
        path_str = ""
        for path in json_path:
            # TODO: Replace with jsonschema.PathElement when moving to python 3.11+
            if "[" in path:
                obj_type = path.split("[")[0]
                obj_index = int(path.split("[")[1].split("]")[0])
                cur_obj = cur_obj[obj_type][obj_index]
                key = next((k for k in cur_obj if k in ("key", "name", "login", "group", "language")), None)
                path_str += f".{path}" if key is None else f".{obj_type}[{cur_obj[key]}]"
            else:
                cur_obj = cur_obj[path]
                path_str += f".{path}"
        schema_url = f"https://github.com/okorach/sonar-tools/blob/master/sonar/cli/sonar-config.schema.{fmt}"
        raise exceptions.SonarException(
            f"{fmt.upper()} file '{file}' does not respect the sonar-config {fmt.upper()} schema:\n"
            f"-> See schema at: {schema_url}\n"
            f"-> Error occured at: {path_str.lstrip('.')} -> {e.message}",
            errcodes.SCHEMA_ERROR,
        ) from e
    except FileNotFoundError as e:
        chelp.clear_cache_and_exit(errcodes.OS_ERROR, f"OS error while reading file: {e}")

    log.info("JSON file '%s' is valid", file)
    return json_data


def __import_config(endpoint: platform.Platform, what: list[str], **kwargs) -> None:
    """Imports a platform configuration from a JSON file"""
    log.info("Importing configuration to %s", kwargs[options.URL])
    data = validate_schema(kwargs[options.REPORT_FILE])
    key_list = kwargs[options.KEY_REGEXP]

    calls = {
        options.WHAT_GROUPS: groups.import_config,
        options.WHAT_USERS: users.import_config,
        options.WHAT_GATES: qualitygates.import_config,
        options.WHAT_RULES: rules.import_config,
        options.WHAT_PROFILES: qualityprofiles.import_config,
        options.WHAT_SETTINGS: platform.import_config,
        options.WHAT_PROJECTS: projects.import_config,
        options.WHAT_APPS: applications.import_config,
        options.WHAT_PORTFOLIOS: portfolios.import_config,
    }

    for what_item, func in calls.items():
        if what_item in what:
            try:
                func(endpoint, data, key_list=key_list)
            except exceptions.UnsupportedOperation as e:
                log.warning(e.message)
    log.info("Importing configuration to %s completed", kwargs[options.URL])


def convert_json(original_json: dict[str, Any]) -> dict[str, Any]:
    """Converts a sonar-config JSON file from the old to new format"""
    mapping = {
        "platform": pfhelp.convert_basics_json,
        "globalSettings": pfhelp.convert_global_settings_json,
        "qualityGates": qualitygates.convert_qgs_json,
        "qualityProfiles": qphelp.convert_qps_json,
        "projects": pjhelp.convert_projects_json,
        "portfolios": foliohelp.convert_portfolios_json,
        "applications": applications.convert_apps_json,
        "users": users.convert_users_json,
        "groups": groups.convert_groups_json,
        "rules": rhelp.convert_rules_json,
    }
    new_json = {}
    for k, func in mapping.items():
        if k in original_json:
            log.info("Converting %s", k)
            new_json[k] = func(original_json[k])
    return __normalize_json(new_json, remove_empty=False, remove_none=True)


def convert_json_file(from_file: str, to_file: Optional[str]) -> None:
    """Converts a sonar-config report from the old to the new JSON format"""
    with open(from_file, encoding="utf-8") as fd:
        new_json = convert_json(json.loads(fd.read()))
    with util.open_file(to_file) as fd:
        print(util.json_dump(new_json), file=fd)


def main() -> None:
    """Main entry point for sonar-config"""
    start_time = util.start_clock()
    try:
        kwargs = sutil.convert_args(__parse_args("Extract SonarQube Server or Cloud platform configuration"))
        if kwargs[options.CONVERT_FROM] is not None:
            convert_json_file(kwargs[options.CONVERT_FROM], kwargs.get(options.CONVERT_TO, None))
            chelp.clear_cache_and_exit(errcodes.OK, "", start_time)
        if kwargs[options.VALIDATE_FILE] is True:
            validate_schema(kwargs[options.REPORT_FILE])
            chelp.clear_cache_and_exit(errcodes.OK, "", start_time)
        log.info("Checking token")
        sutil.check_token(kwargs[options.TOKEN], sutil.is_sonarcloud_url(kwargs[options.URL]))
        log.info("Token OK")
        endpoint = platform.Platform(**kwargs)
        endpoint.verify_connection()
        endpoint.set_user_agent(f"{TOOL_NAME} {version.PACKAGE_VERSION}")

        if not kwargs[options.EXPORT] and not kwargs[options.IMPORT]:
            raise exceptions.SonarException(f"One of --{options.EXPORT} or --{options.IMPORT} option must be chosen", errcodes.ARGS_ERROR)

        what = sutil.check_what(kwargs.pop(options.WHAT, None), WHAT_EVERYTHING, "exported or imported")
        if options.WHAT_PROFILES in what and options.WHAT_RULES not in what:
            what.append(options.WHAT_RULES)
        kwargs[options.FORMAT] = util.deduct_format(kwargs[options.FORMAT], kwargs[options.REPORT_FILE], allowed_formats=("json", "yaml"))
        if kwargs[options.EXPORT]:
            export_config(endpoint, what, **kwargs)
        elif kwargs[options.IMPORT]:
            if kwargs["file"] is None:
                chelp.clear_cache_and_exit(errcodes.ARGS_ERROR, "--file is mandatory to import configuration")
            __import_config(endpoint, what, **kwargs)
    except exceptions.SonarException as e:
        chelp.clear_cache_and_exit(e.errcode, e.message)
    except (PermissionError, FileNotFoundError) as e:
        chelp.clear_cache_and_exit(errcodes.OS_ERROR, f"OS error while exporting config: {e}")

    chelp.clear_cache_and_exit(errcodes.OK, "", start_time)


if __name__ == "__main__":
    main()
