"""AccessPDF — PDF accessibility remediation tool."""

__version__ = "1.0.0"
