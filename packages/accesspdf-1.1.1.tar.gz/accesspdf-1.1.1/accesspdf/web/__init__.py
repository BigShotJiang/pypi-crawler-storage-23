"""Web UI for browser-based PDF accessibility review."""
