"""Octen SDK 版本信息"""

__version__ = "0.1.1b5"
__author__ = "Octen Team"
__license__ = "MIT"
