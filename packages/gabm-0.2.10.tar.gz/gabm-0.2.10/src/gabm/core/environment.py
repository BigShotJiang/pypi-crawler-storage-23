"""
Environment module for GABM.
<<<<<<< HEAD
=======

This is the core environment module for GABM, which is for details of the computing environment in which GABM runs.
That could be an individual machine, a cluster, cloud computer, or distributed computer.
>>>>>>> upstream/main
"""
# Metadata
__author__ = ["Andy Turner <agdturner@gmail.com>"]
__version__ = "0.1.0"
__copyright__ = "Copyright (c) 2026 GABM contributors, University of Leeds"
