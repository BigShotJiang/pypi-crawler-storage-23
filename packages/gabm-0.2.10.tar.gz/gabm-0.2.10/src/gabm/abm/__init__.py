"""GABM: Generative Agent-Based Model framework abm package."""
__version__ = "0.2.10"