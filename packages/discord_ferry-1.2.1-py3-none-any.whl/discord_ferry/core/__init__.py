"""Core migration engine and event system."""
