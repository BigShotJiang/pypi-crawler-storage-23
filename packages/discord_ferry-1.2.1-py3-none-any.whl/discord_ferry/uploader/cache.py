"""Upload cache — handled by state.upload_cache and autumn.upload_with_cache."""
