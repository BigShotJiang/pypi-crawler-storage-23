# Minimal setup.py — all metadata is in pyproject.toml
from setuptools import setup
setup()
