"""
GraphBus CLI - Command-line interface for GraphBus framework
"""

__version__ = "0.4.0"
