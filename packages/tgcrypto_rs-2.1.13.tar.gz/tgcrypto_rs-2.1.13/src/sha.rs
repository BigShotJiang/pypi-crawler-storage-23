use ::sha1::{Digest, Sha1};
use ::sha2::Sha256;
use pyo3::prelude::*;
use pyo3::types::PyBytes;

#[inline(always)]
#[pyfunction]
#[pyo3(signature = (data, /))]
pub fn sha1<'py>(py: Python<'py>, data: &[u8]) -> PyResult<Bound<'py, PyBytes>> {
    let hash = py.detach(|| {
        let mut hasher = Sha1::new();
        hasher.update(data);
        hasher.finalize()
    });
    Ok(PyBytes::new(py, hash.as_slice()))
}

#[inline(always)]
#[pyfunction]
#[pyo3(signature = (data, /))]
pub fn sha256<'py>(py: Python<'py>, data: &[u8]) -> PyResult<Bound<'py, PyBytes>> {
    let hash = py.detach(|| {
        let mut hasher = Sha256::new();
        hasher.update(data);
        hasher.finalize()
    });
    Ok(PyBytes::new(py, hash.as_slice()))
}
