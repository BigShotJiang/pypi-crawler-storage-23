## Exemples de use cases utilisant des LLMs aujourd'hui difficilement couverts par la plateforme:

### Bibliothèque de prompts
Aujourd'hui disposer de bons prompts (template de prompts) par défaut pour une liste de tâches prédéfinies est compliqué. Il faut connaître des projets dans lesquels telle ou telle approche a été implémentée avec succès pour aller copier/coller le prompt utilisé dans notre nouveau projet. Aucune capitalisation ni partage de connaissance.
De même si un même prompt doit être utilisé pour tester plusieurs LLMs dans un même projet ou simplement faire varier certains paramètres du LLM (taille de contexte, température, etc...), là encore c'est copier/coller dans tous les sens.
Besoins:
- pouvoir réutiliser facilement des "bons" prompts globaux ou définis au niveau projet
- éventuellement pouvoir combiner des fragments de prompts en un meta prompt, ces fragments pouvant avoir une fonction différente (définition de persona, tonalité, langue, format de sortie attendu, etc...) ou permettre de modéliser une décomposition d'une Chain-of-Though en steps de raisonnements


### 0-shot / few shot learning (EvalLLM)
Le projet démarre juste avec quelques labels, le nom des labels est suffisamment descriptif pour permettre un apprentissage sans exemples (catégo et? NER)
Besoins:
- injecter dans le prompt la liste de labels (juste le label name ou name + label) 
- avoir un prompt par défaut prédéfini (dans une bilbiothèque? voir point précédent) qui permette ce genre de tâche par exemple comme ce qui est disponible dans [spacy](https://github.com/explosion/spacy-llm/tree/main/spacy_llm/tasks/templates)
- pouvoir utiliser un annotateur/plan quelqueconque dans une boucle de suggestion

Si le projet dispose de guidelines générales et par label, pouvoir utiliser ces instuctions pour améliorer encore le prompt
Besoins
- injecter dans le prompt, non seulement la liste de labels mais aussi les guidelines (voir encore spacy et les injections des label_definitions dans https://github.com/explosion/spacy-llm/blob/main/spacy_llm/tasks/templates/ner.v2.jinja)

Si le projet dispose de quelques examples annotés (segments annotés manuellement avec une metadonnée `Example=true` ?), les utiliser pour faire du few-shot learning
Besoins:
- injecter dans le prompt, quelques exemples dans un format à trouver (voir encore spacy et les injections des examples dans https://github.com/explosion/spacy-llm/blob/main/spacy_llm/tasks/templates/ner.v2.jinja)

### Enchainer les appels LLMs où la sortie du premier constituent l'entrée du suivant
Par exemple pour la tâche de résumé pour X-CAGO, Kevin a mis en place un résumé en 2 passes.
Un 1er LLM créé un premier résumé dont la longueur dépend de la taille du texte d'entrée (% de mots du doc)
Un 2ᵉ LLM fait un abstract d'une seule ligne à partir du 1er résumé
En pratique le 1er appel LLM met son résumé dans un 1er altText "summary"
Le second prend en entrée l'altText "résumé" et non pas le texte du documet et stocke son résumé de résumé dans un 2ᵉ altText "abstract"
Eventuellement un autre prompt pourrait aussi lister les 10 mots clés les plus descriptifs pour le document d'origine et stocker le résultat dans un altText "keywords"
Aujourd'hui c'est au niveau du processeur openai_completion que le choix de stocker le résultat est fait et pour utliser le contenu d'un altText en entrée, il faut faire un bout de jinja complexe pour le récupérer et l'injecter dans le prompt.
Besoins:
- généraliser le concept d'applyTo déja présent dans les pipelines aux altText pour ne pas faire ce choix dans les différents processeurs ? 
- ajouter un resultIn/writeIn dans le pipeline qui permette aussi de définir pour les processeurs qui générent un résultat textuel où le stocker (par défaut dans le texte du doc d'entrée, mais peut-être dans un altText sans changer le texte du doc) ??

### Pouvoir injecter dans un prompt des informations contextuelles qui vont au delà du document
On a déja vu la nécessité de pouvoir injecter des données provenant du projet avec les labels, les guidelines et les exemples.
Dans les scénarios chatbot, on voit aussi se profiler des besoins d'injecter des données supplémentaires provenant du projet (propriétes ? résultats de recherche ?) ou du profil utilisateur (propriété ? persona ?)
Aujourd'hui on n'a pas cette possibilité, dans le pipeline RAG on a fait le choix de passer les résultats de recherche issus d'elasticsearch dans une métadonnée de façon à pouvoir ensuite la réutiliser dans un pseudo document.
Ne pourrions-nous pas envisager une modélisation plus avancée ?
Par exemple en regroupant dans un object Context les informations qui ne sont pas du ressort du document et que l'on pourrait passer de manière optionnelle à un processeur ? Chaque processeur pourrait éventuellement de manière déclarative sous forme de tags (dans sa docstring OpenAPI ?) indiquer s'il a besoin d'un contexte et quels éléments du contexte il veut ?
Bruno avait déja introduit ce genre de mécanisme avec `#consumes:annotation` et `#produces:annotations`, à voir comment généraliser et effectivement utiliser ces mécanismes

L'object Context pourrait avoir plusieurs entrées facultatives :
- project
  - labels
  - examples
  - properties
  - searchHits
- user
  - properties

```
def process(
            self, documents: List[Document], parameters: ProcessorParameters, context: Optional[Context]=None
    ) -> List[Document]:
        #consumes:text,context.labels,context.searchHits
        #produces:text
```

Cela permettrait d'envisager un vrai pipeline explicite permettant de modéliser un pipeline RAG/Chat (ou 0-shot, etc...) de manière explicite et plus implicite comme le pipeline RAG actuel en passant de vrais documents et contextes ?

```
            {
                  "pipeline": [
                    {
                        "processor": "contextual_rag_context_builder"
                    },
                    {
                        "processor": "contextual_question_answerer"
                    }
              ]
            }
```



