"""Entry point for python -m slop_mcp."""

import sys

from slop_mcp import main

if __name__ == "__main__":
    sys.exit(main())
