"""Skaro Web Dashboard package."""
