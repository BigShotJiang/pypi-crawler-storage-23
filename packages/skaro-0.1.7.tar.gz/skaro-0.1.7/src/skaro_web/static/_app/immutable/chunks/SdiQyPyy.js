import{c,a as p}from"./BLoZk-4Q.js";import"./DnbEMVOy.js";import{f as i}from"./CkWh75VR.js";import{I as l,s as m}from"./Bmr4jBBJ.js";import{l as d,s as f}from"./BIAtSU2q.js";function k(t,o){const e=d(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M20 6 9 17l-5-5"}]];l(t,f({name:"check"},()=>e,{get iconNode(){return r},children:(a,$)=>{var s=c(),n=i(s);m(n,o,"default",{}),p(a,s)},$$slots:{default:!0}}))}export{k as C};
