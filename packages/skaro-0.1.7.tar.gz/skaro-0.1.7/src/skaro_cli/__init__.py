"""Skaro CLI package."""
