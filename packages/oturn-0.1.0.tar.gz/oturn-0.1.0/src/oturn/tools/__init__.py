"""OTURN tools package.

No global registry is created at import time.
Tools should be supplied explicitly to ``Oturn(..., tools=[...])``.
"""

from .base import BaseTool, BaseToolRegistry, ToolResult, ToolType
from .examples import WeatherTool, HostConfigTool, EXAMPLE_TOOLS

__all__ = [
    "BaseTool",
    "BaseToolRegistry",
    "ToolResult",
    "ToolType",
    "WeatherTool",
    "HostConfigTool",
    "EXAMPLE_TOOLS",
]
