from dataclasses import dataclass
from typing import Any, Dict, List, Optional


STATUS_ALLOW = "allow"
STATUS_DENY = "deny"
STATUS_NEEDS_APPROVAL = "needs_approval"


@dataclass
class ToolPrecheckResult:
    status: str
    message: Optional[str] = None
    reasons: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None
