from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class OturnProviderConfig:
    api_base: str = ""
    api_key: Optional[str] = None
    debug_request: bool = False
    debug_sse: bool = False
    debug_tools: bool = False


@dataclass(frozen=True)
class OturnModelConfig:
    max_output_tokens: Optional[int] = None
    temperature: Optional[float] = None
    extra_body: Optional[dict[str, Any]] = None


@dataclass(frozen=True)
class OturnAgentConfig:
    max_steps: int = 100
    user_name: str = "User"
    email: Optional[str] = None


@dataclass(frozen=True)
class OturnConfig:
    model: str
    provider: OturnProviderConfig
    model_config: OturnModelConfig
    agent_config: OturnAgentConfig
    debug_loop: bool = False
