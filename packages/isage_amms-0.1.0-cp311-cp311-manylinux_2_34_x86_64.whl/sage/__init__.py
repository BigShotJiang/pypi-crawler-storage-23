"""SAGE-AMMS: Approximate Matrix Multiplication algorithms."""

__version__ = "0.1.0"
