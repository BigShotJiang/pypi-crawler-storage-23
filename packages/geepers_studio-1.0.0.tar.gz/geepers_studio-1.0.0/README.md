# Studio Multi-Provider LLM Interface

A Flask-based web interface for interacting with multiple language model providers (Anthropic, OpenAI, Cohere, Mistral, Perplexity, xAI, Gemini) with support for chat, image generation, video generation, and image analysis.

## Quick Start

### Using the Management Script (Recommended)

```bash
# Start the server
./studio.sh start

# Stop the server
./studio.sh stop

# Restart the server
./studio.sh restart

# Check server status
./studio.sh status

# View live logs
./studio.sh logs
```

### Direct Python Launch

```bash
# Activate virtual environment
source venv/bin/activate

# Run the app
python app.py
```

## Configuration

### Environment Variables

Create a `.env` file in the project root with your API keys:

```env
# Flask Configuration
FLASK_SECRET_KEY=your-secret-key-here
STUDIO_PORT=5413

# LLM Provider API Keys
ANTHROPIC_API_KEY=your-key-here
OPENAI_API_KEY=your-key-here
COHERE_API_KEY=your-key-here
MISTRAL_API_KEY=your-key-here
PERPLEXITY_API_KEY=your-key-here
XAI_API_KEY=your-key-here
GEMINI_API_KEY=your-key-here

# Optional: Base path for reverse proxy
STUDIO_BASE_PATH=/studio
```

### Password

Default password: `friendship`

To change, edit `PASSWORD` in `app.py` (line 28).

## Features

### Chat
- Multi-provider chat interface
- Conversation history management
- Model selection per provider
- Streaming responses

### Image Generation
- Providers: OpenAI (DALL-E), xAI (Aurora)
- Save generated images
- Image prompt library

### Image Analysis
- Providers: Anthropic (Claude Vision), OpenAI (GPT-4 Vision)
- Upload and analyze images
- Custom analysis prompts

### Video Generation
- Providers: xAI (Grok Video) - when available
- Text-to-video and image-to-video

## Troubleshooting

### Port Already in Use

If you see "Port 5413 is already in use":

```bash
# Kill existing processes
./studio.sh stop

# Or manually
kill -9 $(lsof -ti :5413)

# Or use a different port
export STUDIO_PORT=5414
./studio.sh start
```

### Provider Initialization Errors

Check the startup logs to see which providers failed to initialize:

```bash
./studio.sh logs
```

Common issues:
- Missing API keys in `.env` file
- Invalid API keys
- Shared library not found (`/home/coolhand/shared/llm_providers`)

### Import Errors

If you see import errors for the shared library:

```bash
# Verify shared library path
ls -la /home/coolhand/shared/llm_providers/

# Check if all provider modules exist
ls /home/coolhand/shared/llm_providers/*_provider.py
```

## Project Structure

```
studio/
├── app.py                      # Main Flask application
├── studio.sh                   # Management script
├── requirements.txt            # Python dependencies
├── .env                        # Environment variables (create this)
├── templates/
│   ├── index.html             # Main UI
│   └── login.html             # Login page
├── providers/
│   ├── __init__.py            # Provider exports
│   └── studio_adapters.py     # Adapters for shared library
├── prompts.json               # Saved prompts (auto-created)
├── saved_images.json          # Saved images (auto-created)
└── studio.log                 # Application logs
```

## API Endpoints

- `GET /` - Main interface
- `GET /login` - Login page
- `GET /logout` - Logout
- `POST /chat` - Send chat message
- `POST /generate-image` - Generate image
- `POST /generate-video` - Generate video
- `POST /analyze-image` - Analyze image
- `POST /save-prompt` - Save prompt
- `GET /get-prompts/<type>` - Get saved prompts
- `GET /get-saved-images` - Get saved images
- `POST /clear-chat` - Clear conversation history

## Development

### Running in Debug Mode

Debug mode is enabled by default when running with `python app.py` or `./studio.sh start`.

To disable debug mode, edit `app.py` line 434:

```python
app.run(host="0.0.0.0", port=PORT, debug=False)
```

### Adding New Providers

1. Create provider in shared library: `/home/coolhand/shared/llm_providers/`
2. Import in `providers/studio_adapters.py`
3. Create adapter class in `providers/studio_adapters.py`
4. Export from `providers/__init__.py`
5. Initialize in `app.py` (around line 95)

## Accessibility Considerations

- Semantic HTML structure
- ARIA labels for interactive elements
- Keyboard navigation support
- Clear error messages
- High contrast UI elements

## Security Notes

- Password authentication required
- Session-based authentication
- API keys stored in environment variables
- Never commit `.env` file to git

## License

MIT License

## Author

Lucas "Luke" Steuber
