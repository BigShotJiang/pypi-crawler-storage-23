Click on the "Preview" tab and select appropriate PR template:

[New Feature](?expand=1&template=feature.md)
[Bug Fix](?expand=1&template=bug-fix.md)
[Improvement](?expand=1&template=improvement.md)
