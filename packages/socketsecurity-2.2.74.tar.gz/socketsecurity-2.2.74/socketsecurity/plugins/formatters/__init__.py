"""Formatters for Socket security data output."""

from .slack import format_socket_facts_for_slack

__all__ = ['format_socket_facts_for_slack']
