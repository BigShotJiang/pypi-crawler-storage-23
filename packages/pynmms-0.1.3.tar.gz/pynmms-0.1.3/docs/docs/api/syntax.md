# Syntax

::: pynmms.syntax.Sentence
    options:
      show_source: true

::: pynmms.syntax.parse_sentence

::: pynmms.syntax.is_atomic

::: pynmms.syntax.all_atomic
