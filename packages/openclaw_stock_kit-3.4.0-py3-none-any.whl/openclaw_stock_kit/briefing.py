#!/usr/bin/env python3
"""StockClaw Kit — Auto Briefing

Collects data from multiple sources and generates formatted market briefings.

Usage:
    openclaw-stock-kit briefing morning
    openclaw-stock-kit briefing closing
    openclaw-stock-kit briefing morning --send-telegram @channel
    openclaw-stock-kit briefing morning --format json
"""

import json
import logging
from datetime import datetime, timezone, timedelta

logger = logging.getLogger("briefing")

KST = timezone(timedelta(hours=9))

_WEEKDAYS_KR = ["월", "화", "수", "목", "금", "토", "일"]


class BriefingRunner:
    """Collects market data from multiple tools and produces a text briefing."""

    def __init__(self, mcp):
        self.mcp = mcp
        self.collected = {}

    def run(self, mode="morning", output_format="text"):
        """Run data collection and return formatted briefing."""
        now = datetime.now(KST)
        if mode == "morning":
            self._collect_morning(now)
        elif mode == "closing":
            self._collect_closing(now)
        else:
            return json.dumps({"error": f"Unknown mode: {mode}"})

        if output_format == "json":
            return json.dumps(self.collected, ensure_ascii=False, indent=2,
                              default=str)
        return self._format_text(mode, now)

    # ── Data collection ───────────────────────────────────────

    def _safe_call(self, tool, params):
        try:
            raw = self.mcp.call(tool, params)
            result = json.loads(raw)
            if result.get("success"):
                return result
            logger.debug(f"[{tool}] error: {result.get('error', '')}")
        except Exception as e:
            logger.debug(f"[{tool}] failed: {e}")
        return None

    def _collect_morning(self, now):
        yesterday = (now - timedelta(days=1)).strftime("%Y%m%d")
        today = now.strftime("%Y%m%d")

        # 1) KOSPI / KOSDAQ 지수 (PyKRX — free)
        for label, ticker in [("kospi", "1001"), ("kosdaq", "2001")]:
            r = self._safe_call("datakit_call", {
                "function": "get_index",
                "params_json": json.dumps({
                    "ticker": ticker, "start": yesterday, "end": today}),
            })
            if r:
                self.collected[label] = r.get("data") or r

        # 2) 거래대금 TOP 10 (Kiwoom)
        r = self._safe_call("kiwoom_call_api", {"tr_id": "ka10032"})
        if r:
            data = r.get("data", [])
            self.collected["volume_top"] = (
                data[:10] if isinstance(data, list) else data)

        # 3) 외인/기관 순매수 (Kiwoom)
        for key, tr in [("foreign_net", "ka10059"), ("inst_net", "ka10060")]:
            r = self._safe_call("kiwoom_call_api", {"tr_id": tr})
            if r:
                data = r.get("data", [])
                self.collected[key] = (
                    data[:5] if isinstance(data, list) else data)

        # 4) 미국장 — 나스닥/S&P500 (KIS overseas)
        for key, sym, exch in [("nasdaq", "COMP", "NAS"),
                               ("sp500", "SPX", "NYS")]:
            r = self._safe_call("kis_overseas_stock", {
                "action": "inquire_price",
                "params": {"symbol": sym, "exchange": exch},
            })
            if r:
                self.collected[key] = r.get("data") or r

        # 5) 원/달러 환율 (EXIM)
        r = self._safe_call("datakit_call", {
            "function": "exchange_rate",
            "params_json": json.dumps({"currency": "USD"}),
        })
        if r:
            self.collected["usd_krw"] = r.get("data") or r

        # 6) 뉴스 헤드라인 (Naver)
        r = self._safe_call("news_search", {
            "query": "증시 코스피", "display": 5, "sort": "date",
        })
        if r:
            self.collected["news"] = r.get("items", [])[:5]

    def _collect_closing(self, now):
        """Closing = morning data + day-summary extras."""
        self._collect_morning(now)
        # 당일 급등주 (추가)
        r = self._safe_call("kiwoom_call_api", {"tr_id": "ka10030"})
        if r:
            data = r.get("data", [])
            self.collected["surge_top"] = (
                data[:10] if isinstance(data, list) else data)

    # ── Text formatter ────────────────────────────────────────

    def _format_text(self, mode, now):
        date_str = now.strftime(f"%Y-%m-%d {_WEEKDAYS_KR[now.weekday()]}")
        label = "오전장 브리핑" if mode == "morning" else "장 마감 브리핑"
        lines = [f"StockClaw {label} ({date_str})", ""]

        # ■ 미국장
        us_parts = []
        for key, name in [("nasdaq", "나스닥"), ("sp500", "S&P500")]:
            d = self.collected.get(key)
            if not d:
                continue
            price = _pick(d, "현재가", "price", "close", "stck_prpr",
                          "ovrs_nmix_prpr")
            chg = _pick(d, "등락률", "change_rate", "prdy_ctrt",
                        "ovrs_nmix_prdy_ctrt")
            if price:
                s = f"  {name}: {price}"
                if chg:
                    s += f" ({chg}%)" if "%" not in str(chg) else f" ({chg})"
                us_parts.append(s)
        usd = self.collected.get("usd_krw")
        if usd:
            rate = _pick(usd, "환율", "rate", "deal_bas_r", "value")
            if rate:
                us_parts.append(f"  원/달러: {rate}원")
        if us_parts:
            lines.append("■ 미국장")
            lines.extend(us_parts)
            lines.append("")

        # ■ 한국장
        kr_parts = []
        for key, name in [("kospi", "코스피"), ("kosdaq", "코스닥")]:
            d = self.collected.get(key)
            if not d:
                continue
            close = _pick(d, "종가", "close", "체결가")
            chg = _pick(d, "등락률", "change_rate", "등락율")
            if close:
                s = f"  {name}: {close}"
                if chg:
                    s += f" ({chg}%)" if "%" not in str(chg) else f" ({chg})"
                kr_parts.append(s)
        if kr_parts:
            lines.append("■ 한국장")
            lines.extend(kr_parts)
            lines.append("")

        # ■ 거래대금 TOP
        vol = self.collected.get("volume_top")
        if isinstance(vol, list) and vol:
            lines.append("■ 거래대금 TOP")
            for i, item in enumerate(vol[:5], 1):
                n = item.get("종목명", item.get("name", ""))
                a = item.get("거래대금", item.get("trading_value", ""))
                lines.append(f"  {i}. {n} ({a})")
            lines.append("")

        # ■ 수급
        for key, title in [("foreign_net", "외인 순매수"),
                           ("inst_net", "기관 순매수")]:
            data = self.collected.get(key)
            if not isinstance(data, list) or not data:
                continue
            lines.append(f"■ {title}")
            for item in data[:3]:
                n = item.get("종목명", item.get("name", ""))
                a = item.get("순매수량", item.get("net_buy", ""))
                lines.append(f"  {n} ({a})")
            lines.append("")

        # ■ 급등주 (closing only)
        surge = self.collected.get("surge_top")
        if isinstance(surge, list) and surge:
            lines.append("■ 당일 급등주")
            for i, item in enumerate(surge[:5], 1):
                n = item.get("종목명", item.get("name", ""))
                c = item.get("등락률", item.get("change_rate", ""))
                lines.append(f"  {i}. {n} ({c}%)")
            lines.append("")

        # ■ 뉴스
        news = self.collected.get("news")
        if news:
            lines.append("■ 주요 뉴스")
            for item in news[:5]:
                t = item.get("title", "")
                s = item.get("source", "")
                lines.append(f"  - {t} — {s}" if s else f"  - {t}")
            lines.append("")

        if not any(self.collected.values()):
            lines.append("(수집된 데이터 없음. API 키를 확인하세요.)")

        return "\n".join(lines)


# ── Helper ────────────────────────────────────────────────────

def _pick(data, *field_names):
    """Try multiple field names against data (dict or list[0])."""
    targets = [data] if isinstance(data, dict) else []
    if isinstance(data, dict):
        for k in ("data", "output", "result"):
            v = data.get(k)
            if isinstance(v, dict):
                targets.append(v)
            elif isinstance(v, list) and v:
                targets.append(v[0])
    elif isinstance(data, list) and data:
        targets.append(data[0])
    for obj in targets:
        if not isinstance(obj, dict):
            continue
        for name in field_names:
            val = obj.get(name)
            if val is not None:
                return val
    return None
