---
name: stock-kit
description: "Korean stock market data & trading toolkit. CLI direct call. Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트, 종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당, stock, price, trade, order, balance, news, disclosure, chart, KOSPI. Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency"
argument-hint: "[종목명|질문]"
user-invokable: true
---

# StockClaw Kit — CLI 직접 호출 가이드

> **중요**: 모든 도구는 반드시 `openclaw-stock-kit call` 명령으로 호출한다.
> `openclaw` CLI가 아니라 `openclaw-stock-kit` CLI를 사용한다.

---

## 도구 선택 가이드 (반드시 먼저 읽을 것)

사용자 요청을 받으면 아래 규칙에 따라 도구를 선택한다. **TOOLS.md 없이도 이 규칙만으로 판단한다.**

### 기본 원칙: PyKRX 먼저, 증권사 API는 필요할 때만

| 구분 | 도구 | 사용 조건 |
|------|------|----------|
| **[기본값]** `datakit_call` (PyKRX) | 주가, 종목검색, 시총, 거래량, 수급, 지수, 일봉 차트 | 인증 불필요. **항상 먼저 시도.** |
| **[매매전용]** `kiwoom_call_api` | 실시간 현재가, 분봉, 호가, 매수/매도, 잔고, 예수금 | API 키 필요. 실전 20회/s, 모의 2회/s. |
| **[매매전용]** `kis_domestic_stock` | 국내 시세, 주문, 잔고, 체결 | API 키 필요. 조회 10/s, 주문 5/s 권장. 차트 1회 100건. |
| **[해외전용]** `kis_overseas_stock` | 미국/중국/일본 등 해외 주식 | API 키 필요. 조회 10/s, 차트 1회 100건. |
| **[뉴스]** `news_search_stock` | 종목별 뉴스 검색 | 네이버 API 키 필요. |
| **[알림]** `telegram_send_alert` | 분석 결과/알림을 텔레그램으로 발송 | 텔레그램 인증 필요. |
| **[공시]** `datakit_call` (DART) | 기업개황, 최대주주, 임원, 공시 | DART API 키 필요. |

### 데이터 소스별 커버리지 매트릭스 (도구 선택의 핵심)

| 데이터 항목 | PyKRX (무료) | 키움 (유료) | KIS (유료) | 비고 |
|------------|:---:|:---:|:---:|------|
| 종목 검색/코드 조회 | O | O | O | PyKRX 우선 |
| 과거 일봉 (OHLCV) | **최적** | O (600건/회) | O (100건/회) | 대량 수집 = PyKRX |
| 실시간 현재가 (장중) | **X** | **O** | **O** | PyKRX는 전일 종가만 |
| 분봉/틱 차트 | **X** | **O** | **O** | 1분/3분/5분/일 등 |
| 호가창 (매수/매도 10호가) | **X** | **O** | **O** | |
| 체결강도/체결 틱 | **X** | **O** | **O** | |
| 거래대금/거래량 순위 | **부정확** | **정확 (NXT 합산)** | **정확 (NXT 합산)** | ⚠️ 아래 NXT 경고 참조 |
| 시가총액/PER/PBR | O | O | O | PyKRX 우선 |
| 수급 (외인/기관/개인) | O | O | O | PyKRX 우선 |
| 업종/테마별 종목 | X | **O** | 일부 | 키움 우선 |
| 조건검색 | X | **O** | X | 키움 전용 |
| 매수/매도 주문 | X | **O** | **O** | |
| 잔고/예수금/계좌 | X | **O** | **O** | |
| 해외주식 (미국/일본/중국) | X | X | **O** | KIS 전용 |
| 뉴스 검색 | X | X | X | `news_search_stock` |
| 공시 (DART) | O (DART) | X | X | DART API 키 필요 |
| 금리/환율/GDP | O (ECOS) | X | X | ECOS/EXIM API 키 |

### ⚠️ PyKRX 한계 — 반드시 숙지

1. **NXT(넥스트레이드) 미합산** — PyKRX의 거래대금/거래량은 KRX 정규장만 집계. NXT 대체거래소 물량 미포함.
   - "거래대금 순위", "거래량 TOP", "급등주 순위" → **키움 또는 KIS 사용 필수** (NXT 합산 데이터)
   - 단순 개별 종목 주가 조회는 PyKRX로 충분
2. **전일 종가만 제공** — 장중 실시간 가격 조회 불가. "지금 삼성전자 얼마야?"는 키움/KIS 필요.
3. **분봉/호가/체결 미지원** — 1분봉, 호가창, 체결강도 등은 키움/KIS 전용.
4. **업종/테마 분류 없음** — "2차전지 관련주", "반도체 테마" 등은 키움의 업종/테마 API 사용.

### 주말/공휴일/비장시간 데이터 처리

- **주말/공휴일에도 조회 가능** — 모든 도구가 마지막 거래일(직전 영업일) 데이터를 반환한다.
- "토요일인데 주가 조회돼?" → **조회 가능**. 금요일(직전 거래일) 종가가 나온다.
- "장 마감 후 현재가?" → PyKRX는 당일 종가, 키움/KIS는 당일 종가(실시간 아닌 확정 종가).
- **절대로** "주말이라 데이터를 조회할 수 없습니다"라고 답하지 말 것.

### 왜 PyKRX가 기본값인가?

1. **인증 불필요** — API 키 없이 KRX(한국거래소) 데이터를 직접 조회. 100% 성공률.
2. **대량 데이터에 적합** — 과거 일봉(OHLCV), 시총, 수급 등 대량 조회 가능. Rate Limit 없음.
3. **모든 사용자 즉시 사용** — 설치 직후 API 키 설정 없이 바로 동작.

### 왜 키움/KIS는 기본값이 아닌가?

1. **토큰 관리 필요** — 키움 토큰은 24시간 유효, 만료 시 실패. IP 기반 보안 정책 적용.
2. **Rate Limit** — 키움 REST: 실전 20회/s, 모의 2회/s, 토큰 발급 1회/s. 429 에러 시 지수 백오프.
3. **연속조회도 호출 제한에 포함** — 차트 데이터 1회 최대 600개, 이후 cont-yn/next-key로 페이징. 추가 요청도 Rate Limit에 합산.
4. **분봉/실시간 전용** — 대량 과거 일봉 수집에는 부적합 (시간/안정성).
5. **키 없으면 실패** — 사용자가 설정 페이지에서 키를 입력하지 않았으면 호출 불가.

### 의사결정 플로우차트

```
사용자 요청 수신
  │
  ├─ "주가/시세/종목정보" (개별 종목)
  │     └─ 장중 실시간? → YES → kiwoom/kis [키 필수]
  │                      → NO  → datakit_call (PyKRX) [무료]
  │
  ├─ "거래대금 순위/거래량 TOP/급등주 순위" ⚠️
  │     └─ 반드시 kiwoom/kis 사용 (PyKRX는 NXT 미합산으로 부정확)
  │
  ├─ "분봉/호가/체결강도/틱" → kiwoom 또는 kis [키 필수, PyKRX 불가]
  │
  ├─ "과거 일봉 대량 수집" → datakit_call (PyKRX) [무료, Rate Limit 없음]
  │
  ├─ "매수/매도/주문" → kiwoom 또는 kis [키 필수, 확인 후 호출]
  ├─ "잔고/예수금/계좌" → kiwoom 또는 kis [키 필수]
  │
  ├─ "업종/테마/관련주" → kiwoom (업종/테마 API) [키 필수]
  ├─ "조건검색" → kiwoom_condition [키 필수, 키움 전용]
  │
  ├─ "뉴스" → news_search_stock [네이버 키 필수]
  ├─ "공시/기업정보" → datakit_call (DART) [DART 키 필수]
  ├─ "금리/환율/GDP" → datakit_call (ECOS/EXIM) [키 필수]
  ├─ "해외 주식 (미국/일본/중국)" → kis_overseas_stock [KIS 키 필수]
  └─ "...해서 텔레그램으로 알려줘" → 데이터 수집 후 telegram_send_alert 또는 telegram_send_message
```

> **핵심 원칙**:
> 1. 개별 종목 과거 주가 → **PyKRX 우선** (무료, 즉시)
> 2. 순위/실시간/분봉/호가 → **키움/KIS 필수** (PyKRX로 대체 불가)
> 3. 해외주식 → **KIS overseas 전용** (PyKRX/키움은 국내만)

### 복합 분석 패턴 — 여러 도구 조합

사용자 질문이 단일 도구로 해결되지 않는 경우가 많다. 아래 패턴대로 여러 도구를 순차 호출한다.

| 사용자 질문 예시 | 도구 조합 | 순서 |
|----------------|----------|------|
| "삼성전자 종합 분석해줘" | search_stock → get_price + get_market_cap + 수급 + 뉴스 | PyKRX 3회 + 뉴스 1회 |
| "오늘 급등주 뭐야?" | kiwoom 거래대금순위 → 상위 종목 뉴스 검색 | 키움 1회 + 뉴스 N회 |
| "반도체 관련주 수급 어때?" | kiwoom 테마/업종 → 종목목록 → PyKRX 수급 | 키움 1회 + PyKRX N회 |
| "미국장 영향으로 코스피 어떨까?" | kis_overseas(S&P500) → datakit(KOSPI지수) + 뉴스 | KIS 1회 + PyKRX 1회 + 뉴스 1회 |
| "삼성전자 매수 타이밍?" | 키움 현재가+분봉+호가 + PyKRX 수급+시총 | 키움 3회 + PyKRX 2회 |
| "이 종목 공시 나온 거 있어?" | search_stock → DART 공시 + 뉴스 | PyKRX 1회 + DART 1회 + 뉴스 1회 |
| "급등주 찾아서 텔레그램으로 알려줘" | kiwoom 순위 → 뉴스 검색 → telegram_send_alert | 키움 1회 + 뉴스 N회 + 텔레그램 N회 |
| "삼성전자 분석해서 텔레그램에 보내줘" | PyKRX + 키움 + 뉴스 → 분석 작성 → telegram_send_message | 데이터 수집 + 텔레그램 1회 |
| "오전장 브리핑 만들어줘" | `openclaw-stock-kit briefing morning` (자동 수집+포맷) | CLI 1회 |
| "급등주 계속 감시해줘" | `openclaw-stock-kit watch start` (watchlist.json 설정) | CLI 데몬 |

### 응답 원칙 — 투자조언 경계

- **제공 가능**: 주가 데이터, 재무 정보, 뉴스, 수급, 거래대금, 차트 등 **팩트 데이터**
- **제공 불가**: "사도 돼?", "오를까?", "얼마까지 갈까?" 같은 **매매 판단/예측**
- 초보자가 "삼성전자 사도 돼?"라고 물으면 → 현재 주가, 시총, 수급, 뉴스 등 **판단 근거 데이터**를 제공하고, "투자 판단은 사용자 본인이 해야 합니다"라고 안내

---

## 1단계: 설치 확인 (첫 사용 시 반드시 실행)

```bash
openclaw-stock-kit call list 2>/dev/null
```

"command not found" 에러 시 자동 설치:

```bash
pip install openclaw-stock-kit 2>&1 || pip install --break-system-packages openclaw-stock-kit 2>&1
```

설치 후 스킬 등록:

```bash
openclaw-stock-kit setup openclaw 2>&1
```

---

## 2단계: 설정 서버 시작 (API 키 입력용)

사용자가 브라우저에서 API 키를 입력할 수 있는 웹 페이지를 띄운다.

```bash
# 포트 8200이 이미 사용 중일 수 있으므로, 빈 포트를 찾아서 시작
# 8200 시도 → 실패하면 8201, 8202... 순서로 시도
pm2 start openclaw-stock-kit --name stockclaw-settings -- -p 8200 2>/dev/null || nohup openclaw-stock-kit -p 8201 &>/dev/null &
```

설정 페이지 URL을 사용자에게 알려줄 때:
- **서버 환경**: `http://<서버의_외부_IP>:8200` (0.0.0.0이나 localhost가 아닌 실제 IP)
- **로컬 환경**: `http://localhost:8200`

서버 IP 확인 방법:
```bash
hostname -I 2>/dev/null | awk '{print $1}' || curl -s ifconfig.me
```

> **반드시** 사용자에게 "브라우저에서 이 URL을 열어서 API 키를 입력해주세요"라고 안내한다.
> 사용자가 API 키를 입력하기 **전에는** API 키가 필요한 도구를 호출하면 안 된다.

---

## 3단계: API 우선순위 (매우 중요!)

### 무료 (API 키 불필요) — 즉시 사용 가능
| 모듈 | 도구명 | 용도 |
|------|--------|------|
| PyKRX | `datakit_call` | 종목검색, 과거 주가, 시총, 거래량, 수급, 지수 |

### 유료 (API 키 필요) — 사용자가 키 입력 후에만 사용
| 모듈 | 도구명 | 필요 키 | 용도 |
|------|--------|---------|------|
| DART | `datakit_call` | DART_API_KEY | 공시, 기업개황, 최대주주 |
| ECOS/환율 | `datakit_call` | ECOS_API_KEY, EXIM_API_KEY | 기준금리, CPI, GDP, 환율 |
| 네이버 뉴스 | `news_search` / `news_search_stock` | NAVER_CLIENT_ID/SECRET | 뉴스 검색 |
| 텔레그램 | `telegram_*` | TELEGRAM_API_ID/HASH | 실시간 채널 |
| 키움증권 | `kiwoom_call_api` | KIWOOM_APP_KEY/SECRET | 실시간 시세, 매매 |
| 한투(KIS) | `kis_domestic_stock` 등 | KIS_APP_KEY/SECRET | 국내+해외 주식 |
| 프리미엄 | `premium_call` | 라이선스 키 | 브리핑, 백테스트 |

### 사용 규칙
1. **PyKRX는 항상 먼저 시도한다** — 과거 주가, 종목검색, 시총은 PyKRX로 무료 조회 가능
2. **API 키가 필요한 도구는** 사용자가 설정 페이지에서 키를 입력했는지 `gateway_status`로 먼저 확인한다
3. **키가 없으면 해당 도구를 호출하지 않는다** — "API 키가 필요합니다. 설정 페이지에서 입력해주세요"라고 안내
4. 키움/KIS 실시간 현재가가 필요한데 키가 없으면 → PyKRX `get_price`로 최근 종가 대체 가능

---

## 4단계: 도구 호출 (핵심)

**모든 호출은 이 형식을 따른다:**

```bash
openclaw-stock-kit call <도구명> '<JSON 파라미터>' 2>/dev/null
```

> `2>/dev/null`을 항상 붙여서 로딩 로그를 숨긴다.

### 빠른 시작 — 무료 (PyKRX)

```bash
# 종목 검색 (무료)
openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"삼성전자\"}"}' 2>/dev/null

# 과거 주가 (무료)
openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260220\"}"}' 2>/dev/null

# 시가총액 (무료)
openclaw-stock-kit call datakit_call '{"function":"get_market_cap","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260220\"}"}' 2>/dev/null

# 전체 상태 확인 (어떤 모듈이 활성인지)
openclaw-stock-kit call gateway_status 2>/dev/null

# 도구 목록
openclaw-stock-kit call list 2>/dev/null
```

### API 키 필요 (키 입력 후에만)

```bash
# 뉴스 검색 (NAVER_CLIENT_ID/SECRET 필요)
openclaw-stock-kit call news_search_stock '{"stock_name":"삼성전자","days":7}' 2>/dev/null

# 키움 실시간 현재가 (KIWOOM_APP_KEY/SECRET 필요)
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 의사결정 트리 — 서브 스킬 라우팅

사용자 의도를 파악하여 해당 서브 스킬 파일을 **Read 도구**로 읽고, 그 안의 상세 가이드를 따른다.

| 사용자 의도 | 서브 스킬 파일 | CLI 도구 | API 키 |
|------------|--------------|---------|--------|
| 종목검색, 과거 주가, 시총, 수급, 지수 | `{baseDir}/skills/datakit-pykrx.md` | `datakit_call` | 불필요 (무료) |
| DART 공시, 기업개황, 최대주주, 임원 | `{baseDir}/skills/datakit-dart.md` | `datakit_call` | DART_API_KEY |
| 기준금리, CPI, GDP, 실업률, 환율 | `{baseDir}/skills/datakit-macro.md` | `datakit_call` | ECOS/EXIM |
| 뉴스 검색, 종목별 뉴스 | `{baseDir}/skills/news-naver.md` | `news_search` / `news_search_stock` | NAVER |
| 텔레그램 채널, 메시지, 인증, 알림 발송 | `{baseDir}/skills/news-telegram.md` | `telegram_*` | TELEGRAM |
| 키움 실시간 시세, 호가, 차트 | `{baseDir}/skills/kiwoom-market.md` | `kiwoom_call_api` | KIWOOM |
| 키움 매수, 매도, 잔고, 예수금 | `{baseDir}/skills/kiwoom-trading.md` | `kiwoom_call_api` | KIWOOM |
| 키움 외국인, 기관, 순위, 업종, 테마 | `{baseDir}/skills/kiwoom-analysis.md` | `kiwoom_call_api` | KIWOOM |
| 키움 ELW, ETF, 대차 | `{baseDir}/skills/kiwoom-specialty.md` | `kiwoom_call_api` | KIWOOM |
| 키움 조건검색 | `{baseDir}/skills/kiwoom-condition.md` | `kiwoom_condition_*` | KIWOOM |
| 한투 국내주식 (시세, 주문, 잔고) | `{baseDir}/skills/kis-domestic.md` | `kis_domestic_stock` | KIS |
| 한투 해외주식 (미국, 중국, 일본 등) | `{baseDir}/skills/kis-overseas.md` | `kis_overseas_stock` | KIS |
| 한투 선물옵션, 채권, ETF/ETN, ELW | `{baseDir}/skills/kis-derivatives.md` | `kis_*` | KIS |
| 브리핑, 백테스트, 강좌, 프리미엄 | `{baseDir}/skills/premium.md` | `premium_call` | 라이선스 |

---

## 전형적인 사용 흐름

### 처음 설치한 사용자

1. 설치 → `pip install openclaw-stock-kit`
2. 스킬 등록 → `openclaw-stock-kit setup openclaw`
3. 설정 서버 시작 → `openclaw-stock-kit -p 8200`
4. **사용자에게 설정 URL 안내** → `http://<IP>:8200` 에서 API 키 입력
5. 사용자가 키 입력 완료했다고 알려주면 → `gateway_status`로 확인
6. 이후 도구 호출 가능

### "삼성전자 주가 알려줘" 요청 시

1. 종목코드 확인: `datakit_call` + `search_stock` → 005930 (무료, 즉시 가능)
2. 과거 주가: `datakit_call` + `get_price` (무료, 즉시 가능)
3. 실시간 현재가: `kiwoom_call_api` (키움 키 필요 → 키 없으면 PyKRX 최근 종가로 대체)

### "뉴스 보여줘" 요청 시

1. `gateway_status`로 네이버 뉴스 모듈 활성 확인
2. 키가 있으면 → `news_search_stock` 호출
3. 키가 없으면 → "네이버 API 키가 필요합니다. 설정 페이지에서 입력해주세요"

---

## Watch 모드 — 실시간 감시 + 알림

백그라운드에서 API를 주기적으로 호출하고, 조건 충족 시 텔레그램 알림을 발송하는 데몬.

```bash
# 샘플 설정 파일 생성
openclaw-stock-kit watch init

# 감시 데몬 시작 (포그라운드 — PM2로 백그라운드 가능)
openclaw-stock-kit watch start --config ~/.openclaw-stock-kit/watchlist.json

# 1회 실행 (테스트)
openclaw-stock-kit watch run-once --config ~/.openclaw-stock-kit/watchlist.json

# PM2 백그라운드 실행
pm2 start openclaw-stock-kit --name stockclaw-watch -- watch start
```

watchlist.json 구조:
```json
{
  "scan_interval_sec": 30,
  "alerts": {"telegram": "me"},
  "watchers": [
    {"name": "급등주", "tool": "kiwoom_call_api", "params": {"tr_id": "ka10032"},
     "condition": {"field": "등락률", "op": ">", "value": 5},
     "cooldown_sec": 300, "alert_type": "급등"}
  ]
}
```

> 장 시간(KST 08:50~15:40) 자동 감지. 장 외 시간에는 자동 대기.

---

## Briefing 모드 — 시장 브리핑 자동 생성

여러 API를 한 번에 호출하여 포맷된 시장 브리핑 텍스트를 생성한다.

```bash
# 오전장 브리핑 (미국장+환율+지수+수급+뉴스)
openclaw-stock-kit briefing morning

# 장 마감 브리핑
openclaw-stock-kit briefing closing

# JSON 출력
openclaw-stock-kit briefing morning --format json

# 텔레그램으로 발송
openclaw-stock-kit briefing morning --send-telegram @my_channel

# 텔레그램 내게 보내기
openclaw-stock-kit briefing morning --send-telegram me
```

수집 항목: KOSPI/KOSDAQ 지수, 거래대금 TOP, 외인/기관 순매수, 미국 나스닥/S&P500, 원달러 환율, 주요 뉴스
- 키가 없는 항목은 자동 스킵 (PyKRX 데이터는 항상 수집)
- closing 모드는 당일 급등주 데이터 추가 수집

---

## 에러 대처

- "Tool not found" → `call list`로 정확한 도구명 확인
- "Unexpected keyword argument" → 해당 서브 스킬에서 파라미터 확인
- "KIWOOM_APP_KEY not set" → 키움 API 키 미설정 (설정 페이지에서 입력)
- "KIS 인증 필요" → 한투 API 키/계좌 미설정
- 종목코드 모를 때 → `datakit_call` + `search_stock` 먼저 호출 (무료)
- "Connection refused" → call 모드는 SSE 서버 불필요 (독립 실행)
- 포트 충돌 → `-p 8201` 등 다른 포트로 설정 서버 시작
