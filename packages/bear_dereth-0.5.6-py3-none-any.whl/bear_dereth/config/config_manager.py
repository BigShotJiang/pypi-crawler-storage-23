"""Config Manager Module for Bear Dereth."""

from bear_config.manager import ConfigManager, Sources

__all__ = ["ConfigManager", "Sources"]
