"""Simple settings manager supporting multiple file formats."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, Self

from bear_dereth.config.settings_path import SettingsHelper
from codec_cub.jsons.file_handler import JSONFileHandler
from codec_cub.nix.file_handler import NixFileHandler
from codec_cub.toml.file_handler import TomlFileHandler
from codec_cub.yamls.file_handler import YamlFileHandler

if TYPE_CHECKING:
    from collections.abc import Callable

    from codec_cub.general.base_file_handler import BaseFileHandler

FileFormat = Literal["json", "yaml", "toml", "jsonl", "nix", "default", "msgpack"]
FileFormats: set[str] = {"json", "yaml", "toml", "jsonl", "msgpack", "nix"}


def get_file_handler(fmt: FileFormat, file_path: Path, **kwargs) -> BaseFileHandler[dict[str, Any]]:
    """Get the appropriate file handler for the specified format.

    Args:
        fmt: File format (json, yaml, or toml)
        file_path: Path to the file

    Returns:
        File handler instance for the format

    Raises:
        ValueError: If format is not supported
    """
    handlers: dict[FileFormat, type[BaseFileHandler]] = {
        "json": JSONFileHandler,
        "yaml": YamlFileHandler,
        "toml": TomlFileHandler,
        "msgpack": JSONFileHandler,
        "nix": NixFileHandler,
        "default": JSONFileHandler,
    }
    return handlers.get(fmt, JSONFileHandler)(file=file_path, **kwargs)


class SettingsRecord(NamedTuple):
    """Named tuple for a single settings record."""

    key: Any
    value: Any

    @property
    def is_null(self) -> bool:
        """Check if the record is a null record.

        Returns:
            True if both key and value are None, False otherwise.
        """
        return self.key is None and self.value is None

    def unpack(self) -> tuple[Any, Any]:
        """Unpack the record into key and value.

        Returns:
            A tuple of (key, value).
        """
        return self.key, self.value


NOT_FOUND = SettingsRecord(key=None, value=None)


class SettingsRecords(NamedTuple):
    """Named tuple for settings records."""

    items: tuple[SettingsRecord, ...]

    @classmethod
    def not_found(cls) -> SettingsRecords:
        """Create a SettingsRecords instance representing not found.

        Returns:
            A SettingsRecords instance with NOT_FOUND.
        """
        return cls(items=(NOT_FOUND,))

    def first(self) -> SettingsRecord:
        """Get the first item in the settings records.

        Returns:
            The first key-value pair.
        """
        return self.items[0] if self.items else NOT_FOUND

    def last(self) -> SettingsRecord:
        """Get the last item in the settings records.

        Returns:
            The last key-value pair.
        """
        return self.items[-1] if self.items else NOT_FOUND

    def limit(self, n: int) -> SettingsRecords:
        """Get a limited number of items in the settings records.

        Args:
            n: Number of items to return.

        Returns:
            A new SettingsRecords instance with the limited items.
        """
        if not self.items:
            return SettingsRecords.not_found()
        mutable: list[SettingsRecord] = list(self.items)
        limited: list[SettingsRecord] = mutable[:n] if n >= 0 else mutable[n:]
        return SettingsRecords(items=tuple(limited))

    def as_dict(self, exclude_none: bool = True) -> dict[Any, Any]:
        """Convert the settings records to a dictionary.

        Args:
            exclude_none: Whether to exclude records with None keys or values.

        Returns:
            A dictionary of key-value pairs.
        """
        return {
            record.key: record.value
            for record in self.items
            if not (exclude_none and (record.key is None or record.value is None))
        }

    def all(self) -> list[SettingsRecord]:
        """Get all items in the settings records.

        Returns:
            A list of all key-value pairs.
        """
        return list(self.items)


class SimpleKeyStore:
    """A simple settings manager supporting multiple file formats.

    Supports JSON, YAML, and TOML formats with automatic format detection
    based on file extension or explicit format parameter.

    Examples:
        # JSON (default)
        settings = SimpleKeyStore("myapp")

        # YAML
        settings = SimpleKeyStore("myapp", format="yaml")

        # TOML
        settings = SimpleKeyStore("myapp", format="toml")

        # Auto-detect from extension
        settings = SimpleKeyStore("myapp", file_name="config.yaml")
    """

    def __init__(
        self,
        name: str,
        file_name: str | None = None,
        path: Path | str | None = None,
        fmt: FileFormat = "toml",
        strict: bool = False,
        **kwargs,
    ) -> None:
        """Initialize the SimpleKeyStore.

        Args:
            name: Settings name (used for default file path)
            file_name: Optional custom file name
            path: Optional custom directory path
            format: File format (json, yaml, toml). Auto-detected from extension if not provided.
            kwargs: Additional arguments passed to the file handler
        """
        self.name: str = name
        suffix: str | None = Path(file_name).suffix.replace(".", "") if file_name else None
        self.file_path: Path = SettingsHelper(
            name=name,
            file=file_name,
            path=path,
            ext=suffix or fmt,
            allowed_extensions=FileFormats,
            strict=strict,
        ).get_path()
        self.handler: BaseFileHandler[dict[str, Any]] = get_file_handler(fmt=fmt, file_path=self.file_path, **kwargs)
        self.settings: dict[str, Any] = self.read()

    def read(self) -> dict[str, Any]:
        """Read settings from the file.

        Returns:
            Dictionary of settings
        """
        try:
            data: dict[str, Any] | None = self.handler.read()
            return data if isinstance(data, dict) else {}
        except (ValueError, FileNotFoundError):
            return {}

    def write(self) -> None:
        """Write settings to the file."""
        self.handler.write(self.settings)

    def keys(self) -> list[str]:
        """Get a list of all setting keys."""
        return list(self.settings.keys())

    def values(self) -> list[Any]:
        """Get a list of all setting values."""
        return list(self.settings.values())

    def items(self) -> list[tuple[str, Any]]:
        """Get a list of all setting key-value pairs."""
        return list(self.settings.items())

    def all(self) -> dict[str, Any]:
        """Get all settings as a dictionary."""
        return self.settings.copy()

    def delete(self, key: str) -> None:
        """Delete a setting key."""
        if key in self.settings:
            del self.settings[key]
            self.write()

    def clear(self) -> None:
        """Clear all settings."""
        self.settings.clear()
        self.write()

    def search(self, cond: Callable[..., bool]) -> SettingsRecords:
        """Search for settings matching a condition.

        Args:
            cond: A callable that takes a key and value and returns True if it matches.

        Returns:
            A SettingsRecords instance with matching items.
        """
        found: dict[str, Any] = {k: v for k, v in self.settings.items() if cond(k, v)}
        if not found:
            return SettingsRecords.not_found()
        return SettingsRecords(items=tuple(SettingsRecord(key=k, value=v) for k, v in found.items()))

    def set(self, key: str, value: Any) -> None:
        """Set a setting value."""
        self.settings[key] = value
        self.write()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        return self.settings.get(key, default)

    def has(self, key: str) -> bool:
        """Check if a setting key exists."""
        return key in self.settings

    def closed(self) -> bool:
        """Check if the file handle is closed."""
        return self.handler.closed

    def close(self) -> None:
        """Close the file handle."""
        if not self.handler.closed:
            self.handler.close()

    def __del__(self) -> None:
        self.close()

    def __len__(self) -> int:
        return len(self.settings)

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.close()


class SimpleSettingsManager(SimpleKeyStore):
    """An alias for SimpleKeyStore for backward compatibility."""
