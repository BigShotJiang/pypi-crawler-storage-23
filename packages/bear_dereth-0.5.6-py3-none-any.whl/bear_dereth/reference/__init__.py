"""Informative reference submodule for Bear Dereth."""
