"""A set of helper math functions."""

from funcy_bear.ops.math import clamp, inv_lerp, lerp, map_range, neg, normalize, relative_norm, remap, sign, smoothstep
from funcy_bear.ops.math.infinity import INFINITE, MAX_SIZE, Infinity

__all__ = [
    "INFINITE",
    "MAX_SIZE",
    "Infinity",
    "clamp",
    "inv_lerp",
    "lerp",
    "map_range",
    "neg",
    "normalize",
    "relative_norm",
    "remap",
    "sign",
    "smoothstep",
]
