"""A module providing a Rich-based printer for colorful console output."""

from typing import TYPE_CHECKING

from lazy_bear import lazy

if TYPE_CHECKING:
    from bear_dereth.logger.config import Container, LoggerConfig, get_container

    from .basic_logger.basic_logger import BasicLogger
    from .basic_logger.simple_logger import BaseLogger, PrintOnlyLogger, SimpleLogger
    from .common.log_level import LogLevel
    from .handlers import BufferHandler, ConsoleHandler, FileHandler, QueueHandler
    from .rich_printer import BearLogger
else:
    _simple = lazy("bear_dereth.logger.basic_logger.simple_logger")
    BaseLogger = _simple.to("BaseLogger")
    PrintOnlyLogger = _simple.to("PrintOnlyLogger")
    SimpleLogger = _simple.to("SimpleLogger")
    Container, LoggerConfig, get_container = lazy(
        "bear_dereth.logger.config.di", "Container", "LoggerConfig", "get_container"
    )

    BasicLogger = lazy("bear_dereth.logger.basic_logger.basic_logger", "BasicLogger")
    BearLogger = lazy("bear_dereth.logger.rich_printer", "BearLogger")
    LogLevel = lazy("bear_dereth.logger.common.log_level", "LogLevel")
    BufferHandler = lazy("bear_dereth.logger.handlers.buffer_handler", "BufferHandler")
    ConsoleHandler = lazy("bear_dereth.logger.handlers.console_handler", "ConsoleHandler")
    FileHandler = lazy("bear_dereth.logger.handlers.file_handler", "FileHandler")
    QueueHandler = lazy("bear_dereth.logger.handlers.queue_handler", "QueueHandler")


__all__ = [
    "BaseLogger",
    "BasicLogger",
    "BearLogger",
    "BufferHandler",
    "ConsoleHandler",
    "Container",
    "FileHandler",
    "LogLevel",
    "LoggerConfig",
    "PrintOnlyLogger",
    "QueueHandler",
    "SimpleLogger",
    "get_container",
]
