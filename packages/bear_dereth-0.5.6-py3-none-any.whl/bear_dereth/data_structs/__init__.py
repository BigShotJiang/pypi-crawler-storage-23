"""Set of data structures and collections used throughout Bear Dereth."""
