from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Annotated, NamedTuple

if TYPE_CHECKING:
    from argparse import Namespace
    from collections.abc import Callable
    from inspect import BoundArguments, Signature

    from .info import BumpType, ExitCode


ArgsType = Annotated[list[str] | None, "ArgsType: A list of command line arguments or None to use sys.argv[1:]"]
"""A type alias for when command line arguments may be passed in or None to use sys.argv[1:]."""
CLIArgsType = Annotated[list[str], "CLIArgsType: A list of command line arguments specifically for CLI usage"]
"""A type alias for when command line arguments are expected to be passed in."""


def to_argv(args: ArgsType = None) -> list[str]:
    """A simple function to return command line arguments or a provided list of arguments.

    Args:
        args (list[str] | None): A list of arguments to return. If None, it will return sys.argv[1:].

    Returns:
        list[str]: The list of command line arguments.
    """
    return sys.argv[1:] if args is None else args


def args_parse[R](
    param_name: str = "args",
    handler: Callable[[], list[str]] = to_argv,
) -> Callable[[Callable[..., R]], Callable[..., R]]:
    """A decorator to inject raw command line arguments as list[str].

    This decorator injects sys.argv[1:] (or custom handler result) into the specified
    parameter if it's not already provided when calling the function.

    Args:
        param_name: The name of the parameter to inject arguments into
        handler: Function to retrieve arguments (defaults to sys.argv[1:])

    Example:
        ```python
        @args_parse()
        def my_command(args: list[str]) -> None:
            print(f"Args: {args}")
        ```
    """
    from functools import wraps

    from funcy_bear.typing_stuffs import get_function_signature

    def decorator(func: Callable[..., R]) -> Callable[..., R]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> R:
            sig: Signature = get_function_signature(func)
            if param_name in sig.parameters and param_name not in kwargs:
                bound: BoundArguments = sig.bind_partial(*args, **kwargs)
                if param_name not in bound.arguments:
                    bound.arguments[param_name] = handler()
                return func(*bound.args, **bound.kwargs)
            return func(*args, **kwargs)

        return wrapper

    return decorator


def args_inject[R, ProcessedT](
    param_name: str = "args",
    handler: Callable[[], list[str]] = to_argv,
    *,
    process: Callable[[list[str]], ProcessedT],
) -> Callable[[Callable[..., R]], Callable[..., R]]:
    """A decorator to inject processed command line arguments.

    This decorator retrieves command line arguments, processes them through the provided
    function, and injects the result into the specified parameter.

    Args:
        param_name: The name of the parameter to inject processed arguments into
        handler: Function to retrieve raw arguments (defaults to sys.argv[1:])
        process: Function to process the raw arguments - its return type determines
                the type of the injected parameter

    Example:
        ```python
        def parse_args(args: list[str]) -> Namespace:
            parser = ArgumentParser()
            parser.add_argument("--name")
            return parser.parse_args(args)


        @args_inject(process=parse_args)
        def my_command(args: Namespace) -> None:
            print(f"Name: {args.name}")
        ```
    """
    from functools import wraps

    from funcy_bear.typing_stuffs import get_function_signature

    def decorator(func: Callable[..., R]) -> Callable[..., R]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> R:
            sig: Signature = get_function_signature(func)
            if param_name in sig.parameters and param_name not in kwargs:
                bound: BoundArguments = sig.bind_partial(*args, **kwargs)
                raw_args: list[str] = bound.arguments[param_name] if param_name in bound.arguments else handler()
                processed_args: ProcessedT = process(raw_args)
                bound.arguments[param_name] = processed_args
                return func(*bound.args, **bound.kwargs)
            return func(*args, **kwargs)

        return wrapper

    return decorator


def debug_info(no_color: bool = False) -> ExitCode:
    """CLI command to print debug information."""
    from .debug import _print_debug_info
    from .info import ExitCode

    _print_debug_info(no_color=no_color)
    return ExitCode.SUCCESS


def version(name: bool = False) -> ExitCode:
    """CLI command to get the current version of the package."""
    from .info import METADATA, ExitCode

    print(f"{METADATA.name} {METADATA.version}" if name else METADATA.version)
    return ExitCode.SUCCESS


def bump_version(b: BumpType) -> ExitCode:
    """Bump the version of the current package.

    Args:
        b: The type of bump ("major", "minor", or "patch").

    Returns:
        An ExitCode indicating success or failure.
    """
    from .info import _VALIDS, METADATA, ExitCode, _Version

    v: _Version = METADATA.version_tuple
    if b not in _VALIDS:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(_VALIDS)}.")
        return ExitCode.FAILURE

    if v == _Version.default():
        print("Current version is 0.0.0, cannot bump version.")
        return ExitCode.FAILURE
    try:
        new_version: _Version = v.new_version(b)
        print(str(new_version))
        return ExitCode.SUCCESS
    except ValueError:
        print(f"Invalid version tuple: {v}")
        return ExitCode.FAILURE


class _ReturnedArgs(NamedTuple):
    cmd: str
    version_name: bool
    bump_type: BumpType
    no_color: bool


def get_args(args: list[str]) -> _ReturnedArgs:
    """Parse command-line arguments."""
    from argparse import ArgumentParser

    from .info import _VALIDS, METADATA

    parser = ArgumentParser(description=METADATA.description)
    subparsers = parser.add_subparsers(dest="command", required=True)
    version: ArgumentParser = subparsers.add_parser("version", help="Get the version of the package.")
    version.add_argument("--name", "-n", action="store_true", help="Print only the version name.")
    bump: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package.")
    bump.add_argument("bump_type", type=str, choices=_VALIDS, help="Type of version bump (major, minor, patch).")
    debug: ArgumentParser = subparsers.add_parser("debug", help="Print debug information.")
    debug.add_argument("--no-color", "-nc", action="store_true", help="Disable colored output.")
    parsed: Namespace = parser.parse_args(args)
    return _ReturnedArgs(
        cmd=parsed.command,
        version_name=getattr(parsed, "name", False),
        bump_type=getattr(parsed, "bump_type", "patch"),
        no_color=getattr(parsed, "no_color", False),
    )


# ruff: noqa: PLC0415
