from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from ._cmds import args_inject, bump_version, debug_info, get_args, version

if TYPE_CHECKING:
    from ._cmds import _ReturnedArgs
    from .info import ExitCode


@args_inject(process=get_args)
def main(args: _ReturnedArgs) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `bear_dereth` or `python -m bear_dereth`.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    from .info import ExitCode  # noqa: PLC0415

    try:
        match args.cmd:
            case "bump":
                return bump_version(b=args.bump_type)
            case "debug":
                return debug_info(no_color=args.no_color)
            case "version":
                return version(name=args.version_name)
            case _:
                print(f"Unknown command: {args.cmd}", file=sys.stderr)
                return ExitCode.COMMAND_NOT_FOUND
    except SystemExit as e:
        if e.code is not None and isinstance(e.code, int):
            return ExitCode(e.code)
        return ExitCode.SUCCESS
    except Exception:
        return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
