"""
Type stubs for Nexus Engine Python API

A Python wrapper around the Nexus Engine - a financial data calculation engine.
"""
import datetime
from enum import StrEnum
from typing import Any, Generic, Literal, Self, TypeAlias, TypedDict, TypeVar

_P = TypeVar("_P")

__version__: str


# Type aliases for level operations
class LevelOperationSort(TypedDict):
    """Sort operation for breakdown levels.

    Sorts rows at specific breakdown levels by one or more columns.

    Examples:
        >>> # Sort by single column descending
        >>> {"type": "sort", "by": [{"expression": col("revenue"), "order": "desc"}]}
        >>>
        >>> # Sort by multiple columns
        >>> {"type": "sort", "by": [
        ...     {"expression": col("revenue"), "order": "desc"},
        ...     {"expression": col("name"), "order": "asc", "nulls_last": True}
        ... ]}
        >>>
        >>> # Sort using simple string (column name, ascending)
        >>> {"type": "sort", "by": "revenue"}
    """

    type: Literal["sort"]
    by: Any  # Can be string, list of strings, or SortBy objects


class LevelOperationFilter(TypedDict):
    """Filter operation for breakdown levels.

    Filters rows at specific breakdown levels based on a condition.
    Useful for removing small values or focusing on top performers.

    Examples:
        >>> # Keep only rows where revenue > 1000
        >>> {"type": "filter", "condition": col("revenue") > lit(1000)}
        >>>
        >>> # Keep only non-null categories
        >>> {"type": "filter", "condition": col("category").is_not_null()}
        >>>
        >>> # Complex condition
        >>> {"type": "filter", "condition": (col("revenue") > lit(0)) & (col("count") >= lit(10))}
    """

    type: Literal["filter"]
    condition: Expression


class LevelOperationLimit(TypedDict):
    """Limit/offset operation for breakdown levels.

    Limits the number of rows returned at specific breakdown levels.
    Useful for top-N analysis or pagination.

    Examples:
        >>> # Get top 10 items
        >>> {"type": "limit", "limit": 10}
        >>>
        >>> # Skip first 5, return next 10 (pagination)
        >>> {"type": "limit", "limit": 10, "offset": 5}
        >>>
        >>> # Only limit (no offset)
        >>> {"type": "limit", "limit": 20, "offset": None}
    """

    type: Literal["limit"]
    limit: int | None
    offset: int | None


LevelOperation = LevelOperationSort | LevelOperationFilter | LevelOperationLimit
"""Union of all level operation types.

Level operations can be applied to breakdown levels to sort, filter, or limit results.

Examples:
    >>> # Apply to all levels
    >>> level_operations=[{"type": "sort", "by": "revenue"}]
    >>>
    >>> # Apply to specific level range (levels 1-2)
    >>> level_operations=[((1, 3), {"type": "limit", "limit": 5})]
    >>>
    >>> # Multiple operations
    >>> level_operations=[
    ...     {"type": "sort", "by": [{"expression": col("value"), "order": "desc"}]},
    ...     ((1, 2), {"type": "filter", "condition": col("value") > lit(100)}),
    ...     {"type": "limit", "limit": 10}
    ... ]
"""


class LevelOperationDict(TypedDict, total=False):
    """Dict-based level operation with optional level range."""

    levels: tuple[int, int] | None
    operation: LevelOperation


# A level operation with optional level range
# Can be: LevelOperation, (level_range, LevelOperation),
# or {"levels": (start, end), "operation": LevelOperation}
LevelOperationWithRange = (
        LevelOperation | tuple[tuple[int, int] | None, LevelOperation] | LevelOperationDict
)
"""Level operation with optional level range specification.

Allows targeting operations to specific breakdown levels.

Level ranges use Python range notation: (start, end) where start is inclusive, end is exclusive.
- (0, 1): Apply to level 0 only
- (1, 3): Apply to levels 1 and 2
- None: Apply to all levels

Formats:
    1. Simple operation dict (applies to all levels):
       {"type": "sort", "by": "column"}

    2. Tuple with level range:
       ((1, 3), {"type": "sort", "by": "column"})
       (None, {"type": "limit", "limit": 10})  # None means all levels

    3. Dict with levels key:
       {"levels": (1, 3), "operation": {"type": "sort", "by": "column"}}

Examples:
    >>> # Sort all levels by revenue
    >>> table.breakdown(
    ...     "SALES", ["region", "category", "product"],
    ...     [("revenue", "sum")],
    ...     level_operations=[
    ...         {"type": "sort", "by": [{"expression": col("revenue"), "order": "desc"}]}
    ...     ]
    ... )
    >>>
    >>> # Apply different operations to different levels
    >>> table.breakdown(
    ...     "TOP_PERFORMERS", ["region", "category", "product"],
    ...     [("revenue", "sum"), ("units", "sum")],
    ...     level_operations=[
    ...         # Sort all levels by revenue (descending)
    ...         {"type": "sort", "by": [{"expression": col("revenue"), "order": "desc"}]},
    ...         # At levels 1-2 (category and product), keep only revenue > 10000
    ...         ((1, 3), {"type": "filter", "condition": col("revenue") > lit(10000)}),
    ...         # At level 2 (product), show top 5 only
    ...         ((2, 3), {"type": "limit", "limit": 5})
    ...     ]
    ... )
    >>>
    >>> # Pagination: skip first 10, return next 20
    >>> table.breakdown(
    ...     "PAGINATED", ["category"],
    ...     [("amount", "sum")],
    ...     level_operations=[
    ...         {"type": "sort", "by": "amount"},
    ...         {"type": "limit", "limit": 20, "offset": 10}
    ...     ]
    ... )
"""

# //////////////////////////////////////////////////////////////////////////////////////////////////
# Sorting Types
# //////////////////////////////////////////////////////////////////////////////////////////////////

SortOrder = Literal["asc", "ascending", "a", "desc", "descending", "d"]
"""Valid sort order strings (case-insensitive)."""

SortByDict = dict[str, Any]
"""Dictionary specification for a single sort column.

Accepted keys for specifying the column/expression to sort by (use ONE of these):
    - `column`, `column_name`, or `col`: str - Column name to sort by
    - `expression`, `by`, or `expr`: Expression - Expression to sort by

Optional keys:
    - `order`, `sort_direction`, or `direction`: SortOrder - "asc" or "desc" (default: "asc")
    - `nulls_last`: bool - Place nulls last (default: False for expressions, True for column names)

Examples:
    >>> # Sort by column name
    >>> {"column": "revenue", "order": "desc"}
    >>> {"column_name": "price", "order": "asc", "nulls_last": True}
    >>>
    >>> # Sort by expression
    >>> {"expression": col("amount").abs(), "order": "desc"}
    >>> {"by": col("value") * lit(100), "order": "asc"}
"""

SortByItem: TypeAlias = str | "Expression" | SortByDict | "SortBy"
"""A single sort specification.

Can be one of:
- `str`: Column name (ascending order, nulls last)
- `Expression`: Sort by expression result (ascending, nulls first)
- `dict`: Full specification with column/expression and options (see SortByDict)
- `SortBy`: Class instance with column, order, nulls_last

Examples:
    >>> # String - column name, ascending, nulls last
    >>> "revenue"
    >>>
    >>> # Expression - ascending, nulls first
    >>> col("price").abs()
    >>>
    >>> # Dict with column name
    >>> {"column": "revenue", "order": "desc"}
    >>> {"column_name": "price", "order": "asc", "nulls_last": True}
    >>>
    >>> # Dict with expression
    >>> {"expression": col("amount"), "order": "desc", "nulls_last": True}
    >>> {"by": col("value") * lit(100), "order": "asc"}
"""

SortBySpec = SortByItem | list[SortByItem] | tuple[SortByItem, ...]
"""Sort specification for table operations.

Can be a single sort item or a list/tuple of sort items for multi-column sorting.

Examples:
    >>> # Single column by name
    >>> table.sort("revenue")
    >>>
    >>> # Single column descending
    >>> table.sort({"column": "revenue", "order": "desc"})
    >>>
    >>> # Sort by expression
    >>> table.sort({"expression": col("price").abs(), "order": "desc"})
    >>>
    >>> # Multiple columns
    >>> table.sort([
    ...     {"column": "category", "order": "asc"},
    ...     {"expression": col("revenue"), "order": "desc", "nulls_last": True}
    ... ])
    >>>
    >>> # Mix of formats
    >>> table.sort([
    ...     "category",  # ascending by column name
    ...     {"expression": col("revenue"), "order": "desc"}
    ... ])
"""


class SortBy:
    """Sort specification class with column, order, and nulls_last options.

    Attributes:
        column: The column expression to sort by
        order: Sort order (ASC or DESC)
        nulls_last: Whether to place null values last
    """

    column: Expression
    order: SortOrder
    nulls_last: bool


class PyDataType:
    """Python wrapper for nexus data types"""

    ...


class NexusConfig:
    """
    Configuration for the Nexus API client.

    This class manages configuration for connecting to and communicating with
    a Nexus API server. Configuration can be loaded from TOML files, environment
    variables, or provided directly via constructor parameters.
    """

    def __init__(
            self,
            url: str | None = None,
            timeout_seconds: int | None = None,
            auth_token: str | None = None,
            tenant: str | None = None,
            config_path: str | None = None,
            oauth_client_id: str | None = None,
            oauth_client_secret: str | None = None,
            oauth_issuer: str | None = None,
            oauth_authorize_endpoint: str | None = None,
            oauth_token_endpoint: str | None = None,
            oauth_scopes: list[str] | None = None,
    ) -> None:
        """
        Create a new NexusConfig.

        Args:
            url: Optional API base URL override (e.g., "http://localhost:3000").
                The ``/api/v1`` path is appended automatically.
            timeout_seconds: Optional request timeout in seconds (default: 120)
            auth_token: Optional bearer token for authentication
            tenant: Optional tenant ID sent as ``X-Tenant-Id`` header with every request
            config_path: Optional path to TOML config file
            oauth_client_id: Optional OAuth client ID for client credentials flow
            oauth_client_secret: Optional OAuth client secret
            oauth_issuer: Optional OIDC issuer URL for automatic token endpoint discovery
                via ``.well-known/openid-configuration``
            oauth_authorize_endpoint: Deprecated. Use ``oauth_token_endpoint`` or
                ``oauth_issuer`` instead. Legacy fallback token endpoint URL.
            oauth_token_endpoint: Optional OAuth token endpoint URL
                (takes priority over issuer discovery)
            oauth_scopes: Optional list of OAuth scopes to request

        Configuration loading order (highest to lowest priority):
            1. Constructor parameters
            2. Environment variables (NEXUS_API_*)
            3. Config file (specified by config_path, or ./nexus.toml, or ~/.nexus/config.toml)
            4. Default values

        Raises:
            RuntimeError: If configuration cannot be loaded
            ValueError: If the API URL is invalid

        Example:
            >>> # Use default configuration (from file/env)
            >>> config = NexusConfig()
            >>>
            >>> # Override specific values
            >>> config = NexusConfig(url="http://prod:3000", timeout_seconds=180)
            >>>
            >>> # Load from custom config file
            >>> config = NexusConfig(config_path="/path/to/config.toml")
        """
        ...

    @property
    def url(self) -> str:
        """Get the configured API URL"""
        ...

    @property
    def timeout_seconds(self) -> int:
        """Get the configured timeout in seconds"""
        ...

    @property
    def auth_token(self) -> str | None:
        """Get the configured authentication token (if any)"""
        ...

    @property
    def tenant(self) -> str | None:
        """Get the configured tenant ID (if any)"""
        ...

    def __repr__(self) -> str:
        """String representation of the config"""
        ...


class WhenBuilder:
    """
    Builder for when/then/otherwise conditional expressions.

    Created by calling when() function.
    """

    def then(self, value: Expression | str | int | float | bool) -> ThenBuilder:
        """
        Specify the value to return when the condition is true.

        Args:
            value: The value to return (can be Expression or literal)

        Returns:
            A ThenBuilder that can chain more when() or end with otherwise()
        """
        ...


class ThenBuilder:
    """
    Builder that allows chaining more when clauses or finishing with otherwise.

    Created after calling then() on a WhenBuilder.
    """

    def when(self, condition: Expression | Condition) -> ChainedWhenBuilder:
        """
        Add another conditional case.

        Args:
            condition: The condition to check (Expression or Condition)

        Returns:
            A ChainedWhenBuilder to specify the then value
        """
        ...

    def otherwise(self, value: Expression | str | int | float | bool) -> Expression:
        """
        Specify the default value when no conditions match.

        Args:
            value: The default value to return

        Returns:
            The completed conditional Expression
        """
        ...


class ChainedWhenBuilder:
    """
    Builder for chained when clauses.

    Created after calling when() on a ThenBuilder.
    """

    def then(self, value: Expression | str | int | float | bool) -> ThenBuilder:
        """
        Specify the value to return when the current condition is true.

        Args:
            value: The value to return (can be Expression or literal)

        Returns:
            A ThenBuilder for chaining or finishing
        """
        ...


class Expression:
    """
    Python wrapper for expressions with full operation support.

    Represents a DSL expression that can be used for data transformations,
    calculations, and filtering operations.
    """

    # Comparison operators (intentional LSP override — DSL builds expression trees, not booleans)
    def __eq__(self, other: Expression) -> Expression: ...  # type: ignore[override]

    def __ne__(self, other: Expression) -> Expression: ...  # type: ignore[override]

    def __lt__(self, other: Expression) -> Expression: ...

    def __le__(self, other: Expression) -> Expression: ...

    def __gt__(self, other: Expression) -> Expression: ...

    def __ge__(self, other: Expression) -> Expression: ...

    # Mathematical operators
    def __add__(self, other: Expression) -> Expression: ...

    def __sub__(self, other: Expression) -> Expression: ...

    def __mul__(self, other: Expression) -> Expression: ...

    def __truediv__(self, other: Expression) -> Expression: ...

    # Aggregation functions
    def sum(self) -> Self: ...

    def count(self) -> Self: ...

    def mean(self) -> Self: ...

    def median(self) -> Self: ...

    def min(self) -> Self: ...

    def max(self) -> Self: ...

    def std(self) -> Self: ...

    def var(self) -> Self: ...

    def n_unique(self) -> Self: ...

    def null(self) -> Self:
        """
        Converts all values to null while preserving the datatype.

        This method returns null for all rows while maintaining the original
        column's datatype. This is useful for creating placeholder columns
        or replacing values with nulls in expressions.

        Returns:
            Expression with all null values but preserved datatype

        Examples:
            >>> col("value").null()  # All nulls, preserves Int/Float/String type
        """
        ...

    def first(self) -> Self:
        """
        Returns the first value in a group.

        Example:
            >>> col("date").first()
        """
        ...

    def last(self) -> Self:
        """
        Returns the last value in a group.

        Example:
            >>> col("date").last()
        """
        ...

    def product(self) -> Self:
        """
        Returns the product of all values in a group.

        Example:
            >>> col("factor").product()
        """
        ...

    def round(self, decimals: int) -> Self:
        """
        Rounds values to the specified number of decimal places.

        Args:
            decimals: Number of decimal places to round to

        Example:
            >>> col("price").round(2)
        """
        ...

    def coalesce(self, others: Expression | list[Expression]) -> Self:
        """
        Returns the first non-null value from this expression and the fallback expressions.

        Evaluates this expression first, then each expression in `others` in order,
        returning the first non-null value encountered. This is useful for providing
        default values or fallback chains for nullable columns.

        Args:
            others: A single fallback expression or a list of fallback expressions
                    to check in order if this expression is null

        Returns:
            Expression that evaluates to the first non-null value

        Examples:
            >>> # Simple null replacement with a single expression (no list needed)
            >>> col("nullable_field").coalesce(lit("N/A"))
            >>>
            >>> # Chain of fallbacks: primary -> secondary -> tertiary -> default
            >>> col("primary").coalesce([col("secondary"), col("tertiary"), lit("default")])
            >>>
            >>> # Use with numeric columns
            >>> col("price").coalesce([col("estimated_price"), lit(0.0)])
        """
        ...

    # Window and ranking functions
    def rank(
            self, method: str = "average", descending: bool = False, seed: int | None = None
    ) -> Self:
        """
        Rank values with flexible options.

        Args:
            method: Ranking method - "average", "min", "max", "dense",
                "ordinal", "random" (default: "average")
            descending: Rank in descending order (default: False)
            seed: Optional seed for random ranking (default: None)

        Returns:
            Self with ranked values

        Examples:
            >>> # Default ranking (average method, ascending)
            >>> col("score").rank()
            >>>
            >>> # Dense ranking, descending
            >>> col("score").rank(method="dense", descending=True)
            >>>
            >>> # Random ranking with seed for reproducibility
            >>> col("value").rank(method="random", seed=42)
        """
        ...

    def sort(
            self,
            descending: bool = False,
            nulls_last: bool = False,
            maintain_order: bool = False,
    ) -> Self:
        """
        Sort expression with flexible options.

        Args:
            descending: Sort in descending order (default: False)
            nulls_last: Place null values last (default: False)
            maintain_order: Maintain order of equal elements (default: False)

        Returns:
            Self with sorted values

        Examples:
            >>> # Default sort (ascending, nulls first)
            >>> col("name").sort()
            >>>
            >>> # Descending with nulls last
            >>> col("value").sort(descending=True, nulls_last=True)
            >>>
            >>> # Stable sort (maintain order of equal elements)
            >>> col("score").sort(maintain_order=True)
        """
        ...

    def over(
            self,
            partition_by: list[Expression] | None = None,
            order_by: list[Expression] | None = None,
            order_descending: bool = False,
            order_nulls_last: bool = False,
            mapping: str = "groups_to_rows",
    ) -> Self:
        """
        Apply a window function over partitions with optional ordering.

        Args:
            partition_by: Optional list of expressions to partition by (default: None)
            order_by: Optional list of expressions to order by (default: None)
            order_descending: Order in descending order (default: False)
            order_nulls_last: Place nulls last in ordering (default: False)
            mapping: Window mapping strategy - "groups_to_rows" or "explode"
                (default: "groups_to_rows")

        Returns:
            Self with window function applied

        Examples:
            >>> # Simple partition - sum within each category
            >>> col("amount").sum().over(partition_by=[col("category")])
            >>>
            >>> # Multiple partition columns
            >>> col("value").mean().over(partition_by=[col("region"), col("product")])
            >>>
            >>> # With ordering - rank within partitions
            >>> col("score").rank().over(
            ...     partition_by=[col("category")],
            ...     order_by=[col("date")],
            ...     order_descending=True
            ... )
            >>>
            >>> # Complex window with explode mapping
            >>> col("value").over(
            ...     partition_by=[col("region")],
            ...     order_by=[col("timestamp")],
            ...     order_nulls_last=True,
            ...     mapping="explode"
            ... )
        """
        ...

    # String operations
    def contains(self, other: str) -> Expression: ...

    def starts_with(self, other: str) -> Expression: ...

    def ends_with(self, other: str) -> Expression: ...

    def zfill(self, len: Expression) -> Self:
        """
        Pad string with leading zeros to reach specified length.

        Args:
            len: Target length for the padded string

        Returns:
            Expression with zero-padded string

        Example:
            >>> col("id").zfill(lit(5))  # "42" -> "00042"
        """
        ...

    def uppercase(self) -> Self:
        """
        Convert string to uppercase.

        Returns:
            Expression with uppercase string

        Example:
            >>> col("name").uppercase()  # "hello" -> "HELLO"
        """
        ...

    def lowercase(self) -> Self:
        """
        Convert string to lowercase.

        Returns:
            Expression with lowercase string

        Example:
            >>> col("name").lowercase()  # "HELLO" -> "hello"
        """
        ...

    def replace(self, pattern: Expression, value: Expression, literal: bool) -> Self:
        """
        Replace the first occurrence of a pattern with a value.

        Args:
            pattern: The pattern to search for
                (regex if literal=False, literal string if literal=True)
            value: The replacement value
            literal: If True, treat pattern as literal string; if False, treat as regex

        Returns:
            Expression with first occurrence replaced

        Example:
            >>> # "hello world" -> "hi world"
            >>> col("text").replace(lit("hello"), lit("hi"), literal=True)
        """
        ...

    def replace_n(
            self, pattern: Expression, value: Expression, literal: bool, n: int | None
    ) -> Self:
        """
        Replace n occurrences of a pattern with a value.

        Args:
            pattern: The pattern to search for
                (regex if literal=False, literal string if literal=True)
            value: The replacement value
            literal: If True, treat pattern as literal string; if False, treat as regex
            n: Number of replacements (None means replace all)

        Returns:
            Expression with n occurrences replaced

        Example:
            >>> col("text").replace_n(lit("a"), lit("b"), literal=True, n=2)  # "aaa" -> "bba"
        """
        ...

    def replace_all(self, pattern: Expression, value: Expression, literal: bool) -> Self:
        """
        Replace all occurrences of a pattern with a value.

        Args:
            pattern: The pattern to search for
                (regex if literal=False, literal string if literal=True)
            value: The replacement value
            literal: If True, treat pattern as literal string; if False, treat as regex

        Returns:
            Expression with all occurrences replaced

        Example:
            >>> # "hello hello" -> "hi hi"
            >>> col("text").replace_all(lit("hello"), lit("hi"), literal=True)
        """
        ...

    def strip_chars(self, chars: Expression) -> Self:
        """
        Remove leading and trailing occurrences of specified characters.

        Args:
            chars: The characters to remove

        Returns:
            Expression with leading and trailing characters removed

        Example:
            >>> col("text").strip_chars(lit(" *"))  # "  hello**" -> "hello"
        """
        ...

    def strip_chars_end(self, chars: Expression) -> Self:
        """
        Remove trailing occurrences of specified characters.

        Args:
            chars: The characters to remove

        Returns:
            Expression with trailing characters removed

        Example:
            >>> col("text").strip_chars_end(lit("!"))  # "hello!!!" -> "hello"
        """
        ...

    def strip_chars_start(self, chars: Expression) -> Self:
        """
        Remove leading occurrences of specified characters.

        Args:
            chars: The characters to remove

        Returns:
            Expression with leading characters removed

        Example:
            >>> col("text").strip_chars_start(lit("!"))  # "!!!hello" -> "hello"
        """
        ...

    def strip_prefix(self, prefix: Expression) -> Self:
        """
        Remove an exact substring prefix if present.

        Args:
            prefix: The prefix to remove

        Returns:
            Expression with prefix removed if present

        Example:
            >>> col("text").strip_prefix(lit("prefix_"))  # "prefix_hello" -> "hello"
        """
        ...

    def strip_suffix(self, suffix: Expression) -> Self:
        """
        Remove an exact substring suffix if present.

        Args:
            suffix: The suffix to remove

        Returns:
            Expression with suffix removed if present

        Example:
            >>> col("text").strip_suffix(lit("_suffix"))  # "hello_suffix" -> "hello"
        """
        ...

    # Additional methods
    def abs(self) -> Self:
        """Return absolute value of the expression"""
        ...

    def equals(self, other: Expression) -> Expression:
        """Equality comparison (alternative to ==)"""
        ...

    def less(self, other: Expression) -> Expression:
        """Less than comparison (alternative to <)"""
        ...

    def less_or_equal(self, other: Expression) -> Expression:
        """Less than or equal comparison (alternative to <=)"""
        ...

    def greater(self, other: Expression) -> Expression:
        """Greater than comparison (alternative to >)"""
        ...

    def greater_or_equal(self, other: Expression) -> Expression:
        """Greater than or equal comparison (alternative to >=)"""
        ...

    def is_null(self) -> Expression:
        """True if the value is null"""
        ...

    # Condition methods (for use with when/then/otherwise)
    def eq_condition(self, other: Expression) -> Condition:
        """Creates an equality condition (for use with when())"""
        ...

    def lt_condition(self, other: Expression) -> Condition:
        """Creates a less than condition (for use with when())"""
        ...

    def le_condition(self, other: Expression) -> Condition:
        """Creates a less than or equal condition (for use with when())"""
        ...

    def gt_condition(self, other: Expression) -> Condition:
        """Creates a greater than condition (for use with when())"""
        ...

    def ge_condition(self, other: Expression) -> Condition:
        """Creates a greater than or equal condition (for use with when())"""
        ...

    def is_null_condition(self) -> Condition:
        """Creates a null check condition (for use with when())"""
        ...

    # Boolean operators
    def __and__(self, other: Expression) -> Expression:
        """
        Logical AND (&) - combines two boolean expressions.

        Example:
            >>> (col("active") == lit(True)) & (col("amount") > lit(100))
        """
        ...

    def __or__(self, other: Expression) -> Expression:
        """
        Logical OR (|) - combines two boolean expressions.

        Example:
            >>> (col("status") == lit("active")) | (col("status") == lit("pending"))
        """
        ...

    def __invert__(self) -> Expression:
        """
        Logical NOT (~) - negates a boolean expression.

        Example:
            >>> ~(col("deleted") == lit(True))
        """
        ...


# Utility functions for creating expressions
def col(name: str) -> Expression:
    """
    Create a column reference expression.

    Args:
        name: The name of the column to reference

    Returns:
        An Expression that references the specified column
    """
    ...


def left_col(name: str) -> Expression:
    """
    Create a column reference to a column from the left table in a join context.

    This is a helper function for use with `with_columns_from()`. Do not use this function ouside of
    that context!

    Args:
        name: The name of the column from the left table

    Returns:
        An Expression that references the column from the left table

    Example:
        >>> result = users.with_columns_from(
        ...     orders,
        ...     [("user_name", left_col("name"))],  # Reference "name" from left table (users)
        ...     JoinMode.Inner,
        ...     [(col("user_id"), col("user_id"))]
        ... )
    """
    ...


def right_col(name: str) -> Expression:
    """
    Create a column reference to a column from the right table in a join context.

    This is a helper function for use with `with_columns_from()`. Do not use this function ouside of
    that context!

    Args:
        name: The name of the column from the right table

    Returns:
        An Expression that references the column from the right table

    Example:
        >>> result = users.with_columns_from(
        ...     orders,
        ...     # Reference "amount" from right table (orders)
        ...     [("order_amount", right_col("amount"))],
        ...     JoinMode.Inner,
        ...     [(col("user_id"), col("user_id"))]
        ... )
    """
    ...


def row_index(offset: int | None = None) -> Expression:
    """
    Create an expression containing the row index (0-based by default).

    This function generates a column with sequential row numbers. It's useful for:
    - Adding unique identifiers to rows
    - Creating ranking without window functions
    - Selecting top/bottom N rows after sorting

    Args:
        offset: Starting value for the row index (default: 0).
                Use offset=1 for 1-based indexing.

    Returns:
        An Expression containing the row index for each row.

    Example:
        >>> # Add 0-based row numbers
        >>> table.with_column("row_num", row_index())

        >>> # Add 1-based row numbers
        >>> table.with_column("row_num", row_index(offset=1))

        >>> # Select top 5 and bottom 5 after sorting
        >>> result = (
        ...     table
        ...     .sort(col("score"))
        ...     .with_column("idx", row_index())
        ...     .filter(
        ...         (col("idx") < lit(5)) |
        ...         (col("idx") >= col("idx").max() - lit(5))
        ...     )
        ...     .drop("idx")
        ... )

    Note:
        The row index is assigned based on the current row order. If you need
        ranking within groups, use `col("value").rank().over(partition_by=[...])` instead.
    """
    ...


def len() -> Expression:
    """
    Create an expression that returns the number of rows (length) in the current context.

    This is equivalent to `COUNT(*)` in SQL. It returns the total number of rows
    without requiring any column reference.

    Returns:
        An Expression containing the row count.

    Example:
        >>> # Get the total number of rows
        >>> table.with_column("total_rows", len())

        >>> # Use with window function to get group sizes
        >>> table.with_column("group_size", len().over(partition_by=[col("category")]))

        >>> # Calculate percentage of total
        >>> table.with_column(
        ...     "pct_of_total",
        ...     col("amount") / col("amount").sum() * len()
        ... )

    Note:
        Unlike col("x").count() which counts non-null values in column x,
        len() counts all rows regardless of null values.
    """
    ...


def lit_str(value: str) -> Expression:
    """
    Create a literal string expression.

    Args:
        value: The string literal value

    Returns:
        An Expression containing the literal string
    """
    ...


def lit_int(value: int) -> Expression:
    """
    Create a literal integer expression.

    Args:
        value: The integer literal value

    Returns:
        An Expression containing the literal integer
    """
    ...


def lit_float(value: float) -> Expression:
    """
    Create a literal float expression.

    Args:
        value: The float literal value

    Returns:
        An Expression containing the literal float
    """
    ...


def lit_bool(value: bool) -> Expression:
    """
    Create a literal boolean expression.

    Args:
        value: The boolean literal value

    Returns:
        An Expression containing the literal boolean
    """
    ...


def lit_date(value: datetime.date) -> Expression:
    """
    Create a literal date expression from a Python date object.

    Args:
        value: A datetime.date object

    Returns:
        An Expression containing the literal date

    Example:
        >>> from datetime import date
        >>> from nexus import lit_date
        >>> date_expr = lit_date(date(2025, 1, 31))
    """
    ...


def lit_datetime(value: datetime.datetime) -> Expression:
    """
    Create a literal datetime expression from a Python datetime object.

    Args:
        value: A datetime.datetime object

    Returns:
        An Expression containing the literal datetime

    Example:
        >>> from datetime import datetime
        >>> from nexus import lit_datetime
        >>> dt_expr = lit_datetime(datetime(2025, 1, 31, 10, 30, 0))
    """
    ...


def lit(value: str | int | float | bool | Any) -> Expression:
    """
    Create a literal expression from a Python value.

    Accepts int, float, str, bool, date, or datetime objects.

    Args:
        value: The literal value (string, int, float, bool, date, or datetime)

    Returns:
        An Expression containing the literal value

    Example:
        >>> from datetime import date, datetime
        >>> lit(42)          # Integer
        >>> lit(3.14)        # Float
        >>> lit("hello")     # String
        >>> lit(True)        # Boolean
        >>> lit(date(2025, 1, 31))              # Date
        >>> lit(datetime(2025, 1, 31, 10, 30))  # DateTime
    """
    ...


def lit_value(value: Any) -> Expression:
    """
    Create a literal expression from various Python types.

    Accepts int, float, str, bool, date, or datetime objects.
    Equivalent to ``lit()`` but with explicit ``Any`` input type.

    Args:
        value: The literal value

    Returns:
        An Expression containing the literal value
    """
    ...


def when(condition: Expression) -> WhenBuilder:
    """
    Start a when/then/otherwise conditional expression.

    Args:
        condition: The condition to check

    Returns:
        A WhenBuilder to specify the then value

    Example:
        >>> result = when(col("price") > lit(100)).then("expensive") \\
        ...     .when(col("price") > lit(50)).then("moderate") \\
        ...     .otherwise("cheap")
    """
    ...


def when_condition(condition: Expression | Condition) -> WhenBuilder:
    """
    Start a when/then/otherwise conditional expression.

    Accepts either a Condition or a boolean Expression.

    Args:
        condition: The condition or boolean expression to check

    Returns:
        A WhenBuilder to specify the then value
    """
    ...


def reset_rust_log_filter() -> None:
    """
    Reset the cached Rust-to-Python log-level filter.

    Call after reconfiguring Python logging so that pyo3-log picks up
    the new effective level.
    """
    ...


AggregationType = Literal["sum", "avg", "average", "median", "unique"]
"""Valid aggregation types for breakdown and group_by operations"""


def sql_column(name: str, data_type: DataType, data_view: str, sql_projection: str) -> SourceNode:
    """
    Create an SQL column reference with a specific data type.

    This function creates a column reference that can be used in SQL-based
    data views within the Nexus Engine. It constructs a SqlValueNode that
    sources its value from an SQL projection against a specified data view.
    The column reference includes type information for proper data handling and validation.

    Args:
        name: The name of the column to assign to the output of this node
        data_type: The expected data type of the result (PyDataType or DataType enum)
        data_view: The name of the DataView to execute the SQL against
        sql_projection: The SQL projection string (e.g., "SUM(price)", "customer_id", "COUNT(*)")

    Returns:
        A SourceNode representing the SQL column reference with type information

    Example:
        >>> # Simple column reference
        >>> customer_col = sql_column("customer_id", DataType.Int, "customers_view", "customer_id")
        >>>
        >>> # Aggregation
        >>> total_price = sql_column("total_price", DataType.Float, "orders_view", "SUM(price)")
        >>>
        >>> # Count
        >>> order_count = sql_column("order_count", DataType.Int, "orders_view", "COUNT(*)")
    """
    ...


def http_column(name: str, data_type: DataType, data_view: str, params: dict) -> SourceNode:
    """
    Create an HTTP/REST column reference with a specific data type.

    This function creates a column reference that can be used with HTTP-based
    data views (REST APIs, GraphQL endpoints) within the Nexus Engine. It
    constructs an HttpValueNode that sources its value from an HTTP request
    with the specified parameters.

    Args:
        name: The name of the column to assign to the output
        data_type: The expected data type of the result (DataType enum)
        data_view: The name of the DataView to execute the HTTP request against
        params: A dictionary of parameters to pass to the HTTP endpoint.
                These are serialized as JSON and sent with the request.

    Returns:
        A SourceNode representing the HTTP column reference with type information

    Example:
        >>> http_column(
        ...     "product_name",
        ...     DataType.String,
        ...     "abor_api",
        ...     {"graphql_selection": "{ abor { product(productCode: $product_code) { name } } }"}
        ... )
    """
    ...


class Condition:
    """Represents a condition used in filters and when clauses"""

    ...


class SourceNode:
    """Represents a source node (SQL column, etc.)"""

    def name(self) -> str:
        """Get the name of the source node"""
        ...

    def to_dict(self) -> dict[str, Any]:
        """Return a dictionary representation of the column for inspection and testing."""
        ...


class SqlValueNode:
    """Represents an SQL value node"""

    ...


class NodeMetadata:
    """
    Metadata associated with a node in the calculation graph.

    This class provides information about a node's origin and behavior:
    - `exclude_from_output`: If true, the node's column will not appear in the final output.
      This is typically used for internal join columns from `local_nodes`.
    - `source`: Indicates the origin of the node (e.g., "user", "local_nodes", "system").

    Note: NodeMetadata is primarily used internally by the engine. When defining nodes
    through the Python DSL, metadata is automatically set for local_nodes in DataView
    configurations. Users typically don't need to set metadata directly.

    Example:
        >>> # Create metadata for an internal node
        >>> meta = NodeMetadata(exclude_from_output=True, source="local_nodes")
        >>> print(meta.exclude_from_output)  # True
        >>> print(meta.source)  # "local_nodes"
    """

    def __init__(
            self,
            exclude_from_output: bool | None = None,
            source: str | None = None,
    ) -> None:
        """
        Create a new NodeMetadata instance.

        Args:
            exclude_from_output: If True, exclude this node's column from final output.
                                 Used for internal nodes like join keys that shouldn't
                                 appear in results. Defaults to None (not set).
            source: Optional string indicating the origin of this node.
                    Common values: "user", "local_nodes", "system".
        """
        ...

    @property
    def exclude_from_output(self) -> bool | None:
        """
        Get the exclude_from_output flag.

        Returns:
            Optional[bool]: True if this column should be excluded from output,
                            False if it should be included, None if not set.
        """
        ...

    @exclude_from_output.setter
    def exclude_from_output(self, value: bool | None) -> None:
        """Set the exclude_from_output flag."""
        ...

    @property
    def source(self) -> str | None:
        """
        Get the source of this node.

        Returns:
            Optional[str]: The origin of this node (e.g., "user", "local_nodes", "system"),
                           or None if not set.
        """
        ...

    @source.setter
    def source(self, value: str | None) -> None:
        """Set the source of this node."""
        ...

    def __repr__(self) -> str:
        """String representation of the metadata."""
        ...


class DataType(StrEnum):
    """Nexus data types"""

    Int = "Int"
    Float = "Float"
    String = "String"
    Bool = "Bool"
    Date = "Date"
    DateTime = "DateTime"


PyDataType = PyDataType


# Create a module-level object for join modes
class JoinMode:
    """Module providing join mode constants"""

    Inner: str
    Left: str
    Right: str
    Outer: str
    Cross: str
    Full: str
    Semi: str
    Anti: str


class TableBuilder:
    """
    Main table builder for constructing data transformation pipelines.

    This class provides a fluent API for building complex data transformation
    operations including filters, joins, aggregations, and more.
    """

    def __init__(self, source_nodes: list[Any]) -> None:
        """
        Create a new TableBuilder with source columns.

        Args:
            source_nodes: List of SourceNode objects created via sql_column()
        """
        ...

    def filter(self, expr: Expression) -> Self:
        """
        Filter rows based on an expression.

        Args:
            expr: Boolean expression to filter by

        Returns:
            Self for method chaining
        """
        ...

    def sort(self, sort_by: SortBySpec) -> Self:
        """
        Sort the table by one or more columns.

        Args:
            sort_by: Sort specification. Can be:
                - `str`: Column name (ascending, nulls last)
                - `Expression`: Sort by expression (ascending, nulls first)
                - `dict`: Full specification with column/expression and options
                - `list`: Multiple sort specifications for multi-column sorting

        Returns:
            Self for method chaining

        Examples:
            >>> # Sort by column name (ascending, nulls last)
            >>> table.sort("revenue")
            >>>
            >>> # Sort by expression (ascending, nulls first)
            >>> table.sort(col("price").abs())
            >>>
            >>> # Sort descending with dict
            >>> table.sort({"column": "revenue", "order": "desc"})
            >>>
            >>> # Sort by expression with options
            >>> table.sort({"expression": col("amount"), "order": "desc", "nulls_last": True})
            >>>
            >>> # Multi-column sort
            >>> table.sort([
            ...     {"column": "category", "order": "asc"},
            ...     {"expression": col("revenue"), "order": "desc"}
            ... ])
            >>>
            >>> # Sort with when/then expression
            >>> table.sort({
            ...     "expression": when(col("type") == lit("A")).then(1)
            ...                   .when(col("type") == lit("B")).then(2)
            ...                   .otherwise(3),
            ...     "order": "asc"
            ... })
        """
        ...

    def limit(self, limit: int) -> Self:
        """Limit the number of rows returned"""
        ...

    def offset(self, offset: int) -> Self:
        """Skip the first N rows"""
        ...

    def offset_limit(self, offset: int, limit: int) -> Self:
        """Skip N rows and limit to M rows"""
        ...

    def drop(self, columns: str | list[str]) -> Self:
        """
        Drop one or more columns from the table.

        Args:
            columns: Name of a single column or list of column names to remove

        Returns:
            Self for method chaining

        Examples:
            Drop a single column:
            >>> table.drop("temp_column")

            Drop multiple columns:
            >>> table.drop(["col1", "col2", "col3"])
        """
        ...

    def with_column(self, column_name: str, expression: Expression) -> Self:
        """
        Add or replace a column.

        Args:
            column_name: Name of the column to add/replace
            expression: Expression defining the column value

        Returns:
            Self for method chaining
        """
        ...

    def with_row_number(self, column_name: str, offset: int | None = None) -> Self:
        """
        Add a row number column to the table.

        Args:
            column_name: Name of the row number column to add
            offset: Optional starting offset for row numbers (defaults to None which starts at 0)

        Returns:
            Self for method chaining

        Example:
            >>> table.with_row_number("row_num")  # Row numbers starting from 0
            >>> table.with_row_number("row_num", offset=1)  # Row numbers starting from 1
        """
        ...

    def rename(self, old_name: str, new_name: str) -> Self:
        """Rename a column"""
        ...

    def rename_multiple(self, column_tuples: list[tuple[str, str]]) -> Self:
        """Rename multiple columns"""
        ...

    def select_columns(self, columns: list[str]) -> Self:
        """Select only specific columns"""
        ...

    def select(self, selections: list[tuple[Expression | str, str]]) -> Self:
        """
        Select and optionally rename columns using expressions.

        Args:
            selections: List of (expression, new_name) tuples

        Returns:
            Self for method chaining

        Example:
            >>> table.select([
            ...     (col("price").abs().sum(), "total_price"),
            ...     ("old_name", "new_name")
            ... ])
        """
        ...

    def group_by(
            self, by: str | list[str], aggregations: list[tuple[str, AggregationType]]
    ) -> Self:
        """
        Group by columns and apply aggregations.

        Args:
            by: Column name(s) to group by
            aggregations: List of (column, agg_type) tuples

        Returns:
            Self for method chaining

        Example:
            >>> table.group_by(
            ...     by=["currency", "category"],
            ...     aggregations=[("market_value", "sum"), ("price", "avg")]
            ... )
        """
        ...

    def join(
            self,
            right_table: TableBuilder,
            join_mode: str | JoinMode,
            join_on: list[tuple[Expression, Expression]],
            suffix: str | None = None,
    ) -> Self:
        """
        Join with another table.

        Args:
            right_table: The table to join with
            join_mode: Type of join ("inner", "left", "right", "outer", "cross")
            join_on: List of (left_col, right_col) column pairs to join on
            suffix: Optional suffix for duplicate column names from right table

        Returns:
            Self for method chaining
        """
        ...

    def with_columns_from(
            self,
            other: TableBuilder,
            columns: list[tuple[str, Expression]],
            join_mode: str | JoinMode,
            join_on: list[tuple[Expression, Expression]],
    ) -> Self:
        """
        Join with another table and add calculated columns from the joined result.

        This is a convenience method that combines joining with column selection. It allows you to
        easily reference columns from the left and right tables using `left_col()` and `right_col()`
        helper functions.

        Args:
            other: The table to join with (the right side)
            columns: List of (column_name, expression) tuples. Expressions can use
                `left_col()` and `right_col()` to reference columns from the respective tables
            join_mode: Type of join ("inner", "left", "right", "full")
            join_on: List of (left_expr, right_expr) pairs to join on

        Returns:
            Self for method chaining. The result contains:
            - All original left table columns (unless replaced)
            - New columns specified in the columns parameter
            - No intermediate right table columns

        Note:
            If a new column has the same name as an existing column,
            the new column replaces the old one.

        Example:
            >>> users = (
            ...     Builder()
            ...     .add_source_column(sql_column(DataType.Int, "users", "user_id"), "user_id")
            ...     .add_source_column(sql_column(DataType.String, "users", "name"), "name")
            ...     .to_table()
            ... )
            >>> orders = (
            ...     Builder()
            ...     .add_source_column(sql_column(DataType.Int, "orders", "order_id"), "order_id")
            ...     .add_source_column(sql_column(DataType.Int, "orders", "user_id"), "user_id")
            ...     .add_source_column(sql_column(DataType.Float, "orders", "amount"), "amount")
            ...     .to_table()
            ... )
            >>> result = users.with_columns_from(
            ...     orders,
            ...     [
            ...         ("user_name", left_col("name")),
            ...         ("order_amount", right_col("amount")),
            ...         ("total", left_col("user_id") + right_col("order_id"))
            ...     ],
            ...     JoinMode.Inner,
            ...     [(col("user_id"), col("user_id"))]
            ... )
        """
        ...

    def breakdown(
            self,
            breakdown_name: str,
            grouping_keys: list[str],
            aggregations: list[tuple[str, AggregationType]],
            filter: Expression | None = None,
            level_operations: list[LevelOperationWithRange] | None = None,
            node_id_separator: str | None = None,
    ) -> BreakdownBuilder:
        """
        Create a breakdown operation.

        Args:
            breakdown_name: Name for the breakdown operation
            grouping_keys: List of column names to group by at each level
            aggregations: List of (column_name, aggregation_type) tuples
            filter: Optional filter expression to apply before breakdown
            level_operations: Optional list of level operations
                (sort/filter/limit) to apply at different levels
            node_id_separator: Optional separator for constructing the
                node ID of a breakdown node. Defaults to ":".


        Returns:
            A BreakdownBuilder that can be converted back via to_table_builder()

        Example:
            >>> # Basic breakdown
            >>> table.breakdown(
            ...     "CATEGORY_BREAKDOWN",
            ...     ["category", "subcategory"],
            ...     [("amount", "sum")]
            ... ).to_table_builder()
            >>>
            >>> # With filter
            >>> table.breakdown(
            ...     "FILTERED_BREAKDOWN",
            ...     ["region"],
            ...     [("revenue", "sum")],
            ...     filter=col("active") == lit(True),
            ...     node_id_separator = "@"
            ... ).to_table_builder()
            >>>
            >>> # With level operations
            >>> table.breakdown(
            ...     "ADVANCED_BREAKDOWN",
            ...     ["region", "category"],
            ...     [("revenue", "sum")],
            ...     level_operations=[
            ...         {"type": "sort", "by": "revenue"},
            ...         ((1, 3), {"type": "limit", "limit": 5}),  # Apply to levels 1-2
            ...     ]
            ... ).to_table_builder()
        """
        ...

    def unpivot(
            self,
            key_column: str,
            value_column: str,
            columns_to_unpivot: list[str],
    ) -> UnpivotBuilder:
        """
        Unpivot (melt) columns into key-value pairs.

        Args:
            key_column: Name for the column that will contain the original column names
            value_column: Name for the column that will contain the values
            columns_to_unpivot: List of columns to unpivot

        Returns:
            An UnpivotBuilder that can be converted back via to_table_builder()

        Example:
            >>> table.unpivot(
            ...     key_column="metric",
            ...     value_column="value",
            ...     columns_to_unpivot=["Q1", "Q2", "Q3", "Q4"]
            ... ).to_table_builder()
        """
        ...

    def unpivot_builder(self) -> UnpivotBuilder:
        """
        Create an unpivot operation builder.

        Transforms wide format data to long format by converting columns to rows.
        Use the builder methods to configure retained columns, column mappings, and metadata.

        Returns:
            An UnpivotBuilder that can be converted to TableBuilder via into_table()

        Example:
            >>> builder = (
            ...     table.unpivot_builder()
            ...     .add_retained_column("id")
            ...     .add_column_mapping("Q1", "revenue")
            ...     .with_write_unpivoted_column_name("quarter")
            ...     .into_table()
            ... )
        """
        ...

    def partition(self) -> PartitionContext[Self]:
        """
        Create a partition context for conditional branching.

        Returns:
            A PartitionContext for defining branches

        Example:
            >>> table.partition() \\
            ...     .create_branch(col("type") == "A") \\
            ...     .filter(...).finish_branch() \\
            ...     .branch_remaining() \\
            ...     .filter(...).finish_branch() \\
            ...     .union()
        """
        ...

    def fork(self) -> ForkContext[Self]:
        """
        Create a fork context for parallel processing paths.

        Returns:
            A ForkContext for defining parallel branches
        """
        ...

    def set_table_name(self, name: str) -> Self:
        """Set the name of this table"""
        ...

    def list_current_columns(self) -> list[str]:
        """
        Get the list of current column names in the table.

        Returns:
            List of column names currently available in the table

        Example:
            >>> columns = table.list_current_columns()
            >>> print(columns)  # ["id", "name", "price", ...]
        """
        ...

    def current_table_name(self) -> str:
        """Get the current table name"""
        ...

    def detach(self, new_table_name: str) -> Self:
        """
        Detach the current table into an independent subquery.

        This creates a subquery boundary, useful for:
        - Breaking complex queries into simpler parts
        - Creating reusable intermediate results
        - Optimizing query execution by materializing intermediate steps

        Args:
            new_table_name: Name for the detached table/subquery

        Returns:
            Self for method chaining

        Example:
            >>> # Create a complex query, detach it, then use it
            >>> subquery = (
            ...     table
            ...     .filter(col("amount") > lit(1000))
            ...     .group_by(by="category", aggregations=[("amount", "sum")])
            ...     .detach("high_value_summary")
            ... )
            >>> # Now use the subquery in further operations
            >>> result = subquery.filter(col("amount") > lit(5000))
        """
        ...

    def build_json(self) -> str:
        """
        Build and return the result as a JSON string.

        Returns:
            JSON string representation of the query results
        """
        ...

    @staticmethod
    def union(table_builders: list[TableBuilder]) -> TableBuilder:
        """
        Create a union of multiple TableBuilders.

        Unions multiple table builders into a single table builder, concatenating their rows.
        All input tables must have compatible schemas (same columns with same types).

        Args:
            table_builders: List of TableBuilder instances to union

        Returns:
            A new TableBuilder representing the union of all input tables

        Example:
            >>> # Union portfolio and benchmark tables
            >>> pf_table = TableBuilder([...]).filter(col("type") == lit("Portfolio"))
            >>> bm_table = TableBuilder([...]).filter(col("type") == lit("Benchmark"))
            >>> result = TableBuilder.union([pf_table, bm_table])
        """
        ...

    def execute(
            self,
            params: dict[str, Any] | None = None,
            config: NexusConfig | None = None,
            url: str | None = None,
            api_token: str | None = None,
            output_format: Literal["json", "csv", "table", "parquet"] | None = None,
            write_to: str | None = None,
            timeout_seconds: int | None = None,
    ) -> dict | list | str | bytes:
        """
        Execute this table builder against the Nexus API.

        The HTTP client, tokio runtime, and OAuth token provider are cached and
        reused across calls. OAuth settings are configured once via ``NexusConfig``.

        Args:
            params: Optional dictionary of runtime parameters to pass to the calculation.
                   These can be referenced in SQL projections and filters.
                   Example: {"account_id": "ABC123", "date": "2025-01-31"}

            config: Optional NexusConfig to use instead of loading from file/env.
                   Configure OAuth here: ``NexusConfig(oauth_client_id=..., ...)``.
                   The client is cached inside the config object and reused across calls.

            url: Optional API base URL override for this request only.
                    The ``/api/v1`` path is appended automatically.

            api_token: Optional Authorization header value override for this request only.
                      Sent verbatim as the ``Authorization`` header — include the scheme
                      yourself, e.g. ``"Bearer my-token"`` or ``"Basic dXNlcjpwYXNz"``.
                      Takes priority over both static ``auth_token`` and OAuth.

            output_format: Response format for the results:
                          - "json" (default): Returns dict/list with parsed JSON data
                          - "csv": Returns CSV-formatted string
                          - "table": Returns formatted table string
                          - "parquet": Returns bytes containing Parquet binary data

            write_to: Optional name of a configured output writer on the server.

            timeout_seconds: Optional request timeout override in seconds for this request only.

        Returns:
            Result based on output_format:
            - "json": dict or list containing the calculation results
            - "csv" or "table": str with formatted output
            - "parquet": bytes containing binary Parquet data

        Raises:
            RuntimeError: If the API request fails (network error, timeout, server error)
            ValueError: If the table builder is invalid or output_format is unsupported
            TypeError: If params contain values that cannot be converted to JSON

        Example:
            >>> # Basic execution with default config
            >>> result = table.execute()
            >>>
            >>> # With OAuth configured once, reused across calls
            >>> cfg = NexusConfig(oauth_client_id="...", oauth_authorize_endpoint="...")
            >>> result1 = table.execute(config=cfg, params={"date": "2025-01-01"})
            >>> result2 = table.execute(config=cfg, params={"date": "2025-02-01"})
            >>>
            >>> # Per-request overrides
            >>> csv_data = table.execute(
            ...     url="http://prod-server:3000",
            ...     output_format="csv"
            ... )
        """
        ...


class BreakdownBuilder:
    """Builder for breakdown operations"""

    def add_scalar_column(self, column_name: str, value: str | int | float | bool) -> Self:
        """
        Add a scalar column to the breakdown result.

        Args:
            column_name: Name of the column to add
            value: Scalar value to use for all rows

        Returns:
            Self for method chaining
        """
        ...

    def with_breakdown_name(self, name: str) -> Self:
        """
        Set or change the breakdown name.

        Args:
            name: The new name for the breakdown

        Returns:
            Self for method chaining

        Example:
            >>> breakdown = table.breakdown("OLD_NAME", ["region"], [("sales", "sum")])
            >>> breakdown = breakdown.with_breakdown_name("NEW_NAME")
        """
        ...

    def aggregation_names(self) -> list[str]:
        """
        Get the list of aggregation column names.

        Returns:
            List of column names that contain aggregated values

        Example:
            >>> breakdown = table.breakdown(
            ...     "SALES", ["region"], [("revenue", "sum"), ("units", "sum")]
            ... )
            >>> names = breakdown.aggregation_names()
            >>> # Returns: ["revenue", "units"]
        """
        ...

    def modify_level(self, level_index: int, modifier: Any) -> Self:
        """
        Modify a specific breakdown level.

        This allows modifying each breakdown level independently before
        converting to a table. The modifier function receives a TableBuilder
        for that level and should return a modified TableBuilder.

        Args:
            level_index: Index of the level to modify (0 = grand total, 1 = first grouping, etc.)
            modifier: Callable that takes TableBuilder and returns modified TableBuilder

        Returns:
            Self for method chaining

        Example:
            >>> def modify_region_level(table):
            ...     return table.with_column("custom_col", lit("value"))
            >>>
            >>> breakdown = (
            ...     table.breakdown("SALES", ["region", "category"], [("amount", "sum")])
            ...     .modify_level(1, modify_region_level)  # Modify the "region" level
            ... )
        """
        ...

    def num_levels(self) -> int:
        """
        Get the number of breakdown levels.

        Returns:
            The number of levels (always number of grouping keys + 1 for grand total)

        Example:
            >>> breakdown = table.breakdown("SALES", ["region", "category"], [("amount", "sum")])
            >>> num = breakdown.num_levels()  # Returns 3: grand total, region, region+category
        """
        ...

    def to_table_builder(self) -> TableBuilder:
        """
        Convert back to a TableBuilder.

        Returns:
            A TableBuilder for further operations
        """
        ...


class UnpivotBuilder:
    """Builder for unpivot operations"""

    def add_retained_column(self, column: str) -> Self:
        """
        Add a column that should be retained unchanged in the output.
        These columns will be repeated for each unpivoted row.

        Args:
            column: Name of the column to retain

        Returns:
            Self for method chaining
        """
        ...

    def add_retained_columns(self, columns: list[str]) -> Self:
        """
        Add multiple columns that should be retained unchanged in the output.

        Args:
            columns: List of column names to retain

        Returns:
            Self for method chaining
        """
        ...

    def add_column_mapping(self, source_column: str, target_column: str) -> Self:
        """
        Map a source column to a target column name in the unpivot result.

        Args:
            source_column: Name of the source column to unpivot
            target_column: Name of the target column in the result

        Returns:
            Self for method chaining
        """
        ...

    def add_column_mapping_by_type(
            self,
            source_columns: list[str],
            data_type: str | Any,  # DataType enum or string like "Float", "String", etc.
            target_column: str,
    ) -> Self:
        """
        Map multiple source columns to a target column, filtered by data type.

        This method allows you to specify a list of potential source columns and a data type.
        Only columns that match the specified data type will be unpivoted into the target column.
        This is particularly useful when you want to unpivot columns based on their type
        (e.g., all Float columns into ATTRIBUTE_DOUBLE, all String columns into ATTRIBUTE_TEXT).

        Args:
            source_columns: List of column names to consider for unpivoting
            data_type: The data type to filter by
                (can be DataType enum or string like "Float", "String", etc.)
            target_column: Name of the target column in the result

        Returns:
            Self for method chaining

        Example:
            >>> # Unpivot all Float columns into ATTRIBUTE_DOUBLE
            >>> builder.add_column_mapping_by_type(
            ...     ["col1", "col2", "col3"],
            ...     nx.DataType.Float,  # or just "Float"
            ...     "ATTRIBUTE_DOUBLE"
            ... )
            >>>
            >>> # Unpivot all String columns into ATTRIBUTE_TEXT
            >>> builder.add_column_mapping_by_type(
            ...     ["name", "description", "category"],
            ...     "String",  # String representation also works
            ...     "ATTRIBUTE_TEXT"
            ... )
        """
        ...

    def with_write_unpivoted_column_name(self, column: str) -> Self:
        """
        Set the name for a column that will contain the original source column names.

        Args:
            column: Name for the metadata column

        Returns:
            Self for method chaining
        """
        ...

    def with_write_unpivoted_column_type(self, column: str) -> Self:
        """
        Set the name for a column that will contain the original source column types.

        This enables type-based column mapping in unpivot operations.

        Args:
            column: Name for the type metadata column

        Returns:
            Self for method chaining
        """
        ...

    def with_attribute_index_name(self, column: str) -> Self:
        """
        Set the name for an index column that enumerates the mapped attribute.

        Args:
            column: Name for the attribute index column

        Returns:
            Self for method chaining
        """
        ...

    def with_index_name(self, column: str) -> Self:
        """
        Set the name for an index column that enumerates the row number.

        Args:
            column: Name for the row index column

        Returns:
            Self for method chaining
        """
        ...

    def into_table(self) -> TableBuilder:
        """
        Convert the unpivot builder into a table builder.

        Returns:
            A TableBuilder for further operations
        """
        ...

    def to_table_builder(self) -> TableBuilder:
        """
        Alias for into_table(). Convert back to a TableBuilder.

        Returns:
            A TableBuilder for further operations
        """
        ...


class PartitionContext(Generic[_P]):
    """Context for partition operations with conditional branching.

    The type parameter ``_P`` tracks the parent builder type so that
    :meth:`union` can return the correct type for seamless chaining.
    """

    def create_branch(self, expression: Expression) -> PartitionBranchBuilder[_P]:
        """
        Create a new branch with a condition.

        Args:
            expression: Boolean expression to filter this branch

        Returns:
            A PartitionBranchBuilder for defining the branch operations
        """
        ...

    def branch_remaining(self) -> PartitionBranchBuilder[_P]:
        """
        Create a branch for all remaining rows.

        Returns:
            A PartitionBranchBuilder for defining operations on remaining rows
        """
        ...

    def union(self) -> _P:
        """
        Union all branches back together and return to the parent builder.

        Returns:
            The parent builder with the partitioned data unioned back together

        Example:
            >>> # Returns TableBuilder
            >>> result = table.partition() \\
            ...     .create_branch(col("x") > 10).finish_branch() \\
            ...     .branch_remaining().finish_branch() \\
            ...     .union()  # Returns TableBuilder
            >>>
            >>> # Returns ForkBranchBuilder (nested in fork)
            >>> result = table.fork() \\
            ...     .add_branch() \\
            ...     .partition() \\
            ...     .create_branch(col("x") > 10).finish_branch() \\
            ...     .union()  # Returns ForkBranchBuilder
            ...     .finish_branch() \\
            ...     .union()
        """
        ...


class PartitionBranchBuilder(Generic[_P]):
    """Builder for a single partition branch.

    The type parameter ``_P`` tracks the original parent so that the
    full chain unwinds to the correct type.
    """

    def filter(self, expr: Expression) -> Self:
        """Filter rows in this branch"""
        ...

    def sort(self, sort_by: SortBySpec) -> Self:
        """
        Sort the table by one or more columns.

        Args:
            sort_by: Sort specification. See TableBuilder.sort() for full documentation.

        Returns:
            Self for method chaining
        """
        ...

    def limit(self, limit: int) -> Self:
        """Limit rows in this branch"""
        ...

    def offset(self, offset: int) -> Self:
        """
        Skip the first N rows.

        Args:
            offset: Number of rows to skip

        Returns:
            Self for method chaining
        """
        ...

    def offset_limit(self, offset: int, limit: int) -> Self:
        """
        Skip N rows and limit to M rows.

        Args:
            offset: Number of rows to skip
            limit: Maximum number of rows to return

        Returns:
            Self for method chaining
        """
        ...

    def drop(self, columns: str | list[str]) -> Self:
        """
        Drop one or more columns from the table.

        Args:
            columns: Name of a single column or list of column names to remove

        Returns:
            Self for method chaining

        Examples:
            Drop a single column:
            >>> branch.drop("temp_column")

            Drop multiple columns:
            >>> branch.drop(["col1", "col2", "col3"])
        """
        ...

    def with_column(self, column_name: str, expression: Expression) -> Self:
        """Add a column to this branch"""
        ...

    def with_row_number(self, column_name: str, offset: int | None = None) -> Self:
        """
        Add a row number column to the table in this branch.

        Args:
            column_name: Name of the row number column to add
            offset: Optional starting offset for row numbers (defaults to None which starts at 0)

        Returns:
            Self for method chaining
        """
        ...

    def rename(self, old_name: str, new_name: str) -> Self:
        """
        Rename a column.

        Args:
            old_name: Current column name
            new_name: New column name

        Returns:
            Self for method chaining
        """
        ...

    def rename_multiple(self, column_tuples: list[tuple[str, str]]) -> Self:
        """
        Rename multiple columns at once.

        Args:
            column_tuples: List of (old_name, new_name) tuples

        Returns:
            Self for method chaining
        """
        ...

    def select(self, selections: list[tuple[Expression | str, str]]) -> Self:
        """Select columns in this branch"""
        ...

    def select_columns(self, columns: list[str]) -> Self:
        """Select specific columns in this branch"""
        ...

    def join(
            self,
            right_table: TableBuilder,
            join_on: list[tuple[Expression, Expression]],
            join_mode: str | JoinMode,
            suffix: str | None = None,
    ) -> Self:
        """
        Join with another table within this branch.

        Args:
            right_table: The table to join with
            join_on: List of (left_col, right_col) column pairs to join on
            join_mode: Type of join ("inner", "left", "right", "outer", "cross")
            suffix: Optional suffix for duplicate column names from right table

        Returns:
            Self for method chaining
        """
        ...

    def group_by(
            self, by: str | list[str], aggregations: list[tuple[str, AggregationType]]
    ) -> Self:
        """Group by columns in this branch"""
        ...

    def partition(self) -> PartitionContext[Self]:
        """Create a nested partition in this branch"""
        ...

    def fork(self) -> ForkContext[Self]:
        """
        Create a fork context for parallel processing paths within this branch.

        Returns:
            A ForkContext for defining parallel branches
        """
        ...

    def breakdown(
            self,
            breakdown_name: str,
            grouping_keys: list[str],
            aggregations: list[tuple[str, AggregationType]],
            filter: Expression | None = None,
            level_operations: list[LevelOperationWithRange] | None = None,
            node_id_separator: str | None = None,
    ) -> BreakdownBuilder:
        """
        Create a breakdown operation within this branch.

        Args:
            breakdown_name: Name for the breakdown operation
            grouping_keys: List of column names to group by at each level
            aggregations: List of (column_name, aggregation_type) tuples
            filter: Optional filter expression to apply before breakdown
            level_operations: Optional list of level operations
                (sort/filter/limit) to apply at different levels
            node_id_separator: Optional separator for constructing the
                node ID of a breakdown node. Defaults to ":".

        Returns:
            A BreakdownBuilder that can be converted back via to_table_builder()
        """
        ...

    def unpivot_builder(self) -> UnpivotBuilder:
        """
        Create an unpivot operation builder within this branch.

        Returns:
            An UnpivotBuilder that can be converted to TableBuilder via into_table()
        """
        ...

    def list_current_columns(self) -> list[str]:
        """
        Get the list of current column names in this branch.

        Returns:
            List of column names currently available
        """
        ...

    def current_table_name(self) -> str:
        """Get the current table name for this branch"""
        ...

    def detach(self, new_table_name: str) -> Self:
        """
        Detach this branch into an independent subquery.

        Args:
            new_table_name: Name for the detached table/subquery

        Returns:
            Self for method chaining
        """
        ...

    def set_table_name(self, name: str) -> Self:
        """
        Set the name of the table in this branch.

        Args:
            name: The new name for the table

        Returns:
            Self for method chaining
        """
        ...

    def finish_branch(self) -> PartitionContext[_P]:
        """
        Finish this branch and return to the partition context.

        Returns:
            The parent PartitionContext
        """
        ...


class ForkContext(Generic[_P]):
    """Context for fork operations with parallel branches.

    The type parameter ``_P`` tracks the parent builder type so that
    :meth:`union` can return the correct type for seamless chaining.
    """

    def add_branch(self) -> ForkBranchBuilder[_P]:
        """
        Add a parallel branch.

        Returns:
            A ForkBranchBuilder for defining the branch operations
        """
        ...

    def join_branches(
            self,
            left_branch_index: int,
            right_branch_index: int,
            join_mode: str | JoinMode,
            join_on: list[tuple[Expression, Expression]],
            suffix: str | None = None,
    ) -> Self:
        """
        Join two branches within the fork.

        This operation joins the data from two branches using standard SQL join semantics.
        The branch with the smaller index will contain the joined result, and the branch
        with the larger index will be removed.

        Args:
            left_branch_index: Index of the left branch (0-based)
            right_branch_index: Index of the right branch (0-based)
            join_mode: Type of join (Inner, Left, Right, Full, Cross)
            join_on: List of column pairs to join on [(left_col, right_col), ...]
            suffix: Optional suffix for right table columns (default: "_right")

        Returns:
            Self for method chaining

        Raises:
            RuntimeError: If either branch index is invalid or if they are equal

        Examples:
            Join two branches on a common key:
            >>> result = (
            ...     table.fork()
            ...     .add_branch()  # Branch 0
            ...     .filter(col("type") == "A")
            ...     .finish_branch()
            ...     .add_branch()  # Branch 1
            ...     .filter(col("type") == "B")
            ...     .finish_branch()
            ...     .join_branches(0, 1, JoinMode.Inner, [("id", "id")])
            ...     .union()
            ... )
        """
        ...

    def union(self) -> _P:
        """
        Union all branches together and return to the parent builder.

        Returns:
            The parent builder with the forked branches unioned together

        Example:
            >>> # Returns TableBuilder
            >>> result = table.fork() \\
            ...     .add_branch().filter(...).finish_branch() \\
            ...     .add_branch().filter(...).finish_branch() \\
            ...     .union()  # Returns TableBuilder
            >>>
            >>> # Returns PartitionBranchBuilder (nested in partition)
            >>> result = table.partition() \\
            ...     .create_branch(col("x") > 10) \\
            ...     .fork() \\
            ...     .add_branch().finish_branch() \\
            ...     .union()  # Returns PartitionBranchBuilder
            ...     .finish_branch() \\
            ...     .union()
        """
        ...


class ForkBranchBuilder(Generic[_P]):
    """Builder for a single fork branch.

    The type parameter ``_P`` tracks the original parent so that the
    full chain unwinds to the correct type.
    """

    def filter(self, expr: Expression) -> Self:
        """Filter rows in this branch"""
        ...

    def sort(self, sort_by: SortBySpec) -> Self:
        """
        Sort the table by one or more columns.

        Args:
            sort_by: Sort specification. See TableBuilder.sort() for full documentation.

        Returns:
            Self for method chaining
        """
        ...

    def limit(self, limit: int) -> Self:
        """
        Limit the number of rows returned.

        Args:
            limit: Maximum number of rows to return

        Returns:
            Self for method chaining
        """
        ...

    def offset(self, offset: int) -> Self:
        """
        Skip the first N rows.

        Args:
            offset: Number of rows to skip

        Returns:
            Self for method chaining
        """
        ...

    def offset_limit(self, offset: int, limit: int) -> Self:
        """
        Skip N rows and limit to M rows.

        Args:
            offset: Number of rows to skip
            limit: Maximum number of rows to return

        Returns:
            Self for method chaining
        """
        ...

    def drop(self, columns: str | list[str]) -> Self:
        """
        Drop one or more columns from the table.

        Args:
            columns: Name of a single column or list of column names to remove

        Returns:
            Self for method chaining

        Examples:
            Drop a single column:
            >>> branch.drop("temp_column")

            Drop multiple columns:
            >>> branch.drop(["col1", "col2", "col3"])
        """
        ...

    def with_column(self, column_name: str, expression: Expression) -> Self:
        """Add a column to this branch"""
        ...

    def with_row_number(self, column_name: str, offset: int | None = None) -> Self:
        """
        Add a row number column to the table in this branch.

        Args:
            column_name: Name of the row number column to add
            offset: Optional starting offset for row numbers (defaults to None which starts at 0)

        Returns:
            Self for method chaining
        """
        ...

    def rename(self, old_name: str, new_name: str) -> Self:
        """
        Rename a column.

        Args:
            old_name: Current column name
            new_name: New column name

        Returns:
            Self for method chaining
        """
        ...

    def rename_multiple(self, column_tuples: list[tuple[str, str]]) -> Self:
        """
        Rename multiple columns at once.

        Args:
            column_tuples: List of (old_name, new_name) tuples

        Returns:
            Self for method chaining
        """
        ...

    def select(self, selections: list[tuple[Expression | str, str]]) -> Self:
        """Select columns in this branch"""
        ...

    def select_columns(self, columns: list[str]) -> Self:
        """
        Select only specific columns.

        Args:
            columns: List of column names to keep

        Returns:
            Self for method chaining
        """
        ...

    def join(
            self,
            right_table: TableBuilder,
            join_on: list[tuple[Expression, Expression]],
            join_mode: str | JoinMode,
            suffix: str | None = None,
    ) -> Self:
        """
        Join with another table within this branch.

        Args:
            right_table: The table to join with
            join_on: List of (left_col, right_col) column pairs to join on
            join_mode: Type of join (see JoinMode)
            suffix: Optional suffix for duplicate column names from right table

        Returns:
            Self for method chaining
        """
        ...

    def group_by(
            self, by: str | list[str], aggregations: list[tuple[str, AggregationType]]
    ) -> Self:
        """
        Group by columns and apply aggregations.

        Args:
            by: Column name(s) to group by
            aggregations: List of (column, agg_type) tuples

        Returns:
            Self for method chaining
        """
        ...

    def partition(self) -> PartitionContext[Self]:
        """
        Create a partition context for conditional branching within this branch.

        Returns:
            A PartitionContext for defining conditional branches
        """
        ...

    def fork(self) -> ForkContext[Self]:
        """
        Create a nested fork context within this branch.

        Returns:
            A ForkContext for defining parallel branches
        """
        ...

    def breakdown(
            self,
            breakdown_name: str,
            grouping_keys: list[str],
            aggregations: list[tuple[str, AggregationType]],
            filter: Expression | None = None,
            level_operations: list[LevelOperationWithRange] | None = None,
            node_id_separator: str | None = None,
    ) -> BreakdownBuilder:
        """
        Create a breakdown operation within this branch.

        Args:
            breakdown_name: Name for the breakdown operation
            grouping_keys: List of column names to group by at each level
            aggregations: List of (column_name, aggregation_type) tuples
            filter: Optional filter expression to apply before breakdown
            level_operations: Optional list of level operations
                (sort/filter/limit) to apply at different levels
            node_id_separator: Optional separator for constructing the
                node ID of a breakdown node. Defaults to ":".

        Returns:
            A BreakdownBuilder that can be converted back via to_table_builder()
        """
        ...

    def unpivot_builder(self) -> UnpivotBuilder:
        """
        Create an unpivot operation builder within this branch.

        Returns:
            An UnpivotBuilder that can be converted to TableBuilder via into_table()
        """
        ...

    def list_current_columns(self) -> list[str]:
        """
        Get the list of current column names in this branch.

        Returns:
            List of column names currently available
        """
        ...

    def current_table_name(self) -> str:
        """Get the current table name for this branch"""
        ...

    def detach(self, new_table_name: str) -> Self:
        """
        Detach this branch into an independent subquery.

        Args:
            new_table_name: Name for the detached table/subquery

        Returns:
            Self for method chaining
        """
        ...

    def set_table_name(self, name: str) -> Self:
        """
        Set the name of the table in this branch.

        Args:
            name: The new name for the table

        Returns:
            Self for method chaining
        """
        ...

    def finish_branch(self) -> ForkContext[_P]:
        """
        Finish this branch and return to the fork context.

        Returns:
            The parent ForkContext
        """
        ...


def execute_nodes(
        nodes_json: str,
        target_node_name: str,
        params: dict[str, Any] | None = None,
        config: NexusConfig | None = None,
        output_format: str | None = None,
        output: str | None = None,
        api_token: str | None = None,
) -> Any:
    """Execute pre-built graph nodes against the Nexus Engine API.

    This is the primary entry point for ``nexus.serve`` — it takes
    already-serialized graph nodes (from ``TableBuilder.build_json()``)
    and sends them to the engine, releasing the GIL so other Python
    threads can run concurrently.

    Args:
        nodes_json: JSON string of graph nodes (from ``build_calculation_json``).
        target_node_name: Name of the target node to calculate.
        params: Dictionary of runtime parameters.
        config: NexusConfig with API URL and auth settings.
        output_format: Response format — ``"json"`` (default), ``"csv"``,
            ``"table"``, or ``"parquet"``.
        output: Optional output target.
        api_token: Optional bearer token to forward to the engine
            (e.g. ``"Bearer <token>"``).

    Returns:
        Parsed result based on *output_format*.
    """
    ...


# Module exports
__all__ = [
    # Core types
    "Expression",
    "Condition",
    "PyDataType",
    "DataType",
    "NexusConfig",
    # Builders
    "WhenBuilder",
    "ThenBuilder",
    "ChainedWhenBuilder",
    "TableBuilder",
    "BreakdownBuilder",
    "UnpivotBuilder",
    "PartitionContext",
    "PartitionBranchBuilder",
    "ForkContext",
    "ForkBranchBuilder",
    # Source nodes
    "SourceNode",
    "SqlValueNode",
    "NodeMetadata",
    # Enums
    "JoinMode",
    # Functions
    "execute_nodes",
    "col",
    "row_index",
    "left_col",
    "right_col",
    "lit_date",
    "lit_datetime",
    "len",
    "lit_str",
    "lit_int",
    "lit_float",
    "lit_bool",
    "lit",
    "lit_value",
    "when",
    "when_condition",
    "sql_column",
    "http_column",
    # Type aliases
    "AggregationType",
    "reset_rust_log_filter",
]
