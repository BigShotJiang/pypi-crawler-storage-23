"""Calculation registry for managing predefined calculations."""

from collections.abc import Callable
from dataclasses import dataclass, field
import logging
import re
from typing import Any

from nexus import TableBuilder

logger = logging.getLogger("nexus.serve")

CALCULATION_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")


@dataclass
class _CalculationEntry:
    """Metadata for a registered calculation builder."""

    builder: Callable[..., Any]
    name: str
    description: str | None = None
    default_params: dict[str, Any] = field(default_factory=dict)
    output_formatter: Any | None = None
    writer_name: str | None = None


def _normalize_builder_result(
        result: TableBuilder | tuple[TableBuilder, dict[str, Any] | None],
) -> tuple[TableBuilder, dict[str, Any]]:
    """Normalize builder return to (TableBuilder, param_overrides)."""
    if not isinstance(result, tuple):
        return result, {}
    tb: TableBuilder = result[0]  # type: ignore[assignment]
    overrides: dict[str, Any] | None = result[1]  # type: ignore[assignment]
    if overrides is not None:
        return tb, overrides
    return tb, {}


class CalculationRegistry:
    """Registry for managing predefined calculations defined in Python."""

    def __init__(self):
        self._entries: dict[str, _CalculationEntry] = {}
        self._fallback_handler: Callable | None = None

    def register_fallback(self, handler: Callable) -> None:
        """Register a fallback handler for unknown calculations.

        Raises ValueError if a *different* handler is already registered.
        Re-registering the same function is allowed (reload safety).
        """
        if self._fallback_handler is not None and self._fallback_handler is not handler:
            existing = getattr(self._fallback_handler, "__name__", "?")
            raise ValueError(
                f"A fallback handler is already registered ({existing!r}). "
                f"Only one fallback is allowed."
            )
        self._fallback_handler = handler
        logger.info(
            "Registered fallback handler",
            extra={"function": getattr(handler, "__name__", "?")},
        )

    def get_fallback(self) -> Callable | None:
        """Return the registered fallback handler, or None."""
        return self._fallback_handler

    def register(
            self,
            name: str,
            builder: Callable[..., Any],
            *,
            description: str | None = None,
            default_params: dict[str, Any] | None = None,
            output_formatter: Any | None = None,
            writer_name: str | None = None,
    ) -> None:
        entry = _CalculationEntry(
            builder=builder,
            name=name,
            description=description,
            default_params=default_params if default_params is not None else {},
            output_formatter=output_formatter,
            writer_name=writer_name,
        )
        self._entries[name] = entry
        logger.debug(
            "Registered calculation builder",
            extra={
                "calculation_name": name,
                "function": getattr(builder, "__name__", "?"),
                "writer_name": entry.writer_name,
                "description": entry.description,
                "default_params": entry.default_params,
            },
        )

    def has_calculation(self, calculation_name: str) -> bool:
        return calculation_name in self._entries

    def build_calculation(
            self, calculation_name: str, **kwargs
    ) -> tuple[Any, dict[str, Any]] | None:
        entry = self._entries.get(calculation_name)
        if entry is None:
            return None

        try:
            apply_format = kwargs.pop("apply_format", False)

            merged_params = {**entry.default_params, **kwargs}

            logger.debug(
                "Building calculation",
                extra={
                    "calculation_name": calculation_name,
                    "params": merged_params,
                    "default_params": entry.default_params,
                    "apply_format": apply_format,
                },
            )

            result = entry.builder(**merged_params)
            table_builder, param_overrides = _normalize_builder_result(result)
            table_builder.set_table_name(calculation_name)

            if param_overrides:
                logger.debug(
                    "Builder returned param overrides",
                    extra={
                        "calculation_name": calculation_name,
                        "param_overrides": param_overrides,
                    },
                )
                merged_params = {**merged_params, **param_overrides}

            if apply_format and entry.output_formatter is not None:
                formatter = entry.output_formatter
                if hasattr(formatter, "format"):
                    logger.debug(
                        "Applying output formatter",
                        extra={
                            "calculation_name": calculation_name,
                            "formatter": (
                                formatter.__name__
                                if hasattr(formatter, "__name__")
                                else type(formatter).__name__
                            ),
                        },
                    )
                    table_builder = formatter.format(table_builder, **merged_params)

            return table_builder, merged_params

        except Exception as e:
            logger.error(
                "Failed to build calculation",
                extra={"calculation_name": calculation_name, "error": str(e)},
                exc_info=True,
            )
            raise

    def build_calculation_json(
            self, calculation_name: str, **kwargs
    ) -> tuple[str, dict[str, Any]] | None:
        result = self.build_calculation(calculation_name, **kwargs)
        if result is None:
            return None
        table_builder, merged_params = result
        return table_builder.build_json(), merged_params

    def list_calculations(self) -> set[str]:
        return set(self._entries.keys())

    def get_writer_name(self, calculation_name: str) -> str | None:
        entry = self._entries.get(calculation_name)
        if entry is None:
            return None
        return entry.writer_name

    def get_description(self, calculation_name: str) -> str | None:
        entry = self._entries.get(calculation_name)
        if entry is None:
            return None
        return entry.description

    def get_default_params(self, calculation_name: str) -> dict[str, Any] | None:
        entry = self._entries.get(calculation_name)
        if entry is None:
            return None
        return entry.default_params

    def get_calculation_info(self, calculation_name: str) -> dict[str, Any] | None:
        entry = self._entries.get(calculation_name)
        if entry is None:
            return None
        return {
            "name": calculation_name,
            "writer_name": entry.writer_name,
            "description": entry.description,
            "default_params": entry.default_params,
        }

    def validate_all(self) -> dict[str, Exception | None]:
        """Build every calculation with its default params and return results.

        Returns a dict mapping calculation name to None (success) or the Exception raised.
        """
        results: dict[str, Exception | None] = {}
        for name in sorted(self.list_calculations()):
            try:
                default_params = self.get_default_params(name) or {}
                self.build_calculation(name, **default_params)
                results[name] = None
            except Exception as e:
                results[name] = e
        return results

    def clear(self) -> None:
        """Remove all registered calculation builders and the fallback handler."""
        self._entries.clear()
        self._fallback_handler = None


# Global default registry
_default_registry = CalculationRegistry()


def calculation(
        name: str,
        output: type | None = None,
        description: str | None = None,
        default_params: dict[str, Any] | None = None,
) -> Callable:
    """Decorator to register a function as a calculation builder.

    The decorated function can return:
    - A TableBuilder
    - (TableBuilder, param_overrides_dict)
    - {"table_builder": TableBuilder, "param_overrides": dict}
    """

    def decorator(func: Callable) -> Callable:
        if not CALCULATION_NAME_PATTERN.match(name):
            raise ValueError(f"Invalid calculation name {name!r}: must match [a-zA-Z0-9_-]+")

        resolved_formatter = output
        resolved_writer = getattr(output, "writer_name", None) if output is not None else None
        resolved_defaults = default_params if default_params is not None else {}

        # Set attributes on the function for introspection by user code.
        func.calculation_name = name  # type: ignore[attr-defined]
        func.output_formatter = resolved_formatter  # type: ignore[attr-defined]
        func.writer_name = resolved_writer  # type: ignore[attr-defined]
        func.description = description  # type: ignore[attr-defined]
        func.default_params = resolved_defaults  # type: ignore[attr-defined]

        _default_registry.register(
            name,
            func,
            description=description,
            default_params=resolved_defaults,
            output_formatter=resolved_formatter,
            writer_name=resolved_writer,
        )
        return func

    return decorator


def fallback(_func: Callable | None = None) -> Callable:
    """Decorator to register a function as the fallback handler.

    Supports both ``@fallback`` and ``@fallback()`` syntax.
    """

    def decorator(func: Callable) -> Callable:
        _default_registry.register_fallback(func)
        return func

    if _func is not None:
        # Called as @fallback without parentheses
        return decorator(_func)
    return decorator
