"""Column source decorator for mapping functions to nx column calls."""

from collections.abc import Callable
import functools

import nexus as nx


class ColumnSource:
    """Binds decorated functions to a named data view and column kind.

    Usage::

        import nexus as nx
        from nexus.serve import ColumnSource

        sql = ColumnSource("sales_view", kind=nx.sql_column)
        api = ColumnSource("abor_api", kind=nx.http_column)

        @sql.column(nx.DataType.Float)
        def Revenue():
            return '"sales.revenue"'

        # Revenue() calls nx.sql_column("Revenue", DataType.Float, "sales_view", '"sales.revenue"')

        @api.column(nx.DataType.String)
        def ProductName(product_code="DEFAULT"):
            return {"graphql_selection": "...", "params": {"code": product_code}}

        # ProductName("ABC") calls nx.http_column("ProductName", DataType.String, "abor_api", {...})
    """

    def __init__(self, data_view: str, kind: Callable):
        self._data_view = data_view
        self._kind = kind

    def column(
            self,
            data_type: nx.DataType,
            name: str | None = None,
            description: str | None = None,
            tags: list[str] | None = None,
    ) -> Callable:
        data_view = self._data_view
        kind = self._kind

        def decorator(func: Callable) -> Callable:
            col_name = name if name is not None else getattr(func, "__name__", "unknown")

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                result = func(*args, **kwargs)
                return kind(col_name, data_type, data_view, result)

            wrapper.__name__ = col_name
            wrapper.name = col_name  # type: ignore[attr-defined]
            wrapper.description = description  # type: ignore[attr-defined]
            wrapper.tags = tags  # type: ignore[attr-defined]
            return wrapper

        return decorator
