"""nexus.serve — Framework for serving Nexus calculations over HTTP."""

import importlib
from pathlib import Path
import pkgutil
import sys

from nexus.serve.column import ColumnSource

# Always available — no [serve] extras needed (DD-3)
from nexus.serve.registry import CalculationRegistry, calculation, fallback
from nexus.serve.registry import _default_registry as calculation_registry


def import_calculation_packages(packages: list[str]) -> None:
    """Import packages and walk submodules so @calculation decorators fire.

    Adds cwd to ``sys.path`` if not already present so that local packages
    are importable without installation.
    """
    cwd = str(Path.cwd())
    if cwd not in sys.path:
        sys.path.append(cwd)
    for package in packages:
        mod = importlib.import_module(package)
        if hasattr(mod, "__path__"):
            for _importer, modname, _ispkg in pkgutil.walk_packages(
                mod.__path__, prefix=mod.__name__ + "."
            ):
                importlib.import_module(modname)


# Requires [serve] extras — lazy error on access
_SERVE_INSTALL_MSG = (
    "nexus.serve server requires additional dependencies. "
    "Install with: pip install nexus-engine[serve]"
)

try:
    from nexus.serve.auth import AuthContext
    from nexus.serve.config import AuthSettings, NexusConfig
    from nexus.serve.server import create_app, create_router
except ImportError as _serve_import_error:
    _original_error = _serve_import_error

    def _make_lazy_error(name: str):
        """Create a class that raises ImportError when instantiated or called."""

        def _raise(*args, **kwargs):
            raise ImportError(_SERVE_INSTALL_MSG) from _original_error

        _raise.__name__ = name
        _raise.__qualname__ = name
        return _raise

    AuthContext = _make_lazy_error("AuthContext")
    AuthSettings = _make_lazy_error("AuthSettings")
    NexusConfig = _make_lazy_error("NexusConfig")
    create_app = _make_lazy_error("create_app")
    create_router = _make_lazy_error("create_router")


__all__ = [
    "AuthContext",
    "AuthSettings",
    "CalculationRegistry",
    "ColumnSource",
    "NexusConfig",
    "calculation",
    "calculation_registry",
    "create_app",
    "create_router",
    "fallback",
    "import_calculation_packages",
]
