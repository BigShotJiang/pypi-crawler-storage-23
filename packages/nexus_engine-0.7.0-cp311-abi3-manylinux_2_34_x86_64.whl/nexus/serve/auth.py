"""JWT authentication for nexus.serve — JWKS verification + FastAPI dependency."""

import asyncio
import base64
from collections.abc import Callable
from dataclasses import dataclass
import hashlib
import json
import logging
import threading
import time
from typing import Any, Optional
import urllib.error
import urllib.parse
import urllib.request

from fastapi import HTTPException, Request
import jwt
from jwt import PyJWKClient, PyJWKClientError
import jwt.types

from nexus.serve.config import AuthSettings

logger = logging.getLogger(__name__)


@dataclass
class AuthContext:
    """Decoded JWT context attached to authenticated requests."""

    subject: str  # "sub" claim (empty string if absent)
    claims: dict[str, Any]  # full decoded payload


class JWKSTokenVerifier:
    """Validates JWTs against a remote JWKS endpoint with caching and rate-limited refresh."""

    def __init__(self, config: AuthSettings) -> None:
        self._config = config
        self._max_token_length = config.max_token_length
        self._jwk_client = PyJWKClient(
            config.jwks_uri,
            cache_keys=True,
            lifespan=300,
            headers={"User-Agent": "nexus-serve"},
        )
        self._refresh_lock = threading.Lock()
        self._last_refresh: float = 0.0

    def verify(self, token: str) -> dict:
        """Decode and validate a JWT. Retries once on key-fetch errors (key rotation)."""
        if len(token) > self._max_token_length:
            raise jwt.InvalidTokenError(
                f"Token exceeds maximum length ({len(token)} > {self._max_token_length})"
            )

        try:
            return self._decode(token)
        except PyJWKClientError:
            # Key rotation: refresh JWKS and retry once.
            self._rate_limited_refresh()
            return self._decode(token)

    def prefetch_jwks(self) -> None:
        """Fetch JWKS keys at startup to fail-fast if the endpoint is unreachable."""
        self._jwk_client.fetch_data()

    def _decode(self, token: str) -> dict:
        signing_key = self._jwk_client.get_signing_key_from_jwt(token)

        options: jwt.types.Options = {}
        if self._config.issuer is None:
            options["verify_iss"] = False
        if self._config.audience is None:
            options["verify_aud"] = False

        return jwt.decode(
            token,
            signing_key.key,
            algorithms=self._config.algorithms,
            issuer=self._config.issuer,
            audience=self._config.audience,
            leeway=self._config.leeway_seconds,
            options=options,
        )

    def _rate_limited_refresh(self) -> None:
        """Refresh JWKS keys at most once every 5 seconds."""
        with self._refresh_lock:
            now = time.monotonic()
            if now - self._last_refresh < 5.0:
                return
            self._jwk_client.fetch_data()
            self._last_refresh = now


def _check_required_claims(claims: dict, required_claims: dict[str, str]) -> None:
    """Raise HTTPException(403) if any required claim is missing or mismatched."""
    for claim_name, expected_value in required_claims.items():
        actual = claims.get(claim_name)
        if actual is None:
            logger.debug("Missing required claim %r", claim_name)
            raise HTTPException(status_code=403, detail="Insufficient claims")
        if isinstance(actual, list):
            if expected_value not in actual:
                logger.debug("Claim %r does not contain %r", claim_name, expected_value)
                raise HTTPException(status_code=403, detail="Insufficient claims")
        elif actual != expected_value:
            logger.debug(
                "Claim %r mismatch: got %r, expected %r",
                claim_name,
                actual,
                expected_value,
            )
            raise HTTPException(status_code=403, detail="Insufficient claims")


# ─── Token cache ─────────────────────────────────────────────────────────────

_TOKEN_REFRESH_MARGIN_SECS = 30
_DEFAULT_TOKEN_TTL_SECS = 300
_TOKEN_CACHE_MAX_ENTRIES = 1024


@dataclass
class _CachedToken:
    access_token: str
    claims: dict
    expires_at: float  # time.monotonic()


class TokenCache:
    """In-memory cache keyed by SHA-256 hash of client_id:client_secret."""

    def __init__(self, max_entries: int = _TOKEN_CACHE_MAX_ENTRIES) -> None:
        self._max_entries = max_entries
        self._cache: dict[str, _CachedToken] = {}
        self._lock = threading.Lock()

    @staticmethod
    def _cache_key(client_id: str, client_secret: str) -> str:
        return hashlib.sha256(f"{client_id}:{client_secret}".encode()).hexdigest()

    def get(self, client_id: str, client_secret: str) -> tuple[str, dict] | None:
        key = self._cache_key(client_id, client_secret)
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            if time.monotonic() >= entry.expires_at:
                del self._cache[key]
                return None
            return entry.access_token, entry.claims

    def put(
        self,
        client_id: str,
        client_secret: str,
        access_token: str,
        claims: dict,
        expires_in: int | None = None,
    ) -> None:
        key = self._cache_key(client_id, client_secret)
        if expires_in is not None:
            ttl = max(0, expires_in - _TOKEN_REFRESH_MARGIN_SECS)
        else:
            ttl = _DEFAULT_TOKEN_TTL_SECS
        expires_at = time.monotonic() + ttl
        with self._lock:
            if len(self._cache) >= self._max_entries and key not in self._cache:
                # Evict the entry that expires soonest.
                evict_key = min(self._cache, key=lambda k: self._cache[k].expires_at)
                del self._cache[evict_key]
            self._cache[key] = _CachedToken(
                access_token=access_token,
                claims=claims,
                expires_at=expires_at,
            )

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()


# ─── Basic auth exchanger ────────────────────────────────────────────────────


class BasicAuthExchanger:
    """Exchanges Basic auth credentials for a bearer token via client_credentials grant."""

    def __init__(
        self,
        token_endpoint: str,
        verifier: "JWKSTokenVerifier",
        cache: TokenCache,
        scopes: list[str] | None = None,
    ) -> None:
        self._token_endpoint = token_endpoint
        self._verifier = verifier
        self._cache = cache
        self._scopes = scopes

    def exchange(self, client_id: str, client_secret: str) -> tuple[str, dict]:
        """Exchange client credentials for (access_token, verified_claims)."""
        cached = self._cache.get(client_id, client_secret)
        if cached is not None:
            logger.debug("Basic auth token cache hit for client_id=%r", client_id)
            return cached

        logger.debug(
            "Exchanging basic auth credentials for client_id=%r at %s",
            client_id,
            self._token_endpoint,
        )
        token, expires_in = self._fetch_token(client_id, client_secret)
        claims = self._verifier.verify(token)
        self._cache.put(client_id, client_secret, token, claims, expires_in)
        logger.debug(
            "Basic auth token exchange succeeded for client_id=%r (expires_in=%s)",
            client_id,
            expires_in,
        )
        return token, claims

    def _fetch_token(self, client_id: str, client_secret: str) -> tuple[str, int | None]:
        """POST to token endpoint with client_credentials grant."""
        form_data: dict[str, str] = {"grant_type": "client_credentials"}
        if self._scopes:
            form_data["scope"] = " ".join(self._scopes)

        body = urllib.parse.urlencode(form_data).encode()
        credentials = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
        req = urllib.request.Request(
            self._token_endpoint,
            data=body,
            headers={
                "Authorization": f"Basic {credentials}",
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "nexus-serve",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            logger.debug(
                "Token endpoint returned HTTP %d for client_id=%r",
                e.code,
                client_id,
            )
            if 400 <= e.code < 500:
                raise HTTPException(status_code=401, detail="Invalid client credentials") from None
            raise HTTPException(status_code=502, detail="Token endpoint error") from e
        except (urllib.error.URLError, OSError) as e:
            logger.debug("Token endpoint unreachable: %s", e)
            raise HTTPException(status_code=502, detail="Token endpoint unreachable") from e

        access_token = data.get("access_token")
        if not access_token:
            raise HTTPException(status_code=502, detail="Invalid token endpoint response")

        return access_token, data.get("expires_in")


# ─── Token endpoint discovery ────────────────────────────────────────────────


def resolve_token_endpoint_url(auth_config: AuthSettings) -> str | None:
    """Resolve token endpoint from explicit config or OIDC discovery."""
    if auth_config.token_endpoint:
        return auth_config.token_endpoint

    if not auth_config.issuer:
        return None

    discovery_url = f"{auth_config.issuer.rstrip('/')}/.well-known/openid-configuration"
    try:
        req = urllib.request.Request(discovery_url, headers={"User-Agent": "nexus-serve"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        endpoint = data.get("token_endpoint")
        if not endpoint:
            raise RuntimeError(
                f"OIDC discovery at {discovery_url} did not contain 'token_endpoint'"
            )
        return endpoint
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
        raise RuntimeError(f"OIDC discovery failed for {discovery_url}: {e}") from e


def make_auth_dependency(
    auth_config: AuthSettings | None,
    verifier: Optional["JWKSTokenVerifier"],
    exchanger: BasicAuthExchanger | None = None,
) -> Callable:
    """Build a FastAPI dependency that validates JWTs or passes through when auth is disabled."""

    if auth_config is None or verifier is None:

        async def no_auth() -> None:
            return None

        return no_auth

    required_claims = auth_config.required_claims
    basic_enabled = auth_config.basic_auth_enabled and exchanger is not None

    async def verify_auth(request: Request) -> AuthContext:
        auth_header = request.headers.get("authorization", "")
        scheme = auth_header[:6].lower()

        # ── Basic auth path ──
        if scheme == "basic " and basic_enabled:
            assert exchanger is not None  # basic_enabled implies exchanger is set
            raw = auth_header[6:]
            try:
                decoded = base64.b64decode(raw, validate=True).decode("utf-8")
                client_id, client_secret = decoded.split(":", 1)
            except Exception:
                raise HTTPException(status_code=401, detail="Malformed Basic credentials") from None

            try:
                access_token, claims = await asyncio.to_thread(
                    exchanger.exchange,
                    client_id,
                    client_secret,
                )
            except HTTPException:
                raise
            except jwt.ExpiredSignatureError:
                raise HTTPException(status_code=401, detail="Token has expired") from None
            except (jwt.InvalidTokenError, PyJWKClientError) as exc:
                logger.debug("Exchanged token validation failed: %s", exc)
                raise HTTPException(status_code=401, detail="Invalid token") from None

            _check_required_claims(claims, required_claims)
            request.state.exchanged_token = access_token
            return AuthContext(subject=claims.get("sub", ""), claims=claims)

        # ── Bearer auth path ──
        if auth_header[:7].lower() == "bearer ":
            token = auth_header[7:]
            try:
                claims = await asyncio.to_thread(verifier.verify, token)
            except jwt.ExpiredSignatureError:
                raise HTTPException(status_code=401, detail="Token has expired") from None
            except (jwt.InvalidTokenError, PyJWKClientError) as exc:
                logger.debug("Token validation failed: %s", exc)
                raise HTTPException(status_code=401, detail="Invalid token") from None

            _check_required_claims(claims, required_claims)
            return AuthContext(subject=claims.get("sub", ""), claims=claims)

        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")

    return verify_auth
