"""Project scaffolding for `nexus init`."""

from __future__ import annotations

from pathlib import Path

NEXUS_TOML = """\
[project]
name = "my-nexus-project"
version = "0.1.0"

[calculations]
packages = ["calculations"]

# Engine connection (used by both standalone scripts and nexus serve)
# Can also be set via NEXUS_API_* environment variables.
# [engine]
# url = "https://nexus-engine.synlynx.com"
# timeout_seconds = 120
# tenant = "my-tenant-id"
#
# OAuth client credentials (recommended for production/CI):
# oauth_issuer = "https://auth.synlynx.com/realms/nexus-prod"
# oauth_client_id = "my-app"
# oauth_client_secret = "your-client-secret"
# oauth_scopes = ["openid"]

# [serve]
# host = "0.0.0.0"
# port = 8000
# log_level = "INFO"
# log_format = "json"

# [auth]
# jwks_uri = "https://auth.synlynx.com/realms/nexus-prod/protocol/openid-connect/certs"
# issuer = "https://auth.synlynx.com/realms/nexus-prod"
# audience = "nexus-engine-prod"
# required_claims = { organization = "my-org" }
# token_passthrough = true
"""

CALCULATIONS_INIT = """\
# Calculation modules are auto-discovered by `nexus serve`.
# You can also add explicit imports here:
# from . import example_calculation
"""

EXAMPLE_WRITER = '''\
"""Example output writer for reshaping results before writing."""

import nexus as nx


# --- Output writer (optional) ---
# A writer transforms results before writing them to an output destination.
# - `writer_name` identifies the engine-side writer (e.g. a Snowflake table).
# - `format()` reshapes the TableBuilder before the engine writes it.
#
# When the endpoint is called with ?skip_write=false, the server:
#   1. Calls format() to reshape the data  (apply_format is forced on)
#   2. Passes writer_name to the engine so it writes the result
#
# You can also use ?apply_format=true&skip_write=true to preview the
# formatted output without actually writing.


class ExampleWriter:
    writer_name = "my_output_target"

    @staticmethod
    def format(table: nx.TableBuilder, **params) -> nx.TableBuilder:
        """Reshape the table before writing."""
        from datetime import date

        # Example: add a metadata column from params
        report_date = params.get("date", date.today())
        table = table.with_column("REPORT_DATE", nx.lit(report_date))
        return table
'''

EXAMPLE_CALCULATION = '''\
"""Example calculation definition."""

import nexus as nx
from nexus.serve import calculation, ColumnSource

from .example_writer import ExampleWriter


source = ColumnSource("my_data_view", kind=nx.sql_column)


@source.column(nx.DataType.String, description="Security name", tags=["identifier"])
def Name():
    return \'"name"\'


@source.column(nx.DataType.Float, description="Monetary amount", tags=["measure"])
def Amount():
    return \'"amount"\'


# Pass `output=ExampleWriter` to wire up the writer.
# Without `output`, the calculation has no writer and skip_write is a no-op.
@calculation("example", output=ExampleWriter, description="An example calculation")
def build_example(**params):
    tb = nx.TableBuilder([
        Name(),
        Amount(),
    ])
    return tb
'''


def scaffold_project() -> list[str]:
    """Create the default project files if they don't already exist.

    Returns the list of file paths that were created.
    """
    files: dict[Path, str] = {
        Path("nexus.toml"): NEXUS_TOML,
        Path("calculations/__init__.py"): CALCULATIONS_INIT,
        Path("calculations/example_writer.py"): EXAMPLE_WRITER,
        Path("calculations/example_calculation.py"): EXAMPLE_CALCULATION,
    }

    created: list[str] = []
    for path, content in files.items():
        if path.exists():
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        created.append(str(path))

    return created
