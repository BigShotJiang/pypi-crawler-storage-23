"""Structured logging for nexus.serve with lazy configuration."""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.serve.config import ServeSettings

logger = logging.getLogger("nexus.serve")

# Uvicorn loggers that need to match the configured format.
_UVICORN_LOGGERS = ("uvicorn", "uvicorn.error", "uvicorn.access")

# Standard LogRecord attributes to exclude when appending extra fields.
_BUILTIN_ATTRS = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {
    "color_message",
    "taskName",
}


class _TextFormatter(logging.Formatter):
    """Text formatter that appends ``extra`` fields as key=value pairs."""

    def format(self, record: logging.LogRecord) -> str:
        base = super().format(record)
        extras = {k: v for k, v in record.__dict__.items() if k not in _BUILTIN_ATTRS}
        if not extras:
            return base
        parts = " ".join(f"{k}={v!r}" for k, v in extras.items())
        return f"{base}  {parts}"


def _make_formatter(log_format: str) -> logging.Formatter:
    """Build a formatter matching the configured log_format."""
    if log_format == "json":
        try:
            from pythonjsonlogger.json import JsonFormatter

            return JsonFormatter(
                "%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)d"
            )
        except ImportError:
            logger.warning("python-json-logger not installed, falling back to text format")
    return _TextFormatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")


def _apply_formatter(target: logging.Logger, formatter: logging.Formatter, level: int) -> None:
    """Replace all handlers on *target* with a single stdout handler using *formatter*."""
    target.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    target.addHandler(handler)
    target.setLevel(level)
    target.propagate = False


def configure_logger(serve: ServeSettings) -> None:
    """Reconfigure nexus.serve, Rust, and Uvicorn loggers. Called by create_app()."""
    level = getattr(logging, serve.log_level.upper(), logging.INFO)
    formatter = _make_formatter(serve.log_format)

    # Configure the nexus.serve logger.
    _apply_formatter(logger, formatter, level)

    # Configure the Rust-side logger. pyo3-log maps Rust module paths to Python
    # logger names (e.g. _nexus_rs::api_client → _nexus_rs.api_client). The crate's
    # [lib] name is "_nexus_rs", so that is the root logger for all Rust messages.
    _apply_formatter(logging.getLogger("_nexus_rs"), formatter, level)

    # Configure Uvicorn loggers so their output matches the chosen format.
    for name in _UVICORN_LOGGERS:
        _apply_formatter(logging.getLogger(name), formatter, level)

    # Tell pyo3-log to re-read the (now updated) Python log levels so Rust-side
    # messages that were previously filtered out start flowing through.
    try:
        from nexus._nexus_rs import reset_rust_log_filter

        reset_rust_log_filter()
    except ImportError:
        pass
