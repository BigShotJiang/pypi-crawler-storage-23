"""FastAPI application and router factories for nexus.serve."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from contextlib import asynccontextmanager
import inspect
import logging
import time
from typing import Annotated, Any

from fastapi import (
    APIRouter,
    Depends,
    FastAPI,
    Header,
    HTTPException,
    Path,
    Query,
    Request,
)
from fastapi.responses import JSONResponse, PlainTextResponse, Response

import nexus as nx
from nexus.serve import import_calculation_packages
from nexus.serve.auth import (
    AuthContext,
    BasicAuthExchanger,
    JWKSTokenVerifier,
    TokenCache,
    make_auth_dependency,
    resolve_token_endpoint_url,
)
from nexus.serve.config import AuthSettings, NexusConfig, ServeSettings
from nexus.serve.logger import configure_logger, logger
from nexus.serve.metrics import (
    calculations_loaded,
    http_request_duration_seconds,
    http_requests_total,
    metrics_endpoint,
    routing_decisions_total,
    upstream_request_duration_seconds,
    upstream_request_errors_total,
    upstream_requests_total,
)
from nexus.serve.models import (
    CalculationListResponse,
    CalculationParams,
    ErrorResponse,
    HealthResponse,
)
from nexus.serve.registry import (
    CALCULATION_NAME_PATTERN,
    CalculationRegistry,
    _default_registry,
)

# Type for fallback handler: (calculation_name, params, headers, auth) -> tuple | Response
FallbackHandler = Callable[
    [str, dict[str, Any], dict[str, str], AuthContext | None],
    Any,  # sync or async → tuple[int, str, str|None] OR Response
]


class _MetricsMiddleware:
    """Pure ASGI middleware for request metrics. Avoids BaseHTTPMiddleware which
    buffers the entire response body in memory and spawns an extra task per request."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        start = time.perf_counter()
        status_code = 200

        async def send_wrapper(message):
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        except Exception:
            status_code = 500
            raise
        finally:
            duration = time.perf_counter() - start
            # Use the route template (e.g. "/calculate/{calculation_name}") instead of
            # the resolved path to avoid unbounded Prometheus label cardinality.
            route = scope.get("route")
            endpoint = route.path if route and hasattr(route, "path") else "unmatched"
            method = scope.get("method", "GET")
            http_requests_total.labels(
                method=method,
                endpoint=endpoint,
                status=status_code,
            ).inc()
            http_request_duration_seconds.labels(
                method=method,
                endpoint=endpoint,
            ).observe(duration)


async def forward_to_engine(
    calculation_json: str,
    calculation_name: str,
    params: dict[str, Any],
    output_format: str | None = None,
    output: str | None = None,
    api_token: str | None = None,
) -> tuple[int, Any, str | None]:
    """Call nx.execute_nodes() via asyncio.to_thread(), using Rust-side default config.

    Returns (status_code, body, content_type). Body is the raw result from the engine
    (str for CSV, dict/list for JSON).
    """
    start_time = time.perf_counter()

    try:
        logger.info(
            "Forwarding to engine",
            extra={"calculation_name": calculation_name},
        )

        result = await asyncio.to_thread(
            nx.execute_nodes,
            calculation_json,
            calculation_name,
            params=params,
            config=None,
            output_format=output_format,
            output=output,
            api_token=api_token,
        )

        duration = time.perf_counter() - start_time
        upstream_requests_total.labels(upstream_api="engine", status=200).inc()
        upstream_request_duration_seconds.labels(upstream_api="engine").observe(duration)

        content_type = "text/csv" if output_format == "csv" else "application/json"
        return 200, result, content_type

    except Exception as e:
        duration = time.perf_counter() - start_time
        logger.error(
            "Engine request failed",
            extra={
                "calculation_name": calculation_name,
                "error": str(e),
                "duration_seconds": duration,
            },
            exc_info=True,
        )
        upstream_request_errors_total.labels(
            upstream_api="engine", error_type=type(e).__name__
        ).inc()
        raise


def create_router(
    registry: CalculationRegistry | None = None,
    serve: ServeSettings | None = None,
    fallback: FallbackHandler | None = None,
    version: str | None = None,
    auth_config: AuthSettings | None = None,
    verifier: JWKSTokenVerifier | None = None,
    exchanger: BasicAuthExchanger | None = None,
) -> APIRouter:
    """Create an APIRouter with /calculate/{calculation_name}, /health, /calculations, /metrics."""
    reg = registry if registry is not None else _default_registry
    if fallback is None:
        fallback = reg.get_fallback()
    srv = serve if serve is not None else ServeSettings()
    auth_fn = make_auth_dependency(auth_config, verifier, exchanger)
    router = APIRouter()

    @router.post("/calculate/{calculation_name}", response_model=None)
    async def calculate(
        calculation_name: Annotated[str, Path(pattern=CALCULATION_NAME_PATTERN.pattern)],
        request: Request,
        auth: AuthContext | None = Depends(auth_fn),
        body: CalculationParams | None = None,
        accept: str | None = Header(None),
        apply_format: bool = Query(False),
        skip_write: bool = Query(True),
    ) -> Response:
        params = body.model_dump() if body else {}

        # If writing is enabled, force formatting on (consistent with nexus_router)
        writer_format = apply_format
        if not skip_write:
            writer_format = True

        logger.info(
            "Calculation request",
            extra={
                "calculation_name": calculation_name,
                "params": params,
                "apply_format": writer_format,
                "skip_write": skip_write,
            },
        )

        has_calculation = reg.has_calculation(calculation_name)

        routing_decisions_total.labels(
            destination="engine" if has_calculation else "fallback",
            calculation_found=str(has_calculation),
        ).inc()

        if has_calculation:
            try:
                result = reg.build_calculation_json(
                    calculation_name,
                    apply_format=writer_format,
                    **params,
                )
                if result is None:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Calculation builder for '{calculation_name}' returned None",
                    )
                calculation_json, merged_params = result
            except HTTPException:
                raise
            except Exception as e:
                logger.error(
                    "Failed to build calculation",
                    extra={"calculation_name": calculation_name, "error": str(e)},
                    exc_info=True,
                )
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to build calculation '{calculation_name}': {e!s}",
                ) from e

            # Determine output format from Accept header
            output_format = None
            if accept and "text/csv" in accept:
                output_format = "csv"

            # Determine output writer
            writer_name = reg.get_writer_name(calculation_name)
            output_writer = None if skip_write else writer_name

            # Extract token for passthrough to upstream engine
            passthrough_token = None
            if auth_config and auth_config.token_passthrough and auth is not None:
                exchanged = getattr(request.state, "exchanged_token", None)
                if exchanged is not None:
                    passthrough_token = f"Bearer {exchanged}"
                else:
                    raw_header = request.headers.get("authorization", "")
                    if raw_header[:7].lower() == "bearer ":
                        passthrough_token = raw_header

            try:
                status_code, response_body, content_type = await forward_to_engine(
                    calculation_json=calculation_json,
                    calculation_name=calculation_name,
                    params=merged_params,
                    output_format=output_format,
                    output=output_writer,
                    api_token=passthrough_token,
                )
            except Exception as e:
                raise HTTPException(
                    status_code=502,
                    detail=f"Engine error: {e!s}",
                ) from e

            if content_type and "text/csv" in content_type:
                return PlainTextResponse(
                    content=response_body,
                    status_code=status_code,
                    media_type="text/csv",
                )
            else:
                return JSONResponse(
                    content=response_body,
                    status_code=status_code,
                )

        # No calculation found
        if fallback is not None:
            headers = dict(request.headers)

            if inspect.iscoroutinefunction(fallback):
                fb_result = await fallback(calculation_name, params, headers, auth)
            else:
                fb_result = await asyncio.to_thread(
                    fallback, calculation_name, params, headers, auth
                )

            # Support returning a Response directly
            if isinstance(fb_result, Response):
                return fb_result

            status, body_str, ct = fb_result
            return Response(content=body_str, status_code=status, media_type=ct)

        # No fallback — 404
        available = sorted(reg.list_calculations())
        raise HTTPException(
            status_code=404,
            detail=(
                f"Calculation '{calculation_name}' not found. Available calculations: {available}"
            ),
        )

    @router.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(
            status="healthy",
            version=version or "unknown",
            calculations_loaded=len(reg.list_calculations()),
        )

    @router.get("/calculations", response_model=CalculationListResponse)
    async def list_calculations(
        auth: AuthContext | None = Depends(auth_fn),
    ) -> CalculationListResponse:
        calculations = sorted(reg.list_calculations())
        return CalculationListResponse(calculations=calculations, count=len(calculations))

    @router.get("/metrics")
    async def metrics():
        if not srv.metrics_enabled:
            raise HTTPException(status_code=404, detail="Metrics not enabled")
        result = metrics_endpoint()
        if result is None:
            raise HTTPException(status_code=404, detail="prometheus_client not installed")
        return result

    return router


def _setup_auth(
    config: NexusConfig,
) -> tuple[AuthSettings | None, JWKSTokenVerifier | None, BasicAuthExchanger | None]:
    """Resolve auth config and create verifier + optional exchanger.

    Returns (None, None, None) when auth is disabled.
    """
    auth_config = config.auth
    if auth_config is None:
        return None, None, None

    # Log warning for insecure JWKS URI
    if auth_config.allow_insecure_jwks and not auth_config.jwks_uri.startswith("https://"):
        logger.warning(
            "INSECURE: jwks_uri uses plain HTTP (%s). This is NOT recommended for production.",
            auth_config.jwks_uri,
        )

    verifier = JWKSTokenVerifier(auth_config)
    if auth_config.issuer is None:
        logger.warning("Auth enabled but 'issuer' is not set — issuer validation will be skipped")
    if auth_config.audience is None:
        logger.warning(
            "Auth enabled but 'audience' is not set — audience validation will be skipped"
        )

    exchanger = None
    if auth_config.basic_auth_enabled:
        try:
            token_endpoint = resolve_token_endpoint_url(auth_config)
        except RuntimeError as e:
            logger.warning("Basic auth disabled — token endpoint discovery failed: %s", e)
            token_endpoint = None

        if token_endpoint is not None:
            cache = TokenCache()
            exchanger = BasicAuthExchanger(
                token_endpoint,
                verifier,
                cache,
                scopes=auth_config.basic_auth_scopes,
            )
            logger.info("Basic auth enabled", extra={"token_endpoint": token_endpoint})
        else:
            logger.info("Basic auth not available — no token endpoint configured or discoverable")

    return auth_config, verifier, exchanger


def _log_effective_config(cfg: NexusConfig) -> None:
    """Log the resolved configuration at DEBUG level."""
    auth_extra: dict[str, Any] = {"configured": False}
    if cfg.auth is not None:
        auth_extra = {
            "configured": True,
            "jwks_uri": cfg.auth.jwks_uri,
            "issuer": cfg.auth.issuer,
            "audience": cfg.auth.audience,
            "algorithms": cfg.auth.algorithms,
            "token_passthrough": cfg.auth.token_passthrough,
            "basic_auth_enabled": cfg.auth.basic_auth_enabled,
        }

    try:
        engine_repr = repr(nx.NexusConfig())
    except Exception:
        engine_repr = "(unable to resolve)"

    logger.debug(
        "Effective configuration",
        extra={
            "project": cfg.project.model_dump(),
            "calculations": cfg.calculations.model_dump(),
            "serve": cfg.serve.model_dump(),
            "auth": auth_extra,
            "engine": engine_repr,
        },
    )


def create_app(
    config: NexusConfig | None = None,
    registry: CalculationRegistry | None = None,
    fallback: FallbackHandler | None = None,
    validate: bool | None = None,
) -> FastAPI:
    """Create a fully configured FastAPI application."""
    cfg = config if config is not None else NexusConfig()

    # Explicit `validate` parameter overrides config; config is the default.
    should_validate = validate if validate is not None else cfg.serve.validate_on_startup

    reg = registry if registry is not None else _default_registry
    auth_cfg, auth_verifier, auth_exchanger = _setup_auth(cfg)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Configure logging before calculation imports so import-time warnings are captured
        configure_logger(cfg.serve)

        if logger.isEnabledFor(logging.DEBUG):
            _log_effective_config(cfg)

        # Import calculation packages — fail fast on any error
        for package in cfg.calculations.packages:
            try:
                import_calculation_packages([package])
                logger.info(
                    "Loaded calculation package",
                    extra={
                        "package": package,
                        "calculation_count": len(reg.list_calculations()),
                    },
                )
            except Exception as e:
                logger.error(
                    "Failed to import calculation package — server refusing to start",
                    extra={"package": package, "error": str(e)},
                    exc_info=True,
                )
                raise

        # Validate all registered calculations build with their default params
        if should_validate:
            results = reg.validate_all()
            for name, error in results.items():
                if error is None:
                    logger.info("Validated calculation", extra={"calculation_name": name})
                else:
                    logger.error(
                        "Calculation failed validation — server refusing to start",
                        extra={"calculation_name": name, "error": str(error)},
                        exc_info=True,
                    )
                    raise error

        calculations_loaded.set(len(reg.list_calculations()))

        # Prefetch JWKS keys — fail fast if the endpoint is unreachable
        if auth_verifier is not None:
            assert auth_cfg is not None  # always set when verifier is set
            try:
                await asyncio.to_thread(auth_verifier.prefetch_jwks)
                logger.info("JWKS keys prefetched", extra={"jwks_uri": auth_cfg.jwks_uri})
            except Exception as e:
                logger.error(
                    "Failed to prefetch JWKS keys — server refusing to start",
                    extra={"jwks_uri": auth_cfg.jwks_uri, "error": str(e)},
                    exc_info=True,
                )
                raise

        # Log engine URL from Rust-side config for diagnostics
        try:
            engine_config = nx.NexusConfig()
            engine_url = engine_config.url
        except Exception:
            engine_url = "(unable to resolve)"

        logger.info(
            "Starting nexus.serve",
            extra={
                "project": cfg.project.name,
                "version": cfg.project.version,
                "calculations_loaded": len(reg.list_calculations()),
                "engine_url": engine_url,
            },
        )

        yield

        logger.info("Shutting down nexus.serve")

    app = FastAPI(
        title=cfg.project.name,
        version=cfg.project.version,
        lifespan=lifespan,
    )

    # CORS middleware
    if cfg.serve.cors_origins is not None:
        from starlette.middleware.cors import CORSMiddleware

        app.add_middleware(
            CORSMiddleware,  # type: ignore[arg-type]
            allow_origins=cfg.serve.cors_origins,
            allow_credentials=cfg.serve.cors_allow_credentials,
            allow_methods=cfg.serve.cors_allow_methods,
            allow_headers=cfg.serve.cors_allow_headers,
        )

    # Metrics middleware
    if cfg.serve.metrics_enabled:
        app.add_middleware(_MetricsMiddleware)  # type: ignore[arg-type]

    # Include the main router
    router = create_router(
        registry=reg,
        serve=cfg.serve,
        fallback=fallback,
        version=cfg.project.version,
        auth_config=auth_cfg,
        verifier=auth_verifier,
        exchanger=auth_exchanger,
    )
    app.include_router(router)

    # Exception handlers
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.warning(
            "HTTP exception",
            extra={
                "path": request.url.path,
                "status_code": exc.status_code,
                "detail": exc.detail,
            },
        )
        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse(error=exc.detail, details=None).model_dump(),
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(
            "Unhandled exception",
            extra={"path": request.url.path, "error": str(exc)},
            exc_info=True,
        )
        return JSONResponse(
            status_code=500,
            content=ErrorResponse(
                error="Internal server error",
                details={"message": str(exc)},
            ).model_dump(),
        )

    return app
