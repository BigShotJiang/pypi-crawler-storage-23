"""Unified configuration: TOML file + env vars + programmatic overrides.

Single ``NexusConfig`` class whose nested members mirror the TOML sections::

    [project]       → config.project   (ProjectSettings)
    [calculations]  → config.calculations (CalculationSettings)
    [serve]         → config.serve     (ServeSettings)
    [auth]          → config.auth      (AuthSettings | None)

Priority chain (highest → lowest):
    init kwargs  >  env vars (NEXUS_SERVE__PORT)  >  .env  >  nexus.toml  >  defaults
"""

import logging
from pathlib import Path
import tomllib
from typing import Any, Literal

from pydantic import BaseModel, model_validator
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

logger = logging.getLogger(__name__)

_ALLOWED_ALGORITHMS = frozenset(
    {
        "RS256",
        "RS384",
        "RS512",
        "ES256",
        "ES384",
        "ES512",
        "PS256",
        "PS384",
        "PS512",
    }
)


class ProjectSettings(BaseModel):
    """``[project]`` section — project metadata."""

    name: str = "nexus-project"
    version: str = "0.0.0"


class CalculationSettings(BaseModel):
    """``[calculations]`` section — calculation package declarations."""

    packages: list[str] = ["calculations"]


class ServeSettings(BaseModel):
    """``[serve]`` section — HTTP server and deployment settings."""

    host: str = "0.0.0.0"
    port: int = 8000
    validate_on_startup: bool = True
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_format: Literal["json", "text"] = "json"
    metrics_enabled: bool = True
    cors_origins: list[str] | None = None
    cors_allow_credentials: bool = False
    cors_allow_methods: list[str] = ["GET", "POST"]
    cors_allow_headers: list[str] = ["Authorization", "Content-Type"]
    graceful_shutdown_timeout: int = 30


class AuthSettings(BaseModel):
    """``[auth]`` section — JWT authentication configuration."""

    jwks_uri: str
    issuer: str | None = None
    audience: str | None = None
    algorithms: list[str] = ["RS256"]
    required_claims: dict[str, str] = {}
    leeway_seconds: int = 0
    token_passthrough: bool = False
    token_endpoint: str | None = None
    basic_auth_enabled: bool = True
    basic_auth_scopes: list[str] | None = None
    max_token_length: int = 16384
    allow_insecure_jwks: bool = False

    @model_validator(mode="after")
    def _validate_algorithms(self):
        bad = set(self.algorithms) - _ALLOWED_ALGORITHMS
        if bad:
            raise ValueError(
                f"Unsupported algorithm(s): {sorted(bad)}. Allowed: {sorted(_ALLOWED_ALGORITHMS)}"
            )
        return self

    @model_validator(mode="after")
    def _validate_jwks_uri_https(self):
        if not self.jwks_uri.startswith("https://") and not self.allow_insecure_jwks:
            raise ValueError(
                f"jwks_uri must use HTTPS (got {self.jwks_uri!r}). "
                "Set allow_insecure_jwks=true or NEXUS_AUTH__ALLOW_INSECURE_JWKS=true to override."
            )
        return self


class _TomlSource(PydanticBaseSettingsSource):
    """Custom pydantic-settings source that reads ``nexus.toml``."""

    def __init__(
        self, settings_cls: type[BaseSettings], toml_path: Path = Path("nexus.toml")
    ) -> None:
        super().__init__(settings_cls)
        self._data: dict[str, Any] = {}
        try:
            with open(toml_path, "rb") as f:
                raw = tomllib.load(f)
            for key in ("project", "calculations", "serve", "auth"):
                if key in raw:
                    self._data[key] = raw[key]
        except FileNotFoundError:
            pass  # No TOML file → all defaults

    def get_field_value(self, field: Any, field_name: str) -> tuple[Any, str, bool]:
        val = self._data.get(field_name)
        return val, field_name, val is not None

    def __call__(self) -> dict[str, Any]:
        return dict(self._data)


class NexusConfig(BaseSettings):
    """Unified configuration for nexus.serve.

    Priority chain (highest → lowest)::

        init kwargs  >  env vars  >  .env file  >  nexus.toml  >  defaults

    Env var examples::

        NEXUS_SERVE__PORT=9000
        NEXUS_AUTH__JWKS_URI=https://auth.synlynx.com/realms/nexus-prod/protocol/openid-connect/certs
        NEXUS_PROJECT__NAME=my-project
    """

    model_config = SettingsConfigDict(
        env_prefix="NEXUS_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    project: ProjectSettings = ProjectSettings()
    calculations: CalculationSettings = CalculationSettings()
    serve: ServeSettings = ServeSettings()
    auth: AuthSettings | None = None

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            _TomlSource(settings_cls),
            file_secret_settings,
        )

    def __repr__(self) -> str:
        return (
            f"NexusConfig(project={self.project.name!r}, "
            f"serve=ServeSettings(host={self.serve.host!r}, port={self.serve.port}), "
            f"auth_configured={self.auth is not None})"
        )
