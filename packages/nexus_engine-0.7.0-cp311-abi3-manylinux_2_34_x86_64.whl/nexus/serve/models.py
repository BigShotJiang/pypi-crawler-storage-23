"""Pydantic models for HTTP request/response validation."""

from typing import Any

from pydantic import BaseModel, Field


class CalculationParams(BaseModel):
    """Request body for calculation execution.

    Params are calculation-defined and opaque to the framework (e.g. account_id,
    date, filters), so we accept arbitrary fields.  Using a BaseModel rather than
    a plain dict preserves FastAPI's automatic OpenAPI schema and request parsing.
    """

    model_config = {"extra": "allow"}


class ErrorResponse(BaseModel):
    """Structured error response."""

    error: str = Field(..., description="Error message")
    details: dict[str, Any] | None = Field(None, description="Additional error details")


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    version: str
    calculations_loaded: int


class CalculationListResponse(BaseModel):
    """Response for listing available calculations."""

    calculations: list[str] = Field(..., description="Sorted list of calculation names")
    count: int = Field(..., description="Total number of calculations")
