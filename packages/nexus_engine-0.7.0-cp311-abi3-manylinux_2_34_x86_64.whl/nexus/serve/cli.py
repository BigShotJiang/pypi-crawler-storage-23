"""CLI entry point for nexus.serve: nexus serve | nexus init | nexus validate."""

from __future__ import annotations

import argparse
import sys
from typing import Any


def _cmd_serve(args: argparse.Namespace) -> int:
    """Start the development server."""
    try:
        import uvicorn
    except ImportError:
        print(
            "nexus serve requires the [serve] extra.\n"
            "Install with: pip install nexus-engine[serve]",
            file=sys.stderr,
        )
        return 1

    from nexus.serve.config import NexusConfig

    try:
        config = NexusConfig()
    except Exception as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        return 1

    # CLI flags override config (use `is not None` — 0 is a valid port)
    host = args.host if args.host is not None else config.serve.host
    port = args.port if args.port is not None else config.serve.port

    run_kwargs: dict[str, Any] = dict(
        host=host,
        port=port,
        log_level=config.serve.log_level.lower(),
        log_config=None,  # Prevent Uvicorn from overriding our logger config
        timeout_graceful_shutdown=config.serve.graceful_shutdown_timeout,
    )

    if args.reload:
        if args.no_validate:
            print(
                "Warning: --no-validate is ignored in --reload mode",
                file=sys.stderr,
            )
        # Reload requires a string import path so uvicorn can re-import on changes.
        # create_app() with no args reads NexusConfig from nexus.toml and
        # env vars, which is the correct behavior for reload.
        uvicorn.run(
            "nexus.serve.server:create_app",
            factory=True,
            reload=True,
            **run_kwargs,
        )
    else:
        from nexus.serve.server import create_app

        try:
            # --no-validate explicitly overrides config; otherwise let config decide
            validate = False if args.no_validate else None
            app = create_app(config=config, validate=validate)
        except ValueError as e:
            print(f"Configuration error: {e}", file=sys.stderr)
            return 1
        uvicorn.run(app, **run_kwargs)
    return 0


def _cmd_init(args: argparse.Namespace) -> int:
    """Scaffold a new nexus.serve project."""
    from nexus.serve.scaffold import scaffold_project

    created = scaffold_project()

    if created:
        print(f"Created: {', '.join(created)}")
    else:
        print("All files already exist, nothing to create.")

    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    """Import calculation packages and attempt to build all calculations with default params."""
    try:
        from nexus.serve.config import NexusConfig
    except ImportError:
        print(
            "nexus validate requires the [serve] extra.\n"
            "Install with: pip install nexus-engine[serve]",
            file=sys.stderr,
        )
        return 1
    from nexus.serve import import_calculation_packages
    from nexus.serve.registry import _default_registry as reg

    try:
        config = NexusConfig()
    except Exception as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        return 1

    # Import calculation packages (auto-discover submodules)
    for package in config.calculations.packages:
        try:
            import_calculation_packages([package])
            print(f"  Loaded: {package}")
        except Exception as e:
            print(f"  FAILED to import {package}: {e}", file=sys.stderr)
            return 1

    if not reg.list_calculations():
        print("No calculations registered.")
        return 0

    results = reg.validate_all()
    errors = []
    for name, error in results.items():
        if error is None:
            print(f"  OK: {name}")
        else:
            print(f"  FAIL: {name} — {error}", file=sys.stderr)
            errors.append(name)

    if errors:
        print(f"\n{len(errors)} calculation(s) failed validation.", file=sys.stderr)
        return 1

    print(f"\nAll {len(results)} calculation(s) validated successfully.")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(prog="nexus", description="Nexus calculation server")
    sub = parser.add_subparsers(dest="command")

    # nexus serve
    serve_parser = sub.add_parser("serve", help="Start the development server")
    serve_parser.add_argument("--host", type=str, default=None)
    serve_parser.add_argument("--port", type=int, default=None)
    serve_parser.add_argument("--reload", action="store_true", default=False)
    serve_parser.add_argument(
        "--no-validate",
        action="store_true",
        default=False,
        help="Skip calculation validation on startup",
    )

    # nexus init
    sub.add_parser("init", help="Scaffold a new project")

    # nexus validate
    sub.add_parser("validate", help="Validate all calculation builds")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    handlers = {
        "serve": _cmd_serve,
        "init": _cmd_init,
        "validate": _cmd_validate,
    }
    sys.exit(handlers[args.command](args))
