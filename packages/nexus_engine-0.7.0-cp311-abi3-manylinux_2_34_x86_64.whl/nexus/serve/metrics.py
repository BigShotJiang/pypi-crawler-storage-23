"""Prometheus metrics for nexus.serve with no-op fallback."""

try:
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )

    http_requests_total = Counter(
        "nexus_serve_http_requests_total",
        "Total number of HTTP requests",
        ["method", "endpoint", "status"],
    )

    http_request_duration_seconds = Histogram(
        "nexus_serve_http_request_duration_seconds",
        "HTTP request latency in seconds",
        ["method", "endpoint"],
    )

    routing_decisions_total = Counter(
        "nexus_serve_routing_decisions_total",
        "Total number of routing decisions",
        ["destination", "calculation_found"],
    )

    upstream_requests_total = Counter(
        "nexus_serve_upstream_requests_total",
        "Total number of upstream API requests",
        ["upstream_api", "status"],
    )

    upstream_request_duration_seconds = Histogram(
        "nexus_serve_upstream_request_duration_seconds",
        "Upstream API request latency in seconds",
        ["upstream_api"],
    )

    upstream_request_errors_total = Counter(
        "nexus_serve_upstream_request_errors_total",
        "Total number of upstream API request errors",
        ["upstream_api", "error_type"],
    )

    calculations_loaded = Gauge(
        "nexus_serve_calculations_loaded",
        "Number of calculations currently loaded",
    )

    _PROMETHEUS_AVAILABLE = True

except ImportError:

    class _NoOp:
        """No-op metric stand-in when prometheus_client is not installed."""

        def labels(self, **kwargs):
            return self

        def inc(self, amount=1):
            pass

        def observe(self, amount):
            pass

        def set(self, value):
            pass

        def describe(self):
            return []

    http_requests_total = _NoOp()
    http_request_duration_seconds = _NoOp()
    routing_decisions_total = _NoOp()
    upstream_requests_total = _NoOp()
    upstream_request_duration_seconds = _NoOp()
    upstream_request_errors_total = _NoOp()
    calculations_loaded = _NoOp()

    _PROMETHEUS_AVAILABLE = False


def metrics_endpoint():
    """Return Prometheus metrics as a FastAPI Response, or None if unavailable."""
    if not _PROMETHEUS_AVAILABLE:
        return None
    from fastapi import Response

    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
