"""
Nexus Engine Python API

A Python wrapper around the Nexus Engine - a financial data calculation engine.
"""
from ._nexus_rs import (
    # Expressions & conditions
    Expression,
    Condition,
    col,
    left_col,
    right_col,
    lit_value,
    lit_str,
    lit_int,
    lit_float,
    lit_bool,
    lit_date,
    lit_datetime,
    when_condition,
    row_index,
    len,
    sql_column,
    http_column,
    execute_nodes,
    # Builders
    TableBuilder,
    SourceNode,
    BreakdownBuilder,
    UnpivotBuilder,
    PartitionContext,
    PartitionBranchBuilder,
    ForkContext,
    ForkBranchBuilder,
    # When/Then/Otherwise
    WhenBuilder,
    ThenBuilder,
    ChainedWhenBuilder,
    # Data types & enums
    DataType,
    JoinMode,
    # Configuration
    NexusConfig,
    NodeMetadata,
    reset_rust_log_filter,
)

# Convenient aliases
lit = lit_value
when = when_condition

__version__ = "0.7.0"

__all__ = [
    # Expressions & conditions
    "Expression",
    "Condition",
    "col",
    "left_col",
    "right_col",
    "lit",
    "lit_value",
    "lit_str",
    "lit_int",
    "lit_float",
    "lit_bool",
    "lit_date",
    "lit_datetime",
    "when",
    "when_condition",
    "row_index",
    "len",
    "sql_column",
    "http_column",
    "execute_nodes",
    # Builders
    "TableBuilder",
    "SourceNode",
    "BreakdownBuilder",
    "UnpivotBuilder",
    "PartitionContext",
    "PartitionBranchBuilder",
    "ForkContext",
    "ForkBranchBuilder",
    # When/Then/Otherwise
    "WhenBuilder",
    "ThenBuilder",
    "ChainedWhenBuilder",
    # Data types & enums
    "DataType",
    "JoinMode",
    # Configuration
    "NexusConfig",
    "NodeMetadata",
    "reset_rust_log_filter",
]
