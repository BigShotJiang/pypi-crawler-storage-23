"""
Mem0 Matrix MCP Server Entry Point
"""

from mem0_matrix_mcp.server import main

if __name__ == "__main__":
    main()
