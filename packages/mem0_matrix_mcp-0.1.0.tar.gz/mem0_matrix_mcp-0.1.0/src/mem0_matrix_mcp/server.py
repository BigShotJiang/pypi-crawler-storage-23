"""
Mem0 Matrix MCP Server
======================
支持MCP协议和HTTP API的Mem0记忆服务

功能：
- MCP协议支持（用于集成到Claude Desktop、Cursor等）
- HTTP REST API支持（用于云端调用）
- 多用户记忆管理
"""

import os
import json
import asyncio
from typing import Any, Dict, List, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, Header, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Mem0
try:
    from mem0 import Memory
    MEM0_AVAILABLE = True
except ImportError:
    MEM0_AVAILABLE = False
    print("Warning: mem0ai not installed. Install with: pip install mem0ai")


# ==================== 配置 ====================

# 环境变量
MEM0_API_KEY = os.environ.get("MEM0_API_KEY", "")
MCP_API_KEY = os.environ.get("MCP_API_KEY", "default-secret-key")
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8000"))

# 存储路径
DATA_DIR = os.environ.get("DATA_DIR", "./data")
os.makedirs(DATA_DIR, exist_ok=True)

# ==================== Mem0 初始化 ====================

class Mem0Client:
    """Mem0客户端封装"""
    
    def __init__(self, api_key: str):
        if not MEM0_AVAILABLE:
            raise RuntimeError("mem0ai is not installed")
        
        self.api_key = api_key
        self.memory = None
        self._initialize()
    
    def _initialize(self):
        """初始化Mem0"""
        if not self.api_key:
            raise ValueError("MEM0_API_KEY is required")
        
        # 配置 - 使用Qdrant向量存储
        config = {
            "vector_store": {
                "provider": "qdrant",
                "config": {
                    "path": DATA_DIR
                }
            },
            "llm": {
                "provider": "openai",
                "config": {
                    "model": "gpt-4o-mini",
                    "api_key": self.api_key
                }
            },
            "embedder": {
                "provider": "openai",
                "config": {
                    "model": "text-embedding-3-small",
                    "api_key": self.api_key,
                    "embedding_dims": 1536
                }
            }
        }
        
        self.memory = Memory.from_config(config)
        print("Mem0 initialized successfully")
    
    def add(self, content: str, user_id: str = "default", metadata: Dict = None) -> Dict:
        """添加记忆"""
        result = self.memory.add(
            content=content,
            user_id=user_id,
            metadata=metadata or {}
        )
        return result
    
    def search(self, query: str, user_id: str = "default", limit: int = 5) -> List[Dict]:
        """搜索记忆"""
        results = self.memory.search(
            query=query,
            user_id=user_id,
            limit=limit
        )
        return results.get("results", [])
    
    def get_all(self, user_id: str = "default") -> List[Dict]:
        """获取所有记忆"""
        results = self.memory.get_all(user_id=user_id)
        return results.get("results", [])
    
    def update(self, memory_id: str, content: str) -> Dict:
        """更新记忆"""
        result = self.memory.update(memory_id=memory_id, content=content)
        return result
    
    def delete(self, memory_id: str) -> Dict:
        """删除记忆"""
        result = self.memory.delete(memory_id=memory_id)
        return result
    
    def delete_all(self, user_id: str = "default") -> Dict:
        """删除用户所有记忆"""
        result = self.memory.delete_all(user_id=user_id)
        return result


# 全局客户端实例
mem0_client: Optional[Mem0Client] = None


def get_mem0_client() -> Mem0Client:
    """获取Mem0客户端"""
    global mem0_client
    if mem0_client is None:
        if not MEM0_AVAILABLE:
            raise HTTPException(
                status_code=503,
                detail="Mem0 is not installed. Please install mem0ai package."
            )
        if not MEM0_API_KEY:
            raise HTTPException(
                status_code=503,
                detail="MEM0_API_KEY is not configured"
            )
        mem0_client = Mem0Client(MEM0_API_KEY)
    return mem0_client


# ==================== API模型 ====================

class AddMemoryRequest(BaseModel):
    """添加记忆请求"""
    content: str
    user_id: str = "default"
    metadata: Dict = {}


class UpdateMemoryRequest(BaseModel):
    """更新记忆请求"""
    memory_id: str
    content: str


class SearchRequest(BaseModel):
    """搜索请求"""
    query: str
    user_id: str = "default"
    limit: int = 5


# ==================== 认证 ====================

async def verify_api_key(authorization: str = Header(None)):
    """验证API密钥"""
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header is required"
        )
    
    # 支持 Bearer token
    if authorization.startswith("Bearer "):
        token = authorization[7:]
    else:
        token = authorization
    
    if token != MCP_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key"
        )
    
    return True


# ==================== FastAPI应用 ====================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期"""
    # 启动时初始化
    print("Starting Mem0 Matrix MCP Server...")
    try:
        get_mem0_client()
    except Exception as e:
        print(f"Warning: Failed to initialize Mem0: {e}")
    
    yield
    
    # 关闭时清理
    print("Shutting down Mem0 Matrix MCP Server...")


app = FastAPI(
    title="Mem0 Matrix MCP Server",
    description="支持MCP协议和HTTP API的Mem0记忆服务",
    version="0.1.0",
    lifespan=lifespan
)

# CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== API路由 ====================

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "mem0_available": MEM0_AVAILABLE,
        "mem0_initialized": mem0_client is not None
    }


@app.post("/api/memory/add")
async def add_memory(
    request: AddMemoryRequest,
    authorized: bool = Depends(verify_api_key)
):
    """添加记忆"""
    try:
        client = get_mem0_client()
        result = client.add(
            content=request.content,
            user_id=request.user_id,
            metadata=request.metadata
        )
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/memory/search")
async def search_memory(
    query: str,
    user_id: str = "default",
    limit: int = 5,
    authorized: bool = Depends(verify_api_key)
):
    """搜索记忆"""
    try:
        client = get_mem0_client()
        results = client.search(
            query=query,
            user_id=user_id,
            limit=limit
        )
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/memory/all")
async def get_all_memories(
    user_id: str = "default",
    authorized: bool = Depends(verify_api_key)
):
    """获取所有记忆"""
    try:
        client = get_mem0_client()
        results = client.get_all(user_id=user_id)
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/memory/update")
async def update_memory(
    request: UpdateMemoryRequest,
    authorized: bool = Depends(verify_api_key)
):
    """更新记忆"""
    try:
        client = get_mem0_client()
        result = client.update(
            memory_id=request.memory_id,
            content=request.content
        )
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/memory/delete")
async def delete_memory(
    memory_id: str,
    authorized: bool = Depends(verify_api_key)
):
    """删除单条记忆"""
    try:
        client = get_mem0_client()
        result = client.delete(memory_id=memory_id)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/memory/clear")
async def clear_memories(
    user_id: str = "default",
    authorized: bool = Depends(verify_api_key)
):
    """清除用户所有记忆"""
    try:
        client = get_mem0_client()
        result = client.delete_all(user_id=user_id)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== MCP协议支持 ====================

# 注意：这里我们使用HTTP API方式暴露服务
# 如果需要支持MCP协议（用于Claude Desktop等），需要额外配置

@app.get("/mcp/tools")
async def list_mcp_tools(authorized: bool = Depends(verify_api_key)):
    """列出MCP工具（简化版）"""
    return {
        "tools": [
            {
                "name": "add_memory",
                "description": "添加记忆到记忆库",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string", "description": "要记忆的内容"},
                        "user_id": {"type": "string", "description": "用户ID", "default": "default"},
                        "metadata": {"type": "object", "description": "元数据", "default": {}}
                    },
                    "required": ["content"]
                }
            },
            {
                "name": "search_memory",
                "description": "搜索记忆",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "搜索查询"},
                        "user_id": {"type": "string", "description": "用户ID", "default": "default"},
                        "limit": {"type": "integer", "description": "返回数量", "default": 5}
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "get_all_memories",
                "description": "获取用户所有记忆",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "用户ID", "default": "default"}
                    }
                }
            }
        ]
    }


# ==================== 主函数 ====================

def main():
    """主函数"""
    print("=" * 50)
    print("Mem0 Matrix MCP Server")
    print("=" * 50)
    print(f"Host: {HOST}")
    print(f"Port: {PORT}")
    print(f"Data Directory: {DATA_DIR}")
    print(f"MEM0_API_KEY configured: {bool(MEM0_API_KEY)}")
    print(f"MCP_API_KEY configured: {bool(MCP_API_KEY)}")
    print("=" * 50)
    print()
    print("API Endpoints:")
    print(f"  Health: GET  http://{HOST}:{PORT}/health")
    print(f"  Add Memory: POST  http://{HOST}:{PORT}/api/memory/add")
    print(f"  Search: GET  http://{HOST}:{PORT}/api/memory/search")
    print(f"  Get All: GET  http://{HOST}:{PORT}/api/memory/all")
    print(f"  Clear: DELETE  http://{HOST}:{PORT}/api/memory/clear")
    print()
    print("Note: All API endpoints require Authorization header")
    print("Example: curl -H 'Authorization: Bearer YOUR_API_KEY' ...")
    print("=" * 50)
    
    uvicorn.run(
        app,
        host=HOST,
        port=PORT,
        log_level="info"
    )


if __name__ == "__main__":
    main()
