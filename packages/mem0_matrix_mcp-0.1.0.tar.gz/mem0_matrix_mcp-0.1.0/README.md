# mem0-matrix-mcp

Mem0 MCP Server for Matrix Agent - 提供持久化记忆功能的MCP服务

## 功能特性

- **记忆存储**：自动从对话中提取和存储重要信息
- **语义搜索**：支持语义相似度检索
- **多用户支持**：支持多个用户独立记忆
- **REST API**：提供HTTP API接口，方便云端调用
- **MCP协议**：支持MCP协议，可集成到各种AI客户端

## 安装

```bash
pip install mem0-matrix-mcp
```

## 配置环境变量

```bash
# 设置Mem0 API密钥
export MEM0_API_KEY="your-mem0-api-key"

# 可选：设置API访问密钥（用于HTTP API认证）
export MCP_API_KEY="your-api-key-for-http-access"
```

## 使用方法

### 1. MCP协议方式

配置到Claude Desktop或Cursor：

```json
{
  "mcpServers": {
    "mem0-matrix": {
      "command": "uvx",
      "args": ["mem0-matrix-mcp"]
    }
  }
}
```

### 2. HTTP API方式

启动服务后，可以通过HTTP调用：

```bash
# 添加记忆
curl -X POST http://localhost:8000/api/memory/add \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"content": "我喜欢Python编程", "user_id": "user1"}'

# 搜索记忆
curl "http://localhost:8000/api/memory/search?query=编程&user_id=user1" \
  -H "Authorization: Bearer YOUR_API_KEY"

# 获取所有记忆
curl "http://localhost:8000/api/memory/all?user_id=user1" \
  -H "Authorization: Bearer YOUR_API_KEY"
```

## API接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/memory/add | 添加记忆 |
| GET | /api/memory/search | 搜索记忆 |
| GET | /api/memory/all | 获取所有记忆 |
| DELETE | /api/memory/clear | 清除记忆 |
| GET | /health | 健康检查 |

## 开发

### 本地开发

```bash
# 克隆项目
git clone https://github.com/your-username/mem0-matrix-mcp.git
cd mem0-matrix-mcp

# 安装依赖
pip install -e .

# 运行
python -m mem0_matrix_mcp.server
```

### 测试

```bash
pytest tests/
```

## 许可证

MIT License
