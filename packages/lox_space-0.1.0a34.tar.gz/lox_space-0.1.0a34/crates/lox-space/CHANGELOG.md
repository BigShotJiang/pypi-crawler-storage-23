# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.34](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.33...lox-space-v0.1.0-alpha.34) - 2026-03-02

### Added

- *(lox-core)* add time units

### Fixed

- *(lox-orbits)* align J2 APIs

### Other

- *(lox-core/lox-time)* deduplicate time range APIs
- *(lox-space)* used interval time range API

## [0.1.0-alpha.33](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.32...lox-space-v0.1.0-alpha.33) - 2026-03-02

### Other

- updated the following local packages: lox-orbits

## [0.1.0-alpha.32](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.31...lox-space-v0.1.0-alpha.32) - 2026-03-02

### Added

- *(lox-orbits)* add more orbit constructors

## [0.1.0-alpha.31](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.30...lox-space-v0.1.0-alpha.31) - 2026-02-27

### Added

- *(lox-space)* add Python SSO constructor
- *(lox-orbits)* add slew rate constraint
- *(lox-orbits)* add min/max range to ISL
- *(lox-orbits)* improve visibility results API
- *(lox-space)* expose intervals from Python
- *(lox-space)* allow names/ids for origins and frames
- *(lox-space)* add more __repr__s
- *(lox-space)* make Python wrapper unitful

### Fixed

- *(lox-orbits/lox-space)* fix inter-satellite vis API

### Other

- *(lox-space)* more tests
- *(lox-space)* denoise ephem benchmarks
- *(lox-orbits)* update Python docs and type stubs
- *(lox-orbits)* add Python visibility tests
- *(lox-orbits)* improve performance
- fix formatting
- *(lox-orbits)* refactor visibility analysis
- *(lox-orbits)* refactor event detection

## [0.1.0-alpha.30](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.29...lox-space-v0.1.0-alpha.30) - 2026-02-25

### Added

- *(spacelink-validation)* map Lox calulations to Spacelink and cross-validate implementations
- *(lox-comms)* add Python wrapper

### Fixed

- *(lox-space)* add comms type stubs to fix Python docs build
- add spacelink and bump python version to >=3.11
- correct inconsistent trait-contract AntennaGain::beamwidth()
- update dipole-test comment
- explicitly handle case where beamwidth is not defined
- fix various lints
- *(lox-space)* fix core re-exports

### Other

- *(lox-orbits)* fix performance regression
- *(lox-orbits)* address review comments
- *(lox-orbits)* remove frame change and change time parameters
- *(lox-orbits)* re-design propagator API
- more simplifications
- *(lox-orbits)* simplify based on `into_dyn` and co.
- *(lox-comms)* add Python wrapper docs
- *(lox-ephem)* clean-up API and style
- *(lox-ephem)* refactor ephemeris interface

## [0.1.0-alpha.29](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.28...lox-space-v0.1.0-alpha.29) - 2026-02-22

### Added

- *(lox-frames)* add J2000 frame
- add optional serde feature
- *(lox-time)* implement chrono interop
- *(lox-time)* use compensated sum for two-float deltas
- *(lox-orbits)* re-design trajectories

### Fixed

- *(lox-frames/lox-orbits)* fix TEME transformation
- *(lox-orbits)* fix unit mismatches

### Other

- *(lox-frames)* test Earth-based frames
- *(lox-time)* simplify TAI<->UTC conversions
- *(lox-orbits)* deduplicate API
- *(lox-space)* add tests for IAU frames
- get coverage from pytest
- clean up lints and simplify errors
- simplify pytest failure checking
- rewrite from closures to a Callback trait, should_panic for roots tests
- Combine all root errors to common error domain, bubble up errors everywhere.
- failing test cases: expect errors
- *(lox-core)* simplify Series type
- *(lox-space)* fix doctests
- *(lox-frames)* rewrite frame transforms
- *(lox-space)* add Python docs
- *(lox-time)* make LSP trait easier to implement
- *(lox-time)* implement offsets via `OffsetProvider` trait
- *(lox-space)* update MkDocs config
- *(lox-space)* test Python reference docs

## [0.1.0-alpha.28](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.27...lox-space-v0.1.0-alpha.28) - 2025-10-29

### Added

- *(lox-time)* add attosecond-resolution deltas
- *(lox-derive)* implement OffsetProvider derive macro
- add lox-test-utils crate and refine EOP parser interface
- *(lox-earth)* implement new EOP parser and data provider
- *(lox-units)* add Python wrapper

### Fixed

- *(lox-space)* fix uv cache again
- *(lox-space)* fix Python module rebuild

### Other

- move lox-units code to lox-core
- add 3rd-party data licenses
- update SPDX headers and add helper script
- make Lox REUSE-compliant
- get rid of float_eq and lox_math::is_close
- *(lox-units)* make Angle value private
- start reimplementation of frame transformations
- move type aliases to lox-units
- refactor all the things
- *(lox-space/lox-units)* move unit wrappers to lox-space and add feature
- *(lox-time)* fix Python tests

## [0.1.0-alpha.27](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.26...lox-space-v0.1.0-alpha.27) - 2025-09-19

### Other

- disable noisy benchmark

## [0.1.0-alpha.26](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.24...lox-space-v0.1.0-alpha.26) - 2025-07-18

### Other

- updated the following local packages: lox-time, lox-frames, lox-orbits

## [0.1.0-alpha.24](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.23...lox-space-v0.1.0-alpha.24) - 2025-07-18

### Fixed

- fix Python type stubs

### Other

- fix formatting
- add lox-frames crate
- use uv for all the Python things

## [0.1.0-alpha.23](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.22...lox-space-v0.1.0-alpha.23) - 2025-07-01

### Other

- fix clippy lints

## [0.1.0-alpha.22](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.21...lox-space-v0.1.0-alpha.22) - 2025-06-23

### Added

- add Pass struct

## [0.1.0-alpha.21](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.20...lox-space-v0.1.0-alpha.21) - 2025-06-19

### Other

- clean up pytest config
- try Claude-optimised parallel visibility

## [0.1.0-alpha.20](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.19...lox-space-v0.1.0-alpha.20) - 2025-03-04

### Other

- update formatting

## [0.1.0-alpha.19](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.18...lox-space-v0.1.0-alpha.19) - 2025-02-12

### Fixed

- *(lox-orbits)* expose methods for PyElevationMask

## [0.1.0-alpha.18](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.17...lox-space-v0.1.0-alpha.18) - 2025-02-12

### Added

- *(lox-orbits)* check los with other bodies

## [0.1.0-alpha.17](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.16...lox-space-v0.1.0-alpha.17) - 2025-02-11

### Fixed

- make `Time` and `TimeScale` pickable

## [0.1.0-alpha.16](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.15...lox-space-v0.1.0-alpha.16) - 2025-02-10

### Other

- *(lox-orbits)* switch loop order for visibility

## [0.1.0-alpha.15](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.14...lox-space-v0.1.0-alpha.15) - 2025-02-10

### Other

- *(lox-space)* fix type stubs again

## [0.1.0-alpha.14](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.13...lox-space-v0.1.0-alpha.14) - 2025-02-10

### Added

- *(lox-orbits)* implement line-of-sight calculations

### Other

- *(lox-space)* update Python type stubs
- *(lox-orbits)* parallelise visibility

## [0.1.0-alpha.13](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.12...lox-space-v0.1.0-alpha.13) - 2025-01-24

### Added

- implement `DynTimeScale`

### Other

- simplify rotational elements

## [0.1.0-alpha.12](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.11...lox-space-v0.1.0-alpha.12) - 2024-12-19

### Fixed

- fix switched radii

## [0.1.0-alpha.11](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.10...lox-space-v0.1.0-alpha.11) - 2024-12-19

### Fixed

- fix Python types

## [0.1.0-alpha.10](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.9...lox-space-v0.1.0-alpha.10) - 2024-12-19

### Other

- updated the following local packages: lox-bodies, lox-orbits

## [0.1.0-alpha.9](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.8...lox-space-v0.1.0-alpha.9) - 2024-12-18

### Other

- implement dynamic origin and frame types
- bump minimum Python version
- add visibility benchmark and codspeed integration

## [0.1.0-alpha.8](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.6...lox-space-v0.1.0-alpha.8) - 2024-11-15

### Fixed

- add pickle support for `ElevationMask`

## [0.1.0-alpha.6](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.5...lox-space-v0.1.0-alpha.6) - 2024-11-14

### Fixed

- fix Python CI workflows

## [0.1.0-alpha.5](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.4...lox-space-v0.1.0-alpha.5) - 2024-11-14

### Fixed

- fix Python typings

## [0.1.0-alpha.4](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.3...lox-space-v0.1.0-alpha.4) - 2024-11-14

### Other

- updated the following local packages: lox-orbits

## [0.1.0-alpha.3](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.2...lox-space-v0.1.0-alpha.3) - 2024-11-12

### Added

- *(lox-orbits)* implement frame and origin change for Python classes

## [0.1.0-alpha.2](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.1...lox-space-v0.1.0-alpha.2) - 2024-07-19

### Added
- *(lox-space)* Expose `Observables` constructor ([#152](https://github.com/lox-space/lox/pull/152))

## [0.1.0-alpha.1](https://github.com/lox-space/lox/compare/lox-space-v0.1.0-alpha.0...lox-space-v0.1.0-alpha.1) - 2024-07-19

### Other
- Use GitHub app for release workflow ([#150](https://github.com/lox-space/lox/pull/150))

## [0.1.0-alpha.0](https://github.com/lox-space/lox/releases/tag/lox-space-v0.1.0-alpha.0) - 2024-07-19

### Other
- Rename lox-utils to lox-math because the former is taken ([#146](https://github.com/lox-space/lox/pull/146))
- Add crate descriptions ([#145](https://github.com/lox-space/lox/pull/145))
- Align versions ([#143](https://github.com/lox-space/lox/pull/143))
- Release preparation ([#140](https://github.com/lox-space/lox/pull/140))
- Implement trajectory to Numpy array method ([#134](https://github.com/lox-space/lox/pull/134))
- Implement `from_numpy` constructor for `PyTrajectory` ([#133](https://github.com/lox-space/lox/pull/133))
- Fix tests
- Implement state to ground
- Implement PyObservables
- Wrap `Series`
- Simplify elevation analysis
- Expose elevation
- Fix Python ground propagator
- Implement visibility window detection
- Add `from_seconds` constructor to Python
- Expose event/window detection func from Python
- Python API fixes
- Implement SGP4 propagator
- Implement ground propagator
- Return Numpy arrays
- Use `State` as callback parameter
- Impl event and window detection from Python
- Expose `Frame` class from Python
- Fix benchmarks
- Remove `lox-coords` crate
- Prototype trajectory
- Prototype orbit state representations
- Fix benchmark deps ([#108](https://github.com/lox-space/lox/pull/108))
- Move Python wrappers to `lox-bodies` ([#107](https://github.com/lox-space/lox/pull/107))
- Fix typings ([#106](https://github.com/lox-space/lox/pull/106))
- Implement new Python API for `lox-time` and add `TryToScale` trait ([#103](https://github.com/lox-space/lox/pull/103))
- Refactor `lox-time` Rust and Python API - Part I ([#94](https://github.com/lox-space/lox/pull/94))
- Align casing of types with Rust API guidelines ([#86](https://github.com/lox-space/lox/pull/86))
- Hoist shared constants and type aliases ([#84](https://github.com/lox-space/lox/pull/84))
- Implement TAI <-> UTC conversion ([#81](https://github.com/lox-space/lox/pull/81))
- Replace lox_time::continuous with smaller top-level modules ([#72](https://github.com/lox-space/lox/pull/72))
- Subsecond-based time implementation ([#67](https://github.com/lox-space/lox/pull/67))
- Core No More ([#68](https://github.com/lox-space/lox/pull/68))
- Factor lox-time into new crate ([#65](https://github.com/lox-space/lox/pull/65))
- Streamline public API for the `time` module ([#62](https://github.com/lox-space/lox/pull/62))
- Refactor Time ([#56](https://github.com/lox-space/lox/pull/56))
- Add pickle support for bodies ([#51](https://github.com/lox-space/lox/pull/51))
- Refine time representations ([#44](https://github.com/lox-space/lox/pull/44))
- Refactor two-body state vector representation and expose from Python ([#46](https://github.com/lox-space/lox/pull/46))
- Calculate celestial to intermediate-frame-of-date matrix ([#38](https://github.com/lox-space/lox/pull/38))
- Implement IAU1980 nutation ([#23](https://github.com/lox-space/lox/pull/23))
- Add NaifId newtype and mapping to bodies ([#18](https://github.com/lox-space/lox/pull/18))
- Define bodies manually ([#17](https://github.com/lox-space/lox/pull/17))
- Update copyright
- Use flat cargo workspace
