# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.15](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.14...lox-bodies-v0.1.0-alpha.15) - 2026-03-02

### Other

- updated the following local packages: lox-core, lox-test-utils, lox-math, lox-units

## [0.1.0-alpha.14](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.13...lox-bodies-v0.1.0-alpha.14) - 2026-02-27

### Other

- updated the following local packages: lox-core, lox-math, lox-units

## [0.1.0-alpha.13](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.12...lox-bodies-v0.1.0-alpha.13) - 2026-02-25

### Added

- add conversions to `dyn` types

### Other

- add into_dyn tests

## [0.1.0-alpha.12](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.11...lox-bodies-v0.1.0-alpha.12) - 2026-02-22

### Added

- add optional serde feature
- *(lox-orbits)* implement basic J2 numerical propagator

### Other

- *(lox-orbits)* deduplicate API
- *(lox-bodies)* improve test coverage
- *(lox-bodies)* improve test coverage
- *(lox-bodies)* add more tests for generated code
- generated file with unit tests
- *(lox-frames)* rewrite frame transforms

## [0.1.0-alpha.11](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.10...lox-bodies-v0.1.0-alpha.11) - 2025-10-29

### Added

- *(lox-units)* extend and document `lox_units::units` module

### Other

- move lox-units code to lox-core
- *(lox-units)* restructure constants to match std
- update SPDX headers and add helper script
- make Lox REUSE-compliant
- get rid of float_eq and lox_math::is_close
- *(lox-units)* make Angle value private
- *(lox-bodies/lox-earth)* anglify lox-bodies and lox-earth
- move type aliases to lox-units
- refactor all the things
- *(lox-units/lox-math)* move constants to lox-units

## [0.1.0-alpha.10](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.9...lox-bodies-v0.1.0-alpha.10) - 2025-09-19

### Other

- update deps

## [0.1.0-alpha.9](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.8...lox-bodies-v0.1.0-alpha.9) - 2025-07-01

### Other

- updated the following local packages: lox-math

## [0.1.0-alpha.8](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.7...lox-bodies-v0.1.0-alpha.8) - 2025-06-19

### Other

- update Cargo.toml dependencies

## [0.1.0-alpha.7](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.6...lox-bodies-v0.1.0-alpha.7) - 2025-03-04

### Other

- updated the following local packages: lox-math

## [0.1.0-alpha.6](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.5...lox-bodies-v0.1.0-alpha.6) - 2025-02-10

### Other

- update Cargo.toml dependencies

## [0.1.0-alpha.5](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.4...lox-bodies-v0.1.0-alpha.5) - 2025-01-24

### Other

- simplify rotational elements

## [0.1.0-alpha.4](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.3...lox-bodies-v0.1.0-alpha.4) - 2024-12-19

### Fixed

- fix switched radii

## [0.1.0-alpha.3](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.2...lox-bodies-v0.1.0-alpha.3) - 2024-12-19

### Other

- prefer `Result` over `Option` for `Origin` props

## [0.1.0-alpha.2](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.1...lox-bodies-v0.1.0-alpha.2) - 2024-12-18

### Other

- implement dynamic origin and frame types

## [0.1.0-alpha.1](https://github.com/lox-space/lox/compare/lox-bodies-v0.1.0-alpha.0...lox-bodies-v0.1.0-alpha.1) - 2024-11-12

### Other

- update Cargo.toml dependencies

## [0.1.0-alpha.0](https://github.com/lox-space/lox/releases/tag/lox-bodies-v0.1.0-alpha.0) - 2024-07-19

### Other
- Rename lox-utils to lox-math because the former is taken ([#146](https://github.com/lox-space/lox/pull/146))
- Add crate descriptions ([#145](https://github.com/lox-space/lox/pull/145))
- Align versions ([#143](https://github.com/lox-space/lox/pull/143))
- Fix bodyfixed frames for satellites
- Fix Python ground propagator
- Implement visibility window detection
- Implement ground propagator
- Impl event and window detection from Python
- Expose `Frame` class from Python
- Fix transformations
- Prototype trajectory
- Implement ICRF <-> body-fixed transformations
- Prototype orbit state representations
- Move Python wrappers to `lox-bodies` ([#107](https://github.com/lox-space/lox/pull/107))
- Hoist shared constants and type aliases ([#84](https://github.com/lox-space/lox/pull/84))
- Implement TAI <-> UTC conversion ([#81](https://github.com/lox-space/lox/pull/81))
- Core No More ([#68](https://github.com/lox-space/lox/pull/68))
