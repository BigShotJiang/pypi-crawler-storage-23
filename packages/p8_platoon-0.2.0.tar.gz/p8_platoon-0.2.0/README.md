# p8platoon

Agent workforce toolkit for [Percolate](https://github.com/Percolate-AI). Provides a provider pattern for producing percolate-compatible entities (Resources, Moments) from various data sources.

Ships with a **feed aggregator** as the first built-in provider — 13 sources, profile-based scoring, image enrichment, Tavily web search, and HTML output.

## Install

```bash
pip install p8platoon
```

Or for development:

```bash
git clone <repo-url> && cd p8-platoon
pip install -e ".[search]"
```

## Quick Start

### CLI

```bash
# Run all profiles, output HTML
platoon feed

# Single profile, dry-run (print scores to stdout)
platoon feed --profile default --dry-run

# JSON output
platoon feed --profile default --output json

# With web search enrichment (searches per-category, excludes feed domains)
platoon feed --tavily-key sk-... --open

# Export to percolate-compatible YAML + HTML
platoon export --profile default --output-dir ./export/

# Export with user ownership (deterministic resource IDs)
platoon export --profile default --user-id "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

# Standalone Tavily web search
platoon search "latest AI breakthroughs" --max-results 10 --time-range week
```

Exported YAML files can be ingested via:

```bash
p8 upsert resources export/resources-default.yaml
p8 upsert moments export/moments-default.yaml
```

### Library

Use platoon as a Python library — this is the integration path for percolate.
Pass a p8k8 `UserMetadata` object (or any dict with `interests`/`categories`)
and get back percolate-compatible Resources and Moments.

```python
import platoon
from uuid import UUID

# UserMetadata from percolate (or any dict/pydantic model)
user_metadata = UserMetadata(
    interests=["AI machine learning", "physics space", "food restaurants"],
    categories={
        "AI": {"keywords": ["AI", "LLM", "neural", "agent"], "weight": 1.5, "color": "#3b82f6"},
        "Physics": {"keywords": ["physics", "quantum", "space"], "weight": 1.3, "color": "#8b5cf6"},
    },
)

user_id = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")

# Run — sources come from built-in defaults, user data from metadata
result = platoon.run(user_metadata, user_id)

# Percolate-compatible dicts ready for upsert
resource_dicts = [r.to_upsert_dict() for r in result.resources]
moment_dicts = [m.to_upsert_dict() for m in result.moments]
```

Override global sources via config dict:

```python
result = platoon.run(
    user_metadata,
    user_id,
    config={
        "sources": {
            "hacker_news": {"enabled": True, "min_score": 200},
            "reddit": {"enabled": True, "subreddits": ["MachineLearning"]},
        },
    },
)
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `P8_PLATOON_KEYS` | JSON dict of API keys: `{"tavily": "tvly-..."}` |
| `P8_TAVILY_KEY` | Single Tavily API key (alternative to above) |
| `TAVILY_API_KEY` | Legacy Tavily key (backward compat) |

Keys are resolved in priority order: `P8_PLATOON_KEYS` > `P8_TAVILY_KEY` > `TAVILY_API_KEY`.

## Configuration

Copy and edit the example config:

```bash
cp config.example.yaml config.yaml
```

### Profiles

Profiles define interests, category weights, and source configurations. Shared categories (Trivia, General) are injected into every profile.

Built-in profiles:
- **default** — AI, Physics, Business, Food
- **eunseo** — Cats, Crafts, Korean, Food, Beauty, Chemistry

```yaml
profiles:
  default:
    name: "Default"
    interests:
      - "AI machine learning breakthroughs"
      - "physics space quantum discoveries"
      - "business startups economy"
      - "food restaurants cooking recipes"
    categories:
      AI:
        keywords: [AI, LLM, machine learning, neural, ChatGPT, agent, transformer]
        weight: 1.5
        color: "#3b82f6"
      Physics:
        keywords: [physics, quantum, particle, astrophysics, cosmology]
        weight: 1.3
    sources:
      google_news:
        enabled: true
        topics: [science, technology]
        queries: ["AI artificial intelligence"]
      reddit:
        enabled: true
        subreddits: [todayilearned, space, food]
        min_score: 1000
      hacker_news:
        enabled: true
        min_score: 200
```

### Sources (13)

| Source | Type | Config Keys |
|--------|------|-------------|
| `google_news` | RSS | `topics`, `queries`, `max_items_per_query` |
| `reddit` | JSON API | `subreddits`, `min_score`, `max_items` |
| `hacker_news` | Firebase API | `fetch_top_n`, `min_score`, `max_items` |
| `rss_feeds` | RSS/Atom | `feeds` (list of `{url, label}`), `max_items_per_feed` |
| `flipboard` | RSS | `topics`, `max_items_per_topic` |
| `trivia` | REST API | `max_items`, `on_this_day`, `random_facts` |
| `arxiv` | RSS | `feeds`, `max_items_per_feed` |
| `github_trending` | Scrape | `language`, `since` |
| `lobsters` | JSON API | `tags_filter` |
| `papers_with_code` | REST API | `max_items` |
| `semantic_scholar` | Graph API | `queries` |
| `openalex` | REST API | `queries`, `email` |
| `hn_algolia` | Search API | `queries`, `sort` |

### Web Search Enrichment

When a Tavily API key is provided, the feed pipeline runs per-category web searches that **exclude** all 35+ domains already covered by feed sources. This surfaces net-new content from sites not in your feeds.

```bash
# Via CLI flag
platoon feed --tavily-key tvly-...

# Via environment variable
export TAVILY_API_KEY=tvly-...
platoon feed
```

## Feed Pipeline

```
Config + Profile
  -> Phase 1: Fetch from 13 source types
  -> Phase 2: Tavily web search enrichment (excludes feed domains)
  -> Phase 3: Score + dedup (keyword matching, interest boost, engagement bonus)
  -> Phase 4: Backfill sparse categories via Google News fallback
  -> Image enrichment (source → og:image scrape → Unsplash fallback)
  -> Render HTML / JSON / export to percolate
```

## Provider Pattern

Build custom providers that emit percolate entities. `FeedProvider` is the built-in provider (see Library usage above); extend `BaseProvider` for other data sources:

```python
from platoon.providers import BaseProvider, ProviderResult
from platoon.models import P8Resource, P8Moment

class MyProvider(BaseProvider):
    name = "my-provider"

    def run(self, config: dict) -> ProviderResult:
        resources = [
            P8Resource(
                name="Example Resource",
                uri="https://example.com/article",
                content="Article content...",
                category="news",
                tags=["my-source", "tech"],
                metadata={"score": 0.85},
            )
        ]
        moment = P8Moment(
            name="my-digest-2026-02-22",
            moment_type="digest",
            summary="Processed 1 resource",
        )
        return ProviderResult(resources=resources, moments=[moment])
```

## User Profile Schema

Platoon accepts p8k8 `UserMetadata` objects directly — no wrapper needed. The library reads `interests` and `categories` from the user's metadata; sources are global config.

**User-specific fields** (from `UserMetadata`):

| Field | Type | Used by pipeline |
|-------|------|-----------------|
| `interests` | `list[str]` | Scoring: interest-boost matching |
| `categories` | `dict` | Scoring: keyword matching, weights, category assignment |
| `relations` | `list[dict] \| None` | Reserved for future personalization |
| `feeds` | `list[dict] \| None` | Reserved for future per-user feed overrides |
| `preferences` | `dict \| None` | Reserved |
| `facts` | `dict \| None` | Reserved |

**Global config** (not per-user):

| Key | Description |
|-----|-------------|
| `sources` | Feed source configs — `{source_name: {enabled, ...}}` |
| `fetcher` | HTTP settings — timeout, retries, user-agent |
| `output` | Render settings — format, max items, min score |

## Percolate Integration

p8platoon produces entities compatible with percolate's data model:

- **P8Resource** — Maps to percolate's `resources` table. One per article/item with `category="news"`, source tags, engagement metadata, and deterministic UUID5 IDs.
- **P8Moment** — Maps to percolate's `moments` table. One per digest run, links resources via `graph_edges`, contains run statistics.

All entities use deterministic UUID5 IDs matching percolate's `uuid5(P8_NAMESPACE, "table:key:user_id")` scheme, ensuring upserts are idempotent.

### Resource fields

| Feed Item | P8Resource | Notes |
|-----------|------------|-------|
| `title` | `name` | Article title |
| `url` | `uri` | Article URL (also used for deterministic ID) |
| `summary` | `content` | Truncated summary |
| `image_url` | `image_uri` | 3-tier fallback ensures coverage |
| `source` | `tags[]` | e.g. "reddit", "google_news", "web_search" |
| `tags` | `tags[]` | Merged with source tag |
| `score` | `metadata.score` | Deterministic keyword+engagement score |
| `engagement` | `metadata.engagement` | `{upvotes, comments, stars, citations}` |
| `category` | `metadata.feed_category` | Scored category (AI, Physics, Food, etc.) |
| — | `category` | Always `"news"` |

## License

MIT
