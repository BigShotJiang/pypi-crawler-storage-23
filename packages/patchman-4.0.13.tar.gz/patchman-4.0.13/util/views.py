# Copyright 2012 VPAC, http://www.vpac.org
# Copyright 2013-2021 Marcus Furlong <furlongm@gmail.com>
#
# This file is part of Patchman.
#
# Patchman is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3 only.
#
# Patchman is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Patchman. If not, see <http://www.gnu.org/licenses/>

from datetime import timedelta

from django.contrib.auth.decorators import login_required
from django.contrib.sites.models import Site
from django.db.models import F
from django.shortcuts import render
from django.utils import timezone

from hosts.models import Host
from operatingsystems.models import OSRelease, OSVariant
from packages.models import Package
from reports.models import Report
from repos.models import Mirror, Repository
from util import get_setting_of_type


@login_required
def dashboard(request):

    try:
        site = Site.objects.get_current()
    except Site.DoesNotExist:
        site = {'name': '', 'domainname': ''}

    hosts = Host.objects.all()
    osvariants = OSVariant.objects.all()
    osreleases = OSRelease.objects.all()
    repos = Repository.objects.all()
    packages = Package.objects.all()

    # host issues
    days = get_setting_of_type(
        setting_name='DAYS_WITHOUT_REPORT',
        setting_type=int,
        default=14,
    )
    last_report_delta = timezone.now() - timedelta(days=days)
    stale_hosts = hosts.filter(lastreport__lt=last_report_delta)
    norepo_hosts = hosts.filter(repos__isnull=True, osvariant__osrelease__repos__isnull=True)  # noqa
    reboot_hosts = hosts.filter(reboot_required=True)
    # Use cached count fields instead of expensive M2M JOINs
    secupdate_hosts = hosts.filter(sec_updates_count__gt=0)
    bugupdate_hosts = hosts.filter(bug_updates_count__gt=0, sec_updates_count=0)
    diff_rdns_hosts = hosts.exclude(reversedns=F('hostname')).filter(check_dns=True)  # noqa

    # os variant issues
    noosrelease_osvariants = osvariants.filter(osrelease__isnull=True)
    nohost_osvariants = osvariants.filter(host__isnull=True)

    # os release issues
    norepo_osreleases = None
    if hosts.filter(host_repos_only=False).exists():
        norepo_osreleases = osreleases.filter(repos__isnull=True)

    # mirror issues
    failed_mirrors = repos.filter(auth_required=False).filter(mirror__last_access_ok=False).filter(mirror__last_access_ok=True).distinct()  # noqa
    disabled_mirrors = repos.filter(auth_required=False).filter(mirror__enabled=False).filter(mirror__mirrorlist=False).distinct()  # noqa
    norefresh_mirrors = repos.filter(auth_required=False).filter(mirror__refresh=False).distinct()  # noqa

    # repo issues
    failed_repos = repos.filter(auth_required=False).filter(mirror__last_access_ok=False).exclude(id__in=[x.id for x in failed_mirrors]).distinct()  # noqa
    unused_repos = repos.filter(host__isnull=True, osrelease__isnull=True)
    nomirror_repos = repos.filter(mirror__isnull=True)
    nohost_repos = repos.filter(host__isnull=True)

    # package issues
    norepo_packages = packages.filter(mirror__isnull=True, oldpackage__isnull=True, host__isnull=False).distinct()  # noqa
    orphaned_packages = packages.filter(mirror__isnull=True, host__isnull=True).distinct()  # noqa

    # report issues
    unprocessed_reports = Report.objects.filter(processed=False)

    checksums = {}
    possible_mirrors = {}

    # Use cached packages_count to avoid N+1 queries
    for csvalue in Mirror.objects.filter(packages_count__gt=0).values('packages_checksum').distinct():
        checksum = csvalue['packages_checksum']
        if checksum is not None and checksum != 'yast':
            mirrors = list(Mirror.objects.filter(
                packages_checksum=checksum,
                packages_count__gt=0
            ).select_related('repo'))
            if mirrors:
                checksums[checksum] = mirrors

    for checksum in checksums:
        first_mirror = checksums[checksum][0]
        for mirror in checksums[checksum]:
            if mirror.repo != first_mirror.repo and \
                    mirror.repo.arch == first_mirror.repo.arch and \
                    mirror.repo.repotype == first_mirror.repo.repotype:
                possible_mirrors[checksum] = checksums[checksum]
                continue

    has_issues = (
        noosrelease_osvariants.exists() or
        nohost_osvariants.exists() or
        (norepo_osreleases is not None and norepo_osreleases.exists()) or
        stale_hosts.exists() or
        reboot_hosts.exists() or
        secupdate_hosts.exists() or
        bugupdate_hosts.exists() or
        norepo_hosts.exists() or
        diff_rdns_hosts.exists() or
        failed_mirrors.exists() or
        disabled_mirrors.exists() or
        norefresh_mirrors.exists() or
        failed_repos.exists() or
        unused_repos.exists() or
        nomirror_repos.exists() or
        nohost_repos.exists() or
        bool(possible_mirrors) or
        norepo_packages.exists()
    )

    return render(
        request,
        'dashboard.html',
        {'site': site,
         'has_issues': has_issues,
         'noosrelease_osvariants': noosrelease_osvariants,
         'norepo_hosts': norepo_hosts,
         'nohost_osvariants': nohost_osvariants,
         'diff_rdns_hosts': diff_rdns_hosts,
         'stale_hosts': stale_hosts,
         'possible_mirrors': possible_mirrors,
         'norepo_packages': norepo_packages,
         'nohost_repos': nohost_repos,
         'secupdate_hosts': secupdate_hosts,
         'bugupdate_hosts': bugupdate_hosts,
         'norepo_osreleases': norepo_osreleases,
         'unused_repos': unused_repos,
         'disabled_mirrors': disabled_mirrors,
         'norefresh_mirrors': norefresh_mirrors,
         'failed_mirrors': failed_mirrors,
         'orphaned_packages': orphaned_packages,
         'failed_repos': failed_repos,
         'nomirror_repos': nomirror_repos,
         'reboot_hosts': reboot_hosts,
         'unprocessed_reports': unprocessed_reports})
