"""Base queue class with send/send_and_wait mechanics."""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

import redis as redis_lib

from queue_sdk.redis_client import response_key, stream_name
from queue_sdk.types import EmailResponse

DEFAULT_TIMEOUT = 30  # seconds


class BaseQueue:
    """Base queue providing core send/send_and_wait mechanics for any queue type."""

    def __init__(self, redis_client: redis_lib.Redis, environment: str, queue_name: str):
        self._redis = redis_client
        self._environment = environment
        self._queue_name = queue_name
        # Use hash tags for Redis Cluster slot compatibility
        self._stream = stream_name(environment, "{" + queue_name + "}")

    def _enqueue(self, payload: dict[str, Any]) -> str:
        """Add a message to the stream and return the request ID."""
        request_id = str(uuid.uuid4())
        message = {
            "requestId": request_id,
            "payload": json.dumps(payload),
            "createdAt": datetime.now(timezone.utc).isoformat(),
        }

        self._redis.xadd(self._stream, message)
        return request_id

    def _enqueue_and_wait(
        self, payload: dict[str, Any], timeout: Optional[int] = None
    ) -> EmailResponse:
        """Add a message and wait for the response."""
        request_id = self._enqueue(payload)
        wait_timeout = timeout if timeout is not None else DEFAULT_TIMEOUT

        key = response_key(self._environment, self._queue_name, request_id)

        # BRPOP blocks until a response is pushed or timeout
        result = self._redis.brpop(key, timeout=wait_timeout)

        if result is None:
            return EmailResponse(
                success=False,
                message_id=request_id,
                error=f"Timeout waiting for response after {wait_timeout}s",
            )

        try:
            # result is (key, value) tuple
            response_data = json.loads(result[1])
            return EmailResponse(
                success=response_data.get("success", False),
                message_id=response_data.get("messageId", request_id),
                error=response_data.get("error"),
                processed_at=response_data.get("processedAt"),
            )
        except (json.JSONDecodeError, KeyError):
            return EmailResponse(
                success=False,
                message_id=request_id,
                error="Failed to parse response from queue",
            )
