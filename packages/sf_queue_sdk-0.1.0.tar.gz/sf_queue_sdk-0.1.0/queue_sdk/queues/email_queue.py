"""Email queue with typed methods."""

from typing import Any, Optional

import redis as redis_lib

from queue_sdk.queues.base_queue import BaseQueue
from queue_sdk.sanitize import sanitize, sanitize_list
from queue_sdk.types import (
    BatchEmailResponse,
    EmailResponse,
    SendResult,
)


class EmailQueue(BaseQueue):
    """Typed methods for sending emails via the queue."""

    def __init__(self, redis_client: redis_lib.Redis, environment: str):
        super().__init__(redis_client, environment, "email")

    def send(
        self,
        to: str,
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]] = None,
        reply_to: Optional[str] = None,
        image: Optional[dict[str, Any]] = None,
    ) -> SendResult:
        """Enqueue an email for processing (fire and forget)."""
        payload = self._build_payload(to, preview, subject, paragraphs, button, reply_to, image)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def send_and_wait(
        self,
        to: str,
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]] = None,
        reply_to: Optional[str] = None,
        image: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> EmailResponse:
        """Enqueue an email and wait for processing confirmation."""
        payload = self._build_payload(to, preview, subject, paragraphs, button, reply_to, image)
        return self._enqueue_and_wait(payload, timeout)

    def send_batch(
        self,
        to: list[str],
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]] = None,
        reply_to: Optional[str] = None,
        image: Optional[dict[str, Any]] = None,
    ) -> SendResult:
        """Enqueue a batch email for processing (fire and forget)."""
        self._validate_batch(to)
        payload = self._build_batch_payload(to, preview, subject, paragraphs, button, reply_to, image)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def send_batch_and_wait(
        self,
        to: list[str],
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]] = None,
        reply_to: Optional[str] = None,
        image: Optional[dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> BatchEmailResponse:
        """Enqueue a batch email and wait for processing confirmation."""
        self._validate_batch(to)
        payload = self._build_batch_payload(to, preview, subject, paragraphs, button, reply_to, image)
        response = self._enqueue_and_wait(payload, timeout)

        return BatchEmailResponse(
            success=response.success,
            message_id=response.message_id,
            error=response.error,
            processed_at=response.processed_at,
            total=getattr(response, "total", len(to)),
            successful=getattr(response, "successful", len(to) if response.success else 0),
            failed=getattr(response, "failed", 0 if response.success else len(to)),
        )

    def _build_payload(
        self,
        to: str,
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]],
        reply_to: Optional[str],
        image: Optional[dict[str, Any]],
    ) -> dict[str, Any]:
        """Build and sanitize the email payload."""
        payload: dict[str, Any] = {
            "to": to,
            "preview": sanitize(preview),
            "subject": sanitize(subject),
            "paragraphs": sanitize_list(paragraphs),
        }

        if button:
            payload["button"] = {
                "text": sanitize(button["text"]),
                "href": button["href"],
            }

        if reply_to:
            payload["replyTo"] = reply_to

        if image:
            payload["image"] = {
                "src": image.get("src", ""),
                "alt": image.get("alt", ""),
                "width": image.get("width"),
                "height": image.get("height"),
            }

        return payload

    def _build_batch_payload(
        self,
        to: list[str],
        preview: str,
        subject: str,
        paragraphs: list[str],
        button: Optional[dict[str, str]],
        reply_to: Optional[str],
        image: Optional[dict[str, Any]],
    ) -> dict[str, Any]:
        """Build and sanitize the batch email payload."""
        payload = self._build_payload(
            to="",  # not used for batch
            preview=preview,
            subject=subject,
            paragraphs=paragraphs,
            button=button,
            reply_to=reply_to,
            image=image,
        )
        payload["to"] = to
        payload["batch"] = True
        return payload

    @staticmethod
    def _validate_batch(to: list[str]) -> None:
        """Validate batch constraints."""
        if len(to) > 100:
            raise ValueError("Maximum 100 recipients allowed per batch request")
        if len(to) == 0:
            raise ValueError("At least one recipient is required")
