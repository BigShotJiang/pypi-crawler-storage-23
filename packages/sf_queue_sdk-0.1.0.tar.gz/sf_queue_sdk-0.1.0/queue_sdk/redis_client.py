"""Redis connection factory."""

from urllib.parse import urlparse

import redis

from queue_sdk.types import QueueClientConfig


def create_redis_client(config: QueueClientConfig) -> redis.Redis:
    """Create a Redis client from the SDK config."""
    url = config.redis_url
    password = config.redis_password

    # Full URL format (redis://... or rediss://...)
    if url.startswith("redis://") or url.startswith("rediss://"):
        parsed = urlparse(url)
        effective_password = password or parsed.password or None
        return redis.Redis(
            host=parsed.hostname or "localhost",
            port=parsed.port or 6379,
            password=effective_password,
            decode_responses=True,
        )

    # Simple host:port format
    parts = url.split(":")
    host = parts[0] if parts[0] else "localhost"
    port = int(parts[1]) if len(parts) > 1 else 6379

    return redis.Redis(
        host=host,
        port=port,
        password=password or None,
        decode_responses=True,
    )


def stream_name(env: str, base: str) -> str:
    """Return the full stream name with environment prefix."""
    if not env:
        return base
    return f"{env}:{base}"


def response_key(env: str, queue: str, request_id: str) -> str:
    """Return the response list key for a given queue and request ID."""
    key = f"{queue}:response:{request_id}"
    if not env:
        return key
    return f"{env}:{key}"
