"""sf-queue Python SDK - Redis-based queue system."""

__version__ = "0.1.0"

from queue_sdk.client import QueueClient
from queue_sdk.types import (
    BatchEmailResponse,
    EmailButton,
    EmailData,
    EmailImage,
    EmailResponse,
    QueueClientConfig,
    SendResult,
)

__all__ = [
    "QueueClient",
    "QueueClientConfig",
    "EmailData",
    "EmailButton",
    "EmailImage",
    "EmailResponse",
    "BatchEmailResponse",
    "SendResult",
]
