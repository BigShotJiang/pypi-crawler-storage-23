"""Basic HTML sanitization for email content."""

import re

_HTML_TAG_REGEX = re.compile(r"<[^>]*>")


def sanitize(text: str) -> str:
    """Strip HTML tags from a string."""
    return _HTML_TAG_REGEX.sub("", text)


def sanitize_list(texts: list[str]) -> list[str]:
    """Sanitize each string in a list."""
    return [sanitize(t) for t in texts]
