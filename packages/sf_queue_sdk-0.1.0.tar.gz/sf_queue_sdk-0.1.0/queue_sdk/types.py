"""Type definitions for the queue SDK."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class QueueClientConfig:
    """Configuration for the QueueClient."""

    redis_url: str
    redis_password: str
    environment: str


@dataclass
class EmailButton:
    """CTA button for email."""

    text: str
    href: str


@dataclass
class EmailImage:
    """Optional image for email."""

    src: str
    alt: str = ""
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class EmailData:
    """Data for a single email."""

    to: str
    preview: str
    subject: str
    paragraphs: list[str]
    button: Optional[EmailButton] = None
    reply_to: Optional[str] = None
    image: Optional[EmailImage] = None


@dataclass
class BatchEmailData:
    """Data for a batch email (same content to multiple recipients)."""

    to: list[str]
    preview: str
    subject: str
    paragraphs: list[str]
    button: Optional[EmailButton] = None
    reply_to: Optional[str] = None
    image: Optional[EmailImage] = None


@dataclass
class SendResult:
    """Result of a fire-and-forget send."""

    message_id: str


@dataclass
class EmailResponse:
    """Response from a processed email."""

    success: bool
    message_id: str
    error: Optional[str] = None
    processed_at: Optional[str] = None


@dataclass
class BatchEmailResponse:
    """Response from a processed batch email."""

    success: bool
    message_id: str
    total: int
    successful: int
    failed: int
    error: Optional[str] = None
    processed_at: Optional[str] = None
