"""QueueClient - main entry point for the Python SDK."""

from queue_sdk.queues.email_queue import EmailQueue
from queue_sdk.redis_client import create_redis_client
from queue_sdk.types import QueueClientConfig


class QueueClient:
    """Main entry point for the sf-queue Python SDK.

    Initialize with Redis connection details and environment,
    then use typed queue properties to send messages.

    Usage:
        client = QueueClient(
            redis_url="redis://localhost:6379",
            redis_password="your-password",
            environment="staging",
        )

        # Fire and forget
        result = client.email.send(
            to="user@example.com",
            preview="Welcome!",
            subject="Welcome!",
            paragraphs=["Hello!", "Welcome to our platform."],
        )

        # Send and wait for confirmation
        response = client.email.send_and_wait(
            to="user@example.com",
            preview="Welcome!",
            subject="Welcome!",
            paragraphs=["Hello!"],
            timeout=30,
        )
    """

    def __init__(
        self,
        redis_url: str,
        redis_password: str,
        environment: str,
    ):
        config = QueueClientConfig(
            redis_url=redis_url,
            redis_password=redis_password,
            environment=environment,
        )
        self._redis = create_redis_client(config)
        self._environment = environment

        # Initialize queue instances
        self.email = EmailQueue(self._redis, self._environment)

    def disconnect(self) -> None:
        """Close the Redis connection."""
        self._redis.close()
