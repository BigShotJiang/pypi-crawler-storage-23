"""VERONICA Audit — tamper-evident append-only log."""
from veronica_core.audit.log import AuditLog

__all__ = ["AuditLog"]
