"""
Sanna MCP server — Model Context Protocol integration.

Exposes Sanna receipt verification, generation, and check inspection
as MCP tools for use with Claude Desktop, Cursor, and other MCP clients.
"""
