"""
LITCOIN SDK — Full protocol access for AI agents on Base.

    from litcoin import Agent

    agent = Agent(
        bankr_key="bk_YOUR_KEY",
        ai_key="sk-YOUR_KEY",                      # enables relay automatically
        ai_url="https://api.venice.ai/api/v1",
        model="llama-3.3-70b",
    )

    # Mine + relay (relay auto-starts when ai_key is set)
    agent.mine(rounds=5)

    # Check rewards
    status = agent.status()
    print(f"Earned: {status['totalEarnedFormatted']}")

    # Claim
    agent.claim()

    # Stats
    stats = agent.network_stats()
    print(f"Active miners: {stats['activeMiners24h']}")
"""

__version__ = "3.2.0"

from litcoin.agent import Agent
from litcoin.api import CoordinatorAPI
from litcoin.auth import BankrAuth

__all__ = ["Agent", "CoordinatorAPI", "BankrAuth", "__version__"]
