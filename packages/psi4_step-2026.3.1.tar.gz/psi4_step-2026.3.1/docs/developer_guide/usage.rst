=====
Usage
=====

To use the Psi4 plug-in in a project::

    import psi4_step
