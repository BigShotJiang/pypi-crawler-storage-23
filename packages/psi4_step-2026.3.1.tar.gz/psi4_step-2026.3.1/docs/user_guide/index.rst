.. _user-guide:

**********
User Guide
**********
The Psi4 plug-in provides access to many different quantum chemical calculations usign
the Psi4 code.

..
   The following sections cover accessing and controlling this functionality.

   .. toctree::
      :maxdepth: 2
      :titlesonly:

Index
=====

* :ref:`genindex`
