from setuptools import setup, find_packages

setup(
    name="omega-ledger",
    version="1.0.0",
    description="Singapore-Zenith-Mainnet Unitary Ledger",
    author="SimoesCTT",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pyyaml",
    ],
    entry_points={
        "console_scripts": [
            "omega-node=omega_node:run_from_cli",
        ],
    },
)
