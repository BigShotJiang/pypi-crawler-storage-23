import sys
import yaml
import os

# Define path to the engine - still supporting local Sovereign-Logic dev
engine_path = os.path.expanduser('~/Sovereign-Logic')
if engine_path not in sys.path:
    sys.path.insert(0, engine_path)

def run_genesis_sync(config_path):
    print("--- OMEGA-LEDGER GENESIS INITIALIZATION ---")
    try:
        from sovereign_logic import bridge
        
        if not os.path.exists(config_path):
            print(f"[!] Error: Config file not found at {config_path}")
            return

        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)
        
        print(f"[*] Network: {cfg['network']['name']}")
        
        # Initializing the confirmed Class: SovereignBridge
        node = bridge.SovereignBridge()
        
        # Vectorized input for the 32M manifold handshake
        precision_signal = [float(cfg['engine']['precision'])]
        
        # Handshake with the C++ Core
        result = node.bridge_signal(precision_signal)
        
        print(f"[+] SUCCESS: Engine returned Complex Phase: {result}")
        print(f"[+] ANCHOR: {cfg['network']['genesis_anchor']}")
        print("[!] NODE STATUS: ABSOLUTE")
        
    except Exception as e:
        print(f"[!] Bridge call failed: {e}")

def run_from_cli():
    """Entry point for the console_script 'omega-node'"""
    if "--init" in sys.argv and "--config" in sys.argv:
        try:
            config_idx = sys.argv.index("--config") + 1
            run_genesis_sync(sys.argv[config_idx])
        except (IndexError, ValueError):
            print("Error: --config requires a valid path.")
    else:
        print("Usage: omega-node --init --config <path_to_yaml>")

if __name__ == "__main__":
    run_from_cli()
