from src.application.todo import ListTodoResult


class ListTodoResultDTO(ListTodoResult):
    pass
